# QCOM MD&A — 0000804328-23-000043


## mdna

[0000804328-23-000043:mdna:1]
[same as prior period, unchanged from 0000804328-23-000023:mdna:1]

[0000804328-23-000043:mdna:2]
[same as prior period, unchanged from 0000804328-23-000023:mdna:2]

[0000804328-23-000043:mdna:3]
This Quarterly Report (including but not limited to this section titled Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates,” “may,” “will,” “would” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report. Additionally, statements concerning future matters such as our future business, prospects, results of operations or financial condition; research and development or technology investments; new or enhanced products, services or technologies; emerging industries or business models; design wins or product launches; industry, market or technology trends, dynamics or transitions; our expectations regarding future demand or supply conditions or macroeconomic factors; strategic investments or acquisitions, and the anticipated timing or benefits thereof; cost reduction initiatives, associated restructuring charges and the anticipated timing thereof; legal or regulatory matters; U.S./China trade or national security tensions; vertical integration by our customers; competition; annual effective tax rates; and other statements regarding matters that are not historical are also forward-looking statements.

[0000804328-23-000043:mdna:4]
Third Quarter Fiscal 2023 Overview

[0000804328-23-000043:mdna:5]
Revenues for the third quarter of fiscal 2023 were $8.5 billion, a decrease of 23% compared to the year ago quarter, with net income of $1.8 billion, a decrease of 52% compared to the year ago quarter. Key items from the third quarter of fiscal 2023 included:

[0000804328-23-000043:mdna:6]
•Revenues were negatively impacted by the weakness in the macroeconomic environment (which negatively impacted consumer demand for smartphones and other devices that incorporate our products and technologies) and our customers drawing down on their inventory (which remained at elevated levels).

[0000804328-23-000043:mdna:7]
•QCT revenues decreased by 24% in the third quarter of fiscal 2023 compared to the year ago quarter primarily due to lower handset and IoT revenues.

[0000804328-23-000043:mdna:8]
•QTL revenues decreased by 19% in the third quarter of fiscal 2023 compared to the year ago quarter.

[0000804328-23-000043:mdna:9]
[same as prior period, unchanged from 0000804328-23-000023:mdna:9]

[0000804328-23-000043:mdna:10]
[same as prior period, unchanged from 0000804328-23-000023:mdna:10]

[0000804328-23-000043:mdna:11]
[same as prior period, unchanged from 0000804328-23-000023:mdna:11]

[0000804328-23-000043:mdna:12]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering and research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated,

[0000804328-23-000043:mdna:13]
and QTI’s subsidiaries. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0000804328-23-000043:mdna:14]
[same as prior period, unchanged from 0000804328-23-000023:mdna:15]

[0000804328-23-000043:mdna:15]
[same as prior period, unchanged from 0000804328-23-000023:mdna:16]

[0000804328-23-000043:mdna:16]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | Change |  | June 25,2023 |  | June 26,2022 |  | Change |
| Equipment and services | $ | 7,108 |  |  | $ | 9,266 |  |  | $ | (2,158) |  |  | $ | 22,737 |  |  | $ | 27,365 |  |  | $ | (4,628) |  |
| Licensing | 1,343 |  |  | 1,670 |  |  | (327) |  |  | 4,452 |  |  | 5,440 |  |  | (988) |  |
|  | $ | 8,451 |  |  | $ | 10,936 |  |  | $ | (2,485) |  |  | $ | 27,189 |  |  | $ | 32,805 |  |  | $ | (5,616) |  |

[0000804328-23-000043:mdna:17]
Third quarter 2023 vs. 2022

[0000804328-23-000043:mdna:18]
The decrease in revenues in the third quarter of fiscal 2023 was primarily due to:

[0000804328-23-000043:mdna:19]
-    $2.2 billion in lower equipment and services revenues from our QCT segment

[0000804328-23-000043:mdna:20]
-    $289 million in lower licensing revenues from our QTL segment

[0000804328-23-000043:mdna:21]
First nine months 2023 vs. 2022

[0000804328-23-000043:mdna:22]
The decrease in revenues in the first nine months of fiscal 2023 was primarily due to:

[0000804328-23-000043:mdna:23]
-    $4.6 billion in lower equipment and services revenues from our QCT segment

[0000804328-23-000043:mdna:24]
-    $873 million in lower licensing revenues from our QTL segment

[0000804328-23-000043:mdna:25]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | Change |  | June 25,2023 |  | June 26,2022 |  | Change |
| Cost of revenues | $ | 3,792 |  |  | $ | 4,816 |  |  | $ | (1,024) |  |  | $ | 11,989 |  |  | $ | 13,767 |  |  | $ | (1,778) |  |
| Gross margin | 55 | % |  | 56 | % |  |  |  | 56 | % |  | 58 | % |  |  |

[0000804328-23-000043:mdna:26]
Third quarter and first nine months 2023 vs. 2022

[0000804328-23-000043:mdna:27]
Gross margin percentage decreased in the third quarter and first nine months of fiscal 2023 primarily due to a decrease in QCT gross margin.

[0000804328-23-000043:mdna:28]
22

[0000804328-23-000043:mdna:29]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | Change |  | June 25,2023 |  | June 26,2022 |  | Change |
| Research and development | $ | 2,222 |  |  | $ | 2,052 |  |  | $ | 170 |  |  | $ | 6,683 |  |  | $ | 6,016 |  |  | $ | 667 |  |
| % of revenues | 26 | % |  | 19 | % |  |  |  | 25 | % |  | 18 | % |  |  |

[0000804328-23-000043:mdna:30]
Third quarter 2023 vs. 2022

[0000804328-23-000043:mdna:31]
The increase in research and development expenses in the third quarter of fiscal 2023 was primarily due to:

[0000804328-23-000043:mdna:32]
+    $80 million increase in share-based compensation expense

[0000804328-23-000043:mdna:33]
+    $71 million increase in expenses driven by revaluation of our deferred compensation plan obligation on higher relative stock market performance

[0000804328-23-000043:mdna:34]
First nine months 2023 vs. 2022

[0000804328-23-000043:mdna:35]
The increase in research and development expenses in the first nine months of fiscal 2023 was primarily due to:

[0000804328-23-000043:mdna:36]
+    $296 million increase in share-based compensation expense

[0000804328-23-000043:mdna:37]
+    $256 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), primarily driven by an increase in employee-related expenses (which included lower employee cash incentive program costs)

[0000804328-23-000043:mdna:38]
+    $114 million increase in expenses driven by revaluation of our deferred compensation plan obligation on higher relative stock market performance

[0000804328-23-000043:mdna:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | Change |  | June 25,2023 |  | June 26,2022 |  | Change |
| Selling, general and administrative | $ | 618 |  |  | $ | 655 |  |  | $ | (37) |  |  | $ | 1,854 |  |  | $ | 1,887 |  |  | $ | (33) |  |
| % of revenues | 7 | % |  | 6 | % |  |  |  | 7 | % |  | 6 | % |  |  |

[0000804328-23-000043:mdna:40]
Third quarter 2023 vs. 2022

[0000804328-23-000043:mdna:41]
The decrease in selling, general and administrative expenses in the third quarter of fiscal 2023 was primarily due to:

[0000804328-23-000043:mdna:42]
-    $60 million decrease in acquisition-related expenses, primarily related to the Veoneer transaction which closed in the third quarter of fiscal 2022

[0000804328-23-000043:mdna:43]
-    $38 million decrease in employee-related expenses (which included lower employee cash incentive program costs)

[0000804328-23-000043:mdna:44]
+    $55 million increase in expenses driven by revaluation of our deferred compensation plan obligation on higher relative stock market performance

[0000804328-23-000043:mdna:45]
First nine months 2023 vs. 2022

[0000804328-23-000043:mdna:46]
The decrease in selling, general and administrative expenses in the first nine months of fiscal 2023 was primarily due to:

[0000804328-23-000043:mdna:47]
-    $83 million decrease in employee-related expenses (which included lower employee cash incentive program costs)

[0000804328-23-000043:mdna:48]
-    $71 million decrease in acquisition-related expenses, primarily related to the Veoneer transaction which closed in the third quarter of fiscal 2022

[0000804328-23-000043:mdna:49]
+    $87 million increase in expenses driven by revaluation of our deferred compensation plan obligation on higher relative stock market performance

[0000804328-23-000043:mdna:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | Change |  | June 25,2023 |  | June 26,2022 |  | Change |
| Other (income) expense | $ | (4) |  |  | $ | (1,059) |  |  | $ | 1,055 |  |  | $ | 285 |  |  | $ | (1,059) |  |  | $ | 1,344 |  |

[0000804328-23-000043:mdna:51]
Third quarter and first nine months 2023 vs. 2022

[0000804328-23-000043:mdna:52]
Other expense in the first nine months of fiscal 2023 consisted of restructuring and restructuring-related charges, substantially all of which related to severance costs, resulting from certain cost reduction initiatives committed to in fiscal 2023. Additional information regarding our restructuring charges is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Other Income, Costs and Expenses.”

[0000804328-23-000043:mdna:53]
Other income in the third quarter and first nine months of fiscal 2022 consisted of a $1.1 billion benefit resulting from the 2018 EC fine reversal.

[0000804328-23-000043:mdna:54]
| Interest Expense and Investment and Other Income (Expense), Net (in millions) |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | Change |  | June 25,2023 |  | June 26,2022 |  | Change |
| Interest expense | $ | 172 |  |  | $ | 70 |  |  | $ | 102 |  |  | $ | 521 |  |  | $ | 345 |  |  | $ | 176 |  |
| Investment and other income (expense), net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 79 |  |  | $ | 22 |  |  | $ | 57 |  |  | $ | 193 |  |  | $ | 59 |  |  | $ | 134 |  |
| Net losses on marketable securities | (23) |  |  | (104) |  |  | 81 |  |  | (3) |  |  | (327) |  |  | 324 |  |
| Net gains on other investments | 17 |  |  | 25 |  |  | (8) |  |  | 17 |  |  | 97 |  |  | (80) |  |
| Net gains (losses) on deferred compensation plan assets | 48 |  |  | (80) |  |  | 128 |  |  | 95 |  |  | (110) |  |  | 205 |  |
| Impairment losses on other investments | (19) |  |  | (20) |  |  | 1 |  |  | (120) |  |  | (41) |  |  | (79) |  |
| Other | 4 |  |  | (6) |  |  | 10 |  |  | (16) |  |  | 1 |  |  | (17) |  |
|  | $ | 106 |  |  | $ | (163) |  |  | $ | 269 |  |  | $ | 166 |  |  | $ | (321) |  |  | $ | 487 |  |

[0000804328-23-000043:mdna:55]
Interest expense for the three and nine months ended June 26, 2022 included a $62 million reversal of accrued interest previously recorded related to the annulled 2018 EC fine.

[0000804328-23-000043:mdna:56]
Net losses on marketable securities for the three and nine months ended June 26, 2022 was primarily driven by the change in fair value of certain of our QSI marketable equity investments in early or growth stage companies.

[0000804328-23-000043:mdna:57]
[same as prior period, unchanged from 0000804328-23-000023:mdna:51]

[0000804328-23-000043:mdna:58]
[same as prior period, unchanged from 0000804328-23-000023:mdna:46]

[0000804328-23-000043:mdna:59]
[same as prior period, unchanged from 0000804328-23-000023:mdna:47]

[0000804328-23-000043:mdna:60]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | June 25,2023 |  | June 26,2022 |
| Expected income tax provision at federal statutory tax rate | $ | 369 |  |  | $ | 890 |  |  | $ | 1,265 |  |  | $ | 2,421 |  |
| Benefit from foreign-derived intangible income (FDII) deduction, excluding the impact of capitalizing research and development expenditures | (129) |  |  | (222) |  |  | (338) |  |  | (566) |  |
| Benefit from FDII deduction related to capitalizing research and development expenditures | (58) |  |  | — |  |  | (310) |  |  | — |  |
| Benefit related to the research and development tax credit | (61) |  |  | (49) |  |  | (183) |  |  | (153) |  |
| Benefit from fiscal 2021 and 2022 FDII deductions related to a change in sourcing of research and development expenditures | (126) |  |  | — |  |  | (126) |  |  | — |  |
| Foreign currency losses (gains) related to foreign withholding tax receivable | 11 |  |  | 87 |  |  | (103) |  |  | 135 |  |
| Nontaxable reversal of 2018 EC fine | — |  |  | (166) |  |  | — |  |  | (166) |  |
| Shortfall (excess) tax benefit associated with share-based awards | 19 |  |  | (39) |  |  | (2) |  |  | (254) |  |
| Other | (3) |  |  | 8 |  |  | 110 |  |  | 48 |  |
| Income tax expense | $ | 22 |  |  | $ | 509 |  |  | $ | 313 |  |  | $ | 1,465 |  |
| Effective tax rate | 1 | % |  | 12 | % |  | 5 | % |  | 13 | % |

[0000804328-23-000043:mdna:61]
We estimate our annual effective income tax rate to be 6% for fiscal 2023, which is lower than the U.S. federal statutory rate. Additional information regarding our annual effective income tax rate and income tax expense (including discussion related to the impact of the new requirement to capitalize research and development expenditures for federal income tax purposes) is provided in this Quarterly Report in “Notes to Condensed Consolidated Statements, Note 3. Income Taxes.”

[0000804328-23-000043:mdna:62]
| Discontinued Operations (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | Change |  | June 25,2023 |  | June 26,2022 |  | Change |
| Discontinued operations, net of income taxes | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |  | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |

[0000804328-23-000043:mdna:63]
Discontinued operations in the third quarter and first nine months of fiscal 2023 primarily related to a $183 million gain (net of income tax expense) recognized upon the sale of the Active Safety business, partially offset by net losses from the Non-Arriver businesses. Information regarding the Non-Arriver businesses, including the Active Safety business, is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 8. Acquisitions and Divestitures.”

[0000804328-23-000043:mdna:64]
25

[0000804328-23-000043:mdna:65]
[same as prior period, unchanged from 0000804328-23-000023:mdna:53]

[0000804328-23-000043:mdna:66]
The following should be read in conjunction with our financial results for the third quarter of fiscal 2023 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0000804328-23-000043:mdna:67]
[same as prior period, unchanged from 0000804328-23-000023:mdna:55]

[0000804328-23-000043:mdna:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | Change |  | June 25,2023 |  | June 26,2022 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets | $ | 5,255 |  |  | $ | 7,047 |  |  | $ | (1,792) |  |  | $ | 17,114 |  |  | $ | 21,385 |  |  | $ | (4,271) |  |
| Automotive | 434 |  |  | 385 |  |  | 49 |  |  | 1,337 |  |  | 1,044 |  |  | 293 |  |
| IoT (internet of things) | 1,485 |  |  | 1,946 |  |  | (461) |  |  | 4,557 |  |  | 5,344 |  |  | (787) |  |
| Total revenues (1) | $ | 7,174 |  |  | $ | 9,378 |  |  | $ | (2,204) |  |  | $ | 23,008 |  |  | $ | 27,773 |  |  | $ | (4,765) |  |
| EBT (2) | $ | 1,744 |  |  | $ | 2,996 |  |  | $ | (1,252) |  |  | $ | 6,035 |  |  | $ | 9,450 |  |  | $ | (3,415) |  |
| EBT as a % of revenues | 24 | % |  | 32 | % |  | -8 points |  | 26 | % |  | 34 | % |  | -8 points |

[0000804328-23-000043:mdna:69]
(1) Beginning in the first quarter of fiscal 2023, QCT RFFE (radio frequency front-end) revenues, which were previously presented as a separate revenue stream, are now included within our Handset, Automotive and internet of things (IoT) revenue streams, as applicable, based on the industry and application in which the related RFFE products are sold. Prior period information has been recast to reflect this change. Descriptions of our three QCT revenue streams can be found in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items.”

[0000804328-23-000043:mdna:70]
(2) Earnings before income taxes.

[0000804328-23-000043:mdna:71]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $7.1 billion and $9.2 billion in the third quarter of fiscal 2023 and 2022, respectively and $22.6 billion and $27.3 billion in the first nine months of fiscal 2023 and 2022, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets as well as sales of 4G, 5G sub 6 and 5G millimeter wave RFFE products.

[0000804328-23-000043:mdna:72]
Third quarter 2023 vs. 2022

[0000804328-23-000043:mdna:73]
The decrease in QCT revenues in the third quarter of fiscal 2023 was primarily due to:

[0000804328-23-000043:mdna:74]
-    lower handsets revenues, primarily driven by $1.9 billion in lower chipset shipments to certain major OEMs (primarily driven by the negative effects of the macroeconomic environment weakness and customers drawing down on their elevated inventory levels), partially offset by $303 million in higher revenues per chipset primarily driven by favorable mix and increases in average selling prices

[0000804328-23-000043:mdna:75]
-    lower IoT revenues, primarily driven by a decrease in demand across consumer, edge networking and industrial products (primarily driven by the negative effects of the macroeconomic environment weakness and elevated customer inventory levels)

[0000804328-23-000043:mdna:76]
QCT EBT as a percentage of revenues decreased in the third quarter of fiscal 2023 primarily due to:

[0000804328-23-000043:mdna:77]
[same as prior period, unchanged from 0000804328-23-000023:mdna:66]

[0000804328-23-000043:mdna:78]
-    lower gross margin percentage, primarily driven by increased product costs, partially offset by lower product reserve charges

[0000804328-23-000043:mdna:79]
First nine months 2023 vs. 2022

[0000804328-23-000043:mdna:80]
The decrease in QCT revenues in the first nine months of fiscal 2023 was primarily due to:

[0000804328-23-000043:mdna:81]
-    lower handsets revenues, primarily driven by $4.9 billion in lower chipset shipments to certain major OEMs (primarily driven by the negative effects of the macroeconomic environment weakness and customers drawing down on their elevated inventory levels), partially offset by $1.1 billion in higher revenues per chipset primarily driven by favorable mix and increases in average selling prices

[0000804328-23-000043:mdna:82]
-    lower IoT revenues, primarily driven by a decrease in demand across consumer and edge networking products (primarily driven by the negative effects of the macroeconomic environment weakness and elevated customer inventory levels)

[0000804328-23-000043:mdna:83]
26

[0000804328-23-000043:mdna:84]
[same as prior period, unchanged from 0000804328-23-000023:mdna:64]

[0000804328-23-000043:mdna:85]
QCT EBT as a percentage of revenues decreased in the first nine months of fiscal 2023 primarily due to:

[0000804328-23-000043:mdna:86]
[same as prior period, unchanged from 0000804328-23-000023:mdna:75]

[0000804328-23-000043:mdna:87]
-    lower gross margin percentage, primarily driven by increased product costs, partially offset by increases in average selling prices

[0000804328-23-000043:mdna:88]
[same as prior period, unchanged from 0000804328-23-000023:mdna:68]

[0000804328-23-000043:mdna:89]
[same as prior period, unchanged from 0000804328-23-000023:mdna:78]

[0000804328-23-000043:mdna:90]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | Change |  | June 25,2023 |  | June 26,2022 |  | Change |
| Licensing revenues | $ | 1,230 |  |  | $ | 1,519 |  |  | $ | (289) |  |  | $ | 4,044 |  |  | $ | 4,917 |  |  | $ | (873) |  |
| EBT | 811 |  |  | 1,080 |  |  | (269) |  |  | 2,799 |  |  | 3,640 |  |  | (841) |  |
| EBT as a % of revenues | 66 | % |  | 71 | % |  | -5 points |  | 69 | % |  | 74 | % |  | -5 points |

[0000804328-23-000043:mdna:91]
Third quarter 2023 vs. 2022

[0000804328-23-000043:mdna:92]
The decrease in QTL licensing revenues in the third quarter of fiscal 2023 was primarily due to:

[0000804328-23-000043:mdna:93]
-    $161 million decrease in volume of estimated sales of 3G/4G/5G-based multimode products, primarily driven by the macroeconomic environment weakness

[0000804328-23-000043:mdna:94]
[same as prior period, unchanged from 0000804328-23-000023:mdna:83]

[0000804328-23-000043:mdna:95]
QTL EBT as a percentage of revenues decreased in the third quarter of fiscal 2023 primarily due to lower revenues.

[0000804328-23-000043:mdna:96]
First nine months 2023 vs. 2022

[0000804328-23-000043:mdna:97]
The decrease in QTL licensing revenues in the first nine months of fiscal 2023 was primarily due to:

[0000804328-23-000043:mdna:98]
-    $665 million decrease in volume of estimated sales of 3G/4G/5G-based multimode products, primarily driven by the macroeconomic environment weakness

[0000804328-23-000043:mdna:99]
-    $136 million decrease in revenues from the ending of the recognition of certain upfront license fee consideration in the first quarter of fiscal 2023 from our long-term license agreement with Nokia

[0000804328-23-000043:mdna:100]
QTL EBT as a percentage of revenues decreased in the first nine months of fiscal 2023 primarily due to lower revenues.

[0000804328-23-000043:mdna:101]
[same as prior period, unchanged from 0000804328-23-000023:mdna:90]

[0000804328-23-000043:mdna:102]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | Change |  | June 25,2023 |  | June 26,2022 |  | Change |
| Equipment and services revenues | $ | 9 |  |  | $ | 8 |  |  | $ | 1 |  |  | $ | 22 |  |  | $ | 22 |  |  | $ | — |  |
| Loss before income taxes | (21) |  |  | (101) |  |  | 80 |  |  | (83) |  |  | (248) |  |  | 165 |  |

[0000804328-23-000043:mdna:103]
Third quarter 2023 vs. 2022

[0000804328-23-000043:mdna:104]
The decrease in QSI loss before income taxes in the third quarter of fiscal 2023 was primarily due to a $72 million decrease in net losses on investments, which was primarily driven by the change in fair value of certain of our marketable equity investments in early or growth stage companies.

[0000804328-23-000043:mdna:105]
First nine months 2023 vs. 2022

[0000804328-23-000043:mdna:106]
The decrease in QSI loss before income taxes in the first nine months of fiscal 2023 was primarily due to a $248 million decrease in net losses on investments, which was primarily driven by the change in fair value of certain of our marketable equity investments in early or growth stage companies, partially offset by a $54 million increase in impairment losses on certain investments.

[0000804328-23-000043:mdna:107]
[same as prior period, unchanged from 0000804328-23-000023:mdna:95]

[0000804328-23-000043:mdna:108]
[same as prior period, unchanged from 0000804328-23-000023:mdna:96]

[0000804328-23-000043:mdna:109]
[same as prior period, unchanged from 0000804328-23-000023:mdna:97]

[0000804328-23-000043:mdna:110]
[same as prior period, unchanged from 0000804328-23-000023:mdna:98]

[0000804328-23-000043:mdna:111]
•We expect the current macroeconomic environment challenges to continue (which will negatively impact demand for smartphones and other devices that incorporate our products and technologies) and that our customers will continue to draw down on their inventory (which remains at elevated levels), and that both of these dynamics will continue to have a negative impact on our revenues, results of operations and cash flows compared to the prior year, and will impact our historical QCT seasonal trends. These dynamics have also contributed to our elevated inventory levels and contribute to the inherent uncertainties in estimating future customer demand, which may increase excess or obsolete inventory or reserve charges if we overestimate such demand, negatively impacting our results of operations and cash flows.

[0000804328-23-000043:mdna:112]
•We expect to continue to see product cost increases from certain of our key semiconductor wafer suppliers compared to the prior year.

[0000804328-23-000043:mdna:113]
[same as prior period, unchanged from 0000804328-23-000023:mdna:101]

[0000804328-23-000043:mdna:114]
•We expect continued intense competition, particularly in China, including from increasing vertical integration by certain of our customers.

[0000804328-23-000043:mdna:115]
•Given the continued uncertainty in the macroeconomic and demand environment, we expect to take additional restructuring actions to enable continued investments in key growth and diversification opportunities. While we are in the process of developing our plans, we currently expect these actions to consist largely of workforce reductions, and in connection with any such actions we would expect to incur significant additional restructuring charges, a substantial portion of which we expect to incur in the fourth quarter of fiscal 2023. We currently anticipate these additional actions to be substantially completed in the first half of fiscal 2024.

[0000804328-23-000043:mdna:116]
[same as prior period, unchanged from 0000804328-23-000023:mdna:103]

[0000804328-23-000043:mdna:117]
[same as prior period, unchanged from 0000804328-23-000023:mdna:104]

[0000804328-23-000043:mdna:118]
[same as prior period, unchanged from 0000804328-23-000023:mdna:105]

[0000804328-23-000043:mdna:119]
[same as prior period, unchanged from 0000804328-23-000023:mdna:106]

[0000804328-23-000043:mdna:120]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at June 25, 2023 and September 25, 2022 and for the first nine months of fiscal 2023 and 2022 (in millions):

[0000804328-23-000043:mdna:121]
|  | June 25,2023 |  | September 25,2022 |  | Change |  |  |
| Cash and cash equivalents (1) | $ | 6,087 |  |  | $ | 2,773 |  |  | $ | 3,314 |  |  |  |
| Marketable securities | 2,544 |  |  | 3,609 |  |  | (1,065) |  |  |  |
| Cash, cash equivalents and marketable securities | $ | 8,631 |  |  | $ | 6,382 |  |  | $ | 2,249 |  |  |  |

[0000804328-23-000043:mdna:122]
(1) Excludes $90 million and $326 million of cash and cash equivalents classified as held for sale (included in other current assets) at June 25, 2023 and September 25, 2022, respectively.

[0000804328-23-000043:mdna:123]
|  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | Change |  |  |
| Net cash provided by operating activities | $ | 7,209 |  |  | $ | 7,650 |  |  | $ | (441) |  |  |  |
| Net cash provided (used) by investing activities | 1,380 |  |  | (5,514) |  |  | 6,894 |  |  |  |
| Net cash used by financing activities | (5,546) |  |  | (6,004) |  |  | 458 |  |  |  |

[0000804328-23-000043:mdna:124]
Cash, cash equivalents and marketable securities. The net increase in cash, cash equivalents and marketable securities was primarily due to net cash provided by operating activities, the issuance of $1.9 billion of unsecured fixed-rate notes (additional information regarding our issuance of debt is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt”), $1.5 billion in net cash proceeds from the sale of the Active Safety business (additional information regarding the sale of the Active Safety business is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 8. Acquisitions and Divestitures”) and $233 million in proceeds from the issuance of common stock (primarily under our Employee Stock Purchase Plan), partially offset by $2.6 billion in payments to repurchase 21 million shares of our common stock, $2.6 billion in cash dividends paid, $1.4 billion repayments of notes that matured in January 2023, $1.2 billion in capital expenditures, $499 million in payments of tax withholdings related to the vesting of share-based awards and $498 million in net repayments of commercial paper.

[0000804328-23-000043:mdna:125]
[same as prior period, unchanged from 0000804328-23-000023:mdna:114]

[0000804328-23-000043:mdna:126]
[same as prior period, unchanged from 0000804328-23-000023:mdna:115]

[0000804328-23-000043:mdna:127]
We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors. Additional information regarding our capital returns is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 4. Capital Stock.”

[0000804328-23-000043:mdna:128]
Debt. During the second quarter of fiscal 2023, we amended our Revolving Credit Facility, which provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.3 billion (compared to $4.5 billion prior to the amendment), which expires on December 8, 2025. At June 25, 2023, no amounts were outstanding under the Revolving Credit Facility. Additional information regarding our outstanding debt is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt.”

[0000804328-23-000043:mdna:129]
Income Taxes. Beginning in fiscal 2023, for federal income tax purposes, we are required to capitalize and amortize domestic research and development expenditures over five years and foreign research and development expenditures over fifteen years (such expenditures were previously deducted as incurred). Our cash flows from operations will be adversely affected due to significantly higher cash tax payments. We estimate the additional cash tax impact related to fiscal 2023 to be approximately $1.1 billion. Due to an announcement by the IRS, our remaining current year U.S. federal income tax-payment deadlines have been postponed until October 2023. Additional information regarding our income taxes is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes.”

[0000804328-23-000043:mdna:130]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2022 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At June 25, 2023, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements”, “Looking Forward” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2022 Annual Report on Form 10-K.

[0000804328-23-000043:mdna:131]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes

[0000804328-23-000043:mdna:132]
to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0000804328-23-000043:mdna:133]
[same as prior period, unchanged from 0000804328-23-000023:mdna:121]

[0000804328-23-000043:mdna:134]
[same as prior period, unchanged from 0000804328-23-000023:mdna:122]

[0000804328-23-000043:mdna:135]
You should consider each of the following factors in evaluating our business and our prospects, any of which could negatively impact our business, results of operations, cash flows and financial condition, and require significant management time and attention. Further, the risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also negatively impact our business, results of operations, cash flows and financial condition, and require significant management time and attention. In such cases, the trading price of our common stock could decline. You should also consider the other information set forth in this Quarterly Report in evaluating our business and our prospects, including but not limited to our financial statements and the related notes, and “Part I, Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” References to “and,” “or” and “and/or” should be read to include the others, as appropriate.

[0000804328-23-000043:mdna:136]
[same as prior period, unchanged from 0000804328-23-000023:mdna:125]

[0000804328-23-000043:mdna:137]
[same as prior period, unchanged from 0000804328-23-000023:mdna:126]

[0000804328-23-000043:mdna:138]
[same as prior period, unchanged from 0000804328-23-000023:mdna:127]

[0000804328-23-000043:mdna:139]
[same as prior period, unchanged from 0000804328-23-000023:mdna:128]

[0000804328-23-000043:mdna:140]
[same as prior period, unchanged from 0000804328-23-000023:mdna:129]

[0000804328-23-000043:mdna:141]
[same as prior period, unchanged from 0000804328-23-000023:mdna:130]

[0000804328-23-000043:mdna:142]
[same as prior period, unchanged from 0000804328-23-000023:mdna:131]

[0000804328-23-000043:mdna:143]
[same as prior period, unchanged from 0000804328-23-000023:mdna:132]

[0000804328-23-000043:mdna:144]
[same as prior period, unchanged from 0000804328-23-000023:mdna:133]

[0000804328-23-000043:mdna:145]
Our industry has also experienced slowing growth in the premium-tier device segment due to, among other factors, a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and innovation cycles. A reduction in sales of premium-tier devices, a reduction in sales of our premium-tier integrated circuit products (which have a higher revenue and margin contribution than our lower-tier integrated circuit products), or a shift in share away from OEMs that utilize our premium-tier products, would reduce our revenues and margins and may harm our ability to achieve or sustain expected financial results. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0000804328-23-000043:mdna:146]
[same as prior period, unchanged from 0000804328-23-000023:mdna:136]

[0000804328-23-000043:mdna:147]
[same as prior period, unchanged from 0000804328-23-000023:mdna:137]

[0000804328-23-000043:mdna:148]
[same as prior period, unchanged from 0000804328-23-000023:mdna:138]

[0000804328-23-000043:mdna:149]
[same as prior period, unchanged from 0000804328-23-000023:mdna:139]

[0000804328-23-000043:mdna:150]
[same as prior period, unchanged from 0000804328-23-000023:mdna:140]

[0000804328-23-000043:mdna:151]
[same as prior period, unchanged from 0000804328-23-000023:mdna:141]

[0000804328-23-000043:mdna:152]
[same as prior period, unchanged from 0000804328-23-000023:mdna:142]

[0000804328-23-000043:mdna:153]
If some or all of our largest customers and/or the largest smartphone OEMs utilize their own integrated circuit products in some or all of their devices rather than our products, our business, revenues, results of operations, cash flows and financial position could be materially adversely impacted. See also the Risk Factor titled “We derive a significant portion of our

[0000804328-23-000043:mdna:154]
revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected.”

[0000804328-23-000043:mdna:155]
[same as prior period, unchanged from 0000804328-23-000023:mdna:144]

[0000804328-23-000043:mdna:156]
[same as prior period, unchanged from 0000804328-23-000023:mdna:145]

[0000804328-23-000043:mdna:157]
Due to various factors, including pressure, encouragement or incentives from, or policies of, the Chinese government (including its Made in China 2025 campaign), concerns over losing access to our integrated circuit products as a result of actual, threatened or potential U.S. or Chinese government actions or policies, including trade protection or national security policies, or other reasons, some of our Chinese integrated circuit customers have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products in their devices, or use our competitors’ integrated circuit products in their devices, rather than our products, which could materially harm our business, revenues, results of operations, cash flows and financial position. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0000804328-23-000043:mdna:158]
Political actions, including trade protection and national security policies of the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our Chinese customers or suppliers, limit, prevent or discourage certain of our Chinese customers or suppliers from transacting business with us, or make it more expensive to do so. Given our revenue concentration in China, if, due to actual, threatened or potential U.S. or Chinese government actions or policies: we were further limited in, or prohibited from, selling our integrated circuit products to Chinese OEMs; our non-Chinese OEM customers were limited in, or prohibited from, selling devices that incorporate our integrated circuit products into China; Chinese OEMs develop and use their own integrated circuit products or use our competitors’ integrated circuit products in some or all of their devices rather than our integrated circuit products; Chinese tariffs on our integrated circuit products or on devices which incorporate our integrated circuit products made purchasing such products or devices more expensive to Chinese OEMs or Chinese consumers; or our Chinese licensees delay or cease making payments of license fees they owe us, our business, revenues, results of operations, cash flows and financial position could be materially harmed. For example, we currently have export licenses from the U.S. Department of Commerce that allow us to sell 4G and other integrated circuit products, including WiFi products, but excluding 5G products, to Huawei. Recent news reports have indicated that the Department of Commerce is considering not granting any new licenses for sales to Huawei and potentially revoking existing licenses. Further, because we do not have a license to sell 5G products to Huawei, if and when Huawei transitions to 5G devices, we expect them to use their own or a competitor’s integrated circuit products, rather than our products, in such devices. If we are unable to sell products to Huawei, either due to the inability to obtain new export licenses upon the expiration of our current licenses, because our current licenses are revoked, or in connection with Huawei’s transition to 5G devices, our revenues, results of operations and cash flows could be significantly negatively affected. Similarly, if, due to U.S. or Chinese government actions or policies, we were limited in or prohibited from obtaining critical integrated circuit products from our suppliers in China, our business, revenues, results of operations, cash flows and financial position could be materially harmed. See also the Risk Factors titled “We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected” and “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0000804328-23-000043:mdna:159]
[same as prior period, unchanged from 0000804328-23-000023:mdna:149]

[0000804328-23-000043:mdna:160]
[same as prior period, unchanged from 0000804328-23-000023:mdna:150]

[0000804328-23-000043:mdna:161]
[same as prior period, unchanged from 0000804328-23-000023:mdna:151]

[0000804328-23-000043:mdna:162]
32

[0000804328-23-000043:mdna:163]
[same as prior period, unchanged from 0000804328-23-000023:mdna:152]

[0000804328-23-000043:mdna:164]
[same as prior period, unchanged from 0000804328-23-000023:mdna:153]

[0000804328-23-000043:mdna:165]
However, our research, development and other investments in these new and expanded product areas, industries and applications, and corresponding technologies and products, as well as in our existing technologies and products and new technologies in mobile handsets, may not succeed because, among other reasons: we may not be issued patents on the technologies we develop; the technologies we develop may not be incorporated into relevant standards; new and expanded product areas, industries and applications beyond mobile handsets, and consumer demand therein, may not develop or grow as anticipated; we may be unable to attract or retain employees with the necessary skills in such new and expanded product areas, industries and applications; our strategies or the strategies of our customers, licensees or partners may not be successful; alternate technologies or products may be better or may reduce the advantages we anticipate from our investments; competitors’ technologies or products may be more cost effective, have more capabilities or fewer limitations or be brought to market faster than our new technologies or products; we may not be able to develop, or our competitors may have more established and/or stronger, customer, vendor, distributor or other channel relationships; and competitors may have longer operating histories in industries and applications that are new to us. We may also underestimate the costs of, or overestimate the future revenues or margins that could result from, these investments, and these investments may not, or may take many years to, generate material returns.

[0000804328-23-000043:mdna:166]
[same as prior period, unchanged from 0000804328-23-000023:mdna:156]

[0000804328-23-000043:mdna:167]
[same as prior period, unchanged from 0000804328-23-000023:mdna:157]

[0000804328-23-000043:mdna:168]
[same as prior period, unchanged from 0000804328-23-000023:mdna:158]

[0000804328-23-000043:mdna:169]
[same as prior period, unchanged from 0000804328-23-000023:mdna:159]

[0000804328-23-000043:mdna:170]
[same as prior period, unchanged from 0000804328-23-000023:mdna:160]

[0000804328-23-000043:mdna:171]
We engage in acquisitions and other strategic transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. We routinely acquire businesses and other assets, including patents, technology and other intangible assets, enter into joint ventures or other strategic transactions, and purchase minority equity interests in or make loans to companies, including those that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our products and technologies and supporting the design and introduction of new products (or enhancing existing products) for mobile handsets, and for industries and applications beyond mobile handsets. Many of our strategic activities entail a high degree of risk and require the use of significant amounts of capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not be successful, generate financial returns or result in increased adoption or continued use of our technologies or products. We may underestimate the costs or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not

[0000804328-23-000043:mdna:172]
achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership or variable interests. In addition, we have in the past recorded, and may in the future record, impairment or other charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our results of operations and financial condition, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0000804328-23-000043:mdna:173]
Achieving the anticipated benefits of business acquisitions depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models, geographic regions, industries and applications served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0000804328-23-000043:mdna:174]
[same as prior period, unchanged from 0000804328-23-000023:mdna:164]

[0000804328-23-000043:mdna:175]
[same as prior period, unchanged from 0000804328-23-000023:mdna:165]

[0000804328-23-000043:mdna:176]
[same as prior period, unchanged from 0000804328-23-000023:mdna:166]

[0000804328-23-000043:mdna:177]
[same as prior period, unchanged from 0000804328-23-000023:mdna:167]

[0000804328-23-000043:mdna:178]
[same as prior period, unchanged from 0000804328-23-000023:mdna:168]

[0000804328-23-000043:mdna:179]
[same as prior period, unchanged from 0000804328-23-000023:mdna:169]

[0000804328-23-000043:mdna:180]
[same as prior period, unchanged from 0000804328-23-000023:mdna:170]

[0000804328-23-000043:mdna:181]
[same as prior period, unchanged from 0000804328-23-000023:mdna:171]

[0000804328-23-000043:mdna:182]
•an inability to procure or utilize raw materials, components or products from our suppliers due to government prohibitions or restrictions on transactions with certain countries and/or companies, and alternative suppliers, raw

[0000804328-23-000043:mdna:183]
34

[0000804328-23-000043:mdna:184]
material sources or raw materials are not available or not available in acceptable time frames or upon acceptable terms;

[0000804328-23-000043:mdna:185]
[same as prior period, unchanged from 0000804328-23-000023:mdna:173]

[0000804328-23-000043:mdna:186]
[same as prior period, unchanged from 0000804328-23-000023:mdna:174]

[0000804328-23-000043:mdna:187]
[same as prior period, unchanged from 0000804328-23-000023:mdna:175]

[0000804328-23-000043:mdna:188]
[same as prior period, unchanged from 0000804328-23-000023:mdna:176]

[0000804328-23-000043:mdna:189]
[same as prior period, unchanged from 0000804328-23-000023:mdna:177]

[0000804328-23-000043:mdna:190]
[same as prior period, unchanged from 0000804328-23-000023:mdna:178]

[0000804328-23-000043:mdna:191]
[same as prior period, unchanged from 0000804328-23-000023:mdna:179]

[0000804328-23-000043:mdna:192]
[same as prior period, unchanged from 0000804328-23-000023:mdna:180]

[0000804328-23-000043:mdna:193]
[same as prior period, unchanged from 0000804328-23-000023:mdna:181]

[0000804328-23-000043:mdna:194]
[same as prior period, unchanged from 0000804328-23-000023:mdna:182]

[0000804328-23-000043:mdna:195]
Although we have long-term contracts with our suppliers, some of these contracts do not provide for long-term capacity commitments. To the extent we do not have firm commitments from our suppliers over a specific time period or for any specific quantity, our suppliers may allocate, and in the past have allocated, capacity to the manufacture, assembly and testing of products for their other customers (including our competitors) while reducing or limiting capacity to manufacture, assemble or test our products, and such capacity may be limited based on our suppliers’ ability and willingness to invest in the capital required to manufacture in the leading process technologies. Our suppliers or potential alternate suppliers may also manufacture their own integrated circuits that compete with our products. Such suppliers have in the past allocated and may again allocate raw materials and manufacturing capacity to their own products and reduce or limit the production of our products. To the extent we do obtain long-term capacity commitments, we may incur additional costs related to those commitments or make non-refundable payments for capacity commitments that are not used. Further, certain of our suppliers have in the past attempted, and may in the future attempt, to unilaterally reduce their capacity commitments to us. Accordingly, capacity for our products may not be available when we need it. Finally, we may not receive reasonable pricing,

[0000804328-23-000043:mdna:196]
manufacturing or delivery terms from our suppliers, and our ability to obtain favorable terms may be diminished during times of high demand and/or limited manufacturing capacity for integrated circuit products.

[0000804328-23-000043:mdna:197]
[same as prior period, unchanged from 0000804328-23-000023:mdna:184]

[0000804328-23-000043:mdna:198]
[same as prior period, unchanged from 0000804328-23-000023:mdna:185]

[0000804328-23-000043:mdna:199]
[same as prior period, unchanged from 0000804328-23-000023:mdna:186]

[0000804328-23-000043:mdna:200]
[same as prior period, unchanged from 0000804328-23-000023:mdna:187]

[0000804328-23-000043:mdna:201]
[same as prior period, unchanged from 0000804328-23-000023:mdna:188]

[0000804328-23-000043:mdna:202]
[same as prior period, unchanged from 0000804328-23-000023:mdna:189]

[0000804328-23-000043:mdna:203]
We are subject to many complex environmental, health and safety laws, regulations and rules in each jurisdiction in which we operate our manufacturing (and research and development) facilities. The regulatory landscape in these areas continues to evolve, and we anticipate additional laws, regulations and rules in the future. In particular, new, or changes in, environmental and climate change laws, regulations or rules, including relating to greenhouse gas emissions, could lead to new or additional investments in production processes and could increase environmental compliance expenditures. In addition, certain environmental laws impose strict, and in certain circumstances joint and several, liability on current or previous owners or operators of real property, or parties who arranged for hazardous substances to be sent to disposal or treatment facilities, for the cost of investigation, removal or remediation of hazardous substances. As a result, we may incur

[0000804328-23-000043:mdna:204]
clean-up costs in connection with any such removal or remediation efforts, as well as other third-party claims in connection with contaminated sites. In addition, we could be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage. If we, or companies or facilities we acquire or have acquired, in the past failed or in the future fail to comply with any such laws and regulations, then we could incur regulatory penalties, fines and legal liabilities; suspension of production; significant compliance requirements; alteration of our manufacturing, assembly or test processes; restriction on our ability to modify or expand our facilities; damage to our reputation; and restrictions on our operations or sales. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. We cannot make assurances that we will at all times be in compliance with such laws, regulations, rules and permits. See also the risk factor titled “Our business may suffer due to the impact of, or our failure to comply with, the various existing, new or amended laws, regulations, policies or standards to which we are subject.”

[0000804328-23-000043:mdna:205]
Climate change concerns and the potential resulting environmental impact may result in new environmental, health and safety laws and regulations that may affect us, our suppliers and our customers. Such laws or regulations could cause us to incur additional direct costs for compliance, including costs associated with changes to manufacturing processes or the procurement of raw materials used in manufacturing processes, as well as increased indirect costs resulting from our customers, suppliers or both incurring additional compliance costs that are passed on to us. These costs may adversely impact our results of operations and financial condition. In addition, climate change could cause certain natural disasters, such as drought, wildfires, storms, flooding or rising sea levels, to occur more frequently or with greater intensity, which could pose physical risks to our manufacturing facilities or our suppliers’ facilities, could disrupt the availability of water necessary for the operation of such facilities, and could increase or decrease temperatures resulting in increased operating costs and/or business disruption.

[0000804328-23-000043:mdna:206]
[same as prior period, unchanged from 0000804328-23-000023:mdna:194]

[0000804328-23-000043:mdna:207]
[same as prior period, unchanged from 0000804328-23-000023:mdna:195]

[0000804328-23-000043:mdna:208]
Our manufacturing processes are highly complex, require advanced and costly equipment and must be continuously modified to improve yields and performance. Difficulties in the production process can reduce yields or interrupt production, and as a result, we may not be able to deliver our products or do so in a timely, cost-effective or competitive manner. Further, to remain competitive and meet customer demand, we may be required to improve our facilities and process technologies and

[0000804328-23-000043:mdna:209]
[same as prior period, unchanged from 0000804328-23-000023:mdna:205]

[0000804328-23-000043:mdna:210]
carry out extensive research and development, each of which may require investment of significant amounts of capital and may have a material adverse effect on our results of operations, cash flows and financial condition.

[0000804328-23-000043:mdna:211]
[same as prior period, unchanged from 0000804328-23-000023:mdna:197]

[0000804328-23-000043:mdna:212]
[same as prior period, unchanged from 0000804328-23-000023:mdna:199]

[0000804328-23-000043:mdna:213]
[same as prior period, unchanged from 0000804328-23-000023:mdna:200]

[0000804328-23-000043:mdna:214]
[same as prior period, unchanged from 0000804328-23-000023:mdna:201]

[0000804328-23-000043:mdna:215]
[same as prior period, unchanged from 0000804328-23-000023:mdna:202]

[0000804328-23-000043:mdna:216]
[same as prior period, unchanged from 0000804328-23-000023:mdna:203]

[0000804328-23-000043:mdna:217]
Further, certain countries in which we operate have implemented, and other countries or regions may implement, cybersecurity laws that require our overall IT security environment to meet certain standards and/or be certified. Such laws may be complex, ambiguous and subject to interpretation, which may create uncertainty regarding compliance. As a result, our efforts to comply with such laws may be expensive and may fail, which could adversely affect our business, results of operations and cash flows. In addition, our contracts with certain of our customers require us to obtain cybersecurity certifications for our IT systems. Failure to obtain or maintain the necessary cybersecurity certifications could result in loss of future revenues, damage to our customer relationships and reputation, and a shift of business to our competitors.

[0000804328-23-000043:mdna:218]
[same as prior period, unchanged from 0000804328-23-000023:mdna:207]

[0000804328-23-000043:mdna:219]
[same as prior period, unchanged from 0000804328-23-000023:mdna:208]

[0000804328-23-000043:mdna:220]
[same as prior period, unchanged from 0000804328-23-000023:mdna:209]

[0000804328-23-000043:mdna:221]
The COVID-19 pandemic caused us to modify our workforce practices, including having the vast majority of our employees work from home. Upon the reopening of our offices, we initially operated under a hybrid work model, meaning that the majority of our employees had the flexibility to work remotely at least some of the time. We recently implemented changes to our hybrid work model that require the majority of our employees to spend the majority of their working time in the office. This requirement for greater in-office attendance may not meet the needs or expectations of our employees and could negatively impact our ability to attract and retain employees, particularly if it is perceived as less favorable compared to other companies’ remote work policies. If we fail to retain key employees or maintain employee productivity as a result of the shift to more on-site work, our business could be adversely impacted.

[0000804328-23-000043:mdna:222]
[same as prior period, unchanged from 0000804328-23-000023:mdna:211]

[0000804328-23-000043:mdna:223]
[same as prior period, unchanged from 0000804328-23-000023:mdna:212]

[0000804328-23-000043:mdna:224]
[same as prior period, unchanged from 0000804328-23-000023:mdna:213]

[0000804328-23-000043:mdna:225]
Our patent license agreements in effect that generate a significant portion of our licensing revenues are effective for a specified term. To receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms, and may impact the

[0000804328-23-000043:mdna:226]
financial or other terms of license agreements not subject to the litigation or arbitration. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such licensees.

[0000804328-23-000043:mdna:227]
[same as prior period, unchanged from 0000804328-23-000023:mdna:215]

[0000804328-23-000043:mdna:228]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, alleging that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) attempts by licensees to shift their royalty obligation to their suppliers in order to make royalty collection more difficult or reduce the amount of royalties collected.

[0000804328-23-000043:mdna:229]
[same as prior period, unchanged from 0000804328-23-000023:mdna:217]

[0000804328-23-000043:mdna:230]
We have been in the past and are currently subject to various litigation and/or governmental investigations and proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. See also the Risk Factors below titled “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.”

[0000804328-23-000043:mdna:231]
[same as prior period, unchanged from 0000804328-23-000023:mdna:219]

[0000804328-23-000043:mdna:232]
Further, some third parties have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions should not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for

[0000804328-23-000043:mdna:233]
patent infringement (e.g., by limiting the base upon which the royalty rate may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies.

[0000804328-23-000043:mdna:234]
Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party. Further, SDOs in certain countries may attempt to modify widely accepted standards and claim the resulting standard as their own. In addition, governments may enact policies concerning standard-essential patents, such as the European Commission’s recently proposed regulations which would create a new regulatory scheme for standard-essential patents, that may have various consequences, some of which may be detrimental, such as by devaluing standard-essential patents or disrupting worldwide technology standards. Other jurisdictions may adopt similar regulatory schemes, which could also have such effects.

[0000804328-23-000043:mdna:235]
[same as prior period, unchanged from 0000804328-23-000023:mdna:223]

[0000804328-23-000043:mdna:236]
[same as prior period, unchanged from 0000804328-23-000023:mdna:224]

[0000804328-23-000043:mdna:237]
As described in the Risk Factor below titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings,” we have been in the past, currently are and may in the future be subject to various governmental investigations and/or legal proceedings challenging our patent licensing practices. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We believe that one intent of certain of these governmental investigations and legal proceedings has been to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0000804328-23-000043:mdna:238]
[same as prior period, unchanged from 0000804328-23-000023:mdna:226]

[0000804328-23-000043:mdna:239]
[same as prior period, unchanged from 0000804328-23-000023:mdna:227]

[0000804328-23-000043:mdna:240]
[same as prior period, unchanged from 0000804328-23-000023:mdna:228]

[0000804328-23-000043:mdna:241]
To the extent that we were required to implement any of these licensing and/or business practices, including by modifying or renegotiating our existing license agreements or pursuing other commercial arrangements, we would incur additional transaction costs, which may be significant, we could incur delays in recognizing revenues until license

[0000804328-23-000043:mdna:242]
negotiations were completed, and our business, revenues, results of operations, cash flows and financial condition could be harmed. The impact of any such changes to our licensing practices could vary widely and by jurisdiction, depending on the specific outcomes and the geographic scope of such outcomes. In addition, if we were required to make modifications to our licensing practices in one jurisdiction, licensees or governmental agencies in other jurisdictions may attempt to obtain similar outcomes for themselves or for such other jurisdictions, as applicable, which could result in increased legal costs and further harm to our business, revenues, results of operations, cash flows and financial condition.

[0000804328-23-000043:mdna:243]
[same as prior period, unchanged from 0000804328-23-000023:mdna:231]

[0000804328-23-000043:mdna:244]
Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.

[0000804328-23-000043:mdna:245]
We have been in the past and currently are subject to various governmental investigations and/or legal proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations or findings in those matters include or have in the past included, among others: that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers; that our royalty rates are too high; that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions); that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets; that we have entered into exclusive agreements with chipset customers that foreclose competition; that we leverage our position in baseband chipsets in the RFFE space; and that we violate antitrust laws and engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0000804328-23-000043:mdna:246]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others: the loss of our ability to enforce one or more of our patents; injunctions; monetary damages, fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers or other component suppliers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any revenues under such agreements. The renegotiation of license agreements could result in terms that are less favorable to us than existing terms, or lead to arbitration or litigation to resolve the licensing terms, which could also be less favorable to us than existing terms, and each of which could take months or years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. The occurrence of any of the above could have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies. Further, depending on the breadth and severity of the circumstances above, we may have to reduce, suspend or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted.

[0000804328-23-000043:mdna:247]
[same as prior period, unchanged from 0000804328-23-000023:mdna:235]

[0000804328-23-000043:mdna:248]
[same as prior period, unchanged from 0000804328-23-000023:mdna:236]

[0000804328-23-000043:mdna:249]
[same as prior period, unchanged from 0000804328-23-000023:mdna:237]

[0000804328-23-000043:mdna:250]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on our customers and licensees to develop devices and services based on these technologies to drive consumer demand for new 3G/4G/5G multimode and single-mode devices, and to establish the selling prices for such devices. Further, the timing of our shipments of our products is dependent on the timing of our

[0000804328-23-000043:mdna:251]
customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries and applications beyond mobile handsets, such as automotive and IoT, among others. Commercial deployments of 5G networks and devices have begun and are expected to continue for the foreseeable future. However, the timing and scale of certain such deployments were delayed due to the COVID-19 pandemic, and future deployments may similarly be delayed for reasons that are beyond our control.

[0000804328-23-000043:mdna:252]
[same as prior period, unchanged from 0000804328-23-000023:mdna:239]

[0000804328-23-000043:mdna:253]
[same as prior period, unchanged from 0000804328-23-000023:mdna:240]

[0000804328-23-000043:mdna:254]
[same as prior period, unchanged from 0000804328-23-000023:mdna:241]

[0000804328-23-000043:mdna:255]
[same as prior period, unchanged from 0000804328-23-000023:mdna:242]

[0000804328-23-000043:mdna:256]
[same as prior period, unchanged from 0000804328-23-000023:mdna:243]

[0000804328-23-000043:mdna:257]
[same as prior period, unchanged from 0000804328-23-000023:mdna:244]

[0000804328-23-000043:mdna:258]
[same as prior period, unchanged from 0000804328-23-000023:mdna:245]

[0000804328-23-000043:mdna:259]
[same as prior period, unchanged from 0000804328-23-000023:mdna:246]

[0000804328-23-000043:mdna:260]
[same as prior period, unchanged from 0000804328-23-000023:mdna:247]

[0000804328-23-000043:mdna:261]
[same as prior period, unchanged from 0000804328-23-000023:mdna:248]

[0000804328-23-000043:mdna:262]
[same as prior period, unchanged from 0000804328-23-000023:mdna:249]

[0000804328-23-000043:mdna:263]
[same as prior period, unchanged from 0000804328-23-000023:mdna:250]

[0000804328-23-000043:mdna:264]
[same as prior period, unchanged from 0000804328-23-000023:mdna:251]

[0000804328-23-000043:mdna:265]
[same as prior period, unchanged from 0000804328-23-000023:mdna:252]

[0000804328-23-000043:mdna:266]
[same as prior period, unchanged from 0000804328-23-000023:mdna:254]

[0000804328-23-000043:mdna:267]
[same as prior period, unchanged from 0000804328-23-000023:mdna:255]

[0000804328-23-000043:mdna:268]
[same as prior period, unchanged from 0000804328-23-000023:mdna:256]

[0000804328-23-000043:mdna:269]
[same as prior period, unchanged from 0000804328-23-000023:mdna:257]

[0000804328-23-000043:mdna:270]
[same as prior period, unchanged from 0000804328-23-000023:mdna:258]

[0000804328-23-000043:mdna:271]
[same as prior period, unchanged from 0000804328-23-000023:mdna:259]

[0000804328-23-000043:mdna:272]
Competition in any or all product tiers may result in the loss of business or customers, which would negatively impact our business, revenues, results of operations, cash flows and financial condition. Such competition may also reduce average selling prices for our chipset products or the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging regions and China where competitors may have lower cost structures or may have a willingness and ability to accept lower prices or lower margins on their products. Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without

[0000804328-23-000043:mdna:273]
corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0000804328-23-000043:mdna:274]
[same as prior period, unchanged from 0000804328-23-000023:mdna:261]

[0000804328-23-000043:mdna:275]
[same as prior period, unchanged from 0000804328-23-000023:mdna:262]

[0000804328-23-000043:mdna:276]
[same as prior period, unchanged from 0000804328-23-000023:mdna:263]

[0000804328-23-000043:mdna:277]
[same as prior period, unchanged from 0000804328-23-000023:mdna:264]

[0000804328-23-000043:mdna:278]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, meet certain regulatory or industry standards (including product safety and information security standards, which may differ by region, geography and industry, and which are particularly stringent in the automotive industry), or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and the end users of such devices, and potentially to our customers’ IT infrastructure. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products, repairing or replacing defective products, writing down defective inventory or indemnification obligations under our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, and losses on unfavorable purchase commitments. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products.

[0000804328-23-000043:mdna:279]
In addition, the occurrence of defects, errors or security vulnerabilities may give rise to product liability claims, particularly if such defects, errors or security vulnerabilities in our products or the technology we use, or the products into which they are integrated, result in personal injury or death, and could result in significant costs, expenses and losses. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the attention of our technical and management personnel and harm our business, even if we are successful. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. We may also be required to indemnify and/or defend our customers from product liability claims relating to our products. Further, our business liability insurance may be inadequate, may not cover the claims, and future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products

[0000804328-23-000043:mdna:280]
may be used, and perform critical functions, in various high-risk applications such as: automobiles, including ADAS/AD functions; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and XR for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0000804328-23-000043:mdna:281]
[same as prior period, unchanged from 0000804328-23-000023:mdna:269]

[0000804328-23-000043:mdna:282]
[same as prior period, unchanged from 0000804328-23-000023:mdna:270]

[0000804328-23-000043:mdna:283]
[same as prior period, unchanged from 0000804328-23-000023:mdna:271]

[0000804328-23-000043:mdna:284]
[same as prior period, unchanged from 0000804328-23-000023:mdna:272]

[0000804328-23-000043:mdna:285]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. We cannot predict with certainty the long-term effects of any potential changes. In the United States, Europe (including the United Kingdom), India, China and elsewhere, there is continued discussion regarding potential patent law changes, and there is current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. Some proposed changes would apply to only standard-essential patents, and such changes may substantially alter the incentives to participate in standardization or develop standards-compliant products. See also the Risk Factor entitled “Efforts by some original equipment manufacturers (OEMs) to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.”

[0000804328-23-000043:mdna:286]
Further, the laws in certain foreign countries in which our patents are or may be licensed, or our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in ways that are detrimental to our licensing programs or to the sale or use of our products or technologies.

[0000804328-23-000043:mdna:287]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies or political actions of governments, including trade protection and national security policies; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business or the pricing and integration of additional features and functionality into our chipset products. See also the Risk Factors titled “Efforts by some original equipment manufacturers (OEMs) to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.”

[0000804328-23-000043:mdna:288]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of

[0000804328-23-000043:mdna:289]
proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0000804328-23-000043:mdna:290]
[same as prior period, unchanged from 0000804328-23-000023:mdna:276]

[0000804328-23-000043:mdna:291]
[same as prior period, unchanged from 0000804328-23-000023:mdna:277]

[0000804328-23-000043:mdna:292]
[same as prior period, unchanged from 0000804328-23-000023:mdna:278]

[0000804328-23-000043:mdna:293]
From time to time, companies have asserted, and may again assert, patent, copyright or other intellectual property claims against us relating to our technologies or products, including those we have acquired from other companies. These claims have resulted and may again result in our involvement in litigation, and we are currently involved in such litigation, including those described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products were found to infringe another company’s intellectual property, we could be subject to an injunction or be required to redesign our products, or to license such intellectual property or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products, license such intellectual property used in our products or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling our products. Similarly, our suppliers could be found to infringe another company’s intellectual property, and such suppliers could then be enjoined from providing products or services to us.

[0000804328-23-000043:mdna:294]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products sold by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel and/or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0000804328-23-000043:mdna:295]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative

[0000804328-23-000043:mdna:296]
outcome in any such proceeding could severely disrupt the business of our customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing corresponding declines in our chipset or licensing revenues.

[0000804328-23-000043:mdna:297]
[same as prior period, unchanged from 0000804328-23-000023:mdna:282]

[0000804328-23-000043:mdna:298]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe that we will continue to see, customers request that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of our products’ source code and may expose our related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of that software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers, or to license such derivative works under a particular type of license that is different than what we customarily use to license our software. Furthermore, in the course of product development, we may make contributions to third-party open source projects that could subject our intellectual property to adverse licensing conditions. For example, to encourage the growth of a software ecosystem that is interoperable with our products, we may need to contribute certain implementations under the open source licensing terms that govern such projects, which may adversely impact our associated intellectual property. Developing open source products, while adequately protecting the intellectual property upon which our licensing programs depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental and third-party scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products.

[0000804328-23-000043:mdna:299]
[same as prior period, unchanged from 0000804328-23-000023:mdna:285]

[0000804328-23-000043:mdna:300]
[same as prior period, unchanged from 0000804328-23-000023:mdna:286]

[0000804328-23-000043:mdna:301]
[same as prior period, unchanged from 0000804328-23-000023:mdna:287]

[0000804328-23-000043:mdna:302]
The COVID-19 pandemic also caused us to modify our workforce practices, such as having the vast majority of our employees work from home. Although we have reopened our offices, we could be negatively affected in the future if, among others, a significant number of our employees, or employees who perform critical functions, become ill and/or are quarantined as the result of exposure to COVID-19 or a similar health crisis, or if government policies restrict the ability of those employees to perform their critical functions. See also the Risk Factor titled “We may not be able to attract and retain qualified employees, and recent changes to our hybrid work model may not be successful.”

[0000804328-23-000043:mdna:303]
[same as prior period, unchanged from 0000804328-23-000023:mdna:289]

[0000804328-23-000043:mdna:304]
[same as prior period, unchanged from 0000804328-23-000023:mdna:298]

[0000804328-23-000043:mdna:305]
[same as prior period, unchanged from 0000804328-23-000023:mdna:290]

[0000804328-23-000043:mdna:306]
The semiconductor industry is highly cyclical, volatile, subject to downturns and characterized by constant and rapid technological change, price erosion, evolving technical standards, frequent new product introductions, short product life cycles and fluctuations in product supply and demand. Periods of downturns have been characterized by diminished demand for end-user products, high inventory levels, excess or obsolete inventory adjustments or reserves, underutilization of manufacturing capacity, changes in revenue mix and erosion of average selling prices. We expect our business to continue to be subject to such cyclical downturns. During such downturns, our revenues may decline, and our results of operations and financial condition may be adversely impacted. We are currently seeing and expect to continue to see weakness in the macroeconomic environment (negatively impacting consumer demand for smartphones and other devices that incorporate our products and technologies) and elevated inventory levels at our customers (negatively impacting the volume of chipsets they purchase from us until such inventory is depleted). Until these conditions improve, we expect that both of these dynamics will have a negative impact on our revenues, results of operations and cash flows.

[0000804328-23-000043:mdna:307]
[same as prior period, unchanged from 0000804328-23-000023:mdna:294]

[0000804328-23-000043:mdna:308]
Our stock price and financial results have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and our financial results include those identified above and throughout this Risk Factors section, as well as: volatility of the stock market in general and technology and semiconductor companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees, including any announcement concerning the initiation of, or any developments in, any lawsuit or governmental investigation or proceeding against us; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0000804328-23-000043:mdna:309]
[same as prior period, unchanged from 0000804328-23-000023:mdna:296]

[0000804328-23-000043:mdna:310]
Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). These include, among others, Regulations related to: patent licensing practices; antitrust, competition and competitive business practices; the flow of funds out of certain countries (e.g., China); cybersecurity; imports and exports, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; protection of intellectual property; trade and trade protection including tariffs; foreign policy and national security; environmental protection (including climate change), health and safety; supply chain, responsible sourcing, including the use of conflict minerals, and human rights; spectrum availability and license issuance; adoption of standards; taxation; privacy and data protection; labor, employment and human capital; corporate governance; public disclosure; automotive industry safety and quality standards; and business conduct. Compliance with, or changes in the interpretation of, existing Regulations, the adoption of new Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, among others, could

[0000804328-23-000043:mdna:311]
49

[0000804328-23-000043:mdna:312]
have an adverse effect on our business and results of operations. See also the Risk Factors titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises, geopolitical conflicts and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

[0000804328-23-000043:mdna:313]
[same as prior period, unchanged from 0000804328-23-000023:mdna:299]

[0000804328-23-000043:mdna:314]
[same as prior period, unchanged from 0000804328-23-000023:mdna:300]

[0000804328-23-000043:mdna:315]
[same as prior period, unchanged from 0000804328-23-000023:mdna:301]

[0000804328-23-000043:mdna:316]
[same as prior period, unchanged from 0000804328-23-000023:mdna:302]

[0000804328-23-000043:mdna:317]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed, as well as countries where we own intellectual property. The final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0000804328-23-000043:mdna:318]
[same as prior period, unchanged from 0000804328-23-000023:mdna:304]

[0000804328-23-000043:mdna:319]
[same as prior period, unchanged from 0000804328-23-000023:mdna:305]
