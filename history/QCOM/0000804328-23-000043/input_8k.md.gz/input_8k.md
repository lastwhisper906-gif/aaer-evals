# QCOM 8-K — 0000804328-23-000042 filed 2023-08-02

## item codes, every 8-K on or before 2023-08-02

- 2023-08-02 0000804328-23-000042 — 2.02, 9.01
- 2023-07-21 0000804328-23-000033 — 5.03, 9.01
- 2023-05-03 0000804328-23-000022 — 2.02, 9.01
- 2023-03-09 0000804328-23-000014 — 5.07
- 2023-02-02 0000804328-23-000005 — 2.02, 9.01
- 2022-12-08 0001728949-22-000041 — 5.02
- 2022-11-09 0001104659-22-116535 — 1.01, 8.01, 9.01
- 2022-11-02 0000804328-22-000020 — 2.02, 9.01
- 2022-07-27 0001728949-22-000039 — 2.02, 9.01
- 2022-05-09 0001104659-22-057562 — 1.01, 8.01, 9.01
- 2022-04-27 0001728949-22-000025 — 2.02, 9.01
- 2022-03-14 0001728949-22-000016 — 5.07
- 2022-02-02 0001728949-22-000011 — 2.02, 9.01
- 2021-11-03 0001728949-21-000075 — 2.02, 9.01
- 2021-10-04 0001104659-21-122578 — 1.01, 7.01, 9.01
- 2021-07-28 0001728949-21-000065 — 2.02, 9.01
- 2021-07-23 0001728949-21-000055 — 5.03, 9.01
- 2021-05-21 0001728949-21-000048 — 5.02
- 2021-04-28 0001728949-21-000042 — 2.02, 9.01
- 2021-03-15 0001628280-21-004741 — 5.07
- 2021-02-03 0001728949-21-000021 — 2.02, 9.01
- 2021-01-13 0001728949-21-000009 — 1.01, 9.01
- 2021-01-08 0001728949-21-000004 — 5.02
- 2020-12-10 0001104659-20-134200 — 1.01, 1.02, 2.03, 9.01
- 2020-11-19 0001728949-20-000070 — 5.02
- 2020-11-04 0001728949-20-000066 — 2.02, 9.01
- 2020-08-18 0001104659-20-096322 — 1.01, 8.01, 9.01
- 2020-08-05 0001104659-20-090597 — 8.01, 9.01
- 2020-07-29 0001728949-20-000056 — 2.02, 9.01
- 2020-07-24 0001728949-20-000047 — 5.02
- 2020-05-11 0001104659-20-058923 — 1.01, 8.01, 9.01
- 2020-05-04 0001728949-20-000037 — 5.02
- 2020-04-29 0001728949-20-000030 — 2.02, 9.01
- 2020-03-13 0001728949-20-000015 — 5.07
- 2020-02-05 0001728949-20-000010 — 2.02, 9.01
- 2019-11-06 0001728949-19-000074 — 5.02
- 2019-11-06 0001728949-19-000071 — 2.02, 9.01
- 2019-08-28 0001728949-19-000058 — 5.02
- 2019-07-31 0001728949-19-000053 — 2.02, 9.01
- 2019-05-10 0001728949-19-000044 — 5.02
- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2023-08-02

- none on or before 2023-08-02

## item 2.02 — earnings release, exhibit 99.1

[0000804328-23-000042:8k_2_02:1]
EX-99.1
2
qcom062523erex991.htm
EX-99.1

[0000804328-23-000042:8k_2_02:2]
Document

[0000804328-23-000042:8k_2_02:3]
Exhibit 99.1

[0000804328-23-000042:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000804328-23-000042:8k_2_02:5]
Qualcomm Contact:

[0000804328-23-000042:8k_2_02:6]
Mauricio Lopez-Hodoyan

[0000804328-23-000042:8k_2_02:7]
Vice President, Investor Relations

[0000804328-23-000042:8k_2_02:8]
Phone: 1-858-658-4813 | e-mail: ir@qualcomm.com

[0000804328-23-000042:8k_2_02:9]
Qualcomm Announces Third Quarter Fiscal 2023 Results

[0000804328-23-000042:8k_2_02:10]
GAAP Revenues: $8.5 billion

[0000804328-23-000042:8k_2_02:11]
GAAP EPS: $1.60, Non-GAAP EPS: $1.87

[0000804328-23-000042:8k_2_02:12]
—EPS Exceeded Midpoint of Guidance Range—

[0000804328-23-000042:8k_2_02:13]
—QCT Automotive: 11 Straight Quarters of Year-Over-Year Double Digit Percentage Growth in Revenues—

[0000804328-23-000042:8k_2_02:14]
SAN DIEGO - August 2, 2023 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal third quarter ended June 25, 2023.

[0000804328-23-000042:8k_2_02:15]
“We are pleased with our technology leadership, product roadmap and design-win execution, which position us well for growth and diversification in the long term,” said Cristiano Amon, President and CEO of Qualcomm Incorporated. “As AI use cases proliferate to the edge, on-device AI has the potential to drive an inflection point across all our products. Qualcomm remains best positioned to lead this transition given the unmatched accelerated computing performance with the power efficiency of our platforms.”

[0000804328-23-000042:8k_2_02:16]
Third Quarter Results1, 2

[0000804328-23-000042:8k_2_02:17]
|  | GAAP |  | Non-GAAP |  |
| (in millions, except per share data and percentages) | Q3 Fiscal 2023 |  | Q3 Fiscal 2022 |  | Change |  | Q3 Fiscal 2023 |  | Q3 Fiscal 2022 |  |  |  |  | Change |  |
| Revenues | $8,451 |  | $10,936 |  | (23%) |  | $8,442 |  | $10,928 |  |  |  |  | (23%) |  |
| Earnings before taxes (EBT) | $1,757 |  | $4,239 |  | (59%) |  | $2,430 |  | $3,894 |  |  |  |  | (38%) |  |
| Net income | $1,803 |  | $3,730 |  | (52%) |  | $2,105 |  | $3,356 |  |  |  |  | (37%) |  |
| Diluted earnings per share (EPS) | $1.60 |  | $3.29 |  | (51%) |  | $1.87 |  | $2.96 |  |  |  |  | (37%) |  |

[0000804328-23-000042:8k_2_02:18]
(1)  Discussion regarding our use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results are included at the end of this news release in the sections labeled “Note Regarding Use of Non-GAAP Financial Measures” and “Reconciliations of GAAP Results to Non-GAAP Results.”

[0000804328-23-000042:8k_2_02:19]
(2)  Third quarter fiscal 2022 GAAP results included a $1.1 billion benefit, or $0.94 per share, resulting from the reversal of the accrued fine imposed by the European Commission in fiscal 2018 and the associated accrued interest.

[0000804328-23-000042:8k_2_02:20]
Segment Results

[0000804328-23-000042:8k_2_02:21]
|  | QCT |  | QTL |
| (in millions, except percentages) | Q3 Fiscal 2023 |  | Q3 Fiscal 2022 |  | Change |  | Q3 Fiscal 2023 |  | Q3 Fiscal 2022 |  | Change |  |  |  |
| Revenues | $7,174 |  | $9,378 |  | (24%) |  | $1,230 |  | $1,519 |  | (19%) |  |  |  |
| EBT | $1,744 |  | $2,996 |  | (42%) |  | $811 |  | $1,080 |  | (25%) |  |  |  |
| EBT as % of revenues | 24% |  | 32% |  | -8 points |  | 66% |  | 71% |  | -5 points |  |  |  |

[0000804328-23-000042:8k_2_02:22]
| Qualcomm Announces Third Quarter Fiscal 2023 Results | Page 2 of 8 |

[0000804328-23-000042:8k_2_02:23]
QCT Revenue Streams1, 2

[0000804328-23-000042:8k_2_02:24]
| (in millions, except percentages) |  |  |  |  |  |  | Q3 Fiscal 2023 |  | Q3 Fiscal 2022 |  | Change |  |  |  |  |  |  |  |  |  |
| Handsets |  |  |  |  |  |  | $5,255 |  | $7,047 |  | (25%) |  |  |  |  |  |  |  |  |  |
| Automotive |  |  |  |  |  |  | 434 |  | 385 |  | +13% |  |  |  |  |  |  |  |  |  |
| IoT |  |  |  |  |  |  | 1,485 |  | 1,946 |  | (24%) |  |  |  |  |  |  |  |  |  |
| Total QCT revenues |  |  |  |  |  |  | $7,174 |  | $9,378 |  | (24%) |  |  |  |  |  |  |  |  |  |

[0000804328-23-000042:8k_2_02:25]
(1) We disaggregate QCT revenues based on the industries and applications in which our products are sold.

[0000804328-23-000042:8k_2_02:26]
(2) Beginning in the first quarter of fiscal 2023, QCT RFFE (radio frequency front-end) revenues, which were previously presented as a separate revenue stream, are now included within our Handsets, Automotive and internet of things (IoT) revenue streams, as applicable. Prior period information has been recast to reflect this change.

[0000804328-23-000042:8k_2_02:27]
Return of Capital to Stockholders

[0000804328-23-000042:8k_2_02:28]
During the third quarter of fiscal 2023, we returned $1.3 billion to stockholders, including $893 million, or $0.80 per share, of cash dividends paid and $400 million through repurchases of 4 million shares of common stock.

[0000804328-23-000042:8k_2_02:29]
Business Outlook

[0000804328-23-000042:8k_2_02:30]
The midpoint of our fourth quarter fiscal 2023 guidance includes the continued impact of the macroeconomic headwinds, weaker global handset units and channel inventory drawdown.

[0000804328-23-000042:8k_2_02:31]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.

[0000804328-23-000042:8k_2_02:32]
|  |  |  | Current Guidance Q4 FY23 Estimates1 |  |
|  | Revenues |  | $8.1B - $8.9B |  |
|  | Supplemental Revenue Information |  |  |  |
|  | QCT revenues |  | $6.9B - $7.5B |  |
|  | QTL revenues |  | $1.15B - $1.35B |  |
|  | GAAP diluted EPS |  | $1.37 - $1.57 |  |
|  | Less diluted EPS attributable to QSI |  | $— |  |  |
|  | Less diluted EPS attributable to share-based compensation |  | ($0.45) |  |  |
|  | Less diluted EPS attributable to other items2 |  | $0.02 |  |  |
|  | Non-GAAP diluted EPS |  | $1.80 - $2.00 |  |

[0000804328-23-000042:8k_2_02:33]
(1)  Our outlook does not include provisions for proposed tax law changes, future asset impairments, charges from additional restructuring actions or for pending legal matters, other than future legal amounts that are probable and estimable. Further, due to their nature, certain income and expense items, such as certain investments, derivative and foreign currency transaction gains or losses, cannot be accurately forecast. Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain. Our outlook includes the impact of any pending business combinations to the extent they are expected to close in the upcoming quarter. Actual results may differ materially from the outlook.

[0000804328-23-000042:8k_2_02:34]
(2)  Our guidance for diluted EPS attributable to other items for the fourth quarter of fiscal 2023 is primarily related to the tax benefit resulting from the requirement to capitalize research and development (R&D) expenditures under U.S. Federal income tax law, partially offset by acquisition-related items and existing restructuring plan charges.

[0000804328-23-000042:8k_2_02:35]
| Qualcomm Announces Third Quarter Fiscal 2023 Results | Page 3 of 8 |

[0000804328-23-000042:8k_2_02:36]
Conference Call

[0000804328-23-000042:8k_2_02:37]
Qualcomm’s third quarter fiscal 2023 earnings conference call will be broadcast live on August 2, 2023, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm. This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G. The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to our financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at http://investor.qualcomm.com/ immediately prior to the commencement of the call. An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter. To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415. Callers should use reservation number 13739729.

[0000804328-23-000042:8k_2_02:38]
About Qualcomm

[0000804328-23-000042:8k_2_02:39]
Qualcomm is enabling a world where everyone and everything can be intelligently connected. Our one technology roadmap allows us to efficiently scale the technologies that launched the mobile revolution – including advanced connectivity, high-performance, low-power compute, on-device intelligence and more – to the next generation of connected smart devices across industries. Innovations from Qualcomm and our family of Snapdragon platforms will help enable cloud-edge convergence, transform industries, accelerate the digital economy, and revolutionize how we experience the world, for the greater good.

[0000804328-23-000042:8k_2_02:40]
Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio. Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of our engineering and research and development functions and substantially all of our products and services businesses, including our QCT semiconductor business. Snapdragon and Qualcomm branded products are products of Qualcomm Technologies, Inc. and/or its subsidiaries. Qualcomm patented technologies are licensed by Qualcomm Incorporated.

[0000804328-23-000042:8k_2_02:41]
Note Regarding Forward-Looking Statements

[0000804328-23-000042:8k_2_02:42]
###

[0000804328-23-000042:8k_2_02:43]
| Qualcomm Announces Third Quarter Fiscal 2023 Results | Page 4 of 8 |

[0000804328-23-000042:8k_2_02:44]
QUALCOMM Incorporated

[0000804328-23-000042:8k_2_02:45]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000804328-23-000042:8k_2_02:46]
(In millions, except par value amounts)

[0000804328-23-000042:8k_2_02:47]
(Unaudited)

[0000804328-23-000042:8k_2_02:48]
|  | June 25,2023 |  | September 25,2022 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 6,087 |  |  | $ | 2,773 |  |
| Marketable securities | 2,544 |  |  | 3,609 |  |
| Accounts receivable, net | 3,850 |  |  | 5,643 |  |
| Inventories | 6,628 |  |  | 6,341 |  |
| Held for sale assets | 317 |  |  | 733 |  |
| Other current assets | 1,050 |  |  | 1,625 |  |
| Total current assets | 20,476 |  |  | 20,724 |  |
| Deferred tax assets | 2,773 |  |  | 1,803 |  |
| Property, plant and equipment, net | 5,216 |  |  | 5,168 |  |
| Goodwill | 10,591 |  |  | 10,508 |  |
| Other intangible assets, net | 1,618 |  |  | 1,882 |  |
| Held for sale assets | 218 |  |  | 1,200 |  |
| Other assets | 8,110 |  |  | 7,729 |  |
| Total assets | $ | 49,002 |  |  | $ | 49,014 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,744 |  |  | $ | 3,796 |  |
| Payroll and other benefits related liabilities | 1,546 |  |  | 1,486 |  |
| Unearned revenues | 249 |  |  | 369 |  |
| Short-term debt | 914 |  |  | 1,945 |  |
| Held for sale liabilities | 300 |  |  | 581 |  |
| Other current liabilities | 3,710 |  |  | 3,689 |  |
| Total current liabilities | 8,463 |  |  | 11,866 |  |
| Unearned revenues | 92 |  |  | 144 |  |
| Income taxes payable | 1,098 |  |  | 1,472 |  |
| Long-term debt | 14,530 |  |  | 13,537 |  |
| Held for sale liabilities | 36 |  |  | 119 |  |
| Other liabilities | 4,113 |  |  | 3,863 |  |
| Total liabilities | 28,332 |  |  | 31,001 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,115 and 1,121 shares issued and outstanding, respectively | 77 |  |  | 195 |  |
| Retained earnings | 20,163 |  |  | 17,840 |  |
| Accumulated other comprehensive income (loss) | 430 |  |  | (22) |  |
| Total stockholders’ equity | 20,670 |  |  | 18,013 |  |
| Total liabilities and stockholders’ equity | $ | 49,002 |  |  | $ | 49,014 |  |

[0000804328-23-000042:8k_2_02:49]
| Qualcomm Announces Third Quarter Fiscal 2023 Results | Page 5 of 8 |

[0000804328-23-000042:8k_2_02:50]
QUALCOMM Incorporated

[0000804328-23-000042:8k_2_02:51]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000804328-23-000042:8k_2_02:52]
(In millions, except per share data)

[0000804328-23-000042:8k_2_02:53]
(Unaudited)

[0000804328-23-000042:8k_2_02:54]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  |  | June 25,2023 |  | June 26,2022 |  | June 25,2023 |  | June 26,2022 |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services |  |  |  |  |  | $ | 7,108 |  |  | $ | 9,266 |  |  | $ | 22,737 |  |  | $ | 27,365 |  |
| Licensing |  |  |  |  |  | 1,343 |  |  | 1,670 |  |  | 4,452 |  |  | 5,440 |  |
| Total revenues |  |  |  |  |  | 8,451 |  |  | 10,936 |  |  | 27,189 |  |  | 32,805 |  |
| Costs and expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  |  |  |  | 3,792 |  |  | 4,816 |  |  | 11,989 |  |  | 13,767 |  |
| Research and development |  |  |  |  |  | 2,222 |  |  | 2,052 |  |  | 6,683 |  |  | 6,016 |  |
| Selling, general and administrative |  |  |  |  |  | 618 |  |  | 655 |  |  | 1,854 |  |  | 1,887 |  |
| Other |  |  |  |  |  | (4) |  |  | (1,059) |  |  | 285 |  |  | (1,059) |  |
| Total costs and expenses |  |  |  |  |  | 6,628 |  |  | 6,464 |  |  | 20,811 |  |  | 20,611 |  |
| Operating income |  |  |  |  |  | 1,823 |  |  | 4,472 |  |  | 6,378 |  |  | 12,194 |  |
| Interest expense |  |  |  |  |  | (172) |  |  | (70) |  |  | (521) |  |  | (345) |  |
| Investment and other income (expense), net |  |  |  |  |  | 106 |  |  | (163) |  |  | 166 |  |  | (321) |  |
| Income from continuing operations before income taxes |  |  |  |  |  | 1,757 |  |  | 4,239 |  |  | 6,023 |  |  | 11,528 |  |
| Income tax expense |  |  |  |  |  | (22) |  |  | (509) |  |  | (313) |  |  | (1,465) |  |
| Income from continuing operations |  |  |  |  |  | 1,735 |  |  | 3,730 |  |  | 5,710 |  |  | 10,063 |  |
| Discontinued operations, net of income taxes |  |  |  |  |  | 68 |  |  | — |  |  | 32 |  |  | — |  |
| Net income |  |  |  |  |  | $ | 1,803 |  |  | $ | 3,730 |  |  | $ | 5,742 |  |  | $ | 10,063 |  |
| Basic earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  |  |  |  |  | $ | 1.56 |  |  | $ | 3.32 |  |  | $ | 5.11 |  |  | $ | 8.96 |  |
| Discontinued operations |  |  |  |  |  | 0.06 |  |  | — |  |  | 0.03 |  |  | — |  |
| Net income |  |  |  |  |  | $ | 1.62 |  |  | $ | 3.32 |  |  | $ | 5.14 |  |  | $ | 8.96 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  |  |  |  |  | $ | 1.54 |  |  | $ | 3.29 |  |  | $ | 5.07 |  |  | $ | 8.84 |  |
| Discontinued operations |  |  |  |  |  | 0.06 |  |  | — |  |  | 0.03 |  |  | — |  |
| Net income |  |  |  |  |  | $ | 1.60 |  |  | $ | 3.29 |  |  | $ | 5.10 |  |  | $ | 8.84 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  | 1,115 |  |  | 1,122 |  |  | 1,117 |  |  | 1,124 |  |
| Diluted |  |  |  |  |  | 1,124 |  |  | 1,134 |  |  | 1,126 |  |  | 1,139 |  |

[0000804328-23-000042:8k_2_02:55]
| Qualcomm Announces Third Quarter Fiscal 2023 Results | Page 6 of 8 |

[0000804328-23-000042:8k_2_02:56]
QUALCOMM Incorporated

[0000804328-23-000042:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000804328-23-000042:8k_2_02:58]
(In millions)

[0000804328-23-000042:8k_2_02:59]
(Unaudited)

[0000804328-23-000042:8k_2_02:60]
|  | Three Months Ended |  | Nine Months Ended |  |  |  |  |  |  |
|  | June 25,2023 |  | June 26,2022 |  | June 25,2023 |  | June 26,2022 |  |  |  |  |  |  |
| Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income from continuing operations | $ | 1,735 |  |  | $ | 3,730 |  |  | $ | 5,710 |  |  | $ | 10,063 |  |  |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 479 |  |  | 438 |  |  | 1,347 |  |  | 1,272 |  |  |  |  |  |  |  |
| Income tax provision (less than) in excess of income tax payments | (205) |  |  | 169 |  |  | (836) |  |  | (234) |  |  |  |  |  |  |  |
| Share-based compensation expense | 614 |  |  | 516 |  |  | 1,876 |  |  | 1,510 |  |  |  |  |  |  |  |
| Net (gains) losses on marketable securities and other investments | (39) |  |  | 161 |  |  | (84) |  |  | 374 |  |  |  |  |  |  |  |
| Impairment losses on other investments | 19 |  |  | 20 |  |  | 120 |  |  | 41 |  |  |  |  |  |  |  |
| Other items, net | 7 |  |  | 15 |  |  | 23 |  |  | (41) |  |  |  |  |  |  |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net | (157) |  |  | 285 |  |  | 1,807 |  |  | (216) |  |  |  |  |  |  |  |
| Inventories | 204 |  |  | (864) |  |  | (192) |  |  | (2,201) |  |  |  |  |  |  |  |
| Other assets | (11) |  |  | (548) |  |  | 604 |  |  | (2,360) |  |  |  |  |  |  |  |
| Trade accounts payable | 306 |  |  | (31) |  |  | (2,052) |  |  | 948 |  |  |  |  |  |  |  |
| Payroll, benefits and other liabilities | 68 |  |  | (903) |  |  | (604) |  |  | (1,274) |  |  |  |  |  |  |  |
| Unearned revenues | (30) |  |  | (93) |  |  | (116) |  |  | (232) |  |  |  |  |  |  |  |
| Net cash used by operating activities from discontinued operations | (333) |  |  | — |  |  | (394) |  |  | — |  |  |  |  |  |  |  |
| Net cash provided by operating activities | 2,657 |  |  | 2,895 |  |  | 7,209 |  |  | 7,650 |  |  |  |  |  |  |  |
| Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | (306) |  |  | (554) |  |  | (1,157) |  |  | (1,628) |  |  |  |  |  |  |  |
| Purchases of debt and equity marketable securities | — |  |  | (333) |  |  | (22) |  |  | (1,269) |  |  |  |  |  |  |  |
| Proceeds from sales and maturities of debt and equity marketable securities | 628 |  |  | 397 |  |  | 1,119 |  |  | 1,960 |  |  |  |  |  |  |  |
| Acquisitions and other investments, net of cash acquired | (46) |  |  | (4,455) |  |  | (107) |  |  | (4,743) |  |  |  |  |  |  |  |
| Proceeds from sales of property, plant and equipment | — |  |  | — |  |  | 121 |  |  | — |  |  |  |  |  |  |  |
| Proceeds from other investments | 2 |  |  | 28 |  |  | 13 |  |  | 125 |  |  |  |  |  |  |  |
| Other items, net | 22 |  |  | 41 |  |  | 18 |  |  | 41 |  |  |  |  |  |  |  |
| Net cash provided by investing activities from discontinued operations | 1,437 |  |  | — |  |  | 1,395 |  |  | — |  |  |  |  |  |  |  |
| Net cash provided (used) by investing activities | 1,737 |  |  | (4,876) |  |  | 1,380 |  |  | (5,514) |  |  |  |  |  |  |  |
| Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from short-term debt | — |  |  | 1,603 |  |  | 4,668 |  |  | 3,065 |  |  |  |  |  |  |  |
| Repayment of short-term debt | (498) |  |  | (1,604) |  |  | (5,166) |  |  | (3,066) |  |  |  |  |  |  |  |
| Repayment of debt of acquired company | — |  |  | (349) |  |  | — |  |  | (349) |  |  |  |  |  |  |  |
| Proceeds from long-term debt | — |  |  | 1,477 |  |  | 1,880 |  |  | 1,477 |  |  |  |  |  |  |  |
| Repayment of long-term debt | — |  |  | (1,540) |  |  | (1,446) |  |  | (1,540) |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock | 1 |  |  | 1 |  |  | 233 |  |  | 188 |  |  |  |  |  |  |  |
| Repurchases and retirements of common stock | (400) |  |  | (500) |  |  | (2,573) |  |  | (2,629) |  |  |  |  |  |  |  |
| Dividends paid | (893) |  |  | (842) |  |  | (2,569) |  |  | (2,371) |  |  |  |  |  |  |  |
| Payments of tax withholdings related to vesting of share-based awards | (167) |  |  | (189) |  |  | (499) |  |  | (751) |  |  |  |  |  |  |  |
| Other items, net | (2) |  |  | (17) |  |  | (16) |  |  | (28) |  |  |  |  |  |  |  |
| Net cash used by financing activities from discontinued operations | (29) |  |  | — |  |  | (58) |  |  | — |  |  |  |  |  |  |  |
| Net cash used by financing activities | (1,988) |  |  | (1,960) |  |  | (5,546) |  |  | (6,004) |  |  |  |  |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents | (11) |  |  | (34) |  |  | 35 |  |  | (50) |  |  |  |  |  |  |  |
| Net increase (decrease) in total cash and cash equivalents | 2,395 |  |  | (3,975) |  |  | 3,078 |  |  | (3,918) |  |  |  |  |  |  |  |
| Total cash and cash equivalents at beginning of period (including $294 and $326 million classified as held for sale at March 26, 2023 and September 25, 2022, respectively) | 3,782 |  |  | 7,173 |  |  | 3,099 |  |  | 7,116 |  |  |  |  |  |  |  |
| Total cash and cash equivalents at end of period (including $90 and $522 million classified as held for sale at June 25, 2023 and June 26, 2022, respectively) | $ | 6,177 |  |  | $ | 3,198 |  |  | $ | 6,177 |  |  | $ | 3,198 |  |  |  |  |  |  |  |

[0000804328-23-000042:8k_2_02:61]
| Qualcomm Announces Third Quarter Fiscal 2023 Results | Page 7 of 8 |

[0000804328-23-000042:8k_2_02:62]
Note Regarding Use of Non-GAAP Financial Measures

[0000804328-23-000042:8k_2_02:63]
The Non-GAAP financial measures presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP. In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, our Non-GAAP financial measures might be different than similarly titled measures used by other companies. Reconciliations between GAAP and Non-GAAP financial measures are presented herein.

[0000804328-23-000042:8k_2_02:64]
We use Non-GAAP financial information: (i) to evaluate, assess and benchmark our operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of our ongoing core operating businesses, including our QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors. Non-GAAP measurements used by us include revenues, cost of revenues, research and development (R&D) expenses, selling, general and administrative (SG&A) expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share. We are able to assess what we believe is a meaningful and comparable set of financial performance measures by using Non-GAAP information. In addition, the HR and Compensation Committee of our Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers. We present Non-GAAP financial information to provide greater transparency to investors with respect to our use of such information in financial and operational decision-making. This Non-GAAP financial information is also used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0000804328-23-000042:8k_2_02:65]
Non-GAAP information presented herein excludes our QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0000804328-23-000042:8k_2_02:66]
•QSI is excluded because we generally expect to exit our strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed as unrelated to our operational performance.

[0000804328-23-000042:8k_2_02:67]
•Share-based compensation expense primarily relates to restricted stock units. We believe that excluding share-based compensation from Non-GAAP financial information allows us and investors to make additional comparisons of the operating activities of our ongoing core businesses over time and with respect to other companies.

[0000804328-23-000042:8k_2_02:68]
•Certain other items are excluded because we view such items as unrelated to the operating activities of our ongoing core businesses, as follows:

[0000804328-23-000042:8k_2_02:69]
◦Acquisition-related items include amortization of acquisition-related intangible assets, substantially all of which relate to the amortization of technology-based intangible assets that is recorded in cost of revenues and will recur in future periods until the related intangible assets have been fully amortized. We view acquisition-related intangible assets as items arising from pre-acquisition activities determined at the time of an acquisition. Acquisition-related intangible assets contribute to revenue generation that has not been excluded from our Non-GAAP financial information.  Acquisition-related items also include recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of acquisition-related items, as well as any effects from restructuring the ownership of such acquired assets. We also exclude the operating results of acquired and/or consolidated businesses that, as of close, are expected or required to be sold. Additionally, we exclude certain other acquisition-related charges such as third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition.

[0000804328-23-000042:8k_2_02:70]
◦We exclude certain other items that we view as unrelated to our ongoing businesses, such as major restructuring and restructuring-related costs, asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. We exclude gains and losses driven by the revaluation of our deferred compensation plan liabilities recognized in operating expenses and the offsetting gains and losses on the related plan assets recognized in investment and other income (expense).

[0000804328-23-000042:8k_2_02:71]
◦Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of our ongoing Non-GAAP tax rate and after-tax earnings. Beginning in the first quarter of fiscal 2023 and for the initial five-year period in which we are required to capitalize and amortize R&D expenditures for U.S. federal income tax purposes, we also exclude the favorable impact to our provision for income taxes and results of operations resulting from such change in treatment of R&D expenditures. The favorable tax provision impact will diminish in future years as capitalized research and development expenditures continue to amortize.

[0000804328-23-000042:8k_2_02:72]
| Qualcomm Announces Third Quarter Fiscal 2023 Results | Page 8 of 8 |

[0000804328-23-000042:8k_2_02:73]
Reconciliations of GAAP Results to Non-GAAP Results

[0000804328-23-000042:8k_2_02:74]
| (in millions, except per share data and percentages) |  |  |  | GAAP to Non-GAAP Reconciliation | Non-GAAP Supplemental Information |
|  |  |  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1 | Non-GAAP Results | QCT | QTL | Non-GAAP Reconciling Items2 |
| Q3 Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $8,451 |  | $9 |  | $— |  |  | $— |  |  | $8,442 |  | $7,174 |  | $1,230 |  | $38 |  |
| Operating income (loss) |  |  |  | 1,823 |  | 2 |  |  | (613) |  | (87) |  | 2,521 |  |  |  |  |  |  |  |
| EBT |  |  |  | 1,757 |  | (21) |  | (613) |  | (39) |  | 2,430 |  | 1,744 |  | 811 |  | (125) |  |
| EBT as % of revenues |  |  |  | 21 | % |  |  |  |  |  |  |  | 29 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 1,803 |  | (17) |  | (525) |  | 240 |  | 2,105 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $1.60 |  | ($0.01) |  | ($0.47) |  | $0.21 |  | $1.87 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,124 |  | 1,124 |  | 1,124 |  | 1,124 |  | 1,124 |  |  |  |  |  |  |  |
| Q3 Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $10,936 |  | $8 |  | $— |  |  | $— |  |  | $10,928 |  | $9,378 |  | $1,519 |  | $31 |  |
| Operating income (loss) |  |  |  | 4,472 |  | 2 |  | (544) |  | 1,009 |  | 4,005 |  |  |  |  |  |  |  |
| EBT |  |  |  | 4,239 |  | (101) |  | (544) |  | 990 |  | 3,894 |  | 2,996 |  | 1,080 |  | (182) |  |
| EBT as % of revenues |  |  |  | 39 | % |  |  |  |  |  |  |  | 36 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 3,730 |  | (80) |  | (421) |  | 875 |  | 3,356 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $3.29 |  | ($0.07) |  | ($0.37) |  | $0.77 |  | $2.96 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,134 |  | 1,134 |  | 1,134 |  | 1,134 |  | 1,134 |  |  |  |  |  |  |  |

[0000804328-23-000042:8k_2_02:75]
(1)  Further details of amounts included in the “Other Items” column for the current period are included at the end of this news release in the section labeled “Supplemental Information and Reconciliations.” Details of amounts included in the “Other Items” column for the prior periods are included in the news releases for those periods.

[0000804328-23-000042:8k_2_02:76]
(2)   Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations. Non-GAAP reconciling items related to EBT consisted primarily of certain cost of revenues, R&D expenses, SG&A expenses, other expenses or income, interest expense and certain investment income (expense) that are not allocated to segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit.

[0000804328-23-000042:8k_2_02:77]
Sums may not equal totals due to rounding.

[0000804328-23-000042:8k_2_02:78]
|  | Q3 Fiscal 2023 Supplemental Information and Reconciliations |  |
|  | (in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |
|  | Cost of revenues |  | $3,792 |  |  | $4 |  |  | $19 |  |  | $29 |  |  | $3,740 |  |
|  | Research and development expenses |  | 2,222 |  |  | — |  |  |  | 470 |  |  | 35 |  |  | 1,717 |  |
|  | Selling, general and administrative expenses |  | 618 |  |  | 3 |  |  | 124 |  |  | 27 |  |  | 464 |  |
|  | Other income |  | (4) |  |  |  | — |  |  |  | — |  |  |  | (4) |  |  |  | — |  |  |
|  | Interest expense |  | 172 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 172 |  |
|  | Investment and other income (expense), net |  | 106 |  |  | (23) |  |  | — |  |  |  | 48 |  |  | 81 |  |
|  | Income tax expense (benefit) |  | 22 |  |  | (4) |  |  |  | (88) |  |  |  | (211) |  |  | 325 |  |
|  | Discontinued operations, net of income taxes |  | 68 |  |  | — |  |  |  | — |  |  |  | 68 |  |  |  | — |  |  |

[0000804328-23-000042:8k_2_02:79]
(1)  Other items excluded from Non-GAAP results included $39 million of acquisition-related charges, $48 million of losses driven by the revaluation of our deferred compensation plan liabilities, which increased operating expenses, offset by corresponding $48 million of gains driven by the revaluation of the associated plan assets, which were included within investment and other income (expense), net, as well as $68 million of income, net of income taxes, from the discontinued operations of the Non-Arriver businesses.

[0000804328-23-000042:8k_2_02:80]
(2)   At fiscal year end, the quarterly tax provision for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. Tax benefit in the “Other Items” column included a $126 million benefit from fiscal 2021 and 2022 foreign-derived intangible income (FDII) deductions related to a change in sourcing of R&D expenditures, a $57 million benefit related to a foreign tax audit, a $35 million benefit from the FDII deduction resulting from the requirement to capitalize and amortize R&D expenditures, an $11 million benefit for the tax effect of acquisition-related charges and a $7 million benefit from the combined effect of other items in EBT, partially offset by an $11 million foreign currency loss related to a noncurrent receivable resulting from our refund claim of Korean withholding taxes paid in prior periods, an $11 million charge related to prior periods and a $3 million charge to reconcile the tax provision of each column to the total GAAP tax provision for the quarter.

[0000804328-23-000042:8k_2_02:81]
Sums may not equal totals due to rounding.
