# QCOM notes — 0000804328-23-000043


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000804328-23-000043:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 25, 2022. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and nine months ended June 25, 2023 and June 26, 2022 included 13 weeks and 39 weeks, respectively.

[0000804328-23-000043:notes:2]
[same as prior period, unchanged from 0000804328-23-000023:notes:2]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-23-000043:notes:3]
[same as prior period, unchanged from 0000804328-23-000023:notes:3]

[0000804328-23-000043:notes:4]
| Inventories (in millions) |  |  |  |
|  | June 25,2023 |  | September 25,2022 |
| Raw materials | $ | 194 |  |  | $ | 221 |  |
| Work-in-process | 4,366 |  |  | 3,329 |  |
| Finished goods | 2,068 |  |  | 2,791 |  |
|  | $ | 6,628 |  |  | $ | 6,341 |  |

[0000804328-23-000043:notes:5]
[same as prior period, unchanged from 0000804328-23-000023:notes:5]

[0000804328-23-000043:notes:6]
[same as prior period, unchanged from 0000804328-23-000023:notes:6]

[0000804328-23-000043:notes:7]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  | June 25,2023 |  | June 26,2022 |  | June 25,2023 |  | June 26,2022 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 5,255 |  |  | $ | 7,047 |  |  | $ | 17,114 |  |  | $ | 21,385 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 434 |  |  | 385 |  |  | 1,337 |  |  | 1,044 |  |
| IoT (3) |  |  |  |  |  |  |  |  | 1,485 |  |  | 1,946 |  |  | 4,557 |  |  | 5,344 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 7,174 |  |  | $ | 9,378 |  |  | $ | 23,008 |  |  | $ | 27,773 |  |

[0000804328-23-000043:notes:8]
[same as prior period, unchanged from 0000804328-23-000023:notes:8]

[0000804328-23-000043:notes:9]
[same as prior period, unchanged from 0000804328-23-000023:notes:9]

[0000804328-23-000043:notes:10]
[same as prior period, unchanged from 0000804328-23-000023:notes:10]

[0000804328-23-000043:notes:11]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods generally include certain QCT sales-based royalty revenues related to system software, certain amounts related to QCT customer incentives and QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due) and were as follows (in millions):

[0000804328-23-000043:notes:12]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | June 25,2023 |  | June 26,2022 |
| Revenues recognized from previously satisfied performance obligations | $ | 216 |  |  | $ | 260 |  |  | $ | 521 |  |  | $ | 578 |  |

[0000804328-23-000043:notes:13]
Unearned revenues (which are considered contract liabilities) consist primarily of certain customer contracts for which QCT received fees upfront and QTL license fees for intellectual property with continuing performance obligations. In the nine months ended June 25, 2023 and June 26, 2022, we recognized revenues of $302 million and $482 million, respectively, that were recorded as unearned revenues at September 25, 2022 and September 26, 2021, respectively.

[0000804328-23-000043:notes:14]
[same as prior period, unchanged from 0000804328-23-000023:notes:14]

[0000804328-23-000043:notes:15]
[same as prior period, unchanged from 0000804328-23-000023:notes:15]

[0000804328-23-000043:notes:16]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | June 25,2023 |  | June 26,2022 |
| Customer/licensee (x) | 24 | % |  | 22 | % |  | 21 | % |  | 20 | % |
| Customer/licensee (y) | 23 |  |  | 17 |  |  | 28 |  |  | 20 |  |

[0000804328-23-000043:notes:17]
Other Income, Costs and Expenses. Other expense in the nine months ended June 25, 2023 consisted of $285 million in restructuring and restructuring-related charges, substantially all of which related to severance costs, resulting from certain cost reduction initiatives committed to in fiscal 2023. We expect actions associated with existing restructuring plans to be substantially completed (including payments of the related severance) by the end of fiscal 2023.

[0000804328-23-000043:notes:18]
Given the continued uncertainty in the macroeconomic and demand environment, we expect to take additional restructuring actions to enable continued investments in key growth and diversification opportunities. While we are in the process of developing our plans, we currently expect these actions to consist largely of workforce reductions, and in connection with any such actions we would expect to incur significant additional restructuring charges, a substantial portion of which we expect to incur in the fourth quarter of fiscal 2023. We currently anticipate these additional actions to be substantially completed in the first half of fiscal 2024.

[0000804328-23-000043:notes:19]
Other income in the three and nine months ended June 26, 2022 consisted of a $1.1 billion benefit resulting from the General Court of the European Union issuing a ruling to annul a decision made by the European Commission (EC). The benefit was the result of reversing a previously accrued fine and the associated interest that was accrued as a financial guarantee for the decision made by the EC in fiscal 2018.

[0000804328-23-000043:notes:20]
| Investment and Other Income (Expense), Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | June 25,2023 |  | June 26,2022 |
| Interest and dividend income | $ | 79 |  |  | $ | 22 |  |  | $ | 193 |  |  | $ | 59 |  |
| Net losses on marketable securities | (23) |  |  | (104) |  |  | (3) |  |  | (327) |  |
| Net gains on other investments | 17 |  |  | 25 |  |  | 17 |  |  | 97 |  |
| Net gains (losses) on deferred compensation plan assets | 48 |  |  | (80) |  |  | 95 |  |  | (110) |  |
| Impairment losses on other investments | (19) |  |  | (20) |  |  | (120) |  |  | (41) |  |
| Other | 4 |  |  | (6) |  |  | (16) |  |  | 1 |  |
|  | $ | 106 |  |  | $ | (163) |  |  | $ | 166 |  |  | $ | (321) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-23-000043:notes:21]
Income Taxes
We estimate our annual effective income tax rate to be 6% for fiscal 2023, which is lower than the U.S. federal statutory rate, primarily due to (i) a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, which includes certain benefits discussed below from the new requirement to capitalize research and development expenditures for federal income tax purposes, (ii) a benefit from our federal research and development tax credit, (iii) benefits from fiscal 2021 and 2022 FDII deductions related to a change in sourcing of research and development expenditures and (iv) a benefit related to foreign currency gains on a noncurrent receivable related to our refund claim of Korean withholding tax. Our effective tax rate of 1% for the third quarter of fiscal 2023 was lower than our estimated annual effective tax rate of 6% primarily due to benefits from fiscal 2021 and 2022 FDII deductions related to a change in sourcing of research and development expenditures recognized discretely in the third quarter.

[0000804328-23-000043:notes:22]
Beginning in fiscal 2023, for federal income tax purposes, we are required to capitalize and amortize domestic research and development expenditures over five years and foreign research and development expenditures over fifteen years (such expenditures were previously deducted as incurred). Our cash flows from operations will be adversely affected due to significantly higher cash tax payments. However, since the resulting deferred tax asset is established at the statutory rate of 21% (rather than the effective tax rate of 13% to 16% after considering the FDII deduction), capitalization favorably affects our provision for income taxes and results of operations. The adverse cash flow impact and favorable tax provision impact will diminish in future years as capitalized research and development expenditures continue to amortize.
Income taxes payable (recorded in other current liabilities) were $1.4 billion and $634 million at June 25, 2023 and September 25, 2022, respectively. This increase was primarily due to an announcement (IR-2023-33) by the Internal Revenue Service (IRS), which postponed our remaining current year U.S. federal income tax-payment deadlines until October 2023.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-23-000043:notes:23]
Capital Stock
Stock Repurchase Program. On October 12, 2021, we announced a $10.0 billion stock repurchase program. The stock repurchase program has no expiration date. At June 25, 2023, $5.5 billion remained authorized for repurchase under our stock repurchase program.

[0000804328-23-000043:notes:24]
Shares Outstanding. Shares of common stock outstanding at June 25, 2023 were as follows (in millions):

[0000804328-23-000043:notes:25]
| Balance at September 25, 2022 | 1,121 |  |
| Issued | 15 |  |
| Repurchased | (21) |  |
| Balance at June 25, 2023 | 1,115 |  |

[0000804328-23-000043:notes:26]
Dividends. On July 14, 2023, we announced a cash dividend of $0.80 per share on our common stock, payable on September 21, 2023 to stockholders of record as of the close of business on August 31, 2023.

[0000804328-23-000043:notes:27]
[same as prior period, unchanged from 0000804328-23-000023:notes:26]

[0000804328-23-000043:notes:28]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | June 25,2023 |  | June 26,2022 |
| Dilutive common share equivalents included in diluted shares | 9 |  |  | 12 |  |  | 9 |  |  | 15 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 8 |  |  | 2 |  |  | 6 |  |  | 1 |  |


## us-gaap:DebtDisclosureTextBlock

[0000804328-23-000043:notes:29]
Debt
Long-term Debt. In November 2022, we issued unsecured fixed-rate notes, consisting of $700 million of fixed-rate 5.40% notes and $1.2 billion of fixed-rate 6.00% notes (collectively, November 2022 Notes) that mature on May 20, 2033 and May 20, 2053, respectively. The net proceeds from the November 2022 Notes were used to repay $946 million of fixed-rate notes and $500 million of floating-rate notes that matured in January 2023 and the excess will be used for general corporate purposes.

[0000804328-23-000043:notes:30]
At June 25, 2023, the aggregate fair value of our outstanding fixed-rate notes, based on Level 2 inputs, was approximately $14.9 billion.

[0000804328-23-000043:notes:31]
Interest Rate Swaps. At September 25, 2022, we had outstanding forward-starting interest rate swaps with an aggregate notional amount, denominated in U.S. dollars, of $1.6 billion. During the first quarter of fiscal 2023, in connection with the issuance of the November 2022 Notes, we terminated these swaps, and the related gains of $334 million, included within accumulated comprehensive income, are being recorded as a reduction to interest expense over the hedged portions of the related debt.

[0000804328-23-000043:notes:32]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. At June 25, 2023 and September 25, 2022, we had no amounts and $499 million, respectively, of outstanding commercial paper recorded as short-term debt.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-23-000043:notes:33]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0000804328-23-000043:notes:34]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other

[0000804328-23-000043:notes:35]
things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions, and on July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On May 23, 2022, the plaintiffs filed a motion for class certification, and on March 20, 2023, the court issued an order granting in part and denying in part the plaintiffs’ motion for class certification. The order denied class certification on the basis of alleged misrepresentations relating to our chip-level licensing practices, but certified a class on the basis of alleged misrepresentations relating to the separate operations of QCT and QTL. On April 3, 2023, we filed a petition with the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) seeking permission to appeal the district court’s class certification order, which the Ninth Circuit denied. No trial date has been set. We believe the plaintiffs’ claims are without merit.

[0000804328-23-000043:notes:36]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On July 5, 2018, the plaintiffs filed a motion for class certification, and on September 27, 2018, the court granted that motion. We appealed the district court’s class certification order to the Ninth Circuit. On September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class, and remanded the case to the district court. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. On August 1, 2022, we filed a motion to dismiss the amended complaint, and on January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. The order preserved the plaintiffs’ claims related to exclusive dealing under California antitrust and unfair competition laws and dismissed the remainder of the plaintiffs’ claims, which were related to our licensing practices. On April 7, 2023, we filed a motion for summary judgment on the plaintiffs’ remaining claims. A hearing on our motion is scheduled for August 3, 2023. We believe the plaintiffs’ claims are without merit.

[0000804328-23-000043:notes:37]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

[0000804328-23-000043:notes:38]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit. We believe that ParkerVision’s claims are without merit.

[0000804328-23-000043:notes:39]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (ARM) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with ARM (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. The complaint seeks specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology. ARM also contends that we

[0000804328-23-000043:notes:40]
violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of ARM’s trademarks and seeks associated injunctive and declaratory relief. ARM further seeks exemplary or punitive damages, costs, expenses and reasonable attorney’s fees, and equitable relief addressing any infringement occurring after entry of judgment. We believe ARM’s claims are without merit.

[0000804328-23-000043:notes:41]
On September 30, 2022, we filed our Answer and Counterclaim in response to ARM’s complaint denying ARM’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and ARM and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia), server System-on-Chip (SoC) and compute SoC are fully licensed under our existing Architecture License Agreement and Technology License Agreement with ARM (the ARM-Qualcomm Agreements). We further seek an order enjoining ARM from making any claim that our products are not licensed under the ARM-Qualcomm Agreements, are not ARM-compliant or that we are prohibited from using ARM’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements ARM is making in the marketplace concerning our rights under the ARM-Qualcomm Agreements are false, and that ARM has no right to prevent us from shipping our products, which are validly licensed. Trial is scheduled to begin on September 23, 2024.

[0000804328-23-000043:notes:42]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0000804328-23-000043:notes:43]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019, and on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. On April 12, 2023, the Korea Supreme Court delivered its judgment, which dismissed all appeals by both Qualcomm and the KFTC, affirming the judgment of the Seoul High Court. The Korea Supreme Court judgment concludes the appeal process.

[0000804328-23-000043:notes:44]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC did not provide a formal notice on the scope of its investigation, but we believe it concerned our business practices in connection with our sale of RFFE components. On April 18, 2023, the KFTC informed us that it had closed its investigation without finding any violation.

[0000804328-23-000043:notes:45]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were

[0000804328-23-000043:notes:46]
engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision finding that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. From March 13, 2023 to March 15, 2023, the court held a hearing on our appeal. The court has not yet issued a ruling. We believe that our business practices do not violate the European Union (EU) competition rules.

[0000804328-23-000043:notes:47]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to the EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding and included in other current liabilities.

[0000804328-23-000043:notes:48]
Contingent Losses and Other Considerations: We will continue to vigorously defend ourselves in the pending matters described above. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. Other than with respect to the EC fine related to the Icera Complaint to the European Commission, we have not recorded any accrual at June 25, 2023 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-23-000043:notes:49]
Segment InformationWe are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies, including RFFE, for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices; industrial devices; and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our cloud AI inference processing initiative.
The table below presents revenues and EBT for reportable segments (in millions):

[0000804328-23-000043:notes:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | June 25,2023 |  | June 26,2022 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 7,174 |  |  | $ | 9,378 |  |  | $ | 23,008 |  |  | $ | 27,773 |  |
| QTL | 1,230 |  |  | 1,519 |  |  | 4,044 |  |  | 4,917 |  |
| QSI | 9 |  |  | 8 |  |  | 22 |  |  | 22 |  |
| Reconciling items | 38 |  |  | 31 |  |  | 115 |  |  | 93 |  |
| Total | $ | 8,451 |  |  | $ | 10,936 |  |  | $ | 27,189 |  |  | $ | 32,805 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 1,744 |  |  | $ | 2,996 |  |  | $ | 6,035 |  |  | $ | 9,450 |  |
| QTL | 811 |  |  | 1,080 |  |  | 2,799 |  |  | 3,640 |  |
| QSI | (21) |  |  | (101) |  |  | (83) |  |  | (248) |  |
| Reconciling items | (777) |  |  | 264 |  |  | (2,728) |  |  | (1,314) |  |
| Total | $ | 1,757 |  |  | $ | 4,239 |  |  | $ | 6,023 |  |  | $ | 11,528 |  |

[0000804328-23-000043:notes:51]
[same as prior period, unchanged from 0000804328-23-000023:notes:50]

[0000804328-23-000043:notes:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25,2023 |  | June 26,2022 |  | June 25,2023 |  | June 26,2022 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 38 |  |  | $ | 31 |  |  | $ | 115 |  |  | $ | 93 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of revenues | $ | (42) |  |  | $ | (76) |  |  | $ | (155) |  |  | $ | (182) |  |
| Unallocated research and development expenses | (520) |  |  | (408) |  |  | (1,537) |  |  | (1,294) |  |
| Unallocated selling, general and administrative expenses | (172) |  |  | (171) |  |  | (464) |  |  | (462) |  |
| Unallocated other income (expenses) (Note 2) | 4 |  |  | 1,059 |  |  | (285) |  |  | 1,059 |  |
| Unallocated interest expense | (172) |  |  | (69) |  |  | (520) |  |  | (345) |  |
| Unallocated investment and other income (expense), net | 130 |  |  | (58) |  |  | 252 |  |  | (68) |  |
| Nonreportable segments | (5) |  |  | (13) |  |  | (19) |  |  | (22) |  |
|  | $ | (777) |  |  | $ | 264 |  |  | $ | (2,728) |  |  | $ | (1,314) |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000804328-23-000043:notes:53]
Acquisitions and Divestitures Veoneer. On October 4, 2021, we and SSW Partners, a New York-based investment partnership, entered into a definitive agreement to acquire Veoneer, Inc. (Veoneer). The transaction closed on April 1, 2022 (the Closing Date). Total cash consideration paid in the transaction was $4.7 billion, consisting of (i) $4.6 billion paid in respect of Veoneer’s outstanding capital stock and equity awards and amounts paid to settle Veoneer’s convertible senior notes (which were converted at the election of the note holders and settled in cash in the third quarter of fiscal 2022) and (ii) a $110 million termination fee paid to Magna International Inc. (Magna) in the first quarter of fiscal 2022. We funded substantially all of the cash consideration payable in the transaction in exchange for (i) the Arriver business (which SSW transferred to us shortly after the Closing Date) and (ii) the right to receive a majority of the proceeds upon the sale of the Non-Arriver businesses by SSW Partners. We intend to incorporate Arriver’s computer vision, drive policy and driver assistance technologies into our Snapdragon automotive platform to deliver an integrated software SoC ADAS platform for automakers and Tier-1 automotive suppliers. SSW Partners retained Veoneer’s Tier-1 automotive supplier businesses, primarily consisting of the Active Safety and the Restraint Control Systems businesses (the Non-Arriver businesses), with the intent to sell such businesses in multiple transactions.
Although we do not own or operate the Non-Arriver businesses, we are the primary beneficiary, within the meaning of the Financial Accounting Standards Board (FASB) accounting guidance related to consolidation (ASC 810), of these businesses under the variable interest model, until sold by SSW. Factors considered in reaching this conclusion included, among others: (i) our involvement in the design of and our funding of substantially all of the total cash consideration payable in the transaction and (ii) our obligations to absorb losses and rights to receive returns from the Non-Arriver businesses. Accordingly, the assets and liabilities of the Non-Arriver businesses have been consolidated and presented as held for sale on our condensed consolidated balance sheet, and the operating results have been presented as discontinued operations (through the date of disposition).

[0000804328-23-000043:notes:54]
[same as prior period, unchanged from 0000804328-23-000023:notes:56]

[0000804328-23-000043:notes:55]
[same as prior period, unchanged from 0000804328-23-000023:notes:57]

[0000804328-23-000043:notes:56]
[same as prior period, unchanged from 0000804328-23-000023:notes:58]

[0000804328-23-000043:notes:57]
(1) Held for sale assets and liabilities relate to the Non-Arriver businesses and were measured at fair value less costs to sell (including SSW Partners’ estimated return with respect to the sale proceeds of the Non-Arriver businesses), which was estimated using a market approach based on significant inputs that were not observable. The Non-Arriver businesses’ assets are not available to be used to settle our obligations, and the Non-Arriver businesses’ creditors do not have recourse to us. SSW Partners’ funding of the purchase price for Veoneer was recorded as a component of held for sale liabilities. The underlying classes of assets and liabilities held for sale have not been presented because such amounts are not material.

[0000804328-23-000043:notes:58]
Goodwill related to this transaction was allocated to our QCT segment, $471 million of which is expected to be deductible for tax purposes. Goodwill is primarily attributable to assembled workforce and certain synergies expected to arise after the acquisition. Completed technology-based intangible assets will be amortized on a straight-line basis over the weighted-average useful life of nine years. IPR&D relates to a single project that is expected to be completed in fiscal 2025. Upon completion, we expect the IPR&D to be amortized over its useful life of seven years. We valued the completed technology and IPR&D using an income approach based on significant unobservable inputs. Pro forma results of operations have not been presented because the effects of this acquisition were not material to our consolidated results of operations.

[0000804328-23-000043:notes:59]
On June 1, 2023, SSW Partners completed the sale of the Active Safety business to Magna for net cash proceeds of $1.5 billion. As a result of the sale, we recognized a gain in discontinued operations of $183 million (net of income tax expense) in the third quarter of fiscal 2023.

[0000804328-23-000043:notes:60]
We expect that SSW Partners will complete the sale of the Restraint Control Systems business within calendar 2023, subject to any required regulatory approvals and other closing conditions being met. The Restraint Control Systems business continues to be presented as discontinued operations on a one quarter reporting lag.  
The cash flows provided (used) by the Non-Arriver businesses are reflected as discontinued operations and are classified as operating, investing (which includes cash proceeds from the sale of the Active Safety business) and financing activities in the consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-23-000043:notes:61]
Fair Value Measurements and Marketable Securities
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at June 25, 2023 (in millions):

[0000804328-23-000043:notes:62]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 4,179 |  |  | $ | 634 |  |  | $ | — |  |  | $ | 4,813 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 2,396 |  |  | — |  |  | 2,396 |  |
| Mortgage- and asset-backed securities | — |  |  | 80 |  |  | — |  |  | 80 |  |
| Equity securities | 52 |  |  | — |  |  | — |  |  | 52 |  |
| U.S. Treasury securities and government-related securities | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total marketable securities | 52 |  |  | 2,492 |  |  | — |  |  | 2,544 |  |
| Derivative instruments | — |  |  | 50 |  |  | — |  |  | 50 |  |
| Other investments | 761 |  |  | — |  |  | 29 |  |  | 790 |  |
| Total assets measured at fair value | $ | 4,992 |  |  | $ | 3,176 |  |  | $ | 29 |  |  | $ | 8,197 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 259 |  |  | $ | — |  |  | $ | 259 |  |
| Other liabilities | 760 |  |  | — |  |  | — |  |  | 760 |  |
| Total liabilities measured at fair value | $ | 760 |  |  | $ | 259 |  |  | $ | — |  |  | $ | 1,019 |  |

[0000804328-23-000043:notes:63]
At June 25, 2023 and September 25, 2022, our marketable securities were all classified as current and were primarily comprised of available-for-sale debt securities (substantially all of which were corporate bonds and notes).

[0000804328-23-000043:notes:64]
[same as prior period, unchanged from 0000804328-23-000023:notes:65]

[0000804328-23-000043:notes:65]
|  | June 25,2023 |
| Years to Maturity |  |
| Less than one year | $ | 1,266 |  |
| One to five years | 1,146 |  |
| No single maturity date | 80 |  |
| Total | $ | 2,492 |  |

[0000804328-23-000043:notes:66]
[same as prior period, unchanged from 0000804328-23-000023:notes:67]
