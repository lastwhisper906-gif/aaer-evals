# QCOM notes — 0000804328-23-000006


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000804328-23-000006:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 25, 2022. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 25, 2022 and December 26, 2021 included 13 weeks.

[0000804328-23-000006:notes:2]
[same as prior period, unchanged from 0001728949-22-000040:notes:2]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-23-000006:notes:3]
[same as prior period, unchanged from 0001728949-22-000040:notes:3]

[0000804328-23-000006:notes:4]
| Inventories (in millions) |  |  |  |
|  | December 25,2022 |  | September 25,2022 |
| Raw materials | $ | 228 |  |  | $ | 221 |  |
| Work-in-process | 3,647 |  |  | 3,329 |  |
| Finished goods | 3,057 |  |  | 2,791 |  |
|  | $ | 6,932 |  |  | $ | 6,341 |  |

[0000804328-23-000006:notes:5]
Revenues. We disaggregate our revenues by segment (Note 7), by products and services (as presented on our condensed consolidated statement of operations), and for our QCT (Qualcomm CDMA Technologies) segment, by revenue stream, which is based on the industry and application in which our products are sold (as presented below). Beginning in the first quarter of fiscal 2023, QCT RFFE (radio frequency front-end) revenues, which were previously presented as a separate revenue stream, are now included within our Handset, Automotive and internet of things (IoT) revenue streams, as applicable, based on the industry and application in which the related RFFE products are sold. Prior period information has been recast to reflect this change. RFFE revenues include revenues from the sale of 4G, 5G sub 6 and 5G millimeter wave RFFE products (a substantial portion of which relate to mobile handsets) and exclude radio frequency transceiver components. This change aligns with changes made to our internal reporting of revenues. We believe this change provides a more meaningful presentation in understanding QCT revenues going forward, as we expect RFFE revenues to correspond with trends in Handsets, Automotive and IoT (as applicable) and is more consistent with how our revenue diversification is viewed externally. In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s (Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets.

[0000804328-23-000006:notes:6]
QCT revenue streams were as follows (in millions):

[0000804328-23-000006:notes:7]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | December 25,2022 |  | December 26,2021 |  |  |  |  |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 5,754 |  |  | $ | 6,989 |  |  |  |  |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 456 |  |  | 288 |  |  |  |  |  |
| IoT (3) |  |  |  |  |  |  |  |  | 1,682 |  |  | 1,570 |  |  |  |  |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 7,892 |  |  | $ | 8,847 |  |  |  |  |  |

[0000804328-23-000006:notes:8]
(1) Includes revenues from products sold for use in mobile handsets.

[0000804328-23-000006:notes:9]
(2) Includes revenues from products sold for use in automobiles, including connectivity, digital cockpit and advanced driver assistance systems (ADAS) and automated driving (AD).

[0000804328-23-000006:notes:10]
(3) Primarily includes products sold for use in the following industries and applications: consumer (including computing, voice and music and extended reality (XR)), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, transportation and logistics and utilities).

[0000804328-23-000006:notes:11]
[same as prior period, unchanged from 0001728949-22-000040:notes:11]

[0000804328-23-000006:notes:12]
|  | Three Months Ended |  |  |
|  | December 25,2022 (1) |  | December 26,2021 (2) |  |  |  |  |
| Revenues recognized from previously satisfied performance obligations | $ | 199 |  |  | $ | 242 |  |  |  |  |  |

[0000804328-23-000006:notes:13]
(1) Primarily related to certain QCT sales-based royalty revenues related to system software and certain QCT customer incentives.

[0000804328-23-000006:notes:14]
(2) Primarily related to certain QCT sales-based royalty revenues related to system software, QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due) and certain QCT customer incentives.

[0000804328-23-000006:notes:15]
Unearned revenues (which are considered contract liabilities) consist primarily of certain customer contracts for which QCT received fees upfront and QTL license fees for intellectual property with continuing performance obligations. In the three months ended December 25, 2022 and December 26, 2021, we recognized revenues of $173 million and $187 million, respectively, that were recorded as unearned revenues at September 25, 2022 and September 26, 2021, respectively.

[0000804328-23-000006:notes:16]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QCT received fees upfront and certain customer contracts for which QTL received license fees upfront. At December 25, 2022, we had $577 million of remaining performance obligations, of which $301 million, $201 million, $65 million, $6 million and $1 million is expected to be recognized as revenues for the remainder of fiscal 2023 and each of the subsequent four years from fiscal 2024 through 2027, respectively, and $3 million thereafter.

[0000804328-23-000006:notes:17]
Concentrations. A significant portion of our revenues are concentrated with a small number of customers/licensees of our QCT and QTL segments. The comparability of customer/licensee concentrations for the interim periods presented are impacted by the timing of customer/licensee device launches and/or innovation cycles and other seasonal trends, among other fluctuations in demand. Revenues from each customer/licensee that were 10% or greater of total revenues were as follows:

[0000804328-23-000006:notes:18]
|  | Three Months Ended |  |  |
|  | December 25,2022 |  | December 26,2021 |  |  |  |  |
| Customer/licensee (y) | 34 | % |  | 26 | % |  |  |  |  |
| Customer/licensee (z) | 14 |  |  | 19 |  |  |  |  |  |

[0000804328-23-000006:notes:19]
Other Expenses. Other expenses in the three months ended December 25, 2022 consisted of $80 million in restructuring charges, substantially all of which related to accrued severance costs, resulting from certain cost reduction initiatives during the quarter. Additionally, in the second quarter of fiscal 2023, we committed to take additional actions to reduce our operating expenses. As a result, we currently expect to incur additional restructuring charges in the second quarter of fiscal 2023 of approximately $80 million, substantially all of which relate to cash severance payments.

[0000804328-23-000006:notes:20]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 25,2022 |  | December 26,2021 |  |  |  |  |
| Interest and dividend income | $ | 55 |  |  | $ | 17 |  |  |  |  |  |
| Net gains on marketable securities | 11 |  |  | 17 |  |  |  |  |  |
| Net gains on other investments | — |  |  | 93 |  |  |  |  |  |
| Net gains on deferred compensation plan assets | 26 |  |  | 13 |  |  |  |  |  |
| Impairment losses on other investments | (14) |  |  | (1) |  |  |  |  |  |
| Net gains (losses) on derivative instruments | 9 |  |  | (13) |  |  |  |  |  |
| Equity in net (losses) earnings of investees | (8) |  |  | 7 |  |  |  |  |  |
| Net (losses) gains on foreign currency transactions | (3) |  |  | 7 |  |  |  |  |  |
|  | $ | 76 |  |  | $ | 140 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-23-000006:notes:21]
Income Taxes
We estimate our annual effective income tax rate to be 9% for fiscal 2023, which is lower than the U.S. federal statutory rate, primarily due to (i) a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, which includes certain benefits discussed below from the new requirement to capitalize research and development expenditures for federal income tax purposes, (ii) benefits from our federal research and development tax credit and (iii) benefits related to foreign currency gains on a noncurrent receivable related to our refund claim of Korean withholding tax. Our effective tax rate of 4% for the first quarter of fiscal 2023 was lower than our estimated annual effective tax rate of 9% primarily due to $150 million of net discrete tax benefits, which principally related to foreign currency gains on a noncurrent receivable related to our refund claim of Korean withholding tax. Our effective tax rate of 12% for the first quarter of fiscal 2022 included $103 million of discrete net tax benefits, which principally related to excess tax benefits associated with share-based awards that vested in the first fiscal quarter.

[0000804328-23-000006:notes:22]
Beginning in fiscal 2023, for federal income tax purposes, we are required to capitalize and amortize domestic research and development expenditures over five years and foreign research and development expenditures over fifteen years (such expenditures were previously deducted as incurred). Our cash flows from operations will be adversely affected due to significantly higher cash tax payments. However, since the resulting deferred tax asset is established at the statutory rate of 21% (rather than the effective tax rate of 13% to 16% after considering the FDII deduction), capitalization favorably affects our provision for income taxes and results of operations. The adverse cash flow impact and favorable tax provision impact will diminish in future years as capitalized research and development expenditures continue to amortize.

[0000804328-23-000006:notes:23]
Unrecognized tax benefits were $2.2 billion at both December 25, 2022 and September 25, 2022 and primarily related to our refund claim of Korean withholding tax. If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We expect that the total amount of unrecognized tax benefits at December 25, 2022 will increase in the next 12 months as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-23-000006:notes:24]
Capital StockStock Repurchase Program. On October 12, 2021, we announced a $10.0 billion stock repurchase program. The stock repurchase program has no expiration date. At December 25, 2022, $6.8 billion remained authorized for repurchase under our stock repurchase program. Since December 25, 2022, we repurchased and retired 5 million shares of common stock for $531 million.
Shares Outstanding. Shares of common stock outstanding at December 25, 2022 were as follows (in millions):

[0000804328-23-000006:notes:25]
| Balance at September 25, 2022 | 1,121 |  |
| Issued | 9 |  |
| Repurchased | (11) |  |
| Balance at December 25, 2022 | 1,119 |  |

[0000804328-23-000006:notes:26]
Dividends. On January 18, 2023, we announced a cash dividend of $0.75 per share on our common stock, payable on March 23, 2023 to stockholders of record as of the close of business on March 2, 2023.

[0000804328-23-000006:notes:27]
Earnings Per Common Share. Basic earnings per common share is computed by dividing net income by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of the weighted-average number of common shares outstanding and the weighted-average number of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans, during the reporting period. The following table provides information about the diluted earnings per share calculation (in millions):

[0000804328-23-000006:notes:28]
|  | Three Months Ended |  |  |
|  | December 25,2022 |  | December 26,2021 |  |  |  |  |
| Dilutive common share equivalents included in diluted shares | 9 |  |  | 18 |  |  |  |  |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 5 |  |  | — |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000804328-23-000006:notes:29]
Debt
Long-term Debt. In November 2022, we issued unsecured fixed-rate notes, consisting of $700 million of fixed-rate 5.40% notes and $1.2 billion of fixed-rate 6.00% notes (collectively, November 2022 Notes) that mature on May 20, 2033 and May 20, 2053, respectively. The net proceeds from the November 2022 Notes were used to repay $946 million of fixed-rate notes and $500 million of floating-rate notes that matured in January 2023 and the excess will be used for general corporate purposes.

[0000804328-23-000006:notes:30]
The following table provides a summary of our long-term debt:

[0000804328-23-000006:notes:31]
|  | December 25, 2022 |  | September 25, 2022 |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |  | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 5,860 |  |  | 2.66% - 5.17% |  | 2023 - 2047 |  | 5,860 |  |  | 2.68% - 4.46% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.95% - 3.30% |  | 2030 - 2050 |  | 2,000 |  |  | 2.97% - 3.30% |
| August 2020 Notes | 2028 - 2032 |  | 2,207 |  |  | 2.48% - 3.53% |  | 2028 - 2032 |  | 2,207 |  |  | 2.50% - 3.52% |
| May 2022 Notes | 2032 - 2052 |  | 1,500 |  |  | 3.14% - 4.26% |  | 2032 - 2052 |  | 1,500 |  |  | 3.13% - 4.26% |
| November 2022 Notes | 2033 - 2053 |  | 1,900 |  |  | 3.44% - 4.99% |  |  |  | — |  |  |  |
| Total principal |  |  | 17,332 |  |  |  |  |  |  | 15,432 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (258) |  |  |  |  |  |  | (241) |  |  |  |
| Hedge accounting fair value adjustments |  | (197) |  |  |  |  |  |  | (208) |  |  |  |
| Total long-term debt |  |  | $ | 16,877 |  |  |  |  |  |  | $ | 14,983 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 1,446 |  |  |  |  |  |  | $ | 1,446 |  |  |  |
| Long-term debt |  |  | 15,431 |  |  |  |  |  |  | 13,537 |  |  |  |
| Total |  |  | $ | 16,877 |  |  |  |  |  |  | $ | 14,983 |  |  |  |

[0000804328-23-000006:notes:32]
At December 25, 2022, the aggregate fair value of our outstanding floating- and fixed-rate notes, based on Level 2 inputs, was approximately $16.1 billion.

[0000804328-23-000006:notes:33]
Interest Rate Swaps. At September 25, 2022, we had outstanding forward-starting interest rate swaps with an aggregate notional amount, denominated in U.S. dollars, of $1.6 billion. During the first quarter of fiscal 2023, in connection with the issuance of the November 2022 Notes, we terminated these swaps, and the related gains of $334 million are being reclassified from accumulated comprehensive income to being recorded as a reduction to interest expense over the hedged portions of the related debt.

[0000804328-23-000006:notes:34]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. At December 25, 2022 and September 25, 2022, we had no amounts and $499 million, respectively, of outstanding commercial paper recorded as short-term debt.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-23-000006:notes:35]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0000804328-23-000006:notes:36]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions. On July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint, and on March 18, 2019, the court denied our motion. On January 15, 2020, we filed a motion for judgment on the pleadings, which the court denied on February 3, 2022. On May 23, 2022, the plaintiffs filed a motion for class certification, and a hearing on the motion was held on October 19, 2022. The court has not yet ruled on the motion. We believe the plaintiffs’ claims are without merit.

[0000804328-23-000006:notes:37]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On July 5, 2018, the plaintiffs filed a motion for class certification, and on September 27, 2018, the court granted that motion. We appealed the district court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit), and on September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class. The Ninth Circuit remanded the case to the district court and instructed the court to consider the effect of United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated (which the Ninth Circuit decided in favor of Qualcomm in August 2020) on this case. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. On August 1, 2022, we filed a motion to dismiss the amended complaint, and on November 15, 2022, the court held a hearing on our motion. On January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. The order preserved the plaintiffs’ claims related to exclusive dealing under California antitrust and unfair competition laws and dismissed the remainder of the plaintiffs’ claims, which were related to our licensing practices. We believe the plaintiffs’ claims are without merit.

[0000804328-23-000006:notes:38]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in

[0000804328-23-000006:notes:39]
these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

[0000804328-23-000006:notes:40]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit. We believe that ParkerVision’s claims are without merit.

[0000804328-23-000006:notes:41]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (ARM) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with ARM (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. The complaint seeks specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology. ARM also contends that we violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of ARM’s trademarks and seeks associated injunctive and declaratory relief. ARM further seeks exemplary or punitive damages, costs, expenses and reasonable attorney’s fees, and equitable relief addressing any infringement occurring after entry of judgment. We believe ARM’s claims are without merit.

[0000804328-23-000006:notes:42]
On September 30, 2022, we filed our Answer and Counterclaim in response to ARM’s complaint denying ARM’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and ARM and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia), server System-on-Chip (SoC) and compute SoC are fully licensed under our existing Architecture License Agreement and Technology License Agreement with ARM (the ARM-Qualcomm Agreements). We further seek an order enjoining ARM from making any claim that our products are not licensed under the ARM-Qualcomm Agreements, are not ARM-compliant or that we are prohibited from using ARM’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements ARM is making in the marketplace concerning our rights under the ARM-Qualcomm Agreements are false, and that ARM has no right to prevent us from shipping our products, which are validly licensed. Trial is scheduled to begin on September 23, 2024.

[0000804328-23-000006:notes:43]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises.

[0000804328-23-000006:notes:44]
The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0000804328-23-000006:notes:45]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019, and on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC. We believe that our business practices do not violate the MRFTA.

[0000804328-23-000006:notes:46]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of its investigation, but we believe it concerns our business practices in connection with our sale of RFFE components. We continue to cooperate with the KFTC as it conducts its investigation. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

[0000804328-23-000006:notes:47]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision finding that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. A hearing on our appeal is scheduled for March 13-15, 2023. We believe that our business practices do not violate the European Union (EU) competition rules.

[0000804328-23-000006:notes:48]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to the EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding and included in other current liabilities.

[0000804328-23-000006:notes:49]
Contingent Losses and Other Considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. Other than with respect to the EC fine related to the Icera Complaint to the European Commission, we have not recorded any accrual at December 25, 2022 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-23-000006:notes:50]
Segment InformationWe are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarities and the level of centralized resource planning within 
our operating segments, such as the nature of products, the level of shared products, technology and other resources, production processes and customer base. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies, including RFFE, for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices; industrial devices; and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our cloud AI inference processing initiative.

[0000804328-23-000006:notes:51]
Our CODM allocates resources to and evaluates the performance of our segments based on revenues and earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense, certain net investment income, certain share-based compensation, gains and losses on our deferred compensation plan liabilities and related assets and certain research and development expenses, certain selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories and property, plant and equipment to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, asset impairment charges and awards, settlements and/or damages arising from legal or regulatory matters. Our CODM does not evaluate our operating segments using discrete asset information.

[0000804328-23-000006:notes:52]
[same as prior period, unchanged from 0001728949-22-000040:notes:53]

[0000804328-23-000006:notes:53]
|  | Three Months Ended |  |  |
|  | December 25,2022 |  | December 26,2021 |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 7,892 |  |  | $ | 8,847 |  |  |  |  |  |
| QTL | 1,524 |  |  | 1,818 |  |  |  |  |  |
| QSI | 7 |  |  | 8 |  |  |  |  |  |
| Reconciling items | 40 |  |  | 32 |  |  |  |  |  |
| Total | $ | 9,463 |  |  | $ | 10,705 |  |  |  |  |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 2,183 |  |  | $ | 3,114 |  |  |  |  |  |
| QTL | 1,117 |  |  | 1,406 |  |  |  |  |  |
| QSI | (8) |  |  | 122 |  |  |  |  |  |
| Reconciling items | (921) |  |  | (777) |  |  |  |  |  |
| Total | $ | 2,371 |  |  | $ | 3,865 |  |  |  |  |  |

[0000804328-23-000006:notes:54]
[same as prior period, unchanged from 0001728949-22-000040:notes:55]

[0000804328-23-000006:notes:55]
|  | Three Months Ended |  |  |
|  | December 25,2022 |  | December 26,2021 |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 40 |  |  | $ | 32 |  |  |  |  |  |
|  | $ | 40 |  |  | $ | 32 |  |  |  |  |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of revenues | $ | (65) |  |  | $ | (53) |  |  |  |  |  |
| Unallocated research and development expenses | (522) |  |  | (453) |  |  |  |  |  |
| Unallocated selling, general and administrative expenses | (167) |  |  | (152) |  |  |  |  |  |
| Unallocated other expenses (Note 2) | (80) |  |  | — |  |  |  |  |  |
| Unallocated interest expense | (170) |  |  | (139) |  |  |  |  |  |
| Unallocated investment and other income, net | 87 |  |  | 23 |  |  |  |  |  |
| Nonreportable segments | (4) |  |  | (3) |  |  |  |  |  |
|  | $ | (921) |  |  | $ | (777) |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000804328-23-000006:notes:56]
Acquisitions 
Veoneer. On October 4, 2021, we and SSW Partners, a New York-based investment partnership, entered into a definitive agreement to acquire Veoneer, Inc. (Veoneer). The transaction closed on April 1, 2022 (the Closing Date). Total cash consideration paid in the transaction was $4.7 billion, consisting of (i) $4.6 billion paid in respect of Veoneer’s outstanding capital stock and equity awards and amounts paid to settle Veoneer’s convertible senior notes (which were converted at the election of the note holders and settled in cash in the third quarter of fiscal 2022) and (ii) a $110 million termination fee paid to Magna International Inc. (Magna) in the first quarter of fiscal 2022. We funded substantially all of the cash consideration payable in the transaction in exchange for (i) the Arriver business (which SSW transferred to us shortly after the Closing Date) and (ii) the right to receive a majority of the proceeds upon the sale of the Non-Arriver businesses by SSW Partners. We intend to incorporate Arriver’s computer vision, drive policy and driver assistance technologies into our Snapdragon automotive platform to deliver an integrated software SoC ADAS platform for automakers and Tier-1 automotive suppliers. SSW Partners retained Veoneer’s Tier-1 automotive supplier businesses, primarily consisting of the Active Safety and the Restraint Control Systems businesses (the Non-Arriver businesses), which it intends to sell in multiple transactions.

[0000804328-23-000006:notes:57]
We have agreed to provide certain funding of approximately $300 million to the Non-Arriver businesses while SSW Partners sells these businesses, of which approximately $150 million of funding remained available to the Non-Arriver businesses at December 25, 2022. Such amounts, along with cash retained in the Non-Arriver businesses, are expected to be used to fund working and other near-term capital needs, as well as certain costs incurred in connection with the close of the acquisition.

[0000804328-23-000006:notes:58]
Although we do not own or operate the Non-Arriver businesses, we have determined that we are the primary beneficiary, within the meaning of the Financial Accounting Standards Board (FASB) accounting guidance related to consolidation (ASC 810), of these businesses under the variable interest model. Factors considered in reaching this conclusion included, among others: (i) our involvement in the design of and our funding of substantially all of the total cash consideration payable in the transaction and (ii) our obligations to absorb losses and rights to receive returns from the Non-Arriver businesses.

[0000804328-23-000006:notes:59]
In December 2022, Magna entered into a definitive agreement to acquire the Active Safety business from SSW Partners for approximately $1.5 billion in cash, subject to working capital and other purchase price adjustments. The sale is subject to certain regulatory approvals and other customary closing conditions. We expect that SSW Partners will complete the sale of both Non-Arriver businesses within fiscal 2023, subject to any required regulatory approvals and other closing conditions being met. Accordingly, the assets and liabilities of the Non-Arriver businesses (the majority of which relate to the Active Safety business) are consolidated and presented as held for sale on our balance sheet, and the operating results are presented as discontinued operations.

[0000804328-23-000006:notes:60]
[same as prior period, unchanged from 0001728949-22-000040:notes:61]

[0000804328-23-000006:notes:61]
We have finalized the purchase price allocation, except for certain tax matters. Accordingly, the preliminary purchase price allocation shown below could change during the remainder of the measurement period (which will not exceed 12 months from the Closing Date). The preliminary allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0000804328-23-000006:notes:62]
| Cash | $ | 30 |  |
| Current held for sale assets, net of costs to sell (1) | 626 |
| Completed technology-based intangible assets | 349 |
| In-process research and development (IPR&D) | 298 |  |
| Goodwill | 2,789 |  |
| Noncurrent held for sale assets (1) | 1,186 |  |
| Other assets | 333 |  |
| Total assets | 5,611 |  |
| Current held for sale liabilities (1) | (677) |  |
| Convertible senior notes | (352) |  |
| Noncurrent held for sale liabilities (1) | (128) |  |
| Other liabilities | (203) |  |
| Total liabilities | (1,360) |  |
| Net assets acquired | $ | 4,251 |  |

[0000804328-23-000006:notes:63]
(1) Held for sale assets and liabilities relate to the Non-Arriver businesses and were measured at fair value less costs to sell (including SSW Partners’ estimated return with respect to the sale proceeds of the Non-Arriver businesses), which was estimated using a market approach based on significant inputs that were not observable. In the fourth quarter of fiscal 2022, we finalized and adjusted the valuation of the Non-Arriver businesses upward by $229 million and recorded an offsetting adjustment to decrease goodwill for this amount. The Non-Arriver businesses’ assets are not available to be used to settle our obligations, and the Non-Arriver businesses’ creditors do not have recourse to us. SSW Partners owns and operates the Non-Arriver businesses, and its funding of the purchase price for Veoneer was recorded as a component of held for sale liabilities. The underlying classes of assets and liabilities held for sale have not been presented because such amounts are not material.

[0000804328-23-000006:notes:64]
[same as prior period, unchanged from 0001728949-22-000040:notes:66]

[0000804328-23-000006:notes:65]
The Non-Arriver businesses are presented as discontinued operations on a one quarter reporting lag. Pro forma results of operations have not been presented because the effects of this acquisition were not material to our consolidated results of operations. The cash flows generated from (used by) the Non-Arriver businesses are reflected as discontinued operations and are classified as operating, investing and financing activities in the consolidated statements of cash flows. Investing and financing activities from discontinued operations reported in the first quarter of fiscal 2023 were not material.


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-23-000006:notes:66]
Fair Value Measurements
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at December 25, 2022 (in millions):

[0000804328-23-000006:notes:67]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 2,255 |  |  | $ | 754 |  |  | $ | — |  |  | $ | 3,009 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 3,185 |  |  | — |  |  | 3,185 |  |
| Equity securities | 139 |  |  | — |  |  | — |  |  | 139 |  |
| Mortgage- and asset-backed securities | — |  |  | 90 |  |  | — |  |  | 90 |  |
| U.S. Treasury securities and government-related securities | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total marketable securities | 139 |  |  | 3,291 |  |  | — |  |  | 3,430 |  |
| Derivative instruments | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Other investments | 697 |  |  | — |  |  | 22 |  |  | 719 |  |
| Total assets measured at fair value | $ | 3,091 |  |  | $ | 4,084 |  |  | $ | 22 |  |  | $ | 7,197 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 289 |  |  | $ | — |  |  | $ | 289 |  |
| Other liabilities | 697 |  |  | — |  |  | — |  |  | 697 |  |
| Total liabilities measured at fair value | $ | 697 |  |  | $ | 289 |  |  | $ | — |  |  | $ | 986 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000804328-23-000006:notes:68]
Marketable Securities
Our marketable securities were all classified as current and were comprised as follows (in millions):

[0000804328-23-000006:notes:69]
|  | December 25,2022 |  | September 25,2022 |  |  |  |  |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 3,185 |  |  | $ | 3,330 |  |  |  |  |  |
| Mortgage- and asset-backed securities | 90 |  |  | 99 |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 16 |  |  | 16 |  |  |  |  |  |
| Total available-for-sale debt securities | 3,291 |  |  | 3,445 |  |  |  |  |  |
| Equity securities | 139 |  |  | 164 |  |  |  |  |  |
| Total marketable securities | $ | 3,430 |  |  | $ | 3,609 |  |  |  |  |  |

[0000804328-23-000006:notes:70]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0000804328-23-000006:notes:71]
|  | December 25,2022 |
| Years to Maturity |  |
| Less than one year | $ | 1,260 |  |
| One to five years | 1,941 |  |
| No single maturity date | 90 |  |
| Total | $ | 3,291 |  |

[0000804328-23-000006:notes:72]
Debt securities with no single maturity date included mortgage- and asset-backed securities.
