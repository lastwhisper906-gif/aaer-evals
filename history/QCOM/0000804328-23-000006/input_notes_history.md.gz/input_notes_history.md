# QCOM note change history — 0001728949-22-000040 → 0000804328-23-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-02-02):
[0000804328-23-000006:note_history:1]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions. On July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint, and on March 18, 2019, the court denied our motion. On January 15, 2020, we filed a motion for judgment on the pleadings, which the court denied on February 3, 2022. On May 23, 2022, the plaintiffs filed a motion for class certification, and a hearing on the motion was held on October 19, 2022. The court has not yet ruled on the motion. We believe the plaintiffs’ claims are without merit.
  (was, 2022-07-27, similarity 0.9045):
[0001728949-22-000040:note_history:1]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions. On July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint, and on March 18, 2019, the court denied our motion. On January 15, 2020, we filed a motion for judgment on the pleadings, which the court denied on February 3, 2022. On May 23, 2022, the plaintiffs filed a motion for class certification. The court has not yet ruled on the motion, and no trial date has been set. We believe the plaintiffs’ claims are without merit.

- changed (2023-02-02):
[0000804328-23-000006:note_history:2]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On July 5, 2018, the plaintiffs filed a motion for class certification, and on September 27, 2018, the court granted that motion. We appealed the district court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit), and on September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class. The Ninth Circuit remanded the case to the district court and instructed the court to consider the effect of United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated (which the Ninth Circuit decided in favor of Qualcomm in August 2020) on this case. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. On August 1, 2022, we filed a motion to dismiss the amended complaint, and on November 15, 2022, the court held a hearing on our motion. On January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. The order preserved the plaintiffs’ claims related to exclusive dealing under California antitrust and unfair competition laws and dismissed the remainder of the plaintiffs’ claims, which were related to our licensing practices. We believe the plaintiffs’ claims are without merit.
  (was, 2022-07-27, similarity 0.8446):
[0001728949-22-000040:note_history:2]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and on September 27, 2018, the court granted that motion. We appealed the district court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit), and on September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class. The Ninth Circuit remanded the case to the district court and instructed the court to consider the effect of United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated (which the Ninth Circuit decided in favor of Qualcomm in August 2020) on this case. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. We believe the plaintiffs’ claims are without merit.

- changed (2023-02-02):
[0000804328-23-000006:note_history:3]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in
  (was, 2022-07-27, similarity 0.8513):
[0001728949-22-000040:note_history:3]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

- added (2023-02-02):
[0000804328-23-000006:note_history:4]
these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

- changed (2023-02-02):
[0000804328-23-000006:note_history:5]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit. We believe that ParkerVision’s claims are without merit.
  (was, 2022-07-27, similarity 0.9213):
[0001728949-22-000040:note_history:5]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a

- added (2023-02-02):
[0000804328-23-000006:note_history:6]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (ARM) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with ARM (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. The complaint seeks specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology. ARM also contends that we violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of ARM’s trademarks and seeks associated injunctive and declaratory relief. ARM further seeks exemplary or punitive damages, costs, expenses and reasonable attorney’s fees, and equitable relief addressing any infringement occurring after entry of judgment. We believe ARM’s claims are without merit.

- added (2023-02-02):
[0000804328-23-000006:note_history:7]
On September 30, 2022, we filed our Answer and Counterclaim in response to ARM’s complaint denying ARM’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and ARM and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia), server System-on-Chip (SoC) and compute SoC are fully licensed under our existing Architecture License Agreement and Technology License Agreement with ARM (the ARM-Qualcomm Agreements). We further seek an order enjoining ARM from making any claim that our products are not licensed under the ARM-Qualcomm Agreements, are not ARM-compliant or that we are prohibited from using ARM’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements ARM is making in the marketplace concerning our rights under the ARM-Qualcomm Agreements are false, and that ARM has no right to prevent us from shipping our products, which are validly licensed. Trial is scheduled to begin on September 23, 2024.

- changed (2023-02-02):
[0000804328-23-000006:note_history:8]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises.
  (was, 2022-07-27, similarity 0.9743):
[0001728949-22-000040:note_history:8]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

- added (2023-02-02):
[0000804328-23-000006:note_history:9]
The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

- changed (2023-02-02):
[0000804328-23-000006:note_history:10]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of its investigation, but we believe it concerns our business practices in connection with our sale of RFFE components. We continue to cooperate with the KFTC as it conducts its investigation. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.
  (was, 2022-07-27, similarity 0.9806):
[0001728949-22-000040:note_history:10]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of its investigation, but we believe it concerns our business practices in connection with our sale of radio frequency front-end (RFFE) components. We continue to cooperate with the KFTC as it conducts its investigation. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

- changed (2023-02-02):
[0000804328-23-000006:note_history:11]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision finding that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. A hearing on our appeal is scheduled for March 13-15, 2023. We believe that our business practices do not violate the European Union (EU) competition rules.
  (was, 2022-07-27, similarity 0.9459):
[0001728949-22-000040:note_history:11]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision finding that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

- changed (2023-02-02):
[0000804328-23-000006:note_history:12]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to the EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding and included in other current liabilities.
  (was, 2022-07-27, similarity 0.9204):
[0001728949-22-000040:note_history:12]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth

- changed (2023-02-02):
[0000804328-23-000006:note_history:13]
Contingent Losses and Other Considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. Other than with respect to the EC fine related to the Icera Complaint to the European Commission, we have not recorded any accrual at December 25, 2022 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.
  (was, 2022-07-27, similarity 0.9956):
[0001728949-22-000040:note_history:13]
Contingent Losses and Other Considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. Other than with respect to the EC fine related to the Icera Complaint to the European Commission, we have not recorded any accrual at June 26, 2022 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- removed (2023-02-02):
[0001728949-22-000040:note_history:14]
notice of appeal to the United States Court of Appeals for the Federal Circuit. We believe that ParkerVision’s claims are without merit.

- removed (2023-02-02):
[0001728949-22-000040:note_history:15]
quarter of fiscal 2019, we designated the liability as a hedge of our net investment in a certain foreign subsidiary, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At June 26, 2022, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other (expense) income, net), was $266 million and included in other current liabilities.

- removed (2023-02-02):
[0001728949-22-000040:note_history:16]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. From May 4, 2021 to May 6, 2021, a hearing on our appeal was held before the court. On June 15, 2022, the court issued a ruling annulling the EC’s decision in its entirety. Any appeal of the General Court’s decision must be brought before the European Court of Justice by late August 2022.

- removed (2023-02-02):
[0001728949-22-000040:note_history:17]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appealed the EC’s decision. The fine accrued interest at a rate of 1.50% per annum while it was outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. As a result of the court’s ruling, in the third quarter of fiscal 2022, we recorded a $1.1 billion benefit in other income and a $62 million reduction in interest expense resulting from the reversal of the accrued fine and the associated interest previously recorded. We also discontinued the net investment hedge related to this fine. The associated foreign currency gains will remain in accumulated other comprehensive income until the foreign subsidiaries are sold or substantially liquidated, at which point it will be reclassified into earnings.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-02-02):
[0000804328-23-000006:note_history:18]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 25, 2022. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 25, 2022 and December 26, 2021 included 13 weeks.
  (was, 2022-07-27, similarity 0.954):
[0001728949-22-000040:note_history:18]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 26, 2021. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and nine months ended June 26, 2022 and June 27, 2021 included 13 weeks and 39 weeks, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-02-02):
[0000804328-23-000006:note_history:19]
Debt
Long-term Debt. In November 2022, we issued unsecured fixed-rate notes, consisting of $700 million of fixed-rate 5.40% notes and $1.2 billion of fixed-rate 6.00% notes (collectively, November 2022 Notes) that mature on May 20, 2033 and May 20, 2053, respectively. The net proceeds from the November 2022 Notes were used to repay $946 million of fixed-rate notes and $500 million of floating-rate notes that matured in January 2023 and the excess will be used for general corporate purposes.

- changed (2023-02-02):
[0000804328-23-000006:note_history:20]
|  | December 25, 2022 |  | September 25, 2022 |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |  | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 5,860 |  |  | 2.66% - 5.17% |  | 2023 - 2047 |  | 5,860 |  |  | 2.68% - 4.46% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.95% - 3.30% |  | 2030 - 2050 |  | 2,000 |  |  | 2.97% - 3.30% |
| August 2020 Notes | 2028 - 2032 |  | 2,207 |  |  | 2.48% - 3.53% |  | 2028 - 2032 |  | 2,207 |  |  | 2.50% - 3.52% |
| May 2022 Notes | 2032 - 2052 |  | 1,500 |  |  | 3.14% - 4.26% |  | 2032 - 2052 |  | 1,500 |  |  | 3.13% - 4.26% |
| November 2022 Notes | 2033 - 2053 |  | 1,900 |  |  | 3.44% - 4.99% |  |  |  | — |  |  |  |
| Total principal |  |  | 17,332 |  |  |  |  |  |  | 15,432 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (258) |  |  |  |  |  |  | (241) |  |  |  |
| Hedge accounting fair value adjustments |  | (197) |  |  |  |  |  |  | (208) |  |  |  |
| Total long-term debt |  |  | $ | 16,877 |  |  |  |  |  |  | $ | 14,983 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 1,446 |  |  |  |  |  |  | $ | 1,446 |  |  |  |
| Long-term debt |  |  | 15,431 |  |  |  |  |  |  | 13,537 |  |  |  |
| Total |  |  | $ | 16,877 |  |  |  |  |  |  | $ | 14,983 |  |  |  |
  (was, 2022-07-27, similarity 0.9538):
[0001728949-22-000040:note_history:20]
|  | June 26, 2022 |  | September 26, 2021 |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |  | 2022 - 2045 |  | $ | 5,405 |  |  | 2.63% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 5,860 |  |  | 2.03% - 4.46% |  | 2023 - 2047 |  | 5,860 |  |  | 0.92% - 4.46% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.73% - 3.30% |  | 2030 - 2050 |  | 2,000 |  |  | 2.31% - 3.30% |
| August 2020 Notes | 2028 - 2032 |  | 2,207 |  |  | 2.32% - 3.27% |  | 2028 - 2032 |  | 2,207 |  |  | 1.98% - 2.66% |
| May 2022 Notes | 2032 - 2052 |  | 1,500 |  |  | 3.14% - 4.26% |  |  |  | — |  |  |  |
| Total principal |  |  | 15,432 |  |  |  |  |  |  | 15,472 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (249) |  |  |  |  |  |  | (234) |  |  |  |
| Hedge accounting fair value adjustments |  | (138) |  |  |  |  |  |  | 7 |  |  |  |
| Total long-term debt |  |  | $ | 15,045 |  |  |  |  |  |  | $ | 15,245 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 1,445 |  |  |  |  |  |  | $ | 1,544 |  |  |  |
| Long-term debt |  |  | 13,600 |  |  |  |  |  |  | 13,701 |  |  |  |
| Total |  |  | $ | 15,045 |  |  |  |  |  |  | $ | 15,245 |  |  |  |

- changed (2023-02-02):
[0000804328-23-000006:note_history:21]
At December 25, 2022, the aggregate fair value of our outstanding floating- and fixed-rate notes, based on Level 2 inputs, was approximately $16.1 billion.
  (was, 2022-07-27, similarity 0.9653):
[0001728949-22-000040:note_history:21]
At June 26, 2022, the aggregate fair value of our outstanding floating- and fixed-rate notes, based on Level 2 inputs, was approximately $14.6 billion.

- added (2023-02-02):
[0000804328-23-000006:note_history:22]
Interest Rate Swaps. At September 25, 2022, we had outstanding forward-starting interest rate swaps with an aggregate notional amount, denominated in U.S. dollars, of $1.6 billion. During the first quarter of fiscal 2023, in connection with the issuance of the November 2022 Notes, we terminated these swaps, and the related gains of $334 million are being reclassified from accumulated comprehensive income to being recorded as a reduction to interest expense over the hedged portions of the related debt.

- added (2023-02-02):
[0000804328-23-000006:note_history:23]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. At December 25, 2022 and September 25, 2022, we had no amounts and $499 million, respectively, of outstanding commercial paper recorded as short-term debt.

- removed (2023-02-02):
[0001728949-22-000040:note_history:24]
Debt
Long-term Debt. In May 2022, we issued unsecured fixed-rate notes, consisting of $500 million of fixed-rate 4.25% notes and $1.0 billion of fixed-rate 4.50% notes (May 2022 Notes) that mature on May 20, 2032 and May 20, 2052, respectively. The net proceeds from the May 2022 Notes, together with cash on hand, were used to repay $1.5 billion of fixed-rate notes that matured in May 2022.

- removed (2023-02-02):
[0001728949-22-000040:note_history:25]
Interest Rate Swaps. At September 26, 2021, we had outstanding forward-starting interest rate swaps with an aggregate notional amount, denominated in U.S. dollars, of $2.6 billion. During the third quarter of fiscal 2022, we terminated $1.0 billion of these swaps associated with our May 2022 Notes, and the related gains of $123 million are being reclassified from accumulated comprehensive income as a reduction to interest expense over the terms of the related debt.

- removed (2023-02-02):
[0001728949-22-000040:note_history:26]
Beginning in the second quarter of fiscal 2022, we entered into interest rate swaps that are designated as fair value hedges and allow us to effectively convert fixed-rate payments into floating-rate payments on a portion of our outstanding long-term debt. We entered into these agreements, in part, to manage interest rate risk associated with our cash equivalents and marketable securities, in addition to changes in the fair value of our outstanding debt. At June 26, 2022, the notional amount of these swaps, which are denominated in U.S. dollars and mature between 2027 and 2032, was $2.1 billion. The fair value of these swaps, which is included in other noncurrent liabilities, was $141 million at June 26, 2022. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings as interest expense in the current period.
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion. At June 26, 2022 and September 26, 2021, we had $500 million of outstanding commercial paper recorded as short-term debt.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-02-02):
[0000804328-23-000006:note_history:27]
|  | December 25,2022 |  | September 25,2022 |  |  |  |  |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 3,185 |  |  | $ | 3,330 |  |  |  |  |  |
| Mortgage- and asset-backed securities | 90 |  |  | 99 |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 16 |  |  | 16 |  |  |  |  |  |
| Total available-for-sale debt securities | 3,291 |  |  | 3,445 |  |  |  |  |  |
| Equity securities | 139 |  |  | 164 |  |  |  |  |  |
| Total marketable securities | $ | 3,430 |  |  | $ | 3,609 |  |  |  |  |  |

- changed (2023-02-02):
[0000804328-23-000006:note_history:28]
|  | December 25,2022 |
| Years to Maturity |  |
| Less than one year | $ | 1,260 |  |
| One to five years | 1,941 |  |
| No single maturity date | 90 |  |
| Total | $ | 3,291 |  |
  (was, 2022-07-27, similarity 0.9673):
[0001728949-22-000040:note_history:28]
|  | June 26,2022 |
| Years to Maturity |  |
| Less than one year | $ | 959 |  |
| One to five years | 2,859 |  |
| No single maturity date | 108 |  |
| Total | $ | 3,926 |  |

- removed (2023-02-02):
[0001728949-22-000040:note_history:29]
|  | June 26,2022 |  | September 26,2021 |  |  |  |  |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 3,802 |  |  | $ | 4,459 |  |  |  |  |  |
| Mortgage- and asset-backed securities | 108 |  |  | 147 |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 16 |  |  | 10 |  |  |  |  |  |
| Total available-for-sale debt securities | 3,926 |  |  | 4,616 |  |  |  |  |  |
| Equity securities | 246 |  |  | 682 |  |  |  |  |  |
| Total marketable securities | $ | 4,172 |  |  | $ | 5,298 |  |  |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-02):
[0000804328-23-000006:note_history:30]
|  | December 25, 2022 |  | September 25, 2022 |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |  | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 5,860 |  |  | 2.66% - 5.17% |  | 2023 - 2047 |  | 5,860 |  |  | 2.68% - 4.46% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.95% - 3.30% |  | 2030 - 2050 |  | 2,000 |  |  | 2.97% - 3.30% |
| August 2020 Notes | 2028 - 2032 |  | 2,207 |  |  | 2.48% - 3.53% |  | 2028 - 2032 |  | 2,207 |  |  | 2.50% - 3.52% |
| May 2022 Notes | 2032 - 2052 |  | 1,500 |  |  | 3.14% - 4.26% |  | 2032 - 2052 |  | 1,500 |  |  | 3.13% - 4.26% |
| November 2022 Notes | 2033 - 2053 |  | 1,900 |  |  | 3.44% - 4.99% |  |  |  | — |  |  |  |
| Total principal |  |  | 17,332 |  |  |  |  |  |  | 15,432 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (258) |  |  |  |  |  |  | (241) |  |  |  |
| Hedge accounting fair value adjustments |  | (197) |  |  |  |  |  |  | (208) |  |  |  |
| Total long-term debt |  |  | $ | 16,877 |  |  |  |  |  |  | $ | 14,983 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 1,446 |  |  |  |  |  |  | $ | 1,446 |  |  |  |
| Long-term debt |  |  | 15,431 |  |  |  |  |  |  | 13,537 |  |  |  |
| Total |  |  | $ | 16,877 |  |  |  |  |  |  | $ | 14,983 |  |  |  |
  (was, 2022-07-27, similarity 0.9538):
[0001728949-22-000040:note_history:30]
|  | June 26, 2022 |  | September 26, 2021 |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |  | 2022 - 2045 |  | $ | 5,405 |  |  | 2.63% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 5,860 |  |  | 2.03% - 4.46% |  | 2023 - 2047 |  | 5,860 |  |  | 0.92% - 4.46% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.73% - 3.30% |  | 2030 - 2050 |  | 2,000 |  |  | 2.31% - 3.30% |
| August 2020 Notes | 2028 - 2032 |  | 2,207 |  |  | 2.32% - 3.27% |  | 2028 - 2032 |  | 2,207 |  |  | 1.98% - 2.66% |
| May 2022 Notes | 2032 - 2052 |  | 1,500 |  |  | 3.14% - 4.26% |  |  |  | — |  |  |  |
| Total principal |  |  | 15,432 |  |  |  |  |  |  | 15,472 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (249) |  |  |  |  |  |  | (234) |  |  |  |
| Hedge accounting fair value adjustments |  | (138) |  |  |  |  |  |  | 7 |  |  |  |
| Total long-term debt |  |  | $ | 15,045 |  |  |  |  |  |  | $ | 15,245 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 1,445 |  |  |  |  |  |  | $ | 1,544 |  |  |  |
| Long-term debt |  |  | 13,600 |  |  |  |  |  |  | 13,701 |  |  |  |
| Total |  |  | $ | 15,045 |  |  |  |  |  |  | $ | 15,245 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-02-02):
[0000804328-23-000006:note_history:31]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | December 25,2022 |  | December 26,2021 |  |  |  |  |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 5,754 |  |  | $ | 6,989 |  |  |  |  |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 456 |  |  | 288 |  |  |  |  |  |
| IoT (3) |  |  |  |  |  |  |  |  | 1,682 |  |  | 1,570 |  |  |  |  |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 7,892 |  |  | $ | 8,847 |  |  |  |  |  |

- changed (2023-02-02):
[0000804328-23-000006:note_history:32]
(1) Includes revenues from products sold for use in mobile handsets.
  (was, 2022-07-27, similarity 0.712):
[0001728949-22-000040:note_history:32]
(1) Includes revenues from products sold for use in mobile handsets, excluding RFFE (radio frequency front-end) components.

- changed (2023-02-02):
[0000804328-23-000006:note_history:33]
(2) Includes revenues from products sold for use in automobiles, including connectivity, digital cockpit and advanced driver assistance systems (ADAS) and automated driving (AD).
  (was, 2022-07-27, similarity 0.698):
[0001728949-22-000040:note_history:33]
(3) Includes revenues from products sold for use in automobiles, including telematics, connectivity and digital cockpit.

- changed (2023-02-02):
[0000804328-23-000006:note_history:34]
(3) Primarily includes products sold for use in the following industries and applications: consumer (including computing, voice and music and extended reality (XR)), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, transportation and logistics and utilities).
  (was, 2022-07-27, similarity 0.9669):
[0001728949-22-000040:note_history:34]
(4) Primarily includes products sold for use in the following industries and applications: consumer (including computing, voice and music and XR), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, transportation and logistics and utilities).

- removed (2023-02-02):
[0001728949-22-000040:note_history:35]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  | June 26,2022 |  | June 27,2021 |  | June 26,2022 |  | June 27,2021 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,149 |  |  | $ | 3,863 |  |  | $ | 18,457 |  |  | $ | 12,144 |  |
| RFFE (2) |  |  |  |  |  |  |  |  | 1,046 |  |  | 957 |  |  | 3,338 |  |  | 2,921 |  |
| Automotive (3) |  |  |  |  |  |  |  |  | 350 |  |  | 253 |  |  | 945 |  |  | 705 |  |
| IoT (internet of things) (4) |  |  |  |  |  |  |  |  | 1,833 |  |  | 1,399 |  |  | 5,033 |  |  | 3,517 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 9,378 |  |  | $ | 6,472 |  |  | $ | 27,773 |  |  | $ | 19,287 |  |

- removed (2023-02-02):
[0001728949-22-000040:note_history:36]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in mobile handsets) and excludes radio frequency transceiver components.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-02):
[0000804328-23-000006:note_history:37]
We disaggregate our revenues by segment (Note 7), by products and services (as presented on our condensed consolidated statement of operations), and for our QCT (Qualcomm CDMA Technologies) segment, by revenue stream, which is based on the industry and application in which our products are sold (as presented below). Beginning in the first quarter of fiscal 2023, QCT RFFE (radio frequency front-end) revenues, which were previously presented as a separate revenue stream, are now included within our Handset, Automotive and internet of things (IoT) revenue streams, as applicable, based on the industry and application in which the related RFFE products are sold. Prior period information has been recast to reflect this change. RFFE revenues include revenues from the sale of 4G, 5G sub 6 and 5G millimeter wave RFFE products (a substantial portion of which relate to mobile handsets) and exclude radio frequency transceiver components. This change aligns with changes made to our internal reporting of revenues. We believe this change provides a more meaningful presentation in understanding QCT revenues going forward, as we expect RFFE revenues to correspond with trends in Handsets, Automotive and IoT (as applicable) and is more consistent with how our revenue diversification is viewed externally. In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s (Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets.
  (was, 2022-07-27, similarity 0.6096):
[0001728949-22-000040:note_history:37]
We disaggregate our revenues by segment (Note 7), by products and services (as presented on our condensed consolidated statement of operations), and for our QCT (Qualcomm CDMA Technologies) segment, by revenue stream, which is based on the industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s (Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets.
