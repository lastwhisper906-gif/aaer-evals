# QCOM MD&A — 0001728949-22-000026


## mdna

[0001728949-22-000026:mdna:1]
[same as prior period, unchanged from 0001728949-22-000012:mdna:1]

[0001728949-22-000026:mdna:2]
[same as prior period, unchanged from 0001728949-22-000012:mdna:2]

[0001728949-22-000026:mdna:3]
[same as prior period, unchanged from 0001728949-22-000012:mdna:3]

[0001728949-22-000026:mdna:4]
Second Quarter Fiscal 2022 Overview and Other Recent Events

[0001728949-22-000026:mdna:5]
Revenues for the second quarter of fiscal 2022 were $11.2 billion, an increase of 41% compared to the year ago quarter, with net income of $2.9 billion, an increase of 67% compared to the year ago quarter. Highlights from the second quarter of fiscal 2022 and other recent events included:

[0001728949-22-000026:mdna:6]
•QCT revenues increased by 52% in the second quarter of fiscal 2022 compared to the year ago quarter, primarily due to an increase in average selling prices and favorable mix toward higher-tier 5G products in handsets, along with higher IoT revenues.

[0001728949-22-000026:mdna:7]
•On October 4, 2021, we and SSW Partners entered into a definitive agreement to acquire Veoneer, Inc. (Veoneer). The transaction closed on April 1, 2022. We funded substantially all of the total cash consideration payable in the transaction, which was approximately $4.7 billion (inclusive of approximately $4.6 billion for amounts paid in respect of Veoneer’s outstanding capital stock and equity awards and amounts to be paid to settle Veoneer’s outstanding convertible senior notes due 2024; and the $110 million termination fee paid to Magna in the first quarter of fiscal 2022), in exchange for (i) the Arriver business and (ii) the right to receive a majority of the proceeds upon the sale of the Non-Arriver businesses by SSW Partners. We intend to incorporate Arriver’s computer vision, drive policy and driver assistance technologies into our Snapdragon automotive platform to deliver an integrated software SoC ADAS (advanced driver assistance systems) platform for automakers and Tier-1 automotive suppliers. SSW Partners retained Veoneer’s Tier-1 automotive supplier businesses, which it intends to sell in one or more transactions. We will consolidate the Non-Arriver businesses starting from the Closing Date until such businesses are sold by SSW Partners. Additional information related to this acquisition is included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Acquisitions.”

[0001728949-22-000026:mdna:8]
[same as prior period, unchanged from 0001728949-22-000012:mdna:9]

[0001728949-22-000026:mdna:9]
[same as prior period, unchanged from 0001728949-22-000012:mdna:10]

[0001728949-22-000026:mdna:10]
[same as prior period, unchanged from 0001728949-22-000012:mdna:11]

[0001728949-22-000026:mdna:11]
[same as prior period, unchanged from 0001728949-22-000012:mdna:12]

[0001728949-22-000026:mdna:12]
[same as prior period, unchanged from 0001728949-22-000012:mdna:13]

[0001728949-22-000026:mdna:13]
[same as prior period, unchanged from 0001728949-22-000012:mdna:14]

[0001728949-22-000026:mdna:14]
[same as prior period, unchanged from 0001728949-22-000012:mdna:15]

[0001728949-22-000026:mdna:15]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | Change |  | March 27,2022 |  | March 28,2021 |  | Change |
| Equipment and services | $ | 9,417 |  |  | $ | 6,239 |  |  | $ | 3,178 |  |  | $ | 18,098 |  |  | $ | 12,681 |  |  | $ | 5,417 |  |
| Licensing | 1,747 |  |  | 1,696 |  |  | 51 |  |  | 3,770 |  |  | 3,489 |  |  | 281 |  |
|  | $ | 11,164 |  |  | $ | 7,935 |  |  | $ | 3,229 |  |  | $ | 21,868 |  |  | $ | 16,170 |  |  | $ | 5,698 |  |

[0001728949-22-000026:mdna:16]
Second quarter 2022 vs. 2021

[0001728949-22-000026:mdna:17]
The increase in revenues in the second quarter of fiscal 2022 was primarily due to:

[0001728949-22-000026:mdna:18]
+    $3.2 billion in higher equipment and services revenues from our QCT segment

[0001728949-22-000026:mdna:19]
First six months 2022 vs. 2021

[0001728949-22-000026:mdna:20]
The increase in revenues in the first six months of fiscal 2022 was primarily due to:

[0001728949-22-000026:mdna:21]
+    $5.4 billion in higher equipment and services revenues and $158 million in higher licensing revenues from our QCT segment

[0001728949-22-000026:mdna:22]
+    $125 million in higher licensing revenues from our QTL segment

[0001728949-22-000026:mdna:23]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | Change |  | March 27,2022 |  | March 28,2021 |  | Change |
| Cost of revenues | $ | 4,648 |  |  | $ | 3,432 |  |  | $ | 1,216 |  |  | $ | 8,951 |  |  | $ | 6,921 |  |  | $ | 2,030 |  |
| Gross margin | 58 | % |  | 57 | % |  |  |  | 59 | % |  | 57 | % |  |  |

[0001728949-22-000026:mdna:24]
Second quarter and first six months 2022 vs. 2021

[0001728949-22-000026:mdna:25]
Gross margin percentage increased in the second quarter and first six months of fiscal 2022 primarily due to:

[0001728949-22-000026:mdna:26]
+    increase in QCT gross margin

[0001728949-22-000026:mdna:27]
-    decrease in higher margin QTL licensing revenues in proportion to QCT revenues

[0001728949-22-000026:mdna:28]
22

[0001728949-22-000026:mdna:29]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | Change |  | March 27,2022 |  | March 28,2021 |  | Change |
| Research and development | $ | 2,034 |  |  | $ | 1,780 |  |  | $ | 254 |  |  | $ | 3,963 |  |  | $ | 3,433 |  |  | $ | 530 |  |
| % of revenues | 18 | % |  | 22 | % |  |  |  | 18 | % |  | 21 | % |  |  |

[0001728949-22-000026:mdna:30]
Second quarter 2022 vs. 2021

[0001728949-22-000026:mdna:31]
The increase in research and development expenses in the second quarter of fiscal 2022 was primarily due to:

[0001728949-22-000026:mdna:32]
+    $233 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), primarily driven by an increase in employee-related expenses

[0001728949-22-000026:mdna:33]
+    $65 million increase in share-based compensation expense

[0001728949-22-000026:mdna:34]
-    $44 million decrease in expenses driven by revaluation of our deferred compensation plan obligation on lower relative stock market performance (which resulted in a corresponding increase in net losses on deferred compensation plan assets within investment and other income, net due to the revaluation of the related assets)

[0001728949-22-000026:mdna:35]
First six months 2022 vs. 2021

[0001728949-22-000026:mdna:36]
The increase in research and development expenses in the first six months of fiscal 2022 was primarily due to:

[0001728949-22-000026:mdna:37]
+    $430 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), primarily driven by an increase in employee-related expenses

[0001728949-22-000026:mdna:38]
+    $156 million increase in share-based compensation expense

[0001728949-22-000026:mdna:39]
-    $55 million decrease in expenses driven by revaluation of our deferred compensation plan obligation on lower relative stock market performance

[0001728949-22-000026:mdna:40]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | Change |  | March 27,2022 |  | March 28,2021 |  | Change |
| Selling, general and administrative | $ | 624 |  |  | $ | 557 |  |  | $ | 67 |  |  | $ | 1,232 |  |  | $ | 1,124 |  |  | $ | 108 |  |
| % of revenues | 6 | % |  | 7 | % |  |  |  | 6 | % |  | 7 | % |  |  |

[0001728949-22-000026:mdna:41]
Second quarter 2022 vs. 2021

[0001728949-22-000026:mdna:42]
The increase in selling, general and administrative expenses in the second quarter of fiscal 2022 was primarily due to a $27 million increase in employee-related expenses.

[0001728949-22-000026:mdna:43]
First six months 2022 vs. 2021

[0001728949-22-000026:mdna:44]
The increase in selling, general and administrative expenses in the first six months of fiscal 2022 was primarily due to:

[0001728949-22-000026:mdna:45]
+    $91 million increase in employee-related expenses

[0001728949-22-000026:mdna:46]
+    $27 million increase in acquisition-related expenses

[0001728949-22-000026:mdna:47]
+    $23 million increase in sales and marketing expenses

[0001728949-22-000026:mdna:48]
-    $50 million decrease in expenses driven by revaluation of our deferred compensation plan obligation on lower relative stock market performance

[0001728949-22-000026:mdna:49]
23

[0001728949-22-000026:mdna:50]
| Interest Expense and Investment and Other (Expense) Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | Change |  | March 27,2022 |  | March 28,2021 |  | Change |
| Interest expense | $ | 137 |  |  | $ | 141 |  |  | $ | (4) |  |  | $ | 275 |  |  | $ | 283 |  |  | $ | (8) |  |
| Investment and other (expense) income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 20 |  |  | $ | 22 |  |  | $ | (2) |  |  | $ | 37 |  |  | $ | 42 |  |  | $ | (5) |  |
| Net (losses) gains on marketable securities | (240) |  |  | (85) |  |  | (155) |  |  | (223) |  |  | 33 |  |  | (256) |  |
| Net (losses) gains on other investments | (21) |  |  | 176 |  |  | (197) |  |  | 73 |  |  | 209 |  |  | (136) |  |
| Net (losses) gains on deferred compensation plan assets | (43) |  |  | 23 |  |  | (66) |  |  | (30) |  |  | 77 |  |  | (107) |  |
| Impairment losses on other investments | (20) |  |  | (15) |  |  | (5) |  |  | (21) |  |  | (16) |  |  | (5) |  |
| Net losses on derivative instruments | (5) |  |  | (17) |  |  | 12 |  |  | (19) |  |  | (7) |  |  | (12) |  |
| Equity in net earnings of investees | 10 |  |  | 12 |  |  | (2) |  |  | 17 |  |  | 11 |  |  | 6 |  |
| Net gains (losses) on foreign currency transactions | 1 |  |  | (12) |  |  | 13 |  |  | 8 |  |  | (26) |  |  | 34 |  |
|  | $ | (298) |  |  | $ | 104 |  |  | $ | (402) |  |  | $ | (158) |  |  | $ | 323 |  |  | $ | (481) |  |

[0001728949-22-000026:mdna:51]
Net losses on marketable securities for the three and six months ended March 27, 2022 was primarily driven by the change in fair value of certain of our QSI marketable equity investments in early or growth stage companies. The fair values of these investments have been and may continue to be subject to increased volatility. Net gains on other investments for the three and six months ended March 28, 2021 was driven primarily by realized gains resulting from the sale of certain of our QSI non-marketable investments.

[0001728949-22-000026:mdna:52]
[same as prior period, unchanged from 0001728949-22-000012:mdna:37]

[0001728949-22-000026:mdna:53]
[same as prior period, unchanged from 0001728949-22-000012:mdna:38]

[0001728949-22-000026:mdna:54]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | March 27,2022 |  | March 28,2021 |
| Expected income tax provision at federal statutory tax rate | $ | 719 |  |  | $ | 447 |  |  | $ | 1,531 |  |  | $ | 994 |  |
| Benefit from foreign-derived intangible income (FDII) deduction | (203) |  |  | (115) |  |  | (344) |  |  | (189) |  |
| Excess tax benefit associated with share-based awards | (27) |  |  | (22) |  |  | (215) |  |  | (184) |  |
| Benefit related to the research and development tax credit | (46) |  |  | (39) |  |  | (104) |  |  | (98) |  |
| Foreign currency losses (gains) related to foreign withholding tax receivable | 36 |  |  | 33 |  |  | 48 |  |  | (46) |  |
| Audit settlement with Internal Revenue Service | — |  |  | 55 |  |  | — |  |  | 55 |  |
| Other | 10 |  |  | 8 |  |  | 40 |  |  | (17) |  |
| Income tax expense | $ | 489 |  |  | $ | 367 |  |  | $ | 956 |  |  | $ | 515 |  |
| Effective tax rate | 14 | % |  | 17 | % |  | 13 | % |  | 11 | % |

[0001728949-22-000026:mdna:55]
[same as prior period, unchanged from 0001728949-22-000012:mdna:40]

[0001728949-22-000026:mdna:56]
24

[0001728949-22-000026:mdna:57]
Pursuant to U.S. tax law, beginning in fiscal 2023, we are required to capitalize and amortize domestic research and development expenditures over five years and foreign research and development expenditures over fifteen years (currently, such expenditures are deducted as incurred). If this requirement is not delayed or repealed, our cash flows from operations will be adversely affected due to significantly higher cash tax payments. However, since the resulting deferred tax asset will be established at the statutory rate of 21% (rather than the effective tax rate of 13% to 16% after considering FDII), capitalization will favorably affect our provision for income taxes and results of operations. The adverse cash flow impact and favorable tax provision impact will diminish in future years as capitalized research and development expenditures continue to amortize.

[0001728949-22-000026:mdna:58]
The current U.S. presidential administration and Congress have proposed to increase U.S. tax rates, including reducing the benefit of the FDII deduction. Substantially all of our income is taxable in the U.S., of which a significant portion qualifies for preferential treatment as FDII. If such proposals are enacted into law, our provision for income taxes, results of operations and cash flows would be adversely (potentially materially) affected.

[0001728949-22-000026:mdna:59]
[same as prior period, unchanged from 0001728949-22-000012:mdna:42]

[0001728949-22-000026:mdna:60]
The following should be read in conjunction with our financial results for the second quarter of fiscal 2022 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0001728949-22-000026:mdna:61]
[same as prior period, unchanged from 0001728949-22-000012:mdna:44]

[0001728949-22-000026:mdna:62]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | Change |  | March 27,2022 |  | March 28,2021 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets (1) | $ | 6,325 |  |  | $ | 4,065 |  |  | $ | 2,260 |  |  | $ | 12,307 |  |  | $ | 8,281 |  |  | $ | 4,026 |  |
| RFFE (2) | 1,160 |  |  | 903 |  |  | 257 |  |  | 2,292 |  |  | 1,964 |  |  | 328 |  |
| Automotive (3) | 339 |  |  | 240 |  |  | 99 |  |  | 595 |  |  | 452 |  |  | 143 |  |
| IoT (internet of things) (4) | 1,724 |  |  | 1,073 |  |  | 651 |  |  | 3,201 |  |  | 2,117 |  |  | 1,084 |  |
| Total revenues | $ | 9,548 |  |  | $ | 6,281 |  |  | $ | 3,267 |  |  | $ | 18,395 |  |  | $ | 12,814 |  |  | $ | 5,581 |  |
| EBT (5) | $ | 3,340 |  |  | $ | 1,584 |  |  | $ | 1,756 |  |  | $ | 6,455 |  |  | $ | 3,503 |  |  | $ | 2,952 |  |
| EBT as a % of revenues | 35 | % |  | 25 | % |  | 10 points |  | 35 | % |  | 27 | % |  | 8 points |

[0001728949-22-000026:mdna:63]
[same as prior period, unchanged from 0001728949-22-000012:mdna:46]

[0001728949-22-000026:mdna:64]
[same as prior period, unchanged from 0001728949-22-000012:mdna:47]

[0001728949-22-000026:mdna:65]
[same as prior period, unchanged from 0001728949-22-000012:mdna:48]

[0001728949-22-000026:mdna:66]
[same as prior period, unchanged from 0001728949-22-000012:mdna:49]

[0001728949-22-000026:mdna:67]
[same as prior period, unchanged from 0001728949-22-000012:mdna:50]

[0001728949-22-000026:mdna:68]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $9.4 billion and $6.2 billion in the second quarter of fiscal 2022 and 2021, respectively, and $18.0 billion and $12.6 billion in the first six months of fiscal 2022 and 2021, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets.

[0001728949-22-000026:mdna:69]
Second quarter 2022 vs. 2021

[0001728949-22-000026:mdna:70]
The increase in QCT revenues in the second quarter of fiscal 2022 was primarily due to:

[0001728949-22-000026:mdna:71]
+    higher handsets revenues, primarily driven by $2.0 billion in higher revenues per chipset, which was primarily due to increases in average selling prices and favorable mix toward higher-tier 5G products, particularly from major OEMs as we gained additional share

[0001728949-22-000026:mdna:72]
[same as prior period, unchanged from 0001728949-22-000012:mdna:56]

[0001728949-22-000026:mdna:73]
[same as prior period, unchanged from 0001728949-22-000012:mdna:57]

[0001728949-22-000026:mdna:74]
+    higher IoT revenues across consumer, edge networking and industrial products, driven by a $373 million increase in demand, with the remaining increase of $278 million primarily due to favorable mix

[0001728949-22-000026:mdna:75]
25

[0001728949-22-000026:mdna:76]
QCT EBT as a percentage of revenues increased in the second quarter of fiscal 2022 primarily due to:

[0001728949-22-000026:mdna:77]
[same as prior period, unchanged from 0001728949-22-000012:mdna:60]

[0001728949-22-000026:mdna:78]
+    higher gross margin percentage, primarily driven by higher average selling prices and favorable mix toward higher-tier 5G products, partially offset by higher product costs

[0001728949-22-000026:mdna:79]
[same as prior period, unchanged from 0001728949-22-000012:mdna:62]

[0001728949-22-000026:mdna:80]
First six months 2022 vs. 2021

[0001728949-22-000026:mdna:81]
The increase in QCT revenues in the first six months of fiscal 2022 was primarily due to:

[0001728949-22-000026:mdna:82]
+    higher handsets revenues, primarily driven by $3.9 billion in higher revenues per chipset, which was primarily due to increases in average selling prices and favorable mix toward higher-tier 5G products, particularly from major OEMs as we gained additional share

[0001728949-22-000026:mdna:83]
+    higher RFFE revenues, primarily driven by an increase in demand for 4G/5G products from major OEMs

[0001728949-22-000026:mdna:84]
+    higher automotive revenues, primarily driven by an increase in demand for digital cockpit products

[0001728949-22-000026:mdna:85]
+    higher IoT revenues across consumer, edge networking and industrial products, driven by a $554 million increase in demand, with the remaining increase of $530 million primarily due to favorable mix

[0001728949-22-000026:mdna:86]
QCT EBT as a percentage of revenues increased in the first six months of fiscal 2022 primarily due to:

[0001728949-22-000026:mdna:87]
[same as prior period, unchanged from 0001728949-22-000012:mdna:68]

[0001728949-22-000026:mdna:88]
+    higher gross margin percentage, primarily driven by higher average selling prices and favorable mix toward higher-tier 5G products, partially offset by higher product costs

[0001728949-22-000026:mdna:89]
-    higher operating expenses, primarily driven by higher research and development expenses

[0001728949-22-000026:mdna:90]
[same as prior period, unchanged from 0001728949-22-000012:mdna:63]

[0001728949-22-000026:mdna:91]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | Change |  | March 27,2022 |  | March 28,2021 |  | Change |
| Licensing revenues | $ | 1,580 |  |  | $ | 1,614 |  |  | $ | (34) |  |  | $ | 3,398 |  |  | $ | 3,273 |  |  | $ | 125 |  |
| EBT | 1,154 |  |  | 1,191 |  |  | (37) |  |  | 2,560 |  |  | 2,461 |  |  | 99 |  |
| EBT as a % of revenues | 73 | % |  | 74 | % |  | -1 point |  | 75 | % |  | 75 | % |  | — |

[0001728949-22-000026:mdna:92]
Second quarter 2022 vs. 2021

[0001728949-22-000026:mdna:93]
The decrease in QTL licensing revenues in the second quarter of fiscal 2022 was due to:

[0001728949-22-000026:mdna:94]
-    $91 million decrease in estimated sales of 3G/4G/5G-based multimode products

[0001728949-22-000026:mdna:95]
-    $31 million in lower royalty revenues recognized related to devices sold in prior periods

[0001728949-22-000026:mdna:96]
+    $88 million increase in estimated revenues per unit, which was primarily driven by favorable mix, including 5G

[0001728949-22-000026:mdna:97]
QTL EBT as a percentage of revenues decreased in the second quarter of fiscal 2022 primarily due to lower revenues.

[0001728949-22-000026:mdna:98]
First six months 2022 vs. 2021

[0001728949-22-000026:mdna:99]
The increase in QTL licensing revenues in the first six months of fiscal 2022 was primarily due to:

[0001728949-22-000026:mdna:100]
+    $197 million increase in estimated revenues per unit, which was primarily driven by favorable mix, including 5G

[0001728949-22-000026:mdna:101]
-    $66 million decrease in estimated sales of 3G/4G/5G-based multimode products

[0001728949-22-000026:mdna:102]
QTL EBT as a percentage of revenues remained flat in the first six months of fiscal 2022.

[0001728949-22-000026:mdna:103]
[same as prior period, unchanged from 0001728949-22-000012:mdna:70]

[0001728949-22-000026:mdna:104]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | Change |  | March 27,2022 |  | March 28,2021 |  | Change |
| Equipment and services revenues | $ | 6 |  |  | $ | 10 |  |  | $ | (4) |  |  | $ | 14 |  |  | $ | 19 |  |  | $ | (5) |  |
| EBT | (269) |  |  | 98 |  |  | (367) |  |  | (147) |  |  | 256 |  |  | (403) |  |

[0001728949-22-000026:mdna:105]
Second quarter and first six months 2022 vs. 2021

[0001728949-22-000026:mdna:106]
The decrease in QSI EBT in the second quarter and first six months of fiscal 2022 was primarily due to a $353 million and $389 million increase, respectively, in net losses on investments, which was primarily driven by the change in fair value of certain of our marketable equity investments in early or growth stage companies. The fair values of these investments have been and may continue to be subject to increased volatility.

[0001728949-22-000026:mdna:107]
[same as prior period, unchanged from 0001728949-22-000012:mdna:74]

[0001728949-22-000026:mdna:108]
[same as prior period, unchanged from 0001728949-22-000012:mdna:75]

[0001728949-22-000026:mdna:109]
[same as prior period, unchanged from 0001728949-22-000012:mdna:76]

[0001728949-22-000026:mdna:110]
•We expect QCT revenues to continue to be favorably impacted for the remainder of the fiscal year compared to the prior year, reflecting continued strength across handsets, RFFE, automotive and IoT revenue streams.

[0001728949-22-000026:mdna:111]
•While we and the semiconductor industry continue to experience capacity constraints, we have entered into several, and we may enter into additional, multi-year capacity purchase commitments with certain suppliers of our integrated circuit products in an effort to secure commitments for future supply, which we expect will allow us to continue to realize benefits from increased demand for integrated circuit products, particularly from higher-tier 5G products from major OEMs. Despite these realized benefits, there continues to be supply chain complexities and challenges that have prevented, and we expect will continue to prevent, us from securing supply to fully realize the benefits of increased customer demand.

[0001728949-22-000026:mdna:112]
[same as prior period, unchanged from 0001728949-22-000012:mdna:79]

[0001728949-22-000026:mdna:113]
[same as prior period, unchanged from 0001728949-22-000012:mdna:80]

[0001728949-22-000026:mdna:114]
[same as prior period, unchanged from 0001728949-22-000012:mdna:81]

[0001728949-22-000026:mdna:115]
[same as prior period, unchanged from 0001728949-22-000012:mdna:82]

[0001728949-22-000026:mdna:116]
The degree to which the COVID-19 pandemic impacts our business, financial condition and results of operations will depend on future developments, which are highly uncertain. See “Risk Factors” in this Quarterly Report, specifically the Risk Factor titled “The coronavirus (COVID-19) pandemic had an adverse effect on our business and results of operations, and may continue to impact us in the future.”

[0001728949-22-000026:mdna:117]
Further, we currently do not expect a significant impact on our results of operations in the future due to Russia’s invasion of Ukraine, as we have minimal business in Russia and Ukraine, both directly and indirectly. See “Risk Factors” in this Quarterly Report, specifically the Risk Factor titled “We operate in the highly cyclical semiconductor industry, which is subject to significant downturns. We are also susceptible to declines in global, regional and local economic conditions generally. Our stock price and financial results are subject to substantial quarterly and annual fluctuations due to these dynamics, among others.”

[0001728949-22-000026:mdna:118]
[same as prior period, unchanged from 0001728949-22-000012:mdna:84]

[0001728949-22-000026:mdna:119]
[same as prior period, unchanged from 0001728949-22-000012:mdna:85]

[0001728949-22-000026:mdna:120]
27

[0001728949-22-000026:mdna:121]
[same as prior period, unchanged from 0001728949-22-000012:mdna:86]

[0001728949-22-000026:mdna:122]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at March 27, 2022 and September 26, 2021 and for the first six months of fiscal 2022 and 2021 (in millions):

[0001728949-22-000026:mdna:123]
|  | March 27,2022 |  | September 26,2021 |  | Change |  |  |
| Cash and cash equivalents | $ | 7,173 |  |  | $ | 7,116 |  |  | $ | 57 |  |  |  |
| Marketable securities | 4,373 |  |  | 5,298 |  |  | (925) |  |  |  |
| Cash, cash equivalents and marketable securities | $ | 11,546 |  |  | $ | 12,414 |  |  | $ | (868) |  |  |  |

[0001728949-22-000026:mdna:124]
|  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | Change |  |  |
| Net cash provided by operating activities | $ | 4,755 |  |  | $ | 6,086 |  |  | $ | (1,331) |  |  |  |
| Net cash used by investing activities | (638) |  |  | (3,034) |  |  | 2,396 |  |  |  |
| Net cash used by financing activities | (4,044) |  |  | (3,788) |  |  | (256) |  |  |  |

[0001728949-22-000026:mdna:125]
Cash, cash equivalents and marketable securities. The net decrease in cash, cash equivalents and marketable securities was primarily due to $2.1 billion in payments to repurchase shares of our common stock, $1.5 billion in cash dividends paid, $1.1 billion in capital expenditures, $562 million in payments of tax withholdings related to the vesting of share-based awards and $288 million in cash paid for acquisitions and other investments. This was partially offset by net cash provided by operating activities, which was negatively impacted by advanced payments of $1.6 billion made to suppliers of our integrated circuit products under certain multi-year capacity commitments, as well as $1.6 billion of net changes in other operating assets and liabilities, consisting of increased working capital requirements, including higher inventory and related operating liabilities to support QCT demand, an increase in accounts receivable as a result of higher revenues (net of an increase in amounts accrued for customer incentive arrangements recorded as a reduction to accounts receivable) and the timing of payments related to payroll, benefits and other liabilities. We currently expect our working capital requirements to increase in the near term to support QCT demand.

[0001728949-22-000026:mdna:126]
Capital Return Program. On October 12, 2021, we announced a new $10.0 billion stock repurchase program. This was in addition to the then remaining authority of $0.9 billion under the previous program. The stock repurchase programs have no expiration date. During the second quarter of fiscal 2022, we utilized the remaining repurchase authority under the previous program and began repurchases under the new program. In the first six months of fiscal 2022, we repurchased and retired 14 million shares of our common stock for $2.1 billion, before commissions. At March 27, 2022, $9.1 billion remained authorized for repurchase under our stock repurchase program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-22-000026:mdna:127]
On March 9, 2022, we announced a 10% increase in our quarterly dividend per share of common stock from $0.68 to $0.75, which is effective for dividends payable after March 24, 2022. In the first six months of fiscal 2022, we paid cash dividends totaling $1.5 billion, or $1.36 per share. On April 13, 2022, we announced a cash dividend of $0.75 per share on our common stock, payable on June 23, 2022 to stockholders of record as of the close of business on June 2, 2022. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-22-000026:mdna:128]
Debt. At March 27, 2022, we had $15.5 billion of principal floating- and fixed-rate notes outstanding, $1.5 billion of which matures in May 2022 and $1.5 billion of which matures in January 2023. The remaining debt has maturity dates in 2024 through 2050. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At March 27, 2022, we had $500 million of commercial paper outstanding. We also have a Revolving Credit Facility, which provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At March 27, 2022, no amounts were outstanding under the Revolving Credit Facility. We expect to issue debt in the future. The amount and timing of such debt will depend on a number of factors, including but not limited to maturities of our existing debt, acquisitions and strategic investments, favorable and/or acceptable interest rates and changes in corporate income tax law. Additional information regarding our outstanding debt is provided in “Notes to Consolidated Financial Statements, Note 6. Debt” in our 2021 Annual Report on Form 10-K and in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items.”

[0001728949-22-000026:mdna:129]
[same as prior period, unchanged from 0001728949-22-000012:mdna:109]

[0001728949-22-000026:mdna:130]
Income Taxes. Pursuant to U.S. tax law, beginning in fiscal 2023, we are required to capitalize and amortize domestic research and development expenditures over five years and foreign research and development expenditures over fifteen years (currently, such expenditures are deducted as incurred). If this requirement is not delayed or repealed, our cash flows from operations will be adversely affected due to significantly higher cash tax payments. Additional information regarding our income taxes is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes.”

[0001728949-22-000026:mdna:131]
Acquisitions. In October 2021, we and SSW Partners entered into a definitive agreement to acquire Veoneer. The transaction closed on April 1, 2022, and we funded substantially all of the total cash consideration of approximately $4.7 billion (inclusive of approximately $4.6 billion for amounts paid in respect of Veoneer’s outstanding capital stock and equity awards and amounts to be paid to settle Veoneer’s outstanding convertible senior notes due 2024; and the $110 million termination fee paid to Magna in the first quarter of fiscal 2022). We have the right to receive a majority of the proceeds upon the sale of the Non-Arriver businesses by SSW Partners, and we have agreed to provide certain funding of approximately $300 million to the Non-Arriver businesses while SSW Partners seeks a buyer(s). Additional information related to this acquisition is included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Acquisitions.” We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly, to open new opportunities for our technologies, obtain development resources, grow our patent portfolio or pursue new businesses.

[0001728949-22-000026:mdna:132]
Long-term Capacity Commitments. We have entered into several, and we may enter into additional, multi-year capacity purchase commitments with certain suppliers of our integrated circuit products. In the first six months of fiscal 2022, we made $1.6 billion in advance payments related to certain obligations under these purchase agreements, which were included within other assets and other current assets at March 27, 2022. Additional information regarding long-term capacity commitments and other purchase obligations is provided in “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies” in our 2021 Annual Report on Form 10-K.

[0001728949-22-000026:mdna:133]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2021 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At March 27, 2022, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2021 Annual Report on Form 10-K.

[0001728949-22-000026:mdna:134]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0001728949-22-000026:mdna:135]
[same as prior period, unchanged from 0001728949-22-000012:mdna:100]

[0001728949-22-000026:mdna:136]
[same as prior period, unchanged from 0001728949-22-000012:mdna:101]

[0001728949-22-000026:mdna:137]
[same as prior period, unchanged from 0001728949-22-000012:mdna:102]

[0001728949-22-000026:mdna:138]
[same as prior period, unchanged from 0001728949-22-000012:mdna:103]

[0001728949-22-000026:mdna:139]
[same as prior period, unchanged from 0001728949-22-000012:mdna:104]

[0001728949-22-000026:mdna:140]
The rapid, global spread of COVID-19 and the fear it created resulted in significant economic uncertainty, significant declines in business and consumer confidence and global demand in the wireless industry (among others) and a global economic slowdown, which negatively affected our financial results over certain periods. Specifically, throughout most of calendar 2020 and into early calendar 2021, the decline in demand for smartphones and other consumer devices sold by our customers or licensees resulted in decreased demand for our integrated circuit products (which are incorporated into such devices) and a decrease in the royalties we earned on the licensing of our intellectual property (which is dependent upon the number of such devices sold that utilize our intellectual property). The emergence and spread of new variants of COVID-19, and spikes in COVID-19 cases in various geographic regions, continues to create uncertainty as to when and to what extent normal business, economic and social activity and conditions will resume.

[0001728949-22-000026:mdna:141]
The COVID-19 pandemic also caused us to modify our workforce practices, such as having the vast majority of our employees work from home. We are beginning to open our offices globally, and we intend to operate in a “hybrid” working environment. We could be negatively affected in the future if, among others, a significant number of our employees, or employees who perform critical functions, become ill and/or are quarantined as the result of exposure to COVID-19, or if government policies restrict the ability of those employees to perform their critical functions. Further, our efforts to reopen our offices safely may not be successful, could expose our employees, customers, licensees and partners to health risks and us to associated liability, and could result in disruptions among our employees. See also the Risk Factor titled “We may not be able to attract and retain qualified employees, and our attempts to fully reopen our offices and operate under a hybrid working environment may not be successful.”

[0001728949-22-000026:mdna:142]
The COVID-19 pandemic could impact our business, results of operations and financial condition in the future as described above, and/or through delayed, reduced or cancelled customer orders; disruptions or delays in our supply chain; the inability of our customers or licensees to purchase or pay for our products or technologies; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our customers or licensees; or failures by other counterparties. The degree to which the COVID-19 pandemic impacts our future business, results of operations and financial condition will depend on future developments, which are uncertain, including but not limited to the duration of the pandemic; spikes in COVID-19 cases in various geographic regions; the emergence, spread and severity of new variants of COVID-19; the availability, adoption and efficacy of vaccines or other medical treatments for COVID-19; and government responses and other actions to limit the spread of COVID-19 or to mitigate the negative economic effects of the pandemic (including potential increases in corporate tax rates or other tax obligations to pay for stimulus and other actions that have been and may in the future be taken as a result of the pandemic). We are similarly unable to predict the extent to which the pandemic impacts our customers, licensees, suppliers and other partners and their financial conditions, but adverse effects on these parties could also adversely affect us. For example, in response to the rising COVID-19 infections, China has imposed lockdowns in certain parts of the country, which may negatively impact manufacturing and/or supply chains, as well as consumer demand for devices incorporating our products. Finally, the COVID-19 pandemic may make it harder for management to estimate the future performance of our business. To the extent the COVID-19 pandemic adversely affects our business, results of operations and financial condition, it may also have the effect of exacerbating the other risks discussed in this “Risk Factors” section.

[0001728949-22-000026:mdna:143]
[same as prior period, unchanged from 0001728949-22-000012:mdna:111]

[0001728949-22-000026:mdna:144]
[same as prior period, unchanged from 0001728949-22-000012:mdna:112]

[0001728949-22-000026:mdna:145]
[same as prior period, unchanged from 0001728949-22-000012:mdna:113]

[0001728949-22-000026:mdna:146]
In addition, a number of our largest integrated circuit customers have developed, are developing or may develop their own integrated circuit products, or may choose our competitors’ integrated circuit products, which they have in the past utilized, currently utilize and may in the future utilize in some (or all) of their devices, rather than our products, which could

[0001728949-22-000026:mdna:147]
significantly reduce the revenues we derive from these customers. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0001728949-22-000026:mdna:148]
[same as prior period, unchanged from 0001728949-22-000012:mdna:115]

[0001728949-22-000026:mdna:149]
[same as prior period, unchanged from 0001728949-22-000012:mdna:116]

[0001728949-22-000026:mdna:150]
The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or the cancellation of significant purchases by any of these customers, whether due to the use of their own integrated circuit products or our competitors’ integrated circuit products, government restrictions, a decline in global, regional or local economic conditions or otherwise, would reduce our revenues and could harm our ability to achieve or sustain expected results of operations, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0001728949-22-000026:mdna:151]
[same as prior period, unchanged from 0001728949-22-000012:mdna:118]

[0001728949-22-000026:mdna:152]
[same as prior period, unchanged from 0001728949-22-000012:mdna:119]

[0001728949-22-000026:mdna:153]
Our industry has also experienced slowing growth in the premium-tier device segment due to, among other factors, a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and innovation cycles. A reduction in sales of premium-tier devices, a reduction in sales of our premium-tier integrated circuit products (which have a higher revenue and margin contribution than our lower-tier integrated circuit products), or a shift in share away from OEMs that utilize our premium-tier products, would reduce our revenues and margins and may harm our ability to achieve or sustain expected financial results. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0001728949-22-000026:mdna:154]
[same as prior period, unchanged from 0001728949-22-000012:mdna:124]

[0001728949-22-000026:mdna:155]
[same as prior period, unchanged from 0001728949-22-000012:mdna:125]

[0001728949-22-000026:mdna:156]
[same as prior period, unchanged from 0001728949-22-000012:mdna:126]

[0001728949-22-000026:mdna:157]
[same as prior period, unchanged from 0001728949-22-000012:mdna:127]

[0001728949-22-000026:mdna:158]
[same as prior period, unchanged from 0001728949-22-000012:mdna:128]

[0001728949-22-000026:mdna:159]
[same as prior period, unchanged from 0001728949-22-000012:mdna:129]

[0001728949-22-000026:mdna:160]
[same as prior period, unchanged from 0001728949-22-000012:mdna:130]

[0001728949-22-000026:mdna:161]
[same as prior period, unchanged from 0001728949-22-000012:mdna:131]

[0001728949-22-000026:mdna:162]
[same as prior period, unchanged from 0001728949-22-000012:mdna:132]

[0001728949-22-000026:mdna:163]
[same as prior period, unchanged from 0001728949-22-000012:mdna:133]

[0001728949-22-000026:mdna:164]
Due to various factors, including pressure, encouragement or incentives from, or policies of, the Chinese government (including its Made in China 2025 campaign), concerns over losing access to our integrated circuit products as a result of actual, threatened or potential U.S. or Chinese government actions or policies, including trade protection or national security policies, or other reasons, some of our Chinese integrated circuit customers have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products in their devices, or use our competitors’ integrated circuit products in their devices, rather than our products, which could materially harm our business, revenues, results of operations, cash flows and financial position. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0001728949-22-000026:mdna:165]
Political actions, including trade protection and national security policies of the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our Chinese customers or suppliers, limit, prevent or discourage certain of our Chinese customers or suppliers from transacting business with us, or make it more expensive to do so. Given our revenue concentration in China, if, due to actual, threatened or potential U.S. or Chinese government actions or policies: we were further limited in, or prohibited from, selling our integrated circuit products to Chinese OEMs; our non-Chinese OEM customers were limited in, or prohibited from, selling devices into China that incorporate our integrated circuit products; Chinese OEMs develop and use their own integrated circuit products or use our competitors’ integrated circuit products in some (or all) of their devices rather than our integrated circuit products; Chinese tariffs on our integrated circuit products or on devices which incorporate our integrated circuit products made purchasing such products or devices more expensive to Chinese OEMs or Chinese consumers; or our Chinese licensees delay or cease making payments of license fees they owe us,

[0001728949-22-000026:mdna:166]
our business, revenues, results of operations, cash flows and financial position could be materially harmed. Similarly, if, due to U.S. or Chinese government actions or policies, we were limited in or prohibited from obtaining critical integrated circuit products from our suppliers in China, our business, revenues, results of operations, cash flows and financial position could be materially harmed. See also the Risk Factor titled “We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected.”

[0001728949-22-000026:mdna:167]
[same as prior period, unchanged from 0001728949-22-000012:mdna:137]

[0001728949-22-000026:mdna:168]
[same as prior period, unchanged from 0001728949-22-000012:mdna:138]

[0001728949-22-000026:mdna:169]
[same as prior period, unchanged from 0001728949-22-000012:mdna:139]

[0001728949-22-000026:mdna:170]
[same as prior period, unchanged from 0001728949-22-000012:mdna:140]

[0001728949-22-000026:mdna:171]
[same as prior period, unchanged from 0001728949-22-000012:mdna:141]

[0001728949-22-000026:mdna:172]
However, our research, development and other investments in these new and expanded product areas, industries and applications, and corresponding technologies and products, as well as in our existing technologies and products and new technologies in mobile handsets, may not succeed because, among other reasons: we may not be issued patents on the technologies we develop; the technologies we develop may not be incorporated into relevant standards; new and expanded product areas, industries and applications beyond mobile handsets, and consumer demand therein, may not develop or grow as anticipated; we may be unable to attract or retain employees with the necessary skills in such new and expanded product areas, industries and applications; our strategies or the strategies of our customers, licensees or partners may not be successful; alternate technologies or products may be better or may reduce the advantages we anticipate from our investments; competitors’ technologies or products may be more cost effective, have more capabilities or fewer limitations or be brought to market faster than our new technologies or products; we may not be able to develop, or our competitors may have more established and/or stronger, customer, vendor, distributor or other channel relationships; and competitors may have longer operating histories in industries and applications that are new to us. We may also underestimate the costs of, or overestimate the future revenues or margins that could result from, these investments, and these investments may not, or may take many years to, generate material returns.

[0001728949-22-000026:mdna:173]
[same as prior period, unchanged from 0001728949-22-000012:mdna:144]

[0001728949-22-000026:mdna:174]
[same as prior period, unchanged from 0001728949-22-000012:mdna:145]

[0001728949-22-000026:mdna:175]
[same as prior period, unchanged from 0001728949-22-000012:mdna:146]

[0001728949-22-000026:mdna:176]
33

[0001728949-22-000026:mdna:177]
[same as prior period, unchanged from 0001728949-22-000012:mdna:147]

[0001728949-22-000026:mdna:178]
We engage in acquisitions and other strategic transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. We routinely acquire businesses and other assets, including patents, technology and other intangible assets, enter into joint ventures or other strategic transactions, and purchase minority equity interests in or make loans to companies, including those that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our products and technologies and supporting the design and introduction of new products (or enhancing existing products) for mobile handsets, and for new industries and applications beyond mobile handsets. Many of our strategic activities entail a high degree of risk and require the use of significant amounts of capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not be successful, generate financial returns or result in increased adoption or continued use of our technologies or products. We may underestimate the costs or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership or variable interests. In addition, we have in the past recorded, and may in the future record, impairment or other charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our results of operations and financial condition, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001728949-22-000026:mdna:179]
Achieving the anticipated benefits of business acquisitions depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models, geographic regions, industries and applications served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0001728949-22-000026:mdna:180]
[same as prior period, unchanged from 0001728949-22-000012:mdna:150]

[0001728949-22-000026:mdna:181]
Many of our acquisitions and other strategic investments require approval by the United States and/or foreign government agencies. Certain agencies in the past have, and may in the future, deny the transaction or fail to approve in a timely manner, resulting in us not realizing the anticipated benefits of the proposed transaction. Future acquisitions or other strategic investments may be more difficult, complex or expensive to the extent that our reputation for our ability to consummate acquisitions has been harmed. Further, if U.S./China relations remain strained, our ability to consummate any transaction that would require approval from the relevant regulatory agency(ies) in China may be severely impacted. In addition, acquisitions that we have completed could subsequently be reviewed and/or challenged by government agencies, which could result in fines, penalties or other liability, or requirements to divest all or a portion of an acquired business.

[0001728949-22-000026:mdna:182]
[same as prior period, unchanged from 0001728949-22-000012:mdna:153]

[0001728949-22-000026:mdna:183]
[same as prior period, unchanged from 0001728949-22-000012:mdna:154]

[0001728949-22-000026:mdna:184]
We primarily utilize a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Other than the facilities we own that manufacture certain of our RFFE modules and RF (radio frequency) filter products, we rely on third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. There are a limited number of such third-party suppliers, and even fewer who are capable of manufacturing at the leading process technology nodes or who are willing to operate at

[0001728949-22-000026:mdna:185]
[same as prior period, unchanged from 0001728949-22-000012:mdna:176]

[0001728949-22-000026:mdna:186]
older process technology nodes. The semiconductor manufacturing foundries that supply our products are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders.

[0001728949-22-000026:mdna:187]
[same as prior period, unchanged from 0001728949-22-000012:mdna:156]

[0001728949-22-000026:mdna:188]
[same as prior period, unchanged from 0001728949-22-000012:mdna:157]

[0001728949-22-000026:mdna:189]
[same as prior period, unchanged from 0001728949-22-000012:mdna:158]

[0001728949-22-000026:mdna:190]
•a failure or inability by our suppliers to procure raw materials or allocate adequate raw materials for our products;

[0001728949-22-000026:mdna:191]
[same as prior period, unchanged from 0001728949-22-000012:mdna:160]

[0001728949-22-000026:mdna:192]
[same as prior period, unchanged from 0001728949-22-000012:mdna:161]

[0001728949-22-000026:mdna:193]
•our suppliers’ failure or inability to react to shifts in product demand or an increase in raw material or component prices;

[0001728949-22-000026:mdna:194]
•our suppliers’ failure or inability to develop or maintain, or a delay in developing or building out, manufacturing capacity for leading process technologies, including transitions to smaller geometry process technologies;

[0001728949-22-000026:mdna:195]
•the loss of a supplier or the failure or inability of a supplier to meet performance, quality or yield specifications or delivery schedules;

[0001728949-22-000026:mdna:196]
[same as prior period, unchanged from 0001728949-22-000012:mdna:165]

[0001728949-22-000026:mdna:197]
[same as prior period, unchanged from 0001728949-22-000012:mdna:166]

[0001728949-22-000026:mdna:198]
[same as prior period, unchanged from 0001728949-22-000012:mdna:167]

[0001728949-22-000026:mdna:199]
[same as prior period, unchanged from 0001728949-22-000012:mdna:168]

[0001728949-22-000026:mdna:200]
[same as prior period, unchanged from 0001728949-22-000012:mdna:169]

[0001728949-22-000026:mdna:201]
We rely on sole- or limited-source suppliers for certain products, which may exacerbate the risks identified above, and subject us to other significant risks, including poor product performance and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. While we have established and may in the future establish alternate suppliers for certain products, these suppliers may require significant amounts of time and levels of support to bring such products to production, both of which may increase for complex or leading process technologies. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, the elimination or limitation of a foundry supplier’s ability to manufacture components or products for us due to trade or national security protection policies could increase our vulnerability to sole- or limited-source arrangements and limit or prevent us from procuring critical components or products from those suppliers. Future consolidation of foundry suppliers could also increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions, increase our manufacturing costs and limit the amount of capacity available to us. Our arrangements with our suppliers may obligate us to incur costs to manufacture, assemble and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies (which adds risk to manufacturing yields and reliability), and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Any of the above could negatively impact our business, results of operations and cash flows.

[0001728949-22-000026:mdna:202]
[same as prior period, unchanged from 0001728949-22-000012:mdna:183]

[0001728949-22-000026:mdna:203]
Although we have long-term contracts with our suppliers, some of these contracts do not provide for long-term capacity commitments. To the extent we do not have firm commitments from our suppliers over a specific time period or for any specific quantity, our suppliers may allocate, and in the past have allocated, capacity to the manufacture, assembly and testing of products for their other customers (including our competitors) while reducing or limiting capacity to manufacture, assemble or test our products, and such capacity may be limited based on our suppliers’ ability and willingness to invest in the capital required to manufacture in the leading process technologies. Our suppliers or potential alternate suppliers may also manufacture their own integrated circuits that compete with our products. Such suppliers have in the past allocated and may again allocate raw materials and manufacturing capacity to their own products and reduce or limit the production of our products. To the extent we do obtain long-term capacity commitments, we may incur additional costs related to those commitments or make non-refundable payments for capacity commitments that are not used. Further, certain of our suppliers have in the past attempted, and may in the future attempt, to unilaterally reduce their capacity commitments to us. Accordingly, capacity for our products may not be available when we need it. Finally, we may not receive reasonable pricing, manufacturing or delivery terms from our suppliers, and our ability to obtain favorable terms may be diminished during times of high demand and/or limited manufacturing capacity for integrated circuit products.

[0001728949-22-000026:mdna:204]
[same as prior period, unchanged from 0001728949-22-000012:mdna:173]

[0001728949-22-000026:mdna:205]
[same as prior period, unchanged from 0001728949-22-000012:mdna:174]

[0001728949-22-000026:mdna:206]
[same as prior period, unchanged from 0001728949-22-000012:mdna:175]

[0001728949-22-000026:mdna:207]
[same as prior period, unchanged from 0001728949-22-000012:mdna:177]

[0001728949-22-000026:mdna:208]
We own and operate various facilities that manufacture certain of our RFFE modules and RF filter products. Manufacturing facilities are characterized by a higher portion of fixed costs relative to a fabless model. We may be faced with a decline in the utilization rates of our manufacturing facilities due to decreases in demand for our products, including in less favorable industry environments, or due to our failure to win and/or retain designs with OEMs. As a result, from time to time our manufacturing facilities operate at lower capacity levels, while the fixed costs associated with such facilities continue to be incurred, resulting in lower gross profit.

[0001728949-22-000026:mdna:209]
We are subject to many complex environmental, health and safety laws, regulations and rules in each jurisdiction in which we operate our manufacturing (and research and development) facilities. The regulatory landscape in these areas continues to evolve, and we anticipate additional laws, regulations and rules in the future. In particular, new, or changes in, environmental and climate change laws, regulations or rules, including relating to greenhouse gas emissions, could lead to new or additional investments in production processes and could increase environmental compliance expenditures. In addition, certain environmental laws impose strict, and in certain circumstances joint and several, liability on current or

[0001728949-22-000026:mdna:210]
36

[0001728949-22-000026:mdna:211]
previous owners or operators of real property, or parties who arranged for hazardous substances to be sent to disposal or treatment facilities, for the cost of investigation, removal or remediation of hazardous substances. As a result, we may incur clean-up costs in connection with any such removal or remediation efforts, as well as other third-party claims in connection with contaminated sites. In addition, we could be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage. If we, or companies or facilities we acquire or have acquired, in the past failed or in the future fail to comply with any such laws and regulations, then we could incur regulatory penalties, fines and legal liabilities; suspension of production; significant compliance requirements; alteration of our manufacturing, assembly or test processes; restriction on our ability to modify or expand our facilities; damage to our reputation; and restrictions on our operations or sales. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. We cannot make assurances that we will at all times be in compliance with such laws, regulations, rules and permits. See also the risk factor titled “Our business may suffer due to the impact of, or our failure to comply with, the various existing, new or amended laws, regulations, policies or standards to which we are subject.”

[0001728949-22-000026:mdna:212]
[same as prior period, unchanged from 0001728949-22-000012:mdna:180]

[0001728949-22-000026:mdna:213]
We have manufacturing facilities in Asia and Europe. If tsunamis, flooding, earthquakes, volcanic eruptions, drought or other natural disasters, effects of climate change or geopolitical conflicts, were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, cease or delay production and shipments of inventory and result in costly repairs, replacements or other costs and lost business. In addition, natural disasters, effects of climate change or geopolitical conflicts may result in disruptions in transportation, distribution channels and supply chains and significant increases in the prices of raw materials. Further, health crises, including epidemics or pandemics, such as the COVID-19 pandemic, and government and business responses thereto, could affect our manufacturing facilities, including by resulting in quarantines and/or closures, which would result in disruptions to and potential closures of our manufacturing operations. Our manufacturing operations could also be disrupted by cyber-attacks on our IT systems, as described in the Risk Factor below titled “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0001728949-22-000026:mdna:214]
Our manufacturing operations depend on securing raw materials and other supplies in adequate quality and quantity in a timely manner from multiple suppliers, and in some cases, we rely on a limited number of suppliers, including in some cases sole suppliers, particularly in Asia. There may be cases where supplies of raw materials and other products are interrupted or limited by natural disaster, geopolitical conflict, accident or some other event affecting a supplier or source of raw materials; supply is suspended due to quality or other issues; there is a shortage of supply due to a rapid increase in demand; and/or we or our suppliers are prohibited from utilizing certain raw materials, or products or components that incorporate such raw materials, due to government restrictions related to the countries from which such raw materials originate, and acceptable alternative suppliers, raw materials or raw materials sources are not available or not available in acceptable time frames or upon acceptable terms, among others, which could impact production and prevent us from supplying our products to our customers. If the supply-demand balance is disrupted, it may considerably increase costs of manufacturing due to increased prices we pay for raw materials. From time to time, suppliers may extend lead times, limit amounts supplied to us or increase prices due to capacity constraints or other factors. Additionally, supply and costs of raw materials may be negatively impacted by trade and/or national security protection policies, such as tariffs, or actions by governments that limit or prevent us from transacting business with certain countries or companies or that limit or prevent certain companies from transacting business with us, or trade tensions, particularly with countries in Asia. Further, it may be difficult or impossible to substitute one piece of equipment for another or replace one type of material with another. A failure by our suppliers to deliver our requirements could result in disruptions to our manufacturing operations.

[0001728949-22-000026:mdna:215]
Our manufacturing processes are highly complex, require advanced and costly equipment and must be continuously modified to improve yields and performance. Difficulties in the production process can reduce yields or interrupt production, and as a result, we may not be able to deliver our products or do so in a timely, cost-effective or competitive manner. Further, to remain competitive and meet customer demand, we may be required to improve our facilities and process technologies and

[0001728949-22-000026:mdna:216]
37

[0001728949-22-000026:mdna:217]
carry out extensive research and development, each of which may require investment of significant amounts of capital and may have a material adverse effect on our results of operations, cash flows and financial condition.

[0001728949-22-000026:mdna:218]
From time to time, we begin to purchase equipment to meet expected customer demand in advance of any purchase orders or long-term purchase commitments. Further, we typically begin manufacturing our products using our or our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates and may not be covered by long-term purchase commitments. As a result, we may incur increased inventory and manufacturing costs and/or record impairment charges to the extent anticipated sales ultimately do not materialize or are lower than expected. If we or our customers overestimate demand, or if demand is impacted by factors outside of our or our customers’ control such as the COVID-19 pandemic or trade or national security protection policies, and such demand is not covered by a binding commitment from our customers, we may experience higher inventory carrying and operating costs and/or increased excess or obsolete inventory, which would negatively impact our results of operations.

[0001728949-22-000026:mdna:219]
[same as prior period, unchanged from 0001728949-22-000012:mdna:187]

[0001728949-22-000026:mdna:220]
[same as prior period, unchanged from 0001728949-22-000012:mdna:188]

[0001728949-22-000026:mdna:221]
[same as prior period, unchanged from 0001728949-22-000012:mdna:189]

[0001728949-22-000026:mdna:222]
In addition, employees and former employees, in particular former employees who become employees of our competitors, customers, licensees or other third parties, including state actors, have in the past and may in the future misappropriate, wrongfully use, publish or provide to our competitors, customers, licensees or other third parties, including state actors, our technology, intellectual property or other proprietary or confidential information. This risk is exacerbated as competitors for talent, particularly engineering talent, increasingly attempt to hire our employees. See also the Risk Factor titled “We may not be able to attract and retain qualified employees, and our attempts to fully reopen our offices and operate under a hybrid working environment may not be successful.” Similarly, we provide access to certain of our technology, intellectual property and other proprietary or confidential information to our direct and indirect customers and licensees and certain of our consultants, who have in the past and may in the future wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. We also provide access to certain of our technology, intellectual property and other proprietary or confidential information to certain of our joint venture partners, including those affiliated with state actors and including in foreign jurisdictions where ownership restrictions may require us to take a minority ownership interest in the joint venture. Such joint venture partners may wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. Our technology, intellectual property and other proprietary or confidential information that we have provided to customers, licensees or other business partners could also be wrongfully obtained by third parties through cyber-attacks on such customers’, licensees’ or other business partners’ IT systems.

[0001728949-22-000026:mdna:223]
[same as prior period, unchanged from 0001728949-22-000012:mdna:192]

[0001728949-22-000026:mdna:224]
Further, China has implemented, and other countries or regions may implement, cybersecurity laws that require our overall IT security environment to meet certain standards and/or be certified. Such laws may be complex, ambiguous and subject to interpretation, which may create uncertainty regarding compliance. As a result, our efforts to comply with such laws may be expensive and may fail, which could adversely affect our business, results of operations and cash flows. In addition, our contracts with certain of our customers will require us to obtain cybersecurity certifications for our IT systems. Failure to obtain or maintain the necessary cybersecurity certifications could result in loss of future revenues, damage to our customer relationships and reputation, and a shift of business to our competitors.

[0001728949-22-000026:mdna:225]
[same as prior period, unchanged from 0001728949-22-000012:mdna:194]

[0001728949-22-000026:mdna:226]
[same as prior period, unchanged from 0001728949-22-000012:mdna:195]

[0001728949-22-000026:mdna:227]
Our future success depends upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. In addition, in order to extend our business into certain new and expanded product areas and industries and applications beyond mobile handsets, we need to attract, retain and motivate engineering and other technical personnel with specialized skills in these areas, and these skills are in high demand among our competitors. The market for employees in our industry is extremely competitive, and competitors for talent, particularly engineering talent, increasingly attempt to hire, and to varying degrees have been successful in hiring, our employees or employment candidates, including by establishing or expanding local offices near our headquarters in San Diego, California. Further, the increased availability of remote working arrangements, largely driven by the COVID-19 pandemic, has expanded the pool of companies that can compete for our employees and employment candidates. A number of such competitors for talent are significantly larger than us and are able to offer compensation in excess of what we are able to offer or other benefits that we generally do not offer, such as the ability to permanently work from home. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001728949-22-000026:mdna:228]
[same as prior period, unchanged from 0001728949-22-000012:mdna:197]

[0001728949-22-000026:mdna:229]
[same as prior period, unchanged from 0001728949-22-000012:mdna:198]

[0001728949-22-000026:mdna:230]
[same as prior period, unchanged from 0001728949-22-000012:mdna:199]

[0001728949-22-000026:mdna:231]
[same as prior period, unchanged from 0001728949-22-000012:mdna:200]

[0001728949-22-000026:mdna:232]
Our patent license agreements in effect that generate a significant portion of our licensing revenues are effective for a specified term. To receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms, and may impact the

[0001728949-22-000026:mdna:233]
financial or other terms of license agreements not subject to the litigation or arbitration. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such licensees.

[0001728949-22-000026:mdna:234]
[same as prior period, unchanged from 0001728949-22-000012:mdna:202]

[0001728949-22-000026:mdna:235]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, alleging that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) attempts by licensees to shift their royalty obligation to their suppliers in order to lower the wholesale (i.e., licensee’s) selling price on which the royalty is calculated.

[0001728949-22-000026:mdna:236]
[same as prior period, unchanged from 0001728949-22-000012:mdna:204]

[0001728949-22-000026:mdna:237]
We have been in the past and are currently subject to various litigation and/or governmental investigations and proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. See also the Risk Factors below titled “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings.”

[0001728949-22-000026:mdna:238]
[same as prior period, unchanged from 0001728949-22-000012:mdna:206]

[0001728949-22-000026:mdna:239]
Further, some third parties have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions should not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for

[0001728949-22-000026:mdna:240]
40

[0001728949-22-000026:mdna:241]
patent infringement (e.g., by limiting the base upon which the royalty rate may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies.

[0001728949-22-000026:mdna:242]
Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party. Further, SDOs in certain countries may attempt to modify widely accepted standards and claim the resulting standard as their own.

[0001728949-22-000026:mdna:243]
[same as prior period, unchanged from 0001728949-22-000012:mdna:209]

[0001728949-22-000026:mdna:244]
[same as prior period, unchanged from 0001728949-22-000012:mdna:210]

[0001728949-22-000026:mdna:245]
As described in the Risk Factor below titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings,” we have been in the past, currently are and may in the future be subject to various governmental investigations and/or legal proceedings challenging our patent licensing practices. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We believe that one intent of certain of these governmental investigations and legal proceedings has been to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0001728949-22-000026:mdna:246]
[same as prior period, unchanged from 0001728949-22-000012:mdna:212]

[0001728949-22-000026:mdna:247]
[same as prior period, unchanged from 0001728949-22-000012:mdna:213]

[0001728949-22-000026:mdna:248]
[same as prior period, unchanged from 0001728949-22-000012:mdna:214]

[0001728949-22-000026:mdna:249]
[same as prior period, unchanged from 0001728949-22-000012:mdna:215]

[0001728949-22-000026:mdna:250]
[same as prior period, unchanged from 0001728949-22-000012:mdna:216]

[0001728949-22-000026:mdna:251]
[same as prior period, unchanged from 0001728949-22-000012:mdna:217]

[0001728949-22-000026:mdna:252]
We have been in the past and currently are subject to various governmental investigations and proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Key allegations or findings in those matters include or have in the past included, among others: that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers; that our royalty rates are too high; that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions); that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets; that we have entered into exclusive agreements with chipset customers that foreclose competition; that we leverage our position in baseband chipsets in the RFFE space; and that we violate antitrust laws and engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-22-000026:mdna:253]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others: the loss of our ability to enforce one or more of our patents; injunctions; monetary damages, fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any revenues under such agreements. The renegotiation of license agreements could result in terms that are less favorable to us than existing terms, or lead to arbitration or litigation to resolve the licensing terms, which could also be less favorable to us than existing terms, and each of which could take months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. The occurrence of any of the above could have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies. Further, depending on the breadth and severity of the circumstances above, we may have to reduce, suspend or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted.

[0001728949-22-000026:mdna:254]
[same as prior period, unchanged from 0001728949-22-000012:mdna:220]

[0001728949-22-000026:mdna:255]
[same as prior period, unchanged from 0001728949-22-000012:mdna:221]

[0001728949-22-000026:mdna:256]
[same as prior period, unchanged from 0001728949-22-000012:mdna:222]

[0001728949-22-000026:mdna:257]
[same as prior period, unchanged from 0001728949-22-000012:mdna:223]

[0001728949-22-000026:mdna:258]
[same as prior period, unchanged from 0001728949-22-000012:mdna:224]

[0001728949-22-000026:mdna:259]
42

[0001728949-22-000026:mdna:260]
Our revenues and growth in revenues could be negatively impacted, our business may be harmed and our substantial investments in these technologies may not provide us an adequate return, if: our customers’ and licensees’ revenues and sales of products, particularly premium-tier products, and services using these technologies, and average selling prices of such products, decline due to, for example, the maturity of smartphone penetration in developed regions, including China; we do not continue to maintain our intellectual property and technical leadership in 5G, including in ongoing 5G standardization efforts; we are unable to drive the adoption of our products into networks and devices, including devices beyond mobile handsets; or consumers’ rates of replacement of smartphones and other devices decline.

[0001728949-22-000026:mdna:261]
[same as prior period, unchanged from 0001728949-22-000012:mdna:226]

[0001728949-22-000026:mdna:262]
[same as prior period, unchanged from 0001728949-22-000012:mdna:227]

[0001728949-22-000026:mdna:263]
[same as prior period, unchanged from 0001728949-22-000012:mdna:228]

[0001728949-22-000026:mdna:264]
[same as prior period, unchanged from 0001728949-22-000012:mdna:229]

[0001728949-22-000026:mdna:265]
•differentiate our integrated circuit products with innovative technologies across multiple products and features (e.g., modem, RFFE, including millimeter wave (mmWave), graphics and other processors, camera and connectivity) and with smaller geometry process technologies that drive both performance and lower power consumption;

[0001728949-22-000026:mdna:266]
[same as prior period, unchanged from 0001728949-22-000012:mdna:231]

[0001728949-22-000026:mdna:267]
[same as prior period, unchanged from 0001728949-22-000012:mdna:233]

[0001728949-22-000026:mdna:268]
[same as prior period, unchanged from 0001728949-22-000012:mdna:234]

[0001728949-22-000026:mdna:269]
[same as prior period, unchanged from 0001728949-22-000012:mdna:235]

[0001728949-22-000026:mdna:270]
[same as prior period, unchanged from 0001728949-22-000012:mdna:236]

[0001728949-22-000026:mdna:271]
[same as prior period, unchanged from 0001728949-22-000012:mdna:237]

[0001728949-22-000026:mdna:272]
[same as prior period, unchanged from 0001728949-22-000012:mdna:238]

[0001728949-22-000026:mdna:273]
[same as prior period, unchanged from 0001728949-22-000012:mdna:239]

[0001728949-22-000026:mdna:274]
[same as prior period, unchanged from 0001728949-22-000012:mdna:240]

[0001728949-22-000026:mdna:275]
[same as prior period, unchanged from 0001728949-22-000012:mdna:241]

[0001728949-22-000026:mdna:276]
[same as prior period, unchanged from 0001728949-22-000012:mdna:242]

[0001728949-22-000026:mdna:277]
[same as prior period, unchanged from 0001728949-22-000012:mdna:243]

[0001728949-22-000026:mdna:278]
[same as prior period, unchanged from 0001728949-22-000012:mdna:244]

[0001728949-22-000026:mdna:279]
Further, political actions, including trade and/or national security protection policies, or other actions by governments, particularly the U.S. and Chinese governments, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our customers or suppliers; limit, prevent or discourage certain of our customers or suppliers from transacting business with us; or make it more expensive to do so. This could advantage our competitors by enabling them with increased sales, economies of scale, operating income and/or cash flows, and/or enabling critical technology transfer, allowing them to increase their investments in technology development, research and development, and commercialization of products. See also the Risk Factor titled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0001728949-22-000026:mdna:280]
[same as prior period, unchanged from 0001728949-22-000012:mdna:247]

[0001728949-22-000026:mdna:281]
[same as prior period, unchanged from 0001728949-22-000012:mdna:248]

[0001728949-22-000026:mdna:282]
[same as prior period, unchanged from 0001728949-22-000012:mdna:249]

[0001728949-22-000026:mdna:283]
[same as prior period, unchanged from 0001728949-22-000012:mdna:250]

[0001728949-22-000026:mdna:284]
[same as prior period, unchanged from 0001728949-22-000012:mdna:251]

[0001728949-22-000026:mdna:285]
[same as prior period, unchanged from 0001728949-22-000012:mdna:252]

[0001728949-22-000026:mdna:286]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and the end users of such devices, and, potentially, to our customers’ IT infrastructure. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products, repairing or replacing defective products, writing down defective inventory, or indemnification obligations under our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, and losses on unfavorable purchase commitments. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products.

[0001728949-22-000026:mdna:287]
In addition, the occurrence of defects, errors or security vulnerabilities may give rise to product liability claims, particularly if such defects, errors or security vulnerabilities in our products or the technology we use, or the products into which they are integrated, result in personal injury or death, and could result in significant costs, expenses and losses. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the attention of our technical and management personnel and harm our business, even if we are successful. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. Further, our business liability insurance may be inadequate, or future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as: automobiles, including autonomous driver assistance programs; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and extended reality (XR) for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0001728949-22-000026:mdna:288]
[same as prior period, unchanged from 0001728949-22-000012:mdna:269]

[0001728949-22-000026:mdna:289]
[same as prior period, unchanged from 0001728949-22-000012:mdna:256]

[0001728949-22-000026:mdna:290]
[same as prior period, unchanged from 0001728949-22-000012:mdna:257]

[0001728949-22-000026:mdna:291]
[same as prior period, unchanged from 0001728949-22-000012:mdna:258]

[0001728949-22-000026:mdna:292]
[same as prior period, unchanged from 0001728949-22-000012:mdna:259]

[0001728949-22-000026:mdna:293]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. We cannot predict with certainty the long-term effects of any potential changes. In the United States, there is continued discussion regarding potential patent law changes, and there is current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. Further, the laws in certain foreign countries in which our patents are or may be licensed, or our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in ways that are detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-22-000026:mdna:294]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies or political actions of governments, including trade protection and national security policies; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business or the pricing and integration of additional features and functionality into our chipset products. See also the Risk Factors titled “Efforts by some original equipment manufacturers (OEMs) to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings.”

[0001728949-22-000026:mdna:295]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0001728949-22-000026:mdna:296]
Additionally, although our license agreements generally provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our

[0001728949-22-000026:mdna:297]
rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements.

[0001728949-22-000026:mdna:298]
See also the Risk Factors titled “Efforts by some original equipment manufacturers (OEMs) to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business” and “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0001728949-22-000026:mdna:299]
[same as prior period, unchanged from 0001728949-22-000012:mdna:266]

[0001728949-22-000026:mdna:300]
From time to time, companies have asserted, and may again assert, patent, copyright or other intellectual property claims against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation, and we are currently involved in such litigation, including those described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products were found to infringe another company’s intellectual property, we could be subject to an injunction or be required to redesign our products, or to license such intellectual property or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products, license such intellectual property used in our products or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling our products. Similarly, our suppliers could be found to infringe another company’s intellectual property, and such suppliers could then be enjoined from providing products or services to us.

[0001728949-22-000026:mdna:301]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products sold by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel and/or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-22-000026:mdna:302]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing corresponding declines in our chipset or licensing revenues.

[0001728949-22-000026:mdna:303]
[same as prior period, unchanged from 0001728949-22-000012:mdna:272]

[0001728949-22-000026:mdna:304]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe that we will continue to see, customers request that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of our products’ source code and may expose our related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of that software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code

[0001728949-22-000026:mdna:305]
available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Furthermore, in the course of product development, we may make contributions to third-party open source projects that could subject our intellectual property to adverse licensing conditions. For example, to encourage the growth of a software ecosystem that is interoperable with our products, we may need to contribute certain implementations under the open source licensing terms that govern such projects, which may adversely impact our associated intellectual property. Developing open source products, while adequately protecting the intellectual property upon which our licensing program depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental and third-party scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products.

[0001728949-22-000026:mdna:306]
[same as prior period, unchanged from 0001728949-22-000012:mdna:274]

[0001728949-22-000026:mdna:307]
[same as prior period, unchanged from 0001728949-22-000012:mdna:275]

[0001728949-22-000026:mdna:308]
[same as prior period, unchanged from 0001728949-22-000012:mdna:276]

[0001728949-22-000026:mdna:309]
A decline in global, regional or local economic conditions or a slow-down in economic growth, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could also have adverse, wide-ranging effects on our business and financial results, including: a decrease in demand for our products and technologies; a decrease in demand for the products and services of our customers or licensees; the inability of our suppliers to deliver on their supply commitments to us, our inability to supply our products to our customers and/or the inability of our customers or licensees to supply their products to end users; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our customers or licensees; failures by counterparties; and/or negative effects on wireless device inventories. In addition, our customers’ and licensees’ ability to purchase or pay for our products and intellectual property and network operators’ ability to upgrade their wireless networks could be adversely affected, potentially leading to a reduction, cancellation or delay of orders for our products. Acts of war, terrorism or other geopolitical conflicts may also result in or contribute to declining economic conditions, disruptions to global supply chains and increased volatility in financial markets, among other effects. Further, inflationary pressure may increase our costs, including employee compensation costs, reduce demand for our products or those of our customers or licensees due to increased prices of those products, or result in employee attrition to the extent our compensation does not keep up with inflation, particularly if our competitors’ compensation does.

[0001728949-22-000026:mdna:310]
Our stock price and financial results have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and our financial results include those identified above and throughout this Risk Factors section, as well as: volatility of the stock market in general and technology and semiconductor companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0001728949-22-000026:mdna:311]
[same as prior period, unchanged from 0001728949-22-000012:mdna:280]

[0001728949-22-000026:mdna:312]
Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). These include, among others, Regulations related to: patent licensing practices; antitrust, competition and competitive business practices; the flow of funds out of certain countries (e.g., China);

[0001728949-22-000026:mdna:313]
48

[0001728949-22-000026:mdna:314]
cybersecurity; imports and exports, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; protection of intellectual property; trade and trade protection including tariffs; foreign policy and national security; environmental protection (including climate change), health and safety; supply chain, responsible sourcing, including the use of conflict minerals, and human rights; spectrum availability and license issuance; adoption of standards; taxation; privacy and data protection; labor, employment and human capital; corporate governance; public disclosure; and business conduct. Compliance with, or changes in the interpretation of, existing Regulations, the adoption of new Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, among others, could have an adverse effect on our business and results of operations. See also the Risk Factors titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

[0001728949-22-000026:mdna:315]
Regulations are complex and changing (which may create uncertainty regarding compliance), are subject to varying interpretations, and their application in practice may evolve over time. As a result, our efforts to comply with Regulations may fail, particularly if there is ambiguity as to how they should be applied in practice. Failure to comply with any Regulation may adversely affect our business, results of operations and cash flows. New Regulations, or evolving interpretations thereof, may cause us to incur higher costs as we revise current practices, policies or procedures; may divert management time and attention to compliance activities; and may negatively impact our ability to conduct business in certain jurisdictions.

[0001728949-22-000026:mdna:316]
[same as prior period, unchanged from 0001728949-22-000012:mdna:283]

[0001728949-22-000026:mdna:317]
Our outstanding debt and any additional debt we incur may have negative consequences on our business, including, among others: requiring us to use cash to pay the principal of and interest on our debt, thereby reducing the amount of cash available for other purposes; limiting our ability to obtain additional financing for working capital, capital expenditures, acquisitions, stock repurchases, dividends, general corporate or other purposes; and limiting our flexibility in planning for, or reacting to, changes in our business, industries or the market. Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to economic and political conditions, industry cycles and financial, business and other factors, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations to service our debt, we may be required to, among other things: refinance or restructure all or a portion of our debt; reduce or delay planned capital or operating expenditures; reduce, suspend or eliminate our dividend payments and/or our stock repurchase program; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing or restructuring are higher than our current rates, interest expense related to such refinancing or restructuring would increase. Further, if there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt financing in the future and the terms of such debt could be adversely affected.

[0001728949-22-000026:mdna:318]
[same as prior period, unchanged from 0001728949-22-000012:mdna:286]

[0001728949-22-000026:mdna:319]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed, as well as countries where we own intellectual property. The final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-22-000026:mdna:320]
[same as prior period, unchanged from 0001728949-22-000012:mdna:288]

[0001728949-22-000026:mdna:321]
[same as prior period, unchanged from 0001728949-22-000012:mdna:290]
