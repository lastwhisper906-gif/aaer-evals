# QCOM notes — 0001728949-22-000026


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-22-000026:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 26, 2021. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 27, 2022 and March 28, 2021 included 13 weeks and 26 weeks, respectively.

[0001728949-22-000026:notes:2]
[same as prior period, unchanged from 0001728949-22-000012:notes:2]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-22-000026:notes:3]
[same as prior period, unchanged from 0001728949-22-000012:notes:3]

[0001728949-22-000026:notes:4]
| Inventories (in millions) |  |  |  |
|  | March 27,2022 |  | September 26,2021 |
| Raw materials | $ | 253 |  |  | $ | 267 |  |
| Work-in-process | 2,517 |  |  | 1,475 |  |
| Finished goods | 1,785 |  |  | 1,486 |  |
|  | $ | 4,555 |  |  | $ | 3,228 |  |

[0001728949-22-000026:notes:5]
| Short-term Debt (in millions) |  |  |  |
|  | March 27,2022 |  | September 26,2021 |
| Commercial paper | $ | 500 |  |  | $ | 500 |  |
| Current portion of long-term debt | 2,985 |  |  | 1,544 |  |
|  | $ | 3,485 |  |  | $ | 2,044 |  |

[0001728949-22-000026:notes:6]
Interest Rate Swaps. Beginning in the second quarter of fiscal 2022, we entered into interest rate swaps that are designated as fair value hedges and allow us to effectively convert fixed-rate payments into floating-rate payments on a portion of our outstanding long-term debt. We entered into these agreements, in part, to manage interest rate risk associated with our cash equivalents and marketable securities, in addition to changes in the fair value of our outstanding debt. At March 27, 2022, the notional amount of these swaps, which are denominated in U.S. dollars and mature between 2027 and 2032, was $1.6 billion. The fair value of these swaps, which is included in other noncurrent liabilities, was $74 million at March 27, 2022. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings as interest expense in the current period.

[0001728949-22-000026:notes:7]
Revenues. We disaggregate our revenues by segment (Note 6), by products and services (as presented on our condensed consolidated statement of operations), and for our QCT (Qualcomm CDMA Technologies) segment, by revenue stream, which is based on the industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s (Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets. QCT revenue streams were as follows (in millions):

[0001728949-22-000026:notes:8]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  | March 27,2022 |  | March 28,2021 |  | March 27,2022 |  | March 28,2021 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,325 |  |  | $ | 4,065 |  |  | $ | 12,307 |  |  | $ | 8,281 |  |
| RFFE (2) |  |  |  |  |  |  |  |  | 1,160 |  |  | 903 |  |  | 2,292 |  |  | 1,964 |  |
| Automotive (3) |  |  |  |  |  |  |  |  | 339 |  |  | 240 |  |  | 595 |  |  | 452 |  |
| IoT (internet of things) (4) |  |  |  |  |  |  |  |  | 1,724 |  |  | 1,073 |  |  | 3,201 |  |  | 2,117 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 9,548 |  |  | $ | 6,281 |  |  | $ | 18,395 |  |  | $ | 12,814 |  |

[0001728949-22-000026:notes:9]
[same as prior period, unchanged from 0001728949-22-000012:notes:7]

[0001728949-22-000026:notes:10]
[same as prior period, unchanged from 0001728949-22-000012:notes:8]

[0001728949-22-000026:notes:11]
[same as prior period, unchanged from 0001728949-22-000012:notes:9]

[0001728949-22-000026:notes:12]
[same as prior period, unchanged from 0001728949-22-000012:notes:10]

[0001728949-22-000026:notes:13]
[same as prior period, unchanged from 0001728949-22-000012:notes:11]

[0001728949-22-000026:notes:14]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 (1) |  | March 28,2021 (2) |  | March 27,2022 (1) |  | March 28,2021 (2) |
| Revenues recognized from previously satisfied performance obligations | $ | 185 |  |  | $ | 122 |  |  | $ | 367 |  |  | $ | 176 |  |

[0001728949-22-000026:notes:15]
[same as prior period, unchanged from 0001728949-22-000012:notes:13]

[0001728949-22-000026:notes:16]
[same as prior period, unchanged from 0001728949-22-000012:notes:14]

[0001728949-22-000026:notes:17]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In the six months ended March 27, 2022 and March 28, 2021, we recognized revenues of $340 million and $314 million, respectively, that were recorded as unearned revenues at September 26, 2021 and September 27, 2020, respectively.

[0001728949-22-000026:notes:18]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which we received license fees upfront. At March 27, 2022, we had $882 million of remaining performance obligations, of which $362 million, $362 million, $112 million, $42 million and $4 million was expected to be recognized as revenues for the remainder of fiscal 2022 and each of the subsequent four years from fiscal 2023 through 2026, respectively, and no amounts expected thereafter.

[0001728949-22-000026:notes:19]
[same as prior period, unchanged from 0001728949-22-000012:notes:17]

[0001728949-22-000026:notes:20]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | March 27,2022 |  | March 28,2021 |
| Customer/licensee (w) | 19 | % |  | 16 | % |  | 22 | % |  | 25 | % |
| Customer/licensee (x) | 19 |  |  | 16 |  |  | 19 |  |  | 14 |  |
| Customer/licensee (y) | 10 |  |  | 15 |  |  | * |  | 13 |  |
| Customer/licensee (z) | * |  | 13 |  |  | * |  | 11 |  |

[0001728949-22-000026:notes:21]
[same as prior period, unchanged from 0001728949-22-000012:notes:19]

[0001728949-22-000026:notes:22]
| Investment and Other (Expense) Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | March 27,2022 |  | March 28,2021 |
| Interest and dividend income | $ | 20 |  |  | $ | 22 |  |  | $ | 37 |  |  | $ | 42 |  |
| Net (losses) gains on marketable securities | (240) |  |  | (85) |  |  | (223) |  |  | 33 |  |
| Net (losses) gains on other investments | (21) |  |  | 176 |  |  | 73 |  |  | 209 |  |
| Net (losses) gains on deferred compensation plan assets | (43) |  |  | 23 |  |  | (30) |  |  | 77 |  |
| Impairment losses on other investments | (20) |  |  | (15) |  |  | (21) |  |  | (16) |  |
| Net losses on derivative instruments | (5) |  |  | (17) |  |  | (19) |  |  | (7) |  |
| Equity in net earnings of investees | 10 |  |  | 12 |  |  | 17 |  |  | 11 |  |
| Net gains (losses) on foreign currency transactions | 1 |  |  | (12) |  |  | 8 |  |  | (26) |  |
|  | $ | (298) |  |  | $ | 104 |  |  | $ | (158) |  |  | $ | 323 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-22-000026:notes:23]
Income Taxes
We estimate our annual effective income tax rate to be 14% for fiscal 2022, which is lower than the U.S. federal statutory rate primarily due to a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, excess tax benefits associated with share-based awards and benefits from our federal research and development tax credit. Our effective tax rate for the second quarter of fiscal 2022 was 14%. Our effective tax rate of 17% for the second quarter of fiscal 2021 included $87 million of discrete net tax charges recorded in the second quarter of fiscal 2021, which principally related to a tax audit settlement with the Internal Revenue Service and foreign currency losses on a noncurrent receivable related to our refund claim of Korean withholding tax.

[0001728949-22-000026:notes:24]
Unrecognized tax benefits were $2.1 billion at both March 27, 2022 and September 26, 2021 and primarily related to our refund claim of Korean withholding tax. If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We expect that the total amount of unrecognized tax benefits at March 27, 2022 will increase in the next 12 months as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-22-000026:notes:25]
Capital StockStock Repurchase Program. On October 12, 2021, we announced a new $10.0 billion stock repurchase program. This was in addition to the then remaining authority of $0.9 billion under the previous program. The stock repurchase programs have no expiration date. During the second quarter of fiscal 2022, we utilized the remaining repurchase authority under the previous program and began repurchases under the new program. At March 27, 2022, $9.1 billion remained authorized for repurchase under our stock repurchase program.
Shares Outstanding. Shares of common stock outstanding at March 27, 2022 were as follows (in millions):

[0001728949-22-000026:notes:26]
| Balance at September 26, 2021 | 1,125 |  |
| Issued | 11 |  |
| Repurchased | (14) |  |
| Balance at March 27, 2022 | 1,122 |  |

[0001728949-22-000026:notes:27]
Dividends. On March 9, 2022, we announced a 10% increase in our quarterly dividend per share of common stock from $0.68 to $0.75, which is effective for dividends payable after March 24, 2022. On April 13, 2022, we announced a cash dividend of $0.75 per share on our common stock, payable on June 23, 2022 to stockholders of record as of the close of business on June 2, 2022.

[0001728949-22-000026:notes:28]
[same as prior period, unchanged from 0001728949-22-000012:notes:27]

[0001728949-22-000026:notes:29]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | March 27,2022 |  | March 28,2021 |
| Dilutive common share equivalents included in diluted shares | 16 |  |  | 18 |  |  | 17 |  |  | 20 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | — |  |  | — |  |  | — |  |  | — |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-22-000026:notes:30]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0001728949-22-000026:notes:31]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions. On July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint, and on March 18, 2019, the court denied our motion. On January 15, 2020, we filed a motion for judgment on the pleadings, which the court denied on February 3, 2022. No trial date has been set. We believe the plaintiffs’ claims are without merit.

[0001728949-22-000026:notes:32]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our then current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint, and on March 10, 2020, the court granted our motion. On May 11, 2020, the plaintiffs filed a second amended complaint, and on October 8, 2020, the court granted our motion to dismiss the case with prejudice. On November 7, 2020, the plaintiffs filed a notice of appeal with the United States Court of Appeals for the Ninth Circuit (Ninth Circuit), and a hearing on the appeal was held on November 16, 2021. On February 8, 2022, the Ninth Circuit affirmed the district court’s dismissal of the case.

[0001728949-22-000026:notes:33]
Consumer Class Action Lawsuits: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and on September 27, 2018, the court granted that motion. On January 23, 2019, the Ninth Circuit granted us permission to appeal the court’s class certification order, and on January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit, and on September 29, 2021, the Ninth Circuit vacated the district court’s class certification order, ruling that the court had failed to correctly assess the propriety of applying California law to a nationwide class. The Ninth Circuit remanded the case to the district court and instructed the court to consider the effect of United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated (which the Ninth Circuit decided in favor of Qualcomm in August 2020) on this case. We believe the plaintiffs’ claims are without merit.

[0001728949-22-000026:notes:34]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

[0001728949-22-000026:notes:35]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit. We believe that ParkerVision’s claims are without merit.

[0001728949-22-000026:notes:36]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises

[0001728949-22-000026:notes:37]
that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0001728949-22-000026:notes:38]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019, and on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-22-000026:notes:39]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of its investigation, but we believe it concerns our business practices in connection with our sale of radio frequency front-end (RFFE) components. We continue to cooperate with the KFTC as it conducts its investigation. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-22-000026:notes:40]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision finding that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

[0001728949-22-000026:notes:41]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At March 27, 2022, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $276 million and included in other current liabilities.

[0001728949-22-000026:notes:42]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. From May 4, 2021 to May 6, 2021, a hearing on our appeal was held before the court. The court has announced that it will issue a decision on June 15, 2022. We believe that our business practices do not violate the EU competition rules.

[0001728949-22-000026:notes:43]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At March 27, 2022, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.2 billion and included in other current liabilities.

[0001728949-22-000026:notes:44]
Contingent Losses and Other Considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. Other than with respect to the EC fines, we have not recorded any accrual at March 27, 2022 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-22-000026:notes:45]
Segment Information
We are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarity of activities within our operating segments, such as the nature of products, the level of shared products, technology and other resources, production processes and customer base. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies, including RFFE, for use in mobile devices, automotive systems for telematics, connectivity and digital cockpit and IoT including wireless networks, broadband gateway equipment, consumer electronic devices and industrial devices. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies), our cloud AI inference processing initiative and other technology and service initiatives.

[0001728949-22-000026:notes:46]
[same as prior period, unchanged from 0001728949-22-000012:notes:45]

[0001728949-22-000026:notes:47]
[same as prior period, unchanged from 0001728949-22-000012:notes:46]

[0001728949-22-000026:notes:48]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | March 27,2022 |  | March 28,2021 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 9,548 |  |  | $ | 6,281 |  |  | $ | 18,395 |  |  | $ | 12,814 |  |
| QTL | 1,580 |  |  | 1,614 |  |  | 3,398 |  |  | 3,273 |  |
| QSI | 6 |  |  | 10 |  |  | 14 |  |  | 19 |  |
| Reconciling items | 30 |  |  | 30 |  |  | 61 |  |  | 64 |  |
| Total | $ | 11,164 |  |  | $ | 7,935 |  |  | $ | 21,868 |  |  | $ | 16,170 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 3,340 |  |  | $ | 1,584 |  |  | $ | 6,455 |  |  | $ | 3,503 |  |
| QTL | 1,154 |  |  | 1,191 |  |  | 2,560 |  |  | 2,461 |  |
| QSI | (269) |  |  | 98 |  |  | (147) |  |  | 256 |  |
| Reconciling items | (802) |  |  | (744) |  |  | (1,579) |  |  | (1,488) |  |
| Total | $ | 3,423 |  |  | $ | 2,129 |  |  | $ | 7,289 |  |  | $ | 4,732 |  |

[0001728949-22-000026:notes:49]
[same as prior period, unchanged from 0001728949-22-000012:notes:48]

[0001728949-22-000026:notes:50]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27,2022 |  | March 28,2021 |  | March 27,2022 |  | March 28,2021 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 30 |  |  | $ | 30 |  |  | $ | 61 |  |  | $ | 64 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of revenues | $ | (53) |  |  | $ | (72) |  |  | $ | (106) |  |  | $ | (148) |  |
| Unallocated research and development expenses | (433) |  |  | (415) |  |  | (886) |  |  | (821) |  |
| Unallocated selling, general and administrative expenses | (138) |  |  | (113) |  |  | (292) |  |  | (291) |  |
| Unallocated interest expense | (137) |  |  | (141) |  |  | (275) |  |  | (282) |  |
| Unallocated investment and other (expense) income, net | (34) |  |  | 14 |  |  | (11) |  |  | 85 |  |
| Nonreportable segments | (7) |  |  | (17) |  |  | (9) |  |  | (31) |  |
|  | $ | (802) |  |  | $ | (744) |  |  | $ | (1,579) |  |  | $ | (1,488) |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001728949-22-000026:notes:51]
Acquisitions Nuvia. On March 16, 2021, we completed the acquisition of NuVia, Inc. (NUVIA) for $1.1 billion (net of $174 million cash acquired), substantially all of which was paid in cash. In connection with the acquisition, we assumed or replaced unvested NUVIA stock awards with Qualcomm stock awards with an estimated fair value of $258 million, which have post-acquisition requisite service periods of up to four years. NUVIA has certain in-process technologies and is comprised of a CPU (central processing unit) and technology design team with expertise in high performance processors, SoC (system-on-chip) and power management for compute-intensive devices and applications. Upon completion of development, NUVIA’s technologies are expected to be integrated into certain QCT products. We recorded $885 million of goodwill, which is not deductible for tax purposes and was allocated to our QCT segment for annual impairment testing purposes. Goodwill is primarily attributable to assembled workforce and certain revenue and cost synergies expected to arise after the acquisition. We also recorded a $247 million in-process research and development intangible asset related to a single project, which is expected to be completed in fiscal 2023 and, upon completion, will be amortized over its useful life, which is expected to be seven years. Our results of operations for fiscal 2021 included the operating results of NUVIA since the acquisition date, the amounts of which were not material.
Veoneer. On October 4, 2021, we and SSW Partners, a New York-based investment partnership, entered into a definitive agreement (the Merger Agreement) to acquire Veoneer, Inc. (Veoneer) for $37.00 per share in cash. The transaction closed on April 1, 2022 (the Closing Date). Total cash consideration payable in the transaction, inclusive of (i) approximately $4.6 billion for amounts paid in respect of Veoneer’s outstanding capital stock and equity awards and amounts to be paid to settle Veoneer’s outstanding convertible senior notes due 2024; and (ii) the $110 million termination fee paid to Magna International Inc. (Magna) in the first quarter of fiscal 2022, was approximately $4.7 billion. On the Closing Date, SSW Partners acquired all of the outstanding capital stock of Veoneer, shortly after which it transferred Veoneer’s Arriver business to Qualcomm. We intend to incorporate Arriver’s computer vision, drive policy and driver assistance technologies into our Snapdragon automotive platform to deliver an integrated software SoC ADAS (advanced driver assistance systems) platform for automakers and Tier-1 automotive suppliers. SSW Partners retained Veoneer’s Tier-1 automotive supplier businesses, primarily consisting of the Active Safety and Restraint Control Systems businesses (the Non-Arriver businesses), which it intends to sell in one or more transactions.

[0001728949-22-000026:notes:52]
We funded substantially all of the cash consideration payable in the transaction in exchange for (i) the Arriver business and (ii) the right to receive a majority of the proceeds upon the sale of the Non-Arriver businesses by SSW Partners. We have also agreed to provide certain funding of approximately $300 million to the Non-Arriver businesses while SSW Partners seeks a buyer(s). Such amounts, along with cash retained in the Non-Arriver business, are expected to be used to fund working and other near-term capital needs, as well as certain costs incurred in connection with the close of the acquisition.

[0001728949-22-000026:notes:53]
Although we do not own or operate the Non-Arriver businesses, we have determined as of the Closing Date that we are the primary beneficiary, within the meaning of the Financial Accounting Standards Board (FASB) accounting guidance related to consolidation (ASC 810), of these businesses under the variable interest model. Accordingly, we will consolidate the Non-Arriver businesses on a one-quarter reporting lag starting from the Closing Date until such businesses are sold by SSW Partners. We expect to present the assets and liabilities of the Non-Arriver businesses as held for sale and its operating results as discontinued operations. We also expect to initially use a one-quarter reporting lag to consolidate the Arriver business within our consolidated financial statements, until certain integration activities are complete, which are expected to occur in the fourth quarter of fiscal 2022.

[0001728949-22-000026:notes:54]
In accordance with the Merger Agreement, we paid to Magna a termination fee of $110 million in the first quarter of fiscal 2022 on behalf of Veoneer in connection with the termination of the previously announced agreement and plan of merger, dated as of July 22, 2021, by and among Magna and Veoneer. The termination fee was recorded in other noncurrent assets as advanced consideration for the acquisition at March 27, 2022 and was classified as cash used by investing activities in the condensed consolidated statements of cash flows in the six months ended March 27, 2022.

[0001728949-22-000026:notes:55]
Our initial accounting for this business combination is currently underway. We expect to record and disclose the preliminary purchase price allocation in the third quarter of fiscal 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-22-000026:notes:56]
Fair Value Measurements
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at March 27, 2022 (in millions):

[0001728949-22-000026:notes:57]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 4,823 |  |  | $ | 1,274 |  |  | $ | — |  |  | $ | 6,097 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 3,832 |  |  | — |  |  | 3,832 |  |
| Equity securities | 404 |  |  | — |  |  | — |  |  | 404 |  |
| Mortgage- and asset-backed securities | — |  |  | 131 |  |  | — |  |  | 131 |  |
| U.S. Treasury securities and government-related securities | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total marketable securities | 404 |  |  | 3,969 |  |  | — |  |  | 4,373 |  |
| Derivative instruments | — |  |  | 196 |  |  | — |  |  | 196 |  |
| Other investments | 712 |  |  | — |  |  | 24 |  |  | 736 |  |
| Total assets measured at fair value | $ | 5,939 |  |  | $ | 5,439 |  |  | $ | 24 |  |  | $ | 11,402 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 83 |  |  | $ | — |  |  | $ | 83 |  |
| Other liabilities | 711 |  |  | — |  |  | — |  |  | 711 |  |
| Total liabilities measured at fair value | $ | 711 |  |  | $ | 83 |  |  | $ | — |  |  | $ | 794 |  |

[0001728949-22-000026:notes:58]
Long-term Debt. At March 27, 2022, the aggregate fair value of our outstanding floating- and fixed-rate notes, based on Level 2 inputs, was approximately $15.5 billion.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-22-000026:notes:59]
Marketable Securities
Our marketable securities were all classified as current and were comprised as follows (in millions):

[0001728949-22-000026:notes:60]
|  | March 27,2022 |  | September 26,2021 |  |  |  |  |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 3,832 |  |  | $ | 4,459 |  |  |  |  |  |
| Mortgage- and asset-backed securities | 131 |  |  | 147 |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 6 |  |  | 10 |  |  |  |  |  |
| Total available-for-sale debt securities | 3,969 |  |  | 4,616 |  |  |  |  |  |
| Equity securities | 404 |  |  | 682 |  |  |  |  |  |
| Total marketable securities | $ | 4,373 |  |  | $ | 5,298 |  |  |  |  |  |

[0001728949-22-000026:notes:61]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001728949-22-000026:notes:62]
|  | March 27,2022 |
| Years to Maturity |  |
| Less than one year | $ | 682 |  |
| One to five years | 3,156 |  |
| No single maturity date | 131 |  |
| Total | $ | 3,969 |  |

[0001728949-22-000026:notes:63]
Debt securities with no single maturity date included mortgage- and asset-backed securities.
