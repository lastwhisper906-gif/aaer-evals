# QCOM notes — 0001728949-21-000066


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-21-000066:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 27, 2020. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and nine months ended June 27, 2021 and June 28, 2020 included 13 weeks and 39 weeks, respectively.

[0001728949-21-000066:notes:2]
[same as prior period, unchanged from 0001728949-21-000043:notes:2]

[0001728949-21-000066:notes:3]
Recently Adopted Accounting Guidance.

[0001728949-21-000066:notes:4]
Financial Assets: In June 2016, the Financial Accounting Standards Board (FASB) issued new accounting guidance that changed the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) are estimated based on expected losses rather than the previous incurred loss impairment model. The new accounting guidance also eliminated the concept of other-than-temporary impairment with credit losses related to available-for-sale debt securities recorded through an allowance for credit losses rather than as a reduction in the amortized cost basis of the securities. We adopted the new accounting guidance in the first quarter of fiscal 2021 under the modified retrospective transition method, except for certain available-for-sale debt securities where the prospective transition method was required, and as a result, prior period results have not been restated. The impact upon adoption was not material to our condensed consolidated financial statements. The future impact of such accounting guidance will largely depend on the future composition and credit quality of our investment portfolio and accounts receivable, as well as future economic conditions.

[0001728949-21-000066:notes:5]
[same as prior period, unchanged from 0001728949-21-000043:notes:5]

[0001728949-21-000066:notes:6]
[same as prior period, unchanged from 0001728949-21-000043:notes:6]

[0001728949-21-000066:notes:7]
Marketable securities include marketable equity securities, available-for-sale debt securities and, from time-to-time, certain time deposits. We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value with all realized and unrealized gains and losses on investments in marketable equity securities and realized gains and losses on available-for-sale debt securities recognized in investment and other income, net. Debt securities are classified as available for sale or held to maturity at the time of purchase and reevaluated at each balance sheet date. The realized and unrealized gains and losses on marketable securities are determined using the specific identification method.

[0001728949-21-000066:notes:8]
If a debt security has an unrealized loss and we either intend to sell the security or it is more likely than not that we will be required to sell the security before its anticipated recovery, we record an impairment charge to investment and other income, net for the entire amount of the unrealized loss and adjust the amortized cost basis of the security. For the remaining debt securities, if an unrealized loss exists, we separate the impairment into the portion of the loss related to credit factors and the portion of the loss that is not related to credit factors. Unrealized gains or unrealized losses that are not related to credit factors on available-for-sale debt securities are recorded as a component of accumulated other comprehensive income, net of income taxes. Unrealized losses that are related to credit loss factors on available-for-sale debt securities and subsequent adjustments to the credit loss are recorded as an allowance for credit losses, which is included in investment and other income, net. In evaluating whether a credit loss exists, we consider a variety of factors, including the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; the security’s relative performance versus its peers, sector or asset class; the market and economy in general; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-21-000066:notes:9]
[same as prior period, unchanged from 0001728949-21-000043:notes:9]

[0001728949-21-000066:notes:10]
| Inventories (in millions) |  |  |  |
|  | June 27,2021 |  | September 27,2020 |
| Raw materials | $ | 231 |  |  | $ | 94 |  |
| Work-in-process | 1,422 |  |  | 1,155 |  |
| Finished goods | 1,480 |  |  | 1,349 |  |
|  | $ | 3,133 |  |  | $ | 2,598 |  |

[0001728949-21-000066:notes:11]
| Short-term Debt (in millions) |  |  |  |
|  | June 27,2021 |  | September 27,2020 |
| Commercial paper | $ | 500 |  |  | $ | 500 |  |
| Current portion of long-term debt | 1,545 |  |  | — |  |
|  | $ | 2,045 |  |  | $ | 500 |  |

[0001728949-21-000066:notes:12]
Revolving Credit Facility. On December 8, 2020, we entered into a Revolving Credit Facility replacing our prior Amended and Restated Revolving Credit Facility. There were no outstanding borrowings under the Amended and Restated Revolving Credit Facility at the time of termination. The Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At June 27, 2021, no amounts were outstanding under the Revolving Credit Facility. The Revolving Credit Facility requires that we comply with certain financial covenants, including that we maintain an interest coverage ratio, as defined in the agreement. At June 27, 2021, we were in compliance with the applicable covenants under the Revolving Credit Facility.

[0001728949-21-000066:notes:13]
Interest Rate Swaps. During the nine months ended June 27, 2021, we entered into forward-starting interest rate swaps to hedge the variability of forecasted interest payments on anticipated debt issuances through 2025. At June 27, 2021, the notional amount of the forward-starting interest rate swaps outstanding, which are denominated in U.S. dollars, was $2.6 billion. The fair values of the forward-starting interest rate swaps recorded in other current liabilities and other noncurrent liabilities were $38 million and $38 million, respectively, at June 27, 2021.

[0001728949-21-000066:notes:14]
[same as prior period, unchanged from 0001728949-21-000043:notes:13]

[0001728949-21-000066:notes:15]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  | June 27,2021 |  | June 28,2020 |  | June 27,2021 |  | June 28,2020 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 3,863 |  |  | $ | 2,457 |  |  | $ | 12,144 |  |  | $ | 7,461 |  |
| RFFE (2) |  |  |  |  |  |  |  |  | 957 |  |  | 447 |  |  | 2,921 |  |  | 1,509 |  |
| Automotive (3) |  |  |  |  |  |  |  |  | 253 |  |  | 138 |  |  | 705 |  |  | 456 |  |
| IoT (internet of things) (4) |  |  |  |  |  |  |  |  | 1,399 |  |  | 765 |  |  | 3,517 |  |  | 2,100 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 6,472 |  |  | $ | 3,807 |  |  | $ | 19,287 |  |  | $ | 11,526 |  |

[0001728949-21-000066:notes:16]
[same as prior period, unchanged from 0001728949-21-000043:notes:15]

[0001728949-21-000066:notes:17]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in handsets) and excludes radio frequency transceiver components.

[0001728949-21-000066:notes:18]
(3) Includes revenues from products sold for use in automobiles, including telematics, connectivity and infotainment (also known as digital cockpit).

[0001728949-21-000066:notes:19]
(4) Primarily includes products sold for use in the following industry segments and applications: consumer (including computing, voice and music and XR), industrial (including handhelds, retail, transportation and logistics, and utilities) and edge networking (including mobile broadband and wireless access points).

[0001728949-21-000066:notes:20]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were $170 million and $258 million for the three and nine months ended June 27, 2021, respectively, and primarily related to certain QCT customer incentives, the release of a variable constraint against revenues not previously allocated to our segment results (Note 6), and QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due). Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were $141 million and $258 million for the three and nine months ended June 28, 2020, respectively, and primarily related to QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due) and certain QCT customer incentives.

[0001728949-21-000066:notes:21]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In the nine months ended June 27, 2021 and June 28, 2020, we recognized revenues of $437 million and $424 million, respectively, that were recorded as unearned revenues at September 27, 2020 and September 29, 2019, respectively.

[0001728949-21-000066:notes:22]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront. At June 27, 2021, we had $1.1 billion of remaining performance obligations, of which $143 million, $567 million, $274 million, $88 million and $31 million was expected to be recognized as revenues for the remainder of fiscal 2021 and each of the subsequent four years from fiscal 2022 through 2025, respectively, and $2 million thereafter.

[0001728949-21-000066:notes:23]
[same as prior period, unchanged from 0001728949-21-000043:notes:22]

[0001728949-21-000066:notes:24]
|  | Three Months Ended |  | Nine Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | June 27,2021 |  | June 28,2020 |  | June 27,2021 |  | June 28,2020 |  |  |  |  |  |  |  |  |  |  |
| Customer/licensee (v) | 16 | % |  | * |  | 22 | % |  | * |  |  |  |  |  |  |  |  |  |  |
| Customer/licensee (w) | 16 |  |  | 14 | % |  | 14 |  |  | 15 | % |  |  |  |  |  |  |  |  |  |  |
| Customer/licensee (x) | 13 |  |  | 17 |  |  | 14 |  |  | 20 |  |  |  |  |  |  |  |  |  |  |  |
| Customer/licensee (y) | 10 |  |  | 11 |  |  | 10 |  |  | 10 |  |  |  |  |  |  |  |  |  |  |  |
| Customer/licensee (z) | * |  | 10 |  |  | * |  | * |  |  |  |  |  |  |  |  |  |  |

[0001728949-21-000066:notes:25]
[same as prior period, unchanged from 0001728949-21-000043:notes:24]

[0001728949-21-000066:notes:26]
Accounts receivable at September 27, 2020 included approximately $1.3 billion, excluding the impact of foreign withholding taxes, from Huawei related to the remaining amounts due under the previously disclosed settlement agreement and estimated royalties for sales made in the September 2020 quarter. Since September 27, 2020 and subsequent to June 27, 2021, Huawei paid all such amounts, including the final installment under the settlement agreement in accordance with the agreed upon payment schedule.

[0001728949-21-000066:notes:27]
Other Income, Costs and Expenses. Other income in the nine months ended June 28, 2020 consisted of a $23 million gain related to a favorable legal settlement.

[0001728949-21-000066:notes:28]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | June 27,2021 |  | June 28,2020 |
| Interest and dividend income | $ | 21 |  |  | $ | 30 |  |  | $ | 63 |  |  | $ | 135 |  |
| Net gains on marketable securities | 53 |  |  | 117 |  |  | 86 |  |  | 183 |  |
| Net gains on other investments | 97 |  |  | 48 |  |  | 307 |  |  | 84 |  |
| Net gains on deferred compensation plan assets | 38 |  |  | 57 |  |  | 115 |  |  | 16 |  |
| Impairment losses on other investments | (7) |  |  | (12) |  |  | (24) |  |  | (349) |  |
| Net gains (losses) on derivative investments | — |  |  | 1 |  |  | (7) |  |  | 2 |  |
| Equity in net earnings (losses) of investees | 1 |  |  | (6) |  |  | 12 |  |  | (21) |  |
| Net losses on foreign currency transactions | (3) |  |  | (6) |  |  | (29) |  |  | (4) |  |
|  | $ | 200 |  |  | $ | 229 |  |  | $ | 523 |  |  | $ | 46 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-21-000066:notes:29]
Income Taxes
We estimate our annual effective income tax rate to be 11% for fiscal 2021, which is lower than the U.S. federal statutory rate, primarily due to a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, excess tax benefits associated with share-based awards and benefits from our federal research and development tax credit. The effective tax rate of 10% for the third quarter of fiscal 2021 was lower than the estimated annual effective tax rate of 11% primarily due to $64 million of discrete net tax benefits recorded in the third quarter of fiscal 2021, which principally related to excess tax benefits associated with share-based awards that vested in the third fiscal quarter. The effective tax rate of 3% for the third quarter of fiscal 2020 included benefits recorded in the third quarter of fiscal 2020, which principally related to certain releases of our valuation allowance on capital losses, a higher FDII deduction and foreign tax credit utilization.

[0001728949-21-000066:notes:30]
Unrecognized tax benefits were $2.0 billion and $1.9 billion at June 27, 2021 and September 27, 2020, respectively, and primarily related to our refund claim of Korean withholding tax. If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We expect that the total amount of unrecognized tax benefits at June 27, 2021 will increase in the next 12 months as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-21-000066:notes:31]
[same as prior period, unchanged from 0001728949-21-000043:notes:30]

[0001728949-21-000066:notes:32]
In the nine months ended June 27, 2021 and June 28, 2020, we repurchased and retired 18 million and 31 million shares, respectively, for $2.6 billion and $2.5 billion, respectively, before commissions. To reflect share repurchases in the consolidated balance sheet, we (i) reduce common stock for the par value of the shares, (ii) reduce paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) record the residual amount, if any, to retained earnings. At June 27, 2021, $2.0 billion remained authorized for repurchase under our stock repurchase program.

[0001728949-21-000066:notes:33]
Dividends. On July 14, 2021, we announced a cash dividend of $0.68 per share on our common stock, payable on September 23, 2021 to stockholders of record as of the close of business on September 2, 2021.

[0001728949-21-000066:notes:34]
[same as prior period, unchanged from 0001728949-21-000043:notes:33]

[0001728949-21-000066:notes:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | June 27,2021 |  | June 28,2020 |
| Dilutive common share equivalents included in diluted shares | 16 |  |  | 12 |  |  | 19 |  |  | 13 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | — |  |  | 3 |  |  | — |  |  | 1 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-21-000066:notes:36]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0001728949-21-000066:notes:37]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000066:notes:38]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our then current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On January 22, 2019, the court appointed the lead plaintiff in the action. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint, and on March 10, 2020, the court granted our motion. On May 11, 2020, the plaintiffs filed a second amended complaint, and on October 8, 2020, the court granted our motion to dismiss the case with prejudice. On November 7, 2020, the plaintiffs filed a notice of appeal. No hearing date has been set. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000066:notes:39]
Consumer Class Action Lawsuits: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. The Ninth Circuit has not yet ruled on our appeal. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000066:notes:40]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000066:notes:41]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, then captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision has subsequently reduced the number of patents asserted to four, granted covenants not to sue on the other patents and dismissed the Samsung and HTC entities from the case. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 26, 2021, the court issued an order stating that trial is extremely unlikely to occur before November or December 2021, if then. We believe that ParkerVision’s claims are without merit.

[0001728949-21-000066:notes:42]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises.

[0001728949-21-000066:notes:43]
The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0001728949-21-000066:notes:44]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019 and, on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-21-000066:notes:45]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of their investigation, but we believe it concerns our business practices in connection with our sale of radio frequency front-end (RFFE) components. We continue to cooperate with the KFTC as it conducts its investigation. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-21-000066:notes:46]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision confirming their preliminary view that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

[0001728949-21-000066:notes:47]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At June 27, 2021, the liability, including related foreign currency losses and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $296 million and included in other current liabilities.

[0001728949-21-000066:notes:48]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. From May 4, 2021 to May 6, 2021, a hearing on our appeal was held before the court. The court has not yet issued a ruling. We believe that our business practices do not violate the EU competition rules.

[0001728949-21-000066:notes:49]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At June 27, 2021, the liability, including related foreign currency losses and accrued interest (which, to the extent they were

[0001728949-21-000066:notes:50]
not related to the net investment hedge, were recorded in investment and other income, net), was $1.2 billion and included in other current liabilities.

[0001728949-21-000066:notes:51]
Contingent losses and other considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at June 27, 2021 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.
Long-term Capacity Commitments. In the third quarter of fiscal 2021, we entered into several multi-year capacity purchase commitments with certain suppliers of our integrated circuit products. Failure to meet future minimum purchase volumes may result in incremental fees or the loss of amounts paid in advance. We currently expect to meet all future minimum purchase volume commitments in addition to other requirements related to advance and/or ongoing payment obligations. As a result of these arrangements, our future purchase obligation commitments have increased materially since September 27, 2020.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-21-000066:notes:52]
Segment Information
We are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarity of business activities within our operating segments, such as the nature of products, the level of shared products, technology and other resources, production processes and customer base. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies for use in mobile devices, wireless networks, devices used in IoT, broadband gateway equipment, consumer electronic devices and automotive systems for telematics and infotainment. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an investee. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies), our cloud AI inference processing initiative and other technology and service initiatives.

[0001728949-21-000066:notes:53]
[same as prior period, unchanged from 0001728949-21-000043:notes:59]

[0001728949-21-000066:notes:54]
[same as prior period, unchanged from 0001728949-21-000043:notes:60]

[0001728949-21-000066:notes:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | June 27,2021 |  | June 28,2020 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 6,472 |  |  | $ | 3,807 |  |  | $ | 19,287 |  |  | $ | 11,526 |  |
| QTL | 1,489 |  |  | 1,044 |  |  | 4,762 |  |  | 3,520 |  |
| QSI | 11 |  |  | 3 |  |  | 30 |  |  | 33 |  |
| Reconciling items | 88 |  |  | 39 |  |  | 151 |  |  | 106 |  |
| Total | $ | 8,060 |  |  | $ | 4,893 |  |  | $ | 24,230 |  |  | $ | 15,185 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 1,795 |  |  | $ | 603 |  |  | $ | 5,299 |  |  | $ | 1,748 |  |
| QTL | 1,053 |  |  | 646 |  |  | 3,514 |  |  | 2,335 |  |
| QSI | 156 |  |  | 153 |  |  | 412 |  |  | (58) |  |
| Reconciling items | (747) |  |  | (534) |  |  | (2,236) |  |  | (1,612) |  |
| Total | $ | 2,257 |  |  | $ | 868 |  |  | $ | 6,989 |  |  | $ | 2,413 |  |

[0001728949-21-000066:notes:56]
[same as prior period, unchanged from 0001728949-21-000043:notes:62]

[0001728949-21-000066:notes:57]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | June 27,2021 |  | June 28,2020 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 34 |  |  | $ | 39 |  |  | $ | 97 |  |  | $ | 106 |  |
| Unallocated revenues (Note 2) | 54 |  |  | — |  |  | 54 |  |  | — |  |
|  | $ | 88 |  |  | $ | 39 |  |  | $ | 151 |  |  | $ | 106 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated revenues (Note 2) | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |
| Unallocated cost of revenues | (73) |  |  | (87) |  |  | (220) |  |  | (262) |  |
| Unallocated research and development expenses | (505) |  |  | (271) |  |  | (1,325) |  |  | (746) |  |
| Unallocated selling, general and administrative expenses | (125) |  |  | (103) |  |  | (418) |  |  | (275) |  |
| Unallocated other income (Note 2) | — |  |  | — |  |  | — |  |  | 23 |  |
| Unallocated interest expense | (138) |  |  | (142) |  |  | (420) |  |  | (434) |  |
| Unallocated investment and other income, net | 55 |  |  | 76 |  |  | 140 |  |  | 129 |  |
| Nonreportable segments | (15) |  |  | (7) |  |  | (47) |  |  | (47) |  |
|  | $ | (747) |  |  | $ | (534) |  |  | $ | (2,236) |  |  | $ | (1,612) |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001728949-21-000066:notes:58]
Acquisitions 
On March 16, 2021 (the Closing Date), we completed the acquisition of NuVia, Inc. (NUVIA) for $1.1 billion (net of cash acquired), substantially all of which was paid in cash. In connection with the acquisition, we assumed or replaced unvested NUVIA stock awards with Qualcomm stock awards with an estimated fair value of $258 million, for which $10 million was attributable to pre-acquisition services and included in the purchase price, and the remaining amount is recognized as compensation expense over the related post-acquisition requisite service period of up to four years.

[0001728949-21-000066:notes:59]
[same as prior period, unchanged from 0001728949-21-000043:notes:65]

[0001728949-21-000066:notes:60]
We have not finalized the purchase price allocation. Accordingly, the preliminary purchase price allocation shown below could change as the fair values of the assets acquired and liabilities assumed, and the related income tax effects, are finalized during the remainder of the measurement period (which will not exceed 12 months from the Closing Date). The preliminary allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0001728949-21-000066:notes:61]
[same as prior period, unchanged from 0001728949-21-000043:notes:67]

[0001728949-21-000066:notes:62]
Goodwill recognized in this transaction is not deductible for tax purposes and was allocated to our QCT segment for annual impairment testing purposes. Goodwill is primarily attributable to assembled workforce and certain revenue and cost synergies expected to arise after the acquisition. IPR&D is related to a single project, which is expected to be completed in fiscal 2023 and, upon completion, will be amortized over its useful life, which is expected to be seven years. The estimated fair value of the IPR&D asset acquired was determined using an income approach based on significant inputs that were not observable.

[0001728949-21-000066:notes:63]
Our results of operations for the three and nine months ended June 27, 2021 included the operating results of NUVIA since the Closing Date, the amounts of which were not material. Pro forma results of operations have not been presented because the effects of this acquisition were not material to our condensed consolidated results of operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-21-000066:notes:64]
Fair Value Measurements
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at June 27, 2021 (in millions):

[0001728949-21-000066:notes:65]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 3,147 |  |  | $ | 3,022 |  |  | $ | — |  |  | $ | 6,169 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 5,035 |  |  | — |  |  | 5,035 |  |
| Equity securities | 303 |  |  | — |  |  | — |  |  | 303 |  |
| Mortgage- and asset-backed securities | — |  |  | 160 |  |  | — |  |  | 160 |  |
| U.S. Treasury securities and government-related securities | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total marketable securities | 303 |  |  | 5,205 |  |  | — |  |  | 5,508 |  |
| Derivative instruments | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Other investments | 664 |  |  | — |  |  | 9 |  |  | 673 |  |
| Total assets measured at fair value | $ | 4,114 |  |  | $ | 8,267 |  |  | $ | 9 |  |  | $ | 12,390 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 88 |  |  | $ | — |  |  | $ | 88 |  |
| Other liabilities | 664 |  |  | — |  |  | — |  |  | 664 |  |
| Total liabilities measured at fair value | $ | 664 |  |  | $ | 88 |  |  | $ | — |  |  | $ | 752 |  |

[0001728949-21-000066:notes:66]
Activity within Level 3 of the Fair Value Hierarchy. Other investments included in Level 3 at June 27, 2021 were comprised of non-marketable debt instruments. Activity for marketable securities and other investments classified within Level 3 was insignificant during the nine months ended June 27, 2021 (primarily related to sales of auction rate securities and settlements of non-marketable debt instruments) and the nine months ended June 28, 2020 (primarily related to impairments of certain non-marketable debt instruments and purchases of non-marketable debt instruments). Activity for other liabilities

[0001728949-21-000066:notes:67]
classified within Level 3 was insignificant during the nine months ended June 28, 2020 (primarily related to payments of contingent consideration related to a certain business acquisition).

[0001728949-21-000066:notes:68]
Assets Measured and Recorded at Fair Value on a Nonrecurring Basis. We measure certain assets and liabilities at fair value on a nonrecurring basis. These assets and liabilities include equity method and non-marketable equity investments, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During the nine months ended June 27, 2021 and June 28, 2020, certain of our non-marketable equity investments were written down to their estimated fair values, which was recorded as a component of impairment losses on other investments in investment and other income, net (Note 2), and certain other non-marketable equity investments were remeasured to their estimated fair values based on observable price changes in orderly transactions for identical or similar securities, which is recorded as a component of net gains on other investments in investment and other income, net (Note 2). The estimation of fair value used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3.

[0001728949-21-000066:notes:69]
Long-term Debt. At June 27, 2021 and September 27, 2020, the aggregate fair value of our outstanding floating- and fixed-rate notes, based on Level 2 inputs, was approximately $17.0 billion and $17.5 billion, respectively.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-21-000066:notes:70]
Marketable Securities
Our marketable securities were comprised as follows (in millions):

[0001728949-21-000066:notes:71]
|  | Current |  | Noncurrent (1) |
|  | June 27,2021 |  | September 27,2020 |  | June 27,2021 |  | September 27,2020 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 5,035 |  |  | $ | 4,049 |  |  | $ | — |  |  | $ | — |  |
| Mortgage- and asset-backed and auction rate securities | 160 |  |  | 66 |  |  | — |  |  | 35 |  |
| U.S. Treasury securities and government-related securities | 10 |  |  | 10 |  |  | — |  |  | — |  |
| Total available-for-sale debt securities | 5,205 |  |  | 4,125 |  |  | — |  |  | 35 |  |
| Equity securities | 303 |  |  | 352 |  |  | — |  |  | — |  |
| Time deposit (2) | — |  |  | 30 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 5,508 |  |  | $ | 4,507 |  |  | $ | — |  |  | $ | 35 |  |

[0001728949-21-000066:notes:72]
(1) Noncurrent marketable securities were included in other assets.

[0001728949-21-000066:notes:73]
(2) At September 27, 2020, marketable securities also included a time deposit with an original maturity of greater than 90 days.

[0001728949-21-000066:notes:74]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001728949-21-000066:notes:75]
|  | June 27,2021 |
| Years to Maturity |  |
| Less than one year | $ | 1,938 |  |
| One to five years | 3,107 |  |
| No single maturity date | 160 |  |
| Total | $ | 5,205 |  |

[0001728949-21-000066:notes:76]
Debt securities with no single maturity date included mortgage- and asset-backed securities.
