# QCOM MD&A — 0001728949-21-000066


## mdna

[0001728949-21-000066:mdna:1]
[same as prior period, unchanged from 0001728949-21-000043:mdna:1]

[0001728949-21-000066:mdna:2]
[same as prior period, unchanged from 0001728949-21-000043:mdna:2]

[0001728949-21-000066:mdna:3]
This Quarterly Report (including but not limited to this section titled Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements regarding our business, investments, financial condition, results of operations, cash flows and prospects. Forward-looking statements further include but are not limited to statements regarding industry, market, business, product, technology, commercial, competitive or consumer trends, including seasonality; the 5G transition; our businesses, growth potential or strategies, or factors that may impact them; challenges to our licensing business, including by licensees, governments, governmental agencies or regulators, standards bodies or others; challenges to our QCT business; other legal or regulatory matters; competition; new or expanded product areas, adjacent industry segments and applications; costs or expenditures including research and development, selling, general and administrative, restructuring or restructuring-related charges, working capital or information technology (IT) systems; our debt, financing, stock repurchase or dividend programs; our liquidity and capital resources, including our expected increase in operating cash outflows to secure long-term capacity commitments with certain of our suppliers; strategic investments or acquisitions, and the anticipated timing or benefits thereof; the potential impacts of the COVID-19 pandemic; adoption and application of future accounting guidance; tax law changes; our tax structure or strategies; U.S./China trade or national security policies; and the potential business or financial statement impacts of any of the above, among others. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001728949-21-000066:mdna:4]
Third Quarter Fiscal 2021 Overview

[0001728949-21-000066:mdna:5]
Revenues for the third quarter of fiscal 2021 were $8.1 billion, an increase of 65% compared to the year ago quarter, with net income of $2.0 billion, an increase of 140% compared to the year ago quarter. Highlights from the third quarter of fiscal 2021 included:

[0001728949-21-000066:mdna:6]
•QCT revenues increased by 70% in the third quarter of fiscal 2021 compared to the year ago quarter, primarily due to an increase in demand for 5G products across handsets and RFFE, in part reflecting a recovery of the negative impacts of COVID-19, along with higher automotive and IoT revenues.

[0001728949-21-000066:mdna:7]
•QTL revenues increased by 43% in the third quarter of fiscal 2021 compared to the year ago quarter, primarily due to an increase in estimated sales of 3G/4G/5G-based multimode products, which was primarily driven by a recovery from the negative impacts of COVID-19.

[0001728949-21-000066:mdna:8]
[same as prior period, unchanged from 0001728949-21-000043:mdna:11]

[0001728949-21-000066:mdna:9]
[same as prior period, unchanged from 0001728949-21-000043:mdna:12]

[0001728949-21-000066:mdna:10]
[same as prior period, unchanged from 0001728949-21-000043:mdna:13]

[0001728949-21-000066:mdna:11]
22

[0001728949-21-000066:mdna:12]
[same as prior period, unchanged from 0001728949-21-000043:mdna:14]

[0001728949-21-000066:mdna:13]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when licensees’ sales occur. We expect QCT revenues to continue to be impacted by seasonal trends related to product launch timing for sales made to Apple under our multi-year chipset supply agreement. These trends may or may not continue in the future and have been impacted in the past by declines in consumer demand resulting from COVID-19. Further, the trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings.

[0001728949-21-000066:mdna:14]
[same as prior period, unchanged from 0001728949-21-000043:mdna:16]

[0001728949-21-000066:mdna:15]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | Change |  | June 27,2021 |  | June 28,2020 |  | Change |
| Equipment and services | $ | 6,428 |  |  | $ | 3,794 |  |  | $ | 2,634 |  |  | $ | 19,109 |  |  | $ | 11,376 |  |  | $ | 7,733 |  |
| Licensing | 1,632 |  |  | 1,099 |  |  | 533 |  |  | 5,121 |  |  | 3,809 |  |  | 1,312 |  |
|  | $ | 8,060 |  |  | $ | 4,893 |  |  | $ | 3,167 |  |  | $ | 24,230 |  |  | $ | 15,185 |  |  | $ | 9,045 |  |

[0001728949-21-000066:mdna:16]
Third quarter 2021 vs. 2020

[0001728949-21-000066:mdna:17]
The increase in revenues in the third quarter of fiscal 2021 was primarily due to:

[0001728949-21-000066:mdna:18]
+    $2.6 billion in higher equipment and services revenues from our QCT segment

[0001728949-21-000066:mdna:19]
+    $445 million in higher licensing revenues from our QTL segment

[0001728949-21-000066:mdna:20]
First nine months 2021 vs. 2020

[0001728949-21-000066:mdna:21]
The increase in revenues in the first nine months of fiscal 2021 was primarily due to:

[0001728949-21-000066:mdna:22]
+    $7.7 billion in higher equipment and services revenues from our QCT segment

[0001728949-21-000066:mdna:23]
+    $1.2 billion in higher licensing revenues from our QTL segment

[0001728949-21-000066:mdna:24]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | Change |  | June 27,2021 |  | June 28,2020 |  | Change |
| Cost of revenues | $ | 3,404 |  |  | $ | 2,080 |  |  | $ | 1,324 |  |  | $ | 10,325 |  |  | $ | 6,489 |  |  | $ | 3,836 |  |
| Gross margin | 58 | % |  | 57 | % |  |  |  | 57 | % |  | 57 | % |  |  |

[0001728949-21-000066:mdna:25]
Third quarter 2021 vs. 2020

[0001728949-21-000066:mdna:26]
Gross margin percentage increased in the third quarter of fiscal 2021 primarily due to higher QTL revenues.

[0001728949-21-000066:mdna:27]
First nine months 2021 vs. 2020

[0001728949-21-000066:mdna:28]
Gross margin percentage remained flat in the first nine months of fiscal 2021.

[0001728949-21-000066:mdna:29]
[same as prior period, unchanged from 0001728949-21-000043:mdna:7]

[0001728949-21-000066:mdna:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | Change |  | June 27,2021 |  | June 28,2020 |  | Change |
| Research and development | $ | 1,864 |  |  | $ | 1,520 |  |  | $ | 344 |  |  | $ | 5,297 |  |  | $ | 4,393 |  |  | $ | 904 |  |
| % of revenues | 23 | % |  | 31 | % |  |  |  | 22 | % |  | 29 | % |  |  |

[0001728949-21-000066:mdna:31]
Third quarter 2021 vs. 2020

[0001728949-21-000066:mdna:32]
The increase in research and development expenses in the third quarter of fiscal 2021 was primarily due to:

[0001728949-21-000066:mdna:33]
+    $248 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), a portion of which was attributable to higher employee cash incentive program costs

[0001728949-21-000066:mdna:34]
+    $103 million increase in share-based compensation expense

[0001728949-21-000066:mdna:35]
First nine months 2021 vs. 2020

[0001728949-21-000066:mdna:36]
The increase in research and development expenses in the first nine months of fiscal 2021 was primarily due to:

[0001728949-21-000066:mdna:37]
+    $585 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), a portion of which was attributable to higher employee cash incentive program costs

[0001728949-21-000066:mdna:38]
+    $267 million increase in share-based compensation expense

[0001728949-21-000066:mdna:39]
+    $52 million increase in expenses driven by revaluation of our deferred compensation obligation on improved stock market performance (which resulted in a corresponding increase in net gains on deferred compensation plan assets within investment and other income, net due to the revaluation of the related assets)

[0001728949-21-000066:mdna:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | Change |  | June 27,2021 |  | June 28,2020 |  | Change |
| Selling, general and administrative | $ | 597 |  |  | $ | 511 |  |  | $ | 86 |  |  | $ | 1,721 |  |  | $ | 1,523 |  |  | $ | 198 |  |
| % of revenues | 7 | % |  | 10 | % |  |  |  | 7 | % |  | 10 | % |  |  |

[0001728949-21-000066:mdna:41]
Third quarter 2021 vs. 2020

[0001728949-21-000066:mdna:42]
The increase in selling, general and administrative expenses in the third quarter of fiscal 2021 was primarily due to:

[0001728949-21-000066:mdna:43]
+    $101 million increase in employee-related expenses, a portion of which was attributable to higher employee cash incentive program costs

[0001728949-21-000066:mdna:44]
+    $23 million increase in share-based compensation expense

[0001728949-21-000066:mdna:45]
-    $23 million decrease in litigation costs

[0001728949-21-000066:mdna:46]
First nine months 2021 vs. 2020

[0001728949-21-000066:mdna:47]
The increase in selling, general and administrative expenses in the first nine months of fiscal 2021 was primarily due to:

[0001728949-21-000066:mdna:48]
+    $120 million increase in employee-related expenses, primarily driven by higher employee cash incentive program costs

[0001728949-21-000066:mdna:49]
+    $66 million increase in share-based compensation expense

[0001728949-21-000066:mdna:50]
+    $46 million increase in expenses driven by revaluation of our deferred compensation obligation on improved stock market performance (which resulted in a corresponding increase in net gains on deferred compensation plan assets within investment and other income, net due to the revaluation of the related assets)

[0001728949-21-000066:mdna:51]
-    $61 million decrease in litigation costs

[0001728949-21-000066:mdna:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | Change |  | June 27,2021 |  | June 28,2020 |  | Change |
| Other | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (23) |  |  | $ | 23 |  |

[0001728949-21-000066:mdna:53]
First nine months 2020

[0001728949-21-000066:mdna:54]
Other income in the first nine months of fiscal 2020 consisted of a $23 million gain related to a favorable legal settlement.

[0001728949-21-000066:mdna:55]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | Change |  | June 27,2021 |  | June 28,2020 |  | Change |
| Interest expense | $ | 138 |  |  | $ | 143 |  |  | $ | (5) |  |  | $ | 421 |  |  | $ | 436 |  |  | $ | (15) |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 21 |  |  | $ | 30 |  |  | $ | (9) |  |  | $ | 63 |  |  | $ | 135 |  |  | $ | (72) |  |
| Net gains on marketable securities | 53 |  |  | 117 |  |  | (64) |  |  | 86 |  |  | 183 |  |  | (97) |  |
| Net gains on other investments | 97 |  |  | 48 |  |  | 49 |  |  | 307 |  |  | 84 |  |  | 223 |  |
| Net gains on deferred compensation plan assets | 38 |  |  | 57 |  |  | (19) |  |  | 115 |  |  | 16 |  |  | 99 |  |
| Impairment losses on other investments | (7) |  |  | (12) |  |  | 5 |  |  | (24) |  |  | (349) |  |  | 325 |  |
| Net gains (losses) on derivative instruments | — |  |  | 1 |  |  | (1) |  |  | (7) |  |  | 2 |  |  | (9) |  |
| Equity in net earnings (losses) of investees | 1 |  |  | (6) |  |  | 7 |  |  | 12 |  |  | (21) |  |  | 33 |  |
| Net losses on foreign currency transactions | (3) |  |  | (6) |  |  | 3 |  |  | (29) |  |  | (4) |  |  | (25) |  |
|  | $ | 200 |  |  | $ | 229 |  |  | $ | (29) |  |  | $ | 523 |  |  | $ | 46 |  |  | $ | 477 |  |

[0001728949-21-000066:mdna:56]
Net gains on other investments for the nine months ended June 27, 2021 was driven primarily by realized gains resulting from the sale of certain of our QSI non-marketable investments. The impairment losses on other investments for the nine months ended June 28, 2020 were due in part to the impact COVID-19 had on certain of our investees. A significant portion of the impairment losses related to our investment in OneWeb who filed for bankruptcy in the second quarter of fiscal 2020.

[0001728949-21-000066:mdna:57]
[same as prior period, unchanged from 0001728949-21-000043:mdna:66]

[0001728949-21-000066:mdna:58]
[same as prior period, unchanged from 0001728949-21-000043:mdna:67]

[0001728949-21-000066:mdna:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | June 27,2021 |  | June 28,2020 |
| Expected income tax provision at federal statutory tax rate | $ | 474 |  |  | $ | 182 |  |  | $ | 1,468 |  |  | $ | 507 |  |
| Benefit from foreign-derived intangible income (FDII) deduction | (119) |  |  | (52) |  |  | (308) |  |  | (140) |  |
| Excess tax benefit associated with share-based awards | (74) |  |  | (20) |  |  | (258) |  |  | (76) |  |
| Benefit related to the research and development tax credit | (40) |  |  | (24) |  |  | (138) |  |  | (84) |  |
| Audit settlement with Internal Revenue Service | — |  |  | — |  |  | 55 |  |  | — |  |
| Foreign currency gains related to foreign withholding tax receivable | (1) |  |  | (11) |  |  | (47) |  |  | (7) |  |
| Benefit from releasing valuation allowance on capital losses | (5) |  |  | (41) |  |  | (21) |  |  | (72) |  |
| Other | (5) |  |  | (11) |  |  | (7) |  |  | 47 |  |
| Income tax expense | $ | 230 |  |  | $ | 23 |  |  | $ | 744 |  |  | $ | 175 |  |
| Effective tax rate | 10 | % |  | 3 | % |  | 11 | % |  | 7 | % |

[0001728949-21-000066:mdna:60]
We estimate our annual effective income tax rate to be 11% for fiscal 2021, which is lower than the U.S. federal statutory rate, primarily due to a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, excess tax benefits associated with share-based awards and benefits from our federal research and development tax credit.

[0001728949-21-000066:mdna:61]
In the first quarter of fiscal 2021, the United States Treasury Department issued final regulations on the foreign tax credit, which generally are applicable beginning in fiscal 2021, with certain provisions retroactive to fiscal 2019. As a result of these regulations, our fiscal 2021 estimated annual effective tax rate increased by approximately 1%. The retroactive

[0001728949-21-000066:mdna:62]
[same as prior period, unchanged from 0001728949-21-000043:mdna:46]

[0001728949-21-000066:mdna:63]
impact resulting from these new regulations, which was related to fiscal 2019 and fiscal 2020 and recorded discretely in the first quarter of fiscal 2021, was not significant.

[0001728949-21-000066:mdna:64]
[same as prior period, unchanged from 0001728949-21-000043:mdna:72]

[0001728949-21-000066:mdna:65]
The following should be read in conjunction with our financial results for the third quarter and first nine months of fiscal 2021 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0001728949-21-000066:mdna:66]
[same as prior period, unchanged from 0001728949-21-000043:mdna:74]

[0001728949-21-000066:mdna:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | Change |  | June 27,2021 |  | June 28,2020 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets (1) | $ | 3,863 |  |  | $ | 2,457 |  |  | $ | 1,406 |  |  | $ | 12,144 |  |  | $ | 7,461 |  |  | $ | 4,683 |  |
| RFFE (2) | 957 |  |  | 447 |  |  | 510 |  |  | 2,921 |  |  | 1,509 |  |  | 1,412 |  |
| Automotive (3) | 253 |  |  | 138 |  |  | 115 |  |  | 705 |  |  | 456 |  |  | 249 |  |
| IoT (internet of things) (4) | 1,399 |  |  | 765 |  |  | 634 |  |  | 3,517 |  |  | 2,100 |  |  | 1,417 |  |
| Total revenues | $ | 6,472 |  |  | $ | 3,807 |  |  | $ | 2,665 |  |  | $ | 19,287 |  |  | $ | 11,526 |  |  | $ | 7,761 |  |
| EBT (5) | $ | 1,795 |  |  | $ | 603 |  |  | $ | 1,192 |  |  | $ | 5,299 |  |  | $ | 1,748 |  |  | $ | 3,551 |  |
| EBT as a % of revenues | 28 | % |  | 16 | % |  | 12 points |  | 27 | % |  | 15 | % |  | 12 points |

[0001728949-21-000066:mdna:68]
[same as prior period, unchanged from 0001728949-21-000043:mdna:76]

[0001728949-21-000066:mdna:69]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in handsets) and excludes radio frequency transceiver components.

[0001728949-21-000066:mdna:70]
(3) Includes revenues from products sold for use in automobiles, including telematics, connectivity and infotainment (also known as digital cockpit).

[0001728949-21-000066:mdna:71]
(4) Primarily includes products sold for use in the following industry segments and applications: consumer (including computing, voice and music and XR), industrial (including handhelds, retail, transportation and logistics, and utilities) and edge networking (including mobile broadband and wireless access points).

[0001728949-21-000066:mdna:72]
[same as prior period, unchanged from 0001728949-21-000043:mdna:80]

[0001728949-21-000066:mdna:73]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $6.4 billion and $3.8 billion in the third quarter of fiscal 2021 and 2020, respectively, and $19.0 billion and $11.3 billion in the first nine months of fiscal 2021 and 2020, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our stand-alone Mobile Data Modems, Snapdragon platforms (which include processors and modems), radio frequency transceiver, power management and wireless connectivity integrated chipsets.

[0001728949-21-000066:mdna:74]
QCT results for the third quarter and first nine months of fiscal 2021 compared to the prior year reflect a recovery from the negative impacts of COVID-19.

[0001728949-21-000066:mdna:75]
Third quarter 2021 vs. 2020

[0001728949-21-000066:mdna:76]
The increase in QCT revenues in the third quarter of fiscal 2021 was primarily due to:

[0001728949-21-000066:mdna:77]
+    higher handsets revenues, primarily driven by $893 million in higher chipset shipments and $445 million in higher revenues per chipset, both of which were primarily due to an increase in demand for 5G products from Apple and other major OEMs

[0001728949-21-000066:mdna:78]
+    higher RFFE revenues, primarily driven by an increase in demand for 4G/5G products from major OEMs

[0001728949-21-000066:mdna:79]
[same as prior period, unchanged from 0001728949-21-000043:mdna:95]

[0001728949-21-000066:mdna:80]
+    higher IoT revenues, primarily driven by an increase in demand across consumer, edge networking and industrial

[0001728949-21-000066:mdna:81]
QCT EBT as a percentage of revenues increased in the third quarter of fiscal 2021 primarily due to:

[0001728949-21-000066:mdna:82]
[same as prior period, unchanged from 0001728949-21-000043:mdna:89]

[0001728949-21-000066:mdna:83]
[same as prior period, unchanged from 0001728949-21-000043:mdna:90]

[0001728949-21-000066:mdna:84]
First nine months 2021 vs. 2020

[0001728949-21-000066:mdna:85]
The increase in QCT revenues in the first nine months of fiscal 2021 was primarily due to:

[0001728949-21-000066:mdna:86]
+    higher handsets revenues, primarily driven by $3.2 billion in higher chipset shipments and $1.3 billion in higher revenues per chipset, both of which were primarily due to an increase in demand for 5G products from Apple and other major OEMs

[0001728949-21-000066:mdna:87]
[same as prior period, unchanged from 0001728949-21-000043:mdna:94]

[0001728949-21-000066:mdna:88]
+    higher automotive revenues, primarily driven by an increase in demand for telematics and infotainment products

[0001728949-21-000066:mdna:89]
+    higher IoT revenues, primarily driven by an increase in demand across consumer, edge networking and industrial

[0001728949-21-000066:mdna:90]
QCT EBT as a percentage of revenues increased in the first nine months of fiscal 2021 primarily due to:

[0001728949-21-000066:mdna:91]
[same as prior period, unchanged from 0001728949-21-000043:mdna:99]

[0001728949-21-000066:mdna:92]
-    higher operating expenses, primarily driven by higher research and development expenses

[0001728949-21-000066:mdna:93]
[same as prior period, unchanged from 0001728949-21-000043:mdna:102]

[0001728949-21-000066:mdna:94]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | Change |  | June 27,2021 |  | June 28,2020 |  | Change |
| Licensing revenues | $ | 1,489 |  |  | $ | 1,044 |  |  | $ | 445 |  |  | $ | 4,762 |  |  | $ | 3,520 |  |  | $ | 1,242 |  |
| EBT | 1,053 |  |  | 646 |  |  | 407 |  |  | 3,514 |  |  | 2,335 |  |  | 1,179 |  |
| EBT as a % of revenues | 71 | % |  | 62 | % |  | 9 points |  | 74 | % |  | 66 | % |  | 8 points |

[0001728949-21-000066:mdna:95]
As a result of the global patent license agreement entered into with Huawei in July 2020, QTL results for the first nine months of fiscal 2021 included revenues for royalties due on sales made by Huawei in the December 2020, March 2021 and June 2021 quarters. We did not record any revenues in the first nine months of fiscal 2020 for royalties due on the sales of Huawei’s consumer wireless products.

[0001728949-21-000066:mdna:96]
Third quarter 2021 vs. 2020

[0001728949-21-000066:mdna:97]
The increase in QTL licensing revenues in the third quarter of fiscal 2021 was primarily due to:

[0001728949-21-000066:mdna:98]
+    $380 million in higher estimated sales of 3G/4G/5G-based multimode products, primarily due to a recovery from the negative impacts of COVID-19 and, to a lesser extent, due to the new license agreement with Huawei

[0001728949-21-000066:mdna:99]
+    $77 million in higher estimated revenues per unit, primarily due to favorable mix

[0001728949-21-000066:mdna:100]
QTL EBT as a percentage of revenues increased in the third quarter of fiscal 2021 primarily due to:

[0001728949-21-000066:mdna:101]
[same as prior period, unchanged from 0001728949-21-000043:mdna:111]

[0001728949-21-000066:mdna:102]
-    higher operating expenses, primarily driven by higher research and development expenses

[0001728949-21-000066:mdna:103]
First nine months 2021 vs. 2020

[0001728949-21-000066:mdna:104]
The increase in QTL licensing revenues in the first nine months of fiscal 2021 was primarily due to:

[0001728949-21-000066:mdna:105]
+    $1.2 billion in higher estimated sales of 3G/4G/5G-based multimode products, primarily due to a recovery from the negative impacts of COVID-19 and, to a lesser extent, due to the new license agreement with Huawei

[0001728949-21-000066:mdna:106]
+    $190 million in higher estimated revenues per unit, primarily due to favorable mix

[0001728949-21-000066:mdna:107]
-    $109 million in lower royalty revenues related to devices sold in prior periods

[0001728949-21-000066:mdna:108]
QTL EBT as a percentage of revenues increased in the first nine months of fiscal 2021 primarily due to:

[0001728949-21-000066:mdna:109]
[same as prior period, unchanged from 0001728949-21-000043:mdna:119]

[0001728949-21-000066:mdna:110]
-    higher operating expenses, primarily driven by higher research and development expenses

[0001728949-21-000066:mdna:111]
[same as prior period, unchanged from 0001728949-21-000043:mdna:121]

[0001728949-21-000066:mdna:112]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | Change |  | June 27,2021 |  | June 28,2020 |  | Change |
| Equipment and services revenues | $ | 11 |  |  | $ | 3 |  |  | $ | 8 |  |  | $ | 30 |  |  | $ | 33 |  |  | $ | (3) |  |
| EBT | 156 |  |  | 153 |  |  | 3 |  |  | 412 |  |  | (58) |  |  | 470 |  |

[0001728949-21-000066:mdna:113]
Third quarter 2021 vs. 2020

[0001728949-21-000066:mdna:114]
QSI EBT remained approximately flat in the third quarter of fiscal 2021.

[0001728949-21-000066:mdna:115]
First nine months 2021 vs. 2020

[0001728949-21-000066:mdna:116]
The increase in QSI EBT in the first nine months of fiscal 2021 was primarily due to:

[0001728949-21-000066:mdna:117]
+    $322 million decrease in impairment losses on other investments, of which a significant portion related to our investment in OneWeb

[0001728949-21-000066:mdna:118]
+    $113 million increase in net gains on investments

[0001728949-21-000066:mdna:119]
+    $37 million increase in our share of earnings in equity method investments

[0001728949-21-000066:mdna:120]
[same as prior period, unchanged from 0001728949-21-000043:mdna:71]

[0001728949-21-000066:mdna:121]
[same as prior period, unchanged from 0001728949-21-000043:mdna:132]

[0001728949-21-000066:mdna:122]
[same as prior period, unchanged from 0001728949-21-000043:mdna:133]

[0001728949-21-000066:mdna:123]
[same as prior period, unchanged from 0001728949-21-000043:mdna:134]

[0001728949-21-000066:mdna:124]
•We expect QCT revenues in the fourth quarter of fiscal 2021 to continue to be favorably impacted compared to the prior year due to increased demand across handset, RFFE and IoT revenue streams.

[0001728949-21-000066:mdna:125]
•We have entered into several, and we expect to enter into additional, multi-year capacity purchase commitments with certain suppliers of our integrated circuit products in an effort to secure commitments for future supply, which we expect will allow us to realize benefits from increased demand for integrated circuit products by the end of the calendar year, particularly from certain Chinese OEMs as they continue to position to gain device share.

[0001728949-21-000066:mdna:126]
[same as prior period, unchanged from 0001728949-21-000043:mdna:137]

[0001728949-21-000066:mdna:127]
[same as prior period, unchanged from 0001728949-21-000043:mdna:138]

[0001728949-21-000066:mdna:128]
[same as prior period, unchanged from 0001728949-21-000043:mdna:139]

[0001728949-21-000066:mdna:129]
[same as prior period, unchanged from 0001728949-21-000043:mdna:140]

[0001728949-21-000066:mdna:130]
•The COVID-19 pandemic has resulted in significant economic uncertainty, which resulted in a global recession. While the pandemic has had a negative impact on consumer demand for some devices that incorporate our products and intellectual property, as compared to economic conditions and consumer demand prior to the pandemic, we currently do not expect a significant impact on our results of operations in the future due to COVID-19. The degree to which the COVID-19 pandemic impacts our business, financial condition and results of operations will depend on future developments, which are highly uncertain. See “Risk Factors” in this Quarterly Report, specifically the Risk Factor titled “The coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and may continue to impact us in the future.”

[0001728949-21-000066:mdna:131]
[same as prior period, unchanged from 0001728949-21-000043:mdna:142]

[0001728949-21-000066:mdna:132]
Further discussion of risks related to our business is provided in the section titled “Risk Factors” included in this Quarterly Report.

[0001728949-21-000066:mdna:133]
[same as prior period, unchanged from 0001728949-21-000043:mdna:97]

[0001728949-21-000066:mdna:134]
[same as prior period, unchanged from 0001728949-21-000043:mdna:145]

[0001728949-21-000066:mdna:135]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at June 27, 2021 and September 27, 2020 and for the first nine months of fiscal 2021 and 2020 (in millions):

[0001728949-21-000066:mdna:136]
|  | June 27,2021 |  | September 27,2020 |  | Change |  |  |
| Cash, cash equivalents and marketable securities | $ | 12,907 |  |  | $ | 11,249 |  |  | $ | 1,658 |  |  |  |
| Accounts receivable, net | 2,952 |  |  | 4,003 |  |  | (1,051) |  |  |  |
| Inventories | 3,133 |  |  | 2,598 |  |  | 535 |  |  |  |
| Short-term debt | 2,045 |  |  | 500 |  |  | 1,545 |  |  |  |
| Long-term debt | 13,695 |  |  | 15,226 |  |  | (1,531) |  |  |  |
| Noncurrent income taxes payable | 1,714 |  |  | 1,872 |  |  | (158) |  |  |  |

[0001728949-21-000066:mdna:137]
|  | Nine Months Ended |
|  | June 27,2021 |  | June 28,2020 |  | Change |  |  |
| Net cash provided by operating activities | $ | 9,459 |  |  | $ | 4,073 |  |  | $ | 5,386 |  |  |  |
| Net cash used by investing activities | (3,406) |  |  | (4,925) |  |  | 1,519 |  |  |  |
| Net cash used by financing activities | (5,396) |  |  | (4,871) |  |  | (525) |  |  |  |

[0001728949-21-000066:mdna:138]
The net increase in cash, cash equivalents and marketable securities was primarily due to net cash provided by operating activities, $234 million in proceeds from other investments and $174 million in proceeds from the issuance of common stock (primarily under our Employee Stock Purchase Plan), partially offset by $2.6 billion in payments to repurchase shares of our common stock, $2.2 billion in cash dividends paid, $1.5 billion in capital expenditures, $1.3 billion in cash paid for acquisitions and other investments (primarily related to the acquisition of NUVIA) and $710 million in payments of tax withholdings related to the vesting of share-based awards.

[0001728949-21-000066:mdna:139]
The decrease in accounts receivable was primarily due to payments under the previously disclosed settlement agreement with Huawei. Huawei paid the final installment under such agreement subsequent to June 27, 2021 in accordance with the agreed upon payment schedule. The decrease in accounts receivable was also partially attributable to the timing of collection of payments from certain of our QTL licensees. The increase in inventories was primarily driven by the increase in demand for 5G products.

[0001728949-21-000066:mdna:140]
Debt. At June 27, 2021, we had $15.5 billion of principal floating- and fixed-rate notes outstanding, $1.5 billion of which matures in May 2022. The remaining debt has maturity dates in 2023 through 2050.

[0001728949-21-000066:mdna:141]
We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At June 27, 2021, we had $500 million of commercial paper outstanding.

[0001728949-21-000066:mdna:142]
On December 8, 2020, we entered into a Revolving Credit Facility replacing our prior Amended and Restated Revolving Credit Facility. There were no outstanding borrowings under the Amended and Restated Revolving Credit Facility at the time of termination. The Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At June 27, 2021, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-21-000066:mdna:143]
We expect to issue debt in the future. The amount and timing of such debt will depend on a number of factors, including but not limited to maturities of our existing debt, acquisitions and strategic investments, favorable and/or acceptable interest rates and changes in corporate income tax law. Additional information regarding our outstanding debt is provided in “Notes to Consolidated Financial Statements, Note 6. Debt” in our 2020 Annual Report on Form 10-K.

[0001728949-21-000066:mdna:144]
Income Taxes. At June 27, 2021, we estimated remaining future payments of $1.9 billion for the one-time U.S. repatriation tax accrued in fiscal 2018, after application of certain tax credits, which is payable in installments over the next five years. At June 27, 2021, other current liabilities included $196 million for the next installment due in January 2022. Additional information regarding our income taxes is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes.”

[0001728949-21-000066:mdna:145]
[same as prior period, unchanged from 0001728949-21-000043:mdna:127]

[0001728949-21-000066:mdna:146]
Capital Return Program. In fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. The stock repurchase program has no expiration date. In the first nine months of fiscal 2021, we repurchased and retired 18 million shares of our common stock for $2.6 billion, before commissions. At June 27, 2021, $2.0 billion remained authorized for repurchase under the stock repurchase program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-21-000066:mdna:147]
In the first nine months of fiscal 2021, we paid cash dividends totaling $2.2 billion, or $1.98 per share. On July 14, 2021, we announced a cash dividend of $0.68 per share on our common stock, payable on September 23, 2021 to stockholders of record as of the close of business on September 2, 2021. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-21-000066:mdna:148]
Long-term Capacity Commitments. In the third quarter of fiscal 2021, we entered into several multi-year capacity purchase commitments with certain suppliers of our integrated circuit products. Failure to meet future minimum purchase volumes may result in incremental fees or the loss of amounts paid in advance. We currently expect to meet all future minimum purchase volume commitments in addition to other requirements related to advance and/or ongoing payment obligations. As a result of these arrangements, our future purchase obligation commitments have increased materially since September 27, 2020. As of June 27, 2021, approximately $900 million remained unpaid related to advance and/or ongoing payments under these agreements. We expect an increase in operating cash outflows as we make payment under these arrangements and as we enter into additional agreements with certain suppliers of our integrated circuit products.

[0001728949-21-000066:mdna:149]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2020 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At June 27, 2021, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements or contractual obligations described in our 2020 Annual Report on Form 10-K.

[0001728949-21-000066:mdna:150]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0001728949-21-000066:mdna:151]
[same as prior period, unchanged from 0001728949-21-000043:mdna:160]

[0001728949-21-000066:mdna:152]
[same as prior period, unchanged from 0001728949-21-000043:mdna:161]

[0001728949-21-000066:mdna:153]
[same as prior period, unchanged from 0001728949-21-000043:mdna:162]

[0001728949-21-000066:mdna:154]
[same as prior period, unchanged from 0001728949-21-000043:mdna:163]

[0001728949-21-000066:mdna:155]
You should consider each of the following factors in evaluating our business and our prospects. However, the risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also negatively impact our business, results of operations, cash flows and financial condition, and require significant management time and attention. In that case, the trading price of our common stock could decline. In addition to the risks and uncertainties set forth in the Risk Factor below titled “The coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and may continue to impact us in the future,” many of the risks and uncertainties set forth in the other Risk Factors below could be exacerbated by the COVID-19 pandemic, government and business responses thereto and any further resulting decline in the global business and economic environment, and may be impacted by the extent and speed of the global economic recovery. You should also consider the other information set forth in this Quarterly Report in evaluating our business and our prospects, including but not limited to our financial statements and the related notes, and “Part I, Item 2. Management’s Discussion and Analysis of Financial

[0001728949-21-000066:mdna:156]
[same as prior period, unchanged from 0001728949-21-000043:mdna:144]

[0001728949-21-000066:mdna:157]
Condition and Results of Operations.” References to “and,” “or” and “and/or” should be read to include the others, as appropriate.

[0001728949-21-000066:mdna:158]
[same as prior period, unchanged from 0001728949-21-000043:mdna:165]

[0001728949-21-000066:mdna:159]
[same as prior period, unchanged from 0001728949-21-000043:mdna:166]

[0001728949-21-000066:mdna:160]
The rapid, global spread of COVID-19 and the fear it created resulted in significant economic uncertainty, significant declines in business and consumer confidence and global demand in the wireless industry (among others) and a global economic slowdown, which resulted in a global recession. Specifically, the decline in demand for smartphones and other consumer devices sold by our customers or licensees resulted in decreased demand for our integrated circuit products (which are incorporated into such devices) and a decrease in the royalties we earned on the licensing of our intellectual property (which is dependent upon the number of such devices sold that utilize our intellectual property). However, we currently do not expect a significant impact on our results of operations in the future due to the COVID-19 pandemic.

[0001728949-21-000066:mdna:161]
[same as prior period, unchanged from 0001728949-21-000043:mdna:168]

[0001728949-21-000066:mdna:162]
Although the spread of COVID-19 has caused us to modify our workforce practices, such as having the vast majority of our employees working from home, we have not experienced a significant negative impact to our business or results of operations. However, we could be negatively affected in the future if, among others, a significant number of our employees, or employees who perform critical functions, become ill and/or are quarantined as the result of exposure to COVID-19, or if government policies restrict the ability of those employees to perform their critical functions. For example, we have offices and a significant number of employees located in India, which recently experienced a significant spike in COVID-19 infections.

[0001728949-21-000066:mdna:163]
[same as prior period, unchanged from 0001728949-21-000043:mdna:170]

[0001728949-21-000066:mdna:164]
The degree to which the COVID-19 pandemic impacts our future business, results of operations and financial condition will depend on future developments, which are uncertain, including but not limited to the duration, spread and severity of the pandemic; the availability, adoption and efficacy of vaccines; the spread and severity of variants of COVID-19, and the protection afforded by vaccines against such variants; government responses and other actions to mitigate the spread of and to treat COVID-19; and when and to what extent normal business, economic and social activity and conditions resume. We are similarly unable to predict the extent to which the pandemic impacts our customers, licensees, suppliers and other partners and their financial conditions, but adverse effects on these parties could also adversely affect us. Finally, the COVID-19 pandemic may make it harder for management to estimate the future performance of our business.

[0001728949-21-000066:mdna:165]
[same as prior period, unchanged from 0001728949-21-000043:mdna:172]

[0001728949-21-000066:mdna:166]
[same as prior period, unchanged from 0001728949-21-000043:mdna:173]

[0001728949-21-000066:mdna:167]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on our customers and licensees to develop devices and services based on these technologies with value-added features to drive consumer demand for new 3G/4G and 3G/4G/5G multimode devices, as well as 4G single-mode devices, and to establish the selling prices for such devices. Further, the timing of our shipments of our products is dependent on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries and applications beyond mobile, such as automotive and IoT, among others.

[0001728949-21-000066:mdna:168]
[same as prior period, unchanged from 0001728949-21-000043:mdna:175]

[0001728949-21-000066:mdna:169]
31

[0001728949-21-000066:mdna:170]
[same as prior period, unchanged from 0001728949-21-000043:mdna:176]

[0001728949-21-000066:mdna:171]
Our revenues and growth in revenues could be negatively impacted, our business may be harmed and our substantial investments in these technologies may not provide us an adequate return if: our customers’ and licensees’ revenues and sales of products, particularly premium-tier products, and services using these technologies, and average selling prices of such products, decline due to, for example, the maturity of smartphone penetration in developed regions and China; we do not continue to maintain our intellectual property and technical leadership in 5G; we are unable to drive the adoption of our products into networks and devices, including devices beyond mobile; or consumers’ rates of replacement of smartphones and other computing devices decline.

[0001728949-21-000066:mdna:172]
[same as prior period, unchanged from 0001728949-21-000043:mdna:179]

[0001728949-21-000066:mdna:173]
[same as prior period, unchanged from 0001728949-21-000043:mdna:180]

[0001728949-21-000066:mdna:174]
[same as prior period, unchanged from 0001728949-21-000043:mdna:181]

[0001728949-21-000066:mdna:175]
[same as prior period, unchanged from 0001728949-21-000043:mdna:182]

[0001728949-21-000066:mdna:176]
[same as prior period, unchanged from 0001728949-21-000043:mdna:183]

[0001728949-21-000066:mdna:177]
[same as prior period, unchanged from 0001728949-21-000043:mdna:184]

[0001728949-21-000066:mdna:178]
[same as prior period, unchanged from 0001728949-21-000043:mdna:185]

[0001728949-21-000066:mdna:179]
[same as prior period, unchanged from 0001728949-21-000043:mdna:186]

[0001728949-21-000066:mdna:180]
[same as prior period, unchanged from 0001728949-21-000043:mdna:187]

[0001728949-21-000066:mdna:181]
[same as prior period, unchanged from 0001728949-21-000043:mdna:188]

[0001728949-21-000066:mdna:182]
[same as prior period, unchanged from 0001728949-21-000043:mdna:189]

[0001728949-21-000066:mdna:183]
[same as prior period, unchanged from 0001728949-21-000043:mdna:190]

[0001728949-21-000066:mdna:184]
[same as prior period, unchanged from 0001728949-21-000043:mdna:191]

[0001728949-21-000066:mdna:185]
[same as prior period, unchanged from 0001728949-21-000043:mdna:192]

[0001728949-21-000066:mdna:186]
[same as prior period, unchanged from 0001728949-21-000043:mdna:193]

[0001728949-21-000066:mdna:187]
[same as prior period, unchanged from 0001728949-21-000043:mdna:194]

[0001728949-21-000066:mdna:188]
[same as prior period, unchanged from 0001728949-21-000043:mdna:195]

[0001728949-21-000066:mdna:189]
[same as prior period, unchanged from 0001728949-21-000043:mdna:196]

[0001728949-21-000066:mdna:190]
Competition in any or all product tiers may result in the loss of business or customers, which would negatively impact our business, revenues, results of operations, cash flows and financial condition. Such competition may also reduce average selling prices for our chipset products or the products of our customers and licensees. Certain of these dynamics are

[0001728949-21-000066:mdna:191]
[same as prior period, unchanged from 0001728949-21-000043:mdna:177]

[0001728949-21-000066:mdna:192]
particularly pronounced in emerging regions and China where competitors may have lower cost structures or may have a willingness and ability to accept lower prices or lower margins on their products. Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0001728949-21-000066:mdna:193]
[same as prior period, unchanged from 0001728949-21-000043:mdna:199]

[0001728949-21-000066:mdna:194]
[same as prior period, unchanged from 0001728949-21-000043:mdna:200]

[0001728949-21-000066:mdna:195]
[same as prior period, unchanged from 0001728949-21-000043:mdna:201]

[0001728949-21-000066:mdna:196]
[same as prior period, unchanged from 0001728949-21-000043:mdna:202]

[0001728949-21-000066:mdna:197]
[same as prior period, unchanged from 0001728949-21-000043:mdna:203]

[0001728949-21-000066:mdna:198]
[same as prior period, unchanged from 0001728949-21-000043:mdna:204]

[0001728949-21-000066:mdna:199]
The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or the cancellation of significant purchases by any of these customers, whether due to the use of their own integrated circuit products or our competitors’ integrated circuit products, government restrictions, the COVID-19 pandemic or otherwise, would reduce our revenues and could harm our ability to achieve or sustain expected results of operations, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0001728949-21-000066:mdna:200]
[same as prior period, unchanged from 0001728949-21-000043:mdna:206]

[0001728949-21-000066:mdna:201]
[same as prior period, unchanged from 0001728949-21-000043:mdna:207]

[0001728949-21-000066:mdna:202]
Our industry has also experienced, and we expect it will continue to experience, slowing growth in the premium-tier device segment due to, among other factors, lengthening replacement cycles in developed regions, where premium-tier

[0001728949-21-000066:mdna:203]
smartphones are common; increasing consumer demand in emerging regions where premium-tier smartphones are less common and replacement cycles are on average longer than in developed regions and are continuing to lengthen; and a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and innovation cycles.

[0001728949-21-000066:mdna:204]
[same as prior period, unchanged from 0001728949-21-000043:mdna:210]

[0001728949-21-000066:mdna:205]
[same as prior period, unchanged from 0001728949-21-000043:mdna:211]

[0001728949-21-000066:mdna:206]
[same as prior period, unchanged from 0001728949-21-000043:mdna:212]

[0001728949-21-000066:mdna:207]
[same as prior period, unchanged from 0001728949-21-000043:mdna:213]

[0001728949-21-000066:mdna:208]
[same as prior period, unchanged from 0001728949-21-000043:mdna:214]

[0001728949-21-000066:mdna:209]
[same as prior period, unchanged from 0001728949-21-000043:mdna:215]

[0001728949-21-000066:mdna:210]
[same as prior period, unchanged from 0001728949-21-000043:mdna:216]

[0001728949-21-000066:mdna:211]
[same as prior period, unchanged from 0001728949-21-000043:mdna:217]

[0001728949-21-000066:mdna:212]
[same as prior period, unchanged from 0001728949-21-000043:mdna:218]

[0001728949-21-000066:mdna:213]
Due to various factors, including pressure, encouragement or incentives from, or policies of, the Chinese government (including its Made in China 2025 campaign), concerns over losing access to our integrated circuit products as a result of actual, threatened or potential U.S. or Chinese government actions or policies, including trade protection or national security

[0001728949-21-000066:mdna:214]
policies, or other reasons, some of our Chinese integrated circuit customers have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products in their devices, or use our competitors’ integrated circuit products in their devices, rather than our products.

[0001728949-21-000066:mdna:215]
[same as prior period, unchanged from 0001728949-21-000043:mdna:220]

[0001728949-21-000066:mdna:216]
[same as prior period, unchanged from 0001728949-21-000043:mdna:221]

[0001728949-21-000066:mdna:217]
[same as prior period, unchanged from 0001728949-21-000043:mdna:222]

[0001728949-21-000066:mdna:218]
[same as prior period, unchanged from 0001728949-21-000043:mdna:223]

[0001728949-21-000066:mdna:219]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, alleging that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) attempts by licensees to shift their royalty obligation to their suppliers in order to lower the wholesale (i.e., licensee’s) selling price on which the royalty is calculated.

[0001728949-21-000066:mdna:220]
[same as prior period, unchanged from 0001728949-21-000043:mdna:225]

[0001728949-21-000066:mdna:221]
We have been in the past and are currently subject to various litigation and governmental investigations and proceedings. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable

[0001728949-21-000066:mdna:222]
resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. See also the Risk Factors below titled “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations” and “Our business may suffer as a result of adverse rulings in government investigations or proceedings.”

[0001728949-21-000066:mdna:223]
[same as prior period, unchanged from 0001728949-21-000043:mdna:228]

[0001728949-21-000066:mdna:224]
[same as prior period, unchanged from 0001728949-21-000043:mdna:229]

[0001728949-21-000066:mdna:225]
Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party. Further, SDOs in certain countries may attempt to modify widely accepted standards and claim the resulting standard as their own.

[0001728949-21-000066:mdna:226]
[same as prior period, unchanged from 0001728949-21-000043:mdna:231]

[0001728949-21-000066:mdna:227]
Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations.

[0001728949-21-000066:mdna:228]
As described in the Risk Factor below titled “Our business may suffer as a result of adverse rulings in government investigations or proceedings,” we have been in the past subject to various governmental investigations and legal proceedings challenging our patent licensing (or chipset sales) practices. We are currently subject to certain governmental investigations and/or legal proceedings described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We believe that one intent of certain of these governmental investigations and legal proceedings has been to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property. We may become subject to other governmental investigations or legal proceedings challenging our patent licensing practices in the future.

[0001728949-21-000066:mdna:229]
[same as prior period, unchanged from 0001728949-21-000043:mdna:234]

[0001728949-21-000066:mdna:230]
If we were required to grant patent licenses to chipset manufacturers (which could lead to implementing a more complex, multi-level licensing structure in which we license certain portions of our patent portfolio to chipset manufacturers and other portions to OEMs), we would incur additional transaction costs, which may be significant, and we could incur delays in recognizing revenues until license negotiations were completed. In addition, our licensing revenues and earnings would be negatively impacted if we were not able to obtain, in the aggregate, equivalent revenues under such a multi-level licensing structure.

[0001728949-21-000066:mdna:231]
[same as prior period, unchanged from 0001728949-21-000043:mdna:237]

[0001728949-21-000066:mdna:232]
[same as prior period, unchanged from 0001728949-21-000043:mdna:238]

[0001728949-21-000066:mdna:233]
The continued and future success of our licensing programs requires us to continue to evolve our patent portfolio and to renew or renegotiate license agreements that are expiring.

[0001728949-21-000066:mdna:234]
[same as prior period, unchanged from 0001728949-21-000043:mdna:240]

[0001728949-21-000066:mdna:235]
Our patent license agreements in effect that constitute a significant portion of our licensing revenues are effective for a specified term. To receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms and may impact the financial or other terms of license agreements not subject to the litigation or arbitration. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such licensees.

[0001728949-21-000066:mdna:236]
[same as prior period, unchanged from 0001728949-21-000043:mdna:242]

[0001728949-21-000066:mdna:237]
[same as prior period, unchanged from 0001728949-21-000043:mdna:243]

[0001728949-21-000066:mdna:238]
We have been in the past and are currently subject to various governmental investigations and proceedings. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Key allegations or findings in those matters include or have in the past included, among others, that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers; that our royalty rates are too high; that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions); that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets; that we have entered into exclusive agreements with chipset customers that foreclose competition; that we leverage our position in baseband chipsets in the RFFE space; and that we violate antitrust laws and engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-21-000066:mdna:239]
[same as prior period, unchanged from 0001728949-21-000043:mdna:245]

[0001728949-21-000066:mdna:240]
38

[0001728949-21-000066:mdna:241]
certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any licensing or royalty revenues under such agreements. The renegotiation of license agreements could result in terms which are less favorable to us than existing terms, or lead to arbitration or litigation to resolve the licensing terms, which could also be less favorable to us than existing terms, and each of which could take months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. The occurrence of any of the above could have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies such as 5G. Further, depending on the breadth and severity of the circumstances above, we may have to reduce, suspend or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region.

[0001728949-21-000066:mdna:242]
[same as prior period, unchanged from 0001728949-21-000043:mdna:247]

[0001728949-21-000066:mdna:243]
[same as prior period, unchanged from 0001728949-21-000043:mdna:248]

[0001728949-21-000066:mdna:244]
We depend on a limited number of third-party suppliers for the procurement, manufacture, assembly and testing of our products manufactured in a fabless production model. If we fail to execute supply strategies that provide supply assurance, technology leadership and reasonable margins, our business and results of operations may be harmed. We are also subject to order and shipment uncertainties that could negatively impact our results of operations.

[0001728949-21-000066:mdna:245]
We primarily utilize a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Other than the facilities we own that manufacture certain of our RFFE modules and RF (radio frequency) filter products, we rely on third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. There are a limited number of such third-party suppliers, and even fewer who are capable of manufacturing at the leading process technology nodes or who are willing to operate at older process technology nodes. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Under the turnkey model, our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services such as wafer bump, probe, assembly and the majority of our final test requirements. The semiconductor manufacturing foundries that supply our products are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders.

[0001728949-21-000066:mdna:246]
The following issues related to our third-party suppliers could have an adverse effect on our ability to meet customer demand and negatively impact our revenues, business operations, profitability and cash flows:

[0001728949-21-000066:mdna:247]
[same as prior period, unchanged from 0001728949-21-000043:mdna:252]

[0001728949-21-000066:mdna:248]
[same as prior period, unchanged from 0001728949-21-000043:mdna:253]

[0001728949-21-000066:mdna:249]
[same as prior period, unchanged from 0001728949-21-000043:mdna:254]

[0001728949-21-000066:mdna:250]
•a failure by our suppliers to allocate adequate manufacturing, assembly or test capacity for our products;

[0001728949-21-000066:mdna:251]
[same as prior period, unchanged from 0001728949-21-000043:mdna:256]

[0001728949-21-000066:mdna:252]
[same as prior period, unchanged from 0001728949-21-000043:mdna:257]

[0001728949-21-000066:mdna:253]
[same as prior period, unchanged from 0001728949-21-000043:mdna:258]

[0001728949-21-000066:mdna:254]
[same as prior period, unchanged from 0001728949-21-000043:mdna:259]

[0001728949-21-000066:mdna:255]
[same as prior period, unchanged from 0001728949-21-000043:mdna:260]

[0001728949-21-000066:mdna:256]
•health crises, including epidemics or pandemics, such as the COVID-19 pandemic, and government and business responses thereto, which impact our suppliers, including as a result of quarantines or closure;

[0001728949-21-000066:mdna:257]
•cyber-attacks on our suppliers’ information technology (IT) systems, including those related to their manufacturing foundries or assembly, test or other facilities; and

[0001728949-21-000066:mdna:258]
[same as prior period, unchanged from 0001728949-21-000043:mdna:262]

[0001728949-21-000066:mdna:259]
While we have established alternate suppliers for certain technologies, there are a limited number of such suppliers, and even fewer who are capable of operating at the leading process technology nodes or who are willing to operate at older process technology nodes. We rely on sole- or limited-source suppliers for certain products, which may exacerbate the risks identified above, and subject us to other significant risks, including poor product performance and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established or in the future establish alternate suppliers, these suppliers may require significant amounts of time and levels of support to bring such technologies to production, both of which may increase for complex or leading process technologies. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, the elimination or limitation of a foundry supplier’s ability to manufacture components or products for us due to trade or national security protection policies could increase our vulnerability to sole- or limited-source arrangements and limit or prevent us from procuring critical components or products from those suppliers. Future consolidation of foundry suppliers could also increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions, increase our manufacturing costs and limit the amount of capacity available to us. Our arrangements with our suppliers may obligate us to incur costs to manufacture, assemble and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies (which adds risk to manufacturing yields and reliability), and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Any of the above could negatively impact our business, results of operations and cash flows.

[0001728949-21-000066:mdna:260]
Although we have long-term contracts with our suppliers, some of these contracts do not provide for long-term capacity commitments. To the extent we do not have firm commitments from our suppliers over a specific time period or for any specific quantity, our suppliers may allocate, and in the past have allocated, capacity to the manufacture, assembly and testing of products for their other customers while reducing or limiting capacity to manufacture, assemble or test our products, and such capacity may be limited based on our suppliers’ ability and willingness to invest in the capital required to manufacture in the leading process technologies. Accordingly, capacity for our products may not be available when we need it or at reasonable prices. To the extent we do obtain long-term capacity commitments, we may incur additional costs related to those commitments or make non-refundable payments for capacity commitments that are not used.

[0001728949-21-000066:mdna:261]
[same as prior period, unchanged from 0001728949-21-000043:mdna:265]

[0001728949-21-000066:mdna:262]
In addition, we may not receive reasonable pricing, manufacturing or delivery terms from our suppliers, and our ability to obtain favorable terms may be diminished during times of high demand and/or limited manufacturing capacity for integrated circuit products. We cannot guarantee that the actions of our suppliers will not cause disruptions in our operations

[0001728949-21-000066:mdna:263]
that could harm our ability to meet our delivery obligations to our customers or increase our cost of sales. To the extent we are unable to obtain adequate supply, we may be obligated to make payment to our customers for such shortfalls.

[0001728949-21-000066:mdna:264]
Additionally, we place orders with our suppliers using our and our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates. As we move to smaller geometry process technologies, the manufacturing lead-time increases. As a result, the orders we place with our suppliers are generally only partially covered by commitments from our customers. If we, or our customers, overestimate demand, or if demand is impacted by factors outside of our or our customers’ control, such as the COVID-19 pandemic, and such demand is not covered by a binding commitment from our customers, we may experience increased excess or obsolete inventory, which would negatively impact our results of operations.

[0001728949-21-000066:mdna:265]
Conversely, if we or our customers underestimate demand, or if demand increases significantly and/or rapidly, we have in the past been, currently are and may in the future be unable to obtain, on a timely basis or at all, the additional manufacturing, assembly and test capacity necessary to meet such demand, which could result in lost sales opportunities, reduced revenue growth and harm to our customer relationships. Currently, the global semiconductor industry is experiencing demand for integrated circuits that exceeds the industry’s capacity to meet that demand.

[0001728949-21-000066:mdna:266]
See also the Risk Factor below titled “There are numerous risks associated with the operation and control of our manufacturing facilities, including: a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues” for additional risks that may also be applicable to our third-party suppliers’ manufacturing facilities, which could result in disruptions to our business or additional costs to us, and negatively impact our results of operations.

[0001728949-21-000066:mdna:267]
There are numerous risks associated with the operation and control of our manufacturing facilities, including: a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues.

[0001728949-21-000066:mdna:268]
[same as prior period, unchanged from 0001728949-21-000043:mdna:273]

[0001728949-21-000066:mdna:269]
[same as prior period, unchanged from 0001728949-21-000043:mdna:274]

[0001728949-21-000066:mdna:270]
Climate change concerns and the potential resulting environmental impact may result in new environmental, health and safety laws and regulations that may affect us, our suppliers and our customers. Such laws or regulations could cause us to incur additional direct costs for compliance, including costs associated with changes to manufacturing processes or the procurement of raw materials used in manufacturing processes, as well as increased indirect costs resulting from our customers, suppliers or both incurring additional compliance costs that are passed on to us. These costs may adversely impact our results of operations and financial condition. In addition, climate change could cause certain natural disasters, such as

[0001728949-21-000066:mdna:271]
drought, wildfires, storms, flooding or rising sea levels, to occur more frequently or with greater intensity, which could pose physical risks to our manufacturing facilities or our suppliers’ facilities, could disrupt the availability of water necessary for the operation of our manufacturing facilities or our suppliers’ facilities, and could increase or decrease temperatures resulting in increased operating costs and/or business disruption.

[0001728949-21-000066:mdna:272]
We have manufacturing facilities in Asia and Europe. If tsunamis, flooding, earthquakes, volcanic eruptions, drought or other natural disasters, effects of climate change or geopolitical conflicts, were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, delay production and shipments of inventory and result in costly repairs, replacements or other costs. In addition, natural disasters, effects of climate change or geopolitical conflicts may result in disruptions in transportation, distribution channels and supply chains, and significant increases in the prices of raw materials. Further, health crises, including epidemics or pandemics, such as the COVID-19 pandemic, and government and business responses thereto, could affect our manufacturing facilities, including by resulting in quarantines and/or closures, which would result in disruptions to and potential closures of our manufacturing operations. Our manufacturing operations could also be disrupted by cyber-attacks on our IT systems, as described in the Risk Factor below titled “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0001728949-21-000066:mdna:273]
[same as prior period, unchanged from 0001728949-21-000043:mdna:277]

[0001728949-21-000066:mdna:274]
[same as prior period, unchanged from 0001728949-21-000043:mdna:278]

[0001728949-21-000066:mdna:275]
Finally, we typically begin manufacturing our products using our or our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates and may not be covered by long-term purchase commitments. As a result, we incur inventory and manufacturing costs in advance of anticipated sales, which sales ultimately may not materialize or may be lower than expected. If we or our customers overestimate demand, or if demand is impacted by factors outside of our or our customers’ control such as the COVID-19 pandemic or trade or national security protection policies, that is not under a binding commitment from our customers, we may experience higher inventory carrying and operating costs and/or increased excess or obsolete inventory, which would negatively impact our results of operations.

[0001728949-21-000066:mdna:276]
[same as prior period, unchanged from 0001728949-21-000043:mdna:280]

[0001728949-21-000066:mdna:277]
[same as prior period, unchanged from 0001728949-21-000043:mdna:281]

[0001728949-21-000066:mdna:278]
While we continue to invest significant resources toward advancements primarily in support of 4G- and 5G-based technologies, we also invest in new and expanded product areas, and adjacent industry segments and applications, by utilizing our existing technical and business expertise and through acquisitions or other strategic transactions.

[0001728949-21-000066:mdna:279]
In particular, our future growth depends in part on new and expanded product areas, such as RFFE, and adjacent industry segments and applications beyond mobile, such as automotive and IoT; our ability to develop leading and cost-effective technologies and products for new and expanded product areas, adjacent industry segments and applications; and third parties incorporating our technologies and products into devices used in these product areas, industry segments and applications. Accordingly, we intend to continue to make substantial investments in these new and expanded product areas and adjacent industry segments and applications, and in developing new products and technologies for these product areas, industry segments and applications. Our growth also depends significantly on our ability to develop and patent 5G technologies, and to develop and commercialize products using 5G technologies.

[0001728949-21-000066:mdna:280]
[same as prior period, unchanged from 0001728949-21-000043:mdna:285]

[0001728949-21-000066:mdna:281]
[same as prior period, unchanged from 0001728949-21-000043:mdna:286]

[0001728949-21-000066:mdna:282]
[same as prior period, unchanged from 0001728949-21-000043:mdna:287]

[0001728949-21-000066:mdna:283]
[same as prior period, unchanged from 0001728949-21-000043:mdna:288]

[0001728949-21-000066:mdna:284]
[same as prior period, unchanged from 0001728949-21-000043:mdna:289]

[0001728949-21-000066:mdna:285]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not

[0001728949-21-000066:mdna:286]
derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models, geographic regions, industry segments and applications served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0001728949-21-000066:mdna:287]
[same as prior period, unchanged from 0001728949-21-000043:mdna:292]

[0001728949-21-000066:mdna:288]
[same as prior period, unchanged from 0001728949-21-000043:mdna:293]

[0001728949-21-000066:mdna:289]
[same as prior period, unchanged from 0001728949-21-000043:mdna:294]

[0001728949-21-000066:mdna:290]
Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.

[0001728949-21-000066:mdna:291]
Third parties regularly attempt to gain unauthorized access to our IT systems, and many such attacks are increasingly more sophisticated. The perception that the COVID-19 pandemic has made companies’ IT systems more vulnerable has increased the already significant volume of such attacks. These attacks, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, and impersonating authorized users, among others. We may also be subject to ransom-style cyber-attacks, which could impact our IT systems and cause widespread disruption to our business, including our manufacturing operations, and expose our confidential or propriety information. Third parties that store and/or process our confidential information, or that provide products, software or services used in our IT infrastructure (including applications), may be subject to similar attacks, which could also result in malware being introduced into our IT infrastructure, e.g., through the third parties’ software updates. Such attacks could result in the misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our IT systems. We believe that we have a robust cybersecurity program that is aligned to international cybersecurity frameworks, and that we leverage industry best practices across people, processes and technologies in an attempt to mitigate cybersecurity threats. However, we may not be able to anticipate, detect, repel or implement effective preventative measures against all cybersecurity threats, particularly because the techniques used are increasingly sophisticated and constantly evolving. Attempts to gain unauthorized access to our IT systems or other attacks have in the past, in certain instances and to certain degrees, been successful (but have not caused significant harm), and may in the future be successful, and in some cases, we might be unaware of an incident or its magnitude and effects.

[0001728949-21-000066:mdna:292]
[same as prior period, unchanged from 0001728949-21-000043:mdna:297]

[0001728949-21-000066:mdna:293]
The misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, could harm our competitive position, reduce the value of our investment in research and development and other

[0001728949-21-000066:mdna:294]
strategic initiatives, cause us to lose business, damage our reputation, subject us to legal or regulatory proceedings, cause us to incur other loss or liability and otherwise adversely affect our business. We expect to continue to devote significant resources to the security of our IT systems, and our technology, intellectual property and proprietary and confidential information.

[0001728949-21-000066:mdna:295]
Further, China has implemented, and other countries or regions may implement, cybersecurity laws that require our overall IT security environment to meet certain standards and/or be certified. Such laws may be complex, ambiguous and subject to interpretation, which may create uncertainty regarding compliance. As a result, our efforts to comply with such laws may be expensive and may fail, which could adversely affect our business, results of operations and cash flows.

[0001728949-21-000066:mdna:296]
[same as prior period, unchanged from 0001728949-21-000043:mdna:301]

[0001728949-21-000066:mdna:297]
[same as prior period, unchanged from 0001728949-21-000043:mdna:302]

[0001728949-21-000066:mdna:298]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our intellectual property, including our patent portfolio. Policing unauthorized use of our products, technologies and intellectual property is difficult and time consuming. The steps we have taken have not always prevented, and we cannot be certain the steps we will take in the future will prevent, the misappropriation or unauthorized use of our products, technologies or intellectual property, particularly in foreign countries where the laws may not protect our rights as fully or as readily as U.S. laws or where the enforcement of such laws may be lacking or ineffective. See also the Risk Factor titled “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0001728949-21-000066:mdna:299]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-21-000066:mdna:300]
[same as prior period, unchanged from 0001728949-21-000043:mdna:305]

[0001728949-21-000066:mdna:301]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time

[0001728949-21-000066:mdna:302]
to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0001728949-21-000066:mdna:303]
Additionally, although our license agreements generally provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements. Similarly, we provide access to certain of our intellectual property and proprietary and confidential business information to our direct and indirect customers and licensees, who have in the past and may in the future wrongfully use such intellectual property and information or wrongfully disclose such intellectual property and information to third parties, including our competitors. See also the Risk Factor titled “Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.”

[0001728949-21-000066:mdna:304]
[same as prior period, unchanged from 0001728949-21-000043:mdna:310]

[0001728949-21-000066:mdna:305]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property claims against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products were found to infringe another company’s intellectual property, we could be subject to an injunction or be required to redesign our products, or to license such intellectual property or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products, license such intellectual property used in our products or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling our products. Similarly, our suppliers could be found to infringe another company’s intellectual property, and such suppliers could then be enjoined from providing products or services to us.

[0001728949-21-000066:mdna:306]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products sold by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-21-000066:mdna:307]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing corresponding declines in our chipset or licensing revenues.

[0001728949-21-000066:mdna:308]
Certain legal matters, which may include certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0001728949-21-000066:mdna:309]
46

[0001728949-21-000066:mdna:310]
[same as prior period, unchanged from 0001728949-21-000043:mdna:315]

[0001728949-21-000066:mdna:311]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe that we will continue to see, customers request that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of our products’ source code and may expose our related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of that software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Furthermore, in the course of product development, we may make contributions to third-party open source projects that could subject our intellectual property to adverse licensing conditions. For example, to encourage the growth of a software ecosystem that is interoperable with our products, we may need to contribute certain implementations under the open source licensing terms that govern such projects, which may adversely impact our associated intellectual property. Developing open source products, while adequately protecting the intellectual property upon which our licensing program depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental and third-party scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ adequate controls to protect our intellectual property, our contributions to and use of open source software presents risks that could have an adverse effect on these and on our business.

[0001728949-21-000066:mdna:312]
[same as prior period, unchanged from 0001728949-21-000043:mdna:318]

[0001728949-21-000066:mdna:313]
[same as prior period, unchanged from 0001728949-21-000043:mdna:319]

[0001728949-21-000066:mdna:314]
[same as prior period, unchanged from 0001728949-21-000043:mdna:320]

[0001728949-21-000066:mdna:315]
[same as prior period, unchanged from 0001728949-21-000043:mdna:321]

[0001728949-21-000066:mdna:316]
[same as prior period, unchanged from 0001728949-21-000043:mdna:322]

[0001728949-21-000066:mdna:317]
Our products (including for purposes of this Risk Factor, related software) and the technology we use (which may be developed by us or third parties, and may be designed to meet industry standards) are complex and may contain defects, errors or security vulnerabilities, or experience failures or unsatisfactory performance, due to any number of issues, including issues in materials, design, fabrication, packaging and/or use within a system. Development of products in new domains of technology, such as the transition to 5G, and the migration to integrated circuit technologies with smaller geometric feature sizes, increases complexity and adds risk to manufacturing yields and reliability, and increases the likelihood of product defects, errors or security vulnerabilities. Defects, errors, security vulnerabilities or other unintended functionality could also be introduced into our products by cyber-attacks or other actions by malicious actors, either directly or through third-party products or software used in our products or IT infrastructure (including applications). Further, because of the complexity of our products, defects, errors or security vulnerabilities might only be detected when the products are in use. Risks associated with product or technology defects, errors or security vulnerabilities are exacerbated by the fact that our customers typically integrate our products into consumer and other devices.

[0001728949-21-000066:mdna:318]
The use of devices containing our products to interact with untrusted systems or otherwise access untrusted content creates a risk of exposing the system hardware and software in those devices to malicious attacks. Further, security vulnerabilities in our products or the technologies we use could expose our customers, or end users of our customers’ products, to hackers or other unscrupulous third parties who develop and deploy malware that could attack our products or

[0001728949-21-000066:mdna:319]
[same as prior period, unchanged from 0001728949-21-000043:mdna:308]

[0001728949-21-000066:mdna:320]
our customers’ products or IT infrastructure. Such attacks could result in the disruption of our customers’ businesses or the misappropriation, theft, misuse, disclosure, loss or destruction of the technology or intellectual property, or the proprietary, confidential or personal information, of our customers, their employees or the end users of our customers’ devices. While we continue to focus on this issue and take measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and applications, and increasing the risk of security failures, and techniques used to perpetrate cybersecurity attacks are increasingly sophisticated and constantly evolving. See also the Risk Factor titled “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0001728949-21-000066:mdna:321]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and the end users of such devices, and, potentially, to our customers’ IT infrastructure. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products, repairing or replacing defective products, writing down defective inventory, or indemnification obligations under our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, and losses on unfavorable purchase commitments. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products.

[0001728949-21-000066:mdna:322]
In addition, the occurrence of defects, errors or security vulnerabilities may give rise to product liability claims, particularly if such defects, errors or security vulnerabilities in our products or the technology we use, or the products into which they are integrated, result in personal injury or death, and could result in significant costs, expenses and losses. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the efforts of our technical and management personnel and harm our business, even if we are successful. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. Further, our business liability insurance may be inadequate, or future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as (i) automobiles, including autonomous driver assistance programs; (ii) cameras and artificial intelligence, including home and enterprise security; (iii) home automation, including smoke and noxious gas detectors; (iv) medical condition monitoring; (v) location and asset tracking and management, including wearables for child safety and elderly health; (vi) robotics, including public safety drones and autonomous municipality vehicles; and (vii) extended reality (XR) for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0001728949-21-000066:mdna:323]
[same as prior period, unchanged from 0001728949-21-000043:mdna:328]

[0001728949-21-000066:mdna:324]
[same as prior period, unchanged from 0001728949-21-000043:mdna:329]

[0001728949-21-000066:mdna:325]
[same as prior period, unchanged from 0001728949-21-000043:mdna:330]

[0001728949-21-000066:mdna:326]
[same as prior period, unchanged from 0001728949-21-000043:mdna:331]

[0001728949-21-000066:mdna:327]
A decline in global, regional or local economic conditions or a slow-down in economic growth, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could also have adverse, wide-ranging effects on our business and financial results, including a decrease in demand

[0001728949-21-000066:mdna:328]
48

[0001728949-21-000066:mdna:329]
for our products and technologies; a decrease in demand for the products and services of our customers or licensees; the inability of our suppliers to deliver on their supply commitments to us, our inability to supply our products to our customers and/or the inability of our customers or licensees to supply their products to end users; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our customers or licensees; failures by counterparties; and/or negative effects on wireless device inventories. In addition, our customers’ and licensees’ ability to purchase or pay for our products and intellectual property and network operators’ ability to upgrade their wireless networks could be adversely affected, potentially leading to a reduction, cancellation or delay of orders for our products.

[0001728949-21-000066:mdna:330]
Our stock price and financial results have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and our financial results include those identified above and throughout this Risk Factors section; volatility of the stock market in general and technology and semiconductor companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0001728949-21-000066:mdna:331]
[same as prior period, unchanged from 0001728949-21-000043:mdna:335]

[0001728949-21-000066:mdna:332]
Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). Compliance with, or changes in the interpretation of, existing Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, including, among others, Regulations affecting patent licensing practices; antitrust, competition and competitive business practices; the flow of funds out of certain countries (e.g., China); cybersecurity; import and export regulations, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; protection of intellectual property; trade and trade protection including tariffs; foreign policy and national security; environmental protection, health and safety; supply chain, responsible sourcing, including the use of conflict minerals, and human rights; spectrum availability and license issuance; adoption of standards; taxation; privacy and data protection; labor, employment and human capital; corporate governance; public disclosure; or business conduct, could have an adverse effect on our business and results of operations. See also the Risk Factors titled “Our business may suffer as a result of adverse rulings in government investigations or proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “There are numerous risks associated with the operation and control of our manufacturing facilities, including: a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

[0001728949-21-000066:mdna:333]
[same as prior period, unchanged from 0001728949-21-000043:mdna:337]

[0001728949-21-000066:mdna:334]
[same as prior period, unchanged from 0001728949-21-000043:mdna:338]

[0001728949-21-000066:mdna:335]
Our outstanding debt and any additional debt we incur may have negative consequences on our business, including, among others: requiring us to use cash to pay the principal of and interest on our debt, thereby reducing the amount of cash available for other purposes; limiting our ability to obtain additional financing for working capital, capital expenditures, acquisitions, stock repurchases, dividends, general corporate or other purposes; and limiting our flexibility in planning for, or reacting to, changes in our business, industries or the market. Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to economic and political conditions, industry cycles and financial, business and other factors, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations to service our debt, we may be required to, among other things: refinance or restructure all or a portion of our

[0001728949-21-000066:mdna:336]
49

[0001728949-21-000066:mdna:337]
debt; reduce or delay planned capital or operating expenditures; reduce, suspend or eliminate our dividend payments and/or our stock repurchase program; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing or restructuring are higher than our current rates, interest expense related to such refinancing or restructuring would increase. Further, if there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt financing in the future and the terms of such debt could be adversely affected.

[0001728949-21-000066:mdna:338]
[same as prior period, unchanged from 0001728949-21-000043:mdna:340]

[0001728949-21-000066:mdna:339]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed, as well as countries where we own intellectual property. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-21-000066:mdna:340]
[same as prior period, unchanged from 0001728949-21-000043:mdna:343]

[0001728949-21-000066:mdna:341]
[same as prior period, unchanged from 0001728949-21-000043:mdna:344]

[0001728949-21-000066:mdna:342]
[same as prior period, unchanged from 0001728949-21-000043:mdna:345]
