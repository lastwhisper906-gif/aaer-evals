# QCOM MD&A — 0001234452-17-000190


## mdna

[0001234452-17-000190:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001234452-17-000190:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes included in “Part II, Item 8. Financial Statements and Supplementary Data” of this Annual Report.

[0001234452-17-000190:mdna:3]
Fiscal 2017 Overview

[0001234452-17-000190:mdna:4]
Revenues were $22.3 billion with net income attributable to Qualcomm of $2.5 billion, a decrease of 5% and 57% from fiscal 2016, respectively. Highlights and other events from fiscal 2017 included:

[0001234452-17-000190:mdna:5]
| • | The transition of wireless networks and devices to 3G/4G (CDMA-single mode, OFDMA-single mode and CDMA/OFDMA multi-mode) continued around the world. 3G/4G connections increased to approximately 4.7 billion, up 16% year-over-year, and represent approximately 60% of total mobile connections at the end of fiscal 2017, up from 54% at the end of fiscal 2016.(1) |

[0001234452-17-000190:mdna:6]
| • | We continue to invest significant resources toward advancements primarily in support of 4G OFDMA- and 5G-based technologies as well as other technologies to extend the demand for our products and generate new or expanded licensing opportunities, including within adjacent industry segments outside traditional cellular industries, such as automotive, the Internet of Things (IoT) and networking. |

[0001234452-17-000190:mdna:7]
| • | QCT results were positively impacted by growth in revenues related to adjacent industry segments outside traditional cellular industries, results from our recently formed RF360 Holdings joint venture and cost reduction initiatives achieved under the Strategic Realignment Plan, partially offset by a decline in share at Apple. |

[0001234452-17-000190:mdna:8]
| • | QTL results were negatively impacted by actions taken by Apple and its contract manufacturers, as well as the previously disclosed dispute with another licensee, who underpaid royalties due in the second quarter of fiscal 2017 and did not report or pay royalties due in the third or fourth quarter of fiscal 2017. |

[0001234452-17-000190:mdna:9]
| • | In January 2017, we received a formal written decision from the Korea Fair Trade Commission (KFTC) in connection with its investigation of us, which ordered certain remedial actions and imposed a fine of approximately 1.03 trillion Korean Won (approximately $927 million). The fine was paid in March 2017. |

[0001234452-17-000190:mdna:10]
| • | On October 11, 2017, the Taiwan Fair Trade Commission (TFTC) announced that it had reached a decision in its investigation of us and found us to be in violation of the Taiwan Fair Trade Act. On October 23, 2017, we received the TFTC’s written decision, which prohibits certain conduct, allows for certain competing chip companies and handset manufacturers to request to amend or enter into patent license and other relevant agreements, and imposes a fine of approximately 23.4 billion Taiwan Dollars (approximately $778 million based on the exchange rate at September 24, 2017), which was recorded as a charge to other expense in the fourth quarter of fiscal 2017. |

[0001234452-17-000190:mdna:11]
| • | In May 2017, in connection with the arbitration decision, we entered into a Joint Stipulation Regarding Final Award Agreement with BlackBerry Limited (BlackBerry) and paid to BlackBerry $940 million to cover the award amount, prejudgment interest and attorney’s fees. This amount, which was recorded as a reduction to revenues, also reflected certain amounts that were owed to us by BlackBerry. |

[0001234452-17-000190:mdna:12]
| • | On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings, B.V. (Qualcomm River Holdings), an indirect, wholly owned subsidiary of QUALCOMM Incorporated, will acquire NXP Semiconductors N.V. (NXP). Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration to be paid to NXP’s shareholders of $38 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products. The transaction is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions. While we continue to work to close by the end of calendar 2017, the transaction may close in early 2018. |

[0001234452-17-000190:mdna:13]
| • | In May 2017, we issued an aggregate principal amount of $11.0 billion in nine tranches of unsecured floating- and fixed-rate notes, with maturity dates starting in 2019 through 2047 and effective interest rates between 1.80% and 4.47%. The proceeds are intended to be used to finance, in part, our proposed acquisition of NXP and other related transactions and for general corporate purposes. |

[0001234452-17-000190:mdna:14]
40

[0001234452-17-000190:mdna:15]
| (1) | According to GSMA Intelligence estimates as of October 30, 2017 (estimates excluded Wireless Local Loop). |

[0001234452-17-000190:mdna:16]
Our Business and Operating Segments

[0001234452-17-000190:mdna:17]
We develop and commercialize foundational technologies and products used in mobile devices and other wireless products, including network equipment, broadband gateway equipment and consumer electronics devices. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents, software and other rights.

[0001234452-17-000190:mdna:18]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices, wireless networks, devices used in IoT, broadband gateway equipment, consumer electronic devices and automotive telematics and infotainment systems. QTL grants licenses to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including our mobile health, data center, small cell and other wireless technology and service initiatives.

[0001234452-17-000190:mdna:19]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering, research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001234452-17-000190:mdna:20]
Further information regarding our business and operating segments is provided in “Part I, Item 1. Business” of this Annual Report.

[0001234452-17-000190:mdna:21]
Seasonality. Many of our products and/or intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has tended historically to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons; and because QTL recognizes royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made in the fourth calendar quarter. We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 4G networks by wireless operators and the timing of launches of flagship wireless devices that incorporate our products and/or intellectual property. These trends may or may not continue in the future. These seasonal trends for QTL may be impacted by disputes and/or resolutions with licensees.

[0001234452-17-000190:mdna:22]
Results of Operations

[0001234452-17-000190:mdna:23]
| Revenues (in millions) |  |  |  |  |  |
|  | 2017 |  | 2016 |  | 2015 |  | 2017 vs. 2016 Change |  | 2016 vs. 2015 Change |
| Equipment and services | $ | 16,647 |  |  | $ | 15,467 |  |  | $ | 17,079 |  |  | $ | 1,180 |  |  | $ | (1,612 | ) |
| Licensing | 5,644 |  |  | 8,087 |  |  | 8,202 |  |  | (2,443 | ) |  | (115 | ) |
|  | $ | 22,291 |  |  | $ | 23,554 |  |  | $ | 25,281 |  |  | $ | (1,263 | ) |  | $ | (1,727 | ) |

[0001234452-17-000190:mdna:24]
The increase in equipment and services revenues in fiscal 2017 is primarily due to an increase in QCT revenues of $1.13 billion and an increase in QSI revenues of $66 million. The decrease in equipment and services revenues in fiscal 2016 was primarily due to a decrease in QCT revenues of $1.76 billion, partially offset by increases in revenues of one of our nonreportable segments and our QSI segment of $56 million and $43 million, respectively. The decrease in licensing revenues in fiscal 2017 was primarily due to the decrease in QTL revenues, the reduction to licensing revenues of $962 million related to the BlackBerry arbitration and a $103 million decrease in revenues of one of our nonreportable segments. The decrease in licensing revenues in fiscal 2016 was primarily due to the decrease in QTL revenues, partially offset by a $143 million increase in revenues of one our nonreportable segments.

[0001234452-17-000190:mdna:25]
In fiscal 2017, 2016 and 2015, revenues from suppliers to Apple Inc. and from Samsung Electronics each comprised more than 10% of consolidated revenues. Combined revenues from GuangDong OPPO Mobile Telecommunications Corp. Ltd. and vivo Communication Technology Co., Ltd., and their respective affiliates, also comprised more than 10% of consolidated revenues in fiscal 2017. QCT and QTL segment revenues related to the products of these customers/licensees comprised 51%, 49% and 47% of total consolidated revenues in fiscal 2017, 2016 and 2015, respectively.

[0001234452-17-000190:mdna:26]
41

[0001234452-17-000190:mdna:27]
Revenues from customers in China (including Hong Kong) and South Korea comprised 65% and 16%, respectively, of total consolidated revenues for fiscal 2017, compared to 57% and 17%, respectively, for fiscal 2016, and 53% and 16%, respectively, for fiscal 2015. We report revenues from external customers by country based on the location to which our products or services are delivered, which for QCT is generally the country in which our customers manufacture their products, or for licensing revenues, the invoiced addresses of our licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues would include revenues related to shipments of integrated circuits to a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States.

[0001234452-17-000190:mdna:28]
| Costs and Expenses (in millions) |  |  |  |  |  |
|  | 2017 |  | 2016 |  | 2015 |  | 2017 vs. 2016 Change |  | 2016 vs. 2015 Change |
| Cost of revenues | $ | 9,792 |  |  | $ | 9,749 |  |  | $ | 10,378 |  |  | $ | 43 |  |  | $ | (629 | ) |
| Gross margin | 56 | % |  | 59 | % |  | 59 | % |  |  |  |  |

[0001234452-17-000190:mdna:29]
The margin percentage decreased in fiscal 2017 primarily due to the decrease in higher margin QTL licensing revenues as a proportion of total revenues, partially offset by an increase in QCT margin percentage. The margin percentage in fiscal 2017 was also negatively impacted by the reduction to licensing revenues related to the BlackBerry arbitration. The margin percentage in fiscal 2016 remained flat primarily due to the effect of $163 million in additional charges related to the amortization of intangible assets and the recognition of the step-up of inventories to fair value primarily related to the acquisition of CSR plc in the fourth quarter of fiscal 2015, offset by the impact of higher-margin segment mix primarily related to QTL. Our margin percentage may continue to fluctuate in future periods depending on the mix of segment results as well as products sold, competitive pricing, new product introduction costs and other factors, including disputes and/or resolutions with licensees.

[0001234452-17-000190:mdna:30]
|  | 2017 |  | 2016 |  | 2015 |  | 2017 vs. 2016 Change |  | 2016 vs. 2015 Change |
| Research and development | $ | 5,485 |  |  | $ | 5,151 |  |  | $ | 5,490 |  |  | $ | 334 |  |  | $ | (339 | ) |
| % of revenues | 25 | % |  | 22 | % |  | 22 | % |  |  |  |  |
| Selling, general, and administrative | $ | 2,658 |  |  | $ | 2,385 |  |  | $ | 2,344 |  |  | $ | 273 |  |  | $ | 41 |  |
| % of revenues | 12 | % |  | 10 | % |  | 9 | % |  |  |  |  |
| Other | $ | 1,742 |  |  | $ | (226 | ) |  | $ | 1,293 |  |  | $ | 1,968 |  |  | $ | (1,519 | ) |

[0001234452-17-000190:mdna:31]
The dollar increase in research and development expenses in fiscal 2017 was primarily attributable to an increase of $372 million in costs related to the development of integrated circuit technologies, including 5G technology and RFFE technologies from our recently formed RF360 Holdings joint venture, and related software products, partially offset by cost decreases driven by actions initiated under our Strategic Realignment Plan, which was substantially completed by the end of fiscal 2016. The dollar decrease in research and development expenses in fiscal 2016 was primarily attributable to a decrease of $228 million in cost related to the development of integrated circuit technologies and related software products. Such decrease was primarily driven by actions initiated under the Strategic Realignment Plan, partially offset by increased research and development costs resulting from acquisitions. The decrease in research and development expenses in fiscal 2016 also included decreases of $67 million in development costs of display technologies and $45 million in share-based compensation expense.

[0001234452-17-000190:mdna:32]
The dollar increase in selling, general and administrative expenses in fiscal 2017 was primarily attributable to increases of $136 million in professional services fees, primarily related to third-party acquisition and integration services resulting from the proposed acquisition of NXP, $70 million in costs related to litigation and other legal matters and $33 million in employee-related expenses, primarily related to our recently formed RF360 Holdings joint venture, which closed in February 2017. The dollar increase in selling, general and administrative expenses in fiscal 2016 was primarily attributable to increases of $65 million in costs related to litigation and other legal matters, $39 million in employee-related expenses and $27 million in depreciation and amortization expense, partially offset by decreases of $36 million in share-based compensation expense, $21 million in selling and marketing expenses, $19 million in professional services and $17 million in patent-related costs.

[0001234452-17-000190:mdna:33]
42

[0001234452-17-000190:mdna:34]
Other expenses in fiscal 2017 consisted of a $927 million charge related to the KFTC fine, including related foreign currency losses, a $778 million charge related to the TFTC fine and $37 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan. Other income in fiscal 2016 was attributable to a $380 million gain on the sale of wireless spectrum, partially offset by net charges related to our Strategic Realignment Plan, which included $202 million in restructuring and restructuring-related charges, partially offset by a $48 million gain on the sale of our business that provided augmented reality applications. Other expenses in fiscal 2015 were attributable to a $975 million charge resulting from the resolution reached with the NDRC, charges of $255 million and $11 million for impairment of goodwill and intangible assets, respectively, related to our content and push-to-talk services and display businesses and $190 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan, partially offset by $138 million in gains on sales of certain property plant and equipment.

[0001234452-17-000190:mdna:35]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | 2017 |  | 2016 |  | 2015 |  | 2017 vs. 2016 Change |  | 2016 vs. 2015 Change |
| Interest expense | $ | 494 |  |  | $ | 297 |  |  | $ | 104 |  |  | $ | 197 |  |  | $ | 193 |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 619 |  |  | $ | 611 |  |  | $ | 527 |  |  | $ | 8 |  |  | $ | 84 |  |
| Net realized gains on marketable securities | 456 |  |  | 239 |  |  | 451 |  |  | 217 |  |  | (212 | ) |
| Net realized gains on other investments | 74 |  |  | 49 |  |  | 49 |  |  | 25 |  |  | — |  |
| Impairment losses on marketable securities and other investments | (177 | ) |  | (172 | ) |  | (200 | ) |  | (5 | ) |  | 28 |  |
| Equity in net losses of investees | (74 | ) |  | (84 | ) |  | (32 | ) |  | 10 |  |  | (52 | ) |
| Net losses on foreign currency transactions | (30 | ) |  | — |  |  | — |  |  | (30 | ) |  | — |  |
| Net gains (losses) on derivative instruments | 32 |  |  | (8 | ) |  | 17 |  |  | 40 |  |  | (25 | ) |
| Net gains on deconsolidation of subsidiaries | — |  |  | — |  |  | 3 |  |  | — |  |  | (3 | ) |
|  | $ | 900 |  |  | $ | 635 |  |  | $ | 815 |  |  | $ | 265 |  |  | $ | (180 | ) |

[0001234452-17-000190:mdna:36]
The increase in interest expense in fiscal 2017 was primarily due to the issuance of an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes in May 2017 and fees related to the Bridge and Term Loan Facilities entered into during the first quarter of fiscal 2017. The increase in net realized gains on marketable securities in fiscal 2017 was primarily attributable to certain marketable securities that we sold to fund, in part, our proposed acquisition of NXP. The net losses on foreign currency transactions in fiscal 2017 were primarily attributable to the impact of currency exchange rate movements on certain monetary assets and liabilities of our recently formed RF360 Holdings joint venture.

[0001234452-17-000190:mdna:37]
The increase in interest expense in fiscal 2016 was primarily due to the issuance of an aggregate principal amount of $10.0 billion of unsecured floating- and fixed-rate notes in May 2015.

[0001234452-17-000190:mdna:38]
| Income Tax Expense (in millions) |  |  |  |  |  |
|  | 2017 |  | 2016 |  | 2015 |  | 2017 vs. 2016 Change |  | 2016 vs. 2015 Change |
| Income tax expense | $ | 555 |  |  | $ | 1,131 |  |  | $ | 1,219 |  |  | $ | (576 | ) |  | $ | (88 | ) |
| Effective tax rate | 18 | % |  | 17 | % |  | 19 | % |  | 1 | % |  | (2 | %) |

[0001234452-17-000190:mdna:39]
43

[0001234452-17-000190:mdna:40]
The following table summarizes the primary factors that caused our annual effective tax rates to be less than the United States federal statutory rate:

[0001234452-17-000190:mdna:41]
|  | 2017 |  | 2016 |  | 2015 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (32 | %) |  | (16 | %) |  | (14 | %) |
| Benefits related to the research and development tax credits | (3 | %) |  | (2 | %) |  | (2 | %) |
| Worthless stock deduction of domestic subsidiary | — |  |  | (1 | %) |  | — |  |
| Nondeductible charges related to the KFTC and TFTC investigations | 12 | % |  | — |  |  | — |  |
| Impact of changes in tax reserves and audit settlements for prior year tax positions | 4 | % |  | — |  |  | (1 | %) |
| Other | 2 | % |  | 1 | % |  | 1 | % |
| Effective tax rate | 18 | % |  | 17 | % |  | 19 | % |

[0001234452-17-000190:mdna:42]
In fiscal 2017, we recorded charges of $927 million and $778 million related to the fines imposed by the KFTC and the TFTC, respectively, which are not deductible for tax purposes and are each attributable to both the United States and a foreign jurisdiction. Additionally, the effective tax rate of 18% for fiscal 2017 was impacted by lower United States revenues primarily related to decreased royalty revenues from Apple’s contract manufacturers and the BlackBerry arbitration. The effective tax rate of 18% for fiscal 2017 also reflected the increase in our Singapore tax rate as a result of the expiration of certain of our tax incentives in March 2017, which was substantially offset by tax benefits resulting from the increase in our Singapore tax rate that will be in effect when certain deferred tax assets are scheduled to reverse. The effective tax rate for our state income tax provision, net of federal benefit, was negligible for all years presented.

[0001234452-17-000190:mdna:43]
The effective tax rate of 17% for fiscal 2016 reflected a $101 million tax benefit recorded discretely in the third quarter of fiscal 2016 resulting from a worthless stock deduction on a domestic subsidiary of one of our former display businesses and a $79 million benefit recorded discretely in the first quarter of fiscal 2016 related to fiscal 2015 resulting from the retroactive and permanent reinstatement of the United States federal research and development tax credit.

[0001234452-17-000190:mdna:44]
During fiscal 2015, the NDRC imposed a fine of $975 million, which was not deductible for tax purposes and was substantially attributable to a foreign jurisdiction. Additionally, during fiscal 2015, we recorded a tax benefit of $101 million related to fiscal 2014 resulting from the retroactive reinstatement of the United States federal research and development tax credit to January 1, 2014 through December 31, 2014. The effective tax rate for fiscal 2015 also reflected the United States federal research and development tax credit generated through December 31, 2014, the date on which the credit expired and a $61 million tax benefit as a result of a favorable tax audit settlement with the Internal Revenue Service (IRS) related to Qualcomm Atheros, Inc.’s pre-acquisition 2010 and 2011 tax returns.

[0001234452-17-000190:mdna:45]
The effective tax rate for fiscal 2017, 2016 and 2015 also reflected tax benefits for certain tax incentives obtained in Singapore that commenced in March 2012, including a tax exemption for the first five years, provided that we meet specified employment and other criteria. Our Singapore tax rate increased in fiscal 2017 as a result of the expiration of certain of these incentives and will increase again in fiscal 2027 upon the expiration of the remaining incentives.

[0001234452-17-000190:mdna:46]
Unrecognized tax benefits were $372 million and $271 million at September 24, 2017 and September 25, 2016, respectively. The increase in unrecognized tax benefits in fiscal 2017 was primarily due to tax positions related to transfer pricing. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at September 24, 2017 may increase or decrease in the next 12 months.

[0001234452-17-000190:mdna:47]
We are subject to income taxes in the United States and numerous foreign jurisdictions and are currently under examination by various tax authorities worldwide, most notably in countries where we earn a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of September 24, 2017, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0001234452-17-000190:mdna:48]
44

[0001234452-17-000190:mdna:49]
Our Segment Results

[0001234452-17-000190:mdna:50]
The following should be read in conjunction with the fiscal 2017, 2016 and 2015 results of operations for each reportable segment included in this Annual Report in “Notes to Consolidated Financial Statements, Note 8. Segment Information.”

[0001234452-17-000190:mdna:51]
| (in millions) | 2017 |  | 2016 |  | 2015 |
| Revenues |  |  |  |  |  |
| QCT | $ | 16,479 |  |  | $ | 15,409 |  |  | $ | 17,154 |  |
| QTL | 6,445 |  |  | 7,664 |  |  | 7,947 |  |
| QSI | 113 |  |  | 47 |  |  | 4 |  |
| EBT (1) |  |  |  |  |  |
| QCT | $ | 2,747 |  |  | $ | 1,812 |  |  | $ | 2,465 |  |
| QTL | 5,175 |  |  | 6,528 |  |  | 6,882 |  |
| QSI | 65 |  |  | 386 |  |  | (74 | ) |
| EBT as a % of revenues |  |  |  |  |  |
| QCT | 17 | % |  | 12 | % |  | 14 | % |
| QTL | 80 | % |  | 85 | % |  | 87 | % |

[0001234452-17-000190:mdna:52]
| (1) | Earnings (loss) before taxes. |

[0001234452-17-000190:mdna:53]
QCT Segment. QCT revenues increased in fiscal 2017 and decreased in fiscal 2016 due to corresponding fluctuations in equipment and services revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying RF, Power Management (PM) and wireless connectivity integrated circuits, were $16.31 billion, $15.18 billion and $16.95 billion in fiscal 2017, 2016 and 2015, respectively. Approximately 804 million, 842 million and 932 million MSM integrated circuits were sold during fiscal 2017, 2016 and 2015, respectively.

[0001234452-17-000190:mdna:54]
Equipment and services revenues increased in fiscal 2017 primarily due to an increase in revenues related to RFFE products, including $676 million from the formation of our RF360 Holdings joint venture, a $492 million increase resulting from higher shipments of connectivity products primarily related to adjacent industry segments outside of traditional cellular industries and a $469 million increase resulting from the net impact of higher-priced product mix and lower average selling prices. These increases were partially offset by a decrease of $553 million primarily related to lower MSM and accompanying RF and PM unit shipments driven primarily by a decline in share at Apple, partially offset by higher demand from OEMs in China. The decrease in equipment and services revenues in fiscal 2016 resulted primarily from decreases of $1.35 billion related to lower MSM and accompanying RF and PM unit shipments and $1.14 billion from lower average selling prices and lower-priced product mix, partially offset by a net increase of $753 million in revenues related to other products, primarily related to higher connectivity shipments resulting from the acquisition of CSR in the fourth quarter of fiscal 2015.

[0001234452-17-000190:mdna:55]
QCT EBT as a percentage of revenues increased in fiscal 2017 primarily due to an increase in gross margin percentage, partially offset by a combined increase of 1% in research and development and selling, general and administrative expenses primarily from our RF360 Holdings joint venture. QCT gross margin percentage increased in fiscal 2017 primarily as a result of higher-margin product mix and lower average unit costs, partially offset by lower average selling prices and higher excess inventory charges. QCT EBT as a percentage of revenues decreased in fiscal 2016 primarily due to the impact of lower revenues relative to operating expenses. QCT gross margin percentage remained flat in fiscal 2016 primarily as a result of lower average selling prices and lower-margin product mix, offset by lower average unit costs and lower excess inventory charges.

[0001234452-17-000190:mdna:56]
QCT accounts receivable increased by 24% in fiscal 2017 from $1.46 billion to $1.81 billion, primarily due to the accounts receivable related to our RF360 Holdings joint venture and increased revenues related to integrated circuits. QCT inventories increased by 31% in fiscal 2017 from $1.54 billion to $2.02 billion due to inventories relating to our RF360 Holdings joint venture and an increase in the overall quantity of units on hand, partially offset by lower average unit costs.

[0001234452-17-000190:mdna:57]
QTL Segment. QTL results were negatively impacted by actions taken by Apple and its contract manufacturers as well as the previously disclosed dispute with another licensee, who did not report or pay royalties due in the third or fourth quarter of fiscal 2017. Revenues related to the products of Apple’s contract manufacturers and the other licensee in dispute comprised a total of approximately $1.35 billion in the third and fourth quarters of fiscal 2016. Additionally, QTL revenues were negatively impacted by an estimated amount in excess of $150 million related to the dispute with the other licensee who

[0001234452-17-000190:mdna:58]
underpaid royalties due in the second quarter of fiscal 2017. In addition to the above, the decrease in QTL revenues during fiscal 2017 was also attributable to the recognition of revenues in fiscal 2016 relating to the termination of an infrastructure license agreement resulting from the merger of two licensees and decreased recognition of unearned license fees, partially offset by an increase in revenues per unit and higher royalty revenues recognized related to devices sold in prior periods. QTL EBT as a percentage of revenues decreased in fiscal 2017 as compared to fiscal 2016 primarily due to the decrease in QTL revenues. QTL revenues and EBT in fiscal 2016 and 2017 also continued to be impacted negatively by units that we believe are not being reported by certain other licensees and sales of certain unlicensed products. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing, particularly in emerging regions, including China, and additional litigation may become necessary if negotiations fail to resolve the relevant issues.

[0001234452-17-000190:mdna:59]
The decrease in QTL revenues in fiscal 2016 of $283 million was primarily attributable to decreases in revenues per reported unit and recognition of unearned license fees, partially offset by an increase in reported sales of CDMA-based products (including multimode products that also implement OFDMA) and $266 million in licensing revenues recorded in the second quarter of fiscal 2016 due to the termination of an infrastructure license agreement resulting from the merger of two licensees.

[0001234452-17-000190:mdna:60]
QTL accounts receivable increased by more than 100% in fiscal 2017 from $644 million to $1.74 billion, primarily due to the short payment of royalties reported in the second quarter of fiscal 2017 by, and deemed collectible from, Apple’s contract manufacturers and the timing of the collection of payments from certain of our other licensees.

[0001234452-17-000190:mdna:61]
QSI Segment. The decrease in QSI EBT in fiscal 2017 of $321 million was primarily due to the effect of a $380 million gain on the sale of wireless spectrum recorded in fiscal 2016, partially offset by the net impact of $41 million resulting from higher revenues and costs associated with certain development contracts with one of our equity method investees. The increase in QSI EBT in fiscal 2016 of $460 million was primarily due to a $380 million gain on the sale of wireless spectrum, an increase of $47 million in net realized gains on investments and a decrease of $21 million in impairment losses on investments.

[0001234452-17-000190:mdna:62]
Looking Forward

[0001234452-17-000190:mdna:63]
We expect continued growth in the coming years in consumer demand for 3G, 3G/4G multimode and 4G products and services around the world, driven primarily by smartphones. We also expect growth in new device categories and industries, driven by the expanding adoption of certain technologies that are already commonly used in smartphones by industry segments outside traditional cellular industries, such as automotive, IoT and networking. As we look forward to the next several months and beyond, we expect our business to be impacted by the following key items:

[0001234452-17-000190:mdna:64]
| • | On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings, an indirect, wholly owned subsidiary of QUALCOMM Incorporated, will acquire NXP. Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration to be paid to NXP’s shareholders of $38 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products. The transaction is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions, including the tender of at least 80% of the issued and outstanding common shares of NXP in the offer (provided that the minimum tender threshold may be reduced to a percentage not less than 70% with the prior written consent of NXP). While we continue to work to close by the end of calendar 2017, the transaction may close in early 2018. We intend to fund the transaction with cash generated from our recent debt offering as well as cash held by our foreign entities and use of a Term Loan, which we expect to draw on at close. We expect that this acquisition will continue to require us to devote significant resources and management time and attention and utilize a substantial portion of our cash, cash equivalents and marketable securities. |

[0001234452-17-000190:mdna:65]
| • | Regulatory authorities in certain jurisdictions continue to investigate our business practices, and other regulatory authorities may do so in the future. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business with remedies that include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Additionally, certain of our direct and indirect customers and licensees, including BlackBerry Limited and Apple Inc., have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, including monetary damages. These activities have required and we expect that they will continue to require the investment of significant management time and attention, and |

[0001234452-17-000190:mdna:66]
46

[0001234452-17-000190:mdna:67]
have resulted and we expect that they will continue to result in increased legal costs. See “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies” included in this Annual Report.

[0001234452-17-000190:mdna:68]
| • | We are currently in dispute with Apple surrounding what we believe is an attempt by Apple to reduce the amount of royalties that its contract manufacturers are required to pay to us for use of our intellectual property. QTL revenues and EBT in fiscal 2017 were negatively impacted as a result of actions taken by Apple and its contract manufacturers. Such contract manufacturers did not fully report and did not pay royalties due on sales of Apple products for a portion of the fiscal year. We have taken action against Apple’s contract manufacturers to compel such licensees to pay the required royalties, and against Apple. Additionally, QTL revenues and EBT in fiscal 2017 were negatively impacted by the previously disclosed dispute with another licensee, who did not fully report or fully pay royalties due in the last three quarters of fiscal 2017. We expect these companies will continue to take such actions in the future, resulting in increased legal costs and negatively impacting our future revenues, as well as our financial condition, results of operations and cash flows until the respective disputes are resolved. |

[0001234452-17-000190:mdna:69]
| • | We continue to believe that certain licensees, particularly in China, are not fully complying with their contractual obligations to report their sales of licensed products to us, and certain companies, including unlicensed companies, particularly in emerging regions, including China, are delaying execution of new license agreements. We have made substantial progress in reaching agreements with many companies, primarily in China. However, negotiations with certain licensees and unlicensed companies are ongoing. We believe that the conclusion of new agreements with these companies will result in improved reporting by these licensees, including with respect to sales of three-mode devices (i.e., devices that implement GSM, TD-SCDMA and LTE-TDD) sold in China. Additionally, we believe our increased efforts in the areas of compliance will improve reporting, but will also result in increased costs to the business. Litigation and/or other actions, such as those recently taken against Apple and its contract manufacturers, may be necessary to compel licensees to report and pay the required royalties for sales they have not previously reported and/or to compel unlicensed companies to execute licenses. Such litigation or other actions would result in increased legal costs. |

[0001234452-17-000190:mdna:70]
| • | We expect our business, particularly QCT, to continue to be impacted by industry dynamics, including: |

[0001234452-17-000190:mdna:71]
| • | Concentration of device share among a few companies within the premium tier, resulting in significant supply chain leverage for those companies; |

[0001234452-17-000190:mdna:72]
| • | Decisions by companies to utilize their own internally-developed integrated circuit products and/or sell such products to others, including by bundling with other products, increasing competition; |

[0001234452-17-000190:mdna:73]
| • | Decisions by certain companies to utilize our competitors’ integrated circuit products in all or a portion of their devices. For example, commencing with the iPhone 7 (which was released in September 2016), we are no longer the sole supplier of modems for new iPhone product launches, as Apple utilizes modems from one of our competitors in a portion of such devices. We expect that in the future Apple will utilize our competitors’ modems in a portion of (or potentially all) iPhones. Accordingly, QCT revenues from modem sales for iPhones declined in fiscal 2017 and may continue to decline in the future, in part depending on the extent of Apple’s utilization of competitors’ modems and the mix of the various versions that are sold. Overall QCT revenues, as well as profitability, may similarly decline unless offset by sales of integrated circuit products to other customers, including those outside of traditional cellular industries, such as automotive, IoT and networking. Apple’s dual sourcing does not impact our licensing revenues since our licensing revenues from Apple products are not dependent upon whether such products include our chipsets; |

[0001234452-17-000190:mdna:74]
| • | Intense competition, particularly in China, as our competitors expand their product offerings and/or reduce the prices of their products as part of a strategy to attract new and/or retain existing customers; and |

[0001234452-17-000190:mdna:75]
| • | Lengthening replacement cycles in developed regions, where the smartphone industry is mature, premium-tier smartphones are common and consumer demand is increasingly driven by new product launches and/or innovation cycles, and from increasing consumer demand in emerging regions where premium-tier smartphones are less common and replacement cycles are on average longer than in developed regions. |

[0001234452-17-000190:mdna:76]
| • | Consumer demand for 3G/4G smartphone products is increasing in emerging regions driven by availability of lower-tier 3G/4G devices. We expect the ongoing rollout of 4G services in emerging regions will encourage competition and growth, bringing the benefits of 3G/4G LTE multimode to consumers. |

[0001234452-17-000190:mdna:77]
| • | We continue to invest significant resources toward advancements in 4G LTE and 5G technologies, OFDM-based WLAN technologies, wireless baseband chips, our converged computing/communications (Snapdragon) chips, radio |

[0001234452-17-000190:mdna:78]
47

[0001234452-17-000190:mdna:79]
RFFE, connectivity, power management, graphics, audio and video codecs, multimedia products and software, which contribute to the expansion of our intellectual property portfolio. We are also investing in targeted opportunities that leverage our existing technical and business expertise to deploy new business models and enter and/or expand into new industry segments, such as products for automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), data center, networking, computing and machine learning, among others.

[0001234452-17-000190:mdna:80]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless value chain and governments as to the benefits of our business model and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not welcome the success of our business model in enabling new, highly cost-effective competitors to their products. We expect that such companies, and/or governments or regulators, will continue to challenge our business model in various forums throughout the world.

[0001234452-17-000190:mdna:81]
Further discussion of risks related to our business is presented in “Part I, Item 1A. Risk Factors” included in this Annual Report.

[0001234452-17-000190:mdna:82]
Liquidity and Capital Resources

[0001234452-17-000190:mdna:83]
On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings will acquire NXP. Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration to be paid to NXP’s shareholders of $38 billion. The transaction is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions. While we continue to work to close by the end of calendar 2017, the transaction may close in early 2018. In May 2017, we issued an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes with varying maturities, of which a portion will be used to fund the purchase price and other related transactions. In addition, we have secured $4.0 billion in committed financing through a Term Loan Facility, which is expected to be drawn on at the close of the NXP transaction. The remaining amount will be funded with cash held by our foreign entities, which will result in the use of a substantial portion of our cash, cash equivalents and marketable securities.

[0001234452-17-000190:mdna:84]
Qualcomm River Holdings and NXP may terminate the definitive agreement under certain circumstances. If the definitive agreement is terminated by NXP in certain circumstances, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the definitive agreement is terminated by Qualcomm River Holdings under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion. In November 2016, as required by the definitive agreement, we entered into four letters of credit for an aggregate amount of $2.0 billion pursuant to which NXP will have the right to draw amounts to fund the potential termination fee payable to NXP. Each letter of credit is required to be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. We are restricted from using the funds deposited as collateral while the letters of credit are outstanding. At September 24, 2017, the letters of credit were fully collateralized through bank time deposits and money market funds.

[0001234452-17-000190:mdna:85]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. The following table presents selected financial information related to our liquidity as of and for the years ended September 24, 2017 and September 25, 2016 (in millions):

[0001234452-17-000190:mdna:86]
|  | 2017 |  | 2016 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 38,578 |  |  | $ | 32,350 |  |  | $ | 6,228 |  |  | 19 | % |
| Accounts receivable, net | 3,632 |  |  | 2,219 |  |  | 1,413 |  |  | 64 | % |
| Inventories | 2,035 |  |  | 1,556 |  |  | 479 |  |  | 31 | % |
| Short-term debt | 2,495 |  |  | 1,749 |  |  | 746 |  |  | 43 | % |
| Long-term debt | 19,398 |  |  | 10,008 |  |  | 9,390 |  |  | 94 | % |
| Net cash provided by operating activities | 4,693 |  |  | 7,400 |  |  | (2,707 | ) |  | (37 | %) |
| Net cash provided (used) by investing activities | 18,463 |  |  | (3,488 | ) |  | 21,951 |  |  | N/M |  |
| Net cash provided (used) by financing activities | 5,879 |  |  | (5,522 | ) |  | 11,401 |  |  | N/M |  |

[0001234452-17-000190:mdna:87]
N/M = Not meaningful

[0001234452-17-000190:mdna:88]
The net increase in cash, cash equivalents and marketable securities was primarily due to the proceeds from the issuance of unsecured floating-rate and fixed-rate notes in May 2017 of approximately $10.95 billion, net of underwriting discounts and offering expenses, and net cash provided by operating activities, partially offset by $3.3 billion in cash dividends paid, the deposit of $2.0 billion that was used to collateralize the letters of credit related to our proposed acquisition of NXP, $1.5 billion in payments to fund acquisitions and other investments, primarily related to our recently formed RF360 Holdings joint venture, $1.3 billion in payments to repurchase shares of our common stock and $751 million of net repayments of our outstanding commercial paper debt. Total cash provided by operating activities decreased primarily due to the $940 million payment in connection with the BlackBerry arbitration and the $927 million payment of the fine imposed by the KFTC, as well as changes in working capital related to an increase in accounts receivable and inventories and the timing of related payments. Total cash provided by operating activities was also impacted by actions taken by Apple and its contract manufacturers, as well as the previously disclosed dispute with another licensee, who did not report or pay royalties due in the third or fourth quarter of fiscal 2017.

[0001234452-17-000190:mdna:89]
Our days sales outstanding, on a consolidated basis, increased to 56 days at September 24, 2017 compared to 33 days at September 25, 2016. The increase in accounts receivable and the related days sales outstanding were primarily due to the short payment in the second quarter of fiscal 2017 of royalties reported by and deemed collectible from Apple’s contract manufacturers. We expect these receivables to remain outstanding until we resolve our dispute with Apple. The increase in accounts receivable also resulted from the accounts receivable relating to our RF360 Holdings joint venture, increased revenues related to integrated circuits and the timing of the collection of payments from certain of our other licensees. The increase in inventories was primarily due to inventories relating to our RF360 Holdings joint venture and an increase in the overall quantity of units on hand, partially offset by lower average unit costs.

[0001234452-17-000190:mdna:90]
Our cash, cash equivalents and marketable securities at September 24, 2017 consisted of $9.2 billion held by our United States-based entities and $29.4 billion held by our foreign entities. Most of our cash, cash equivalents and marketable securities held by our foreign entities are indefinitely reinvested and would be subject to material tax effects if repatriated. However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate the funds.

[0001234452-17-000190:mdna:91]
We believe our current cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements, in addition to our proposed acquisition of NXP, also include the items described below.

[0001234452-17-000190:mdna:92]
| • | Our purchase obligations at September 24, 2017, some of which relate to research and development activities and capital expenditures, totaled $4.3 billion and $1.0 billion for fiscal 2018 and 2019, respectively, and $0.5 billion thereafter. |

[0001234452-17-000190:mdna:93]
| • | Our research and development expenditures were $5.5 billion and $5.2 billion during fiscal 2017 and 2016, respectively, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications. |

[0001234452-17-000190:mdna:94]
| • | Cash outflows for capital expenditures were $690 million and $539 million during fiscal 2017 and 2016, respectively. We anticipate that capital expenditures will be higher in fiscal 2018 as compared to fiscal 2017, primarily due to an increase in estimated capital expenditures of approximately $150 million for the full year impact of capital expenditures related to the manufacturing operations of our RF360 Holdings joint venture. We expect to |

[0001234452-17-000190:mdna:95]
49

[0001234452-17-000190:mdna:96]
continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted.

[0001234452-17-000190:mdna:97]
| • | The TFTC imposed a fine on us of approximately 23.4 billion Taiwan Dollars (approximately $778 million based on exchange rates at September 24, 2017), which is due on or before November 7, 2017. |

[0001234452-17-000190:mdna:98]
| • | We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly, to open new opportunities for our technologies, obtain development resources, grow our patent portfolio or pursue new businesses. |

[0001234452-17-000190:mdna:99]
Debt. In November 2016, we amended and restated our existing Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit to increase the aggregate amount available to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. At September 24, 2017, no amounts were outstanding under the Amended and Restated Revolving Credit Facility.

[0001234452-17-000190:mdna:100]
We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At September 24, 2017, we had $999 million of commercial paper outstanding with weighted-average net interest rates of 1.19% and weighted-average remaining days to maturity of 45 days.

[0001234452-17-000190:mdna:101]
In May 2017, we issued an aggregate principal amount of $11.0 billion in nine tranches of unsecured floating- and fixed-rate notes, with maturity dates starting in 2019 through 2047 and effective interest rates between 1.80% and 4.47%. Net proceeds from the issuance of the notes of $10.95 billion are intended to be used to fund a portion of the purchase price of our planned acquisition of NXP and other related transactions and also for general corporate purposes. Our 2019 floating-rate notes, 2020 floating-rate notes, 2019 fixed-rate notes and 2020 fixed-rate notes issued in May 2017 for an aggregate principal amount of $4.0 billion are subject to a special mandatory redemption at a price equal to 101% of the aggregate principal amount, plus accrued and unpaid interest to, but excluding, the date of such mandatory redemption. The redemption is required on the first to occur of (i) the termination of the NXP purchase agreement or (ii) January 25, 2018 (which reflects the automatic extension of the original expiration date of October 27, 2017 in accordance with the NXP purchase agreement, and as such date may be further extended in accordance with the NXP purchase agreement to a date on or prior to June 1, 2018).

[0001234452-17-000190:mdna:102]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, with maturity dates in 2018 through 2045 and effective interest rates between 1.65% and 4.74%. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001234452-17-000190:mdna:103]
In November 2016, we entered into a Term Loan Facility that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion. Proceeds from the Term Loan Facility, if drawn, will be used to finance, in part, the proposed acquisition of NXP. At September 24, 2017, no amounts were outstanding under the Term Loan Facility.

[0001234452-17-000190:mdna:104]
We may issue additional debt in the future. The amount and timing of such additional borrowings will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors. Additional information regarding our outstanding debt at September 24, 2017 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 6. Debt.”

[0001234452-17-000190:mdna:105]
Capital Return Program. The following table summarizes stock repurchases and dividends paid during fiscal 2017, 2016 and 2015 (in millions, except per-share amounts):

[0001234452-17-000190:mdna:106]
|  |  | Stock Repurchase Program |  | Dividends |  | Total |
|  |  | Shares |  | Average Price Paid Per Share |  | Amount |  | Per Share |  | Amount |  | Amount |
| 2017 |  | 22.8 |  |  | $ | 58.87 |  |  | $ | 1,342 |  |  | $ | 2.20 |  |  | $ | 3,252 |  |  | $ | 4,594 |  |
| 2016 |  | 73.8 |  |  | 53.16 |  |  | 3,922 |  |  | 2.02 |  |  | 2,990 |  |  | 6,912 |  |
| 2015 |  | 172.4 |  |  | 65.21 |  |  | 11,245 |  |  | 1.80 |  |  | 2,880 |  |  | 14,125 |  |

[0001234452-17-000190:mdna:107]
On March 9, 2015, we announced that we had been authorized to repurchase up to $15 billion of our common stock. At September 24, 2017, $1.6 billion remained authorized for repurchase under our stock repurchase program. As a result of our proposed acquisition of NXP and the pending use of a substantial portion of our cash, cash equivalents and marketable securities, we currently expect to repurchase shares in the next few years to offset dilution from the issuance of common stock under our employee benefit plans. We periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders.

[0001234452-17-000190:mdna:108]
On October 10, 2017, we announced a cash dividend of $0.57 per share on our common stock, payable on December 15, 2017 to stockholders of record as of the close of business on November 29, 2017. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001234452-17-000190:mdna:109]
Contractual Obligations/Off-Balance Sheet Arrangements

[0001234452-17-000190:mdna:110]
We have no significant contractual obligations not fully recorded on our consolidated balance sheets or fully disclosed in the notes to our consolidated financial statements. We have no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001234452-17-000190:mdna:111]
The following table summarizes the payments due by fiscal period for our outstanding contractual obligations at September 24, 2017 (in millions):

[0001234452-17-000190:mdna:112]
|  | Total |  | 2018 |  | 2019-2020 |  | 2021-2022 |  | Beyond2022 |  | NoExpirationDate |
| Purchase obligations (1) | $ | 5,874 |  |  | $ | 4,348 |  |  | $ | 1,379 |  |  | $ | 147 |  |  | $ | — |  |  | $ | — |  |
| Operating lease obligations | 445 |  |  | 98 |  |  | 184 |  |  | 108 |  |  | 55 |  |  | — |  |
| Capital lease obligations (2) | 44 |  |  | 14 |  |  | 27 |  |  | 3 |  |  | — |  |  | — |  |
| Equity funding and financing commitments (3) | 514 |  |  | 69 |  |  | — |  |  | 69 |  |  | — |  |  | 376 |  |
| Long-term debt (4) | 21,000 |  |  | 1,500 |  |  | 6,000 |  |  | 2,000 |  |  | 11,500 |  |  | — |  |
| Other long-term liabilities (5)(6) | 1,957 |  |  | 308 |  |  | 1,448 |  |  | 62 |  |  | 15 |  |  | 124 |  |
| Total contractual obligations | $ | 29,834 |  |  | $ | 6,337 |  |  | $ | 9,038 |  |  | $ | 2,389 |  |  | $ | 11,570 |  |  | $ | 500 |  |

[0001234452-17-000190:mdna:113]
| (1) | Total purchase obligations included commitments to purchase integrated circuit product inventories of $3.5 billion, $846 million, $286 million, $72 million and $27 million for each of the subsequent five years from fiscal 2018 through 2022, respectively; there were no such purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancelation of outstanding purchase orders is generally allowed but requires payment of all costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization. |

[0001234452-17-000190:mdna:114]
| (2) | Amounts represent future minimum lease payments including interest payments. Capital lease obligations are included in other liabilities in the consolidated balance sheet at September 24, 2017. |

[0001234452-17-000190:mdna:115]
| (3) | Certain of these commitments do not have fixed funding dates and are subject to certain conditions and have, therefore, been presented as having no expiration date. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all. |

[0001234452-17-000190:mdna:116]
| (4) | The amounts noted herein represent contractual payments of principal only. |

[0001234452-17-000190:mdna:117]
| (5) | Certain long-term liabilities reflected on our balance sheet, such as unearned revenues, are not presented in this table because they do not require cash settlement in the future. Other long-term liabilities as presented in this table include the related current portions, as applicable. |

[0001234452-17-000190:mdna:118]
| (6) | Our consolidated balance sheet at September 24, 2017 included $138 million in noncurrent liabilities for uncertain tax positions, some of which may result in cash payment. The future payments related to uncertain tax positions recorded as noncurrent liabilities have not been presented in the table above due to the uncertainty of the amounts and timing of cash settlement with the taxing authorities. |

[0001234452-17-000190:mdna:119]
Additional information regarding our financial commitments at September 24, 2017 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 3. Income Taxes,” “Note 6. Debt” and “Note 7. Commitments and Contingencies.”

[0001234452-17-000190:mdna:120]
Critical Accounting Estimates

[0001234452-17-000190:mdna:121]
The preparation of our consolidated financial statements in accordance with accounting principles generally accepted in the United States requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and disclosure of contingent assets and liabilities. We base our estimates on historical and anticipated results and trends and on various other assumptions that we believe are reasonable under the circumstances, including assumptions as to future events. By their nature, estimates are subject to an inherent degree of uncertainty. Although we believe that our estimates and the assumptions supporting our assessments are reasonable, actual results that differ from our estimates could be material to our consolidated financial statements. A summary of our significant accounting policies is included in this

[0001234452-17-000190:mdna:122]
Annual Report in “Notes to Consolidated Financial Statements, Note 1. The Company and Its Significant Accounting Policies.” We consider the following accounting estimates to be critical in the preparation of our consolidated financial statements.

[0001234452-17-000190:mdna:123]
Impairment of Marketable Securities and Other Investments. We hold investments in marketable securities, with increases and decreases in fair value generally recorded through stockholders’ equity as other comprehensive income or loss. We record impairment losses in earnings when we believe an investment has experienced a decline that is other than temporary. During fiscal 2017, 2016 and 2015, we recorded $131 million, $112 million and $163 million, respectively, in impairment losses on our investments in marketable securities. In connection with the proposed NXP transaction, during fiscal 2017, we divested a substantial portion of our marketable securities portfolio in order to finance, in part, that transaction. Given the change in our intention to sell certain marketable securities, we recognized other-than-temporary impairment losses in fiscal 2017 for such marketable securities and may recognize additional losses prior to the sale of such marketable securities still held at September 24, 2017. For the available-for-sale securities that are not expected to be sold to finance the NXP transaction, we concluded that the gross unrealized losses of $1 million were temporary at September 24, 2017.

[0001234452-17-000190:mdna:124]
We also hold investments in non-marketable equity instruments in privately held companies that are accounted for using either the cost or the equity method. Many of these investments are in early-stage companies, which are inherently risky because the markets for the technologies or products of these companies are uncertain and may never develop. We monitor our investments for events or circumstances that could indicate the investments are impaired, such as a deterioration in the investee’s financial condition and business forecasts and lower valuations in recently completed or proposed financings, and we record impairment losses in earnings when we believe an investment has experienced a decline in value that is other than temporary.

[0001234452-17-000190:mdna:125]
Valuation of Inventories. Inventories are valued at the lower of cost or market (replacement cost, not to exceed net realizable value) using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers, among other things. This valuation also requires us to make judgments and assumptions based on information currently available about market conditions, including competition, product pricing, product life cycle and development plans. If we overestimate demand for our products, the amount of our loss will be impacted by our contractual ability to reduce inventory purchases from our suppliers. Our assumptions of future product demand are inherently uncertain, and changes in our estimates and assumptions may cause us to realize material write-downs in the future.

[0001234452-17-000190:mdna:126]
Valuation of Goodwill and Other Indefinite-Lived and Long-Lived Assets. Our business combinations typically result in the recording of goodwill, other intangible assets and property, plant and equipment, and the recorded values of those assets may become impaired in the future. We also acquire intangible assets and property, plant and equipment in other types of transactions. The determination of the recorded value of intangible assets acquired in a business combination requires management to make estimates and assumptions that affect our consolidated financial statements. For intangible assets acquired in a non-monetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value. An estimate of fair value can be affected by many assumptions that require significant judgment. For example, the income approach generally requires us to use assumptions to estimate future cash flows including those related to total addressable market, pricing and share forecasts, competition, technology obsolescence, future tax rates and discount rates. Our estimate of the fair value of certain assets may differ materially from that determined by others who use different assumptions or utilize different business models and from the future cash flows actually realized.

[0001234452-17-000190:mdna:127]
Goodwill and other indefinite-lived intangible assets are tested annually for impairment and in interim periods if certain events occur indicating that the carrying amounts may be impaired. Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Our judgments regarding the existence of impairment indicators and future cash flows related to goodwill and other indefinite-lived intangible assets and long-lived assets may be based on operational performance of our businesses, market conditions, expected selling price and/or other factors. Although there are inherent uncertainties in this assessment process, the estimates and assumptions we use, including estimates of future cash flows and discount rates, are consistent with our internal planning, when appropriate. If these estimates or their related assumptions change in the future, we may be required to record an impairment charge on a

[0001234452-17-000190:mdna:128]
52

[0001234452-17-000190:mdna:129]
portion or all of our goodwill, other indefinite-lived intangible assets and/or long-lived assets. Furthermore, we cannot predict the occurrence of future impairment-triggering events nor the impact such events might have on our reported asset values. Future events could cause us to conclude that impairment indicators exist and that goodwill or other intangible assets associated with our acquired businesses are impaired. Any resulting impairment loss could have an adverse impact on our financial condition and results of operations. During fiscal 2017, 2016 and 2015, we recorded $76 million, $107 million and $317 million, respectively, in impairment charges for goodwill, other indefinite-lived intangible assets and long-lived assets. The estimated fair values of our QCT and QTL reporting units were substantially in excess of their respective carrying values at September 24, 2017.

[0001234452-17-000190:mdna:130]
Legal and Regulatory Proceedings. We are currently involved in certain legal and regulatory proceedings, and we intend to continue to vigorously defend ourselves. However, the unfavorable resolution of one or more of these proceedings could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. A broad range of remedies with respect to our business practices that are deemed to violate applicable laws are potentially available. These remedies may include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or to modify our business practices. We disclose a loss contingency if there is at least a reasonable possibility that a material loss has been incurred. We record our best estimate of a loss related to pending legal or regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, we record the minimum estimated liability. As additional information becomes available, we assess the potential liability, including the probability of loss related to pending legal or regulatory proceedings, and revise our estimates and update our disclosures accordingly. Significant judgment is required in both the determination of probability and the determination as to whether a loss is reasonably estimable. Revisions in our estimates of the potential liability could materially impact our results of operations.

[0001234452-17-000190:mdna:131]
Income Taxes. We are subject to income taxes in the United States and numerous foreign jurisdictions, and the assessment of our income tax positions involves dealing with uncertainties in the application of complex tax laws and regulations in various taxing jurisdictions. In addition, the application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws and regulations themselves are subject to change as a result of changes in fiscal policy, changes in legislation, the evolution of regulations and court rulings. Significant judgments and estimates are required in determining our provision for income taxes, including those related to tax incentives, intercompany research and development cost-sharing arrangements, transfer pricing and tax credits. While we believe we have appropriate support for the positions taken on our tax returns, we regularly assess the potential outcomes of examinations by taxing authorities in determining the adequacy of our provision for income taxes. Therefore, the actual liability for United States or foreign taxes may be materially different from our estimates, which could result in the need to record additional tax liabilities or potentially reverse previously recorded tax liabilities. We are participating in the Internal Revenue Service (IRS) Compliance Assurance Process program whereby we endeavor to agree with the IRS on the treatment of all issues prior to filing our federal return. A benefit of participation in this program is that post-filing adjustments by the IRS are less likely to occur.

[0001234452-17-000190:mdna:132]
Our QCT segment’s non-United States headquarters is located in Singapore. We obtained tax incentives in Singapore that commenced in March 2012, including a tax exemption for the first five years, provided that we meet specified employment and incentive criteria, and as a result of the expiration of certain of these incentives, our Singapore tax rate increased in fiscal 2017 and will increase again in fiscal 2027 upon the expiration of the remaining incentives. Our failure to meet these criteria could adversely impact our provision for income taxes.

[0001234452-17-000190:mdna:133]
We consider the operating earnings of certain non-United States subsidiaries to be indefinitely reinvested outside the United States based on our plans for use and/or investment outside of the United States and our belief that our sources of cash and liquidity in the United States will be sufficient to meet future domestic cash needs. On a regular basis, we consider projected cash needs for, among other things, potential acquisitions, such as our proposed acquisition of NXP, investments in our existing businesses, future research and development and capital transactions, including repurchases of our common stock, dividends and debt repayments. We estimate the amount of cash or other liquidity that is available or needed in the jurisdictions where these investments are expected as well as our ability to generate cash in those jurisdictions and our access to capital markets. This analysis enables us to conclude whether or not we will indefinitely reinvest the current period’s foreign earnings. We have not recorded a deferred tax liability of approximately $13.7 billion related to the United States federal and state income taxes and foreign withholding taxes on approximately $39.0 billion of undistributed earnings of certain non-United States subsidiaries indefinitely reinvested outside the United States. Should we decide to no longer indefinitely reinvest such earnings outside the United States, for example, if we determine that such earnings are needed to fund future domestic operations or there is not a sufficient need for such earnings outside of the United States, we would have to adjust the income tax provision in the period we make such determination.

[0001234452-17-000190:mdna:134]
Recent Accounting Pronouncements

[0001234452-17-000190:mdna:135]
Information regarding recent accounting pronouncements and the impact of those pronouncements, if any, on our consolidated financial statements is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 1. The Company and Its Significant Accounting Policies.”
