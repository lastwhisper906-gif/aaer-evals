# QCOM notes — 0001234452-17-000190


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001234452-17-000190:notes:1]
Composition of Certain Financial Statement Items

[0001234452-17-000190:notes:2]
| Accounts Receivable (in millions) |  |  |  |
|  | September 24, 2017 |  | September 25, 2016 |
| Trade, net of allowances for doubtful accounts of $11 and $1, respectively | $ | 3,576 |  |  | $ | 2,194 |  |
| Long-term contracts | 40 |  |  | 20 |  |
| Other | 16 |  |  | 5 |  |
|  | $ | 3,632 |  |  | $ | 2,219 |  |

[0001234452-17-000190:notes:3]
Approximately 70% of the increase in accounts receivable was due to the short payment in the second quarter of fiscal 2017 of royalties reported by and deemed collectible from Apple’s contract manufacturers. This same amount is recorded in customer-related liabilities for Apple, since the Company does not have the contractual right to offset these amounts. The remaining increase in accounts receivable resulted from the accounts receivable relating to the Company’s recently formed RF360 Holdings joint venture (Note 9), increased revenues related to integrated circuits and the timing of the collection of payments from certain of the Company’s other licensees.

[0001234452-17-000190:notes:4]
| Inventories (in millions) |  |  |  |
|  | September 24, 2017 |  | September 25, 2016 |
| Raw materials | $ | 103 |  |  | $ | 1 |  |
| Work-in-process | 799 |  |  | 847 |  |
| Finished goods | 1,133 |  |  | 708 |  |
|  | $ | 2,035 |  |  | $ | 1,556 |  |

[0001234452-17-000190:notes:5]
| Property, Plant and Equipment (in millions) | September 24, 2017 |  | September 25, 2016 |
| Land | $ | 195 |  |  | $ | 192 |  |
| Buildings and improvements | 1,595 |  |  | 1,545 |  |
| Computer equipment and software | 1,609 |  |  | 1,426 |  |
| Machinery and equipment | 3,528 |  |  | 2,454 |  |
| Furniture and office equipment | 109 |  |  | 77 |  |
| Leasehold improvements | 310 |  |  | 254 |  |
| Construction in progress | 73 |  |  | 92 |  |
|  | 7,419 |  |  | 6,040 |  |
| Less accumulated depreciation and amortization | (4,203 | ) |  | (3,734 | ) |
|  | $ | 3,216 |  |  | $ | 2,306 |  |

[0001234452-17-000190:notes:6]
Depreciation and amortization expense related to property, plant and equipment for fiscal 2017, 2016 and 2015 was $684 million, $624 million and $625 million, respectively. The gross book values of property under capital leases included in buildings and improvements were negligible at September 24, 2017 and September 25, 2016.

[0001234452-17-000190:notes:7]
Goodwill and Other Intangible Assets. The Company allocates goodwill to its reporting units for annual impairment testing purposes. The following table presents the goodwill allocated to the Company’s reportable and nonreportable segments, as described in Note 8, as well as the changes in the carrying amounts of goodwill during fiscal 2017 and 2016 (in millions):

[0001234452-17-000190:notes:8]
|  | QCT |  | QTL |  | Nonreportable Segments |  | Total |
| Balance at September 27, 2015 | $ | 4,461 |  |  | $ | 718 |  |  | $ | 300 |  |  | $ | 5,479 |  |
| Acquisitions | 172 |  |  | — |  |  | — |  |  | 172 |  |
| Impairments | — |  |  | — |  |  | (17 | ) |  | (17 | ) |
| Other (1) | 41 |  |  | — |  |  | 4 |  |  | 45 |  |
| Balance at September 25, 2016 (2) | 4,674 |  |  | 718 |  |  | 287 |  |  | 5,679 |  |
| Acquisitions | 841 |  |  | 23 |  |  | 11 |  |  | 875 |  |
| Impairments | — |  |  | — |  |  | — |  |  | — |  |
| Other (1) | 66 |  |  | — |  |  | 3 |  |  | 69 |  |
| Balance at September 24, 2017 (2) | $ | 5,581 |  |  | $ | 741 |  |  | $ | 301 |  |  | $ | 6,623 |  |

[0001234452-17-000190:notes:9]
| (1) | Includes changes in goodwill amounts resulting from foreign currency translation, purchase accounting adjustments and, in fiscal 2016, the sale of the Company’s business that provided augmented reality applications. |

[0001234452-17-000190:notes:10]
| (2) | Cumulative goodwill impairments were $537 million at both September 24, 2017 and September 25, 2016. |

[0001234452-17-000190:notes:11]
The components of other intangible assets, net were as follows (in millions):

[0001234452-17-000190:notes:12]
|  | September 24, 2017 |  | September 25, 2016 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |
| Wireless spectrum | $ | 1 |  |  | $ | — |  |  | 20 |  | $ | 2 |  |  | $ | (2 | ) |  | 5 |
| Marketing-related | 77 |  |  | (52 | ) |  | 4 |  | 119 |  |  | (77 | ) |  | 8 |
| Technology-based | 6,413 |  |  | (2,818 | ) |  | 10 |  | 5,900 |  |  | (2,459 | ) |  | 10 |
| Customer-related | 149 |  |  | (33 | ) |  | 9 |  | 21 |  |  | (4 | ) |  | 7 |
|  | $ | 6,640 |  |  | $ | (2,903 | ) |  | 10 |  | $ | 6,042 |  |  | $ | (2,542 | ) |  | 10 |

[0001234452-17-000190:notes:13]
All of these intangible assets are subject to amortization, other than acquired in-process research and development with carrying values of $74 million and $83 million at September 24, 2017 and September 25, 2016, respectively. Amortization expense related to these intangible assets was $777 million, $804 million and $591 million for fiscal 2017, 2016 and 2015, respectively. Amortization expense related to these intangible assets and acquired in-process research and development, beginning upon the expected completion of the underlying projects, is expected to be $780 million, $734 million, $622 million, $507 million and $415 million for each of the subsequent five years from fiscal 2018 through 2022, respectively, and $679 million thereafter.

[0001234452-17-000190:notes:14]
| Other Current Liabilities (in millions) |  |  |  |
|  | September 24, 2017 |  | September 25, 2016 |
| Customer incentives and other customer-related liabilities | $ | 2,804 |  |  | $ | 1,710 |  |
| Accrual for TFTC fine (Note 7) | 778 |  |  | — |  |
| Other | 1,174 |  |  | 551 |  |
|  | $ | 4,756 |  |  | $ | 2,261 |  |

[0001234452-17-000190:notes:15]
Customer incentives and other customer-related liabilities substantially consist of amounts payable to customers for incentive and other arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of the Company’s products and technologies. The corresponding charges for such arrangements were recorded as a reduction to revenues.

[0001234452-17-000190:notes:16]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity during fiscal 2017 were as follows (in millions):

[0001234452-17-000190:notes:17]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Other Gains |  | Total Accumulated Other Comprehensive Income |
| Balance at September 25, 2016 | $ | (161 | ) |  | $ | 6 |  |  | $ | 532 |  |  | $ | 51 |  |  | $ | — |  |  | $ | 428 |  |
| Other comprehensive (loss) income before reclassifications | 309 |  |  | 6 |  |  | (102 | ) |  | (49 | ) |  | 4 |  |  | 168 |  |
| Reclassifications from accumulated other comprehensive income | (1 | ) |  | 11 |  |  | (212 | ) |  | (10 | ) |  | — |  |  | (212 | ) |
| Other comprehensive (loss) income | 308 |  |  | 17 |  |  | (314 | ) |  | (59 | ) |  | 4 |  |  | (44 | ) |
| Balance at September 24, 2017 | $ | 147 |  |  | $ | 23 |  |  | $ | 218 |  |  | $ | (8 | ) |  | $ | 4 |  |  | $ | 384 |  |

[0001234452-17-000190:notes:18]
Reclassifications from accumulated other comprehensive income related to net gains on available-for-sale securities of $201 million, $83 million and $212 million during fiscal 2017, 2016 and 2015, respectively, were recorded in investment and other income, net (Note 2). Reclassifications from accumulated other comprehensive income related to foreign currency translation losses of $21 million during fiscal 2016 were recorded in selling, general and administrative expenses and other operating expenses. Reclassifications from accumulated other comprehensive income related to foreign currency translation adjustments during fiscal 2017 and 2015 were negligible. Reclassifications from accumulated other comprehensive income related to derivative instruments of $10 million for fiscal 2017 were recorded in revenues, cost of revenues, research and development expenses and selling, general and administrative expenses. Reclassifications from accumulated other comprehensive income related to derivative instruments during fiscal 2016 and 2015 were negligible.

[0001234452-17-000190:notes:19]
Other Income, Costs and Expenses. Other expenses in fiscal 2017 consisted of a $927 million charge related to the KFTC fine (Note 7), including related foreign currency losses, a $778 million charge related to the TFTC fine (Note 7) and $37 million in restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan (Note 10).

[0001234452-17-000190:notes:20]
Other income for fiscal 2016 included a gain of $380 million on the sale of wireless spectrum in the United Kingdom that was held by the QSI (Qualcomm Strategic Initiatives) segment in the first quarter of fiscal 2016 for $232 million in cash and $275 million in deferred payments due in 2020 to 2023, which were recorded at their present values in other assets. Other income for fiscal 2016 also included $202 million in restructuring and restructuring-related charges, which were partially offset by a $48 million gain on the sale of the Company’s business that provided augmented reality applications, all of which related to the Company’s Strategic Realignment Plan.

[0001234452-17-000190:notes:21]
On February 9, 2015, the Company announced that it had reached a resolution with the China National Development and Reform Commission (NDRC) regarding its investigation of the Company relating to China’s Anti-Monopoly Law (AML) and the Company’s licensing business and certain interactions between the Company’s licensing business and its semiconductor business. The NDRC issued an Administrative Sanction Decision finding that the Company had violated the AML, and the Company agreed to implement a rectification plan that modified certain of its business practices in China. In addition, the NDRC imposed a fine on the Company of 6.088 billion Chinese renminbi (approximately $975 million), which the Company paid. The Company recorded the amount of the fine in the second quarter of fiscal 2015 in other expenses. Other expenses in fiscal 2015 also included $255 million and $11 million in impairment charges on goodwill and intangible assets, respectively, related to the Company’s content and push-to-talk services and display businesses and $190 million in restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan, partially offset by $138 million in gains on sales of certain property, plant and equipment.

[0001234452-17-000190:notes:22]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |
|  | 2017 |  | 2016 |  | 2015 |
| Interest and dividend income | $ | 619 |  |  | $ | 611 |  |  | $ | 527 |  |
| Net realized gains on marketable securities | 456 |  |  | 239 |  |  | 451 |  |
| Net realized gains on other investments | 74 |  |  | 49 |  |  | 49 |  |
| Impairment losses on marketable securities | (131 | ) |  | (112 | ) |  | (163 | ) |
| Impairment losses on other investments | (46 | ) |  | (60 | ) |  | (37 | ) |
| Net gains (losses) on derivative instruments | 32 |  |  | (8 | ) |  | 17 |  |
| Equity in net losses of investees | (74 | ) |  | (84 | ) |  | (32 | ) |
| Net losses on foreign currency transactions | (30 | ) |  | — |  |  | — |  |
| Net gains on deconsolidation of subsidiaries | — |  |  | — |  |  | 3 |  |
|  | $ | 900 |  |  | $ | 635 |  |  | $ | 815 |  |

[0001234452-17-000190:notes:23]
There were no net impairment losses on marketable securities related to the noncredit portion of losses on debt securities recognized in other comprehensive income in fiscal 2017, and such losses were $37 million and $23 million in fiscal 2016 and 2015, respectively. The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was negligible and $55 million at September 24, 2017 and September 25, 2016, respectively.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001234452-17-000190:notes:24]
The unaudited pro forma results presented below include adjustments for the step-up of inventories to fair value, amortization and depreciation of identified intangible assets and property, plant and equipment, adjustments for certain acquisition-related charges, interest expense related to the Put and Call Option and related tax effects (in millions):

[0001234452-17-000190:notes:25]
|  | (Unaudited) |
|  | 2017 |  | 2016 |
| Pro forma revenues | $ | 22,806 |  |  | $ | 24,731 |  |
| Pro forma net income attributable to Qualcomm | 2,614 |  |  | 5,791 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001234452-17-000190:notes:26]
Acquisitions

[0001234452-17-000190:notes:27]
Completed. On February 3, 2017 (the Closing Date), the Company and TDK Corporation (TDK) completed the formation of a joint venture, under the name RF360 Holdings, to enable delivery of radio frequency front-end (RFFE) modules and radio frequency (RF) filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others. The joint venture is owned 51% by Qualcomm Global Trading Pte. Ltd. (Qualcomm Global Trading), a Singapore corporation and wholly-owned subsidiary of the Company, and 49% by EPCOS AG (EPCOS), a German wholly-owned subsidiary of TDK. RF360 Holdings is a Singapore corporation with research and development and manufacturing and/or sales locations in the United States, Europe and Asia and its headquarters in Munich, Germany. Certain intellectual property, patents and filter and module design and manufacturing assets were carved out of existing TDK businesses and are owned by the joint venture, and certain assets were acquired directly by affiliates of the Company. Qualcomm Global Trading has the option to acquire (and EPCOS has an option to sell) EPCOS’s interest in the joint venture for $1.15 billion (Settlement Amount) 30 months after the Closing Date (the Put and Call Option).

[0001234452-17-000190:notes:28]
EPCOS is entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the Closing Date, which is a substitute for and in lieu of the right of EPCOS to receive any profit sharing, distributions, dividends or other payments of any kind or nature. Such contingent consideration was recorded as a liability at fair value at close based on significant inputs that were not observable, with future changes in fair value recorded in earnings. Such fair value adjustments recorded in fiscal 2017 were negligible.

[0001234452-17-000190:notes:29]
RF360 Holdings is a variable interest entity, and its results of operations and statement of financial position are included in the Company’s consolidated financial statements (on a one-month reporting lag) as the governance structure of RF360 Holdings provides the Company with the power to direct the activities of the joint venture that most significantly impact its economic performance, such as operating decisions related to research and development, manufacturing and sales and marketing of its products. Since the Put and Call Option is considered a financing of the Company’s purchase of EPCOS’s interest in RF360 Holdings, noncontrolling interest is not recorded in the Company’s consolidated financial statements. Therefore, the Put and Call Option was recorded as a liability at fair value at close and included in other noncurrent liabilities. The liability is being accreted to the Settlement Amount, with the offset recorded as interest expense. The carrying value of the Put and Call Option approximated its estimated fair value at September 24, 2017.

[0001234452-17-000190:notes:30]
The total purchase price consisted of the following (in millions):

[0001234452-17-000190:notes:31]
| Cash paid to TDK at close | $ | 1,463 |  |
| Fair value of Put and Call Option | 1,112 |  |
| Fair value of contingent consideration and other deferred payments | 496 |  |
| Total purchase price | $ | 3,071 |  |

[0001234452-17-000190:notes:32]
The Company has not finalized the accounting for this business acquisition related to certain tax matters, and therefore, such amounts are subject to change during the remainder of the one year measurement period. The allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0001234452-17-000190:notes:33]
| Cash and cash equivalents | $ | 306 |  |
| Accounts receivable | 303 |  |
| Inventories | 261 |  |
| Intangible assets subject to amortization: |  |
| Technology-based intangible assets | 738 |  |
| Customer-related intangible assets | 87 |  |
| Marketing-related intangible assets | 8 |  |
| In-process research and development (IPR&D) | 75 |  |
| Property, plant and equipment | 821 |  |
| Goodwill | 829 |  |
| Other assets | 42 |  |
| Total assets | 3,470 |  |
| Liabilities | (399 | ) |
|  | $ | 3,071 |  |

[0001234452-17-000190:notes:34]
The Company recognized $829 million in goodwill related to this transaction, of which $386 million is expected to be deductible for tax purposes. The goodwill recognized was allocated to the QCT segment for annual impairment testing purposes. The goodwill is primarily attributable to the assembled workforce and synergies expected to arise after the acquisition. Each category of intangible assets acquired will be amortized on a straight-line basis over the weighted-average useful lives of seven years for technology-based intangible assets, nine years for customer-related intangible assets and one year for marketing-related intangible assets. At September 24, 2017, the remaining IPR&D of $61 million consisted of two projects, which are expected to be completed over the next year. Upon completion, the IPR&D projects will be amortized over their useful lives, which are estimated to be six years. The estimated fair values of the intangible assets and the property, plant and equipment acquired were primarily determined using the income approach and cost approach, respectively, both of which were based on significant inputs that were not observable.

[0001234452-17-000190:notes:35]
The Company’s results of operations for fiscal 2017 included the operating results of RF360 Holdings on a one-month reporting lag since the date of acquisition, the amounts of which were not material. The following table presents the unaudited pro forma results for fiscal 2017 and fiscal 2016. The unaudited pro forma financial information combines the results of operations of Qualcomm and RF360 Holdings as though the companies had been combined as of the beginning of fiscal 2016. The pro forma information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at such time. The unaudited pro forma results presented below include adjustments for the step-up of inventories to fair value, amortization and depreciation of identified intangible assets and property, plant and equipment, adjustments for certain acquisition-related charges, interest expense related to the Put and Call Option and related tax effects (in millions):

[0001234452-17-000190:notes:36]
During fiscal 2017, the Company acquired three other businesses for total cash consideration of $35 million, net of cash acquired, and up to a total of $94 million in certain contingent payments, which were recorded as a liability at fair value. The Company recognized $47 million in goodwill related to these transactions, of which $12 million is expected to be deductible for tax purposes. Goodwill of $23 million, $12 million and $11 million was assigned to the Company’s QTL, QCT and nonreportable segments, respectively.

[0001234452-17-000190:notes:37]
During fiscal 2016, the Company acquired four businesses for total cash consideration of $392 million, net of cash acquired. Technology-based intangible assets of $257 million were recognized with a weighted-average useful life of four years. The Company recognized $172 million in goodwill related to these transactions, all of which was assigned to the Company’s QCT segment and of which $24 million is expected to be deductible for tax purposes.

[0001234452-17-000190:notes:38]
On August 13, 2015, the Company acquired CSR plc, which was renamed CSR Limited (CSR), for total cash consideration of $2.3 billion (net of $176 million of cash acquired). CSR is an innovator in the development of multifunction semiconductor platforms and technologies for the automotive, consumer and voice and music categories. The acquisition complemented the Company’s current offerings by adding products, channels and customers in the growth categories of the IoT and automotive infotainment. CSR was integrated into the QCT segment. The $2.4 billion total purchase price was allocated as follows: $1.0 billion to amortizable intangible assets, $969 million to goodwill, $182 million to IPR&D and $280 million to other net assets.

[0001234452-17-000190:notes:39]
Goodwill recognized in this transaction is not deductible for tax purposes and was allocated to the QCT segment for annual impairment testing purposes. Goodwill is primarily attributable to synergies expected to arise after the acquisition. Each category of intangible assets acquired are being amortized on a straight-line basis over their weighted-average useful lives of five years for technology-based intangible assets and four years for customer-related and marketing-related intangible assets.

[0001234452-17-000190:notes:40]
The Company’s results of operations for fiscal 2015 included the operating results of CSR since the date of acquisition, the amounts of which were not material. Unaudited pro forma revenues and net income attributable to Qualcomm for fiscal 2015, presenting the results of operations of Qualcomm and CSR as though the companies had been combined as of the beginning of fiscal 2014, were $25.9 billion and $5.2 billion, respectively. This unaudited pro forma information is provided for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place as of the beginning of fiscal 2014.

[0001234452-17-000190:notes:41]
During fiscal 2015, the Company acquired four other businesses for total cash consideration of $405 million, net of cash acquired. Technology-based intangible assets of $84 million were recognized with a weighted-average useful life of eight years. The Company recognized $289 million in goodwill related to these transactions, of which $35 million is expected to be deductible for tax purposes. Goodwill of $29 million, $6 million and $254 million was assigned to the Company’s QCT, QTL and nonreportable segments, respectively.

[0001234452-17-000190:notes:42]
Proposed. On October 27, 2016, the Company announced a definitive agreement under which Qualcomm River Holdings, B.V. (Qualcomm River Holdings), an indirect, wholly owned subsidiary of QUALCOMM Incorporated, will acquire NXP Semiconductors N.V. (NXP). Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration to be paid to NXP’s shareholders of $38 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products.

[0001234452-17-000190:notes:43]
The transaction is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions, including the tender of at least 80% of the issued and outstanding common shares of NXP in the offer (provided that the minimum tender threshold may be reduced to a percentage not less than 70% with the prior written consent of NXP). At an Extraordinary General Meeting of NXP’s shareholders held on January 27, 2017, NXP’s shareholders approved certain matters relating to the transaction, including the appointment of designees of Qualcomm River Holdings to NXP’s board of directors (effective upon the closing of the transaction) and certain transactions that are intended to be consummated after the completion of the tender offer.

[0001234452-17-000190:notes:44]
In May 2017, the Company issued an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes with varying maturities, of which a portion will be used to fund the purchase price and other related transactions. In addition, the Company has secured $4.0 billion in committed financing through a Term Loan Facility, which is expected to be drawn on at the close of the NXP transaction (Note 6). The remaining amount will be funded with cash held by foreign entities.

[0001234452-17-000190:notes:45]
Qualcomm River Holdings and NXP may terminate the definitive agreement under certain circumstances. If the definitive agreement is terminated by NXP in certain circumstances, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the definitive agreement is terminated by Qualcomm River Holdings under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion. In November 2016, as required by the definitive agreement, Qualcomm River Holdings entered into four letters of credit for an aggregate amount of $2.0 billion related to the potential termination fee payable to NXP. Pursuant to the terms of each letter of credit, NXP will have the right to draw amounts to fund certain termination compensation owed by Qualcomm River Holdings to NXP if the definitive agreement is terminated under certain circumstances. The letters of credit expire on June 30, 2018 or if drawn on by NXP or surrendered by Qualcomm River Holdings. Each letter of credit is required to be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. Qualcomm River Holdings is restricted from using the funds deposited as collateral while the letters of credit are outstanding. At September 24, 2017, the letters of credit were fully collateralized through bank time deposits and money market funds, which were recorded as other noncurrent assets.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001234452-17-000190:notes:46]
Cash Equivalents. The Company considers all highly liquid investments with original maturities of 90 days or less to be cash equivalents. Cash equivalents are comprised of money market funds, certificates of deposit, commercial paper, government agencies’ securities, corporate bonds and notes, certain bank time deposits and repurchase agreements fully collateralized by government agencies’ securities. The carrying amounts approximate fair value due to the short maturities of these instruments.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001234452-17-000190:notes:47]
Commitments and Contingencies

[0001234452-17-000190:notes:48]
Legal and Regulatory Proceedings.

[0001234452-17-000190:notes:49]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe certain ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 ParkerVision patents and seeks damages and injunctive and other relief. On December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against the Company and other parties with the United States International Trade Commission (ITC) described below. Subsequently, ParkerVision announced that it had reached a settlement with Samsung which dismissed the Samsung entities from the District Court case. The Company had previously filed Inter-Partes Review petitions with the United States Patent and Trademark Office (USPTO) to invalidate all asserted claims of several of the remaining patents. On March 7, 2017, the USPTO decided in the Company’s favor with respect to all asserted claims of one such patent. After the ITC action described below was closed, and upon agreement among the parties, on May 24, 2017, the District Court further stayed the District Court case pending ParkerVision’s appeals of the USPTO’s invalidation decisions.

[0001234452-17-000190:notes:50]
On December 14, 2015, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. are also named defendants. The complaint asserts that certain of the Company’s products infringe four additional ParkerVision patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. On February 12, 2016, the District Court case was stayed pending completion of the ITC investigation. Subsequently, ParkerVision announced that it had reached a settlement with Samsung which dismissed the Samsung entities from the ITC investigation and related District Court case. On February 2, 2017, the ITC granted ParkerVision’s motion to drop all but one patent and one accused product from the ITC investigation. On March 12, 2017, one day before the ITC hearing was scheduled to begin, ParkerVision moved to withdraw its ITC complaint in its entirety. The Company and the other defendants did not oppose the withdrawal of the complaint. On April 28, 2017, the ITC formally closed the investigation. On May 4, 2017, ParkerVision filed a motion to reopen the related District Court Case, and on May 26, 2017, the District Court granted the motion. On July 19, 2017, the District Court set an approximate date of mid-January 2018 for a claim construction hearing. A trial date has not been set.

[0001234452-17-000190:notes:51]
Apple Inc. (Apple) v. QUALCOMM Incorporated: On January 20, 2017, Apple filed a complaint against the Company in the United States District Court for the Southern District of California seeking declarations with respect to several of the Company’s patents and alleging that the Company breached certain agreements and violated federal antitrust and California state unfair competition laws. In its initial complaint, Apple sought declaratory judgments of non-infringement by Apple of nine of the Company’s patents, or in the alternative, a declaration of royalties Apple must pay for the patents. Apple further sought a declaration that the Company’s sale of baseband chipsets exhausts the Company’s patent rights for patents embodied in those chipsets. Separately, Apple sought to enjoin the Company from seeking excessive royalties from Apple and to disgorge royalties paid by Apple’s contract manufacturers that the court finds were not fair, reasonable and non-discriminatory (FRAND). Apple also claimed that the Company’s refusal to make certain payments to Apple under a Business Cooperation and Patent Agreement (Cooperation Agreement) constitutes a breach of contract in violation of California law and sought damages in the amount of the unpaid payments, alleged to be approximately $1 billion. In addition, Apple claimed that the Company has refused to deal with competitors in contravention of the Company’s agreements with applicable standard setting organizations, has used its market position to impose contractual obligations on Apple that prevented Apple from challenging the Company’s licensing practices, has tied the purchase of the Company’s CDMA-enabled and “premium” LTE-enabled chipsets to licensing certain of the Company’s patents and has required Apple to purchase baseband chipsets exclusively from the Company as a condition of the Company’s payment to Apple of certain rebates, in violation of Section 2 of the Sherman Act and the California Unfair Competition Law. Apple sought injunctive relief with respect to these claims and a judgment awarding its expenses, costs and attorneys’ fees.

[0001234452-17-000190:notes:52]
On April 10, 2017, the Company filed its Answer and Counterclaims (amended on May 24, 2017) in response to Apple’s complaint denying Apple’s claims and asserting claims against Apple. The counterclaims against Apple include tortious interference with the Company’s long-standing Subscriber Unit License Agreements (SULAs) with third-party contract manufacturers of Apple devices, causing those contract manufacturers to withhold certain royalty payments owed to the Company and violate their audit obligations; breach of contract and the implied covenant of good faith and fair dealing relating to the parties’ Cooperation Agreement; unjust enrichment and declaratory relief relating to the Cooperation Agreement; breach of contract based on Apple’s failure to pay amounts owed to the Company under a Statement of Work relating to a high-speed feature of the Company’s chipsets; breach of the parties’ software agreement; and violation of California Unfair Competition Law based on Apple’s threatening the Company to prevent it from promoting the superior performance of the Company’s own chipsets. The Company also seeks declaratory judgments that the Company has satisfied its FRAND commitments with respect to Apple, and that the Company’s SULAs with the contract manufacturers do not violate either competition law or the Company’s FRAND commitments. On June 19, 2017, Apple filed a Partial Motion to Dismiss the Company’s counterclaim for violation of the California Unfair Competition Law. A hearing on that motion was held on October 13, 2017. The court has not yet ruled on the motion. On June 20, 2017, Apple filed an Answer and Affirmative Defenses to the rest of the Company’s counterclaims, and also filed an Amended Complaint reiterating all of the original claims and adding claims for declaratory judgments of invalidity of the nine patents that are subject to declaratory judgment claims in the original complaint, adding new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for nine more patents. Apple also added claims for declaratory judgments that certain of the Company’s agreements are unenforceable. On July 21, 2017, the Company filed an Answer to Apple’s Amended Complaint as well as a motion to dismiss the new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for the nine additional patents. A hearing on that motion was also held on October 13, 2017. The court has not yet ruled on the motion. On July 18, 2017, Apple filed a motion to consolidate this action with QUALCOMM Incorporated v. Compal Electronics, Inc., et al., discussed below, and on September 13, 2017, the court granted that motion.

[0001234452-17-000190:notes:53]
On January 23, 2017, an Apple subsidiary in China filed two complaints against the Company in the Beijing Intellectual Property Court. On March 31, 2017, the court granted an application by Apple Inc. to join the actions as a plaintiff, and Apple amended the complaints. One of the complaints alleges a violation of China’s Anti-Monopoly Law (AML complaint); the other complaint requests a determination of the terms of a patent license between the Company and Apple (FRAND complaint). The AML complaint alleges that (i) the Company has abused its dominant position in communication standard-essential patents licensing markets and certain global baseband chipset markets by charging and offering royalty terms that were excessively high; (ii) the Company refused to license certain implementers of standardized technologies, including Apple and baseband chipset manufacturers; (iii) the Company forced Apple to use only the Company’s products and services; and (iv) the Company bundled licenses to standard-essential patents with licenses to non-standard-essential patents and imposed other unreasonable or discriminatory trading terms on Apple in violation of the AML. The AML complaint seeks a decree that the Company cease the alleged abuse of dominance, as well as damages in the amount of 1 billion Chinese Renminbi (approximately $152 million based on the exchange rate on September 24, 2017). The FRAND complaint makes allegations similar to the AML complaint and further alleges that the Company refused to offer licensing terms for the Company’s cellular standard-essential patents consistent with the Company’s FRAND licensing commitments and failed to provide to Apple certain information about the Company’s patents. The FRAND complaint seeks (i) a declaration that the license terms offered to Apple by the Company for its mobile communication standard essential patents are not compliant with FRAND; (ii) an order that the Company cease its actions that allegedly violate the Company’s FRAND obligations, including pricing on unfair, unreasonable and excessive terms, refusing to deal, imposing unreasonable trade conditions and failing to provide information on the Company’s patents; and (iii) a determination of FRAND-compliant license terms for the Company’s Chinese standard-essential patents. Apple also seeks its expenses in each of the cases. On August 3, 2017, the Company received three additional complaints filed by an Apple subsidiary and Apple Inc. against the Company in the Beijing Intellectual Property Court. The complaints seek declaratory judgments of non-infringement of three Qualcomm patents.

[0001234452-17-000190:notes:54]
On February 16, 2017, Apple and one of its Japanese subsidiaries filed four complaints against the Company in the Tokyo District Court. In three of the complaints, Apple seeks declaratory judgment of non-infringement by Apple of three of the Company’s patents. Apple further seeks a declaration that the Company’s patent rights with respect to those three patents are exhausted by the Company’s SULAs with the contract manufacturers of Apple’s devices as well as the Company’s sale of baseband chipsets. Apple also seeks an award of fees. On May 15, 2017, the Company learned of the fourth complaint. In that complaint, Apple and one of its Japanese subsidiaries seek damages of 100 million Japanese Yen (approximately $1 million based on the exchange rate on September 24, 2017) from the Company based on allegations that the Company violated the Japanese Antimonopoly Act and the Japanese Civil Code. In particular, the fourth complaint alleges that (i) the Company holds a monopoly position in the market for baseband processor chipsets that implement certain cellular standards; (ii) the Company collects double royalties through its license agreements and the sale of chipsets; (iii) the Company refused to grant Apple a license on FRAND terms and forced Apple to execute a rebate agreement under unreasonable conditions; (iv) the Company refused to grant Apple a direct license; and (v) the Company demanded a license fee based on the market value of the total device. The Company has filed answers to all four of the complaints.

[0001234452-17-000190:notes:55]
On March 2, 2017, the Company learned that Apple and certain of its European subsidiaries issued a Claim Form against the Company in the UK High Court of Justice, Chancery Division, Patents Court on January 23, 2017. Apple subsequently filed an Amended Claim Form and Particulars of Claim. Both the Amended Claim Form and the Particulars of Claim allege several European competition law claims, including refusal to license competing chipmakers, failure to offer Apple a direct license to the Company’s standard-essential patents on FRAND terms, demanding excessive royalties for the Company’s standard-essential patents, and demanding excessive license fees for the use of the Company’s standard-essential patents in connection with chipsets purchased from the Company. Apple also seeks declarations that the Company is obliged to offer a direct patent license to Apple in respect of standard-essential patents actually practiced on fair, reasonable and non-discriminatory terms and that using the Company’s chipsets does not infringe any of the Company’s patents because the Company exhausted its patent rights. Finally, Apple seeks declarations that five of the Company’s European (UK) patents are invalid and not essential, and an order that each of those patents be revoked.

[0001234452-17-000190:notes:56]
On April 20, 2017, the Company was informed that on April 18, 2017, Apple and one of its Taiwanese subsidiaries filed a complaint against the Company in the Taiwan Intellectual Property Court alleging that the Company has abused a dominant market position in licensing wireless standard-essential patents and selling baseband chipsets, including improper pricing, refusal to deal, exclusive dealing, tying, imposing unreasonable trade terms and discriminatory treatment. The complaint seeks rulings that the Company not use the sales price of the terminal device as the royalty base for standard-essential patents; not leverage its cellular standard-essential patents to obtain licenses of its non-standard-essential patents or demand cross-licenses without proper compensation; not refuse, reduce, delay or take any other action to limit the supply of its baseband chipsets to non-licensees; that the Company must license its standard-essential patents on FRAND terms; and that the Company shall not, based on standard-essential patents, seek injunctions. The complaint also seeks damages of 10 million Taiwan Dollars (less than $1 million based on the exchange rate on September 24, 2017), among other relief.

[0001234452-17-000190:notes:57]
On July 14, 2017, the Company filed a motion for anti-suit injunction in the United States District Court for the Southern District of California, asking the court to enjoin Apple from pursuing its foreign actions in the UK, China, Japan and Taiwan and from initiating other duplicative foreign actions, while the action in the Southern District of California is pending. On September 7, 2017, the court denied this motion.

[0001234452-17-000190:notes:58]
The Company believes Apple’s claims in the above matters are without merit.

[0001234452-17-000190:notes:59]
QUALCOMM Incorporated v. Compal Electronics, Inc. et al.: On May 17, 2017, the Company filed a complaint in the United States District Court for the Southern District of California against Compal Electronics, Inc. (Compal), FIH Mobile, Ltd., Hon Hai Precision Industry Co., Ltd. (together with FIH Mobile, Ltd., Foxconn), Pegatron Corporation (Pegatron) and Wistron Corporation (Wistron) asserting claims for injunctive relief, specific performance, declaratory relief and damages stemming from the defendants’ breach of contracts by ceasing the payment of royalties for iPhones and other devices which they manufacture for Apple. On May 24, 2017, the Company filed a Motion for Preliminary Injunction seeking to enjoin each of the defendants from violating their license agreements during the pendency of the litigation. On July 17, 2017, Compal, Foxconn, Pegatron and Wistron each filed third-party complaints for contractual indemnity against Apple seeking to join Apple as a party to the action. On July 18, 2017, Apple filed an answer to these third party complaints acknowledging its indemnity agreements and consenting to be joined. On that same date, the defendants and Apple filed papers opposing the motion for preliminary injunction. On August 18, 2017, a hearing on the preliminary injunction motion was held, and on September 7, 2017, the court denied the motion. Also on July 18, 2017, the defendants filed an Answer and Counterclaims to the complaint, asserting defenses and counterclaims similar to allegations previously made by Apple in the Apple Inc. v. QUALCOMM Incorporated case in the Southern District of California discussed above. In addition, the defendants asserted certain new claims, including claims under Section 1 of the Sherman Act and California’s Cartwright Act. The defendants seek damages, declaratory relief, injunctive relief, restitution of certain royalties and other relief. On July 18, 2017, Apple filed a motion to consolidate this action with the Apple Inc. v. QUALCOMM Incorporated case in the Southern District of California. On September 13, 2017, the court granted Apple’s consolidation motion.

[0001234452-17-000190:notes:60]
The Company believes Compal’s, Foxconn’s, Pegatron’s and Wistron’s claims in the above matter are without merit.

[0001234452-17-000190:notes:61]
QUALCOMM Incorporated v. Apple Inc.: On July 6, 2017, the Company filed a complaint against Apple in the United States District Court for the Southern District of California asserting claims for damages and injunctive relief for infringement of six of the Company’s patents directed to a variety of features found in iPhone models. On July 7, 2017, the Company filed a complaint against Apple in the United States International Trade Commission (ITC) requesting that the ITC institute an investigation pursuant to Section 337 of the Tariff Act of 1930 based on Apple’s infringement of the same six patents. The Company is seeking a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple filed an Answer and Counterclaims in the District Court case on September 26, 2017, but no schedule has been set in that case. On August 8, 2017, the ITC issued a notice of institution of an investigation. On August 25, 2017, the Company withdrew allegations as to one patent in both the ITC investigation and the District Court case. A claim construction hearing is scheduled in the ITC investigation for January 22-23, 2018. The ITC investigation is scheduled for evidentiary hearing by the Administrative Law Judge (ALJ) from June 18-26, 2018.  The ALJ’s Initial Determination on the merits is due on September 14, 2018, and the target date for final determination by the ITC is set for January 14, 2019.

[0001234452-17-000190:notes:62]
On July 17, 2017, the Company filed complaints against Apple and certain of its subsidiaries in the Federal Republic of Germany, asserting infringement of one patent in the Mannheim District Court and infringement of another patent in the Munich District Court. On October 2, 2017, the Company filed claim extensions in these actions against Apple and certain of its subsidiaries, asserting infringement of two additional patents in the Mannheim District Court and infringement of five additional patents in the Munich District Court. The complaints seek remedies including, among other relief, declaratory relief confirming liability on the merits for damages and injunctive relief. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

[0001234452-17-000190:notes:63]
On September 29, 2017, the Company filed three complaints against Apple and certain of its subsidiaries in the Beijing (China) Intellectual Property Court, asserting infringement of three patents.  The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

[0001234452-17-000190:notes:64]
On November 1, 2017, the Company filed a complaint against Apple in San Diego Superior Court for breach of the Master Software Agreement between the companies. The complaint recounts instances when Apple failed to protect the Company’s software as required by the agreement and failed to provide sufficient information to which the Company is entitled under the agreement in order to understand whether other breaches have occurred. The complaint seeks specific performance of Apple’s obligations to cooperate with an audit of its handling of the Company’s software, damages and injunctive relief. No case schedule has yet been set.

[0001234452-17-000190:notes:65]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, plaintiffs filed a securities class action complaint against the Company and certain of its current and former officers in the United States District Court for the Southern District of California. On April 29, 2016, plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, plaintiffs filed a second amended complaint, alleging that the Company and certain of its current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding the Company’s business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint seeks unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, the Company filed a motion to dismiss the second amended complaint, and on October 20, 2017, the court entered an order granting in part and denying in part the Company’s motion to dismiss. The court dismissed all claims as to all defendants other than the Company and Steve Mollenkopf with prejudice. The court also limited the case to two statements which it found, at least for pleading purposes, had stated a claim that could be explored in the discovery process. The Company believes the plaintiffs’ claims are without merit.

[0001234452-17-000190:notes:66]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, respectively, two securities class action complaints were filed by purported stockholders of the Company in the United States District Court for the Southern District of California against the Company and certain of its current and former officers and directors. The complaints alleged, among other things, that the defendants violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that the Company is or was engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, the defendants filed a motion to dismiss the consolidated amended complaint. The hearing on that motion is scheduled for December 4, 2017. The Company believes the plaintiffs’ claims are without merit.

[0001234452-17-000190:notes:67]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against the Company in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Twenty-four such cases remain outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel, and on May 25, 2017, set a trial date of April 29, 2019. On July 11, 2017, plaintiffs filed a consolidated amended complaint alleging that the Company violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to its competitors, conditioning the supply of certain of its baseband chipsets on the purchaser first agreeing to license the Company’s entire patent portfolio, entering into exclusive deals with companies including Apple Inc., and charging unreasonably high royalties that do not comply with the Company’s commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that the Company be enjoined from further unlawful conduct. On August 11, 2017, the Company filed a motion to dismiss the consolidated amended complaint. The Company believes the plaintiffs’ claims are without merit.

[0001234452-17-000190:notes:68]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 37 different dates. No further hearings are currently scheduled.

[0001234452-17-000190:notes:69]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments since then with respect to this matter.

[0001234452-17-000190:notes:70]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it was conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that the Company has violated provisions of the MRFTA. On January 22, 2017, the Company received the KFTC’s formal written decision, which finds that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with the Company; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders the Company to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chips; (iii) not demand unjustifiable conditions in the Company’s license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on the Company and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between the Company and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of approximately 1.03 trillion Korean Won (approximately $927 million), which was paid on March 30, 2017. The Company believes that its business practices do not violate the MRFTA, and on February 21, 2017 filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court has not ruled on the Company’s action to cancel the KFTC’s decision. On the same day, the Company filed an application with the Seoul High Court to stay the decision’s remedial order pending the Seoul High Court’s final judgment on the Company’s action to cancel the KFTC’s decision. The Seoul High Court held hearings on the Company’s application to stay the decision’s remedial order on July 10, 2017 and July 14, 2017. On September 4, 2017, the Seoul High Court denied the Company’s application to stay the remedial order. The Company has appealed the Seoul High Court’s decision to the Korea Supreme Court. The Supreme Court has not ruled on the Company’s appeal of the stay decision.

[0001234452-17-000190:notes:71]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company provided additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On August 15, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

[0001234452-17-000190:notes:72]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that since 2011 the Company has paid significant amounts to a customer on condition that it exclusively use the Company’s baseband chipsets in its smartphones and tablets. This conduct has allegedly reduced the customer’s incentives to source chipsets from the Company’s competitors and harmed competition and innovation for certain baseband chipsets. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On June 27, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

[0001234452-17-000190:notes:73]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against the Company in the United States District Court for the Northern District of California alleging that the Company engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of baseband processors on the purchaser first agreeing to a license to the Company’s standard-essential patents, paying incentives to purchasers of baseband processors to induce them to accept certain license terms, refusing to license its standard-essential patents to the Company’s competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint seeks a permanent injunction against the Company’s alleged violations of the FTCA and other unspecified ancillary equitable relief. The Company filed a motion to dismiss the FTC’s complaint on April 3, 2017, which the court denied on June 26, 2017. On April 19, 2017, the court set a trial date for January 4, 2019. The Company believes the FTC’s claims are without merit.

[0001234452-17-000190:notes:74]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified the Company that it was conducting an investigation into whether the Company’s patent licensing practices violate the Taiwan Fair Trade Act (TFTA). On April 27, 2016, the TFTC specified that the allegations under investigation include whether: (i) the Company jointly licensed its patents rather than separately licensing standard-essential patents and non-standard-essential patents; (ii) the Company’s royalty charges are unreasonable; (iii) the Company unreasonably required licensees to grant it cross-licenses; (iv) the Company failed to provide lists of licensed patents to licensees; (v) the Company violated a FRAND licensing commitment by declining to grant licenses to chipset makers; (vi) the Company declined to sell chipsets to unlicensed potential customers; and (vii) the Company provided royalty rebates to certain companies in exchange for their exclusive use of the Company’s chipsets. On October 11, 2017, the TFTC announced that it had reached a decision in the investigation, finding that the Company has violated the TFTA. On October 23, 2017, the Company received TFTC’s formal written decision, which finds that the following conducts violate the TFTA: (i) refusing to license and demanding restrictive covenants from chip competitors; (ii) refusing to supply baseband processors to companies that do not have an executed license; and (iii) providing a royalty discount to Apple in exchange for its exclusive use of the Company’s chipsets. The TFTC’s decision orders the Company to: (1) cease the following conduct within 60 days of the day after receipt of the decision: (a) applying the clauses in an agreement entered into with a competing chip supplier requesting it to provide sensitive sales information such as chip prices, customers, sales volumes, product types and serial numbers; (b) applying clauses in component supply agreements entered into with handset manufacturers relating to the refusal to sell chips to unlicensed manufacturers; and (c) applying discount clauses in the exclusive agreement entered into with a relevant enterprise; (2) notify competing chip companies and handset manufacturers in writing within 30 days after receipt of the decision that those companies may request to amend or enter into patent license agreements and other relevant agreements within 60 days of the day following the day such notices are received, and upon receipt of such requests, the Company shall commence negotiation in good faith; (3) submit status reports to the TFTC on any such negotiations every six months beginning from the day after receipt of the decision, as well as to submit a report to the TFTC within 30 days after amendments to any license agreements or newly signed license agreements are executed. The TFTC’s decision also imposed a fine of 23.4 billion Taiwan Dollars (approximately $778 million based on the exchange rate at September 24, 2017), which is due on or before November 7, 2017. The Company believes that its business practices do not violate the TFTA and intends to seek a stay of, and to file an action to revoke, the TFTC’s decision.

[0001234452-17-000190:notes:75]
Contingent losses: The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. Other than with respect to the TFTC fine, the Company has not recorded any accrual at September 24, 2017 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001234452-17-000190:notes:76]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company, or by intellectual property provided by the Company to chipset foundries and semiconductor assembly and test service providers. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0001234452-17-000190:notes:77]
Through September 24, 2017, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at September 24, 2017 associated with these indemnification arrangements based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001234452-17-000190:notes:78]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at September 24, 2017 for each of the subsequent five years from fiscal 2018 through 2022 were $4.3 billion, $1.0 billion, $376 million, $120 million and $27 million, respectively, and there were no obligations thereafter. Of these amounts, for each of the subsequent five years from fiscal 2018 through 2022, commitments to purchase integrated circuit product inventories comprised $3.5 billion, $846 million, $286 million, $72 million and $27 million, respectively, and there were no purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

[0001234452-17-000190:notes:79]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Rental expense for fiscal 2017, 2016 and 2015 was $129 million, $116 million and $99 million, respectively. Future minimum lease payments at September 24, 2017 for each of the subsequent five years from fiscal 2018 through 2022 were $98 million, $102 million, $82 million, $66 million and $42 million, respectively, and $55 million thereafter.

[0001234452-17-000190:notes:80]
Other Commitments. At September 24, 2017, the Company was committed to fund certain strategic investments up to $514 million, of which $69 million is expected to be funded in both fiscal 2018 and fiscal 2021. The remaining commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001234452-17-000190:notes:81]
Employee Benefit Plans

[0001234452-17-000190:notes:82]
Employee Savings and Retirement Plan. The Company has a 401(k) plan that allows eligible employees to contribute up to 85% of their eligible compensation, subject to annual limits. The Company matches a portion of the employee contributions and may, at its discretion, make additional contributions based upon earnings. The Company’s contribution expense was $76 million, $74 million and $81 million in fiscal 2017, 2016 and 2015, respectively.

[0001234452-17-000190:notes:83]
Equity Compensation Plans. On March 8, 2016, the Company’s stockholders approved the Qualcomm Incorporated 2016 Long-Term Incentive Plan (the 2016 Plan), which replaced the Qualcomm Incorporated 2006 Long-Term Incentive Plan (the Prior Plan). Effective on and after that date, no new awards will be granted under the Prior Plan, although all outstanding awards under the Prior Plan will remain outstanding according to their terms and the terms of the Prior Plan. The 2016 Plan provides for the grant of incentive and nonstatutory stock options, stock appreciation rights, restricted stock, unrestricted stock, restricted stock units, performance units, performance shares, deferred compensation awards and other stock-based awards. The share reserve under the 2016 Plan is equal to 90,000,000 shares, plus approximately 20,120,000 shares that were available for future grant under the Prior Plan on March 8, 2016, for a total of approximately 110,120,000 shares available for grant under the 2016 Plan on that date. This share reserve is automatically increased as provided in the 2016 Plan by the number of shares subject to stock options granted under the Prior Plan and outstanding as of March 8, 2016, which after that date expire or for any reason are forfeited, canceled or terminated, and by two times the number of shares subject to any awards other than stock options granted under the Prior Plan and outstanding as of March 8, 2016, which after that date expire, are forfeited, canceled or terminated, fail to vest, are not earned due to any performance goal that is not met, are otherwise reacquired without having become vested, or are paid in cash, exchanged by a participant or withheld by the Company to satisfy any tax withholding or tax payment obligations related to such award. The Board of Directors of the Company may amend or terminate the 2016 Plan at any time. Certain amendments, including an increase in the share reserve, require stockholder approval. As of September 24, 2017, approximately 95,485,000 shares were available for future grant under the 2016 Plan.

[0001234452-17-000190:notes:84]
RSUs are share awards that entitle the holder to receive shares of the Company’s common stock upon vesting. The RSUs generally include dividend-equivalent rights and vest over periods of three years from the date of grant. A summary of RSU transactions for all equity compensation plans follows:

[0001234452-17-000190:notes:85]
|  | Number of Shares |  | Weighted-AverageGrant Date FairValue |  | Aggregate IntrinsicValue |
|  | (In thousands) |  |  |  | (In billions) |
| RSUs outstanding at September 25, 2016 | 26,078 |  |  | $ | 61.42 |  |  |  |
| RSUs granted | 12,525 |  |  | 66.54 |  |  |  |
| RSUs canceled/forfeited | (1,793 | ) |  | 63.17 |  |  |  |
| RSUs vested | (12,106 | ) |  | 64.34 |  |  |  |
| RSUs outstanding at September 24, 2017 | 24,704 |  |  | $ | 62.46 |  |  | $ | 1.3 |  |

[0001234452-17-000190:notes:86]
At September 24, 2017, total unrecognized compensation expense related to non-vested RSUs granted prior to that date was $911 million, which is expected to be recognized over a weighted-average period of 1.6 years. The total vest-date fair value of RSUs that vested during fiscal 2017, 2016 and 2015 was $820 million, $685 million and $1.0 billion, respectively. The total shares withheld to satisfy statutory tax withholding requirements related to all share-based awards were approximately 4,247,000, 4,300,000 and 5,043,000 in fiscal 2017, 2016 and 2015, respectively, and were based on the value of the awards on their vesting dates as determined by the Company’s closing stock price. Total payments for the employees’ tax obligations to the taxing authorities were $268 million, $224 million and $351 million in fiscal 2017, 2016 and 2015, respectively, and were included as a reduction to net cash provided by operating activities in the consolidated statements of cash flows.

[0001234452-17-000190:notes:87]
The Board of Directors may grant stock options to employees, directors and consultants to the Company to purchase shares of the Company’s common stock at an exercise price not less than the fair market value of the stock at the date of grant. Stock options vest over periods not exceeding five years and are exercisable for up to ten years from the grant date. A summary of stock option transactions for all equity compensation plans follows:

[0001234452-17-000190:notes:88]
|  | Number of Shares |  | Weighted- AverageExercisePrice |  | Average RemainingContractual Term |  | Aggregate IntrinsicValue |
|  | (In thousands) |  |  |  | (Years) |  | (In millions) |
| Stock options outstanding at September 25, 2016 | 17,979 |  |  | $ | 40.96 |  |  |  |  |  |
| Stock options canceled/forfeited/expired | (52 | ) |  | 27.33 |  |  |  |  |  |
| Stock options exercised | (5,542 | ) |  | 41.02 |  |  |  |  |  |
| Stock options outstanding at September 24, 2017 | 12,385 |  |  | $ | 40.99 |  |  | 1.3 |  | $ | 139 |  |
| Exercisable at September 24, 2017 | 12,382 |  |  | $ | 41.00 |  |  | 1.3 |  | $ | 139 |  |

[0001234452-17-000190:notes:89]
The total intrinsic value of stock options exercised during fiscal 2017, 2016 and 2015 was $118 million, $147 million and $371 million, respectively, and the amount of cash received from the exercise of stock options was $236 million, $436 million and $519 million, respectively. Upon option exercise, the Company issues new shares of stock.

[0001234452-17-000190:notes:90]
The total tax benefits realized, including the excess tax benefits, related to share-based awards during fiscal 2017, 2016 and 2015 was $301 million, $253 million and $437 million, respectively.

[0001234452-17-000190:notes:91]
Employee Stock Purchase Plan. The Company has an employee stock purchase plan for eligible employees to purchase shares of common stock at 85% of the lower of the fair market value on the first or the last day of each offering period, which is generally six months. Employees may authorize the Company to withhold up to 15% of their compensation during any offering period, subject to certain limitations. The employee stock purchase plan includes a non-423(b) plan. The shares authorized under the employee stock purchase plan were approximately 71,709,000 at September 24, 2017. The shares reserved for future issuance were approximately 14,648,000 at September 24, 2017. During fiscal 2017, 2016 and 2015, approximately 5,746,000, 5,966,000 and 4,977,000 shares, respectively, were issued under the plan at an average price of $45.29, $38.89 and $53.92 per share, respectively. At September 24, 2017, total unrecognized compensation expense related to non-vested purchase rights granted prior to that date was $26 million. The Company recorded cash received from the exercise of purchase rights of $260 million, $232 million and $268 million during fiscal 2017, 2016 and 2015, respectively.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001234452-17-000190:notes:92]
Concentrations. Revenues in fiscal 2017 were negatively impacted by the actions of Apple Inc. and Hon Hai Precision Industry Co., Ltd./Foxconn, its affiliates and other suppliers to Apple as well as the dispute with another licensee, who did not report or pay royalties due in the third or fourth quarter of fiscal 2017. Apple’s contract manufacturers did not fully report and did not pay royalties due on sales of Apple products for a portion of the fiscal year, which resulted in higher accounts receivable from those suppliers (Note 2). A significant portion of the Company’s revenues is concentrated with a small number of customers/licensees of the Company’s QCT and QTL segments. Revenues related to the products of two customers/licensees comprised 18% and 17% of total consolidated revenues in fiscal 2017, compared to 24% and 16% in fiscal 2016 and 25% and 20% in fiscal 2015. Excluding the unpaid royalty receivables due from suppliers to Apple (Note 2), aggregate accounts receivable from one customer/licensee comprised 10% and 14% of accounts receivable at September 24, 2017 and September 25, 2016, respectively.

[0001234452-17-000190:notes:93]
The Company relies on sole- or limited-source suppliers for some products, particularly products in the QCT segment, subjecting the Company to possible shortages of raw materials or manufacturing capacity. While the Company has established alternate suppliers for certain technologies that the Company considers critical, the loss of a supplier or the inability of a supplier to meet performance or quality specifications or delivery schedules could harm the Company’s ability to meet its delivery obligations and/or negatively impact the Company’s revenues, business operations and ability to compete for future business.


## us-gaap:ConsolidationPolicyTextBlock

[0001234452-17-000190:notes:94]
Principles of Consolidation. The Company’s consolidated financial statements include the assets, liabilities and operating results of majority-owned subsidiaries, including its joint venture RF360 Holdings Singapore Pte. Ltd (RF360 Holdings) (Note 9). In addition, the Company consolidated its investment in an immaterial less than majority-owned variable interest entity as the Company was the primary beneficiary until the end of fiscal 2017. The ownership of the other interest holders of consolidated subsidiaries and the immaterial less than majority-owned variable interest entity is presented separately in the consolidated balance sheets and statements of operations. All significant intercompany accounts and transactions have been eliminated.


## us-gaap:DebtDisclosureTextBlock

[0001234452-17-000190:notes:95]
Debt

[0001234452-17-000190:notes:96]
Revolving Credit Facility. In November 2016, the Company amended and restated its existing Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit (Amended and Restated Revolving Credit Facility) to increase the aggregate amount available to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. The Company had not previously borrowed any funds under the existing Revolving Credit Facility. Proceeds from the Amended and Restated Revolving Credit Facility are expected to be used for general corporate purposes. Loans under the Amended and Restated Revolving Credit Facility will bear interest, at the option of the Company, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the Amended and Restated Revolving Credit Facility) or the Base Rate (determined in accordance with the Amended and Restated Revolving Credit Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.70% and 0.00% per annum, respectively. The Amended and Restated Revolving Credit Facility has a facility fee, which initially accrues at a rate of 0.05% per annum. At September 24, 2017, the Company had not borrowed any funds under the Amended and Restated Revolving Credit Facility.

[0001234452-17-000190:notes:97]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At September 24, 2017 and September 25, 2016, the Company had $999 million and $1.7 billion, respectively, of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 1.19% and 0.52%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 45 days and 36 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at September 24, 2017 and September 25, 2016.

[0001234452-17-000190:notes:98]
Bridge Loan Facility. In October 2016, the Company entered into commitment letters pursuant to which the Company received commitments for senior unsecured bridge facility loans in an aggregate principal amount up to $13.6 billion (Bridge Loan Facility). Proceeds from the Bridge Loan Facility, if drawn, were intended to be used to finance, in part, the proposed acquisition of NXP Semiconductors N.V. (NXP) by Qualcomm River Holdings B.V., a wholly owned subsidiary of the Company (Qualcomm River Holdings) (Note 9). Subsequently, the commitments available under the Bridge Loan Facility were reduced to $7.1 billion upon the Company entering into a $4.0 billion Term Loan Facility, described below, and the sale of certain assets by NXP for estimated net cash proceeds of $2.5 billion in February 2017. In May 2017, in connection with the Company’s issuance of an aggregate principal amount of $11.0 billion of unsecured floating-rate and fixed-rate notes, described below, the commitments available under the Bridge Loan Facility were reduced such that there were no remaining commitments available, and the Bridge Loan Facility was terminated. The Company had not previously borrowed any funds under the Bridge Loan Facility. The Bridge Loan Facility had a ticking fee, which accrued at a rate of 0.05% per annum commencing on December 26, 2016.

[0001234452-17-000190:notes:99]
Term Loan Facility. In November 2016, the Company entered into a Credit Agreement that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion (Term Loan Facility). Proceeds from the Term Loan Facility, if drawn, will be used to finance the proposed acquisition of NXP. Commitments under the Term Loan Facility will expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the Term Loan Facility, (ii) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP and (iii) January 25, 2018 (which reflects the automatic extension of the original expiration date of October 27, 2017 in accordance with the NXP purchase agreement, and as such date may be further extended in accordance with the NXP purchase agreement). Loans under the Term Loan Facility will mature on the third anniversary of the date on which they are funded and will bear interest at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the Term Loan Facility) or the Base Rate (determined in accordance with the Term Loan Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.875% and 0.00% per annum, respectively. The Term Loan Facility has a ticking fee, which initially accrues at a rate of 0.05% per annum commencing on December 26, 2016. At September 24, 2017, the Company had not borrowed any funds under the Term Loan Facility.

[0001234452-17-000190:notes:100]
Long-term Debt. In May 2015, the Company issued an aggregate principal amount of $10.0 billion of unsecured floating- and fixed-rate notes (May 2015 Notes) with varying maturities. The proceeds from the May 2015 Notes of $9.9 billion, net of underwriting discounts and offering expenses, were used to fund the ASR Agreements (Note 4) and also for other general corporate purposes. In May 2017, the Company issued an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes (May 2017 Notes) with varying maturities. The proceeds from the May 2017 Notes of $10.95 billion, net of underwriting discounts and offering expenses, are intended to be used to finance, in part, the Company’s proposed acquisition of NXP and other related transactions and for general corporate purposes. The following table provides a summary of the Company’s long-term debt (in millions except percentages):

[0001234452-17-000190:notes:101]
|  |  | September 24, 2017 |  | September 25, 2016 |
|  |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.27% notes due May 18, 2018 | $ | 250 |  |  | 1.65% |  | $ | 250 |  |  | 1.14% |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | 250 |  |  | 1.92% |  | 250 |  |  | 1.42% |
|  | Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 1.93% |  | 1,250 |  |  | 0.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 2.20% |  | 1,750 |  |  | 1.69% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.65% |  | 2,000 |  |  | 2.04% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.36% notes due May 20, 2019 | 750 |  |  | 1.80% |  | — |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.45% notes due May 20, 2020 | 500 |  |  | 1.86% |  | — |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 2.11% |  | — |  |  |  |
|  | Fixed-rate 1.85% notes due May 20, 2019 | 1,250 |  |  | 2.00% |  | — |  |  |  |
|  | Fixed-rate 2.10% notes due May 20, 2020 | 1,500 |  |  | 2.19% |  | — |  |  |  |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | — |  |  |  |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | — |  |  |  |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | — |  |  |  |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.47% |  | — |  |  |  |
|  | Total principal | 21,000 |  |  |  |  | 10,000 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (106 | ) |  |  |  | (57 | ) |  |  |
|  | Hedge accounting fair value adjustments | — |  |  |  |  | 65 |  |  |  |
|  | Total long-term debt | $ | 20,894 |  |  |  |  | $ | 10,008 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | 1,496 |  |  |  |  | $ | — |  |  |  |
|  | Long-term debt | 19,398 |  |  |  |  | 10,008 |  |  |  |
|  | Total | $ | 20,894 |  |  |  |  | $ | 10,008 |  |  |  |

[0001234452-17-000190:notes:102]
At September 24, 2017, future principal payments were $1.5 billion in fiscal 2018, $2.0 billion in fiscal 2019, $4.0 billion in fiscal 2020, $2.0 billion in fiscal 2022 and $11.5 billion after fiscal 2022; no principal payments are due in fiscal 2021.

[0001234452-17-000190:notes:103]
The Company’s 2019 floating-rate notes, 2020 floating-rate notes, 2019 fixed-rate notes and 2020 fixed-rate notes issued in May 2017 for an aggregate principal amount of $4.0 billion are subject to a special mandatory redemption at a price equal to 101% of the aggregate principal amount, plus accrued and unpaid interest to, but excluding, the date of such mandatory redemption. The redemption is required on the first to occur of (i) the termination of the NXP purchase agreement or (ii) January 25, 2018 (which reflects the automatic extension of the original expiration date of October 27, 2017 in accordance with the NXP purchase agreement, and as such date may be further extended in accordance with the NXP purchase agreement to a date on or prior to June 1, 2018).

[0001234452-17-000190:notes:104]
The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of the Company’s other senior unsecured indebtedness and will effectively rank junior to all liabilities of the Company’s subsidiaries. At September 24, 2017 and September 25, 2016, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $21.5 billion and $10.6 billion, respectively.

[0001234452-17-000190:notes:105]
In connection with issuance of the May 2015 Notes, the Company entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings in interest expense in the current period. The Company did not enter into similar interest rate swaps in connection with issuance of the May 2017 Notes.

[0001234452-17-000190:notes:106]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $313 million, $282 million and negligible during fiscal 2017, 2016 and 2015, respectively.

[0001234452-17-000190:notes:107]
Debt Covenants. The Amended and Restated Revolving Credit Facility and the Term Loan Facility require, and the Bridge Loan Facility and prior Revolving Credit Facility required, that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At September 24, 2017 and September 25, 2016, the Company was in compliance with the applicable covenants under each facility outstanding at such time.


## us-gaap:DerivativesPolicyTextBlock

[0001234452-17-000190:notes:108]
Derivatives. The Company’s primary objectives for holding derivative instruments are to manage interest rate risk on its long-term debt and to manage foreign exchange risk for certain foreign currency revenues, operating expenses, receivables and payables. Derivative instruments are recorded at fair value and included in other current or noncurrent assets or other current or noncurrent liabilities based on their maturity dates. Counterparties to the Company’s derivative instruments are all major banking institutions.

[0001234452-17-000190:notes:109]
Interest Rate Swaps: The Company manages its exposure to certain interest rate risks related to its long-term debt through the use of interest rate swaps. Such swaps allow the Company to effectively convert fixed-rate payments into floating-rate payments based on LIBOR. These transactions are designated as fair value hedges, and the gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate debt attributable to the hedged risks, are recognized in earnings as interest expense in the current period. The interest settlement payments associated with the interest rate swap agreements are classified as cash flows from operating activities in the consolidated statements of cash flows.

[0001234452-17-000190:notes:110]
At September 24, 2017 and September 25, 2016, the aggregate fair value of the Company’s interest rate swaps related to its long-term debt issued in May 2015 was negligible and $65 million, respectively. The fair values of the swaps were recorded in noncurrent assets, other current liabilities and other noncurrent liabilities at September 24, 2017 and in noncurrent assets at September 25, 2016. The swaps had an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate debt due in 2018 and approximately 43% and 50% of the fixed-rate debt due in 2020 and 2022, respectively, into floating-rate debt. The maturities of the swaps match the Company’s fixed-rate debt due in 2018, 2020 and 2022.

[0001234452-17-000190:notes:111]
Foreign Currency Hedges: The Company manages its exposure to foreign exchange market risks, when deemed appropriate, through the use of derivative instruments, including foreign currency forward and option contracts with financial counterparties, that may or may not be designated as hedging instruments. These derivative instruments mature between one and twelve months. Gains and losses arising from the effective portion of such contracts that are designated as cash flow hedging instruments are recorded as a component of accumulated other comprehensive income as gains and losses on derivative instruments, net of income taxes. The hedging gains and losses in accumulated other comprehensive income are subsequently reclassified to revenues or costs and expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect the Company’s earnings. Gains and losses arising from the ineffective portion of such contracts are recorded in investment and other income, net as gains and losses on derivative instruments. The cash flows associated with derivative instruments designated as cash flow hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The cash flows associated with the ineffective portion of such derivative instruments are classified as cash flows from investing activities in the consolidated statements of cash flows. The fair values of the Company’s foreign currency forward and option contracts used to hedge foreign currency risk designated as cash flow hedges recorded in total assets and in total liabilities were $10 million and $22 million, respectively, at September 24, 2017 and negligible at September 25, 2016.

[0001234452-17-000190:notes:112]
For foreign currency forward and option contracts not designated as hedging instruments, the changes in fair value are recorded in investment and other income, net in the period of change. The cash flows associated with derivative instruments not designated as hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The fair value of the Company’s foreign currency forward and option contracts not designated as hedging instruments was negligible at September 24, 2017. There were no foreign currency forward and option contracts not designated as hedging instruments at September 25, 2016.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0001234452-17-000190:notes:113]
A summary of stock option transactions for all equity compensation plans follows:

[0001234452-17-000190:notes:114]
A summary of RSU transactions for all equity compensation plans follows:


## us-gaap:DividendsDeclaredTableTextBlock

[0001234452-17-000190:notes:115]
Dividends charged to retained earnings in fiscal 2017, 2016 and 2015 were as follows (in millions, except per share data):

[0001234452-17-000190:notes:116]
|  | 2017 |  | 2016 |  | 2015 |
|  | Per Share |  | Total |  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.53 |  |  | $ | 801 |  |  | $ | 0.48 |  |  | $ | 730 |  |  | $ | 0.42 |  |  | $ | 710 |  |
| Second quarter | 0.53 |  |  | 798 |  |  | 0.48 |  |  | 726 |  |  | 0.42 |  |  | 702 |  |
| Third quarter | 0.57 |  |  | 858 |  |  | 0.53 |  |  | 794 |  |  | 0.48 |  |  | 771 |  |
| Fourth quarter | 0.57 |  |  | 857 |  |  | 0.53 |  |  | 796 |  |  | 0.48 |  |  | 749 |  |
|  | $ | 2.20 |  |  | $ | 3,314 |  |  | $ | 2.02 |  |  | $ | 3,046 |  |  | $ | 1.80 |  |  | $ | 2,932 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001234452-17-000190:notes:117]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for fiscal 2017, 2016 and 2015 were 12,989,000, 13,864,000 and 20,724,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 2,955,000, 2,435,000 and 4,652,000 during fiscal 2017, 2016 and 2015, respectively.


## us-gaap:EquityMethodInvestmentsTextBlock

[0001234452-17-000190:notes:118]
The carrying values of the Company’s non-marketable equity investments are recorded in other noncurrent assets and were as follows (in millions):

[0001234452-17-000190:notes:119]
|  | September 24, 2017 |  | September 25, 2016 |
| Equity method investments | $ | 379 |  |  | $ | 324 |  |
| Cost method investments | 603 |  |  | 531 |  |
|  | $ | 982 |  |  | $ | 855 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001234452-17-000190:notes:120]
The following table includes the activity for marketable securities, other investments and other liabilities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-17-000190:notes:121]
|  | 2017 |  | 2016 |
|  | Marketable Securities |  | Other Investments |  | Other Liabilities |  | Marketable Securities |  | Other Investments |
| Beginning balance of Level 3 | $ | 43 |  |  | $ | 37 |  |  | $ | — |  |  | $ | 224 |  |  | $ | 13 |  |
| Total realized and unrealized gains or losses: |  |  |  |  |  |  |  |  |  |
| Included in selling, general and administrative expenses | — |  |  | — |  |  | (7 | ) |  | — |  |  | — |  |
| Included in investment and other income, net | — |  |  | 3 |  |  | — |  |  | (4 | ) |  | (23 | ) |
| Included in other comprehensive income (loss) | — |  |  | 8 |  |  | — |  |  | (1 | ) |  | 15 |  |
| Issuances | — |  |  | — |  |  | 203 |  |  | — |  |  | — |  |
| Purchases | — |  |  | 111 |  |  | — |  |  | 2 |  |  | 40 |  |
| Sales | — |  |  | — |  |  | — |  |  | (106 | ) |  | — |  |
| Settlements | (3 | ) |  | (34 | ) |  | — |  |  | (45 | ) |  | (8 | ) |
| Transfers into Level 3 | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Transfers out of Level 3 | — |  |  | — |  |  | — |  |  | (27 | ) |  | — |  |
| Ending balance of Level 3 | $ | 40 |  |  | $ | 125 |  |  | $ | 196 |  |  | $ | 43 |  |  | $ | 37 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001234452-17-000190:notes:122]
Fair Value Measurements

[0001234452-17-000190:notes:123]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at September 24, 2017 (in millions):

[0001234452-17-000190:notes:124]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 21,016 |  |  | $ | 12,933 |  |  | $ | — |  |  | $ | 33,949 |  |
| Marketable securities |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 969 |  |  | 13 |  |  | — |  |  | 982 |  |
| Corporate bonds and notes | — |  |  | 2,285 |  |  | — |  |  | 2,285 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 93 |  |  | 40 |  |  | 133 |  |
| Equity and preferred securities and equity funds | 36 |  |  | — |  |  | — |  |  | 36 |  |
| Debt funds | — |  |  | 109 |  |  | — |  |  | 109 |  |
| Total marketable securities | 1,005 |  |  | 2,500 |  |  | 40 |  |  | 3,545 |  |
| Derivative instruments | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Other investments | 369 |  |  | — |  |  | 125 |  |  | 494 |  |
| Total assets measured at fair value | $ | 22,390 |  |  | $ | 15,447 |  |  | $ | 165 |  |  | $ | 38,002 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 27 |  |  | $ | — |  |  | $ | 27 |  |
| Other liabilities | 369 |  |  | — |  |  | 196 |  |  | 565 |  |
| Total liabilities measured at fair value | $ | 369 |  |  | $ | 27 |  |  | $ | 196 |  |  | $ | 592 |  |

[0001234452-17-000190:notes:125]
Activity between Levels of the Fair Value Hierarchy. There were no significant transfers between Level 1 and Level 2 during fiscal 2017 and 2016.

[0001234452-17-000190:notes:126]
The Company recognizes transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. Transfers out of Level 3 during fiscal 2016 for marketable securities primarily consisted of debt securities with significant upgrades in credit ratings or for which there were observable inputs.

[0001234452-17-000190:notes:127]
Nonrecurring Fair Value Measurements. The Company measures certain assets and liabilities at fair value on a nonrecurring basis. These assets and liabilities include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During fiscal 2015, the Company updated the business plans and related internal forecasts related to certain of the Company’s businesses, resulting in impairment charges to write down certain property, plant and equipment, intangible assets and goodwill (Note 2). The Company determined the fair values using cost, income and market approaches. The estimation of fair value and cash flows used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During fiscal 2017, 2016 and 2015, the Company did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001234452-17-000190:notes:128]
Fair Value Measurements. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants as of the measurement date. Applicable accounting guidance provides an established hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Observable inputs are inputs that market participants would use in valuing the asset or liability and are developed based on market data obtained from sources independent of the Company. Unobservable inputs are inputs that reflect the Company’s assumptions about the factors that market participants would use in valuing the asset or liability. There are three levels of inputs that may be used to measure fair value:

[0001234452-17-000190:notes:129]
| • | Level 1 includes financial instruments for which quoted market prices for identical instruments are available in active markets. |

[0001234452-17-000190:notes:130]
| • | Level 2 includes financial instruments for which there are inputs other than quoted prices included within Level 1 that are observable for the instrument. |

[0001234452-17-000190:notes:131]
| • | Level 3 includes financial instruments for which fair value is derived from valuation techniques in which one or more significant inputs are unobservable, including the Company’s own assumptions. |

[0001234452-17-000190:notes:132]
Assets and liabilities are classified based on the lowest level of input that is significant to the fair value measurements. The Company reviews the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy.

[0001234452-17-000190:notes:133]
Cash Equivalents and Marketable Securities: With the exception of auction rate securities, the Company obtains pricing information from quoted market prices, pricing vendors or quotes from brokers/dealers. The Company conducts reviews of its primary pricing vendors to determine whether the inputs used in the vendor’s pricing processes are deemed to be observable. The fair value for interest-bearing securities includes accrued interest.

[0001234452-17-000190:notes:134]
The fair value of U.S. Treasury securities and government-related securities, corporate bonds and notes and common and preferred stock is generally determined using standard observable inputs, including reported trades, quoted market prices, matrix pricing, benchmark yields, broker/dealer quotes, issuer spreads, two-sided markets and/or benchmark securities.

[0001234452-17-000190:notes:135]
The fair value of debt and equity funds is reported at published net asset values. The Company assesses the daily frequency and size of transactions at published net asset values and/or the funds’ underlying holdings to determine whether fair value is based on observable or unobservable inputs.

[0001234452-17-000190:notes:136]
The fair value of mortgage- and asset-backed securities is derived from the use of matrix pricing (prices for similar securities) or, in some cases, cash flow pricing models with observable inputs, such as contractual terms, maturity, credit rating and/or securitization structure to determine the timing and amount of future cash flows. Certain mortgage- and asset-backed securities may require the use of significant unobservable inputs to estimate fair value, such as default likelihood, recovery rates and prepayment speed.

[0001234452-17-000190:notes:137]
The fair value of auction rate securities is estimated by the Company using a discounted cash flow model that incorporates transaction details, such as contractual terms, maturity and timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery, the future state of the auction rate market and credit valuation adjustments of market participants. Though most of the securities held by the Company are pools of student loans guaranteed by the U.S. government, prepayment speeds and illiquidity discounts are considered significant unobservable inputs. These additional inputs are generally unobservable, and therefore, auction rate securities are included in Level 3.

[0001234452-17-000190:notes:138]
Derivative Instruments: Derivative instruments that are traded on an exchange are valued using quoted market prices and are included in Level 1. Derivative instruments that are not traded on an exchange are valued using conventional calculations/models that are primarily based on observable inputs, such as foreign currency exchange rates, volatilities and interest rates, and therefore, such derivative instruments are included in Level 2.

[0001234452-17-000190:notes:139]
Other Investments and Other Liabilities: Other investments and other liabilities included in Level 1 are comprised of the Company’s deferred compensation plan liability and related assets, which consist of mutual funds classified as trading securities, and are included in other assets. Other investments and other liabilities included in Level 3 are comprised of convertible debt instruments issued by private companies and contingent consideration related to business combinations, respectively. The fair value of convertible debt instruments is estimated by the Company based on the estimated timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery. The fair value of contingent consideration related to business combinations is estimated by the Company using a real options approach, which includes inputs, such as projected financial information, market volatility, discount rates and timing of contractual payments. The inputs used by the Company to estimate the fair values of the convertible debt instruments and contingent consideration are generally unobservable, and therefore, they are included in Level 3.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001234452-17-000190:notes:140]
Foreign Currency. Certain foreign subsidiaries use a local currency as the functional currency. Resulting translation gains or losses are recognized as a component of accumulated other comprehensive income. Transaction gains or losses related to balances denominated in a currency other than the functional currency are recognized in the consolidated statements of operations.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001234452-17-000190:notes:141]
Goodwill and Other Intangible Assets. Goodwill represents the excess of purchase price over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Acquired intangible assets other than goodwill are amortized over their useful lives unless the lives are determined to be indefinite. For intangible assets purchased in a business combination, the estimated fair values of the assets received are used to establish their recorded values. For intangible assets acquired in a non-monetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001234452-17-000190:notes:142]
Impairment of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. Goodwill and other indefinite-lived intangible assets are tested annually for impairment in the fourth fiscal quarter and in interim periods if certain events occur indicating that the carrying amounts may be impaired. If a qualitative assessment is used and the Company determines that the fair value of a reporting unit or indefinite-lived intangible asset is more likely than not (i.e., a likelihood of more than 50%) less than its carrying amount, a quantitative impairment test will be performed. If goodwill is quantitatively assessed for impairment, a two-step approach is applied. First, the Company compares the estimated fair value of the reporting unit in which the goodwill resides to its carrying value. The second step, if necessary, measures the amount of impairment, if any, by comparing the implied fair value of goodwill to its carrying value. Other indefinite-lived intangible assets are quantitatively assessed for impairment, if necessary, by comparing their estimated fair values to their carrying values. If the carrying value exceeds the fair value, the difference is recorded as an impairment.

[0001234452-17-000190:notes:143]
Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by comparing the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Long-lived assets to be disposed of by sale are reported at the lower of their carrying amounts or their estimated fair values less costs to sell and are not depreciated.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001234452-17-000190:notes:144]
Income Taxes

[0001234452-17-000190:notes:145]
The components of the income tax provision were as follows (in millions):

[0001234452-17-000190:notes:146]
|  | 2017 |  | 2016 |  | 2015 |
| Current provision (benefit): |  |  |  |  |  |
| Federal | $ | 72 |  |  | $ | 4 |  |  | $ | (67 | ) |
| State | 3 |  |  | 4 |  |  | 4 |  |
| Foreign | 1,256 |  |  | 1,411 |  |  | 1,307 |  |
|  | 1,331 |  |  | 1,419 |  |  | 1,244 |  |
| Deferred (benefit) provision: |  |  |  |  |  |
| Federal | (586 | ) |  | (184 | ) |  | (9 | ) |
| State | 4 |  |  | 6 |  |  | 1 |  |
| Foreign | (194 | ) |  | (110 | ) |  | (17 | ) |
|  | (776 | ) |  | (288 | ) |  | (25 | ) |
|  | $ | 555 |  |  | $ | 1,131 |  |  | $ | 1,219 |  |

[0001234452-17-000190:notes:147]
The foreign component of the income tax provision consisted primarily of foreign withholding taxes on royalty fees included in United States earnings.

[0001234452-17-000190:notes:148]
The components of income before income taxes by United States and foreign jurisdictions were as follows (in millions):

[0001234452-17-000190:notes:149]
|  | 2017 |  | 2016 |  | 2015 |
| United States | $ | (762 | ) |  | $ | 3,032 |  |  | $ | 2,993 |  |
| Foreign | 3,782 |  |  | 3,801 |  |  | 3,494 |  |
|  | $ | 3,020 |  |  | $ | 6,833 |  |  | $ | 6,487 |  |

[0001234452-17-000190:notes:150]
The foreign component of income before income taxes in foreign jurisdictions consists primarily of income earned in Singapore.

[0001234452-17-000190:notes:151]
The following is a reconciliation of the expected statutory federal income tax provision to the Company’s actual income tax provision (in millions):

[0001234452-17-000190:notes:152]
|  | 2017 |  | 2016 |  | 2015 |
| Expected income tax provision at federal statutory tax rate | $ | 1,057 |  |  | $ | 2,392 |  |  | $ | 2,270 |  |
| State income tax provision, net of federal benefit | 8 |  |  | 19 |  |  | 18 |  |
| Foreign income taxed at other than U.S. rates | (963 | ) |  | (1,068 | ) |  | (937 | ) |
| Research and development tax credits | (81 | ) |  | (143 | ) |  | (148 | ) |
| Worthless stock deduction of domestic subsidiary | — |  |  | (101 | ) |  | — |  |
| Nondeductible charges related to the KFTC and TFTC investigations | 363 |  |  | — |  |  | — |  |
| Impact of changes in tax reserves and audit settlements for prior year tax positions | 111 |  |  | — |  |  | (61 | ) |
| Other | 60 |  |  | 32 |  |  | 77 |  |
|  | $ | 555 |  |  | $ | 1,131 |  |  | $ | 1,219 |  |

[0001234452-17-000190:notes:153]
During fiscal 2017, the Company recorded charges of $927 million and $778 million related to the fines imposed by the KFTC and the TFTC, respectively (Note 7), which are not deductible for tax purposes and are attributable to both the United States and a foreign jurisdiction.

[0001234452-17-000190:notes:154]
During fiscal 2016, the Company recorded a tax benefit of $101 million from a worthless stock deduction on a domestic subsidiary of one of the Company’s former display businesses. Also, during fiscal 2016, the United States government permanently reinstated the federal research and development tax credit retroactively to January 1, 2015. As a result of the reinstatement, the Company recorded a tax benefit of $79 million in fiscal 2016 related to fiscal 2015. During fiscal 2015, the NDRC imposed a fine of $975 million (Note 2), which was not deductible for tax purposes and was substantially attributable to a foreign jurisdiction. Additionally, during fiscal 2015, the Company recorded a tax benefit of $101 million related to fiscal 2014 resulting from the United States government reinstating the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. The effective tax rate for fiscal 2015 also reflected the United States federal research and development tax credit generated through December 31, 2014, the date on which the credit expired, and a $61 million tax benefit as a result of a favorable tax audit settlement with the Internal Revenue Service (IRS) related to Qualcomm Atheros, Inc.’s pre-acquisition 2010 and 2011 tax returns.

[0001234452-17-000190:notes:155]
The Company’s QCT segment’s non-United States headquarters is located in Singapore. The Company has obtained tax incentives in Singapore that commenced in March 2012, which are effective through March 2027, that result in a tax exemption for the first five years provided that the Company meets specified employment and investment criteria. As a result of the expiration of certain of these incentives, the Company’s Singapore tax rate increased in fiscal 2017 and will increase again in fiscal 2027 upon the expiration of the remaining incentives. Had the Company established QCT’s non-United States headquarters in Singapore without these tax incentives, the Company’s income tax expense would have been higher and impacted earnings per share attributable to Qualcomm as follows (in millions, except per share amounts):

[0001234452-17-000190:notes:156]
|  | 2017 |  | 2016 |  | 2015 |
| Additional income tax expense | $ | 493 |  |  | $ | 487 |  |  | $ | 656 |  |
| Reduction to diluted earnings per share | $ | 0.33 |  |  | $ | 0.32 |  |  | $ | 0.40 |  |

[0001234452-17-000190:notes:157]
The Company considers the operating earnings of certain non-United States subsidiaries to be indefinitely reinvested outside the United States based on the Company’s plans for use and/or investment outside the United States and the Company’s belief that its sources of cash and liquidity in the United States will be sufficient to meet future domestic cash needs. The Company has not recorded a deferred tax liability of approximately $13.7 billion related to the United States federal and state income taxes and foreign withholding taxes on approximately $39.0 billion of undistributed earnings of certain non-United States subsidiaries indefinitely reinvested outside the United States. Should the Company decide to no longer indefinitely reinvest such earnings outside the United States, the Company would have to adjust the income tax provision in the period management makes such determination.

[0001234452-17-000190:notes:158]
The Company had deferred tax assets and deferred tax liabilities as follows (in millions):

[0001234452-17-000190:notes:159]
|  | September 24, 2017 |  | September 25, 2016 |
| Unused tax credits | $ | 1,798 |  |  | $ | 1,256 |  |
| Accrued liabilities and reserves | 888 |  |  | 409 |  |
| Unearned revenues | 886 |  |  | 920 |  |
| Share-based compensation | 241 |  |  | 277 |  |
| Unused net operating losses | 208 |  |  | 218 |  |
| Unrealized losses on other investments and marketable securities | 151 |  |  | 254 |  |
| Other | 21 |  |  | 55 |  |
| Total gross deferred tax assets | 4,193 |  |  | 3,389 |  |
| Valuation allowance | (863 | ) |  | (754 | ) |
| Total net deferred tax assets | 3,330 |  |  | 2,635 |  |
| Intangible assets | (535 | ) |  | (502 | ) |
| Unrealized gains on other investments and marketable securities | (33 | ) |  | (194 | ) |
| Other | (95 | ) |  | (78 | ) |
| Total deferred tax liabilities | (663 | ) |  | (774 | ) |
| Net deferred tax assets | $ | 2,667 |  |  | $ | 1,861 |  |
| Reported as: |  |  |  |
| Non-current deferred tax assets | 2,900 |  |  | 2,030 |  |
| Non-current deferred tax liabilities (1) | (233 | ) |  | (169 | ) |
|  | $ | 2,667 |  |  | $ | 1,861 |  |

[0001234452-17-000190:notes:160]
| (1) | Non-current deferred tax liabilities were included in other liabilities in the consolidated balance sheets. |

[0001234452-17-000190:notes:161]
At September 24, 2017, the Company had unused federal net operating loss carryforwards of $245 million expiring from 2021 through 2035, unused state net operating loss carryforwards of $858 million expiring from 2018 through 2037 and unused foreign net operating loss carryforwards of $215 million, of which substantially all may be carried forward indefinitely. At September 24, 2017, the Company had unused state tax credits of $763 million, of which substantially all may be carried forward indefinitely, unused federal tax credits of $1.0 billion expiring from 2025 through 2037 and unused tax credits of $28 million in foreign jurisdictions expiring from 2033 through 2037. The Company does not expect its federal net operating loss carryforwards to expire unused.

[0001234452-17-000190:notes:162]
At September 24, 2017, the Company has provided a valuation allowance on certain state tax credits, foreign deferred tax assets and state net operating losses of $752 million, $69 million and $42 million, respectively. The valuation allowances reflect the uncertainties surrounding the Company’s ability to generate sufficient future taxable income in certain foreign and state tax jurisdictions to utilize its net operating losses and the Company’s ability to generate sufficient capital gains to utilize all capital losses. The Company believes, more likely than not, that it will have sufficient taxable income after deductions related to share-based awards to utilize its remaining deferred tax assets.

[0001234452-17-000190:notes:163]
A summary of the changes in the amount of unrecognized tax benefits for fiscal 2017, 2016 and 2015 follows (in millions):

[0001234452-17-000190:notes:164]
|  | 2017 |  | 2016 |  | 2015 |
| Beginning balance of unrecognized tax benefits | $ | 271 |  |  | $ | 40 |  |  | $ | 87 |  |
| Additions based on prior year tax positions | 92 |  |  | 20 |  |  | 31 |  |
| Reductions for prior year tax positions and lapse in statute of limitations | (11 | ) |  | (6 | ) |  | (70 | ) |
| Additions for current year tax positions | 23 |  |  | 218 |  |  | 5 |  |
| Settlements with taxing authorities | (3 | ) |  | (1 | ) |  | (13 | ) |
| Ending balance of unrecognized tax benefits | $ | 372 |  |  | $ | 271 |  |  | $ | 40 |  |

[0001234452-17-000190:notes:165]
The Company believes that it is reasonably possible that certain unrecognized tax benefits recorded at September 24, 2017 may result in a significant cash payment in fiscal 2018. Unrecognized tax benefits at September 24, 2017 included $289 million for tax positions that, if recognized, would impact the effective tax rate. The unrecognized tax benefits differ from the amount that would affect the Company’s effective tax rate primarily because the unrecognized tax benefits were included on a gross basis and did not reflect secondary impacts such as the federal deduction for state taxes, adjustments to deferred tax assets and the valuation allowance that might be required if the Company’s tax positions are sustained. The increase in unrecognized tax benefits in fiscal 2017 was primarily due to tax positions related to transfer pricing. The increase in unrecognized tax benefits in fiscal 2016 was primarily due to tax positions related to classification of income. The Company believes that it is reasonably possible that the total amount of unrecognized tax benefits at September 24, 2017 may increase or decrease in fiscal 2018.

[0001234452-17-000190:notes:166]
The Company files income tax returns in the United States federal jurisdiction and various state and foreign jurisdictions. The Company is currently a participant in the IRS Compliance Assurance Process, whereby the IRS and the Company endeavor to agree on the treatment of all tax issues prior to the tax return being filed. The IRS completed its examination of the Company’s tax return for fiscal 2015 and issued a no change letter in February 2017, resulting in no change to the income tax provision. The Company is no longer subject to United States federal income tax examinations for years prior to fiscal 2014. The Company is subject to examination by the California Franchise Tax Board for fiscal years after 2011. The Company is also subject to examination in other taxing jurisdictions in the United States and numerous foreign jurisdictions, most notably in countries where the Company earns a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2000. The Company continually assesses the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of September 24, 2017, the Company believes that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in the Company’s income tax provision and the related accruals.

[0001234452-17-000190:notes:167]
Cash amounts paid for income taxes, net of refunds received, were $1.0 billion, $1.3 billion and $1.2 billion for fiscal 2017, 2016 and 2015, respectively.


## us-gaap:IncomeTaxPolicyTextBlock

[0001234452-17-000190:notes:168]
Income Taxes. The asset and liability approach is used to recognize deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax bases of assets and liabilities. Tax law and rate changes are reflected in income in the period such changes are enacted. The Company records a valuation allowance to reduce deferred tax assets to the amount that is more likely than not to be realized. The Company includes interest and penalties related to income taxes, including unrecognized tax benefits, within income tax expense. The Company classifies all deferred tax assets and liabilities as noncurrent in the consolidated balance sheets.

[0001234452-17-000190:notes:169]
The Company’s income tax returns are based on calculations and assumptions that are subject to examination by the Internal Revenue Service and other tax authorities. In addition, the calculation of the Company’s tax liabilities involves dealing with uncertainties in the application of complex tax regulations. The Company recognizes liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. While the Company believes it has appropriate support for the positions taken on its tax returns, the Company regularly assesses the potential outcomes of examinations by tax authorities in determining the adequacy of its provision for income taxes. The Company continually assesses the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts that give rise to a revision become known.

[0001234452-17-000190:notes:170]
The Company recognizes windfall tax benefits associated with share-based awards directly to stockholders’ equity when realized. A windfall tax benefit occurs when the actual tax benefit realized by the Company upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that the Company had recorded. The Company records windfall tax benefits to stockholders’ equity. A shortfall occurs when the actual tax benefit realized by the Company upon an employee’s disposition of a share-based award is less than the deferred tax asset, if any, associated with the award that the Company has recorded. The Company records shortfall tax detriments when realized to stockholders’ equity to the extent that previous windfall tax benefits exist (referred to as the APIC windfall pool), with any remainder recognized in income tax expense. The Company had a sufficient APIC windfall pool to absorb all shortfalls that occurred in fiscal 2017. When assessing whether a tax benefit relating to share-based compensation has been realized, the Company follows the tax law ordering method, under which current year share-based compensation deductions are assumed to be utilized before net operating loss carryforwards and other tax attributes.


## us-gaap:InventoryPolicyTextBlock

[0001234452-17-000190:notes:171]
Inventories. Inventories are valued at the lower of cost or market (replacement cost, not to exceed net realizable value) using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers, among other things.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001234452-17-000190:notes:172]
At September 24, 2017, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001234452-17-000190:notes:173]
|  | September 24, 2017 |
| Years to Maturity: |  |
| Less than one year | $ | 2,189 |  |
| One to five years | 1,079 |  |
| Five to ten years | — |  |
| Greater than ten years | — |  |
| No single maturity date | 241 |  |
| Total | $ | 3,509 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001234452-17-000190:notes:174]
Marketable Securities

[0001234452-17-000190:notes:175]
Marketable securities were comprised as follows (in millions):

[0001234452-17-000190:notes:176]
|  | Current |  | Noncurrent |
|  | September 24, 2017 |  | September 25, 2016 |  | September 24, 2017 |  | September 25, 2016 |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 23 |  |  | $ | 1,116 |  |  | $ | 959 |  |  | $ | 1,099 |  |
| Corporate bonds and notes | 2,014 |  |  | 10,159 |  |  | 271 |  |  | 8,584 |  |
| Mortgage- and asset-backed and auction rate securities | 93 |  |  | 1,363 |  |  | 40 |  |  | 534 |  |
| Equity and preferred securities and equity funds | 36 |  |  | 64 |  |  | — |  |  | 1,682 |  |
| Debt funds | 109 |  |  | — |  |  | — |  |  | 1,803 |  |
| Total available-for-sale | 2,275 |  |  | 12,702 |  |  | 1,270 |  |  | 13,702 |  |
| Time deposits | 4 |  |  | — |  |  | — |  |  | — |  |
| Total marketable securities | $ | 2,279 |  |  | $ | 12,702 |  |  | $ | 1,270 |  |  | $ | 13,702 |  |

[0001234452-17-000190:notes:177]
During fiscal 2016, the Company exited an investment in a debt fund for which the Company elected the fair value option. The investment would have otherwise been recorded using the equity method. Changes in fair value associated with this investment were recognized in investment and other income, net. During fiscal 2016 and 2015, the net decrease in fair value associated with this investment was negligible and $10 million, respectively. At September 24, 2017, marketable securities also included $4 million of time deposits with original maturities that range from 94 to 285 days.

[0001234452-17-000190:notes:178]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities and auction rate securities.

[0001234452-17-000190:notes:179]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001234452-17-000190:notes:180]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| 2017 | $ | 553 |  |  | $ | (127 | ) |  | $ | 426 |  |
| 2016 | 277 |  |  | (37 | ) |  | 240 |  |
| 2015 | 540 |  |  | (52 | ) |  | 488 |  |

[0001234452-17-000190:notes:181]
Available-for-sale securities were comprised as follows (in millions):

[0001234452-17-000190:notes:182]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| September 24, 2017 |  |  |  |  |  |  |  |
| Equity securities | $ | 8 |  |  | $ | 28 |  |  | $ | — |  |  | $ | 36 |  |
| Debt securities (including debt funds) | 3,497 |  |  | 13 |  |  | (1 | ) |  | 3,509 |  |
|  | $ | 3,505 |  |  | $ | 41 |  |  | $ | (1 | ) |  | $ | 3,545 |  |
| September 25, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,554 |  |  | $ | 204 |  |  | $ | (12 | ) |  | $ | 1,746 |  |
| Debt securities (including debt funds) | 24,363 |  |  | 388 |  |  | (93 | ) |  | 24,658 |  |
|  | $ | 25,917 |  |  | $ | 592 |  |  | $ | (105 | ) |  | $ | 26,404 |  |

[0001234452-17-000190:notes:183]
The following table shows the gross unrealized losses and fair values of the Company’s investments in individual securities that are classified as available-for-sale and have been in a continuous unrealized loss position deemed to be temporary for less than 12 months and for more than 12 months, aggregated by investment category (in millions):

[0001234452-17-000190:notes:184]
|  | September 24, 2017 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| Corporate bonds and notes | $ | 330 |  |  | $ | (1 | ) |  | $ | 21 |  |  | $ | — |  |

[0001234452-17-000190:notes:185]
|  | September 25, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 444 |  |  | $ | (5 | ) |  | $ | 16 |  |  | $ | — |  |
| Corporate bonds and notes | 2,775 |  |  | (12 | ) |  | 1,033 |  |  | (65 | ) |
| Mortgage- and asset-backed and auction rate securities | 337 |  |  | (3 | ) |  | 211 |  |  | (2 | ) |
| Equity and preferred securities and equity funds | 312 |  |  | (4 | ) |  | 130 |  |  | (8 | ) |
| Debt funds | — |  |  | — |  |  | 309 |  |  | (6 | ) |
|  | $ | 3,868 |  |  | $ | (24 | ) |  | $ | 1,699 |  |  | $ | (81 | ) |

[0001234452-17-000190:notes:186]
In connection with the proposed NXP transaction (Note 9), the Company divested a substantial portion of its marketable securities portfolio in order to finance, in part, that transaction. Marketable securities that were expected to be used to finance the NXP transaction were classified as noncurrent at September 24, 2017 as they are not considered available for current operations. Given the change in the Company’s intention to sell certain marketable securities, the Company recognized other-than-temporary impairment losses in fiscal 2017 for such marketable securities (Note 2) and may recognize additional losses prior to the sale of such marketable securities. For the available-for-sale securities that are not expected to be sold to finance the NXP transaction, the Company concluded that the unrealized losses were temporary at September 24, 2017. Further, for debt securities with unrealized losses, as of September 24, 2017, the Company did not have the intent to sell, nor was it more likely than not that the Company would be required to sell, such securities before recovery or maturity.


## us-gaap:LegalCostsPolicyTextBlock

[0001234452-17-000190:notes:187]
The Company’s legal costs associated with defending itself are recorded to expense as incurred.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001234452-17-000190:notes:188]
Recent Accounting Pronouncements. In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue as control of goods or services transfers to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The Company will adopt the new guidance in the first quarter of fiscal 2019 and currently expects to apply the modified retrospective approach, which means that the cumulative effect of applying the new guidance is recognized as an adjustment to the opening retained earnings balance. Given the scope of work required to implement the recognition and disclosure requirements under the new guidance, the Company has made progress in the identification of changes to policy, processes, systems and controls, and the Company continues to assess data availability and presentation necessary to meet the additional disclosure requirements of the guidance in the notes to the consolidated financial statements.

[0001234452-17-000190:notes:189]
The Company currently expects the adoption of this new guidance to most significantly impact its licensing business. Specifically, the Company expects a change in the timing of revenues recognized from sales-based royalties. The Company currently recognizes sales-based royalties as revenues in the period in which such royalties are reported by licensees, which is after the conclusion of the quarter in which the licensees’ sales occur and when all other revenue recognition criteria are met. Under the new guidance, the Company will be required to estimate and recognize sales-based royalties in the period in which the associated sales occur, resulting in an acceleration of revenue recognition compared to the current method. Upon adoption of the new guidance, licenses to use portions of the Company’s intellectual property portfolio will be considered one performance obligation, and license fees will be recognized as revenues on a straight-line basis over the term of the license agreement, which is similar to the recognition of license revenues under the current guidance. The Company currently accounts for customer incentive arrangements in its licensing and semiconductor businesses, including volume-related and other pricing rebates or cost reimbursements for marketing and other activities involving certain of the Company’s products and technologies in part based on the maximum potential liability. Under the new guidance, the Company expects to estimate the amount of all customer incentives. The Company does not otherwise expect the adoption of the new guidance will have a material impact on its businesses.

[0001234452-17-000190:notes:190]
In January 2016, the FASB issued new guidance on classifying and measuring financial instruments, which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk be recognized separately in other comprehensive income. Additionally, it changes the disclosure requirements for financial instruments. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Early adoption is permitted for certain provisions. The Company does not intend adopt any of the provisions early and is in the process of determining the effects the adoption will have on its consolidated financial statements.

[0001234452-17-000190:notes:191]
In February 2016, the FASB issued new guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease guidance. The new guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. The new guidance must be adopted using the modified retrospective approach. The Company will adopt the new guidance in the first quarter of fiscal 2020 and is in the process of determining the effects the adoption will have on its consolidated financial statements.

[0001234452-17-000190:notes:192]
In March 2016, the FASB issued new guidance that changes the accounting for share-based payments, including income taxes, classification of awards and classification in the statement of cash flows. The new guidance will increase the number of shares an employer can withhold to cover income taxes on share-based payment awards and still qualify for the exemption to liability classification. In addition, under the new guidance, excess tax benefits or deficiencies associated with share-based payment awards will be recognized through earnings when the awards vest or settle, rather than in stockholders’ equity. As a result, subsequent to adoption, the Company’s income tax expense and associated effective tax rate will be impacted by fluctuations in stock price between the grant dates and vesting dates of equity awards. The new guidance will be effective for the Company starting in the first quarter of fiscal 2018.

[0001234452-17-000190:notes:193]
In June 2016, the FASB issued new guidance that changes the accounting for recognizing impairments of financial assets. Under the new guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The new guidance also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The new guidance will be effective for the Company starting in the first quarter of fiscal 2021. Early adoption is permitted starting in the first quarter of fiscal 2020. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.

[0001234452-17-000190:notes:194]
In August 2016, the FASB issued new guidance related to the classification of certain cash receipts and cash payments on the statement of cash flows. The new guidance will be effective for the Company beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. The Company does not intend to adopt the new guidance early and is currently evaluating the impact of this accounting standard update on its consolidated financial statements.

[0001234452-17-000190:notes:195]
In October 2016, the FASB issued new guidance that changes the accounting for income tax effects of intra-entity transfers of assets other than inventory. Under the new guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. The Company does not intend to adopt the new guidance early and is currently evaluating the impact of this accounting standard update on its consolidated financial statements.

[0001234452-17-000190:notes:196]
In August 2017, the FASB issued new guidance that expands and refines hedge accounting for both financial and non-financial risks, aligns the recognition and presentation of the effects of hedging instruments and hedged items in the financial statements, and includes targeted improvements related to the assessment of hedge effectiveness. The new guidance also modifies disclosure requirements for hedging activities. The new guidance will be effective for the Company starting in the first quarter of fiscal 2020, and early adoption is permitted in any interim period. The Company is currently evaluating the impact of the new guidance on its consolidated financial statements as well as whether to adopt the new guidance early.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001234452-17-000190:notes:197]
The Company and Its Significant Accounting Policies

[0001234452-17-000190:notes:198]
The Company. QUALCOMM Incorporated, a Delaware corporation, and its subsidiaries (collectively the Company or Qualcomm) develop, design, manufacture, have manufactured on its behalf and market digital communications products, which principally consist of integrated circuits and system software based on CDMA, OFDMA and other technologies, for use in mobile devices, wireless networks,  devices used in the Internet of Things (IoT), broadband gateway equipment, consumer electronic devices and automotive telematics and infotainment systems. The Company also grants licenses to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products and receives fixed license fees (payable in one or more installments) as well as ongoing royalties based on sales by licensees of wireless products incorporating its patented technologies.

[0001234452-17-000190:notes:199]
Financial Statement Preparation. The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in the Company’s consolidated financial statements and the accompanying notes. Examples of the Company’s significant accounting estimates that may involve a higher degree of judgment and complexity than others include: the determination of other-than-temporary impairments of marketable securities and other investments; the valuation of inventories; the valuation and assessment of the recoverability of goodwill and other indefinite-lived and long-lived assets; the recognition, measurement and disclosure of loss contingencies related to legal and regulatory proceedings; and the calculation of tax liabilities, including the recognition and measurement of uncertain tax positions. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

[0001234452-17-000190:notes:200]
Fiscal Year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. The fiscal years ended September 24, 2017, September 25, 2016 and September 27, 2015 included 52 weeks.

[0001234452-17-000190:notes:201]
Marketable Securities. Marketable securities include available-for-sale securities and certain time deposits for which classification is determined at the time of purchase and reevaluated at each balance sheet date. The Company also held trading securities and securities for which the Company had elected the fair value option that would have otherwise been recorded using the equity method. These investments were exited during fiscal 2016, and the related changes in fair value associated with these investments were recognized in investment and other income, net and were negligible in fiscal 2016 and 2015. The Company classifies marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value. The net unrealized gains or losses on available-for-sale securities are recorded as a component of accumulated other comprehensive income, net of income taxes. The realized gains and losses on marketable securities are determined using the specific identification method.

[0001234452-17-000190:notes:202]
At each balance sheet date, the Company assesses available-for-sale securities in an unrealized loss position to determine whether the unrealized loss is other than temporary. The Company considers factors including: the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; how long the market value of the security has been less than its cost basis; the security’s relative performance versus its peers, sector or asset class; expected market volatility; the market and economy in general; analyst recommendations and price targets; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.

[0001234452-17-000190:notes:203]
If a debt security’s market value is below amortized cost and the Company either intends to sell the security or it is more likely than not that the Company will be required to sell the security before its anticipated recovery, the Company records an other-than-temporary impairment charge to investment and other income, net for the entire amount of the impairment. For the remaining debt securities, if an other-than-temporary impairment exists, the Company separates the other-than-temporary impairment into the portion of the loss related to credit factors, or the credit loss portion, which is recorded as a charge to investment and other income, net, and the portion of the loss that is not related to credit factors, or the noncredit loss portion, which is recorded as a component of other accumulated comprehensive income, net of income taxes.

[0001234452-17-000190:notes:204]
For equity securities, the Company considers the loss relative to the expected volatility and the likelihood of recovery over a reasonable period of time. If events and circumstances indicate that a decline in the value of an equity security has occurred and is other than temporary, the Company records a charge to investment and other income, net for the difference between fair value and cost at the balance sheet date. Additionally, if the Company has either the intent to sell the equity security or does not have both the intent and the ability to hold the equity security until its anticipated recovery, the Company records a charge to investment and other income, net for the difference between fair value and cost at the balance sheet date.

[0001234452-17-000190:notes:205]
Equity and Cost Method Investments. The Company generally accounts for non-marketable equity investments either under the equity or the cost method. Equity investments over which the Company has significant influence, but not control over the investee and is not the primary beneficiary of the investee’s activities are accounted for under the equity method. Other non-marketable equity investments are accounted for under the cost method. The Company’s share of gains and losses in equity method investments are recorded in investment and other income, net. The Company monitors non-marketable equity investments for events or circumstances that could indicate the investments are impaired, such as a deterioration in the investee’s financial condition and business forecasts and lower valuations in recently completed or proposed financings, and records a charge to investment and other income, net for the difference between the estimated fair value and the carrying value.

[0001234452-17-000190:notes:206]
Transactions with equity method investees are considered related party transactions. Revenues from certain licensing and services contracts with two of the Company’s equity method investees were $165 million, $196 million and negligible in fiscal 2017, 2016 and 2015, respectively. The Company eliminates unrealized profit or loss related to such transactions in relation to its ownership interest in the investee, which is recorded as a component of equity in net losses in investees in investment and other income, net. Aggregate accounts receivable from these equity method investees were $29 million and $73 million at September 24, 2017 and September 25, 2016, respectively.

[0001234452-17-000190:notes:207]
Gross Notional Amounts: The gross notional amounts of the Company’s interest rate and foreign currency derivatives by instrument type were as follows (in millions):

[0001234452-17-000190:notes:208]
|  | September 24, 2017 |  | September 25, 2016 |
| Forwards | $ | 163 |  |  | $ | 108 |  |
| Options | 2,333 |  |  | 929 |  |
| Swaps | 3,000 |  |  | 3,061 |  |
|  | $ | 5,496 |  |  | $ | 4,098 |  |

[0001234452-17-000190:notes:209]
The gross notional amounts by currency were as follows (in millions):

[0001234452-17-000190:notes:210]
|  | September 24, 2017 |  | September 25, 2016 |
| Chinese renminbi | $ | 1,460 |  |  | $ | 325 |  |
| Euro | 146 |  |  | 31 |  |
| Indian rupee | 772 |  |  | 433 |  |
| Japanese yen | 68 |  |  | 97 |  |
| Korean won | 50 |  |  | 85 |  |
| United States dollar | 3,000 |  |  | 3,045 |  |
| Other | — |  |  | 82 |  |
|  | $ | 5,496 |  |  | $ | 4,098 |  |

[0001234452-17-000190:notes:211]
Allowances for Doubtful Accounts. The Company maintains allowances for doubtful accounts for estimated losses resulting from the inability of the Company’s customers to make required payments. The Company considers the following factors when determining if collection of required payments is reasonably assured: customer credit-worthiness; past transaction history with the customer; current economic industry trends; changes in customer payment terms; and bank credit-worthiness for letters of credit. If the Company has no previous experience with the customer, the Company may request financial information, including financial statements or other documents, to determine that the customer has the means of making payment. The Company may also obtain reports from various credit organizations to determine that the customer has a history of paying its creditors. If these factors do not indicate collection is reasonably assured, revenue is deferred as a reduction to accounts receivable until collection becomes reasonably assured, which is generally upon receipt of cash. If the financial condition of the Company’s customers was to deteriorate, adversely affecting their ability to make payments, additional allowances would be required.

[0001234452-17-000190:notes:212]
Property, Plant and Equipment. Property, plant and equipment are recorded at cost and depreciated or amortized using the straight-line method over their estimated useful lives. Upon the retirement or disposition of property, plant and equipment, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded, when appropriate. Buildings on owned land are depreciated over 30 years, and building improvements are depreciated over their useful lives ranging from 7 to 15 years. Leasehold improvements are amortized over the shorter of their estimated useful lives, not to exceed 15 years, or the remaining term of the related lease. Other property, plant and equipment have useful lives ranging from 2 to 25 years. Leased property meeting certain capital lease criteria is capitalized, and the net present value of the related lease payments is recorded as a liability. Amortization of assets under capital leases is recorded using the straight-line method over the shorter of the estimated useful lives or the lease terms. Maintenance, repairs and minor renewals or betterments are charged to expense as incurred.

[0001234452-17-000190:notes:213]
Revenue Recognition. The Company derives revenues principally from sales of integrated circuit products and licensing of its intellectual property and also generates revenues through sales of products that connect medical devices and by performing software hosting, software development and other services. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of the Company’s deliverables and obligations. Unearned revenues consist primarily of license fees for intellectual property with continuing performance obligations.

[0001234452-17-000190:notes:214]
Revenues from sales of the Company’s products are recognized at the time of shipment, or when title and risk of loss pass to the customer and all other criteria for revenue recognition are met, if later. Revenues from providing services are recognized when earned. Revenues from providing services were less than 10% of total revenues for all periods presented.

[0001234452-17-000190:notes:215]
The Company grants licenses or otherwise provides rights to use portions of its intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Licensees typically pay a fixed license fee in one or more installments and royalties based on their sales of products incorporating or using the Company’s licensed intellectual property. License fees are recognized over the estimated period of benefit of the license to the licensee, typically 5 to 15 years. Royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). The Company broadly provides per unit running royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops, which in general, effectively provide for a maximum running royalty amount per device (i.e., the royalty caps limit the running royalties due on a per unit basis). The Company earns royalties on such licensed products sold worldwide by its licensees at the time that the licensees’ sales occur. The Company’s licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter, which is generally the following quarter. The Company recognizes royalty revenues based on royalties reported by licensees during the quarter and when all other revenue recognition criteria are met.

[0001234452-17-000190:notes:216]
The Company records reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of the Company’s products and technologies. The charges for such arrangements are recorded as a reduction to accounts receivable or as other current liabilities based on whether the Company has the contractual right of offset. The Company recognizes the liability based on the estimated amount of the incentive, or if not reasonably estimated, the maximum potential liability, at the later of the date at which the Company records the related revenues or the date at which the Company offers the incentive or, if payment is contingent, when the contingency is resolved. In certain arrangements, the liabilities are based on customer forecasts. The Company reverses accruals for unclaimed incentive amounts to revenues when the unclaimed amounts are no longer subject to payment.

[0001234452-17-000190:notes:217]
Shipping and Handling Costs. Costs incurred for shipping and handling are included in cost of revenues. Amounts billed to a customer for shipping and handling are reported as revenues.

[0001234452-17-000190:notes:218]
Share-Based Compensation. Share-based compensation expense for equity-classified awards, principally related to restricted stock units (RSUs), is measured at the grant date, or at the acquisition date for awards assumed in business combinations, based on the estimated fair value of the award and is recognized over the employee’s requisite service period. Share-based compensation expense is adjusted to exclude amounts related to share-based awards that are expected to be forfeited.

[0001234452-17-000190:notes:219]
The fair values of RSUs are estimated based on the fair market values of the underlying stock on the dates of grant or dates the RSUs are assumed. If RSUs do not have the right to participate in dividends, the fair values are discounted by the dividend yield. The weighted-average estimated fair values of employee RSUs granted during fiscal 2017, 2016 and 2015 were $66.54, $53.56 and $68.77 per share, respectively. Upon vesting, the Company issues new shares of common stock. For the majority of RSUs, shares are issued on the vesting dates net of the amount of shares needed to satisfy statutory tax withholding requirements to be paid by the Company on behalf of the employees. As a result, the actual number of shares issued will be fewer than the number of RSUs outstanding. The annual pre-vest forfeiture rate for RSUs was estimated to be approximately 5%, 4% and 3% in fiscal 2017, 2016 and 2015, respectively.

[0001234452-17-000190:notes:220]
Total share-based compensation expense, related to all of the Company’s share-based awards, was comprised as follows (in millions):

[0001234452-17-000190:notes:221]
|  | 2017 |  | 2016 |  | 2015 |
| Cost of revenues | $ | 38 |  |  | $ | 40 |  |  | $ | 42 |  |
| Research and development | 588 |  |  | 614 |  |  | 659 |  |
| Selling, general and administrative | 288 |  |  | 289 |  |  | 325 |  |
| Share-based compensation expense before income taxes | 914 |  |  | 943 |  |  | 1,026 |  |
| Related income tax benefit | (161 | ) |  | (190 | ) |  | (190 | ) |
|  | $ | 753 |  |  | $ | 753 |  |  | $ | 836 |  |

[0001234452-17-000190:notes:222]
Legal and Regulatory Proceedings. The Company is currently involved in certain legal and regulatory proceedings. The Company discloses a loss contingency if there is at least a reasonable possibility that a material loss has been incurred. The Company records its best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, the Company records the minimum estimated liability. As additional information becomes available, the Company assesses the potential liability related to pending legal and regulatory proceedings and revises its estimates and updates its disclosures accordingly. The Company’s legal costs associated with defending itself are recorded to expense as incurred.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001234452-17-000190:notes:223]
Summarized Quarterly Data (Unaudited)

[0001234452-17-000190:notes:224]
The following financial information reflects all normal recurring adjustments that are, in the opinion of management, necessary for a fair statement of the results of the interim periods.

[0001234452-17-000190:notes:225]
The table below presents quarterly data for fiscal 2017 and 2016 (in millions, except per share data):

[0001234452-17-000190:notes:226]
|  | 1st Quarter |  | 2nd Quarter |  | 3rd Quarter |  | 4th Quarter |
| 2017 (1) |  |  |  |  |  |  |  |
| Revenues | $ | 5,999 |  |  | $ | 5,016 |  |  | $ | 5,371 |  |  | $ | 5,905 |  |
| Operating income (2) | 778 |  |  | 729 |  |  | 773 |  |  | 333 |  |
| Net income (2) | 681 |  |  | 749 |  |  | 865 |  |  | 168 |  |
| Net income attributable to Qualcomm | 682 |  |  | 749 |  |  | 866 |  |  | 168 |  |
| Basic earnings per share attributable to Qualcomm (3): | $ | 0.46 |  |  | $ | 0.51 |  |  | $ | 0.59 |  |  | $ | 0.11 |  |
| Diluted earnings per share attributable to Qualcomm (3): | 0.46 |  |  | 0.50 |  |  | 0.58 |  |  | 0.11 |  |
| 2016 (1) |  |  |  |  |  |  |  |
| Revenues | $ | 5,775 |  |  | $ | 5,551 |  |  | $ | 6,044 |  |  | $ | 6,184 |  |
| Operating income | 1,685 |  |  | 1,415 |  |  | 1,592 |  |  | 1,804 |  |
| Net income | 1,496 |  |  | 1,164 |  |  | 1,443 |  |  | 1,599 |  |
| Net income attributable to Qualcomm | 1,498 |  |  | 1,164 |  |  | 1,444 |  |  | 1,599 |  |
| Basic earnings per share attributable to Qualcomm (3): | $ | 1.00 |  |  | $ | 0.78 |  |  | $ | 0.98 |  |  | $ | 1.08 |  |
| Diluted earnings per share attributable to Qualcomm (3): | 0.99 |  |  | 0.78 |  |  | 0.97 |  |  | 1.07 |  |

[0001234452-17-000190:notes:227]
| (1) | Amounts, other than per share amounts, are rounded to millions each quarter. Therefore, the sum of the quarterly amounts may not equal the annual amounts reported. |

[0001234452-17-000190:notes:228]
| (2) | Operating income and net income in the fourth quarter of fiscal 2017 were negatively impacted by a $778 million charge related to the TFTC fine. |

[0001234452-17-000190:notes:229]
| (3) | Earnings per share attributable to Qualcomm are computed independently for each quarter and the full year based upon respective average shares outstanding. Therefore, the sum of the quarterly earnings per share amounts may not equal the annual amounts reported. |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001234452-17-000190:notes:230]
Reconciling items in the previous table were as follows (in millions):

[0001234452-17-000190:notes:231]
|  | 2017 |  | 2016 |  | 2015 |
| Revenues |  |  |  |  |  |
| Nonreportable segments | $ | 311 |  |  | $ | 438 |  |  | $ | 181 |  |
| BlackBerry arbitration | (962 | ) |  | — |  |  | — |  |
| Unallocated other revenues | (95 | ) |  | — |  |  | — |  |
| Intersegment eliminations | — |  |  | (4 | ) |  | (5 | ) |
|  | $ | (746 | ) |  | $ | 434 |  |  | $ | 176 |  |
| EBT |  |  |  |  |  |
| BlackBerry arbitration | $ | (962 | ) |  | $ | — |  |  | $ | — |  |
| Unallocated other revenues | (95 | ) |  | — |  |  | — |  |
| Unallocated cost of revenues | (517 | ) |  | (495 | ) |  | (314 | ) |
| Unallocated research and development expenses | (1,056 | ) |  | (799 | ) |  | (809 | ) |
| Unallocated selling, general and administrative expenses | (647 | ) |  | (478 | ) |  | (497 | ) |
| Unallocated other expense, net | (1,742 | ) |  | (154 | ) |  | (1,289 | ) |
| Unallocated interest expense | (488 | ) |  | (292 | ) |  | (101 | ) |
| Unallocated investment and other income, net | 913 |  |  | 667 |  |  | 855 |  |
| Nonreportable segments | (373 | ) |  | (342 | ) |  | (630 | ) |
| Intersegment eliminations | — |  |  | — |  |  | (1 | ) |
|  | $ | (4,967 | ) |  | $ | (1,893 | ) |  | $ | (2,786 | ) |

[0001234452-17-000190:notes:232]
Unallocated acquisition-related expenses were comprised as follows (in millions):

[0001234452-17-000190:notes:233]
|  | 2017 |  | 2016 |  | 2015 |
| Cost of revenues | $ | 437 |  |  | $ | 434 |  |  | $ | 272 |  |
| Research and development expenses | 20 |  |  | 10 |  |  | 14 |  |
| Selling, general and administrative expenses | 272 |  |  | 99 |  |  | 72 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001234452-17-000190:notes:234]
Strategic Realignment Plan

[0001234452-17-000190:notes:235]
On July 22, 2015, the Company announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as the Company works to create sustainable long-term value for stockholders. As part of this, among other actions, the Company implemented a cost reduction plan, which included a series of targeted reductions across the Company’s businesses, particularly in QCT, and a reduction to its annual share-based compensation grants. Restructuring activities were initiated in the fourth quarter of fiscal 2015, the cost reduction initiatives were achieved by the end of fiscal 2016 and other activities under the plan were completed by the end of fiscal 2017. During fiscal 2017, 2016 and 2015, the Company recorded restructuring and restructuring-related charges of $37 million, $202 million (which was partially offset by a $48 million gain on the sale of the Company’s business that provided augmented reality applications) and $190 million, respectively.


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001234452-17-000190:notes:236]
Revenues by country were as follows (in millions):

[0001234452-17-000190:notes:237]
|  | 2017 |  | 2016 |  | 2015 |
| China (including Hong Kong) | $ | 14,579 |  |  | $ | 13,503 |  |  | $ | 13,337 |  |
| South Korea | 3,538 |  |  | 3,918 |  |  | 4,107 |  |
| United States | 513 |  |  | 386 |  |  | 246 |  |
| Other foreign | 3,661 |  |  | 5,747 |  |  | 7,591 |  |
|  | $ | 22,291 |  |  | $ | 23,554 |  |  | $ | 25,281 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001234452-17-000190:notes:238]
The table below presents revenues, EBT and total assets for reportable segments (in millions):

[0001234452-17-000190:notes:239]
|  | 2017 |  | 2016 |  | 2015 |
| Revenues |  |  |  |  |  |
| QCT | $ | 16,479 |  |  | $ | 15,409 |  |  | $ | 17,154 |  |
| QTL | 6,445 |  |  | 7,664 |  |  | 7,947 |  |
| QSI | 113 |  |  | 47 |  |  | 4 |  |
| Reconciling Items | (746 | ) |  | 434 |  |  | 176 |  |
| Total | $ | 22,291 |  |  | $ | 23,554 |  |  | $ | 25,281 |  |
| EBT |  |  |  |  |  |
| QCT | $ | 2,747 |  |  | $ | 1,812 |  |  | $ | 2,465 |  |
| QTL | 5,175 |  |  | 6,528 |  |  | 6,882 |  |
| QSI | 65 |  |  | 386 |  |  | (74 | ) |
| Reconciling Items | (4,967 | ) |  | (1,893 | ) |  | (2,786 | ) |
| Total | $ | 3,020 |  |  | $ | 6,833 |  |  | $ | 6,487 |  |
| Assets |  |  |  |  |  |
| QCT | $ | 3,830 |  |  | $ | 2,995 |  |  | $ | 2,923 |  |
| QTL | 1,735 |  |  | 644 |  |  | 438 |  |
| QSI | 1,037 |  |  | 910 |  |  | 812 |  |
| Reconciling Items | 58,884 |  |  | 47,810 |  |  | 46,623 |  |
| Total | $ | 65,486 |  |  | $ | 52,359 |  |  | $ | 50,796 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001234452-17-000190:notes:240]
SCHEDULE II

[0001234452-17-000190:notes:241]
QUALCOMM INCORPORATED

[0001234452-17-000190:notes:242]
VALUATION AND QUALIFYING ACCOUNTS

[0001234452-17-000190:notes:243]
(In millions)

[0001234452-17-000190:notes:244]
|  | Balance atBeginning ofPeriod |  | Charged(Credited) toCosts andExpenses |  | Deductions |  | Other |  | Balance atEnd ofPeriod |
| Year ended September 24, 2017 |  |  |  |  |  |  |  |  |  |
| Allowances: |  |  |  |  |  |  |  |  |  |
| — trade receivables | $ | 1 |  |  | $ | 10 |  |  | $ | — |  |  | $ | — |  |  | $ | 11 |  |
| Valuation allowance on deferred tax assets | 754 |  |  | 109 |  |  | — |  |  | — |  |  | 863 |  |
|  | $ | 755 |  |  | $ | 119 |  |  | $ | — |  |  | $ | — |  |  | $ | 874 |  |
| Year ended September 25, 2016 |  |  |  |  |  |  |  |  |  |
| Allowances: |  |  |  |  |  |  |  |  |  |
| — trade receivables | $ | 6 |  |  | $ | (5 | ) |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |
| Valuation allowance on deferred tax assets | 635 |  |  | 118 |  |  | — |  |  | 1 |  | (a) | 754 |  |
|  | $ | 641 |  |  | $ | 113 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 755 |  |
| Year ended September 27, 2015 |  |  |  |  |  |  |  |  |  |
| Allowances: |  |  |  |  |  |  |  |  |  |
| — trade receivables | $ | 5 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |
| — notes receivable | 4 |  |  | — |  |  | (3 | ) |  | (1 | ) | (b) | — |  |
| Valuation allowance on deferred tax assets | 414 |  |  | 130 |  |  | — |  |  | 91 |  | (a) | 635 |  |
|  | $ | 423 |  |  | $ | 131 |  |  | $ | (3 | ) |  | $ | 90 |  |  | $ | 641 |  |

[0001234452-17-000190:notes:245]
| (a) | This amount was recorded to goodwill in connection with a business acquisition. |

[0001234452-17-000190:notes:246]
| (b) | This amount relates to notes receivable on strategic investments that were converted to cost method equity investments. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001234452-17-000190:notes:247]
Segment Information

[0001234452-17-000190:notes:248]
The Company is organized on the basis of products and services and has three reportable segments. The Company conducts business primarily through its QCT (Qualcomm CDMA Technologies) semiconductor business and its QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices, wireless networks, devices used in the Internet of Things (IoT), broadband gateway equipment, consumer electronic devices and automotive telematics and infotainment systems. QTL grants licenses to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. The Company’s QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an equity method investee. The Company also has nonreportable segments, including its mobile health, data center, small cell and other wireless technology and service initiatives.

[0001234452-17-000190:notes:249]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense; certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. Additionally, starting with acquisitions in the second quarter of fiscal 2017, unallocated charges include recognition of the depreciation related to the step-up of property, plant and equipment to fair value. Such charges related to acquisitions that were completed prior to the second quarter of fiscal 2017 continue to be allocated to the respective segment, and such amounts are not material. All of the costs related to the initial research of 5G (fifth generation) technology are included in unallocated corporate research and development expenses, whereas initial costs related to the research of 3G (third generation) and 4G (fourth generation) technology were recorded in both the QCT segment and unallocated corporate research and development expenses based on the nature of the activity. Fiscal 2016 and 2015 results have not been revised as such costs were incurred prior to fiscal 2014.

[0001234452-17-000190:notes:250]
The Company reports revenues from external customers by country based on the location to which its products or services are delivered, which for QCT is generally the country in which its customers manufacture their products, or for licensing revenues, the invoiced addresses of its licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing the Company’s products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues could include revenues related to shipments of integrated circuits to a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States. Revenues by country were as follows (in millions):

[0001234452-17-000190:notes:251]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets include certain non-marketable equity instruments and other investments and a receivable from the sale of wireless spectrum in fiscal 2016 (Note 2). QSI assets at September 24, 2017, September 25, 2016 and September 27, 2015 included $254 million, $162 million and $163 million, respectively, related to investments in equity method investees. The increase in QCT segment assets resulted primarily from the Company’s recently formed RF360 Holdings joint venture in the second quarter of fiscal 2017 (Note 9). The increase in QTL segment assets was due to an increase in accounts receivable (Note 2). Total segment assets differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable securities, property, plant and equipment, deferred tax assets, intangible assets and assets of nonreportable segments. The net book values of long-lived tangible assets located outside of the United States were $1.4 billion, $404 million and $414 million at September 24, 2017, September 25, 2016 and September 27, 2015, respectively. The increase in fiscal 2017 was primarily from the RF360 Holdings joint venture, which has substantially all of its operations outside the United States. The net book values of long-lived tangible assets located in the United States were $1.8 billion, $1.9 billion and $2.1 billion at September 24, 2017, September 25, 2016 and September 27, 2015, respectively.

[0001234452-17-000190:notes:252]
In May 2017, in connection with the arbitration decision, BlackBerry Limited (BlackBerry) and the Company entered into a Joint Stipulation Regarding Final Award Agreement agreeing that the Company would pay BlackBerry $940 million to cover the award amount, pre-judgment interest and attorneys’ fees. This amount, which was paid in the third quarter of fiscal 2017, also reflected $22 million that was owed to the Company by BlackBerry, which was recorded as revenues in the QTL segment. The remaining amount was recorded as an adjustment to revenues related to the arbitration decision, which was not allocated to QTL in the Company’s management reports because it will not be considered in evaluating segment results. Unallocated other revenues is comprised of a reduction to revenues related to the portion of a business arrangement under negotiation that resolves a legal dispute. Unallocated other expense, net in fiscal 2017 was comprised of charges related to the fines imposed by the KFTC and the TFTC (Note 7), as well as restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan, which was substantially implemented in fiscal 2016 (Note 10). Unallocated other expense, net for fiscal 2016 was comprised of net restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan (Note 10). Unallocated other expense, net for fiscal 2015 was comprised of a charge related to the resolution reached with the NDRC, goodwill and intangible asset impairment charges related to three of the Company’s nonreportable segments and restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan, partially offset by a gain on the sale of certain property, plant and equipment (Note 2).


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001234452-17-000190:notes:253]
The Company reports revenues from external customers by country based on the location to which its products or services are delivered, which for QCT is generally the country in which its customers manufacture their products, or for licensing revenues, the invoiced addresses of its licensees.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001234452-17-000190:notes:254]
Capital Stock

[0001234452-17-000190:notes:255]
Stock Repurchase Program. On March 9, 2015, the Company announced a stock repurchase program authorizing it to repurchase up to $15 billion of the Company’s common stock. The stock repurchase program has no expiration date. During fiscal 2015, the Company entered into two accelerated share repurchase agreements (ASR Agreements) with two financial institutions under which the Company paid an aggregate of $5.0 billion to the financial institutions and received from them a total of 78,276,000 shares of the Company’s common stock based on the average daily volume weighted-average stock price of the Company’s common stock during the respective terms of the ASR Agreements, less a discount. The shares were retired and recorded as a reduction to stockholders’ equity.

[0001234452-17-000190:notes:256]
During fiscal 2017, 2016 and 2015, the Company repurchased and retired an additional 22,792,000, 73,782,000 and 94,159,000 shares of common stock, respectively, for $1.3 billion, $3.9 billion and $6.2 billion, respectively, before commissions. To reflect share repurchases in the consolidated balance sheet, the Company (i) reduces common stock for the par value of the shares, (ii) reduces paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) records the residual amount to retained earnings. At September 24, 2017, $1.6 billion remained authorized for repurchase under the Company’s stock repurchase program.

[0001234452-17-000190:notes:257]
Dividends. On October 10, 2017, the Company announced a cash dividend of $0.57 per share on the Company’s common stock, payable on December 15, 2017 to stockholders of record as of the close of business on November 29, 2017. Dividends charged to retained earnings in fiscal 2017, 2016 and 2015 were as follows (in millions, except per share data):
