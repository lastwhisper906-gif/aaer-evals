# QCOM 8-K — 0001234452-17-000189 filed 2017-11-01

## item codes, every 8-K on or before 2017-11-01

- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2017-11-01

- none on or before 2017-11-01

## item 2.02 — earnings release, exhibit 99.1

[0001234452-17-000189:8k_2_02:1]
EX-99.1
2
qcom092417erex991.htm
EXHIBIT 99.1

[0001234452-17-000189:8k_2_02:2]
Exhibit

[0001234452-17-000189:8k_2_02:3]
Exhibit 99.1

[0001234452-17-000189:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-17-000189:8k_2_02:5]
Qualcomm Contact:

[0001234452-17-000189:8k_2_02:6]
John Sinnott

[0001234452-17-000189:8k_2_02:7]
Vice President, Investor Relations

[0001234452-17-000189:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-17-000189:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-17-000189:8k_2_02:10]
Qualcomm Announces Fourth Quarter and Fiscal 2017 Results

[0001234452-17-000189:8k_2_02:11]
Fiscal 2017 Revenues $22.3 billion

[0001234452-17-000189:8k_2_02:12]
GAAP EPS $1.65, Non-GAAP EPS $4.28

[0001234452-17-000189:8k_2_02:13]
SAN DIEGO - November 1, 2017 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal fourth quarter and year ended September 24, 2017.

[0001234452-17-000189:8k_2_02:14]
“Our fourth quarter and fiscal 2017 results reflect continued product leadership and profitability improvement in our semiconductor business, including strength in adjacent opportunities outside mobile,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “We continue to see strong growth trends for global 3G/4G device shipments and are focused on protecting the established value of our technologies and inventions.  We are leading the industry to 5G and are well positioned with our product and technology leadership to continue our expansion into many exciting new product categories, such as automotive, mobile computing, networking and the Internet of Things.”

[0001234452-17-000189:8k_2_02:15]
GAAP Results*

[0001234452-17-000189:8k_2_02:16]
Fourth Quarter Fiscal 2017

[0001234452-17-000189:8k_2_02:17]
|  | Q4 Fiscal 2017 |  | Q4 Fiscal 2016 |  | Year-Over-Year Change |  | Q3 Fiscal 2017 |  | Sequential Change |
| Revenues | $5.9B |  | $6.2B |  | (5%) |  | $5.4B |  | +10% |
| Operating income | $0.3B |  | $1.8B |  | (82%) |  | $0.8B |  | (57%) |
| Net income 1 | $0.2B |  | $1.6B |  | (89%) |  | $0.9B |  | (81%) |
| Diluted earnings per share 1 | $0.11 |  | $1.07 |  | (90%) |  | $0.58 |  | (81%) |
| Operating cash flow | $2.4B |  | $2.1B |  | +16% |  | $0.1B |  | N/M |

[0001234452-17-000189:8k_2_02:18]
1 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests), unless otherwise stated.

[0001234452-17-000189:8k_2_02:19]
Fiscal 2017

[0001234452-17-000189:8k_2_02:20]
|  | Fiscal 2017 |  | Fiscal2016 |  | Year-Over-Year Change |
| Revenues | $22.3B |  | $23.6B |  | (5%) |
| Operating income | $2.6B |  | $6.5B |  | (60%) |
| Net income | $2.5B |  | $5.7B |  | (57%) |
| Diluted earnings per share | $1.65 |  | $3.81 |  | (57%) |
| Operating cash flow | $4.7B |  | $7.4B |  | (37%) |

[0001234452-17-000189:8k_2_02:21]
Non-GAAP Results*

[0001234452-17-000189:8k_2_02:22]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding the Company’s use of Non-GAAP financial measures and detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-17-000189:8k_2_02:23]
Fourth Quarter Fiscal 2017

[0001234452-17-000189:8k_2_02:24]
|  | Q4 Fiscal 2017 |  | Q4 Fiscal 2016 |  | Year-Over-Year Change |  | Q3 Fiscal 2017 |  | Sequential Change |
| Revenues | $6.0B |  | $6.2B |  | (3%) |  | $5.3B |  | +12% |
| Operating income | $1.6B |  | $2.2B |  | (27%) |  | $1.2B |  | +29% |
| Net income | $1.4B |  | $1.9B |  | (28%) |  | $1.2B |  | +11% |
| Diluted earnings per share | $0.92 |  | $1.28 |  | (28%) |  | $0.83 |  | +11% |

[0001234452-17-000189:8k_2_02:25]
Fiscal 2017

[0001234452-17-000189:8k_2_02:26]
|  | Fiscal 2017 |  | Fiscal2016 |  | Year-Over-Year Change |
| Revenues | $23.2B |  | $23.5B |  | (1%) |
| Operating income | $7.1B |  | $7.8B |  | (9%) |
| Net income | $6.4B |  | $6.7B |  | (4%) |
| Diluted earnings per share | $4.28 |  | $4.44 |  | (4%) |

[0001234452-17-000189:8k_2_02:27]
* The third and fourth quarters and fiscal 2017 GAAP and Non-GAAP results were negatively impacted as a result of actions taken by Apple and its contract manufacturers as well as the previously disclosed dispute with another licensee, who underpaid royalties due in the second quarter of fiscal 2017 and did not report or pay royalties due in the third and fourth quarter of fiscal 2017.  We expect these licensees will continue to take such actions in the future until the respective disputes are resolved.

[0001234452-17-000189:8k_2_02:28]
The following also should be considered in regard to the sequential and year-over-year comparisons:

[0001234452-17-000189:8k_2_02:29]
| • | Fiscal 2017 GAAP results included the following items: |

[0001234452-17-000189:8k_2_02:30]
| ◦ | $868 million charge, or ($0.49) per share, for the fine imposed by the Korea Fair Trade Commission (KFTC) in the first quarter of fiscal 2017 (additional impact of $59 million of related foreign exchange losses, resulting in a total charge of $927 million in fiscal 2017); |

[0001234452-17-000189:8k_2_02:31]
| ◦ | $974 million reduction to revenues, or ($0.48) per share, related to the BlackBerry arbitration decision in the second quarter of fiscal 2017 (subsequent downward adjustment of $34 million to reflect the final award amount, resulting in a total reduction to revenues of $940 million in fiscal 2017); and |

[0001234452-17-000189:8k_2_02:32]
| ◦ | $778 million charge, or ($0.52) per share, for the fine imposed by the Taiwan Fair Trade Commission (TFTC), which was accrued in the fourth quarter of fiscal 2017. |

[0001234452-17-000189:8k_2_02:33]
| • | Fiscal 2016 GAAP results included the following items: |

[0001234452-17-000189:8k_2_02:34]
| ◦ | $154 million of charges, or ($0.07) per share, that resulted from net restructuring and restructuring-related charges related to our Strategic Realignment Plan in fiscal 2016; and |

[0001234452-17-000189:8k_2_02:35]
| ◦ | $380 million gain, or $0.20 per share, related to the sale of our wireless spectrum in the United Kingdom in the first quarter of fiscal 2016. |

[0001234452-17-000189:8k_2_02:36]
| • | Fiscal 2016 GAAP and Non-GAAP results included: |

[0001234452-17-000189:8k_2_02:37]
| ◦ | $266 million of revenues, or $0.13 per share, due to the termination of an infrastructure license agreement resulting from the merger of two licensees in the second quarter of fiscal 2016. |

[0001234452-17-000189:8k_2_02:38]
Segment Results

[0001234452-17-000189:8k_2_02:39]
Fourth Quarter Fiscal 2017

[0001234452-17-000189:8k_2_02:40]
| (in millions except percentages) | Q4 Fiscal 2017 |  | Q4 Fiscal 2016 |  | Year-Over-Year Change |  | Q3 Fiscal 2017 |  | Sequential Change |
| QCT |  |  |  |  |  |  |  |  |  |
| Revenues | $4,650 |  | $4,124 |  | +13% |  | $4,052 |  | +15% |
| Earnings before taxes (EBT) | $973 |  | $687 |  | +42% |  | $575 |  | +69% |
| EBT as % of revenues | 21% |  | 17% |  | +4% |  | 14% |  | +7% |
| MSMTM chip shipments | 220 |  | 211 |  | +4% |  | 187 |  | +18% |
| QTL |  |  |  |  |  |  |  |  |  |
| Revenues | $1,213 |  | $1,885 |  | (36%) |  | $1,172 |  | +3% |
| EBT | $829 |  | $1,584 |  | (48%) |  | $854 |  | (3%) |
| EBT as % of revenues | 68% |  | 84% |  | (16%) |  | 73% |  | (5%) |

[0001234452-17-000189:8k_2_02:41]
Fiscal 2017

[0001234452-17-000189:8k_2_02:42]
| (in millions except percentages) | Fiscal 2017 |  | Fiscal 2016 |  | Year-Over-Year Change |
| QCT |  |  |  |  |  |
| Revenues | $16,479 |  | $15,409 |  | +7% |
| Earnings before taxes (EBT) | $2,747 |  | $1,812 |  | +52% |
| EBT as % of revenues | 17% |  | 12% |  | +5% |
| MSMTM chip shipments | 804 |  | 842 |  | (5%) |
| QTL |  |  |  |  |  |
| Revenues | $6,445 |  | $7,664 |  | (16%) |
| EBT | $5,175 |  | $6,528 |  | (21%) |
| EBT as % of revenues | 80% |  | 85% |  | (5%) |

[0001234452-17-000189:8k_2_02:43]
Cash and Marketable Securities

[0001234452-17-000189:8k_2_02:44]
Our cash, cash equivalents and marketable securities totaled $38.6 billion at the end of the fourth quarter of fiscal 2017, compared to $32.4 billion a year ago and $37.8 billion at the end of the third quarter of fiscal 2017.  In addition, during the fiscal year, we deposited $2.0 billion to collateralize the letters of credit related to our proposed acquisition of NXP, which was recorded as other noncurrent assets at the end of the third and fourth quarters of fiscal 2017.

[0001234452-17-000189:8k_2_02:45]
Announced Agreement to Acquire NXP

[0001234452-17-000189:8k_2_02:46]
On October 27, 2016, we announced a definitive agreement to acquire NXP Semiconductors N.V. for estimated total cash to be paid to shareholders of $38 billion.  NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure

[0001234452-17-000189:8k_2_02:47]
identification, network processing and RF power products.  The transaction is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions, including the tender of at least 80% of the issued and outstanding common shares of NXP in the offer (provided that the minimum tender threshold may be reduced to a percentage not less than 70% with the prior written consent of NXP). While we continue to work to close by the end of calendar 2017, the transaction may close in early 2018.  We intend to fund the transaction with cash generated from our May 2017 debt offering as well as cash, cash equivalents and marketable securities held by our foreign entities, which will result in the use of a substantial portion of our cash, cash equivalents and marketable securities, and the use of a Term Loan Facility, which is expected to be drawn on at close.

[0001234452-17-000189:8k_2_02:48]
Return of Capital to Stockholders

[0001234452-17-000189:8k_2_02:49]
The following table summarizes stock repurchases and dividends paid during the fourth quarter and fiscal 2017 (in millions, except per-share amounts):

[0001234452-17-000189:8k_2_02:50]
|  | Stock Repurchases |  | Dividends |  | Total |
|  | Shares |  | Amount |  | Per Share |  | Amount |  | Amount |
| Q4 fiscal 2017 | 6.1 |  | $315 |  | $0.57 |  | $841 |  | $1,156 |
| Fiscal 2017 | 22.8 |  | $1,342 |  | $2.20 |  | $3,252 |  | $4,594 |

[0001234452-17-000189:8k_2_02:51]
On October 10, 2017, we announced a cash dividend of $0.57 per share payable on December 15, 2017 to stockholders of record as of the close of business on November 29, 2017.

[0001234452-17-000189:8k_2_02:52]
Effective Income Tax Rates

[0001234452-17-000189:8k_2_02:53]
Our fiscal 2017 annual effective income tax rates were 18 percent for GAAP and 15 percent for Non-GAAP.  The fiscal 2017 GAAP and Non-GAAP effective tax rates included the impact of lower income from United States operations, primarily related to decreased QTL revenues from Apple’s contract manufacturers and the other licensee in dispute.  The fiscal 2017 GAAP effective tax rate also included $1.7 billion in charges related to the fines imposed by the KFTC and TFTC, which are not deductible for tax purposes. Our annual tax rate for fiscal 2017 GAAP increased from our prior estimate, primarily due to the tax impact of the fine imposed by the TFTC.  The effective income tax rates for the fourth quarter of fiscal 2017 were 61 percent for GAAP and 18 percent for Non-GAAP, which reflected the cumulative effect of the increase in our estimated annual effective rates in the fourth quarter of fiscal 2017.

[0001234452-17-000189:8k_2_02:54]
Business Outlook

[0001234452-17-000189:8k_2_02:55]
we face, and our most recent annual report on file with the Securities and Exchange Commission (SEC) provides a more complete description of risks.

[0001234452-17-000189:8k_2_02:56]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment, certain derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001234452-17-000189:8k_2_02:57]
We have not included estimates related to the operating results of our proposed acquisition of NXP in our first quarter of fiscal 2018 outlook.

[0001234452-17-000189:8k_2_02:58]
Our financial guidance for the first quarter of fiscal 2018 excludes QTL revenues related to the sale of Apple products by Apple’s contract manufacturers, as well as the sale of products by the other licensee in dispute as we expect the recent actions taken by these licensees will continue until the respective disputes are resolved.

[0001234452-17-000189:8k_2_02:59]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-17-000189:8k_2_02:60]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001234452-17-000189:8k_2_02:61]
|  |  | Q1 FY17Results | Current Guidance Q1 FY18 Estimates (2) |  |
|  | Revenues | $6.0B | $5.5B - $6.3B |  |  |
|  | Year-over-year change |  | decrease 8% - increase 5% |  |  |
|  | GAAP diluted earnings per share (EPS) | $0.46 | $0.63 - $0.73 |  |  |
|  | Year-over-year change |  | increase 37% - 59% |  |  |
|  | Less diluted EPS attributable to QSI | ($0.01) |  | $0.01 |  |  |
|  | Less diluted EPS attributable to share-based compensation | ($0.13) |  | ($0.14 | ) |  |
|  | Less diluted EPS attributable to other items (1) | ($0.60) |  | ($0.09 | ) |  |
|  | Non-GAAP diluted EPS | $1.19 | $0.85 - $0.95 |  |  |
|  | Year-over-year change |  | decrease 20% - 29% |  |  |
|  | Other Information |  |  |  |
|  | MSM chip shipments | 217M | 220M - 240M |  |  |
|  | Year-over-year change |  | increase 1% - 11% |  |  |
|  | QTL revenues | $1.8B | $1.1B - $1.3B |  |  |
|  | Year-over-year change |  | decrease 28% - 39% |  |  |

[0001234452-17-000189:8k_2_02:62]
| (1) | Our guidance for diluted EPS attributable to other items for the first quarter of fiscal 2018 is primarily attributable to acquisition-related items. Diluted EPS attributable to other items for the first quarter of fiscal 2017 was primarily attributable to the $868 million charge related to the fine imposed by the KFTC. |

[0001234452-17-000189:8k_2_02:63]
| (2) | Our financial guidance for the first quarter of fiscal 2018 excludes QTL revenues related to the sale of Apple products by Apple’s contract manufacturers, as well as the other licensee in dispute as we expect the recent actions taken by these licensees will continue until the respective disputes are resolved. |

[0001234452-17-000189:8k_2_02:64]
Sums may not equal total due to rounding.

[0001234452-17-000189:8k_2_02:65]
Reconciliations of GAAP Results to Non-GAAP Results

[0001234452-17-000189:8k_2_02:66]
The following tables reconcile our GAAP results to our Non-GAAP results ($ in millions, except per share data):

[0001234452-17-000189:8k_2_02:67]
|  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) | Non-GAAP Results |
| Q4 FISCAL 2017 |  |  |  |  |  |  |  |
| Revenues | $5,905 |  | $43 |  |  | $— |  |  | ($95 | ) | (c) | $5,957 |  |
| Operating income (loss) | 333 |  | 22 |  | (204) | (1,063) |  | 1,578 |  |
| EBT | 434 |  | 28 |  | (204) | (1,065) |  | 1,675 |  |
| EBT as % of revenues | 7 | % |  |  |  |  |  |  | 28 | % |  |
| Net income (loss) | 168 |  | 25 |  | (153) | (1,079) |  | 1,375 |  |
| Diluted EPS | $0.11 |  | $0.02 |  | ($0.10) | ($0.73) |  | $0.92 |  |
| Diluted shares | 1,488 |  | 1,488 |  | 1,488 | 1,488 |  | 1,488 |  |
| Q3 FISCAL 2017 |  |  |  |  |  |  |  |
| Revenues | $5,371 |  | $56 |  |  | $— |  |  | $12 |  |  | $5,303 |  |
| Operating income (loss) | 773 |  | 34 |  | (227) | (259) |  | 1,225 |  |
| EBT | 858 |  | 55 |  | (227) | (271) |  | 1,301 |  |
| EBT as % of revenues | 16 | % |  |  |  |  |  |  | 25 | % |  |
| Net income (loss) | 866 |  | 32 |  | (199) | (204) |  | 1,237 |  |
| Diluted EPS | $0.58 |  | $0.02 |  | ($0.13) | ($0.14) |  | $0.83 |  |
| Diluted shares | 1,491 |  | 1,491 |  | 1,491 | 1,491 |  | 1,491 |  |
| Q4 FISCAL 2016 |  |  |  |  |  |  |  |
| Revenues | $6,184 |  | $14 |  |  | $— |  |  | $— |  |  | $6,170 |  |
| Operating income (loss) | 1,804 |  | (1) |  | (213) | (158) |  | 2,176 |  |
| EBT | 1,960 |  | (14) |  | (213) | (158) |  | 2,345 |  |
| EBT as % of revenues | 32 | % |  |  |  |  |  |  | 38 | % |  |
| Net income (loss) | 1,599 |  | (9) |  | (150) | (147) |  | 1,905 |  |
| Diluted EPS | $1.07 |  | ($0.01) |  | ($0.10) | ($0.10) |  | $1.28 |  |
| Diluted shares | 1,491 |  | 1,491 |  | 1,491 | 1,491 |  | 1,491 |  |
| FISCAL 2017 |  |  |  |  |  |  |  |  |  |
| Revenues | $22,291 |  | $113 |  |  | $— |  |  | ($1,057 | ) | (d) | $23,235 |  |
| Operating income (loss) | 2,614 |  | 38 |  | (914 | ) | (3,604 | ) |  | 7,094 |  |
| EBT | 3,020 |  | 65 |  | (914 | ) | (3,641 | ) |  | 7,510 |  |
| EBT as % of revenues | 14 | % |  |  |  |  |  |  | 32 | % |  |
| Net income (loss) | 2,466 |  | 46 |  | (753 | ) | (3,213 | ) |  | 6,386 |  |
| Diluted EPS | $1.65 |  | $0.03 |  | ($0.51) | ($2.16) |  | $4.28 |  |
| Diluted shares | 1,490 |  | 1,490 |  | 1,490 | 1,490 |  | 1,490 |  |
| FISCAL 2016 |  |  |  |  |  |  |  |  |  |
| Revenues | $23,554 |  | $47 |  |  | $— |  |  | $— |  |  | $23,507 |  |
| Operating income (loss) | 6,495 |  | 372 |  | (943 | ) | (768 | ) |  | 7,834 |  |
| EBT | 6,833 |  | 386 |  | (943 | ) | (768 | ) |  | 8,158 |  |
| EBT as % of revenues | 29 | % |  |  |  |  |  |  | 35 | % |  |
| Net income (loss) | 5,705 |  | 252 |  | (753 | ) | (447 | ) |  | 6,653 |  |
| Diluted EPS | $3.81 |  | $0.17 |  | ($0.50) | ($0.30) |  | $4.44 |  |
| Diluted shares | 1,498 |  | 1,498 |  | 1,498 | 1,498 |  | 1,498 |  |

[0001234452-17-000189:8k_2_02:68]
| (a) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” herein for further details. |

[0001234452-17-000189:8k_2_02:69]
| (b) | Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates.” Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001234452-17-000189:8k_2_02:70]
| (c) | In the fourth quarter of fiscal 2017, other items excluded from Non-GAAP results consisted of a $95 million reduction to revenues related to the portion of a business arrangement under negotiation that resolves a legal dispute. |

[0001234452-17-000189:8k_2_02:71]
| (d) | In fiscal 2017, other items excluded from Non-GAAP results consisted of a $962 million reduction to revenues related to the BlackBerry arbitration decision, as well as a $95 million reduction to revenues related to the portion of a business arrangement under negotiation that resolves a legal dispute. |

[0001234452-17-000189:8k_2_02:72]
Sums may not equal totals due to rounding.

[0001234452-17-000189:8k_2_02:73]
Supplemental Information and Reconciliations

[0001234452-17-000189:8k_2_02:74]
(Unaudited)

[0001234452-17-000189:8k_2_02:75]
|  | Q4 FISCAL 2017 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results |
|  | Cost of revenues |  | $2,653 |  |  | $17 |  |  | $9 |  |  | $108 |  |  | $2,519 |  |
|  | Research and development (R&D) expenses |  | 1,397 |  |  | — |  |  |  | 133 |  |  | 3 |  |  | 1,261 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 742 |  |  | 4 |  |  | 62 |  |  | 77 |  |  | 599 |  |
|  | Other expenses |  | 780 |  |  | — |  |  |  | — |  |  |  | 780 |  |  | — |  |  |
|  | Interest expense |  | 164 |  |  | — |  |  |  | — |  |  |  | 2 |  |  | 162 |  |
|  | Investment and other income, net |  | 265 |  |  | 6 |  |  | — |  |  |  | — |  |  |  | 259 | (b) |

[0001234452-17-000189:8k_2_02:76]
| (a) | Other items excluded from Non-GAAP results included a $778 million charge related to the fine imposed by the TFTC, $189 million of acquisition-related charges and $3 million of restructuring and restructuring-related charges. |

[0001234452-17-000189:8k_2_02:77]
| (b) | Included $147 million in interest and dividend income, $127 million in net realized gains on investments and $4 million in net foreign currency transaction gains, partially offset by $19 million in other net investment losses. |

[0001234452-17-000189:8k_2_02:78]
|  | FISCAL 2017 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (c) | Non-GAAP Results |
|  | Cost of revenues |  | $9,792 |  |  | $60 |  |  | $38 |  |  | $479 |  |  | $9,215 |  |
|  | Research and development (R&D) expenses |  | 5,485 |  |  | 1 |  |  | 588 |  |  | 53 |  |  | 4,843 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 2,658 |  |  | 14 |  |  | 288 |  |  | 273 |  |  | 2,083 |  |
|  | Other expenses |  | 1,742 |  |  | — |  |  |  | — |  |  |  | 1,742 |  |  | — |  |  |
|  | Interest expense |  | 494 |  |  | — |  |  |  | — |  |  |  | 54 |  |  | 440 |  |
|  | Investment and other income, net |  | 900 |  |  | 27 |  |  | — |  |  |  | 17 |  |  | 856 | (d) |

[0001234452-17-000189:8k_2_02:79]
| (c) | Other items excluded from Non-GAAP results included a $911 million charge, including net foreign currency losses, related to the fine imposed by the KFTC, $783 million of acquisition-related charges, $778 million charge related to the fine imposed by the TFTC, $74 million of asset impairment charges and $38 million of restructuring and restructuring-related charges primarily related to our Strategic Realignment Plan. |

[0001234452-17-000189:8k_2_02:80]
| (d) | Included $601 million in interest and dividend income and $436 million in net realized gains on investments, partially offset by $167 million in other-than-temporary losses on investments and $14 million in net foreign currency transaction losses. |

[0001234452-17-000189:8k_2_02:81]
Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates

[0001234452-17-000189:8k_2_02:82]
(Unaudited)

[0001234452-17-000189:8k_2_02:83]
|  |  | GAAP Results |  |  | Less QSI |  | Less Share-Based Compensation |  | Less Other Items (c)(d) |  |  | Non-GAAP Results |  |
| Q4 FISCAL 2017 ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 434 |  |  |  | $ | 28 |  |  |  | $ | (204 | ) |  |  | $ | (1,065 | ) |  |  | $ | 1,675 |  |  |
| Income tax (expense) benefit |  | (266 | ) |  |  | (3 | ) |  |  | 51 |  |  |  | (14 | ) |  |  | (300 | ) |  |
| Net income (loss) (a) |  | $ | 168 |  |  |  | $ | 25 |  |  |  | $ | (153 | ) |  |  | $ | (1,079 | ) |  |  | $ | 1,375 |  |  |
| Tax rate |  | 61 | % |  |  | (1 | %) | (b) |  |  |  | 4 | % | (b) |  |  | 40 | % | (b) |  |  | 18 | % |  |
| FISCAL 2017 ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 3,020 |  |  |  | $ | 65 |  |  |  | $ | (914 | ) |  |  | $ | (3,641 | ) |  |  | $ | 7,510 |  |  |
| Income tax (expense) benefit |  | (555 | ) |  |  | (20 | ) |  |  | 161 |  |  |  | 428 |  |  |  | (1,124 | ) |  |
| Net income (loss) (a) |  | $ | 2,465 |  |  |  | $ | 45 |  |  |  | $ | (753 | ) |  |  | $ | (3,213 | ) |  |  | $ | 6,386 |  |  |
| Tax rate |  | 18 | % |  |  | 0 | % | (b) |  |  |  | 0 | % | (b) |  |  | 3 | % | (b) |  |  | 15 | % |  |

[0001234452-17-000189:8k_2_02:84]
| (a) | Before adjustments for noncontrolling interests. |

[0001234452-17-000189:8k_2_02:85]
| (b) | The incremental effect of our adjustments to the Non-GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001234452-17-000189:8k_2_02:86]
| (c) | In the fourth quarter of fiscal 2017, the tax expense in the “Other Items” column included a $98 million tax expense related to an increase in unrecognized tax benefits, partially offset by a $30 million tax benefit for the combined effect of other items in EBT, a $29 million tax benefit for the tax effect of acquisition-related items in EBT and a $25 million tax benefit to reconcile the tax provision for each column to the total GAAP tax provision for the quarter. |

[0001234452-17-000189:8k_2_02:87]
| (d) | In fiscal 2017, the tax benefit in the “Other Items” column included a $395 million tax benefit for the combined tax effect of other items in EBT and a $144 million tax benefit for the tax effect of acquisition-related items in EBT, partially offset by a $111 million tax expense related to an increase in unrecognized tax benefits. |

[0001234452-17-000189:8k_2_02:88]
Conference Call

[0001234452-17-000189:8k_2_02:89]
Qualcomm’s fiscal fourth quarter 2017 earnings conference call will be broadcast live on November 1, 2017, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 39466043.

[0001234452-17-000189:8k_2_02:90]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-17-000189:8k_2_02:91]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-17-000189:8k_2_02:92]
The Company uses Non-GAAP financial information: (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating the Company’s business and assessing trends and future expectations.

[0001234452-17-000189:8k_2_02:93]
Non-GAAP information used by management excludes its QSI segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001234452-17-000189:8k_2_02:94]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-17-000189:8k_2_02:95]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001234452-17-000189:8k_2_02:96]
| • | Certain other items are excluded because management views such items as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001234452-17-000189:8k_2_02:97]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items, as well as any effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property, third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition. Starting with acquisitions in the second quarter of fiscal 2017, the Company excludes recognition of the step-up of property, plant and equipment from the net book value based on the original cost basis to fair value. Such charges related to acquisitions that were completed prior to the second quarter of fiscal 2017 continue to be allocated to the segments, and such amounts are not material. |

[0001234452-17-000189:8k_2_02:98]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. |

[0001234452-17-000189:8k_2_02:99]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. |

[0001234452-17-000189:8k_2_02:100]
About Qualcomm

[0001234452-17-000189:8k_2_02:101]
Qualcomm’s technologies powered the smartphone revolution and connected billions of people.  We pioneered 3G and 4G - and now we are leading the way to 5G and a new era of intelligent, connected devices.  Our products are revolutionizing industries, including automotive, computing, IoT, healthcare and data center, and are allowing millions of devices to connect with each other in ways never before imagined.  Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, all of our engineering, research and development functions, and all of our products and services businesses, including our QCT semiconductor business.  For more information, visit www.qualcomm.com.

[0001234452-17-000189:8k_2_02:102]
Note Regarding Forward-Looking Statements

[0001234452-17-000189:8k_2_02:103]
###

[0001234452-17-000189:8k_2_02:104]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries. Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001234452-17-000189:8k_2_02:105]
MSM is a product of Qualcomm Technologies, Inc.

[0001234452-17-000189:8k_2_02:106]
Qualcomm Incorporated

[0001234452-17-000189:8k_2_02:107]
CONSOLIDATED BALANCE SHEETS

[0001234452-17-000189:8k_2_02:108]
(In millions, except per share data)

[0001234452-17-000189:8k_2_02:109]
(Unaudited)

[0001234452-17-000189:8k_2_02:110]
|  | September 24, 2017 |  | September 25, 2016 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 35,029 |  |  | $ | 5,946 |  |
| Marketable securities | 2,279 |  |  | 12,702 |  |
| Accounts receivable, net | 3,632 |  |  | 2,219 |  |
| Inventories | 2,035 |  |  | 1,556 |  |
| Other current assets | 618 |  |  | 558 |  |
| Total current assets | 43,593 |  |  | 22,981 |  |
| Marketable securities | 1,270 |  |  | 13,702 |  |
| Deferred tax assets | 2,900 |  |  | 2,030 |  |
| Property, plant and equipment, net | 3,216 |  |  | 2,306 |  |
| Goodwill | 6,623 |  |  | 5,679 |  |
| Other intangible assets, net | 3,737 |  |  | 3,500 |  |
| Other assets | 4,147 |  |  | 2,161 |  |
| Total assets | $ | 65,486 |  |  | $ | 52,359 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,971 |  |  | $ | 1,858 |  |
| Payroll and other benefits related liabilities | 1,183 |  |  | 934 |  |
| Unearned revenues | 502 |  |  | 509 |  |
| Short-term debt | 2,495 |  |  | 1,749 |  |
| Other current liabilities | 4,756 |  |  | 2,261 |  |
| Total current liabilities | 10,907 |  |  | 7,311 |  |
| Unearned revenues | 2,003 |  |  | 2,377 |  |
| Long-term debt | 19,398 |  |  | 10,008 |  |
| Other liabilities | 2,432 |  |  | 895 |  |
| Total liabilities | 34,740 |  |  | 20,591 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,474 and 1,476 shares issued and outstanding, respectively | 274 |  |  | 414 |  |
| Retained earnings | 30,088 |  |  | 30,936 |  |
| Accumulated other comprehensive income | 384 |  |  | 428 |  |
| Total Qualcomm stockholders’ equity | 30,746 |  |  | 31,778 |  |
| Noncontrolling interests | — |  |  | (10 | ) |
| Total stockholders’ equity | 30,746 |  |  | 31,768 |  |
| Total liabilities and stockholders’ equity | $ | 65,486 |  |  | $ | 52,359 |  |

[0001234452-17-000189:8k_2_02:111]
Qualcomm Incorporated

[0001234452-17-000189:8k_2_02:112]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-17-000189:8k_2_02:113]
(In millions, except per share data)

[0001234452-17-000189:8k_2_02:114]
(Unaudited)

[0001234452-17-000189:8k_2_02:115]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 24, 2017 |  | September 25, 2016 |  | September 24, 2017 |  | September 25, 2016 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 4,698 |  |  | $ | 4,156 |  |  | $ | 16,647 |  |  | $ | 15,467 |  |
| Licensing | 1,207 |  |  | 2,028 |  |  | 5,644 |  |  | 8,087 |  |
| Total revenues | 5,905 |  |  | 6,184 |  |  | 22,291 |  |  | 23,554 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of revenues | 2,653 |  |  | 2,539 |  |  | 9,792 |  |  | 9,749 |  |
| Research and development | 1,397 |  |  | 1,229 |  |  | 5,485 |  |  | 5,151 |  |
| Selling, general and administrative | 742 |  |  | 568 |  |  | 2,658 |  |  | 2,385 |  |
| Other | 780 |  |  | 44 |  |  | 1,742 |  |  | (226 | ) |
| Total costs and expenses | 5,572 |  |  | 4,380 |  |  | 19,677 |  |  | 17,059 |  |
| Operating income | 333 |  |  | 1,804 |  |  | 2,614 |  |  | 6,495 |  |
| Interest expense | (164 | ) |  | (76 | ) |  | (494 | ) |  | (297 | ) |
| Investment and other income, net | 265 |  |  | 232 |  |  | 900 |  |  | 635 |  |
| Income before income taxes | 434 |  |  | 1,960 |  |  | 3,020 |  |  | 6,833 |  |
| Income tax expense | (266 | ) |  | (361 | ) |  | (555 | ) |  | (1,131 | ) |
| Net income | 168 |  |  | 1,599 |  |  | 2,465 |  |  | 5,702 |  |
| Net loss attributable to noncontrolling interests | — |  |  | — |  |  | 1 |  |  | 3 |  |
| Net income attributable to Qualcomm | $ | 168 |  |  | $ | 1,599 |  |  | $ | 2,466 |  |  | $ | 5,705 |  |
| Basic earnings per share attributable to Qualcomm | $ | 0.11 |  |  | $ | 1.08 |  |  | $ | 1.67 |  |  | $ | 3.84 |  |
| Diluted earnings per share attributable to Qualcomm | $ | 0.11 |  |  | $ | 1.07 |  |  | $ | 1.65 |  |  | $ | 3.81 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,476 |  |  | 1,476 |  |  | 1,477 |  |  | 1,484 |  |
| Diluted | 1,488 |  |  | 1,491 |  |  | 1,490 |  |  | 1,498 |  |
| Dividends per share announced | $ | 0.57 |  |  | $ | 0.53 |  |  | $ | 2.20 |  |  | $ | 2.02 |  |

[0001234452-17-000189:8k_2_02:116]
Qualcomm Incorporated

[0001234452-17-000189:8k_2_02:117]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-17-000189:8k_2_02:118]
(In millions)

[0001234452-17-000189:8k_2_02:119]
(Unaudited)

[0001234452-17-000189:8k_2_02:120]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 24, 2017 |  | September 25, 2016 |  | September 24, 2017 |  | September 25, 2016 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 168 |  |  | $ | 1,599 |  |  | $ | 2,465 |  |  | $ | 5,702 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 397 |  |  | 336 |  |  | 1,461 |  |  | 1,428 |  |
| Indefinite and long-lived asset impairment charges | — |  |  | 13 |  |  | 76 |  |  | 107 |  |
| Income tax provision in excess of (less than) income tax payments | 67 |  |  | 36 |  |  | (400 | ) |  | (200 | ) |
| Gain on sale of wireless spectrum | — |  |  | — |  |  | — |  |  | (380 | ) |
| Non-cash portion of share-based compensation expense | 204 |  |  | 213 |  |  | 914 |  |  | 943 |  |
| Incremental tax benefits from share-based compensation | (2 | ) |  | (5 | ) |  | (40 | ) |  | (8 | ) |
| Net realized gains on marketable securities and other investments | (156 | ) |  | (145 | ) |  | (530 | ) |  | (288 | ) |
| Impairment losses on marketable securities and other investments | 15 |  |  | 35 |  |  | 177 |  |  | 172 |  |
| Other items, net | 131 |  |  | 75 |  |  | 146 |  |  | 77 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (83 | ) |  | (271 | ) |  | (1,104 | ) |  | (232 | ) |
| Inventories | (18 | ) |  | (218 | ) |  | (200 | ) |  | (49 | ) |
| Other assets | 58 |  |  | 93 |  |  | 169 |  |  | 246 |  |
| Trade accounts payable | 498 |  |  | 278 |  |  | (45 | ) |  | 541 |  |
| Payroll, benefits and other liabilities | 1,220 |  |  | 82 |  |  | 1,835 |  |  | (352 | ) |
| Unearned revenues | (82 | ) |  | (37 | ) |  | (231 | ) |  | (307 | ) |
| Net cash provided by operating activities | 2,417 |  |  | 2,084 |  |  | 4,693 |  |  | 7,400 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (262 | ) |  | (150 | ) |  | (690 | ) |  | (539 | ) |
| Purchases of available-for-sale securities | (3,553 | ) |  | (5,055 | ) |  | (19,062 | ) |  | (18,015 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 22,072 |  |  | 4,083 |  |  | 41,715 |  |  | 14,386 |  |
| Purchases of trading securities | — |  |  | — |  |  | — |  |  | (177 | ) |
| Proceeds from sales and maturities of trading securities | — |  |  | — |  |  | — |  |  | 779 |  |
| Purchases of other marketable securities | (5 | ) |  | — |  |  | (710 | ) |  | — |  |
| Proceeds from sales and maturities of other marketable securities | 706 |  |  | — |  |  | 706 |  |  | 450 |  |
| Deposits of investments designated as collateral | — |  |  | — |  |  | (2,000 | ) |  | — |  |
| Acquisitions and other investments, net of cash acquired | (143 | ) |  | (149 | ) |  | (1,544 | ) |  | (812 | ) |
| Proceeds from sale of wireless spectrum | — |  |  | — |  |  | — |  |  | 232 |  |
| Proceeds from sales of property, plant and equipment | 28 |  |  | 1 |  |  | 28 |  |  | 16 |  |
| Other items, net | (38 | ) |  | 11 |  |  | 20 |  |  | 192 |  |
| Net cash provided (used) by investing activities | 18,805 |  |  | (1,259 | ) |  | 18,463 |  |  | (3,488 | ) |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 1,710 |  |  | 2,316 |  |  | 8,558 |  |  | 8,949 |  |
| Repayment of short-term debt | (1,711 | ) |  | (2,315 | ) |  | (9,309 | ) |  | (8,200 | ) |
| Proceeds from long-term debt | — |  |  | — |  |  | 10,953 |  |  | — |  |
| Proceeds from issuance of common stock | 166 |  |  | 246 |  |  | 497 |  |  | 668 |  |
| Repurchases and retirements of common stock | (315 | ) |  | (225 | ) |  | (1,342 | ) |  | (3,923 | ) |
| Dividends paid | (841 | ) |  | (782 | ) |  | (3,252 | ) |  | (2,990 | ) |
| Incremental tax benefits from share-based compensation | 2 |  |  | 5 |  |  | 40 |  |  | 8 |  |
| Other items, net | (133 | ) |  | (2 | ) |  | (266 | ) |  | (34 | ) |
| Net cash (used) provided by financing activities | (1,122 | ) |  | (757 | ) |  | 5,879 |  |  | (5,522 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 20 |  |  | (7 | ) |  | 48 |  |  | (4 | ) |
| Net increase (decrease) in cash and cash equivalents | 20,120 |  |  | 61 |  |  | 29,083 |  |  | (1,614 | ) |
| Cash and cash equivalents at beginning of period | 14,909 |  |  | 5,885 |  |  | 5,946 |  |  | 7,560 |  |
| Cash and cash equivalents at end of period | $ | 35,029 |  |  | $ | 5,946 |  |  | $ | 35,029 |  |  | $ | 5,946 |  |
