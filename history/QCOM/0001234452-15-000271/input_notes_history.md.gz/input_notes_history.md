# QCOM note change history — 0001234452-15-000134 → 0001234452-15-000208


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-07-22):
[0001234452-15-000208:note_history:1]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit heard the appeal on May 8, 2015 and will issue a decision sometime in the coming months. On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision now alleges that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. The Company was served with the complaint in this second action on August 28, 2014 and answered on November 17, 2014. The judge’s schedule sets the claim construction hearing for August 12, 2015, the close of discovery for January 2016 and the trial for August 2016.
  (was, 2015-04-22, similarity 0.9701):
[0001234452-15-000134:note_history:1]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of approximately $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit will hear the appeal on May 8, 2015 and issue a decision sometime thereafter. On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision now alleges that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. The Company was served with the complaint in this second action on August 28, 2014 and answered on November 17, 2014. The judge’s schedule sets the claim construction hearing for August 12, 2015, the close of discovery for January 2016 and the trial for August 2016.

- changed (2015-07-22):
[0001234452-15-000208:note_history:2]
Nvidia Corporation v. QUALCOMM Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd., and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chipset products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District of Delaware complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. On April 2, 2015, the Administrative Law Judge in the ITC investigation issued a claim construction order construing seven claim terms from five of the seven asserted patents. The evidentiary hearing for the investigation was held from June 22 to June 26, 2015. Nvidia withdrew the ITC complaint with respect to four of the patents, but is moving forward with infringement allegations with respect to three of the patents. The Initial Determination of the Administrative Law Judge is due October 9, 2015, and the target date for completion of the investigation by the ITC is set for February 10, 2016. The district court case was stayed on October 23, 2014 pending completion of the ITC investigation including appeals.
  (was, 2015-04-22, similarity 0.9507):
[0001234452-15-000134:note_history:2]
Nvidia Corporation v. Qualcomm Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd., and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chip products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District of Delaware complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. On April 2, 2015, the Administrative Law Judge in the ITC investigation issued a claim construction order construing seven claim terms from five of the seven asserted patents. The evidentiary hearing for the investigation is set for June 22 to June 26, 2015. The Initial Determination of the Administrative Law Judge is due October 9, 2015, and the target date for completion of the investigation by the ITC is set for February 10, 2016. The district court case was stayed on October 23, 2014 pending completion of the ITC investigation including appeals.

- added (2015-07-22):
[0001234452-15-000208:note_history:3]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. The Commission is investigating “alleged practices in the form of predatory pricing on certain UMTS standard-compliant chipsets used to deliver cellular mobile broadband access.” The initiation of proceedings merely means that the Commission will deal with the case as a matter of priority. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that none of the business practices under investigation are in breach of the EU competition rules and will continue to cooperate with the Commission.

- changed (2015-07-22):
[0001234452-15-000208:note_history:4]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments during fiscal 2015 with respect to this matter.
  (was, 2015-04-22, similarity 0.9979):
[0001234452-15-000134:note_history:4]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chips and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments during fiscal 2015 with respect to this matter.

- changed (2015-07-22):
[0001234452-15-000208:note_history:5]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 27 different dates, with the next hearing scheduled for August 4, 2015.
  (was, 2015-04-22, similarity 0.9967):
[0001234452-15-000134:note_history:5]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 26 different dates, with the next hearing scheduled for May 25, 2015.

- added (2015-07-22):
[0001234452-15-000208:note_history:6]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. The Commission is investigating “alleged payments, rebates and/or other consideration granted by Qualcomm Incorporated or any of its affiliates and/or subsidiaries (Qualcomm) to smartphone and/or tablet manufacturers which are conditional upon the exclusive or quasi-exclusive use or purchase of Qualcomm products, in particular baseband chipsets, by the respective manufacturer(s).” The initiation of proceedings merely means that the Commission will deal with the case as a matter of priority. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that none of the business practices under investigation are in breach of the EU competition rules and will continue to cooperate with the Commission.

- changed (2015-07-22):
[0001234452-15-000208:note_history:7]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at June 28, 2015 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.
  (was, 2015-04-22, similarity 0.9377):
[0001234452-15-000134:note_history:7]
With the exception of the NDRC matter, which has been resolved, the Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at March 29, 2015 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

- changed (2015-07-22):
[0001234452-15-000208:note_history:8]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through June 28, 2015, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.
  (was, 2015-04-22, similarity 0.9955):
[0001234452-15-000134:note_history:8]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through March 29, 2015, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

- changed (2015-07-22):
[0001234452-15-000208:note_history:9]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at June 28, 2015 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.
  (was, 2015-04-22, similarity 0.9951):
[0001234452-15-000134:note_history:9]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at March 29, 2015 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- added (2015-07-22):
[0001234452-15-000208:note_history:10]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at June 28, 2015 for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 were $2.2 billion, $1.2 billion, $921 million, $791 million and $721 million, respectively, and $175 million thereafter. Of these amounts, for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019, commitments to purchase integrated circuit product inventories comprised $1.8 billion, $1.0 billion, $771 million, $703 million and $651 million, respectively, and $152 million thereafter. Integrated circuit product inventory obligations represent purchase commitments for wafers, die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

- added (2015-07-22):
[0001234452-15-000208:note_history:11]
Other Commitments. The Company is committed to fund certain strategic investments up to $197 million. Of this amount, $105 million will be funded in fiscal 2015. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.

- removed (2015-07-22):
[0001234452-15-000134:note_history:12]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. The Company continues to cooperate with the Commission’s preliminary investigation.

- removed (2015-07-22):
[0001234452-15-000134:note_history:13]
China National Development and Reform Commission (NDRC) Investigation: In November 2013, the NDRC notified the Company that it had commenced an investigation of the Company relating to China’s Anti-Monopoly Law (AML). The investigation concerned primarily the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business. On February 9, 2015, the Company announced that it had reached a resolution with the NDRC regarding the investigation. The NDRC issued an Administrative Sanction Decision finding that the Company had violated the AML, and the Company agreed to implement a rectification plan that modifies certain of its business practices in China. The NDRC has reviewed that plan and stated that it satisfies their decision. The Company will not pursue further legal proceedings contesting the NDRC’s findings.

- removed (2015-07-22):
[0001234452-15-000134:note_history:14]
The key terms of the rectification plan provide that the Company will offer licenses for devices under its current 3G and 4G essential Chinese patents separately from licenses to its other patents and will provide patent lists during the negotiation process. If the Company seeks a cross license from a Chinese licensee as part of such offer, it will negotiate with the licensee in good faith and provide fair consideration for such rights. For licenses of the Company’s 3G and 4G essential Chinese patents for branded devices sold for use in China starting on January 1, 2015, the Company will charge running royalties of 5% for 3G CDMA or WCDMA devices (including multimode 3G/4G devices) and 3.5% for 4G devices that do not implement CDMA or WCDMA (including 3-mode LTE-TDD devices), in each case using a royalty base of 65% of the net selling price of the device. Consistent with the plan, the Company has offered its existing licensees the revised terms for sales of devices for use in China. The plan also provides that the Company will not condition the sale of baseband chipsets on the chipset customer signing a license agreement with terms that the NDRC found to be unreasonable or on the chipset customer not challenging unreasonable terms in its license agreement. The rectification plan does not require the Company to sell chipsets to any entity that is not a patent licensee of the Company.

- removed (2015-07-22):
[0001234452-15-000134:note_history:15]
In addition, the NDRC imposed a fine on the Company of 6.088 billion Chinese Yuan Renminbi (approximately $975 million), which the Company has paid. The Company recorded the amount of the fine in the second quarter of fiscal 2015 as a charge in other expenses.

- removed (2015-07-22):
[0001234452-15-000134:note_history:16]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Article 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU) and Article 53 and/or 54 of the Agreement for the European Economic Area (EEA Agreement). The Company understands that the investigation concerns the sale and/or marketing of the Company’s baseband chipsets, including alleged conditions relating to the provision by the Company of rebates and/or other financial incentives. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. Given that this investigation is in its early stages, it is difficult to predict the outcome or what remedies, if any, may be imposed by the Commission. The Company continues to cooperate with the Commission as it conducts its investigation.

- removed (2015-07-22):
[0001234452-15-000134:note_history:17]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at March 29, 2015 for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 were approximately $3.2 billion, $1.2 billion, $941 million, $797 million and $733 million, respectively, and $208 million thereafter. Of these amounts, for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019, commitments to purchase integrated circuit product inventories comprised $2.5 billion, $994 million, $794 million, $715 million and $665 million, respectively, and $185 million thereafter. Integrated circuit product inventory obligations represent purchase commitments for wafers, die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-07-22):
[0001234452-15-000208:note_history:18]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 28, 2014. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 28, 2015 and June 29, 2014 included 13 weeks and 39 weeks, respectively.
  (was, 2015-04-22, similarity 0.9819):
[0001234452-15-000134:note_history:18]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 28, 2014. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and six-month periods ended March 29, 2015 and March 30, 2014 included 13 weeks and 26 weeks, respectively.

- changed (2015-07-22):
[0001234452-15-000208:note_history:19]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 28, 2015 were 20,749,000 and 22,447,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 29, 2014 were 30,642,000 and 31,985,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 16,711,000 and 6,067,000 during the three and nine months ended June 28, 2015, respectively, which were primarily attributable to the ASR Agreements (Note 4), and 7,000 and 278,000 during the three and nine months ended June 29, 2014, respectively.
  (was, 2015-04-22, similarity 0.9108):
[0001234452-15-000134:note_history:19]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 29, 2015 were 21,588,000 and 23,295,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 30, 2014 were 30,989,000 and 32,656,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 18,000 and 744,000 during the three and six months ended March 29, 2015, respectively, and 12,000 and 413,000 during the three and six months ended March 30, 2014, respectively.

- changed (2015-07-22):
[0001234452-15-000208:note_history:20]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | June 28, 2015 |  | June 29, 2014 |
| Cost of equipment and services revenues | $ | 10 |  |  | $ | 12 |  |  | $ | 33 |  |  | $ | 37 |  |
| Research and development | 176 |  |  | 174 |  |  | 508 |  |  | 510 |  |
| Selling, general and administrative | 85 |  |  | 88 |  |  | 252 |  |  | 259 |  |
| Share-based compensation expense before income taxes | 271 |  |  | 274 |  |  | 793 |  |  | 806 |  |
| Related income tax benefit | (58 | ) |  | (42 | ) |  | (145 | ) |  | (151 | ) |
|  | $ | 213 |  |  | $ | 232 |  |  | $ | 648 |  |  | $ | 655 |  |
  (was, 2015-04-22, similarity 0.8709):
[0001234452-15-000134:note_history:20]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | March 29, 2015 |  | March 30, 2014 |
| Cost of equipment and services revenues | $ | 11 |  |  | $ | 13 |  |  | $ | 23 |  |  | $ | 25 |  |
| Research and development | 158 |  |  | 163 |  |  | 333 |  |  | 336 |  |
| Selling, general and administrative | 80 |  |  | 75 |  |  | 166 |  |  | 171 |  |
| Share-based compensation expense before income taxes | 249 |  |  | 251 |  |  | 522 |  |  | 532 |  |
| Related income tax benefit | (43 | ) |  | (53 | ) |  | (86 | ) |  | (109 | ) |
|  | $ | 206 |  |  | $ | 198 |  |  | $ | 436 |  |  | $ | 423 |  |

- changed (2015-07-22):
[0001234452-15-000208:note_history:21]
The Company recorded $173 million and $177 million in share-based compensation expense during the nine months ended June 28, 2015 and June 29, 2014, respectively, related to share-based awards granted during those periods. At June 28, 2015, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.5 billion, which is expected to be recognized over a weighted-average period of 2.0 years. During the nine months ended June 28, 2015 and June 29, 2014, net share-based awards granted, after forfeitures and cancelations, represented 0.8% of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.9% of outstanding shares as of the end of each fiscal period.
  (was, 2015-04-22, similarity 0.8975):
[0001234452-15-000134:note_history:21]
The Company recorded $81 million and $82 million in share-based compensation expense during the six months ended March 29, 2015 and March 30, 2014, respectively, related to share-based awards granted during those periods. At March 29, 2015, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.3 billion, which is expected to be recognized over a weighted-average period of 1.8 years. During the six months ended March 29, 2015 and March 30, 2014, net share-based awards granted, after forfeitures and cancelations, represented 0.4% of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.5% of outstanding shares as of the end of each fiscal period.

- changed (2015-07-22):
[0001234452-15-000208:note_history:22]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for the Company starting in the first quarter of fiscal 2019. The FASB will also permit entities to adopt one year earlier if they choose (i.e., the original effective date). The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the standard early and is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.
  (was, 2015-04-22, similarity 0.8395):
[0001234452-15-000134:note_history:22]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The ASU as currently issued will be effective for the Company starting in the first quarter of fiscal 2018. On April 1, 2015, the FASB voted to propose a one-year deferral to the effective date, but to permit entities to adopt one year earlier if they choose (i.e., the original effective date). The proposal will be subject to the FASB’s due process requirement, which includes a period for public comments. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. The Company is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-07-22):
[0001234452-15-000208:note_history:23]
Revolving Credit Facility. In February 2015, the Company entered into a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. Proceeds from the Revolving Credit Facility will be used for general corporate purposes. Loans under the Revolving Credit Facility bear interest, at the option of the Company, at either LIBOR (determined in accordance with the Revolving Credit Facility) plus a margin of 0.7% per annum or the Base Rate (determined in accordance with the Revolving Credit Facility), plus an initial margin of 0% per annum. The Revolving Credit Facility has a facility fee, which initially accrues at a rate of 0.05% per annum. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At June 28, 2015, the Company was in compliance with the covenants, and the Company had not borrowed any funds under the Revolving Credit Facility.
  (was, 2015-04-22, similarity 0.9749):
[0001234452-15-000134:note_history:23]
In February 2015, the Company entered into a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. Proceeds from the Revolving Credit Facility will be used for general corporate purposes. Loans under the Revolving Credit Facility bear interest, at the option of the Company, at either LIBOR (determined in accordance with the Revolving Credit Facility) plus a margin of 0.7% per annum or the Base Rate (determined in accordance with the Revolving Credit Facility), plus an initial margin of 0% per annum. The Revolving Credit Facility has a facility fee, which initially accrues at a rate of 0.05% per annum. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At March 29, 2015, the Company was in compliance with the financial covenant, and the Company had not borrowed any funds under the Revolving Credit Facility.

- added (2015-07-22):
[0001234452-15-000208:note_history:24]
Commercial Paper Program. In March 2015, the Company began an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At June 28, 2015, the Company had $1.0 billion of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 0.14%, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 51 days. The carrying value of the outstanding commercial paper approximated its estimated fair value at June 28, 2015.

- added (2015-07-22):
[0001234452-15-000208:note_history:25]
Long-term Debt. In May 2015, the Company issued an aggregate principal amount of $10.0 billion of unsecured floating- and fixed-rate notes (the notes) with varying maturities. The proceeds from the notes of $9.9 billion, net of underwriting discounts and offering expenses, were used to fund the ASR Agreements (Note 4) and are also being used for other general corporate purposes. The following table provides a summary of the Company’s long-term debt as of June 28, 2015 (dollar amounts in millions):

- added (2015-07-22):
[0001234452-15-000208:note_history:26]
|  |  | PrincipalAmount |  | EffectiveInterest Rate |
| Floating-rate notes due May 18, 2018 |  | $ | 250 |  |  | 0.61% |
| Floating-rate notes due May 20, 2020 |  | 250 |  |  | 0.88% |
| Fixed-rate 1.40% notes due May 18, 2018 |  | 1,250 |  |  | 0.68% |
| Fixed-rate 2.25% notes due May 20, 2020 |  | 1,750 |  |  | 1.78% |
| Fixed-rate 3.00% notes due May 20, 2022 |  | 2,000 |  |  | 2.28% |
| Fixed-rate 3.45% notes due May 20, 2025 |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 |  | 1,500 |  |  | 4.71% |
| Total principal |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments |  | (22 | ) |  |  |
| Total long-term debt |  | $ | 9,913 |  |  |  |

- added (2015-07-22):
[0001234452-15-000208:note_history:27]
The interest rate on the floating rate notes due in 2018 and the floating rate notes due in 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At June 28, 2015, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $9.8 billion.

- added (2015-07-22):
[0001234452-15-000208:note_history:28]
The Company has entered, and may in the future enter, into interest rate swaps to manage interest rate risk on certain notes. Such swaps allow the Company to effectively convert fixed-rate payments into floating-rate payments. These transactions are designated as fair value hedges, and the gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. In the third quarter of fiscal 2015, the Company entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings as interest expense in the current period.

- added (2015-07-22):
[0001234452-15-000208:note_history:29]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and, if applicable, adjustments related to hedging. The Company recognized $30 million of interest expense on its long-term debt during the three and nine months ended June 28, 2015. The Company did not have any long-term debt outstanding in fiscal 2014.

- added (2015-07-22):
[0001234452-15-000208:note_history:30]
No principal payments are due on the Company’s notes prior to fiscal 2018. At June 28, 2015, future principal payments were $1.5 billion in fiscal 2018 and $8.5 billion after fiscal 2019; no principal payments were due in fiscal 2019.

- removed (2015-07-22):
[0001234452-15-000134:note_history:31]
In March 2015, the Company began an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At March 29, 2015, the Company had $1.1 billion of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 0.14%, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 58 days. The carrying value of the outstanding commercial paper approximated its estimated fair value at March 29, 2015.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-07-22):
[0001234452-15-000208:note_history:32]
|  | Current |  | Noncurrent |
|  | June 28, 2015 |  | September 28, 2014 |  | June 28, 2015 |  | September 28, 2014 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 329 |  |  | $ | 320 |  |  | $ | 6 |  |  | $ | 38 |  |
| Corporate bonds and notes | 187 |  |  | 191 |  |  | 379 |  |  | 367 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 252 |  |  | 237 |  |
| Total trading | 516 |  |  | 511 |  |  | 637 |  |  | 642 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 138 |  |  | 805 |  |  | 708 |  |  | 392 |  |
| Corporate bonds and notes | 8,628 |  |  | 6,274 |  |  | 7,078 |  |  | 7,649 |  |
| Mortgage- and asset-backed securities | 1,297 |  |  | 1,063 |  |  | 216 |  |  | 195 |  |
| Auction rate securities | — |  |  | — |  |  | 46 |  |  | 83 |  |
| Common and preferred stock | 550 |  |  | 192 |  |  | 886 |  |  | 1,605 |  |
| Equity funds | — |  |  | — |  |  | 496 |  |  | 541 |  |
| Debt funds | 215 |  |  | 813 |  |  | 3,038 |  |  | 2,560 |  |
| Total available-for-sale | 10,828 |  |  | 9,147 |  |  | 12,468 |  |  | 13,025 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 789 |  |  | 790 |  |
| Total marketable securities | $ | 11,344 |  |  | $ | 9,658 |  |  | $ | 13,894 |  |  | $ | 14,457 |  |
  (was, 2015-04-22, similarity 0.9918):
[0001234452-15-000134:note_history:32]
|  | Current |  | Noncurrent |
|  | March 29, 2015 |  | September 28, 2014 |  | March 29, 2015 |  | September 28, 2014 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 338 |  |  | $ | 320 |  |  | $ | 23 |  |  | $ | 38 |  |
| Corporate bonds and notes | 177 |  |  | 191 |  |  | 345 |  |  | 367 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 240 |  |  | 237 |  |
| Total trading | 515 |  |  | 511 |  |  | 608 |  |  | 642 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 385 |  |  | 805 |  |  | 715 |  |  | 392 |  |
| Corporate bonds and notes | 7,250 |  |  | 6,274 |  |  | 7,668 |  |  | 7,649 |  |
| Mortgage- and asset-backed securities | 1,091 |  |  | 1,063 |  |  | 205 |  |  | 195 |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | 83 |  |
| Common and preferred stock | 572 |  |  | 192 |  |  | 819 |  |  | 1,605 |  |
| Equity funds | — |  |  | — |  |  | 646 |  |  | 541 |  |
| Debt funds | 250 |  |  | 813 |  |  | 2,559 |  |  | 2,560 |  |
| Total available-for-sale | 9,548 |  |  | 9,147 |  |  | 12,659 |  |  | 13,025 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 788 |  |  | 790 |  |
| Total marketable securities | $ | 10,063 |  |  | $ | 9,658 |  |  | $ | 14,055 |  |  | $ | 14,457 |  |

- changed (2015-07-22):
[0001234452-15-000208:note_history:33]
In connection with the pending acquisition of CSR (Note 8), the Company agreed to set aside certain cash, cash equivalents and marketable securities to be held for purposes of satisfying payment of the consideration to effect the acquisition, which is expected to close by the end of the summer of 2015. At June 28, 2015, the fair values of the marketable securities that were set aside were $2.9 billion of corporate bonds and notes, $790 million of mortgage- and asset-backed securities and $79 million in U.S. Treasury securities and government-related securities. Additionally, $47 million in cash equivalents, which were recorded as other current assets, were set aside. If the combined fair values fall below approximately £1.9 billion (approximately $2.9 billion using an exchange rate of USD: GBP 1.5634), the Company may be required to set aside additional amounts. Additionally, if certain conditions are met, such as a reduction in the liquidity of any of the securities that are set aside, the Company may be required to liquidate the securities and transfer the cash to a third party until the acquisition closes.
  (was, 2015-04-22, similarity 0.9918):
[0001234452-15-000134:note_history:33]
In connection with the pending acquisition of CSR (Note 9), the Company agreed to set aside certain cash, cash equivalents and marketable securities to be held for purposes of satisfying payment of the consideration to effect the acquisition, which is expected to close by the end of the summer of 2015. At March 29, 2015, the fair values of the marketable securities that were set aside were $2.9 billion of corporate bonds and notes, $717 million of mortgage- and asset-backed securities and $140 million in U.S. Treasury securities and government-related securities. Additionally, $24 million in cash equivalents, which were recorded as other current assets, were set aside. If the combined fair values fall below approximately £1.9 billion (approximately $2.8 billion using an exchange rate of 1.4929), the Company may be required to set aside additional amounts. Additionally, if certain conditions are met, such as a reduction in the liquidity of any of the securities that are set aside, the Company may be required to liquidate the securities and transfer the cash to a third party until the acquisition closes.

- changed (2015-07-22):
[0001234452-15-000208:note_history:34]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At June 28, 2015, the Company had an effective ownership interest in the debt fund of 25%. Changes in fair value associated with this investment are recognized in net investment income. During the three and nine months ended June 28, 2015, the changes in fair value associated with this investment were negligible. During the three and nine months ended June 29, 2014, net increases in fair value associated with this investment were $12 million and $30 million, respectively.
  (was, 2015-04-22, similarity 0.9369):
[0001234452-15-000134:note_history:34]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At March 29, 2015, the Company had an effective ownership interest in the debt fund of 27%. Changes in fair value associated with this investment are recognized in net investment income. During the three and six months ended March 29, 2015, the changes in fair value associated with this investment were negligible. During the three and six months ended March 30, 2014, net increases in fair value associated with this investment were $12 million and $18 million, respectively.

- added (2015-07-22):
[0001234452-15-000208:note_history:35]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains recognized on debt securities classified as trading held at June 28, 2015 were negligible for both the three and nine months ended June 28, 2015. Net gains recognized on debt securities classified as trading held at June 29, 2014 were negligible for both the three and nine months ended June 29, 2014.

- changed (2015-07-22):
[0001234452-15-000208:note_history:36]
At June 28, 2015, the contractual maturities of available-for-sale debt securities were as follows (in millions):
  (was, 2015-04-22, similarity 0.9581):
[0001234452-15-000134:note_history:36]
At March 29, 2015, the contractual maturities of available-for-sale debt securities were as follows (in millions):

- changed (2015-07-22):
[0001234452-15-000208:note_history:37]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| June 28, 2015 | $ | 126 |  |  | $ | (10 | ) |  | $ | 116 |  |
| June 29, 2014 | 267 |  |  | (8 | ) |  | 259 |  |
| For the nine months ended |  |  |  |  |  |
| June 28, 2015 | $ | 434 |  |  | $ | (48 | ) |  | $ | 386 |  |
| June 29, 2014 | 610 |  |  | (16 | ) |  | 594 |  |
  (was, 2015-04-22, similarity 0.8516):
[0001234452-15-000134:note_history:37]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| March 29, 2015 | $ | 128 |  |  | $ | (30 | ) |  | $ | 98 |  |
| March 30, 2014 | 227 |  |  | (5 | ) |  | 222 |  |
| For the six months ended |  |  |  |  |  |
| March 29, 2015 | $ | 308 |  |  | $ | (37 | ) |  | $ | 271 |  |
| March 30, 2014 | 343 |  |  | (8 | ) |  | 335 |  |

- changed (2015-07-22):
[0001234452-15-000208:note_history:38]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| June 28, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,543 |  |  | $ | 391 |  |  | $ | (2 | ) |  | $ | 1,932 |  |
| Debt securities (including debt funds) | 21,203 |  |  | 253 |  |  | (92 | ) |  | 21,364 |  |
|  | $ | 22,746 |  |  | $ | 644 |  |  | $ | (94 | ) |  | $ | 23,296 |  |
| September 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,769 |  |  | $ | 575 |  |  | $ | (6 | ) |  | $ | 2,338 |  |
| Debt securities (including debt funds) | 19,582 |  |  | 312 |  |  | (60 | ) |  | 19,834 |  |
|  | $ | 21,351 |  |  | $ | 887 |  |  | $ | (66 | ) |  | $ | 22,172 |  |
  (was, 2015-04-22, similarity 0.9829):
[0001234452-15-000134:note_history:38]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| March 29, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,654 |  |  | $ | 383 |  |  | $ | — |  |  | $ | 2,037 |  |
| Debt securities (including debt funds) | 19,940 |  |  | 311 |  |  | (81 | ) |  | 20,170 |  |
|  | $ | 21,594 |  |  | $ | 694 |  |  | $ | (81 | ) |  | $ | 22,207 |  |
| September 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,769 |  |  | $ | 575 |  |  | $ | (6 | ) |  | $ | 2,338 |  |
| Debt securities (including debt funds) | 19,582 |  |  | 312 |  |  | (60 | ) |  | 19,834 |  |
|  | $ | 21,351 |  |  | $ | 887 |  |  | $ | (66 | ) |  | $ | 22,172 |  |

- changed (2015-07-22):
[0001234452-15-000208:note_history:39]
|  | June 28, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 313 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 7,413 |  |  | (59 | ) |  | 142 |  |  | (9 | ) |
| Mortgage- and asset-backed securities | 874 |  |  | (2 | ) |  | 16 |  |  | — |  |
| Auction rate securities | — |  |  | — |  |  | 46 |  |  | (1 | ) |
| Common and preferred stock | 155 |  |  | (2 | ) |  | 18 |  |  | — |  |
| Debt funds | 934 |  |  | (18 | ) |  | 47 |  |  | (1 | ) |
|  | $ | 9,689 |  |  | $ | (83 | ) |  | $ | 269 |  |  | $ | (11 | ) |
  (was, 2015-04-22, similarity 0.9646):
[0001234452-15-000134:note_history:39]
|  | March 29, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 395 |  |  | $ | (3 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,211 |  |  | (58 | ) |  | 201 |  |  | (10 | ) |
| Mortgage- and asset-backed securities | 535 |  |  | (1 | ) |  | 26 |  |  | — |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | (1 | ) |
| Common and preferred stock | 13 |  |  | — |  |  | 12 |  |  | — |  |
| Debt funds | 784 |  |  | (7 | ) |  | 38 |  |  | (1 | ) |
|  | $ | 5,938 |  |  | $ | (69 | ) |  | $ | 324 |  |  | $ | (12 | ) |

- changed (2015-07-22):
[0001234452-15-000208:note_history:40]
At June 28, 2015, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.
  (was, 2015-04-22, similarity 0.9921):
[0001234452-15-000134:note_history:40]
At March 29, 2015, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

- changed (2015-07-22):
[0001234452-15-000208:note_history:41]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company were negligible at June 28, 2015 and June 29, 2014, respectively.
  (was, 2015-04-22, similarity 0.8902):
[0001234452-15-000134:note_history:41]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was negligible at March 29, 2015 and March 30, 2014.

- removed (2015-07-22):
[0001234452-15-000134:note_history:42]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains recognized on debt securities classified as trading held at March 29, 2015 were $14 million and negligible for the three and six months ended March 29, 2015, respectively. Net gains recognized on debt securities classified as trading held at March 30, 2014 were negligible for both the three and six months ended March 30, 2014.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2015-07-22):
[0001234452-15-000208:note_history:43]
The following table provides a summary of the Company’s long-term debt as of June 28, 2015 (dollar amounts in millions):

- added (2015-07-22):
[0001234452-15-000208:note_history:44]
|  |  | PrincipalAmount |  | EffectiveInterest Rate |
| Floating-rate notes due May 18, 2018 |  | $ | 250 |  |  | 0.61% |
| Floating-rate notes due May 20, 2020 |  | 250 |  |  | 0.88% |
| Fixed-rate 1.40% notes due May 18, 2018 |  | 1,250 |  |  | 0.68% |
| Fixed-rate 2.25% notes due May 20, 2020 |  | 1,750 |  |  | 1.78% |
| Fixed-rate 3.00% notes due May 20, 2022 |  | 2,000 |  |  | 2.28% |
| Fixed-rate 3.45% notes due May 20, 2025 |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 |  | 1,500 |  |  | 4.71% |
| Total principal |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments |  | (22 | ) |  |  |
| Total long-term debt |  | $ | 9,913 |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2015-07-22):
[0001234452-15-000208:note_history:45]
Note 12 - Subsequent Event

- added (2015-07-22):
[0001234452-15-000208:note_history:46]
On July 22, 2015, the Company announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as the Company works to create sustainable long-term value for stockholders. As part of this, among other actions, the Company is implementing a cost reduction plan to reduce annual costs from fiscal 2015 levels of $7.3 billion (adjusted for variable compensation) by approximately $1.1 billion through a series of targeted reductions across the Company’s businesses, particularly in QCT. The Company also plans to reduce annual share-based compensation grants by approximately $300 million. The Company expects these cost initiatives to be fully implemented by the end of fiscal 2016. In connection with this plan, the Company expects to incur approximately $350 million to $450 million in restructuring and restructuring-related charges, of which approximately $100 million to $200 million are expected to be incurred in the fourth quarter of fiscal 2015. Restructuring and restructuring-related charges include an estimate of severance costs, lease termination costs, acceleration of depreciation, consultancy fees and other costs.
