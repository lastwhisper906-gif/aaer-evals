# QCOM 8-K — 0001234452-15-000269 filed 2015-11-04

## item codes, every 8-K on or before 2015-11-04

- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2015-11-04

- none on or before 2015-11-04

## item 2.02 — earnings release, exhibit 99.1

[0001234452-15-000269:8k_2_02:1]
EX-99.1
2
qcom92715erex991.htm
EXHIBIT 99.1

[0001234452-15-000269:8k_2_02:2]
Exhibit

[0001234452-15-000269:8k_2_02:3]
Exhibit 99.1

[0001234452-15-000269:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-15-000269:8k_2_02:5]
Qualcomm Contact:

[0001234452-15-000269:8k_2_02:6]
Warren Kneeshaw

[0001234452-15-000269:8k_2_02:7]
Vice President, Investor Relations

[0001234452-15-000269:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-15-000269:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-15-000269:8k_2_02:10]
Qualcomm Announces Fourth Quarter and Fiscal 2015 Results

[0001234452-15-000269:8k_2_02:11]
Fiscal 2015 Revenues $25.3 billion

[0001234452-15-000269:8k_2_02:12]
GAAP EPS $3.22, Non-GAAP EPS $4.66

[0001234452-15-000269:8k_2_02:13]
-Record Fiscal Year QTL Results and $14 Billion Return of Capital to Stockholders-

[0001234452-15-000269:8k_2_02:14]
SAN DIEGO - November 4, 2015 - Qualcomm Incorporated (Nasdaq:  QCOM), a leading developer and innovator of advanced wireless technologies, products and services, today announced results for its fiscal fourth quarter and year ended September 27, 2015.

[0001234452-15-000269:8k_2_02:15]
“Our fiscal fourth quarter revenues and EPS were at the high end of our expectations, with stronger-than-expected MSM chipset shipments offsetting slower than expected progress concluding new license agreements in China.  We executed a major increase in our capital return program in fiscal 2015, returning a record $14 billion of capital to stockholders,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “We are encouraged by customer reaction to our flagship Snapdragon 820, are on track to deliver on our fiscal 2016 cost reduction targets and expect to exit fiscal 2016 on an improving financial trajectory.”

[0001234452-15-000269:8k_2_02:16]
GAAP Results

[0001234452-15-000269:8k_2_02:17]
Fourth Quarter Fiscal 2015*

[0001234452-15-000269:8k_2_02:18]
|  | Q4 Fiscal 2015 |  | Q4 Fiscal 2014 |  | Year-Over-Year Change |  | Q3 Fiscal 2015 |  | Sequential Change |
| Revenues 1 | $5.5B |  | $6.7B |  | (18%) |  | $5.8B |  | (6%) |
| Operating income 1 | $1.1B |  | $2.0B |  | (43%) |  | $1.2B |  | (8%) |
| Net income 2 | $1.1B |  | $1.9B |  | (44%) |  | $1.2B |  | (10%) |
| Diluted earnings per share 2 | $0.67 |  | $1.11 |  | (40%) |  | $0.73 |  | (8%) |
| Operating cash flow | $1.7B |  | $1.6B |  | +4% |  | $2.1B |  | (20%) |

[0001234452-15-000269:8k_2_02:19]
1 Throughout this news release, revenues, operating expenses, operating income, earnings before tax (EBT) and effective tax rates are from continuing operations (i.e., before adjustments for noncontrolling interests and discontinued operations), unless otherwise stated.

[0001234452-15-000269:8k_2_02:20]
2 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests and discontinued operations), unless otherwise stated.

[0001234452-15-000269:8k_2_02:21]
Fiscal 2015*

[0001234452-15-000269:8k_2_02:22]
|  | Fiscal 2015 |  | Fiscal2014 |  | Year-Over-Year Change |
| Revenues | $25.3B |  | $26.5B |  | (5%) |
| Operating income | $5.8B |  | $7.6B |  | (23%) |
| Net income | $5.3B |  | $8.0B |  | (34%) |
| Diluted earnings per share | $3.22 |  | $4.65 |  | (31%) |
| Operating cash flow | $5.5B |  | $8.9B |  | (38%) |

[0001234452-15-000269:8k_2_02:23]
Non-GAAP Results

[0001234452-15-000269:8k_2_02:24]
Fourth Quarter Fiscal 2015*

[0001234452-15-000269:8k_2_02:25]
|  | Q4 Fiscal 2015 |  | Q4 Fiscal 2014 |  | Year-Over-Year Change |  | Q3 Fiscal 2015 |  | Sequential Change |
| Revenues | $5.5B |  | $6.7B |  | (19%) |  | $5.8B |  | (7%) |
| Operating income | $1.6B |  | $2.3B |  | (30%) |  | $1.7B |  | (5%) |
| Net income | $1.4B |  | $2.1B |  | (33%) |  | $1.6B |  | (11%) |
| Diluted earnings per share | $0.91 |  | $1.26 |  | (28%) |  | $0.99 |  | (8%) |

[0001234452-15-000269:8k_2_02:26]
Fiscal 2015*

[0001234452-15-000269:8k_2_02:27]
|  | Fiscal2015 |  | Fiscal2014 |  | Year-Over-Year Change |
| Revenues | $25.3B |  | $26.5B |  | (5%) |
| Operating income | $8.6B |  | $8.9B |  | (4%) |
| Net income | $7.6B |  | $9.0B |  | (15%) |
| Diluted earnings per share | $4.66 |  | $5.27 |  | (12%) |

[0001234452-15-000269:8k_2_02:28]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Beginning in the first quarter of fiscal 2015, we changed our methodology for reporting Non-GAAP results to exclude third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairment charges and litigation settlements and/or damages.  Detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-15-000269:8k_2_02:29]
* The following should be considered in regards to the year-over-year and sequential comparisons:

[0001234452-15-000269:8k_2_02:30]
| • | The fiscal 2015 GAAP results included: |

[0001234452-15-000269:8k_2_02:31]
| ◦ | $975 million charge, or $0.58 per share, related to the resolution reached with the China National Development and Reform Commission (NDRC) regarding its investigation of us under China’s Anti-Monopoly Law in the second quarter of fiscal 2015; |

[0001234452-15-000269:8k_2_02:32]
| ◦ | $142 million of charges, or $0.08 per share, that resulted from an impairment of goodwill and long-lived assets related to one of our display businesses in the third quarter of fiscal 2015; |

[0001234452-15-000269:8k_2_02:33]
| ◦ | $190 million of charges, or $0.09 per share, that resulted from restructuring and restructuring-related charges related to our Strategic Realignment Plan in the fourth quarter of fiscal 2015; and |

[0001234452-15-000269:8k_2_02:34]
| ◦ | Operating cash flow also was impacted by the prepayment of $950 million to secure long-term capacity commitments at a supplier of our integrated circuit products in the second quarter of fiscal 2015. |

[0001234452-15-000269:8k_2_02:35]
| • | The fiscal 2014 Non-GAAP and GAAP results included: |

[0001234452-15-000269:8k_2_02:36]
| ◦ | $665 million gain, or $0.25 per share, in discontinued operations associated with the sale of substantially all of the operations of our Omnitracs division in the first quarter of fiscal 2014; |

[0001234452-15-000269:8k_2_02:37]
| ◦ | $444 million charge, or $0.20 per share, that resulted from an impairment on long-lived assets related to one of our display businesses in the first quarter of fiscal 2014; |

[0001234452-15-000269:8k_2_02:38]
| ◦ | $208 million of income, or $0.12 per share, of which $184 million was recorded in other income, due to the reversal of accruals related to our litigation with ParkerVision in the third quarter of fiscal 2014; and |

[0001234452-15-000269:8k_2_02:39]
| ◦ | $164 million of charges, or $0.08 per share, that resulted from an impairment of goodwill and long-lived assets related to one of our display businesses in the third quarter of fiscal 2014. |

[0001234452-15-000269:8k_2_02:40]
Key Business Metrics

[0001234452-15-000269:8k_2_02:41]
Fourth Quarter

[0001234452-15-000269:8k_2_02:42]
|  | Q4 Fiscal 2015 |  | Q4 Fiscal 2014 |  | Year-Over-Year Change (1) |  | Q3 Fiscal 2015 |  | Sequential Change (1) |
| MSMTM chip shipments | 203M |  | 236M |  | (14%) |  | 225M |  | (10%) |
| Total reported device sales (2) | $58.3B |  | $57.4B |  | +2% |  | $60.4B |  | (3%) |
| Est. reported 3G/4G device shipments (approx.) (2) | 276M - 280M |  | 256M - 260M |  | +8% |  | 289M - 293M |  | (4%) |
| Est. reported 3G/4G average selling price (approx.) (2) | $207 - $213 |  | $220 - $226 |  | (6%) |  | $205 - $211 |  | +1% |

[0001234452-15-000269:8k_2_02:43]
Fiscal 2015

[0001234452-15-000269:8k_2_02:44]
|  | Fiscal2015 |  | Fiscal2014 |  | Year-Over-Year Change (1) |
| MSM chip shipments | 932M |  | 861M |  | +8% |
| Total reported device sales (2) | $250.9B |  | $243.6B |  | +3% |
| Est. reported 3G/4G device shipments (approx.) (2) | 1,233M - 1,249M |  | 1,077M - 1,093M |  | +14% |
| Est. reported 3G/4G average selling price (approx.) (2) | $199 - $205 |  | $222 - $228 |  | (10%) |

[0001234452-15-000269:8k_2_02:45]
| (1) | The year-over-year and sequential changes for estimated reported 3G/4G device shipments and average selling prices are calculated at the midpoints. The midpoints of the estimated ranges are used for comparison purposes only and do not indicate a higher degree of confidence in the midpoints. |

[0001234452-15-000269:8k_2_02:46]
| (2) | The fourth quarter of fiscal 2014 and 2015 are based on sales by our licensees in the June quarter as reported to us in the September quarter, and the third quarter of fiscal 2015 is based on sales by our licensees in the March quarter as reported to us in the June quarter. Fiscal 2014 and 2015 are based on sales of our licensees in the September to June quarters as reported to us in the December to September quarters. |

[0001234452-15-000269:8k_2_02:47]
Cash and Marketable Securities

[0001234452-15-000269:8k_2_02:48]
Our cash, cash equivalents and marketable securities totaled $30.9 billion at the end of the fourth quarter of fiscal 2015, compared to $32.0 billion a year ago and $35.2 billion at the end of the third quarter of fiscal 2015.  In August 2015, we acquired CSR plc for $2.3 billion in cash, net of cash acquired.

[0001234452-15-000269:8k_2_02:49]
Return of Capital to Stockholders

[0001234452-15-000269:8k_2_02:50]
The following table summarizes stock repurchases and dividends paid during the fourth quarter and fiscal 2015 (in millions, except per-share amounts):

[0001234452-15-000269:8k_2_02:51]
|  | Stock Repurchases |  | Dividends |  | Total |
|  | Shares (1) |  | Amount |  | Per Share |  | Amount |  | Amount |
| Q4 fiscal 2015 | 58.0 |  | $2,230 |  | $0.48 |  | $738 |  | $2,968 |
| Fiscal 2015 | 172.4 |  | $11,245 |  | $1.80 |  | $2,880 |  | $14,125 |

[0001234452-15-000269:8k_2_02:52]
| (1) | Fourth quarter fiscal 2015 shares repurchased includes 20.5 million shares delivered in August 2015 upon the completion of the accelerated share repurchase agreements, in addition to 37.5 million shares repurchased for $2.2 billion. In fiscal 2015, a total of 78.3 million shares were delivered under the $5.0 billion accelerated share repurchase agreements, in addition to 94.2 million shares repurchased for $6.2 billion. |

[0001234452-15-000269:8k_2_02:53]
Our fiscal 2015 return of capital to stockholders of $14.1 billion was a record and increased 98 percent year-over-year.  Since September 27, 2015, we repurchased and retired 24.6 million shares of common stock for $1.4 billion.  On October 9, 2015, we announced a cash dividend of $0.48 per share payable on December 18, 2015 to stockholders of record as of the close of business on December 1, 2015.

[0001234452-15-000269:8k_2_02:54]
Effective Income Tax Rates

[0001234452-15-000269:8k_2_02:55]
Our fiscal 2015 annual effective income tax rates were 19 percent for GAAP and 18 percent for Non-GAAP, both of which include the United States federal research and development (R&D) tax credit generated through December 31, 2014, the date on which the credit expired.  The fiscal 2015 GAAP effective tax rate included the impact of the $975 million fine related to the resolution of the NDRC investigation during the second quarter of fiscal 2015, which was not deductible for tax purposes.  The effective income tax rates for the fourth quarter of fiscal 2015 were 15 percent for GAAP and 17 percent for Non-GAAP.

[0001234452-15-000269:8k_2_02:56]
Business Outlook

[0001234452-15-000269:8k_2_02:57]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment and certain derivative gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.  Our outlook includes an estimate of the benefit related to stock repurchases that we plan to complete.

[0001234452-15-000269:8k_2_02:58]
Updating Guidance Practices

[0001234452-15-000269:8k_2_02:59]
We have modified our approach to providing a financial outlook for our business.  Beginning with today’s release, we are no longer providing annual revenue and EPS guidance.  We will continue to provide quarterly guidance for certain financial and operational metrics, along with commentary on our earnings call on the drivers of our longer-term performance, including our view of industry trends and growth prospects and other key factors that influence our business and operating environment.  For fiscal 2016, we will provide certain full-year financial metrics to assist with the transition to our new policy.  This approach aligns our practices more closely with our semiconductor and large cap technology peers.  Our quarterly executive presentation, which is available on the results section of our investor relations website http://investor.qualcomm.com/results.cfm, also includes the supplementary guidance points we are providing during the transition to this new practice.

[0001234452-15-000269:8k_2_02:60]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-15-000269:8k_2_02:61]
Qualcomm’s Business Outlook Summary

[0001234452-15-000269:8k_2_02:62]
| FIRST FISCAL QUARTER |
|  |  | Q1 FY15 Results | Current Guidance Q1 FY16 Estimates |
|  | Revenues |  | $7.1 | B | $5.2B - $6.0B |  |
|  | Year-over-year change |  | decrease 15% - 27% |  |
|  | Non-GAAP diluted earnings per share (EPS) |  | $1.34 |  | $0.80 - $0.90 |  |
|  | Year-over-year change |  | decrease 33% - 40% |  |
|  | Diluted EPS attributable to QSI (1) |  | $0.00 |  |  | $0.28 |  |
|  | Diluted EPS attributable to share-based compensation |  | ($0.14 | ) |  | ($0.12 | ) |
|  | Diluted EPS attributable to other items (2) |  | ($0.04 | ) |  | ($0.16 | ) |
|  | GAAP diluted EPS |  | $1.17 |  | $0.80 - $0.90 |  |
|  | Year-over-year change |  | decrease 23% - 32% |  |
|  | Metrics |  |  |
|  | MSM chip shipments | 270 | M | 225M - 245M |  |
|  | Year-over-year change |  | decrease 9% - 17% |  |
|  | Total reported device sales* (3) | approx. $56.4B | approx. $50.0B - $58.0B (4) |  |
|  | Year-over-year change |  | decrease 11% - increase 3% |  |
|  | *Est. sales in September quarter, reported in December quarter |  |  |

[0001234452-15-000269:8k_2_02:63]
| (1) | Our guidance for diluted EPS attributable to QSI for the first quarter of fiscal 2016 includes earnings per share of $0.25 related to an estimated gain of approximately $380 million associated with completing the sale of our L-Band spectrum in the United Kingdom. |

[0001234452-15-000269:8k_2_02:64]
| (2) | Our guidance for diluted EPS attributable to other items for the first quarter of fiscal 2016 includes a loss per share of $0.10 for acquisition-related items. |

[0001234452-15-000269:8k_2_02:65]
| (3) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). The reported quarterly estimated ranges of average selling prices (ASPs) and unit shipments are determined based on the information as reported to us by our licensees during the relevant period and our own estimates of the selling prices and unit shipments for licensees that do not provide such information. Not all licensees report sales, selling prices and/or unit shipments the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales, estimated unit shipments and estimated ASPs for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-15-000269:8k_2_02:66]
| (4) | Our guidance range for the first quarter of fiscal 2016 total reported device sales reflects estimated 3G/4G total reported device sales that we currently expect to be reported to us, which includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-15-000269:8k_2_02:67]
Sums may not equal totals due to rounding.

[0001234452-15-000269:8k_2_02:68]
Results of Business Segments

[0001234452-15-000269:8k_2_02:69]
The following table reconciles our Non-GAAP results to our GAAP results ($ in millions, except per share data):

[0001234452-15-000269:8k_2_02:70]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (a) | Non-GAAP | QSI | Share-Based Compensation | Other Items (b) (c) (d) |  | GAAP |
| Q4 - FISCAL 2015 |  |  |  |  |  |
| Revenues | $3,625 | $1,785 | $42 | $5,452 |  | $4 |  |  | $— |  |  | $— |  |  | $5,456 |  |
| Change from prior year | (25 | %) | (1 | %) | (13 | %) | (19 | %) |  | N/M |  |  |  |  |  | (18 | %) |  |
| Change from prior quarter | (6 | %) | (8 | %) | (13 | %) | (7 | %) |  | N/M |  |  |  |  |  | (6 | %) |  |
| Cost of equipment and services revenues |  |  |  | $2,151 |  | $4 |  | $9 | $88 |  | $2,252 |  |
| Research and development |  |  |  | 1,202 |  | 1 |  | 151 | 3 |  | 1,357 |  |
| Selling, general and administrative |  |  |  | 482 |  | 7 |  | 73 | 33 |  | 595 |  |
| Other expenses |  |  |  | — |  |  | — |  |  | — |  | 112 |  | 112 |  |
| Operating income (loss) |  |  |  | $1,617 |  | ($8) |  | ($233) | ($236) |  | $1,140 |  |
| Change from prior year |  |  |  | (30 | %) |  | N/M |  |  | 8 | % | N/M |  |  | (43 | %) |  |
| Change from prior quarter |  |  |  | (5 | %) |  | 62 | % |  | 14 | % | (30 | %) |  | (8 | %) |  |
| Interest expense |  |  |  | ($70) |  |  | $— |  |  |  | $— |  |  | $— |  |  | ($70) |  |
| Investment income, net |  |  |  | $166 | (e) | $16 | (f) |  | $— |  |  | $— |  |  | $182 |  |
| EBT | $280 | $1,487 | ($54) | $1,713 |  | $8 |  | ($233) | ($236) |  | $1,252 |  |
| Change from prior year | (73 | %) | (3 | %) | N/M |  | (33 | %) |  | (72 | %) |  | 8 | % | N/M |  |  | (44 | %) |  |
| Change from prior quarter | (3 | %) | (10 | %) | N/M |  | (10 | %) |  | N/M |  |  | 14 | % | (30 | %) |  | (10 | %) |  |
| EBT as % of revenues | 8 | % | 83 | % | N/M |  | 31 | % |  |  |  |  |  |  | 23 | % |  |
| Net income (loss) |  |  |  | $1,427 |  | $8 |  | ($188) | ($186) |  | $1,061 |  |
| Change from prior year |  |  |  | (33 | %) |  | (71 | %) |  | 6 | % | N/M |  |  | (44 | %) |  |
| Change from prior quarter |  |  |  | (11 | %) |  | N/M |  |  | 12 | % | 1 | % |  | (10 | %) |  |
| Diluted EPS |  |  |  | $0.91 |  | $0.01 |  | ($0.12) | ($0.12) |  | $0.67 |  |
| Change from prior year |  |  |  | (28 | %) |  | (50 | %) |  | — | % | N/M |  |  | (40 | %) |  |
| Change from prior quarter |  |  |  | (8 | %) |  | N/M |  |  | 8 | % | — | % |  | (8 | %) |  |
| Diluted shares |  |  |  | 1,573 |  | 1,573 |  | 1,573 | 1,573 |  | 1,573 |  |
| Q3 - FISCAL 2015 |  |  |  |  |  |
| Revenues | $3,853 | $1,931 | $48 | $5,832 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $5,832 |  |
| Operating income (loss) |  |  |  | 1,709 |  | (21) |  | (271) | (182) |  | 1,235 |  |
| EBT | $289 | $1,654 | ($43) | 1,900 |  | (49) |  | (271) | (182) |  | 1,398 |  |
| Net income (loss) |  |  |  | 1,611 |  | (26) |  | (213) | (188) |  | 1,184 |  |
| Diluted EPS |  |  |  | $0.99 |  | ($0.02) |  | ($0.13) | ($0.12) |  | $0.73 |  |
| Diluted shares |  |  |  | 1,629 |  | 1,629 |  | 1,629 | 1,629 |  | 1,629 |  |
| Q4 - FISCAL 2014 |  |  |  |  |  |
| Revenues | $4,849 | $1,795 | $48 | $6,692 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $6,692 |  |
| Operating income (loss) |  |  |  | 2,323 |  | (3) |  | (252) | (76) |  | 1,992 |  |
| EBT | $1,045 | $1,536 | ($30) | 2,551 |  | 29 |  | (252) | (76) |  | 2,252 |  |
| Net income (loss) |  |  |  | 2,143 |  | 28 |  | (199) | (78) |  | 1,894 |  |
| Diluted EPS |  |  |  | $1.26 |  | $0.02 |  | ($0.12) | ($0.05) |  | $1.11 |  |
| Diluted shares |  |  |  | 1,701 |  | 1,701 |  | 1,701 | 1,701 |  | 1,701 |  |

[0001234452-15-000269:8k_2_02:71]
| (a) | Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations. Non-GAAP reconciling items related to earnings before taxes consisted primarily of certain research and development expenses, selling, general and administrative expenses, other expenses or income, interest expense and certain investment income that are not allocated to the segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit. |

[0001234452-15-000269:8k_2_02:72]
| (b) | Beginning in the first quarter of fiscal 2015, we changed our methodology for reporting Non-GAAP results to exclude third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairment charges and litigation settlements and/or damages. In the fourth quarter of fiscal 2015, other items excluded from Non-GAAP EBT included $190 million of restructuring and restructuring-related charges related to our Strategic Realignment Plan, $119 million of acquisition-related items and $5 million of other severance costs and asset impairment charges, partially offset by a $78 million gain on the sale of certain assets. |

[0001234452-15-000269:8k_2_02:73]
| (c) | In the fourth quarter of fiscal 2015, the tax benefit in the “Other Items” column included a $33 million tax benefit for the tax effect of other items in EBT, a $11 million tax benefit for the tax effect of acquisition-related items and a $6 million tax benefit to reconcile the tax provision for each column to the total GAAP tax provision for the quarter. At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. In interim quarters of prior fiscal years, this difference was allocated to the tax provisions (benefits) among the columns. See the “Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates” herein. |

[0001234452-15-000269:8k_2_02:74]
| (d) | Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001234452-15-000269:8k_2_02:75]
| (e) | Included $127 million in interest and dividend income and $69 million in net realized gains on investments, partially offset by $29 million in other-than-temporary losses on investments and $1 million in other net investment expense. |

[0001234452-15-000269:8k_2_02:76]
| (f) | Included $32 million in net realized gains on investments, partially offset by $10 million in other-than-temporary losses on investments and $6 million in equity in losses of investees. |

[0001234452-15-000269:8k_2_02:77]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (a) | Non-GAAP | QSI | Share-Based Compensation | Other Items (d) (g) (h) |  | GAAP |
| 12 MONTHS - FISCAL 2015 |  |  |  |  |  |
| Revenues | $17,154 | $7,947 | $176 | $25,277 |  | $4 |  |  | $— |  |  | $— |  |  | $25,281 |  |
| Change from prior year | (8 | %) | 5 | % | (30 | %) | (5 | %) |  |  |  |  |  |  | (5 | %) |  |
| Cost of equipment and services revenues |  |  |  | $10,060 |  | $4 |  | $42 | $272 |  | $10,378 |  |
| Research and development |  |  |  | 4,784 |  | 6 |  | 659 | 41 |  | 5,490 |  |
| Selling, general and administrative |  |  |  | 1,864 |  | 34 |  | 325 | 121 |  | 2,344 |  |
| Other expenses |  |  |  | 4 |  | — |  |  | — |  | 1,289 |  | 1,293 |  |
| Operating income (loss) |  |  |  | $8,565 |  | ($40) |  | ($1,026) | ($1,723) |  | $5,776 |  |
| Change from prior year |  |  |  | (4 | %) |  | N/M |  |  | 3 | % | N/M |  |  | (23 | %) |  |
| Interest expense |  |  |  | ($104) |  |  | $— |  |  |  | $— |  |  | $— |  |  | ($104) |  |
| Investment income, net |  |  |  | $849 | (i) | ($34) | (j) |  | $— |  |  | $— |  |  | $815 |  |
| EBT | $2,465 | $6,882 | ($37) | $9,310 |  | ($74) |  | ($1,026) | ($1,723) |  | $6,487 |  |
| Change from prior year | (35 | %) | 4 | % | N/M |  | (8 | %) |  | N/M |  |  | 3 | % | N/M |  |  | (26 | %) |  |
| EBT as % of revenues | 14 | % | 87 | % | N/M |  | 37 | % |  |  |  |  |  |  | 26 | % |  |
| Net income (loss) |  |  |  | $7,641 |  | ($44) |  | ($836) | ($1,490) |  | $5,271 |  |
| Change from prior year |  |  |  | (15 | %) |  | N/M |  |  | 2 | % | N/M |  |  | (34 | %) |  |
| Diluted EPS |  |  |  | $4.66 |  | ($0.03) |  | ($0.51) | ($0.91) |  | $3.22 |  |
| Change from prior year |  |  |  | (12 | %) |  | N/M |  |  | (2 | %) | N/M |  |  | (31 | %) |  |
| Diluted shares |  |  |  | 1,639 |  | 1,639 |  | 1,639 | 1,639 |  | 1,639 |  |
| 12 MONTHS - FISCAL 2014 |  |  |  |  |  |
| Revenues | $18,665 | $7,569 | $253 | $26,487 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $26,487 |  |
| Operating income (loss) |  |  |  | 8,933 |  | (18) |  | (1,059) | (306) |  | 7,550 |  |
| EBT | $3,807 | $6,590 | ($247) | 10,150 |  | (7) |  | (1,059) | (306) |  | 8,778 |  |
| Discontinued operations, net of tax |  |  |  | 430 |  | — |  |  | — |  | — |  |  | 430 |  |
| Net income (loss) |  |  |  | 9,032 |  | 15 |  | (856) | (224) |  | 7,967 |  |
| Diluted EPS |  |  |  | $5.27 |  | $0.01 |  | ($0.50) | ($0.13) |  | $4.65 |  |
| Diluted shares |  |  |  | 1,714 |  | 1,714 |  | 1,714 | 1,714 |  | 1,714 |  |

[0001234452-15-000269:8k_2_02:78]
| (g) | In the fiscal year ended September 27, 2015, other items excluded from Non-GAAP EBT included $975 million related to the resolution reached with the NDRC, $358 million of acquisition-related items, $235 million related to goodwill impairment charges, $190 million of restructuring and restructuring-related charges related to our Strategic Realignment Plan, $48 million of other severance costs and $40 million in asset impairment charges, partially offset by $123 million in gains on the sale of certain assets. |

[0001234452-15-000269:8k_2_02:79]
| (h) | In the fiscal year ended September 27, 2015, the tax benefit in the “Other Items” column included a $101 million tax benefit related to fiscal 2014 as a result of the retroactive reinstatement of the federal R&D tax credit, a $61 million tax benefit as a result of an agreement reached with the Internal Revenue Service related to Atheros’ pre-acquisition tax returns, a $58 million tax benefit for the tax effect of other items in EBT, a $10 million tax benefit for the tax effect of acquisition-related items and a $3 million tax benefit related to fiscal 2014 as a result of the retroactive reinstatement of other tax laws. See the “Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates” herein. |

[0001234452-15-000269:8k_2_02:80]
| (i) | Included $524 million in interest and dividend income, $440 million in net realized gains on investments and $4 million in other net investment income, partially offset by $119 million in other-than-temporary losses on investments. |

[0001234452-15-000269:8k_2_02:81]
| (j) | Included $81 million in other-than-temporary losses on investments and $24 million in equity in losses of investees, partially offset by $60 million in net realized gains on investments and $11 million in other net investment income. |

[0001234452-15-000269:8k_2_02:82]
N/M - Not Meaningful

[0001234452-15-000269:8k_2_02:83]
Sums may not equal totals due to rounding.

[0001234452-15-000269:8k_2_02:84]
Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates

[0001234452-15-000269:8k_2_02:85]
(Unaudited)

[0001234452-15-000269:8k_2_02:86]
| Three Months Ended September 27, 2015 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Other Items |  |  | GAAP Results |  |
| Income (loss) from continuing operations before income taxes |  | $ | 1,713 |  |  |  | $ | 8 |  |  |  | $ | (233 | ) |  |  | $ | (236 | ) |  |  | $ | 1,252 |  |  |
| Income tax (expense) benefit |  | (286 | ) |  |  | (1 | ) |  |  | 45 |  |  |  | 50 |  |  |  | (192 | ) |  |
| Income (loss) from continuing operations |  | $ | 1,427 |  |  |  | $ | 7 |  |  |  | $ | (188 | ) |  |  | $ | (186 | ) |  |  | $ | 1,060 |  |  |
| Tax rate |  | 17 | % |  |  | 13 | % |  |  | 19 | % |  |  | 21 | % |  |  | 15 | % |  |

[0001234452-15-000269:8k_2_02:87]
| Year Ended September 27, 2015 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Other Items |  |  | GAAP Results |  |
| Income (loss) from continuing operations before income taxes |  | $ | 9,310 |  |  |  | $ | (74 | ) |  |  | $ | (1,026 | ) |  |  | $ | (1,723 | ) |  |  | $ | 6,487 |  |  |
| Income tax (expense) benefit |  | (1,669 | ) |  |  | 27 |  |  |  | 190 |  |  |  | 233 |  |  |  | (1,219 | ) |  |
| Income (loss) from continuing operations |  | $ | 7,641 |  |  |  | $ | (47 | ) |  |  | $ | (836 | ) |  |  | $ | (1,490 | ) |  |  | $ | 5,268 |  |  |
| Tax rate |  | 18 | % |  |  | 36 | % |  |  | 19 | % |  |  | 14 | % |  |  | 19 | % |  |

[0001234452-15-000269:8k_2_02:88]
Conference Call

[0001234452-15-000269:8k_2_02:89]
Qualcomm’s fiscal fourth quarter and fiscal 2015 earnings conference call will be broadcast live on November 4, 2015, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 60312462.

[0001234452-15-000269:8k_2_02:90]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-15-000269:8k_2_02:91]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for, or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-15-000269:8k_2_02:92]
The Company uses the Non-GAAP financial information: (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and

[0001234452-15-000269:8k_2_02:93]
efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against each other and against competitors.  Non-GAAP measurements used by the Company include revenues, cost of equipment and services revenues, R&D expenses, SG&A expenses, other expenses, operating income, interest expense, net investment income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial information also is used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0001234452-15-000269:8k_2_02:94]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items, tax items and other items.

[0001234452-15-000269:8k_2_02:95]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-15-000269:8k_2_02:96]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001234452-15-000269:8k_2_02:97]
| • | Certain other items are excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001234452-15-000269:8k_2_02:98]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items starting with acquisitions completed in the third quarter of fiscal 2011, as well as any tax effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property. Starting in the first quarter of fiscal 2015, the Company excludes third-party |

[0001234452-15-000269:8k_2_02:99]
acquisition and integration services costs.  Prior year amounts have not been reclassified to conform to the current presentation.

[0001234452-15-000269:8k_2_02:100]
| • | Starting in the first quarter of fiscal 2015, the Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and litigation settlements and/or damages. Prior year amounts have not been reclassified to conform to the current presentation. |

[0001234452-15-000269:8k_2_02:101]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. |

[0001234452-15-000269:8k_2_02:102]
About Qualcomm

[0001234452-15-000269:8k_2_02:103]
Qualcomm Incorporated (Nasdaq: QCOM) is a world leader in 3G, 4G and next-generation wireless technologies.  Qualcomm Incorporated includes Qualcomm’s licensing business, QTL, and the vast majority of its patent portfolio.  Qualcomm Technologies, Inc., a wholly-owned subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of Qualcomm’s engineering, research and development functions, and substantially all of its products and services businesses, including its semiconductor business, QCT.  For more than 30 years, Qualcomm ideas and inventions have driven the evolution of digital communications, linking people everywhere more closely to information, entertainment and each other.  For more information, visit www.qualcomm.com.

[0001234452-15-000269:8k_2_02:104]
Note Regarding Forward-Looking Statements

[0001234452-15-000269:8k_2_02:105]
###

[0001234452-15-000269:8k_2_02:106]
Qualcomm, Snapdragon and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-15-000269:8k_2_02:107]
Qualcomm Incorporated

[0001234452-15-000269:8k_2_02:108]
CONSOLIDATED BALANCE SHEETS

[0001234452-15-000269:8k_2_02:109]
(In millions, except per share data)

[0001234452-15-000269:8k_2_02:110]
(Unaudited)

[0001234452-15-000269:8k_2_02:111]
|  | September 27, 2015 |  | September 28, 2014 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 7,560 |  |  | $ | 7,907 |  |
| Marketable securities | 9,761 |  |  | 9,658 |  |
| Accounts receivable, net | 1,964 |  |  | 2,412 |  |
| Inventories | 1,492 |  |  | 1,458 |  |
| Deferred tax assets | 635 |  |  | 577 |  |
| Other current assets | 687 |  |  | 401 |  |
| Total current assets | 22,099 |  |  | 22,413 |  |
| Marketable securities | 13,626 |  |  | 14,457 |  |
| Deferred tax assets | 1,453 |  |  | 1,174 |  |
| Property, plant and equipment, net | 2,534 |  |  | 2,487 |  |
| Goodwill | 5,479 |  |  | 4,488 |  |
| Other intangible assets, net | 3,742 |  |  | 2,580 |  |
| Other assets | 1,863 |  |  | 975 |  |
| Total assets | $ | 50,796 |  |  | $ | 48,574 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,300 |  |  | $ | 2,183 |  |
| Payroll and other benefits related liabilities | 861 |  |  | 802 |  |
| Unearned revenues | 583 |  |  | 785 |  |
| Short-term debt | 1,000 |  |  | — |  |
| Other current liabilities | 2,356 |  |  | 2,243 |  |
| Total current liabilities | 6,100 |  |  | 6,013 |  |
| Unearned revenues | 2,496 |  |  | 2,967 |  |
| Long-term debt | 9,969 |  |  | — |  |
| Other liabilities | 817 |  |  | 428 |  |
| Total liabilities | 19,382 |  |  | 9,408 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,524 and 1,669 shares issued and outstanding, respectively | — |  |  | 7,736 |  |
| Retained earnings | 31,226 |  |  | 30,799 |  |
| Accumulated other comprehensive income | 195 |  |  | 634 |  |
| Total Qualcomm stockholders’ equity | 31,421 |  |  | 39,169 |  |
| Noncontrolling interests | (7 | ) |  | (3 | ) |
| Total stockholders’ equity | 31,414 |  |  | 39,166 |  |
| Total liabilities and stockholders’ equity | $ | 50,796 |  |  | $ | 48,574 |  |

[0001234452-15-000269:8k_2_02:112]
Qualcomm Incorporated

[0001234452-15-000269:8k_2_02:113]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-15-000269:8k_2_02:114]
(In millions, except per share data)

[0001234452-15-000269:8k_2_02:115]
(Unaudited)

[0001234452-15-000269:8k_2_02:116]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 27, 2015 |  | September 28, 2014 |  | September 27, 2015 |  | September 28, 2014 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,619 |  |  | $ | 4,822 |  |  | $ | 17,079 |  |  | $ | 18,625 |  |
| Licensing | 1,837 |  |  | 1,870 |  |  | 8,202 |  |  | 7,862 |  |
| Total revenues | 5,456 |  |  | 6,692 |  |  | 25,281 |  |  | 26,487 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of equipment and services revenues | 2,252 |  |  | 2,757 |  |  | 10,378 |  |  | 10,686 |  |
| Research and development | 1,357 |  |  | 1,364 |  |  | 5,490 |  |  | 5,477 |  |
| Selling, general and administrative | 595 |  |  | 545 |  |  | 2,344 |  |  | 2,290 |  |
| Other | 112 |  |  | 34 |  |  | 1,293 |  |  | 484 |  |
| Total costs and expenses | 4,316 |  |  | 4,700 |  |  | 19,505 |  |  | 18,937 |  |
| Operating income | 1,140 |  |  | 1,992 |  |  | 5,776 |  |  | 7,550 |  |
| Interest expense | (70 | ) |  | (1 | ) |  | (104 | ) |  | (5 | ) |
| Investment income, net | 182 |  |  | 261 |  |  | 815 |  |  | 1,233 |  |
| Income from continuing operations before income taxes | 1,252 |  |  | 2,252 |  |  | 6,487 |  |  | 8,778 |  |
| Income tax expense | (192 | ) |  | (359 | ) |  | (1,219 | ) |  | (1,244 | ) |
| Income from continuing operations | 1,060 |  |  | 1,893 |  |  | 5,268 |  |  | 7,534 |  |
| Discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | 430 |  |
| Net income | 1,060 |  |  | 1,893 |  |  | 5,268 |  |  | 7,964 |  |
| Net loss attributable to noncontrolling interests | 1 |  |  | 1 |  |  | 3 |  |  | 3 |  |
| Net income attributable to Qualcomm | $ | 1,061 |  |  | $ | 1,894 |  |  | $ | 5,271 |  |  | $ | 7,967 |  |
| Basic earnings per share attributable to Qualcomm: |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.68 |  |  | $ | 1.13 |  |  | $ | 3.26 |  |  | $ | 4.48 |  |
| Discontinued operations | — |  |  | — |  |  | — |  |  | 0.25 |  |
| Net income | $ | 0.68 |  |  | $ | 1.13 |  |  | $ | 3.26 |  |  | $ | 4.73 |  |
| Diluted earnings per share attributable to Qualcomm: |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.67 |  |  | $ | 1.11 |  |  | $ | 3.22 |  |  | $ | 4.40 |  |
| Discontinued operations | — |  |  | — |  |  | — |  |  | 0.25 |  |
| Net income | $ | 0.67 |  |  | $ | 1.11 |  |  | $ | 3.22 |  |  | $ | 4.65 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,557 |  |  | 1,674 |  |  | 1,618 |  |  | 1,683 |  |
| Diluted | 1,573 |  |  | 1,701 |  |  | 1,639 |  |  | 1,714 |  |
| Dividends per share announced | $ | 0.48 |  |  | $ | 0.42 |  |  | $ | 1.80 |  |  | $ | 1.54 |  |

[0001234452-15-000269:8k_2_02:117]
Qualcomm Incorporated

[0001234452-15-000269:8k_2_02:118]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-15-000269:8k_2_02:119]
(In millions)

[0001234452-15-000269:8k_2_02:120]
(Unaudited)

[0001234452-15-000269:8k_2_02:121]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 27, 2015 |  | September 28, 2014 |  | September 27, 2015 |  | September 28, 2014 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,060 |  |  | $ | 1,894 |  |  | $ | 5,268 |  |  | $ | 7,964 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 326 |  |  | 297 |  |  | 1,214 |  |  | 1,150 |  |
| Gain on sale of discontinued operations | — |  |  | — |  |  | — |  |  | (665 | ) |
| Indefinite and long-lived asset impairment charges | 13 |  |  | — |  |  | 317 |  |  | 642 |  |
| Income tax provision (less than) in excess of income tax payments | (112 | ) |  | 54 |  |  | 47 |  |  | 298 |  |
| Non-cash portion of share-based compensation expense | 233 |  |  | 252 |  |  | 1,026 |  |  | 1,059 |  |
| Incremental tax benefits from share-based compensation | (5 | ) |  | (41 | ) |  | (103 | ) |  | (280 | ) |
| Net realized gains on marketable securities and other investments | (101 | ) |  | (141 | ) |  | (500 | ) |  | (826 | ) |
| Impairment losses on marketable securities and other investments | 39 |  |  | 9 |  |  | 200 |  |  | 180 |  |
| Other items, net | 14 |  |  | (10 | ) |  | (16 | ) |  | (17 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | 112 |  |  | (324 | ) |  | 550 |  |  | (281 | ) |
| Inventories | 215 |  |  | (271 | ) |  | 93 |  |  | (155 | ) |
| Other assets | 104 |  |  | (28 | ) |  | (793 | ) |  | 108 |  |
| Trade accounts payable | (139 | ) |  | 298 |  |  | (908 | ) |  | 619 |  |
| Payroll, benefits and other liabilities | 78 |  |  | (280 | ) |  | (328 | ) |  | (617 | ) |
| Unearned revenues | (153 | ) |  | (90 | ) |  | (561 | ) |  | (292 | ) |
| Net cash provided by operating activities | 1,684 |  |  | 1,619 |  |  | 5,506 |  |  | 8,887 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (179 | ) |  | (230 | ) |  | (994 | ) |  | (1,185 | ) |
| Purchases of available-for-sale securities | (2,282 | ) |  | (3,266 | ) |  | (15,400 | ) |  | (13,581 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 3,183 |  |  | 3,843 |  |  | 15,080 |  |  | 13,587 |  |
| Purchases of trading securities | (126 | ) |  | (207 | ) |  | (1,160 | ) |  | (3,075 | ) |
| Proceeds from sales and maturities of trading securities | 650 |  |  | 205 |  |  | 1,658 |  |  | 2,824 |  |
| Purchases of other marketable securities | — |  |  | — |  |  | — |  |  | (220 | ) |
| Proceeds from sale of discontinued operations, net of cash sold | — |  |  | — |  |  | — |  |  | 788 |  |
| Proceeds from sales of property, plant and equipment | 105 |  |  | — |  |  | 266 |  |  | 37 |  |
| Acquisitions and other investments, net of cash acquired | (2,689 | ) |  | (436 | ) |  | (2,997 | ) |  | (883 | ) |
| Other items, net | (14 | ) |  | 4 |  |  | (25 | ) |  | 69 |  |
| Net cash used by investing activities | (1,352 | ) |  | (87 | ) |  | (3,572 | ) |  | (1,639 | ) |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 1,270 |  |  | — |  |  | 4,083 |  |  | — |  |
| Proceeds from long-term debt | — |  |  | — |  |  | 9,937 |  |  | — |  |
| Repayment of short-term debt | (1,269 | ) |  | — |  |  | (3,083 | ) |  | — |  |
| Proceeds from issuance of common stock | 216 |  |  | 292 |  |  | 787 |  |  | 1,439 |  |
| Repurchases and retirements of common stock | (2,230 | ) |  | (1,195 | ) |  | (11,246 | ) |  | (4,549 | ) |
| Dividends paid | (738 | ) |  | (702 | ) |  | (2,880 | ) |  | (2,586 | ) |
| Incremental tax benefits from share-based compensation | 5 |  |  | 41 |  |  | 103 |  |  | 280 |  |
| Other items, net | (3 | ) |  | 1 |  |  | 38 |  |  | (64 | ) |
| Net cash used by financing activities | (2,749 | ) |  | (1,563 | ) |  | (2,261 | ) |  | (5,480 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (10 | ) |  | (6 | ) |  | (20 | ) |  | (3 | ) |
| Net (decrease) increase in cash and cash equivalents | (2,427 | ) |  | (37 | ) |  | (347 | ) |  | 1,765 |  |
| Cash and cash equivalents at beginning of period | 9,987 |  |  | 7,944 |  |  | 7,907 |  |  | 6,142 |  |
| Cash and cash equivalents at end of period | $ | 7,560 |  |  | $ | 7,907 |  |  | $ | 7,560 |  |  | $ | 7,907 |  |
