# QCOM 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 1 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001234452-15-000271:item_9a:1]
Item 9A. Controls and Procedures

[0001234452-15-000271:item_9a:2]
Conclusion Regarding the Effectiveness of Disclosure Controls and Procedures

[0001234452-15-000271:item_9a:3]
Under the supervision and with the participation of our management, including our principal executive officer and principal financial officer, we conducted an evaluation of our disclosure controls and procedures, as such terms are defined under Rule 13a-15(e) promulgated under the Securities Exchange Act of 1934, as amended (the Exchange Act). Based on this evaluation, our principal executive officer and our principal financial officer concluded that our disclosure controls and procedures were effective as of the end of the period covered by this Annual Report.

[0001234452-15-000271:item_9a:4]
Management’s Report on Internal Control over Financial Reporting

[0001234452-15-000271:item_9a:5]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). Under the supervision and with the participation of our management,

[0001234452-15-000271:item_9a:6]
46

[0001234452-15-000271:item_9a:7]
including our principal executive officer and principal financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting based on the framework in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on our evaluation under this framework, our management concluded that our internal control over financial reporting was effective as of September 27, 2015.

[0001234452-15-000271:item_9a:8]
PricewaterhouseCoopers LLP, the independent registered public accounting firm that audited the consolidated financial statements included in this Annual Report, has also audited the effectiveness of our internal control over financial reporting as of September 27, 2015, as stated in its report which appears on page F-1.

[0001234452-15-000271:item_9a:9]
Inherent Limitations over Internal Controls

[0001234452-15-000271:item_9a:10]
Our internal control over financial reporting is designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of consolidated financial statements for external purposes in accordance with generally accepted accounting principles. Our internal control over financial reporting includes those policies and procedures that:

[0001234452-15-000271:item_9a:11]
| i. | pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of our assets; |

[0001234452-15-000271:item_9a:12]
| ii. | provide reasonable assurance that transactions are recorded as necessary to permit preparation of consolidated financial statements in accordance with generally accepted accounting principles, and that our receipts and expenditures are being made only in accordance with authorizations of our management and directors; and |

[0001234452-15-000271:item_9a:13]
| iii. | provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on the consolidated financial statements. |

[0001234452-15-000271:item_9a:14]
Internal control over financial reporting cannot provide absolute assurance of achieving financial reporting objectives because of its inherent limitations, including the possibility of human error and circumvention by collusion or overriding of controls. Accordingly, even an effective internal control system may not prevent or detect material misstatements on a timely basis. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions or that the degree of compliance with the policies or procedures may deteriorate.

[0001234452-15-000271:item_9a:15]
Changes in Internal Control over Financial Reporting

[0001234452-15-000271:item_9a:16]
There were no changes in our internal control over financial reporting during the fourth quarter of fiscal 2015 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
