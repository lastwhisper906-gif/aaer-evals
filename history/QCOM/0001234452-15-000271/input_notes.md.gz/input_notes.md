# QCOM notes — 0001234452-15-000271


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001234452-15-000271:notes:1]
Note 2. Composition of Certain Financial Statement Items

[0001234452-15-000271:notes:2]
| Accounts Receivable (in millions) |  |  |  |
|  | September 27, 2015 |  | September 28, 2014 |
| Trade, net of allowances for doubtful accounts of $6 and $5, respectively | $ | 1,941 |  |  | $ | 2,362 |  |
| Long-term contracts | 11 |  |  | 17 |  |
| Other | 12 |  |  | 33 |  |
|  | $ | 1,964 |  |  | $ | 2,412 |  |

[0001234452-15-000271:notes:3]
| Inventories (in millions) |  |  |  |
|  | September 27, 2015 |  | September 28, 2014 |
| Raw materials | $ | 1 |  |  | $ | 1 |  |
| Work-in-process | 550 |  |  | 656 |  |
| Finished goods | 941 |  |  | 801 |  |
|  | $ | 1,492 |  |  | $ | 1,458 |  |

[0001234452-15-000271:notes:4]
| Property, Plant and Equipment (in millions) | September 27, 2015 |  | September 28, 2014 |
| Land | $ | 212 |  |  | $ | 225 |  |
| Buildings and improvements | 1,544 |  |  | 1,456 |  |
| Computer equipment and software | 1,422 |  |  | 1,349 |  |
| Machinery and equipment | 2,287 |  |  | 2,117 |  |
| Furniture and office equipment | 83 |  |  | 85 |  |
| Leasehold improvements | 274 |  |  | 247 |  |
| Construction in progress | 72 |  |  | 201 |  |
|  | 5,894 |  |  | 5,680 |  |
| Less accumulated depreciation and amortization | (3,360 | ) |  | (3,193 | ) |
|  | $ | 2,534 |  |  | $ | 2,487 |  |

[0001234452-15-000271:notes:5]
Depreciation and amortization expense related to property, plant and equipment for fiscal 2015, 2014 and 2013 was $625 million, $609 million and $515 million, respectively. The gross book values of property under capital leases included in buildings and improvements were negligible at September 27, 2015 and September 28, 2014, respectively.

[0001234452-15-000271:notes:6]
Goodwill and Other Intangible Assets. The Company allocates goodwill to its reporting units for annual impairment testing purposes. The following table presents the goodwill allocated to the Company’s reportable and nonreportable segments, as described in Note 8, as well as the changes in the carrying amounts of goodwill during fiscal 2015 and 2014 (in millions):

[0001234452-15-000271:notes:7]
|  | QCT |  | QTL |  | Nonreportable Segments |  | Total |
| Balance at September 29, 2013 | $ | 2,875 |  |  | $ | 706 |  |  | $ | 395 |  |  | $ | 3,976 |  |
| Acquisitions | 592 |  |  | 6 |  |  | 30 |  |  | 628 |  |
| Impairments | — |  |  | — |  |  | (116 | ) |  | (116 | ) |
| Balance at September 28, 2014 (1) | 3,467 |  |  | 712 |  |  | 309 |  |  | 4,488 |  |
| Acquisitions | 998 |  |  | 6 |  |  | 254 |  |  | 1,258 |  |
| Impairments | — |  |  | — |  |  | (260 | ) |  | (260 | ) |
| Other (2) | (4 | ) |  | — |  |  | (3 | ) |  | (7 | ) |
| Balance at September 27, 2015 (1) | $ | 4,461 |  |  | $ | 718 |  |  | $ | 300 |  |  | $ | 5,479 |  |

[0001234452-15-000271:notes:8]
| (1) | Cumulative goodwill impairments were $520 million and $260 million at September 27, 2015 and September 28, 2014, respectively. |

[0001234452-15-000271:notes:9]
| (2) | Includes changes in goodwill amounts resulting from foreign currency translation and purchase accounting adjustments. |

[0001234452-15-000271:notes:10]
The components of other intangible assets, net were as follows (in millions):

[0001234452-15-000271:notes:11]
|  | September 27, 2015 |  | September 28, 2014 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |
| Wireless spectrum | $ | 2 |  |  | $ | (2 | ) |  | 5 |  | $ | 18 |  |  | $ | (9 | ) |  | 14 |
| Marketing-related | 93 |  |  | (59 | ) |  | 8 |  | 78 |  |  | (47 | ) |  | 9 |
| Technology-based | 5,735 |  |  | (2,078 | ) |  | 10 |  | 4,460 |  |  | (1,956 | ) |  | 11 |
| Customer-related | 111 |  |  | (60 | ) |  | 4 |  | 85 |  |  | (49 | ) |  | 6 |
|  | $ | 5,941 |  |  | $ | (2,199 | ) |  | 10 |  | $ | 4,641 |  |  | $ | (2,061 | ) |  | 11 |

[0001234452-15-000271:notes:12]
All of these intangible assets are subject to amortization, other than acquired in-process research and development with carrying values of $196 million and $55 million at September 27, 2015 and September 28, 2014, respectively. Amortization expense related to these intangible assets was $591 million, $543 million and $499 million for fiscal 2015, 2014 and 2013, respectively. Amortization expense related to these intangible assets and acquired in-process research and development, beginning upon the expected completion of the underlying projects, is expected to be $727 million, $593 million, $550 million, $515 million and $445 million for each of the subsequent five years from fiscal 2016 through 2020, respectively, and $912 million thereafter.

[0001234452-15-000271:notes:13]
| Other Current Liabilities (in millions) |  |  |  |
|  | September 27, 2015 |  | September 28, 2014 |
| Customer incentives and other customer-related liabilities | $ | 1,894 |  |  | $ | 1,777 |  |
| Other | 462 |  |  | 466 |  |
|  | $ | 2,356 |  |  | $ | 2,243 |  |

[0001234452-15-000271:notes:14]
Other Comprehensive Income. Other comprehensive income is defined as the change in equity of a business enterprise during a period from transactions and other events and circumstances from non-owner sources, other than net income and including foreign currency translation adjustments and unrealized gains and losses on marketable securities and derivative instruments. Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity during fiscal year ended September 27, 2015 were as follows (in millions):

[0001234452-15-000271:notes:15]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Total Accumulated Other Comprehensive Income |
| Balance at September 28, 2014 | $ | (113 | ) |  | $ | 24 |  |  | $ | 723 |  |  | $ | — |  |  | $ | 634 |  |
| Other comprehensive (loss) income before reclassifications | (47 | ) |  | (19 | ) |  | (215 | ) |  | 54 |  |  | (227 | ) |
| Reclassifications from accumulated other comprehensive (loss) income | — |  |  | (1 | ) |  | (211 | ) |  | — |  |  | (212 | ) |
| Other comprehensive (loss) income | (47 | ) |  | (20 | ) |  | (426 | ) |  | 54 |  |  | (439 | ) |
| Balance at September 27, 2015 | $ | (160 | ) |  | $ | 4 |  |  | $ | 297 |  |  | $ | 54 |  |  | $ | 195 |  |

[0001234452-15-000271:notes:16]
In the third quarter of fiscal 2015, the Company entered into U.S. Treasury rate locks in anticipation of its debt offering (Note 6), which were designated as cash flow hedges. This resulted in the deferral of gains of $56 million in accumulated other comprehensive income, which is recognized ratably over the 10- and 30-year lives of the underlying notes associated with the U.S. Treasury rate locks. Reclassifications from accumulated other comprehensive income related to available-for-sale securities and foreign currency translation adjustments of $212 million and $360 million for fiscal 2015 and fiscal 2014, respectively, were recorded in investment income, net (Note 2). Reclassifications from accumulated other comprehensive income related to derivative instruments of $26 million for fiscal 2014 were recorded in revenues, cost of equipment and services revenues, research and development expenses and selling, general and administrative expenses.

[0001234452-15-000271:notes:17]
Other Costs and Expenses. On February 9, 2015, the Company announced that it had reached a resolution with the China National Development and Reform Commission (NDRC) regarding its investigation of the Company relating to China’s Anti-Monopoly Law (AML) and the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business. The NDRC issued an Administrative Sanction Decision finding that the Company had violated the AML, and the Company agreed to implement a rectification plan that modifies certain of its business practices in China. In addition, the NDRC imposed a fine on the Company of 6.088 billion Chinese Yuan renminbi (approximately $975 million), which the Company has paid. The Company recorded the amount of the fine in the second quarter of fiscal 2015 in other expenses. Other expenses in fiscal 2015 also included $255 million and $11 million in impairment charges on goodwill and intangible assets, respectively, related to the Company’s content and push-to-talk services and display businesses and $190 million in restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan (Note 10), partially offset by $138 million in gains on sales of certain property, plant and equipment.

[0001234452-15-000271:notes:18]
Other expenses in fiscal 2014 were comprised of $507 million and $100 million in certain property, plant and equipment and goodwill impairment charges, respectively, and $19 million in restructuring-related costs incurred by one of the Company’s display businesses. At September 28, 2014, the carrying values of such goodwill and property, plant and equipment were $35 million and $148 million, respectively, including $116 million in property, plant and equipment that was classified as held for sale and included in other assets. Other expenses in fiscal 2014 also included a $16 million goodwill impairment charge related to the Company’s former QRS division and a $15 million legal settlement, partially offset by the reversal of the $173 million accrual recorded in fiscal 2013 related to the ParkerVision verdict against us, which was overturned (Note 7).

[0001234452-15-000271:notes:19]
Other expenses in fiscal 2013 were comprised of the $173 million ParkerVision charge and a $158 million impairment charge related to certain property, plant and equipment of one of the Company’s display businesses.

[0001234452-15-000271:notes:20]
| Investment Income, Net (in millions) |  |  |  |  |  |
|  | 2015 |  | 2014 |  | 2013 |
| Interest and dividend income | $ | 527 |  |  | $ | 586 |  |  | $ | 697 |  |
| Net realized gains on marketable securities | 451 |  |  | 770 |  |  | 317 |  |
| Net realized gains on other investments | 49 |  |  | 56 |  |  | 52 |  |
| Impairment losses on marketable securities | (163 | ) |  | (156 | ) |  | (72 | ) |
| Impairment losses on other investments | (37 | ) |  | (24 | ) |  | (13 | ) |
| Net gains on derivative instruments | 17 |  |  | 5 |  |  | — |  |
| Equity in net losses of investees | (32 | ) |  | (10 | ) |  | (6 | ) |
| Net gains on deconsolidation of subsidiaries | 3 |  |  | 6 |  |  | 12 |  |
|  | $ | 815 |  |  | $ | 1,233 |  |  | $ | 987 |  |

[0001234452-15-000271:notes:21]
Net impairment losses on marketable securities related to the noncredit portion of losses on debt securities recognized in other comprehensive income were $23 million in fiscal 2015 and were negligible in fiscal 2014 and 2013.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001234452-15-000271:notes:22]
The following table presents the unaudited pro forma results for fiscal 2015 and 2014. The unaudited pro forma financial information combines the results of operations of Qualcomm and CSR as though the companies had been combined as of the beginning of fiscal 2014, and the pro forma information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at such time. The unaudited pro forma results presented below include amortization charges for acquired intangible assets, eliminations of intercompany transactions, adjustments for increased fair value of acquired inventory, adjustments for depreciation expense for property, plant and equipment and related tax effects (in millions):

[0001234452-15-000271:notes:23]
|  | 2015 |  | 2014 |
|  | (unaudited) |
| Revenues | $ | 25,939 |  |  | $ | 27,282 |  |
| Net income attributable to Qualcomm | 5,157 |  |  | 7,730 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001234452-15-000271:notes:24]
Note 9. Acquisitions

[0001234452-15-000271:notes:25]
On August 13, 2015, the Company acquired CSR plc, which was renamed CSR Limited (CSR), for total cash consideration of $2.3 billion (net of $176 million of cash acquired). In addition, $28 million of third-party acquisition and integration services costs were included in selling, general and administrative expenses in fiscal 2015. CSR is an innovator in the development of multifunction semiconductor platforms and technologies for the automotive, consumer and voice and music categories. The acquisition complements the Company’s current offerings by adding products, channels and customers in the growth categories of the Internet of Things and automotive infotainment. CSR was integrated into the QCT segment.

[0001234452-15-000271:notes:26]
The allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0001234452-15-000271:notes:27]
| Current assets | $ | 560 |  |
| Intangible assets subject to amortization: |  |
| Technology-based intangible assets | 953 |  |
| Customer-related intangible assets | 45 |  |
| Marketing-related intangible assets | 15 |  |
| In-process research and development (IPR&D) | 182 |  |
| Goodwill | 969 |  |
| Other assets | 131 |  |
| Total assets | 2,855 |  |
| Liabilities | (411 | ) |
| Net assets acquired | $ | 2,444 |  |

[0001234452-15-000271:notes:28]
Goodwill recognized in this transaction is not deductible for tax purposes and was allocated to the QCT segment for annual impairment testing purposes. Goodwill is primarily attributable to synergies expected to arise after the acquisition. Each category of intangible assets acquired will be amortized on a straight-line basis over their weighted-average useful lives of five years for technology-based intangible assets and four years for customer-related and marketing-related intangible assets. On the acquisition date, IPR&D consisted of three projects, primarily related to Bluetooth audio and Bluetooth low energy (also known as Bluetooth Smart) technologies, which are expected to be completed over the next nine months at a cost of $19 million as of the acquisition date. Upon completion, the IPR&D projects will be amortized over their useful lives, which are expected to range from six to seven years. The estimated fair values of the intangible assets acquired were primarily determined using the income approach based on significant inputs that were not observable.

[0001234452-15-000271:notes:29]
The Company’s results of operations for fiscal 2015 included the operating results of CSR since the date of acquisition, the amounts of which were not material. The following table presents the unaudited pro forma results for fiscal 2015 and 2014. The unaudited pro forma financial information combines the results of operations of Qualcomm and CSR as though the companies had been combined as of the beginning of fiscal 2014, and the pro forma information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at such time. The unaudited pro forma results presented below include amortization charges for acquired intangible assets, eliminations of intercompany transactions, adjustments for increased fair value of acquired inventory, adjustments for depreciation expense for property, plant and equipment and related tax effects (in millions):

[0001234452-15-000271:notes:30]
During fiscal 2015, the Company acquired four other businesses for total cash consideration of $405 million, net of cash acquired. Technology-based intangible assets recognized in the amount of $84 million are being amortized on a straight-line basis over a weighted-average useful life of eight years. The Company recognized $289 million in goodwill related to these transactions, of which $35 million is expected to be deductible for tax purposes. Goodwill of $29 million, $6 million and $254 million was assigned to the Company’s QCT, QTL and nonreportable segments, respectively.

[0001234452-15-000271:notes:31]
During fiscal 2014, the Company acquired 11 businesses for total cash consideration of $761 million, net of cash acquired, and the exchange of unvested stock options that had a negligible fair value. Technology-based intangible assets recognized in the amount of $146 million are being amortized on a straight-line basis over a weighted-average useful life of six years. Goodwill of $624 million was recognized in these transactions, of which $294 million is expected to be deductible for tax purposes. Goodwill of $589 million, $6 million and $29 million was assigned to the Company’s QCT, QTL and nonreportable segments, respectively.

[0001234452-15-000271:notes:32]
During fiscal 2013, the Company acquired five businesses for total cash consideration of $114 million, net of cash acquired. Technology-based intangible assets recognized in the amount of $24 million are being amortized on a straight-line basis over a weighted-average useful life of six years. Goodwill of $83 million was recognized in these transactions, of which $21 million is expected to be deductible for tax purposes. Goodwill of $65 million and $18 million was assigned to the Company’s QCT and nonreportable segments, respectively.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001234452-15-000271:notes:33]
Cash Equivalents. The Company considers all highly liquid investments with original maturities of 90 days or less to be cash equivalents. Cash equivalents are comprised of money market funds, certificates of deposit, commercial paper, government agencies’ securities, certain bank time deposits and repurchase agreements fully collateralized by government agencies’ securities. The carrying amounts approximate fair value due to the short maturities of these instruments.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001234452-15-000271:notes:34]
Note 7. Commitments and Contingencies

[0001234452-15-000271:notes:35]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit heard the appeal on May 8, 2015 and issued a decision on July 31, 2015. The decision affirmed the District Court’s finding of non-infringement and granted in part the Company’s cross-appeal, holding 10 of the 11 asserted claims invalid. A subsequent Petition for Rehearing by ParkerVision was denied on October 2, 2015. On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision now alleges that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. The Company was served with the complaint in this second action on August 28, 2014 and answered on November 17, 2014. A claim construction hearing was held on August 12, 2015, and no ruling has issued yet. The close of discovery is scheduled for March 2016, and the trial is scheduled for August 2016.

[0001234452-15-000271:notes:36]
Nvidia Corporation v. QUALCOMM Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd., and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chipset products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District of Delaware complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. On April 2, 2015, the Administrative Law Judge in the ITC investigation issued a claim construction order construing seven claim terms from five of the seven asserted patents. The evidentiary hearing for the investigation was held from June 22 to 25, 2015. Nvidia narrowed the case to three asserted patents. On October 9, 2015, the Administrative Law Judge issued an Initial Determination finding no violation of Section 337 because none of the three patents were both valid and infringed. On October 22, 2015, the Administrative Law Judge issued a recommendation that, if the ITC were to find any violation of Section 337 in the investigation, the ITC should issue a limited exclusion order directed at Samsung’s accused products and a cease and desist order against Samsung but not the Company. On October 26, 2015, Nvidia filed a petition requesting the ITC to review the Initial Determination as to two of the asserted patents, but is no longer pursuing infringement allegations with respect to the third patent. The target date for completion of the ITC investigation is scheduled for February 10, 2016. The district court case was stayed on October 23, 2014 pending completion of the ITC investigation, including appeals.

[0001234452-15-000271:notes:37]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 30 different dates, with the next hearing scheduled for December 16, 2015.

[0001234452-15-000271:notes:38]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments during fiscal 2015 with respect to this matter.

[0001234452-15-000271:notes:39]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it is conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). The Company understands that this investigation concerns primarily its licensing business. If a violation of the MRFTA is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine or requiring modifications to the Company’s licensing practices. Given that this investigation is in its early stages, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. The Company continues to cooperate with the KFTC as it conducts its investigation.

[0001234452-15-000271:notes:40]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. The Commission is investigating “alleged practices in the form of predatory pricing on certain UMTS standard-compliant chipsets used to deliver cellular mobile broadband access.” The initiation of proceedings merely means that the Commission will deal with the case as a matter of priority. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that none of the business practices under investigation are in breach of the EU competition rules and will continue to cooperate with the Commission.

[0001234452-15-000271:notes:41]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. The Commission is investigating “alleged payments, rebates and/or other consideration granted by Qualcomm Incorporated or any of its affiliates and/or subsidiaries (Qualcomm) to smartphone and/or tablet manufacturers which are conditional upon the exclusive or quasi-exclusive use or purchase of Qualcomm products, in particular baseband chipsets, by the respective manufacturer(s).” The initiation of proceedings merely means that the Commission will deal with the case as a matter of priority. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that none of the business practices under investigation are in breach of the EU competition rules and will continue to cooperate with the Commission.

[0001234452-15-000271:notes:42]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). As discussed below, FCPA compliance is also the focus of the SEC investigation. The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee has completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.

[0001234452-15-000271:notes:43]
As previously disclosed, the Company discovered, and as a part of its cooperation with these investigations informed the SEC and the DOJ of, instances in which special hiring consideration, gifts or other benefits (collectively, benefits) were provided to several individuals associated with Chinese state-owned companies or agencies. Based on the facts currently known, the Company believes the aggregate monetary value of the benefits in question to be less than $250,000, excluding employment compensation.

[0001234452-15-000271:notes:44]
On March 13, 2014, the Company received a Wells Notice from the SEC’s Los Angeles Regional Office indicating that the staff has made a preliminary determination to recommend that the SEC file an enforcement action against the Company for violations of the anti-bribery, books and records and internal control provisions of the FCPA. The bribery allegations relate to benefits offered or provided to individuals associated with Chinese state-owned companies or agencies. The Wells Notice indicated that the recommendation could involve a civil injunctive action and could seek remedies that include disgorgement of profits, the retention of an independent compliance monitor to review the Company’s FCPA policies and procedures, an injunction, civil monetary penalties and prejudgment interest.

[0001234452-15-000271:notes:45]
A Wells Notice is not a formal allegation or finding by the SEC of wrongdoing or violation of law. Rather, the purpose of a Wells Notice is to give the recipient an opportunity to make a “Wells submission” setting forth reasons why the proposed enforcement action should not be filed and/or bringing additional facts to the SEC’s attention before any decision is made by the SEC as to whether to commence a proceeding. On April 4, 2014 and May 29, 2014, the Company made Wells submissions to the staff of the Los Angeles Regional Office explaining why the Company believes it has not violated the FCPA and therefore enforcement action is not warranted.

[0001234452-15-000271:notes:46]
The Company is continuing to cooperate with the SEC and the DOJ, but is unable to predict the outcome of their investigations or any actions that the SEC or DOJ may decide to file.

[0001234452-15-000271:notes:47]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act. The FTC has notified the Company that it is investigating conduct related to standard essential patents and pricing and contracting practices with respect to baseband processors and related products. If a violation of Section 5 is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company continues to cooperate with the FTC as it conducts its investigation.

[0001234452-15-000271:notes:48]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at September 27, 2015 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001234452-15-000271:notes:49]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through September 27, 2015, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

[0001234452-15-000271:notes:50]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at September 27, 2015 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001234452-15-000271:notes:51]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at September 27, 2015 for each of the subsequent five years from fiscal 2016 through 2020 were $3.0 billion, $953 million, $742 million, $697 million and $183 million, respectively, and $9 million thereafter. Of these amounts, for each of the subsequent five years from fiscal 2016 through 2020, commitments to purchase integrated circuit product inventories comprised $2.5 billion, $787 million, $706 million, $680 million and $166 million, respectively, and there were no purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

[0001234452-15-000271:notes:52]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Rental expense for fiscal 2015, 2014 and 2013 was $99 million, $91 million and $90 million, respectively. Future minimum lease payments at September 27, 2015 for each of the subsequent five years from fiscal 2016 through 2020 were $99 million, $73 million, $41 million, $27 million and $17 million, respectively, and $24 million thereafter.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001234452-15-000271:notes:53]
Note 5. Employee Benefit Plans

[0001234452-15-000271:notes:54]
Employee Savings and Retirement Plan. The Company has a 401(k) plan that allows eligible employees to contribute up to 85% of their eligible compensation, subject to annual limits. The Company matches a portion of the employee contributions and may, at its discretion, make additional contributions based upon earnings. The Company’s contribution expense was $81 million, $77 million and $70 million in fiscal 2015, 2014 and 2013, respectively.

[0001234452-15-000271:notes:55]
Equity Compensation Plans. The 2006 Long-Term Incentive Plan (the 2006 Plan) was adopted during the second quarter of fiscal 2006 and replaced the 2001 Stock Option Plan and the 2001 Non-Employee Directors’ Stock Option Plan and their predecessor plans (the Prior Plans). The 2006 Plan provides for the grant of incentive and non-qualified stock options, restricted stock units, stock appreciation rights, restricted stock, performance stock units and other share-based awards and is the source of shares issued under the Non-Qualified Deferred Compensation Plan (the NQDCP). The shares authorized under the 2006 Plan were approximately 573,284,000 at September 27, 2015. The share reserve remaining under the 2006 Plan was approximately 199,772,000 at September 27, 2015. Shares subject to any stock option under the Prior Plans that is terminated or canceled (but not a stock option under the Prior Plans that expires) following the date that the 2006 Plan was approved by stockholders, and shares that are subject to an award under the NQDCP and are returned to the Company because they fail to vest, will again become available for grant under the 2006 Plan. The Board of Directors of the Company may amend or terminate the 2006 Plan at any time. Certain amendments, including an increase in the share reserve, require stockholder approval.

[0001234452-15-000271:notes:56]
RSUs are share awards that entitle the holder to receive shares of the Company’s common stock upon vesting. The RSUs generally include dividend-equivalent rights and vest over periods of three years from the date of grant. A summary of RSU transactions for all equity compensation plans follows:

[0001234452-15-000271:notes:57]
|  | Number of Shares |  | Weighted-AverageGrant Date FairValue |  | Aggregate IntrinsicValue |
|  | (In thousands) |  |  |  | (In billions) |
| RSUs outstanding at September 28, 2014 | 28,550 |  |  | $ | 67.36 |  |  |  |
| RSUs granted | 15,425 |  |  | 68.77 |  |  |  |
| RSUs canceled/forfeited | (2,329 | ) |  | 69.42 |  |  |  |
| RSUs vested | (13,899 | ) |  | 64.63 |  |  |  |
| RSUs outstanding at September 27, 2015 | 27,747 |  |  | $ | 69.35 |  |  | $ | 1.5 |  |

[0001234452-15-000271:notes:58]
At September 27, 2015, total unrecognized compensation expense related to non-vested RSUs granted prior to that date was $1.3 billion, which is expected to be recognized over a weighted-average period of 1.8 years. The total vest-date fair value of RSUs that vested during fiscal 2015, 2014 and 2013 was $1.0 billion, $1.1 billion and $1.0 billion, respectively. Upon vesting, the Company issues new shares of common stock. For the majority of RSUs, shares are issued on the vesting dates net of the amount of shares needed to satisfy statutory tax withholding requirements to be paid by the Company on behalf of the employees. The total shares withheld related to all share-based awards were approximately 5,043,000, 5,568,000 and 5,805,000 in fiscal 2015, 2014 and 2013, respectively, and were based on the value of the awards on their vesting dates as determined by the Company’s closing stock price. Total payments for the employees’ tax obligations to the taxing authorities were $351 million, $417 million and $374 million in fiscal 2015, 2014 and 2013, respectively.

[0001234452-15-000271:notes:59]
The Board of Directors may grant stock options to selected employees, directors and consultants to the Company to purchase shares of the Company’s common stock at an exercise price not less than the fair market value of the stock at the date of grant. Stock options vest over periods not exceeding five years and are exercisable for up to ten years from the grant date. A summary of stock option transactions for all equity compensation plans follows:

[0001234452-15-000271:notes:60]
|  | Number of Shares |  | Weighted- AverageExercisePrice |  | Average RemainingContractual Term |  | Aggregate IntrinsicValue |
|  | (In thousands) |  |  |  | (Years) |  | (In millions) |
| Stock options outstanding at September 28, 2014 | 42,113 |  |  | $ | 41.23 |  |  |  |  |  |
| Stock options canceled/forfeited/expired | (72 | ) |  | 40.82 |  |  |  |  |  |
| Stock options exercised | (12,664 | ) |  | 40.86 |  |  |  |  |  |
| Stock options outstanding at September 27, 2015 | 29,377 |  |  | $ | 41.40 |  |  | 2.6 |  | $ | 349 |  |
| Exercisable at September 27, 2015 | 29,223 |  |  | $ | 41.46 |  |  | 2.6 |  | $ | 345 |  |

[0001234452-15-000271:notes:61]
The total intrinsic value of stock options exercised during fiscal 2015, 2014 and 2013 was $371 million, $971 million and $949 million, respectively, and the amount of cash received from the exercise of stock options was $519 million, $1.2 billion and $1.3 billion, respectively. Upon option exercise, the Company issues new shares of stock. The total tax benefits realized, including the excess tax benefits, related to share-based awards was $437 million, $690 million and $659 million during fiscal 2015, 2014 and 2013, respectively.

[0001234452-15-000271:notes:62]
Employee Stock Purchase Plan. The Company has an employee stock purchase plan for eligible employees to purchase shares of common stock at 85% of the lower of the fair market value on the first or the last day of each offering period, which is generally six months. Employees may authorize the Company to withhold up to 15% of their compensation during any offering period, subject to certain limitations. The employee stock purchase plan includes a non-423(b) plan. The shares authorized under the employee stock purchase plan were approximately 71,709,000 at September 27, 2015. The shares reserved for future issuance were approximately 26,361,000 at September 27, 2015. During fiscal 2015, 2014 and 2013, approximately 4,977,000, 4,376,000 and 4,044,000 shares, respectively, were issued under the plan at an average price of $53.92, $58.81 and $52.70 per share, respectively. At September 27, 2015, total unrecognized compensation expense related to non-vested purchase rights granted prior to that date was $23 million. The Company recorded cash received from the exercise of purchase rights of $268 million, $257 million and $213 million during fiscal 2015, 2014 and 2013, respectively.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001234452-15-000271:notes:63]
Concentrations. A significant portion of the Company’s revenues is concentrated with a small number of customers/licensees of the Company’s QCT and QTL segments. Revenues related to the products of two companies comprised 20% and 25% of total consolidated revenues in fiscal 2015, compared to 28% and 21% in fiscal 2014 and 24% and 19% in fiscal 2013, respectively. Aggregate accounts receivable from three customers/licensees comprised 36% and 53% of gross accounts receivable at September 27, 2015 and September 28, 2014, respectively.

[0001234452-15-000271:notes:64]
The Company relies on sole- or limited-source suppliers for some products, particularly products in the QCT segment, subjecting the Company to possible shortages of raw materials or manufacturing capacity. While the Company has established alternate suppliers for certain technologies that the Company considers critical, the loss of a supplier or the inability of a supplier to meet performance or quality specifications or delivery schedules could harm the Company’s ability to meet its delivery obligations and/or negatively impact the Company’s revenues, business operations and ability to compete for future business.


## us-gaap:ConsolidationPolicyTextBlock

[0001234452-15-000271:notes:65]
Principles of Consolidation. The Company’s consolidated financial statements include the assets, liabilities and operating results of majority-owned subsidiaries. In addition, the Company consolidates its investment in an immaterial less than majority-owned variable interest entity as the Company is the primary beneficiary. The ownership of the other interest holders of consolidated subsidiaries and the variable interest entity is presented separately in the consolidated balance sheets and statements of operations. All significant intercompany accounts and transactions have been eliminated.


## us-gaap:DebtDisclosureTextBlock

[0001234452-15-000271:notes:66]
Note 6. Debt

[0001234452-15-000271:notes:67]
Revolving Credit Facility. In February 2015, the Company entered into a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. Proceeds from the Revolving Credit Facility will be used for general corporate purposes. Loans under the Revolving Credit Facility bear interest, at the option of the Company, at either LIBOR (determined in accordance with the Revolving Credit Facility) plus a margin of 0.7% per annum or the Base Rate (determined in accordance with the Revolving Credit Facility), plus an initial margin of 0% per annum. The Revolving Credit Facility has a facility fee, which accrues at a rate of 0.05% per annum. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At September 27, 2015, the Company was in compliance with the covenants, and the Company had not borrowed any funds under the Revolving Credit Facility.

[0001234452-15-000271:notes:68]
Commercial Paper Program. In March 2015, the Company began an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At September 27, 2015, the Company had $1.0 billion of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 0.19%, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 38 days. The carrying value of the outstanding commercial paper approximated its estimated fair value at September 27, 2015.

[0001234452-15-000271:notes:69]
Long-term Debt. In May 2015, the Company issued an aggregate principal amount of $10.0 billion of unsecured floating- and fixed-rate notes (the notes) with varying maturities. The proceeds from the notes of $9.9 billion, net of underwriting discounts and offering expenses, were used to fund the ASR Agreements (Note 4) and are also being used for other general corporate purposes. The following table provides a summary of the Company’s long-term debt as of September 27, 2015 (dollar amounts in millions):

[0001234452-15-000271:notes:70]
|  | PrincipalAmount |  | EffectiveInterest Rate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 32 |  |  |  |
| Total long-term debt | $ | 9,969 |  |  |  |

[0001234452-15-000271:notes:71]
The interest rate on the floating rate notes due in 2018 and the floating rate notes due in 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At September 27, 2015, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $9.6 billion.

[0001234452-15-000271:notes:72]
The Company has entered, and may in the future enter, into interest rate swaps to manage interest rate risk on certain notes. Such swaps allow the Company to effectively convert fixed-rate payments into floating-rate payments. These transactions are designated as fair value hedges, and the gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. In the third quarter of fiscal 2015, the Company entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings as interest expense in the current period.

[0001234452-15-000271:notes:73]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs and, if applicable, adjustments related to hedging. The Company recognized $97 million of interest expense on its long-term debt during fiscal 2015. The Company did not have any long-term debt outstanding in fiscal 2014.

[0001234452-15-000271:notes:74]
No principal payments are due on the Company’s notes prior to fiscal 2018. At September 27, 2015, future principal payments were $1.5 billion in fiscal 2018, $2.0 billion in fiscal 2020 and $6.5 billion after fiscal 2020; no principal payments were due in fiscal 2019. Cash interest paid related to the Company’s commercial paper program and long-term debt was $8 million during fiscal 2015. There were no such amounts paid in fiscal 2014.


## us-gaap:DerivativesPolicyTextBlock

[0001234452-15-000271:notes:75]
Stock Repurchase Program: In connection with the Company’s stock repurchase program, the Company may sell put options that require it to repurchase shares of its common stock at fixed prices. These put options subject the Company to equity price risk. Changes in the fair value of these put options are recorded in net investment income as gains and losses on derivative instruments. The cash flows associated with the put options are classified as cash flows from investing activities in the consolidated statements of cash flows. There were no put options outstanding during fiscal 2015 and 2014.

[0001234452-15-000271:notes:76]
Derivatives. The Company’s primary objectives for holding derivative instruments are to manage interest rate risk on its long-term debt and to manage foreign exchange risk for certain foreign currency revenue and operating expenditure transactions. To a lesser extent, the Company also holds derivative instruments in its investment portfolios to manage risk by acquiring or reducing foreign exchange risk, interest rate risk and/or equity, prepayment and credit risk. Additionally, the Company may use derivative instruments as part of its stock repurchase program. Derivative instruments are recorded at fair value and included in other current assets, noncurrent assets, other accrued liabilities or other noncurrent liabilities based on their maturity dates. Counterparties to the Company’s derivative instruments are all major banking institutions.

[0001234452-15-000271:notes:77]
Interest Rate Swaps: The Company manages its exposure to certain interest rate risks related to its long-term debt through the use of interest rate swaps. Such swaps allow the Company to effectively convert fixed-rate payments into floating-rate payments based on LIBOR. These transactions are designated as fair value hedges, and the gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate debt attributable to the hedged risks, are recognized in earnings as interest expense in the current period. The interest settlement payments associated with the interest rate swap agreements are classified as cash flows from operating activities in the consolidated statements of cash flows.

[0001234452-15-000271:notes:78]
At September 27, 2015, the aggregate fair value of the Company’s interest rate swaps related to its long-term debt of $32 million was recorded in total assets. The swaps had an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate debt due in 2018 and approximately 43% and 50% of the fixed-rate debt due in 2020 and 2022, respectively, into floating-rate debt. The maturities of the swaps match the Company’s fixed-rate debt due in 2018, 2020 and 2022. There were no such interest rate swaps outstanding at September 28, 2014.

[0001234452-15-000271:notes:79]
Foreign Currency Hedges: The Company manages its exposure to foreign exchange market risks, when deemed appropriate, through the use of derivative instruments, including foreign currency forward and option contracts with financial counterparties. These derivative instruments mature between one and nine months. Gains and losses arising from the effective portion of such contracts that are designated as cash flow hedging instruments are recorded as a component of accumulated other comprehensive income as gains and losses on derivative instruments, net of income taxes. The hedging gains and losses in accumulated other comprehensive income are subsequently reclassified to revenues or costs and expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect the Company’s earnings. Gains and losses arising from the ineffective portion of such contracts are recorded in net investment income as gains and losses on derivative instruments. The cash flows associated with derivative instruments designated as cash flow or net investment hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The cash flows associated with the ineffective portion of such derivative instruments are classified as cash flows from investing activities in the consolidated statements of cash flows.

[0001234452-15-000271:notes:80]
The aggregate fair value of the Company’s foreign currency option and forward contracts used to hedge foreign currency risk recorded in total assets and in total liabilities was negligible at September 27, 2015 and September 28, 2014. All such instruments were designated as cash flow hedges.

[0001234452-15-000271:notes:81]
Investment Portfolio Derivatives: The Company also utilizes currency forwards, futures, options and swaps that are not designated as hedging instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks in its marketable securities investment portfolios. The Company primarily uses such derivative instruments for risk management and not speculative purposes. These derivative instruments mature over various periods up to one year. Gains and losses arising from changes in the fair values of such derivative instruments are recorded in net investment income as gains and losses on derivative instruments. The cash flows associated with such derivative instruments are classified as cash flows from investing activities in the consolidated statements of cash flows. At September 27, 2015 and September 28, 2014, the fair values of these derivative instruments recorded in total assets and in total liabilities were negligible.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0001234452-15-000271:notes:82]
A summary of RSU transactions for all equity compensation plans follows:

[0001234452-15-000271:notes:83]
A summary of stock option transactions for all equity compensation plans follows:


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001234452-15-000271:notes:84]
Note 11. Discontinued Operations

[0001234452-15-000271:notes:85]
On November 25, 2013, the Company completed its sale of the North and Latin America operations of its Omnitracs division to a U.S.-based private equity firm for cash consideration of $788 million (net of cash sold). As a result, the Company recorded a gain in discontinued operations of $665 million ($430 million net of income tax expense) during fiscal 2014. The revenues and operating results of the North and Latin America operations of the Omnitracs division, which comprised substantially all of the Omnitracs division, were not presented as discontinued operations in any fiscal period because they were immaterial.


## us-gaap:DividendsDeclaredTableTextBlock

[0001234452-15-000271:notes:86]
Dividends charged to retained earnings in fiscal 2015, 2014 and 2013 were as follows (in millions, except per share data):

[0001234452-15-000271:notes:87]
|  | 2015 |  | 2014 |  | 2013 |
|  | Per Share |  | Total |  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.42 |  |  | $ | 710 |  |  | $ | 0.35 |  |  | $ | 599 |  |  | $ | 0.25 |  |  | $ | 435 |  |
| Second quarter | 0.42 |  |  | 702 |  |  | 0.35 |  |  | 599 |  |  | 0.25 |  |  | 439 |  |
| Third quarter | 0.48 |  |  | 771 |  |  | 0.42 |  |  | 718 |  |  | 0.35 |  |  | 615 |  |
| Fourth quarter | 0.48 |  |  | 749 |  |  | 0.42 |  |  | 713 |  |  | 0.35 |  |  | 604 |  |
|  | $ | 1.80 |  |  | $ | 2,932 |  |  | $ | 1.54 |  |  | $ | 2,629 |  |  | $ | 1.20 |  |  | $ | 2,093 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001234452-15-000271:notes:88]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for fiscal 2015, 2014 and 2013 were 20,724,000, 30,655,000 and 38,670,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 4,652,000 during fiscal 2015, which were primarily attributable to the ASR Agreements (Note 4), and 846,000 and 507,000 during fiscal 2014 and 2013, respectively


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001234452-15-000271:notes:89]
The following table includes the activity for mortgage- and asset-backed and auction rate securities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-15-000271:notes:90]
|  | 2015 |  | 2014 |
| Beginning balance of Level 3 | $ | 269 |  |  | $ | 322 |  |
| Total realized and unrealized gains or losses: |  |  |  |
| Included in investment income, net | 3 |  |  | 11 |  |
| Included in other comprehensive income (loss) | (4 | ) |  | (3 | ) |
| Purchases | 69 |  |  | 107 |  |
| Sales | (46 | ) |  | (126 | ) |
| Settlements | (64 | ) |  | (40 | ) |
| Transfers out of Level 3 | (3 | ) |  | (2 | ) |
| Ending balance of Level 3 | $ | 224 |  |  | $ | 269 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001234452-15-000271:notes:91]
Note 12. Fair Value Measurements

[0001234452-15-000271:notes:92]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at September 27, 2015 (in millions):

[0001234452-15-000271:notes:93]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 2,043 |  |  | $ | 5,055 |  |  | $ | — |  |  | $ | 7,098 |  |
| Marketable securities |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 41 |  |  | 818 |  |  | — |  |  | 859 |  |
| Corporate bonds and notes | — |  |  | 15,402 |  |  | — |  |  | 15,402 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 1,583 |  |  | 224 |  |  | 1,807 |  |
| Equity and preferred securities and equity funds | 1,168 |  |  | 462 |  |  | — |  |  | 1,630 |  |
| Debt funds | — |  |  | 3,689 |  |  | — |  |  | 3,689 |  |
| Total marketable securities | 1,209 |  |  | 21,954 |  |  | 224 |  |  | 23,387 |  |
| Derivative instruments | 1 |  |  | 39 |  |  | — |  |  | 40 |  |
| Other investments | 290 |  |  | — |  |  | — |  |  | 290 |  |
| Total assets measured at fair value | $ | 3,543 |  |  | $ | 27,048 |  |  | $ | 224 |  |  | $ | 30,815 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 6 |  |  | $ | — |  |  | $ | 6 |  |
| Other liabilities | 289 |  |  | — |  |  | — |  |  | 289 |  |
| Total liabilities measured at fair value | $ | 289 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 295 |  |

[0001234452-15-000271:notes:94]
Activity between Levels of the Fair Value Hierarchy. There were no significant transfers between Level 1 and Level 2 during fiscal 2015 and 2014. When a determination is made to classify an asset or liability within Level 3, the determination is based upon the significance of the unobservable inputs to the overall fair value measurement. The following table includes the activity for mortgage- and asset-backed and auction rate securities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-15-000271:notes:95]
The Company recognizes transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. Transfers out of Level 3 during fiscal 2015 and 2014 primarily consisted of debt securities with significant upgrades in credit ratings. There were no transfers into Level 3 during fiscal 2015 and 2014.

[0001234452-15-000271:notes:96]
Nonrecurring Fair Value Measurements. The Company measures certain assets at fair value on a nonrecurring basis. These assets include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During fiscal 2015, 2014 and 2013, the Company updated the business plans and related internal forecasts related to certain of the Company’s businesses, resulting in impairment charges to write down certain property, plant and equipment, intangible assets and goodwill (Note 2). The Company determined the fair values using cost, income and market approaches. The estimation of fair value and cash flows used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During fiscal 2015, 2014 and 2013, the Company did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001234452-15-000271:notes:97]
Fair Value Measurements. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants as of the measurement date. Applicable accounting guidance provides an established hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Observable inputs are inputs that market participants would use in valuing the asset or liability and are developed based on market data obtained from sources independent of the Company. Unobservable inputs are inputs that reflect the Company’s assumptions about the factors that market participants would use in valuing the asset or liability. There are three levels of inputs that may be used to measure fair value:

[0001234452-15-000271:notes:98]
| • | Level 1 includes financial instruments for which quoted market prices for identical instruments are available in active markets. |

[0001234452-15-000271:notes:99]
| • | Level 2 includes financial instruments for which there are inputs other than quoted prices included within Level 1 that are observable for the instrument. |

[0001234452-15-000271:notes:100]
| • | Level 3 includes financial instruments for which fair value is derived from valuation techniques in which one or more significant inputs are unobservable, including the Company’s own assumptions. |

[0001234452-15-000271:notes:101]
Assets and liabilities are classified based on the lowest level of input that is significant to the fair value measurements. The Company reviews the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy.

[0001234452-15-000271:notes:102]
Cash Equivalents and Marketable Securities: With the exception of auction rate securities, the Company obtains pricing information from quoted market prices, pricing vendors or quotes from brokers/dealers. The Company conducts reviews of its primary pricing vendors to determine whether the inputs used in the vendor’s pricing processes are deemed to be observable. The fair value for interest-bearing securities includes accrued interest.

[0001234452-15-000271:notes:103]
The fair value of U.S. Treasury securities and government-related securities, corporate bonds and notes and common and preferred stock is generally determined using standard observable inputs, including reported trades, quoted market prices, matrix pricing, benchmark yields, broker/dealer quotes, issuer spreads, two-sided markets and/or benchmark securities.

[0001234452-15-000271:notes:104]
The fair value of debt and equity funds is reported at published net asset values. The Company assesses the daily frequency and size of transactions at published net asset values and/or the funds’ underlying holdings to determine whether fair value is based on observable or unobservable inputs.

[0001234452-15-000271:notes:105]
The fair value of highly rated mortgage- and asset-backed securities is derived from the use of matrix pricing (prices for similar securities) or, in some cases, cash flow pricing models with observable inputs, such as contractual terms, maturity, credit rating and/or securitization structure to determine the timing and amount of future cash flows. Certain mortgage- and asset-backed securities, principally those rated below AAA, may require the use of significant unobservable inputs to estimate fair value, such as default likelihood, recovery rates and prepayment speed.

[0001234452-15-000271:notes:106]
The fair value of auction rate securities is estimated by the Company using a discounted cash flow model that incorporates transaction details, such as contractual terms, maturity and timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery, the future state of the auction rate market and credit valuation adjustments of market participants. Though most of the securities held by the Company are pools of student loans guaranteed by the U.S. government, prepayment speeds and illiquidity discounts are considered significant unobservable inputs. These additional inputs are generally unobservable, and therefore, auction rate securities are included in Level 3.

[0001234452-15-000271:notes:107]
Derivative Instruments: Derivative instruments that are traded on an exchange are valued using quoted market prices and are included in Level 1. Derivative instruments that are not traded on an exchange are valued using conventional calculations/models that are primarily based on observable inputs, such as foreign currency exchange rates, the Company’s stock price, volatilities and interest rates, and therefore, such derivative instruments are included in Level 2.

[0001234452-15-000271:notes:108]
Other Investments and Other Liabilities: Other investments and other liabilities included in Level 1 are comprised of the Company’s deferred compensation plan liability and related assets, which consist of mutual funds classified as trading securities, and are included in other assets.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001234452-15-000271:notes:109]
Foreign Currency. Certain foreign subsidiaries use a local currency as the functional currency. Resulting translation gains or losses are recognized as a component of accumulated other comprehensive income. Transaction gains or losses related to balances denominated in a currency other than the functional currency are recognized in the consolidated statements of operations.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001234452-15-000271:notes:110]
Goodwill and Other Intangible Assets. Goodwill represents the excess of purchase price over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Acquired intangible assets other than goodwill are amortized over their useful lives unless the lives are determined to be indefinite. For intangible assets purchased in a business combination, the estimated fair values of the assets received are used to establish their recorded values. For intangible assets acquired in a non-monetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001234452-15-000271:notes:111]
Impairment of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. Goodwill and other indefinite-lived intangible assets are tested annually for impairment in the fourth fiscal quarter and in interim periods if certain events occur indicating that the carrying amounts may be impaired. If a qualitative assessment is used and the Company determines that the fair value of a reporting unit or indefinite-lived intangible asset is more likely than not (i.e., a likelihood of more than 50%) less than its carrying amount, a quantitative impairment test will be performed. If goodwill is quantitatively assessed for impairment, a two-step approach is applied. First, the Company compares the estimated fair value of the reporting unit in which the goodwill resides to its carrying value. The second step, if necessary, measures the amount of impairment, if any, by comparing the implied fair value of goodwill to its carrying value. Other indefinite-lived intangible assets are quantitatively assessed for impairment, if necessary, by comparing their estimated fair values to their carrying values. If the carrying value exceeds the fair value, the difference is recorded as an impairment.

[0001234452-15-000271:notes:112]
Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by comparing the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Long-lived assets to be disposed of by sale are reported at the lower of their carrying amounts or their estimated fair values less costs to sell and are not depreciated.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001234452-15-000271:notes:113]
Note 3. Income Taxes

[0001234452-15-000271:notes:114]
The components of the income tax provision for continuing operations were as follows (in millions):

[0001234452-15-000271:notes:115]
|  | 2015 |  | 2014 |  | 2013 |
| Current (benefit) provision: |  |  |  |  |  |
| Federal | $ | (67 | ) |  | $ | 172 |  |  | $ | 324 |  |
| State | 4 |  |  | 10 |  |  | 15 |  |
| Foreign | 1,307 |  |  | 1,116 |  |  | 1,068 |  |
|  | 1,244 |  |  | 1,298 |  |  | 1,407 |  |
| Deferred (benefit) provision: |  |  |  |  |  |
| Federal | (9 | ) |  | (30 | ) |  | (32 | ) |
| State | 1 |  |  | (10 | ) |  | 6 |  |
| Foreign | (17 | ) |  | (14 | ) |  | (32 | ) |
|  | (25 | ) |  | (54 | ) |  | (58 | ) |
|  | $ | 1,219 |  |  | $ | 1,244 |  |  | $ | 1,349 |  |

[0001234452-15-000271:notes:116]
The foreign component of the income tax provision consists primarily of foreign withholding taxes on royalty fees included in United States earnings.

[0001234452-15-000271:notes:117]
The components of income from continuing operations before income taxes by United States and foreign jurisdictions were as follows (in millions):

[0001234452-15-000271:notes:118]
|  | 2015 |  | 2014 |  | 2013 |
| United States | $ | 2,993 |  |  | $ | 3,213 |  |  | $ | 3,798 |  |
| Foreign | 3,494 |  |  | 5,565 |  |  | 4,396 |  |
|  | $ | 6,487 |  |  | $ | 8,778 |  |  | $ | 8,194 |  |

[0001234452-15-000271:notes:119]
The following is a reconciliation of the expected statutory federal income tax provision to the Company’s actual income tax provision for continuing operations (in millions):

[0001234452-15-000271:notes:120]
|  | 2015 |  | 2014 |  | 2013 |
| Expected income tax provision at federal statutory tax rate | $ | 2,270 |  |  | $ | 3,072 |  |  | $ | 2,868 |  |
| State income tax provision, net of federal benefit | 18 |  |  | 24 |  |  | 26 |  |
| Foreign income taxed at other than U.S. rates | (937 | ) |  | (1,750 | ) |  | (1,362 | ) |
| Research and development tax credits | (148 | ) |  | (61 | ) |  | (195 | ) |
| Other | 16 |  |  | (41 | ) |  | 12 |  |
|  | $ | 1,219 |  |  | $ | 1,244 |  |  | $ | 1,349 |  |

[0001234452-15-000271:notes:121]
During fiscal 2015, the NDRC imposed a fine of $975 million, which was not deductible for tax purposes and was substantially attributable to a foreign jurisdiction. Additionally, during fiscal 2015, the Company recorded a tax benefit of $101 million related to fiscal 2014 resulting from the United States government reinstating the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. The effective tax rate for fiscal 2015 also reflected the United States federal research and development tax credit generated through December 31, 2014, the date on which the credit expired, and a $61 million tax benefit as a result of a favorable tax audit settlement with the Internal Revenue Service (IRS).

[0001234452-15-000271:notes:122]
The Company’s QCT segment’s non-United States headquarters is located in Singapore. The Company has obtained tax incentives in Singapore that commenced in March 2012, which are effective through March 2027, that result in a tax exemption for the first five years provided that the Company meets specified employment and investment criteria. The Company’s Singapore tax rate will increase in fiscal 2017 and again in fiscal 2027 as a result of the expiration of these incentives. Had the Company established QCT’s non-United States headquarters in Singapore without these tax incentives, the Company’s income tax expense would have been higher and impacted earnings per share attributable to Qualcomm as follows (in millions, except per share amounts):

[0001234452-15-000271:notes:123]
|  | 2015 |  | 2014 |  | 2013 |
| Additional income tax expense | $ | 656 |  |  | $ | 690 |  |  | $ | 758 |  |
| Reduction to diluted earnings per share | $ | 0.40 |  |  | $ | 0.40 |  |  | $ | 0.43 |  |

[0001234452-15-000271:notes:124]
The Company considers the operating earnings of certain non-United States subsidiaries to be indefinitely reinvested outside the United States based on the Company’s plans for use and/or investment outside the United States and the Company’s belief that its sources of cash and liquidity in the United States will be sufficient to meet future domestic cash needs. The Company has not recorded a deferred tax liability of approximately $10.2 billion related to the United States federal and state income taxes and foreign withholding taxes on approximately $28.8 billion of undistributed earnings of certain non-United States subsidiaries indefinitely reinvested outside the United States. Should the Company decide to no longer indefinitely reinvest such earnings outside the United States, the Company would have to adjust the income tax provision in the period management makes such determination.

[0001234452-15-000271:notes:125]
The Company files income tax returns in the United States federal jurisdiction and various state and foreign jurisdictions. The Company is currently a participant in the IRS Compliance Assurance Process, whereby the IRS and the Company endeavor to agree on the treatment of all tax issues prior to the tax return being filed. The IRS completed its examination of the Company’s tax return for fiscal 2013 and issued a no change letter in October 2014, resulting in no change to the income tax provision. The Company is no longer subject to United States federal income tax examinations for years prior to fiscal 2014. The Company is subject to examination by the California Franchise Tax Board for fiscal years after 2011. The Company is also subject to income taxes in other taxing jurisdictions in the United States and around the world, many of which are open to tax examinations for periods after fiscal 2000. The outcome of any state or foreign income tax examination is not expected to be material to the Company’s consolidated financial statements.

[0001234452-15-000271:notes:126]
The Company had deferred tax assets and deferred tax liabilities as follows (in millions):

[0001234452-15-000271:notes:127]
|  | September 27, 2015 |  | September 28, 2014 |
| Unearned revenues | $ | 1,029 |  |  | $ | 1,189 |  |
| Unused tax credits | 897 |  |  | 388 |  |
| Unrealized losses on marketable securities | 441 |  |  | 370 |  |
| Share-based compensation | 331 |  |  | 404 |  |
| Accrued liabilities and reserves | 317 |  |  | 529 |  |
| Unused net operating losses | 265 |  |  | 120 |  |
| Other | 95 |  |  | 93 |  |
| Total gross deferred tax assets | 3,375 |  |  | 3,093 |  |
| Valuation allowance | (635 | ) |  | (414 | ) |
| Total net deferred tax assets | 2,740 |  |  | 2,679 |  |
| Intangible assets | (548 | ) |  | (315 | ) |
| Unrealized gains on marketable securities | (273 | ) |  | (484 | ) |
| Other | (105 | ) |  | (135 | ) |
| Total deferred tax liabilities | (926 | ) |  | (934 | ) |
| Net deferred tax assets | $ | 1,814 |  |  | $ | 1,745 |  |
| Reported as: |  |  |  |
| Current deferred tax assets | $ | 635 |  |  | $ | 577 |  |
| Non-current deferred tax assets | 1,453 |  |  | 1,174 |  |
| Current deferred tax liabilities (1) | (4 | ) |  | — |  |
| Non-current deferred tax liabilities (1) | (270 | ) |  | (6 | ) |
|  | $ | 1,814 |  |  | $ | 1,745 |  |

[0001234452-15-000271:notes:128]
| (1) | Current deferred tax liabilities and non-current deferred tax liabilities were included in other current liabilities and other liabilities, respectively, in the consolidated balance sheets. |

[0001234452-15-000271:notes:129]
At September 27, 2015, the Company had unused federal net operating loss carryforwards of $366 million expiring from 2021 through 2033, unused state net operating loss carryforwards of $696 million expiring from 2016 through 2035 and unused foreign net operating loss carryforwards of $413 million expiring from 2019 through 2024. At September 27, 2015, the Company had unused state tax credits of $522 million, of which substantially all may be carried forward indefinitely, unused federal tax credits of $353 million expiring from 2025 through 2034 and unused tax credits of $22 million in foreign jurisdictions expiring from 2032 through 2035. The Company does not expect its federal net operating loss carryforwards to expire unused.

[0001234452-15-000271:notes:130]
The Company believes, more likely than not, that it will have sufficient taxable income after deductions related to share-based awards to utilize the majority of its deferred tax assets. At September 27, 2015, the Company has provided a valuation allowance on certain state tax credits, foreign deferred tax assets, state net operating losses and state net capital losses of $513 million, $102 million, $19 million and $1 million, respectively. The valuation allowances reflect the uncertainties surrounding the Company’s ability to generate sufficient future taxable income in certain foreign and state tax jurisdictions to utilize its net operating losses and the Company’s ability to generate sufficient capital gains to utilize all capital losses.

[0001234452-15-000271:notes:131]
A summary of the changes in the amount of unrecognized tax benefits for fiscal 2015, 2014 and 2013 follows (in millions):

[0001234452-15-000271:notes:132]
|  | 2015 |  | 2014 |  | 2013 |
| Beginning balance of unrecognized tax benefits | $ | 87 |  |  | $ | 221 |  |  | $ | 86 |  |
| Additions based on prior year tax positions | 31 |  |  | 1 |  |  | 1 |  |
| Reductions for prior year tax positions and lapse in statute of limitations | (70 | ) |  | (67 | ) |  | — |  |
| Additions for current year tax positions | 5 |  |  | 5 |  |  | 145 |  |
| Settlements with taxing authorities | (13 | ) |  | (73 | ) |  | (11 | ) |
| Ending balance of unrecognized tax benefits | $ | 40 |  |  | $ | 87 |  |  | $ | 221 |  |

[0001234452-15-000271:notes:133]
The Company does not expect any unrecognized tax benefits recorded at September 27, 2015 to result in a significant cash payment in fiscal 2016. Unrecognized tax benefits at September 27, 2015 included $38 million for tax positions that, if recognized, would impact the effective tax rate. The unrecognized tax benefits differ from the amount that would affect the Company’s effective tax rate primarily because the unrecognized tax benefits were included on a gross basis and did not reflect secondary impacts such as the federal deduction for state taxes, adjustments to deferred tax assets and the valuation allowance that might be required if the Company’s tax positions are sustained. The decrease in unrecognized tax benefits in fiscal 2015 primarily resulted from a favorable tax audit settlement with the IRS related to Qualcomm Atheros, Inc.’s pre-acquisition 2010 and 2011 tax returns, which was partially offset by an increase related to the CSR acquisition (Note 9). The decrease in unrecognized tax benefits in fiscal 2014 was primarily due to an agreement reached with the IRS on components of the Company’s fiscal 2013 tax returns. The increase in unrecognized tax benefits in fiscal 2013 was primarily due to tax positions related to transfer pricing. The Company does not believe that it is reasonably possible that the total amounts of unrecognized tax benefits at September 27, 2015 will significantly increase or decrease in fiscal 2016.

[0001234452-15-000271:notes:134]
Cash amounts paid for income taxes, net of refunds received, were $1.2 billion, $1.2 billion and $1.1 billion for fiscal 2015, 2014 and 2013, respectively.


## us-gaap:IncomeTaxPolicyTextBlock

[0001234452-15-000271:notes:135]
Income Taxes. The asset and liability approach is used to recognize deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax bases of assets and liabilities. Tax law and rate changes are reflected in income in the period such changes are enacted. The Company records a valuation allowance to reduce deferred tax assets to the amount that is more likely than not to be realized. The Company includes interest and penalties related to income taxes, including unrecognized tax benefits, within income tax expense.

[0001234452-15-000271:notes:136]
The Company’s income tax returns are based on calculations and assumptions that are subject to examination by the Internal Revenue Service and other tax authorities. In addition, the calculation of the Company’s tax liabilities involves dealing with uncertainties in the application of complex tax regulations. The Company recognizes liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. While the Company believes it has appropriate support for the positions taken on its tax returns, the Company regularly assesses the potential outcomes of examinations by tax authorities in determining the adequacy of its provision for income taxes. The Company continually assesses the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts that give rise to a revision become known.

[0001234452-15-000271:notes:137]
The Company recognizes windfall tax benefits associated with share-based awards directly to stockholders’ equity when realized. A windfall tax benefit occurs when the actual tax benefit realized by the Company upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that the Company had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, the Company follows the tax law ordering method, under which current year share-based compensation deductions are assumed to be utilized before net operating loss carryforwards and other tax attributes.


## us-gaap:InventoryPolicyTextBlock

[0001234452-15-000271:notes:138]
Inventories. Inventories are valued at the lower of cost or market (replacement cost, not to exceed net realizable value) using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers, among other things.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001234452-15-000271:notes:139]
At September 27, 2015, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001234452-15-000271:notes:140]
| Years to Maturity |  |  |  |  |
| Less Than One Year |  | One to Five Years |  | Five to Ten Years |  | Greater Than Ten Years |  | No Single Maturity Date |  | Total |
| $ | 3,124 |  |  | $ | 11,271 |  |  | $ | 980 |  |  | $ | 510 |  |  | $ | 4,474 |  |  | $ | 20,359 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001234452-15-000271:notes:141]
Note 13. Marketable Securities

[0001234452-15-000271:notes:142]
Marketable securities were comprised as follows (in millions):

[0001234452-15-000271:notes:143]
|  | Current |  | Noncurrent |
|  | September 27, 2015 |  | September 28, 2014 |  | September 27, 2015 |  | September 28, 2014 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | — |  |  | $ | 320 |  |  | $ | 12 |  |  | $ | 38 |  |
| Corporate bonds and notes | — |  |  | 191 |  |  | 364 |  |  | 367 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | — |  |  | 242 |  |  | 237 |  |
| Total trading | — |  |  | 511 |  |  | 618 |  |  | 642 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 156 |  |  | 805 |  |  | 691 |  |  | 392 |  |
| Corporate bonds and notes | 7,926 |  |  | 6,274 |  |  | 7,112 |  |  | 7,649 |  |
| Mortgage- and asset-backed and auction rate securities | 1,302 |  |  | 1,063 |  |  | 263 |  |  | 278 |  |
| Equity and preferred securities and equity funds | 377 |  |  | 192 |  |  | 1,253 |  |  | 2,146 |  |
| Debt funds | — |  |  | 813 |  |  | 2,909 |  |  | 2,560 |  |
| Total available-for-sale | 9,761 |  |  | 9,147 |  |  | 12,228 |  |  | 13,025 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 780 |  |  | 790 |  |
| Total marketable securities | $ | 9,761 |  |  | $ | 9,658 |  |  | $ | 13,626 |  |  | $ | 14,457 |  |

[0001234452-15-000271:notes:144]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At September 27, 2015, the Company had an effective ownership interest in the debt fund of 25%. Changes in fair value associated with this investment are recognized in net investment income. During fiscal 2015, the net decrease in fair value associated with this investment was $10 million. During fiscal 2014 and 2013, net increases in fair value associated with this investment were $33 million and $17 million, respectively.

[0001234452-15-000271:notes:145]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net losses recognized on debt securities classified as trading held at September 27, 2015 and September 28, 2014, respectively, were negligible. Net losses recognized on debt securities classified as trading held at September 29, 2013 were $20 million.

[0001234452-15-000271:notes:146]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities, auction rate securities and corporate bonds and notes.

[0001234452-15-000271:notes:147]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001234452-15-000271:notes:148]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| 2015 | $ | 540 |  |  | $ | (52 | ) |  | $ | 488 |  |
| 2014 | 732 |  |  | (18 | ) |  | 714 |  |
| 2013 | 430 |  |  | (142 | ) |  | 288 |  |

[0001234452-15-000271:notes:149]
Available-for-sale securities were comprised as follows (in millions):

[0001234452-15-000271:notes:150]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| September 27, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,394 |  |  | $ | 264 |  |  | $ | (28 | ) |  | $ | 1,630 |  |
| Debt securities (including debt funds) | 20,459 |  |  | 185 |  |  | (285 | ) |  | 20,359 |  |
|  | $ | 21,853 |  |  | $ | 449 |  |  | $ | (313 | ) |  | $ | 21,989 |  |
| September 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,769 |  |  | $ | 575 |  |  | $ | (6 | ) |  | $ | 2,338 |  |
| Debt securities (including debt funds) | 19,582 |  |  | 312 |  |  | (60 | ) |  | 19,834 |  |
|  | $ | 21,351 |  |  | $ | 887 |  |  | $ | (66 | ) |  | $ | 22,172 |  |

[0001234452-15-000271:notes:151]
The following table shows the gross unrealized losses and fair values of the Company’s investments in individual securities that are classified as available-for-sale and have been in a continuous unrealized loss position deemed to be temporary for less than 12 months and for more than 12 months, aggregated by investment category (in millions):

[0001234452-15-000271:notes:152]
|  | September 27, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 304 |  |  | $ | (4 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 7,656 |  |  | (93 | ) |  | 368 |  |  | (62 | ) |
| Mortgage- and asset-backed and auction rate securities | 862 |  |  | (3 | ) |  | 108 |  |  | (1 | ) |
| Equity and preferred securities and equity funds | 392 |  |  | (28 | ) |  | 17 |  |  | — |  |
| Debt funds | 1,792 |  |  | (117 | ) |  | 124 |  |  | (5 | ) |
|  | $ | 11,006 |  |  | $ | (245 | ) |  | $ | 617 |  |  | $ | (68 | ) |

[0001234452-15-000271:notes:153]
|  | September 28, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 279 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,924 |  |  | (31 | ) |  | 104 |  |  | (4 | ) |
| Mortgage- and asset-backed and auction rate securities | 484 |  |  | (1 | ) |  | 135 |  |  | (2 | ) |
| Equity and preferred securities and equity funds | 86 |  |  | (3 | ) |  | 52 |  |  | (3 | ) |
| Debt funds | 133 |  |  | (1 | ) |  | 384 |  |  | (19 | ) |
|  | $ | 5,906 |  |  | $ | (38 | ) |  | $ | 675 |  |  | $ | (28 | ) |

[0001234452-15-000271:notes:154]
At September 27, 2015, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

[0001234452-15-000271:notes:155]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was $12 million at September 27, 2015. The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was negligible at September 28, 2014 and September 29, 2013.


## us-gaap:LegalCostsPolicyTextBlock

[0001234452-15-000271:notes:156]
The Company’s legal costs associated with defending itself are recorded to expense as incurred.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001234452-15-000271:notes:157]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. This ASU, as amended, will be effective for the Company starting in the first quarter of fiscal 2019. The FASB will also permit entities to adopt one year earlier if they choose. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the standard early and is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001234452-15-000271:notes:158]
Note 1. The Company and Its Significant Accounting Policies

[0001234452-15-000271:notes:159]
The Company. QUALCOMM Incorporated, a Delaware corporation, and its subsidiaries (collectively the Company or Qualcomm) develop, design, manufacture, have manufactured on its behalf and market digital communications products and services. The Company is a leading developer and supplier of integrated circuits and system software based on CDMA (Code Division Multiple Access), OFDMA (Orthogonal Frequency Division Multiple Access) and other technologies for use in voice and data communications, networking, application processing, multimedia and global positioning system products to device and infrastructure manufacturers. The Company grants licenses to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products and receives fixed license fees (payable in one or more installments) as well as ongoing royalties based on sales by licensees of wireless telecommunications equipment products incorporating its patented technologies. The Company provides software products and content and push-to-talk enablement services across a wide variety of platforms and devices for the wireless industry and sells products designed for the implementation of small cells. The Company also makes strategic investments to support the global adoption of its technologies and services.

[0001234452-15-000271:notes:160]
Financial Statement Preparation. The preparation of financial statements in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in the Company’s consolidated financial statements and the accompanying notes. Examples of the Company’s significant accounting estimates that may involve a higher degree of judgment and complexity than others include: the determination of other-than-temporary impairments of marketable securities; the valuation of inventories; the valuation and assessment of the recoverability of goodwill and other indefinite-lived and long-lived assets; the recognition, measurement and disclosure of loss contingencies related to legal proceedings; and the calculation of tax liabilities, including the recognition and measurement of uncertain tax positions and the determination that the operating earnings of certain non-United States subsidiaries are indefinitely reinvested outside the United States. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

[0001234452-15-000271:notes:161]
Fiscal Year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. The fiscal years ended September 27, 2015, September 28, 2014 and September 29, 2013 included 52 weeks.

[0001234452-15-000271:notes:162]
Marketable Securities. Marketable securities include trading securities, available-for-sale securities and securities for which the Company has elected the fair value option. The classification of marketable securities within these categories is determined at the time of purchase and reevaluated at each balance sheet date. The Company classifies portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange and/or equity, prepayment and credit risk as trading. The Company classifies marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value. The net unrealized gains or losses on available-for-sale securities are recorded as a component of accumulated other comprehensive income, net of income taxes. The unrealized gains or losses on trading securities and securities for which the Company has elected the fair value option are recognized in net investment income. The realized gains and losses on marketable securities are determined using the specific identification method.

[0001234452-15-000271:notes:163]
At each balance sheet date, the Company assesses available-for-sale securities in an unrealized loss position to determine whether the unrealized loss is other than temporary. The Company considers factors including: the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; how long the market value of the security has been less than its cost basis; the security’s relative performance versus its peers, sector or asset class; expected market volatility; the market and economy in general; analyst recommendations and price targets; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.

[0001234452-15-000271:notes:164]
If a debt security’s market value is below amortized cost and the Company either intends to sell the security or it is more likely than not that the Company will be required to sell the security before its anticipated recovery, the Company records an other-than-temporary impairment charge to net investment income for the entire amount of the impairment. For the remaining debt securities, if an other-than-temporary impairment exists, the Company separates the other-than-temporary impairment into the portion of the loss related to credit factors, or the credit loss portion, which is recorded as a charge to net investment income, and the portion of the loss that is not related to credit factors, or the noncredit loss portion, which is recorded as a component of other accumulated comprehensive income, net of income taxes.

[0001234452-15-000271:notes:165]
For equity securities, the Company considers the loss relative to the expected volatility and the likelihood of recovery over a reasonable period of time. If events and circumstances indicate that a decline in the value of an equity security has occurred and is other than temporary, the Company records a charge to net investment income for the difference between fair value and cost at the balance sheet date. Additionally, if the Company has either the intent to sell the equity security or does not have both the intent and the ability to hold the equity security until its anticipated recovery, the Company records a charge to net investment income for the difference between fair value and cost at the balance sheet date.

[0001234452-15-000271:notes:166]
Gross Notional Amounts: The gross notional amounts of the Company’s interest rate, foreign currency and investment portfolio derivatives by instrument type were as follows (in millions):

[0001234452-15-000271:notes:167]
|  | September 27, 2015 |  | September 28, 2014 |
| Forwards | $ | 269 |  |  | $ | 210 |  |
| Futures | 133 |  |  | $ | 260 |  |
| Options | 620 |  |  | 122 |  |
| Swaps | 3,004 |  |  | 5 |  |
|  | $ | 4,026 |  |  | $ | 597 |  |

[0001234452-15-000271:notes:168]
The gross notional amounts by currency were as follows (in millions):

[0001234452-15-000271:notes:169]
|  | September 27, 2015 |  | September 28, 2014 |
| British pound sterling | $ | 83 |  |  | $ | 97 |  |
| Chinese renminbi | 111 |  |  | — |  |
| Euro | 36 |  |  | 43 |  |
| Indian rupee | 409 |  |  | 3 |  |
| Japanese yen | 174 |  |  | 19 |  |
| Korean won | 81 |  |  | 121 |  |
| United States dollar | 3,089 |  |  | 266 |  |
| Other | 43 |  |  | 48 |  |
|  | $ | 4,026 |  |  | $ | 597 |  |

[0001234452-15-000271:notes:170]
Allowances for Doubtful Accounts. The Company maintains allowances for doubtful accounts for estimated losses resulting from the inability of the Company’s customers to make required payments. The Company considers the following factors when determining if collection of required payments is reasonably assured: customer credit-worthiness; past transaction history with the customer; current economic industry trends; changes in customer payment terms; and bank credit-worthiness for letters of credit. If the Company has no previous experience with the customer, the Company may request financial information, including financial statements or other documents, to determine that the customer has the means of making payment. The Company may also obtain reports from various credit organizations to determine that the customer has a history of paying its creditors. If these factors do not indicate collection is reasonably assured, revenue is deferred as a reduction to accounts receivable until collection becomes reasonably assured, which is generally upon receipt of cash. If the financial condition of the Company’s customers was to deteriorate, adversely affecting their ability to make payments, additional allowances would be required.

[0001234452-15-000271:notes:171]
Property, Plant and Equipment. Property, plant and equipment are recorded at cost and depreciated or amortized using the straight-line method over their estimated useful lives. Upon the retirement or disposition of property, plant and equipment, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. Buildings and building improvements on owned land are depreciated over 30 years and 15 years, respectively. Leasehold improvements are amortized over the shorter of their estimated useful lives, not to exceed 15 years, or the remaining term of the related lease. Other property, plant and equipment have useful lives ranging from 2 to 25 years. Leased property meeting certain capital lease criteria is capitalized, and the net present value of the related lease payments is recorded as a liability. Amortization of assets under capital leases is recorded using the straight-line method over the shorter of the estimated useful lives or the lease terms. Maintenance, repairs and minor renewals or betterments are charged to expense as incurred. Interest expense related to the broadband wireless access (BWA) spectrum and related construction of the network infrastructure assets in India by the Company’s former BWA subsidiaries was capitalized beginning in May 2012 through the third quarter of fiscal 2013 when the BWA subsidiaries were deconsolidated. Interest capitalized by the former BWA subsidiaries totaled $65 million in fiscal 2013.

[0001234452-15-000271:notes:172]
Revenue Recognition. The Company derives revenues principally from sales of integrated circuit products, licensing of its intellectual property and sales of software hosting, software development and other services. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of the Company’s deliverables and obligations. Unearned revenues consist primarily of license fees for intellectual property with continuing performance obligations.

[0001234452-15-000271:notes:173]
Revenues from sales of the Company’s products are recognized at the time of shipment, or when title and risk of loss pass to the customer and other criteria for revenue recognition are met, if later. Revenues from providing services are recognized when earned. Revenues from providing services were less than 10% of total revenues for all periods presented.

[0001234452-15-000271:notes:174]
The Company licenses or otherwise provides rights to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Licensees typically pay a fixed license fee in one or more installments and royalties based on their sales of products incorporating or using the Company’s licensed intellectual property. License fees are recognized over the estimated period of benefit of the license to the licensee, typically 5 to 15 years. The Company earns royalties on such licensed products sold worldwide by its licensees at the time that the licensees’ sales occur. The Company’s licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. The Company recognizes royalty revenues based on royalties reported by licensees during the quarter and when other revenue recognition criteria are met.

[0001234452-15-000271:notes:175]
The Company records reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of the Company’s products and technologies. The Company recognizes the maximum potential liability at the later of the date at which the Company records the related revenues or the date at which the Company offers the incentive or, if payment is contingent, when the contingency is resolved. In certain arrangements, the liabilities are based on customer forecasts. The Company reverses accruals for unclaimed incentive amounts to revenues when the unclaimed amounts are no longer subject to payment.

[0001234452-15-000271:notes:176]
Shipping and Handling Costs. Costs incurred for shipping and handling are included in cost of equipment and services revenues. Amounts billed to a customer for shipping and handling are reported as revenues.

[0001234452-15-000271:notes:177]
Share-Based Compensation. Share-based compensation expense for equity-classified awards, principally related to restricted stock units (RSUs), is measured at the grant date, or at the acquisition date for awards assumed in business combinations, based on the estimated fair value of the award and is recognized over the employee’s requisite service period. Share-based compensation expense is adjusted to exclude amounts related to share-based awards that are expected to be forfeited.

[0001234452-15-000271:notes:178]
The fair values of RSUs are estimated based on the fair market values of the underlying stock on the dates of grant or dates the RSUs are assumed. If RSUs do not have the right to participate in dividends, the fair values are discounted by the dividend yield. The weighted-average estimated fair values of employee RSUs granted during fiscal 2015, 2014 and 2013 were $68.77, $72.81 and $64.21 per share, respectively. For the majority of RSUs, shares are issued on the vesting dates net of the amount of shares needed to satisfy statutory tax withholding requirements to be paid by the Company on behalf of the employees. As a result, the actual number of shares issued will be fewer than the number of RSUs outstanding. The annual pre-vest forfeiture rate for RSUs granted in fiscal 2015, 2014 and 2013 was estimated to be approximately 3% based on historical experience.

[0001234452-15-000271:notes:179]
Total share-based compensation expense, related to all of the Company’s share-based awards, was comprised as follows (in millions):

[0001234452-15-000271:notes:180]
|  | 2015 |  | 2014 |  | 2013 |
| Cost of equipment and services revenues | $ | 42 |  |  | $ | 49 |  |  | $ | 71 |  |
| Research and development | 659 |  |  | 672 |  |  | 643 |  |
| Selling, general and administrative | 325 |  |  | 338 |  |  | 391 |  |
| Share-based compensation expense before income taxes | 1,026 |  |  | 1,059 |  |  | 1,105 |  |
| Related income tax benefit | (190 | ) |  | (203 | ) |  | (217 | ) |
|  | $ | 836 |  |  | $ | 856 |  |  | $ | 888 |  |

[0001234452-15-000271:notes:181]
The Company recorded $267 million, $249 million and $242 million in share-based compensation expense during fiscal 2015, 2014 and 2013, respectively, related to share-based awards granted during those periods. The remaining share-based compensation expense was primarily related to share-based awards granted in earlier periods and share-based awards assumed. In addition, for fiscal 2015, 2014 and 2013, $103 million, $280 million and $231 million, respectively, were reclassified to reduce net cash provided by operating activities with an offset to net cash used by financing activities in the consolidated statements of cash flows to reflect the incremental tax benefits from stock options exercised and restricted stock units and other share-based awards that vested in those periods.

[0001234452-15-000271:notes:182]
Legal Proceedings. The Company is currently involved in certain legal proceedings. The Company discloses a loss contingency if there is at least a reasonable possibility that a material loss has been incurred. The Company records its best estimate of a loss related to pending legal proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, the Company records the minimum estimated liability. As additional information becomes available, the Company assesses the potential liability related to pending legal proceedings and revises its estimates and updates its disclosures accordingly. The Company’s legal costs associated with defending itself are recorded to expense as incurred.

[0001234452-15-000271:notes:183]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for fiscal 2015, 2014 and 2013 were 20,724,000, 30,655,000 and 38,670,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 4,652,000 during fiscal 2015, which were primarily attributable to the ASR Agreements (Note 4), and 846,000 and 507,000 during fiscal 2014 and 2013, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001234452-15-000271:notes:184]
Note 14. Summarized Quarterly Data (Unaudited)

[0001234452-15-000271:notes:185]
The following financial information reflects all normal recurring adjustments that are, in the opinion of management, necessary for a fair statement of the results of the interim periods.

[0001234452-15-000271:notes:186]
The table below presents quarterly data for fiscal 2015 and 2014 (in millions, except per share data):

[0001234452-15-000271:notes:187]
|  | 1st Quarter |  | 2nd Quarter |  | 3rd Quarter |  | 4th Quarter |
| 2015 (1) |  |  |  |  |  |  |  |
| Revenues | $ | 7,099 |  |  | $ | 6,894 |  |  | $ | 5,832 |  |  | $ | 5,456 |  |
| Operating income | 2,064 |  |  | 1,336 |  |  | 1,235 |  |  | 1,140 |  |
| Income from continuing operations | 1,971 |  |  | 1,052 |  |  | 1,183 |  |  | 1,060 |  |
| Net income | 1,971 |  |  | 1,052 |  |  | 1,183 |  |  | 1,060 |  |
| Net income attributable to Qualcomm | 1,972 |  |  | 1,053 |  |  | 1,184 |  |  | 1,061 |  |
| Basic earnings per share attributable to Qualcomm (2): | $ | 1.19 |  |  | $ | 0.64 |  |  | $ | 0.74 |  |  | $ | 0.68 |  |
| Diluted earnings per share attributable to Qualcomm (2): | 1.17 |  |  | 0.63 |  |  | 0.73 |  |  | 0.67 |  |
| 2014 (1) |  |  |  |  |  |  |  |
| Revenues | $ | 6,622 |  |  | $ | 6,367 |  |  | $ | 6,806 |  |  | $ | 6,692 |  |
| Operating income | 1,493 |  |  | 1,990 |  |  | 2,075 |  |  | 1,992 |  |
| Income from continuing operations | 1,444 |  |  | 1,958 |  |  | 2,237 |  |  | 1,893 |  |
| Discontinued operations, net of tax | 430 |  |  | — |  |  | — |  |  | — |  |
| Net income | 1,874 |  |  | 1,958 |  |  | 2,237 |  |  | 1,893 |  |
| Net income attributable to Qualcomm | 1,875 |  |  | 1,959 |  |  | 2,238 |  |  | 1,894 |  |
| Basic earnings per share attributable to Qualcomm (2): |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.86 |  |  | $ | 1.16 |  |  | $ | 1.33 |  |  | $ | 1.13 |  |
| Discontinued operations | 0.25 |  |  | — |  |  | — |  |  | — |  |
| Net income | 1.11 |  |  | 1.16 |  |  | 1.33 |  |  | 1.13 |  |
| Diluted earnings per share attributable to Qualcomm (2): |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.84 |  |  | $ | 1.14 |  |  | $ | 1.31 |  |  | $ | 1.11 |  |
| Discontinued operations | 0.25 |  |  | — |  |  | — |  |  | — |  |
| Net income | 1.09 |  |  | 1.14 |  |  | 1.31 |  |  | 1.11 |  |

[0001234452-15-000271:notes:188]
| (1) | Amounts, other than per share amounts, are rounded to millions each quarter. Therefore, the sum of the quarterly amounts may not equal the annual amounts reported. |

[0001234452-15-000271:notes:189]
| (2) | Earnings per share attributable to Qualcomm are computed independently for each quarter and the full year based upon respective average shares outstanding. Therefore, the sum of the quarterly earnings per share amounts may not equal the annual amounts reported. |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001234452-15-000271:notes:190]
Reconciling items in the previous table were as follows (in millions):

[0001234452-15-000271:notes:191]
|  | 2015 |  | 2014 |  | 2013 |
| Revenues |  |  |  |  |  |
| Nonreportable segments | $ | 181 |  |  | $ | 258 |  |  | $ | 601 |  |
| Intersegment eliminations | (5 | ) |  | (5 | ) |  | (4 | ) |
|  | $ | 176 |  |  | $ | 253 |  |  | $ | 597 |  |
| EBT |  |  |  |  |  |
| Unallocated cost of equipment and services revenues | $ | (314 | ) |  | $ | (300 | ) |  | $ | (335 | ) |
| Unallocated research and development expenses | (809 | ) |  | (860 | ) |  | (789 | ) |
| Unallocated selling, general and administrative expenses | (497 | ) |  | (412 | ) |  | (502 | ) |
| Unallocated other (expense) income | (1,289 | ) |  | 142 |  |  | (173 | ) |
| Unallocated interest expense | (101 | ) |  | (2 | ) |  | (3 | ) |
| Unallocated investment income, net | 855 |  |  | 1,215 |  |  | 880 |  |
| Nonreportable segments | (630 | ) |  | (1,395 | ) |  | (719 | ) |
| Intersegment eliminations | (1 | ) |  | — |  |  | — |  |
|  | $ | (2,786 | ) |  | $ | (1,612 | ) |  | $ | (1,641 | ) |

[0001234452-15-000271:notes:192]
Unallocated acquisition-related expenses were comprised as follows (in millions):

[0001234452-15-000271:notes:193]
|  | 2015 |  | 2014 |  | 2013 |
| Cost of equipment and services revenues | $ | 272 |  |  | $ | 251 |  |  | $ | 264 |  |
| Research and development expenses | 14 |  |  | 30 |  |  | 3 |  |
| Selling, general and administrative expenses | 72 |  |  | 25 |  |  | 26 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001234452-15-000271:notes:194]
Note 10. Strategic Realignment Plan

[0001234452-15-000271:notes:195]
On July 22, 2015, the Company announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as the Company works to create sustainable long-term value for stockholders. As part of this, among other actions, the Company is implementing a cost reduction plan, which includes a series of targeted reductions across the Company’s businesses, particularly in QCT, and a reduction to its annual share-based compensation grants. The Company expects these cost reduction initiatives to be fully implemented by the end of fiscal 2016. During fiscal 2015, the Company recorded restructuring charges of $170 million, including $125 million in severance costs, and restructuring-related charges of $20 million, primarily consisting of asset impairments. Restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan were included in other expenses (Note 2) in reconciling items (Note 8). In connection with this plan, the Company expects to incur total restructuring and restructuring-related charges of approximately $350 million to $450 million, which primarily consist of severance and consulting costs, and substantially all of which are expected to be settled in cash.

[0001234452-15-000271:notes:196]
The restructuring accrual, a portion of which is included in payroll and other benefits related liabilities with the remainder included in other current liabilities, is expected to be substantially paid within the next 12 months. Changes in the restructuring accrual for fiscal 2015 were as follows (in millions):

[0001234452-15-000271:notes:197]
|  | Severance Costs |  | Other Costs |  | Total |
| Beginning balance of restructuring accrual | $ | — |  |  | $ | — |  |  | $ | — |  |
| Initial costs | 125 |  |  | 45 |  |  | 170 |  |
| Cash payments | (3 | ) |  | (14 | ) |  | (17 | ) |
| Ending balance of restructuring accrual | $ | 122 |  |  | $ | 31 |  |  | $ | 153 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001234452-15-000271:notes:198]
Revenues by country were as follows (in millions):

[0001234452-15-000271:notes:199]
|  | 2015 |  | 2014 |  | 2013 |
| China (including Hong Kong) | $ | 13,337 |  |  | $ | 13,200 |  |  | $ | 12,288 |  |
| South Korea | 4,107 |  |  | 6,172 |  |  | 4,983 |  |
| Taiwan | 3,294 |  |  | 2,876 |  |  | 2,683 |  |
| United States | 246 |  |  | 372 |  |  | 805 |  |
| Other foreign | 4,297 |  |  | 3,867 |  |  | 4,107 |  |
|  | $ | 25,281 |  |  | $ | 26,487 |  |  | $ | 24,866 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001234452-15-000271:notes:200]
The table below presents revenues, EBT and total assets for reportable segments (in millions):

[0001234452-15-000271:notes:201]
|  | QCT |  | QTL |  | QSI |  | ReconcilingItems |  | Total |
| 2015 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 17,154 |  |  | $ | 7,947 |  |  | $ | 4 |  |  | $ | 176 |  |  | $ | 25,281 |  |
| EBT | 2,465 |  |  | 6,882 |  |  | (74 | ) |  | (2,786 | ) |  | 6,487 |  |
| Total assets | 2,923 |  |  | 438 |  |  | 812 |  |  | 46,623 |  |  | 50,796 |  |
| 2014 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 18,665 |  |  | $ | 7,569 |  |  | $ | — |  |  | $ | 253 |  |  | $ | 26,487 |  |
| EBT | 3,807 |  |  | 6,590 |  |  | (7 | ) |  | (1,612 | ) |  | 8,778 |  |
| Total assets | 3,639 |  |  | 161 |  |  | 484 |  |  | 44,290 |  |  | 48,574 |  |
| 2013 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 16,715 |  |  | $ | 7,554 |  |  | $ | — |  |  | $ | 597 |  |  | $ | 24,866 |  |
| EBT | 3,189 |  |  | 6,590 |  |  | 56 |  |  | (1,641 | ) |  | 8,194 |  |
| Total assets | 3,305 |  |  | 28 |  |  | 511 |  |  | 41,672 |  |  | 45,516 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001234452-15-000271:notes:202]
SCHEDULE II

[0001234452-15-000271:notes:203]
QUALCOMM INCORPORATED

[0001234452-15-000271:notes:204]
VALUATION AND QUALIFYING ACCOUNTS

[0001234452-15-000271:notes:205]
(In millions)

[0001234452-15-000271:notes:206]
|  | Balance atBeginning ofPeriod |  | Charged(Credited) toCosts andExpenses |  | Deductions |  | Other |  | Balance atEnd ofPeriod |
| Year ended September 27, 2015 |  |  |  |  |  |  |  |  |  |
| Allowances: |  |  |  |  |  |  |  |  |  |
| — trade receivables | $ | 5 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |
| — notes receivable | 4 |  |  | — |  |  | (3 | ) |  | (1 | ) | (a) | — |  |
| Valuation allowance on deferred tax assets | 414 |  |  | 130 |  |  | — |  |  | 91 |  | (b) | 635 |  |
|  | $ | 423 |  |  | $ | 131 |  |  | $ | (3 | ) |  | $ | 90 |  |  | $ | 641 |  |
| Year ended September 28, 2014 |  |  |  |  |  |  |  |  |  |
| Allowances: |  |  |  |  |  |  |  |  |  |
| — trade receivables | $ | 2 |  |  | $ | 5 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | 5 |  |
| — notes receivable | 10 |  |  | (3 | ) |  | (1 | ) |  | (2 | ) | (a) | 4 |  |
| Valuation allowance on deferred tax assets | 265 |  |  | 148 |  |  | — |  |  | 1 |  | (b) | 414 |  |
|  | $ | 277 |  |  | $ | 150 |  |  | $ | (3 | ) |  | $ | (1 | ) |  | $ | 423 |  |
| Year ended September 29, 2013 |  |  |  |  |  |  |  |  |  |
| Allowances: |  |  |  |  |  |  |  |  |  |
| — trade receivables | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |
| — notes receivable | 7 |  |  | 5 |  |  | — |  |  | (2 | ) | (a) | 10 |  |
| Valuation allowance on deferred tax assets | 227 |  |  | 114 |  |  | — |  |  | (76 | ) | (c) | 265 |  |
|  | $ | 235 |  |  | $ | 120 |  |  | $ | — |  |  | $ | (78 | ) |  | $ | 277 |  |

[0001234452-15-000271:notes:207]
| (a) | This amount relates to notes receivable on strategic investments that were converted to cost method equity investments. |

[0001234452-15-000271:notes:208]
| (b) | This amount was recorded to goodwill in connection with a business acquisition. |

[0001234452-15-000271:notes:209]
| (c) | This amount represents $88 million recorded as part of the gain on deconsolidation of certain subsidiaries, partially offset by $12 million recorded as a component of other comprehensive income. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001234452-15-000271:notes:210]
Note 8. Segment Information

[0001234452-15-000271:notes:211]
The Company is organized on the basis of products and services. The Company conducts business primarily through two reportable segments: QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing), and its QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an equity method investee. The Company also has nonreportable segments, including its small cells, data center and other wireless technology and service initiatives.

[0001234452-15-000271:notes:212]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT) from continuing operations. Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense; certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization and impairment of certain intangible assets and certain other acquisition-related charges, and beginning in the first quarter of fiscal 2015, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. The table below presents revenues, EBT and total assets for reportable segments (in millions):

[0001234452-15-000271:notes:213]
The Company reports revenues from external customers by country based on the location to which its products or services are delivered, which for QCT is generally the country in which its customers manufacture their products, or for licensing revenues, the invoiced addresses of its licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues could include revenues related to shipments of integrated circuits to a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States. Revenues by country were as follows (in millions):

[0001234452-15-000271:notes:214]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets include certain marketable securities, wireless spectrum, other investments and all assets of consolidated subsidiaries included in QSI. QSI assets at September 27, 2015, September 28, 2014 and September 29, 2013 included $163 million, $18 million and $17 million, respectively, related to investments in equity method investees. Total segment assets differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable securities, property, plant and equipment, deferred tax assets, intangible assets and assets of nonreportable segments. The net book values of long-lived tangible assets located outside of the United States were $414 million, $288 million and $896 million at September 27, 2015, September 28, 2014 and September 29, 2013, respectively. The net book values of long-lived tangible assets located in the United States were $2.1 billion, $2.2 billion and $2.1 billion at September 27, 2015, September 28, 2014 and September 29, 2013, respectively.

[0001234452-15-000271:notes:215]
Unallocated other expense for fiscal 2015 included a $975 million charge related to the resolution reached with the NDRC, $190 million in restructuring and restructuring-related charges related to the Strategic Realignment Plan (Note 10), and $235 million and $11 million in impairment charges of goodwill and intangible assets, respectively, related to three of the Company’s nonreportable segments (Note 2), partially offset by a $122 million gain on the sale of certain property, plant and equipment. Nonreportable segments EBT for fiscal 2014 and 2013 included $607 million and $158 million in impairment charges related to property, plant and equipment and goodwill, respectively (Note 2). Unallocated acquisition-related expenses were comprised as follows (in millions):


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001234452-15-000271:notes:216]
Note 4. Capital Stock

[0001234452-15-000271:notes:217]
Preferred Stock. The Company has 8,000,000 shares of preferred stock authorized for issuance in one or more series, at a par value of $0.0001 per share. In conjunction with the Amended and Restated Rights Agreement dated as of September 25, 2005 between the Company and Computershare Trust Company, N.A., as successor Rights Agent to Computershare Investor Services LLC, as amended (the Rights Agreement), 4,000,000 shares of preferred stock were designated as Series A Junior Participating Preferred Stock. The Rights Agreement expired on its scheduled expiration date of September 25, 2015, and all shares of preferred stock previously designated as Series A Junior Participating Preferred Stock were eliminated and returned to the status of authorized but unissued shares of preferred stock, without designation on September 28, 2015. At September 27, 2015 and September 28, 2014, no shares of preferred stock were outstanding.

[0001234452-15-000271:notes:218]
Stock Repurchase Program. On March 9, 2015, the Company announced a stock repurchase program authorizing it to repurchase up to $15 billion of the Company’s common stock. The stock repurchase program has no expiration date.

[0001234452-15-000271:notes:219]
In May 2015, the Company entered into two accelerated share repurchase agreements (ASR Agreements) with two financial institutions under which the Company paid an aggregate of $5.0 billion upfront to the financial institutions and received from them an initial delivery of 57,737,000 shares of the Company’s common stock, which were retired and recorded as a $4.0 billion reduction to stockholders’ equity. The remaining payment of $1.0 billion was recorded as a reduction to stockholders’ equity as an unsettled forward contract indexed to the Company’s own stock. During August 2015, the ASR Agreements were completed, and an additional 20,539,000 shares were delivered to the Company, which were retired. In total, the Company purchased 78,276,000 shares based on the average daily volume weighted-average stock price of the Company’s common stock during the respective terms of the ASR Agreements, less a discount.

[0001234452-15-000271:notes:220]
During fiscal 2015, 2014 and 2013, the Company repurchased and retired an additional 94,159,000, 60,253,000 and 71,696,000 shares of common stock, respectively, for $6.2 billion, $4.5 billion and $4.6 billion, respectively, before commissions. To reflect share repurchases in the consolidated balance sheet, the Company (i) reduces common stock for the par value of the shares, (ii) reduces paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) records the residual amount to retained earnings. At September 27, 2015, $6.9 billion remained authorized for repurchase under the Company’s stock repurchase program. Since September 27, 2015, the Company repurchased and retired 24,561,000 shares of common stock for $1.4 billion.

[0001234452-15-000271:notes:221]
Dividends. On October 9, 2015, the Company announced a cash dividend of $0.48 per share on the Company’s common stock, payable on December 18, 2015 to stockholders of record as of the close of business on December 1, 2015. Dividends charged to retained earnings in fiscal 2015, 2014 and 2013 were as follows (in millions, except per share data):
