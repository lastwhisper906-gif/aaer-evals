# QCOM MD&A — 0001234452-15-000271


## mdna

[0001234452-15-000271:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001234452-15-000271:mdna:2]
Overview

[0001234452-15-000271:mdna:3]
Fiscal 2015 Overview

[0001234452-15-000271:mdna:4]
The transition of wireless networks and devices to 3G/4G (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) continued around the world. 3G/4G connections increased to approximately 3.4 billion, up 22% year-over-year, and represent approximately 47% of total cellular connections, up from 40% at the end of fiscal 2014.(1)

[0001234452-15-000271:mdna:5]
Revenues were $25.3 billion, a decrease of 5% compared to fiscal 2014, with net income attributable to Qualcomm of $5.3 billion, a decrease of 34% compared to fiscal 2014.

[0001234452-15-000271:mdna:6]
QCT Segment. We shipped approximately 932 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, an increase of 8%, compared to approximately 861 million MSM integrated circuits in fiscal 2014. However, despite the increase in MSM integrated circuit shipments, QCT’s revenues decreased by 8%, and its earnings before taxes as a percentage of revenues decreased to 14% from 20% in fiscal 2014, primarily due to the effects of a shift in share among our customers within the premium tier, which reduced our sales of integrated Snapdragon processors and skewed our product mix towards lower-margin modem chipsets in this tier, a decline in share at a large customer and the competitive environment in China.

[0001234452-15-000271:mdna:7]
On August 13, 2015, we acquired CSR plc for total cash consideration of $2.3 billion, net of cash acquired. CSR, which was integrated into the QCT segment, is an innovator in the development of multifunction semiconductor platforms and technologies for the automotive, consumer and voice and music categories. The acquisition complements our current offerings by adding products, channels and customers in the growth categories of the Internet of Things and automotive infotainment.

[0001234452-15-000271:mdna:8]
QTL Segment. Total reported device sales(2) by licensees were approximately $250.9 billion in fiscal 2015, an increase of approximately 3%, compared to approximately $243.6 billion in fiscal 2014. Our total reported device sales and QTL’s results of operations were negatively impacted by units that we believe are not being reported to us by certain licensees and sales of certain unlicensed products in China.

[0001234452-15-000271:mdna:9]
In the second quarter of fiscal 2015, we recorded and paid a $975 million fine after reaching a resolution with the China National Development and Reform Commission (NDRC) regarding its investigation of us under China’s Anti-Monopoly Law. Despite the resolution of the NDRC investigation, China continues to present significant challenges for us as we believe that certain licensees in China are not fully complying with their contractual obligations to report their sales of licensed products to us, and certain companies, including unlicensed companies, are delaying execution of new license agreements. We continue to make progress with licensees executing agreements based on the new China terms and with several other licensees informing us that they intend to retain the terms of their existing agreements. Negotiations with certain other licensees and unlicensed companies are ongoing, and we expect it will take some time to conclude these negotiations.

[0001234452-15-000271:mdna:10]
Strategic Realignment Plan. In the fourth quarter of fiscal 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders. During fiscal 2015, we recorded restructuring and restructuring-related charges of $190 million related to the plan.

[0001234452-15-000271:mdna:11]
Capital Return Program. On March 9, 2015, we announced that our Board of Directors authorized us to repurchase up to $15 billion of our common stock. We intend to return a minimum of 75% of our free cash flow(3) to stockholders through stock repurchases and dividends over the foreseeable future. Additionally, we announced our intention to repurchase $10 billion of stock from March 2015 through March 2016. In fiscal 2015, we completed $8.1 billion of repurchases towards our $10 billion stock repurchase commitment, which includes the completion of our $5.0 billion accelerated share repurchase agreements. Excluding these stock repurchases, we returned $6.0 billion, or 134% of free cash flow, to stockholders, including $3.1 billion through repurchases of common stock and $2.9 billion of cash dividends. Shares outstanding decreased by 9% to 1.52 billion at September 27, 2015 from 1.67 billion at September 28, 2014 due to share repurchases, partially offset by net shares issued under our employee benefit plans.

[0001234452-15-000271:mdna:12]
32

[0001234452-15-000271:mdna:13]
To support our capital return program and for other general corporate purposes, in May 2015, we issued an aggregate principal amount of $10.0 billion of unsecured floating- and fixed-rate notes, with maturity dates in 2018 through 2045 and effective interest rates between 0.43% and 4.74%.

[0001234452-15-000271:mdna:14]
| (1) | According to GSMA Intelligence estimates as of November 2, 2015 for the quarter ended September 30, 2015 (estimates excluded Wireless Local Loop). |

[0001234452-15-000271:mdna:15]
| (2) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). Not all licensees report sales the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-15-000271:mdna:16]
| (3) | Free cash flow, a non-GAAP financial measure, is defined as net cash provided by operating activities less capital expenditures. See “Non-GAAP Financial Information.” |

[0001234452-15-000271:mdna:17]
Our Business and Operating Segments

[0001234452-15-000271:mdna:18]
We design, manufacture, have manufactured on our behalf and market digital communications products and services based on CDMA, OFDMA and other technologies. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents, software and other rights.

[0001234452-15-000271:mdna:19]
We have three reportable segments. We conduct business primarily through two reportable segments: QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing), and our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering, research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001234452-15-000271:mdna:20]
QCT is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products are sold and its system software is licensed to manufacturers that use our products in wireless devices, particularly mobile phones, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards and infrastructure equipment, and in wired devices, particularly broadband gateway equipment, desktop computers and streaming media players. Our MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Qualcomm Snapdragon processors and LTE modems, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon processors provide advanced application and graphics processing capabilities. QCT’s system software enables the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits. QCT revenues comprised 68%, 70% and 67% of our total consolidated revenues in fiscal 2015, 2014 and 2013, respectively.

[0001234452-15-000271:mdna:21]
QCT utilizes a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Integrated circuits are die cut from silicon wafers that have completed the package assembly and test manufacturing processes. We rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits based primarily on our proprietary designs and test programs. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Turnkey is when our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services, such as wafer bump, probe, assembly and final test.

[0001234452-15-000271:mdna:22]
QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products,

[0001234452-15-000271:mdna:23]
including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD and/or LTE standards and their derivatives. QTL licensing revenues include license fees and royalties based on sales by licensees of products incorporating or using our intellectual property. License fees are fixed amounts paid in one or more installments. Royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). QTL recognizes royalty revenues based on royalties reported by licensees and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. QTL revenues comprised 31%, 29% and 30% of our total consolidated revenues in fiscal 2015, 2014 and 2013, respectively. The vast majority of such revenues were generated through our licensees’ sales of CDMA2000- and WCDMA-based products, such as feature phones and smartphones.

[0001234452-15-000271:mdna:24]
QSI makes strategic investments that are focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications. Many of these strategic investments are in early-stage companies in a variety of industries, including, but not limited to, digital media, e-commerce, healthcare and wearable devices. Investments primarily include non-marketable equity instruments, which generally are recorded using the cost method or the equity method, and convertible debt instruments, which are recorded at fair value. QSI also holds wireless spectrum, which at September 27, 2015 consisted of L-Band spectrum in the United Kingdom that was subsequently sold in October 2015 for an estimated gain of approximately $380 million. In addition, QSI segment results include revenues and related costs associated with development contracts with one of our equity method investees. As part of our strategic investment activities, we intend to pursue various exit strategies for each of our QSI investments in the foreseeable future.

[0001234452-15-000271:mdna:25]
Nonreportable segments include our small cells, data center and other wireless technology and service initiatives.

[0001234452-15-000271:mdna:26]
Seasonality. Many of our products or intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has tended historically to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons; and because QTL recognizes royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made during the fourth calendar quarter. We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 3G/4G networks by wireless operators and the timing of launches of flagship wireless devices that incorporate our products and/or intellectual property. These trends may or may not continue in the future.

[0001234452-15-000271:mdna:27]
Discontinued Operations

[0001234452-15-000271:mdna:28]
On November 25, 2013, we completed our sale of the North and Latin America operations of our Omnitracs division to a U.S.-based private equity firm for cash consideration of $788 million (net of cash sold). As a result, we recorded a gain in discontinued operations of $665 million ($430 million net of income tax expense) during fiscal 2014. The revenues and operating results of the North and Latin America operations of the Omnitracs division, which comprised substantially all of the Omnitracs division, were not presented as discontinued operations in any fiscal period because they were immaterial.

[0001234452-15-000271:mdna:29]
Looking Forward

[0001234452-15-000271:mdna:30]
We expect continued growth in the coming years in consumer demand for 3G, 3G/4G multimode and 4G products and services around the world, driven primarily by smartphones. We also expect growth in new device categories and industries, driven by the expanding adoption of certain technologies that are already commonly used in smartphones. As we look forward to the next several months, we expect our business to be impacted by the following key items:

[0001234452-15-000271:mdna:31]
| • | Our business has been impacted by changing industry dynamics, including: an increased shift in share among our customers within the premium tier, which will continue to negatively impact sales of our integrated Snapdragon processors and skew our product mix towards lower-margin modem chipsets in this tier; an increased use of internally-developed integrated circuit products by certain of our OEM (original equipment manufacturer) customers, which has led to a decline in share at a large customer; and the acceleration of intense competition in the low-tier, particularly in China. We anticipate that our results of operations, particularly for our semiconductor business, QCT, will continue to be adversely impacted by these factors into the next fiscal year. |

[0001234452-15-000271:mdna:32]
| • | China continues to present significant opportunities for us, particularly with the rollout of 3G/4G LTE multimode. We expect the rollout of 4G services in China will encourage competition and growth, bring the benefits of 3G/4G LTE multimode to consumers, encourage consumers to replace 2G (GSM) and 3G devices and enable new opportunities beyond mobile applications (e.g., machine-to-machine). |

[0001234452-15-000271:mdna:33]
34

[0001234452-15-000271:mdna:34]
| • | In February 2015, we reached a resolution with the NDRC regarding its investigation and agreed to implement a rectification plan that modifies certain of our business practices in China. The rectification plan provides, among other things, that for licenses of only our 3G and 4G essential Chinese patents for branded devices sold for use in China starting on January 1, 2015 (and reported to us starting in the third quarter of fiscal 2015), we will charge running royalties at royalty rates of 5% for 3G CDMA or WCDMA devices (including multimode 3G/4G devices) and 3.5% for 4G devices that do not implement CDMA or WCDMA (including 3-mode LTE-TDD devices), in each case using a royalty base of 65% of the net selling price. |

[0001234452-15-000271:mdna:35]
| • | Despite the resolution of the NDRC investigation, China continues to present significant challenges for us. We continue to believe that certain licensees in China are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes 3G/4G units that we believe are not being reported by certain licensees), and certain companies, including unlicensed companies, are delaying execution of new license agreements. We continue to make progress with licensees executing agreements based on the new China terms and with several other licensees informing us that they intend to retain the terms of their existing agreements. Negotiations with certain other licensees and unlicensed companies are ongoing, and we expect it will take some time to conclude these negotiations. We believe that the conclusion of new agreements with these licensees will result in improved reporting by these licensees, including with respect to sales of three-mode devices (i.e., devices that implement GSM, TD-SCDMA and LTE-TDD) sold in China. However, litigation and/or other actions may be necessary to compel licensees to report and pay the required royalties for sales they have not previously reported and to compel unlicensed companies to execute new licenses. |

[0001234452-15-000271:mdna:36]
| • | We continue to invest significant resources toward advancements in 3G, 3G/4G multimode and 4G LTE technologies, OFDM-based WLAN technologies, audio and video codecs, wireless baseband chips, our converged computing/communications (Snapdragon) chips, graphics, connectivity, multimedia products, software and services. We are also investing in targeted opportunities that utilize our existing technical and business expertise to deploy new business models and enter into new industry segments, such as products for the connected home and the Internet of Things; automotive; networking; mobile computing; small cells and addressing the challenge of meeting the increased demand for data; very high speed connectivity; data centers; mobile health; wireless charging; and machine learning, including robotics. |

[0001234452-15-000271:mdna:37]
| • | We expect that the increased availability of low-tier 3G/4G smartphone products will help enable further expansion of 3G and 3G/4G multimode in emerging regions, particularly in China. |

[0001234452-15-000271:mdna:38]
| • | We expect that 3G/4G device prices will continue to vary broadly due to the increased penetration of smartphones combined with competition throughout the world at all price tiers. Additionally, varying rates of economic growth by region and stronger growth of device shipments in emerging regions as compared to developed regions, are expected to continue to impact the average and range of selling prices of 3G/4G devices. |

[0001234452-15-000271:mdna:39]
| • | In the fourth quarter of fiscal 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders. The core elements of this plan include: (a) right-sizing our cost structure; (b) reviewing alternatives to our corporate and financial structure; (c) reaffirming our plan to return significant capital to stockholders; (d) adding new Directors with complementary skills while reducing the average tenure of our Board of Directors; (e) further aligning executive compensation with performance and stockholder return objectives; and (f) making disciplined investments in areas that build upon our core technologies and capabilities and offer attractive growth opportunities and returns. |

[0001234452-15-000271:mdna:40]
| • | In order to right-size our cost structure, we are planning to reduce our annual costs from fiscal 2015 levels (adjusted for variable compensation) of $7.3 billion (as announced on July 22, 2015) by approximately $1.1 billion through a series of targeted reductions across Qualcomm’s businesses, particularly in QCT. We also plan to reduce annual share-based compensation grants by approximately $300 million. We expect these cost reduction initiatives to be fully implemented by the end of fiscal 2016. In connection with this plan, we expect to incur approximately $350 million to $450 million in restructuring and restructuring-related charges, of which $190 million were incurred in the fourth quarter of fiscal 2015. Restructuring and restructuring-related charges include severance costs, asset impairment charges, consultancy fees, lease termination costs, acceleration of depreciation and other costs. |

[0001234452-15-000271:mdna:41]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless value chain and governments as to the benefits of our business model and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not

[0001234452-15-000271:mdna:42]
35

[0001234452-15-000271:mdna:43]
welcome the success of our business model in enabling new, highly cost-effective competitors to their products. We expect that such companies and/or governments or regulators will continue to challenge our business model in various forums throughout the world.

[0001234452-15-000271:mdna:44]
Further discussion of risks related to our business is presented in the Risk Factors included in this Annual Report.

[0001234452-15-000271:mdna:45]
Critical Accounting Estimates

[0001234452-15-000271:mdna:46]
The preparation of our consolidated financial statements in accordance with accounting principles generally accepted in the United States requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and disclosure of contingent assets and liabilities. We base our estimates on historical and anticipated results and trends and on various other assumptions that we believe are reasonable under the circumstances, including assumptions as to future events. By their nature, estimates are subject to an inherent degree of uncertainty. Although we believe that our estimates and the assumptions supporting our assessments are reasonable, actual results that differ from our estimates could be material to our consolidated financial statements. A summary of our significant accounting policies is included in this Annual Report in “Notes to Consolidated Financial Statements, Note 1. The Company and Its Significant Accounting Policies.” We consider the following accounting estimates to be critical in the preparation of our consolidated financial statements.

[0001234452-15-000271:mdna:47]
Impairment of Marketable Securities. We hold investments in marketable securities, with increases and decreases in fair value generally recorded through stockholders’ equity as other comprehensive income or loss. We record impairment charges through the statement of operations when we believe an investment has experienced a decline that is other than temporary. The determination that a decline is other than temporary is subjective and influenced by many factors. Adverse changes in market conditions or poor operating results of investees could result in losses or an inability to recover the carrying value of the investments, thereby requiring recognition of impairment losses. When assessing these investments for an other-than-temporary decline in value, we consider such factors as, among other things, the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; how long the market value of the security has been less than its cost basis; the security’s relative performance versus its peers, sector or asset class; expected market volatility; the market and economy in general; analyst recommendations and price targets; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates, as applicable. If we determine that a security price decline is other than temporary, we record an impairment loss, which could have an adverse impact on our results of operations. During fiscal 2015, 2014 and 2013, we recorded $163 million, $156 million and $72 million, respectively, in impairment losses on our investments in marketable securities.

[0001234452-15-000271:mdna:48]
Valuation of Inventories. Inventories are valued at the lower of cost or market (replacement cost, not to exceed net realizable value) using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers, among other things. This valuation also requires us to make judgments and assumptions based on information currently available about market conditions, including competition, product pricing, product life cycle and development plans. If we overestimate demand for our products, the amount of our loss will be impacted by our contractual ability to reduce inventory purchases from our suppliers. Our assumptions of future product demand are inherently uncertain, and changes in our estimates and assumptions may cause us to realize material write-downs in the future.

[0001234452-15-000271:mdna:49]
Valuation of Goodwill and Other Indefinite-Lived and Long-Lived Assets. Our business acquisitions typically result in the recording of goodwill, other intangible assets and property, plant and equipment, and the recorded values of those assets may become impaired in the future. We also acquire intangible assets and property, plant and equipment in other types of transactions. The determination of the recorded value of intangible assets acquired in a business combination requires management to make estimates and assumptions that affect our consolidated financial statements. For intangible assets acquired in a non-monetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value. An estimate of fair value can be affected by many assumptions that require significant judgment. For example, the income approach generally requires us to use assumptions to estimate future cash flows including those related to total addressable market, pricing and share forecasts, competition, technology obsolescence, future tax rates and discount rates. Our estimate of the fair value of certain assets may differ materially from that determined by others who use different assumptions or utilize different business models.

[0001234452-15-000271:mdna:50]
Goodwill and other indefinite-lived intangible assets are tested annually for impairment and in interim periods if certain events occur indicating that the carrying amounts may be impaired. Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Our judgments regarding the existence of impairment indicators and future cash flows related to goodwill and other indefinite-lived intangible assets and long-lived assets may be based on operational performance of our businesses, market conditions, expected selling price and/or other factors. Although there are inherent uncertainties in this assessment process, the estimates and assumptions we use, including estimates of future cash flows and discount rates, are consistent with our internal planning, when appropriate. If these estimates or their related assumptions change in the future, we may be required to record an impairment charge on a portion or all of our goodwill, other indefinite-lived intangible assets and/or long-lived assets. Furthermore, we cannot predict the occurrence of future impairment-triggering events nor the impact such events might have on our reported asset values. Future events could cause us to conclude that impairment indicators exist and that goodwill or other intangible assets associated with our acquired businesses are impaired. Any resulting impairment loss could have an adverse impact on our financial position and results of operations. During fiscal 2015, 2014 and 2013, we recorded $317 million, $642 million and $192 million, respectively, in impairment charges for goodwill, other indefinite-lived intangible assets and long-lived assets. The estimated fair values of our QCT and QTL reporting units were substantially in excess of their respective carrying values at September 27, 2015.

[0001234452-15-000271:mdna:51]
Legal Proceedings. We are currently involved in certain legal proceedings, and we intend to continue to vigorously defend ourselves. However, the unfavorable resolution of one or more of these proceedings could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. A broad range of remedies with respect to our business practices that are deemed to violate applicable laws are potentially available. These remedies may include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or to modify our business practices. We disclose a loss contingency if there is at least a reasonable possibility that a material loss has been incurred. We record our best estimate of a loss related to pending legal proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, we record the minimum estimated liability. As additional information becomes available, we assess the potential liability, including the probability of loss related to pending legal proceedings, and revise our estimates and update our disclosures accordingly. Significant judgment is required in both the determination of probability and the determination as to whether a loss is reasonably estimable. Revisions in our estimates of the potential liability could materially impact our results of operations.

[0001234452-15-000271:mdna:52]
Income Taxes. We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgments and estimates are required in determining our provision for income taxes, including those related to tax incentives, intercompany research and development cost-sharing arrangements, transfer pricing and tax credits. In addition, the calculation of our tax liabilities involves uncertainties in the application of complex tax regulations. While we believe we have appropriate support for the positions taken on our tax returns, we regularly assess the potential outcomes of examinations by taxing authorities in determining the adequacy of our provision for income taxes. We are participating in the Internal Revenue Service (IRS) Compliance Assurance Process program whereby we endeavor to agree with the IRS on the treatment of all issues prior to filing our federal return. A benefit of participation in this program is that post-filing adjustments by the IRS are less likely to occur.

[0001234452-15-000271:mdna:53]
Our QCT segment’s non-United States headquarters is located in Singapore. We obtained tax incentives in Singapore that commenced in March 2012, including a tax exemption for the first five years, provided that we meet specified employment and incentive criteria, and as a result of expiration of these incentives, our Singapore tax rate will increase in fiscal 2017 and again in fiscal 2027. Our failure to meet these criteria could adversely impact our provision for income taxes.

[0001234452-15-000271:mdna:54]
We consider the operating earnings of certain non-United States subsidiaries to be indefinitely reinvested outside the United States based on our plans for use and/or investment outside of the United States and our belief that our sources of cash and liquidity in the United States will be sufficient to meet future domestic cash needs. On a regular basis, we consider projected cash needs for, among other things, investments in our existing businesses, future research and development, potential acquisitions and capital transactions, including repurchases of our common stock, dividends and debt repayments. We estimate the amount of cash or other liquidity that is available or needed in the jurisdictions where these investments are expected as well as our ability to generate cash in those jurisdictions and our access to capital markets. This analysis enables us to conclude whether or not we will indefinitely reinvest the current period’s foreign earnings. We have not recorded a deferred tax liability of approximately $10.2 billion related to the United States federal and state income taxes and foreign withholding taxes on approximately $28.8 billion of undistributed earnings of certain non-United States subsidiaries indefinitely reinvested outside the United States. Should we decide to no longer indefinitely reinvest such earnings outside the United States, for example, if we determine that such earnings are needed to fund future domestic operations or there is

[0001234452-15-000271:mdna:55]
37

[0001234452-15-000271:mdna:56]
not a sufficient need for such earnings outside of the United States, we would have to adjust the income tax provision in the period we make such determination.

[0001234452-15-000271:mdna:57]
Results of Operations

[0001234452-15-000271:mdna:58]
| Revenues (in millions) | Year Ended |  |  |  |  |
|  | September 27, 2015 |  | September 28, 2014 |  | September 29, 2013 |  | 2015 vs. 2014 Change |  | 2014 vs. 2013 Change |
| Equipment and services | $ | 17,079 |  |  | $ | 18,625 |  |  | $ | 16,988 |  |  | $ | (1,546 | ) |  | $ | 1,637 |  |
| Licensing | 8,202 |  |  | 7,862 |  |  | 7,878 |  |  | 340 |  |  | (16 | ) |
|  | $ | 25,281 |  |  | $ | 26,487 |  |  | $ | 24,866 |  |  | $ | (1,206 | ) |  | $ | 1,621 |  |

[0001234452-15-000271:mdna:59]
The decrease and increase in equipment and services revenues in fiscal 2015 and 2014, respectively, were primarily due to a decrease and an increase in QCT revenues of $1.49 billion and $1.94 billion, respectively. The increase in equipment and services revenues in fiscal 2014 was partially offset by a decrease of $305 million as a result of the sale of our Omnitracs division during fiscal 2014. The increase in our licensing revenues in fiscal 2015 was primarily due to an increase in QTL revenues of $378 million. The decrease in our licensing revenues in fiscal 2014 was primarily due to a decrease in a nonreportable segment’s revenues of $32 million, partially offset by an increase in QTL revenues of $15 million.

[0001234452-15-000271:mdna:60]
QCT and QTL segment revenues related to the products of Samsung Electronics and Hon Hai Precision Industry Co., Ltd/Foxconn, its affiliates and other suppliers to Apple Inc. comprised 45%, 49% and 43% of total consolidated revenues in fiscal 2015, 2014 and 2013, respectively.

[0001234452-15-000271:mdna:61]
Revenues from customers in China, South Korea and Taiwan comprised 53%, 16% and 13%, respectively, of total consolidated revenues for fiscal 2015, compared to 50%, 23% and 11%, respectively, for fiscal 2014, and 49%, 20% and 11%, respectively, for fiscal 2013. We report revenues from external customers by country based on the location to which our products or services are delivered, which for QCT is generally the country in which our customers manufacture their products, or for licensing revenues, the invoiced addresses of our licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues would include revenues related to shipments of integrated circuits to a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States.

[0001234452-15-000271:mdna:62]
| Costs and Expenses (in millions) | Year Ended |  |  |  |  |
|  | September 27, 2015 |  | September 28, 2014 |  | September 29, 2013 |  | 2015 vs. 2014 Change |  | 2014 vs. 2013 Change |
| Cost of equipment and services (E&S) revenues | $ | 10,378 |  |  | $ | 10,686 |  |  | $ | 9,820 |  |  | $ | (308 | ) |  | $ | 866 |  |
| Cost as % of E&S revenues | 61 | % |  | 57 | % |  | 58 | % |  |  |  |  |

[0001234452-15-000271:mdna:63]
The decrease in margin percentage in fiscal 2015 was primarily attributable to a decrease in QCT gross margin percentage. The increase in margin percentage in fiscal 2014 was primarily attributable to a net decrease in gross margin losses incurred by our nonreportable segments, partially offset by a decrease in QCT’s gross margin percentage. Our margin percentage may continue to fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors.

[0001234452-15-000271:mdna:64]
|  | Year Ended |  |  |  |  |
|  | September 27, 2015 |  | September 28, 2014 |  | September 29, 2013 |  | 2015 vs. 2014 Change |  | 2014 vs. 2013 Change |
| Research and development | $ | 5,490 |  |  | $ | 5,477 |  |  | $ | 4,967 |  |  | $ | 13 |  |  | $ | 510 |  |
| % of revenues | 22 | % |  | 21 | % |  | 20 | % |  |  |  |  |
| Selling, general, and administrative | $ | 2,344 |  |  | $ | 2,290 |  |  | $ | 2,518 |  |  | $ | 54 |  |  | $ | (228 | ) |
| % of revenues | 9 | % |  | 9 | % |  | 10 | % |  |  |  |  |
| Other | $ | 1,293 |  |  | $ | 484 |  |  | $ | 331 |  |  | $ | 809 |  |  | $ | 153 |  |

[0001234452-15-000271:mdna:65]
The dollar increases in research and development expenses in fiscal 2015 and 2014 were primarily attributable to increases of $117 million and $498 million, respectively, in costs related to the development of CDMA-based 3G, OFDMA-

[0001234452-15-000271:mdna:66]
based 4G LTE and other technologies for integrated circuit products, including small cell and data center products, and to expand our intellectual property portfolio. The increase in fiscal 2015 was partially offset by a decrease of $72 million related to the development costs of display technologies and additional decreases related to the development costs of other new product and licensing initiatives.

[0001234452-15-000271:mdna:67]
The dollar increase in selling, general and administrative expenses in fiscal 2015 was primarily attributable to increases of $73 million in selling and marketing expenses and $46 million in costs related to litigation and other legal matters, partially offset by decreases of $49 million in employee-related expenses and $13 million in share-based compensation. The dollar decrease in selling, general and administrative expenses in fiscal 2014 was primarily attributable to decreases of $59 million in costs related to litigation and other legal matters, $53 million in share-based compensation, $53 million in selling and marketing expenses and $22 million in employee-related expenses. The decrease in employee-related expenses and a portion of the decrease in share-based compensation in fiscal 2014 were due to the sale of our Omnitracs division during fiscal 2014.

[0001234452-15-000271:mdna:68]
Other expenses in fiscal 2015 were attributable to a $975 million charge resulting from the resolution reached with the NDRC, charges of $255 million and $11 million for impairment of goodwill and intangible assets, respectively, related to our content and push-to-talk services and display businesses and $190 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan, partially offset by $138 million in gains on sales of certain property plant and equipment. Other expenses in fiscal 2014 were comprised of $607 million in certain property, plant and equipment and goodwill impairment charges and $19 million in restructuring-related costs incurred by one of our display businesses, a $16 million goodwill impairment charge related to our former QRS (Qualcomm Retail Solutions) division and a $15 million legal settlement, partially offset by the reversal of a $173 million expense accrual recorded in fiscal 2013 related to the ParkerVision verdict against us, which was overturned. Other expenses in fiscal 2013 were comprised of the $173 million ParkerVision charge and a $158 million impairment charge related to certain long-lived assets of one our display businesses.

[0001234452-15-000271:mdna:69]
| Interest Expense and Net Investment Income (in millions) |  |  |  |  |  |  |
|  | Year Ended |  |  |  |  |
|  | September 27, 2015 |  | September 28, 2014 |  | September 29, 2013 |  | 2015 vs. 2014 Change |  | 2014 vs. 2013 Change |
| Interest expense | $ | 104 |  |  | $ | 5 |  |  | $ | 23 |  |  | $ | 99 |  |  | $ | (18 | ) |
| Investment income, net |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 527 |  |  | $ | 586 |  |  | $ | 697 |  |  | $ | (59 | ) |  | $ | (111 | ) |
| Net realized gains on marketable securities | 451 |  |  | 770 |  |  | 317 |  |  | (319 | ) |  | 453 |  |
| Net realized gains on other investments | 49 |  |  | 56 |  |  | 52 |  |  | (7 | ) |  | 4 |  |
| Impairment losses on marketable securities and other investments | (200 | ) |  | (180 | ) |  | (85 | ) |  | (20 | ) |  | (95 | ) |
| Other | (12 | ) |  | 1 |  |  | 6 |  |  | (13 | ) |  | (5 | ) |
|  | $ | 815 |  |  | $ | 1,233 |  |  | $ | 987 |  |  | $ | (418 | ) |  | $ | 246 |  |

[0001234452-15-000271:mdna:70]
The increase in interest expense in fiscal 2015 was primarily due to the issuance of an aggregate principal amount of $10.0 billion in floating- and fixed-rate notes in May 2015. Due to portfolio rebalancing in fiscal 2014 and 2015, we earned lower interest and dividend income on cash and cash equivalents and recorded lower realized gains on marketable securities balances in fiscal 2015. We expect to earn lower interest and dividend income and record lower realized gains in fiscal 2016 as a result of our rebalancing, among other factors.

[0001234452-15-000271:mdna:71]
In fiscal 2014, we rebalanced our marketable securities portfolio, which resulted in lower interest and dividend income, due to lower interest rates, and higher net realized gains on marketable securities, compared to fiscal 2013. The increase in impairment losses on marketable securities and other investments in fiscal 2014 was primarily due to an increase in our recognition of unrealized losses on marketable debt securities that we intended to sell or that we more likely than not would

[0001234452-15-000271:mdna:72]
39

[0001234452-15-000271:mdna:73]
sell before recovery, which was also impacted by our portfolio rebalancing.

[0001234452-15-000271:mdna:74]
| Income Tax Expense (in millions) | Year Ended |  |  |  |  |
|  | September 27, 2015 |  | September 28, 2014 |  | September 29, 2013 |  | 2015 vs. 2014 Change |  | 2014 vs. 2013 Change |
| Income tax expense | $ | 1,219 |  |  | $ | 1,244 |  |  | $ | 1,349 |  |  | $ | (25 | ) |  | $ | (105 | ) |
| Effective tax rate | 19 | % |  | 14 | % |  | 16 | % |  | 5 | % |  | (2 | %) |

[0001234452-15-000271:mdna:75]
The following table summarizes the primary factors that caused our annual effective tax rates to be less than the United States federal statutory rate:

[0001234452-15-000271:mdna:76]
|  | Year Ended |
|  | September 27, 2015 |  | September 28, 2014 |  | September 29, 2013 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (14 | %) |  | (20 | %) |  | (17 | %) |
| Benefits related to the research and development tax credits | (2 | %) |  | (1 | %) |  | (2 | %) |
| Effective tax rate | 19 | % |  | 14 | % |  | 16 | % |

[0001234452-15-000271:mdna:77]
During fiscal 2015, the NDRC imposed a fine of $975 million, which was not deductible for tax purposes and was substantially attributable to a foreign jurisdiction. Additionally, during fiscal 2015, we recorded a tax benefit of $101 million related to fiscal 2014 resulting from the United States government reinstating the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. The effective tax rate for fiscal 2015 also reflected the United States federal research and development tax credit generated through December 31, 2014, the date on which the credit expired, and a $61 million tax benefit as a result of a favorable tax audit settlement with the Internal Revenue Service related to Qualcomm Atheros, Inc.’s pre-acquisition 2010 and 2011 tax returns. The effective tax rate for our state income tax provision, net of federal benefit, was negligible for all years presented.

[0001234452-15-000271:mdna:78]
The annual effective tax rate for fiscal 2014 reflected the tax benefit from the United States federal research and development tax credit generated through December 31, 2013, the date on which the credit previously expired. The effective tax rate for fiscal 2014 also reflected a tax benefit of $66 million related to fiscal 2013 resulting from an agreement reached with the Internal Revenue Service on components of our fiscal 2013 tax return. Additionally, the effective tax rate for fiscal 2014 as compared to fiscal 2013 reflected increased foreign earnings taxed at less than the United States federal rate. The effective tax rate for fiscal 2013 reflected a tax benefit of $64 million related to fiscal 2012 resulting from the retroactive extension of the United States federal research and development tax credit.

[0001234452-15-000271:mdna:79]
Our Segment Results

[0001234452-15-000271:mdna:80]
The following should be read in conjunction with the fiscal 2015, 2014 and 2013 financial results for each reportable segment included in this Annual Report in “Notes to Consolidated Financial Statements, Note 8. Segment Information.”

[0001234452-15-000271:mdna:81]
| (in millions) | QCT |  | QTL |  | QSI |
| 2015 |  |  |  |  |  |
| Revenues | $ | 17,154 |  |  | $ | 7,947 |  |  | $ | 4 |  |
| EBT (1) | 2,465 |  |  | 6,882 |  |  | (74 | ) |
| EBT as a % of revenues | 14 | % |  | 87 | % |  |  |
| 2014 |  |  |  |  |  |
| Revenues | $ | 18,665 |  |  | $ | 7,569 |  |  | $ | — |  |
| EBT (1) | 3,807 |  |  | 6,590 |  |  | (7 | ) |
| EBT as a % of revenues | 20 | % |  | 87 | % |  |  |
| 2013 |  |  |  |  |  |
| Revenues | $ | 16,715 |  |  | $ | 7,554 |  |  | $ | — |  |
| EBT (1) | 3,189 |  |  | 6,590 |  |  | 56 |  |
| EBT as a % of revenues | 19 | % |  | 87 | % |  |  |

[0001234452-15-000271:mdna:82]
| (1) | Earnings (loss) before taxes. |

[0001234452-15-000271:mdna:83]
QCT Segment. QCT results of operations in fiscal 2015 were negatively impacted by the effects of a shift in share among our customers within the premium tier, which reduced our sales of integrated Snapdragon processors and skewed our product mix towards lower-margin modem chipsets in this tier, a decline in share at a large customer and the competitive environment in China. The decrease and increase in QCT revenues in fiscal 2015 and 2014 of $1.51 billion and $1.95 billion, respectively, were primarily due to changes in equipment and services revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying RF and PM integrated circuits, were $16.95 billion, $18.43 billion and $16.49 billion in fiscal 2015, 2014 and 2013, respectively. The decrease in equipment and services revenues in fiscal 2015 resulted primarily from a decrease of $2.89 billion from lower-priced product mix and lower average selling prices, partially offset by an increase of $1.26 billion related to higher MSM and accompanying RF and PM unit shipments. The increase in equipment and services revenues in 2014 resulted primarily from increases of $2.66 billion related to higher MSM and accompanying RF and PM unit shipments and $203 million related to sales of connectivity products, partially offset by a net decrease of $1.08 billion resulting from lower average selling prices offset by higher-priced product mix. Approximately 932 million, 861 million and 716 million MSM integrated circuits were sold during fiscal 2015, 2014 and 2013, respectively.

[0001234452-15-000271:mdna:84]
QCT EBT as a percentage of revenues decreased in fiscal 2015 as compared to fiscal 2014 primarily due to decreases in gross margin percentage and the related impact of lower revenues relative to operating expenses. The decrease in QCT gross margin percentage in fiscal 2015 primarily resulted from lower average selling prices and lower-margin product mix, partially offset by lower average unit costs. QCT gross margin percentage in fiscal 2015 was also impacted by an increase of $179 million in excess inventory charges. QCT EBT as a percentage of revenues increased in fiscal 2014 as compared to fiscal 2013. During fiscal 2014, QCT revenues increased 12% relative to a combined increase of 5% in research and development expenses and selling, general and administrative expenses, whereas gross margin percentage decreased as a result of lower average selling prices and lower-margin product mix, partially offset by lower average unit costs.

[0001234452-15-000271:mdna:85]
QTL Segment. The increases in QTL revenues in fiscal 2015 and 2014 of $378 million and $15 million, respectively, were primarily due to increases in sales of CDMA-based products, including multimode products that also implement OFDMA, reported by licensees, partially offset by decreases in revenues per reported unit. QTL revenues and EBT in fiscal 2015 continued to be impacted negatively by units that we believe are not being reported by certain licensees and sales of certain unlicensed products in China. We expect it will take some time for those certain licensees to fully comply with the reporting requirements of their license agreements and for unlicensed companies that had delayed execution of new licenses pending resolution of the NDRC investigation to execute new licenses. Also in fiscal 2015, QTL experienced negative fluctuations in foreign currency exchange rates. QTL revenues and EBT for fiscal 2014 were impacted by units that we believe were being underreported by certain licensees, a dispute with a licensee and sales of certain unlicensed products in China.

[0001234452-15-000271:mdna:86]
QSI Segment. The decrease in QSI EBT in fiscal 2015 of $67 million was primarily due to increases of $32 million in impairment losses on investments and $29 million in equity losses and other costs related to our equity method investments. The decrease in QSI EBT in fiscal 2014 of $63 million was primarily due to a $39 million decrease in net realized gains on investments and a $35 million increase in impairment losses on investments, partially offset by a $16 million decrease in interest expense related to our former subsidiaries that held Broadband Wireless Access spectrum in India.

[0001234452-15-000271:mdna:87]
Liquidity and Capital Resources

[0001234452-15-000271:mdna:88]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. The following table presents selected financial information related to our liquidity as of and for the years ended September 27, 2015 and September 28, 2014 (in millions):

[0001234452-15-000271:mdna:89]
41

[0001234452-15-000271:mdna:90]
|  | 2015 |  | 2014 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 30,947 |  |  | $ | 32,022 |  |  | $ | (1,075 | ) |  | (3 | %) |
| Accounts receivable, net | 1,964 |  |  | 2,412 |  |  | (448 | ) |  | (19 | %) |
| Inventories | 1,492 |  |  | 1,458 |  |  | 34 |  |  | 2 | % |
| Short-term debt | 1,000 |  |  | — |  |  | 1,000 |  |  |  |
| Long-term debt | 9,969 |  |  | — |  |  | 9,969 |  |  |  |
| Net cash provided by operating activities | 5,506 |  |  | 8,887 |  |  | (3,381 | ) |  | (38 | %) |
| Net cash used by investing activities | (3,572 | ) |  | (1,639 | ) |  | (1,933 | ) |  |  |
| Net cash used by financing activities | (2,261 | ) |  | (5,480 | ) |  | 3,219 |  |  |  |

[0001234452-15-000271:mdna:91]
The net decrease in cash, cash equivalents and marketable securities was primarily the result of $11.2 billion in payments to repurchase shares of our common stock, including the $5.0 billion accelerated share repurchase agreements, partially offset by $9.9 billion in proceeds from the issuance of notes and net cash provided by operating activities. Total cash provided by operating activities decreased primarily due to a reduction in net income of $2.7 billion and prepayment of $950 million to secure long-term capacity commitments at a supplier of our integrated circuit products. The decrease in accounts receivable was primarily due to lower revenues related to sales of integrated circuits, partially offset by the timing of payments from certain of our licensees. Our day sales outstanding, on a consolidated basis, increased to 33 days at September 27, 2015 compared to 32 days at September 28, 2014, primarily due to the timing of cash payments from certain of our licensees, partially offset by the timing of customer payments for receivables related to integrated circuits. The increase in inventories was primarily due to increases in work-in-process and finished goods inventories in connection with the CSR acquisition, including a step-up in the fair value of the acquired inventories, partially offset by a decrease in other QCT inventories resulting primarily from lower-cost product mix and lower average unit costs.

[0001234452-15-000271:mdna:92]
We classify certain of our marketable securities as short-term based on their nature and our plan to make them available, if needed, for use in our current operations. While we do not anticipate using our non-current marketable securities in operations in the foreseeable future, the securities could be liquidated within a short period of time if required. Our cash, cash equivalents and marketable securities at September 27, 2015 consisted of $5.3 billion held by United States-based entities and $25.6 billion held by foreign entities. Most of our cash, cash equivalents and marketable securities held by foreign entities are indefinitely reinvested and would be subject to material tax effects if repatriated. However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate the funds.

[0001234452-15-000271:mdna:93]
We believe our current cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements also include the items described below.

[0001234452-15-000271:mdna:94]
| • | In connection with our Strategic Realignment Plan, we expect to incur a total of approximately $350 million to $450 million in restructuring and restructuring-related charges, the majority of which will result in future cash payments. |

[0001234452-15-000271:mdna:95]
| • | Our purchase obligations at September 27, 2015, some of which relate to research and development activities and capital expenditures, totaled $3.0 billion and $953 million for fiscal 2016 and 2017, respectively, and $1.6 billion thereafter. |

[0001234452-15-000271:mdna:96]
| • | Our research and development expenditures were $5.5 billion during fiscal 2015 and 2014, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications, primarily in the wireless industry. |

[0001234452-15-000271:mdna:97]
| • | Cash outflows for capital expenditures were $994 million and $1.2 billion during fiscal 2015 and 2014, respectively. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-15-000271:mdna:98]
| • | We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly, to open new opportunities for our technologies, obtain development resources, grow our patent portfolio or pursue new businesses. |

[0001234452-15-000271:mdna:99]
Debt. In February 2015, we entered into a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. At September 27, 2015, no amounts were outstanding under the Revolving Credit Facility.

[0001234452-15-000271:mdna:100]
In March 2015, we began an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At September 27, 2015, we had $1.0 billion of commercial paper outstanding with weighted-average net interest rates of 0.19% and weighted-average remaining days to maturity of 38 days.

[0001234452-15-000271:mdna:101]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, with maturity dates in 2018 through 2045 and effective interest rates between 0.43% and 4.74%. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Net proceeds from the issuance of the notes of $9.9 billion were used to fund two accelerated share repurchase agreements and are being used for other general corporate purposes. We may issue additional debt in the future. The amount and timing of additional borrowings will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001234452-15-000271:mdna:102]
Additional information regarding our outstanding debt at September 27, 2015 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 6. Debt.”

[0001234452-15-000271:mdna:103]
Capital Return Program. The following table summarizes stock repurchases and dividends paid during fiscal 2015, 2014 and 2013 (in millions, except per-share amounts):

[0001234452-15-000271:mdna:104]
|  |  | Stock Repurchase Program |  | Dividends |  | Total |
|  |  | Shares |  | Average Price Paid Per Share |  | Amount |  | Per Share |  | Amount |  | Amount |
| 2015 |  | 172.4 |  |  | $ | 65.21 |  |  | $ | 11,245 |  |  | $ | 1.80 |  |  | $ | 2,880 |  |  | $ | 14,125 |  |
| 2014 |  | 60.3 |  |  | 75.48 |  |  | 4,548 |  |  | 1.54 |  |  | 2,586 |  |  | 7,134 |  |
| 2013 |  | 71.7 |  |  | 64.28 |  |  | 4,609 |  |  | 1.20 |  |  | 2,055 |  |  | 6,664 |  |

[0001234452-15-000271:mdna:105]
We intend to return a minimum of 75% of our free cash flow to stockholders through stock repurchases and dividends over the foreseeable future, where free cash flow is defined as net cash provided by operating activities less capital expenditures. On March 9, 2015, we announced that we had been authorized to repurchase up to $15 billion of our common stock. Additionally, we announced our intention to repurchase $10 billion of stock from March 2015 through March 2016. In May 2015, we entered into two accelerated share repurchase agreements (ASR Agreements) to repurchase an aggregate of $5.0 billion of our common stock. During the fourth quarter of fiscal 2015, the ASR Agreements were completed, and a total of 78.3 million shares were delivered to us under the ASR Agreements based on the combined volume-weighted average stock price over the terms of the ASR agreements. At September 27, 2015, $6.9 billion remained authorized for repurchase under our stock repurchase program. To meet our remaining goal, we expect to use existing cash and marketable securities (which include the proceeds from the May 2015 debt offering) held by, and cash flow generated from, United States-based entities. Since September 27, 2015, we repurchased and retired 24.6 million shares of common stock for $1.4 billion. We periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders.

[0001234452-15-000271:mdna:106]
On October 9, 2015, we announced a cash dividend of $0.48 per share on our common stock, payable on December 18, 2015 to stockholders of record as of the close of business on December 1, 2015. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-15-000271:mdna:107]
Contractual Obligations/Off-Balance Sheet Arrangements

[0001234452-15-000271:mdna:108]
We have no significant contractual obligations not fully recorded on our consolidated balance sheets or fully disclosed in the notes to our consolidated financial statements. We have no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001234452-15-000271:mdna:109]
The following table summarizes the payments due by fiscal period for our outstanding contractual obligations at September 27, 2015 (in millions):

[0001234452-15-000271:mdna:110]
|  | Total |  | 2016 |  | 2017-2018 |  | 2019-2020 |  | Beyond2020 |  | NoExpirationDate |
| Purchase obligations (1) | $ | 5,601 |  |  | $ | 3,017 |  |  | $ | 1,695 |  |  | $ | 880 |  |  | $ | 9 |  |  | $ | — |  |
| Operating lease obligations | 281 |  |  | 99 |  |  | 114 |  |  | 44 |  |  | 24 |  |  | — |  |
| Equity funding and financing commitments (2) | 132 |  |  | 82 |  |  | 32 |  |  | — |  |  | 15 |  |  | 3 |  |
| Long-term debt | 10,000 |  |  | — |  |  | 1,500 |  |  | 2,000 |  |  | 6,500 |  |  | — |  |
| Other long-term liabilities (3)(4) | 246 |  |  | 2 |  |  | 124 |  |  | 110 |  |  | 5 |  |  | 5 |  |
| Total contractual obligations | $ | 16,260 |  |  | $ | 3,200 |  |  | $ | 3,465 |  |  | $ | 3,034 |  |  | $ | 6,553 |  |  | $ | 8 |  |

[0001234452-15-000271:mdna:111]
| (1) | Total purchase obligations include commitments to purchase integrated circuit product inventories of $2.5 billion, $787 million, $706 million, $680 million and $166 million for each of the subsequent five years from fiscal 2016 through 2020, respectively; there were no such purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancelation of outstanding purchase orders is generally allowed but requires payment of all costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization. |

[0001234452-15-000271:mdna:112]
| (2) | Certain of these commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all. |

[0001234452-15-000271:mdna:113]
| (3) | Certain long-term liabilities reflected on our balance sheet, such as unearned revenues, are not presented in this table because they do not require cash settlement in the future. Other long-term liabilities as presented in this table include the related current portions. |

[0001234452-15-000271:mdna:114]
| (4) | Our consolidated balance sheet at September 27, 2015 included $23 million in noncurrent liabilities for uncertain tax positions, some of which may result in cash payment. The future payments related to uncertain tax positions have not been presented in the table above due to the uncertainty of the amounts and timing of cash settlement with the taxing authorities. |

[0001234452-15-000271:mdna:115]
Additional information regarding our financial commitments at September 27, 2015 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 3. Income Taxes,” “Note 6. Debt” and “Note 7. Commitments and Contingencies.”

[0001234452-15-000271:mdna:116]
Recent Accounting Pronouncements

[0001234452-15-000271:mdna:117]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. This ASU, as amended, will be effective for us starting in the first quarter of fiscal 2019. The FASB will also permit entities to adopt one year earlier if they choose. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. We do not intend to adopt the standard early and are in the process of determining the adoption method as well as the effects the adoption will have on our consolidated financial statements.

[0001234452-15-000271:mdna:118]
Non-GAAP Financial Information

[0001234452-15-000271:mdna:119]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations includes references to free cash flow and return of capital to stockholders as a percentage of free cash flow. These are financial measures that were not prepared in accordance with GAAP. We define “free cash flow” as net cash provided by operating activities less capital expenditures and “return of capital to stockholders” as cash paid to repurchase shares of our common stock and cash dividends paid.

[0001234452-15-000271:mdna:120]
The non-GAAP financial information presented should be considered in addition to, not as a substitute for, or superior to, financial measures calculated in accordance with GAAP. In addition, “non-GAAP” is not a term defined by GAAP, and as a result, our measure of non-GAAP results might be different than similarly titled measures used by other companies.

[0001234452-15-000271:mdna:121]
44

[0001234452-15-000271:mdna:122]
We use free cash flow to facilitate an understanding of the amount of cash flow generated that is available to grow our business and to create long-term stockholder value. We believe return of capital to stockholders as a percentage of free cash flow provides insight into our cash-generating activities relative to the amount of capital returned to stockholders. These non-GAAP measures are supplemental to the comparable GAAP measures. The following is a reconciliation between GAAP and non-GAAP results for fiscal 2015 (dollars in millions):

[0001234452-15-000271:mdna:123]
| Net cash provided by operating activities (GAAP) | $ | 5,506 |  |
| Capital expenditures | (994 | ) |
| Free cash flow (non-GAAP) | $ | 4,512 |  |
| Cash paid to repurchase shares of our common stock (before commissions) | $ | 11,245 |  |
| Cash dividends paid | 2,880 |  |
| Total return of capital to stockholders | 14,125 |  |
| Less: common stock repurchases related to $10 billion stock repurchase commitment | 8,100 |  |
| Adjusted return of capital, excluding repurchases related to $10 billion stock repurchase commitment | $ | 6,025 |  |
| Total return of capital to stockholders as a percentage of net cash provided by operating activities (GAAP) | 257 | % |
| Total return of capital to stockholders as a percentage of free cash flow (non-GAAP) | 313 | % |
| Adjusted return of capital to stockholders as a percentage of free cash flow (non-GAAP) | 134 | % |
