# QCOM note change history — 0001234452-16-000429 → 0001234452-16-000483


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-07-20):
[0001234452-16-000483:note_history:1]
Commitments and Contingencies
  (was, 2016-04-20, similarity 0.8923):
[0001234452-16-000429:note_history:1]
Note 7. Commitments and Contingencies

- changed (2016-07-20):
[0001234452-16-000483:note_history:2]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringed seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims were invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict and denied ParkerVision’s motions for injunctive relief and ongoing royalties as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit heard the appeal on May 8, 2015 and issued a decision on July 31, 2015. The decision affirmed the District Court’s finding of non-infringement and granted in part the Company’s cross-appeal, holding 10 of the 11 asserted claims invalid. A subsequent Petition for Rehearing by ParkerVision was denied on October 2, 2015. On February 29, 2016, ParkerVision filed a petition for certiorari with the United States Supreme Court asking for review of the Federal Circuit’s decision. On March 28, 2016, the United States Supreme Court denied ParkerVision’s petition. No further appeals are available to ParkerVision in this matter.
  (was, 2016-04-20, similarity 0.9998):
[0001234452-16-000429:note_history:2]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims were invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict and denied ParkerVision’s motions for injunctive relief and ongoing royalties as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit heard the appeal on May 8, 2015 and issued a decision on July 31, 2015. The decision affirmed the District Court’s finding of non-infringement and granted in part the Company’s cross-appeal, holding 10 of the 11 asserted claims invalid. A subsequent Petition for Rehearing by ParkerVision was denied on October 2, 2015. On February 29, 2016, ParkerVision filed a petition for certiorari with the United States Supreme Court asking for review of the Federal Circuit’s decision. On March 28, 2016, the United States Supreme Court denied ParkerVision’s petition. No further appeals are available to ParkerVision in this matter.

- changed (2016-07-20):
[0001234452-16-000483:note_history:3]
On December 14, 2015, ParkerVision filed a third complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. are also named defendants. The complaint asserts four additional patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. The ITC scheduled a hearing to begin on August 24, 2016. The ITC’s target date for completion of the investigation is April 21, 2017. The District Court case was stayed on February 12, 2016 pending completion of the ITC investigation. The Company believes ParkerVision’s claims in the above matters are without merit.
  (was, 2016-04-20, similarity 0.9701):
[0001234452-16-000429:note_history:3]
On December 14, 2015, ParkerVision filed a third complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. are also named defendants. The complaint asserts four additional patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. The ITC scheduled a hearing to begin on August 24, 2016. The ITC’s target date for completion of the investigation is April 21, 2017. The District Court case was stayed on February 12, 2016 pending completion of the ITC investigation.

- added (2016-07-20):
[0001234452-16-000483:note_history:4]
Nvidia Corporation v. QUALCOMM Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd. and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia sought an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chipset products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District Court complaint, Nvidia sought an award of damages for the infringement of the asserted patents, a finding that such infringement was willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. Nvidia later narrowed the ITC case to three asserted patents. On October 9, 2015, the Administrative Law Judge in the ITC case issued an Initial Determination finding no violation of Section 337 because none of the three patents were both valid and infringed. On October 26, 2015, Nvidia filed a petition requesting the ITC to review the Initial Determination as to two of the asserted patents, but was no longer pursuing infringement allegations with respect to the third patent. On December 14, 2015, the ITC issued its decision not to review the Initial Determination of the Administrative Law Judge. This made final the determination that the Company did not violate Section 337. Therefore, neither an exclusion order nor a cease and desist order were issued. On February 17, 2016, Nvidia filed a notice of appeal of the ITC’s determination to the United States Court of Appeals for the Federal Circuit. The District Court case was stayed on October 23, 2014 pending completion of the ITC investigation, including appeals. Nvidia has since entered into a confidential settlement agreement with Samsung and dismissed the above actions against Samsung and the Company, including its appeal of the ITC’s determination (dismissed May 11, 2016) and the District Court case (dismissed May 12, 2016).

- changed (2016-07-20):
[0001234452-16-000483:note_history:5]
LG Electronics, Inc. (LGE) Arbitration: In December 2015, LGE filed an arbitration demand with the International Chamber of Commerce (ICC) alleging that it overpaid royalties on certain CDMA (including WCDMA) subscriber units based on the alleged effect of specific provisions in its license agreement, and that the Company breached its license agreement with LGE, as well as certain implied covenants. The arbitration demand sought determination and return of the overpayment and determination of the ongoing royalties owed by LGE. On April 16, 2016, the parties entered into agreements pursuant to which the parties agreed to settle the disputes raised by LGE in its arbitration demand, and LGE agreed to dismiss the arbitration with prejudice and release all claims brought in the arbitration against the Company. On April 18, 2016, the parties jointly moved for dismissal of the arbitration, and on April 19, 2016, the ICC acknowledged the motion for dismissal and the withdrawal of all claims. Although the Company believed LGE’s claims were without merit, it deferred the recognition of revenue related to CDMA subscriber unit royalties reported and paid by LGE in the first and second quarters of fiscal 2016 because, among other reasons, the matter was submitted to arbitration for resolution. As a result of the settlement, commencing with the third quarter of fiscal 2016, the Company is no longer deferring royalty revenues reported by LGE and recorded $235 million of revenues related to prior periods.
  (was, 2016-04-20, similarity 0.6004):
[0001234452-16-000429:note_history:5]
LG Electronics, Inc. (LGE) Arbitration: In December 2015, LGE filed an arbitration demand with the International Chamber of Commerce (ICC) alleging that it overpaid royalties on certain CDMA (including WCDMA) subscriber units based on the alleged effect of specific provisions in its license agreement, and that the Company breached its license agreement with LGE, as well as certain implied covenants. The arbitration demand sought determination and return of the overpayment and determination of the ongoing royalties owed by LGE. On April 16, 2016, the parties entered into agreements pursuant to which the parties agreed to settle the disputes raised by LGE in its arbitration demand, and LGE agreed to dismiss the arbitration with prejudice and release all claims brought in the arbitration against the Company. Although the Company believed LGE’s claims were without merit, it deferred the recognition of revenue related to CDMA subscriber unit royalties reported and paid by LGE in the first and second quarters of fiscal 2016 because, among other reasons, the matter was submitted to arbitration for resolution. As a result of the settlement, commencing with the third quarter of fiscal 2016, the Company will no longer defer royalty revenues reported by LGE and will record greater than $200 million of revenues that were previously deferred.

- added (2016-07-20):
[0001234452-16-000483:note_history:6]
Blackberry Limited (Blackberry) Arbitration: On April 20, 2016, the Company and Blackberry entered into an agreement to arbitrate Blackberry’s allegation that it overpaid royalties on certain past sales of subscriber units based on the alleged effect of specific provisions in its license agreement. The arbitration, which is scheduled to begin on February 27, 2017, is being conducted under the rules of the Judicial Arbitration and Mediation Services in San Diego, California. Blackberry seeks the return of the alleged overpayment. The Company believes Blackberry’s claims are without merit.

- added (2016-07-20):
[0001234452-16-000483:note_history:7]
3226701 Canada, Inc. v. Qualcomm Incorporated et al. On November 30, 2015, plaintiffs filed a securities class action complaint against the Company and certain of its current and former officers in the United States District Court for the Southern District of California. On April 29, 2016, plaintiffs filed an amended complaint alleging that the Company and certain of its current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding the Company’s business outlook and product development between April 7, 2014 and July 22, 2015. The amended complaint seeks unspecified damages, interest, attorneys’ fees and other costs. On June 28, 2016, the Company filed a Motion to Dismiss. The Company believes the plaintiffs’ claims are without merit.

- added (2016-07-20):
[0001234452-16-000483:note_history:8]
QUALCOMM Incorporated v. Meizu Technology Co., Ltd.: On June 23, 2016 and June 29, 2016, the Company filed a series of actions against Meizu Technology Co., Ltd. et al. (Meizu) in the Intellectual Property Courts in Beijing and Shanghai (China). The first complaint, filed in Beijing on June 23, 2016, requests rulings that the terms of a patent license offered by the Company to Meizu comply with China’s Anti-Monopoly Law and the Company’s applicable fair, reasonable and non-discriminatory licensing commitment. The complaint also seeks a ruling that the offered patent license terms should form the basis for a patent license with Meizu for the Company’s fundamental mobile device technologies patented in China, including those relating to 3G (WCDMA and CDMA2000) and 4G (LTE) wireless communications standards, and seeks damages for Meizu’s past use of the Company’s patented inventions. On June 29, 2016, the Company filed patent infringement complaints in the Intellectual Property Courts in Beijing and Shanghai alleging infringement of 17 patents by Zhuhai Meizu Technology Co., Ltd. et al. (Zhuhai Meizu). The patent infringement actions concern a broad range of features and technologies used in smartphones, including features relating to 3G (WCDMA and CDMA2000) and 4G (LTE) wireless communications standards, and seek to enjoin Zhuhai Meizu from manufacturing, selling and offering for sale mobile devices that infringe the asserted patents. No schedules have yet been set by the courts.

- changed (2016-07-20):
[0001234452-16-000483:note_history:9]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 33 different dates, with the next hearing scheduled for January 17, 2017.
  (was, 2016-04-20, similarity 0.9982):
[0001234452-16-000429:note_history:9]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 32 different dates, with the next hearing scheduled for July 20, 2016.

- changed (2016-07-20):
[0001234452-16-000483:note_history:10]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it is conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On November 13, 2015, the Company received a case Examiner’s Report (ER) prepared by the KFTC’s investigative staff. The ER alleges, among other things, that the Company is in violation of Korean competition law by licensing its patents exhaustively only to device manufacturers and requiring that its chipset customers be licensed to the Company’s intellectual property. The ER also alleges that the Company obtains certain terms, including royalty terms, that are unfair or unreasonable in its license agreements through negotiations that do not conform to Korean competition law. The ER proposes remedies including modifications to certain business practices and monetary penalties. On May 27, 2016, the Company submitted a written response to the ER. The KFTC is holding hearings, which commenced on July 20, 2016. It remains difficult to predict the outcome of this matter. The Company believes that its business practices do not violate the MRFTA. The Company continues to cooperate with the KFTC as it conducts its investigation.
  (was, 2016-04-20, similarity 0.7673):
[0001234452-16-000429:note_history:10]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it is conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On November 13, 2015, the Company received a case Examiner’s Report (ER) prepared by the KFTC’s investigative staff. The ER alleges, among other things, that the Company is in violation of Korean competition law by licensing its patents exhaustively only to device manufacturers and requiring that its chipset customers be licensed to the Company’s intellectual property. The ER also alleges that the Company obtains certain terms, including royalty terms, that are unfair or unreasonable in its license agreements through negotiations that do not conform to Korean competition law. The ER proposes remedies including modifications to certain business practices and monetary penalties. It remains difficult to predict the outcome of this matter. The Company believes that its business practices do not violate the MRFTA. The Company continues to cooperate with the KFTC as it conducts its investigation.

- changed (2016-07-20):
[0001234452-16-000483:note_history:11]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that since 2011 the Company has paid significant amounts to a customer on condition that it exclusively use the Company’s baseband chipsets in its smartphones and tablets. This conduct has allegedly reduced the customer’s incentives to source chipsets from the Company’s competitors and harmed competition and innovation for certain baseband chipsets. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On June 27, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.
  (was, 2016-04-20, similarity 0.7082):
[0001234452-16-000429:note_history:11]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that since 2011 the Company has paid significant amounts to a customer on condition that it exclusively use the Company’s baseband chipsets in its smartphones and tablets. This conduct has allegedly reduced the customer’s incentives to source chipsets from the Company’s competitors and harmed competition and innovation for certain baseband chipsets. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

- added (2016-07-20):
[0001234452-16-000483:note_history:12]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified the Company that it is conducting an investigation into whether the Company’s patent licensing arrangements violate the Taiwan Fair Trade Act (TFTA). On April 27, 2016, the TFTC specified that the allegations under investigation include whether: (i) the Company jointly licensed its patents rather than separately licensing standard-essential patents and non-standard-essential patents; (ii) the Company’s royalty charges are unreasonable; (iii) the Company unreasonably required licensees to grant it cross-licenses; (iv) the Company failed to provide lists of licensed patents to licensees; (v) the Company violated a FRAND licensing commitment by declining to grant licenses to chipset makers; (vi) the Company declined to sell chipsets to unlicensed potential customers; and (vii) the Company provided royalty rebates to certain companies in exchange for their exclusive use of the Company’s chipsets. If a violation is found, a broad range of remedies is potentially available to the TFTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the TFTC. The Company believes that its business practices do not violate the TFTA. The Company continues to cooperate with the TFTC as it conducts its investigation.

- added (2016-07-20):
[0001234452-16-000483:note_history:13]
The Company will continue to vigorously defend itself in the foregoing matters in which it is a defendant and which remain outstanding. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at June 26, 2016 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

- changed (2016-07-20):
[0001234452-16-000483:note_history:14]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company.
  (was, 2016-04-20, similarity 0.8455):
[0001234452-16-000429:note_history:14]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through March 27, 2016, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

- added (2016-07-20):
[0001234452-16-000483:note_history:15]
Through June 26, 2016, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at June 26, 2016 associated with these indemnification arrangements, other than nominal amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- changed (2016-07-20):
[0001234452-16-000483:note_history:16]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at June 26, 2016 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $3.0 billion, $1.2 billion, $782 million, $702 million and $206 million, respectively, and $50 million thereafter. Of these amounts, for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020, commitments to purchase integrated circuit product inventories comprised $2.6 billion, $979 million, $700 million, $647 million and $157 million, respectively, and there were no purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancellation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancellation, and in some cases, incremental fees related to capacity underutilization.
  (was, 2016-04-20, similarity 0.9964):
[0001234452-16-000429:note_history:16]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at March 27, 2016 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $3.1 billion, $1.0 billion, $778 million, $736 million and $221 million, respectively, and $34 million thereafter. Of these amounts, for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020, commitments to purchase integrated circuit product inventories comprised $2.6 billion, $822 million, $704 million, $687 million and $175 million, respectively, and there were no purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancellation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancellation, and in some cases, incremental fees related to capacity underutilization.

- changed (2016-07-20):
[0001234452-16-000483:note_history:17]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments at June 26, 2016 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $23 million, $89 million, $64 million, $50 million and $38 million, respectively, and $90 million thereafter.
  (was, 2016-04-20, similarity 0.9908):
[0001234452-16-000429:note_history:17]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments at March 27, 2016 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $51 million, $43 million, $26 million, $20 million and $19 million, respectively, and $24 million thereafter.

- changed (2016-07-20):
[0001234452-16-000483:note_history:18]
Other Commitments. At June 26, 2016, the Company was committed to fund certain strategic investments up to $316 million. Of this amount, $85 million is expected to be funded in the remainder of fiscal 2016. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.
  (was, 2016-04-20, similarity 0.9883):
[0001234452-16-000429:note_history:18]
Other Commitments. At March 27, 2016, the Company was committed to fund certain strategic investments up to $310 million. Of this amount, $86 million is expected to be funded in the remainder of fiscal 2016. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.

- removed (2016-07-20):
[0001234452-16-000429:note_history:19]
Nvidia Corporation v. QUALCOMM Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd. and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chipset products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District Court complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. Nvidia later narrowed the ITC case to three asserted patents. On October 9, 2015, the Administrative Law Judge in the ITC case issued an Initial Determination finding no violation of Section 337 because none of the three patents were both valid and infringed. On October 26, 2015, Nvidia filed a petition requesting the ITC to review the Initial Determination as to two of the asserted patents, but is no longer pursuing infringement allegations with respect to the third patent. On December 14, 2015, the ITC issued its decision not to review the Initial Determination of the Administrative Law Judge. This made final the determination that the Company did not violate Section 337. Therefore, neither an exclusion order nor a cease and desist order were issued. On February 17, 2016, Nvidia filed a notice of appeal of the ITC’s determination to the United States Court of Appeals for the Federal Circuit. The District Court case was stayed on October 23, 2014 pending completion of the ITC investigation, including appeals.

- removed (2016-07-20):
[0001234452-16-000429:note_history:20]
Blackberry Limited (Blackberry) Arbitration: On April 20, 2016, the Company and Blackberry entered into an agreement to arbitrate Blackberry’s allegation that it overpaid royalties on certain past sales of subscriber units based on the alleged effect of specific provisions in its license agreement. The arbitration will be conducted under the rules of the Judicial Arbitration and Mediation Services in San Diego, California. Blackberry seeks the return of the alleged overpayment. The Company believes Blackberry’s claims are without merit.

- removed (2016-07-20):
[0001234452-16-000429:note_history:21]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). As discussed below, FCPA compliance was also the focus of the SEC investigation. The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.

- removed (2016-07-20):
[0001234452-16-000429:note_history:22]
As previously disclosed, the Company discovered, and as a part of its cooperation with these investigations informed the SEC and the DOJ of, instances in which special hiring consideration, gifts or other benefits (collectively, benefits) were provided to several individuals associated with Chinese state-owned companies or agencies. Based on the facts currently known, the Company believes the aggregate monetary value of the benefits in question to be less than $250,000, excluding employment compensation.

- removed (2016-07-20):
[0001234452-16-000429:note_history:23]
On November 19, 2015, the DOJ notified the Company that it was terminating its investigation and would not pursue charges in this matter. On March 1, 2016, the Company entered into an administrative settlement with the SEC pursuant to which the Company paid a $7.5 million penalty and entered into a two-year period of self-monitoring and self-reporting with respect to FCPA compliance. The Company neither admits nor denies the findings in the SEC’s order and does not expect any further enforcement action against the Company or its current or former employees relating to this investigation.

- removed (2016-07-20):
[0001234452-16-000429:note_history:24]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified the Company that it is conducting an investigation into whether the Company’s patent licensing arrangements violate the Taiwan Fair Trade Act (TFTA). If a violation is found, a broad range of remedies is potentially available to the TFTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the TFTC. The Company believes that its business practices do not violate the TFTA. The Company continues to cooperate with the TFTC as it conducts its investigation.

- removed (2016-07-20):
[0001234452-16-000429:note_history:25]
The Company will continue to vigorously defend itself in the foregoing matters that remain outstanding. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at March 27, 2016 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

- removed (2016-07-20):
[0001234452-16-000429:note_history:26]
Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at March 27, 2016 associated with these indemnification arrangements, other than nominal amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-07-20):
[0001234452-16-000483:note_history:27]
Basis of Presentation
  (was, 2016-04-20, similarity 0.8571):
[0001234452-16-000429:note_history:27]
Note 1. Basis of Presentation

- changed (2016-07-20):
[0001234452-16-000483:note_history:28]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 27, 2015. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 26, 2016 and June 28, 2015 included 13 weeks and 39 weeks, respectively.
  (was, 2016-04-20, similarity 0.9819):
[0001234452-16-000429:note_history:28]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 27, 2015. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and six-month periods ended March 27, 2016 and March 29, 2015 included 13 weeks and 26 weeks, respectively.

- changed (2016-07-20):
[0001234452-16-000483:note_history:29]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the sum of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 26, 2016 were 14,812,000 and 13,325,000, respectively, and 20,749,000 and 22,447,000 for the three and nine months ended June 28, 2015, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 1,378,000 and 3,150,000 during the three and nine months ended June 26, 2016, respectively, and 16,711,000 and 6,067,000 during the three and nine months ended June 28, 2015, respectively.
  (was, 2016-04-20, similarity 0.9158):
[0001234452-16-000429:note_history:29]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the sum of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 27, 2016 were 10,734,000 and 12,582,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 29, 2015 were 21,588,000 and 23,295,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 6,899,000 and 4,036,000 during the three and six months ended March 27, 2016, respectively, and 18,000 and 744,000 during the three and six months ended March 29, 2015, respectively.

- changed (2016-07-20):
[0001234452-16-000483:note_history:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26, 2016 |  | June 28, 2015 |  | June 26, 2016 |  | June 28, 2015 |
| Cost of equipment and services revenues | $ | 10 |  |  | $ | 10 |  |  | $ | 31 |  |  | $ | 33 |  |
| Research and development | 152 |  |  | 176 |  |  | 478 |  |  | 508 |  |
| Selling, general and administrative | 73 |  |  | 85 |  |  | 221 |  |  | 252 |  |
| Share-based compensation expense before income taxes | 235 |  |  | 271 |  |  | 730 |  |  | 793 |  |
| Related income tax benefit | (38 | ) |  | (58 | ) |  | (126 | ) |  | (145 | ) |
|  | $ | 197 |  |  | $ | 213 |  |  | $ | 604 |  |  | $ | 648 |  |
  (was, 2016-04-20, similarity 0.8709):
[0001234452-16-000429:note_history:30]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | March 27, 2016 |  | March 29, 2015 |
| Cost of equipment and services revenues | $ | 10 |  |  | $ | 11 |  |  | $ | 20 |  |  | $ | 23 |  |
| Research and development | 161 |  |  | 158 |  |  | 326 |  |  | 333 |  |
| Selling, general and administrative | 76 |  |  | 80 |  |  | 148 |  |  | 166 |  |
| Share-based compensation expense before income taxes | 247 |  |  | 249 |  |  | 494 |  |  | 522 |  |
| Related income tax benefit | (27 | ) |  | (43 | ) |  | (87 | ) |  | (86 | ) |
|  | $ | 220 |  |  | $ | 206 |  |  | $ | 407 |  |  | $ | 436 |  |

- changed (2016-07-20):
[0001234452-16-000483:note_history:31]
The Company recorded $170 million and $173 million in share-based compensation expense during the nine months ended June 26, 2016 and June 28, 2015, respectively, related to share-based awards granted during those periods. At June 26, 2016, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.2 billion, which is expected to be recognized over a weighted-average period of 2.0 years. During the nine months ended June 26, 2016 and June 28, 2015, net share-based awards granted, after forfeitures and cancellations, represented 0.7% and 0.8%, respectively, of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 1.0% and 0.9%, respectively, of outstanding shares as of the end of each fiscal period.
  (was, 2016-04-20, similarity 0.9034):
[0001234452-16-000429:note_history:31]
The Company recorded $96 million and $81 million in share-based compensation expense during the six months ended March 27, 2016 and March 29, 2015, respectively, related to share-based awards granted during those periods. At March 27, 2016, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.4 billion, which is expected to be recognized over a weighted-average period of 2.0 years. During the six months ended March 27, 2016 and March 29, 2015, net share-based awards granted, after forfeitures and cancellations, represented 0.7% and 0.4%, respectively, of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.9% and 0.5%, respectively, of outstanding shares as of the end of each fiscal period.

- added (2016-07-20):
[0001234452-16-000483:note_history:32]
In June 2016, the FASB issued new guidance that changes the accounting for recognizing impairments of financial assets. Under the new guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The new guidance also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The new guidance will be effective for the Company starting in the first quarter of fiscal 2021. Early adoption is permitted starting in the first quarter of fiscal 2020. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-07-20):
[0001234452-16-000483:note_history:33]
Debt

- changed (2016-07-20):
[0001234452-16-000483:note_history:34]
Revolving Credit Facility. The Company has a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At June 26, 2016 and September 27, 2015, the Company was in compliance with the covenants, and the Company had not borrowed any funds under the Revolving Credit Facility.
  (was, 2016-04-20, similarity 0.994):
[0001234452-16-000429:note_history:34]
Revolving Credit Facility. The Company has a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At March 27, 2016 and September 27, 2015, the Company was in compliance with the covenants, and the Company had not borrowed any funds under the Revolving Credit Facility.

- changed (2016-07-20):
[0001234452-16-000483:note_history:35]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At June 26, 2016 and September 27, 2015, the Company had $1.7 billion and $1.0 billion, respectively, of outstanding commercial paper recorded as short-term debt with weighted-average interest rates of 0.50% and 0.19%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 37 days and 38 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at June 26, 2016 and September 27, 2015.
  (was, 2016-04-20, similarity 0.9883):
[0001234452-16-000429:note_history:35]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At March 27, 2016 and September 27, 2015, the Company had $1.9 billion and $1.0 billion, respectively, of outstanding commercial paper recorded as short-term debt with weighted-average interest rates of 0.49% and 0.19%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 33 days and 38 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at March 27, 2016 and September 27, 2015.

- changed (2016-07-20):
[0001234452-16-000483:note_history:36]
Long-term Debt. The following table provides a summary of the Company’s long-term debt (in millions except percentages):
  (was, 2016-04-20, similarity 0.8559):
[0001234452-16-000429:note_history:36]
Long-term Debt. The following table provides a summary of the Company’s long-term debt (dollar amounts in millions):

- changed (2016-07-20):
[0001234452-16-000483:note_history:37]
|  | June 26, 2016 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.97% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.24% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.53% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.55% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 1.91% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (59 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 83 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 10,024 |  |  |  |  | $ | 9,969 |  |  |  |
  (was, 2016-04-20, similarity 0.9948):
[0001234452-16-000429:note_history:37]
|  | March 27, 2016 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.95% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.23% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.75% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.67% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.06% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (60 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 53 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 9,993 |  |  |  |  | $ | 9,969 |  |  |  |

- changed (2016-07-20):
[0001234452-16-000483:note_history:38]
The interest rate on the floating rate notes due in 2018 and 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At June 26, 2016 and September 27, 2015, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $10.4 billion and $9.6 billion, respectively.
  (was, 2016-04-20, similarity 0.9956):
[0001234452-16-000429:note_history:38]
The interest rate on the floating rate notes due in 2018 and 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At March 27, 2016 and September 27, 2015, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $10.1 billion and $9.6 billion, respectively.

- changed (2016-07-20):
[0001234452-16-000483:note_history:39]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $270 million during the nine months ended June 26, 2016. Cash interest paid related to the Company’s commercial paper program and long-term debt was negligible in the nine months ended June 28, 2015.
  (was, 2016-04-20, similarity 0.832):
[0001234452-16-000429:note_history:39]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $137 million during the six months ended March 27, 2016. Cash interest paid related to the Company’s commercial paper program was negligible in the six months ended March 29, 2015. No long-term debt was outstanding in the six months ended March 29, 2015.

- removed (2016-07-20):
[0001234452-16-000429:note_history:40]
Note 6. Debt


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-07-20):
[0001234452-16-000483:note_history:41]
Marketable Securities
  (was, 2016-04-20, similarity 0.8571):
[0001234452-16-000429:note_history:41]
Note 12. Marketable Securities

- changed (2016-07-20):
[0001234452-16-000483:note_history:42]
|  | Current |  | Noncurrent |
|  | June 26, 2016 |  | September 27, 2015 |  | June 26, 2016 |  | September 27, 2015 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 12 |  |
| Corporate bonds and notes | — |  |  | — |  |  | — |  |  | 364 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | — |  |  | — |  |  | 242 |  |
| Total trading | — |  |  | — |  |  | — |  |  | 618 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 217 |  |  | 156 |  |  | 1,931 |  |  | 691 |  |
| Corporate bonds and notes | 9,381 |  |  | 7,926 |  |  | 7,778 |  |  | 7,112 |  |
| Mortgage- and asset-backed and auction rate securities | 1,521 |  |  | 1,302 |  |  | 538 |  |  | 263 |  |
| Equity and preferred securities and equity funds | 106 |  |  | 377 |  |  | 1,459 |  |  | 1,253 |  |
| Debt funds | — |  |  | — |  |  | 2,216 |  |  | 2,909 |  |
| Total available-for-sale | 11,225 |  |  | 9,761 |  |  | 13,922 |  |  | 12,228 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | — |  |  | 780 |  |
| Total marketable securities | $ | 11,225 |  |  | $ | 9,761 |  |  | $ | 13,922 |  |  | $ | 13,626 |  |
  (was, 2016-04-20, similarity 0.9895):
[0001234452-16-000429:note_history:42]
|  | Current |  | Noncurrent |
|  | March 27, 2016 |  | September 27, 2015 |  | March 27, 2016 |  | September 27, 2015 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | — |  |  | $ | — |  |  | $ | 23 |  |  | $ | 12 |  |
| Corporate bonds and notes | — |  |  | — |  |  | — |  |  | 364 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | — |  |  | — |  |  | 242 |  |
| Total trading | — |  |  | — |  |  | 23 |  |  | 618 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 238 |  |  | 156 |  |  | 861 |  |  | 691 |  |
| Corporate bonds and notes | 8,770 |  |  | 7,926 |  |  | 7,926 |  |  | 7,112 |  |
| Mortgage- and asset-backed and auction rate securities | 1,505 |  |  | 1,302 |  |  | 461 |  |  | 263 |  |
| Equity and preferred securities and equity funds | 114 |  |  | 377 |  |  | 1,377 |  |  | 1,253 |  |
| Debt funds | — |  |  | — |  |  | 2,934 |  |  | 2,909 |  |
| Total available-for-sale | 10,627 |  |  | 9,761 |  |  | 13,559 |  |  | 12,228 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | — |  |  | 780 |  |
| Total marketable securities | $ | 10,627 |  |  | $ | 9,761 |  |  | $ | 13,582 |  |  | $ | 13,626 |  |

- changed (2016-07-20):
[0001234452-16-000483:note_history:43]
In the second quarter of fiscal 2016, the Company exited an investment in a debt fund for which the Company elected the fair value option. The investment would have otherwise been recorded using the equity method. Changes in fair value associated with this investment were recognized in net investment income and were negligible for all periods presented.
  (was, 2016-04-20, similarity 0.8096):
[0001234452-16-000429:note_history:43]
In the second quarter of fiscal 2016, the Company exited an investment in a debt fund for which the Company elected the fair value option. The investment would have otherwise been recorded using the equity method. Changes in fair value associated with this investment were recognized in net investment income. During the three and six months ended March 27, 2016 and March 29, 2015, the changes in fair value associated with this investment were negligible.

- changed (2016-07-20):
[0001234452-16-000483:note_history:44]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains or net losses recognized on debt securities classified as trading held at June 28, 2015 were negligible during the three and nine months ended June 28, 2015, respectively.
  (was, 2016-04-20, similarity 0.896):
[0001234452-16-000429:note_history:44]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains or net losses recognized on debt securities classified as trading held at March 27, 2016 and March 29, 2015 were negligible during the three and six months ended March 27, 2016 and March 29, 2015, respectively.

- changed (2016-07-20):
[0001234452-16-000483:note_history:45]
At June 26, 2016, the contractual maturities of available-for-sale debt securities were as follows (in millions):
  (was, 2016-04-20, similarity 0.9581):
[0001234452-16-000429:note_history:45]
At March 27, 2016, the contractual maturities of available-for-sale debt securities were as follows (in millions):

- changed (2016-07-20):
[0001234452-16-000483:note_history:46]
Debt securities with no single maturity date included debt funds, corporate bonds and notes, mortgage- and asset-backed securities and auction rate securities.
  (was, 2016-04-20, similarity 0.9072):
[0001234452-16-000429:note_history:46]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities and auction rate securities.

- changed (2016-07-20):
[0001234452-16-000483:note_history:47]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| June 26, 2016 | $ | 62 |  |  | $ | (8 | ) |  | $ | 54 |  |
| June 28, 2015 | 126 |  |  | (10 | ) |  | 116 |  |
| For the nine months ended |  |  |  |  |  |
| June 26, 2016 | $ | 146 |  |  | $ | (30 | ) |  | $ | 116 |  |
| June 28, 2015 | 434 |  |  | (48 | ) |  | 386 |  |
  (was, 2016-04-20, similarity 0.8516):
[0001234452-16-000429:note_history:47]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| March 27, 2016 | $ | 34 |  |  | $ | (11 | ) |  | $ | 23 |  |
| March 29, 2015 | 128 |  |  | (30 | ) |  | 98 |  |
| For the six months ended |  |  |  |  |  |
| March 27, 2016 | $ | 84 |  |  | $ | (22 | ) |  | $ | 62 |  |
| March 29, 2015 | 308 |  |  | (37 | ) |  | 271 |  |

- changed (2016-07-20):
[0001234452-16-000483:note_history:48]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| June 26, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,355 |  |  | $ | 254 |  |  | $ | (44 | ) |  | $ | 1,565 |  |
| Debt securities (including debt funds) | 23,461 |  |  | 292 |  |  | (171 | ) |  | 23,582 |  |
|  | $ | 24,816 |  |  | $ | 546 |  |  | $ | (215 | ) |  | $ | 25,147 |  |
| September 27, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,394 |  |  | $ | 264 |  |  | $ | (28 | ) |  | $ | 1,630 |  |
| Debt securities (including debt funds) | 20,459 |  |  | 185 |  |  | (285 | ) |  | 20,359 |  |
|  | $ | 21,853 |  |  | $ | 449 |  |  | $ | (313 | ) |  | $ | 21,989 |  |
  (was, 2016-04-20, similarity 0.9915):
[0001234452-16-000429:note_history:48]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| March 27, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,283 |  |  | $ | 242 |  |  | $ | (34 | ) |  | $ | 1,491 |  |
| Debt securities (including debt funds) | 22,824 |  |  | 196 |  |  | (325 | ) |  | 22,695 |  |
|  | $ | 24,107 |  |  | $ | 438 |  |  | $ | (359 | ) |  | $ | 24,186 |  |
| September 27, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,394 |  |  | $ | 264 |  |  | $ | (28 | ) |  | $ | 1,630 |  |
| Debt securities (including debt funds) | 20,459 |  |  | 185 |  |  | (285 | ) |  | 20,359 |  |
|  | $ | 21,853 |  |  | $ | 449 |  |  | $ | (313 | ) |  | $ | 21,989 |  |

- changed (2016-07-20):
[0001234452-16-000483:note_history:49]
|  | June 26, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 421 |  |  | $ | (2 | ) |  | $ | 35 |  |  | $ | (1 | ) |
| Corporate bonds and notes | 3,054 |  |  | (36 | ) |  | 1,488 |  |  | (82 | ) |
| Mortgage- and asset-backed and auction rate securities | 537 |  |  | (5 | ) |  | 265 |  |  | (2 | ) |
| Equity and preferred securities and equity funds | 447 |  |  | (43 | ) |  | 5 |  |  | (1 | ) |
| Debt funds | 318 |  |  | (4 | ) |  | 863 |  |  | (39 | ) |
|  | $ | 4,777 |  |  | $ | (90 | ) |  | $ | 2,656 |  |  | $ | (125 | ) |
  (was, 2016-04-20, similarity 0.9852):
[0001234452-16-000429:note_history:49]
|  | March 27, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 468 |  |  | $ | (3 | ) |  | $ | 39 |  |  | $ | (1 | ) |
| Corporate bonds and notes | 7,498 |  |  | (117 | ) |  | 1,065 |  |  | (93 | ) |
| Mortgage- and asset-backed and auction rate securities | 1,122 |  |  | (9 | ) |  | 171 |  |  | (2 | ) |
| Equity and preferred securities and equity funds | 358 |  |  | (34 | ) |  | 4 |  |  | — |  |
| Debt funds | 1,953 |  |  | (95 | ) |  | 79 |  |  | (5 | ) |
|  | $ | 11,399 |  |  | $ | (258 | ) |  | $ | 1,358 |  |  | $ | (101 | ) |

- changed (2016-07-20):
[0001234452-16-000483:note_history:50]
At June 26, 2016, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company did not have the intent to sell, nor was it more likely than not that the Company will be required to sell, such securities before recovery or maturity.
  (was, 2016-04-20, similarity 0.9921):
[0001234452-16-000429:note_history:50]
At March 27, 2016, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company did not have the intent to sell, nor was it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

- changed (2016-07-20):
[0001234452-16-000483:note_history:51]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was $61 million and negligible at June 26, 2016 and June 28, 2015, respectively.
  (was, 2016-04-20, similarity 0.9526):
[0001234452-16-000429:note_history:51]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was $52 million and negligible at March 27, 2016 and March 29, 2015, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-07-20):
[0001234452-16-000483:note_history:52]
The following table provides a summary of the Company’s long-term debt (in millions except percentages):
  (was, 2016-04-20, similarity 0.8333):
[0001234452-16-000429:note_history:52]
The following table provides a summary of the Company’s long-term debt (dollar amounts in millions):

- changed (2016-07-20):
[0001234452-16-000483:note_history:53]
|  | June 26, 2016 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.97% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.24% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.53% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.55% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 1.91% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (59 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 83 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 10,024 |  |  |  |  | $ | 9,969 |  |  |  |
  (was, 2016-04-20, similarity 0.9948):
[0001234452-16-000429:note_history:53]
|  | March 27, 2016 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.95% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.23% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.75% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.67% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.06% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (60 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 53 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 9,993 |  |  |  |  | $ | 9,969 |  |  |  |
