# QCOM notes — 0001234452-16-000552


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001234452-16-000552:notes:1]
Composition of Certain Financial Statement Items

[0001234452-16-000552:notes:2]
| Accounts Receivable (in millions) |  |  |  |
|  | September 25, 2016 |  | September 27, 2015 |
| Trade, net of allowances for doubtful accounts of $1 and $6, respectively | $ | 2,194 |  |  | $ | 1,941 |  |
| Long-term contracts | 20 |  |  | 11 |  |
| Other | 5 |  |  | 12 |  |
|  | $ | 2,219 |  |  | $ | 1,964 |  |

[0001234452-16-000552:notes:3]
| Inventories (in millions) |  |  |  |
|  | September 25, 2016 |  | September 27, 2015 |
| Raw materials | $ | 1 |  |  | $ | 1 |  |
| Work-in-process | 847 |  |  | 550 |  |
| Finished goods | 708 |  |  | 941 |  |
|  | $ | 1,556 |  |  | $ | 1,492 |  |

[0001234452-16-000552:notes:4]
| Property, Plant and Equipment (in millions) | September 25, 2016 |  | September 27, 2015 |
| Land | $ | 192 |  |  | $ | 212 |  |
| Buildings and improvements | 1,545 |  |  | 1,544 |  |
| Computer equipment and software | 1,426 |  |  | 1,422 |  |
| Machinery and equipment | 2,454 |  |  | 2,287 |  |
| Furniture and office equipment | 77 |  |  | 83 |  |
| Leasehold improvements | 254 |  |  | 274 |  |
| Construction in progress | 92 |  |  | 72 |  |
|  | 6,040 |  |  | 5,894 |  |
| Less accumulated depreciation and amortization | (3,734 | ) |  | (3,360 | ) |
|  | $ | 2,306 |  |  | $ | 2,534 |  |

[0001234452-16-000552:notes:5]
Depreciation and amortization expense related to property, plant and equipment for fiscal 2016, 2015 and 2014 was $624 million, $625 million and $609 million, respectively. The gross book values of property under capital leases included in buildings and improvements were negligible at September 25, 2016 and September 27, 2015.

[0001234452-16-000552:notes:6]
Goodwill and Other Intangible Assets. The Company allocates goodwill to its reporting units for annual impairment testing purposes. The following table presents the goodwill allocated to the Company’s reportable and nonreportable segments, as described in Note 8, as well as the changes in the carrying amounts of goodwill during fiscal 2016 and 2015 (in millions):

[0001234452-16-000552:notes:7]
|  | QCT |  | QTL |  | Nonreportable Segments |  | Total |
| Balance at September 28, 2014 | $ | 3,467 |  |  | $ | 712 |  |  | $ | 309 |  |  | $ | 4,488 |  |
| Acquisitions | 998 |  |  | 6 |  |  | 254 |  |  | 1,258 |  |
| Impairments | — |  |  | — |  |  | (260 | ) |  | (260 | ) |
| Other (1) | (4 | ) |  | — |  |  | (3 | ) |  | (7 | ) |
| Balance at September 27, 2015 (2) | 4,461 |  |  | 718 |  |  | 300 |  |  | 5,479 |  |
| Acquisitions | 172 |  |  | — |  |  | — |  |  | 172 |  |
| Impairments | — |  |  | — |  |  | (17 | ) |  | (17 | ) |
| Other (1) | 41 |  |  | — |  |  | 4 |  |  | 45 |  |
| Balance at September 25, 2016 (2) | $ | 4,674 |  |  | $ | 718 |  |  | $ | 287 |  |  | $ | 5,679 |  |

[0001234452-16-000552:notes:8]
| (1) | Includes changes in goodwill amounts resulting from foreign currency translation, purchase accounting adjustments and, in fiscal 2016, the sale of the Company’s business that provided augmented reality applications. |

[0001234452-16-000552:notes:9]
| (2) | Cumulative goodwill impairments were $537 million and $520 million at September 25, 2016 and September 27, 2015, respectively. |

[0001234452-16-000552:notes:10]
The components of other intangible assets, net were as follows (in millions):

[0001234452-16-000552:notes:11]
|  | September 25, 2016 |  | September 27, 2015 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |
| Wireless spectrum | $ | 2 |  |  | $ | (2 | ) |  | 5 |  | $ | 2 |  |  | $ | (2 | ) |  | 5 |
| Marketing-related | 119 |  |  | (77 | ) |  | 8 |  | 93 |  |  | (59 | ) |  | 8 |
| Technology-based | 5,900 |  |  | (2,459 | ) |  | 10 |  | 5,735 |  |  | (2,078 | ) |  | 10 |
| Customer-related | 21 |  |  | (4 | ) |  | 7 |  | 111 |  |  | (60 | ) |  | 4 |
|  | $ | 6,042 |  |  | $ | (2,542 | ) |  | 10 |  | $ | 5,941 |  |  | $ | (2,199 | ) |  | 10 |

[0001234452-16-000552:notes:12]
All of these intangible assets are subject to amortization, other than acquired in-process research and development with carrying values of $83 million and $196 million at September 25, 2016 and September 27, 2015, respectively. Amortization expense related to these intangible assets was $804 million, $591 million and $543 million for fiscal 2016, 2015 and 2014, respectively. Amortization expense related to these intangible assets and acquired in-process research and development, beginning upon the expected completion of the underlying projects, is expected to be $674 million, $635 million, $597 million, $494 million and $374 million for each of the subsequent five years from fiscal 2017 through 2021, respectively, and $726 million thereafter.

[0001234452-16-000552:notes:13]
| Other Current Liabilities (in millions) |  |  |  |
|  | September 25, 2016 |  | September 27, 2015 |
| Customer incentives and other customer-related liabilities | $ | 1,710 |  |  | $ | 1,894 |  |
| Other | 551 |  |  | 462 |  |
|  | $ | 2,261 |  |  | $ | 2,356 |  |

[0001234452-16-000552:notes:14]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity during fiscal 2016 were as follows (in millions):

[0001234452-16-000552:notes:15]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Total Accumulated Other Comprehensive Income |
| Balance at September 27, 2015 | $ | (160 | ) |  | $ | 4 |  |  | $ | 297 |  |  | $ | 54 |  |  | $ | 195 |  |
| Other comprehensive (loss) income before reclassifications | (22 | ) |  | 14 |  |  | 306 |  |  | (4 | ) |  | 294 |  |
| Reclassifications from accumulated other comprehensive income | 21 |  |  | (12 | ) |  | (71 | ) |  | 1 |  |  | (61 | ) |
| Other comprehensive (loss) income | (1 | ) |  | 2 |  |  | 235 |  |  | (3 | ) |  | 233 |  |
| Balance at September 25, 2016 | $ | (161 | ) |  | $ | 6 |  |  | $ | 532 |  |  | $ | 51 |  |  | $ | 428 |  |

[0001234452-16-000552:notes:16]
Reclassifications from accumulated other comprehensive income related to net gains on available-for-sale securities of $83 million, $212 million and $360 million during fiscal 2016, 2015 and 2014, respectively, were recorded in investment income, net (Note 2). Reclassifications from accumulated other comprehensive income related to foreign currency translation losses of $21 million during fiscal 2016 were recorded in selling, general and administrative expenses and other operating expenses. Reclassifications from accumulated other comprehensive income related to foreign currency translation adjustments during fiscal 2015 and 2014 were negligible. Reclassifications from accumulated other comprehensive income related to derivative instruments during fiscal 2016 and 2015 were negligible. Reclassifications from accumulated other comprehensive income related to derivative instruments of $26 million for fiscal 2014 were recorded in revenues, cost of revenues, research and development expenses and selling, general and administrative expenses.

[0001234452-16-000552:notes:17]
Other Income, Costs and Expenses. Other income for fiscal 2016 included a gain of $380 million on the sale of wireless spectrum in the United Kingdom that was held by the QSI (Qualcomm Strategic Initiatives) segment in the first quarter of fiscal 2016 for $232 million in cash and $275 million in deferred payments due in 2020 to 2023, which were recorded at their present values in other assets. Other income for fiscal 2016 also included $202 million in restructuring and restructuring-related charges, which were partially offset by a $48 million gain on the sale of the Company’s business that provided augmented reality applications, all of which related to the Company’s Strategic Realignment Plan.

[0001234452-16-000552:notes:18]
On February 9, 2015, the Company announced that it had reached a resolution with the China National Development and Reform Commission (NDRC) regarding its investigation of the Company relating to China’s Anti-Monopoly Law (AML) and the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business. The NDRC issued an Administrative Sanction Decision finding that the Company had violated the AML, and the Company agreed to implement a rectification plan that modifies certain of its business practices in China. In addition, the NDRC imposed a fine on the Company of 6.088 billion Chinese renminbi (approximately $975 million), which the Company paid. The Company recorded the amount of the fine in the second quarter of fiscal 2015 in other expenses. Other expenses in fiscal 2015 also included $255 million and $11 million in impairment charges on goodwill and intangible assets, respectively, related to the Company’s content and push-to-talk services and display businesses and $190 million in restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan (Note 10), partially offset by $138 million in gains on sales of certain property, plant and equipment.

[0001234452-16-000552:notes:19]
Other expenses in fiscal 2014 were comprised of $507 million and $100 million in certain property, plant and equipment and goodwill impairment charges, respectively, and $19 million in restructuring-related costs incurred by one of the Company’s display businesses. Other expenses in fiscal 2014 also included a $16 million goodwill impairment charge related to the Company’s former QRS (Qualcomm Retail Solutions) division and a $15 million legal settlement, partially offset by the reversal of the $173 million accrual recorded in fiscal 2013 related to the ParkerVision verdict against us, which was overturned (Note 7).

[0001234452-16-000552:notes:20]
| Investment Income, Net (in millions) |  |  |  |  |  |
|  | 2016 |  | 2015 |  | 2014 |
| Interest and dividend income | $ | 611 |  |  | $ | 527 |  |  | $ | 586 |  |
| Net realized gains on marketable securities | 239 |  |  | 451 |  |  | 770 |  |
| Net realized gains on other investments | 49 |  |  | 49 |  |  | 56 |  |
| Impairment losses on marketable securities | (112 | ) |  | (163 | ) |  | (156 | ) |
| Impairment losses on other investments | (60 | ) |  | (37 | ) |  | (24 | ) |
| Net (losses) gains on derivative instruments | (8 | ) |  | 17 |  |  | 5 |  |
| Equity in net losses of investees | (84 | ) |  | (32 | ) |  | (10 | ) |
| Net gains on deconsolidation of subsidiaries | — |  |  | 3 |  |  | 6 |  |
|  | $ | 635 |  |  | $ | 815 |  |  | $ | 1,233 |  |

[0001234452-16-000552:notes:21]
Net impairment losses on marketable securities related to the noncredit portion of losses on debt securities recognized in other comprehensive income were $37 million, $23 million and negligible in fiscal 2016, 2015 and 2014, respectively. The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was $55 million and $12 million at September 25, 2016 and September 27, 2015, respectively.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001234452-16-000552:notes:22]
The following table presents the unaudited pro forma results for fiscal 2015 and 2014. The unaudited pro forma financial information combines the results of operations of Qualcomm and CSR as though the companies had been combined as of the beginning of fiscal 2014, and the pro forma information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at such time. The unaudited pro forma results presented below include amortization charges for acquired intangible assets, eliminations of intercompany transactions, adjustments for increased fair value of acquired inventory, adjustments for depreciation expense for property, plant and equipment and related tax effects (in millions):

[0001234452-16-000552:notes:23]
|  | 2015 |  | 2014 |
|  | (unaudited) |
| Revenues | $ | 25,939 |  |  | $ | 27,282 |  |
| Net income attributable to Qualcomm | 5,157 |  |  | 7,730 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001234452-16-000552:notes:24]
Acquisitions

[0001234452-16-000552:notes:25]
During fiscal 2016, the Company acquired four businesses for total cash consideration of $392 million, net of cash acquired. Technology-based intangible assets of $257 million were recognized with a weighted-average useful life of four years. The Company recognized $172 million in goodwill related to these transactions, all of which was assigned to the Company’s QCT segment and of which $24 million is expected to be deductible for tax purposes.

[0001234452-16-000552:notes:26]
In January 2016, the Company announced that it had reached agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd., to enable delivery of radio frequency front-end (RFFE) modules and RF filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others. The joint venture will initially be owned 51% by the Company and 49% by TDK. Certain intellectual property, patents and filter and module design and manufacturing assets will be carved out of existing TDK businesses and be acquired by the joint venture, with certain assets acquired by the Company. The purchase price of the Company’s interest in the joint venture and the assets to be transferred to the Company is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, the Company has the option to acquire (and TDK has an option to sell) TDK’s interest in the joint venture for $1.15 billion 30 months after the closing date. TDK will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date, which is a substitute for and in lieu of any right of TDK to receive any profit sharing, distributions, dividends or other payments of any kind or nature. The transaction is subject to receipt of regulatory approvals and other closing conditions and is expected to close in early calendar 2017.

[0001234452-16-000552:notes:27]
On August 13, 2015, the Company acquired CSR plc, which was renamed CSR Limited (CSR), for total cash consideration of $2.3 billion (net of $176 million of cash acquired). In addition, $28 million of third-party acquisition and integration services costs were included in selling, general and administrative expenses in fiscal 2015. CSR is an innovator in the development of multifunction semiconductor platforms and technologies for the automotive, consumer and voice and music categories. The acquisition complements the Company’s current offerings by adding products, channels and customers in the growth categories of the IoT and automotive infotainment. CSR was integrated into the QCT segment.

[0001234452-16-000552:notes:28]
The allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0001234452-16-000552:notes:29]
| Current assets | $ | 560 |  |
| Intangible assets subject to amortization: |  |
| Technology-based intangible assets | 953 |  |
| Customer-related intangible assets | 45 |  |
| Marketing-related intangible assets | 15 |  |
| In-process research and development (IPR&D) | 182 |  |
| Goodwill | 969 |  |
| Other assets | 131 |  |
| Total assets | 2,855 |  |
| Liabilities | (411 | ) |
| Net assets acquired | $ | 2,444 |  |

[0001234452-16-000552:notes:30]
Goodwill recognized in this transaction is not deductible for tax purposes and was allocated to the QCT segment for annual impairment testing purposes. Goodwill is primarily attributable to synergies expected to arise after the acquisition. Each category of intangible assets acquired will be amortized on a straight-line basis over their weighted-average useful lives of five years for technology-based intangible assets and four years for customer-related and marketing-related intangible assets. On the acquisition date, IPR&D consisted of three projects, primarily related to Bluetooth audio and Bluetooth low energy (also known as Bluetooth Smart) technologies, one of which was completed during fiscal 2016 and will be amortized over its useful life of seven years. The remaining two projects are expected to be completed in fiscal 2017 and will be amortized over their useful lives, which are expected to be six years. The estimated fair values of the intangible assets acquired were primarily determined using the income approach based on significant inputs that were not observable.

[0001234452-16-000552:notes:31]
The Company’s results of operations for fiscal 2015 included the operating results of CSR since the date of acquisition, the amounts of which were not material. The following table presents the unaudited pro forma results for fiscal 2015 and 2014. The unaudited pro forma financial information combines the results of operations of Qualcomm and CSR as though the companies had been combined as of the beginning of fiscal 2014, and the pro forma information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at such time. The unaudited pro forma results presented below include amortization charges for acquired intangible assets, eliminations of intercompany transactions, adjustments for increased fair value of acquired inventory, adjustments for depreciation expense for property, plant and equipment and related tax effects (in millions):

[0001234452-16-000552:notes:32]
During fiscal 2015, the Company acquired four other businesses for total cash consideration of $405 million, net of cash acquired. Technology-based intangible assets recognized in the amount of $84 million are being amortized on a straight-line basis over a weighted-average useful life of eight years. The Company recognized $289 million in goodwill related to these transactions, of which $35 million is expected to be deductible for tax purposes. Goodwill of $29 million, $6 million and $254 million was assigned to the Company’s QCT, QTL and nonreportable segments, respectively.

[0001234452-16-000552:notes:33]
During fiscal 2014, the Company acquired 11 businesses for total cash consideration of $761 million, net of cash acquired, and the exchange of unvested stock options that had a negligible fair value. Technology-based intangible assets recognized in the amount of $146 million are being amortized on a straight-line basis over a weighted-average useful life of six years. Goodwill of $624 million was recognized in these transactions, of which $294 million is expected to be deductible for tax purposes. Goodwill of $589 million, $6 million and $29 million was assigned to the Company’s QCT, QTL and nonreportable segments, respectively.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001234452-16-000552:notes:34]
Cash Equivalents. The Company considers all highly liquid investments with original maturities of 90 days or less to be cash equivalents. Cash equivalents are comprised of money market funds, certificates of deposit, commercial paper, government agencies’ securities, corporate bonds and notes, certain bank time deposits and repurchase agreements fully collateralized by government agencies’ securities. The carrying amounts approximate fair value due to the short maturities of these instruments.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001234452-16-000552:notes:35]
Commitments and Contingencies

[0001234452-16-000552:notes:36]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe certain ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 ParkerVision patents and seeks damages and injunctive and other relief. On September 25, 2015, ParkerVision filed a motion with the court to sever some claims against the Company and all other defendants into a separate lawsuit. In addition, on December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against the Company and other parties with the United States International Trade Commission (ITC) described below.

[0001234452-16-000552:notes:37]
On December 14, 2015, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. are also named defendants. The complaint asserts that certain of the Company’s products infringe four additional ParkerVision patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. The ITC hearing is scheduled to begin on March 13, 2017. The ITC’s target date for completion of the investigation is October 23, 2017. The District Court case was stayed on February 12, 2016 pending completion of the ITC investigation. The Company believes ParkerVision’s claims in the above matters are without merit.

[0001234452-16-000552:notes:38]
Blackberry Limited (Blackberry) Arbitration: On April 20, 2016, the Company and Blackberry entered into an agreement to arbitrate Blackberry’s allegation that it overpaid royalties on certain past sales of subscriber units based on the alleged effect of specific provisions in its license agreement. The arbitration, which is scheduled to begin on February 27, 2017, is being conducted under the rules of the Judicial Arbitration and Mediation Services in San Diego, California. Blackberry seeks the return of the alleged overpayment. The Company believes Blackberry’s claims are without merit.

[0001234452-16-000552:notes:39]
3226701 Canada, Inc. v. Qualcomm Incorporated et al: On November 30, 2015, plaintiffs filed a securities class action complaint against the Company and certain of its current and former officers in the United States District Court for the Southern District of California. On April 29, 2016, plaintiffs filed an amended complaint alleging that the Company and certain of its current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding the Company’s business outlook and product development between April 7, 2014 and July 22, 2015. The amended complaint seeks unspecified damages, interest, attorneys’ fees and other costs. On June 28, 2016, the Company filed a Motion to Dismiss. The Company believes the plaintiffs’ claims are without merit.

[0001234452-16-000552:notes:40]
QUALCOMM Incorporated v. Meizu Technology Co., Ltd. et al: On June 23, 2016 and June 29, 2016, the Company filed a series of actions against Meizu Technology Co., Ltd., aka Zhuhai Meizu Technology Co., Ltd. (Meizu) and certain of its distributors in the Intellectual Property Courts in Beijing and Shanghai (China). The first complaint, filed in Beijing on June 23, 2016, requests rulings that the terms of a patent license offered by the Company to Meizu comply with China’s Anti-Monopoly Law and the Company’s applicable fair, reasonable and non-discriminatory licensing commitment. The complaint also seeks a ruling that the offered patent license terms should form the basis for a patent license with Meizu for the Company’s fundamental mobile device technologies patented in China, including those relating to 3G (WCDMA and CDMA2000) and 4G (LTE) wireless communications standards, and seeks damages for Meizu’s past use of the Company’s patented inventions. On June 29, 2016, the Company filed patent infringement complaints in the Intellectual Property Courts in Beijing and Shanghai alleging infringement of 17 patents by Meizu. The patent infringement actions concern a broad range of features and technologies used in smartphones, including features relating to 3G (WCDMA and CDMA2000) and 4G (LTE) wireless communications standards, and seek to enjoin Meizu from manufacturing, selling and offering for sale mobile devices that infringe the asserted patents. The courts are currently considering various jurisdictional challenges raised by Meizu. No final schedules have been set by the courts. Meizu has also filed actions before China’s Patent Reexamination Board challenging the validity of each of the asserted patents. These actions are proceeding in parallel with the litigation.

[0001234452-16-000552:notes:41]
On October 14, 2016, the Company filed patent infringement complaints against Meizu in the United States ITC and the Mannheim Regional Court in Germany. The ITC complaint seeks an exclusion order enjoining Meizu and certain of its distributors from the importation, sale for importation and sale after importation of Meizu mobile devices that infringe certain of the Company’s patents related to semiconductor, radio frequency and digital camera technologies. The German complaint seeks damages and to enjoin Meizu from offering, putting into circulation, using, possessing or importing into Germany mobile devices that infringe one of the Company’s patents related to wireless messaging technology. On the same day, the Company also initiated a seizure action in France pursuant to orders from the Paris District Court to obtain evidence for a possible future infringement action in that country.

[0001234452-16-000552:notes:42]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 33 different dates, with the next hearing scheduled for January 17, 2017.

[0001234452-16-000552:notes:43]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments since then with respect to this matter.

[0001234452-16-000552:notes:44]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it is conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On November 13, 2015, the Company received a case Examiner’s Report (ER) prepared by the KFTC’s investigative staff. The ER alleges, among other things, that the Company is in violation of Korean competition law by licensing its patents exhaustively only to device manufacturers and requiring that its chipset customers be licensed to the Company’s intellectual property. The ER also alleges that the Company obtains certain terms, including royalty terms, that are unfair or unreasonable in its license agreements through negotiations that do not conform to Korean competition law. The ER proposes remedies including modifications to certain business practices and monetary penalties. On May 27, 2016, the Company submitted a written response to the ER. The KFTC is holding hearings, which commenced on July 20, 2016. It remains difficult to predict the outcome of this matter. The Company believes that its business practices do not violate the MRFTA. The Company continues to cooperate with the KFTC as it conducts its investigation.

[0001234452-16-000552:notes:45]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company provided additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On August 15, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

[0001234452-16-000552:notes:46]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that since 2011 the Company has paid significant amounts to a customer on condition that it exclusively use the Company’s baseband chipsets in its smartphones and tablets. This conduct has allegedly reduced the customer’s incentives to source chipsets from the Company’s competitors and harmed competition and innovation for certain baseband chipsets. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On June 27, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

[0001234452-16-000552:notes:47]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act (FTCA). The FTC has notified the Company that it is investigating conduct under the antitrust and unfair competition laws related to standard essential patents and pricing and contracting practices with respect to baseband processors and related products. If a violation is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company believes that its business practices do not violate the antitrust or unfair competition laws. The Company continues to cooperate with the FTC as it conducts its investigation.

[0001234452-16-000552:notes:48]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified the Company that it is conducting an investigation into whether the Company’s patent licensing arrangements violate the Taiwan Fair Trade Act (TFTA). On April 27, 2016, the TFTC specified that the allegations under investigation include whether: (i) the Company jointly licensed its patents rather than separately licensing standard-essential patents and non-standard-essential patents; (ii) the Company’s royalty charges are unreasonable; (iii) the Company unreasonably required licensees to grant it cross-licenses; (iv) the Company failed to provide lists of licensed patents to licensees; (v) the Company violated a FRAND licensing commitment by declining to grant licenses to chipset makers; (vi) the Company declined to sell chipsets to unlicensed potential customers; and (vii) the Company provided royalty rebates to certain companies in exchange for their exclusive use of the Company’s chipsets. If a violation is found, a broad range of remedies is potentially available to the TFTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the TFTC. The Company believes that its business practices do not violate the TFTA. The Company continues to cooperate with the TFTC as it conducts its investigation.

[0001234452-16-000552:notes:49]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at September 25, 2016 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001234452-16-000552:notes:50]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0001234452-16-000552:notes:51]
Through September 25, 2016, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products. These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at September 25, 2016 associated with these indemnification arrangements, other than nominal amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001234452-16-000552:notes:52]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at September 25, 2016 for each of the subsequent five years from fiscal 2017 through 2021 were $4.2 billion, $886 million, $749 million, $223 million and $37 million, respectively, and $5 million thereafter. Of these amounts, for each of the subsequent four years from fiscal 2017 through 2020, commitments to purchase integrated circuit product inventories comprised $3.4 billion, $766 million, $673 million, and $158 million, respectively, and there were no purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

[0001234452-16-000552:notes:53]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Rental expense for fiscal 2016, 2015 and 2014 was $116 million, $99 million and $91 million, respectively. Future minimum lease payments at September 25, 2016 for each of the subsequent five years from fiscal 2017 through 2021 were $94 million, $74 million, $58 million, $43 million and $33 million, respectively, and $36 million thereafter.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001234452-16-000552:notes:54]
Employee Benefit Plans

[0001234452-16-000552:notes:55]
Employee Savings and Retirement Plan. The Company has a 401(k) plan that allows eligible employees to contribute up to 85% of their eligible compensation, subject to annual limits. The Company matches a portion of the employee contributions and may, at its discretion, make additional contributions based upon earnings. The Company’s contribution expense was $74 million, $81 million and $77 million in fiscal 2016, 2015 and 2014, respectively.

[0001234452-16-000552:notes:56]
Equity Compensation Plans. On March 8, 2016, the Company’s stockholders approved the Qualcomm Incorporated 2016 Long-Term Incentive Plan (the 2016 Plan), which replaced the Qualcomm Incorporated 2006 Long-Term Incentive Plan (the Prior Plan). Effective on and after that date, no new awards will be granted under the Prior Plan, although all outstanding awards under the Prior Plan will remain outstanding according to their terms and the terms of the Prior Plan. The 2016 Plan provides for the grant of incentive and nonstatutory stock options, stock appreciation rights, restricted stock, unrestricted stock, restricted stock units, performance units, performance shares, deferred compensation awards and other stock-based awards. The share reserve under the 2016 Plan is equal to 90,000,000 shares, plus approximately 20,120,000 shares that were available for future grant under the Prior Plan on March 8, 2016, for a total of approximately 110,120,000 shares available for grant under the 2016 Plan on that date. This share reserve is automatically increased as provided in the 2016 Plan by the number of shares subject to stock options granted under the Prior Plan and outstanding as of March 8, 2016, which after that date expire or for any reason are forfeited, canceled or terminated, and by two times the number of shares subject to any awards other than stock options granted under the Prior Plan and outstanding as of March 8, 2016, which after that date expire, are forfeited, canceled or terminated, fail to vest, are not earned due to any performance goal that is not met, are otherwise reacquired without having become vested, or are paid in cash, exchanged by a participant or withheld by the Company to satisfy any tax withholding or tax payment obligations related to such award. The Board of Directors of the Company may amend or terminate the 2016 Plan at any time. Certain amendments, including an increase in the share reserve, require stockholder approval. The share reserve remaining under the 2016 Plan was approximately 114,041,000 at September 25, 2016.

[0001234452-16-000552:notes:57]
RSUs are share awards that entitle the holder to receive shares of the Company’s common stock upon vesting. The RSUs generally include dividend-equivalent rights and vest over periods of three years from the date of grant. A summary of RSU transactions for all equity compensation plans follows:

[0001234452-16-000552:notes:58]
|  | Number of Shares |  | Weighted-AverageGrant Date FairValue |  | Aggregate IntrinsicValue |
|  | (In thousands) |  |  |  | (In billions) |
| RSUs outstanding at September 27, 2015 | 27,747 |  |  | $ | 69.35 |  |  |  |
| RSUs granted | 14,782 |  |  | 53.56 |  |  |  |
| RSUs canceled/forfeited | (4,017 | ) |  | 65.37 |  |  |  |
| RSUs vested | (12,434 | ) |  | 68.48 |  |  |  |
| RSUs outstanding at September 25, 2016 | 26,078 |  |  | $ | 61.42 |  |  | $ | 1.6 |  |

[0001234452-16-000552:notes:59]
At September 25, 2016, total unrecognized compensation expense related to non-vested RSUs granted prior to that date was $1.0 billion, which is expected to be recognized over a weighted-average period of 1.7 years. The total vest-date fair value of RSUs that vested during fiscal 2016, 2015 and 2014 was $685 million, $1.0 billion and $1.1 billion, respectively. The total shares withheld to satisfy statutory tax withholding requirements related to all share-based awards were approximately 4,300,000, 5,043,000 and 5,568,000 in fiscal 2016, 2015 and 2014, respectively, and were based on the value of the awards on their vesting dates as determined by the Company’s closing stock price. Total payments for the employees’ tax obligations to the taxing authorities were $224 million, $351 million and $417 million in fiscal 2016, 2015 and 2014, respectively, and were included as a reduction to net cash provided by operating activities in the consolidated statements of cash flows.

[0001234452-16-000552:notes:60]
The Board of Directors may grant stock options to employees, directors and consultants to the Company to purchase shares of the Company’s common stock at an exercise price not less than the fair market value of the stock at the date of grant. Stock options vest over periods not exceeding five years and are exercisable for up to ten years from the grant date. A summary of stock option transactions for all equity compensation plans follows:

[0001234452-16-000552:notes:61]
|  | Number of Shares |  | Weighted- AverageExercisePrice |  | Average RemainingContractual Term |  | Aggregate IntrinsicValue |
|  | (In thousands) |  |  |  | (Years) |  | (In millions) |
| Stock options outstanding at September 27, 2015 | 29,377 |  |  | $ | 41.40 |  |  |  |  |  |
| Stock options canceled/forfeited/expired | (690 | ) |  | 51.47 |  |  |  |  |  |
| Stock options exercised | (10,708 | ) |  | 41.49 |  |  |  |  |  |
| Stock options outstanding at September 25, 2016 | 17,979 |  |  | $ | 40.96 |  |  | 2.0 |  | $ | 392 |  |
| Exercisable at September 25, 2016 | 17,940 |  |  | $ | 41.05 |  |  | 2.0 |  | $ | 389 |  |

[0001234452-16-000552:notes:62]
The total intrinsic value of stock options exercised during fiscal 2016, 2015 and 2014 was $147 million, $371 million and $971 million, respectively, and the amount of cash received from the exercise of stock options was $436 million, $519 million and $1.2 billion, respectively. Upon option exercise, the Company issues new shares of stock.

[0001234452-16-000552:notes:63]
The total tax benefits realized, including the excess tax benefits, related to share-based awards during fiscal 2016, 2015 and 2014 was $253 million, $437 million and $690 million, respectively.

[0001234452-16-000552:notes:64]
Employee Stock Purchase Plan. The Company has an employee stock purchase plan for eligible employees to purchase shares of common stock at 85% of the lower of the fair market value on the first or the last day of each offering period, which is generally six months. Employees may authorize the Company to withhold up to 15% of their compensation during any offering period, subject to certain limitations. The employee stock purchase plan includes a non-423(b) plan. The shares authorized under the employee stock purchase plan were approximately 71,709,000 at September 25, 2016. The shares reserved for future issuance were approximately 20,395,000 at September 25, 2016. During fiscal 2016, 2015 and 2014, approximately 5,966,000, 4,977,000 and 4,376,000 shares, respectively, were issued under the plan at an average price of $38.89, $53.92 and $58.81 per share, respectively. At September 25, 2016, total unrecognized compensation expense related to non-vested purchase rights granted prior to that date was $22 million. The Company recorded cash received from the exercise of purchase rights of $232 million, $268 million and $257 million during fiscal 2016, 2015 and 2014, respectively.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001234452-16-000552:notes:65]
Concentrations. A significant portion of the Company’s revenues is concentrated with a small number of customers/licensees of the Company’s QCT and QTL segments. Revenues related to the products of two customers/licensees comprised 16% and 24% of total consolidated revenues in fiscal 2016, compared to 20% and 25% in fiscal 2015 and 28% and 21% in fiscal 2014. Aggregate accounts receivable from two customers/licensees comprised 44% and 19% of gross accounts receivable at September 25, 2016 and September 27, 2015, respectively.

[0001234452-16-000552:notes:66]
The Company relies on sole- or limited-source suppliers for some products, particularly products in the QCT segment, subjecting the Company to possible shortages of raw materials or manufacturing capacity. While the Company has established alternate suppliers for certain technologies that the Company considers critical, the loss of a supplier or the inability of a supplier to meet performance or quality specifications or delivery schedules could harm the Company’s ability to meet its delivery obligations and/or negatively impact the Company’s revenues, business operations and ability to compete for future business.


## us-gaap:ConsolidationPolicyTextBlock

[0001234452-16-000552:notes:67]
Principles of Consolidation. The Company’s consolidated financial statements include the assets, liabilities and operating results of majority-owned subsidiaries. In addition, the Company consolidates its investment in an immaterial less than majority-owned variable interest entity as the Company is the primary beneficiary. The ownership of the other interest holders of consolidated subsidiaries and the variable interest entity is presented separately in the consolidated balance sheets and statements of operations. All significant intercompany accounts and transactions have been eliminated.


## us-gaap:DebtDisclosureTextBlock

[0001234452-16-000552:notes:68]
Debt

[0001234452-16-000552:notes:69]
Revolving Credit Facility. The Company has a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. Proceeds from the Revolving Credit Facility will be used for general corporate purposes. Loans under the Revolving Credit Facility bear interest, at the option of the Company, at either LIBOR (determined in accordance with the Revolving Credit Facility) plus a margin of 0.7% per annum or the Base Rate (determined in accordance with the Revolving Credit Facility), plus an initial margin of 0% per annum. The Revolving Credit Facility has a facility fee, which accrues at a rate of 0.05% per annum. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At September 25, 2016 and September 27, 2015, the Company was in compliance with the covenants, and the Company had not borrowed any funds under the Revolving Credit Facility.

[0001234452-16-000552:notes:70]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At September 25, 2016 and September 27, 2015, the Company had $1.7 billion and $1.0 billion, respectively, of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 0.52% and 0.19%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 36 days and 38 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at September 25, 2016 and September 27, 2015.

[0001234452-16-000552:notes:71]
Long-term Debt. In May 2015, the Company issued an aggregate principal amount of $10.0 billion of unsecured floating- and fixed-rate notes (the notes) with varying maturities. The proceeds from the notes of $9.9 billion, net of underwriting discounts and offering expenses, were used to fund the ASR Agreements (Note 4) and also for other general corporate purposes. The following table provides a summary of the Company’s long-term debt (in millions except percentages):

[0001234452-16-000552:notes:72]
|  | September 25, 2016 |  | September 27, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 1.14% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.42% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.93% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.69% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.04% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (57 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 65 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 10,008 |  |  |  |  | $ | 9,969 |  |  |  |

[0001234452-16-000552:notes:73]
The interest rate on the floating rate notes due in 2018 and 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At September 25, 2016 and September 27, 2015, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $10.6 billion and $9.6 billion, respectively.

[0001234452-16-000552:notes:74]
In the third quarter of fiscal 2015, the Company entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes (Note 1). The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings as interest expense in the current period. The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs and, if applicable, adjustments related to hedging.

[0001234452-16-000552:notes:75]
No principal payments are due on the Company’s notes prior to fiscal 2018. At September 25, 2016, future principal payments were $1.5 billion in fiscal 2018, $2.0 billion in fiscal 2020 and $6.5 billion after fiscal 2021; no principal payments are due in fiscal 2019 and 2021. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $282 million and $8 million during fiscal 2016 and 2015, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0001234452-16-000552:notes:76]
Derivatives. The Company’s primary objectives for holding derivative instruments are to manage interest rate risk on its long-term debt and to manage foreign exchange risk for certain foreign currency revenue and operating expenditure transactions. To a lesser extent, the Company also holds derivative instruments in its investment portfolios to manage risk by acquiring or reducing foreign exchange risk, interest rate risk and/or equity, prepayment and credit risk. Derivative instruments are recorded at fair value and included in other current assets, noncurrent assets, other accrued liabilities or other noncurrent liabilities based on their maturity dates. Counterparties to the Company’s derivative instruments are all major banking institutions.

[0001234452-16-000552:notes:77]
Interest Rate Swaps: The Company manages its exposure to certain interest rate risks related to its long-term debt through the use of interest rate swaps. Such swaps allow the Company to effectively convert fixed-rate payments into floating-rate payments based on LIBOR. These transactions are designated as fair value hedges, and the gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate debt attributable to the hedged risks, are recognized in earnings as interest expense in the current period. The interest settlement payments associated with the interest rate swap agreements are classified as cash flows from operating activities in the consolidated statements of cash flows.

[0001234452-16-000552:notes:78]
At September 25, 2016 and September 27, 2015, the aggregate fair values of the Company’s interest rate swaps related to its long-term debt were $65 million and $32 million, respectively, and were recorded in noncurrent assets. The swaps had an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate debt due in 2018 and approximately 43% and 50% of the fixed-rate debt due in 2020 and 2022, respectively, into floating-rate debt. The maturities of the swaps match the Company’s fixed-rate debt due in 2018, 2020 and 2022.

[0001234452-16-000552:notes:79]
Foreign Currency Hedges: The Company manages its exposure to foreign exchange market risks, when deemed appropriate, through the use of derivative instruments, including foreign currency forward and option contracts with financial counterparties. These derivative instruments mature between one and nine months. Gains and losses arising from the effective portion of such contracts that are designated as cash flow hedging instruments are recorded as a component of accumulated other comprehensive income as gains and losses on derivative instruments, net of income taxes. The hedging gains and losses in accumulated other comprehensive income are subsequently reclassified to revenues or costs and expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect the Company’s earnings. Gains and losses arising from the ineffective portion of such contracts are recorded in net investment income as gains and losses on derivative instruments. The cash flows associated with derivative instruments designated as cash flow or net investment hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The cash flows associated with the ineffective portion of such derivative instruments are classified as cash flows from investing activities in the consolidated statements of cash flows. At September 25, 2016 and September 27, 2015, the fair values of the Company’s foreign currency option and forward contracts used to hedge foreign currency risk recorded in total assets and in total liabilities were negligible. All such instruments were designated as cash flow hedges.

[0001234452-16-000552:notes:80]
Investment Portfolio Derivatives: The Company also utilizes currency forwards, futures, options and swaps that are not designated as hedging instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks in its marketable securities investment portfolios. The Company primarily uses such derivative instruments for risk management and not speculative purposes. These derivative instruments mature over various periods up to five years. Gains and losses arising from changes in the fair values of such derivative instruments are recorded in net investment income as gains and losses on derivative instruments. The cash flows associated with such derivative instruments are classified as cash flows from investing activities in the consolidated statements of cash flows. At September 25, 2016 and September 27, 2015, the fair values of these derivative instruments recorded in total assets and in total liabilities were negligible.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0001234452-16-000552:notes:81]
A summary of RSU transactions for all equity compensation plans follows:

[0001234452-16-000552:notes:82]
A summary of stock option transactions for all equity compensation plans follows:


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001234452-16-000552:notes:83]
Discontinued Operations

[0001234452-16-000552:notes:84]
On November 25, 2013, the Company completed its sale of the North and Latin America operations of its Omnitracs division to a U.S.-based private equity firm for cash consideration of $788 million (net of cash sold). As a result, the Company recorded a gain in discontinued operations of $665 million ($430 million net of income tax expense) during fiscal 2014. The revenues and operating results of the North and Latin America operations of the Omnitracs division, which comprised substantially all of the Omnitracs division, were not presented as discontinued operations in any fiscal period because they were immaterial.


## us-gaap:DividendsDeclaredTableTextBlock

[0001234452-16-000552:notes:85]
Dividends charged to retained earnings in fiscal 2016, 2015 and 2014 were as follows (in millions, except per share data):

[0001234452-16-000552:notes:86]
|  | 2016 |  | 2015 |  | 2014 |
|  | Per Share |  | Total |  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.48 |  |  | $ | 730 |  |  | $ | 0.42 |  |  | $ | 710 |  |  | $ | 0.35 |  |  | $ | 599 |  |
| Second quarter | 0.48 |  |  | 726 |  |  | 0.42 |  |  | 702 |  |  | 0.35 |  |  | 599 |  |
| Third quarter | 0.53 |  |  | 794 |  |  | 0.48 |  |  | 771 |  |  | 0.42 |  |  | 718 |  |
| Fourth quarter | 0.53 |  |  | 796 |  |  | 0.48 |  |  | 749 |  |  | 0.42 |  |  | 713 |  |
|  | $ | 2.02 |  |  | $ | 3,046 |  |  | $ | 1.80 |  |  | $ | 2,932 |  |  | $ | 1.54 |  |  | $ | 2,629 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001234452-16-000552:notes:87]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for fiscal 2016, 2015 and 2014 were 13,864,000, 20,724,000 and 30,655,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 2,435,000, 4,652,000 (which were primarily attributable to the ASR Agreements (Note 4)) and 846,000 during fiscal 2016, 2015 and 2014


## us-gaap:EquityMethodInvestmentsTextBlock

[0001234452-16-000552:notes:88]
The carrying values of the Company’s non-marketable equity investments are recorded in other noncurrent assets and were as follows (in millions):

[0001234452-16-000552:notes:89]
|  | September 25, 2016 |  | September 27, 2015 |
| Equity method investments | $ | 324 |  |  | $ | 163 |  |
| Cost method investments | 531 |  |  | 457 |  |
|  | $ | 855 |  |  | $ | 620 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001234452-16-000552:notes:90]
The following table includes the activity for mortgage- and asset-backed and auction rate securities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-16-000552:notes:91]
|  | 2016 |  | 2015 |
| Beginning balance of Level 3 | $ | 224 |  |  | $ | 269 |  |
| Total realized and unrealized gains or losses: |  |  |  |
| Included in investment income, net | (4 | ) |  | 3 |  |
| Included in other comprehensive income (loss) | (1 | ) |  | (4 | ) |
| Purchases | 2 |  |  | 69 |  |
| Sales | (106 | ) |  | (46 | ) |
| Settlements | (45 | ) |  | (64 | ) |
| Transfers out of Level 3 | (27 | ) |  | (3 | ) |
| Ending balance of Level 3 | $ | 43 |  |  | $ | 224 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001234452-16-000552:notes:92]
Fair Value Measurements

[0001234452-16-000552:notes:93]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at September 25, 2016 (in millions):

[0001234452-16-000552:notes:94]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 2,679 |  |  | $ | 2,598 |  |  | $ | — |  |  | $ | 5,277 |  |
| Marketable securities |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 867 |  |  | 1,348 |  |  | — |  |  | 2,215 |  |
| Corporate bonds and notes | — |  |  | 18,743 |  |  | — |  |  | 18,743 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 1,854 |  |  | 43 |  |  | 1,897 |  |
| Equity and preferred securities and equity funds | 1,005 |  |  | 741 |  |  | — |  |  | 1,746 |  |
| Debt funds | — |  |  | 1,803 |  |  | — |  |  | 1,803 |  |
| Total marketable securities | 1,872 |  |  | 24,489 |  |  | 43 |  |  | 26,404 |  |
| Derivative instruments | — |  |  | 71 |  |  | — |  |  | 71 |  |
| Other investments | 303 |  |  | — |  |  | — |  |  | 303 |  |
| Total assets measured at fair value | $ | 4,854 |  |  | $ | 27,158 |  |  | $ | 43 |  |  | $ | 32,055 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |
| Other liabilities | 302 |  |  | — |  |  | — |  |  | 302 |  |
| Total liabilities measured at fair value | $ | 302 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 313 |  |

[0001234452-16-000552:notes:95]
Activity between Levels of the Fair Value Hierarchy. There were no significant transfers between Level 1 and Level 2 during fiscal 2016 and 2015. When a determination is made to classify an asset or liability within Level 3, the determination is based upon the significance of the unobservable inputs to the overall fair value measurement. The following table includes the activity for mortgage- and asset-backed and auction rate securities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-16-000552:notes:96]
The Company recognizes transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. Transfers out of Level 3 during fiscal 2016 and 2015 primarily consisted of debt securities with significant upgrades in credit ratings or for which there were observable inputs. There were no transfers into Level 3 during fiscal 2016 and 2015.

[0001234452-16-000552:notes:97]
Nonrecurring Fair Value Measurements. The Company measures certain assets at fair value on a nonrecurring basis. These assets include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During fiscal 2016, the Company recorded impairment charges of $43 million to write down certain intangible assets based on updated cash flow projections. Such charges were recorded in cost of revenues, research and development expenses and selling, general and administrative expenses. The estimation of fair value and cash flows used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During fiscal 2015 and 2014, the Company updated the business plans and related internal forecasts related to certain of the Company’s businesses, resulting in impairment charges to write down certain property, plant and equipment, intangible assets and goodwill (Note 2). The Company determined the fair values using cost, income and market approaches. The estimation of fair value and cash flows used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During fiscal 2016, 2015 and 2014, the Company did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001234452-16-000552:notes:98]
Fair Value Measurements. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants as of the measurement date. Applicable accounting guidance provides an established hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Observable inputs are inputs that market participants would use in valuing the asset or liability and are developed based on market data obtained from sources independent of the Company. Unobservable inputs are inputs that reflect the Company’s assumptions about the factors that market participants would use in valuing the asset or liability. There are three levels of inputs that may be used to measure fair value:

[0001234452-16-000552:notes:99]
| • | Level 1 includes financial instruments for which quoted market prices for identical instruments are available in active markets. |

[0001234452-16-000552:notes:100]
| • | Level 2 includes financial instruments for which there are inputs other than quoted prices included within Level 1 that are observable for the instrument. |

[0001234452-16-000552:notes:101]
| • | Level 3 includes financial instruments for which fair value is derived from valuation techniques in which one or more significant inputs are unobservable, including the Company’s own assumptions. |

[0001234452-16-000552:notes:102]
Assets and liabilities are classified based on the lowest level of input that is significant to the fair value measurements. The Company reviews the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy.

[0001234452-16-000552:notes:103]
Cash Equivalents and Marketable Securities: With the exception of auction rate securities, the Company obtains pricing information from quoted market prices, pricing vendors or quotes from brokers/dealers. The Company conducts reviews of its primary pricing vendors to determine whether the inputs used in the vendor’s pricing processes are deemed to be observable. The fair value for interest-bearing securities includes accrued interest.

[0001234452-16-000552:notes:104]
The fair value of U.S. Treasury securities and government-related securities, corporate bonds and notes and common and preferred stock is generally determined using standard observable inputs, including reported trades, quoted market prices, matrix pricing, benchmark yields, broker/dealer quotes, issuer spreads, two-sided markets and/or benchmark securities.

[0001234452-16-000552:notes:105]
The fair value of debt and equity funds is reported at published net asset values. The Company assesses the daily frequency and size of transactions at published net asset values and/or the funds’ underlying holdings to determine whether fair value is based on observable or unobservable inputs.

[0001234452-16-000552:notes:106]
The fair value of mortgage- and asset-backed securities is derived from the use of matrix pricing (prices for similar securities) or, in some cases, cash flow pricing models with observable inputs, such as contractual terms, maturity, credit rating and/or securitization structure to determine the timing and amount of future cash flows. Certain mortgage- and asset-backed securities may require the use of significant unobservable inputs to estimate fair value, such as default likelihood, recovery rates and prepayment speed.

[0001234452-16-000552:notes:107]
The fair value of auction rate securities is estimated by the Company using a discounted cash flow model that incorporates transaction details, such as contractual terms, maturity and timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery, the future state of the auction rate market and credit valuation adjustments of market participants. Though most of the securities held by the Company are pools of student loans guaranteed by the U.S. government, prepayment speeds and illiquidity discounts are considered significant unobservable inputs. These additional inputs are generally unobservable, and therefore, auction rate securities are included in Level 3.

[0001234452-16-000552:notes:108]
Derivative Instruments: Derivative instruments that are traded on an exchange are valued using quoted market prices and are included in Level 1. Derivative instruments that are not traded on an exchange are valued using conventional calculations/models that are primarily based on observable inputs, such as foreign currency exchange rates, volatilities and interest rates, and therefore, such derivative instruments are included in Level 2.

[0001234452-16-000552:notes:109]
Other Investments and Other Liabilities: Other investments and other liabilities included in Level 1 are comprised of the Company’s deferred compensation plan liability and related assets, which consist of mutual funds classified as trading securities, and are included in other assets.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001234452-16-000552:notes:110]
Foreign Currency. Certain foreign subsidiaries use a local currency as the functional currency. Resulting translation gains or losses are recognized as a component of accumulated other comprehensive income. Transaction gains or losses related to balances denominated in a currency other than the functional currency are recognized in the consolidated statements of operations.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001234452-16-000552:notes:111]
Goodwill and Other Intangible Assets. Goodwill represents the excess of purchase price over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Acquired intangible assets other than goodwill are amortized over their useful lives unless the lives are determined to be indefinite. For intangible assets purchased in a business combination, the estimated fair values of the assets received are used to establish their recorded values. For intangible assets acquired in a non-monetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001234452-16-000552:notes:112]
Impairment of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. Goodwill and other indefinite-lived intangible assets are tested annually for impairment in the fourth fiscal quarter and in interim periods if certain events occur indicating that the carrying amounts may be impaired. If a qualitative assessment is used and the Company determines that the fair value of a reporting unit or indefinite-lived intangible asset is more likely than not (i.e., a likelihood of more than 50%) less than its carrying amount, a quantitative impairment test will be performed. If goodwill is quantitatively assessed for impairment, a two-step approach is applied. First, the Company compares the estimated fair value of the reporting unit in which the goodwill resides to its carrying value. The second step, if necessary, measures the amount of impairment, if any, by comparing the implied fair value of goodwill to its carrying value. Other indefinite-lived intangible assets are quantitatively assessed for impairment, if necessary, by comparing their estimated fair values to their carrying values. If the carrying value exceeds the fair value, the difference is recorded as an impairment.

[0001234452-16-000552:notes:113]
Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by comparing the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Long-lived assets to be disposed of by sale are reported at the lower of their carrying amounts or their estimated fair values less costs to sell and are not depreciated.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001234452-16-000552:notes:114]
Income Taxes

[0001234452-16-000552:notes:115]
The components of the income tax provision for continuing operations were as follows (in millions):

[0001234452-16-000552:notes:116]
|  | 2016 |  | 2015 |  | 2014 |
| Current provision (benefit): |  |  |  |  |  |
| Federal | $ | 4 |  |  | $ | (67 | ) |  | $ | 172 |  |
| State | 4 |  |  | 4 |  |  | 10 |  |
| Foreign | 1,411 |  |  | 1,307 |  |  | 1,116 |  |
|  | 1,419 |  |  | 1,244 |  |  | 1,298 |  |
| Deferred (benefit) provision: |  |  |  |  |  |
| Federal | (184 | ) |  | (9 | ) |  | (30 | ) |
| State | 6 |  |  | 1 |  |  | (10 | ) |
| Foreign | (110 | ) |  | (17 | ) |  | (14 | ) |
|  | (288 | ) |  | (25 | ) |  | (54 | ) |
|  | $ | 1,131 |  |  | $ | 1,219 |  |  | $ | 1,244 |  |

[0001234452-16-000552:notes:117]
The foreign component of the income tax provision consists primarily of foreign withholding taxes on royalty fees included in United States earnings.

[0001234452-16-000552:notes:118]
The components of income from continuing operations before income taxes by United States and foreign jurisdictions were as follows (in millions):

[0001234452-16-000552:notes:119]
|  | 2016 |  | 2015 |  | 2014 |
| United States | $ | 3,032 |  |  | $ | 2,993 |  |  | $ | 3,213 |  |
| Foreign | 3,801 |  |  | 3,494 |  |  | 5,565 |  |
|  | $ | 6,833 |  |  | $ | 6,487 |  |  | $ | 8,778 |  |

[0001234452-16-000552:notes:120]
The following is a reconciliation of the expected statutory federal income tax provision to the Company’s actual income tax provision for continuing operations (in millions):

[0001234452-16-000552:notes:121]
|  | 2016 |  | 2015 |  | 2014 |
| Expected income tax provision at federal statutory tax rate | $ | 2,392 |  |  | $ | 2,270 |  |  | $ | 3,072 |  |
| State income tax provision, net of federal benefit | 19 |  |  | 18 |  |  | 24 |  |
| Foreign income taxed at other than U.S. rates | (1,068 | ) |  | (937 | ) |  | (1,750 | ) |
| Research and development tax credits | (143 | ) |  | (148 | ) |  | (61 | ) |
| Worthless stock deduction of domestic subsidiary | (101 | ) |  | — |  |  | — |  |
| Other | 32 |  |  | 16 |  |  | (41 | ) |
|  | $ | 1,131 |  |  | $ | 1,219 |  |  | $ | 1,244 |  |

[0001234452-16-000552:notes:122]
During fiscal 2016, the Company recorded a tax benefit of $101 million from a worthless stock deduction on a domestic subsidiary of one of the Company’s former display businesses. Also, during fiscal 2016, the United States government permanently reinstated the federal research and development tax credit retroactively to January 1, 2015. As a result of the reinstatement, the Company recorded a tax benefit of $79 million in fiscal 2016 related to fiscal 2015.

[0001234452-16-000552:notes:123]
During fiscal 2015, the NDRC imposed a fine of $975 million (Note 2), which was not deductible for tax purposes and was substantially attributable to a foreign jurisdiction. Additionally, during fiscal 2015, the Company recorded a tax benefit of $101 million related to fiscal 2014 resulting from the United States government reinstating the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. The effective tax rate for fiscal 2015 also reflected the United States federal research and development tax credit generated through December 31, 2014, the date on which the credit expired, and a $61 million tax benefit as a result of a favorable tax audit settlement with the Internal Revenue Service (IRS) related to Qualcomm Atheros, Inc.’s pre-acquisition 2010 and 2011 tax returns.

[0001234452-16-000552:notes:124]
The Company’s QCT segment’s non-United States headquarters is located in Singapore. The Company has obtained tax incentives in Singapore that commenced in March 2012, which are effective through March 2027, that result in a tax exemption for the first five years provided that the Company meets specified employment and investment criteria. The Company’s Singapore tax rate will increase in fiscal 2017 and again in fiscal 2027 as a result of the expiration of these incentives. Had the Company established QCT’s non-United States headquarters in Singapore without these tax incentives, the Company’s income tax expense would have been higher and impacted earnings per share attributable to Qualcomm as follows (in millions, except per share amounts):

[0001234452-16-000552:notes:125]
|  | 2016 |  | 2015 |  | 2014 |
| Additional income tax expense | $ | 487 |  |  | $ | 656 |  |  | $ | 690 |  |
| Reduction to diluted earnings per share | $ | 0.32 |  |  | $ | 0.40 |  |  | $ | 0.40 |  |

[0001234452-16-000552:notes:126]
The Company considers the operating earnings of certain non-United States subsidiaries to be indefinitely reinvested outside the United States based on the Company’s plans for use and/or investment outside the United States and the Company’s belief that its sources of cash and liquidity in the United States will be sufficient to meet future domestic cash needs. The Company has not recorded a deferred tax liability of approximately $11.5 billion related to the United States federal and state income taxes and foreign withholding taxes on approximately $32.5 billion of undistributed earnings of certain non-United States subsidiaries indefinitely reinvested outside the United States. Should the Company decide to no longer indefinitely reinvest such earnings outside the United States, the Company would have to adjust the income tax provision in the period management makes such determination.

[0001234452-16-000552:notes:127]
The Company files income tax returns in the United States federal jurisdiction and various state and foreign jurisdictions. The Company is currently a participant in the IRS Compliance Assurance Process, whereby the IRS and the Company endeavor to agree on the treatment of all tax issues prior to the tax return being filed. The IRS completed its examination of the Company’s tax return for fiscal 2014 and issued a no change letter in December 2015, resulting in no change to the income tax provision. The Company is no longer subject to United States federal income tax examinations for years prior to fiscal 2014. The Company is subject to examination by the California Franchise Tax Board for fiscal years after 2011. The Company is also subject to income taxes in other taxing jurisdictions in the United States and around the world, many of which are open to tax examinations for periods after fiscal 2000. The outcome of any state or foreign income tax examination is not expected to be material to the Company’s consolidated financial statements.

[0001234452-16-000552:notes:128]
The Company had deferred tax assets and deferred tax liabilities as follows (in millions):

[0001234452-16-000552:notes:129]
|  | September 25, 2016 |  | September 27, 2015 |
| Unused tax credits | $ | 1,256 |  |  | $ | 897 |  |
| Unearned revenues | 920 |  |  | 1,029 |  |
| Unrealized losses on marketable securities | 493 |  |  | 441 |  |
| Accrued liabilities and reserves | 409 |  |  | 317 |  |
| Share-based compensation | 277 |  |  | 331 |  |
| Unused net operating losses | 218 |  |  | 265 |  |
| Other | 107 |  |  | 95 |  |
| Total gross deferred tax assets | 3,680 |  |  | 3,375 |  |
| Valuation allowance | (754 | ) |  | (635 | ) |
| Total net deferred tax assets | 2,926 |  |  | 2,740 |  |
| Intangible assets | (502 | ) |  | (548 | ) |
| Unrealized gains on marketable securities | (430 | ) |  | (273 | ) |
| Other | (133 | ) |  | (105 | ) |
| Total deferred tax liabilities | (1,065 | ) |  | (926 | ) |
| Net deferred tax assets | $ | 1,861 |  |  | $ | 1,814 |  |
| Reported as: |  |  |  |
| Current deferred tax assets | $ | — |  |  | $ | 635 |  |
| Non-current deferred tax assets | 2,030 |  |  | 1,453 |  |
| Current deferred tax liabilities (1) | — |  |  | (4 | ) |
| Non-current deferred tax liabilities (1) | (169 | ) |  | (270 | ) |
|  | $ | 1,861 |  |  | $ | 1,814 |  |

[0001234452-16-000552:notes:130]
| (1) | Current deferred tax liabilities and non-current deferred tax liabilities were included in other current liabilities and other liabilities, respectively, in the consolidated balance sheets. |

[0001234452-16-000552:notes:131]
At September 25, 2016, the Company had unused federal net operating loss carryforwards of $267 million expiring from 2021 through 2034, unused state net operating loss carryforwards of $892 million expiring from 2017 through 2036 and unused foreign net operating loss carryforwards of $287 million expiring from 2019 through 2025. At September 25, 2016, the Company had unused state tax credits of $637 million, of which substantially all may be carried forward indefinitely, unused federal tax credits of $595 million expiring from 2025 through 2036 and unused tax credits of $24 million in foreign jurisdictions expiring from 2033 through 2036. The Company does not expect its federal net operating loss carryforwards to expire unused.

[0001234452-16-000552:notes:132]
The Company believes, more likely than not, that it will have sufficient taxable income after deductions related to share-based awards to utilize the majority of its deferred tax assets. At September 25, 2016, the Company has provided a valuation allowance on certain state tax credits, foreign deferred tax assets and state net operating losses of $627 million, $94 million and $33 million, respectively. The valuation allowances reflect the uncertainties surrounding the Company’s ability to generate sufficient future taxable income in certain foreign and state tax jurisdictions to utilize its net operating losses and the Company’s ability to generate sufficient capital gains to utilize all capital losses.

[0001234452-16-000552:notes:133]
A summary of the changes in the amount of unrecognized tax benefits for fiscal 2016, 2015 and 2014 follows (in millions):

[0001234452-16-000552:notes:134]
|  | 2016 |  | 2015 |  | 2014 |
| Beginning balance of unrecognized tax benefits | $ | 40 |  |  | $ | 87 |  |  | $ | 221 |  |
| Additions based on prior year tax positions | 20 |  |  | 31 |  |  | 1 |  |
| Reductions for prior year tax positions and lapse in statute of limitations | (6 | ) |  | (70 | ) |  | (67 | ) |
| Additions for current year tax positions | 218 |  |  | 5 |  |  | 5 |  |
| Settlements with taxing authorities | (1 | ) |  | (13 | ) |  | (73 | ) |
| Ending balance of unrecognized tax benefits | $ | 271 |  |  | $ | 40 |  |  | $ | 87 |  |

[0001234452-16-000552:notes:135]
The Company does not expect any unrecognized tax benefits recorded at September 25, 2016 to result in a significant cash payment in fiscal 2017. Unrecognized tax benefits at September 25, 2016 included $191 million for tax positions that, if recognized, would impact the effective tax rate. The unrecognized tax benefits differ from the amount that would affect the Company’s effective tax rate primarily because the unrecognized tax benefits were included on a gross basis and did not reflect secondary impacts such as the federal deduction for state taxes, adjustments to deferred tax assets and the valuation allowance that might be required if the Company’s tax positions are sustained. The increase in unrecognized tax benefits in fiscal 2016 was primarily due to tax positions related to classification of income. The decrease in unrecognized tax benefits in fiscal 2015 primarily resulted from a favorable tax audit settlement with the IRS related to Qualcomm Atheros, Inc.’s pre-acquisition 2010 and 2011 tax returns, which was partially offset by an increase related to the CSR acquisition (Note 9). The decrease in unrecognized tax benefits in fiscal 2014 was primarily due to an agreement reached with the IRS on components of the Company’s fiscal 2013 tax returns. The Company believes that it is reasonably possible that the total amount of unrecognized tax benefits at September 25, 2016 may increase or decrease in fiscal 2017.

[0001234452-16-000552:notes:136]
Cash amounts paid for income taxes, net of refunds received, were $1.3 billion, $1.2 billion and $1.2 billion for fiscal 2016, 2015 and 2014, respectively.


## us-gaap:IncomeTaxPolicyTextBlock

[0001234452-16-000552:notes:137]
Income Taxes. The asset and liability approach is used to recognize deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax bases of assets and liabilities. Tax law and rate changes are reflected in income in the period such changes are enacted. The Company records a valuation allowance to reduce deferred tax assets to the amount that is more likely than not to be realized. The Company includes interest and penalties related to income taxes, including unrecognized tax benefits, within income tax expense.

[0001234452-16-000552:notes:138]
The Company’s income tax returns are based on calculations and assumptions that are subject to examination by the Internal Revenue Service and other tax authorities. In addition, the calculation of the Company’s tax liabilities involves dealing with uncertainties in the application of complex tax regulations. The Company recognizes liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. While the Company believes it has appropriate support for the positions taken on its tax returns, the Company regularly assesses the potential outcomes of examinations by tax authorities in determining the adequacy of its provision for income taxes. The Company continually assesses the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts that give rise to a revision become known.

[0001234452-16-000552:notes:139]
The Company recognizes windfall tax benefits associated with share-based awards directly to stockholders’ equity when realized. A windfall tax benefit occurs when the actual tax benefit realized by the Company upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that the Company had recorded. The Company records windfall tax benefits to stockholders’ equity. A shortfall occurs when the actual tax benefit realized by the Company upon an employee’s disposition of a share-based award is less than the deferred tax asset, if any, associated with the award that the Company has recorded. The Company records shortfall tax detriments when realized to stockholders’ equity to the extent that previous windfall tax benefits exist (referred to as the APIC windfall pool), with any remainder recognized in income tax expense. The Company had a sufficient APIC windfall pool to absorb all shortfalls that occurred in fiscal 2016. When assessing whether a tax benefit relating to share-based compensation has been realized, the Company follows the tax law ordering method, under which current year share-based compensation deductions are assumed to be utilized before net operating loss carryforwards and other tax attributes.


## us-gaap:InventoryPolicyTextBlock

[0001234452-16-000552:notes:140]
Inventories. Inventories are valued at the lower of cost or market (replacement cost, not to exceed net realizable value) using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers, among other things.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001234452-16-000552:notes:141]
At September 25, 2016, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001234452-16-000552:notes:142]
| Years to Maturity |  |  |  |  |
| Less Than One Year |  | One to Five Years |  | Five to Ten Years |  | Greater Than Ten Years |  | No Single Maturity Date |  | Total |
| $ | 4,892 |  |  | $ | 12,819 |  |  | $ | 2,269 |  |  | $ | 978 |  |  | $ | 3,700 |  |  | $ | 24,658 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001234452-16-000552:notes:143]
Marketable Securities

[0001234452-16-000552:notes:144]
Marketable securities were comprised as follows (in millions):

[0001234452-16-000552:notes:145]
|  | Current |  | Noncurrent |
|  | September 25, 2016 |  | September 27, 2015 |  | September 25, 2016 |  | September 27, 2015 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 12 |  |
| Corporate bonds and notes | — |  |  | — |  |  | — |  |  | 364 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | — |  |  | — |  |  | 242 |  |
| Total trading | — |  |  | — |  |  | — |  |  | 618 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 1,116 |  |  | 156 |  |  | 1,099 |  |  | 691 |  |
| Corporate bonds and notes | 10,159 |  |  | 7,926 |  |  | 8,584 |  |  | 7,112 |  |
| Mortgage- and asset-backed and auction rate securities | 1,363 |  |  | 1,302 |  |  | 534 |  |  | 263 |  |
| Equity and preferred securities and equity funds | 64 |  |  | 377 |  |  | 1,682 |  |  | 1,253 |  |
| Debt funds | — |  |  | — |  |  | 1,803 |  |  | 2,909 |  |
| Total available-for-sale | 12,702 |  |  | 9,761 |  |  | 13,702 |  |  | 12,228 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | — |  |  | 780 |  |
| Total marketable securities | $ | 12,702 |  |  | $ | 9,761 |  |  | $ | 13,702 |  |  | $ | 13,626 |  |

[0001234452-16-000552:notes:146]
During fiscal 2016, the Company exited an investment in a debt fund for which the Company elected the fair value option. The investment would have otherwise been recorded using the equity method. Changes in fair value associated with this investment were recognized in net investment income. During fiscal 2016 and 2015, the net decrease in fair value associated with this investment was negligible and $10 million, respectively. During fiscal 2014, the net increase in fair value associated with this investment was $33 million.

[0001234452-16-000552:notes:147]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net losses recognized on debt securities classified as trading held at September 27, 2015 and September 28, 2014, respectively, were negligible.

[0001234452-16-000552:notes:148]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities and auction rate securities.

[0001234452-16-000552:notes:149]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001234452-16-000552:notes:150]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| 2016 | $ | 277 |  |  | $ | (37 | ) |  | $ | 240 |  |
| 2015 | 540 |  |  | (52 | ) |  | 488 |  |
| 2014 | 732 |  |  | (18 | ) |  | 714 |  |

[0001234452-16-000552:notes:151]
Available-for-sale securities were comprised as follows (in millions):

[0001234452-16-000552:notes:152]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| September 25, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,554 |  |  | $ | 204 |  |  | $ | (12 | ) |  | $ | 1,746 |  |
| Debt securities (including debt funds) | 24,363 |  |  | 388 |  |  | (93 | ) |  | 24,658 |  |
|  | $ | 25,917 |  |  | $ | 592 |  |  | $ | (105 | ) |  | $ | 26,404 |  |
| September 27, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,394 |  |  | $ | 264 |  |  | $ | (28 | ) |  | $ | 1,630 |  |
| Debt securities (including debt funds) | 20,459 |  |  | 185 |  |  | (285 | ) |  | 20,359 |  |
|  | $ | 21,853 |  |  | $ | 449 |  |  | $ | (313 | ) |  | $ | 21,989 |  |

[0001234452-16-000552:notes:153]
The following table shows the gross unrealized losses and fair values of the Company’s investments in individual securities that are classified as available-for-sale and have been in a continuous unrealized loss position deemed to be temporary for less than 12 months and for more than 12 months, aggregated by investment category (in millions):

[0001234452-16-000552:notes:154]
|  | September 25, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 444 |  |  | $ | (5 | ) |  | $ | 16 |  |  | $ | — |  |
| Corporate bonds and notes | 2,775 |  |  | (12 | ) |  | 1,033 |  |  | (65 | ) |
| Mortgage- and asset-backed and auction rate securities | 337 |  |  | (3 | ) |  | 211 |  |  | (2 | ) |
| Equity and preferred securities and equity funds | 312 |  |  | (4 | ) |  | 130 |  |  | (8 | ) |
| Debt funds | — |  |  | — |  |  | 309 |  |  | (6 | ) |
|  | $ | 3,868 |  |  | $ | (24 | ) |  | $ | 1,699 |  |  | $ | (81 | ) |

[0001234452-16-000552:notes:155]
|  | September 27, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 304 |  |  | $ | (4 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 7,656 |  |  | (93 | ) |  | 368 |  |  | (62 | ) |
| Mortgage- and asset-backed and auction rate securities | 862 |  |  | (3 | ) |  | 108 |  |  | (1 | ) |
| Equity and preferred securities and equity funds | 392 |  |  | (28 | ) |  | 17 |  |  | — |  |
| Debt funds | 1,792 |  |  | (117 | ) |  | 124 |  |  | (5 | ) |
|  | $ | 11,006 |  |  | $ | (245 | ) |  | $ | 617 |  |  | $ | (68 | ) |

[0001234452-16-000552:notes:156]
At September 25, 2016, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, as of September 25, 2016, the Company had the ability and the intent to hold such securities until they recovered, which was expected to be within a reasonable period of time, and for debt securities and preferred stock with unrealized losses, the Company did not have the intent to sell, nor was it more likely than not that the Company would be required to sell, such securities before recovery or maturity. In the first quarter of fiscal 2017, the Company announced that it entered into an agreement to acquire NXP Semiconductors N.V. (Note 14). As a result, prior to the closing, the Company expects to divest a substantial portion of its marketable securities portfolio in order to finance that transaction. Given the change in the Company’s intention to sell certain marketable securities, the Company may recognize losses.


## us-gaap:LegalCostsPolicyTextBlock

[0001234452-16-000552:notes:157]
The Company’s legal costs associated with defending itself are recorded to expense as incurred.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001234452-16-000552:notes:158]
Recent Accounting Pronouncements. In November 2015, the Financial Accounting Standards Board (FASB) issued new guidance related to accounting for income taxes, which requires all deferred tax assets and liabilities to be classified as noncurrent on the balance sheet. The Company early adopted the new guidance prospectively in the second quarter of fiscal 2016. Prior period amounts have not been adjusted.

[0001234452-16-000552:notes:159]
In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Adoption one year early is permitted. Two methods of adoption are permitted: (a) full retrospective adoption, meaning the standard is applied to all periods presented or (b) modified retrospective adoption, meaning the cumulative effect of applying the new guidance is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the new guidance early and is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.

[0001234452-16-000552:notes:160]
In January 2016, the FASB issued new guidance on classifying and measuring financial instruments, which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk be recognized separately in other comprehensive income. Additionally, it changes the disclosure requirements for financial instruments. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Early adoption is permitted for certain provisions. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt certain provisions early.

[0001234452-16-000552:notes:161]
In February 2016, the FASB issued new guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease guidance. The new guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. The new guidance must be adopted using the modified retrospective approach and will be effective for the Company starting in the first quarter of fiscal 2020. Early adoption is permitted. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.

[0001234452-16-000552:notes:162]
In March 2016, the FASB issued new guidance that changes the accounting for share-based payments. Under the new guidance, excess tax benefits associated with share-based payment awards will be recognized through earnings when the awards vest or settle, rather than in stockholders’ equity. In addition, it will increase the number of shares an employer can withhold to cover income taxes on share-based payment awards and still qualify for the exemption to liability classification. The new guidance will be effective for the Company starting in the first quarter of fiscal 2018. Early adoption is permitted in any annual or interim period. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.

[0001234452-16-000552:notes:163]
In June 2016, the FASB issued new guidance that changes the accounting for recognizing impairments of financial assets. Under the new guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The new guidance also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The new guidance will be effective for the Company starting in the first quarter of fiscal 2021. Early adoption is permitted starting in the first quarter of fiscal 2020. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.

[0001234452-16-000552:notes:164]
In August 2016, the FASB issued new guidance related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its consolidated financial statements as well as whether to adopt the new guidance early.

[0001234452-16-000552:notes:165]
In October 2016, the FASB issued new guidance that changes the accounting for income tax effects of intra-entity transfers of assets other than inventory. Under the new guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its consolidated financial statements as well as whether to adopt the new guidance early.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001234452-16-000552:notes:166]
The Company and Its Significant Accounting Policies

[0001234452-16-000552:notes:167]
The Company. QUALCOMM Incorporated, a Delaware corporation, and its subsidiaries (collectively the Company or Qualcomm) develop, design, manufacture, have manufactured on its behalf and market digital communications products, which principally consist of integrated circuits and system software, for use in mobile devices, wireless networks, broadband gateway equipment and consumer electronic devices. The Company also grants licenses to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products and receives fixed license fees (payable in one or more installments) as well as ongoing royalties based on sales by licensees of wireless products incorporating its patented technologies.

[0001234452-16-000552:notes:168]
Financial Statement Preparation. The preparation of financial statements in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in the Company’s consolidated financial statements and the accompanying notes. Examples of the Company’s significant accounting estimates that may involve a higher degree of judgment and complexity than others include: the determination of other-than-temporary impairments of marketable securities and other investments; the valuation of inventories; the valuation and assessment of the recoverability of goodwill and other indefinite-lived and long-lived assets; the recognition, measurement and disclosure of loss contingencies related to legal proceedings; and the calculation of tax liabilities, including the recognition and measurement of uncertain tax positions. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

[0001234452-16-000552:notes:169]
Fiscal Year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. The fiscal years ended September 25, 2016, September 27, 2015 and September 28, 2014 included 52 weeks.

[0001234452-16-000552:notes:170]
Marketable Securities. Marketable securities include trading securities, available-for-sale securities and securities for which the Company has elected the fair value option. The classification of marketable securities within these categories is determined at the time of purchase and reevaluated at each balance sheet date. The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange and/or equity, prepayment and credit risk as trading. The Company classifies marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value. The net unrealized gains or losses on available-for-sale securities are recorded as a component of accumulated other comprehensive income, net of income taxes. The unrealized gains or losses on trading securities and securities for which the Company has elected the fair value option are recognized in net investment income. The realized gains and losses on marketable securities are determined using the specific identification method.

[0001234452-16-000552:notes:171]
At each balance sheet date, the Company assesses available-for-sale securities in an unrealized loss position to determine whether the unrealized loss is other than temporary. The Company considers factors including: the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; how long the market value of the security has been less than its cost basis; the security’s relative performance versus its peers, sector or asset class; expected market volatility; the market and economy in general; analyst recommendations and price targets; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.

[0001234452-16-000552:notes:172]
If a debt security’s market value is below amortized cost and the Company either intends to sell the security or it is more likely than not that the Company will be required to sell the security before its anticipated recovery, the Company records an other-than-temporary impairment charge to net investment income for the entire amount of the impairment. For the remaining debt securities, if an other-than-temporary impairment exists, the Company separates the other-than-temporary impairment into the portion of the loss related to credit factors, or the credit loss portion, which is recorded as a charge to net investment income, and the portion of the loss that is not related to credit factors, or the noncredit loss portion, which is recorded as a component of other accumulated comprehensive income, net of income taxes.

[0001234452-16-000552:notes:173]
For equity securities, the Company considers the loss relative to the expected volatility and the likelihood of recovery over a reasonable period of time. If events and circumstances indicate that a decline in the value of an equity security has occurred and is other than temporary, the Company records a charge to net investment income for the difference between fair value and cost at the balance sheet date. Additionally, if the Company has either the intent to sell the equity security or does not have both the intent and the ability to hold the equity security until its anticipated recovery, the Company records a charge to net investment income for the difference between fair value and cost at the balance sheet date.

[0001234452-16-000552:notes:174]
Equity and Cost Method Investments. The Company generally accounts for non-marketable equity investments either under the equity or the cost method. Equity investments over which the Company has significant influence, but not control over the investee and is not the primary beneficiary of the investee’s activities are accounted for under the equity method. Other non-marketable equity investments are accounted for under the cost method. The Company’s share of gains and losses in equity method investments are recorded in net investment income. The Company monitors non-marketable equity investments for events or circumstances that could indicate the investments are impaired, such as a deterioration in the investee’s financial condition and business forecasts and lower valuations in recently completed or proposed financings, and records a charge to net investment income for the difference between the estimated fair value and the carrying value.

[0001234452-16-000552:notes:175]
Transactions with equity method investees are considered related party transactions. Revenues from certain licensing and services contracts with two of the Company’s equity method investees were $196 million and negligible in fiscal 2016 and 2015, respectively. There were no such revenues in fiscal 2014. The Company eliminates unrealized profit or loss related to such transactions in relation to its ownership interest in the investee, which is recorded as a component of equity in net losses in investees in net investment income. Aggregate accounts receivable from these equity method investees were $73 million at September 25, 2016. No accounts receivable were due from these equity method investees at September 27, 2015.

[0001234452-16-000552:notes:176]
Gross Notional Amounts: The gross notional amounts of the Company’s interest rate, foreign currency and investment portfolio derivatives by instrument type were as follows (in millions):

[0001234452-16-000552:notes:177]
|  | September 25, 2016 |  | September 27, 2015 |
| Forwards | $ | 108 |  |  | $ | 269 |  |
| Futures | — |  |  | 133 |  |
| Options | 929 |  |  | 620 |  |
| Swaps | 3,061 |  |  | 3,004 |  |
|  | $ | 4,098 |  |  | $ | 4,026 |  |

[0001234452-16-000552:notes:178]
The gross notional amounts by currency were as follows (in millions):

[0001234452-16-000552:notes:179]
|  | September 25, 2016 |  | September 27, 2015 |
| British pound sterling | $ | — |  |  | $ | 83 |  |
| Chinese renminbi | 325 |  |  | 111 |  |
| Euro | 31 |  |  | 36 |  |
| Indian rupee | 433 |  |  | 409 |  |
| Japanese yen | 97 |  |  | 174 |  |
| Korean won | 85 |  |  | 81 |  |
| United States dollar | 3,045 |  |  | 3,089 |  |
| Other | 82 |  |  | 43 |  |
|  | $ | 4,098 |  |  | $ | 4,026 |  |

[0001234452-16-000552:notes:180]
Allowances for Doubtful Accounts. The Company maintains allowances for doubtful accounts for estimated losses resulting from the inability of the Company’s customers to make required payments. The Company considers the following factors when determining if collection of required payments is reasonably assured: customer credit-worthiness; past transaction history with the customer; current economic industry trends; changes in customer payment terms; and bank credit-worthiness for letters of credit. If the Company has no previous experience with the customer, the Company may request financial information, including financial statements or other documents, to determine that the customer has the means of making payment. The Company may also obtain reports from various credit organizations to determine that the customer has a history of paying its creditors. If these factors do not indicate collection is reasonably assured, revenue is deferred as a reduction to accounts receivable until collection becomes reasonably assured, which is generally upon receipt of cash. If the financial condition of the Company’s customers was to deteriorate, adversely affecting their ability to make payments, additional allowances would be required.

[0001234452-16-000552:notes:181]
Property, Plant and Equipment. Property, plant and equipment are recorded at cost and depreciated or amortized using the straight-line method over their estimated useful lives. Upon the retirement or disposition of property, plant and equipment, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. Buildings on owned land are depreciated over 30 years, and building improvements are depreciated over their useful lives ranging from 7 to 15 years. Leasehold improvements are amortized over the shorter of their estimated useful lives, not to exceed 15 years, or the remaining term of the related lease. Other property, plant and equipment have useful lives ranging from 2 to 25 years. Leased property meeting certain capital lease criteria is capitalized, and the net present value of the related lease payments is recorded as a liability. Amortization of assets under capital leases is recorded using the straight-line method over the shorter of the estimated useful lives or the lease terms. Maintenance, repairs and minor renewals or betterments are charged to expense as incurred.

[0001234452-16-000552:notes:182]
Revenue Recognition. The Company derives revenues principally from sales of integrated circuit products and licensing of its intellectual property and also generates revenues through sales of software hosting, software development and other services. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of the Company’s deliverables and obligations. Unearned revenues consist primarily of license fees for intellectual property with continuing performance obligations.

[0001234452-16-000552:notes:183]
Revenues from sales of the Company’s products are recognized at the time of shipment, or when title and risk of loss pass to the customer and all other criteria for revenue recognition are met, if later. Revenues from providing services are recognized when earned. Revenues from providing services were less than 10% of total revenues for all periods presented.

[0001234452-16-000552:notes:184]
The Company licenses or otherwise provides rights to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Licensees typically pay a fixed license fee in one or more installments and royalties based on their sales of products incorporating or using the Company’s licensed intellectual property. License fees are recognized over the estimated period of benefit of the license to the licensee, typically 5 to 15 years. The Company earns royalties on such licensed products sold worldwide by its licensees at the time that the licensees’ sales occur. The Company’s licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. The Company recognizes royalty revenues based on royalties reported by licensees during the quarter and when all other revenue recognition criteria are met.

[0001234452-16-000552:notes:185]
The Company records reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of the Company’s products and technologies. The Company recognizes the maximum potential liability at the later of the date at which the Company records the related revenues or the date at which the Company offers the incentive or, if payment is contingent, when the contingency is resolved. In certain arrangements, the liabilities are based on customer forecasts. The Company reverses accruals for unclaimed incentive amounts to revenues when the unclaimed amounts are no longer subject to payment.

[0001234452-16-000552:notes:186]
Shipping and Handling Costs. Costs incurred for shipping and handling are included in cost of revenues. Amounts billed to a customer for shipping and handling are reported as revenues.

[0001234452-16-000552:notes:187]
Share-Based Compensation. Share-based compensation expense for equity-classified awards, principally related to restricted stock units (RSUs), is measured at the grant date, or at the acquisition date for awards assumed in business combinations, based on the estimated fair value of the award and is recognized over the employee’s requisite service period. Share-based compensation expense is adjusted to exclude amounts related to share-based awards that are expected to be forfeited.

[0001234452-16-000552:notes:188]
The fair values of RSUs are estimated based on the fair market values of the underlying stock on the dates of grant or dates the RSUs are assumed. If RSUs do not have the right to participate in dividends, the fair values are discounted by the dividend yield. The weighted-average estimated fair values of employee RSUs granted during fiscal 2016, 2015 and 2014 were $53.56, $68.77 and $72.81 per share, respectively. Upon vesting, the Company issues new shares of common stock. For the majority of RSUs, shares are issued on the vesting dates net of the amount of shares needed to satisfy statutory tax withholding requirements to be paid by the Company on behalf of the employees. As a result, the actual number of shares issued will be fewer than the number of RSUs outstanding. The annual pre-vest forfeiture rate for RSUs was estimated to be approximately 4% in fiscal 2016 and 3% in both fiscal 2015 and 2014.

[0001234452-16-000552:notes:189]
Total share-based compensation expense, related to all of the Company’s share-based awards, was comprised as follows (in millions):

[0001234452-16-000552:notes:190]
|  | 2016 |  | 2015 |  | 2014 |
| Cost of revenues | $ | 40 |  |  | $ | 42 |  |  | $ | 49 |  |
| Research and development | 614 |  |  | 659 |  |  | 672 |  |
| Selling, general and administrative | 289 |  |  | 325 |  |  | 338 |  |
| Share-based compensation expense before income taxes | 943 |  |  | 1,026 |  |  | 1,059 |  |
| Related income tax benefit | (190 | ) |  | (190 | ) |  | (203 | ) |
|  | $ | 753 |  |  | $ | 836 |  |  | $ | 856 |  |

[0001234452-16-000552:notes:191]
Legal Proceedings. The Company is currently involved in certain legal proceedings. The Company discloses a loss contingency if there is at least a reasonable possibility that a material loss has been incurred. The Company records its best estimate of a loss related to pending legal proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, the Company records the minimum estimated liability. As additional information becomes available, the Company assesses the potential liability related to pending legal proceedings and revises its estimates and updates its disclosures accordingly. The Company’s legal costs associated with defending itself are recorded to expense as incurred.

[0001234452-16-000552:notes:192]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for fiscal 2016, 2015 and 2014 were 13,864,000, 20,724,000 and 30,655,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 2,435,000, 4,652,000 (which were primarily attributable to the ASR Agreements (Note 4)) and 846,000 during fiscal 2016, 2015 and 2014, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001234452-16-000552:notes:193]
Summarized Quarterly Data (Unaudited)

[0001234452-16-000552:notes:194]
The following financial information reflects all normal recurring adjustments that are, in the opinion of management, necessary for a fair statement of the results of the interim periods.

[0001234452-16-000552:notes:195]
The table below presents quarterly data for fiscal 2016 and 2015 (in millions, except per share data):

[0001234452-16-000552:notes:196]
|  | 1st Quarter |  | 2nd Quarter |  | 3rd Quarter |  | 4th Quarter |
| 2016 (1) |  |  |  |  |  |  |  |
| Revenues | $ | 5,775 |  |  | $ | 5,551 |  |  | $ | 6,044 |  |  | $ | 6,184 |  |
| Operating income | 1,685 |  |  | 1,415 |  |  | 1,592 |  |  | 1,804 |  |
| Net income | 1,496 |  |  | 1,164 |  |  | 1,443 |  |  | 1,599 |  |
| Net income attributable to Qualcomm | 1,498 |  |  | 1,164 |  |  | 1,444 |  |  | 1,599 |  |
| Basic earnings per share attributable to Qualcomm (2): | $ | 1.00 |  |  | $ | 0.78 |  |  | $ | 0.98 |  |  | $ | 1.08 |  |
| Diluted earnings per share attributable to Qualcomm (2): | 0.99 |  |  | 0.78 |  |  | 0.97 |  |  | 1.07 |  |
| 2015 (1) |  |  |  |  |  |  |  |
| Revenues | $ | 7,099 |  |  | $ | 6,894 |  |  | $ | 5,832 |  |  | $ | 5,456 |  |
| Operating income | 2,064 |  |  | 1,336 |  |  | 1,235 |  |  | 1,140 |  |
| Net income | 1,971 |  |  | 1,052 |  |  | 1,183 |  |  | 1,060 |  |
| Net income attributable to Qualcomm | 1,972 |  |  | 1,053 |  |  | 1,184 |  |  | 1,061 |  |
| Basic earnings per share attributable to Qualcomm (2): | $ | 1.19 |  |  | $ | 0.64 |  |  | $ | 0.74 |  |  | $ | 0.68 |  |
| Diluted earnings per share attributable to Qualcomm (2): | 1.17 |  |  | 0.63 |  |  | 0.73 |  |  | 0.67 |  |

[0001234452-16-000552:notes:197]
| (1) | Amounts, other than per share amounts, are rounded to millions each quarter. Therefore, the sum of the quarterly amounts may not equal the annual amounts reported. |

[0001234452-16-000552:notes:198]
| (2) | Earnings per share attributable to Qualcomm are computed independently for each quarter and the full year based upon respective average shares outstanding. Therefore, the sum of the quarterly earnings per share amounts may not equal the annual amounts reported. |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001234452-16-000552:notes:199]
Reconciling items in the previous table were as follows (in millions):

[0001234452-16-000552:notes:200]
|  | 2016 |  | 2015 |  | 2014 |
| Revenues |  |  |  |  |  |
| Nonreportable segments | $ | 438 |  |  | $ | 181 |  |  | $ | 258 |  |
| Intersegment eliminations | (4 | ) |  | (5 | ) |  | (5 | ) |
|  | $ | 434 |  |  | $ | 176 |  |  | $ | 253 |  |
| EBT |  |  |  |  |  |
| Unallocated cost of revenues | $ | (495 | ) |  | $ | (314 | ) |  | $ | (300 | ) |
| Unallocated research and development expenses | (799 | ) |  | (809 | ) |  | (860 | ) |
| Unallocated selling, general and administrative expenses | (478 | ) |  | (497 | ) |  | (412 | ) |
| Unallocated other (expense) income | (154 | ) |  | (1,289 | ) |  | 142 |  |
| Unallocated interest expense | (292 | ) |  | (101 | ) |  | (2 | ) |
| Unallocated investment income, net | 667 |  |  | 855 |  |  | 1,215 |  |
| Nonreportable segments | (342 | ) |  | (630 | ) |  | (1,395 | ) |
| Intersegment eliminations | — |  |  | (1 | ) |  | — |  |
|  | $ | (1,893 | ) |  | $ | (2,786 | ) |  | $ | (1,612 | ) |

[0001234452-16-000552:notes:201]
Unallocated acquisition-related expenses were comprised as follows (in millions):

[0001234452-16-000552:notes:202]
|  | 2016 |  | 2015 |  | 2014 |
| Cost of revenues | $ | 434 |  |  | $ | 272 |  |  | $ | 251 |  |
| Research and development expenses | 10 |  |  | 14 |  |  | 30 |  |
| Selling, general and administrative expenses | 99 |  |  | 72 |  |  | 25 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001234452-16-000552:notes:203]
Strategic Realignment Plan

[0001234452-16-000552:notes:204]
On July 22, 2015, the Company announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as the Company works to create sustainable long-term value for stockholders. As part of this, among other actions, the Company implemented a cost reduction plan, which includes a series of targeted reductions across the Company’s businesses, particularly in QCT, and a reduction to its annual share-based compensation grants. These cost reduction initiatives were achieved by the end of fiscal 2016. During fiscal 2016, the Company recorded restructuring charges of $144 million, including consulting costs of $73 million and severance costs of $67 million, restructuring-related charges of $58 million which, primarily consisted of asset impairments, and a $48 million gain on the sale of the Company’s business that provided augmented reality application, since such sale was executed in connection with the Strategic Realignment Plan, all of which were included in other expenses (Note 2) in reconciling items (Note 8). Restructuring activities were initiated in the fourth quarter of fiscal 2015, and a total of $344 million in net restructuring and restructuring-related charges were incurred through the end of fiscal 2016. The remaining restructuring and restructuring-related charges to be incurred related to the plan are expected to be negligible.

[0001234452-16-000552:notes:205]
The restructuring accrual, a portion of which is included in payroll and other benefits related liabilities with the remainder included in other current liabilities, is expected to be substantially paid within the next 12 months. Changes in the restructuring accrual during fiscal 2016 were as follows (in millions):

[0001234452-16-000552:notes:206]
|  | Severance Costs |  | Other Costs |  | Total |
| Beginning balance of restructuring accrual | $ | 122 |  |  | $ | 31 |  |  | $ | 153 |  |
| Additional costs | 78 |  |  | 81 |  |  | 159 |  |
| Cash payments | (162 | ) |  | (93 | ) |  | (255 | ) |
| Adjustments | (11 | ) |  | (4 | ) |  | (15 | ) |
| Ending balance of restructuring accrual | $ | 27 |  |  | $ | 15 |  |  | $ | 42 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001234452-16-000552:notes:207]
Revenues by country were as follows (in millions):

[0001234452-16-000552:notes:208]
|  | 2016 |  | 2015 |  | 2014 |
| China (including Hong Kong) | $ | 13,503 |  |  | $ | 13,337 |  |  | $ | 13,200 |  |
| South Korea | 3,918 |  |  | 4,107 |  |  | 6,172 |  |
| Taiwan | 2,846 |  |  | 3,294 |  |  | 2,876 |  |
| United States | 386 |  |  | 246 |  |  | 372 |  |
| Other foreign | 2,901 |  |  | 4,297 |  |  | 3,867 |  |
|  | $ | 23,554 |  |  | $ | 25,281 |  |  | $ | 26,487 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001234452-16-000552:notes:209]
The table below presents revenues, EBT and total assets for reportable segments (in millions):

[0001234452-16-000552:notes:210]
|  | QCT |  | QTL |  | QSI |  | ReconcilingItems |  | Total |
| 2016 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 15,409 |  |  | $ | 7,664 |  |  | $ | 47 |  |  | $ | 434 |  |  | $ | 23,554 |  |
| EBT | 1,812 |  |  | 6,528 |  |  | 386 |  |  | (1,893 | ) |  | 6,833 |  |
| Total assets | 2,995 |  |  | 644 |  |  | 910 |  |  | 47,810 |  |  | 52,359 |  |
| 2015 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 17,154 |  |  | $ | 7,947 |  |  | $ | 4 |  |  | $ | 176 |  |  | $ | 25,281 |  |
| EBT | 2,465 |  |  | 6,882 |  |  | (74 | ) |  | (2,786 | ) |  | 6,487 |  |
| Total assets | 2,923 |  |  | 438 |  |  | 812 |  |  | 46,623 |  |  | 50,796 |  |
| 2014 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 18,665 |  |  | $ | 7,569 |  |  | $ | — |  |  | $ | 253 |  |  | $ | 26,487 |  |
| EBT | 3,807 |  |  | 6,590 |  |  | (7 | ) |  | (1,612 | ) |  | 8,778 |  |
| Total assets | 3,639 |  |  | 161 |  |  | 484 |  |  | 44,290 |  |  | 48,574 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001234452-16-000552:notes:211]
SCHEDULE II

[0001234452-16-000552:notes:212]
QUALCOMM INCORPORATED

[0001234452-16-000552:notes:213]
VALUATION AND QUALIFYING ACCOUNTS

[0001234452-16-000552:notes:214]
(In millions)

[0001234452-16-000552:notes:215]
|  | Balance atBeginning ofPeriod |  | Charged(Credited) toCosts andExpenses |  | Deductions |  | Other |  | Balance atEnd ofPeriod |
| Year ended September 25, 2016 |  |  |  |  |  |  |  |  |  |
| Allowances: |  |  |  |  |  |  |  |  |  |
| — trade receivables | $ | 6 |  |  | $ | (5 | ) |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |
| Valuation allowance on deferred tax assets | 635 |  |  | 118 |  |  | — |  |  | 1 |  | (a) | 754 |  |
|  | $ | 641 |  |  | $ | 113 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 755 |  |
| Year ended September 27, 2015 |  |  |  |  |  |  |  |  |  |
| Allowances: |  |  |  |  |  |  |  |  |  |
| — trade receivables | $ | 5 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |
| — notes receivable | 4 |  |  | — |  |  | (3 | ) |  | (1 | ) | (b) | — |  |
| Valuation allowance on deferred tax assets | 414 |  |  | 130 |  |  | — |  |  | 91 |  | (a) | 635 |  |
|  | $ | 423 |  |  | $ | 131 |  |  | $ | (3 | ) |  | $ | 90 |  |  | $ | 641 |  |
| Year ended September 28, 2014 |  |  |  |  |  |  |  |  |  |
| Allowances: |  |  |  |  |  |  |  |  |  |
| — trade receivables | $ | 2 |  |  | $ | 5 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | 5 |  |
| — notes receivable | 10 |  |  | (3 | ) |  | (1 | ) |  | (2 | ) | (b) | 4 |  |
| Valuation allowance on deferred tax assets | 265 |  |  | 148 |  |  | — |  |  | 1 |  | (a) | 414 |  |
|  | $ | 277 |  |  | $ | 150 |  |  | $ | (3 | ) |  | $ | (1 | ) |  | $ | 423 |  |

[0001234452-16-000552:notes:216]
| (a) | This amount was recorded to goodwill in connection with a business acquisition. |

[0001234452-16-000552:notes:217]
| (b) | This amount relates to notes receivable on strategic investments that were converted to cost method equity investments. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001234452-16-000552:notes:218]
Segment Information

[0001234452-16-000552:notes:219]
The Company is organized on the basis of products and services. The Company conducts business primarily through two reportable segments, QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing), and its QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an equity method investee. QCT develops and supplies integrated circuits and system software for use in mobile devices, wireless networks, broadband gateway equipment and consumer electronic devices. QTL grants licenses to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. The Company also has nonreportable segments, including its mobile health, data center, small cell and other wireless technology and service initiatives.

[0001234452-16-000552:notes:220]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT) from continuing operations. Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense; certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization and impairment of certain intangible assets and certain other acquisition-related charges, and beginning in the first quarter of fiscal 2015, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. The table below presents revenues, EBT and total assets for reportable segments (in millions):

[0001234452-16-000552:notes:221]
The Company reports revenues from external customers by country based on the location to which its products or services are delivered, which for QCT is generally the country in which its customers manufacture their products, or for licensing revenues, the invoiced addresses of its licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing the Company’s products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues could include revenues related to shipments of integrated circuits to a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States. Revenues by country were as follows (in millions):

[0001234452-16-000552:notes:222]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets include certain marketable securities, other investments and all assets of consolidated subsidiaries included in QSI. QSI assets at September 25, 2016, September 27, 2015 and September 28, 2014 included $162 million, $163 million and $18 million, respectively, related to investments in equity method investees. The increase in QSI assets was primarily a result of a receivable that was recorded in connection with the sale of wireless spectrum during fiscal 2016 (Note 2) and investments in equity method investees. Total segment assets differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable securities, property, plant and equipment, deferred tax assets, intangible assets and assets of nonreportable segments. The net book values of long-lived tangible assets located outside of the United States were $404 million, $414 million and $288 million at September 25, 2016, September 27, 2015 and September 28, 2014, respectively. The net book values of long-lived tangible assets located in the United States were $1.9 billion, $2.1 billion and $2.2 billion at September 25, 2016, September 27, 2015 and September 28, 2014, respectively.

[0001234452-16-000552:notes:223]
Unallocated other expense for fiscal 2016 was comprised of net restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan (Note 10). Unallocated other expense for fiscal 2015 was comprised of a charge related to the resolution reached with the NDRC, goodwill and intangible asset impairment charges related to three of the Company’s nonreportable segments and restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan, partially offset by a gain on the sale of certain property, plant and equipment (Note 2). Nonreportable segments EBT for fiscal 2014 included impairment charges related to certain property, plant and equipment and goodwill (Note 2).


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001234452-16-000552:notes:224]
The Company reports revenues from external customers by country based on the location to which its products or services are delivered, which for QCT is generally the country in which its customers manufacture their products, or for licensing revenues, the invoiced addresses of its licensees.

[0001234452-16-000552:notes:225]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT) from continuing operations. Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense; certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization and impairment of certain intangible assets and certain other acquisition-related charges, and beginning in the first quarter of fiscal 2015, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001234452-16-000552:notes:226]
Capital Stock

[0001234452-16-000552:notes:227]
Preferred Stock. The Company has 8,000,000 shares of preferred stock authorized for issuance in one or more series, at a par value of $0.0001 per share. In conjunction with the Amended and Restated Rights Agreement dated as of September 25, 2005 between the Company and Computershare Trust Company, N.A., as successor Rights Agent to Computershare Investor Services LLC, as amended (the Rights Agreement), 4,000,000 shares of preferred stock were designated as Series A Junior Participating Preferred Stock. The Rights Agreement expired on its scheduled expiration date of September 25, 2015, and all shares of preferred stock previously designated as Series A Junior Participating Preferred Stock were eliminated and returned to the status of authorized but unissued shares of preferred stock, without designation on September 28, 2015. At September 25, 2016 and September 27, 2015, no shares of preferred stock were outstanding.

[0001234452-16-000552:notes:228]
Stock Repurchase Program. On March 9, 2015, the Company announced a stock repurchase program authorizing it to repurchase up to $15 billion of the Company’s common stock. The stock repurchase program has no expiration date. During fiscal 2015, the Company entered into two accelerated share repurchase agreements (ASR Agreements) with two financial institutions under which the Company paid an aggregate of $5.0 billion to the financial institutions and received from them a total of 78,276,000 shares of the Company’s common stock based on the average daily volume weighted-average stock price of the Company’s common stock during the respective terms of the ASR Agreements, less a discount. The shares were retired and recorded as a reduction to stockholders’ equity.

[0001234452-16-000552:notes:229]
During fiscal 2016, 2015 and 2014, the Company repurchased and retired an additional 73,782,000, 94,159,000 and 60,253,000 shares of common stock, respectively, for $3.9 billion, $6.2 billion and $4.5 billion, respectively, before commissions. To reflect share repurchases in the consolidated balance sheet, the Company (i) reduces common stock for the par value of the shares, (ii) reduces paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) records the residual amount to retained earnings. At September 25, 2016, $3.0 billion remained authorized for repurchase under the Company’s stock repurchase program. Since September 25, 2016, the Company repurchased and retired 1,865,000 shares of common stock for $124 million.

[0001234452-16-000552:notes:230]
Dividends. On October 6, 2016, the Company announced a cash dividend of $0.53 per share on the Company’s common stock, payable on December 16, 2016 to stockholders of record as of the close of business on November 30, 2016. Dividends charged to retained earnings in fiscal 2016, 2015 and 2014 were as follows (in millions, except per share data):


## us-gaap:SubsequentEventsTextBlock

[0001234452-16-000552:notes:231]
Subsequent Event

[0001234452-16-000552:notes:232]
On October 27, 2016, the Company announced a definitive agreement under which Qualcomm River Holdings, B.V., an indirect, wholly owned subsidiary of Qualcomm Incorporated, will acquire NXP Semiconductors N.V. Pursuant to the definitive agreement, Qualcomm River Holdings will commence a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration of $38 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products.

[0001234452-16-000552:notes:233]
The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions, including the tender of specified percentages (which vary from 70% to 95% based on certain circumstances as provided in the definitive agreement) of the issued and outstanding common shares of NXP in the offer. An Extraordinary General Meeting of NXP’s shareholders will be convened in connection with the offer to adopt, among other things, certain resolutions relating to the transaction. The tender offer is not subject to any financing condition; however, the Company intends to fund the transaction with cash held by foreign entities and new debt. As a result, the Company secured $13.6 billion in committed financing in connection with signing the definitive agreement.

[0001234452-16-000552:notes:234]
Qualcomm River Holdings and NXP may terminate the definitive agreement under certain circumstances. If the definitive agreement is terminated by NXP in certain circumstances, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the definitive agreement is terminated by Qualcomm River Holdings under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion.
