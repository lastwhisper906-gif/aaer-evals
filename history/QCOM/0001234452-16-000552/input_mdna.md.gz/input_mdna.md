# QCOM MD&A — 0001234452-16-000552


## mdna

[0001234452-16-000552:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001234452-16-000552:mdna:2]
Overview

[0001234452-16-000552:mdna:3]
Fiscal 2016 Overview

[0001234452-16-000552:mdna:4]
The transition of wireless networks and devices to 3G/4G (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) continued around the world. 3G/4G connections increased to approximately 4.0 billion, up 18% year-over-year, and represent approximately 54% of total mobile connections, up from 47% at the end of fiscal 2015.(1)

[0001234452-16-000552:mdna:5]
Revenues were $23.6 billion, a decrease of 7% compared to fiscal 2015, with net income attributable to Qualcomm of $5.7 billion, an increase of 8% compared to fiscal 2015.

[0001234452-16-000552:mdna:6]
QCT Segment. We shipped approximately 842 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, a decrease of 10%, compared to approximately 932 million MSM integrated circuits in fiscal 2015. QCT’s revenues decreased by 10%, and its earnings before taxes as a percentage of revenues decreased to 12% from 14% in fiscal 2015, primarily due to the effects of a shift in share among our customers within the premium tier, which reduced our sales of integrated Snapdragon processors and skewed our product mix towards lower-margin modem chipsets in this tier, a decline in share at our large customers and the competitive environment in China, partially offset by lower product costs, including lower excess inventory charges, and the impact of the acquisition of CSR in the fourth quarter of fiscal 2015.

[0001234452-16-000552:mdna:7]
QTL Segment. Total reported device sales(2) by licensees were approximately $267.4 billion in fiscal 2016, an increase of approximately 7%, compared to approximately $250.9 billion in fiscal 2015. However, despite the increase in total reported device sales, QTL’s revenues decreased by 4% compared to fiscal 2015 primarily due to decreases in revenues per reported unit and recognition of unearned license fees, partially offset by an increase in reported sales of CDMA-based products (including multimode products that also implement OFDMA) and $266 million in licensing revenues recorded in the second quarter of fiscal 2016 due to the termination of an infrastructure license agreement resulting from the merger of two licensees. QTL revenues and EBT in fiscal 2016 continued to be impacted negatively by units that we believe are not being reported by certain licensees and sales of certain unlicensed products.

[0001234452-16-000552:mdna:8]
Strategic Realignment Plan. In the fourth quarter of fiscal 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders. As part of this Strategic Realignment Plan, among other actions, we implemented a cost reduction plan, which included a series of targeted reductions across our businesses, particularly in QCT, and a reduction to annual share-based compensation grants. These cost reduction initiatives were achieved by the end of fiscal 2016.(3) During fiscal 2016, we recorded restructuring and restructuring-related charges of $202 million related to the plan.

[0001234452-16-000552:mdna:9]
Capital Return Program. We previously announced our intention to repurchase $10 billion of stock from March 2015 through March 2016. In the first quarter of fiscal 2016, we completed the remaining $1.9 billion of repurchases towards our $10 billion stock repurchase commitment, which includes the completion of our $5.0 billion accelerated share repurchase agreements. Excluding these stock repurchases, we returned $5.0 billion to stockholders, including $2.0 billion through repurchases of common stock and $3.0 billion of cash dividends. Shares outstanding decreased by 3% to 1.48 billion at September 25, 2016 from 1.52 billion at September 27, 2015 due to share repurchases, partially offset by net shares issued under our employee benefit plans.

[0001234452-16-000552:mdna:10]
| (1) | According to GSMA Intelligence estimates as of October 31, 2016 for the quarter ended September 30, 2016 (estimates excluded Wireless Local Loop). |

[0001234452-16-000552:mdna:11]
| (2) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). Not all licensees report sales the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other |

[0001234452-16-000552:mdna:12]
36

[0001234452-16-000552:mdna:13]
reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales for a particular period may include prior period activity that was not reported by the licensee until such particular period.

[0001234452-16-000552:mdna:14]
| (3) | The cost reduction initiative related to certain research and development and selling, general and marketing expenses and certain non-product-related cost of revenues. It excludes the impact of the CSR and Capsule Technologie acquisitions as well as costs of a nonreportable segment up to the amount of related revenues recognized in fiscal 2016. |

[0001234452-16-000552:mdna:15]
Our Business and Operating Segments

[0001234452-16-000552:mdna:16]
We design, manufacture, have manufactured on our behalf and market digital communications products and services based on CDMA, OFDMA and other technologies. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents, software and other rights.

[0001234452-16-000552:mdna:17]
We have three reportable segments. We conduct business primarily through two reportable segments, QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing), and our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering, research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001234452-16-000552:mdna:18]
QCT is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in wireless voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products are sold and its system software is licensed to manufacturers that use our products in mobile phones, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards and infrastructure equipment, broadband gateway equipment and other consumer electronic devices. Our MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Snapdragon processors and LTE modems, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon processors provide advanced application and graphics processing capabilities. QCT’s system software helps enable the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits. QCT revenues comprised 65%, 68% and 70% of our total consolidated revenues in fiscal 2016, 2015 and 2014, respectively.

[0001234452-16-000552:mdna:19]
QCT currently utilizes a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Integrated circuits are die cut from silicon wafers that have completed the package assembly and test manufacturing processes. We rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits based primarily on our proprietary designs and test programs. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Turnkey is when our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services, such as wafer bump, probe, assembly and final test.

[0001234452-16-000552:mdna:20]
QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD and/or LTE standards and their derivatives. QTL licensing revenues include license fees and royalties based on sales by licensees of products incorporating or using our intellectual property. License fees are fixed amounts paid in one or more installments. Royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). QTL recognizes royalty revenues based on royalties reported by licensees and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. QTL revenues comprised 33%, 31% and 29% of our total consolidated revenues in fiscal 2016, 2015 and 2014, respectively. The vast majority of such revenues were generated through our licensees’ sales of CDMA2000- and WCDMA-based products, such as feature phones and smartphones.

[0001234452-16-000552:mdna:21]
QSI makes strategic investments that are focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications. Many of these strategic investments are in early-stage companies in a variety of industries, including, but not limited to, digital media, e-commerce, healthcare and wearable devices. Investments primarily include non-

[0001234452-16-000552:mdna:22]
marketable equity instruments, which generally are recorded using the cost method or the equity method, and convertible debt instruments, which are recorded at fair value. QSI also held wireless spectrum, which was sold in the first quarter of fiscal 2016 for a gain of approximately $380 million. In addition, QSI segment results include revenues and related costs associated with development contracts with one of our equity method investees. As part of our strategic investment activities, we intend to pursue various exit strategies for each of our QSI investments in the foreseeable future.

[0001234452-16-000552:mdna:23]
Nonreportable segments include our mobile heath, data center, small cell and other wireless technology and service initiatives.

[0001234452-16-000552:mdna:24]
Seasonality. Many of our products or intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has tended historically to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons; and because QTL recognizes royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made during the fourth calendar quarter. We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 3G/4G networks by wireless operators and the timing of launches of flagship wireless devices that incorporate our products and/or intellectual property. These trends may or may not continue in the future.

[0001234452-16-000552:mdna:25]
Looking Forward

[0001234452-16-000552:mdna:26]
We expect continued growth in the coming years in consumer demand for 3G, 3G/4G multimode and 4G products and services around the world, driven primarily by smartphones. We also expect growth in new device categories and industries, driven by the expanding adoption of certain technologies that are already commonly used in smartphones. As we look forward to the next several months, we expect our business to be impacted by the following key items:

[0001234452-16-000552:mdna:27]
| • | On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings, B.V., an indirect, wholly owned subsidiary of Qualcomm Incorporated, will acquire NXP Semiconductors N.V. Pursuant to the definitive agreement, Qualcomm River Holdings will commence a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration of $38 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products. The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions, including the tender of specified percentages (which vary from 70% to 95% based on certain circumstances as provided in the definitive agreement) of the issued and outstanding common shares of NXP in the offer. The tender offer is not subject to any financing condition; however, we intend to fund the transaction with cash held by foreign entities and new debt. We expect that this will require us to: devote significant resources and management time and attention prior to close; take on significant debt; and utilize a substantial portion of our cash, cash equivalents and marketable securities. |

[0001234452-16-000552:mdna:28]
| • | Consumer demand for 3G/4G smartphone products is increasing in emerging regions, particularly in China, driven by availability of lower-tier-3G/4G devices. We expect the ongoing rollout of 4G services in emerging regions will encourage competition and growth, bringing the benefits of 3G/4G LTE multimode to consumers. |

[0001234452-16-000552:mdna:29]
| • | Our business, particularly QCT, expects to continue to be impacted by industry dynamics, including: |

[0001234452-16-000552:mdna:30]
| • | Concentration of device share among a few companies within the premium tier, resulting in significant supply chain leverage for those companies; |

[0001234452-16-000552:mdna:31]
| • | Decisions by companies to utilize their own internally-developed integrated circuit products or our competitors’ integrated circuit products in a portion of their devices; |

[0001234452-16-000552:mdna:32]
| • | Intense competition, particularly in China, as our competitors expand their product offerings and/or reduce the prices of their products as part of a strategy to attract new and/or retain customers; and |

[0001234452-16-000552:mdna:33]
| • | Lengthening replacement cycles in developed regions, where the smartphone industry is mature, premium-tier smartphones are common and consumer demand is increasingly driven by new product launches and/or innovation cycles, and from increasing consumer demand in emerging regions where premium-tier smartphones are less common and replacement cycles are on average longer than in developed regions. |

[0001234452-16-000552:mdna:34]
| • | We continue to believe that certain licensees, particularly in China, are not fully complying with their contractual obligations to report their sales of licensed products to us, and certain companies, including unlicensed companies, are delaying execution of new license agreements. While we have made substantial progress in reaching agreements |

[0001234452-16-000552:mdna:35]
38

[0001234452-16-000552:mdna:36]
with many companies, negotiations with certain licensees and unlicensed companies are ongoing. We believe that the conclusion of new agreements with these companies will result in improved reporting by these licensees, including with respect to sales of three-mode devices (i.e., devices that implement GSM, TD-SCDMA and LTE-TDD) sold in China. Additionally, we believe our increased efforts in the areas of compliance will also improve reporting, but will also result in increased costs to the business. Litigation and/or other actions (such as the litigation against Meizu Technology Co., Ltd. described in this Annual Report in “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies”) may be necessary to compel licensees to report and pay the required royalties for sales they have not previously reported and/or to compel unlicensed companies to execute licenses.

[0001234452-16-000552:mdna:37]
| • | Regulatory authorities in other jurisdictions continue to investigate our business practices. An unfavorable resolution of one or more of these matters could have a material adverse effect on our business with remedies that include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. See “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies” elsewhere in this Annual Report. |

[0001234452-16-000552:mdna:38]
| • | We continue to invest significant resources toward advancements in 4G LTE and 5G technologies, OFDM-based WLAN technologies, wireless baseband chips, our converged computing/communications (Snapdragon) chips, radio frequency front-end (RFFE), connectivity, graphics, audio and video codecs, multimedia products, software and services, which contribute to the expansion of our intellectual property portfolio. We are also investing in targeted opportunities that leverage our existing technical and business expertise to deploy new business models and enter into new industry segments, such as products for automotive, the Internet of Things (IoT), including the connected home, smart cities and wearables, data center, networking, mobile computing, mobile health and machine learning, including robotics, among others. |

[0001234452-16-000552:mdna:39]
| • | In January 2016, we announced that we had reached an agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd., to enable delivery of RFFE modules and RF filters into fully integrated products for mobile devices and IoT applications, among others. The joint venture will initially be owned 51% by us and 49% by TDK. Certain intellectual property, patents and filter and module design and manufacturing assets will be carved out of existing TDK businesses and be acquired by the joint venture, with certain assets acquired by us. The purchase price of our interest in the joint venture and the assets to be transferred to us is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, we have the option to acquire (and TDK has an option to sell) TDK’s interest in the joint venture for $1.15 billion 30 months after the closing date. TDK will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date, which is a substitute for and in lieu of any right of TDK to receive any profit sharing, distributions, dividends or other payments of any kind or nature. The transaction is subject to receipt of regulatory approvals and other closing conditions and is expected to close in early calendar 2017. |

[0001234452-16-000552:mdna:40]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless value chain and governments as to the benefits of our business model and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not welcome the success of our business model in enabling new, highly cost-effective competitors to their products. We expect that such companies, and/or governments or regulators, will continue to challenge our business model in various forums throughout the world.

[0001234452-16-000552:mdna:41]
Further discussion of risks related to our business is presented in the Risk Factors included in this Annual Report.

[0001234452-16-000552:mdna:42]
Critical Accounting Estimates

[0001234452-16-000552:mdna:43]
The preparation of our consolidated financial statements in accordance with accounting principles generally accepted in the United States requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and disclosure of contingent assets and liabilities. We base our estimates on historical and anticipated results and trends and on various other assumptions that we believe are reasonable under the circumstances, including assumptions as to future events. By their nature, estimates are subject to an inherent degree of uncertainty. Although we believe that our estimates and the assumptions supporting our assessments are reasonable, actual results that differ from our estimates could be material to our consolidated financial statements. A summary of our significant accounting policies is included in this Annual Report in “Notes to Consolidated Financial Statements, Note 1. The Company and Its Significant Accounting Policies.” We consider the following accounting estimates to be critical in the preparation of our consolidated financial statements.

[0001234452-16-000552:mdna:44]
39

[0001234452-16-000552:mdna:45]
Impairment of Marketable Securities and Other Investments. We hold investments in marketable securities, with increases and decreases in fair value generally recorded through stockholders’ equity as other comprehensive income or loss. We record impairment losses in earnings when we believe an investment has experienced a decline that is other than temporary. The determination that a decline is other than temporary is subjective and influenced by many factors. Adverse changes in market conditions or poor operating results of investees could result in losses or an inability to recover the carrying value of the investments, thereby requiring recognition of impairment losses. When assessing these investments for an other-than-temporary decline in value, we consider such factors as, among other things, the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; how long the market value of the security has been less than its cost basis; the security’s relative performance versus its peers, sector or asset class; expected market volatility; the market and economy in general; analyst recommendations and price targets; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates, as applicable. During fiscal 2016, 2015 and 2014, we recorded $112 million, $163 million and $156 million, respectively, in impairment losses on our investments in marketable securities. As of September 25, 2016, we had gross unrealized losses of $105 million. Prior to closing the NXP transaction, we expect to divest a substantial portion of our marketable securities portfolio in order to finance our proposed  acquisition, which may result in losses in our results of operations.

[0001234452-16-000552:mdna:46]
We also hold investments in non-marketable equity instruments in privately held companies that are accounted for using either the cost or the equity method. Many of these investments are in early-stage companies, which are inherently risky because the markets for the technologies or products of these companies are uncertain and may never develop. We monitor our investments for events or circumstances that could indicate the investments are impaired, such as a deterioration in the investee’s financial condition and business forecasts and lower valuations in recently completed or proposed financings, and we record impairment losses in earnings when we believe an investment has experienced a decline in value that is other than temporary.

[0001234452-16-000552:mdna:47]
Valuation of Inventories. Inventories are valued at the lower of cost or market (replacement cost, not to exceed net realizable value) using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers, among other things. This valuation also requires us to make judgments and assumptions based on information currently available about market conditions, including competition, product pricing, product life cycle and development plans. If we overestimate demand for our products, the amount of our loss will be impacted by our contractual ability to reduce inventory purchases from our suppliers. Our assumptions of future product demand are inherently uncertain, and changes in our estimates and assumptions may cause us to realize material write-downs in the future.

[0001234452-16-000552:mdna:48]
Valuation of Goodwill and Other Indefinite-Lived and Long-Lived Assets. Our business acquisitions typically result in the recording of goodwill, other intangible assets and property, plant and equipment, and the recorded values of those assets may become impaired in the future. We also acquire intangible assets and property, plant and equipment in other types of transactions. The determination of the recorded value of intangible assets acquired in a business combination requires management to make estimates and assumptions that affect our consolidated financial statements. For intangible assets acquired in a non-monetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value. An estimate of fair value can be affected by many assumptions that require significant judgment. For example, the income approach generally requires us to use assumptions to estimate future cash flows including those related to total addressable market, pricing and share forecasts, competition, technology obsolescence, future tax rates and discount rates. Our estimate of the fair value of certain assets may differ materially from that determined by others who use different assumptions or utilize different business models.

[0001234452-16-000552:mdna:49]
Goodwill and other indefinite-lived intangible assets are tested annually for impairment and in interim periods if certain events occur indicating that the carrying amounts may be impaired. Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Our judgments regarding the existence of impairment indicators and future cash flows related to goodwill and other indefinite-lived intangible assets and long-lived assets may be based on operational performance of our businesses, market conditions, expected selling price and/or other factors. Although there are inherent uncertainties in this assessment process, the estimates and assumptions we use, including estimates of future cash flows and discount rates, are consistent with our internal planning, when appropriate. If these estimates or their related assumptions change in the future, we may be required to record an impairment charge on a

[0001234452-16-000552:mdna:50]
40

[0001234452-16-000552:mdna:51]
portion or all of our goodwill, other indefinite-lived intangible assets and/or long-lived assets. Furthermore, we cannot predict the occurrence of future impairment-triggering events nor the impact such events might have on our reported asset values. Future events could cause us to conclude that impairment indicators exist and that goodwill or other intangible assets associated with our acquired businesses are impaired. Any resulting impairment loss could have an adverse impact on our financial position and results of operations. During fiscal 2016, 2015 and 2014, we recorded $107 million, $317 million and $642 million, respectively, in impairment charges for goodwill, other indefinite-lived intangible assets and long-lived assets. The estimated fair values of our QCT and QTL reporting units were substantially in excess of their respective carrying values at September 25, 2016.

[0001234452-16-000552:mdna:52]
Legal Proceedings. We are currently involved in certain legal proceedings, and we intend to continue to vigorously defend ourselves. However, the unfavorable resolution of one or more of these proceedings could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. A broad range of remedies with respect to our business practices that are deemed to violate applicable laws are potentially available. These remedies may include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or to modify our business practices. We disclose a loss contingency if there is at least a reasonable possibility that a material loss has been incurred. We record our best estimate of a loss related to pending legal proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, we record the minimum estimated liability. As additional information becomes available, we assess the potential liability, including the probability of loss related to pending legal proceedings, and revise our estimates and update our disclosures accordingly. Significant judgment is required in both the determination of probability and the determination as to whether a loss is reasonably estimable. Revisions in our estimates of the potential liability could materially impact our results of operations.

[0001234452-16-000552:mdna:53]
Income Taxes. We are subject to income taxes in the United States and numerous foreign jurisdictions, and the assessment of our income tax positions involves dealing with uncertainties in the application of complex tax laws and regulations in various taxing jurisdictions. In addition, the application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws and regulations themselves are subject to change as a result of changes in fiscal policy, changes in legislation, the evolution of regulations and court rulings. Significant judgments and estimates are required in determining our provision for income taxes, including those related to tax incentives, intercompany research and development cost-sharing arrangements, transfer pricing and tax credits. While we believe we have appropriate support for the positions taken on our tax returns, we regularly assess the potential outcomes of examinations by taxing authorities in determining the adequacy of our provision for income taxes. Therefore, the actual liability for United States or foreign taxes may be materially different from our estimates, which could result in the need to record additional tax liabilities or potentially reverse previously recorded tax liabilities. We are participating in the Internal Revenue Service (IRS) Compliance Assurance Process program whereby we endeavor to agree with the IRS on the treatment of all issues prior to filing our federal return. A benefit of participation in this program is that post-filing adjustments by the IRS are less likely to occur.

[0001234452-16-000552:mdna:54]
Our QCT segment’s non-United States headquarters is located in Singapore. We obtained tax incentives in Singapore that commenced in March 2012, including a tax exemption for the first five years, provided that we meet specified employment and incentive criteria, and as a result of the expiration of these incentives, our Singapore tax rate is expected to increase in fiscal 2017 and again in fiscal 2027. Our failure to meet these criteria could adversely impact our provision for income taxes.

[0001234452-16-000552:mdna:55]
We consider the operating earnings of certain non-United States subsidiaries to be indefinitely reinvested outside the United States based on our plans for use and/or investment outside of the United States and our belief that our sources of cash and liquidity in the United States will be sufficient to meet future domestic cash needs. On a regular basis, we consider projected cash needs for, among other things, potential acquisitions, such as our proposed acquisition of NXP, investments in our existing businesses, future research and development and capital transactions, including repurchases of our common stock, dividends and debt repayments. We estimate the amount of cash or other liquidity that is available or needed in the jurisdictions where these investments are expected as well as our ability to generate cash in those jurisdictions and our access to capital markets. This analysis enables us to conclude whether or not we will indefinitely reinvest the current period’s foreign earnings. We have not recorded a deferred tax liability of approximately $11.5 billion related to the United States federal and state income taxes and foreign withholding taxes on approximately $32.5 billion of undistributed earnings of certain non-United States subsidiaries indefinitely reinvested outside the United States. Should we decide to no longer indefinitely reinvest such earnings outside the United States, for example, if we determine that such earnings are needed to fund future domestic operations or there is not a sufficient need for such earnings outside of the United States, we would have to adjust the income tax provision in the period we make such determination.

[0001234452-16-000552:mdna:56]
41

[0001234452-16-000552:mdna:57]
Results of Operations

[0001234452-16-000552:mdna:58]
| Revenues (in millions) |  |  |  |  |  |
|  | 2016 |  | 2015 |  | 2014 |  | 2016 vs. 2015 Change |  | 2015 vs. 2014 Change |
| Equipment and services | $ | 15,467 |  |  | $ | 17,079 |  |  | $ | 18,625 |  |  | $ | (1,612 | ) |  | $ | (1,546 | ) |
| Licensing | 8,087 |  |  | 8,202 |  |  | 7,862 |  |  | (115 | ) |  | 340 |  |
|  | $ | 23,554 |  |  | $ | 25,281 |  |  | $ | 26,487 |  |  | $ | (1,727 | ) |  | $ | (1,206 | ) |

[0001234452-16-000552:mdna:59]
The decreases in equipment and services revenues in fiscal 2016 and 2015 were primarily due to decreases in QCT revenues of $1.76 billion and $1.49 billion, respectively. The decrease in equipment and services revenues in fiscal 2016 was partially offset by increases in a nonreportable segment’s revenues and QSI revenues of $56 million and $43 million, respectively. The decrease in licensing revenues in fiscal 2016 was primarily due to the decrease in QTL revenues, partially offset by an increase in a nonreportable segment’s revenues of $143 million. The increase in our licensing revenues in fiscal 2015 was primarily due to an increase in QTL revenues of $378 million.

[0001234452-16-000552:mdna:60]
QCT and QTL segment revenues related to the products of Samsung Electronics and Hon Hai Precision Industry Co., Ltd/Foxconn, its affiliates and other suppliers to Apple Inc. comprised 40%, 45% and 49% of total consolidated revenues in fiscal 2016, 2015 and 2014, respectively.

[0001234452-16-000552:mdna:61]
Revenues from customers in China, South Korea and Taiwan comprised 57%, 17% and 12%, respectively, of total consolidated revenues for fiscal 2016, compared to 53%, 16% and 13%, respectively, for fiscal 2015, and 50%, 23% and 11%, respectively, for fiscal 2014. We report revenues from external customers by country based on the location to which our products or services are delivered, which for QCT is generally the country in which our customers manufacture their products, or for licensing revenues, the invoiced addresses of our licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues would include revenues related to shipments of integrated circuits to a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States.

[0001234452-16-000552:mdna:62]
| Costs and Expenses (in millions) |  |  |  |  |  |
|  | 2016 |  | 2015 |  | 2014 |  | 2016 vs. 2015 Change |  | 2015 vs. 2014 Change |
| Cost of revenues | $ | 9,749 |  |  | $ | 10,378 |  |  | $ | 10,686 |  |  | $ | (629 | ) |  | $ | (308 | ) |
| Gross margin | 59 | % |  | 59 | % |  | 60 | % |  |  |  |  |

[0001234452-16-000552:mdna:63]
The margin percentage in fiscal 2016 remained flat primarily due to the effect of $163 million in additional charges related to the amortization of intangible assets and the recognition of the step-up of inventories to fair value primarily related to the acquisition of CSR plc in the fourth quarter of fiscal 2015, offset by the impact of higher-margin segment mix primarily related to QTL. The decrease in margin percentage in fiscal 2015 was primarily attributable to a decrease in QCT gross margin percentage. Our margin percentage may continue to fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors.

[0001234452-16-000552:mdna:64]
|  | 2016 |  | 2015 |  | 2014 |  | 2016 vs. 2015 Change |  | 2015 vs. 2014 Change |
| Research and development | $ | 5,151 |  |  | $ | 5,490 |  |  | $ | 5,477 |  |  | $ | (339 | ) |  | $ | 13 |  |
| % of revenues | 22 | % |  | 22 | % |  | 21 | % |  |  |  |  |
| Selling, general, and administrative | $ | 2,385 |  |  | $ | 2,344 |  |  | $ | 2,290 |  |  | $ | 41 |  |  | $ | 54 |  |
| % of revenues | 10 | % |  | 9 | % |  | 9 | % |  |  |  |  |
| Other | $ | (226 | ) |  | $ | 1,293 |  |  | $ | 484 |  |  | $ | (1,519 | ) |  | $ | 809 |  |

[0001234452-16-000552:mdna:65]
The dollar decrease in research and development expenses in fiscal 2016 was primarily attributable to a decrease of $228 million in costs related to the development of integrated circuit technologies and related software products. Such decrease was primarily driven by actions initiated under the Strategic Realignment Plan, partially offset by increased research and development costs resulting from acquisitions. The decrease in research and development expenses in fiscal 2016 also

[0001234452-16-000552:mdna:66]
42

[0001234452-16-000552:mdna:67]
included decreases of $67 million in development costs of display technologies and $45 million in share-based compensation expense. The dollar increase in research and development expenses in fiscal 2015 was primarily attributable to an increase of $117 million in costs related to the development of integrated circuit technologies and related software products, partially offset by a decrease of $72 million related to the development costs of display technologies and additional decreases related to the development costs of other new product and licensing initiatives.

[0001234452-16-000552:mdna:68]
The dollar increase in selling, general and administrative expenses in fiscal 2016 was primarily attributable to increases of $65 million in costs related to litigation and other legal matters, $39 million in employee-related expenses and $27 million in depreciation and amortization expense, partially offset by decreases of $36 million in share-based compensation expense, $21 million in selling and marketing expenses, $19 million in professional services and $17 million in patent-related costs. The dollar increase in selling, general and administrative expenses in fiscal 2015 was primarily attributable to increases of $73 million in selling and marketing expenses and $46 million in costs related to litigation and other legal matters, partially offset by decreases of $49 million in employee-related expenses and $13 million in share-based compensation.

[0001234452-16-000552:mdna:69]
Other income in fiscal 2016 was primarily attributable to a $380 million gain on the sale of wireless spectrum, partially offset by be net charges related to our Strategic Realignment Plan, which included $202 million in restructuring and restructuring-related charges, partially offset by a $48 million gain on the sale of our business that provided augmented reality applications. Other expenses in fiscal 2015 were attributable to a $975 million charge resulting from the resolution reached with the NDRC, charges of $255 million and $11 million for impairment of goodwill and intangible assets, respectively, related to our content and push-to-talk services and display businesses and $190 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan, partially offset by $138 million in gains on sales of certain property plant and equipment. Other expenses in fiscal 2014 were comprised of $607 million in certain property, plant and equipment and goodwill impairment charges and $19 million in restructuring-related costs incurred by one of our display businesses, a $16 million goodwill impairment charge related to our former QRS (Qualcomm Retail Solutions) division and a $15 million legal settlement, partially offset by the reversal of a $173 million expense accrual recorded in fiscal 2013 related to the ParkerVision verdict against us, which was overturned.

[0001234452-16-000552:mdna:70]
| Interest Expense and Net Investment Income (in millions) |  |  |  |  |  |  |
|  | 2016 |  | 2015 |  | 2014 |  | 2016 vs. 2015 Change |  | 2015 vs. 2014 Change |
| Interest expense | $ | 297 |  |  | $ | 104 |  |  | $ | 5 |  |  | $ | 193 |  |  | $ | 99 |  |
| Investment income, net |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 611 |  |  | $ | 527 |  |  | $ | 586 |  |  | $ | 84 |  |  | $ | (59 | ) |
| Net realized gains on marketable securities | 239 |  |  | 451 |  |  | 770 |  |  | (212 | ) |  | (319 | ) |
| Net realized gains on other investments | 49 |  |  | 49 |  |  | 56 |  |  | — |  |  | (7 | ) |
| Impairment losses on marketable securities and other investments | (172 | ) |  | (200 | ) |  | (180 | ) |  | 28 |  |  | (20 | ) |
| Equity in net losses of investees | (84 | ) |  | (32 | ) |  | (10 | ) |  | (52 | ) |  | (22 | ) |
| Other | (8 | ) |  | 20 |  |  | 11 |  |  | (28 | ) |  | 9 |  |
|  | $ | 635 |  |  | $ | 815 |  |  | $ | 1,233 |  |  | $ | (180 | ) |  | $ | (418 | ) |

[0001234452-16-000552:mdna:71]
The increase in interest expense in fiscal 2016 and 2015 was primarily due to the issuance of an aggregate principal amount of $10.0 billion in floating- and fixed-rate notes in May 2015.

[0001234452-16-000552:mdna:72]
| Income Tax Expense (in millions) |  |  |  |  |  |
|  | 2016 |  | 2015 |  | 2014 |  | 2016 vs. 2015 Change |  | 2015 vs. 2014 Change |
| Income tax expense | $ | 1,131 |  |  | $ | 1,219 |  |  | $ | 1,244 |  |  | $ | (88 | ) |  | $ | (25 | ) |
| Effective tax rate | 17 | % |  | 19 | % |  | 14 | % |  | (2 | )% |  | 5 | % |

[0001234452-16-000552:mdna:73]
The following table summarizes the primary factors that caused our annual effective tax rates to be less than the United States federal statutory rate:

[0001234452-16-000552:mdna:74]
|  | 2016 |  | 2015 |  | 2014 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (16 | %) |  | (14 | %) |  | (20 | %) |
| Benefits related to the research and development tax credits | (2 | %) |  | (2 | %) |  | (1 | %) |
| Worthless stock deduction of domestic subsidiary | (1 | %) |  | — |  |  | — |  |
| Other | 1 | % |  | — |  |  | — |  |
| Effective tax rate | 17 | % |  | 19 | % |  | 14 | % |

[0001234452-16-000552:mdna:75]
The annual effective tax rate of 17% for fiscal 2016 reflected a $101 million tax benefit recorded discretely in the third quarter resulting from a worthless stock deduction on a domestic subsidiary of one of our former display businesses and a $79 million benefit of the retroactive reinstatement of the United States federal research and development credit recorded discretely during the first quarter of fiscal 2016 related to fiscal 2015. The effective tax rate for our state income tax provision, net of federal benefit, was negligible for all years presented.

[0001234452-16-000552:mdna:76]
During fiscal 2015, the NDRC imposed a fine of $975 million, which was not deductible for tax purposes and was substantially attributable to a foreign jurisdiction. Additionally, during fiscal 2015, we recorded a tax benefit of $101 million related to fiscal 2014 resulting from the United States government reinstating the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. The effective tax rate for fiscal 2015 also reflected the United States federal research and development tax credit generated through December 31, 2014, the date on which the credit expired and a $61 million tax benefit as a result of a favorable tax audit settlement with the Internal Revenue Service (IRS) related to Qualcomm Atheros, Inc.’s pre-acquisition 2010 and 2011 tax returns. The annual effective tax rate for fiscal 2014 reflected the tax benefit from the United States federal research and development tax credit generated through December 31, 2013, the date on which the credit previously expired. The effective tax rate for fiscal 2014 also reflected a tax benefit of $66 million related to fiscal 2013 resulting from an agreement reached with the IRS on components of our fiscal 2013 tax return.

[0001234452-16-000552:mdna:77]
The annual effective tax rate for fiscal 2016, 2015 and 2014 also reflected tax benefits for certain tax incentives obtained in Singapore that commenced in March 2012, including a tax exemption for the first five years, provided that we meet specified employment and other criteria. Our Singapore tax rate is expected to increase in fiscal 2017 and again in fiscal 2027 as a result of the expiration of these incentives.

[0001234452-16-000552:mdna:78]
Unrecognized tax benefits were $271 million and $40 million at September 25, 2016 and September 27, 2015, respectively. The increase in unrecognized tax benefits in fiscal 2016 was primarily due to tax positions related to classification of income. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at September 25, 2016 may increase or decrease in the next 12 months.

[0001234452-16-000552:mdna:79]
Our Segment Results

[0001234452-16-000552:mdna:80]
The following should be read in conjunction with the fiscal 2016, 2015 and 2014 financial results for each reportable segment included in this Annual Report in “Notes to Consolidated Financial Statements, Note 8. Segment Information.”

[0001234452-16-000552:mdna:81]
| (in millions) | QCT |  | QTL |  | QSI |
| 2016 |  |  |  |  |  |
| Revenues | $ | 15,409 |  |  | $ | 7,664 |  |  | $ | 47 |  |
| EBT (1) | 1,812 |  |  | 6,528 |  |  | 386 |  |
| EBT as a % of revenues | 12 | % |  | 85 | % |  |  |
| 2015 |  |  |  |  |  |
| Revenues | $ | 17,154 |  |  | $ | 7,947 |  |  | $ | 4 |  |
| EBT (1) | 2,465 |  |  | 6,882 |  |  | (74 | ) |
| EBT as a % of revenues | 14 | % |  | 87 | % |  |  |
| 2014 |  |  |  |  |  |
| Revenues | $ | 18,665 |  |  | $ | 7,569 |  |  | $ | — |  |
| EBT (1) | 3,807 |  |  | 6,590 |  |  | (7 | ) |
| EBT as a % of revenues | 20 | % |  | 87 | % |  |  |

[0001234452-16-000552:mdna:82]
| (1) | Earnings (loss) before taxes. |

[0001234452-16-000552:mdna:83]
QCT Segment. QCT results of operations in fiscal 2016 were negatively impacted by the effects of a shift in share among our customers within the premium tier, which reduced our sales of integrated Snapdragon processors and skewed our product mix towards lower-margin modem chipsets in this tier, a decline in share at our large customers and the competitive environment in China. The decreases in QCT revenues in fiscal 2016 and 2015 of $1.75 billion and $1.51 billion, respectively, were primarily due to decreases in equipment and services revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying Radio Frequency (RF) and Power Management (PM) integrated circuits, were $15.18 billion, $16.95 billion and $18.43 billion in fiscal 2016, 2015 and 2014, respectively. The decrease in equipment and services revenues in fiscal 2016 resulted primarily from decreases of $1.35 billion related to lower MSM and accompanying RF and PM unit shipments and $1.14 billion from lower average selling prices and lower-priced product mix, partially offset by a net increase of $753 million in revenues related to other products, primarily related to higher connectivity shipments resulting from the acquisition of CSR in the fourth quarter of fiscal 2015. The decrease in equipment and services revenues in fiscal 2015 resulted primarily from a decrease of $2.89 billion from lower-priced product mix and lower average selling prices, partially offset by an increase of $1.26 billion related to higher MSM and accompanying RF and PM unit shipments. Approximately 842 million, 932 million and 861 million MSM integrated circuits were sold during fiscal 2016, 2015 and 2014, respectively.

[0001234452-16-000552:mdna:84]
QCT EBT as a percentage of revenues decreased in fiscal 2016 as compared to fiscal 2015 primarily due to the impact of lower revenues relative to operating expenses. QCT gross margin percentage remained flat in fiscal 2016 primarily as a result of lower average selling prices and lower-margin product mix, offset by lower average unit costs and lower excess inventory charges. QCT EBT as a percentage of revenues decreased in fiscal 2015 as compared to fiscal 2014 primarily due to a decrease in gross margin percentage and the related impact of lower revenues relative to operating expenses. The decrease in QCT gross margin percentage in fiscal 2015 primarily resulted from lower average selling prices and lower-margin product mix, partially offset by lower average unit costs. QCT gross margin percentage in fiscal 2015 was also impacted by an increase of $179 million in excess inventory charges.

[0001234452-16-000552:mdna:85]
QTL Segment. The decrease in QTL revenues in fiscal 2016 of $283 million was primarily attributable to decreases in revenues per reported unit and recognition of unearned license fees, partially offset by an increase in reported sales of CDMA-based products (including multimode products that also implement OFDMA) and $266 million in licensing revenues recorded in the second quarter of fiscal 2016 due to the termination of an infrastructure license agreement resulting from the merger of two licensees. QTL revenues and EBT in fiscal 2016 continued to be impacted negatively by units that we believe are not being reported by certain licensees and sales of certain unlicensed products. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing, and additional litigation may become necessary if negotiations fail to resolve the relevant issues.

[0001234452-16-000552:mdna:86]
The increase in QTL revenues in fiscal 2015 of $378 million was primarily due to an increase in sales of CDMA-based products, including multimode products that also implement OFDMA, reported by licensees, partially offset by a decrease in revenues per reported unit. QTL revenues and EBT in fiscal 2015 were impacted negatively by units that we believe were not being reported by certain licensees and sales of certain unlicensed products in China. Also in fiscal 2015, QTL experienced negative fluctuations in foreign currency exchange rates.

[0001234452-16-000552:mdna:87]
45

[0001234452-16-000552:mdna:88]
QSI Segment. The increase in QSI EBT in fiscal 2016 was primarily due to a $380 million gain on the sale of wireless spectrum, an increase of $47 million in net realized gains on investments and a decrease of $21 million in impairment losses on investments. The decrease in QSI EBT in fiscal 2015 of $67 million was primarily due to increases of $32 million in impairment losses on investments and $29 million in equity losses and other costs related to our equity method investments.

[0001234452-16-000552:mdna:89]
Liquidity and Capital Resources

[0001234452-16-000552:mdna:90]
On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings will acquire NXP. Pursuant to the definitive agreement, Qualcomm River Holdings will commence a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration of $38 billion. The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions. We intend to fund the transaction with cash held by foreign entities, which will result in the use of a substantial portion of our cash, cash equivalents and marketable securities, as well as new debt, and we secured $13.6 billion in committed financing in connection with signing the definitive agreement.

[0001234452-16-000552:mdna:91]
Qualcomm River Holdings and NXP may terminate the definitive agreement under certain circumstances. If the definitive agreement is terminated by NXP in certain circumstances, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the definitive agreement is terminated by Qualcomm River Holdings under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion.

[0001234452-16-000552:mdna:92]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. The following table presents selected financial information related to our liquidity as of and for the years ended September 25, 2016 and September 27, 2015 (in millions):

[0001234452-16-000552:mdna:93]
|  | 2016 |  | 2015 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 32,350 |  |  | $ | 30,947 |  |  | $ | 1,403 |  |  | 5 | % |
| Accounts receivable, net | 2,219 |  |  | 1,964 |  |  | 255 |  |  | 13 | % |
| Inventories | 1,556 |  |  | 1,492 |  |  | 64 |  |  | 4 | % |
| Short-term debt | 1,749 |  |  | 1,000 |  |  | 749 |  |  | 75 | % |
| Long-term debt | 10,008 |  |  | 9,969 |  |  | 39 |  |  | — | % |
| Net cash provided by operating activities | 7,400 |  |  | 5,506 |  |  | 1,894 |  |  | 34 | % |
| Net cash used by investing activities | (3,488 | ) |  | (3,572 | ) |  | 84 |  |  | 2 | % |
| Net cash used by financing activities | (5,522 | ) |  | (2,261 | ) |  | (3,261 | ) |  |  |

[0001234452-16-000552:mdna:94]
The net increase in cash, cash equivalents and marketable securities was primarily the result of net cash provided by operating activities and net proceeds from short-term debt, partially offset by $3.9 billion in payments to repurchase shares of our common stock and $3.0 billion in cash dividends paid. Total cash provided by operating activities increased primarily due to changes in working capital, which was impacted by a prepayment of $950 million in fiscal 2015 to secure long-term capacity commitments at a supplier of our integrated circuit products, and an increase in net income of $434 million. Our days sales outstanding, on a consolidated basis, were 33 days at September 25, 2016 and September 27, 2015. The increase in accounts receivable was primarily due to the timing of the collection of payments from certain of our licensees. The increase in inventories was primarily due to an increase in the overall quantity of units on hand to align with near-term demand, partially offset by lower average unit costs.

[0001234452-16-000552:mdna:95]
Our cash, cash equivalents and marketable securities at September 25, 2016 consisted of $2.8 billion held by United States-based entities and $29.6 billion held by foreign entities. Most of our cash, cash equivalents and marketable securities held by foreign entities are indefinitely reinvested and would be subject to material tax effects if repatriated. However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate the funds.

[0001234452-16-000552:mdna:96]
We believe our current cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements, in addition to our proposed acquisition of NXP, also include the items described below.

[0001234452-16-000552:mdna:97]
| • | Our purchase obligations at September 25, 2016, some of which relate to research and development activities and capital expenditures, totaled $4.2 billion and $886 million for fiscal 2017 and 2018, respectively, and $1.0 billion thereafter. |

[0001234452-16-000552:mdna:98]
| • | Our research and development expenditures were $5.2 billion and $5.5 billion during fiscal 2016 and 2015, respectively, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications. |

[0001234452-16-000552:mdna:99]
| • | Cash outflows for capital expenditures were $539 million and $994 million during fiscal 2016 and 2015, respectively. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-16-000552:mdna:100]
| • | In January 2016, we announced that we had reached agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd. The joint venture will initially be owned 51% by us and 49% by TDK. The purchase price due upon close of the transaction is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, we have the option to acquire (and TDK has an option to sell) TDK’s interest in the joint venture for $1.15 billion 30 months after the closing date. We expect to use existing cash resources to fund the acquisition. TDK will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date. The transaction is subject to regulatory approvals and other closing conditions and is expected to close in early calendar 2017. |

[0001234452-16-000552:mdna:101]
| • | We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly, to open new opportunities for our technologies, obtain development resources, grow our patent portfolio or pursue new businesses. |

[0001234452-16-000552:mdna:102]
Debt. We have a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. At September 25, 2016, no amounts were outstanding under the Revolving Credit Facility.

[0001234452-16-000552:mdna:103]
We have an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At September 25, 2016, we had $1.7 billion of commercial paper outstanding with weighted-average net interest rates of 0.52% and weighted-average remaining days to maturity of 36 days.

[0001234452-16-000552:mdna:104]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, with maturity dates in 2018 through 2045 and effective interest rates between 0.93% and 4.74%. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. In addition to the new debt we expect to issue in connection with our proposed acquisition of NXP, we may also issue debt in the future. The amount and timing of such additional borrowings will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001234452-16-000552:mdna:105]
Additional information regarding our outstanding debt at September 25, 2016 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 6. Debt.”

[0001234452-16-000552:mdna:106]
Capital Return Program. The following table summarizes stock repurchases and dividends paid during fiscal 2016, 2015 and 2014 (in millions, except per-share amounts):

[0001234452-16-000552:mdna:107]
|  |  | Stock Repurchase Program |  | Dividends |  | Total |
|  |  | Shares |  | Average Price Paid Per Share |  | Amount |  | Per Share |  | Amount |  | Amount |
| 2016 |  | 73.8 |  |  | $ | 53.16 |  |  | $ | 3,922 |  |  | $ | 2.02 |  |  | $ | 2,990 |  |  | $ | 6,912 |  |
| 2015 |  | 172.4 |  |  | 65.21 |  |  | 11,245 |  |  | 1.80 |  |  | 2,880 |  |  | 14,125 |  |
| 2014 |  | 60.3 |  |  | 75.48 |  |  | 4,548 |  |  | 1.54 |  |  | 2,586 |  |  | 7,134 |  |

[0001234452-16-000552:mdna:108]
On March 9, 2015, we announced that we had been authorized to repurchase up to $15 billion of our common stock. Additionally, we announced our intention to repurchase $10 billion of stock from March 2015 through March 2016, which we completed during the first quarter of fiscal 2016. At September 25, 2016, $3.0 billion remained authorized for repurchase under our stock repurchase program. Since September 25, 2016, we repurchased and retired 1,865,000 shares of common

[0001234452-16-000552:mdna:109]
47

[0001234452-16-000552:mdna:110]
stock for $124 million. As a result of our proposed acquisition of NXP and the pending use of our cash and marketable securities, we currently expect to repurchase shares during the next few years to offset dilution. We periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders.

[0001234452-16-000552:mdna:111]
On October 6, 2016, we announced a cash dividend of $0.53 per share on our common stock, payable on December 16, 2016 to stockholders of record as of the close of business on November 30, 2016. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-16-000552:mdna:112]
Contractual Obligations/Off-Balance Sheet Arrangements

[0001234452-16-000552:mdna:113]
We have no significant contractual obligations not fully recorded on our consolidated balance sheets or fully disclosed in the notes to our consolidated financial statements. We have no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001234452-16-000552:mdna:114]
The following table summarizes the payments due by fiscal period for our outstanding contractual obligations at September 25, 2016 (in millions):

[0001234452-16-000552:mdna:115]
|  | Total |  | 2017 |  | 2018-2019 |  | 2020-2021 |  | Beyond2021 |  | NoExpirationDate |
| Purchase obligations (1) | $ | 6,104 |  |  | $ | 4,204 |  |  | $ | 1,635 |  |  | $ | 260 |  |  | $ | 5 |  |  | $ | — |  |
| Operating lease obligations | 338 |  |  | 94 |  |  | 132 |  |  | 76 |  |  | 36 |  |  | — |  |
| Equity funding and financing commitments (2) | 251 |  |  | 16 |  |  | 87 |  |  | 12 |  |  | 134 |  |  | 2 |  |
| Long-term debt (3) | 10,000 |  |  | — |  |  | 1,500 |  |  | 2,000 |  |  | 6,500 |  |  | — |  |
| Other long-term liabilities (4)(5) | 240 |  |  | 4 |  |  | 191 |  |  | 31 |  |  | 3 |  |  | 11 |  |
| Total contractual obligations | $ | 16,933 |  |  | $ | 4,318 |  |  | $ | 3,545 |  |  | $ | 2,379 |  |  | $ | 6,678 |  |  | $ | 13 |  |

[0001234452-16-000552:mdna:116]
| (1) | Total purchase obligations include commitments to purchase integrated circuit product inventories of $3.4 billion, $766 million, $673 million and $158 million for each of the subsequent four years from fiscal 2017 through 2020, respectively; there were no such purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancelation of outstanding purchase orders is generally allowed but requires payment of all costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization. |

[0001234452-16-000552:mdna:117]
| (2) | Certain of these commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all. |

[0001234452-16-000552:mdna:118]
| (3) | The amounts noted herein represent contractual payments of principal only. |

[0001234452-16-000552:mdna:119]
| (4) | Certain long-term liabilities reflected on our balance sheet, such as unearned revenues, are not presented in this table because they do not require cash settlement in the future. Other long-term liabilities as presented in this table include the related current portions, as applicable. |

[0001234452-16-000552:mdna:120]
| (5) | Our consolidated balance sheet at September 25, 2016 included $140 million in noncurrent liabilities for uncertain tax positions, some of which may result in cash payment. The future payments related to uncertain tax positions have not been presented in the table above due to the uncertainty of the amounts and timing of cash settlement with the taxing authorities. |

[0001234452-16-000552:mdna:121]
Additional information regarding our financial commitments at September 25, 2016 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 3. Income Taxes,” “Note 6. Debt” and “Note 7. Commitments and Contingencies.”

[0001234452-16-000552:mdna:122]
Recent Accounting Pronouncements

[0001234452-16-000552:mdna:123]
Information regarding recent accounting pronouncements and the impact of those pronouncements, if any, on our consolidated financial statements is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 1. The Company and Its Significant Accounting Policies.”
