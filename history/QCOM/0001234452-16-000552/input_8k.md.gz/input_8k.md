# QCOM 8-K — 0001234452-16-000551 filed 2016-11-02

## item codes, every 8-K on or before 2016-11-02

- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2016-11-02

- none on or before 2016-11-02

## item 2.02 — earnings release, exhibit 99.1

[0001234452-16-000551:8k_2_02:1]
EX-99.1
2
qcom92516erex991.htm
EXHIBIT 99.1

[0001234452-16-000551:8k_2_02:2]
Exhibit

[0001234452-16-000551:8k_2_02:3]
Exhibit 99.1

[0001234452-16-000551:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-16-000551:8k_2_02:5]
Qualcomm Contact:

[0001234452-16-000551:8k_2_02:6]
John Sinnott

[0001234452-16-000551:8k_2_02:7]
Vice President, Investor Relations

[0001234452-16-000551:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-16-000551:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-16-000551:8k_2_02:10]
Qualcomm Announces Fourth Quarter and Fiscal 2016 Results

[0001234452-16-000551:8k_2_02:11]
Fiscal 2016 Revenues $23.6 billion

[0001234452-16-000551:8k_2_02:12]
GAAP EPS $3.81, Non-GAAP EPS $4.44

[0001234452-16-000551:8k_2_02:13]
-Fiscal Q4 EPS Exceeds High End of Prior Guidance-

[0001234452-16-000551:8k_2_02:14]
SAN DIEGO - November 2, 2016 - Qualcomm Incorporated (NASDAQ: QCOM), a leading developer and innovator of advanced wireless technologies, products and services, today announced results for its fiscal fourth quarter and year ended September 25, 2016.

[0001234452-16-000551:8k_2_02:15]
“Our fiscal fourth quarter EPS was above the high end of our expectations, reflecting new license agreements in China and strong chipset shipments,” said Steve Mollenkopf, CEO of Qualcomm Incorporated. “We are forecasting continued growth of global 3G/4G device shipments in calendar year 2017, led by growing demand in emerging regions.  We are well positioned to extend our mobile technology leadership and footprint into attractive growth opportunities, accelerated by our recently announced agreement to acquire NXP.”

[0001234452-16-000551:8k_2_02:16]
GAAP Results

[0001234452-16-000551:8k_2_02:17]
Fourth Quarter Fiscal 2016*

[0001234452-16-000551:8k_2_02:18]
|  | Q4 Fiscal 2016 |  | Q4 Fiscal 2015 |  | Year-Over-Year Change |  | Q3 Fiscal 2016 |  | Sequential Change |
| Revenues | $6.2B |  | $5.5B |  | +13% |  | $6.0B |  | +2% |
| Operating income | $1.8B |  | $1.1B |  | +58% |  | $1.6B |  | +13% |
| Net income 1 | $1.6B |  | $1.1B |  | +51% |  | $1.4B |  | +11% |
| Diluted earnings per share 1 | $1.07 |  | $0.67 |  | +60% |  | $0.97 |  | +10% |
| Operating cash flow | $2.1B |  | $1.7B |  | +24% |  | $1.8B |  | +13% |

[0001234452-16-000551:8k_2_02:19]
1 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests), unless otherwise stated.

[0001234452-16-000551:8k_2_02:20]
Fiscal 2016*

[0001234452-16-000551:8k_2_02:21]
|  | Fiscal2016 |  | Fiscal2015 |  | Year-Over-Year Change |
| Revenues | $23.6B |  | $25.3B |  | (7%) |
| Operating income | $6.5B |  | $5.8B |  | +12% |
| Net income | $5.7B |  | $5.3B |  | +8% |
| Diluted earnings per share | $3.81 |  | $3.22 |  | +18% |
| Operating cash flow | $7.4B |  | $5.5B |  | +34% |

[0001234452-16-000551:8k_2_02:22]
Non-GAAP Results

[0001234452-16-000551:8k_2_02:23]
Fourth Quarter Fiscal 2016*

[0001234452-16-000551:8k_2_02:24]
|  | Q4 Fiscal 2016 |  | Q4 Fiscal 2015 |  | Year-Over-Year Change |  | Q3 Fiscal 2016 |  | Sequential Change |
| Revenues | $6.2B |  | $5.5B |  | +13% |  | $6.0B |  | +2% |
| Operating income | $2.2B |  | $1.6B |  | +35% |  | $2.0B |  | +7% |
| Net income | $1.9B |  | $1.4B |  | +33% |  | $1.7B |  | +10% |
| Diluted earnings per share | $1.28 |  | $0.91 |  | +41% |  | $1.16 |  | +10% |

[0001234452-16-000551:8k_2_02:25]
Fiscal 2016*

[0001234452-16-000551:8k_2_02:26]
|  | Fiscal2016 |  | Fiscal2015 |  | Year-Over-Year Change |
| Revenues | $23.5B |  | $25.3B |  | (7%) |
| Operating income | $7.8B |  | $8.6B |  | (9%) |
| Net income | $6.7B |  | $7.6B |  | (13%) |
| Diluted earnings per share | $4.44 |  | $4.66 |  | (5%) |

[0001234452-16-000551:8k_2_02:27]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding the Company’s use of Non-GAAP financial measures and detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-16-000551:8k_2_02:28]
* The following should be considered in regards to the year-over-year and sequential comparisons:

[0001234452-16-000551:8k_2_02:29]
| • | Fiscal 2016 GAAP results included: |

[0001234452-16-000551:8k_2_02:30]
| ◦ | $154 million of charges, or $0.07 per share, that resulted from net restructuring and restructuring-related charges related to our Strategic Realignment Plan in fiscal 2016; and |

[0001234452-16-000551:8k_2_02:31]
| ◦ | $380 million gain, or $0.20 per share, related to the sale of our wireless spectrum in the United Kingdom in the first quarter of fiscal 2016. |

[0001234452-16-000551:8k_2_02:32]
| • | Fiscal 2016 GAAP and Non-GAAP results included: |

[0001234452-16-000551:8k_2_02:33]
| ◦ | $266 million of revenues, or $0.13 per share, due to the termination of an infrastructure license agreement resulting from the merger of two licensees in the second quarter of fiscal 2016; and |

[0001234452-16-000551:8k_2_02:34]
| ◦ | $235 million of revenues, or $0.11 per share, due to the recognition of previously deferred royalty revenues related to the dismissal of the arbitration with LG Electronics, Inc. in the third quarter of fiscal 2016. |

[0001234452-16-000551:8k_2_02:35]
| • | Fiscal 2015 GAAP results included: |

[0001234452-16-000551:8k_2_02:36]
| ◦ | $975 million charge, or $0.58 per share, related to the resolution reached with the China National Development and Reform Commission (NDRC) regarding its investigation of us under China’s Anti-Monopoly Law in the second quarter of fiscal 2015; |

[0001234452-16-000551:8k_2_02:37]
| ◦ | $142 million of charges, or $0.08 per share, that resulted from an impairment of goodwill and long-lived assets related to one of our display businesses in the third quarter of fiscal 2015; |

[0001234452-16-000551:8k_2_02:38]
| ◦ | $190 million of charges, or $0.09 per share, that resulted from restructuring and restructuring-related charges related to our Strategic Realignment Plan in the fourth quarter of fiscal 2015; and |

[0001234452-16-000551:8k_2_02:39]
| ◦ | Operating cash flow was impacted by the prepayment of $950 million to secure long-term capacity commitments at a supplier of our integrated circuit products in the second quarter of fiscal 2015. |

[0001234452-16-000551:8k_2_02:40]
Segment Results

[0001234452-16-000551:8k_2_02:41]
Fourth Quarter Fiscal 2016

[0001234452-16-000551:8k_2_02:42]
|  | Q4 Fiscal 2016 |  | Q4 Fiscal 2015 |  | Year-Over-Year Change (1) |  | Q3 Fiscal 2016 |  | Sequential Change (1) |
| QCT |  |  |  |  |  |  |  |  |  |
| Revenues | $4,124M |  | $3,625M |  | +14% |  | $3,853M |  | +7% |
| Earnings before taxes (EBT) | $687M |  | $280M |  | +145% |  | $365M |  | +88% |
| EBT as % of revenues | 17% |  | 8% |  | +9% |  | 9% |  | +8% |
| MSMTM chip shipments | 211M |  | 203M |  | +4% |  | 201M |  | +5% |
| QTL |  |  |  |  |  |  |  |  |  |
| Revenues | $1,885M |  | $1,785M |  | +6% |  | $2,038M |  | (8%) |
| EBT | $1,584M |  | $1,487M |  | +7% |  | $1,749M |  | (9%) |
| EBT as % of revenues | 84% |  | 83% |  | +1% |  | 86% |  | (2%) |
| Total reported device sales (2) (3) | $74.2B |  | $58.3B |  | +27% |  | $62.6B |  | +19% |
| Est. reported 3G/4G device shipments | 401M - 405M |  | 276M - 280M |  | +45% |  | 321M - 325M |  | +25% |
| Est. reported 3G/4G average selling price | $181 - $187 |  | $207 - $213 |  | (12%) |  | $191 - $197 |  | (5%) |

[0001234452-16-000551:8k_2_02:43]
Refer to the footnotes immediately following the next table.

[0001234452-16-000551:8k_2_02:44]
Fiscal 2016

[0001234452-16-000551:8k_2_02:45]
|  | Fiscal2016 |  | Fiscal2015 |  | Year-Over-Year Change (1) |
| QCT |  |  |  |  |  |
| Revenues | $15,409M |  | $17,154M |  | (10%) |
| Earnings before taxes (EBT) | $1,812M |  | $2,465M |  | (26%) |
| EBT as % of revenues | 12% |  | 14% |  | (2%) |
| MSM chip shipments | 842M |  | 932M |  | (10%) |
| QTL |  |  |  |  |  |
| Revenues | $7,664M |  | $7,947M |  | (4%) |
| EBT | $6,528M |  | $6,882M |  | (5%) |
| EBT as % of revenues | 85% |  | 87% |  | (2%) |
| Total reported device sales (2) (3) | $267.4B |  | $250.9B |  | +7% |
| Est. reported 3G/4G device shipments | 1,364M - 1,380M |  | 1,233M - 1,249M |  | +11% |
| Est. reported 3G/4G average selling price | $192 - $198 |  | $199 - $205 |  | (3%) |

[0001234452-16-000551:8k_2_02:46]
| (1) | The sequential changes and year-over-year for estimated reported 3G/4G device shipments and average selling prices are calculated at the midpoints. The midpoints of the estimated ranges are used for comparison purposes only and do not indicate a higher degree of confidence in the midpoints. |

[0001234452-16-000551:8k_2_02:47]
| (2) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based |

[0001234452-16-000551:8k_2_02:48]
and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a

[0001234452-16-000551:8k_2_02:49]
particular period (collectively, 3G/4G devices). The reported quarterly estimated ranges of average selling prices (ASPs) and unit shipments are determined based on the information as reported to us by our licensees during the relevant period and our own estimates of the selling prices and unit shipments for licensees that do not provide such information. Not all licensees report sales, selling prices and/or unit shipments the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales, estimated unit shipments and estimated ASPs for a particular period may include prior period activity that was not reported by the licensee until such particular period.

[0001234452-16-000551:8k_2_02:50]
| (3) | The fourth quarter of fiscal 2015 and 2016 are based on sales by our licensees in the June quarter as reported to us in the September quarter, and the third quarter of fiscal 2016 is based on sales by our licensees in the March quarter as reported to us in the June quarter. Fiscal 2015 and 2016 are based on sales of our licensees in the September to June quarters as reported to us in the December to September quarters. |

[0001234452-16-000551:8k_2_02:51]
The third and fourth quarters of fiscal 2016 total reported device sales include reporting of certain prior period activity (i.e., devices shipped in prior periods) from certain licensees that had not previously been reporting under their prior agreements.

[0001234452-16-000551:8k_2_02:52]
Cash and Marketable Securities

[0001234452-16-000551:8k_2_02:53]
Our cash, cash equivalents and marketable securities totaled $32.4 billion at the end of the fourth quarter of fiscal 2016, compared to $30.9 billion a year ago and $31.0 billion at the end of the third quarter of fiscal 2016.

[0001234452-16-000551:8k_2_02:54]
Recently Announced Agreement to Acquire NXP

[0001234452-16-000551:8k_2_02:55]
On October 27, 2016, we announced a definitive agreement to acquire NXP Semiconductors N.V. for estimated total cash consideration of $38 billion.  NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network

[0001234452-16-000551:8k_2_02:56]
processing and RF power products.  The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions.  We intend to fund the transaction with cash held by foreign entities, which will result in the use of a substantial portion of our cash, cash equivalents and marketable securities, and new debt.

[0001234452-16-000551:8k_2_02:57]
Return of Capital to Stockholders

[0001234452-16-000551:8k_2_02:58]
The following table summarizes stock repurchases and dividends paid during the fourth quarter and fiscal 2016 (in millions, except per-share amounts):

[0001234452-16-000551:8k_2_02:59]
|  | Stock Repurchases |  | Dividends |  | Total |
|  | Shares |  | Amount |  | Per Share |  | Amount |  | Amount |
| Q4 fiscal 2016 | 3.6 |  | $225 |  | $0.53 |  | $782 |  | $1,007 |
| Fiscal 2016 | 73.8 |  | $3,922 |  | $2.02 |  | $2,990 |  | $6,912 |

[0001234452-16-000551:8k_2_02:60]
Since September 25, 2016, we repurchased and retired 1.9 million shares of common stock for $124 million.  On October 6, 2016, we announced a cash dividend of $0.53 per share payable on December 16, 2016 to stockholders of record as of the close of business on November 30, 2016.

[0001234452-16-000551:8k_2_02:61]
Effective Income Tax Rates

[0001234452-16-000551:8k_2_02:62]
Our fiscal 2016 annual effective income tax rates were 17 percent for GAAP and 18 percent for Non-GAAP.  The effective income tax rates for the fourth quarter of fiscal 2016 were 18 percent for GAAP and 19 percent for Non-GAAP.  The fiscal 2016 effective tax rate for GAAP included a $101 million benefit recorded discretely in the third quarter resulting from a worthless stock deduction on a domestic subsidiary of one of our former display businesses and a $79 million benefit of the retroactive reinstatement of the United States federal research and development credit recorded discretely during the first quarter of fiscal 2016 related to fiscal 2015.

[0001234452-16-000551:8k_2_02:63]
Business Outlook

[0001234452-16-000551:8k_2_02:64]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment and certain derivative gains or losses, cannot be accurately

[0001234452-16-000551:8k_2_02:65]
forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001234452-16-000551:8k_2_02:66]
We have not included any estimates related to any proposed joint ventures or acquisitions in our first quarter of fiscal 2017 outlook.

[0001234452-16-000551:8k_2_02:67]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-16-000551:8k_2_02:68]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001234452-16-000551:8k_2_02:69]
|  |  | Q1 FY16 Results | Current Guidance Q1 FY17 Estimates |  |
|  | Revenues | $5.8B | $5.7B - $6.5B |  |  |
|  | Year-over-year change |  | decrease 1% - increase 13% |  |  |
|  | GAAP diluted earnings per share (EPS) | $0.99 | $0.91 - $1.01 |  |  |
|  | Year-over-year change |  | decrease 8% - increase 2% |  |  |
|  | Less diluted EPS attributable to QSI | $0.15 |  | $0.01 |  |  |
|  | Less diluted EPS attributable to share-based compensation | ($0.12) |  | ($0.13 | ) |  |
|  | Less diluted EPS attributable to other items (1) | ($0.01) |  | ($0.09 | ) |  |
|  | Non-GAAP diluted EPS | $0.97 | $1.12 - $1.22 |  |  |
|  | Year-over-year change |  | increase 15% - 26% |  |  |
|  | Metrics |  |  |  |
|  | MSM chip shipments | 242M | 205M - 225M |  |  |
|  | Year-over-year change |  | decrease 7% - 15% |  |  |
|  | Total reported device sales* | approx. $60.6B | approx. $58.0B - $66.0B |  | (2) |
|  | Year-over-year change |  | decrease 4% - increase 9% |  |  |
|  | *Est. sales in September quarter, reported in December quarter |  |  |  |

[0001234452-16-000551:8k_2_02:70]
| (1) | Our guidance for diluted EPS attributable to other items for the first quarter of fiscal 2017 is attributable to acquisition-related items. |

[0001234452-16-000551:8k_2_02:71]
| (2) | Our guidance range for the first quarter of fiscal 2017 total reported device sales reflects estimated 3G/4G total reported device sales that we currently expect to be reported to us, which includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-16-000551:8k_2_02:72]
Sums may not equal total due to rounding.

[0001234452-16-000551:8k_2_02:73]
Reconciliations of GAAP Results to Non-GAAP Results

[0001234452-16-000551:8k_2_02:74]
The following tables reconcile our GAAP results to our Non-GAAP results ($ in millions, except per share data):

[0001234452-16-000551:8k_2_02:75]
|  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) |  | Non-GAAP Results |
| Q4 FISCAL 2016 |  |  |  |  |  |  |  |
| Revenues | $6,184 |  | $14 |  |  | $— |  |  | $— |  |  | $6,170 |  |
| Operating income (loss) | 1,804 |  | (1) |  | (213) | (158) |  | 2,176 |  |
| EBT | 1,960 |  | (14) |  | (213) | (158) |  | 2,345 |  |
| EBT as % of revenues | 32 | % |  |  |  |  |  |  | 38 | % |  |
| Net income (loss) | 1,599 |  | (9) |  | (150) | (147) |  | 1,905 |  |
| Diluted EPS | $1.07 |  | ($0.01) |  | ($0.10) | ($0.10) |  | $1.28 |  |
| Diluted shares | 1,491 |  | 1,491 |  | 1,491 | 1,491 |  | 1,491 |  |
| Q3 FISCAL 2016 |  |  |  |  |  |  |  |
| Revenues | $6,044 |  | $12 |  |  | $— |  |  | $— |  |  | $6,032 |  |
| Operating income (loss) | 1,592 |  | (2) |  | (235) | (203) |  | 2,032 |  |
| EBT | 1,693 |  | (5) |  | (235) | (203) |  | 2,136 |  |
| EBT as % of revenues | 28 | % |  |  |  |  |  |  | 35 | % |  |
| Net income (loss) | 1,444 |  | (4) |  | (197) | (84) |  | 1,729 |  |
| Diluted EPS | $0.97 |  | $0.00 |  | ($0.13) | ($0.06) |  | $1.16 |  |
| Diluted shares | 1,486 |  | 1,486 |  | 1,486 | 1,486 |  | 1,486 |  |
| Q4 FISCAL 2015 |  |  |  |  |  |  |  |
| Revenues | $5,456 |  | $4 |  |  | $— |  |  | $— |  |  | $5,452 |  |
| Operating income (loss) | 1,140 |  | (8) |  | (233) | (236) |  | 1,617 |  |
| EBT | 1,252 |  | 8 |  | (233) | (236) |  | 1,713 |  |
| EBT as % of revenues | 23 | % |  |  |  |  |  |  | 31 | % |  |
| Net income (loss) | 1,061 |  | 8 |  | (188) | (186) |  | 1,427 |  |
| Diluted EPS | $0.67 |  | $0.01 |  | ($0.12) | ($0.12) |  | $0.91 |  |
| Diluted shares | 1,573 |  | 1,573 |  | 1,573 | 1,573 |  | 1,573 |  |
| FISCAL 2016 |  |  |  |  |  |  |  |  |  |
| Revenues | $23,554 |  | $47 |  |  | $— |  |  | $— |  |  | $23,507 |  |
| Operating income (loss) | 6,495 |  | 372 |  | (943) | (768) |  | 7,834 |  |
| EBT | 6,833 |  | 386 |  | (943) | (768) |  | 8,158 |  |
| EBT as % of revenues | 29 | % |  |  |  |  |  |  | 35 | % |  |
| Net income (loss) | 5,705 |  | 252 |  | (753) | (447) |  | 6,653 |  |
| Diluted EPS | $3.81 |  | $0.17 |  | ($0.50) | ($0.30) |  | $4.44 |  |
| Diluted shares | 1,498 |  | 1,498 |  | 1,498 | 1,498 |  | 1,498 |  |
| FISCAL 2015 |  |  |  |  |  |  |  |  |  |
| Revenues | $25,281 |  | $4 |  |  | $— |  |  | $— |  |  | $25,277 |  |
| Operating income (loss) | 5,776 |  | (40 | ) |  | (1,026 | ) | (1,723 | ) |  | 8,565 |  |
| EBT | 6,487 |  | (74 | ) |  | (1,026 | ) | (1,723 | ) |  | 9,310 |  |
| EBT as % of revenues | 26 | % |  |  |  |  |  |  | 37 | % |  |
| Net income (loss) | 5,271 |  | (44 | ) |  | (836 | ) | (1,490 | ) |  | 7,641 |  |
| Diluted EPS | $3.22 |  | ($0.03) |  | ($0.51) | ($0.91) |  | $4.66 |  |
| Diluted shares | 1,639 |  | 1,639 |  |  | 1,639 |  | 1,639 |  |  | 1,639 |  |

[0001234452-16-000551:8k_2_02:76]
| (a) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” herein for further details. |

[0001234452-16-000551:8k_2_02:77]
| (b) | Details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates.” Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001234452-16-000551:8k_2_02:78]
Sums may not equal totals due to rounding.

[0001234452-16-000551:8k_2_02:79]
Supplemental Information and Reconciliations

[0001234452-16-000551:8k_2_02:80]
(Unaudited)

[0001234452-16-000551:8k_2_02:81]
|  | Q4 FISCAL 2016 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results |
|  | Cost of revenues |  | $2,539 |  |  | $11 |  |  | $9 |  |  | $89 |  |  | $2,430 |  |
|  | Research and development expenses |  | 1,229 |  |  | — |  |  |  | 136 |  |  | 4 |  |  | 1,089 |  |
|  | Selling, general and administrative expenses |  | 568 |  |  | 4 |  |  | 68 |  |  | 21 |  |  | 475 |  |
|  | Other expenses |  | 44 |  |  | — |  |  |  | — |  |  |  | 44 |  |  | — |  |  |
|  | Interest expense |  | 76 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 76 |  |
|  | Investment income (loss), net |  | 232 |  |  | (13) | (b) |  | — |  |  |  | — |  |  |  | 245 | (c) |

[0001234452-16-000551:8k_2_02:82]
| (a) | Other items excluded from Non-GAAP EBT included $112 million of acquisition-related charges, $44 million of restructuring and restructuring-related charges related to our Strategic Realignment Plan and $2 million of impairment and other charges. |

[0001234452-16-000551:8k_2_02:83]
| (b) | Included $31 million in other-than-temporary losses on investments and $6 million in equity in losses of investees, partially offset by $21 million in net realized gains on investments and $3 million in other net investment income. |

[0001234452-16-000551:8k_2_02:84]
| (c) | Included $156 million in interest and dividend income and $124 million in net realized gains on investments, partially offset by $29 million in equity in losses of investees and $6 million in other net investment expense. |

[0001234452-16-000551:8k_2_02:85]
|  | FISCAL 2016 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (d) | Non-GAAP Results |
|  | Cost of revenues |  | $9,749 |  |  | $35 |  |  | $40 |  |  | $455 |  |  | $9,219 |  |
|  | Research and development expenses |  | 5,151 |  |  | 4 |  |  | 614 |  |  | 31 |  |  | 4,502 |  |
|  | Selling, general and administrative expenses |  | 2,385 |  |  | 16 |  |  | 289 |  |  | 128 |  |  | 1,952 |  |
|  | Other (income) expenses |  | (226) |  |  | (380) |  |  | — |  |  |  | 154 |  |  | — |  |  |
|  | Interest expense |  | 297 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 297 |  |
|  | Investment income, net |  | 635 |  |  | 14 | (e) |  | — |  |  |  | — |  |  |  | 621 | (f) |

[0001234452-16-000551:8k_2_02:86]
| (d) | Other items excluded from Non-GAAP EBT included $543 million of acquisition-related charges; $202 million of restructuring and restructuring-related charges, partially offset by a $48 million gain on the sale of our business that provided augmented reality applications, all of which related to our Strategic Realignment Plan; $56 million of asset impairment charges; and $15 million of other severance costs. |

[0001234452-16-000551:8k_2_02:87]
| (e) | Included $107 million in net realized gains on investments and $12 million in other net investment income, partially offset by $60 million in other-than-temporary losses on investments and $45 million in equity in losses of investees. |

[0001234452-16-000551:8k_2_02:88]
| (f) | Included $595 million in interest and dividend income and $181 million in net realized gains on investments, partially offset by $112 million in other-than-temporary losses on investments, $39 million in equity in losses of investees and $4 million in other net investment expense. |

[0001234452-16-000551:8k_2_02:89]
Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates

[0001234452-16-000551:8k_2_02:90]
(Unaudited)

[0001234452-16-000551:8k_2_02:91]
|  |  | GAAP Results |  |  | Less QSI |  | Less Share-Based Compensation |  | Less Other Items (c) (d) |  |  | Non-GAAP Results |  |
| Q4 FISCAL 2016 ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 1,960 |  |  |  | $ | (14 | ) |  |  | $ | (213 | ) |  |  | $ | (158 | ) |  |  | $ | 2,345 |  |  |
| Income tax (expense) benefit |  | (361 | ) |  |  | 5 |  |  |  | 63 |  |  |  | 11 |  |  |  | (440 | ) |  |
| Net income (loss) (a) |  | $ | 1,599 |  |  |  | $ | (9 | ) |  |  | $ | (150 | ) |  |  | $ | (147 | ) |  |  | $ | 1,905 |  |  |
| Tax rate |  | 18 | % |  |  | 0 | % | (b) |  |  |  | (1 | %) | (b) |  |  | 0 | % | (b) |  |  | 19 | % |  |
| FISCAL 2016 ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 6,833 |  |  |  | $ | 386 |  |  |  | $ | (943 | ) |  |  | $ | (768 | ) |  |  | $ | 8,158 |  |  |
| Income tax (expense) benefit |  | (1,131 | ) |  |  | (137 | ) |  |  | 190 |  |  |  | 321 |  |  |  | (1,505 | ) |  |
| Net income (loss) (a) |  | $ | 5,702 |  |  |  | $ | 249 |  |  |  | $ | (753 | ) |  |  | $ | (447 | ) |  |  | $ | 6,653 |  |  |
| Tax rate |  | 17 | % |  |  | 1 | % | (b) |  |  |  | 0 | % | (b) |  |  |  | (2 | %) | (b) |  |  |  | 18 | % |  |

[0001234452-16-000551:8k_2_02:92]
| (a) | Before adjustments for noncontrolling interests. |

[0001234452-16-000551:8k_2_02:93]
| (b) | The incremental effect of our adjustments to the Non-GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001234452-16-000551:8k_2_02:94]
| (c) | In the fourth quarter of fiscal 2016, the tax benefit in the “Other Items” column included a $22 million tax benefit for the combined tax effect of other items in EBT and a $7 million tax benefit for the tax effect of acquisition-related items in EBT, partially offset by a $18 million tax expense to reconcile the tax provision for each column to the total GAAP tax provision for the quarter. |

[0001234452-16-000551:8k_2_02:95]
| (d) | In fiscal 2016, the tax benefit in the “Other Items” column included tax benefits of $101 million for a worthless stock deduction, $79 million related to fiscal 2015 as a result of the retroactive reinstatement of the federal R&D tax credit, $71 million for the tax effect of acquisition-related items in EBT and $70 million for the combined tax effect of other items in EBT. |

[0001234452-16-000551:8k_2_02:96]
Conference Call

[0001234452-16-000551:8k_2_02:97]
Qualcomm’s fiscal fourth quarter 2016 earnings conference call will be broadcast live on November 2, 2016, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 95313544.

[0001234452-16-000551:8k_2_02:98]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-16-000551:8k_2_02:99]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-16-000551:8k_2_02:100]
The Company uses the Non-GAAP financial information:  (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial information also is used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0001234452-16-000551:8k_2_02:101]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items, tax items and other items.

[0001234452-16-000551:8k_2_02:102]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-16-000551:8k_2_02:103]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001234452-16-000551:8k_2_02:104]
| • | Certain other items are excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001234452-16-000551:8k_2_02:105]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items starting with acquisitions completed in the third quarter of fiscal 2011, as well as any tax effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes |

[0001234452-16-000551:8k_2_02:106]
expenses related to the termination of contracts that limit the use of the acquired intellectual property and third-party acquisition and integration services costs.

[0001234452-16-000551:8k_2_02:107]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and litigation settlements and/or damages. |

[0001234452-16-000551:8k_2_02:108]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. |

[0001234452-16-000551:8k_2_02:109]
About Qualcomm

[0001234452-16-000551:8k_2_02:110]
Qualcomm Incorporated (NASDAQ: QCOM) is a world leader in 3G, 4G and next-generation wireless technologies.  Qualcomm Incorporated includes Qualcomm’s licensing business, QTL, and the vast majority of its patent portfolio.  Qualcomm Technologies, Inc., a wholly-owned subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of Qualcomm’s engineering, research and development functions, and substantially all of its products and services businesses, including its semiconductor business, QCT.  For more than 30 years, Qualcomm ideas and inventions have driven the evolution of digital communications, linking people everywhere more closely to information, entertainment and each other.  For more information, visit www.qualcomm.com.

[0001234452-16-000551:8k_2_02:111]
Note Regarding Forward-Looking Statements

[0001234452-16-000551:8k_2_02:112]
###

[0001234452-16-000551:8k_2_02:113]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-16-000551:8k_2_02:114]
Qualcomm Incorporated

[0001234452-16-000551:8k_2_02:115]
CONSOLIDATED BALANCE SHEETS

[0001234452-16-000551:8k_2_02:116]
(In millions, except per share data)

[0001234452-16-000551:8k_2_02:117]
(Unaudited)

[0001234452-16-000551:8k_2_02:118]
|  | September 25, 2016 |  | September 27, 2015 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 5,946 |  |  | $ | 7,560 |  |
| Marketable securities | 12,702 |  |  | 9,761 |  |
| Accounts receivable, net | 2,219 |  |  | 1,964 |  |
| Inventories | 1,556 |  |  | 1,492 |  |
| Deferred tax assets | — |  |  | 635 |  |
| Other current assets | 558 |  |  | 687 |  |
| Total current assets | 22,981 |  |  | 22,099 |  |
| Marketable securities | 13,702 |  |  | 13,626 |  |
| Deferred tax assets | 2,030 |  |  | 1,453 |  |
| Property, plant and equipment, net | 2,306 |  |  | 2,534 |  |
| Goodwill | 5,679 |  |  | 5,479 |  |
| Other intangible assets, net | 3,500 |  |  | 3,742 |  |
| Other assets | 2,161 |  |  | 1,863 |  |
| Total assets | $ | 52,359 |  |  | $ | 50,796 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,858 |  |  | $ | 1,300 |  |
| Payroll and other benefits related liabilities | 934 |  |  | 861 |  |
| Unearned revenues | 509 |  |  | 583 |  |
| Short-term debt | 1,749 |  |  | 1,000 |  |
| Other current liabilities | 2,261 |  |  | 2,356 |  |
| Total current liabilities | 7,311 |  |  | 6,100 |  |
| Unearned revenues | 2,377 |  |  | 2,496 |  |
| Long-term debt | 10,008 |  |  | 9,969 |  |
| Other liabilities | 895 |  |  | 817 |  |
| Total liabilities | 20,591 |  |  | 19,382 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,476 and 1,524 shares issued and outstanding, respectively | 414 |  |  | — |  |
| Retained earnings | 30,936 |  |  | 31,226 |  |
| Accumulated other comprehensive income | 428 |  |  | 195 |  |
| Total Qualcomm stockholders’ equity | 31,778 |  |  | 31,421 |  |
| Noncontrolling interests | (10 | ) |  | (7 | ) |
| Total stockholders’ equity | 31,768 |  |  | 31,414 |  |
| Total liabilities and stockholders’ equity | $ | 52,359 |  |  | $ | 50,796 |  |

[0001234452-16-000551:8k_2_02:119]
Qualcomm Incorporated

[0001234452-16-000551:8k_2_02:120]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-16-000551:8k_2_02:121]
(In millions, except per share data)

[0001234452-16-000551:8k_2_02:122]
(Unaudited)

[0001234452-16-000551:8k_2_02:123]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 25, 2016 |  | September 27, 2015 |  | September 25, 2016 |  | September 27, 2015 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 4,156 |  |  | $ | 3,619 |  |  | $ | 15,467 |  |  | $ | 17,079 |  |
| Licensing | 2,028 |  |  | 1,837 |  |  | 8,087 |  |  | 8,202 |  |
| Total revenues | 6,184 |  |  | 5,456 |  |  | 23,554 |  |  | 25,281 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of revenues | 2,539 |  |  | 2,252 |  |  | 9,749 |  |  | 10,378 |  |
| Research and development | 1,229 |  |  | 1,357 |  |  | 5,151 |  |  | 5,490 |  |
| Selling, general and administrative | 568 |  |  | 595 |  |  | 2,385 |  |  | 2,344 |  |
| Other | 44 |  |  | 112 |  |  | (226 | ) |  | 1,293 |  |
| Total costs and expenses | 4,380 |  |  | 4,316 |  |  | 17,059 |  |  | 19,505 |  |
| Operating income | 1,804 |  |  | 1,140 |  |  | 6,495 |  |  | 5,776 |  |
| Interest expense | (76 | ) |  | (70 | ) |  | (297 | ) |  | (104 | ) |
| Investment income, net | 232 |  |  | 182 |  |  | 635 |  |  | 815 |  |
| Income before income taxes | 1,960 |  |  | 1,252 |  |  | 6,833 |  |  | 6,487 |  |
| Income tax expense | (361 | ) |  | (192 | ) |  | (1,131 | ) |  | (1,219 | ) |
| Net income | 1,599 |  |  | 1,060 |  |  | 5,702 |  |  | 5,268 |  |
| Net loss attributable to noncontrolling interests | — |  |  | 1 |  |  | 3 |  |  | 3 |  |
| Net income attributable to Qualcomm | $ | 1,599 |  |  | $ | 1,061 |  |  | $ | 5,705 |  |  | $ | 5,271 |  |
| Basic earnings per share attributable to Qualcomm | $ | 1.08 |  |  | $ | 0.68 |  |  | $ | 3.84 |  |  | $ | 3.26 |  |
| Diluted earnings per share attributable to Qualcomm | $ | 1.07 |  |  | $ | 0.67 |  |  | $ | 3.81 |  |  | $ | 3.22 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,476 |  |  | 1,557 |  |  | 1,484 |  |  | 1,618 |  |
| Diluted | 1,491 |  |  | 1,573 |  |  | 1,498 |  |  | 1,639 |  |
| Dividends per share announced | $ | 0.53 |  |  | $ | 0.48 |  |  | $ | 2.02 |  |  | $ | 1.80 |  |

[0001234452-16-000551:8k_2_02:124]
Qualcomm Incorporated

[0001234452-16-000551:8k_2_02:125]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-16-000551:8k_2_02:126]
(In millions)

[0001234452-16-000551:8k_2_02:127]
(Unaudited)

[0001234452-16-000551:8k_2_02:128]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 25, 2016 |  | September 27, 2015 |  | September 25, 2016 |  | September 27, 2015 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,599 |  |  | $ | 1,060 |  |  | $ | 5,702 |  |  | $ | 5,268 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 336 |  |  | 326 |  |  | 1,428 |  |  | 1,214 |  |
| Indefinite and long-lived asset impairment charges | 13 |  |  | 13 |  |  | 107 |  |  | 317 |  |
| Income tax provision in excess of (less than) income tax payments | 36 |  |  | (112 | ) |  | (200 | ) |  | 47 |  |
| Gain on sale of wireless spectrum | — |  |  | — |  |  | (380 | ) |  | — |  |
| Non-cash portion of share-based compensation expense | 213 |  |  | 233 |  |  | 943 |  |  | 1,026 |  |
| Incremental tax benefits from share-based compensation | (5 | ) |  | (5 | ) |  | (8 | ) |  | (103 | ) |
| Net realized gains on marketable securities and other investments | (145 | ) |  | (101 | ) |  | (288 | ) |  | (500 | ) |
| Impairment losses on marketable securities and other investments | 35 |  |  | 39 |  |  | 172 |  |  | 200 |  |
| Other items, net | 75 |  |  | 14 |  |  | 77 |  |  | (16 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (271 | ) |  | 112 |  |  | (232 | ) |  | 550 |  |
| Inventories | (218 | ) |  | 215 |  |  | (49 | ) |  | 93 |  |
| Other assets | 93 |  |  | 104 |  |  | 246 |  |  | (793 | ) |
| Trade accounts payable | 278 |  |  | (139 | ) |  | 541 |  |  | (908 | ) |
| Payroll, benefits and other liabilities | 82 |  |  | 78 |  |  | (352 | ) |  | (328 | ) |
| Unearned revenues | (37 | ) |  | (153 | ) |  | (307 | ) |  | (561 | ) |
| Net cash provided by operating activities | 2,084 |  |  | 1,684 |  |  | 7,400 |  |  | 5,506 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (150 | ) |  | (179 | ) |  | (539 | ) |  | (994 | ) |
| Purchases of available-for-sale securities | (5,055 | ) |  | (2,282 | ) |  | (18,015 | ) |  | (15,400 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 4,083 |  |  | 3,183 |  |  | 14,386 |  |  | 15,080 |  |
| Purchases of trading securities | — |  |  | (126 | ) |  | (177 | ) |  | (1,160 | ) |
| Proceeds from sales and maturities of trading securities | — |  |  | 650 |  |  | 779 |  |  | 1,658 |  |
| Proceeds from sales of other marketable securities | — |  |  | — |  |  | 450 |  |  | — |  |
| Acquisitions and other investments, net of cash acquired | (149 | ) |  | (2,694 | ) |  | (812 | ) |  | (3,019 | ) |
| Proceeds from sale of wireless spectrum | — |  |  | — |  |  | 232 |  |  | — |  |
| Proceeds from sales of property, plant and equipment | 1 |  |  | 105 |  |  | 16 |  |  | 266 |  |
| Other items, net | 11 |  |  | (9 | ) |  | 192 |  |  | (3 | ) |
| Net cash used by investing activities | (1,259 | ) |  | (1,352 | ) |  | (3,488 | ) |  | (3,572 | ) |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 2,316 |  |  | 1,270 |  |  | 8,949 |  |  | 4,083 |  |
| Repayment of short-term debt | (2,315 | ) |  | (1,269 | ) |  | (8,200 | ) |  | (3,083 | ) |
| Proceeds from long-term debt | — |  |  | — |  |  | — |  |  | 9,937 |  |
| Proceeds from issuance of common stock | 246 |  |  | 216 |  |  | 668 |  |  | 787 |  |
| Repurchases and retirements of common stock | (225 | ) |  | (2,230 | ) |  | (3,923 | ) |  | (11,246 | ) |
| Dividends paid | (782 | ) |  | (738 | ) |  | (2,990 | ) |  | (2,880 | ) |
| Incremental tax benefits from share-based compensation | 5 |  |  | 5 |  |  | 8 |  |  | 103 |  |
| Other items, net | (2 | ) |  | (3 | ) |  | (34 | ) |  | 38 |  |
| Net cash used by financing activities | (757 | ) |  | (2,749 | ) |  | (5,522 | ) |  | (2,261 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (7 | ) |  | (10 | ) |  | (4 | ) |  | (20 | ) |
| Net increase (decrease) in cash and cash equivalents | 61 |  |  | (2,427 | ) |  | (1,614 | ) |  | (347 | ) |
| Cash and cash equivalents at beginning of period | 5,885 |  |  | 9,987 |  |  | 7,560 |  |  | 7,907 |  |
| Cash and cash equivalents at end of period | $ | 5,946 |  |  | $ | 7,560 |  |  | $ | 5,946 |  |  | $ | 7,560 |  |
