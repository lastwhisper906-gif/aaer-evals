# QCOM notes — 0000804328-25-000031


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000804328-25-000031:notes:1]
[same as prior period, unchanged from 0000804328-25-000011:notes:1]

[0000804328-25-000031:notes:2]
[same as prior period, unchanged from 0000804328-25-000011:notes:2]

[0000804328-25-000031:notes:3]
We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 30, 2025 and March 24, 2024 included 13 weeks and 26 weeks, respectively. Our fiscal year for 2025 will include 52 weeks.

[0000804328-25-000031:notes:4]
[same as prior period, unchanged from 0000804328-25-000011:notes:4]

[0000804328-25-000031:notes:5]
[same as prior period, unchanged from 0000804328-25-000011:notes:5]

[0000804328-25-000031:notes:6]
[same as prior period, unchanged from 0000804328-25-000011:notes:6]

[0000804328-25-000031:notes:7]
[same as prior period, unchanged from 0000804328-25-000011:notes:7]

[0000804328-25-000031:notes:8]
[same as prior period, unchanged from 0000804328-25-000011:notes:8]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-25-000031:notes:9]
[same as prior period, unchanged from 0000804328-25-000011:notes:9]

[0000804328-25-000031:notes:10]
| Inventories (in millions) |  |  |  |
|  | March 30,2025 |  | September 29,2024 |
| Raw materials | $ | 298 |  |  | $ | 340 |  |
| Work-in-process | 3,750 |  |  | 3,497 |  |
| Finished goods | 2,148 |  |  | 2,586 |  |
|  | $ | 6,196 |  |  | $ | 6,423 |  |

[0000804328-25-000031:notes:11]
We have multi-year capacity purchase commitments with certain suppliers of our integrated circuit products. Total advance payments related to multi-year capacity purchase commitments recorded on our condensed consolidated balance sheets at March 30, 2025 and September 29, 2024 were $2.7 billion and $3.0 billion, respectively, of which $1.6 billion and $765 million were recorded in other current assets, respectively, and $1.1 billion and $2.2 billion were recorded in other assets, respectively.

[0000804328-25-000031:notes:12]
[same as prior period, unchanged from 0000804328-25-000011:notes:11]

[0000804328-25-000031:notes:13]
[same as prior period, unchanged from 0000804328-25-000011:notes:12]

[0000804328-25-000031:notes:14]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  | March 30,2025 |  | March 24,2024 |  | March 30,2025 |  | March 24,2024 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,929 |  |  | $ | 6,180 |  |  | $ | 14,503 |  |  | $ | 12,867 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 959 |  |  | 603 |  |  | 1,920 |  |  | 1,201 |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,581 |  |  | 1,243 |  |  | 3,130 |  |  | 2,381 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 9,469 |  |  | $ | 8,026 |  |  | $ | 19,553 |  |  | $ | 16,449 |  |

[0000804328-25-000031:notes:15]
[same as prior period, unchanged from 0000804328-25-000011:notes:14]

[0000804328-25-000031:notes:16]
[same as prior period, unchanged from 0000804328-25-000011:notes:15]

[0000804328-25-000031:notes:17]
[same as prior period, unchanged from 0000804328-25-000011:notes:16]

[0000804328-25-000031:notes:18]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods generally include certain sales-based royalty revenues related to system software, certain amounts related to customer incentives and licensing revenues recognized related to devices sold in prior periods (including revenues resulting from certain settlements and adjustments to prior period royalty estimates, which include the impact of the reporting by our licensees of actual royalties due) and were as follows (in millions):

[0000804328-25-000031:notes:19]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | March 30,2025 |  | March 24,2024 |
| Revenues recognized from previously satisfied performance obligations | $ | 285 |  |  | $ | 55 |  |  | $ | 526 |  |  | $ | 206 |  |

[0000804328-25-000031:notes:20]
Remaining performance obligations, which are primarily included in unearned revenues (as presented on our condensed consolidated balance sheets), represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our patent license agreements with key OEMs are generally long-term, with remaining terms expiring between fiscal 2027 and 2031.

[0000804328-25-000031:notes:21]
Concentrations. A significant portion of our revenues are concentrated with a small number of customers/licensees of our QCT and QTL segments. The comparability of customer/licensee concentrations for the periods presented are impacted by the timing of customer/licensee device launches and/or innovation cycles and other seasonal trends, among other fluctuations in demand. Revenues from each customer/licensee that were 10% or greater of total revenues were as follows:

[0000804328-25-000031:notes:22]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | March 30,2025 |  | March 24,2024 |
| Customer/licensee (x) | 27 | % |  | 24 | % |  | 21 | % |  | 21 | % |
| Customer/licensee (y) | 18 |  |  | 19 |  |  | 21 |  |  | 22 |  |
| Customer/licensee (z) | 10 |  |  | 14 |  |  | 12 |  |  | 14 |  |

[0000804328-25-000031:notes:23]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | March 30,2025 |  | March 24,2024 |
| Interest and dividend income | $ | 167 |  |  | $ | 160 |  |  | $ | 336 |  |  | $ | 312 |  |
| Net gains (losses) on marketable securities | 18 |  |  | (3) |  |  | 37 |  |  | 8 |  |
| Net (losses) gains on other investments | (5) |  |  | 155 |  |  | 26 |  |  | 159 |  |
| Net (losses) gains on deferred compensation plan assets | (34) |  |  | 62 |  |  | (20) |  |  | 126 |  |
| Impairment losses on other investments | (16) |  |  | (50) |  |  | (41) |  |  | (62) |  |
| Other | 18 |  |  | 6 |  |  | 53 |  |  | (1) |  |
|  | $ | 148 |  |  | $ | 330 |  |  | $ | 391 |  |  | $ | 542 |  |

[0000804328-25-000031:notes:24]
[same as prior period, unchanged from 0000804328-25-000011:notes:23]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-25-000031:notes:25]
Note 3. Income Taxes
We estimate our annual effective income tax rate to be 11% for fiscal 2025, which is lower than the U.S. federal statutory rate, primarily due to a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, which includes certain additional benefits from the requirement to capitalize research and development expenditures for federal income tax purposes (that are expected to continue to decline over time as capitalized research and development expenditures continue to amortize) and a benefit from our federal research and development tax credit. Our effective tax rate of 9% for the second quarter of fiscal 2025 was lower than our estimated annual effective tax rate, primarily due to net discrete tax benefits realized in the second quarter of fiscal 2025.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-25-000031:notes:26]
[same as prior period, unchanged from 0000804328-25-000011:notes:26]

[0000804328-25-000031:notes:27]
Stock Repurchase Program. During the first quarter of fiscal 2025, we utilized the remaining repurchase authority under the $10.0 billion stock repurchase program announced on October 12, 2021 and we began repurchases under the $15.0 billion stock repurchase program announced on November 6, 2024, which has no expiration date. At March 30, 2025, $12.5 billion remained authorized for repurchase under our stock repurchase program.

[0000804328-25-000031:notes:28]
Shares Outstanding. Shares of common stock outstanding at March 30, 2025 were as follows (in millions):

[0000804328-25-000031:notes:29]
| Balance at September 29, 2024 | 1,113 |  |
| Issued | 9 |  |
| Repurchased | (22) |  |
| Balance at March 30, 2025 | 1,100 |  |

[0000804328-25-000031:notes:30]
Dividends. On March 18, 2025, we announced an increase in our quarterly dividend per share of common stock from $0.85 to $0.89, which is effective for dividends payable after March 27, 2025. On April 18, 2025, we announced a cash dividend of $0.89 per share on our common stock, payable on June 26, 2025 to stockholders of record as of the close of business on June 5, 2025.

[0000804328-25-000031:notes:31]
[same as prior period, unchanged from 0000804328-25-000011:notes:31]

[0000804328-25-000031:notes:32]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | March 30,2025 |  | March 24,2024 |
| Dilutive common share equivalents included in diluted shares | 10 |  |  | 13 |  |  | 11 |  |  | 12 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 1 |  |  | — |  |  | 1 |  |  | 7 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-25-000031:notes:33]
Note 5. Commitments and Contingencies

[0000804328-25-000031:notes:34]
Legal and Regulatory Proceedings.

[0000804328-25-000031:notes:35]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. The cases filed in the Southern District of California were subsequently transferred to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On September 27, 2018, the court certified the class. We appealed the court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class, and remanded the case to the district court. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. We filed a motion to dismiss the amended complaint, and on January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. We subsequently filed a motion for summary judgment on the plaintiffs’ remaining claims. The court granted our motion in its entirety and, on October 5, 2023, entered final judgment in Qualcomm’s favor. The plaintiffs appealed the decision to the Ninth Circuit. On February 25, 2025, the Ninth Circuit issued a ruling dismissing all but one of the plaintiffs’ claims with prejudice and dismissing the remaining claim without prejudice.

[0000804328-25-000031:notes:36]
Beginning in November 2017, several other consumer class action complaints were filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws and seeking damages. The claims in these complaints are similar to those in the U.S. consumer class action complaints described above. These matters are at various stages of litigation, and we intend to continue to vigorously defend ourselves.

[0000804328-25-000031:notes:37]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the district court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit (Federal Circuit). On September 6, 2024, the Federal Circuit reversed the judgment of the district court, citing certain substantive and procedural issues, and remanded the case to the district court for further proceedings. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-25-000031:notes:38]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (Arm) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with Arm (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. Arm is seeking specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology (which Arm alleges includes our custom Qualcomm Oryon CPU cores). Arm’s complaint also contended that we violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of Arm’s trademarks and sought associated injunctive and declaratory relief; however, Arm dismissed these claims prior to trial. On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm, and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia) and System-on-Chip (SoC) products incorporating such cores are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm (the Qualcomm TLA). A trial was held beginning on December 16, 2024, and on December 20, 2024, the jury found that (i) Qualcomm did not breach the Nuvia ALA and (ii) Qualcomm CPUs that include designs acquired in the Nuvia acquisition are licensed under the Qualcomm ALA. The jury was unable to reach a verdict with respect to Arm’s claim as to whether Nuvia breached the Nuvia ALA. The parties have filed various post-trial motions in this matter, including motions for judgment as a matter of law. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.

[0000804328-25-000031:notes:39]
On April 18, 2024, we filed a separate complaint (captioned QUALCOMM Incorporated v. Arm Ltd.) against Arm in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief. Arm moved to dismiss this complaint, and on October 30, 2024, the court denied Arm’s motion to dismiss. On December 16, 2024, we filed a First Amended Complaint, alleging additional causes of action based on Arm improperly seeking to terminate the Qualcomm ALA and improperly publicizing that it was seeking to terminate the Qualcomm ALA. Arm has moved to dismiss the First Amended Complaint. On March 27, 2025, we moved to file a Second Amended Complaint to add a claim that Arm has breached the Qualcomm TLA by failing to provide license offers at commercially reasonable prices and terms. Trial is scheduled to begin on March 9, 2026.

[0000804328-25-000031:notes:40]
On October 22, 2024, Arm provided us with a notice alleging that we have breached the Qualcomm ALA by marketing products that contain CPUs that Arm alleges use designs, technology and code created by Nuvia employees prior to our acquisition of Nuvia; by seeking support and verification from Arm for additional products that use such alleged designs, technology and code; and by suing Arm for breach of the Qualcomm ALA. Arm’s notice asserts that it will have the right to terminate the Qualcomm ALA if such alleged breaches are not cured within 60 days of such notice. We disagree with Arm’s allegations, including that we are, or have been, in breach of the Qualcomm ALA. On January 8, 2025, Arm notified us that it was withdrawing its October 22, 2024 notice of breach and indicated that it has no current plan to terminate the Qualcomm ALA, while reserving its rights pending the outcome of the ongoing litigation.

[0000804328-25-000031:notes:41]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at March 30, 2025 for contingent losses associated with the pending matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (for example, our 2010 European Commission matter relating to the Icera complaint, and other matters arising in the ordinary course of our business, including those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-25-000031:notes:42]
[same as prior period, unchanged from 0000804328-25-000011:notes:42]

[0000804328-25-000031:notes:43]
[same as prior period, unchanged from 0000804328-25-000011:notes:43]

[0000804328-25-000031:notes:44]
[same as prior period, unchanged from 0000804328-25-000011:notes:44]

[0000804328-25-000031:notes:45]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | March 30,2025 |  | March 24,2024 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 9,469 |  |  | $ | 8,026 |  |  | $ | 19,553 |  |  | $ | 16,449 |  |
| QTL | 1,319 |  |  | 1,318 |  |  | 2,854 |  |  | 2,778 |  |
| QSI | — |  |  | 3 |  |  | — |  |  | 16 |  |
| Reconciling items | 191 |  |  | 42 |  |  | 242 |  |  | 82 |  |
| Total | $ | 10,979 |  |  | $ | 9,389 |  |  | $ | 22,649 |  |  | $ | 19,325 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 2,857 |  |  | $ | 2,288 |  |  | $ | 6,103 |  |  | $ | 4,881 |  |
| QTL | 929 |  |  | 933 |  |  | 2,086 |  |  | 2,013 |  |
| QSI | 10 |  |  | 96 |  |  | 29 |  |  | 107 |  |
| Reconciling items | (691) |  |  | (819) |  |  | (1,478) |  |  | (1,541) |  |
| Total | $ | 3,105 |  |  | $ | 2,498 |  |  | $ | 6,740 |  |  | $ | 5,460 |  |

[0000804328-25-000031:notes:46]
[same as prior period, unchanged from 0000804328-25-000011:notes:46]

[0000804328-25-000031:notes:47]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | March 30,2025 |  | March 24,2024 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 48 |  |  | $ | 42 |  |  | $ | 99 |  |  | $ | 82 |  |
| Unallocated revenues | 143 |  |  | — |  |  | 143 |  |  | — |  |
|  | $ | 191 |  |  | $ | 42 |  |  | $ | 242 |  |  | $ | 82 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated revenues | $ | 143 |  |  | $ | — |  |  | $ | 143 |  |  | $ | — |  |
| Unallocated cost of revenues | (60) |  |  | (57) |  |  | (119) |  |  | (113) |  |
| Unallocated research and development expenses | (558) |  |  | (584) |  |  | (1,156) |  |  | (1,116) |  |
| Unallocated selling, general and administrative expenses | (184) |  |  | (229) |  |  | (372) |  |  | (414) |  |
| Unallocated other income | — |  |  | — |  |  | — |  |  | 28 |  |
| Unallocated interest expense | (163) |  |  | (172) |  |  | (326) |  |  | (350) |  |
| Unallocated investment and other income, net | 138 |  |  | 228 |  |  | 358 |  |  | 434 |  |
| Nonreportable segments | (7) |  |  | (5) |  |  | (6) |  |  | (10) |  |
|  | $ | (691) |  |  | $ | (819) |  |  | $ | (1,478) |  |  | $ | (1,541) |  |

[0000804328-25-000031:notes:48]
Certain revenues were not allocated to our segments in our management reports because they were not considered in evaluating segment results. Unallocated revenues in the second quarter and first six months of fiscal 2025 were comprised of licensing revenues resulting from a recent settlement of a licensing dispute.


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-25-000031:notes:49]
[same as prior period, unchanged from 0000804328-25-000011:notes:48]

[0000804328-25-000031:notes:50]
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at March 30, 2025 (in millions):

[0000804328-25-000031:notes:51]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 2,720 |  |  | $ | 241 |  |  | $ | — |  |  | $ | 2,961 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 5,048 |  |  | — |  |  | 5,048 |  |
| Mortgage- and asset-backed securities | — |  |  | 1,037 |  |  | — |  |  | 1,037 |  |
| U.S. Treasury securities and government-related securities | 303 |  |  | 183 |  |  | — |  |  | 486 |  |
| Equity securities | 72 |  |  | — |  |  | — |  |  | 72 |  |
| Total marketable securities | 375 |  |  | 6,268 |  |  | — |  |  | 6,643 |  |
| Derivative instruments | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Other investments (1) | 963 |  |  | — |  |  | 56 |  |  | 1,019 |  |
| Total assets measured at fair value | $ | 4,058 |  |  | $ | 6,532 |  |  | $ | 56 |  |  | $ | 10,646 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 176 |  |  | $ | — |  |  | $ | 176 |  |
| Other liabilities (1) | 959 |  |  | — |  |  | — |  |  | 959 |  |
| Total liabilities measured at fair value | $ | 959 |  |  | $ | 176 |  |  | $ | — |  |  | $ | 1,135 |  |

[0000804328-25-000031:notes:52]
[same as prior period, unchanged from 0000804328-25-000011:notes:51]

[0000804328-25-000031:notes:53]
Long-term Debt. At March 30, 2025, the aggregate fair value of our outstanding fixed-rate notes, based on Level 2 inputs, was approximately $13.8 billion.

[0000804328-25-000031:notes:54]
Marketable Securities. At March 30, 2025 and September 29, 2024, our marketable securities were all classified as current and were primarily comprised of available-for-sale debt securities (the vast majority of which were corporate bonds and notes).

[0000804328-25-000031:notes:55]
[same as prior period, unchanged from 0000804328-25-000011:notes:54]

[0000804328-25-000031:notes:56]
|  | March 30,2025 |
| Years to Maturity |  |
| Less than one year | $ | 1,451 |  |
| One to five years | 4,083 |  |
| No single maturity date | 1,037 |  |
| Total | $ | 6,571 |  |

[0000804328-25-000031:notes:57]
[same as prior period, unchanged from 0000804328-25-000011:notes:56]
