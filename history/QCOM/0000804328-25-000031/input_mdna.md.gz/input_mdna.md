# QCOM MD&A — 0000804328-25-000031


## mdna

[0000804328-25-000031:mdna:1]
[same as prior period, unchanged from 0000804328-25-000011:mdna:1]

[0000804328-25-000031:mdna:2]
[same as prior period, unchanged from 0000804328-25-000011:mdna:2]

[0000804328-25-000031:mdna:3]
This Quarterly Report (including but not limited to this section titled Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates,” “may,” “will,” “would” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report. Additionally, statements concerning future matters such as our future business, prospects, results of operations or financial condition; research and development or technology investments; new or enhanced products, services or technologies; emerging industries or business models; design wins or product launches; industry, market or technology trends, dynamics or transitions; our expectations regarding future demand or supply conditions; strategic investments or acquisitions, and the anticipated timing or benefits thereof; legal or regulatory matters, including the expected impacts of pending tax or other regulatory changes; U.S./China trade or national security tensions; vertical integration by our customers; competition; annual effective tax rates; and other statements regarding matters that are not historical are also forward-looking statements.

[0000804328-25-000031:mdna:4]
Second Quarter Fiscal 2025 Overview

[0000804328-25-000031:mdna:5]
Revenues for the second quarter of fiscal 2025 were $11.0 billion, an increase of 17% compared to the year ago quarter, with net income of $2.8 billion, an increase of 21% compared to the year ago quarter. Key items from the second quarter of fiscal 2025 included:

[0000804328-25-000031:mdna:6]
•QCT revenues increased by 18% in the second quarter of fiscal 2025 compared to the year ago quarter, due to higher handsets, automotive and IoT revenues.

[0000804328-25-000031:mdna:7]
•QTL revenues remained approximately flat in the second quarter of fiscal 2025 compared to the year ago quarter.

[0000804328-25-000031:mdna:8]
[same as prior period, unchanged from 0000804328-25-000011:mdna:8]

[0000804328-25-000031:mdna:9]
[same as prior period, unchanged from 0000804328-25-000011:mdna:9]

[0000804328-25-000031:mdna:10]
[same as prior period, unchanged from 0000804328-25-000011:mdna:10]

[0000804328-25-000031:mdna:11]
[same as prior period, unchanged from 0000804328-25-000011:mdna:11]

[0000804328-25-000031:mdna:12]
17

[0000804328-25-000031:mdna:13]
[same as prior period, unchanged from 0000804328-25-000011:mdna:12]

[0000804328-25-000031:mdna:14]
[same as prior period, unchanged from 0000804328-25-000011:mdna:13]

[0000804328-25-000031:mdna:15]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | Change |  | March 30,2025 |  | March 24,2024 |  | Change |
| Equipment and services | $ | 9,359 |  |  | $ | 7,950 |  |  | $ | 1,409 |  |  | $ | 19,301 |  |  | $ | 16,266 |  |  | $ | 3,035 |  |
| Licensing | 1,620 |  |  | 1,439 |  |  | 181 |  |  | 3,348 |  |  | 3,059 |  |  | 289 |  |
|  | $ | 10,979 |  |  | $ | 9,389 |  |  | $ | 1,590 |  |  | $ | 22,649 |  |  | $ | 19,325 |  |  | $ | 3,324 |  |

[0000804328-25-000031:mdna:16]
Second quarter 2025 vs. 2024

[0000804328-25-000031:mdna:17]
The increase in revenues in the second quarter of fiscal 2025 was primarily due to:

[0000804328-25-000031:mdna:18]
+    $1.4 billion in higher equipment and services revenues from our QCT segment

[0000804328-25-000031:mdna:19]
+    $143 million in licensing revenues resulting from a recent settlement of a licensing dispute, which was not allocated to our segment results

[0000804328-25-000031:mdna:20]
First six months 2025 vs. 2024

[0000804328-25-000031:mdna:21]
The increase in revenues in the first six months of fiscal 2025 was primarily due to:

[0000804328-25-000031:mdna:22]
+    $3.0 billion in higher equipment and services revenues from our QCT segment

[0000804328-25-000031:mdna:23]
+    $143 million in licensing revenues resulting from a recent settlement of a licensing dispute, which was not allocated to our segment results

[0000804328-25-000031:mdna:24]
+    $76 million in higher licensing revenues from our QTL segment

[0000804328-25-000031:mdna:25]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | Change |  | March 30,2025 |  | March 24,2024 |  | Change |
| Cost of revenues | $ | 4,937 |  |  | $ | 4,106 |  |  | $ | 831 |  |  | $ | 10,098 |  |  | $ | 8,418 |  |  | $ | 1,680 |  |
| Gross margin | 55 | % |  | 56 | % |  |  |  | 55 | % |  | 56 | % |  |  |

[0000804328-25-000031:mdna:26]
Second quarter 2025 vs. 2024

[0000804328-25-000031:mdna:27]
Gross margin percentage decreased in the second quarter of fiscal 2025 primarily due to a decrease in QCT gross margin.

[0000804328-25-000031:mdna:28]
First six months 2025 vs. 2024

[0000804328-25-000031:mdna:29]
Gross margin percentage decreased in the first six months of fiscal 2025 primarily due to a decrease in the proportion of total revenues related to QTL licensing revenues (which have a higher margin contribution).

[0000804328-25-000031:mdna:30]
18

[0000804328-25-000031:mdna:31]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | Change |  | March 30,2025 |  | March 24,2024 |  | Change |
| Research and development | $ | 2,216 |  |  | $ | 2,236 |  |  | $ | (20) |  |  | $ | 4,446 |  |  | $ | 4,332 |  |  | $ | 114 |  |
| % of revenues | 20 | % |  | 24 | % |  |  |  | 20 | % |  | 22 | % |  |  |

[0000804328-25-000031:mdna:32]
Second quarter 2025 vs. 2024

[0000804328-25-000031:mdna:33]
The decrease in research and development expenses in the second quarter of fiscal 2025 was primarily due to:

[0000804328-25-000031:mdna:34]
-    $57 million decrease in expenses driven by the revaluation of our deferred compensation obligation (which resulted in a corresponding decrease in net gains on deferred compensation plan assets within investment and other income, net due to the revaluation of the related assets)

[0000804328-25-000031:mdna:35]
+    $20 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including investments in key growth and diversification opportunities), which included higher employee-related costs, offset by higher non-recurring engineering cost reimbursements

[0000804328-25-000031:mdna:36]
First six months 2025 vs. 2024

[0000804328-25-000031:mdna:37]
The increase in research and development expenses in the first six months of fiscal 2025 was primarily due to:

[0000804328-25-000031:mdna:38]
+    $120 million increase in share-based compensation expense

[0000804328-25-000031:mdna:39]
+    $81 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including investments in key growth and diversification opportunities), primarily driven by an increase in employee-related costs, partially offset by higher non-recurring engineering cost reimbursements

[0000804328-25-000031:mdna:40]
-    $88 million decrease in expenses driven by the revaluation of our deferred compensation obligation

[0000804328-25-000031:mdna:41]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | Change |  | March 30,2025 |  | March 24,2024 |  | Change |
| Selling, general and administrative | $ | 706 |  |  | $ | 707 |  |  | $ | (1) |  |  | $ | 1,430 |  |  | $ | 1,335 |  |  | $ | 95 |  |
| % of revenues | 6 | % |  | 8 | % |  |  |  | 6 | % |  | 7 | % |  |  |

[0000804328-25-000031:mdna:42]
Second quarter 2025 vs. 2024

[0000804328-25-000031:mdna:43]
Selling, general and administrative expenses remained approximately flat in the second quarter of fiscal 2025 primarily due to:

[0000804328-25-000031:mdna:44]
-    $37 million decrease in expenses driven by the revaluation of our deferred compensation obligation

[0000804328-25-000031:mdna:45]
+    $48 million increase in sales and marketing expenses

[0000804328-25-000031:mdna:46]
First six months 2025 vs. 2024

[0000804328-25-000031:mdna:47]
The increase in selling, general and administrative expenses in the first six months of fiscal 2025 was primarily due to:

[0000804328-25-000031:mdna:48]
+    $94 million increase in sales and marketing expenses

[0000804328-25-000031:mdna:49]
+    $29 million increase in share-based compensation expense

[0000804328-25-000031:mdna:50]
+    $29 million increase in employee-related expenses

[0000804328-25-000031:mdna:51]
-    $56 million decrease in expenses driven by the revaluation of our deferred compensation obligation

[0000804328-25-000031:mdna:52]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | Change |  | March 30,2025 |  | March 24,2024 |  | Change |
| Interest expense | $ | 163 |  |  | $ | 172 |  |  | $ | (9) |  |  | $ | 326 |  |  | $ | 350 |  |  | $ | (24) |  |
| Investment and other income, net |
| Interest and dividend income | $ | 167 |  |  | $ | 160 |  |  | $ | 7 |  |  | $ | 336 |  |  | $ | 312 |  |  | $ | 24 |  |
| Net gains (losses) on marketable securities | 18 |  |  | (3) |  |  | 21 |  |  | 37 |  |  | 8 |  |  | 29 |  |
| Net (losses) gains on other investments | (5) |  |  | 155 |  |  | (160) |  |  | 26 |  |  | 159 |  |  | (133) |  |
| Net (losses) gains on deferred compensation plan assets | (34) |  |  | 62 |  |  | (96) |  |  | (20) |  |  | 126 |  |  | (146) |  |
| Impairment losses on other investments | (16) |  |  | (50) |  |  | 34 |  |  | (41) |  |  | (62) |  |  | 21 |  |
| Other | 18 |  |  | 6 |  |  | 12 |  |  | 53 |  |  | (1) |  |  | 54 |  |
|  | $ | 148 |  |  | $ | 330 |  |  | $ | (182) |  |  | $ | 391 |  |  | $ | 542 |  |  | $ | (151) |  |

[0000804328-25-000031:mdna:53]
Net gains on other investments in the second quarter and first six months of fiscal 2024 was primarily driven by certain of our QSI non-marketable equity investments.

[0000804328-25-000031:mdna:54]
[same as prior period, unchanged from 0000804328-25-000011:mdna:35]

[0000804328-25-000031:mdna:55]
[same as prior period, unchanged from 0000804328-25-000011:mdna:36]

[0000804328-25-000031:mdna:56]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | March 30,2025 |  | March 24,2024 |
| Expected income tax provision at federal statutory tax rate | $ | 652 |  |  | $ | 525 |  |  | $ | 1,415 |  |  | $ | 1,147 |  |
| Benefit from foreign-derived intangible income (FDII) deduction, excluding the impact of capitalizing research and development expenditures | (190) |  |  | (145) |  |  | (397) |  |  | (309) |  |
| Benefit from FDII deduction related to capitalizing research and development expenditures | (110) |  |  | (133) |  |  | (263) |  |  | (323) |  |
| Foreign currency (gain) loss related to foreign withholding tax receivable | (1) |  |  | 41 |  |  | 165 |  |  | 2 |  |
| Benefit related to the federal research and development tax credit | (45) |  |  | (59) |  |  | (119) |  |  | (135) |  |
| Excess tax benefit associated with share-based awards | (39) |  |  | (23) |  |  | (77) |  |  | (51) |  |
| Other | 26 |  |  | 17 |  |  | 24 |  |  | 42 |  |
| Income tax expense | $ | 293 |  |  | $ | 223 |  |  | $ | 748 |  |  | $ | 373 |  |
| Effective tax rate | 9 | % |  | 9 | % |  | 11 | % |  | 7 | % |

[0000804328-25-000031:mdna:57]
[same as prior period, unchanged from 0000804328-25-000011:mdna:38]

[0000804328-25-000031:mdna:58]
[same as prior period, unchanged from 0000804328-25-000011:mdna:39]

[0000804328-25-000031:mdna:59]
[same as prior period, unchanged from 0000804328-25-000011:mdna:80]

[0000804328-25-000031:mdna:60]
| Discontinued Operations (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | Change |  | March 30,2025 |  | March 24,2024 |  | Change |
| Discontinued operations, net of income taxes | $ | — |  |  | $ | 51 |  |  | $ | (51) |  |  | $ | — |  |  | $ | 6 |  |  | $ | (6) |  |

[0000804328-25-000031:mdna:61]
Discontinued operations in the second quarter and first six months of fiscal 2024 are related to the Non-Arriver businesses. Information regarding the Non-Arriver businesses is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Discontinued Operations.”

[0000804328-25-000031:mdna:62]
[same as prior period, unchanged from 0000804328-25-000011:mdna:42]

[0000804328-25-000031:mdna:63]
The following should be read in conjunction with our financial results for the second quarter of fiscal 2025 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0000804328-25-000031:mdna:64]
[same as prior period, unchanged from 0000804328-25-000011:mdna:44]

[0000804328-25-000031:mdna:65]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | Change |  | March 30,2025 |  | March 24,2024 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets | $ | 6,929 |  |  | $ | 6,180 |  |  | $ | 749 |  | $ | 14,503 |  |  | $ | 12,867 |  |  | $ | 1,636 |
| Automotive | 959 |  |  | 603 |  |  | 356 |  | 1,920 |  |  | 1,201 |  |  | 719 |
| IoT (internet of things) | 1,581 |  |  | 1,243 |  |  | 338 |  | 3,130 |  |  | 2,381 |  |  | 749 |
| Total revenues (1) | $ | 9,469 |  |  | $ | 8,026 |  |  | $ | 1,443 |  | $ | 19,553 |  |  | $ | 16,449 |  |  | $ | 3,104 |
| EBT (2) | $ | 2,857 |  |  | $ | 2,288 |  |  | $ | 569 |  | $ | 6,103 |  |  | $ | 4,881 |  |  | $ | 1,222 |
| EBT as a % of revenues | 30 | % |  | 29 | % |  | 1 point |  | 31 | % |  | 30 | % |  | 1 point |

[0000804328-25-000031:mdna:66]
[same as prior period, unchanged from 0000804328-25-000011:mdna:46]

[0000804328-25-000031:mdna:67]
[same as prior period, unchanged from 0000804328-25-000011:mdna:47]

[0000804328-25-000031:mdna:68]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $9.3 billion and $7.9 billion in the second quarter of fiscal 2025 and 2024, respectively, and $19.2 billion and $16.2 billion in the first six months of fiscal 2025 and 2024, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets as well as sales of 4G, 5G sub 6 and 5G millimeter wave RFFE products.

[0000804328-25-000031:mdna:69]
Second quarter 2025 vs. 2024

[0000804328-25-000031:mdna:70]
The increase in QCT revenues in the second quarter of fiscal 2025 was primarily due to:

[0000804328-25-000031:mdna:71]
+    higher handsets revenues, primarily due to $381 million in higher chipset shipments driven by certain major OEMs, and $368 million in higher revenues per chipset (primarily driven by higher average selling prices), both of which benefited from an increase in demand in premium-tier Snapdragon platforms

[0000804328-25-000031:mdna:72]
[same as prior period, unchanged from 0000804328-25-000011:mdna:53]

[0000804328-25-000031:mdna:73]
+    higher IoT revenues, primarily due to $410 million in higher shipments primarily across edge networking and industrial products

[0000804328-25-000031:mdna:74]
QCT EBT as a percentage of revenues increased in the second quarter of fiscal 2025 primarily due to:

[0000804328-25-000031:mdna:75]
[same as prior period, unchanged from 0000804328-25-000011:mdna:55]

[0000804328-25-000031:mdna:76]
-    lower gross margin percentage, primarily driven by increased product costs, partially offset by increases in average selling prices

[0000804328-25-000031:mdna:77]
First six months 2025 vs. 2024

[0000804328-25-000031:mdna:78]
The increase in QCT revenues in the first six months of fiscal 2025 was primarily due to:

[0000804328-25-000031:mdna:79]
+    higher handsets revenues, primarily due to $854 million in higher revenues per chipset (primarily driven by higher average selling prices), and $783 million in higher chipset shipments driven by certain major OEMs, both of which benefited from an increase in demand in premium-tier Snapdragon platforms

[0000804328-25-000031:mdna:80]
[same as prior period, unchanged from 0000804328-25-000011:mdna:92]

[0000804328-25-000031:mdna:81]
+    higher IoT revenues, due to $924 million in higher shipments across consumer, edge networking and industrial products, partially offset by unfavorable product mix

[0000804328-25-000031:mdna:82]
+    higher automotive revenues, primarily driven by an increase in shipments from new vehicle launches with our Snapdragon digital cockpit products

[0000804328-25-000031:mdna:83]
QCT EBT as a percentage of revenues increased in the first six months of fiscal 2025 primarily due to:

[0000804328-25-000031:mdna:84]
+    higher revenues

[0000804328-25-000031:mdna:85]
-    higher operating expenses, primarily driven by higher selling, general and administrative expenses

[0000804328-25-000031:mdna:86]
Gross margin percentage remained approximately flat in the first six months of fiscal 2025, primarily driven by higher product costs, partially offset by higher average selling prices.

[0000804328-25-000031:mdna:87]
[same as prior period, unchanged from 0000804328-25-000011:mdna:59]

[0000804328-25-000031:mdna:88]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | Change |  | March 30,2025 |  | March 24,2024 |  | Change |
| Licensing revenues | $ | 1,319 |  |  | $ | 1,318 |  |  | $ | 1 |  |  | $ | 2,854 |  |  | $ | 2,778 |  |  | $ | 76 |  |
| EBT | 929 |  |  | 933 |  |  | (4) |  |  | 2,086 |  |  | 2,013 |  |  | 73 |  |
| EBT as a % of revenues | 70 | % |  | 71 | % |  | -1 point |  | 73 | % |  | 72 | % |  | 1 point |

[0000804328-25-000031:mdna:89]
During the second quarter of fiscal 2025, we executed final agreements for new long-term licenses with two key Chinese OEMs (for which the initial terms had expired). We also recently entered into comprehensive 4G and 5G license agreements with Transsion (a growing, China-headquartered OEM that sells primarily in developing regions). As a result of our agreements with Transsion, all outstanding litigation between the parties has been dismissed. QTL revenues for the second quarter and first six months of fiscal 2025 included estimated royalties due from Transsion for sales made in the March 2025 quarter. We did not record QTL revenues in the second quarter of fiscal 2025 from Huawei, whose license agreement has expired.

[0000804328-25-000031:mdna:90]
Second quarter 2025 vs. 2024

[0000804328-25-000031:mdna:91]
QTL licensing revenues and EBT remained approximately flat in the second quarter of fiscal 2025.

[0000804328-25-000031:mdna:92]
First six months 2025 vs. 2024

[0000804328-25-000031:mdna:93]
The increase in QTL licensing revenues in the first six months of fiscal 2025 was primarily due to:

[0000804328-25-000031:mdna:94]
+    $39 million increase in estimated sales of 3G/4G/5G-based multimode products

[0000804328-25-000031:mdna:95]
+    $37 million in higher royalty revenues recognized related to devices sold in prior periods

[0000804328-25-000031:mdna:96]
QTL EBT as a percentage of revenues increased in the first six months of fiscal 2025 primarily due to higher revenues.

[0000804328-25-000031:mdna:97]
[same as prior period, unchanged from 0000804328-25-000011:mdna:66]

[0000804328-25-000031:mdna:98]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | Change |  | March 30,2025 |  | March 24,2024 |  | Change |
| Equipment and services revenues | $ | — |  |  | $ | 3 |  |  | $ | (3) |  |  | $ | — |  |  | $ | 16 |  |  | $ | (16) |  |
| EBT | 10 |  |  | 96 |  |  | (86) |  |  | 29 |  |  | 107 |  |  | (78) |  |

[0000804328-25-000031:mdna:99]
Second quarter and first six months 2025 vs. 2024

[0000804328-25-000031:mdna:100]
QSI EBT decreased in the second quarter and first six months of fiscal 2025 primarily due to lower net gains on certain of our equity investments.

[0000804328-25-000031:mdna:101]
[same as prior period, unchanged from 0000804328-25-000011:mdna:70]

[0000804328-25-000031:mdna:102]
[same as prior period, unchanged from 0000804328-25-000011:mdna:71]

[0000804328-25-000031:mdna:103]
[same as prior period, unchanged from 0000804328-25-000011:mdna:72]

[0000804328-25-000031:mdna:104]
•We continue to monitor the recent changes in global trade policy, including tariffs and related trade actions announced by the U.S., China and other countries. The degree to which such tariffs and other related actions impact

[0000804328-25-000031:mdna:105]
22

[0000804328-25-000031:mdna:106]
our business, financial condition and results of operations will depend on future developments, which are uncertain. Changes to global trade policies may negatively impact demand, pricing and cost for our products and technologies, and contribute to the inherent uncertainties in estimating future customer demand, which may result in increased excess or obsolete inventory or reserve charges, negatively impacting our results of operations and cash flows. See “Risk Factors” in this Quarterly Report, including the Risk Factor titled “We operate in the highly cyclical semiconductor industry, which is subject to significant downturns. We are also susceptible to declines in global, regional and local economic conditions generally. Our stock price and financial results are subject to substantial quarterly and annual fluctuations due to these dynamics, among others.”

[0000804328-25-000031:mdna:107]
[same as prior period, unchanged from 0000804328-25-000011:mdna:73]

[0000804328-25-000031:mdna:108]
•We expect continued intense competition, including from vertical integration by certain of our customers. Specifically, Apple began utilizing its own modem (rather than our products) in its recently released smartphone and we expect that Apple will increasingly use its own modem products, rather than our products, in its future devices, which will have a significant negative impact on our QCT revenues, results of operations and cash flows.

[0000804328-25-000031:mdna:109]
[same as prior period, unchanged from 0000804328-25-000011:mdna:75]

[0000804328-25-000031:mdna:110]
We are also involved in certain legal proceedings, including those described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Litigation is inherently uncertain, and, while we intend to continue to vigorously defend ourselves in such matters, the unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0000804328-25-000031:mdna:111]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless industry and governments as to the benefits of our licensing programs and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may be dissatisfied with the need to pay reasonable royalties for the use of our technologies and not welcome the success of our licensing programs in enabling new, highly cost-effective competitors to their products. Accordingly, such companies and/or governments or regulators may continue to challenge our business model in various forums throughout the world.

[0000804328-25-000031:mdna:112]
[same as prior period, unchanged from 0000804328-25-000011:mdna:82]

[0000804328-25-000031:mdna:113]
[same as prior period, unchanged from 0000804328-25-000011:mdna:83]

[0000804328-25-000031:mdna:114]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at March 30, 2025 and September 29, 2024 and for the first six months of fiscal 2025 and 2024 (in millions):

[0000804328-25-000031:mdna:115]
|  | March 30,2025 |  | September 29,2024 |  | Change |  |  |
| Cash, cash equivalents and marketable securities |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 7,203 |  |  | $ | 7,849 |  |  | $ | (646) |  |  |  |
| Marketable securities | 6,643 |  |  | 5,451 |  |  | 1,192 |  |  |  |
|  | $ | 13,846 |  |  | $ | 13,300 |  |  | $ | 546 |  |  |  |
| Debt (1) | $ | 14,623 |  |  | $ | 14,634 |  |  | $ | (11) |  |  |  |

[0000804328-25-000031:mdna:116]
(1) Includes our issued debt reported as long-term and $1.4 billion reported as short-term debt (which matures in May 2025). As of March 30, 2025 and September 29, 2024, our credit facility was undrawn, and we had no commercial paper outstanding.

[0000804328-25-000031:mdna:117]
|  | Six Months Ended |
|  | March 30,2025 |  | March 24,2024 |  | Change |  |  |
| Net cash provided by operating activities | $ | 7,141 |  |  | $ | 6,503 |  |  | $ | 638 |  |  |  |
| Net cash used by investing activities | (1,960) |  |  | (2,195) |  |  | 235 |  |  |  |
| Net cash used by financing activities | (5,789) |  |  | (3,621) |  |  | (2,168) |  |  |  |

[0000804328-25-000031:mdna:118]
Cash, cash equivalents and marketable securities. The net increase in cash, cash equivalents and marketable securities for the first six months of fiscal 2025 was primarily due to net cash provided by operating activities, partially offset by $3.5 billion in payments to repurchase 22 million shares of our common stock, $1.9 billion in cash dividends paid, $609 million in payments of tax withholdings related to the vesting of share-based awards, $491 million in capital expenditures and $341 million in cash paid for acquisitions and other investments.

[0000804328-25-000031:mdna:119]
During the first six months of fiscal 2025, income taxes paid were in excess of our provision, negatively impacting net cash provided by operating activities. This was driven primarily by our installment payment for a one-time U.S. repatriation tax accrued in fiscal 2018 of $530 million and the adverse impact of the requirement to capitalize and amortize research and development expenditures for federal income tax purposes.

[0000804328-25-000031:mdna:120]
Net changes in our operating assets and liabilities for the first six months of fiscal 2025 negatively impacted our operating cash flows primarily from a decrease in payroll and other benefit related liabilities primarily driven by payments related to our employee cash incentive program. This was partially offset by a decrease in other assets primarily driven by utilization of prior advanced supply agreement payments.

[0000804328-25-000031:mdna:121]
Capital Return Program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time.

[0000804328-25-000031:mdna:122]
On March 18, 2025, we announced an increase in our quarterly dividend per share of common stock from $0.85 to $0.89, which is effective for dividends payable after March 27, 2025. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors. Additional information regarding our capital returns is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 4. Capital Stock.”

[0000804328-25-000031:mdna:123]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2024 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At March 30, 2025, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements”, “Looking Forward” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2024 Annual Report on Form 10-K.

[0000804328-25-000031:mdna:124]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Risk Factors” in this Quarterly Report.

[0000804328-25-000031:mdna:125]
[same as prior period, unchanged from 0000804328-25-000011:mdna:94]

[0000804328-25-000031:mdna:126]
[same as prior period, unchanged from 0000804328-25-000011:mdna:95]

[0000804328-25-000031:mdna:127]
[same as prior period, unchanged from 0000804328-25-000011:mdna:96]

[0000804328-25-000031:mdna:128]
24
