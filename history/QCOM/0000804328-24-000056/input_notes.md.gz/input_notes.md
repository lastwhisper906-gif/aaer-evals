# QCOM notes — 0000804328-24-000056


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000804328-24-000056:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 24, 2023. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and nine months ended June 23, 2024 and June 25, 2023 included 13 weeks and 39 weeks, respectively. Our fiscal year for 2024 will include 53 weeks, with a 14-week fiscal fourth quarter.

[0000804328-24-000056:notes:2]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in our condensed consolidated financial statements and the accompanying notes. Actual results could differ from those estimates.

[0000804328-24-000056:notes:3]
[same as prior period, unchanged from 0000804328-24-000039:notes:3]

[0000804328-24-000056:notes:4]
[same as prior period, unchanged from 0000804328-24-000039:notes:4]

[0000804328-24-000056:notes:5]
[same as prior period, unchanged from 0000804328-24-000039:notes:5]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-24-000056:notes:6]
[same as prior period, unchanged from 0000804328-24-000039:notes:6]

[0000804328-24-000056:notes:7]
| Inventories (in millions) |  |  |  |
|  | June 23,2024 |  | September 24,2023 |
| Raw materials | $ | 264 |  |  | $ | 176 |  |
| Work-in-process | 3,316 |  |  | 4,096 |  |
| Finished goods | 2,440 |  |  | 2,150 |  |
|  | $ | 6,020 |  |  | $ | 6,422 |  |

[0000804328-24-000056:notes:8]
| Other Current Liabilities (in millions) |  |  |  |
|  | June 23,2024 |  | September 24,2023 |
| Customer incentives and other customer-related liabilities | $ | 2,241 |  |  | $ | 1,821 |  |
| Income taxes payable | 701 |  |  | 1,717 |  |
| Other | 812 |  |  | 953 |  |
|  | $ | 3,754 |  |  | $ | 4,491 |  |

[0000804328-24-000056:notes:9]
Debt. In May 2024, we repaid $914 million of fixed-rate notes that matured in May 2024. At June 23, 2024, the aggregate fair value of our outstanding fixed-rate notes, based on Level 2 inputs, was approximately $13.8 billion.

[0000804328-24-000056:notes:10]
Revenues. We disaggregate our revenues by segment (Note 6), by products and services (as presented on our condensed consolidated statement of operations), and for our QCT (Qualcomm CDMA Technologies) segment, by revenue stream, which is based on the industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s

[0000804328-24-000056:notes:11]
(Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets.

[0000804328-24-000056:notes:12]
[same as prior period, unchanged from 0000804328-24-000039:notes:10]

[0000804328-24-000056:notes:13]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  | June 23,2024 |  | June 25,2023 |  | June 23,2024 |  | June 25,2023 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 5,899 |  |  | $ | 5,255 |  |  | $ | 18,766 |  |  | $ | 17,114 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 811 |  |  | 434 |  |  | 2,012 |  |  | 1,337 |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,359 |  |  | 1,485 |  |  | 3,740 |  |  | 4,557 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 8,069 |  |  | $ | 7,174 |  |  | $ | 24,518 |  |  | $ | 23,008 |  |

[0000804328-24-000056:notes:14]
[same as prior period, unchanged from 0000804328-24-000039:notes:12]

[0000804328-24-000056:notes:15]
[same as prior period, unchanged from 0000804328-24-000039:notes:13]

[0000804328-24-000056:notes:16]
[same as prior period, unchanged from 0000804328-24-000039:notes:14]

[0000804328-24-000056:notes:17]
[same as prior period, unchanged from 0000804328-24-000039:notes:15]

[0000804328-24-000056:notes:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | June 23,2024 |  | June 25,2023 |
| Revenues recognized from previously satisfied performance obligations | $ | 163 |  |  | $ | 216 |  |  | $ | 364 |  |  | $ | 521 |  |

[0000804328-24-000056:notes:19]
Unearned revenues (which are considered contract liabilities) consist primarily of certain customer contracts for which QCT received fees upfront. In the nine months ended June 23, 2024 and June 25, 2023, we recognized revenues of $271 million and $302 million, respectively, that were recorded as unearned revenues at September 24, 2023 and September 25, 2022, respectively.

[0000804328-24-000056:notes:20]
[same as prior period, unchanged from 0000804328-24-000039:notes:18]

[0000804328-24-000056:notes:21]
[same as prior period, unchanged from 0000804328-24-000039:notes:19]

[0000804328-24-000056:notes:22]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | June 23,2024 |  | June 25,2023 |
| Customer/licensee (x) | 18 | % |  | 24 | % |  | 20 | % |  | 21 | % |
| Customer/licensee (y) | 17 |  |  | 23 |  |  | 20 |  |  | 28 |  |
| Customer/licensee (z) | 11 |  |  | * |  | 13 |  |  | * |

[0000804328-24-000056:notes:23]
[same as prior period, unchanged from 0000804328-24-000039:notes:21]

[0000804328-24-000056:notes:24]
Other Income, Costs and Expenses. Other expenses in the three months and nine months ended June 23, 2024 primarily consisted of a $75 million charge related to the proposed settlement of the securities class action lawsuit (Note 5). Other expenses in the nine months ended June 25, 2023 included certain restructuring amounts (substantially all of which related to accrued severance costs) from cost reduction actions initiated in fiscal 2023.

[0000804328-24-000056:notes:25]
| Investment and Other Income (Expense), Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | June 23,2024 |  | June 25,2023 |
| Interest and dividend income | $ | 182 |  |  | $ | 79 |  |  | $ | 490 |  |  | $ | 193 |  |
| Net gains (losses) on marketable securities | 8 |  |  | (23) |  |  | 16 |  |  | (3) |  |
| Net gains on other investments | 10 |  |  | 17 |  |  | 170 |  |  | 17 |  |
| Net gains on deferred compensation plan assets | 26 |  |  | 48 |  |  | 153 |  |  | 95 |  |
| Impairment losses on other investments | (5) |  |  | (19) |  |  | (66) |  |  | (120) |  |
| Other | 5 |  |  | 4 |  |  | 5 |  |  | (16) |  |
|  | $ | 226 |  |  | $ | 106 |  |  | $ | 768 |  |  | $ | 166 |  |

[0000804328-24-000056:notes:26]
Discontinued Operations. On June 1, 2023, SSW Partners completed the sale of Veoneer’s Active Safety business to Magna International Inc. for net cash proceeds of $1.5 billion. On March 1, 2024, SSW Partners completed the sale of Veoneer’s Restraint Control Systems (RCS) business (collectively with the Active Safety business, the Non-Arriver businesses) to American Industrial Partners Capital Fund VII. Through the date of disposition by SSW Partners, the assets and liabilities of the Non-Arriver businesses have been presented as held for sale on our condensed consolidated balance sheets, and the operating results (including the gain or loss on sale, the amounts of which were not material) have been presented as discontinued operations. Also, the cash flows provided (used) by the Non-Arriver businesses are reflected separately as discontinued operations, with the cash proceeds from the sale of the Active Safety and RCS businesses presented as investing activities.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-24-000056:notes:27]
Income Taxes
For the third quarter of fiscal 2024, we estimated our annual effective income tax rate to be 7% for fiscal 2024, which is lower than the U.S. federal statutory rate, primarily due to (i) a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, which includes certain additional benefits from the requirement to capitalize research and development expenditures for federal income tax purposes, (ii) a benefit from our federal research and development tax credit and (iii) excess tax benefits associated with share-based awards. Our effective tax rate of 8% for the third quarter of fiscal 2024 was higher than our estimated annual effective tax rate of 7%, primarily due to net discrete tax benefits realized in the first quarter of fiscal 2024. Our effective tax rate of 1% for the third quarter of fiscal 2023 included benefits from fiscal 2021 and 2022 FDII deductions related to a change in sourcing of research and development expenditures in the third quarter of fiscal 2023.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-24-000056:notes:28]
Capital Stock
Stock Repurchase Program. On October 12, 2021, we announced a $10.0 billion stock repurchase program. The stock repurchase program has no expiration date. At June 23, 2024, $2.3 billion remained authorized for repurchase under our stock repurchase program.

[0000804328-24-000056:notes:29]
Shares Outstanding. Shares of common stock outstanding at June 23, 2024 were as follows (in millions):

[0000804328-24-000056:notes:30]
| Balance at September 24, 2023 | 1,114 |  |
| Issued | 20 |  |
| Repurchased | (18) |  |
| Balance at June 23, 2024 | 1,116 |  |

[0000804328-24-000056:notes:31]
Dividends. On July 17, 2024, we announced a cash dividend of $0.85 per share on our common stock, payable on September 26, 2024 to stockholders of record as of the close of business on September 5, 2024.

[0000804328-24-000056:notes:32]
[same as prior period, unchanged from 0000804328-24-000039:notes:30]

[0000804328-24-000056:notes:33]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | June 23,2024 |  | June 25,2023 |
| Dilutive common share equivalents included in diluted shares | 18 |  |  | 9 |  |  | 14 |  |  | 9 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | — |  |  | 8 |  |  | 5 |  |  | 6 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-24-000056:notes:34]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0000804328-24-000056:notes:35]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. The court consolidated the two actions, and on July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On May 23, 2022, the plaintiffs filed a motion for class certification, and on March 20, 2023, the court issued an order granting in part and denying in part the plaintiffs’ motion for class certification. The order denied class certification on the basis of alleged misrepresentations relating to our chip-level licensing practices, but certified a class on the basis of alleged misrepresentations relating to the separate operations of QCT and QTL. We have reached a proposed settlement with the plaintiffs to resolve this litigation, and on June 18, 2024, we and the plaintiffs, along with the individual defendants, filed a joint Stipulation and Agreement of Settlement with the court. The settlement has been preliminarily approved by the court and is subject to final approval following notice to the class, with a final settlement hearing scheduled for September 27, 2024. If the court approves the settlement, the claims of all class members who did not elect to opt out of the class will be extinguished, and we will pay $75 million to be distributed to the class. As a result, in the third quarter of fiscal 2024, we recorded a charge of $75 million to other expenses for the proposed settlement amount.

[0000804328-24-000056:notes:36]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. The cases filed in the Southern District of California were subsequently transferred to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On September 27, 2018, the court certified the class. We appealed the court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class, and remanded the case to the district court. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. We filed a motion to dismiss the amended complaint, and on January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. We subsequently filed a motion for summary judgment on the plaintiffs’ remaining claims. The court granted our motion in its entirety and, on October 5, 2023, entered final judgment in Qualcomm’s favor. On November

[0000804328-24-000056:notes:37]
2, 2023, the plaintiffs filed a notice of appeal to the Ninth Circuit. A hearing on the plaintiffs’ appeal is scheduled for October 15, 2024. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-24-000056:notes:38]
Beginning in November 2017, several other consumer class action complaints were filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws and seeking damages. The claims in these complaints are similar to those in the U.S. consumer class action complaints described above. These matters are at various stages of litigation, and we intend to continue to vigorously defend ourselves.

[0000804328-24-000056:notes:39]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit (Federal Circuit), and on November 6, 2023, the court held a hearing on the appeal. On July 16, 2024, the Federal Circuit dismissed ParkerVision’s appeal due to a procedural issue, subject to reinstatement following resolution of that issue by the district court. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-24-000056:notes:40]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (Arm) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with Arm (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. The complaint seeks specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology. Arm also contends that we violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of Arm’s trademarks and seeks associated injunctive and declaratory relief. Arm further seeks exemplary or punitive damages, costs, expenses and reasonable attorney’s fees, and equitable relief addressing any infringement occurring after entry of judgment.

[0000804328-24-000056:notes:41]
On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm (together with the Nuvia ALA, the Arm-Nuvia Agreements) and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia), server System-on-Chip (SoC) and compute SoC are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm (together with the Qualcomm ALA, the Arm-Qualcomm Agreements). We further seek an order enjoining Arm from making any claim that our products are not licensed under the Arm-Qualcomm Agreements, are not Arm-compliant or that we are prohibited from using Arm’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements Arm is making in the marketplace concerning our rights under the Arm-Qualcomm Agreements are false, and that Arm has no right to prevent us from shipping our products, which are validly licensed. On March 22, 2024, we filed a Second Amended Counterclaim asserting that Arm has breached the Arm-Nuvia Agreements by continuing to use Nuvia technology and by failing to return or destroy Nuvia confidential information after the Arm-Nuvia Agreements were terminated. The Second Amended Counterclaim seeks damages related to the asserted breaches. Trial is scheduled to begin on December 16, 2024. On July 10, 2024, Arm filed a motion for partial summary judgment that the Nuvia ALA was properly terminated, that the Nuvia ALA was breached, and that Arm did not breach the Arm-Nuvia Agreements. We also filed a motion for summary judgment on Arm’s breach of contract claims, that Qualcomm’s architected cores are licensed under the Qualcomm ALA, and that Qualcomm has not infringed Arm’s trademarks. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.

[0000804328-24-000056:notes:42]
On April 18, 2024, we filed a separate complaint (captioned QUALCOMM Incorporated v. Arm Ltd.) against Arm in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief. Arm has moved to dismiss this complaint.

[0000804328-24-000056:notes:43]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. Other than with respect to the Consolidated Securities Class Action Lawsuit proposed settlement, we have not recorded any accrual at June 23, 2024 for contingent losses associated with the pending matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (for example, our 2010 European Commission matter relating to the Icera complaint, and other matters arising in the ordinary course of our business, including those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-24-000056:notes:44]
[same as prior period, unchanged from 0000804328-24-000039:notes:42]

[0000804328-24-000056:notes:45]
[same as prior period, unchanged from 0000804328-24-000039:notes:43]

[0000804328-24-000056:notes:46]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | June 23,2024 |  | June 25,2023 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 8,069 |  |  | $ | 7,174 |  |  | $ | 24,518 |  |  | $ | 23,008 |  |
| QTL | 1,273 |  |  | 1,230 |  |  | 4,051 |  |  | 4,044 |  |
| QSI | 2 |  |  | 9 |  |  | 18 |  |  | 22 |  |
| Reconciling items | 49 |  |  | 38 |  |  | 131 |  |  | 115 |  |
| Total | $ | 9,393 |  |  | $ | 8,451 |  |  | $ | 28,718 |  |  | $ | 27,189 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 2,181 |  |  | $ | 1,744 |  |  | $ | 7,062 |  |  | $ | 6,035 |  |
| QTL | 894 |  |  | 811 |  |  | 2,907 |  |  | 2,799 |  |
| QSI | 14 |  |  | (21) |  |  | 121 |  |  | (83) |  |
| Reconciling items | (810) |  |  | (777) |  |  | (2,350) |  |  | (2,728) |  |
| Total | $ | 2,279 |  |  | $ | 1,757 |  |  | $ | 7,740 |  |  | $ | 6,023 |  |

[0000804328-24-000056:notes:47]
[same as prior period, unchanged from 0000804328-24-000039:notes:45]

[0000804328-24-000056:notes:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | June 23,2024 |  | June 25,2023 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 49 |  |  | $ | 38 |  |  | $ | 131 |  |  | $ | 115 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of revenues | $ | (54) |  |  | $ | (42) |  |  | $ | (168) |  |  | $ | (155) |  |
| Unallocated research and development expenses | (549) |  |  | (520) |  |  | (1,664) |  |  | (1,537) |  |
| Unallocated selling, general and administrative expenses | (175) |  |  | (172) |  |  | (588) |  |  | (464) |  |
| Unallocated other (expenses) income (Note 2) | (75) |  |  | 4 |  |  | (47) |  |  | (285) |  |
| Unallocated interest expense | (168) |  |  | (172) |  |  | (518) |  |  | (520) |  |
| Unallocated investment and other income, net | 213 |  |  | 130 |  |  | 648 |  |  | 252 |  |
| Nonreportable segments | (2) |  |  | (5) |  |  | (13) |  |  | (19) |  |
|  | $ | (810) |  |  | $ | (777) |  |  | $ | (2,350) |  |  | $ | (2,728) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-24-000056:notes:49]
Fair Value Measurements and Marketable Securities
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at June 23, 2024 (in millions):

[0000804328-24-000056:notes:50]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 4,400 |  |  | $ | 1,926 |  |  | $ | — |  |  | $ | 6,326 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 4,292 |  |  | — |  |  | 4,292 |  |
| U.S. Treasury securities and government-related securities | 324 |  |  | 34 |  |  | — |  |  | 358 |  |
| Mortgage- and asset-backed securities | — |  |  | 475 |  |  | — |  |  | 475 |  |
| Equity securities | 137 |  |  | — |  |  | — |  |  | 137 |  |
| Total marketable securities | 461 |  |  | 4,801 |  |  | — |  |  | 5,262 |  |
| Derivative instruments | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Other investments | 917 |  |  | — |  |  | 39 |  |  | 956 |  |
| Total assets measured at fair value | $ | 5,778 |  |  | $ | 6,750 |  |  | $ | 39 |  |  | $ | 12,567 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 237 |  |  | $ | — |  |  | $ | 237 |  |
| Other liabilities | 914 |  |  | — |  |  | — |  |  | 914 |  |
| Total liabilities measured at fair value | $ | 914 |  |  | $ | 237 |  |  | $ | — |  |  | $ | 1,151 |  |

[0000804328-24-000056:notes:51]
Marketable Securities. At June 23, 2024 and September 24, 2023, our marketable securities were all classified as current and were primarily comprised of available-for-sale debt securities (substantially all of which were corporate bonds and notes).

[0000804328-24-000056:notes:52]
[same as prior period, unchanged from 0000804328-24-000039:notes:51]

[0000804328-24-000056:notes:53]
|  | June 23,2024 |
| Years to Maturity |  |
| Less than one year | $ | 1,726 |  |
| One to five years | 2,913 |  |
| Five to ten years | 11 |  |
| No single maturity date | 475 |  |
| Total | $ | 5,125 |  |

[0000804328-24-000056:notes:54]
[same as prior period, unchanged from 0000804328-24-000039:notes:53]


## ecd:MtrlTermsOfTrdArrTextBlock

[0000804328-24-000056:notes:55]
On May 21, 2024, Cristiano Amon, our President and Chief Executive Officer, acting as trustee on behalf of his family trust, adopted a Rule 10b5-1 trading arrangement (as defined in Item 408 of Regulation S-K) providing for the sale of up to 75,000 shares of our common stock. The plan is scheduled to terminate on September 30, 2025.

[0000804328-24-000056:notes:56]
On June 6, 2024, Ann Chaplin, our General Counsel and Corporate Secretary, adopted a Rule 10b5-1 trading arrangement providing for the sale of (i) 50% of the net shares issued to Ms. Chaplin upon the vesting of restricted stock unit awards representing 25,216 shares of our common stock and (ii) 60% of the net shares issued to Ms. Chaplin upon the vesting of performance stock unit awards representing 45,074 shares of our common stock (assuming that such shares underlying performance stock units vest at target amounts), including, in each case, accrued dividend-equivalent shares and excluding any shares withheld to satisfy tax withholding obligations in connection with the settlement of such awards. The plan is scheduled to terminate on December 31, 2025.

[0000804328-24-000056:notes:57]
On June 6, 2024, Neil Martin, our Senior Vice President, Finance and Chief Accounting Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale of the net shares issued to Mr. Martin upon the vesting of restricted stock unit awards representing 9,030 shares of our common stock, including accrued dividend-equivalent shares and excluding any shares withheld to satisfy tax withholding obligations in connection with the settlement of such awards. The plan is scheduled to terminate on June 5, 2026.
