# QCOM MD&A — 0000804328-24-000056


## mdna

[0000804328-24-000056:mdna:1]
[same as prior period, unchanged from 0000804328-24-000039:mdna:1]

[0000804328-24-000056:mdna:2]
[same as prior period, unchanged from 0000804328-24-000039:mdna:2]

[0000804328-24-000056:mdna:3]
[same as prior period, unchanged from 0000804328-24-000039:mdna:3]

[0000804328-24-000056:mdna:4]
Third Quarter Fiscal 2024 Overview

[0000804328-24-000056:mdna:5]
Revenues for the third quarter of fiscal 2024 were $9.4 billion, an increase of 11% compared to the year ago quarter, with net income of $2.1 billion, an increase of 18% compared to the year ago quarter. Key items from the third quarter of fiscal 2024 included:

[0000804328-24-000056:mdna:6]
•QCT revenues increased by 12% in the third quarter of fiscal 2024 compared to the year ago quarter, due to higher handsets and automotive revenues, partially offset by lower IoT revenues.

[0000804328-24-000056:mdna:7]
•QTL revenues increased by 3% in the third quarter of fiscal 2024 compared to the year ago quarter, due to an increase in estimated sales of 3G/4G/5G-based multimode products.

[0000804328-24-000056:mdna:8]
[same as prior period, unchanged from 0000804328-24-000039:mdna:9]

[0000804328-24-000056:mdna:9]
[same as prior period, unchanged from 0000804328-24-000039:mdna:10]

[0000804328-24-000056:mdna:10]
[same as prior period, unchanged from 0000804328-24-000039:mdna:11]

[0000804328-24-000056:mdna:11]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering and research and development functions are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0000804328-24-000056:mdna:12]
[same as prior period, unchanged from 0000804328-24-000039:mdna:30]

[0000804328-24-000056:mdna:13]
[same as prior period, unchanged from 0000804328-24-000039:mdna:14]

[0000804328-24-000056:mdna:14]
[same as prior period, unchanged from 0000804328-24-000039:mdna:15]

[0000804328-24-000056:mdna:15]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | Change |  | June 23,2024 |  | June 25,2023 |  | Change |
| Equipment and services | $ | 7,993 |  |  | $ | 7,108 |  |  | $ | 885 |  |  | $ | 24,259 |  |  | $ | 22,737 |  |  | $ | 1,522 |  |
| Licensing | 1,400 |  |  | 1,343 |  |  | 57 |  |  | 4,459 |  |  | 4,452 |  |  | 7 |  |
|  | $ | 9,393 |  |  | $ | 8,451 |  |  | $ | 942 |  |  | $ | 28,718 |  |  | $ | 27,189 |  |  | $ | 1,529 |  |

[0000804328-24-000056:mdna:16]
Third quarter 2024 vs. 2023

[0000804328-24-000056:mdna:17]
The increase in revenues in the third quarter of fiscal 2024 was primarily due to $880 million in higher equipment and services revenues from our QCT segment.

[0000804328-24-000056:mdna:18]
First nine months 2024 vs. 2023

[0000804328-24-000056:mdna:19]
The increase in revenues in the first nine months of fiscal 2024 was primarily due to $1.5 billion in higher equipment and services revenues from our QCT segment.

[0000804328-24-000056:mdna:20]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | Change |  | June 23,2024 |  | June 25,2023 |  | Change |
| Cost of revenues | $ | 4,174 |  |  | $ | 3,792 |  |  | $ | 382 |  |  | $ | 12,593 |  |  | $ | 11,989 |  |  | $ | 604 |  |
| Gross margin | 56 | % |  | 55 | % |  |  |  | 56 | % |  | 56 | % |  |  |

[0000804328-24-000056:mdna:21]
Third quarter 2024 vs. 2023

[0000804328-24-000056:mdna:22]
Gross margin percentage increased in the third quarter of fiscal 2024 primarily due to an increase in QCT gross margin.

[0000804328-24-000056:mdna:23]
First nine months 2024 vs. 2023

[0000804328-24-000056:mdna:24]
Gross margin percentage remained flat in the first nine months of fiscal 2024.

[0000804328-24-000056:mdna:25]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | Change |  | June 23,2024 |  | June 25,2023 |  | Change |
| Research and development | $ | 2,259 |  |  | $ | 2,222 |  |  | $ | 37 |  |  | $ | 6,591 |  |  | $ | 6,683 |  |  | $ | (92) |  |
| % of revenues | 24 | % |  | 26 | % |  |  |  | 23 | % |  | 25 | % |  |  |

[0000804328-24-000056:mdna:26]
Third quarter 2024 vs. 2023

[0000804328-24-000056:mdna:27]
Research and development expenses remained approximately flat in the third quarter of fiscal 2024.

[0000804328-24-000056:mdna:28]
First nine months 2024 vs. 2023

[0000804328-24-000056:mdna:29]
The decrease in research and development expenses in the first nine months of fiscal 2024 was primarily due to:

[0000804328-24-000056:mdna:30]
-    $174 million decrease driven by lower costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies). This was primarily driven by a decrease in employee-related costs as a result of certain restructuring actions initiated in fiscal 2023 (which were substantially completed by the first quarter of fiscal 2024) to fund continued investments in key growth and diversification opportunities, partially offset by higher employee cash incentive program costs.

[0000804328-24-000056:mdna:31]
+    $49 million increase in share-based compensation expense

[0000804328-24-000056:mdna:32]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | Change |  | June 23,2024 |  | June 25,2023 |  | Change |
| Selling, general and administrative | $ | 664 |  |  | $ | 618 |  |  | $ | 46 |  |  | $ | 1,998 |  |  | $ | 1,854 |  |  | $ | 144 |  |
| % of revenues | 7 | % |  | 7 | % |  |  |  | 7 | % |  | 7 | % |  |  |

[0000804328-24-000056:mdna:33]
Third quarter 2024 vs. 2023

[0000804328-24-000056:mdna:34]
The increase in selling, general and administrative expenses in the third quarter of fiscal 2024 was primarily due to an increase in sales and marketing expenses.

[0000804328-24-000056:mdna:35]
First nine months 2024 vs. 2023

[0000804328-24-000056:mdna:36]
The increase in selling, general and administrative expenses in the first nine months of fiscal 2024 was primarily due to:

[0000804328-24-000056:mdna:37]
+    $34 million increase in sales and marketing expenses

[0000804328-24-000056:mdna:38]
+    $29 million increase in litigation costs

[0000804328-24-000056:mdna:39]
+    $22 million increase in expenses driven by revaluation of our deferred compensation obligation

[0000804328-24-000056:mdna:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | Change |  | June 23,2024 |  | June 25,2023 |  | Change |
| Other expenses (income) | $ | 75 |  |  | $ | (4) |  |  | $ | 79 |  |  | $ | 47 |  |  | $ | 285 |  |  | $ | (238) |  |

[0000804328-24-000056:mdna:41]
Third quarter and first nine months 2024 vs. 2023

[0000804328-24-000056:mdna:42]
Other expenses in the third quarter and first nine months of fiscal 2024 primarily consisted of a $75 million charge related to the proposed settlement of the securities class action lawsuit.

[0000804328-24-000056:mdna:43]
Other expenses in the first nine months of fiscal 2023 included certain restructuring amounts (substantially all of which related to accrued severance costs) from cost reduction actions initiated in fiscal 2023.

[0000804328-24-000056:mdna:44]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | Change |  | June 23,2024 |  | June 25,2023 |  | Change |
| Interest expense | $ | 168 |  |  | $ | 172 |  |  | $ | (4) |  |  | $ | 517 |  |  | $ | 521 |  |  | $ | (4) |  |
| Investment and other income (expense), net |
| Interest and dividend income | $ | 182 |  |  | $ | 79 |  |  | $ | 103 |  |  | $ | 490 |  |  | $ | 193 |  |  | $ | 297 |  |
| Net gains (losses) on marketable securities | 8 |  |  | (23) |  |  | 31 |  |  | 16 |  |  | (3) |  |  | 19 |  |
| Net gains on other investments | 10 |  |  | 17 |  |  | (7) |  |  | 170 |  |  | 17 |  |  | 153 |  |
| Net gains on deferred compensation plan assets | 26 |  |  | 48 |  |  | (22) |  |  | 153 |  |  | 95 |  |  | 58 |  |
| Impairment losses on other investments | (5) |  |  | (19) |  |  | 14 |  |  | (66) |  |  | (120) |  |  | 54 |  |
| Other | 5 |  |  | 4 |  |  | 1 |  |  | 5 |  |  | (16) |  |  | 21 |  |
|  | $ | 226 |  |  | $ | 106 |  |  | $ | 120 |  |  | $ | 768 |  |  | $ | 166 |  |  | $ | 602 |  |

[0000804328-24-000056:mdna:45]
The increase in interest and dividend income in the third quarter and first nine months of fiscal 2024 was primarily due to higher interest rates earned on higher balances of interest-bearing securities.

[0000804328-24-000056:mdna:46]
Net gains on other investments in the first nine months of fiscal 2024 was primarily driven by certain of our QSI non-marketable equity investments.

[0000804328-24-000056:mdna:47]
[same as prior period, unchanged from 0000804328-24-000039:mdna:58]

[0000804328-24-000056:mdna:48]
[same as prior period, unchanged from 0000804328-24-000039:mdna:54]

[0000804328-24-000056:mdna:49]
[same as prior period, unchanged from 0000804328-24-000039:mdna:55]

[0000804328-24-000056:mdna:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | June 23,2024 |  | June 25,2023 |
| Expected income tax provision at federal statutory tax rate | $ | 479 |  |  | $ | 369 |  |  | $ | 1,625 |  |  | $ | 1,265 |  |
| Benefit from foreign-derived intangible income (FDII) deduction, excluding the impact of capitalizing research and development expenditures | (130) |  |  | (129) |  |  | (439) |  |  | (338) |  |
| Benefit from FDII deduction related to capitalizing research and development expenditures | (94) |  |  | (58) |  |  | (417) |  |  | (310) |  |
| Benefit related to the research and development tax credit | (61) |  |  | (61) |  |  | (195) |  |  | (183) |  |
| Excess tax (benefit) deficiency associated with share-based awards | (89) |  |  | 19 |  |  | (141) |  |  | (2) |  |
| Foreign currency loss (gain) related to foreign withholding tax receivable | 55 |  |  | 11 |  |  | 57 |  |  | (103) |  |
| Benefit from fiscal 2021 and 2022 FDII deductions related to a change in sourcing of research and development expenditures | — |  |  | (126) |  |  | — |  |  | (126) |  |
| Other | 11 |  |  | (3) |  |  | 55 |  |  | 110 |  |
| Income tax expense | $ | 171 |  |  | $ | 22 |  |  | $ | 545 |  |  | $ | 313 |  |
| Effective tax rate | 8 | % |  | 1 | % |  | 7 | % |  | 5 | % |

[0000804328-24-000056:mdna:51]
For the third quarter of fiscal 2024, we estimated our annual effective income tax rate to be 7% for fiscal 2024, which is lower than the U.S. federal statutory rate, and excluded the effects of an intra-group transfer of intellectual property to better align certain intellectual property ownership within our QCT business that is expected to be completed in the fourth quarter of fiscal 2024. While we continue to assess the accounting impact of the transfer, we currently expect that such transfer will result in the recognition of a tax benefit of approximately $400 million during the fourth quarter of fiscal 2024 from the establishment of a deferred tax asset. Additional information regarding our annual effective income tax rate and income tax expense is provided in this Quarterly Report in “Notes to Condensed Consolidated Statements, Note 3. Income Taxes.”

[0000804328-24-000056:mdna:52]
| Discontinued Operations (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | Change |  | June 23,2024 |  | June 25,2023 |  | Change |
| Discontinued operations, net of income taxes | $ | 21 |  |  | $ | 68 |  |  | $ | (47) |  |  | $ | 27 |  |  | $ | 32 |  |  | $ | (5) |  |

[0000804328-24-000056:mdna:53]
Discontinued operations in the third quarter and first nine months of fiscal 2024 and 2023 are related to the Non-Arriver businesses. Information regarding the Non-Arriver businesses is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Discontinued Operations.”

[0000804328-24-000056:mdna:54]
[same as prior period, unchanged from 0000804328-24-000039:mdna:81]

[0000804328-24-000056:mdna:55]
[same as prior period, unchanged from 0000804328-24-000039:mdna:61]

[0000804328-24-000056:mdna:56]
The following should be read in conjunction with our financial results for the third quarter of fiscal 2024 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0000804328-24-000056:mdna:57]
[same as prior period, unchanged from 0000804328-24-000039:mdna:63]

[0000804328-24-000056:mdna:58]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | Change |  | June 23,2024 |  | June 25,2023 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets | $ | 5,899 |  |  | $ | 5,255 |  |  | $ | 644 |  |  | $ | 18,766 |  |  | $ | 17,114 |  |  | $ | 1,652 |  |
| Automotive | 811 |  |  | 434 |  |  | 377 |  |  | 2,012 |  |  | 1,337 |  |  | 675 |  |
| IoT (internet of things) | 1,359 |  |  | 1,485 |  |  | (126) |  |  | 3,740 |  |  | 4,557 |  |  | (817) |  |
| Total revenues (1) | $ | 8,069 |  |  | $ | 7,174 |  |  | $ | 895 |  |  | $ | 24,518 |  |  | $ | 23,008 |  |  | $ | 1,510 |  |
| EBT (2) | $ | 2,181 |  |  | $ | 1,744 |  |  | $ | 437 |  |  | $ | 7,062 |  |  | $ | 6,035 |  |  | $ | 1,027 |  |
| EBT as a % of revenues | 27 | % |  | 24 | % |  | 3 points |  | 29 | % |  | 26 | % |  | 3 points |

[0000804328-24-000056:mdna:59]
[same as prior period, unchanged from 0000804328-24-000039:mdna:65]

[0000804328-24-000056:mdna:60]
[same as prior period, unchanged from 0000804328-24-000039:mdna:66]

[0000804328-24-000056:mdna:61]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $7.9 billion and $7.1 billion in the third quarter of fiscal 2024 and 2023, respectively, and $24.1 billion and $22.6 billion in the first nine months of fiscal 2024 and 2023, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets as well as sales of 4G, 5G sub 6 and 5G millimeter wave RFFE products.

[0000804328-24-000056:mdna:62]
Third quarter 2024 vs. 2023

[0000804328-24-000056:mdna:63]
The increase in QCT revenues in the third quarter of fiscal 2024 was primarily due to:

[0000804328-24-000056:mdna:64]
+    higher handsets revenues, due to $443 million in higher chipset shipments driven by certain major OEMs (primarily driven by the normalization of customer inventory levels, which were elevated in the prior year) and $159 million in higher revenues per chipset driven by favorable mix toward higher-tier Snapdragon platforms

[0000804328-24-000056:mdna:65]
+    higher automotive revenues, primarily driven by an increase in demand from new vehicle launches with our Snapdragon digital cockpit products

[0000804328-24-000056:mdna:66]
[same as prior period, unchanged from 0000804328-24-000039:mdna:72]

[0000804328-24-000056:mdna:67]
QCT EBT as a percentage of revenues increased in the third quarter of fiscal 2024 primarily due to:

[0000804328-24-000056:mdna:68]
[same as prior period, unchanged from 0000804328-24-000039:mdna:84]

[0000804328-24-000056:mdna:69]
[same as prior period, unchanged from 0000804328-24-000039:mdna:75]

[0000804328-24-000056:mdna:70]
First nine months 2024 vs. 2023

[0000804328-24-000056:mdna:71]
The increase in QCT revenues in the first nine months of fiscal 2024 was primarily due to:

[0000804328-24-000056:mdna:72]
+    higher handsets revenues, due to $885 million in higher chipset shipments driven by certain major OEMs (primarily driven by the normalization of customer inventory levels, which were elevated in the prior year) and $741 million in higher revenues per chipset primarily driven by favorable mix toward higher-tier Snapdragon platforms

[0000804328-24-000056:mdna:73]
+    higher automotive revenues, primarily driven by an increase in demand from new vehicle launches with our Snapdragon digital cockpit products

[0000804328-24-000056:mdna:74]
-    lower IoT revenues, due to $616 million in lower revenues per unit primarily driven by unfavorable mix and $200 million decrease in demand (primarily in edge networking products as customers continue drawing down on their elevated inventory levels, partially offset by consumer products)

[0000804328-24-000056:mdna:75]
QCT EBT as a percentage of revenues increased in the first nine months of fiscal 2024 primarily due to:

[0000804328-24-000056:mdna:76]
+    higher revenues

[0000804328-24-000056:mdna:77]
[same as prior period, unchanged from 0000804328-24-000039:mdna:74]

[0000804328-24-000056:mdna:78]
23

[0000804328-24-000056:mdna:79]
[same as prior period, unchanged from 0000804328-24-000039:mdna:85]

[0000804328-24-000056:mdna:80]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | Change |  | June 23,2024 |  | June 25,2023 |  | Change |
| Licensing revenues | $ | 1,273 |  |  | $ | 1,230 |  |  | $ | 43 |  |  | $ | 4,051 |  |  | $ | 4,044 |  |  | $ | 7 |  |
| EBT | 894 |  |  | 811 |  |  | 83 |  |  | 2,907 |  |  | 2,799 |  |  | 108 |  |
| EBT as a % of revenues | 70 | % |  | 66 | % |  | 4 points |  | 72 | % |  | 69 | % |  | 3 points |

[0000804328-24-000056:mdna:81]
Third quarter 2024 vs. 2023

[0000804328-24-000056:mdna:82]
The increase in QTL licensing revenues in the third quarter of fiscal 2024 was primarily due to an increase in estimated sales of 3G/4G/5G-based multimode products.

[0000804328-24-000056:mdna:83]
QTL EBT as a percentage of revenues increased in the third quarter of fiscal 2024 primarily due to:

[0000804328-24-000056:mdna:84]
+    lower cost of sales driven by a decrease in amortization expense related to acquired patents

[0000804328-24-000056:mdna:85]
+    higher revenues

[0000804328-24-000056:mdna:86]
First nine months 2024 vs. 2023

[0000804328-24-000056:mdna:87]
The increase in QTL licensing revenues in the first nine months of fiscal 2024 was primarily due to:

[0000804328-24-000056:mdna:88]
+    $188 million increase in estimated sales of 3G/4G/5G-based multimode products

[0000804328-24-000056:mdna:89]
-    $115 million decrease in estimated revenues per unit

[0000804328-24-000056:mdna:90]
[same as prior period, unchanged from 0000804328-24-000039:mdna:93]

[0000804328-24-000056:mdna:91]
QTL EBT as a percentage of revenues increased in the first nine months of fiscal 2024 primarily due to lower cost of sales driven by a decrease in amortization expense related to acquired patents.

[0000804328-24-000056:mdna:92]
[same as prior period, unchanged from 0000804328-24-000039:mdna:96]

[0000804328-24-000056:mdna:93]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | Change |  | June 23,2024 |  | June 25,2023 |  | Change |
| Equipment and services revenues | $ | 2 |  |  | $ | 9 |  |  | $ | (7) |  |  | $ | 18 |  |  | $ | 22 |  |  | $ | (4) |  |
| EBT | 14 |  |  | (21) |  |  | 35 |  |  | 121 |  |  | (83) |  |  | 204 |  |

[0000804328-24-000056:mdna:94]
Third quarter 2024 vs. 2023

[0000804328-24-000056:mdna:95]
QSI segment results were not material in the third quarter of fiscal 2024 and 2023.

[0000804328-24-000056:mdna:96]
First nine months 2024 vs. 2023

[0000804328-24-000056:mdna:97]
QSI EBT increased in the first nine months of fiscal 2024 primarily due to net gains on certain of our non-marketable equity investments.

[0000804328-24-000056:mdna:98]
[same as prior period, unchanged from 0000804328-24-000039:mdna:100]

[0000804328-24-000056:mdna:99]
[same as prior period, unchanged from 0000804328-24-000039:mdna:101]

[0000804328-24-000056:mdna:100]
[same as prior period, unchanged from 0000804328-24-000039:mdna:102]

[0000804328-24-000056:mdna:101]
•We expect certain IoT customers (primarily in edge networking) will continue to draw down on their inventory (which remains at elevated levels), which will continue to have a negative impact on our revenues, results of operations and cash flows.

[0000804328-24-000056:mdna:102]
[same as prior period, unchanged from 0000804328-24-000039:mdna:104]

[0000804328-24-000056:mdna:103]
[same as prior period, unchanged from 0000804328-24-000039:mdna:105]

[0000804328-24-000056:mdna:104]
•We expect continued intense competition, including from vertical integration by certain of our customers.

[0000804328-24-000056:mdna:105]
[same as prior period, unchanged from 0000804328-24-000039:mdna:119]

[0000804328-24-000056:mdna:106]
[same as prior period, unchanged from 0000804328-24-000039:mdna:107]

[0000804328-24-000056:mdna:107]
We have recently extended, renewed or entered into license agreements with several key OEMs. We are currently pursuing negotiations with other key OEMs whose agreements expire in early fiscal 2025 (including Huawei). In addition, we have recently entered into a license agreement with Shenzhen Transsion Holdings Limited (a growing, China-headquartered OEM that sells primarily in developing regions) for its 5G products. While we continue to engage in negotiations toward a comprehensive resolution, we have initiated litigation against Transsion in multiple jurisdictions to enforce our intellectual property rights against certain of its unlicensed products. See “Risk Factors” in this Quarterly Report, including the Risk Factors titled “The continued and future success of our licensing programs requires us to continue to evolve our patent portfolio and to renew or renegotiate license agreements that are expiring” and “The enforcement and protection of our intellectual property may be expensive, could fail to prevent misappropriation or unauthorized use of our intellectual property, could result in the loss of our ability to enforce one or more patents, and could be adversely affected by changes in patent laws, by laws in certain foreign jurisdictions that may not effectively protect our intellectual property and by ineffective enforcement of laws in such jurisdictions.”

[0000804328-24-000056:mdna:108]
[same as prior period, unchanged from 0000804328-24-000039:mdna:109]

[0000804328-24-000056:mdna:109]
[same as prior period, unchanged from 0000804328-24-000039:mdna:110]

[0000804328-24-000056:mdna:110]
[same as prior period, unchanged from 0000804328-24-000039:mdna:111]

[0000804328-24-000056:mdna:111]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at June 23, 2024 and September 24, 2023 and for the first nine months of fiscal 2024 and 2023 (in millions):

[0000804328-24-000056:mdna:112]
|  | June 23,2024 |  | September 24,2023 |  | Change |  |  |
| Cash, cash equivalents and marketable securities |  |  |  |  |  |  |  |
| Cash and cash equivalents (1) | $ | 7,770 |  |  | $ | 8,450 |  |  | $ | (680) |  |  |  |
| Marketable securities | 5,262 |  |  | 2,874 |  |  | 2,388 |  |  |  |
|  | $ | 13,032 |  |  | $ | 11,324 |  |  | $ | 1,708 |  |  |  |
| Debt (2) | $ | 14,554 |  |  | $ | 15,398 |  |  | $ | (844) |  |  |  |

[0000804328-24-000056:mdna:113]
[same as prior period, unchanged from 0000804328-24-000039:mdna:114]

[0000804328-24-000056:mdna:114]
(2) Includes our issued debt reported as long-term and short-term. We had $1.4 billion (which matures in May 2025) and $914 million (which matured in May 2024) reported as short-term debt at June 23, 2024 and September 24, 2023, respectively. As of June 23, 2024 and September 24, 2023, our credit facility was undrawn, and we had no commercial paper outstanding.

[0000804328-24-000056:mdna:115]
|  | Nine Months Ended |
|  | June 23,2024 |  | June 25,2023 |  | Change |  |  |
| Net cash provided by operating activities | $ | 9,555 |  |  | $ | 7,209 |  |  | $ | 2,346 |  |  |  |
| Net cash (used) provided by investing activities | (3,238) |  |  | 1,380 |  |  | (4,618) |  |  |  |
| Net cash used by financing activities | (7,070) |  |  | (5,546) |  |  | (1,524) |  |  |  |

[0000804328-24-000056:mdna:116]
Cash, cash equivalents and marketable securities. The net increase in cash, cash equivalents and marketable securities for the first nine months of fiscal 2024 was primarily due to net cash provided by operating activities, partially offset by $2.8 billion in payments to repurchase 18 million shares of our common stock, $2.7 billion in cash dividends paid, $914 million in

[0000804328-24-000056:mdna:117]
[same as prior period, unchanged from 0000804328-24-000039:mdna:133]

[0000804328-24-000056:mdna:118]
repayment of fixed-rate notes that matured in May 2024, $797 million in payments of tax withholdings related to the vesting of share-based awards and $785 million in capital expenditures.

[0000804328-24-000056:mdna:119]
During the first nine months of fiscal 2024, income taxes paid were in excess of our provision, negatively impacting net cash provided by operating activities. This was primarily driven by the adverse impact of the requirement to capitalize and amortize research and development expenditures for federal income tax purposes, our payment of $1.0 billion related to certain previously postponed U.S. federal income tax-payments from fiscal 2023 and an installment payment for a one-time U.S. repatriation tax accrued in fiscal 2018 of $414 million.

[0000804328-24-000056:mdna:120]
Net changes in our operating assets and liabilities for the first nine months of fiscal 2024 positively impacted our operating cash flows primarily from an increase in accounts payable due to timing and amount of inventory purchases, an increase in accrued customer incentives, which included the impact of timing of related payments, and a decrease in inventory as we sold a portion of our elevated inventory. This was partially offset by approximately $385 million in severance payments related to restructuring actions initiated in fiscal 2023.

[0000804328-24-000056:mdna:121]
Capital Return Program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors. Additional information regarding our capital returns is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 4. Capital Stock.”

[0000804328-24-000056:mdna:122]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2023 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At June 23, 2024, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements”, “Looking Forward” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2023 Annual Report on Form 10-K.

[0000804328-24-000056:mdna:123]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Risk Factors” in this Quarterly Report.

[0000804328-24-000056:mdna:124]
[same as prior period, unchanged from 0000804328-24-000039:mdna:125]

[0000804328-24-000056:mdna:125]
[same as prior period, unchanged from 0000804328-24-000039:mdna:126]

[0000804328-24-000056:mdna:126]
[same as prior period, unchanged from 0000804328-24-000039:mdna:127]

[0000804328-24-000056:mdna:127]
[same as prior period, unchanged from 0000804328-24-000039:mdna:128]

[0000804328-24-000056:mdna:128]
[same as prior period, unchanged from 0000804328-24-000039:mdna:129]

[0000804328-24-000056:mdna:129]
[same as prior period, unchanged from 0000804328-24-000039:mdna:144]

[0000804328-24-000056:mdna:130]
[same as prior period, unchanged from 0000804328-24-000039:mdna:130]

[0000804328-24-000056:mdna:131]
[same as prior period, unchanged from 0000804328-24-000039:mdna:131]

[0000804328-24-000056:mdna:132]
We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier handset devices, and we expect this trend to continue in the foreseeable future. The mobile industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. Certain Chinese original equipment manufacturers (OEMs) have increased and may continue to increase their device share in China and in certain regions outside of China, and we derive a significant portion of our revenues from a small number of these OEMs as well. See also “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Concentrations.”

[0000804328-24-000056:mdna:133]
[same as prior period, unchanged from 0000804328-24-000039:mdna:135]

[0000804328-24-000056:mdna:134]
[same as prior period, unchanged from 0000804328-24-000039:mdna:136]

[0000804328-24-000056:mdna:135]
[same as prior period, unchanged from 0000804328-24-000039:mdna:137]

[0000804328-24-000056:mdna:136]
[same as prior period, unchanged from 0000804328-24-000039:mdna:138]

[0000804328-24-000056:mdna:137]
[same as prior period, unchanged from 0000804328-24-000039:mdna:139]

[0000804328-24-000056:mdna:138]
[same as prior period, unchanged from 0000804328-24-000039:mdna:140]

[0000804328-24-000056:mdna:139]
The mobile industry has also experienced slowing growth in the premium-tier device segment due to, among other factors, a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and innovation cycles. A reduction in sales of premium-tier devices, a reduction in sales of our premium-tier integrated circuit products (which have a higher revenue and margin contribution than our lower-tier integrated circuit products), a shift in share away from OEMs that utilize our premium-tier products, or a shift in consumer demand in favor of refurbished or secondhand devices, would reduce our revenues and margins and may harm our ability to achieve or sustain expected

[0000804328-24-000056:mdna:140]
[same as prior period, unchanged from 0000804328-24-000039:mdna:156]

[0000804328-24-000056:mdna:141]
financial results. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0000804328-24-000056:mdna:142]
[same as prior period, unchanged from 0000804328-24-000039:mdna:142]

[0000804328-24-000056:mdna:143]
Although we have more than 300 licensees, we derive a significant portion of our licensing revenues from a limited number of licensees, which includes a number of Chinese OEMs. In the event that one or more of our significant licensees fail to meet their reporting and payment obligations, or we are unable to renew or modify one or more of their license agreements under similar terms as their existing agreements, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the success of our core licensing business depends in part on the ability of our licensees to continue to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We do not have control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful in these efforts. Reductions in sales of our licensees’ products, or reductions in the average selling prices of such products without a sufficient increase in the volumes sold, would generally have an adverse effect on our licensing revenues.

[0000804328-24-000056:mdna:144]
[same as prior period, unchanged from 0000804328-24-000039:mdna:146]

[0000804328-24-000056:mdna:145]
[same as prior period, unchanged from 0000804328-24-000039:mdna:147]

[0000804328-24-000056:mdna:146]
[same as prior period, unchanged from 0000804328-24-000039:mdna:148]

[0000804328-24-000056:mdna:147]
[same as prior period, unchanged from 0000804328-24-000039:mdna:149]

[0000804328-24-000056:mdna:148]
[same as prior period, unchanged from 0000804328-24-000039:mdna:150]

[0000804328-24-000056:mdna:149]
[same as prior period, unchanged from 0000804328-24-000039:mdna:151]

[0000804328-24-000056:mdna:150]
[same as prior period, unchanged from 0000804328-24-000039:mdna:152]

[0000804328-24-000056:mdna:151]
[same as prior period, unchanged from 0000804328-24-000039:mdna:153]

[0000804328-24-000056:mdna:152]
Due to various factors, including pressure, encouragement or incentives from, or policies of, the Chinese government (including its Made in China 2025 campaign), concerns over losing access to our integrated circuit products as a result of actual, threatened or potential U.S. or Chinese government actions or policies, including trade protection or national security policies, or other reasons, some of our customers in China have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products in their devices, or use our competitors’ integrated circuit

[0000804328-24-000056:mdna:153]
products in their devices, rather than our products, which could materially harm our business, revenues, results of operations, cash flows and financial position. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0000804328-24-000056:mdna:154]
Political actions, including trade protection and national security policies of the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our Chinese customers or suppliers, limit, prevent or discourage certain of our Chinese customers or suppliers from transacting business with us, or make it more expensive to do so. Given our revenue concentration in China, if, due to actual, threatened or potential U.S. or Chinese government actions or policies: we were further limited in, or prohibited from, selling our integrated circuit products to Chinese customers; our non-Chinese OEM customers were limited in, or prohibited from, selling devices that incorporate our integrated circuit products into China; Chinese OEMs develop and use their own integrated circuit products or use our competitors’ integrated circuit products in some or all of their devices rather than our integrated circuit products; Chinese tariffs on our integrated circuit products or on devices which incorporate our integrated circuit products made purchasing such products or devices more expensive to our Chinese customers or Chinese consumers; or our Chinese licensees delay or cease making payments of license fees they owe us, our business, revenues, results of operations, cash flows and financial position could be materially harmed. Similarly, if, due to U.S. or Chinese government actions or policies, we were limited in or prohibited from obtaining critical integrated circuit products from our suppliers in China, our business, revenues, results of operations, cash flows and financial position could be materially harmed. See also the Risk Factors titled “We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier handset devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected” and “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0000804328-24-000056:mdna:155]
For example, we previously sold 4G and other integrated circuit products, including Wi-Fi products, but excluding 5G products, to Huawei under export licenses from the U.S. Department of Commerce. On May 7, 2024, the U.S. Department of Commerce informed us that it was revoking our license to export 4G and certain other integrated circuit products to Huawei, effective immediately, and we implemented procedures to immediately comply. Accordingly, we do not expect to receive any further product revenues from Huawei. For the first nine months of fiscal 2024, product revenues from Huawei prior to our license being revoked on May 7, 2024 were approximately $560 million. Additionally, to the extent that Huawei’s devices take share from Chinese OEMs that utilize our products or from non-Chinese OEMs that utilize our products in devices they sell into China, our revenues, results of operations and cash flows could be further impacted.

[0000804328-24-000056:mdna:156]
[same as prior period, unchanged from 0000804328-24-000039:mdna:159]

[0000804328-24-000056:mdna:157]
[same as prior period, unchanged from 0000804328-24-000039:mdna:160]

[0000804328-24-000056:mdna:158]
[same as prior period, unchanged from 0000804328-24-000039:mdna:161]

[0000804328-24-000056:mdna:159]
[same as prior period, unchanged from 0000804328-24-000039:mdna:162]

[0000804328-24-000056:mdna:160]
[same as prior period, unchanged from 0000804328-24-000039:mdna:163]

[0000804328-24-000056:mdna:161]
However, our research, development and other investments in these new and expanded product areas, industries and applications, and corresponding technologies and products, as well as in our existing technologies and products and new technologies in mobile handsets, may not succeed because, among other reasons: we may not be issued patents on the technologies we develop; the technologies we develop may not be incorporated into relevant standards; new and expanded

[0000804328-24-000056:mdna:162]
[same as prior period, unchanged from 0000804328-24-000039:mdna:173]

[0000804328-24-000056:mdna:163]
product areas, industries and applications beyond mobile handsets, and consumer demand therein, may not develop or grow as anticipated; we may be unable to attract or retain employees with the necessary skills in such new and expanded product areas, industries and applications; our strategies or the strategies of our customers, licensees or partners may not be successful; alternate technologies or products may be better or may reduce the advantages we anticipate from our investments; competitors’ technologies or products may be more cost effective, have more capabilities or fewer limitations or be brought to market faster than our new technologies or products; we may not be able to develop, or our competitors may have more established and/or stronger, customer, vendor, distributor or other channel relationships; and competitors may have longer operating histories in industries and applications that are new to us. We may also underestimate the costs of, or overestimate the future revenues or margins that could result from, these investments, and these investments may not, or may take many years to, generate material returns.

[0000804328-24-000056:mdna:164]
[same as prior period, unchanged from 0000804328-24-000039:mdna:166]

[0000804328-24-000056:mdna:165]
[same as prior period, unchanged from 0000804328-24-000039:mdna:167]

[0000804328-24-000056:mdna:166]
[same as prior period, unchanged from 0000804328-24-000039:mdna:168]

[0000804328-24-000056:mdna:167]
[same as prior period, unchanged from 0000804328-24-000039:mdna:169]

[0000804328-24-000056:mdna:168]
[same as prior period, unchanged from 0000804328-24-000039:mdna:170]

[0000804328-24-000056:mdna:169]
[same as prior period, unchanged from 0000804328-24-000039:mdna:171]

[0000804328-24-000056:mdna:170]
Achieving the anticipated benefits of business acquisitions depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply

[0000804328-24-000056:mdna:171]
and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from acquired technologies or products or from future technologies or products based on these technologies, and we may become subject to liabilities, including liabilities arising as a result of litigation, that are not covered by any indemnification protection that we may obtain. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models, geographic regions, industries and applications served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0000804328-24-000056:mdna:172]
[same as prior period, unchanged from 0000804328-24-000039:mdna:174]

[0000804328-24-000056:mdna:173]
[same as prior period, unchanged from 0000804328-24-000039:mdna:175]

[0000804328-24-000056:mdna:174]
[same as prior period, unchanged from 0000804328-24-000039:mdna:176]

[0000804328-24-000056:mdna:175]
[same as prior period, unchanged from 0000804328-24-000039:mdna:177]

[0000804328-24-000056:mdna:176]
[same as prior period, unchanged from 0000804328-24-000039:mdna:178]

[0000804328-24-000056:mdna:177]
[same as prior period, unchanged from 0000804328-24-000039:mdna:179]

[0000804328-24-000056:mdna:178]
[same as prior period, unchanged from 0000804328-24-000039:mdna:180]

[0000804328-24-000056:mdna:179]
[same as prior period, unchanged from 0000804328-24-000039:mdna:181]

[0000804328-24-000056:mdna:180]
[same as prior period, unchanged from 0000804328-24-000039:mdna:182]

[0000804328-24-000056:mdna:181]
[same as prior period, unchanged from 0000804328-24-000039:mdna:183]

[0000804328-24-000056:mdna:182]
[same as prior period, unchanged from 0000804328-24-000039:mdna:184]

[0000804328-24-000056:mdna:183]
[same as prior period, unchanged from 0000804328-24-000039:mdna:196]

[0000804328-24-000056:mdna:184]
[same as prior period, unchanged from 0000804328-24-000039:mdna:185]

[0000804328-24-000056:mdna:185]
[same as prior period, unchanged from 0000804328-24-000039:mdna:186]

[0000804328-24-000056:mdna:186]
[same as prior period, unchanged from 0000804328-24-000039:mdna:187]

[0000804328-24-000056:mdna:187]
[same as prior period, unchanged from 0000804328-24-000039:mdna:188]

[0000804328-24-000056:mdna:188]
[same as prior period, unchanged from 0000804328-24-000039:mdna:190]

[0000804328-24-000056:mdna:189]
[same as prior period, unchanged from 0000804328-24-000039:mdna:191]

[0000804328-24-000056:mdna:190]
[same as prior period, unchanged from 0000804328-24-000039:mdna:192]

[0000804328-24-000056:mdna:191]
[same as prior period, unchanged from 0000804328-24-000039:mdna:193]

[0000804328-24-000056:mdna:192]
[same as prior period, unchanged from 0000804328-24-000039:mdna:194]

[0000804328-24-000056:mdna:193]
We cannot guarantee that the actions of our suppliers will not cause disruptions in our operations that could harm our ability to meet our delivery obligations to our customers or increase our cost of sales. To the extent we are unable to obtain adequate supply to meet our delivery obligations, we may be obligated to make payments to our customers for such shortfalls. From time to time, the global semiconductor industry experiences demand for integrated circuits that exceeds the industry’s capacity to meet that demand. Our ability to meet increased demand for our products has been in the past and may

[0000804328-24-000056:mdna:194]
32

[0000804328-24-000056:mdna:195]
in the future be limited due to the inability to obtain the additional manufacturing, assembly and test capacity necessary to fully meet such demand. If we are unable to fully meet customer demand, this could result in lost sales opportunities, reduced revenue growth and harm to our customer relationships. These issues may be exacerbated if customers overstate their expected demand requirements in order to procure additional supply, which could negatively impact our ability to forecast and to allocate supply appropriately among our customers. The above issues may also be exacerbated with respect to our platform solutions, which already entail a great deal of complexity due to differing lead-times, technologies and suppliers for each integrated circuit product included in such solutions. Additionally, our suppliers have in the past and may in the future increase their prices during periods of capacity constraints, or for other reasons, thus increasing our costs.

[0000804328-24-000056:mdna:196]
[same as prior period, unchanged from 0000804328-24-000039:mdna:197]

[0000804328-24-000056:mdna:197]
[same as prior period, unchanged from 0000804328-24-000039:mdna:198]

[0000804328-24-000056:mdna:198]
[same as prior period, unchanged from 0000804328-24-000039:mdna:199]

[0000804328-24-000056:mdna:199]
[same as prior period, unchanged from 0000804328-24-000039:mdna:200]

[0000804328-24-000056:mdna:200]
[same as prior period, unchanged from 0000804328-24-000039:mdna:201]

[0000804328-24-000056:mdna:201]
We are subject to many complex environmental, health and safety laws, regulations and rules in each jurisdiction in which we operate our manufacturing (and research and development) facilities. The regulatory landscape in these areas continues to evolve, and we anticipate additional laws, regulations and rules in the future. In particular, new, or changes in, environmental and climate change laws, regulations or rules, including relating to greenhouse gas emissions, could lead to new or additional investments in production processes and could increase environmental compliance expenditures. In addition, certain environmental laws impose strict, and in certain circumstances joint and several, liability on current or previous owners or operators of real property, or parties who arranged for hazardous substances to be sent to disposal or treatment facilities, for the cost of investigation, removal or remediation of hazardous substances. As a result, we may incur clean-up costs in connection with any such removal or remediation efforts, as well as other third-party claims in connection with contaminated sites. In addition, we could be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage. If we, or companies or facilities we acquire or have acquired, in the past failed or in the future fail to comply with any such laws and regulations, then we could incur regulatory penalties, fines and legal liabilities; suspension of production; significant compliance requirements; alteration of our manufacturing, assembly or test processes; restriction on our ability to modify or expand our facilities; damage to our reputation; and restrictions on our operations or sales. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. We cannot make assurances that we will at all times be in compliance with such laws, regulations,

[0000804328-24-000056:mdna:202]
rules and permits. See also the risk factor titled “Our business may suffer due to the impact of, or our failure to comply with, the various existing, new or amended laws, regulations, policies or standards to which we are subject.”

[0000804328-24-000056:mdna:203]
Climate change concerns and the potential resulting environmental impact may result in new environmental, health and safety laws and regulations that may affect us, our suppliers and our customers. Such laws or regulations could cause us to incur additional direct costs for compliance, including costs associated with changes to manufacturing processes or the procurement of raw materials used in manufacturing processes, as well as increased indirect costs resulting from our customers, suppliers or both incurring additional compliance costs that are passed on to us. These costs may adversely impact our results of operations and financial condition. In addition, climate change could cause certain natural disasters, such as drought, wildfires, storms, flooding or rising sea levels, to occur more frequently or with greater intensity, which could pose physical risks to our manufacturing facilities or our suppliers’ facilities, could disrupt the availability of water necessary for the operation of such facilities, and could increase or decrease temperatures resulting in increased operating costs and/or business disruption.

[0000804328-24-000056:mdna:204]
[same as prior period, unchanged from 0000804328-24-000039:mdna:205]

[0000804328-24-000056:mdna:205]
[same as prior period, unchanged from 0000804328-24-000039:mdna:206]

[0000804328-24-000056:mdna:206]
[same as prior period, unchanged from 0000804328-24-000039:mdna:207]

[0000804328-24-000056:mdna:207]
From time to time, we purchase equipment to meet expected customer demand in advance of any purchase orders or long-term purchase commitments. Further, we typically begin manufacturing our products using our or our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates and may not be covered by long-term purchase commitments. As a result, we may incur increased inventory and manufacturing costs and/or record impairment charges to the extent anticipated sales ultimately do not materialize or are lower than expected. If we or our customers overestimate demand, or if demand is impacted by factors outside of our or our customers’ control, and such

[0000804328-24-000056:mdna:208]
[same as prior period, unchanged from 0000804328-24-000039:mdna:215]

[0000804328-24-000056:mdna:209]
demand is not covered by a binding commitment from our customers, we may experience higher inventory carrying and operating costs and/or increased excess or obsolete inventory or reserve charges, which would negatively impact our results of operations.

[0000804328-24-000056:mdna:210]
[same as prior period, unchanged from 0000804328-24-000039:mdna:209]

[0000804328-24-000056:mdna:211]
[same as prior period, unchanged from 0000804328-24-000039:mdna:210]

[0000804328-24-000056:mdna:212]
[same as prior period, unchanged from 0000804328-24-000039:mdna:211]

[0000804328-24-000056:mdna:213]
[same as prior period, unchanged from 0000804328-24-000039:mdna:212]

[0000804328-24-000056:mdna:214]
[same as prior period, unchanged from 0000804328-24-000039:mdna:213]

[0000804328-24-000056:mdna:215]
35

[0000804328-24-000056:mdna:216]
[same as prior period, unchanged from 0000804328-24-000039:mdna:214]

[0000804328-24-000056:mdna:217]
[same as prior period, unchanged from 0000804328-24-000039:mdna:216]

[0000804328-24-000056:mdna:218]
[same as prior period, unchanged from 0000804328-24-000039:mdna:217]

[0000804328-24-000056:mdna:219]
[same as prior period, unchanged from 0000804328-24-000039:mdna:218]

[0000804328-24-000056:mdna:220]
[same as prior period, unchanged from 0000804328-24-000039:mdna:219]

[0000804328-24-000056:mdna:221]
[same as prior period, unchanged from 0000804328-24-000039:mdna:220]

[0000804328-24-000056:mdna:222]
[same as prior period, unchanged from 0000804328-24-000039:mdna:221]

[0000804328-24-000056:mdna:223]
[same as prior period, unchanged from 0000804328-24-000039:mdna:222]

[0000804328-24-000056:mdna:224]
[same as prior period, unchanged from 0000804328-24-000039:mdna:223]

[0000804328-24-000056:mdna:225]
Our patent license agreements in effect that generate a significant portion of our licensing revenues are effective for a specified term. To receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms, and may impact the financial or other terms of license agreements not subject to the litigation or arbitration. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such licensees. Finally, certain of our license agreements contain binding renewal provisions which provide that if the parties are unable to agree upon the terms and conditions of a new license agreement by a specified date, either party may initiate binding arbitration proceedings to establish such terms and conditions. Such new license agreement would become effective immediately after the expiration of the prior agreement.

[0000804328-24-000056:mdna:226]
Nonetheless, in either event, we may not be able to recognize some or any revenues related to that licensee’s product sales until such new license agreement is finalized.

[0000804328-24-000056:mdna:227]
[same as prior period, unchanged from 0000804328-24-000039:mdna:225]

[0000804328-24-000056:mdna:228]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, alleging that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) attempts by licensees to shift their royalty obligation to their suppliers in order to make royalty collection more difficult or reduce the amount of royalties collected.

[0000804328-24-000056:mdna:229]
[same as prior period, unchanged from 0000804328-24-000039:mdna:228]

[0000804328-24-000056:mdna:230]
We have been in the past and are currently subject to various litigation and/or governmental investigations and proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. See also the Risk Factors below titled “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.”

[0000804328-24-000056:mdna:231]
[same as prior period, unchanged from 0000804328-24-000039:mdna:230]

[0000804328-24-000056:mdna:232]
Further, some third parties have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions should not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by limiting the base upon which the royalty rate may be applied). A number of these strategies are

[0000804328-24-000056:mdna:233]
[same as prior period, unchanged from 0000804328-24-000039:mdna:242]

[0000804328-24-000056:mdna:234]
purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies.

[0000804328-24-000056:mdna:235]
Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party. Further, SDOs in certain countries may attempt to modify widely accepted standards and claim the resulting standard as their own. In addition, governments may enact policies concerning standard-essential patents, such as the European Commission’s recently proposed regulations which would create a new regulatory scheme for standard-essential patents, that may have various consequences, some of which may be detrimental, such as by devaluing standard-essential patents or disrupting worldwide technology standards. Other jurisdictions may adopt similar regulatory schemes, which could also have such effects.

[0000804328-24-000056:mdna:236]
[same as prior period, unchanged from 0000804328-24-000039:mdna:235]

[0000804328-24-000056:mdna:237]
[same as prior period, unchanged from 0000804328-24-000039:mdna:236]

[0000804328-24-000056:mdna:238]
As described in the Risk Factor below titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings,” we have been in the past, currently are and may in the future be subject to various governmental investigations and/or legal proceedings challenging our patent licensing practices. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We believe that one intent of certain of these governmental investigations and legal proceedings has been to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0000804328-24-000056:mdna:239]
[same as prior period, unchanged from 0000804328-24-000039:mdna:238]

[0000804328-24-000056:mdna:240]
[same as prior period, unchanged from 0000804328-24-000039:mdna:239]

[0000804328-24-000056:mdna:241]
[same as prior period, unchanged from 0000804328-24-000039:mdna:240]

[0000804328-24-000056:mdna:242]
To the extent that we were required to implement any of these licensing and/or business practices, including by modifying or renegotiating our existing license agreements or pursuing other commercial arrangements, we would incur additional transaction costs, which may be significant, we could incur delays in recognizing revenues until license negotiations were completed, and our business, revenues, results of operations, cash flows and financial condition could be harmed. The impact of any such changes to our licensing practices could vary widely and by jurisdiction, depending on the

[0000804328-24-000056:mdna:243]
specific outcomes and the geographic scope of such outcomes. In addition, if we were required to make modifications to our licensing practices in one jurisdiction, licensees or governmental agencies in other jurisdictions may attempt to obtain similar outcomes for themselves or for such other jurisdictions, as applicable, which could result in increased legal costs and further harm to our business, revenues, results of operations, cash flows and financial condition.

[0000804328-24-000056:mdna:244]
[same as prior period, unchanged from 0000804328-24-000039:mdna:243]

[0000804328-24-000056:mdna:245]
Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.

[0000804328-24-000056:mdna:246]
We have been in the past and currently are subject to various governmental investigations and/or legal proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Key allegations or findings in those matters include or have in the past included, among others: that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers; that our royalty rates are too high; that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions); that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets; that we have entered into exclusive agreements with chipset customers that foreclose competition; that we leverage our position in baseband chipsets in the RFFE space; and that we violate antitrust laws and engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0000804328-24-000056:mdna:247]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others: the loss of our ability to enforce one or more of our patents; injunctions; monetary damages, fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers or other component suppliers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any revenues under such agreements. The renegotiation of license agreements could result in terms that are less favorable to us than existing terms, or lead to arbitration or litigation to resolve the licensing terms, which could also be less favorable to us than existing terms, and each of which could take months or years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. The occurrence of any of the above could have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies. Further, depending on the breadth and severity of the circumstances above, we may have to reduce, suspend or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted.

[0000804328-24-000056:mdna:248]
[same as prior period, unchanged from 0000804328-24-000039:mdna:247]

[0000804328-24-000056:mdna:249]
[same as prior period, unchanged from 0000804328-24-000039:mdna:248]

[0000804328-24-000056:mdna:250]
[same as prior period, unchanged from 0000804328-24-000039:mdna:249]

[0000804328-24-000056:mdna:251]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on our customers and licensees to develop devices and services based on these technologies to drive consumer demand for such devices, and to establish the selling prices for such devices (which impact the amount of royalties we receive for certain devices). Further, the timing of our shipments of our products is dependent on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third

[0000804328-24-000056:mdna:252]
parties to incorporate these technologies into new device types and into industries and applications beyond mobile handsets, such as automotive and IoT, among others. Commercial deployments of 5G networks and devices have begun and are expected to continue for the foreseeable future. However, the timing and scale of certain such deployments were delayed due to the COVID-19 pandemic, and future deployments may similarly be delayed for reasons that are beyond our control.

[0000804328-24-000056:mdna:253]
[same as prior period, unchanged from 0000804328-24-000039:mdna:251]

[0000804328-24-000056:mdna:254]
[same as prior period, unchanged from 0000804328-24-000039:mdna:252]

[0000804328-24-000056:mdna:255]
[same as prior period, unchanged from 0000804328-24-000039:mdna:253]

[0000804328-24-000056:mdna:256]
[same as prior period, unchanged from 0000804328-24-000039:mdna:254]

[0000804328-24-000056:mdna:257]
[same as prior period, unchanged from 0000804328-24-000039:mdna:255]

[0000804328-24-000056:mdna:258]
[same as prior period, unchanged from 0000804328-24-000039:mdna:256]

[0000804328-24-000056:mdna:259]
[same as prior period, unchanged from 0000804328-24-000039:mdna:257]

[0000804328-24-000056:mdna:260]
[same as prior period, unchanged from 0000804328-24-000039:mdna:258]

[0000804328-24-000056:mdna:261]
[same as prior period, unchanged from 0000804328-24-000039:mdna:259]

[0000804328-24-000056:mdna:262]
[same as prior period, unchanged from 0000804328-24-000039:mdna:260]

[0000804328-24-000056:mdna:263]
[same as prior period, unchanged from 0000804328-24-000039:mdna:261]

[0000804328-24-000056:mdna:264]
[same as prior period, unchanged from 0000804328-24-000039:mdna:262]

[0000804328-24-000056:mdna:265]
[same as prior period, unchanged from 0000804328-24-000039:mdna:263]

[0000804328-24-000056:mdna:266]
[same as prior period, unchanged from 0000804328-24-000039:mdna:265]

[0000804328-24-000056:mdna:267]
[same as prior period, unchanged from 0000804328-24-000039:mdna:266]

[0000804328-24-000056:mdna:268]
[same as prior period, unchanged from 0000804328-24-000039:mdna:267]

[0000804328-24-000056:mdna:269]
[same as prior period, unchanged from 0000804328-24-000039:mdna:268]

[0000804328-24-000056:mdna:270]
[same as prior period, unchanged from 0000804328-24-000039:mdna:269]

[0000804328-24-000056:mdna:271]
[same as prior period, unchanged from 0000804328-24-000039:mdna:270]

[0000804328-24-000056:mdna:272]
[same as prior period, unchanged from 0000804328-24-000039:mdna:271]

[0000804328-24-000056:mdna:273]
Competition in any or all product areas or device tiers may result in the loss of business or customers, which would negatively impact our business, revenues, results of operations, cash flows and financial condition. Such competition may also reduce average selling prices for our chipset products or the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging regions and China where competitors may have lower cost structures or may have a willingness and ability to accept lower prices or lower margins on their products. Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in

[0000804328-24-000056:mdna:274]
the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0000804328-24-000056:mdna:275]
[same as prior period, unchanged from 0000804328-24-000039:mdna:273]

[0000804328-24-000056:mdna:276]
[same as prior period, unchanged from 0000804328-24-000039:mdna:274]

[0000804328-24-000056:mdna:277]
[same as prior period, unchanged from 0000804328-24-000039:mdna:275]

[0000804328-24-000056:mdna:278]
[same as prior period, unchanged from 0000804328-24-000039:mdna:276]

[0000804328-24-000056:mdna:279]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, meet certain regulatory or industry standards (including product safety and information security standards, which may differ by region, geography and industry, and which are particularly stringent in the automotive industry), or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and the end users of such devices, and potentially to our customers’ IT infrastructure. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products or participating in customer recalls (for example, in the automotive industry), repairing or replacing defective products, writing down defective inventory or indemnification obligations under our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, and losses on unfavorable purchase commitments. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products.

[0000804328-24-000056:mdna:280]
In addition, the occurrence of defects, errors or security vulnerabilities may give rise to product liability claims, particularly if such defects, errors or security vulnerabilities in our products or the technology we use, or the products into which they are integrated, result in personal injury or death, and could result in significant costs, expenses and losses. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the attention of our technical and management personnel and harm our business, even if we are successful. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. We may also be required to indemnify and/or defend our customers from product liability claims relating to our products. Further, our

[0000804328-24-000056:mdna:281]
business liability insurance may be inadequate, may not cover the claims, and future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as: automobiles, including ADAS/AD functions; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and XR for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0000804328-24-000056:mdna:282]
[same as prior period, unchanged from 0000804328-24-000039:mdna:281]

[0000804328-24-000056:mdna:283]
[same as prior period, unchanged from 0000804328-24-000039:mdna:282]

[0000804328-24-000056:mdna:284]
[same as prior period, unchanged from 0000804328-24-000039:mdna:283]

[0000804328-24-000056:mdna:285]
[same as prior period, unchanged from 0000804328-24-000039:mdna:284]

[0000804328-24-000056:mdna:286]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. We cannot predict with certainty the long-term effects of any potential changes. In the United States, Europe (including the United Kingdom), India, China and elsewhere, there is continued discussion regarding potential patent law changes, and there is current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. Some proposed changes would apply to only standard-essential patents, and such changes may substantially alter the incentives to participate in standardization or develop standards-compliant products. See also the Risk Factor entitled “Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.”

[0000804328-24-000056:mdna:287]
[same as prior period, unchanged from 0000804328-24-000039:mdna:286]

[0000804328-24-000056:mdna:288]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies or political actions of governments, including trade protection and national security policies; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business or the pricing and integration of additional features and functionality into our chipset products. See also the Risk Factors titled “Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.”

[0000804328-24-000056:mdna:289]
43

[0000804328-24-000056:mdna:290]
We have engaged in litigation and arbitration in the past, are currently engaged in litigation, and may need to further litigate or arbitrate in the future to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Actions we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0000804328-24-000056:mdna:291]
[same as prior period, unchanged from 0000804328-24-000039:mdna:291]

[0000804328-24-000056:mdna:292]
[same as prior period, unchanged from 0000804328-24-000039:mdna:292]

[0000804328-24-000056:mdna:293]
[same as prior period, unchanged from 0000804328-24-000039:mdna:293]

[0000804328-24-000056:mdna:294]
From time to time, companies have asserted, and may again assert, patent, copyright or other intellectual property claims against us relating to our technologies or products, including those we have acquired from other companies. These claims have resulted and may again result in our involvement in litigation, and we are currently involved in such litigation, including certain matters described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products were found to infringe another company’s intellectual property, we could be subject to an injunction or be required to redesign our products, or to license such intellectual property or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products, license such intellectual property used in our products or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling our products. Similarly, our suppliers could be found to infringe another company’s intellectual property, and such suppliers could then be enjoined from providing products or services to us.

[0000804328-24-000056:mdna:295]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products sold by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel and/or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0000804328-24-000056:mdna:296]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or

[0000804328-24-000056:mdna:297]
modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing corresponding declines in our chipset or licensing revenues.

[0000804328-24-000056:mdna:298]
[same as prior period, unchanged from 0000804328-24-000039:mdna:298]

[0000804328-24-000056:mdna:299]
[same as prior period, unchanged from 0000804328-24-000039:mdna:299]

[0000804328-24-000056:mdna:300]
[same as prior period, unchanged from 0000804328-24-000039:mdna:300]

[0000804328-24-000056:mdna:301]
[same as prior period, unchanged from 0000804328-24-000039:mdna:301]

[0000804328-24-000056:mdna:302]
The semiconductor industry is highly cyclical, volatile, subject to downturns and characterized by constant and rapid technological change, price erosion, evolving technical standards, frequent new product introductions, short product life cycles and fluctuations in product supply and demand. Periods of downturns have been characterized by diminished demand for end-user products, high inventory levels, excess or obsolete inventory adjustments or reserves, underutilization of manufacturing capacity, changes in revenue mix and erosion of average selling prices. During such downturns, our revenues have declined, and our results of operations and financial condition have been adversely impacted. We expect our business to continue to be subject to such cyclical downturns. In addition, we are currently seeing and expect to continue to see elevated inventory levels at certain of our IoT customers (primarily in edge networking), negatively impacting the volume of chipsets they purchase from us until such inventory is depleted.

[0000804328-24-000056:mdna:303]
[same as prior period, unchanged from 0000804328-24-000039:mdna:303]

[0000804328-24-000056:mdna:304]
Our stock price and financial results have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and our financial results include those identified above and throughout this Risk Factors section, as well as: volatility of the stock market in general and technology and semiconductor

[0000804328-24-000056:mdna:305]
companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees, including any announcement concerning the initiation of, or any developments in, any lawsuit or governmental investigation or proceeding against us; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0000804328-24-000056:mdna:306]
[same as prior period, unchanged from 0000804328-24-000039:mdna:306]

[0000804328-24-000056:mdna:307]
[same as prior period, unchanged from 0000804328-24-000039:mdna:307]

[0000804328-24-000056:mdna:308]
[same as prior period, unchanged from 0000804328-24-000039:mdna:308]

[0000804328-24-000056:mdna:309]
Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). These include, among others, Regulations related to: patent licensing practices; antitrust, competition and competitive business practices; the flow of funds out of certain countries (e.g., China); cybersecurity; privacy and data protection; imports and exports, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; protection of intellectual property; trade and trade protection including tariffs; foreign policy and national security; environmental protection (including climate change), health and safety; supply chain, responsible sourcing, including the use of conflict minerals, and human rights; spectrum availability and license issuance; adoption of standards; taxation; labor, employment and human capital; corporate governance; public disclosure and reporting (including reporting of ESG-related data); automotive industry safety and quality standards; AI technologies; and business conduct. Compliance with, or changes in the interpretation of, existing Regulations, the adoption of new Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, among others, could have an adverse effect on our business and results of operations. See also the Risk Factors titled “Our business may suffer as a result of adverse rulings in

[0000804328-24-000056:mdna:310]
46

[0000804328-24-000056:mdna:311]
governmental investigations or proceedings or other legal proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises, geopolitical conflicts and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

[0000804328-24-000056:mdna:312]
[same as prior period, unchanged from 0000804328-24-000039:mdna:312]

[0000804328-24-000056:mdna:313]
[same as prior period, unchanged from 0000804328-24-000039:mdna:313]

[0000804328-24-000056:mdna:314]
[same as prior period, unchanged from 0000804328-24-000039:mdna:314]

[0000804328-24-000056:mdna:315]
[same as prior period, unchanged from 0000804328-24-000039:mdna:315]

[0000804328-24-000056:mdna:316]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed, as well as countries where we own intellectual property. The final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0000804328-24-000056:mdna:317]
[same as prior period, unchanged from 0000804328-24-000039:mdna:317]

[0000804328-24-000056:mdna:318]
Further changes in the tax laws of foreign jurisdictions could arise as a result of the base erosion and profit shifting (BEPS) project that was undertaken by the Organization for Economic Co-operation and Development (OECD). The OECD, which represents a coalition of member countries, has made certain changes and is recommending additional changes to

[0000804328-24-000056:mdna:319]
47

[0000804328-24-000056:mdna:320]
numerous long-standing tax principles. These changes, if and as adopted by countries, may increase tax uncertainty and may adversely affect our provision for income taxes, results of operations and cash flows.
