# QCOM MD&A — 0001234452-17-000077


## mdna

[0001234452-17-000077:mdna:1]
[same as prior period, unchanged from 0001234452-17-000028:mdna:1]

[0001234452-17-000077:mdna:2]
[same as prior period, unchanged from 0001234452-17-000028:mdna:2]

[0001234452-17-000077:mdna:3]
This Quarterly Report (including, but not limited to, this section regarding Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements, including, but not limited to, statements regarding industry trends and dynamics; challenges and opportunities related to our semiconductor and licensing businesses; our proposed acquisition of NXP Semiconductors N.V.; current and future legal proceedings or actions of governmental or quasi governmental bodies or standards or industry organizations; and our future business, investments, financial condition, results of operations and prospects. Additionally, statements concerning other future matters, such as the development of new products, enhancements of technologies, industry or regional trends, consumer demand, sales or price levels, challenges to our business and/or business model, capital expenditures, investments in research and development, strategic investments and acquisitions and other statements regarding matters that are not historical, are forward-looking statements. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001234452-17-000077:mdna:4]
[same as prior period, unchanged from 0001234452-17-000028:mdna:4]

[0001234452-17-000077:mdna:5]
Revenues for the second quarter of fiscal 2017 were $5.0 billion, a decrease of 10% compared to the year ago quarter, with net income attributable to Qualcomm of $0.7 billion, a decrease of 36% compared to the year ago quarter.

[0001234452-17-000077:mdna:6]
| • | We shipped approximately 179 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, a decrease of 5% compared to approximately 189 million MSM integrated circuits in the year ago quarter. Despite the decline in MSM shipments, QCT’s revenues increased compared to the year ago quarter primarily due to an increase in revenues related to other products, primarily connectivity shipments, and the net impact of higher margin product mix and lower average selling prices. |

[0001234452-17-000077:mdna:7]
| • | Total reported device sales were approximately $82.6 billion, an increase of approximately 18% compared to approximately $70.1 billion in the year ago quarter.(1) QTL’s revenues increased by 5% compared to the prior year quarter primarily due to an increase in reported sales of CDMA-based products (including multimode products that also implement OFDMA), partially offset by a decrease in revenues per reported unit. The decrease in revenues per reported unit was primarily attributable to licensing revenues recorded in the second quarter of fiscal 2016 due to the termination of an infrastructure license agreement resulting from the merger of two licensees, partially offset by recognition of royalty revenues associated with devices sold in prior periods and the deferral of royalty revenues due to an arbitration with LG Electronics, Inc. in the second quarter of fiscal 2016. Further, QTL revenues and EBT in the second quarter of fiscal 2017 were negatively impacted by an estimated amount greater than $150 million due to a dispute with a licensee who underreported its royalties. Apple’s contract manufacturers reported, but underpaid, royalties in the second quarter of fiscal 2017. However, our revenues were not negatively impacted as the contract manufacturers acknowledged the amounts are due and the underpayment was approximately equal to unpaid amounts under our Business Cooperation and Patent Agreement with Apple that are currently in dispute. Revenues also continued to be impacted negatively by units that we believe are not being reported by certain other licensees and sales of certain unlicensed products. |

[0001234452-17-000077:mdna:8]
| • | On April 11, 2017, a three-judge panel under the rules of the Judicial Arbitration and Mediation Services in San Diego, California provided its decision, finding that we must pay to BlackBerry $815 million, plus interest at a rate |

[0001234452-17-000077:mdna:9]
of 10% from June 2015. The decision was limited to prepayment provisions unique to BlackBerry’s license agreement with the Company and has no impact on agreements with any other licensee. The decision is binding and is not subject to appeal. BlackBerry is also entitled to recover its reasonable attorneys’ fees to be determined by the panel. As a result, we recorded a reduction to licensing revenues of $974 million in the second quarter of fiscal 2017.

[0001234452-17-000077:mdna:10]
| • | On December 27, 2016, the Korea Fair Trade Commission (KFTC) announced that it had reached a decision in its investigation of us, finding that we violated provisions of the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On January 22, 2017, we received the KFTC’s formal written decision. The KFTC ordered certain remedial actions and imposed a fine of approximately 1.03 trillion Korean Won (approximately $921 million based on exchange rates at March 26, 2017), which was recorded in other expenses in the first six months of fiscal 2017. We believe that our business practices do not violate the MRFTA. On February 21, 2017, we filed an action to cancel the KFTC’s decision and an application to stay the decision’s remedial order with the Seoul High Court. |

[0001234452-17-000077:mdna:11]
| • | On February 3, 2017, we completed the formation of our joint venture with TDK Corporation (TDK), under the name RF360 Holdings Singapore Pte. Ltd. (RF360 Holdings), to enable delivery of radio frequency front-end (RFFE) modules and radio frequency (RF) filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others. The joint venture is initially owned 51% by Qualcomm Global Trading Pte. Ltd. (Qualcomm Global Trading), a Singapore corporation and wholly-owned subsidiary of ours, and 49% by EPCOS AG (EPCOS), a German wholly-owned subsidiary of TDK. Certain intellectual property, patents and filter and module design and manufacturing assets were carved out of existing TDK businesses and are owned by the joint venture, and certain assets were acquired directly by affiliates of ours. The total purchase price was $3.1 billion. RF360 Holdings, which was included in our QCT segment, is a Singapore corporation with research and development and manufacturing and/or sales locations in the United States, Europe and Asia and its headquarters in Munich, Germany. |

[0001234452-17-000077:mdna:12]
Against this backdrop, the following recent developments occurred in the second quarter of fiscal 2017 with respect to key elements of our industry:

[0001234452-17-000077:mdna:13]
| • | Worldwide cellular connections grew sequentially by approximately 1% to reach approximately 7.6 billion.(2) |

[0001234452-17-000077:mdna:14]
| • | Worldwide 3G/4G connections (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) grew sequentially by approximately 4% to approximately 4.4 billion, which was approximately 57% of total cellular connections.(2) |

[0001234452-17-000077:mdna:15]
[same as prior period, unchanged from 0001234452-17-000028:mdna:13]

[0001234452-17-000077:mdna:16]
| (2) | According to GSMA Intelligence estimates as of April 17, 2017 for the quarter ended March 31, 2017. |

[0001234452-17-000077:mdna:17]
[same as prior period, unchanged from 0001234452-17-000028:mdna:15]

[0001234452-17-000077:mdna:18]
[same as prior period, unchanged from 0001234452-17-000028:mdna:16]

[0001234452-17-000077:mdna:19]
[same as prior period, unchanged from 0001234452-17-000028:mdna:17]

[0001234452-17-000077:mdna:20]
QCT is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in wireless voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products are sold and its system software is licensed to manufacturers

[0001234452-17-000077:mdna:21]
28

[0001234452-17-000077:mdna:22]
that use our products in mobile devices, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards and infrastructure equipment, broadband gateway equipment and other consumer electronic devices. Our MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Snapdragon processors and LTE modems, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon processors provide advanced application and graphics processing capabilities. Through our joint venture with TDK, RF360 Holdings, QCT also offers an expanded portfolio of radio frequency front-end products, which complements its current product offerings for mobile devices and IoT applications. QCT’s system software helps enable the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits.

[0001234452-17-000077:mdna:23]
QCT primarily utilizes a fabless production model, which means that we generally do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Integrated circuits are die cut from silicon wafers that have completed the package assembly and test manufacturing processes. Other than the recent joint venture of RF360 Holdings, which uses certain internal fabrication facilities to manufacture RFFE modules and RF filter acoustic products, we primarily rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits based primarily on our proprietary designs and test programs. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Turnkey is when our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services, such as wafer bump, probe, assembly and the majority of our final test requirements. The manufacturing operations of RF360 Holdings consist of front-end and back-end processes. The front-end processes primarily take place at manufacturing facilities located in Germany and Singapore and involve the imprinting of substrate silicon wafers with the circuitry required for semiconductors to function (also known as wafer fabrication). The back-end processes involve the assembly, packaging and test of semiconductors to prepare RFFE modules and RF filter acoustic products for distribution. Our back-end manufacturing facilities are located in China and Singapore.

[0001234452-17-000077:mdna:24]
QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD and/or LTE standards and their derivatives. We have historically licensed our cellular standard-essential patents together with other Qualcomm patents that may be useful to such licensed products because licensees typically have desired to obtain the commercial benefits of receiving such broad patent rights from us. However, we also have licensed only our cellular standard-essential patents to certain licensees who have requested such licenses. In addition, in connection with our resolution with the China National Development and Reform Commission (NDRC) in China, our practice in China since 2015 is to offer licenses to our 3G and 4G standard-essential Chinese patents for devices sold for use in China separately from licenses to our other patents.

[0001234452-17-000077:mdna:25]
QTL licensing revenues include license fees and royalties based on sales by licensees of products incorporating or using our intellectual property. License fees are fixed amounts paid in one or more installments. Royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit running royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops, which in general, effectively provide for a maximum running royalty amount per device. QTL recognizes royalty revenues based on royalties reported by licensees and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. The vast majority of QTL revenues were generated through our licensees’ sales of CDMA2000- and WCDMA-based products, such as feature phones and smartphones.

[0001234452-17-000077:mdna:26]
[same as prior period, unchanged from 0001234452-17-000028:mdna:23]

[0001234452-17-000077:mdna:27]
[same as prior period, unchanged from 0001234452-17-000028:mdna:24]

[0001234452-17-000077:mdna:28]
Seasonality. Many of our products and/or intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has tended historically to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons; and because QTL recognizes royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made in the fourth calendar quarter. We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 3G/4G networks by wireless operators and the timing of launches of flagship wireless devices that incorporate our products and/or intellectual property. These trends may or may not continue in the future.

[0001234452-17-000077:mdna:29]
[same as prior period, unchanged from 0001234452-17-000028:mdna:26]

[0001234452-17-000077:mdna:30]
[same as prior period, unchanged from 0001234452-17-000028:mdna:27]

[0001234452-17-000077:mdna:31]
| • | On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings, B.V., an indirect, wholly owned subsidiary of QUALCOMM Incorporated, will acquire NXP Semiconductors N.V. Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration of $38 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products. The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions, including the tender of at least 80% of the issued and outstanding common shares of NXP in the offer (provided that the minimum tender threshold may be reduced to a percentage not less than 70% with the prior written consent of NXP). In addition, the waiting period under the Hart-Scott-Rodino Antitrust Improvements Act of 1976 in the United States, as amended, expired on April 3, 2017. The tender offer is not subject to any financing condition; however, we intend to fund the transaction with cash held by foreign entities and new debt. We expect that this acquisition will require us to devote significant resources and management time and attention prior to close, take on significant debt and utilize a substantial portion of our cash, cash equivalents and marketable securities. |

[0001234452-17-000077:mdna:32]
| • | Regulatory authorities in certain jurisdictions continue to investigate our business practices, and other regulatory authorities may do so in the future. An unfavorable resolution of one or more of these matters could have a material adverse effect on our business with remedies that include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Additionally, certain of our direct and indirect customers and licensees, including Apple Inc., have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, including monetary damages. These activities may also require the investment of significant management time and attention and may result in increased legal costs. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” elsewhere in this Quarterly Report. |

[0001234452-17-000077:mdna:33]
| • | We continue to believe that certain licensees, particularly in China, are not fully complying with their contractual obligations to report their sales of licensed products to us, and certain companies, including unlicensed companies, particularly in emerging regions, including China, are delaying execution of new license agreements. We have made substantial progress in reaching agreements with many companies, primarily in China. However, negotiations with certain licensees and unlicensed companies are ongoing. We believe that the conclusion of new agreements with these companies will result in improved reporting by these licensees, including with respect to sales of three-mode devices (i.e., devices that implement GSM, TD-SCDMA and LTE-TDD) sold in China. Additionally, we believe our increased efforts in the areas of compliance will also improve reporting, but will also result in increased costs to the business. Further, QTL revenues and EBT in the second quarter of fiscal 2017 were negatively impacted by an estimated amount greater than $150 million due to a dispute with a licensee who underreported its royalties. That licensee may continue to underreport its royalties in the future until the dispute is resolved. Similarly, while most of Apple’s contract manufacturers have reported royalties for sales made during the March quarter, it is not clear whether Apple’s contract manufacturers will continue to underpay royalties owed under their contracts with us in the future. These matters could have a negative impact on our future royalty revenues, as well as our financial condition, results of operations and cash flows. Litigation and/or other actions may be necessary to compel licensees to report |

[0001234452-17-000077:mdna:34]
30

[0001234452-17-000077:mdna:35]
and pay the required royalties for sales they have not previously reported and/or to compel unlicensed companies to execute licenses.

[0001234452-17-000077:mdna:36]
| • | Further, we expect our business, particularly QCT, to continue to be impacted by industry dynamics, including: |

[0001234452-17-000077:mdna:37]
[same as prior period, unchanged from 0001234452-17-000028:mdna:31]

[0001234452-17-000077:mdna:38]
[same as prior period, unchanged from 0001234452-17-000028:mdna:32]

[0001234452-17-000077:mdna:39]
[same as prior period, unchanged from 0001234452-17-000028:mdna:34]

[0001234452-17-000077:mdna:40]
[same as prior period, unchanged from 0001234452-17-000028:mdna:35]

[0001234452-17-000077:mdna:41]
[same as prior period, unchanged from 0001234452-17-000028:mdna:29]

[0001234452-17-000077:mdna:42]
[same as prior period, unchanged from 0001234452-17-000028:mdna:38]

[0001234452-17-000077:mdna:43]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless value chain and governments as to the benefits of our business model and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not welcome the success of our business model in enabling new, highly cost-effective competitors to their products. We expect that such companies, and/or governments or regulators, will continue to challenge our business model in various forums throughout the world.

[0001234452-17-000077:mdna:44]
[same as prior period, unchanged from 0001234452-17-000028:mdna:42]

[0001234452-17-000077:mdna:45]
[same as prior period, unchanged from 0001234452-17-000028:mdna:43]

[0001234452-17-000077:mdna:46]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | Change |  | March 26, 2017 |  | March 27, 2016 |  | Change |
| Equipment and services | $ | 3,689 |  |  | $ | 3,349 |  |  | $ | 340 |  |  | $ | 7,828 |  |  | $ | 7,436 |  |  | $ | 392 |  |
| Licensing | 1,327 |  |  | 2,202 |  |  | (875 | ) |  | 3,187 |  |  | 3,890 |  |  | (703 | ) |
|  | $ | 5,016 |  |  | $ | 5,551 |  |  | $ | (535 | ) |  | $ | 11,015 |  |  | $ | 11,326 |  |  | $ | (311 | ) |

[0001234452-17-000077:mdna:47]
The increases in equipment and services revenues in the second quarter and first six months of fiscal 2017 were primarily due to increases in QCT revenues. In the second quarter of fiscal 2017, we recorded a reduction to licensing revenues of $974 million related to the BlackBerry arbitration decision. Excluding this reduction, licensing revenues increased by $99 million and $271 million in the second quarter and first six months of fiscal 2017, respectively, primarily due to increases in QTL revenues.

[0001234452-17-000077:mdna:48]
| Costs and Expenses (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | Change |  | March 26, 2017 |  | March 27, 2016 |  | Change |
| Cost of revenues | $ | 2,208 |  |  | $ | 2,141 |  |  | $ | 67 |  |  | $ | 4,651 |  |  | $ | 4,675 |  |  | $ | (24 | ) |
| Gross margin | 56 | % |  | 61 | % |  |  |  | 58 | % |  | 59 | % |  |  |

[0001234452-17-000077:mdna:49]
Excluding the reduction to licensing revenues related to the BlackBerry arbitration decision, margin percentage increased in the second quarter of fiscal 2017 primarily due to an increase in QCT margin percentage, and margin percentage increased in the first six months of fiscal 2017 primarily due to the impact of higher-margin segment mix primarily related to QTL, an increase in QCT margin percentage and a decrease of $55 million in charges related to the recognition of the step-up of inventories to fair value and the amortization of intangible assets primarily related to the acquisition of CSR plc in the fourth quarter of fiscal 2015. Our margin percentage may fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors.

[0001234452-17-000077:mdna:50]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | Change |  | March 26, 2017 |  | March 27, 2016 |  | Change |
| Research and development | $ | 1,386 |  |  | $ | 1,301 |  |  | $ | 85 |  |  | $ | 2,697 |  |  | $ | 2,653 |  |  | $ | 44 |  |
| % of revenues | 28 | % |  | 23 | % |  |  |  | 24 | % |  | 23 | % |  |  |
| Selling, general, and administrative | $ | 615 |  |  | $ | 619 |  |  | $ | (4 | ) |  | $ | 1,206 |  |  | $ | 1,198 |  |  | $ | 8 |  |
| % of revenues | 12 | % |  | 11 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| Other | $ | 78 |  |  | $ | 75 |  |  | $ | 3 |  |  | $ | 954 |  |  | $ | (299 | ) |  | $ | 1,253 |  |

[0001234452-17-000077:mdna:51]
The dollar increases in research and development expenses in the second quarter and first six months of fiscal 2017 were primarily attributable to increases of $85 million and $30 million, respectively, in costs related to the development of integrated circuit technologies and related software products, partially offset by cost decreases driven by actions initiated under our Strategic Realignment Plan, which was substantially implemented in fiscal 2016. The increase for the first six months of fiscal 2017 also included a $30 million impairment charge on certain intangible assets recorded in the first quarter of fiscal 2017.

[0001234452-17-000077:mdna:52]
The dollar decrease in selling, general and administrative expenses in the second quarter of fiscal 2017 was primarily attributable to decreases of $17 million in depreciation and amortization expense and $5 million in selling and marketing expenses, offset by an increase of $28 million in professional services fees primarily related to third-party acquisition and integration services. The dollar increase in selling, general and administrative expenses in the first six months of fiscal 2017 was primarily attributable to increases of $56 million in professional services fees, primarily related to third-party acquisition and integration services, and $10 million in costs related to litigation and other legal matters, partially offset by decreases of $32 million in depreciation and amortization expense and $20 million in selling and marketing expenses.

[0001234452-17-000077:mdna:53]
Other expenses in the second quarter of fiscal 2017 consisted of $53 million in foreign currency losses related to the fine imposed by the KFTC, which was accrued in the first quarter of fiscal 2017, and $25 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan. Other expenses in the first six months of fiscal 2017 consisted of a $921 million charge related to the KFTC fine, including related foreign currency losses, and $33 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan.

[0001234452-17-000077:mdna:54]
Other expenses in the second quarter of fiscal 2016 were attributable to $75 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan. Other income in the first six months of fiscal 2016 was primarily attributable to a $380 million gain on the sale of wireless spectrum, partially offset by net charges related to our Strategic Realignment Plan, which included $129 million in restructuring and restructuring-related charges, partially offset by a $48

[0001234452-17-000077:mdna:55]
32

[0001234452-17-000077:mdna:56]
million gain on the sale of our business that provided augmented reality applications.

[0001234452-17-000077:mdna:57]
| Interest Expense and Net Investment Income (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | Change |  | March 26, 2017 |  | March 27, 2016 |  | Change |
| Interest expense | $ | 107 |  |  | $ | 72 |  |  | $ | 35 |  |  | $ | 197 |  |  | $ | 145 |  |  | $ | 52 |  |
| Investment income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 153 |  |  | $ | 158 |  |  | $ | (5 | ) |  | $ | 320 |  |  | $ | 295 |  |  | $ | 25 |  |
| Net realized gains on marketable securities | 67 |  |  | 1 |  |  | 66 |  |  | 206 |  |  | 43 |  |  | 163 |  |
| Net realized gains on other investments | 21 |  |  | 23 |  |  | (2 | ) |  | 30 |  |  | 30 |  |  | — |  |
| Impairment losses on marketable securities and other investments | (5 | ) |  | (43 | ) |  | 38 |  |  | (148 | ) |  | (106 | ) |  | (42 | ) |
| Equity in net losses of investees | (14 | ) |  | (11 | ) |  | (3 | ) |  | (11 | ) |  | (31 | ) |  | 20 |  |
| Net gains (losses) on derivative instruments | 13 |  |  | (1 | ) |  | 14 |  |  | 20 |  |  | (5 | ) |  | 25 |  |
|  | $ | 235 |  |  | $ | 127 |  |  | $ | 108 |  |  | $ | 417 |  |  | $ | 226 |  |  | $ | 191 |  |

[0001234452-17-000077:mdna:58]
The increases in net realized gains on marketable securities in the second quarter and first six months of fiscal 2017 were primarily attributable to certain marketable securities that we sold to fund, in part, our proposed acquisition of NXP Semiconductors N.V.

[0001234452-17-000077:mdna:59]
| Income Tax Expense (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | Change |  | March 26, 2017 |  | March 27, 2016 |  | Change |
| Income tax expense | $ | 108 |  |  | $ | 306 |  |  | $ | (198 | ) |  | $ | 296 |  |  | $ | 520 |  |  | $ | (224 | ) |
| Effective tax rate | 13 | % |  | 21 | % |  | (8 | %) |  | 17 | % |  | 16 | % |  | 1 | % |

[0001234452-17-000077:mdna:60]
The following table summarizes the primary factors that caused our effective tax rates for the second quarter and first six months of fiscal 2017 and 2016 to be less than the United States federal statutory rate:

[0001234452-17-000077:mdna:61]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | March 26, 2017 |  | March 27, 2016 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |  | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (25 | %) |  | (14 | %) |  | (20 | %) |  | (16 | %) |
| Benefits related to the research and development tax credit | (2 | %) |  | (1 | %) |  | (2 | %) |  | (4 | %) |
| Nondeductible charge related to the KFTC investigation | 3 | % |  | — |  |  | 3 | % |  | — |  |
| Other | 2 | % |  | 1 | % |  | 1 | % |  | 1 | % |
| Effective tax rate | 13 | % |  | 21 | % |  | 17 | % |  | 16 | % |

[0001234452-17-000077:mdna:62]
[same as prior period, unchanged from 0001234452-17-000028:mdna:132]

[0001234452-17-000077:mdna:63]
The effective tax rate of 13% for the second quarter of fiscal 2017 was less than the estimated annual effective tax rate of 17% primarily resulting from the reduction to our United States revenues related to the BlackBerry arbitration decision. The estimated annual effective tax rate of 17% for fiscal 2017 is equal to the 17% effective income tax rate for fiscal 2016. In the first six months of fiscal 2017, we recorded a $921 million charge related to the KFTC imposed fine, which is not deductible for tax purposes and is attributable to both the United States and a foreign jurisdiction. The estimated annual effective tax rate of 17% for fiscal 2017 also reflects the increase in our Singapore tax rate as a result of the expiration of its tax exemption in March 2017, which is partially offset by tax benefits resulting from the increase in our Singapore tax rate that will be in effect when certain deferred tax assets are scheduled to reverse. The annual effective tax rate of 17% for fiscal 2016 reflected a $101 million tax benefit recorded discretely in the third quarter of fiscal 2016 resulting from a worthless stock deduction on a domestic subsidiary of one of our former display businesses and a $79 million benefit recorded discretely in the first quarter of fiscal 2016 related to fiscal 2015 resulting from the retroactive and permanent reinstatement of the United States federal research and development tax credit.

[0001234452-17-000077:mdna:64]
Unrecognized tax benefits were $279 million and $271 million at March 26, 2017 and September 25, 2016, respectively. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at March 26, 2017 may increase or decrease in the next 12 months.

[0001234452-17-000077:mdna:65]
[same as prior period, unchanged from 0001234452-17-000028:mdna:60]

[0001234452-17-000077:mdna:66]
The following should be read in conjunction with the financial results for the second quarter and first six months of fiscal 2017 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0001234452-17-000077:mdna:67]
| (in millions) | QCT |  | QTL |  | QSI |
| Three Months Ended March 26, 2017 |  |  |  |  |  |
| Revenues | $ | 3,676 |  |  | $ | 2,249 |  |  | $ | — |  |
| EBT (1) | 475 |  |  | 1,959 |  |  | — |  |
| EBT as a % of revenues | 13 | % |  | 87 | % |  |  |  |
| Three Months Ended March 27, 2016 |  |  |  |  |  |
| Revenues | $ | 3,337 |  |  | $ | 2,135 |  |  | $ | 12 |  |
| EBT (1) | 170 |  |  | 1,857 |  |  | 46 |  |
| EBT as a % of revenues | 5 | % |  | 87 | % |  |  |
| Six Months Ended March 26, 2017 |  |  |  |  |  |
| Revenues | $ | 7,777 |  |  | $ | 4,060 |  |  | $ | 14 |  |
| EBT (1) | 1,199 |  |  | 3,492 |  |  | (17 | ) |
| EBT as a % of revenues | 15 | % |  | 86 | % |  |  |
| Six Months Ended March 27, 2016 |  |  |  |  |  |
| Revenues | $ | 7,433 |  |  | $ | 3,742 |  |  | $ | 21 |  |
| EBT (1) | 760 |  |  | 3,195 |  |  | 405 |  |
| EBT as a % of revenues | 10 | % |  | 85 | % |  |  |

[0001234452-17-000077:mdna:68]
[same as prior period, unchanged from 0001234452-17-000028:mdna:63]

[0001234452-17-000077:mdna:69]
QCT Segment. QCT results of operations in the second quarter and first six months of fiscal 2017 were impacted by growth within adjacent industry segments outside traditional cellular industries and cost reduction initiatives achieved under the Strategic Realignment Plan, partially offset by a decline in share at a large customer. Results of operations in the first six months of fiscal 2017 were also impacted by higher demand in China. Approximately 179 million and 189 million MSM integrated circuits were sold in the second quarter of fiscal 2017 and 2016, respectively, and approximately 397 million and 430 million MSM integrated circuits were sold in the first six months of fiscal 2017 and 2016, respectively. Despite the decline in MSM shipments, QCT revenues in the second quarter and first six months of fiscal 2017 increased primarily due to increases in equipment and services revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying RF, Power Management (PM) and wireless connectivity integrated circuits, were $3.63 billion and $3.28 billion in the second quarter of fiscal 2017 and 2016, respectively and $7.70 billion and $7.30 billion in the first six months of fiscal 2017 and 2016, respectively. The increases in equipment and services revenues in the second quarter and first six months of fiscal 2017 were primarily due to increases of $171 million and $432 million, respectively, resulting from the net impact of higher-priced product mix and lower average selling prices and increases of $309 million and $421 million,

[0001234452-17-000077:mdna:70]
34

[0001234452-17-000077:mdna:71]
respectively, in revenues related to other products, primarily related to higher connectivity shipments and revenues from our recently formed RF360 Holdings joint venture in the second quarter of fiscal 2017, partially offset by a decrease of $128 million and $460 million, respectively, primarily related to lower MSM shipments.

[0001234452-17-000077:mdna:72]
QCT EBT as a percentage of revenues in the second quarter and first six months of fiscal 2017 increased primarily due to increases in gross margin percentage and combined decreases of 3% and 4%, respectively, in research and development and selling, general and administrative expenses. The increases in QCT gross margin percentage resulted primarily from higher-margin product mix and lower average unit costs, partially offset by lower average selling prices and higher excess inventory charges.

[0001234452-17-000077:mdna:73]
QCT accounts receivable increased by 32% in the first six months of fiscal 2017 from $1.46 billion to $1.92 billion, primarily due to the acquisition of receivables in connection with the RF360 Holdings joint venture and the timing of integrated circuit shipments. QCT inventories increased by 33% in the first six months of fiscal 2017 from $1.54 billion to $2.05 billion, primarily due to the acquisition of inventories in connection with the RF360 Holdings joint venture and an increase in the overall quantity of units on hand, partially offset by lower average unit cost.

[0001234452-17-000077:mdna:74]
QTL Segment. The increases in QTL revenues in the second quarter and first six months of fiscal 2017 of $114 million and $318 million, respectively, were primarily attributable to increases in reported sales of CDMA-based products (including multimode products that also implement OFDMA), partially offset by decreases in revenues per reported unit. The decreases in revenues per reported unit were primarily attributable to licensing revenues recorded in the second quarter of fiscal 2016 due to the termination of an infrastructure license agreement resulting from the merger of two licensees, partially offset by recognition of royalty revenues associated with devices sold in prior periods and the deferral of royalty revenues reported by LG Electronics, Inc. in the second quarter of fiscal 2016. The decrease in revenues per reported unit for the first six months of fiscal 2017 also related to a decrease in the recognition of unearned license fees. QTL revenues and EBT in the second quarter and first six months of fiscal 2017 were negatively impacted by an estimated amount greater than $150 million due to a dispute with a licensee who underreported its royalties and may continue to do so in the future until the dispute is resolved. Revenues also continued to be impacted negatively by units that we believe are not being reported by certain other licensees and sales of certain unlicensed products. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing, particularly in emerging regions, including China, and additional litigation may become necessary if negotiations fail to resolve the relevant issues.

[0001234452-17-000077:mdna:75]
QTL accounts receivable increased by more than 100% in the first six months of fiscal 2017 from $644 million to $2.23 billion, primarily due to the short payment of royalties reported by and deemed collectible from certain of our licensees that manufacture products for Apple and the timing of the collection of payments from certain of our other licensees.

[0001234452-17-000077:mdna:76]
QSI Segment. The decrease in QSI EBT in the second quarter of fiscal 2017 was primarily due to a decrease of $29 million in net realized gains on investments and the combined impact of $16 million of lower revenues and higher costs associated with certain development contracts with one of our equity method investees. The decrease in QSI EBT in the first six months of fiscal 2017 was primarily due to the effect of a $380 million gain on the sale of wireless spectrum recorded in the first quarter of fiscal 2016, a decrease of $44 million in net realized gains on investments and the combined impact of $17 million of lower revenues and higher costs associated with certain development contracts with one of our equity method investees, partially offset by a decrease of $18 million in equity losses.

[0001234452-17-000077:mdna:77]
[same as prior period, unchanged from 0001234452-17-000028:mdna:68]

[0001234452-17-000077:mdna:78]
On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings will acquire NXP. Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration of $38 billion. The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions. We intend to fund the transaction with cash held by foreign entities, which will result in the use of a substantial portion of our cash, cash equivalents and marketable securities, as well as new debt, and we secured $11.1 billion in committed financing through a $7.1 billion Bridge Loan Facility and $4.0 billion Term Loan Facility. The Company expects to issue additional debt, including accessing the public debt markets in fiscal 2017, in lieu of drawing on the Bridge Loan Facility at close of the NXP transaction.

[0001234452-17-000077:mdna:79]
Qualcomm River Holdings and NXP may terminate the definitive agreement under certain circumstances. If the definitive agreement is terminated by NXP in certain circumstances, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the definitive agreement is terminated by Qualcomm River Holdings under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion. In November 2016, as required by the definitive agreement, we entered into four letters of credit for an

[0001234452-17-000077:mdna:80]
[same as prior period, unchanged from 0001234452-17-000028:mdna:156]

[0001234452-17-000077:mdna:81]
aggregate amount of $2.0 billion pursuant to which NXP will have the right to draw amounts to fund the potential termination fee payable to NXP. Each letter of credit is required to be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. We are restricted from using the funds deposited as collateral while the letters of credit are outstanding. At March 26, 2017, the letters of credit were fully collateralized through bank time deposits and money market funds.

[0001234452-17-000077:mdna:82]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our employee benefit plans. The following tables present selected financial information related to our liquidity as of March 26, 2017 and September 25, 2016 and for the first six months of fiscal 2017 and 2016 (in millions):

[0001234452-17-000077:mdna:83]
|  | March 26, 2017 |  | September 25, 2016 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 28,858 |  |  | $ | 32,350 |  |  | $ | (3,492 | ) |  | (11 | %) |
| Accounts receivable, net | 4,201 |  |  | 2,219 |  |  | 1,982 |  |  | 89 | % |
| Inventories | 2,066 |  |  | 1,556 |  |  | 510 |  |  | 33 | % |
| Short-term debt | 1,998 |  |  | 1,749 |  |  | 249 |  |  | 14 | % |
| Long-term debt | 9,939 |  |  | 10,008 |  |  | (69 | ) |  | (1 | %) |

[0001234452-17-000077:mdna:84]
|  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | $ Change |  | % Change |
| Net cash provided by operating activities | $ | 2,194 |  |  | $ | 3,476 |  |  | $ | (1,282 | ) |  | (37 | %) |
| Net cash provided (used) by investing activities | 760 |  |  | (1,435 | ) |  | 2,195 |  |  | N/M |  |
| Net cash used by financing activities | (1,770 | ) |  | (3,822 | ) |  | 2,052 |  |  | (54 | %) |

[0001234452-17-000077:mdna:85]
[same as prior period, unchanged from 0001234452-17-000028:mdna:74]

[0001234452-17-000077:mdna:86]
The net decrease in cash, cash equivalents and marketable securities was primarily due to the deposit of $2.0 billion that was used to collateralize the letters of credit related to our proposed acquisition of NXP and recorded as other noncurrent assets, $1.6 billion in cash dividends paid, $1.4 billion in payments to fund acquisitions and other investments, primarily related to the RF360 Holdings joint venture, and $727 million in payments to repurchase shares of our common stock, partially offset by net cash provided by operating activities. Total cash provided by operating activities decreased primarily due to changes in working capital related to an increase in accounts receivable and inventories and the timing of related payments. Our days sales outstanding, on a consolidated basis (excluding the impact of the $974 million reduction to licensing revenues recorded in the second quarter of fiscal 2017 related to the BlackBerry arbitration decision), increased to 61 at March 26, 2017 compared to 33 days at September 25, 2016. The increases in accounts receivable and the related days sales outstanding were primarily due to the short payment of royalties reported by and deemed collectible from certain of our licensees that manufacture products for Apple. The increase in accounts receivable also resulted from the timing of the collection of payments from certain of our other licensees, the acquisition of receivables in connection with the RF360 Holdings joint venture and the timing of integrated circuit shipments. The increase in inventories was primarily due to the acquisition of inventories in connection with the RF360 Holdings joint venture and the overall quantity of units on hand, partially offset by lower average unit cost.

[0001234452-17-000077:mdna:87]
Our cash, cash equivalents and marketable securities at March 26, 2017 consisted of $2.1 billion held by United States-based entities and $26.8 billion held by foreign entities. Most of our cash, cash equivalents and marketable securities held by foreign entities are indefinitely reinvested and would be subject to material tax effects if repatriated. However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate funds held by foreign entities.

[0001234452-17-000077:mdna:88]
[same as prior period, unchanged from 0001234452-17-000028:mdna:77]

[0001234452-17-000077:mdna:89]
| • | Our purchase obligations at March 26, 2017, some of which relate to research and development activities and capital expenditures, totaled $4.0 billion and $1.2 billion for fiscal 2017 and 2018, respectively, and $1.5 billion thereafter. |

[0001234452-17-000077:mdna:90]
36

[0001234452-17-000077:mdna:91]
| • | Our research and development expenditures were $2.7 billion in the first six months of fiscal 2017 and $5.2 billion in fiscal 2016, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications. |

[0001234452-17-000077:mdna:92]
| • | Cash outflows for capital expenditures were $251 million in the first six months of fiscal 2017 and $539 million in fiscal 2016. We anticipate that capital expenditures will be higher in fiscal 2017 as compared to fiscal 2016, primarily due to estimated capital expenditures of approximately $200 million related to the manufacturing operations of our joint venture, RF360 Holdings. We also expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-17-000077:mdna:93]
| • | In connection with the KFTC investigation, we paid a fine of approximately 1.03 trillion Korean Won (approximately $927 million) on March 30, 2017. |

[0001234452-17-000077:mdna:94]
| • | In connection with the BlackBerry arbitration decision, we are obligated to pay to BlackBerry $815 million, plus interest at a rate of 10% from June 2015. BlackBerry is also entitled to recover its reasonable attorneys’ fees to be determined by the arbitration panel. Payment is expected to be made in the second half of fiscal 2017. |

[0001234452-17-000077:mdna:95]
[same as prior period, unchanged from 0001234452-17-000028:mdna:84]

[0001234452-17-000077:mdna:96]
Debt. In November 2016, we amended and restated our existing Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit to increase the aggregate amount available to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. At March 26, 2017, no amounts were outstanding under the Amended and Restated Revolving Credit Facility.

[0001234452-17-000077:mdna:97]
We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At March 26, 2017, we had $2.0 billion of commercial paper outstanding with weighted-average net interest rates of 0.82% and weighted-average remaining days to maturity of 39 days.

[0001234452-17-000077:mdna:98]
In October 2016, we entered into a Bridge Loan Facility that provides for senior unsecured bridge facility loans in an aggregate amount up to $13.6 billion. Subsequently, the commitments available under the Bridge Loan Facility were reduced to $7.1 billion upon us entering into a $4.0 billion Term Loan Facility, described below, and the sale of certain assets by NXP for estimated net cash proceeds of $2.5 billion in February 2017. Proceeds from the Bridge Loan Facility, if drawn, will be used to finance, in part, the proposed acquisition of NXP. At March 26, 2017, no amounts were outstanding under the Bridge Loan Facility.

[0001234452-17-000077:mdna:99]
In November 2016, we entered into a Term Loan Facility that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion. Proceeds from the Term Loan Facility, if drawn, will be used to finance, in part, the proposed acquisition of NXP. At March 26, 2017, no amounts were outstanding under the Term Loan Facility.

[0001234452-17-000077:mdna:100]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, with maturity dates in 2018 through 2045 and effective interest rates between 1.38% and 4.74%. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. In addition to the new debt we expect to issue in connection with our proposed acquisition of NXP, we may also issue debt in the future. The amount and timing of such additional borrowings will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001234452-17-000077:mdna:101]
Additional information regarding our outstanding debt at March 26, 2017 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt.”

[0001234452-17-000077:mdna:102]
Capital Return Program. In the first six months of fiscal 2017, we repurchased and retired 11,488,000 shares of our common stock for $727 million, before commissions. At March 26, 2017, $2.3 billion remained authorized for repurchase under our stock repurchase program. As a result of our proposed acquisition of NXP and the pending use of our cash and marketable securities, we currently expect to repurchase shares in the next few years to offset dilution from the issuance of common stock under our employee benefit plans.

[0001234452-17-000077:mdna:103]
In the first six months of fiscal 2017, we paid cash dividends totaling $1.6 billion, or $1.06 per share. On April 12, 2017, we announced a cash dividend of $0.57 per share on our common stock, payable on June 21, 2017 to stockholders of record

[0001234452-17-000077:mdna:104]
as of the close of business on May 31, 2017. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-17-000077:mdna:105]
[same as prior period, unchanged from 0001234452-17-000028:mdna:93]

[0001234452-17-000077:mdna:106]
[same as prior period, unchanged from 0001234452-17-000028:mdna:94]

[0001234452-17-000077:mdna:107]
Additional information regarding our financial commitments at March 26, 2017 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes,” “Note 5. Debt,” “Note 6. Commitments and Contingencies” and “Note 8. Acquisitions.”

[0001234452-17-000077:mdna:108]
[same as prior period, unchanged from 0001234452-17-000028:mdna:96]

[0001234452-17-000077:mdna:109]
[same as prior period, unchanged from 0001234452-17-000028:mdna:97]

[0001234452-17-000077:mdna:110]
[same as prior period, unchanged from 0001234452-17-000028:mdna:98]

[0001234452-17-000077:mdna:111]
[same as prior period, unchanged from 0001234452-17-000028:mdna:99]

[0001234452-17-000077:mdna:112]
[same as prior period, unchanged from 0001234452-17-000028:mdna:100]

[0001234452-17-000077:mdna:113]
[same as prior period, unchanged from 0001234452-17-000028:mdna:101]

[0001234452-17-000077:mdna:114]
Our and NXP’s obligations to consummate the proposed transaction are subject to the satisfaction or waiver of certain conditions, including, among others: (i) the tender of a minimum number of NXP’s outstanding common shares in the tender offer commenced by a subsidiary of QUALCOMM Incorporated; (ii) the receipt of regulatory clearance under European Union and certain other foreign antitrust laws; (iii) the absence of any law or order prohibiting the proposed transaction; (iv) there being no event that would have a material adverse effect on NXP; (v) the accuracy of the representations and warranties of NXP, subject to certain exceptions, and NXP’s material compliance with its covenants, in the definitive agreement; and (vi) the completion of certain internal reorganization steps with respect to NXP and the disposition of certain non-core assets of NXP. We cannot provide assurance that the conditions to the completion of the proposed transaction will be satisfied in a timely manner or at all, and if the proposed transaction is not completed, we would not realize any of the expected benefits.

[0001234452-17-000077:mdna:115]
[same as prior period, unchanged from 0001234452-17-000028:mdna:104]

[0001234452-17-000077:mdna:116]
[same as prior period, unchanged from 0001234452-17-000028:mdna:105]

[0001234452-17-000077:mdna:117]
[same as prior period, unchanged from 0001234452-17-000028:mdna:106]

[0001234452-17-000077:mdna:118]
[same as prior period, unchanged from 0001234452-17-000028:mdna:107]

[0001234452-17-000077:mdna:119]
[same as prior period, unchanged from 0001234452-17-000028:mdna:180]

[0001234452-17-000077:mdna:120]
[same as prior period, unchanged from 0001234452-17-000028:mdna:108]

[0001234452-17-000077:mdna:121]
[same as prior period, unchanged from 0001234452-17-000028:mdna:109]

[0001234452-17-000077:mdna:122]
| • | we may be subject to legal proceedings related to the proposed transaction or the failure to complete the proposed transaction; |

[0001234452-17-000077:mdna:123]
[same as prior period, unchanged from 0001234452-17-000028:mdna:111]

[0001234452-17-000077:mdna:124]
[same as prior period, unchanged from 0001234452-17-000028:mdna:112]

[0001234452-17-000077:mdna:125]
[same as prior period, unchanged from 0001234452-17-000028:mdna:113]

[0001234452-17-000077:mdna:126]
[same as prior period, unchanged from 0001234452-17-000028:mdna:114]

[0001234452-17-000077:mdna:127]
The proposed transaction may also result in significant charges or other liabilities that could adversely affect our financial results, such as cash expenses and non-cash accounting charges incurred in connection with our acquisition and/or integration of the business and operations of NXP. Further, our failure to identify or accurately assess the magnitude of certain liabilities we are assuming in the proposed transaction could result in unexpected litigation or regulatory exposure, unfavorable accounting charges, unexpected increases in taxes due, a loss of anticipated tax benefits or other adverse effects on our business, operating results or financial condition. The price of our common stock following the proposed transaction could decline to the extent our financial results are materially affected by any of these events.

[0001234452-17-000077:mdna:128]
[same as prior period, unchanged from 0001234452-17-000028:mdna:116]

[0001234452-17-000077:mdna:129]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on operators of wireless networks and our customers and licensees to adopt these technologies for use in their networks, devices and services. We also depend on our customers and licensees to develop devices and services based on these technologies with value-added features to drive consumer demand for new 3G, 3G/4G multimode and 4G devices, as well as establishing the selling prices for such devices. Further, we depend on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries beyond traditional cellular communications, such as automotive, the IoT, including the connected home, smart cities and wearables, data center, networking, computing, mobile health and machine learning, including robotics, among others. We are also impacted by consumers’ rates of replacement of smartphones and other computing devices.

[0001234452-17-000077:mdna:130]
[same as prior period, unchanged from 0001234452-17-000028:mdna:119]

[0001234452-17-000077:mdna:131]
[same as prior period, unchanged from 0001234452-17-000028:mdna:120]

[0001234452-17-000077:mdna:132]
[same as prior period, unchanged from 0001234452-17-000028:mdna:121]

[0001234452-17-000077:mdna:133]
[same as prior period, unchanged from 0001234452-17-000028:mdna:122]

[0001234452-17-000077:mdna:134]
39

[0001234452-17-000077:mdna:135]
[same as prior period, unchanged from 0001234452-17-000028:mdna:123]

[0001234452-17-000077:mdna:136]
[same as prior period, unchanged from 0001234452-17-000028:mdna:124]

[0001234452-17-000077:mdna:137]
[same as prior period, unchanged from 0001234452-17-000028:mdna:125]

[0001234452-17-000077:mdna:138]
[same as prior period, unchanged from 0001234452-17-000028:mdna:126]

[0001234452-17-000077:mdna:139]
[same as prior period, unchanged from 0001234452-17-000028:mdna:127]

[0001234452-17-000077:mdna:140]
[same as prior period, unchanged from 0001234452-17-000028:mdna:128]

[0001234452-17-000077:mdna:141]
[same as prior period, unchanged from 0001234452-17-000028:mdna:129]

[0001234452-17-000077:mdna:142]
[same as prior period, unchanged from 0001234452-17-000028:mdna:130]

[0001234452-17-000077:mdna:143]
[same as prior period, unchanged from 0001234452-17-000028:mdna:131]

[0001234452-17-000077:mdna:144]
| • | differentiate our integrated circuit products with innovative technologies across multiple products and features (e.g., modem, radio frequency front-end (RFFE), graphics and/or other processors, camera and connectivity) and with smaller geometry process technologies that drive performance; |

[0001234452-17-000077:mdna:145]
[same as prior period, unchanged from 0001234452-17-000028:mdna:134]

[0001234452-17-000077:mdna:146]
[same as prior period, unchanged from 0001234452-17-000028:mdna:135]

[0001234452-17-000077:mdna:147]
[same as prior period, unchanged from 0001234452-17-000028:mdna:136]

[0001234452-17-000077:mdna:148]
[same as prior period, unchanged from 0001234452-17-000028:mdna:137]

[0001234452-17-000077:mdna:149]
[same as prior period, unchanged from 0001234452-17-000028:mdna:138]

[0001234452-17-000077:mdna:150]
[same as prior period, unchanged from 0001234452-17-000028:mdna:139]

[0001234452-17-000077:mdna:151]
[same as prior period, unchanged from 0001234452-17-000028:mdna:140]

[0001234452-17-000077:mdna:152]
[same as prior period, unchanged from 0001234452-17-000028:mdna:141]

[0001234452-17-000077:mdna:153]
| • | create standalone value and/or contribute to the success of our existing businesses through acquisitions, joint ventures and other transactions (and/or by developing customer, licensee and/or vendor relationships) in new industry segments and/or disruptive technologies, products and/or services (such as products for automotive, the Internet of Things (IoT), including the connected home, smart cities and wearables, data center, networking, computing, mobile health and machine learning, including robotics, among others); |

[0001234452-17-000077:mdna:154]
| • | become a leading supplier of RFFE products, which are designed to address cellular radio frequency band fragmentation while improving radio frequency performance and assist original equipment manufacturers in developing multiband, multimode mobile devices; |

[0001234452-17-000077:mdna:155]
[same as prior period, unchanged from 0001234452-17-000028:mdna:144]

[0001234452-17-000077:mdna:156]
[same as prior period, unchanged from 0001234452-17-000028:mdna:145]

[0001234452-17-000077:mdna:157]
[same as prior period, unchanged from 0001234452-17-000028:mdna:146]

[0001234452-17-000077:mdna:158]
Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM) as well as companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom Limited, Cirrus Logic, Ericsson, HiSilicon Technologies, Intel, Marvell Technology, Maxim Integrated Products, MediaTek, Microchip Technology Inc., Murata Manufacturing Co., Ltd., Nvidia, Qorvo Inc., Realtek Semiconductor, Samsung Electronics, Skyworks Solutions Inc. and Spreadtrum Communications (which is controlled by Tsinghua Unigroup). Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to utilize their own internally-developed integrated circuit products, to use our competitors’ integrated circuit products, or to choose alternative technologies; lower cost structures and/or a willingness and ability to accept lower prices and lower or negative margins for their products, particularly in China; foreign government support of other technologies or competitors; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and original equipment manufacturers in emerging geographic regions (such as China); and/or a more established presence in certain regions.

[0001234452-17-000077:mdna:159]
[same as prior period, unchanged from 0001234452-17-000028:mdna:149]

[0001234452-17-000077:mdna:160]
[same as prior period, unchanged from 0001234452-17-000028:mdna:150]

[0001234452-17-000077:mdna:161]
41

[0001234452-17-000077:mdna:162]
[same as prior period, unchanged from 0001234452-17-000028:mdna:151]

[0001234452-17-000077:mdna:163]
[same as prior period, unchanged from 0001234452-17-000028:mdna:152]

[0001234452-17-000077:mdna:164]
Further, companies that develop HLOS for devices, including leading technology companies, sell their own devices. If we fail to effectively partner or continue partnering with these companies, or with their partners or customers, they may decide not to purchase (either directly or through their contract manufacturers), or to reduce or discontinue their purchases of, our integrated circuit products.

[0001234452-17-000077:mdna:165]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products and/or intellectual property or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001234452-17-000077:mdna:166]
Although we have more than 340 CDMA-based licensees, our QTL segment derives a significant portion of its licensing revenues from a limited number of licensees. In the event that one or more of our significant licensees fail to meet their reporting and/or payment requirements or we are unable to renew or modify one or more of such license agreements under similar terms, our revenues, operating results and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our major licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues.

[0001234452-17-000077:mdna:167]
[same as prior period, unchanged from 0001234452-17-000028:mdna:157]

[0001234452-17-000077:mdna:168]
[same as prior period, unchanged from 0001234452-17-000028:mdna:158]

[0001234452-17-000077:mdna:169]
[same as prior period, unchanged from 0001234452-17-000028:mdna:159]

[0001234452-17-000077:mdna:170]
[same as prior period, unchanged from 0001234452-17-000028:mdna:160]

[0001234452-17-000077:mdna:171]
Efforts by some communications equipment manufacturers or their customers to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources

[0001234452-17-000077:mdna:172]
and may result in legal decisions and/or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.

[0001234452-17-000077:mdna:173]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, or some form of unfair competition; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the imposition of some form of compulsory licensing and/or to weaken a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies to attempt to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated. In addition, certain licensees have disputed, underreported and/or underpaid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into license agreements with us for their use of our intellectual property, and licensees and/or companies may continue to do so in the future. Further, to the extent such licensees and/or companies increase their device share, the negative impact of their underreporting, underpayment and/or non-reporting on our business, results of operations, financial condition and/or cash flows will be exacerbated.

[0001234452-17-000077:mdna:174]
We are currently subject to various litigation and governmental investigations and/or proceedings, some of which may arise out of the strategies described above. Certain legal matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region.

[0001234452-17-000077:mdna:175]
[same as prior period, unchanged from 0001234452-17-000028:mdna:164]

[0001234452-17-000077:mdna:176]
[same as prior period, unchanged from 0001234452-17-000028:mdna:165]

[0001234452-17-000077:mdna:177]
Some SDOs, courts and governmental agencies have adopted and may in the future adopt some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001234452-17-000077:mdna:178]
[same as prior period, unchanged from 0001234452-17-000028:mdna:167]

[0001234452-17-000077:mdna:179]
[same as prior period, unchanged from 0001234452-17-000028:mdna:228]

[0001234452-17-000077:mdna:180]
If we are required to change our patent licensing practices due to governmental investigations and/or private legal proceedings challenging those practices, our business and financial results could be adversely impacted.

[0001234452-17-000077:mdna:181]
We are currently subject to various governmental investigations and private legal proceedings challenging our patent licensing practices as described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations in those matters include that we do not license our cellular standard-essential patents separately from our other patents, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high and/or that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions). We believe that the ultimate intent of these investigations and legal proceedings is to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0001234452-17-000077:mdna:182]
We have historically licensed our cellular standard-essential patents together with other Qualcomm patents that may be useful to licensed products because licensees typically have desired to obtain the commercial benefits of receiving such broad patent rights from us. However, on occasion, we also have licensed only our cellular standard-essential patents to certain licensees who have requested such licenses. In addition, in connection with our resolution with the China National Development and Reform Commission (NDRC) in China, our standard practice in China since 2015 is to offer licenses for our 3G and 4G standard-essential Chinese patents for branded devices sold for use in China separately from licenses to our other patents. If we were required to separately license our cellular standard-essential patents to all of our licensees worldwide, and more licensees chose such a license instead of a portfolio license than has historically been the case, our licensing revenues and earnings would be negatively impacted unless we were able to license our other patents at rates that offset all or a portion of any difference between the royalties previously received for licenses of substantially all of our patent portfolio as compared to licenses of only our cellular standard-essential patents and/or there was a sufficient increase in the overall volume of sales of devices upon which royalties are paid.

[0001234452-17-000077:mdna:183]
If we were required to grant patent licenses to chipset manufacturers (i.e., to implement a more complex, tiered licensing structure in which we license certain portions of our patent portfolio to chipset manufacturers and other portions to device manufacturers), we would incur additional transaction costs, which may be significant, and we may incur delays in recognizing revenues until license negotiations were completed. In addition, our licensing revenues and earnings would be negatively impacted if we were not able to obtain, in the aggregate, equivalent revenues under such a multi-level licensing structure.

[0001234452-17-000077:mdna:184]
If we were required to reduce the royalty rates we charge under our patent license agreements, our revenues and earnings would be negatively impacted absent a sufficient increase in the volume of sales of devices upon which royalties are paid. Similarly, if we were required to reduce the base on which our royalties are calculated, our revenue and earnings would be negatively impacted unless there was a sufficient increase in the volume of sales of devices upon which royalties are paid and/or we were able to increase our royalty rates to offset the decrease in revenues resulting from such lower royalty base (assuming the absolute royalty dollars were below any relevant royalty caps).

[0001234452-17-000077:mdna:185]
To the extent that we were required to implement any of these new licensing practices by modifying or renegotiating our existing license agreements, we would incur additional transaction costs, which may be significant, and we may incur delays in recognizing revenues until license negotiations were completed. The impact of any such changes to our licensing practices could vary widely and by jurisdiction, depending on the specific outcomes and the geographic scope of such outcomes. In addition, if we were required to make modifications to our licensing practices in one jurisdiction, licensees and/or governmental agencies in other jurisdictions may attempt to obtain similar outcomes for themselves and/or for such other jurisdictions, as applicable.

[0001234452-17-000077:mdna:186]
[same as prior period, unchanged from 0001234452-17-000028:mdna:168]

[0001234452-17-000077:mdna:187]
[same as prior period, unchanged from 0001234452-17-000028:mdna:169]

[0001234452-17-000077:mdna:188]
We are currently subject to various governmental investigations and/or proceedings, and certain matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and

[0001234452-17-000077:mdna:189]
44

[0001234452-17-000077:mdna:190]
Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region.

[0001234452-17-000077:mdna:191]
[same as prior period, unchanged from 0001234452-17-000028:mdna:171]

[0001234452-17-000077:mdna:192]
National, state and local environmental laws and regulations affect our operations around the world. These laws may make it more expensive to manufacture, have manufactured and sell products, and our costs could increase if our vendors (e.g., third-party manufacturers or utility companies) pass on their costs to us. We are also subject to laws and regulations impacting the manufacturing operations we acquired through our RF360 Holdings joint venture as described in the Risk Factor entitled “There are numerous risks associated with our operation and control of manufacturing facilities we acquired through the formation of our joint venture with TDK, RF360 Holdings, including high fixed costs, environmental compliance and liability, exposure to natural disasters, timely supply of equipment and materials and manufacturing difficulties.”

[0001234452-17-000077:mdna:193]
Regulations in the United States require that we determine whether certain materials used in our products, referred to as conflict minerals, originated in the Democratic Republic of the Congo (DRC) or an adjoining country, or were from recycled or scrap sources. The verification and reporting requirements, in addition to customer demands for conflict free sourcing, impose additional costs on us and on our suppliers and may limit the sources or increase the prices of materials used in our products. Further, if we are unable to determine that our products are “DRC conflict free,” we may face challenges with our customers that place us at a competitive disadvantage, and our reputation may be harmed.

[0001234452-17-000077:mdna:194]
[same as prior period, unchanged from 0001234452-17-000028:mdna:175]

[0001234452-17-000077:mdna:195]
[same as prior period, unchanged from 0001234452-17-000028:mdna:176]

[0001234452-17-000077:mdna:196]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our proprietary information, technologies and processes, including our patent portfolio. Policing unauthorized use of our products, technologies and proprietary information is difficult and time consuming. The steps we have taken have not always prevented, and we cannot be certain the steps we will take in the future will prevent, the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as United States laws or where the enforcement of such laws may be lacking or ineffective. Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that the European Union will adopt a unitary patent system in the next few years that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technology.

[0001234452-17-000077:mdna:197]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property rights and/or contracts, including collecting royalties for use of our patent portfolio in particular foreign jurisdictions due to, among others: policies of foreign governments; challenges to our licensing practices under such jurisdictions’ competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued

[0001234452-17-000077:mdna:198]
by courts in the United States; and/or challenges pending before foreign competition agencies to the pricing and integration of additional features and functionality into our chipset products. Certain licensees have disputed, underreported and/or underpaid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into license agreements for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements.

[0001234452-17-000077:mdna:199]
We have entered into litigation in the past and may need to further litigate in the future to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements and/or initiating litigation) and/or we could incur substantial unexpected operating costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our operating results. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues in the period prior to conclusion.

[0001234452-17-000077:mdna:200]
[same as prior period, unchanged from 0001234452-17-000028:mdna:182]

[0001234452-17-000077:mdna:201]
[same as prior period, unchanged from 0001234452-17-000028:mdna:183]

[0001234452-17-000077:mdna:202]
[same as prior period, unchanged from 0001234452-17-000028:mdna:184]

[0001234452-17-000077:mdna:203]
[same as prior period, unchanged from 0001234452-17-000028:mdna:185]

[0001234452-17-000077:mdna:204]
[same as prior period, unchanged from 0001234452-17-000028:mdna:186]

[0001234452-17-000077:mdna:205]
There are numerous risks associated with our operation and control of manufacturing facilities we acquired through the formation of our joint venture with TDK, RF360 Holdings, including a higher portion of fixed costs relative to a fabless

[0001234452-17-000077:mdna:206]
46

[0001234452-17-000077:mdna:207]
model, environmental compliance and liability, exposure to natural disasters, timely supply of equipment and materials and manufacturing difficulties.

[0001234452-17-000077:mdna:208]
Manufacturing facilities are characterized by a higher portion of fixed costs relative to a fabless model. In less favorable industry environments, in particular, we may be faced with a decline in the utilization rates of our manufacturing facilities due to decreases in demand for our products. During such periods, our manufacturing facilities could operate at lower capacity levels, while the fixed costs associated with full capacity continue to be incurred, resulting in lower gross profit.

[0001234452-17-000077:mdna:209]
We are subject to many environmental, health and safety laws and regulations in each jurisdiction in which we operate our manufacturing facilities, which govern, among other things, emissions of pollutants into the air, wastewater discharges, the use and handling of hazardous substances, waste disposal, the investigation and remediation of soil and ground water contamination and the health and safety of our employees. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. We cannot make assurances that we will be at all times in compliance with such laws, regulations and permits. Certain environmental laws impose strict, and in certain circumstances, joint and several, liability on current or previous owners or operators of real property for the cost of investigation, removal or remediation of hazardous substances. Certain of these laws also assess liability on persons who arrange for hazardous substances to be sent to disposal or treatment facilities when such facilities are found to be contaminated. In addition, we could also be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage.

[0001234452-17-000077:mdna:210]
We have manufacturing facilities in Asia and Europe. If flooding, earthquake, volcanic eruption or other natural disasters or geopolitical conflicts were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, delay new production and shipments of inventory or result in costly repairs, replacements or other costs. In addition, natural disasters or geopolitical conflicts may result in disruptions in transportation, distribution channels or supply chains, or significant increases in the prices of raw materials.

[0001234452-17-000077:mdna:211]
Our manufacturing operations depend on securing raw materials and other supplies in adequate quality and quantity in a timely manner from multiple suppliers, and in some cases we rely on a limited number of suppliers, particularly in Asia. Accordingly, there may be cases where supplies of raw materials and other products are interrupted by disaster, accident or some other event at a supplier, supply is suspended due to quality or other issues, or there is a shortage of supply due to a rapid increase in demand, which could impact production and prevent us from supplying products to our customers. If the supply-demand balance is disrupted, it may considerably increase costs of manufacturing due to increased prices we pay for raw materials or fuel. From time to time, suppliers may extend lead times, limit the amounts supplied to us or increase prices due to capacity constraints or other factors. Further, it may be difficult or impossible to substitute one piece of equipment for another or replace one type of material with another. A failure by our suppliers to deliver our requirements could result in disruptions to our manufacturing operations.

[0001234452-17-000077:mdna:212]
Our manufacturing processes are highly complex, require advanced and costly equipment and must be continuously modified to improve yields and performance. Difficulties in the production process can reduce yields or interrupt production, and as a result we may not be able to deliver products or do so in a timely, cost-effective or competitive manner. Further, to remain competitive and/or meet customer demand, we may be required to improve our facilities and process technologies and carry out extensive research and development, each of which may require investment of significant amounts of capital, and may have a material adverse effect on our results of operations, financial condition and/or cash flows.

[0001234452-17-000077:mdna:213]
[same as prior period, unchanged from 0001234452-17-000028:mdna:187]

[0001234452-17-000077:mdna:214]
Although we own a very strong portfolio of issued and pending patents related to EDGE, OFDM, OFDMA, WLAN and other technologies, our patent portfolio licensing program in these areas is less established and might not be as successful in generating licensing revenues as our CDMA licensing program has been. Many wireless operators are investigating, have selected or have deployed OFDMA-based LTE as their next-generation 4G technology in existing (or future if not yet deployed) wireless spectrum bands as complementary to their existing CDMA-based networks. While 3G/4G multimode products are generally covered by our existing 3G licensing agreements, products that implement 4G but do not also implement 3G are generally not covered by these agreements. Although we believe that our patented technology is essential and useful to implementation of the LTE industry standards and have granted royalty-bearing licenses to more than 225 companies (including Huawei, Lenovo, LG, Microsoft, Oppo, Samsung, Sony Mobile, vivo, Xiaomi and ZTE) that have realized that they need a license to our patents to make and sell products implementing 4G standards but not implementing 3G standards, it may be difficult to agree on material terms and/or conditions of new license agreements that are acceptable to us with companies that are currently unlicensed. Further, the royalty rates for single mode 4G products are lower than our royalty rates for 3G and 3G/4G multimode products, so, without a corresponding increase in volumes and/or device ASP, we will not

[0001234452-17-000077:mdna:215]
achieve the same licensing revenues on such LTE products as on 3G and 3G/4G multimode products. In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the connected home or the IoT. We also seek to diversify and broaden our technology licensing programs to new industry segments in which we can utilize our technology leadership, such as wireless charging and other technologies. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties that are equivalent to those that we receive for 3G and 3G/4G multimode products used in cellular communications. Although we believe that our patented technology is essential and useful to the commercialization of such services, the royalties we receive may be lower than those we receive from our current licensing program.

[0001234452-17-000077:mdna:216]
[same as prior period, unchanged from 0001234452-17-000028:mdna:190]

[0001234452-17-000077:mdna:217]
The licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, certain of our license agreements (including essentially all of our recent agreements in China) are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of a specified term, or to receive royalties after the specified time period, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. Accordingly, to the extent not renewed on their terms or by election for an additional (generally multi-year) period, if applicable, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. We might not be able to renew those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in renewing a license agreement prior to its expiration, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001234452-17-000077:mdna:218]
We depend on a limited number of third-party suppliers for the procurement, manufacture and testing of our products manufactured in a fabless production model. If we fail to execute supply strategies that provide technology leadership, supply assurance and low cost, our operating results and our business may be harmed. We are also subject to order and shipment uncertainties that could negatively impact our operating results.

[0001234452-17-000077:mdna:219]
Our QCT segment primarily utilizes a fabless production model, which means that we generally do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Other than the manufacturing facilities we now operate through our recent RF360 Holdings joint venture, we rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Under the turnkey model, our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services such as wafer bump, probe, assembly and the majority of our final test requirements. The semiconductor manufacturing foundries that supply products to our QCT segment are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders. The following could have an adverse effect on our ability to meet customer demands and/or negatively impact our revenues, business operations, profitability and/or cash flows:

[0001234452-17-000077:mdna:220]
[same as prior period, unchanged from 0001234452-17-000028:mdna:194]

[0001234452-17-000077:mdna:221]
[same as prior period, unchanged from 0001234452-17-000028:mdna:195]

[0001234452-17-000077:mdna:222]
[same as prior period, unchanged from 0001234452-17-000028:mdna:196]

[0001234452-17-000077:mdna:223]
[same as prior period, unchanged from 0001234452-17-000028:mdna:197]

[0001234452-17-000077:mdna:224]
| • | the loss of a supplier or the inability of a supplier to meet performance, quality or yield specifications or delivery schedules; |

[0001234452-17-000077:mdna:225]
| • | additional expense and/or production delays as a result of qualifying a new supplier and commencing volume production or testing in the event of a loss of or a decision to add or change a supplier; and/or |

[0001234452-17-000077:mdna:226]
| • | natural disasters or geopolitical conflicts, particularly in Asia, impacting our suppliers. |

[0001234452-17-000077:mdna:227]
48

[0001234452-17-000077:mdna:228]
While we have established alternate suppliers for certain technologies, we rely on sole- or limited-source suppliers for certain products, subjecting us to significant risks, including: possible shortages of raw materials or manufacturing capacity; poor product performance; and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established alternate suppliers, these suppliers may require significant levels of support to bring complex technologies to production. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, any future consolidation of foundry suppliers could increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions and/or increase our manufacturing costs. Our arrangements with our suppliers may obligate us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies, and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Our inability to meet customer demand due to sole- or limited-sourcing and/or the additional costs that we incur because of these or other supply constraints or because of the need to support alternate suppliers could negatively impact our business and our results of operations.

[0001234452-17-000077:mdna:229]
[same as prior period, unchanged from 0001234452-17-000028:mdna:203]

[0001234452-17-000077:mdna:230]
[same as prior period, unchanged from 0001234452-17-000028:mdna:204]

[0001234452-17-000077:mdna:231]
[same as prior period, unchanged from 0001234452-17-000028:mdna:205]

[0001234452-17-000077:mdna:232]
[same as prior period, unchanged from 0001234452-17-000028:mdna:206]

[0001234452-17-000077:mdna:233]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our operating results.

[0001234452-17-000077:mdna:234]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example,

[0001234452-17-000077:mdna:235]
monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (and/or on the sale of our customers’ devices using such products) and/or the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001234452-17-000077:mdna:236]
Certain legal matters, including certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001234452-17-000077:mdna:237]
[same as prior period, unchanged from 0001234452-17-000028:mdna:211]

[0001234452-17-000077:mdna:238]
We engage in strategic acquisitions and other transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. We acquire businesses and other assets, including patents, technology, wireless spectrum and other intangible assets, enter into joint ventures or other strategic transactions, and purchase minority equity interests in or make loans to companies that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications and new industry segments. Recent material transactions include our acquisition of CSR plc, our RF360 Holdings joint venture with TDK Corporation and our proposed acquisition of NXP. Many of our strategic activities entail a high degree of risk and require the use of domestic and/or foreign capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies, products or services. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our financial results, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited. We may underestimate the costs and/or overestimate the benefits, including product and other synergies and growth opportunities that we expect to realize, and we may not achieve them. If we do not achieve the anticipated benefits of business acquisitions or other strategic activities, our results of operations may be adversely affected, and we may not enhance stockholder value by engaging in these transactions.

[0001234452-17-000077:mdna:239]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, technology, products, processes, operations (including manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development and/or supply operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models (including manufacturing), geographic regions, industry segments and/or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of the combination.

[0001234452-17-000077:mdna:240]
[same as prior period, unchanged from 0001234452-17-000028:mdna:214]

[0001234452-17-000077:mdna:241]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe we will continue to see, an increase in customers requesting that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of a product’s source code and may expose related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of the open source software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Developing open source products, while adequately protecting the intellectual property rights upon which our licensing business depends, may prove burdensome and time-consuming under

[0001234452-17-000077:mdna:242]
certain circumstances, thereby placing us at a competitive disadvantage. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ adequate controls to protect our intellectual property rights, our use of open source software presents risks that could have an adverse effect on these rights and on our business.

[0001234452-17-000077:mdna:243]
[same as prior period, unchanged from 0001234452-17-000028:mdna:217]

[0001234452-17-000077:mdna:244]
[same as prior period, unchanged from 0001234452-17-000028:mdna:218]

[0001234452-17-000077:mdna:245]
In the past, securities class action litigation has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001234452-17-000077:mdna:246]
We maintain an extensive investment portfolio of varied holdings, which are generally classified as available-for-sale and are therefore recorded on our consolidated balance sheet at fair value, with unrealized gains or losses reported as a component of accumulated other comprehensive income. The fair values of our investments are subject to fluctuation based primarily on market price volatility, as well as the underlying operations of the associated investment, among other things. If the fair value of such investments decreases below their cost basis, as some of our previous investments have, we may be required in certain circumstances to recognize a loss in our results of operations. The sensitivity of and risks associated with the market value of our investment portfolio are described more fully in our Annual Report on Form 10-K for our fiscal year ended September 25, 2016 and “Part 1, Item 3. Quantitative and Qualitative Disclosures About Market Risk” in this Quarterly Report.

[0001234452-17-000077:mdna:247]
[same as prior period, unchanged from 0001234452-17-000028:mdna:221]

[0001234452-17-000077:mdna:248]
[same as prior period, unchanged from 0001234452-17-000028:mdna:222]

[0001234452-17-000077:mdna:249]
[same as prior period, unchanged from 0001234452-17-000028:mdna:223]

[0001234452-17-000077:mdna:250]
[same as prior period, unchanged from 0001234452-17-000028:mdna:224]

[0001234452-17-000077:mdna:251]
[same as prior period, unchanged from 0001234452-17-000028:mdna:225]

[0001234452-17-000077:mdna:252]
[same as prior period, unchanged from 0001234452-17-000028:mdna:226]

[0001234452-17-000077:mdna:253]
Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to general economic conditions, industry cycles and financial, business and other factors, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations in the future to service our debt, we may be required to, among other things: repatriate funds to the United States at substantial tax cost; refinance or restructure all or a portion of our indebtedness; reduce or delay planned capital or operating expenditures; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing and/or restructuring are higher than our current rates, interest expense related to such refinancing and/or restructuring would increase. If there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt in the future and/or the terms of such debt could be adversely affected.

[0001234452-17-000077:mdna:254]
[same as prior period, unchanged from 0001234452-17-000028:mdna:230]

[0001234452-17-000077:mdna:255]
A decline in global, regional or local economic conditions or a slow-down in economic growth, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could

[0001234452-17-000077:mdna:256]
have adverse, wide-ranging effects on demand for our products and for the products and services of our customers or licensees, particularly equipment manufacturers or others in the wireless communications industry who buy their products, such as wireless operators. Any prolonged economic downturn may result in a decrease in demand for our products or technologies; the insolvency of key suppliers, customers or licensees; delays in reporting and/or payments from our licensees and/or customers; failures by counterparties; and negative effects on wireless device inventories. In addition, our customers’ ability to purchase or pay for our products and services and network operators’ ability to upgrade their wireless networks could be adversely affected by economic conditions, leading to a reduction, cancelation or delay of orders for our products or services.

[0001234452-17-000077:mdna:257]
[same as prior period, unchanged from 0001234452-17-000028:mdna:232]

[0001234452-17-000077:mdna:258]
Our future success depends largely upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. The market for employees in our industry is extremely competitive. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001234452-17-000077:mdna:259]
[same as prior period, unchanged from 0001234452-17-000028:mdna:234]

[0001234452-17-000077:mdna:260]
[same as prior period, unchanged from 0001234452-17-000028:mdna:235]

[0001234452-17-000077:mdna:261]
[same as prior period, unchanged from 0001234452-17-000028:mdna:236]

[0001234452-17-000077:mdna:262]
[same as prior period, unchanged from 0001234452-17-000028:mdna:237]

[0001234452-17-000077:mdna:263]
[same as prior period, unchanged from 0001234452-17-000028:mdna:238]

[0001234452-17-000077:mdna:264]
[same as prior period, unchanged from 0001234452-17-000028:mdna:239]

[0001234452-17-000077:mdna:265]
[same as prior period, unchanged from 0001234452-17-000028:mdna:240]

[0001234452-17-000077:mdna:266]
The use of devices containing our products to access untrusted content creates a risk of exposing the system software in those devices to viral or malicious attacks. While we continue to focus on this issue and are taking measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more data and processes, such as computing, and increasing the risk of security failures. Further, our products are inherently complex and may contain defects or errors that are detected only when the products are in use. The design process interface in new domains of technology and the migration to integrated circuit technologies with smaller geometric feature sizes are complex and add risk to manufacturing yields and reliability. Further, manufacturing, testing, marketing and use of our products and those of our customers and licensees entail the risk of product liability. Because our products and services are responsible for critical functions in our customers’ products and/or networks, security failures, defects or errors in our products or services could have an adverse impact on us, on our customers and/or on the end users of our customers’ products. Such adverse impact could include product liability claims or recalls; write-offs of our inventories, property, plant and equipment and/or intangible assets; unfavorable purchase commitments; a shift of business to our competitors; a decrease in demand for connected devices and wireless services; damage to our reputation and to our customer relationships; and other financial liability or harm to our business. Further, security failures, defects or errors in the products of our customers or licensees, such as the recent issues with the Galaxy Note 7 that caused Samsung to discontinue that product, could have an adverse impact on our operating results due to a delay or decrease in demand for our products or services generally, and our premium-tier products in particular, among other factors.

[0001234452-17-000077:mdna:267]
52

[0001234452-17-000077:mdna:268]
[same as prior period, unchanged from 0001234452-17-000028:mdna:243]

[0001234452-17-000077:mdna:269]
[same as prior period, unchanged from 0001234452-17-000028:mdna:244]

[0001234452-17-000077:mdna:270]
[same as prior period, unchanged from 0001234452-17-000028:mdna:245]

[0001234452-17-000077:mdna:271]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-United States headquarters is located. Significant judgment is required in determining our provision for income taxes. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision and results of operations in the period or periods in which that determination is made could be negatively affected.

[0001234452-17-000077:mdna:272]
[same as prior period, unchanged from 0001234452-17-000028:mdna:247]

[0001234452-17-000077:mdna:273]
[same as prior period, unchanged from 0001234452-17-000028:mdna:248]

[0001234452-17-000077:mdna:274]
[same as prior period, unchanged from 0001234452-17-000028:mdna:249]
