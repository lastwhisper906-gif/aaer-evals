# QCOM 8-K — 0001234452-17-000075 filed 2017-04-19

## item codes, every 8-K on or before 2017-04-19

- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2017-04-19

- none on or before 2017-04-19

## item 2.02 — earnings release, exhibit 99.1

[0001234452-17-000075:8k_2_02:1]
EX-99.1
2
qcom032617erex991.htm
EXHIBIT 99.1

[0001234452-17-000075:8k_2_02:2]
Exhibit

[0001234452-17-000075:8k_2_02:3]
Exhibit 99.1

[0001234452-17-000075:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-17-000075:8k_2_02:5]
Qualcomm Contact:

[0001234452-17-000075:8k_2_02:6]
John Sinnott

[0001234452-17-000075:8k_2_02:7]
Vice President, Investor Relations

[0001234452-17-000075:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-17-000075:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-17-000075:8k_2_02:10]
Qualcomm Announces Second Quarter Fiscal 2017 Results

[0001234452-17-000075:8k_2_02:11]
GAAP Revenues $5.0 billion, Non-GAAP Revenues $6.0 billion

[0001234452-17-000075:8k_2_02:12]
GAAP EPS $0.50, Non-GAAP EPS $1.34

[0001234452-17-000075:8k_2_02:13]
SAN DIEGO - April 19, 2017 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal second quarter ended March 26, 2017.

[0001234452-17-000075:8k_2_02:14]
“We delivered strong results this quarter, with healthy year-over-year growth across our QTL licensing and QCT semiconductor businesses, especially in the important automotive, networking and IoT growth areas,” said Steve Mollenkopf, CEO of Qualcomm Incorporated. “Our performance reflects continued execution of our strategy to lead the mobile industry across a broad set of technologies, including advanced LTE and 5G, and accelerate our growth opportunities beyond mobile into automotive, IoT, security and networking.”

[0001234452-17-000075:8k_2_02:15]
Mr. Mollenkopf added, “We will continue to protect the value of our technologies, which enables today’s robust mobile communications ecosystem, and invest in R&D that will drive the leading edge of mobile computing and connectivity for decades to come - focusing on areas where our technologies will have the most impact and generate the best returns.  With our leading technology roadmap and pending acquisition of NXP, we are positioned to address a larger set of opportunities ahead than any other time in our history.”

[0001234452-17-000075:8k_2_02:16]
Second Quarter Results (GAAP)*

[0001234452-17-000075:8k_2_02:17]
|  | Q2 Fiscal 2017 |  | Q2 Fiscal 2016 |  | Year-Over-Year Change |  | Q1 Fiscal 2017 |  | Sequential Change |
| Revenues | $5.0B |  | $5.6B |  | (10%) |  | $6.0B |  | (16%) |
| Operating income | $0.7B |  | $1.4B |  | (48%) |  | $0.8B |  | (6%) |
| Net income 1 | $0.7B |  | $1.2B |  | (36%) |  | $0.7B |  | +10% |
| Diluted earnings per share 1 | $0.50 |  | $0.78 |  | (36%) |  | $0.46 |  | +9% |
| Operating cash flow | $0.8B |  | $0.7B |  | +11% |  | $1.4B |  | (41%) |

[0001234452-17-000075:8k_2_02:18]
1 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests), unless otherwise stated.

[0001234452-17-000075:8k_2_02:19]
Second Quarter Results (Non-GAAP)*

[0001234452-17-000075:8k_2_02:20]
|  | Q2 Fiscal 2017 |  | Q2 Fiscal 2016 |  | Year-Over-Year Change |  | Q1 Fiscal 2017 |  | Sequential Change |
| Revenues | $6.0B |  | $5.5B |  | +8% |  | $6.0B |  | — |
| Operating income | $2.2B |  | $1.9B |  | +18% |  | $2.1B |  | +7% |
| Net income | $2.0B |  | $1.6B |  | +28% |  | $1.8B |  | +12% |
| Diluted earnings per share | $1.34 |  | $1.04 |  | +29% |  | $1.19 |  | +13% |

[0001234452-17-000075:8k_2_02:21]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding the Company’s use of Non-GAAP financial measures and detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-17-000075:8k_2_02:22]
* The following should be considered in regards to the sequential and year-over-year comparisons:

[0001234452-17-000075:8k_2_02:23]
| • | The second quarter of fiscal 2017 GAAP results included: |

[0001234452-17-000075:8k_2_02:24]
| ◦ | $974 million reduction to revenues, or $0.48 per share, which was accrued, related to the BlackBerry arbitration decision. |

[0001234452-17-000075:8k_2_02:25]
| • | The first quarter of fiscal 2017 GAAP results included: |

[0001234452-17-000075:8k_2_02:26]
| ◦ | $868 million charge, or $0.49 per share, which was accrued, related to the Korea Free Trade Commission (KFTC) investigation (additional second quarter of fiscal 2017 impact of $53 million of related foreign exchange losses, resulting in a total charge of $921 million in the first six months of fiscal 2017). |

[0001234452-17-000075:8k_2_02:27]
| • | The second quarter of fiscal 2016 GAAP and Non-GAAP results included: |

[0001234452-17-000075:8k_2_02:28]
| ◦ | $266 million of revenues, or $0.13 per share, due to the termination of an infrastructure license agreement resulting from the merger of two licensees. |

[0001234452-17-000075:8k_2_02:29]
Second Quarter Segment Results

[0001234452-17-000075:8k_2_02:30]
|  | Q2 Fiscal 2017 |  | Q2 Fiscal 2016 |  | Year-Over-Year Change (1) |  | Q1 Fiscal 2017 |  | Sequential Change (1) |
| QCT |  |  |  |  |  |  |  |  |  |
| Revenues | $3,676M |  | $3,337M |  | +10% |  | $4,101M |  | (10%) |
| Earnings before taxes (EBT) | $475M |  | $170M |  | +179% |  | $724M |  | (34%) |
| EBT as % of revenues | 13% |  | 5% |  | +8% |  | 18% |  | (5%) |
| MSMTM chip shipments | 179M |  | 189M |  | (5%) |  | 217M |  | (18%) |
| QTL |  |  |  |  |  |  |  |  |  |
| Revenues | $2,249M |  | $2,135M |  | +5% |  | $1,811M |  | +24% |
| EBT | $1,959M |  | $1,857M |  | +5% |  | $1,532M |  | +28% |
| EBT as % of revenues | 87% |  | 87% |  | — |  | 85% |  | 2% |
| Total reported device sales (2) (3) | $82.6B |  | $70.1B |  | +18% |  | $62.9B |  | +31% |
| Est. reported 3G/4G device shipments | 398M - 402M |  | 335M - 339M |  | +19% |  | 331M - 335M |  | +20% |
| Est. reported 3G/4G average selling price | $204 - $210 |  | $205 - $211 |  | — |  | $186 - $192 |  | +10% |

[0001234452-17-000075:8k_2_02:31]
| (1) | The year-over-year and sequential changes for estimated reported 3G/4G device shipments and average selling prices are calculated at the midpoints. The midpoints of the estimated ranges are used for comparison purposes only and do not indicate a higher degree of confidence in the midpoints. |

[0001234452-17-000075:8k_2_02:32]
| (2) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based |

[0001234452-17-000075:8k_2_02:33]
and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a

[0001234452-17-000075:8k_2_02:34]
particular period (collectively, 3G/4G devices). The reported quarterly estimated ranges of average selling prices (ASPs) and unit shipments are determined based on the information as reported to us by our licensees during the relevant period and our own estimates of the selling prices and unit shipments for licensees that do not provide such information. Not all licensees report sales, selling prices and/or unit shipments the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales, estimated unit shipments and estimated ASPs for a particular period may include prior period activity that was not reported by the licensee until such particular period.

[0001234452-17-000075:8k_2_02:35]
| (3) | Total reported device sales for the second quarter of fiscal 2016 and 2017 are based on sales by our licensees in the December quarter as reported to us in the March quarter, and the first quarter of fiscal 2017 is based on sales by our licensees in the September quarter as reported to us in the December quarter. |

[0001234452-17-000075:8k_2_02:36]
Cash and Marketable Securities

[0001234452-17-000075:8k_2_02:37]
Our cash, cash equivalents and marketable securities totaled $28.9 billion at the end of the second quarter of fiscal 2017, compared to $30.0 billion a year ago and $29.8 billion at the end of the first quarter of fiscal 2017. In February 2017, we completed the formation of a joint venture, RF360 Holdings Singapore Pte. Ltd., which resulted in a cash payment of $1.2 billion, net of cash acquired, in the second quarter of fiscal 2017.

[0001234452-17-000075:8k_2_02:38]
Announced Agreement to Acquire NXP

[0001234452-17-000075:8k_2_02:39]
On October 27, 2016, we announced a definitive agreement to acquire NXP Semiconductors N.V. for estimated total cash to be paid to shareholders of $38 billion.  NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products.  The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions.  We intend to fund the transaction with cash held by foreign entities, which will result in the use of a substantial portion of our cash, cash equivalents and marketable securities, and new debt.

[0001234452-17-000075:8k_2_02:40]
Return of Capital to Stockholders

[0001234452-17-000075:8k_2_02:41]
During the second quarter of fiscal 2017, we returned $1.1 billion to stockholders, including $782 million, or $0.53 per share, of cash dividends paid and $283 million through repurchases of 4.8 million shares of common stock.  On April 12, 2017, we announced a cash dividend of $0.57 per share payable on June 21, 2017 to stockholders of record as of the close of business on May 31, 2017, which represents a 7.5 percent increase over our prior quarterly dividend.

[0001234452-17-000075:8k_2_02:42]
Effective Income Tax Rates

[0001234452-17-000075:8k_2_02:43]
Our fiscal 2017 annual effective income tax rates are estimated to be approximately 17 percent for both GAAP and Non-GAAP.  The effective income tax rates for the second quarter of fiscal 2017 were 13 percent for GAAP and 15 percent for Non-GAAP.  Our estimated annual tax rates for fiscal 2017 GAAP and Non-GAAP decreased from our prior estimates of 22% and 18%, respectively, primarily as a result of a decrease in our estimate of income from United States operations.  Additionally, our estimated annual 2017 effective income tax rates for GAAP included the tax impact of the $921 million charge related to the fine imposed by the KFTC, which is not deductible for tax purposes, and the tax impact of the $974 million reduction to revenues related to the BlackBerry arbitration decision, which is deductible for tax purposes.

[0001234452-17-000075:8k_2_02:44]
Business Outlook

[0001234452-17-000075:8k_2_02:45]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment and certain derivative gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001234452-17-000075:8k_2_02:46]
Apple’s contract manufacturers reported, but underpaid, royalties in the second quarter of fiscal 2017. However, our revenues were not negatively impacted as the contract manufacturers acknowledged the amounts are due and the underpayment was equal to the amounts that Qualcomm has not paid Apple under our Cooperation Agreement that are currently in dispute. The Cooperation Agreement expired December 31, 2016.  It is not clear whether Apple’s contract manufacturers will underpay royalties owed under their contracts with us in the third quarter of fiscal 2017, which could have a negative impact on our financial results. Our guidance range for fiscal third quarter EPS is wider than our typical practice primarily due to this uncertainty. We have considered a variety of scenarios within this range, but have not included a scenario where no payment is made by the contract manufacturers.  We will update our guidance if we subsequently learn of any action that would take us outside of the announced guidance range.

[0001234452-17-000075:8k_2_02:47]
We have not included any estimates related to any proposed acquisitions in our third quarter of fiscal 2017 outlook.

[0001234452-17-000075:8k_2_02:48]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-17-000075:8k_2_02:49]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001234452-17-000075:8k_2_02:50]
|  |  | Q3 FY16 Results | Current Guidance Q3 FY17 Estimates |  |
|  | Revenues | $6.0B | $5.3B - $6.1B |  |  |
|  | Year-over-year change |  | decrease 12% - increase 1% |  |  |
|  | GAAP diluted earnings per share (EPS) | $0.97 | $0.67 - $0.92 |  |  |
|  | Year-over-year change |  | decrease 31% - 5% |  |  |
|  | Less diluted EPS attributable to QSI | $0.00 |  | $0.02 |  |  |
|  | Less diluted EPS attributable to share-based compensation | ($0.13) |  | ($0.13 | ) |  |
|  | Less diluted EPS attributable to other items (1) | ($0.06) |  | ($0.12 | ) |  |
|  | Non-GAAP diluted EPS | $1.16 | $0.90 - $1.15 |  |  |
|  | Year-over-year change |  | decrease 22% - 1% |  |  |
|  | Metrics |  |  |  |
|  | MSM chip shipments | 201M | 180M - 200M |  |  |
|  | Year-over-year change |  | decrease 10% - flat |  |  |
|  | Total reported device sales* | approx. $62.6B | approx. $59.0B - $67.0B |  | (2) |
|  | Year-over-year change |  | decrease 6% - increase 7% |  |  |
|  | *Est. sales in March quarter, reported in June quarter |  |  |  |

[0001234452-17-000075:8k_2_02:51]
| (1) | Our guidance for diluted EPS attributable to other items for the third quarter of fiscal 2017 is primarily attributable to acquisition-related items. |

[0001234452-17-000075:8k_2_02:52]
| (2) | Our guidance range for the third quarter of fiscal 2017 total reported device sales reflects estimated 3G/4G total reported device sales that we currently expect to be reported to us, which includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-17-000075:8k_2_02:53]
Sums may not equal total due to rounding.

[0001234452-17-000075:8k_2_02:54]
Reconciliations of GAAP Results to Non-GAAP Results

[0001234452-17-000075:8k_2_02:55]
The following tables reconcile our GAAP results to our Non-GAAP results ($ in millions, except per share data):

[0001234452-17-000075:8k_2_02:56]
|  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) |  | Non-GAAP Results |
| Q2 FISCAL 2017 |  |  |  |  |  |  |  |
| Revenues | $5,016 |  |  | $— |  |  |  | $— |  |  | ($974 | ) | (c) | $5,990 |  |
| Operating income (loss) | 729 |  | (17) |  | (246) | (1,228) |  | 2,220 |  |
| EBT | 857 |  | — |  |  | (246) | (1,239) |  | 2,342 |  |
| EBT as % of revenues | 17 | % |  |  |  |  |  |  | 39 | % |  |
| Net income (loss) | 749 |  | — |  |  | (210) | (1,030) |  | 1,989 |  |
| Diluted EPS | $0.50 |  | $0.00 |  | ($0.14) | ($0.69) |  | $1.34 |  |
| Diluted shares | 1,489 |  | 1,489 |  | 1,489 | 1,489 |  | 1,489 |  |
| Q1 FISCAL 2017 |  |  |  |  |  |  |  |
| Revenues | $5,999 |  | $14 |  |  | $— |  |  | $— |  |  | $5,985 |  |
| Operating income (loss) | 778 |  | (2) |  | (239) | (1,054) |  | 2,073 |  |
| EBT | 870 |  | (17) |  | (239) | (1,065) |  | 2,191 |  |
| EBT as % of revenues | 15 | % |  |  |  |  |  |  | 37 | % |  |
| Net income (loss) | 682 |  | (11) |  | (190) | (900) |  | 1,783 |  |
| Diluted EPS | $0.46 |  | ($0.01) |  | ($0.13) | ($0.60) |  | $1.19 |  |
| Diluted shares | 1,495 |  | 1,495 |  | 1,495 | 1,495 |  | 1,495 |  |
| Q2 FISCAL 2016 |  |  |  |  |  |  |  |
| Revenues | $5,551 |  | $12 |  |  | $— |  |  | $— |  |  | $5,539 |  |
| Operating income (loss) | 1,415 |  | 3 |  | (247) | (226) |  | 1,885 |  |
| EBT | 1,470 |  | 46 |  | (247) | (226) |  | 1,897 |  |
| EBT as % of revenues | 26 | % |  |  |  |  |  |  | 34 | % |  |
| Net income (loss) | 1,164 |  | 30 |  | (220) | (198) |  | 1,552 |  |
| Diluted EPS | $0.78 |  | $0.02 |  | ($0.15) | ($0.13) |  | $1.04 |  |
| Diluted shares | 1,498 |  | 1,498 |  | 1,498 | 1,498 |  | 1,498 |  |

[0001234452-17-000075:8k_2_02:57]
| (a) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” herein for further details. |

[0001234452-17-000075:8k_2_02:58]
| (b) | Details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates.” Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001234452-17-000075:8k_2_02:59]
| (c) | Other items excluded from Non-GAAP results consisted of a $974 million reduction to revenues related to the BlackBerry arbitration decision. |

[0001234452-17-000075:8k_2_02:60]
Sums may not equal totals due to rounding.

[0001234452-17-000075:8k_2_02:61]
Supplemental Information and Reconciliations

[0001234452-17-000075:8k_2_02:62]
(Unaudited)

[0001234452-17-000075:8k_2_02:63]
|  | Q2 FISCAL 2017 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results |
|  | Cost of revenues |  | $2,208 |  |  | $13 |  |  | $10 |  |  | $106 |  |  | $2,079 |  |
|  | Research and development (R&D) expenses |  | 1,386 |  |  | — |  |  |  | 155 |  |  | 13 |  |  | 1,218 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 615 |  |  | 4 |  |  | 81 |  |  | 57 |  |  | 473 |  |
|  | Other expenses |  | 78 |  |  | — |  |  |  | — |  |  |  | 78 |  |  | — |  |  |
|  | Interest expense |  | 107 |  |  | — |  |  |  | — |  |  |  | 24 |  |  | 83 |  |
|  | Investment income, net |  | 235 |  |  | 17 |  |  | — |  |  |  | 13 |  |  | 205 | (b) |

[0001234452-17-000075:8k_2_02:64]
| (a) | Other items excluded from Non-GAAP EBT included $200 million of acquisition-related charges, $40 million of net foreign currency losses related to the fine imposed by the KFTC and $25 million of restructuring and restructuring-related charges related to our Strategic Realignment Plan. |

[0001234452-17-000075:8k_2_02:65]
| (b) | Included $148 million in interest and dividend income, $67 million in net realized gains on investments, partially offset by $10 million in other net investment losses. |

[0001234452-17-000075:8k_2_02:66]
Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates

[0001234452-17-000075:8k_2_02:67]
(Unaudited)

[0001234452-17-000075:8k_2_02:68]
|  |  | GAAP Results |  |  | Less QSI |  | Less Share-Based Compensation |  | Less Other Items (c)(d) |  |  | Non-GAAP Results |  |
| Q2 FISCAL 2017 ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 857 |  |  |  | $ | — |  |  |  | $ | (246 | ) |  |  | $ | (1,239 | ) |  |  | $ | 2,342 |  |  |
| Income tax (expense) benefit |  | (108 | ) |  |  | — |  |  |  | 36 |  |  |  | 209 |  |  |  | (353 | ) |  |
| Net income (loss) (a) |  | $ | 749 |  |  |  | $ | — |  |  |  | $ | (210 | ) |  |  | $ | (1,030 | ) |  |  | $ | 1,989 |  |  |
| Tax rate |  | 13 | % |  |  | 0 | % | (b) |  |  |  | 0 | % | (b) |  |  | (2 | %) | (b) |  |  | 15 | % |  |
| FISCAL 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Estimated annual tax rate |  | 17 | % |  |  | 0 | % | (b) |  |  |  | 0 | % | (b) |  |  |  | 0 | % | (b) |  |  |  | 17 | % |  |

[0001234452-17-000075:8k_2_02:69]
| (a) | Before adjustments for noncontrolling interests. |

[0001234452-17-000075:8k_2_02:70]
| (b) | The incremental effect of our adjustments to the Non-GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001234452-17-000075:8k_2_02:71]
| (c) | In the second quarter of fiscal 2017, the tax benefit in the “Other Items” column included a $38 million tax benefit for the tax effect of acquisition-related items in EBT and a $339 million benefit for the combined tax effect of other items in EBT, partially offset by a $155 million tax expense to reconcile the tax provision for each column to the total GAAP tax provision for the quarter primarily due to the impact of the KFTC and BlackBerry charges and a $13 million tax expense related to an increase in unrecognized tax benefits. |

[0001234452-17-000075:8k_2_02:72]
| (d) | In fiscal 2017, the estimated annual effective tax rate for the “Other Items” column includes a $112 million tax benefit for the tax effect of acquisition-related items in EBT and a $364 million tax benefit for the combined tax effect of other items in EBT, partially offset by a $13 million tax expense related to an increase in unrecognized tax benefits. |

[0001234452-17-000075:8k_2_02:73]
Conference Call

[0001234452-17-000075:8k_2_02:74]
Qualcomm’s fiscal second quarter 2017 earnings conference call will be broadcast live on April 19, 2017, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 95200877.

[0001234452-17-000075:8k_2_02:75]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-17-000075:8k_2_02:76]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-17-000075:8k_2_02:77]
The Company uses the Non-GAAP financial information:  (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating the Company’s business and assessing trends and future expectations.

[0001234452-17-000075:8k_2_02:78]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items, tax items and other items.

[0001234452-17-000075:8k_2_02:79]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-17-000075:8k_2_02:80]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001234452-17-000075:8k_2_02:81]
| • | Certain other items are excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001234452-17-000075:8k_2_02:82]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items, as well as any effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property, third-party acquisition and integration services costs and costs related to |

[0001234452-17-000075:8k_2_02:83]
temporary debt facilities and letters of credit executed prior to the close of an acquisition. Starting with acquisitions in the second quarter of fiscal 2017, the Company excludes recognition of the step-up of property, plant and equipment from the net book value based on the original cost basis to fair value.  Such change related to acquisitions that were completed prior to the second quarter of fiscal 2017 continue to be allocated to the segments, and such amounts are not material.

[0001234452-17-000075:8k_2_02:84]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. |

[0001234452-17-000075:8k_2_02:85]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. |

[0001234452-17-000075:8k_2_02:86]
About Qualcomm

[0001234452-17-000075:8k_2_02:87]
Qualcomm’s technologies powered the smartphone revolution and connected billions of people.  We pioneered 3G and 4G - and now we are leading the way to 5G and a new era of intelligent, connected devices.  Our products are revolutionizing industries, including automotive, computing, IoT, healthcare and data center, and are allowing millions of devices to connect with each other in ways never before imagined.  Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, all of our engineering, research and development functions, and all of our products and services businesses, including, our QCT semiconductor business.  For more information, visit www.qualcomm.com.

[0001234452-17-000075:8k_2_02:88]
Note Regarding Forward-Looking Statements

[0001234452-17-000075:8k_2_02:89]
###

[0001234452-17-000075:8k_2_02:90]
Qualcomm, Snapdragon and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-17-000075:8k_2_02:91]
Qualcomm Snapdragon and MSM are products of Qualcomm Technologies, Inc.

[0001234452-17-000075:8k_2_02:92]
Qualcomm Incorporated

[0001234452-17-000075:8k_2_02:93]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001234452-17-000075:8k_2_02:94]
(In millions, except per share data)

[0001234452-17-000075:8k_2_02:95]
(Unaudited)

[0001234452-17-000075:8k_2_02:96]
|  | March 26, 2017 |  | September 25, 2016 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 7,124 |  |  | $ | 5,946 |  |
| Marketable securities | 2,858 |  |  | 12,702 |  |
| Accounts receivable, net | 4,201 |  |  | 2,219 |  |
| Inventories | 2,066 |  |  | 1,556 |  |
| Other current assets | 659 |  |  | 558 |  |
| Total current assets | 16,908 |  |  | 22,981 |  |
| Marketable securities | 18,876 |  |  | 13,702 |  |
| Deferred tax assets | 2,458 |  |  | 2,030 |  |
| Property, plant and equipment, net | 3,065 |  |  | 2,306 |  |
| Goodwill | 6,497 |  |  | 5,679 |  |
| Other intangible assets, net | 4,084 |  |  | 3,500 |  |
| Other assets | 4,191 |  |  | 2,161 |  |
| Total assets | $ | 56,079 |  |  | $ | 52,359 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,289 |  |  | $ | 1,858 |  |
| Payroll and other benefits related liabilities | 895 |  |  | 934 |  |
| Unearned revenues | 513 |  |  | 509 |  |
| Short-term debt | 1,998 |  |  | 1,749 |  |
| Other current liabilities | 5,450 |  |  | 2,261 |  |
| Total current liabilities | 10,145 |  |  | 7,311 |  |
| Unearned revenues | 2,220 |  |  | 2,377 |  |
| Long-term debt | 9,939 |  |  | 10,008 |  |
| Other liabilities | 2,441 |  |  | 895 |  |
| Total liabilities | 24,745 |  |  | 20,591 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,477 and 1,476 shares issued and outstanding, respectively | 346 |  |  | 414 |  |
| Retained earnings | 30,768 |  |  | 30,936 |  |
| Accumulated other comprehensive income | 230 |  |  | 428 |  |
| Total Qualcomm stockholders’ equity | 31,344 |  |  | 31,778 |  |
| Noncontrolling interests | (10 | ) |  | (10 | ) |
| Total stockholders’ equity | 31,334 |  |  | 31,768 |  |
| Total liabilities and stockholders’ equity | $ | 56,079 |  |  | $ | 52,359 |  |

[0001234452-17-000075:8k_2_02:97]
Qualcomm Incorporated

[0001234452-17-000075:8k_2_02:98]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-17-000075:8k_2_02:99]
(In millions, except per share data)

[0001234452-17-000075:8k_2_02:100]
(Unaudited)

[0001234452-17-000075:8k_2_02:101]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | March 26, 2017 |  | March 27, 2016 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,689 |  |  | $ | 3,349 |  |  | $ | 7,828 |  |  | $ | 7,436 |  |
| Licensing | 1,327 |  |  | 2,202 |  |  | 3,187 |  |  | 3,890 |  |
| Total revenues | 5,016 |  |  | 5,551 |  |  | 11,015 |  |  | 11,326 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of revenues | 2,208 |  |  | 2,141 |  |  | 4,651 |  |  | 4,675 |  |
| Research and development | 1,386 |  |  | 1,301 |  |  | 2,697 |  |  | 2,653 |  |
| Selling, general and administrative | 615 |  |  | 619 |  |  | 1,206 |  |  | 1,198 |  |
| Other | 78 |  |  | 75 |  |  | 954 |  |  | (299 | ) |
| Total costs and expenses | 4,287 |  |  | 4,136 |  |  | 9,508 |  |  | 8,227 |  |
| Operating income | 729 |  |  | 1,415 |  |  | 1,507 |  |  | 3,099 |  |
| Interest expense | (107 | ) |  | (72 | ) |  | (197 | ) |  | (145 | ) |
| Investment income, net | 235 |  |  | 127 |  |  | 417 |  |  | 226 |  |
| Income before income taxes | 857 |  |  | 1,470 |  |  | 1,727 |  |  | 3,180 |  |
| Income tax expense | (108 | ) |  | (306 | ) |  | (296 | ) |  | (520 | ) |
| Net income | 749 |  |  | 1,164 |  |  | 1,431 |  |  | 2,660 |  |
| Net loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 2 |  |
| Net income attributable to Qualcomm | $ | 749 |  |  | $ | 1,164 |  |  | $ | 1,431 |  |  | $ | 2,662 |  |
| Basic earnings per share attributable to Qualcomm | $ | 0.51 |  |  | $ | 0.78 |  |  | $ | 0.97 |  |  | $ | 1.78 |  |
| Diluted earnings per share attributable to Qualcomm | $ | 0.50 |  |  | $ | 0.78 |  |  | $ | 0.96 |  |  | $ | 1.77 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,477 |  |  | 1,487 |  |  | 1,478 |  |  | 1,495 |  |
| Diluted | 1,489 |  |  | 1,498 |  |  | 1,492 |  |  | 1,507 |  |
| Dividends per share announced | $ | 0.53 |  |  | $ | 0.48 |  |  | $ | 1.06 |  |  | $ | 0.96 |  |

[0001234452-17-000075:8k_2_02:102]
Qualcomm Incorporated

[0001234452-17-000075:8k_2_02:103]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-17-000075:8k_2_02:104]
(In millions)

[0001234452-17-000075:8k_2_02:105]
(Unaudited)

[0001234452-17-000075:8k_2_02:106]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | March 26, 2017 |  | March 27, 2016 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 749 |  |  | $ | 1,164 |  |  | $ | 1,431 |  |  | $ | 2,660 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 342 |  |  | 372 |  |  | 671 |  |  | 736 |  |
| Indefinite and long-lived asset impairment charges | 2 |  |  | 45 |  |  | 34 |  |  | 47 |  |
| Income tax provision less than income tax payments | (117 | ) |  | (86 | ) |  | (230 | ) |  | (189 | ) |
| Gain on sale of wireless spectrum | — |  |  | — |  |  | — |  |  | (380 | ) |
| Non-cash portion of share-based compensation expense | 246 |  |  | 247 |  |  | 485 |  |  | 494 |  |
| Incremental tax benefits from share-based compensation | (2 | ) |  | — |  |  | (37 | ) |  | (2 | ) |
| Net realized gains on marketable securities and other investments | (88 | ) |  | (24 | ) |  | (236 | ) |  | (73 | ) |
| Impairment losses on marketable securities and other investments | 5 |  |  | 43 |  |  | 148 |  |  | 106 |  |
| Other items, net | 101 |  |  | 60 |  |  | 97 |  |  | 47 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (1,822 | ) |  | (392 | ) |  | (1,691 | ) |  | 254 |  |
| Inventories | 109 |  |  | (212 | ) |  | (245 | ) |  | 79 |  |
| Other assets | 123 |  |  | 55 |  |  | 107 |  |  | 121 |  |
| Trade accounts payable | (469 | ) |  | 87 |  |  | (677 | ) |  | 137 |  |
| Payroll, benefits and other liabilities | 1,632 |  |  | (708 | ) |  | 2,417 |  |  | (610 | ) |
| Unearned revenues | 4 |  |  | 86 |  |  | (80 | ) |  | 49 |  |
| Net cash provided by operating activities | 815 |  |  | 737 |  |  | 2,194 |  |  | 3,476 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (122 | ) |  | (125 | ) |  | (251 | ) |  | (253 | ) |
| Purchases of available-for-sale securities | (4,685 | ) |  | (4,038 | ) |  | (8,802 | ) |  | (7,775 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 6,255 |  |  | 2,693 |  |  | 13,146 |  |  | 5,806 |  |
| Purchases of trading securities | — |  |  | (28 | ) |  | — |  |  | (177 | ) |
| Proceeds from sales and maturities of trading securities | — |  |  | 635 |  |  | — |  |  | 756 |  |
| Proceeds from sales of other marketable securities | — |  |  | 250 |  |  | — |  |  | 450 |  |
| Deposits of investments designated as collateral | (50 | ) |  | — |  |  | (2,000 | ) |  | — |  |
| Acquisitions and other investments, net of cash acquired | (1,325 | ) |  | (173 | ) |  | (1,382 | ) |  | (623 | ) |
| Proceeds from sale of wireless spectrum | — |  |  | — |  |  | — |  |  | 232 |  |
| Other items, net | 6 |  |  | 67 |  |  | 49 |  |  | 149 |  |
| Net cash provided (used) by investing activities | 79 |  |  | (719 | ) |  | 760 |  |  | (1,435 | ) |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 2,386 |  |  | 3,239 |  |  | 5,113 |  |  | 4,328 |  |
| Repayment of short-term debt | (2,137 | ) |  | (2,290 | ) |  | (4,864 | ) |  | (3,380 | ) |
| Proceeds from issuance of common stock | 159 |  |  | 172 |  |  | 290 |  |  | 271 |  |
| Repurchases and retirements of common stock | (283 | ) |  | (1,548 | ) |  | (727 | ) |  | (3,598 | ) |
| Dividends paid | (783 | ) |  | (710 | ) |  | (1,567 | ) |  | (1,427 | ) |
| Incremental tax benefits from share-based compensation | 2 |  |  | — |  |  | 37 |  |  | 2 |  |
| Other items, net | (10 | ) |  | (20 | ) |  | (52 | ) |  | (18 | ) |
| Net cash used by financing activities | (666 | ) |  | (1,157 | ) |  | (1,770 | ) |  | (3,822 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 11 |  |  | 1 |  |  | (6 | ) |  | (4 | ) |
| Net increase (decrease) in cash and cash equivalents | 239 |  |  | (1,138 | ) |  | 1,178 |  |  | (1,785 | ) |
| Cash and cash equivalents at beginning of period | 6,885 |  |  | 6,913 |  |  | 5,946 |  |  | 7,560 |  |
| Cash and cash equivalents at end of period | $ | 7,124 |  |  | $ | 5,775 |  |  | $ | 7,124 |  |  | $ | 5,775 |  |
