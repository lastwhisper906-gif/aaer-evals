# QCOM notes — 0001234452-17-000077


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001234452-17-000077:notes:1]
[same as prior period, unchanged from 0001234452-17-000028:notes:1]

[0001234452-17-000077:notes:2]
| Accounts Receivable (in millions) |  |  |  |
|  | March 26, 2017 |  | September 25, 2016 |
| Trade, net of allowances for doubtful accounts of $1 and $1, respectively | $ | 4,177 |  |  | $ | 2,194 |  |
| Long-term contracts | 12 |  |  | 20 |  |
| Other | 12 |  |  | 5 |  |
|  | $ | 4,201 |  |  | $ | 2,219 |  |

[0001234452-17-000077:notes:3]
Approximately half of the increase in accounts receivable was due to the underpayment of royalties reported by and deemed collectible from certain of the Company’s licensees that manufacture products for Apple. This same amount is recorded in customer-related liabilities for Apple, since the Company does not have the contractual right to offset these amounts. The remaining increase in accounts receivable resulted from the timing of the collection of payments from certain of the Company’s other licensees, the acquisition of receivables in connection with the RF360 Holdings joint venture (Note 8) and the timing of integrated circuit shipments.

[0001234452-17-000077:notes:4]
| Inventories (in millions) |  |  |  |
|  | March 26, 2017 |  | September 25, 2016 |
| Raw materials | $ | 73 |  |  | $ | 1 |  |
| Work-in-process | 1,018 |  |  | 847 |  |
| Finished goods | 975 |  |  | 708 |  |
|  | $ | 2,066 |  |  | $ | 1,556 |  |

[0001234452-17-000077:notes:5]
| Other Current Liabilities (in millions) |  |  |  |
|  | March 26, 2017 |  | September 25, 2016 |
| Customer incentives and other customer-related liabilities | $ | 2,665 |  |  | $ | 1,710 |  |
| Accrual for BlackBerry arbitration decision (Note 6) | 974 |  |  | — |  |
| Accrual for KFTC decision (Note 6) | 921 |  |  | — |  |
| Other | 890 |  |  | 551 |  |
|  | $ | 5,450 |  |  | $ | 2,261 |  |

[0001234452-17-000077:notes:6]
Other Income, Costs and Expenses. Other expenses in the three months ended March 26, 2017 consisted of $53 million in foreign currency losses related to the fine imposed by the Korea Fair Trade Commission (KFTC), which was accrued in the first quarter of fiscal 2017 (Note 6), and $25 million in restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan, which was substantially implemented in fiscal 2016. Other expenses in the six months ended March 26, 2017 consisted of a $921 million charge related to the KFTC fine, including related foreign currency losses, and $33 million in restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan.

[0001234452-17-000077:notes:7]
Other expenses in the three months ended March 27, 2016 consisted of restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan. Other income in the six months ended March 27, 2016 included a gain of $380 million on the sale of wireless spectrum in the United Kingdom that was held by the QSI (Qualcomm Strategic Initiative) segment in the first quarter of fiscal 2016 for $232 million in cash and $275 million in deferred payments due in 2020 to 2023, which were recorded at their present values in other assets. Other income in the six months ended March 27, 2016 also included $129 million in restructuring and restructuring-related charges, which were partially offset by a $48 million gain on the sale of the Company’s business that provided augmented reality applications, both of which related to the Company’s Strategic Realignment Plan.

[0001234452-17-000077:notes:8]
| Investment Income, Net (in millions) |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | March 26, 2017 |  | March 27, 2016 |
| Interest and dividend income | $ | 153 |  |  | $ | 158 |  |  | $ | 320 |  |  | $ | 295 |  |
| Net realized gains on marketable securities | 67 |  |  | 1 |  |  | 206 |  |  | 43 |  |
| Net realized gains on other investments | 21 |  |  | 23 |  |  | 30 |  |  | 30 |  |
| Impairment losses on marketable securities | (3 | ) |  | (41 | ) |  | (125 | ) |  | (90 | ) |
| Impairment losses on other investments | (2 | ) |  | (2 | ) |  | (23 | ) |  | (16 | ) |
| Equity in net losses of investees | (14 | ) |  | (11 | ) |  | (11 | ) |  | (31 | ) |
| Net gains (losses) on derivative investments | 13 |  |  | (1 | ) |  | 20 |  |  | (5 | ) |
|  | $ | 235 |  |  | $ | 127 |  |  | $ | 417 |  |  | $ | 226 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001234452-17-000077:notes:9]
The unaudited pro forma results presented below include adjustments for the step-up of inventories to fair value, amortization and depreciation of identified intangible assets and property, plant and equipment, adjustments for certain acquisition-related charges, interest expense related to the Put and Call Option and related tax effects (in millions):

[0001234452-17-000077:notes:10]
|  | (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | March 26, 2017 |  | March 27, 2016 |
| Revenues | $ | 6,108 |  |  | $ | 5,799 |  |  | $ | 12,504 |  |  | $ | 11,810 |  |
| Net income attributable to Qualcomm | 1,481 |  |  | 1,182 |  |  | 2,236 |  |  | 2,651 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001234452-17-000077:notes:11]
[same as prior period, unchanged from 0001234452-17-000028:notes:8]

[0001234452-17-000077:notes:12]
RF360 Holdings. On February 3, 2017 (the Closing Date), the Company and TDK Corporation (TDK) completed the formation of a joint venture, under the name RF360 Holdings Singapore Pte. Ltd. (RF360 Holdings), to enable delivery of radio frequency front-end (RFFE) modules and radio frequency (RF) filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others. The joint venture is initially owned 51% by Qualcomm Global Trading Pte. Ltd. (Qualcomm Global Trading), a Singapore corporation and wholly-owned subsidiary of the Company, and 49% by EPCOS AG (EPCOS), a German wholly-owned subsidiary of TDK. Certain intellectual property, patents and filter and module design and manufacturing assets were carved out of existing TDK businesses and are owned by the joint venture, and certain assets were acquired directly by affiliates of the Company. Qualcomm Global Trading has the option to acquire (and EPCOS has an option to sell) EPCOS’s interest in the joint venture for $1.15 billion (Settlement Amount) 30 months after the Closing Date (the Put and Call Option).

[0001234452-17-000077:notes:13]
EPCOS will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the Closing Date, which is a substitute for and in lieu of the right of EPCOS to receive any profit sharing, distributions, dividends or other payments of any kind or nature. Such contingent consideration was recorded as a liability at fair value at close, with future changes in fair value recorded in earnings.

[0001234452-17-000077:notes:14]
RF360 Holdings is a variable interest entity, and its results of operations and statement of financial position are included in the Company’s consolidated financial statements (on a one-month reporting lag) as the governance structure of RF360 Holdings provides the Company with the power to direct the activities of the joint venture that most significantly impact its economic performance, such as operating decisions related to research and development, manufacturing and sales and marketing of its products. Since the Put and Call Option is considered a financing of the Company’s purchase of EPCOS’s interest in RF360 Holdings, noncontrolling interest is not recorded in the Company’s consolidated financial statements. Therefore, the Put and Call Option was recorded as a liability at fair value at close and included in other noncurrent liabilities. The liability is being accreted to the Settlement Amount, with the offset recorded as interest expense. The carrying value of the Put and Call Option approximated its estimated fair value at March 26, 2017.

[0001234452-17-000077:notes:15]
The total purchase price consisted of the following (in millions):

[0001234452-17-000077:notes:16]
| Cash paid to TDK | $ | 1,463 |  |
| Fair value of Put and Call Option | 1,112 |  |
| Fair value of contingent consideration and other deferred payments | 492 |  |
| Total purchase price | $ | 3,067 |  |

[0001234452-17-000077:notes:17]
The Company has not finalized the purchase price allocation. Accordingly, the preliminary purchase price allocation shown below could change as the fair values of the tangible and intangible assets acquired and liabilities assumed and the related income tax effects are finalized during the remainder of the measurement period (which will not exceed 12 months from the Closing Date). The preliminary allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0001234452-17-000077:notes:18]
| Cash and cash equivalents | $ | 306 |  |
| Accounts receivable | 303 |  |
| Inventories | 261 |  |
| Intangible assets subject to amortization: |  |
| Technology-based intangible assets | 738 |  |
| Customer-related intangible assets | 87 |  |
| Marketing-related intangible assets | 8 |  |
| In-process research and development (IPR&D) | 75 |  |
| Property, plant and equipment | 838 |  |
| Goodwill | 808 |  |
| Other assets | 42 |  |
| Total assets | $ | 3,466 |  |
| Liabilities | (399 | ) |
|  | $ | 3,067 |  |

[0001234452-17-000077:notes:19]
The Company recognized $808 million in goodwill related to this transaction, of which $269 million is expected to be deductible for tax purposes. The goodwill recognized was allocated to the QCT segment for annual impairment testing purposes. The goodwill is primarily attributable to the assembled workforce and synergies expected to arise after the acquisition. Each category of intangible assets acquired will be amortized on a straight-line basis over the weighted-average useful lives of seven years for technology-based intangible assets, nine years for customer-related intangible assets and one year for marketing-related intangible assets. On the acquisition date, IPR&D consisted of two projects. Upon completion, the IPR&D projects will be amortized over their useful lives of six years. The estimated fair values of the intangible assets and the property, plant and equipment acquired were primarily determined using the income approach and cost approach, respectively, both of which were based on significant inputs that were not observable.

[0001234452-17-000077:notes:20]
The Company’s results of operations for the three and six months ended March 26, 2017 included the operating results of RF360 Holdings on a one-month reporting lag since the date of acquisition, the amounts of which were not material. The following table presents the unaudited pro forma results for the three and six months ended March 26, 2017 and March 27, 2016. The unaudited pro forma financial information combines the results of operations of Qualcomm and RF360 Holdings as though the companies had been combined as of the beginning of fiscal 2016. The pro forma information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at such time. The unaudited pro forma results presented below include adjustments for the step-up of inventories to fair value, amortization and depreciation of identified intangible assets and property, plant and equipment, adjustments for certain acquisition-related charges, interest expense related to the Put and Call Option and related tax effects (in millions):

[0001234452-17-000077:notes:21]
NXP. On October 27, 2016, the Company announced a definitive agreement under which Qualcomm River Holdings, B.V. (Qualcomm River Holdings), an indirect, wholly owned subsidiary of QUALCOMM Incorporated, will acquire NXP Semiconductors N.V. Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration of $38 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products.

[0001234452-17-000077:notes:22]
The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions, including the tender of at least 80% of the issued and outstanding common shares of NXP in the offer (provided that the minimum tender threshold may be reduced to a percentage not less than 70% with the prior written consent of NXP). At an Extraordinary General Meeting of NXP’s shareholders held on January 27, 2017, NXP’s shareholders approved certain matters relating to the transaction, including the appointment of designees of Qualcomm River Holdings to NXP’s board of directors (effective upon the closing of the transaction) and certain transactions that are intended to be consummated after the completion of the tender offer. In addition, the waiting period under the Hart-Scott-Rodino Antitrust Improvements Act of 1976 in the United States, as amended, expired on April 3, 2017.

[0001234452-17-000077:notes:23]
The tender offer is not subject to any financing condition; however, the Company intends to fund the transaction with cash held by foreign entities and new debt. As a result, the Company has secured $11.1 billion in committed financing through a $7.1 billion Bridge Loan Facility and $4.0 billion Term Loan Facility (Note 5). The Company expects to issue additional debt, including accessing the public debt markets in fiscal 2017, in lieu of drawing on the Bridge Loan Facility at close of the NXP transaction.

[0001234452-17-000077:notes:24]
Qualcomm River Holdings and NXP may terminate the definitive agreement under certain circumstances. If the definitive agreement is terminated by NXP in certain circumstances, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the definitive agreement is terminated by Qualcomm River Holdings under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion. In November 2016, as required by the definitive agreement, Qualcomm River Holdings entered into four letters of credit for an aggregate amount of $2.0 billion related to the potential termination fee payable to NXP. Pursuant to the terms of each letter of credit, NXP will have the right to draw amounts to fund certain termination compensation owed by Qualcomm River Holdings to NXP if the definitive agreement is terminated under certain circumstances. The letters of credit expire on June 30, 2018 or if drawn on by NXP or surrendered by Qualcomm River Holdings. Each letter of credit is required to be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. Qualcomm River Holdings is restricted from using the funds deposited as collateral while the letters of credit are outstanding. At March 26, 2017, the letters of credit were fully collateralized through bank time deposits and money market funds, which were recorded as other noncurrent assets.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001234452-17-000077:notes:25]
Commitments and Contingencies

[0001234452-17-000077:notes:26]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe certain ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 ParkerVision patents and seeks damages and injunctive and other relief. On September 25, 2015, ParkerVision filed a motion with the court to sever some claims against the Company and all other defendants into a separate lawsuit. In addition, on December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against the Company and other parties with the United States International Trade Commission (ITC) described below.

[0001234452-17-000077:notes:27]
On December 14, 2015, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. were also named defendants. The complaint asserts that certain of the Company’s products infringe four additional ParkerVision patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. The District Court case was stayed on February 12, 2016 pending completion of the ITC investigation. Subsequently, ParkerVision announced that it had reached a settlement with Samsung which dismissed the Samsung entities from the ITC investigation and related District Court case. On February 2, 2017, the ITC granted ParkerVision’s motion to drop all but one patent and one accused product from the ITC investigation. On March 12, 2017, one day before the ITC hearing was scheduled to begin, ParkerVision moved to withdraw its ITC complaint in its entirety. The Company and the other defendants did not oppose the withdrawal of the complaint. The ITC is expected to formally close the investigation in the coming weeks. ParkerVision has asserted in public statements that it plans to proceed with the related District Court case once the stay is lifted.

[0001234452-17-000077:notes:28]
The Company believes ParkerVision’s claims are without merit.

[0001234452-17-000077:notes:29]
BlackBerry Limited (BlackBerry) Arbitration: On April 20, 2016, the Company and BlackBerry entered into an agreement to arbitrate BlackBerry’s allegation that it overpaid royalties on certain past sales of subscriber units based on the alleged effect of specific provisions in its license agreement. The arbitration hearing was held during the week of February 27, 2017 by a three-judge panel under the rules of the Judicial Arbitration and Mediation Services in San Diego, California. On April 11, 2017, the panel provided its decision, finding that the Company must pay to BlackBerry $815 million, plus interest at a rate of 10% from June 2015. The decision was limited to prepayment provisions unique to BlackBerry’s license agreement with the Company and has no impact on agreements with any other licensee. The decision is binding and is not subject to appeal. BlackBerry is also entitled to recover its reasonable attorneys’ fees to be determined by the panel. A hearing regarding attorneys’ fees is scheduled for May 30, 2017. As a result, the Company recorded a reduction to licensing revenues of $974 million in the second quarter of fiscal 2017.

[0001234452-17-000077:notes:30]
QUALCOMM Incorporated v. Meizu Technology Co., Ltd. et al: On June 23, 2016 and June 29, 2016, the Company filed a series of actions against Meizu Technology Co., Ltd., aka Zhuhai Meizu Technology Co., Ltd. (Meizu) and certain of its distributors in the Intellectual Property Courts in Beijing and Shanghai (China). The first complaint, filed in Beijing on June 23, 2016, requested rulings that the terms of a patent license offered by the Company to Meizu comply with China’s Anti-Monopoly Law and the Company’s applicable fair, reasonable and non-discriminatory licensing commitment. The complaint also sought a ruling that the offered patent license terms should form the basis for a patent license with Meizu for the Company’s fundamental mobile device technologies patented in China, including those relating to 3G (WCDMA and CDMA2000) and 4G (LTE) wireless communications standards, and sought damages for Meizu’s past use of the Company’s patented inventions. On June 29, 2016, the Company filed patent infringement complaints in the Intellectual Property Courts in Beijing and Shanghai alleging infringement of 17 patents by Meizu. The patent infringement actions concerned a broad range of features and technologies used in smartphones, including features relating to 3G (WCDMA and CDMA2000) and 4G (LTE) wireless communications standards, and sought to enjoin Meizu from manufacturing, selling and offering for sale mobile devices that infringe the asserted patents. Meizu also filed actions before China’s Patent Reexamination Board challenging the validity of each of the asserted patents.

[0001234452-17-000077:notes:31]
On October 14, 2016, the Company filed patent infringement complaints against Meizu in the United States ITC and the Mannheim Regional Court in Germany. The ITC complaint sought an exclusion order enjoining Meizu and certain of its distributors from the importation, sale for importation and sale after importation of Meizu mobile devices that infringe certain of the Company’s patents related to semiconductor, radio frequency and digital camera technologies. The German complaint sought damages and to enjoin Meizu from offering, putting into circulation, using, possessing or importing into Germany mobile devices that infringe one of the Company’s patents related to wireless messaging technology. On the same day, the Company also initiated a seizure action in France pursuant to orders from the Paris District Court to obtain evidence for a possible future infringement action in that country.

[0001234452-17-000077:notes:32]
On December 26, 2016, the Company and Meizu entered into several agreements whereby the Company granted Meizu a worldwide royalty-bearing patent license to develop, manufacture and sell CDMA2000, WCDMA and 4G LTE (including “3-mode” GSM, TD-SCDMA and LTE-TDD) complete devices. These agreements resolved all of the patent disputes between the Company and Meizu in China, Germany, France and the United States. Accordingly, the Company and Meizu took appropriate steps to terminate or withdraw the foregoing complaints and actions, which had all been formally dismissed by the respective tribunals as of March 14, 2017.

[0001234452-17-000077:notes:33]
Apple Inc. (Apple) v. Qualcomm Incorporated: On January 20, 2017, Apple filed a complaint against the Company in the United States District Court for the Southern District of California seeking declarations with respect to several of the Company’s patents and alleging that the Company breached certain agreements and violated federal antitrust and California state unfair competition laws. In particular, Apple seeks declaratory judgments of non-infringement by Apple of nine of the Company’s patents, or in the alternative, a declaration of royalties Apple must pay for the patents. Apple further seeks a declaration that the Company’s sale of baseband chipsets exhausts the Company’s patent rights for patents embodied in those chipsets. Separately, Apple seeks to enjoin the Company from seeking excessive royalties from Apple and to disgorge royalties paid by Apple’s contract manufacturers that the court finds were not fair, reasonable and non-discriminatory (FRAND). Apple also claims that the Company’s refusal to make certain payments to Apple under a Business Cooperation and Patent Agreement (Cooperation Agreement) constitutes a breach of contract in violation of California law and seeks damages in the amount of the unpaid payments, alleged to be approximately $1 billion. In addition, Apple claims that the Company has refused to deal with competitors in contravention of the Company’s agreements with applicable standard setting organizations, has used its market position to impose contractual obligations on Apple that prevented Apple from challenging the Company’s licensing practices, has tied the purchase of the Company’s CDMA-enabled and premium LTE-enabled chipsets to licensing certain of the Company’s patents and has required Apple to purchase baseband chipsets exclusively from the Company as a condition of the Company’s payment to Apple of certain rebates, in violation of Section 2 of the Sherman Act and the California Unfair Competition Law. Apple seeks injunctive relief with respect to these claims and a judgment awarding its expenses, costs and attorneys’ fees.

[0001234452-17-000077:notes:34]
On April 10, 2017, the Company filed its Answer and Counterclaims in response to Apple’s complaint denying Apple’s claims and asserting claims against Apple. The counterclaims against Apple include tortious interference with the Company’s long-standing Subscriber Unit License Agreements (SULAs) with third-party contract manufacturers of Apple devices, causing those contract manufacturers to withhold certain royalty payments owed to the Company; breach of contract and the implied covenant of good faith and fair dealing relating to the parties’ Cooperation Agreement; unjust enrichment and declaratory relief relating to the Cooperation Agreement; breach of contract based on Apple’s failure to pay amounts owed to the Company under a Statement of Work relating to a high-speed feature of the Company’s chipsets; breach of the parties’ software agreement; and violation of California Unfair Competition Law based on (i) Apple’s falsely claiming that there was “no discernible difference” between iPhones using the Company’s chipsets and iPhones using Intel Corp.’s chipsets, and (ii) Apple’s threatening the Company to prevent it from promoting the superior performance of the Company’s own chipsets. The Company also seeks declaratory judgments that the Company has satisfied its FRAND commitments with respect to Apple, and that the Company’s SULAs with the contract manufacturers do not violate either competition law or the Company’s FRAND commitments.

[0001234452-17-000077:notes:35]
On January 23, 2017, an Apple subsidiary in China filed two complaints against the Company in the Beijing Intellectual Property Court. On April 1, 2017, the court informed the Company that it had preliminarily granted an application by Apple Inc. to join the actions as a plaintiff, and Apple amended the complaints. One of the complaints alleges a violation of China’s Anti-Monopoly Law (AML complaint); the other complaint requests a determination of the terms of a patent license between the Company and Apple (FRAND complaint). In particular, the AML complaint alleges that (i) the Company has abused its dominant position in communication standard-essential patents licensing markets and certain global baseband chipset markets by charging and offering royalty terms that were excessively high; (ii) the Company refused to license certain implementers of standardized technologies, including Apple and baseband chipset manufacturers; (iii) the Company forced Apple to use only the Company’s products and services; and (iv) the Company bundled licenses to standard-essential patents with licenses to non-standard-essential patents and imposed other unreasonable or discriminatory trading terms on Apple in violation of the AML. The AML complaint seeks a decree that the Company cease the alleged abuse of dominance, as well as damages in the amount of 1 billion Chinese Renminbi (approximately $145 million based on the exchange rate on March 26, 2017). The FRAND complaint makes allegations similar to the AML complaint and further alleges that the Company refused to offer licensing terms for the Company’s cellular standard-essential patents consistent with the Company’s FRAND licensing commitments and failed to provide to Apple certain information about the Company’s patents. The FRAND complaint seeks (i) a declaration that the license terms offered to Apple by the Company for its mobile communication standard essential patents are not compliant with FRAND; (ii) an order that the Company cease its actions that allegedly violate the Company’s FRAND obligations, including pricing on unfair, unreasonable and excessive terms, refusing to deal, imposing unreasonable trade conditions and failing to provide information on the Company’s patents; and (iii) a determination of FRAND-compliant license terms for the Company’s Chinese standard-essential patents. Apple also seeks its expenses in each of the cases. On March 3, 2017, the Company filed objections to the court’s jurisdiction in these cases. On April 17, 2017, the Company filed (i) new jurisdictional objections to the April 1, 2017 complaints; and (ii) opinions on Apple Inc.’s application to join the suits as a plaintiff.

[0001234452-17-000077:notes:36]
On February 16, 2017, Apple and one of its Japanese subsidiaries filed three complaints against the Company in the Tokyo District Court. In the complaints, Apple seeks declaratory judgment of non-infringement by Apple of three of the Company’s patents. Apple further seeks a declaration that the Company’s patent rights with respect to those three patents are exhausted by the Company’s SULAs with the contract manufacturers of Apple’s devices as well as the Company’s sale of baseband chipsets. Finally, Apple seeks an award of fees.

[0001234452-17-000077:notes:37]
On March 2, 2017, the Company learned that Apple and certain of its European subsidiaries issued a Claim Form against the Company in the UK High Court of Justice, Chancery Division, Patents Court on January 23, 2017. The Claim Form alleges several European competition law claims, including refusal to license competing chipmakers, failure to offer Apple a direct license to the Company’s standard-essential patents on FRAND terms, demanding excessive royalties for the Company’s standard-essential patents, and demanding excessive license fees for the use of the Company’s standard-essential patents in connection with chipsets purchased from the Company. Apple also seeks declarations that it is a willing licensee and that commercial activity in relation to its iPhones and iPads attributable to, implemented by, or using the Company’s chipsets does not infringe any of the Company’s patents because the Company either exhausted its patent rights or granted Apple an implied license.

[0001234452-17-000077:notes:38]
The Company believes Apple’s claims in the above matters are without merit.

[0001234452-17-000077:notes:39]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, plaintiffs filed a securities class action complaint against the Company and certain of its current and former officers in the United States District Court for the Southern District of California. On April 29, 2016, plaintiffs filed an amended complaint. On January 27, 2017, the Court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, plaintiffs filed a second amended complaint, alleging that the Company and certain of its current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding the Company’s business outlook and product development between November 19, 2014 and July 22, 2015. The Company intends to move to dismiss that complaint. The second amended complaint seeks unspecified damages, interest, attorneys’ fees and other costs. The Company believes the plaintiffs’ claims are without merit.

[0001234452-17-000077:notes:40]
Securities Class Action Lawsuits: On January 23 and 26, 2017, respectively, two securities class action complaints were filed by purported stockholders of the Company in the United States District Court for the Southern District of California against the Company and certain of its current and former officers and directors. The complaints allege that the defendants violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that the Company is or was engaged in anticompetitive conduct and in connection with the Company’s internal control over financial reporting. The complaints seek unspecified damages, interest, attorneys’ fees and other costs. On March 24, 2017, four sets of plaintiffs filed motions to consolidate the actions and to be appointed lead plaintiff. The Company believes the plaintiffs’ claims are without merit.

[0001234452-17-000077:notes:41]
Consumer Class Action Lawsuits: Since January 18, 2017, more than thirty consumer class action complaints have been filed against the Company in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Although the complaints contain certain differences, in general they all allege that the Company violated various federal and state antitrust and consumer protection laws by, among other things, refusing to license standard-essential patents to its competitors, conditioning the supply of certain of its baseband chipsets on the purchaser first agreeing to license the Company’s entire patent portfolio, entering into exclusive deals with companies including Apple Inc., and charging unreasonably high royalties that do not comply with the Company’s commitments to standard setting organizations. The complaints further allege that the Company was unjustly enriched by the foregoing alleged conduct. The complaints seek unspecified damages, interest, attorneys’ fees and other costs, as well as an order that the Company be enjoined from further unlawful conduct. On April 5, 2017, the Judicial Panel on Multidistrict Litigation (the Judicial Panel) issued a transfer order transferring two of these cases from the Southern District of California to the Northern District of California. On April 7, 2017, the Judicial Panel issued a conditional transfer order that is expected to result in the transfer of the rest of these cases in the Southern District of California to the Northern District of California. The Company believes the plaintiffs’ claims are without merit.

[0001234452-17-000077:notes:42]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 34 different dates, with the next hearing scheduled for April 24, 2017.

[0001234452-17-000077:notes:43]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments since then with respect to this matter.

[0001234452-17-000077:notes:44]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it was conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that the Company has violated provisions of the MRFTA. On January 22, 2017, the Company received the KFTC’s formal written decision, which finds that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with the Company; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders the Company to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chips; (iii) not demand unjustifiable conditions in the Company’s license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on the Company and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between the Company and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposes a fine of approximately 1.03 trillion Korean Won (approximately $927 million), which was paid on March 30, 2017. The Company believes that its business practices do not violate the MRFTA, and on February 21, 2017 filed an action in the Seoul High Court to cancel the KFTC’s decision. On the same day, the Company filed an application with the Seoul High Court to stay the decision’s remedial order pending the Seoul High Court’s final judgment on the Company’s action to cancel the KFTC’s decision. The Seoul High Court has not ruled on the Company’s action to cancel the KFTC’s decision or its application to stay the decision’s remedial order.

[0001234452-17-000077:notes:45]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company provided additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On August 15, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

[0001234452-17-000077:notes:46]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that since 2011 the Company has paid significant amounts to a customer on condition that it exclusively use the Company’s baseband chipsets in its smartphones and tablets. This conduct has allegedly reduced the customer’s incentives to source chipsets from the Company’s competitors and harmed competition and innovation for certain baseband chipsets. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On June 27, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

[0001234452-17-000077:notes:47]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified the Company that it was conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against the Company in the United States District Court for the Northern District of California alleging that the Company engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of baseband processors on the purchaser first agreeing to a license to the Company’s standard-essential patents, paying incentives to purchasers of baseband processors to induce them to accept certain license terms, refusing to license its standard-essential patents to the Company’s competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint seeks a permanent injunction against the Company’s alleged violations of the FTCA and other unspecified ancillary equitable relief. The Company filed a motion to dismiss the FTC’s complaint on April 3, 2017, which is pending. On April 19, 2017, the court set a trial date for January 4, 2019. The Company believes the FTC’s claims are without merit.

[0001234452-17-000077:notes:48]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified the Company that it is conducting an investigation into whether the Company’s patent licensing arrangements violate the Taiwan Fair Trade Act (TFTA). On April 27, 2016, the TFTC specified that the allegations under investigation include whether: (i) the Company jointly licensed its patents rather than separately licensing standard-essential patents and non-standard-essential patents; (ii) the Company’s royalty charges are unreasonable; (iii) the Company unreasonably required licensees to grant it cross-licenses; (iv) the Company failed to provide lists of licensed patents to licensees; (v) the Company violated a FRAND licensing commitment by declining to grant licenses to chipset makers; (vi) the Company declined to sell chipsets to unlicensed potential customers; and (vii) the Company provided royalty rebates to certain companies in exchange for their exclusive use of the Company’s chipsets. If a violation is found, a broad range of remedies is potentially available to the TFTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the TFTC. The Company believes that its business practices do not violate the TFTA. The Company continues to cooperate with the TFTC as it conducts its investigation.

[0001234452-17-000077:notes:49]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. Other than with respect to the BlackBerry Arbitration and the KFTC Investigation, the Company has not recorded any accrual at March 26, 2017 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001234452-17-000077:notes:50]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0001234452-17-000077:notes:51]
Through March 26, 2017, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at March 26, 2017 associated with these indemnification arrangements based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001234452-17-000077:notes:52]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at March 26, 2017 for the remainder of fiscal 2017 and for each of the subsequent four years from fiscal 2018 through 2021 were $4.0 billion, $1.2 billion, $955 million, $356 million and $117 million, respectively, and $29 million thereafter. Of these amounts, for the remainder of fiscal 2017 and for each of the subsequent four years from fiscal 2018 through 2021, commitments to purchase integrated circuit product inventories comprised $3.3 billion, $918 million, $829 million, $281 million, $76 million, respectively, and there were $28 million purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

[0001234452-17-000077:notes:53]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments at March 26, 2017 for the remainder of fiscal 2017 and for each of the subsequent four years from fiscal 2018 through 2021 were $61 million, $107 million, $93 million, $68 million and $53 million, respectively, and $63 million thereafter.

[0001234452-17-000077:notes:54]
Other Commitments. At March 26, 2017, the Company was committed to fund certain strategic investments up to $305 million. Of this amount, $73 million is expected to be funded in the remainder of fiscal 2017. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.


## us-gaap:DebtDisclosureTextBlock

[0001234452-17-000077:notes:55]
Debt

[0001234452-17-000077:notes:56]
Revolving Credit Facility. In November 2016, the Company amended and restated its existing Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit (Amended and Restated Revolving Credit Facility) to increase the aggregate amount available to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. The Company had not previously borrowed any funds under the existing Revolving Credit Facility. Proceeds from the Amended and Restated Revolving Credit Facility are expected to be used for general corporate purposes. Loans under the Amended and Restated Revolving Credit Facility will bear interest, at the option of the Company, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the Amended and Restated Revolving Credit Facility) or the Base Rate (determined in accordance with the Amended and Restated Revolving Credit Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.70% and 0.00% per annum, respectively. The Amended and Restated Revolving Credit Facility has a facility fee, which initially accrues at a rate of 0.05% per annum. At March 26, 2017, the Company had not borrowed any funds under the Amended and Restated Revolving Credit Facility.

[0001234452-17-000077:notes:57]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At March 26, 2017 and September 25, 2016, the Company had $2.0 billion and $1.7 billion, respectively, of outstanding commercial paper recorded as short-term debt with weighted-average interest rates of 0.82% and 0.52%, respectively, which included fees paid to the commercial paper dealers and weighted-average remaining days to maturity of 39 days and 36 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at March 26, 2017 and September 25, 2016.

[0001234452-17-000077:notes:58]
Bridge Loan Facility. In October 2016, the Company entered into commitment letters pursuant to which the Company received commitments for senior unsecured bridge facility loans in an aggregate principal amount up to $13.6 billion (Bridge Loan Facility). Subsequently, the commitments available under the Bridge Loan Facility were reduced to $7.1 billion upon the Company entering into a $4.0 billion Term Loan Facility, described below, and the sale of certain assets by NXP Semiconductors N.V. for estimated net cash proceeds of $2.5 billion in February 2017. Proceeds from the Bridge Loan Facility, if drawn, will be used to finance, in part, the proposed acquisition of NXP by Qualcomm River Holdings B.V., a wholly owned subsidiary of the Company (Qualcomm River Holdings) (Note 8). Loans under the Bridge Loan Facility will only be available on the closing date of the proposed acquisition of NXP. The commitments available under the Bridge Loan Facility will be reduced on a dollar-for-dollar basis by the net cash proceeds of certain issuances of debt or equity securities and the incurrence of certain indebtedness by the Company, and the sales of certain assets by the Company. Commitments under the Bridge Loan Facility will expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the Bridge Loan Facility, (ii) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP and (iii) October 27, 2017 (unless such date is extended in accordance with the NXP purchase agreement).

[0001234452-17-000077:notes:59]
Loans drawn under the Bridge Loan Facility will mature 364 days after the date on which the Bridge Loan Facility is funded and will bear interest at either the reserve-adjusted Eurodollar Rate (determined in accordance with the Bridge Loan Facility) or the Base Rate (determined in accordance with the Bridge Loan Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurodollar Rate and the Base Rate will be 0.75% and 0.00% per annum, respectively, and will adjust 90 days, 180 days and 270 days after the Bridge Loan Facility is funded to 1.00% and 0.00%, respectively, 1.25% and 0.25%, respectively, and 1.50% and 0.50%, respectively. Loans outstanding under the Bridge Loan Facility will also incur duration fees equal to 0.50%, 0.75% and 1.00% of the outstanding principal amount of Bridge Loan Facility loans on the dates that are 90 days, 180 days and 270 days after the funding date, respectively. The Bridge Loan Facility also has a ticking fee, which initially accrues at a rate of 0.05% per annum commencing on December 26, 2016. At March 26, 2017, no amounts were outstanding under the Bridge Loan Facility.

[0001234452-17-000077:notes:60]
Term Loan Facility. In November 2016, the Company entered into a Credit Agreement that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion (Term Loan Facility). Proceeds from the Term Loan Facility, if drawn, will be used to finance the proposed acquisition of NXP. Commitments under the Term Loan Facility will expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the Term Loan Facility, (ii) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP and (iii) October 27, 2017 (unless such date is extended in accordance with the NXP purchase agreement). Loans under the Term Loan Facility will mature on the third anniversary of the date on which they are funded and will bear interest at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the Term Loan Facility) or the Base Rate (determined in accordance with the Term Loan Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.875% and 0.00% per annum, respectively. The Term Loan Facility has a ticking fee, which initially accrues at a rate of 0.05% per annum commencing on December 26, 2016. At March 26, 2017, the Company had not borrowed any funds under the Term Loan Facility.

[0001234452-17-000077:notes:61]
Long-term Debt. The following table provides a summary of the Company’s long-term debt (in millions except percentages):

[0001234452-17-000077:notes:62]
|  | March 26, 2017 |  | September 25, 2016 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 1.38% |  | $ | 250 |  |  | 1.14% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.66% |  | 250 |  |  | 1.42% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 1.59% |  | 1,250 |  |  | 0.93% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 2.10% |  | 1,750 |  |  | 1.69% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.58% |  | 2,000 |  |  | 2.04% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (53 | ) |  |  |  | (57 | ) |  |  |
| Hedge accounting fair value adjustments | (8 | ) |  |  |  | 65 |  |  |  |
| Total long-term debt | $ | 9,939 |  |  |  |  | $ | 10,008 |  |  |  |

[0001234452-17-000077:notes:63]
The interest rate on the floating rate notes due in 2018 and 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At March 26, 2017 and September 25, 2016, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $10.1 billion and $10.6 billion, respectively.

[0001234452-17-000077:notes:64]
In fiscal 2015, the Company entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings in interest expense in the current period.

[0001234452-17-000077:notes:65]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $150 million and $137 million in the six months ended March 26, 2017 and March 27, 2016.

[0001234452-17-000077:notes:66]
Debt Covenants. The Amended and Restated Revolving Credit Facility, the Bridge Loan Facility and the Term Loan Facility require, and the prior Revolving Credit Facility required, that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. At March 26, 2017 and September 25, 2016, the Company was in compliance with the applicable covenants under each facility outstanding at such time.


## us-gaap:DividendsDeclaredTableTextBlock

[0001234452-17-000077:notes:67]
In the six months ended March 26, 2017 and March 27, 2016, dividends charged to retained earnings were as follows (in millions, except per share data):

[0001234452-17-000077:notes:68]
|  | 2017 |  | 2016 |
|  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.53 |  |  | $ | 801 |  |  | $ | 0.48 |  |  | $ | 730 |  |
| Second quarter | 0.53 |  |  | 798 |  |  | 0.48 |  |  | 726 |  |
|  | $ | 1.06 |  |  | $ | 1,599 |  |  | $ | 0.96 |  |  | $ | 1,456 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001234452-17-000077:notes:69]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and the weighted-average number of common shares outstanding during the reporting period. The dilutive common share equivalents, calculated using the treasury stock method, in the three and six months ended March 26, 2017 were 11,284,000 and 14,156,000, respectively, and in the three and six months ended March 27, 2016 were 10,734,000 and 12,582,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share, because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period, were 10,823,000 and 5,443,000 in the three and six months ended March 26, 2017, respectively, and 6,899,000 and 4,036,000 in the three and six months ended March 27, 2016, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001234452-17-000077:notes:70]
[same as prior period, unchanged from 0001234452-17-000028:notes:54]

[0001234452-17-000077:notes:71]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at March 26, 2017 (in millions):

[0001234452-17-000077:notes:72]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 3,270 |  |  | $ | 2,939 |  |  | $ | — |  |  | $ | 6,209 |  |
| Marketable securities |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 319 |  |  | 772 |  |  | — |  |  | 1,091 |  |
| Corporate bonds and notes | — |  |  | 18,330 |  |  | — |  |  | 18,330 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 1,411 |  |  | 41 |  |  | 1,452 |  |
| Equity and preferred securities and equity funds | 70 |  |  | 176 |  |  | — |  |  | 246 |  |
| Debt funds | — |  |  | 615 |  |  | — |  |  | 615 |  |
| Total marketable securities | 389 |  |  | 21,304 |  |  | 41 |  |  | 21,734 |  |
| Derivative instruments | — |  |  | 24 |  |  | — |  |  | 24 |  |
| Other investments | 338 |  |  | — |  |  | 130 |  |  | 468 |  |
| Total assets measured at fair value | $ | 3,997 |  |  | $ | 24,267 |  |  | $ | 171 |  |  | $ | 28,435 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | — |  |  | 28 |  |  | — |  |  | 28 |  |
| Other liabilities | 337 |  |  | — |  |  | 193 |  |  | 530 |  |
| Total liabilities measured at fair value | $ | 337 |  |  | $ | 28 |  |  | $ | 193 |  |  | $ | 558 |  |

[0001234452-17-000077:notes:73]
Activity between Levels of the Fair Value Hierarchy. There were no significant transfers between Level 1 and Level 2 in the six months ended March 26, 2017 and March 27, 2016. The Company recognizes transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. Transfers of marketable securities out of Level 3 in the six months ended March 27, 2016 primarily consisted of debt securities with significant upgrades in credit ratings or for which there were observable inputs.

[0001234452-17-000077:notes:74]
Other investments and other liabilities included in Level 3 at March 26, 2017 were comprised of convertible debt instruments issued by private companies and contingent consideration related to business combinations, respectively, in the six months ended March 26, 2017. There were no transfers of convertible debt instruments or contingent consideration amounts into or out of Level 3 during the six months ended March 26, 2017. When a determination is made to classify an asset or liability within Level 3, the determination is based upon the significance of the unobservable inputs to the overall fair value measurement. The fair value of convertible debt instruments is estimated by the Company based on the estimated timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery. The fair value of contingent consideration related to business combinations is estimated by the Company using a real options approach, which includes inputs, such as projected financial information, market volatility, discount rates and timing of contractual payments. The inputs used by the Company to estimate the fair values of the convertible debt instruments and contingent consideration are generally unobservable, and therefore, they are included in Level 3.

[0001234452-17-000077:notes:75]
Nonrecurring Fair Value Measurements. The Company measures certain assets at fair value on a nonrecurring basis. These assets include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. In the six months ended March 26, 2017 and March 27, 2016, the Company did not have any significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001234452-17-000077:notes:76]
[same as prior period, unchanged from 0001234452-17-000028:notes:60]

[0001234452-17-000077:notes:77]
The Company estimates its annual effective income tax rate to be approximately 17% for fiscal 2017, which is equal to its 17% effective income tax rate for fiscal 2016. Tax benefits from foreign income taxed at rates lower than rates in the United States are expected to be approximately 21% in fiscal 2017, compared to 16% in fiscal 2016. In the six months ended March 26, 2017, the Company recorded a charge of $921 million related to the KFTC fine (Note 6), which is not deductible for tax purposes and is attributable to both the United States and a foreign jurisdiction. The estimated annual effective tax rate of 17% for fiscal 2017 also reflects the increase in the Company’s Singapore tax rate as a result of the expiration of its tax exemption in March 2017, which is partially offset by tax benefits resulting from the increase in the Singapore tax rate that will be in effect when certain deferred tax assets are scheduled to reverse. The annual effective tax rate of 17% for fiscal 2016 reflected a $101 million tax benefit recorded discretely in the third quarter of fiscal 2016 resulting from a worthless stock deduction on a domestic subsidiary of one of the Company’s former display businesses and a $79 million benefit recorded discretely in the first quarter of fiscal 2016 related to fiscal 2015 resulting from the retroactive and permanent reinstatement of the United States federal research and development tax credit.

[0001234452-17-000077:notes:78]
The effective tax rate of 13% for the second quarter of fiscal 2017 was less than the estimated annual effective tax rate of 17% primarily resulting from the reduction to the Company’s United States revenues related to the BlackBerry arbitration decision (Note 6).

[0001234452-17-000077:notes:79]
Unrecognized tax benefits were $279 million and $271 million at March 26, 2017 and September 25, 2016, respectively. The Company believes that it is reasonably possible that the total amounts of unrecognized tax benefits at March 26, 2017 may increase or decrease in the next 12 months.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001234452-17-000077:notes:80]
At March 26, 2017, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001234452-17-000077:notes:81]
| Years to Maturity |  |  |  |  |
| Less Than One Year |  | One to Five Years |  | Five to Ten Years |  | Greater Than Ten Years |  | No Single Maturity Date |  | Total |
| $ | 6,979 |  |  | $ | 10,513 |  |  | $ | 1,396 |  |  | $ | 533 |  |  | $ | 2,067 |  |  | $ | 21,488 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001234452-17-000077:notes:82]
Marketable Securities

[0001234452-17-000077:notes:83]
Marketable securities were comprised as follows (in millions):

[0001234452-17-000077:notes:84]
|  | Current |  | Noncurrent |
|  | March 26, 2017 |  | September 25, 2016 |  | March 26, 2017 |  | September 25, 2016 |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 255 |  |  | $ | 1,116 |  |  | $ | 836 |  |  | $ | 1,099 |  |
| Corporate bonds and notes | 2,273 |  |  | 10,159 |  |  | 16,057 |  |  | 8,584 |  |
| Mortgage- and asset-backed and auction rate securities | 156 |  |  | 1,363 |  |  | 1,296 |  |  | 534 |  |
| Equity and preferred securities and equity funds | 70 |  |  | 64 |  |  | 176 |  |  | 1,682 |  |
| Debt funds | 104 |  |  | — |  |  | 511 |  |  | 1,803 |  |
|  | $ | 2,858 |  |  | $ | 12,702 |  |  | $ | 18,876 |  |  | $ | 13,702 |  |

[0001234452-17-000077:notes:85]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities and auction rate securities.

[0001234452-17-000077:notes:86]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001234452-17-000077:notes:87]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| March 26, 2017 | $ | 57 |  |  | $ | — |  |  | $ | 57 |  |
| March 27, 2016 | 34 |  |  | (11 | ) |  | 23 |  |
| For the six months ended |  |  |  |  |  |
| March 26, 2017 | $ | 303 |  |  | $ | (107 | ) |  | $ | 196 |  |
| March 27, 2016 | 84 |  |  | (22 | ) |  | 62 |  |

[0001234452-17-000077:notes:88]
Available-for-sale securities were comprised as follows (in millions):

[0001234452-17-000077:notes:89]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| March 26, 2017 |  |  |  |  |  |  |  |
| Equity securities | $ | 171 |  |  | $ | 75 |  |  | $ | — |  |  | $ | 246 |  |
| Debt securities (including debt funds) | 21,360 |  |  | 156 |  |  | (28 | ) |  | 21,488 |  |
|  | $ | 21,531 |  |  | $ | 231 |  |  | $ | (28 | ) |  | $ | 21,734 |  |
| September 25, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,554 |  |  | $ | 204 |  |  | $ | (12 | ) |  | $ | 1,746 |  |
| Debt securities (including debt funds) | 24,363 |  |  | 388 |  |  | (93 | ) |  | 24,658 |  |
|  | $ | 25,917 |  |  | $ | 592 |  |  | $ | (105 | ) |  | $ | 26,404 |  |

[0001234452-17-000077:notes:90]
The following table shows the gross unrealized losses and fair values of the Company’s investments in individual securities that are classified as available-for-sale and have been in a continuous unrealized loss position deemed to be temporary for less than 12 months and for more than 12 months, aggregated by investment category (in millions):

[0001234452-17-000077:notes:91]
|  | March 26, 2017 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 366 |  |  | $ | (8 | ) |  | $ | 3 |  |  | $ | — |  |
| Corporate bonds and notes | 2,141 |  |  | (18 | ) |  | 25 |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 69 |  |  | (1 | ) |  | 55 |  |  | (1 | ) |
|  | $ | 2,576 |  |  | $ | (27 | ) |  | $ | 83 |  |  | $ | (1 | ) |

[0001234452-17-000077:notes:92]
|  | September 25, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 444 |  |  | $ | (5 | ) |  | $ | 16 |  |  | $ | — |  |
| Corporate bonds and notes | 2,775 |  |  | (12 | ) |  | 1,033 |  |  | (65 | ) |
| Mortgage- and asset-backed and auction rate securities | 337 |  |  | (3 | ) |  | 211 |  |  | (2 | ) |
| Equity and preferred securities and equity funds | 312 |  |  | (4 | ) |  | 130 |  |  | (8 | ) |
| Debt funds | — |  |  | — |  |  | 309 |  |  | (6 | ) |
|  | $ | 3,868 |  |  | $ | (24 | ) |  | $ | 1,699 |  |  | $ | (81 | ) |

[0001234452-17-000077:notes:93]
In the first quarter of fiscal 2017, the Company announced that it entered into an agreement to acquire NXP Semiconductors N.V. (Note 8). As a result, prior to the closing, the Company has begun, and expects to continue, to divest a substantial portion of its marketable securities portfolio in order to finance, in part, that transaction. Marketable securities that were expected to be used to finance the NXP transaction were classified as noncurrent at March 26, 2017 as they are not considered available for current operations. Given the change in the Company’s intention to sell certain marketable securities, the Company recognized other-than-temporary impairment losses in the six months ended March 26, 2017 for certain marketable securities (Note 2) and may recognize additional losses prior to the sale of such marketable securities. For the remaining available-for-sale securities, which are not expected to be sold to finance the NXP transaction, the Company concluded that the unrealized losses were temporary at March 26, 2017. Further, for debt securities and preferred stock with unrealized losses, the Company did not have the intent to sell, nor was it more likely than not that the Company would be required to sell, such securities before recovery or maturity.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001234452-17-000077:notes:94]
Recent Accounting Pronouncements. In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue as control of goods or services transfers to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Adoption one year early is permitted. Two methods of adoption are permitted: (a) full retrospective adoption, meaning the standard is applied to all periods presented or (b) modified retrospective adoption, meaning the cumulative effect of applying the new guidance is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the new guidance early. The Company currently expects the adoption of this new guidance to most significantly impact its licensing business. Specifically, the Company expects a change in the timing of revenues recognized from sales-based royalties. The Company currently recognizes sales-based royalties as revenues in the period in which such royalties are reported by licensees, which is after the conclusion of the quarter in which the licensees’ sales occur. Under the new guidance, the Company will be required to estimate and recognize sales-based royalties in the period in which the associated sales occur, resulting in an acceleration of revenue recognition compared to the current method. Upon adoption of the new guidance, licenses to use portions of the Company’s intellectual property portfolio will be considered one performance obligation, and license fees will be recognized as revenues on a straight-line basis over the term of the license agreement. The Company currently accounts for customer incentive arrangements in its licensing and chip businesses, including volume-related and other pricing rebates or cost reimbursements for marketing and other activities involving certain of the Company’s products and technologies, based on the maximum potential liability. Under the new guidance, the Company expects to estimate the amount of the customer incentive. The Company does not otherwise expect the adoption of the new guidance will have a material impact on its businesses and is in the process of determining the adoption method.

[0001234452-17-000077:notes:95]
In January 2016, the FASB issued new guidance on classifying and measuring financial instruments, which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk be recognized separately in other comprehensive income. Additionally, it changes the disclosure requirements for financial instruments. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Early adoption is permitted for certain provisions. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt certain provisions early.

[0001234452-17-000077:notes:96]
In February 2016, the FASB issued new guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease guidance. The new guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. The new guidance must be adopted using the modified retrospective approach and will be effective for the Company starting in the first quarter of fiscal 2020. Early adoption is permitted. The Company does not intend to adopt the new guidance early and is in the process of determining the effects the adoption will have on its consolidated financial statements.

[0001234452-17-000077:notes:97]
In March 2016, the FASB issued new guidance that changes the accounting for share-based payments. Under the new guidance, excess tax benefits associated with share-based payment awards will be recognized through earnings when the awards vest or settle, rather than in stockholders’ equity. In addition, it will increase the number of shares an employer can withhold to cover income taxes on share-based payment awards and still qualify for the exemption to liability classification. The new guidance will be effective for the Company starting in the first quarter of fiscal 2018. Early adoption is permitted in any annual or interim period. The Company does not intend to adopt the new guidance early and is in the process of determining the effects the adoption will have on its consolidated financial statements.

[0001234452-17-000077:notes:98]
In June 2016, the FASB issued new guidance that changes the accounting for recognizing impairments of financial assets. Under the new guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The new guidance also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The new guidance will be effective for the Company starting in the first quarter of fiscal 2021. Early adoption is permitted starting in the first quarter of fiscal 2020. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.

[0001234452-17-000077:notes:99]
In August 2016, the FASB issued new guidance related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. The Company does not intend to adopt the new guidance early and is in the process of determining the effects the adoption will have on its consolidated financial statements.

[0001234452-17-000077:notes:100]
In October 2016, the FASB issued new guidance that changes the accounting for income tax effects of intra-entity transfers of assets other than inventory. Under the new guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its consolidated financial statements as well as whether to adopt the new guidance early.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001234452-17-000077:notes:101]
[same as prior period, unchanged from 0001234452-17-000028:notes:84]

[0001234452-17-000077:notes:102]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 25, 2016. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and six-month periods ended March 26, 2017 and March 27, 2016 included 13 weeks and 26 weeks, respectively.

[0001234452-17-000077:notes:103]
[same as prior period, unchanged from 0001234452-17-000028:notes:86]

[0001234452-17-000077:notes:104]
[same as prior period, unchanged from 0001234452-17-000028:notes:87]

[0001234452-17-000077:notes:105]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | March 26, 2017 |  | March 27, 2016 |
| Cost of equipment and services revenues | $ | 10 |  |  | $ | 10 |  |  | $ | 20 |  |  | $ | 20 |  |
| Research and development | 155 |  |  | 161 |  |  | 308 |  |  | 326 |  |
| Selling, general and administrative | 81 |  |  | 76 |  |  | 157 |  |  | 148 |  |
| Share-based compensation expense before income taxes | 246 |  |  | 247 |  |  | 485 |  |  | 494 |  |
| Related income tax benefit | (36 | ) |  | (27 | ) |  | (84 | ) |  | (87 | ) |
|  | $ | 210 |  |  | $ | 220 |  |  | $ | 401 |  |  | $ | 407 |  |

[0001234452-17-000077:notes:106]
At March 26, 2017, total unrecognized compensation expense related to nonvested restricted stock units granted prior to that date was $1.3 billion, which is expected to be recognized over a weighted-average period of 1.9 years.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001234452-17-000077:notes:107]
[same as prior period, unchanged from 0001234452-17-000028:notes:92]

[0001234452-17-000077:notes:108]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | March 26, 2017 |  | March 27, 2016 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 65 |  |  | $ | 68 |  |  | $ | 138 |  |  | $ | 132 |  |
| Reduction to revenues related to BlackBerry arbitration decision | (974 | ) |  | — |  |  | (974 | ) |  | — |  |
| Intersegment eliminations | — |  |  | (1 | ) |  | — |  |  | (2 | ) |
|  | $ | (909 | ) |  | $ | 67 |  |  | $ | (836 | ) |  | $ | 130 |  |
| EBT |  |  |  |  |  |  |  |
| Reduction to revenues related to BlackBerry arbitration decision | $ | (974 | ) |  | $ | — |  |  | $ | (974 | ) |  | $ | — |  |
| Unallocated cost of revenues | (119 | ) |  | (115 | ) |  | (213 | ) |  | (266 | ) |
| Unallocated research and development expenses | (277 | ) |  | (186 | ) |  | (546 | ) |  | (402 | ) |
| Unallocated selling, general and administrative expenses | (138 | ) |  | (125 | ) |  | (283 | ) |  | (252 | ) |
| Unallocated other expenses, net | (78 | ) |  | (75 | ) |  | (954 | ) |  | (81 | ) |
| Unallocated interest expense | (106 | ) |  | (71 | ) |  | (195 | ) |  | (143 | ) |
| Unallocated investment income, net | 223 |  |  | 89 |  |  | 407 |  |  | 203 |  |
| Nonreportable segments | (108 | ) |  | (117 | ) |  | (189 | ) |  | (239 | ) |
| Intersegment eliminations | — |  |  | (3 | ) |  | — |  |  | — |  |
|  | $ | (1,577 | ) |  | $ | (603 | ) |  | $ | (2,947 | ) |  | $ | (1,180 | ) |

[0001234452-17-000077:notes:109]
[same as prior period, unchanged from 0001234452-17-000028:notes:90]

[0001234452-17-000077:notes:110]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26, 2017 |  | March 27, 2016 |  | March 26, 2017 |  | March 27, 2016 |
| Cost of revenues | $ | 106 |  |  | $ | 105 |  |  | $ | 191 |  |  | $ | 246 |  |
| Research and development expenses | 12 |  |  | 2 |  |  | 14 |  |  | 5 |  |
| Selling, general and administrative expenses | 57 |  |  | 28 |  |  | 118 |  |  | 57 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001234452-17-000077:notes:111]
Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity in the six months ended March 26, 2017 were as follows (in millions):

[0001234452-17-000077:notes:112]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Total Accumulated Other Comprehensive Income |
| Balance at September 25, 2016 | $ | (161 | ) |  | $ | 6 |  |  | $ | 532 |  |  | $ | 51 |  |  | $ | 428 |  |
| Other comprehensive (loss) income before reclassifications | (10 | ) |  | 6 |  |  | (141 | ) |  | (3 | ) |  | (148 | ) |
| Reclassifications from accumulated other comprehensive income (loss) | — |  |  | 11 |  |  | (59 | ) |  | (2 | ) |  | (50 | ) |
| Other comprehensive (loss) income | (10 | ) |  | 17 |  |  | (200 | ) |  | (5 | ) |  | (198 | ) |
| Balance at March 26, 2017 | $ | (171 | ) |  | $ | 23 |  |  | $ | 332 |  |  | $ | 46 |  |  | $ | 230 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001234452-17-000077:notes:113]
[same as prior period, unchanged from 0001234452-17-000028:notes:96]

[0001234452-17-000077:notes:114]
|  | QCT |  | QTL |  | QSI |  | ReconcilingItems |  | Total |
| For the three months ended |  |  |  |  |  |  |  |  |  |
| March 26, 2017 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 3,676 |  |  | $ | 2,249 |  |  | $ | — |  |  | $ | (909 | ) |  | $ | 5,016 |  |
| EBT | 475 |  |  | 1,959 |  |  | — |  |  | (1,577 | ) |  | 857 |  |
| March 27, 2016 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 3,337 |  |  | $ | 2,135 |  |  | $ | 12 |  |  | $ | 67 |  |  | $ | 5,551 |  |
| EBT | 170 |  |  | 1,857 |  |  | 46 |  |  | (603 | ) |  | 1,470 |  |
| For the six months ended |  |  |  |  |  |  |  |  |  |
| March 26, 2017 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 7,777 |  |  | $ | 4,060 |  |  | $ | 14 |  |  | $ | (836 | ) |  | $ | 11,015 |  |
| EBT | 1,199 |  |  | 3,492 |  |  | (17 | ) |  | (2,947 | ) |  | 1,727 |  |
| March 27, 2016 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 7,433 |  |  | $ | 3,742 |  |  | $ | 21 |  |  | $ | 130 |  |  | $ | 11,326 |  |
| EBT | 760 |  |  | 3,195 |  |  | 405 |  |  | (1,180 | ) |  | 3,180 |  |
| Total assets |  |  |  |  |  |  |  |  |  |
| March 26, 2017 | $ | 3,969 |  |  | $ | 2,232 |  |  | $ | 1,014 |  |  | $ | 48,864 |  |  | $ | 56,079 |  |
| September 25, 2016 | 2,995 |  |  | 644 |  |  | 910 |  |  | 47,810 |  |  | 52,359 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001234452-17-000077:notes:115]
Changes in stockholders’ equity in the six months ended March 26, 2017 were as follows (in millions):

[0001234452-17-000077:notes:116]
|  | Qualcomm Stockholders’ Equity |  | Noncontrolling Interests |  | Total Stockholders’ Equity |
| Balance at September 25, 2016 | $ | 31,778 |  |  | $ | (10 | ) |  | $ | 31,768 |  |
| Net income | 1,431 |  |  | — |  |  | 1,431 |  |
| Other comprehensive loss | (198 | ) |  | — |  |  | (198 | ) |
| Common stock issued under employee benefit plans and related tax benefits | 320 |  |  | — |  |  | 320 |  |
| Share-based compensation | 515 |  |  | — |  |  | 515 |  |
| Tax withholdings related to vesting of share-based payments | (175 | ) |  | — |  |  | (175 | ) |
| Dividends | (1,599 | ) |  | — |  |  | (1,599 | ) |
| Stock repurchases | (727 | ) |  | — |  |  | (727 | ) |
| Other | (1 | ) |  | — |  |  | (1 | ) |
| Balance at March 26, 2017 | $ | 31,344 |  |  | $ | (10 | ) |  | $ | 31,334 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001234452-17-000077:notes:117]
[same as prior period, unchanged from 0001234452-17-000028:notes:100]

[0001234452-17-000077:notes:118]
[same as prior period, unchanged from 0001234452-17-000028:notes:101]

[0001234452-17-000077:notes:119]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense; certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. Additionally, starting with acquisitions in the second quarter of fiscal 2017, unallocated charges include recognition of the depreciation related to the step-up of property, plant and equipment to fair value. Such changes related to acquisitions that were completed prior to the second quarter of fiscal 2017 continue to be allocated to the respective segment, and such amounts are not material. All of the costs related to the initial research of 5G technology are included in unallocated corporate research and development expenses, whereas initial costs related to the research of 3G and 4G technology were recorded in both the QCT segment and unallocated corporate research and development expenses based on the nature of the activity. Fiscal 2016 results have not been revised as such costs were incurred prior to fiscal 2014.

[0001234452-17-000077:notes:120]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets are comprised primarily of certain non-marketable equity instruments and other investments and a receivable from the sale of wireless spectrum in fiscal 2016 (Note 2). The increase in QCT segment assets resulted primarily from our recently formed RF360 Holdings joint venture in the second quarter of fiscal 2017 (Note 8). The increase in QTL segment assets was due to an increase in accounts receivable (Note 2). Total segment assets differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable securities, property, plant and equipment, deferred tax assets, intangible assets and assets of nonreportable segments.

[0001234452-17-000077:notes:121]
The reduction to revenues related to the BlackBerry arbitration decision (Note 6) was not allocated to QTL in the Company’s management reports because it will not be considered in evaluating segment results. Unallocated other expense in the six months ended March 26, 2017 was comprised of the fine imposed by the KFTC (Note 6) and restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan, which was substantially implemented in fiscal 2016 (Note 2). Unallocated other expense in the six months ended March 27, 2016 was comprised of net restructuring and restructuring-related charges associated with the Company’s Strategic Realignment Plan.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001234452-17-000077:notes:122]
[same as prior period, unchanged from 0001234452-17-000028:notes:105]

[0001234452-17-000077:notes:123]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity in the six months ended March 26, 2017 were as follows (in millions):

[0001234452-17-000077:notes:124]
Reclassifications from accumulated other comprehensive income related to available-for-sale securities of $35 million and $48 million in the three and six months ended March 26, 2017, respectively, and $11 million and $18 million in the three and six months ended March 27, 2016, respectively, were recorded in investment income, net (Note 2). Reclassifications from accumulated other comprehensive income related to foreign currency translation losses were negligible in the three and six months ended March 27, 2016 and were recorded in selling, general and administrative expenses and other operating expenses.

[0001234452-17-000077:notes:125]
Stock Repurchase Program. On March 9, 2015, the Company announced a stock repurchase program authorizing it to repurchase up to $15 billion of the Company’s common stock. The stock repurchase program has no expiration date. In the six months ended March 26, 2017 and March 27, 2016, the Company repurchased and retired 11,488,000 and 68,335,000 shares for $727 million and $3.6 billion, respectively, before commissions. At March 26, 2017, $2.3 billion remained authorized for repurchase under the Company’s stock repurchase program.

[0001234452-17-000077:notes:126]
Dividends. On March 7, 2017, the Company announced a 7.5% increase in its quarterly cash dividend from $0.53 to $0.57 per share of common stock, which is effective for dividends payable after March 22, 2017. On April 12, 2017, the Company announced a cash dividend of $0.57 per share on the Company’s common stock, payable on June 21, 2017 to stockholders of record as of the close of business on May 31, 2017. In the six months ended March 26, 2017 and March 27, 2016, dividends charged to retained earnings were as follows (in millions, except per share data):
