# QCOM 8-K — 0000804328-26-000060 filed 2026-04-29

## item codes, every 8-K on or before 2026-04-29

- 2026-04-29 0000804328-26-000060 — 2.02, 9.01
- 2026-03-19 0000804328-26-000041 — 5.07
- 2026-02-04 0000804328-26-000016 — 2.02, 9.01
- 2026-01-16 0000804328-26-000008 — 5.02
- 2025-12-16 0000804328-25-000098 — 5.02
- 2025-12-10 0000804328-25-000096 — 5.03, 9.01
- 2025-11-05 0000804328-25-000084 — 2.02, 9.01
- 2025-09-02 0000804328-25-000054 — 5.02
- 2025-08-25 0000804328-25-000049 — 5.02
- 2025-07-30 0000804328-25-000044 — 2.02, 9.01
- 2025-06-09 0001104659-25-057814 — 3.02
- 2025-05-22 0001104659-25-051981 — 1.01, 8.01, 9.01
- 2025-05-13 0000804328-25-000034 — 5.02
- 2025-04-30 0000804328-25-000029 — 2.02, 9.01
- 2025-03-20 0000804328-25-000018 — 5.07
- 2025-02-05 0000804328-25-000010 — 2.02, 9.01
- 2024-12-12 0000804328-24-000079 — 5.02
- 2024-11-06 0000804328-24-000074 — 2.02, 9.01
- 2024-10-09 0000804328-24-000064 — 5.02
- 2024-08-09 0000804328-24-000061 — 1.01, 1.02, 2.03, 9.01
- 2024-07-31 0000804328-24-000055 — 2.02, 9.01
- 2024-05-09 0000804328-24-000042 — 7.01
- 2024-05-01 0000804328-24-000038 — 2.02, 9.01
- 2024-03-07 0000804328-24-000020 — 5.07, 9.01
- 2024-01-31 0000804328-24-000015 — 2.02, 9.01
- 2024-01-23 0000804328-24-000005 — 5.02
- 2023-11-01 0000804328-23-000054 — 2.02, 9.01
- 2023-08-02 0000804328-23-000042 — 2.02, 9.01
- 2023-07-21 0000804328-23-000033 — 5.03, 9.01
- 2023-05-03 0000804328-23-000022 — 2.02, 9.01
- 2023-03-09 0000804328-23-000014 — 5.07
- 2023-02-02 0000804328-23-000005 — 2.02, 9.01
- 2022-12-08 0001728949-22-000041 — 5.02
- 2022-11-09 0001104659-22-116535 — 1.01, 8.01, 9.01
- 2022-11-02 0000804328-22-000020 — 2.02, 9.01
- 2022-07-27 0001728949-22-000039 — 2.02, 9.01
- 2022-05-09 0001104659-22-057562 — 1.01, 8.01, 9.01
- 2022-04-27 0001728949-22-000025 — 2.02, 9.01
- 2022-03-14 0001728949-22-000016 — 5.07
- 2022-02-02 0001728949-22-000011 — 2.02, 9.01
- 2021-11-03 0001728949-21-000075 — 2.02, 9.01
- 2021-10-04 0001104659-21-122578 — 1.01, 7.01, 9.01
- 2021-07-28 0001728949-21-000065 — 2.02, 9.01
- 2021-07-23 0001728949-21-000055 — 5.03, 9.01
- 2021-05-21 0001728949-21-000048 — 5.02
- 2021-04-28 0001728949-21-000042 — 2.02, 9.01
- 2021-03-15 0001628280-21-004741 — 5.07
- 2021-02-03 0001728949-21-000021 — 2.02, 9.01
- 2021-01-13 0001728949-21-000009 — 1.01, 9.01
- 2021-01-08 0001728949-21-000004 — 5.02
- 2020-12-10 0001104659-20-134200 — 1.01, 1.02, 2.03, 9.01
- 2020-11-19 0001728949-20-000070 — 5.02
- 2020-11-04 0001728949-20-000066 — 2.02, 9.01
- 2020-08-18 0001104659-20-096322 — 1.01, 8.01, 9.01
- 2020-08-05 0001104659-20-090597 — 8.01, 9.01
- 2020-07-29 0001728949-20-000056 — 2.02, 9.01
- 2020-07-24 0001728949-20-000047 — 5.02
- 2020-05-11 0001104659-20-058923 — 1.01, 8.01, 9.01
- 2020-05-04 0001728949-20-000037 — 5.02
- 2020-04-29 0001728949-20-000030 — 2.02, 9.01
- 2020-03-13 0001728949-20-000015 — 5.07
- 2020-02-05 0001728949-20-000010 — 2.02, 9.01
- 2019-11-06 0001728949-19-000074 — 5.02
- 2019-11-06 0001728949-19-000071 — 2.02, 9.01
- 2019-08-28 0001728949-19-000058 — 5.02
- 2019-07-31 0001728949-19-000053 — 2.02, 9.01
- 2019-05-10 0001728949-19-000044 — 5.02
- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2026-04-29

- none on or before 2026-04-29

## item 2.02 — earnings release, exhibit 99.1

[0000804328-26-000060:8k_2_02:1]
EX-99.1
2
qcom032926erex991.htm
EX-99.1

[0000804328-26-000060:8k_2_02:2]
Document

[0000804328-26-000060:8k_2_02:3]
Exhibit 99.1

[0000804328-26-000060:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000804328-26-000060:8k_2_02:5]
Qualcomm Contact:

[0000804328-26-000060:8k_2_02:6]
Brett Simpson

[0000804328-26-000060:8k_2_02:7]
Senior Vice President, Investor Relations

[0000804328-26-000060:8k_2_02:8]
Phone: 1-858-658-4813 | e-mail: ir@qualcomm.com

[0000804328-26-000060:8k_2_02:9]
Qualcomm Announces Second Quarter Fiscal 2026 Results

[0000804328-26-000060:8k_2_02:10]
Revenues: $10.6 billion

[0000804328-26-000060:8k_2_02:11]
GAAP EPS: $6.88, Non-GAAP EPS: $2.65

[0000804328-26-000060:8k_2_02:12]
—Record Quarterly QCT Automotive Revenues—

[0000804328-26-000060:8k_2_02:13]
—Diversification: Combined QCT Automotive and IoT Revenues Grew 20% Year-Over-Year—

[0000804328-26-000060:8k_2_02:14]
—Completed $5.4B of Share Repurchases in First Half of Fiscal 2026 and Announced New $20B Authorization—

[0000804328-26-000060:8k_2_02:15]
SAN DIEGO - April 29, 2026 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal second quarter ended March 29, 2026.

[0000804328-26-000060:8k_2_02:16]
“We are pleased to deliver results in line with our guidance, reflecting solid execution as we navigate a challenging memory environment,” said Cristiano Amon, President and CEO of Qualcomm Incorporated. “We are in a period of profound industry transformation — the rise of AI agents is reshaping our roadmap across every platform we develop. We are equally excited by our entry into the data center, where a leading hyperscaler custom silicon engagement is on track for initial shipments later this calendar year. We look forward to providing an update on our growth initiatives, including opportunities in Data Center and Physical AI, at our Investor Day on June 24.”

[0000804328-26-000060:8k_2_02:17]
Second Quarter Results1,2

[0000804328-26-000060:8k_2_02:18]
|  | GAAP |  | Non-GAAP |  |
| (in millions, except per share data and percentages) | Q2 Fiscal 2026 |  | Q2 Fiscal 2025 |  | Change |  | Q2 Fiscal 2026 |  | Q2 Fiscal 2025 |  |  |  |  | Change |  |
| Revenues | $10,599 |  | $10,979 |  | (3%) |  | $10,599 |  | $10,836 |  |  |  |  | (2%) |  |
| Earnings before taxes (EBT) | $2,232 |  | $3,105 |  | (28%) |  | $3,246 |  | $3,694 |  |  |  |  | (12%) |  |
| Net income | $7,370 |  | $2,812 |  | +162% |  | $2,840 |  | $3,172 |  |  |  |  | (10%) |  |
| Diluted earnings per share (EPS) | $6.88 |  | $2.52 |  | +173% |  | $2.65 |  | $2.85 |  |  |  |  | (7%) |  |

[0000804328-26-000060:8k_2_02:19]
(1)  Discussion regarding our use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results are included at the end of this news release in the sections labeled “Note Regarding Use of Non-GAAP Financial Measures” and “Reconciliations of GAAP Results to Non-GAAP Results.”

[0000804328-26-000060:8k_2_02:20]
(2)  Second quarter of fiscal 2026 GAAP results included a $5.7 billion income tax benefit, or $5.33 per share, resulting from the release of a valuation allowance that was established in the fourth quarter of fiscal 2025. Refer to the section labeled “Income Taxes” included within this news release for additional details.

[0000804328-26-000060:8k_2_02:21]
Segment Results

[0000804328-26-000060:8k_2_02:22]
|  | QCT |  | QTL |
| (in millions, except percentages) | Q2 Fiscal 2026 |  | Q2 Fiscal 2025 |  | Change |  | Q2 Fiscal 2026 |  | Q2 Fiscal 2025 |  | Change |  |  |  |
| Revenues | $9,076 |  | $9,469 |  | (4%) |  | $1,382 |  | $1,319 |  | +5% |  |  |  |
| EBT | $2,465 |  | $2,857 |  | (14%) |  | $994 |  | $929 |  | +7% |  |  |  |
| EBT as % of revenues | 27% |  | 30% |  | -3 points |  | 72% |  | 70% |  | +2 points |  |  |  |

[0000804328-26-000060:8k_2_02:23]
| Qualcomm Announces Second Quarter Fiscal 2026 Results | Page 2 of 9 |

[0000804328-26-000060:8k_2_02:24]
QCT Revenue Streams1

[0000804328-26-000060:8k_2_02:25]
| (in millions, except percentages) | Q2 Fiscal 2026 |  | Q2 Fiscal 2025 |  | Change |
| Handsets | $6,024 |  | $6,929 |  | (13%) |
| Automotive | 1,326 |  | 959 |  | +38% |
| IoT (internet of things) | 1,726 |  | 1,581 |  | +9% |
| Total QCT revenues | $9,076 |  | $9,469 |  | (4%) |

[0000804328-26-000060:8k_2_02:26]
(1) We disaggregate QCT revenues based on the industries and applications in which our products are sold.

[0000804328-26-000060:8k_2_02:27]
Return of Capital to Stockholders

[0000804328-26-000060:8k_2_02:28]
During the second quarter of fiscal 2026, we returned $3.7 billion to stockholders, including $945 million, or $0.89 per share, of cash dividends paid and $2.8 billion through repurchases of 19 million shares of common stock.

[0000804328-26-000060:8k_2_02:29]
Income Taxes

[0000804328-26-000060:8k_2_02:30]
In the second quarter of fiscal 2026, we recorded a $5.7 billion income tax benefit, or $5.33 per share, from the release of a valuation allowance that was established in the fourth quarter of fiscal 2025, as we now expect to realize our existing federal deferred tax assets as a result of additional guidance issued on corporate alternative minimum tax by the U.S. Department of Treasury and the Internal Revenue Service. This benefit was excluded from our Non-GAAP metrics but was reflected in our GAAP results.

[0000804328-26-000060:8k_2_02:31]
| Qualcomm Announces Second Quarter Fiscal 2026 Results | Page 3 of 9 |

[0000804328-26-000060:8k_2_02:32]
Business Outlook

[0000804328-26-000060:8k_2_02:33]
Our guidance for the third quarter of fiscal 2026 includes the estimated impact of memory supply constraints and related pricing on demand from several handset OEMs. We now estimate that QCT handset revenues from Chinese customers will reach a bottom in the third quarter and return to sequential growth in the following quarter.

[0000804328-26-000060:8k_2_02:34]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.

[0000804328-26-000060:8k_2_02:35]
|  |  |  | Current Guidance Q3 FY26 Estimates1 |
|  | Revenues |  | $9.2B - $10.0B |  |
|  | Supplemental Revenue Information |  |  |  |
|  | QCT revenues |  | $7.9B - $8.5B |  |
|  | QTL revenues |  | $1.15B - $1.35B |  |
|  | GAAP diluted EPS |  | $1.26 - $1.46 |  |
|  | Less diluted EPS attributable to QSI |  | $— |  |  |
|  | Less diluted EPS attributable to share-based compensation |  | ($0.68) |  |  |
|  | Less diluted EPS attributable to other items2 |  | ($0.16) |  |  |
|  | Non-GAAP diluted EPS |  | $2.10 - $2.30 |  |

[0000804328-26-000060:8k_2_02:36]
(1)  Our outlook does not include provisions for proposed tax law changes, future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable. Further, due to their nature, certain income and expense items, such as certain investments, derivative and foreign currency transaction gains or losses, cannot be accurately forecast. Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain. Our outlook includes the impact of any pending business combinations to the extent they are expected to close in the upcoming quarter. Actual results may differ materially from the outlook.

[0000804328-26-000060:8k_2_02:37]
(2)  Our guidance for diluted EPS attributable to other items for the third quarter of fiscal 2026 is primarily related to acquisition-related items and the tax impact from amortization of previously capitalized domestic research and development expenditures for U.S. federal income tax purposes.

[0000804328-26-000060:8k_2_02:38]
| Qualcomm Announces Second Quarter Fiscal 2026 Results | Page 4 of 9 |

[0000804328-26-000060:8k_2_02:39]
Conference Call and Available Information

[0000804328-26-000060:8k_2_02:40]
Qualcomm’s second quarter fiscal 2026 earnings conference call will be broadcast live on April 29, 2026, beginning at 1:45 p.m. Pacific Time (PT) at https://investor.qualcomm.com/news-events/investor-events. This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G. The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to our financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted to our Investor Relations website at

[0000804328-26-000060:8k_2_02:41]
https://investor.qualcomm.com immediately prior to the commencement of the call. An audio replay will be available on our website and via telephone following the live call for 30 days thereafter. To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415. Callers should use reservation number 13759551.

[0000804328-26-000060:8k_2_02:42]
Our Investor Relations website at https://investor.qualcomm.com contains a significant amount of information about us, including financial and other information for investors, and it is possible that this information could be deemed to be material information. Accordingly, investors and others interested in Qualcomm should review the information posted on our website in addition to following our press releases, SEC filings and public conference calls and webcasts.

[0000804328-26-000060:8k_2_02:43]
About Qualcomm

[0000804328-26-000060:8k_2_02:44]
Qualcomm relentlessly innovates to deliver intelligent computing everywhere, helping the world tackle some of its most important challenges. Building on our 40 years of technology leadership in creating era-defining breakthroughs, we deliver a broad portfolio of solutions built with our leading edge AI, high-performance, low-power computing, and unrivaled connectivity. Our Snapdragon® platforms power extraordinary consumer experiences, and our Qualcomm DragonwingTM products empower businesses and industries to scale to new heights. Together with our ecosystem partners, we enable next-generation digital transformation to enrich lives, improve businesses, and advance societies. At Qualcomm, we are engineering human progress.

[0000804328-26-000060:8k_2_02:45]
Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio. Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of our engineering and research and development functions and substantially all of our products and services businesses, including our QCT semiconductor business. Snapdragon and Qualcomm branded products are products of Qualcomm Technologies, Inc. and/or its subsidiaries. Qualcomm patents are licensed by Qualcomm Incorporated.

[0000804328-26-000060:8k_2_02:46]
Note Regarding Forward-Looking Statements

[0000804328-26-000060:8k_2_02:47]
| Qualcomm Announces Second Quarter Fiscal 2026 Results | Page 5 of 9 |

[0000804328-26-000060:8k_2_02:48]
QUALCOMM Incorporated

[0000804328-26-000060:8k_2_02:49]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000804328-26-000060:8k_2_02:50]
(In millions, except par value amounts)

[0000804328-26-000060:8k_2_02:51]
(Unaudited)

[0000804328-26-000060:8k_2_02:52]
|  | March 29,2026 |  | September 28,2025 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 5,435 |  |  | $ | 5,520 |  |
| Restricted cash | — |  |  | 2,323 |  |
| Marketable securities | 4,364 |  |  | 4,635 |  |
| Accounts receivable, net | 4,347 |  |  | 4,315 |  |
| Inventories | 7,368 |  |  | 6,526 |  |
| Other current assets | 1,598 |  |  | 2,435 |  |
| Total current assets | 23,112 |  |  | 25,754 |  |
| Deferred tax assets | 5,968 |  |  | 743 |  |
| Property, plant and equipment, net | 5,071 |  |  | 4,690 |  |
| Goodwill | 14,251 |  |  | 11,358 |  |
| Other intangible assets, net | 1,575 |  |  | 1,148 |  |
| Other assets | 7,159 |  |  | 6,450 |  |
| Total assets | $ | 57,136 |  |  | $ | 50,143 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 2,973 |  |  | $ | 2,791 |  |
| Payroll and other benefits related liabilities | 1,370 |  |  | 1,839 |  |
| Unearned revenues | 323 |  |  | 358 |  |
| Short-term debt | 498 |  |  | — |  |
| Other current liabilities | 4,603 |  |  | 4,156 |  |
| Total current liabilities | 9,767 |  |  | 9,144 |  |
| Unearned revenues | 70 |  |  | 71 |  |
| Long-term debt | 14,772 |  |  | 14,811 |  |
| Other liabilities | 5,249 |  |  | 4,911 |  |
| Total liabilities | 29,858 |  |  | 28,937 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,059 and 1,074 shares issued and outstanding, respectively | — |  |  | — |  |
| Retained earnings | 26,901 |  |  | 20,646 |  |
| Accumulated other comprehensive income | 377 |  |  | 560 |  |
| Total stockholders’ equity | 27,278 |  |  | 21,206 |  |
| Total liabilities and stockholders’ equity | $ | 57,136 |  |  | $ | 50,143 |  |

[0000804328-26-000060:8k_2_02:53]
| Qualcomm Announces Second Quarter Fiscal 2026 Results | Page 6 of 9 |

[0000804328-26-000060:8k_2_02:54]
QUALCOMM Incorporated

[0000804328-26-000060:8k_2_02:55]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000804328-26-000060:8k_2_02:56]
(In millions, except per share data)

[0000804328-26-000060:8k_2_02:57]
(Unaudited)

[0000804328-26-000060:8k_2_02:58]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  |  | March 29,2026 |  | March 30,2025 |  | March 29,2026 |  | March 30,2025 |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services |  |  |  |  |  | $ | 9,060 |  |  | $ | 9,359 |  |  | $ | 19,526 |  |  | $ | 19,301 |  |
| Licensing |  |  |  |  |  | 1,539 |  |  | 1,620 |  |  | 3,325 |  |  | 3,348 |  |
| Total revenues |  |  |  |  |  | 10,599 |  |  | 10,979 |  |  | 22,851 |  |  | 22,649 |  |
| Costs and expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  |  |  |  | 4,900 |  |  | 4,937 |  |  | 10,468 |  |  | 10,098 |  |
| Research and development |  |  |  |  |  | 2,463 |  |  | 2,216 |  |  | 4,915 |  |  | 4,446 |  |
| Selling, general and administrative |  |  |  |  |  | 898 |  |  | 706 |  |  | 1,763 |  |  | 1,430 |  |
| Other |  |  |  |  |  | 29 |  |  | — |  |  | 29 |  |  | — |  |
| Total costs and expenses |  |  |  |  |  | 8,290 |  |  | 7,859 |  |  | 17,175 |  |  | 15,974 |  |
| Operating income |  |  |  |  |  | 2,309 |  |  | 3,120 |  |  | 5,676 |  |  | 6,675 |  |
| Interest expense |  |  |  |  |  | (171) |  |  | (163) |  |  | (341) |  |  | (326) |  |
| Investment and other income, net |  |  |  |  |  | 94 |  |  | 148 |  |  | 444 |  |  | 391 |  |
| Income before income taxes |  |  |  |  |  | 2,232 |  |  | 3,105 |  |  | 5,779 |  |  | 6,740 |  |
| Income tax benefit (expense) |  |  |  |  |  | 5,138 |  |  | (293) |  |  | 4,596 |  |  | (748) |  |
| Net income |  |  |  |  |  | $ | 7,370 |  |  | $ | 2,812 |  |  | $ | 10,375 |  |  | $ | 5,992 |  |
| Basic earnings per share |  |  |  |  |  | $ | 6.92 |  |  | $ | 2.55 |  |  | $ | 9.71 |  |  | $ | 5.41 |  |
| Diluted earnings per share |  |  |  |  |  | $ | 6.88 |  |  | $ | 2.52 |  |  | $ | 9.65 |  |  | $ | 5.36 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  | 1,066 |  |  | 1,104 |  |  | 1,068 |  |  | 1,107 |  |
| Diluted |  |  |  |  |  | 1,072 |  |  | 1,115 |  |  | 1,075 |  |  | 1,118 |  |

[0000804328-26-000060:8k_2_02:59]
| Qualcomm Announces Second Quarter Fiscal 2026 Results | Page 7 of 9 |

[0000804328-26-000060:8k_2_02:60]
QUALCOMM Incorporated

[0000804328-26-000060:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000804328-26-000060:8k_2_02:62]
(In millions)

[0000804328-26-000060:8k_2_02:63]
(Unaudited)

[0000804328-26-000060:8k_2_02:64]
|  | Six Months Ended |  |  |  |  |  |  |
|  | March 29,2026 |  | March 30,2025 |  |  |  |  |  |  |
| Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net income | $ | 10,375 |  |  | $ | 5,992 |  |  |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 806 |  |  | 833 |  |  |  |  |  |  |  |
| Income tax provision less than income tax payments | (5,857) |  |  | (899) |  |  |  |  |  |  |  |
| Share-based compensation expense | 1,749 |  |  | 1,461 |  |  |  |  |  |  |  |
| Net gains on marketable securities and other investments | (47) |  |  | (9) |  |  |  |  |  |  |  |
| Equity in net earnings of investees | (83) |  |  | (16) |  |  |  |  |  |  |  |
| Other items | (47) |  |  | (12) |  |  |  |  |  |  |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net | 58 |  |  | 227 |  |  |  |  |  |  |  |
| Inventories | (802) |  |  | 202 |  |  |  |  |  |  |  |
| Other assets | 1,019 |  |  | 299 |  |  |  |  |  |  |  |
| Trade accounts payable | 229 |  |  | (97) |  |  |  |  |  |  |  |
| Payroll, benefits and other liabilities | 208 |  |  | (773) |  |  |  |  |  |  |  |
| Unearned revenues | (194) |  |  | (67) |  |  |  |  |  |  |  |
| Net cash provided by operating activities | 7,414 |  |  | 7,141 |  |  |  |  |  |  |  |
| Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | (1,082) |  |  | (491) |  |  |  |  |  |  |  |
| Purchases of debt and equity marketable securities | (1,925) |  |  | (3,326) |  |  |  |  |  |  |  |
| Proceeds from sales and maturities of debt and equity marketable securities | 1,985 |  |  | 2,155 |  |  |  |  |  |  |  |
| Acquisitions and other investments, net of cash acquired | (1,238) |  |  | (341) |  |  |  |  |  |  |  |
| Other items | 38 |  |  | 43 |  |  |  |  |  |  |  |
| Net cash used by investing activities | (2,222) |  |  | (1,960) |  |  |  |  |  |  |  |
| Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 1,246 |  |  | 500 |  |  |  |  |  |  |  |
| Repayment of short-term debt | (750) |  |  | (500) |  |  |  |  |  |  |  |
| Repayment of debt of acquired company | (174) |  |  | — |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock | — |  |  | 201 |  |  |  |  |  |  |  |
| Repurchases and retirements of common stock | (5,442) |  |  | (3,498) |  |  |  |  |  |  |  |
| Dividends paid | (1,895) |  |  | (1,880) |  |  |  |  |  |  |  |
| Payments of tax withholdings related to vesting of share-based awards | (536) |  |  | (609) |  |  |  |  |  |  |  |
| Other items | (24) |  |  | (3) |  |  |  |  |  |  |  |
| Net cash used by financing activities | (7,575) |  |  | (5,789) |  |  |  |  |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (25) |  |  | (38) |  |  |  |  |  |  |  |
| Net decrease in total cash, cash equivalents and restricted cash | (2,408) |  |  | (646) |  |  |  |  |  |  |  |
| Total cash and cash equivalents at beginning of period (including $2,323 classified as restricted cash at September 28, 2025) | 7,843 |  |  | 7,849 |  |  |  |  |  |  |  |
| Total cash and cash equivalents at end of period | $ | 5,435 |  |  | $ | 7,203 |  |  |  |  |  |  |  |

[0000804328-26-000060:8k_2_02:65]
| Qualcomm Announces Second Quarter Fiscal 2026 Results | Page 8 of 9 |

[0000804328-26-000060:8k_2_02:66]
Note Regarding Use of Non-GAAP Financial Measures

[0000804328-26-000060:8k_2_02:67]
The Non-GAAP financial measures presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP. In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, our Non-GAAP financial measures might be different than similarly titled measures used by other companies. Reconciliations between GAAP and Non-GAAP financial measures are presented herein.

[0000804328-26-000060:8k_2_02:68]
We use Non-GAAP financial information: (i) to evaluate, assess and benchmark our operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of our ongoing core operating businesses, including our QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors. Non-GAAP measurements used by us include revenues, cost of revenues, research and development (R&D) expenses, selling, general and administrative (SG&A) expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share. We are able to assess what we believe is a meaningful and comparable set of financial performance measures by using Non-GAAP information. In addition, the HR and Compensation Committee of our Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers. We present Non-GAAP financial information to provide greater transparency to investors with respect to our use of such information in financial and operational decision-making. This Non-GAAP financial information is also used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0000804328-26-000060:8k_2_02:69]
Non-GAAP information presented herein excludes our QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0000804328-26-000060:8k_2_02:70]
•QSI is excluded because we generally expect to exit our strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed as unrelated to our operational performance.

[0000804328-26-000060:8k_2_02:71]
•Share-based compensation expense primarily relates to restricted stock units. We believe that excluding share-based compensation from Non-GAAP financial information allows us and investors to make additional comparisons of the operating activities of our ongoing core businesses over time and with respect to other companies.

[0000804328-26-000060:8k_2_02:72]
•Certain other items are excluded because we view such items as unrelated to the operating activities of our ongoing core businesses, as follows:

[0000804328-26-000060:8k_2_02:73]
◦Acquisition-related items include amortization of acquisition-related intangible assets, substantially all of which relate to the amortization of technology-based intangible assets that is recorded in cost of revenues and will recur in future periods until the related intangible assets have been fully amortized. We view acquisition-related intangible assets as items arising from pre-acquisition activities determined at the time of an acquisition. Acquisition-related intangible assets contribute to revenue generation that has not been excluded from our Non-GAAP financial information. Acquisition-related items also include recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of acquisition-related items, as well as any effects from restructuring the ownership of such acquired assets. We also exclude the operating results of acquired and/or consolidated businesses that, as of close, are expected or required to be sold. Additionally, we exclude certain other acquisition-related charges such as third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition.

[0000804328-26-000060:8k_2_02:74]
◦We exclude certain other items that we view as unrelated to our ongoing businesses, such as major restructuring and restructuring-related costs, asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. We exclude gains and losses driven by the revaluation of our deferred compensation plan liabilities recognized in operating expenses and the offsetting gains and losses on the related plan assets recognized in investment and other income (expense).

[0000804328-26-000060:8k_2_02:75]
◦Beginning in the first quarter of fiscal 2026, we are applying a fixed estimated Non-GAAP tax rate to determine our Non-GAAP provision for income taxes. Our Non-GAAP tax rate is determined annually based on our estimated annual GAAP income tax forecast (computed inclusive of both current and deferred income taxes), adjusted to account for items excluded from our Non-GAAP earnings before taxes as well as certain tax items that are unrelated to the fiscal year in which they are recorded. We will periodically re-evaluate the appropriateness of our Non-GAAP tax rate and may adjust for significant changes, including significant changes in our geographic earnings mix, our corporate structure or tax laws. Prior periods have not been updated for this change as the effect would not be material.

[0000804328-26-000060:8k_2_02:76]
| Qualcomm Announces Second Quarter Fiscal 2026 Results | Page 9 of 9 |

[0000804328-26-000060:8k_2_02:77]
Reconciliations of GAAP Results to Non-GAAP Results

[0000804328-26-000060:8k_2_02:78]
| (in millions, except per share data and percentages) |  |  |  | GAAP to Non-GAAP Reconciliation |  |
|  |  |  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |  |  |  |
| Q2 Fiscal 2026 |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  |  | $10,599 |  |  | $— |  |  | $— |  |  |  | $— |  |  |  | $10,599 |  |  |  |  |  |  |  |
| Operating income (loss) |  |  |  |  | 2,309 |  |  | (3) |  |  | (860) |  |  | (108) |  |  | 3,280 |  |  |  |  |  |  |  |
| EBT |  |  |  |  | 2,232 |  |  | (30) |  |  | (860) |  |  | (124) |  |  | 3,246 |  |  |  |  |  |  |  |
| EBT as % of revenues |  |  |  |  | 21 | % |  |  |  |  |  |  |  |  |  |  |  | 31 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  |  | 7,370 |  |  | (23) |  |  | (757) |  |  | 5,310 |  |  | 2,840 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  |  | $6.88 |  |  | ($0.02) |  |  | ($0.71) |  |  | $4.95 |  |  | $2.65 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  |  | 1,072 |  |  | 1,072 |  |  | 1,072 |  |  | 1,072 |  |  | 1,072 |  |  |  |  |  |  |  |
| Q2 Fiscal 2025 |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  |  | $10,979 |  |  | $— |  |  | $— |  |  |  | $143 |  |  | $10,836 |  |  |  |  |  |  |  |
| Operating income (loss) |  |  |  |  | 3,120 |  |  | (3) |  |  | (703) |  |  | 139 |  |  | 3,687 |  |  |  |  |  |  |  |
| EBT |  |  |  |  | 3,105 |  |  | 10 |  |  | (703) |  |  | 104 |  |  | 3,694 |  |  |  |  |  |  |  |
| EBT as % of revenues |  |  |  |  | 28 | % |  |  |  |  |  |  |  |  |  |  |  | 34 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  |  | 2,812 |  |  | 8 |  |  | (551) |  |  | 183 |  |  | 3,172 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  |  | $2.52 |  |  | $0.01 |  |  | ($0.49) |  |  | $0.16 |  |  | $2.85 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  |  | 1,115 |  |  | 1,115 |  |  | 1,115 |  |  | 1,115 |  |  | 1,115 |  |  |  |  |  |  |  |

[0000804328-26-000060:8k_2_02:79]
(1)  Further details of amounts included in the “Other Items” column for the current periods are included at the end of this news release in the table labeled “Supplemental Information and Reconciliations.” Details of amounts included in the “Other Items” column for the prior period are included in the news release for that period.

[0000804328-26-000060:8k_2_02:80]
(2)  In the second quarter of fiscal 2025, other items excluded from Non-GAAP revenues included licensing revenues resulting from a settlement of a licensing dispute, which was not allocated to our segment results.

[0000804328-26-000060:8k_2_02:81]
Sums may not equal totals due to rounding.

[0000804328-26-000060:8k_2_02:82]
|  | Q2 Fiscal 2026 Supplemental Information and Reconciliations |
| (in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |
| Cost of revenues |  | $4,900 |  |  | $— |  |  | $24 |  |  | $71 |  |  | $4,805 |  |
| Research and development expenses |  | 2,463 |  |  | — |  |  | 623 |  |  | (27) |  |  | 1,867 |  |
| Selling, general and administrative expenses |  | 898 |  |  | 3 |  |  | 213 |  |  | 35 |  |  | 647 |  |
| Other |  | 29 |  |  |  | — |  |  | — |  |  | 29 |  |  | — |  |  |
| Interest expense |  | 171 |  |  | — |  |  | — |  |  | 1 |  |  | 170 |  |
| Investment and other income (expense), net |  | 94 |  |  | (27) |  |  | — |  |  | (15) |  |  | 136 |  |
| Income tax (benefit) expense |  | (5,138) |  |  | (7) |  |  | (103) |  |  | (5,434) |  |  | 406 |  |

[0000804328-26-000060:8k_2_02:83]
(1)  Other items excluded from Non-GAAP results included $88 million of acquisition-related charges (net of a $37 million gain on settlement of debt of an acquired company), $34 million of restructuring and restructuring-related charges and $1 million of interest expense related to a fine imposed on us by the European Commission in 2019. Other items excluded from Non-GAAP results also included $55 million of gains driven by the revaluation of our deferred compensation plan liabilities, which decreases operating expenses, offset by a corresponding $56 million of losses driven by the revaluation of the associated plan assets, which were included within investment and other income (expense), net.

[0000804328-26-000060:8k_2_02:84]
(2)   Tax benefit in the “Other Items” column represents an adjustment to arrive at our fixed estimated Non-GAAP tax rate of 12.5% for the second quarter of fiscal 2026. This adjustment is primarily related to a $5.7 billion income tax benefit from the release of a valuation allowance as we now expect to realize our existing federal deferred tax assets, partially offset by the impact of the amortization of previously capitalized domestic research and development expenditures for U.S. federal income tax purposes (for which the initial benefit was previously excluded from our Non-GAAP results).

[0000804328-26-000060:8k_2_02:85]
Sums may not equal totals due to rounding.
