# QCOM MD&A — 0000804328-26-000061


## mdna

[0000804328-26-000061:mdna:1]
[same as prior period, unchanged from 0000804328-26-000017:mdna:1]

[0000804328-26-000061:mdna:2]
[same as prior period, unchanged from 0000804328-26-000017:mdna:2]

[0000804328-26-000061:mdna:3]
[same as prior period, unchanged from 0000804328-26-000017:mdna:3]

[0000804328-26-000061:mdna:4]
Second Quarter Fiscal 2026 Overview

[0000804328-26-000061:mdna:5]
Revenues for the second quarter of fiscal 2026 were $10.6 billion, a decrease of 3% compared to the year ago quarter, with net income of $7.4 billion, an increase of 162% compared to the year ago quarter. Key items from the second quarter of fiscal 2026 included:

[0000804328-26-000061:mdna:6]
•QCT revenues decreased by 4% in the second quarter of fiscal 2026 compared to the year ago quarter due to lower handset revenues, partially offset by higher automotive and IoT revenues.

[0000804328-26-000061:mdna:7]
•QTL revenues increased by 5% in the second quarter of fiscal 2026 compared to the year ago quarter, primarily due to an increase in estimated revenues per unit, which was primarily driven by favorable mix.

[0000804328-26-000061:mdna:8]
•We recorded a $5.7 billion income tax benefit to release a valuation allowance in the second quarter of fiscal 2026 as we now expect to realize substantially all of our existing federal deferred tax assets as a result of additional guidance issued on corporate alternative minimum tax (CAMT) by the U.S. Department of Treasury and the Internal Revenue Service.

[0000804328-26-000061:mdna:9]
[same as prior period, unchanged from 0000804328-26-000017:mdna:9]

[0000804328-26-000061:mdna:10]
[same as prior period, unchanged from 0000804328-26-000017:mdna:10]

[0000804328-26-000061:mdna:11]
[same as prior period, unchanged from 0000804328-26-000017:mdna:11]

[0000804328-26-000061:mdna:12]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering and research

[0000804328-26-000061:mdna:13]
18

[0000804328-26-000061:mdna:14]
and development functions are operated by Qualcomm Technologies, Inc. (QTI), a subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0000804328-26-000061:mdna:15]
[same as prior period, unchanged from 0000804328-26-000017:mdna:13]

[0000804328-26-000061:mdna:16]
[same as prior period, unchanged from 0000804328-26-000017:mdna:14]

[0000804328-26-000061:mdna:17]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | Change |  | March 29,2026 |  | March 30,2025 |  | Change |
| Equipment and services | $ | 9,060 |  |  | $ | 9,359 |  |  | $ | (299) |  |  | $ | 19,526 |  |  | $ | 19,301 |  |  | $ | 225 |  |
| Licensing | 1,539 |  |  | 1,620 |  |  | (81) |  |  | 3,325 |  |  | 3,348 |  |  | (23) |  |
|  | $ | 10,599 |  |  | $ | 10,979 |  |  | $ | (380) |  |  | $ | 22,851 |  |  | $ | 22,649 |  |  | $ | 202 |  |

[0000804328-26-000061:mdna:18]
Second quarter 2026 vs. 2025

[0000804328-26-000061:mdna:19]
The decrease in revenues in the second quarter fiscal 2026 was primarily due to:

[0000804328-26-000061:mdna:20]
-    $393 million in lower equipment and services revenues from our QCT segment

[0000804328-26-000061:mdna:21]
-    $143 million in licensing revenues from a settlement of a licensing dispute in the second quarter of fiscal 2025, which was not allocated to our segment results

[0000804328-26-000061:mdna:22]
+    $97 million in higher equipment and services revenues from our Data Center segment, primarily driven by our acquisition of Alphawave in the first quarter of fiscal 2026

[0000804328-26-000061:mdna:23]
+    $63 million in higher licensing revenues from our QTL segment

[0000804328-26-000061:mdna:24]
First six months 2026 vs. 2025

[0000804328-26-000061:mdna:25]
The increase in revenues in the first six months of fiscal 2026 was primarily due to:

[0000804328-26-000061:mdna:26]
+    $135 million in higher equipment and services revenues from our QCT segment

[0000804328-26-000061:mdna:27]
+    $120 million in higher licensing revenues from our QTL segment

[0000804328-26-000061:mdna:28]
+    $94 million in higher equipment and services revenues from our Data Center segment, primarily driven by our acquisition of Alphawave in the first quarter of fiscal 2026

[0000804328-26-000061:mdna:29]
-    $143 million in licensing revenues from a settlement of a licensing dispute in the second quarter of fiscal 2025, which was not allocated to our segment results

[0000804328-26-000061:mdna:30]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | Change |  | March 29,2026 |  | March 30,2025 |  | Change |
| Cost of revenues | $ | 4,900 |  |  | $ | 4,937 |  |  | $ | (37) |  |  | $ | 10,468 |  |  | $ | 10,098 |  |  | $ | 370 |  |
| Gross margin | 54 | % |  | 55 | % |  |  |  | 54 | % |  | 55 | % |  |  |

[0000804328-26-000061:mdna:31]
Second quarter and first six months 2026 vs. 2025

[0000804328-26-000061:mdna:32]
Gross margin percentage decreased in the second quarter and first six months of fiscal 2026 primarily due to a decrease in QCT gross margin percentage.

[0000804328-26-000061:mdna:33]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | Change |  | March 29,2026 |  | March 30,2025 |  | Change |
| Research and development | $ | 2,463 |  |  | $ | 2,216 |  |  | $ | 247 |  |  | $ | 4,915 |  |  | $ | 4,446 |  |  | $ | 469 |  |
| % of revenues | 23 | % |  | 20 | % |  |  |  | 22 | % |  | 20 | % |  |  |

[0000804328-26-000061:mdna:34]
Second quarter 2026 vs. 2025

[0000804328-26-000061:mdna:35]
The increase in research and development expenses in the second quarter of fiscal 2026 was primarily due to:

[0000804328-26-000061:mdna:36]
+    $177 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including investments in key growth and diversification opportunities), primarily driven by an increase in employee-related expenses and lower non-recurring engineering cost reimbursements for product-related development work

[0000804328-26-000061:mdna:37]
+    $83 million increase in share-based compensation expense

[0000804328-26-000061:mdna:38]
First six months 2026 vs. 2025

[0000804328-26-000061:mdna:39]
The increase in research and development expenses in the first six months of fiscal 2026 was primarily due to:

[0000804328-26-000061:mdna:40]
+    $298 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including investments in key growth and diversification opportunities), primarily driven by an increase in employee-related expenses

[0000804328-26-000061:mdna:41]
+    $168 million increase in share-based compensation expense

[0000804328-26-000061:mdna:42]
[same as prior period, unchanged from 0000804328-26-000017:mdna:28]

[0000804328-26-000061:mdna:43]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | Change |  | March 29,2026 |  | March 30,2025 |  | Change |
| Selling, general and administrative | $ | 898 |  |  | $ | 706 |  |  | $ | 192 |  |  | $ | 1,763 |  |  | $ | 1,430 |  |  | $ | 333 |  |
| % of revenues | 8 | % |  | 6 | % |  |  |  | 8 | % |  | 6 | % |  |  |

[0000804328-26-000061:mdna:44]
Second quarter 2026 vs. 2025

[0000804328-26-000061:mdna:45]
The increase in selling, general and administrative expenses in the second quarter of fiscal 2026 was primarily due to:

[0000804328-26-000061:mdna:46]
+    $72 million increase in share-based compensation expense

[0000804328-26-000061:mdna:47]
+    $44 million increase in acquisition-related expenses

[0000804328-26-000061:mdna:48]
First six months 2026 vs. 2025

[0000804328-26-000061:mdna:49]
The increase in selling, general and administrative expenses in the first six months of fiscal 2026 was primarily due to:

[0000804328-26-000061:mdna:50]
+    $123 million increase in share-based compensation expense

[0000804328-26-000061:mdna:51]
+    $84 million increase in acquisition-related expenses

[0000804328-26-000061:mdna:52]
[same as prior period, unchanged from 0000804328-26-000017:mdna:43]

[0000804328-26-000061:mdna:53]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | Change |  | March 29,2026 |  | March 30,2025 |  | Change |
| Interest expense | $ | 171 |  |  | $ | 163 |  |  | $ | 8 |  |  | $ | 341 |  |  | $ | 326 |  |  | $ | 15 |  |
| Investment and other income, net |
| Interest and dividend income | $ | 113 |  |  | $ | 167 |  |  | $ | (54) |  |  | $ | 250 |  |  | $ | 336 |  |  | $ | (86) |  |
| Net (losses) gains on marketable securities | (64) |  |  | 18 |  |  | (82) |  |  | (120) |  |  | 37 |  |  | (157) |  |
| Net gains (losses) on other investments | 7 |  |  | (5) |  |  | 12 |  |  | 217 |  |  | 26 |  |  | 191 |  |
| Net losses on deferred compensation plan assets | (56) |  |  | (34) |  |  | (22) |  |  | (13) |  |  | (20) |  |  | 7 |  |
| Impairment losses on other investments | (12) |  |  | (16) |  |  | 4 |  |  | (23) |  |  | (41) |  |  | 18 |  |
| Equity in net earnings of investees | 44 |  |  | 18 |  |  | 26 |  |  | 83 |  |  | 16 |  |  | 67 |  |
| Other | 62 |  |  | — |  |  | 62 |  |  | 50 |  |  | 37 |  |  | 13 |  |
|  | $ | 94 |  |  | $ | 148 |  |  | $ | (54) |  |  | $ | 444 |  |  | $ | 391 |  |  | $ | 53 |  |

[0000804328-26-000061:mdna:54]
Net losses on marketable securities in the second quarter and first six months of fiscal 2026 was primarily driven by the change in fair value of certain of our QSI marketable equity investments.

[0000804328-26-000061:mdna:55]
Net gains on other investments in the first six months of fiscal 2026 was primarily driven by observable price changes on certain of our QSI non-marketable equity investments.

[0000804328-26-000061:mdna:56]
[same as prior period, unchanged from 0000804328-26-000017:mdna:38]

[0000804328-26-000061:mdna:57]
[same as prior period, unchanged from 0000804328-26-000017:mdna:39]

[0000804328-26-000061:mdna:58]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | March 29,2026 |  | March 30,2025 |
| Expected income tax provision at federal statutory tax rate | $ | 469 |  |  | $ | 652 |  |  | $ | 1,214 |  |  | $ | 1,415 |  |
| Benefit of releasing valuation allowance on federal deferred tax assets | (5,724) |  |  | — |  |  | (5,724) |  |  | — |  |
| Benefit from foreign-derived deduction eligible income (FDDEI) | (88) |  |  | (300) |  |  | (296) |  |  | (660) |  |
| Foreign currency loss (gain) related to foreign withholding tax receivable | 63 |  |  | (1) |  |  | 121 |  |  | 165 |  |
| Benefit related to the federal research and development tax credit | (26) |  |  | (45) |  |  | (98) |  |  | (119) |  |
| Excess tax deficiency (benefit) associated with share-based awards | 11 |  |  | (39) |  |  | (18) |  |  | (77) |  |
| Other | 157 |  |  | 26 |  |  | 205 |  |  | 24 |  |
| Income tax (benefit) expense | $ | (5,138) |  |  | $ | 293 |  |  | $ | (4,596) |  |  | $ | 748 |  |
| Effective tax rate | (230 | %) |  | 9 | % |  | (80 | %) |  | 11 | % |

[0000804328-26-000061:mdna:59]
We estimate our annual effective income tax rate to be 40% benefit for fiscal 2026, which is lower than the U.S. federal statutory rate. Additional information regarding our annual effective income tax rate and income tax expense is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes.”

[0000804328-26-000061:mdna:60]
In the fourth quarter of fiscal 2025, tax reform legislation included in the One Big Beautiful Bill Act (OBBB) was enacted in the United States. The OBBB included significant corporate tax reforms, including changes to the foreign-derived deduction eligible income (FDDEI) regime and changes allowing domestic research and development (R&D) expenditures to be deducted as incurred beginning in fiscal 2026 (under prior law such expenditures were capitalized and amortized over five years). As a result, we expected to be perpetually subject to CAMT and established a $5.7 billion valuation allowance on our federal deferred tax assets in fiscal 2025.

[0000804328-26-000061:mdna:61]
21

[0000804328-26-000061:mdna:62]
In the second quarter of fiscal 2026, the U.S. Department of Treasury and the Internal Revenue Service issued Notice 2026-07, which, among other items, allows us to reduce CAMT by certain previously capitalized domestic R&D expenditures. As a result, we no longer expect to be subject to CAMT in the foreseeable future, and therefore, we now expect to realize our existing federal deferred tax assets. Accordingly, we released our valuation allowance on our federal deferred tax assets resulting in a $5.7 billion income tax benefit in the second quarter of fiscal 2026. Changes in future taxable income, tax laws and other factors may change our determination regarding whether we will be able to realize our deferred tax assets.

[0000804328-26-000061:mdna:63]
Unrecognized tax benefits were $2.9 billion and $2.7 billion at March 29, 2026 and September 28, 2025, respectively. We believe that it is reasonably possible that our unrecognized tax benefits will change within the next twelve months.

[0000804328-26-000061:mdna:64]
[same as prior period, unchanged from 0000804328-26-000017:mdna:46]

[0000804328-26-000061:mdna:65]
The following should be read in conjunction with our financial results for the second quarter of fiscal 2026 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0000804328-26-000061:mdna:66]
[same as prior period, unchanged from 0000804328-26-000017:mdna:48]

[0000804328-26-000061:mdna:67]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | Change |  | March 29,2026 |  | March 30,2025 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets | $ | 6,024 |  |  | $ | 6,929 |  |  | $ | (905) |  |  | $ | 13,848 |  |  | $ | 14,503 |  |  | $ | (655) |  |
| Automotive | 1,326 |  |  | 959 |  |  | 367 |  |  | 2,427 |  |  | 1,920 |  |  | 507 |  |
| IoT (internet of things) | 1,726 |  |  | 1,581 |  |  | 145 |  |  | 3,414 |  |  | 3,130 |  |  | 284 |  |
| Total revenues (1) | $ | 9,076 |  |  | $ | 9,469 |  |  | $ | (393) |  |  | $ | 19,689 |  |  | $ | 19,553 |  |  | $ | 136 |  |
| EBT (2) | $ | 2,465 |  |  | $ | 2,857 |  |  | $ | (392) |  |  | $ | 5,767 |  |  | $ | 6,103 |  |  | $ | (336) |  |
| EBT as a % of revenues | 27 | % |  | 30 | % |  | -3 points |  | 29 | % |  | 31 | % |  | -2 points |

[0000804328-26-000061:mdna:68]
[same as prior period, unchanged from 0000804328-26-000017:mdna:50]

[0000804328-26-000061:mdna:69]
[same as prior period, unchanged from 0000804328-26-000017:mdna:51]

[0000804328-26-000061:mdna:70]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $8.9 billion and $9.3 billion in the second quarter of fiscal 2026 and 2025, respectively, and $19.3 billion and $19.2 billion in the first six months of fiscal 2026 and 2025, respectively. QCT revenues mostly relate to sales of our Snapdragon and Dragonwing platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets as well as sales of 4G, 5G sub 6 and 5G millimeter wave RFFE products.

[0000804328-26-000061:mdna:71]
Second quarter 2026 vs. 2025

[0000804328-26-000061:mdna:72]
The decrease in QCT revenues in the second quarter of fiscal 2026 was primarily due to:

[0000804328-26-000061:mdna:73]
-    lower handsets revenues, primarily due to lower chipset shipments to certain major OEMs (primarily driven by customers adjusting build plans to reduce their inventory levels as a result of the negative effects of recent memory supply constraints and related price increases)

[0000804328-26-000061:mdna:74]
+    higher automotive revenues, due to $191 million in higher shipments primarily from new vehicle launches with our Snapdragon digital cockpit and advanced driver assistance and automated driving (ADAS/AD) products and a $176 million increase in revenues per unit driven by favorable mix and higher average selling prices

[0000804328-26-000061:mdna:75]
+    higher IoT revenues, primarily due to an increase in revenues per unit primarily driven by favorable mix

[0000804328-26-000061:mdna:76]
QCT EBT as a percentage of revenues decreased in the second quarter of fiscal 2026 primarily due to:

[0000804328-26-000061:mdna:77]
[same as prior period, unchanged from 0000804328-26-000017:mdna:59]

[0000804328-26-000061:mdna:78]
-    lower gross margin, primarily driven by higher product cost, partially offset by higher average selling prices

[0000804328-26-000061:mdna:79]
-    lower revenues

[0000804328-26-000061:mdna:80]
First six months 2026 vs. 2025

[0000804328-26-000061:mdna:81]
The increase in QCT revenues in the first six months of fiscal 2026 was primarily due to:

[0000804328-26-000061:mdna:82]
+    higher automotive revenues, due to $328 million in higher shipments primarily from new vehicle launches with our Snapdragon digital cockpit and ADAS/AD products and a $179 million increase in revenues per unit driven by favorable mix and higher average selling prices

[0000804328-26-000061:mdna:83]
+    higher IoT revenues, primarily due to an increase in revenues per unit primarily driven by favorable mix

[0000804328-26-000061:mdna:84]
22

[0000804328-26-000061:mdna:85]
-    lower handsets revenues, primarily due to lower chipset shipments to certain major OEMs (primarily driven by customers adjusting build plans to reduce their inventory levels as a result of the negative effects of recent memory supply constraints and related price increases)

[0000804328-26-000061:mdna:86]
QCT EBT as a percentage of revenues decreased in the first six months of fiscal 2026 primarily due to:

[0000804328-26-000061:mdna:87]
-    higher operating expenses, primarily driven by higher research and development and selling, general and administrative expenses

[0000804328-26-000061:mdna:88]
-    lower gross margin, primarily driven by higher product cost, partially offset by higher average selling prices

[0000804328-26-000061:mdna:89]
[same as prior period, unchanged from 0000804328-26-000017:mdna:62]

[0000804328-26-000061:mdna:90]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | Change |  | March 29,2026 |  | March 30,2025 |  | Change |
| Licensing revenues | $ | 1,382 |  |  | $ | 1,319 |  |  | $ | 63 |  | $ | 2,974 |  |  | $ | 2,854 |  |  | $ | 120 |
| EBT | 994 |  |  | 929 |  |  | 65 |  | 2,224 |  |  | 2,086 |  |  | 138 |
| EBT as a % of revenues | 72 | % |  | 70 | % |  | 2 points |  | 75 | % |  | 73 | % |  | 2 points |

[0000804328-26-000061:mdna:91]
Second quarter 2026 vs. 2025

[0000804328-26-000061:mdna:92]
The increase in QTL licensing revenues in the second quarter of fiscal 2026 was primarily due to an increase in estimated revenues per unit, which was primarily driven by favorable mix.

[0000804328-26-000061:mdna:93]
QTL EBT as a percentage of revenues increased in the second quarter of fiscal 2026 primarily due to higher revenues.

[0000804328-26-000061:mdna:94]
First six months 2026 vs. 2025

[0000804328-26-000061:mdna:95]
The increase in QTL licensing revenues in the first six months of fiscal 2026 was primarily due to an increase in estimated sales of cellular products.

[0000804328-26-000061:mdna:96]
QTL EBT as a percentage of revenues increased in the first six months of fiscal 2026 primarily due to higher revenues.

[0000804328-26-000061:mdna:97]
[same as prior period, unchanged from 0000804328-26-000017:mdna:69]

[0000804328-26-000061:mdna:98]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | Change |  | March 29,2026 |  | March 30,2025 |  | Change |
| Revenues | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| EBT | (30) |  |  | 10 |  |  | (40) |  |  | 149 |  |  | 29 |  |  | 120 |  |

[0000804328-26-000061:mdna:99]
Second quarter 2026 vs. 2025

[0000804328-26-000061:mdna:100]
QSI EBT decreased in the second quarter of fiscal 2026 primarily due to net losses from the change in fair value of certain of our marketable equity investments.

[0000804328-26-000061:mdna:101]
First six months 2026 vs. 2025

[0000804328-26-000061:mdna:102]
QSI EBT increased in the first six months of fiscal 2026 primarily due to higher net gains from observable price changes on certain of our non-marketable equity investments and an increase in our share of earnings in equity method investments, partially offset by net losses from the change in fair value of certain of our marketable equity investments.

[0000804328-26-000061:mdna:103]
[same as prior period, unchanged from 0000804328-26-000017:mdna:73]

[0000804328-26-000061:mdna:104]
[same as prior period, unchanged from 0000804328-26-000017:mdna:74]

[0000804328-26-000061:mdna:105]
[same as prior period, unchanged from 0000804328-26-000017:mdna:75]

[0000804328-26-000061:mdna:106]
•We expect recent memory supply constraints and related pricing increases to adversely affect demand from several handset OEMs, which will negatively impact our financial results. The extent to which these conditions may affect our business will depend on future developments, including memory supply availability, memory and device pricing dynamics and end‑consumer demand for devices, all of which remain uncertain.

[0000804328-26-000061:mdna:107]
•We continue to monitor changes in global trade policy, including tariffs and related trade actions announced by the U.S., China and other countries. The degree to which such tariffs and other related actions impact our business,

[0000804328-26-000061:mdna:108]
23

[0000804328-26-000061:mdna:109]
financial condition and results of operations will depend on future developments, which are uncertain. Changes to global trade policies may negatively impact demand, pricing and cost for our products and technologies, and contribute to the inherent uncertainties in estimating future customer demand, which may result in increased excess or obsolete inventory or reserve charges, negatively impacting our results of operations and cash flows. See “Risk Factors” in this Quarterly Report, including the Risk Factor titled “We operate in the highly cyclical semiconductor industry, which is subject to significant downturns. We are also susceptible to declines in global, regional and local economic conditions generally. Our stock price and financial results are subject to substantial quarterly and annual fluctuations due to these dynamics, among others.”

[0000804328-26-000061:mdna:110]
[same as prior period, unchanged from 0000804328-26-000017:mdna:78]

[0000804328-26-000061:mdna:111]
•We expect continued intense competition, including from vertical integration by certain of our customers (for example, Apple and Samsung). In particular, Apple utilizes its own modem (rather than our products) in certain of its smartphones and we expect that Apple will increasingly use its own modem products, rather than our products, in its future devices, which will have a significant negative impact on our QCT revenues, results of operations and cash flows.

[0000804328-26-000061:mdna:112]
[same as prior period, unchanged from 0000804328-26-000017:mdna:81]

[0000804328-26-000061:mdna:113]
We are also involved in certain legal proceedings, including those described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Litigation is inherently uncertain, and, while we intend to continue to vigorously defend ourselves in such matters, the unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0000804328-26-000061:mdna:114]
[same as prior period, unchanged from 0000804328-26-000017:mdna:83]

[0000804328-26-000061:mdna:115]
[same as prior period, unchanged from 0000804328-26-000017:mdna:84]

[0000804328-26-000061:mdna:116]
[same as prior period, unchanged from 0000804328-26-000017:mdna:85]

[0000804328-26-000061:mdna:117]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at March 29, 2026 and September 28, 2025 and for the first six months of fiscal 2026 and 2025 (in millions):

[0000804328-26-000061:mdna:118]
|  | March 29,2026 |  | September 28,2025 |  | Change |  |  |
| Cash, cash equivalents and marketable securities (including restricted cash) |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 5,435 |  |  | $ | 5,520 |  |  | $ | (85) |  |  |  |
| Restricted cash (1) | — |  |  | 2,323 |  |  | (2,323) |  |  |  |
| Marketable securities | 4,364 |  |  | 4,635 |  |  | (271) |  |  |  |
|  | $ | 9,799 |  |  | $ | 12,478 |  |  | $ | (2,679) |  |  |  |
| Debt (2) | $ | 15,270 |  |  | $ | 14,811 |  |  | $ | 459 |  |  |  |

[0000804328-26-000061:mdna:119]
(1) In connection with the acquisition of Alphawave, which closed in the first quarter of fiscal 2026, we had agreed to restrict the use of approximately $2.3 billion of cash to be held for purposes of satisfying payment of the consideration to effect the acquisition. Additional information regarding our acquisition of Alphawave is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 8. Acquisitions.”

[0000804328-26-000061:mdna:120]
(2) Includes our issued debt which is reported as long-term and $498 million of outstanding commercial paper reported as short-term debt as of March 29, 2026. At March 29, 2026, our credit facility was undrawn.

[0000804328-26-000061:mdna:121]
24

[0000804328-26-000061:mdna:122]
|  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | Change |  |  |
| Net cash provided by operating activities | $ | 7,414 |  |  | $ | 7,141 |  |  | $ | 273 |  |  |  |
| Net cash used by investing activities | (2,222) |  |  | (1,960) |  |  | (262) |  |  |  |
| Net cash used by financing activities | (7,575) |  |  | (5,789) |  |  | (1,786) |  |  |  |

[0000804328-26-000061:mdna:123]
Cash, cash equivalents and marketable securities (including restricted cash). The net decrease in cash, cash equivalents and marketable securities (including restricted cash) for the first six months of fiscal 2026 was primarily due to $5.4 billion in payments to repurchase 34 million shares of our common stock (which includes repurchases that offset share issuances in connection with the acquisition of Alphawave), $1.9 billion in cash dividends paid, $1.2 billion in cash paid for acquisitions and other investments (net of cash acquired), $1.1 billion in capital expenditures and $536 million in payments of tax withholdings related to the vesting of share-based awards, partially offset by cash provided by operating activities and $496 million in net proceeds of commercial paper.

[0000804328-26-000061:mdna:124]
During the first six months of fiscal 2026, income taxes paid were greater than our provision. This was primarily driven by the $5.7 billion release of our valuation allowance on federal deferred tax assets in the second quarter of fiscal 2026 and our final installment payment for a one-time U.S. repatriation tax accrued in fiscal 2018 of $663 million. The OBBB includes significant corporate tax reforms, including the permanent reinstatement of deducting domestic research and development expenditures as incurred beginning in fiscal 2026 (under prior law such expenditures were capitalized and amortized over five years). We expect this change will have a favorable effect on our cash flows from operations due to significantly lower cash tax payments.

[0000804328-26-000061:mdna:125]
Net changes in our operating assets and liabilities for the first six months of fiscal 2026 positively impacted our operating cash flows primarily driven by a decrease in other assets primarily due to utilization of prior advanced supply agreement payments, partially offset by an increase in inventory reflecting certain customer demand impacts from memory supply constraints.

[0000804328-26-000061:mdna:126]
[same as prior period, unchanged from 0000804328-26-000017:mdna:93]

[0000804328-26-000061:mdna:127]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2025 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At March 29, 2026, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements”, “Looking Forward” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2025 Annual Report on Form 10-K.

[0000804328-26-000061:mdna:128]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Risk Factors” in this Quarterly Report.

[0000804328-26-000061:mdna:129]
[same as prior period, unchanged from 0000804328-26-000017:mdna:96]

[0000804328-26-000061:mdna:130]
[same as prior period, unchanged from 0000804328-26-000017:mdna:97]

[0000804328-26-000061:mdna:131]
[same as prior period, unchanged from 0000804328-26-000017:mdna:98]
