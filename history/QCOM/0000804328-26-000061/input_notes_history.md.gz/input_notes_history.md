# QCOM note change history — 0000804328-26-000017 → 0000804328-26-000061


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2026-04-29):
[0000804328-26-000061:note_history:1]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s

- changed (2026-04-29):
[0000804328-26-000061:note_history:2]
Architecture License Agreement with Arm (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. Arm is seeking specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology (which Arm alleges includes our custom Qualcomm Oryon CPU cores). On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm, and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia) and System-on-Chip (SoC) products incorporating such cores are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm (the Qualcomm TLA). A trial was held beginning on December 16, 2024, and on December 20, 2024, the jury found that (i) Qualcomm did not breach the Nuvia ALA and (ii) Qualcomm CPUs that include designs acquired in the Nuvia acquisition are licensed under the Qualcomm ALA. The jury was unable to reach a verdict with respect to Arm’s claim as to whether Nuvia breached the Nuvia ALA. The parties filed various post-trial motions, including motions for judgment as a matter of law. On September 30, 2025, the court entered a final judgment upholding the jury’s verdict in favor of Qualcomm, granting judgment to Nuvia, and dismissing Arm’s remaining claims. On October 1, 2025, Arm filed a notice of appeal to the United States Court of Appeals for the Third Circuit. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.
  (was, 2026-02-04, similarity 0.6486):
[0000804328-26-000017:note_history:2]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with Arm (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. Arm is seeking specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology (which Arm alleges includes our custom Qualcomm Oryon CPU cores). On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm, and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia) and System-on-Chip (SoC) products incorporating such cores are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm (the Qualcomm TLA). A trial was held beginning on

- changed (2026-04-29):
[0000804328-26-000061:note_history:3]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at March 29, 2026 for contingent losses associated with the matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (including matters arising in the ordinary course of our business, such as those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights, among others) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.
  (was, 2026-02-04, similarity 0.9946):
[0000804328-26-000017:note_history:3]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at December 28, 2025 for contingent losses associated with the matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (including matters arising in the ordinary course of our business, such as those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights, among others) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- removed (2026-04-29):
[0000804328-26-000017:note_history:4]
December 16, 2024, and on December 20, 2024, the jury found that (i) Qualcomm did not breach the Nuvia ALA and (ii) Qualcomm CPUs that include designs acquired in the Nuvia acquisition are licensed under the Qualcomm ALA. The jury was unable to reach a verdict with respect to Arm’s claim as to whether Nuvia breached the Nuvia ALA. The parties filed various post-trial motions, including motions for judgment as a matter of law. On September 30, 2025, the court entered a final judgment upholding the jury’s verdict in favor of Qualcomm, granting judgment to Nuvia, and dismissing Arm’s remaining claims. On October 1, 2025, Arm filed a notice of appeal to the United States Court of Appeals for the Third Circuit. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-04-29):
[0000804328-26-000061:note_history:5]
We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 29, 2026 and March 30, 2025 included 13 weeks and 26 weeks, respectively. Our fiscal year for 2026 will include 52 weeks.
  (was, 2026-02-04, similarity 0.6123):
[0000804328-26-000017:note_history:5]
We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 28, 2025 and December 29, 2024 included 13 weeks. Our fiscal year for 2026 will include 52 weeks.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-04-29):
[0000804328-26-000061:note_history:6]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  | March 29,2026 |  | March 30,2025 |  | March 29,2026 |  | March 30,2025 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,024 |  |  | $ | 6,929 |  |  | $ | 13,848 |  |  | $ | 14,503 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 1,326 |  |  | 959 |  |  | 2,427 |  |  | 1,920 |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,726 |  |  | 1,581 |  |  | 3,414 |  |  | 3,130 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 9,076 |  |  | $ | 9,469 |  |  | $ | 19,689 |  |  | $ | 19,553 |  |
  (was, 2026-02-04, similarity 0.7677):
[0000804328-26-000017:note_history:6]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | December 28,2025 |  | December 29,2024 |  |  |  |  |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 7,824 |  |  | $ | 7,574 |  |  |  |  |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 1,101 |  |  | 961 |  |  |  |  |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,688 |  |  | 1,549 |  |  |  |  |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 10,613 |  |  | $ | 10,084 |  |  |  |  |  |
