# QCOM notes — 0000804328-26-000061


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000804328-26-000061:notes:1]
[same as prior period, unchanged from 0000804328-26-000017:notes:1]

[0000804328-26-000061:notes:2]
[same as prior period, unchanged from 0000804328-26-000017:notes:2]

[0000804328-26-000061:notes:3]
We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 29, 2026 and March 30, 2025 included 13 weeks and 26 weeks, respectively. Our fiscal year for 2026 will include 52 weeks.

[0000804328-26-000061:notes:4]
[same as prior period, unchanged from 0000804328-26-000017:notes:4]

[0000804328-26-000061:notes:5]
[same as prior period, unchanged from 0000804328-26-000017:notes:5]

[0000804328-26-000061:notes:6]
[same as prior period, unchanged from 0000804328-26-000017:notes:6]

[0000804328-26-000061:notes:7]
[same as prior period, unchanged from 0000804328-26-000017:notes:7]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-26-000061:notes:8]
[same as prior period, unchanged from 0000804328-26-000017:notes:8]

[0000804328-26-000061:notes:9]
| Inventories (in millions) |  |  |  |
|  | March 29,2026 |  | September 28,2025 |
| Raw materials | $ | 580 |  |  | $ | 336 |  |
| Work-in-process | 4,346 |  |  | 3,985 |  |
| Finished goods | 2,442 |  |  | 2,205 |  |
|  | $ | 7,368 |  |  | $ | 6,526 |  |

[0000804328-26-000061:notes:10]
We have multi-year capacity purchase commitments with certain suppliers of our integrated circuit products. Total advance payments related to multi-year capacity purchase commitments recorded on our condensed consolidated balance sheets at March 29, 2026 and September 28, 2025 were $782 million and $1.9 billion, respectively, of which $469 million and $1.5 billion were recorded in other current assets, respectively, and $313 million and $357 million were recorded in other assets, respectively.

[0000804328-26-000061:notes:11]
| Other Current Liabilities (in millions) |  |  |  |
|  | March 29,2026 |  | September 28,2025 |
| Customer incentives and other customer-related liabilities | $ | 2,865 |  |  | $ | 1,948 |  |
| Income taxes payable | 508 |  |  | 1,007 |  |
| Other | 1,230 |  |  | 1,201 |  |
|  | $ | 4,603 |  |  | $ | 4,156 |  |

[0000804328-26-000061:notes:12]
Interest Rate Swaps. At March 29, 2026 and September 28, 2025, we had outstanding interest rate swaps with an aggregate notional amount of $5.0 billion and $3.6 billion, respectively, that are designated as fair value hedges and allow us to effectively convert fixed-rate payments into floating-rate payments on a portion of our outstanding long-term debt.

[0000804328-26-000061:notes:13]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. At March 29, 2026 and September 28, 2025, we had $498 million and no amounts, respectively, of outstanding commercial paper recorded as short-term debt.

[0000804328-26-000061:notes:14]
[same as prior period, unchanged from 0000804328-26-000017:notes:13]

[0000804328-26-000061:notes:15]
[same as prior period, unchanged from 0000804328-26-000017:notes:14]

[0000804328-26-000061:notes:16]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  | March 29,2026 |  | March 30,2025 |  | March 29,2026 |  | March 30,2025 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,024 |  |  | $ | 6,929 |  |  | $ | 13,848 |  |  | $ | 14,503 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 1,326 |  |  | 959 |  |  | 2,427 |  |  | 1,920 |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,726 |  |  | 1,581 |  |  | 3,414 |  |  | 3,130 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 9,076 |  |  | $ | 9,469 |  |  | $ | 19,689 |  |  | $ | 19,553 |  |

[0000804328-26-000061:notes:17]
[same as prior period, unchanged from 0000804328-26-000017:notes:16]

[0000804328-26-000061:notes:18]
[same as prior period, unchanged from 0000804328-26-000017:notes:17]

[0000804328-26-000061:notes:19]
[same as prior period, unchanged from 0000804328-26-000017:notes:18]

[0000804328-26-000061:notes:20]
[same as prior period, unchanged from 0000804328-26-000017:notes:19]

[0000804328-26-000061:notes:21]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | March 29,2026 |  | March 30,2025 |
| Revenues recognized from previously satisfied performance obligations | $ | 132 |  |  | $ | 285 |  |  | $ | 313 |  |  | $ | 526 |  |

[0000804328-26-000061:notes:22]
Remaining performance obligations, which are primarily included in unearned revenues (as presented on our condensed consolidated balance sheets), represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license

[0000804328-26-000061:notes:23]
agreements. Our patent license agreements with key OEMs are generally long-term, with remaining terms expiring between fiscal 2027 and 2031. We generally seek to renew or renegotiate such license agreements prior to expiration.

[0000804328-26-000061:notes:24]
[same as prior period, unchanged from 0000804328-26-000017:notes:22]

[0000804328-26-000061:notes:25]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | March 29,2026 |  | March 30,2025 |
| Customer/licensee (x) | 24 | % |  | 27 | % |  | 20 | % |  | 21 | % |
| Customer/licensee (y) | 22 |  |  | 18 |  |  | 24 |  |  | 21 |  |
| Customer/licensee (z) | * |  | 10 |  |  | * |  | 12 |  |

[0000804328-26-000061:notes:26]
*Less than 10%

[0000804328-26-000061:notes:27]
Other Income, Costs and Expenses. Other expenses in the three months and six months ended March 29, 2026 consisted of $29 million in restructuring and restructuring-related charges (substantially all of which related to severance costs).

[0000804328-26-000061:notes:28]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | March 29,2026 |  | March 30,2025 |
| Interest and dividend income | $ | 113 |  |  | $ | 167 |  |  | $ | 250 |  |  | $ | 336 |  |
| Net (losses) gains on marketable securities | (64) |  |  | 18 |  |  | (120) |  |  | 37 |  |
| Net gains (losses) on other investments | 7 |  |  | (5) |  |  | 217 |  |  | 26 |  |
| Net losses on deferred compensation plan assets | (56) |  |  | (34) |  |  | (13) |  |  | (20) |  |
| Impairment losses on other investments | (12) |  |  | (16) |  |  | (23) |  |  | (41) |  |
| Equity in net earnings of investees | 44 |  |  | 18 |  |  | 83 |  |  | 16 |  |
| Other | 62 |  |  | — |  |  | 50 |  |  | 37 |  |
|  | $ | 94 |  |  | $ | 148 |  |  | $ | 444 |  |  | $ | 391 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-26-000061:notes:29]
[same as prior period, unchanged from 0000804328-26-000017:notes:25]

[0000804328-26-000061:notes:30]
In the fourth quarter of fiscal 2025, tax reform legislation included in the One Big Beautiful Bill Act (OBBB) was enacted in the United States. The OBBB included significant corporate tax reforms, including changes to the foreign-derived deduction eligible income (FDDEI) regime and changes allowing domestic research and development (R&D) expenditures to be deducted as incurred beginning in fiscal 2026 (under prior law such expenditures were capitalized and amortized over five years). As a result, we expected to be perpetually subject to corporate alternative minimum tax (CAMT) and established a $5.7 billion valuation allowance on our federal deferred tax assets in fiscal 2025.

[0000804328-26-000061:notes:31]
In the second quarter of fiscal 2026, the U.S. Department of Treasury and the Internal Revenue Service issued Notice 2026-07, which, among other items, allows us to reduce CAMT by certain previously capitalized domestic R&D expenditures. As a result, we no longer expect to be subject to CAMT in the foreseeable future, and therefore, we now expect to realize our existing federal deferred tax assets. Accordingly, we released our valuation allowance on our federal deferred tax assets resulting in a $5.7 billion income tax benefit in the second quarter of fiscal 2026. Changes in future taxable income, tax laws and other factors may change our determination regarding whether we will be able to realize our deferred tax assets.

[0000804328-26-000061:notes:32]
We estimate our annual effective income tax rate to be 40% benefit for fiscal 2026, primarily due to the release of our valuation allowance on our federal deferred tax assets. Our annual effective income tax rate for fiscal 2026 also reflects a significant portion of our income qualifying as FDDEI taxable at a 13% effective tax rate and benefits from the federal research and development tax credit. Such benefits from FDDEI for fiscal 2026 will be reduced compared to fiscal 2025 as a result of the current deduction of domestic R&D expenditures under OBBB. However, it will have a favorable effect on our cash flows from operations due to significantly lower cash tax payments.
Our effective tax rate for the second quarter of fiscal 2026 was 230% benefit, primarily due to the release of our valuation allowance on our federal deferred tax assets. Our effective tax rate for the second quarter of fiscal 2025 was 9%, primarily due to net discrete tax benefits.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-26-000061:notes:33]
[same as prior period, unchanged from 0000804328-26-000017:notes:29]

[0000804328-26-000061:notes:34]
Stock Repurchase Program. On March 17, 2026, we announced a new $20.0 billion stock repurchase program, which was in addition to the then-remaining repurchase authority of $2.1 billion under the previous program announced in November 2024. The stock repurchase programs have no expiration date. At March 29, 2026, $21.9 billion remained authorized for repurchase under our stock repurchase programs.

[0000804328-26-000061:notes:35]
Shares Outstanding. Shares of common stock outstanding at March 29, 2026 were as follows (in millions):

[0000804328-26-000061:notes:36]
| Balance at September 28, 2025 | 1,074 |  |
| Issued | 19 |  |
| Repurchased | (34) |  |
| Balance at March 29, 2026 | 1,059 |  |

[0000804328-26-000061:notes:37]
Dividends. On March 17, 2026, we announced an increase in our quarterly dividend per share of common stock from $0.89 to $0.92, which is effective for dividends payable after March 26, 2026.

[0000804328-26-000061:notes:38]
[same as prior period, unchanged from 0000804328-26-000017:notes:33]

[0000804328-26-000061:notes:39]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | March 29,2026 |  | March 30,2025 |
| Dilutive common share equivalents included in diluted shares | 6 |  |  | 10 |  |  | 7 |  |  | 11 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 18 |  |  | 1 |  |  | 15 |  |  | 1 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-26-000061:notes:40]
Note 5. Commitments and Contingencies

[0000804328-26-000061:notes:41]
Legal and Regulatory Proceedings.

[0000804328-26-000061:notes:42]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision, Inc. (ParkerVision) filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the district court entered judgment in our favor on all claims and closed the case. ParkerVision appealed to the United States Court of Appeals for the Federal Circuit (Federal Circuit), and on September 6, 2024, the Federal Circuit reversed the judgment of the district court, citing certain substantive and procedural issues, and remanded the case to the district court for further proceedings. Following a claim construction ruling by the district court, the parties agreed to a stipulated judgment of non-infringement with respect to certain of ParkerVision’s claims (Receiver Claims). On October 2, 2025, the court entered a final judgment in our favor with respect to the Receiver Claims and severed and stayed ParkerVision’s remaining claims (Transmitter Claims), pending appeal of the court’s claim construction ruling and resulting determination of non-infringement of the Receiver Claims. ParkerVision has appealed to the Federal Circuit. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-26-000061:notes:43]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s

[0000804328-26-000061:notes:44]
Architecture License Agreement with Arm (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. Arm is seeking specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology (which Arm alleges includes our custom Qualcomm Oryon CPU cores). On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm, and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia) and System-on-Chip (SoC) products incorporating such cores are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm (the Qualcomm TLA). A trial was held beginning on December 16, 2024, and on December 20, 2024, the jury found that (i) Qualcomm did not breach the Nuvia ALA and (ii) Qualcomm CPUs that include designs acquired in the Nuvia acquisition are licensed under the Qualcomm ALA. The jury was unable to reach a verdict with respect to Arm’s claim as to whether Nuvia breached the Nuvia ALA. The parties filed various post-trial motions, including motions for judgment as a matter of law. On September 30, 2025, the court entered a final judgment upholding the jury’s verdict in favor of Qualcomm, granting judgment to Nuvia, and dismissing Arm’s remaining claims. On October 1, 2025, Arm filed a notice of appeal to the United States Court of Appeals for the Third Circuit. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.

[0000804328-26-000061:notes:45]
On April 18, 2024, we filed a separate complaint, captioned QUALCOMM Incorporated v. Arm Holdings plc f/k/a Arm Ltd., in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief. On December 16, 2024, we filed a First Amended Complaint alleging additional causes of action based on Arm improperly seeking to terminate the Qualcomm ALA and improperly publicizing that it was seeking to terminate the Qualcomm ALA. On June 3, 2025, we filed a Second Amended Complaint to add a claim that Arm has breached the Qualcomm TLA by failing to provide license offers at commercially reasonable prices and terms. Arm has moved to dismiss our amended complaint. On January 8, 2026, we filed a substantially identical complaint against Arm Ltd., which was subsequently consolidated with the Arm Holdings plc complaint. Trial is scheduled to begin on October 5, 2026.

[0000804328-26-000061:notes:46]
On October 22, 2024, Arm provided us with a notice alleging that we have breached the Qualcomm ALA by marketing products that contain CPUs that Arm alleges use designs, technology and code created by Nuvia employees prior to our acquisition of Nuvia; by seeking support and verification from Arm for additional products that use such alleged designs, technology and code; and by suing Arm for breach of the Qualcomm ALA. Arm’s notice asserts that it will have the right to terminate the Qualcomm ALA if such alleged breaches are not cured within 60 days of such notice. We disagree with Arm’s allegations, including that we are, or have been, in breach of the Qualcomm ALA. On January 8, 2025, Arm notified us that it was withdrawing its October 22, 2024 notice of breach and indicated that it has no current plan to terminate the Qualcomm ALA, while reserving its rights pending the outcome of the ongoing litigation.

[0000804328-26-000061:notes:47]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at March 29, 2026 for contingent losses associated with the matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (including matters arising in the ordinary course of our business, such as those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights, among others) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-26-000061:notes:48]
[same as prior period, unchanged from 0000804328-26-000017:notes:43]

[0000804328-26-000061:notes:49]
We are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarities and the level of centralized resource planning within our operating segments, such as the nature of products, the level of shared products, technology and other resources,

[0000804328-26-000061:notes:50]
production processes and customer base. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuit platforms and system software with advanced connectivity and high-performance, low-power computing technologies for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices, industrial devices and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our Data Center business.

[0000804328-26-000061:notes:51]
[same as prior period, unchanged from 0000804328-26-000017:notes:45]

[0000804328-26-000061:notes:52]
[same as prior period, unchanged from 0000804328-26-000017:notes:46]

[0000804328-26-000061:notes:53]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | March 29,2026 |  | March 30,2025 |
| QCT: |  |  |  |  |  |  |  |
| Revenues | $ | 9,076 |  |  | $ | 9,469 |  |  | $ | 19,689 |  |  | $ | 19,553 |  |
| Cost of revenues | 4,700 |  |  | 4,834 |  |  | 10,145 |  |  | 9,898 |  |
| Operating expenses (R&D and SG&A) | 1,911 |  |  | 1,778 |  |  | 3,777 |  |  | 3,552 |  |
| EBT | $ | 2,465 |  |  | $ | 2,857 |  |  | $ | 5,767 |  |  | $ | 6,103 |  |
| QTL: |  |  |  |  |  |  |  |
| Revenues | $ | 1,382 |  |  | $ | 1,319 |  |  | $ | 2,974 |  |  | $ | 2,854 |  |
| Costs and expenses (1) | 388 |  |  | 390 |  |  | 750 |  |  | 768 |  |
| EBT | $ | 994 |  |  | $ | 929 |  |  | $ | 2,224 |  |  | $ | 2,086 |  |
| QSI: |  |  |  |  |  |  |  |
| Revenues | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Operating expenses | 3 |  |  | 3 |  |  | 5 |  |  | 6 |  |
| Investment and other (expense) income, net | (27) |  |  | 13 |  |  | 154 |  |  | 35 |  |
| EBT | $ | (30) |  |  | $ | 10 |  |  | $ | 149 |  |  | $ | 29 |  |

[0000804328-26-000061:notes:54]
[same as prior period, unchanged from 0000804328-26-000017:notes:48]

[0000804328-26-000061:notes:55]
[same as prior period, unchanged from 0000804328-26-000017:notes:49]

[0000804328-26-000061:notes:56]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29,2026 |  | March 30,2025 |  | March 29,2026 |  | March 30,2025 |
| Revenues |  |  |  |  |  |  |  |
| Reportable segments | $ | 10,458 |  |  | $ | 10,788 |  |  | $ | 22,663 |  |  | $ | 22,407 |  |
| Nonreportable segments | 141 |  |  | 48 |  |  | 188 |  |  | 99 |  |
| Unallocated revenues | — |  |  | 143 |  |  | — |  |  | 143 |  |
|  | $ | 10,599 |  |  | $ | 10,979 |  |  | $ | 22,851 |  |  | $ | 22,649 |  |
| EBT |  |  |  |  |  |  |  |
| Reportable segments | $ | 3,429 |  |  | $ | 3,796 |  |  | $ | 8,140 |  |  | $ | 8,218 |  |
| Nonreportable segments | (121) |  |  | (7) |  |  | (204) |  |  | (6) |  |
| Unallocated revenues | — |  |  | 143 |  |  | — |  |  | 143 |  |
| Unallocated cost of revenues | (95) |  |  | (60) |  |  | (178) |  |  | (119) |  |
| Unallocated R&D expenses | (616) |  |  | (558) |  |  | (1,314) |  |  | (1,156) |  |
| Unallocated SG&A expenses | (274) |  |  | (184) |  |  | (573) |  |  | (372) |  |
| Unallocated other expenses | (29) |  |  | — |  |  | (29) |  |  | — |  |
| Unallocated interest expense | (171) |  |  | (163) |  |  | (341) |  |  | (326) |  |
| Unallocated investment and other income, net | 109 |  |  | 138 |  |  | 278 |  |  | 358 |  |
|  | $ | 2,232 |  |  | $ | 3,105 |  |  | $ | 5,779 |  |  | $ | 6,740 |  |

[0000804328-26-000061:notes:57]
Certain revenues were not allocated to our segments in our management reports because they were not considered in evaluating segment results. Unallocated revenues in the second quarter and first six months of fiscal 2025 were comprised of licensing revenues resulting from a settlement of a licensing dispute in the second quarter of fiscal 2025.


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-26-000061:notes:58]
[same as prior period, unchanged from 0000804328-26-000017:notes:51]

[0000804328-26-000061:notes:59]
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at March 29, 2026 (in millions):

[0000804328-26-000061:notes:60]
|  | Level 1 |  | Level 2 |  |  |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 1,014 |  |  | $ | 515 |  |  |  |  | $ | 1,529 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 3,266 |  |  |  |  | 3,266 |  |
| Mortgage- and asset-backed securities | — |  |  | 863 |  |  |  |  | 863 |  |
| U.S. Treasury securities and government-related securities | 58 |  |  | 37 |  |  |  |  | 95 |  |
| Equity securities | 140 |  |  | — |  |  |  |  | 140 |  |
| Total marketable securities | 198 |  |  | 4,166 |  |  |  |  | 4,364 |  |
| Derivative instruments | — |  |  | 36 |  |  |  |  | 36 |  |
| Other investments (1) | 1,138 |  |  | — |  |  |  |  | 1,138 |  |
| Total assets measured at fair value | $ | 2,350 |  |  | $ | 4,717 |  |  |  |  | $ | 7,067 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 295 |  |  |  |  | $ | 295 |  |
| Other liabilities (1) | 1,134 |  |  | — |  |  |  |  | 1,134 |  |
| Total liabilities measured at fair value | $ | 1,134 |  |  | $ | 295 |  |  |  |  | $ | 1,429 |  |

[0000804328-26-000061:notes:61]
[same as prior period, unchanged from 0000804328-26-000017:notes:54]

[0000804328-26-000061:notes:62]
Long-term Debt. At March 29, 2026, the aggregate fair value of our outstanding fixed-rate notes, based on Level 2 inputs, was approximately $13.7 billion.

[0000804328-26-000061:notes:63]
Marketable Securities. At March 29, 2026 and September 28, 2025, our marketable securities were all classified as current and were primarily comprised of available-for-sale debt securities (the vast majority of which were corporate bonds and notes).

[0000804328-26-000061:notes:64]
[same as prior period, unchanged from 0000804328-26-000017:notes:57]

[0000804328-26-000061:notes:65]
|  | March 29,2026 |
| Years to maturity |  |
| Less than one year | $ | 870 |  |
| One to five years | 2,489 |  |
| Five to ten years | 2 |  |
| No single maturity date | 863 |  |
| Total | $ | 4,224 |  |

[0000804328-26-000061:notes:66]
[same as prior period, unchanged from 0000804328-26-000017:notes:59]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000804328-26-000061:notes:67]
[same as prior period, unchanged from 0000804328-26-000017:notes:60]

[0000804328-26-000061:notes:68]
[same as prior period, unchanged from 0000804328-26-000017:notes:61]

[0000804328-26-000061:notes:69]
In connection with the acquisition, we issued Exchangeable Shares of Aqua ExchangeCo ULC, an indirect, wholly-owned subsidiary of QUALCOMM Incorporated, to certain Alphawave executives in exchange for their outstanding capital stock. The Exchangeable Shares (no par value; unlimited shares authorized; 4 million shares issued and outstanding as of March 29, 2026) are exchangeable for our common stock on a one-for-one basis and are substantially the economic equivalent of our common stock. The issued and outstanding Exchangeable Shares have been presented together with our common stock in our condensed consolidated financial statements. The Exchangeable Shares had an estimated fair value of $746 million, of which $453 million is included within the $2.3 billion purchase price and the remainder is subject to a four-year service requirement post-acquisition and will be recognized as compensation expense.

[0000804328-26-000061:notes:70]
[same as prior period, unchanged from 0000804328-26-000017:notes:63]

[0000804328-26-000061:notes:71]
| Cash | $ | 51 |  |
| Intangible assets subject to amortization | 239 |  |
| In-process research and development (IPR&D) | 107 |  |
| Goodwill | 2,215 |  |
| Other assets | 283 |  |
| Total assets | 2,895 |  |
| Convertible debt (1) | (278) |  |
| Other liabilities | (343) |  |
| Total liabilities | (621) |  |
| Net assets acquired | $ | 2,274 |  |

[0000804328-26-000061:notes:72]
(1) Alphawave's outstanding unsecured convertible bonds were settled in the second quarter of fiscal 2026.

[0000804328-26-000061:notes:73]
[same as prior period, unchanged from 0000804328-26-000017:notes:66]

[0000804328-26-000061:notes:74]
[same as prior period, unchanged from 0000804328-26-000017:notes:67]

[0000804328-26-000061:notes:75]
Other. During the first six months of fiscal 2026, we acquired six other businesses for a total accounting purchase price of $985 million. These acquisitions were primarily for the purpose of executing on certain products and technology that support our QCT business, including our diversification strategy. The acquired assets primarily consisted of $272 million of intangible assets and $698 million of goodwill, with $622 million allocated to our QCT segment and $76 million allocated to our Data Center operating segment, all of which is primarily attributable to assembled workforce and certain synergies expected to arise after the acquisitions.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000804328-26-000061:notes:76]
On March 13, 2026, Ann Chaplin, our EVP, General Counsel and Corporate Secretary, adopted a Rule 10b5-1 trading arrangement (as defined in Item 408 of Regulation S-K) providing for the sale of (i) 50% of the net shares issued to Ms. Chaplin upon the vesting of restricted stock unit awards representing 27,421 shares of our common stock and (ii) 50% of the net shares issued to Ms. Chaplin upon the vesting of performance stock unit awards representing 43,853 shares of our common stock (assuming that such shares underlying performance stock units vest at target amounts), including, in each case, accrued dividend-equivalent shares and excluding any shares withheld to satisfy tax withholding obligations in connection with the settlement of such awards. The plan is scheduled to terminate on December 31, 2027.
