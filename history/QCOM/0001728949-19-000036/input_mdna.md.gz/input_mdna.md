# QCOM MD&A — 0001728949-19-000036


## mdna

[0001728949-19-000036:mdna:1]
[same as prior period, unchanged from 0001728949-19-000012:mdna:1]

[0001728949-19-000036:mdna:2]
[same as prior period, unchanged from 0001728949-19-000012:mdna:2]

[0001728949-19-000036:mdna:3]
This Quarterly Report (including, but not limited to, this section regarding Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements regarding our business, investments, financial condition, results of operations and prospects. Additionally, statements concerning future matters that are not historical are forward-looking statements, such as statements regarding our expectations concerning: industry, market, business, commercial, competitive or consumer trends; our businesses, growth potential or strategies, or factors that may impact them; attacks on our licensing business, including by licensees, customers, governments, governmental agencies or regulators, standards bodies or others; other legal or regulatory matters; competition; product or technology trends; new or expanded product areas, adjacent industry segments or applications; costs or expenditures including research and development, selling, general and administrative, restructuring or restructuring-related charges, working capital or information technology systems; our financing, stock repurchase or dividend programs; strategic investments or acquisitions; adoption and application of future accounting guidance; tax law changes; our tax structure or strategies; or the potential business or financial statement impacts of any of the above. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001728949-19-000036:mdna:4]
Second Quarter Fiscal 2019 Overview and Other Recent Events

[0001728949-19-000036:mdna:5]
Revenues for the second quarter of fiscal 2019 were $5.0 billion, a decrease of 5% compared to the year ago quarter, with net income of $663 million, an increase of 101% compared to the year ago quarter. Highlights and other events from the second quarter of fiscal 2019 and other recent events included:

[0001728949-19-000036:mdna:6]
| • | On April 16, 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties. We also entered into a six-year global patent license agreement with Apple, effective as of April 1, 2019, which includes an option for Apple to extend for two additional years, and a multi-year chipset supply agreement with Apple. |

[0001728949-19-000036:mdna:7]
| • | The transition of wireless networks and devices to 3G/4G (CDMA-single mode, OFDMA-single mode and CDMA/OFDMA multi-mode) continued around the world. 3G/4G connections grew sequentially by approximately 3% to approximately 5.7 billion, which was approximately 73% of total mobile connections at the end of the second quarter of fiscal 2019.(1) |

[0001728949-19-000036:mdna:8]
[same as prior period, unchanged from 0001728949-19-000012:mdna:7]

[0001728949-19-000036:mdna:9]
| • | QCT results in the second quarter of fiscal 2019 were negatively impacted by lower modem sales to Apple. |

[0001728949-19-000036:mdna:10]
| • | We adopted new revenue recognition accounting guidance in the first quarter of fiscal 2019 that requires us to estimate and recognize QTL royalties in the period in which the associated sales occur, resulting in an acceleration of royalty revenues by one quarter compared to the prior method. As a result of estimation, adjustments are recorded |

[0001728949-19-000036:mdna:11]
in subsequent quarters to reflect changes in estimates as new information becomes available, primarily when actual amounts are reported by licensees. Prior period results have not been restated for the adoption of the new accounting guidance and continue to be reported in accordance with the accounting guidance in effect for those periods.

[0001728949-19-000036:mdna:12]
| • | QTL results were negatively impacted by our prior dispute with Apple and its contract manufacturers. Revenues in the second quarter of fiscal 2019 did not include royalties due on sales of Apple or other products by Apple’s contract manufacturers. QTL revenues in the second quarter of fiscal 2019 included $150 million of royalties due under an interim agreement with Huawei. This represents a minimum, non-refundable amount for royalties due for the second quarter of fiscal 2019 by Huawei while negotiations continue. This payment does not reflect the full amount of royalties due under the underlying license agreement. |

[0001728949-19-000036:mdna:13]
| • | In the second quarter of fiscal 2018, we announced a Cost Plan designed to align our cost structure to our long-term margin targets, under which we initiated a series of targeted actions across our businesses with the objective to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. Actions taken under this plan have been completed and have resulted in us achieving substantially all of this target in fiscal 2019 based on our run rate exiting the second quarter of fiscal 2019, excluding litigation costs that are in excess of the baseline spend. |

[0001728949-19-000036:mdna:14]
| (1) | According to GSMA Intelligence estimates as of April 29, 2019 (estimates excluded Wireless Local Loop). |

[0001728949-19-000036:mdna:15]
[same as prior period, unchanged from 0001728949-19-000012:mdna:15]

[0001728949-19-000036:mdna:16]
[same as prior period, unchanged from 0001728949-19-000012:mdna:16]

[0001728949-19-000036:mdna:17]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices, wireless networks, devices used in IoT, broadband gateway equipment, consumer electronic devices and automotive telematics and infotainment systems. QTL grants licenses to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including Qualcomm Government Technologies or QGOV (formerly Qualcomm Cyber Security Solutions) and other wireless technology and service initiatives.

[0001728949-19-000036:mdna:18]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. All of our products and services businesses, including QCT, and all of our engineering, research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001728949-19-000036:mdna:19]
Seasonality. Many of our products and/or much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has historically tended to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons and due to the timing of Apple’s device launch in the fall. Similarly, because QTL historically has recognized royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made in the fourth calendar quarter. These trends did not occur in the first six months of fiscal 2019 due to QCT’s decline in share of modem sales for iPhone products and the lack of QTL royalty revenues recognized related to the sales of Apple’s products resulting from our prior dispute with Apple and its contract manufacturers. These trends may or may not continue in the future. Additionally, QTL’s revenues have been impacted by the adoption of the new revenue recognition guidance in fiscal 2019 pursuant to which we estimate and recognize sales-based royalties in the period in which the associated sales occur, resulting in an acceleration of royalty revenue recognition by one quarter compared to the prior method. The trends for QTL have been, and may be in the future be, impacted by disputes and/or resolutions with licensees.

[0001728949-19-000036:mdna:20]
We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 4G networks by wireless operators and the timing of launches of flagship wireless devices and consumer demand for wireless

[0001728949-19-000036:mdna:21]
devices that incorporate our products and/or intellectual property. These trends may or may not continue in the future, including as a result of 5G network deployments and flagship device launches.

[0001728949-19-000036:mdna:22]
[same as prior period, unchanged from 0001728949-19-000012:mdna:22]

[0001728949-19-000036:mdna:23]
| Revenues (in millions) |
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2019 |  | March 25, 2018 |  | Change |  | March 31, 2019 |  | March 25, 2018 |  | Change |
| Equipment and services | $ | 3,753 |  |  | $ | 3,936 |  |  | $ | (183 | ) |  | $ | 7,506 |  |  | $ | 8,639 |  |  | $ | (1,133 | ) |
| Licensing | 1,229 |  |  | 1,284 |  |  | (55 | ) |  | 2,318 |  |  | 2,616 |  |  | (298 | ) |
|  | $ | 4,982 |  |  | $ | 5,220 |  |  | $ | (238 | ) |  | $ | 9,824 |  |  | $ | 11,255 |  |  | $ | (1,431 | ) |

[0001728949-19-000036:mdna:24]
Second quarter 2019 vs. 2018

[0001728949-19-000036:mdna:25]
The decrease in revenues in the second quarter of fiscal 2019 was primarily due to:

[0001728949-19-000036:mdna:26]
| - | $227 million in lower equipment and services revenues from our QCT segment |

[0001728949-19-000036:mdna:27]
| - | $97 million in lower licensing revenues from our QTL segment |

[0001728949-19-000036:mdna:28]
First six months 2019 vs. 2018

[0001728949-19-000036:mdna:29]
The decrease in revenues in the first six months of fiscal 2019 was primarily due to:

[0001728949-19-000036:mdna:30]
| - | $1.1 billion in lower equipment and services revenues from our QCT segment |

[0001728949-19-000036:mdna:31]
| - | $344 million in lower licensing revenues from our QTL segment |

[0001728949-19-000036:mdna:32]
| Costs and Expenses (in millions) |
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2019 |  | March 25, 2018 |  | Change |  | March 31, 2019 |  | March 25, 2018 |  | Change |
| Cost of revenues | $ | 2,179 |  |  | $ | 2,239 |  |  | $ | (60 | ) |  | $ | 4,367 |  |  | $ | 4,902 |  |  | $ | (535 | ) |
| Gross margin | 56 | % |  | 57 | % |  |  |  | 56 | % |  | 56 | % |  |  |

[0001728949-19-000036:mdna:33]
Second quarter 2019 vs. 2018

[0001728949-19-000036:mdna:34]
Gross margin percentage decreased in the second quarter of fiscal 2019 primarily due to:

[0001728949-19-000036:mdna:35]
[same as prior period, unchanged from 0001728949-19-000012:mdna:31]

[0001728949-19-000036:mdna:36]
First six months 2019 vs. 2018

[0001728949-19-000036:mdna:37]
Gross margin percentage remained flat in the first six months of fiscal 2019 primarily due to:

[0001728949-19-000036:mdna:38]
-    decrease in QCT gross margin

[0001728949-19-000036:mdna:39]
+    increase in QSI gross margin

[0001728949-19-000036:mdna:40]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2019 |  | March 25, 2018 |  | Change |  | March 31, 2019 |  | March 25, 2018 |  | Change |
| Research and development | $ | 1,308 |  |  | $ | 1,402 |  |  | $ | (94 | ) |  | $ | 2,577 |  |  | $ | 2,822 |  |  | $ | (245 | ) |
| % of revenues | 26 | % |  | 27 | % |  |  |  | 26 | % |  | 25 | % |  |  |

[0001728949-19-000036:mdna:41]
Second quarter 2019 vs. 2018

[0001728949-19-000036:mdna:42]
The dollar decrease in research and development expenses in the second quarter of fiscal 2019 was primarily due to:

[0001728949-19-000036:mdna:43]
| - | $92 million decrease primarily driven by actions under our Cost Plan, partially offset by higher costs related to the development of 5G wireless and integrated circuit technologies |

[0001728949-19-000036:mdna:44]
First six months 2019 vs. 2018

[0001728949-19-000036:mdna:45]
The dollar decrease in research and development expenses in the first six months of fiscal 2019 was primarily due to:

[0001728949-19-000036:mdna:46]
| - | $244 million decrease primarily driven by actions under our Cost Plan, partially offset by higher costs related to the development of 5G wireless and integrated circuit technologies |

[0001728949-19-000036:mdna:47]
In fiscal 2018, all of the costs related to pre-commercial research and development of 5G technologies, of which we recorded $115 million and $216 million in the second quarter and first six months of fiscal 2018, respectively, were included in unallocated corporate research and development expenses. Beginning in the first quarter of fiscal 2019, all research and

[0001728949-19-000036:mdna:48]
[same as prior period, unchanged from 0001728949-19-000012:mdna:20]

[0001728949-19-000036:mdna:49]
development costs associated with 5G technologies are included in segment results. Additionally, beginning in the first quarter of fiscal 2019, certain research and development costs associated with early research and development that were historically included in our QCT segment are allocated to our QTL segment. The net effect of these changes negatively impacted QTL’s EBT by $119 million and $241 million in the second quarter and first six months of fiscal 2019, respectively. QCT's EBT was positively impacted by $32 million and $44 million in the second quarter and first six months of fiscal 2019, respectively.

[0001728949-19-000036:mdna:50]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2019 |  | March 25, 2018 |  | Change |  | March 31, 2019 |  | March 25, 2018 |  | Change |
| Selling, general and administrative | $ | 573 |  |  | $ | 869 |  |  | $ | (296 | ) |  | $ | 1,100 |  |  | $ | 1,641 |  |  | $ | (541 | ) |
| % of revenues | 12 | % |  | 17 | % |  |  |  | 11 | % |  | 15 | % |  |  |

[0001728949-19-000036:mdna:51]
Second quarter 2019 vs. 2018

[0001728949-19-000036:mdna:52]
The dollar decrease in selling, general and administrative expenses in the second quarter of fiscal 2019 was primarily due to:

[0001728949-19-000036:mdna:53]
| - | $217 million in lower professional fees and costs, primarily driven by Broadcom’s withdrawn takeover proposal in fiscal 2018 |

[0001728949-19-000036:mdna:54]
| - | $24 million in lower sales and marketing expenses |

[0001728949-19-000036:mdna:55]
| - | $24 million in lower employee-related expenses, primarily driven by actions under our Cost Plan |

[0001728949-19-000036:mdna:56]
First six months 2019 vs. 2018

[0001728949-19-000036:mdna:57]
The dollar decrease in selling, general and administrative expenses in the first six months of fiscal 2019 was primarily due to:

[0001728949-19-000036:mdna:58]
| - | $285 million in lower professional fees and costs, primarily driven by Broadcom’s withdrawn takeover proposal in fiscal 2018 and our proposed acquisition of NXP Semiconductors N.V. in fiscal 2018 |

[0001728949-19-000036:mdna:59]
| - | $72 million in lower employee-related expenses, primarily driven by actions under our Cost Plan |

[0001728949-19-000036:mdna:60]
[same as prior period, unchanged from 0001728949-19-000012:mdna:41]

[0001728949-19-000036:mdna:61]
| - | $45 million in lower sales and marketing expenses |

[0001728949-19-000036:mdna:62]
Selling, general and administrative expenses included $126 million and $223 million in the second quarter and first six months of fiscal 2019, respectively, related to litigation costs, a decrease compared to the second quarter and first six months fiscal 2018 of $20 million and $29 million, respectively.

[0001728949-19-000036:mdna:63]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2019 |  | March 25, 2018 |  | Change |  | March 31, 2019 |  | March 25, 2018 |  | Change |
| Other | $ | (18 | ) |  | $ | 310 |  |  | $ | (328 | ) |  | $ | 130 |  |  | $ | 1,493 |  |  | $ | (1,363 | ) |

[0001728949-19-000036:mdna:64]
Second quarter 2019

[0001728949-19-000036:mdna:65]
Other income in the second quarter of fiscal 2019 consisted of:

[0001728949-19-000036:mdna:66]
| + | $43 million gain due to the partial recovery of a fine imposed in fiscal 2009 resulting from our appeal of the Korea Fair Trade Commission (KFTC) decision |

[0001728949-19-000036:mdna:67]
| - | $25 million in net charges related to our Cost Plan, which included $70 million in restructuring and restructuring-related charges, partially offset by a $45 million net gain from the sale of certain assets related to wireless electric vehicle charging applications and the sale of our mobile health nonreportable segment |

[0001728949-19-000036:mdna:68]
Second quarter 2018

[0001728949-19-000036:mdna:69]
Other expenses in the second quarter of fiscal 2018 consisted of:

[0001728949-19-000036:mdna:70]
+    $310 million in restructuring and restructuring-related charges related to our Cost Plan

[0001728949-19-000036:mdna:71]
First six months 2019

[0001728949-19-000036:mdna:72]
Other expenses in the first six months of fiscal 2019 consisted of:

[0001728949-19-000036:mdna:73]
| + | $204 million net charges related to our Cost Plan, which included $249 million in restructuring and restructuring-related charges, partially offset by a $45 million net gain from the sale of certain assets related to wireless electric vehicle charging applications and the sale of our mobile health nonreportable segment |

[0001728949-19-000036:mdna:74]
| - | $43 million gain due to the partial recovery of a fine imposed in fiscal 2009 resulting from our appeal of the KFTC decision |

[0001728949-19-000036:mdna:75]
-    $31 million gain related to a favorable legal settlement

[0001728949-19-000036:mdna:76]
37

[0001728949-19-000036:mdna:77]
First six months 2018

[0001728949-19-000036:mdna:78]
Other expenses in the first six months of fiscal 2018 consisted of:

[0001728949-19-000036:mdna:79]
[same as prior period, unchanged from 0001728949-19-000012:mdna:53]

[0001728949-19-000036:mdna:80]
+    $310 million in restructuring and restructuring-related charges related to our Cost Plan

[0001728949-19-000036:mdna:81]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2019 |  | March 25, 2018 |  | Change |  | March 31, 2019 |  | March 25, 2018 |  | Change |
| Interest expense | $ | 162 |  |  | $ | 179 |  |  | $ | (17 | ) |  | $ | 317 |  |  | $ | 350 |  |  | $ | (33 | ) |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 80 |  |  | $ | 154 |  |  | $ | (74 | ) |  | $ | 155 |  |  | $ | 280 |  |  | $ | (125 | ) |
| Net gains (losses) on marketable securities | 40 |  |  | 3 |  |  | 37 |  |  | (33 | ) |  | 13 |  |  | (46 | ) |
| Net gains on other investments | 6 |  |  | 47 |  |  | (41 | ) |  | 42 |  |  | 60 |  |  | (18 | ) |
| Impairment losses on marketable securities and other investments | (60 | ) |  | (11 | ) |  | (49 | ) |  | (69 | ) |  | (20 | ) |  | (49 | ) |
| Equity in net losses of investees | (36 | ) |  | (17 | ) |  | (19 | ) |  | (58 | ) |  | (38 | ) |  | (20 | ) |
| Net (losses) gains on foreign currency transactions | (1 | ) |  | (90 | ) |  | 89 |  |  | 5 |  |  | (93 | ) |  | 98 |  |
| Net (losses) gains on derivative instruments | (1 | ) |  | 10 |  |  | (11 | ) |  | (9 | ) |  | 9 |  |  | (18 | ) |
|  | $ | 28 |  |  | $ | 96 |  |  | $ | (68 | ) |  | $ | 33 |  |  | $ | 211 |  |  | $ | (178 | ) |

[0001728949-19-000036:mdna:82]
[same as prior period, unchanged from 0001728949-19-000012:mdna:55]

[0001728949-19-000036:mdna:83]
| Income Tax Expense (Benefit) (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2019 |  | March 25, 2018 |  | Change |  | March 31, 2019 |  | March 25, 2018 |  | Change |
| Income tax expense (benefit) | $ | 143 |  |  | $ | (13 | ) |  | $ | 156 |  |  | $ | (365 | ) |  | $ | 5,911 |  |  | $ | (6,276 | ) |
| Effective tax rate | 18 | % |  | N/M |  |  | N/M |  |  | (27 | %) |  | N/M |  |  | N/M |  |

[0001728949-19-000036:mdna:84]
[same as prior period, unchanged from 0001728949-19-000012:mdna:57]

[0001728949-19-000036:mdna:85]
38

[0001728949-19-000036:mdna:86]
The following table summarizes the primary factors that caused our income tax provision to differ from the expected income tax provision at the U.S. federal statutory rate:

[0001728949-19-000036:mdna:87]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2019 |  | March 25, 2018 |  | March 31, 2019 |  | March 25, 2018 |
| Expected income tax provision at federal statutory tax rate | $ | 169 |  |  | $ | 78 |  |  | $ | 287 |  |  | $ | 64 |  |
| Benefits from establishing new U.S. net deferred tax assets | — |  |  | — |  |  | (570 | ) |  | — |  |
| Detriments (benefits) from foreign income taxed at other than U.S. rates | 8 |  |  | (107 | ) |  | 12 |  |  | (100 | ) |
| Benefits related to the research and development tax credit | (22 | ) |  | (29 | ) |  | (46 | ) |  | (28 | ) |
| Benefit from foreign-derived intangible income (FDII) deduction | (48 | ) |  | — |  |  | (88 | ) |  | — |  |
| Toll Charge from U.S. tax reform | — |  |  | 7 |  |  | — |  |  | 5,314 |  |
| Remeasurement of deferred taxes due to changes in statutory tax rate | — |  |  | (10 | ) |  | — |  |  | 557 |  |
| Foreign withholding taxes | — |  |  | 7 |  |  | — |  |  | 93 |  |
| Nondeductible charges related to the KFTC and EC investigations | — |  |  | 16 |  |  | — |  |  | 15 |  |
| Other | 36 |  |  | 25 |  |  | 40 |  |  | (4 | ) |
| Income tax expense (benefit) | $ | 143 |  |  | $ | (13 | ) |  | $ | (365 | ) |  | $ | 5,911 |  |

[0001728949-19-000036:mdna:88]
The 2017 Tax Cuts and Jobs Act (the Tax Legislation) significantly revised the United States corporate income tax by, among other things, lowering the corporate income tax rate to 21% and imposing a one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge). The Tax Legislation fundamentally changed the taxation of multinational entities, including a shift from a system of worldwide taxation with deferral to a hybrid territorial system, featuring a participation exemption regime with current taxation of certain foreign income, a minimum tax on low-taxed foreign earnings and new measures to deter base erosion and promote U.S. production. As a fiscal-year taxpayer, certain provisions of the Tax Legislation became effective starting at the beginning of fiscal 2019, including new taxes due on certain foreign income, such as GILTI (global intangible low-taxed income), BEAT (base-erosion and anti-abuse tax) and FDII (foreign-derived intangible income). In response to the Tax Legislation, we implemented certain tax restructuring in fiscal 2018 and 2019. As a result, without considering the effects of the agreements with Apple and its contract manufacturers signed in April 2019, substantially all of our income is in the U.S. and qualifies for preferential treatment as FDII, and the impact of GILTI and BEAT are negligible. Accordingly, our estimated annual effective tax rate for fiscal 2019 reflects the effects of these components of the Tax Legislation. Our federal statutory income tax rate for fiscal 2018 reflected a blended rate of approximately 25%.

[0001728949-19-000036:mdna:89]
As a result of the Tax Legislation, in fiscal 2019, several of our foreign subsidiaries made tax elections to be treated as U.S. branches for federal income tax purposes (commonly referred to as “check-the-box” elections) effective beginning in fiscal 2018 and 2019. We believe that by treating these foreign subsidiaries as U.S. branches for federal income taxes, rather than controlled foreign corporations, we will significantly reduce the risk of being subject to GILTI and BEAT taxes. As a result of making these check-the-box elections in the first quarter of fiscal 2019, we recorded a tax benefit of $570 million due to establishing new U.S. net deferred tax assets resulting from the difference between the GAAP basis and the U.S. federal tax carryover basis of the existing assets and liabilities of those foreign subsidiaries, primarily related to customer incentive liabilities that have not been deducted for tax purposes.

[0001728949-19-000036:mdna:90]
The effective tax rate of 18% for the second quarter of fiscal 2019 was higher than the estimated annual effective tax rate of 6% benefit (which excluded the effects of the agreements with Apple and its contract manufacturers signed in April 2019) primarily due to the tax benefit of $570 million described above, which was recorded discretely in the first quarter.

[0001728949-19-000036:mdna:91]
Unrecognized tax benefits were $228 million and $217 million at March 31, 2019 and September 30, 2018, respectively. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at March 31, 2019 may increase or decrease in the next 12 months.

[0001728949-19-000036:mdna:92]
The United States Treasury Department has issued proposed regulations on several provisions of the Tax Legislation, including foreign tax credits, FDII, GILTI, BEAT and interest expense deduction limitations, which are expected to be finalized in the next several months. When finalized, these proposed regulations may adversely affect our provision for income taxes, results of operations and/or cash flows.

[0001728949-19-000036:mdna:93]
[same as prior period, unchanged from 0001728949-19-000012:mdna:65]

[0001728949-19-000036:mdna:94]
The following should be read in conjunction with the financial results for the second quarter and first six months of fiscal 2019 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0001728949-19-000036:mdna:95]
[same as prior period, unchanged from 0001728949-19-000012:mdna:67]

[0001728949-19-000036:mdna:96]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | March 31, 2019 |  | March 25, 2018 |  | Change |  | March 31, 2019 |  | March 25, 2018 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,622 |  |  | $ | 3,849 |  |  | $ | (227 | ) |  | $ | 7,300 |  |  | $ | 8,447 |  |  | $ | (1,147 | ) |
| Licensing | 100 |  |  | 48 |  |  | 52 |  |  | 161 |  |  | 101 |  |  | 60 |  |
| Total revenues | $ | 3,722 |  |  | $ | 3,897 |  |  | $ | (175 | ) |  | $ | 7,461 |  |  | $ | 8,548 |  |  | $ | (1,087 | ) |
| EBT (1) | $ | 542 |  |  | $ | 608 |  |  | $ | (66 | ) |  | $ | 1,140 |  |  | $ | 1,563 |  |  | $ | (423 | ) |
| EBT as a % of revenues | 15 | % |  | 16 | % |  | (1 | %) |  | 15 | % |  | 18 | % |  | (3 | %) |

[0001728949-19-000036:mdna:97]
[same as prior period, unchanged from 0001728949-19-000012:mdna:69]

[0001728949-19-000036:mdna:98]
[same as prior period, unchanged from 0001728949-19-000012:mdna:70]

[0001728949-19-000036:mdna:99]
Equipment and services revenues mostly relate to sales of Mobile Station Modem (MSM) and accompanying Radio Frequency (RF), Power Management (PM) and wireless connectivity integrated circuits. Approximately 155 million and 187 million MSM integrated circuits were sold in the second quarter of fiscal 2019 and 2018, respectively, and approximately 341 million and 424 million MSM integrated circuits were sold in the first six months of fiscal 2019 and 2018, respectively.

[0001728949-19-000036:mdna:100]
Second quarter 2019 vs. 2018

[0001728949-19-000036:mdna:101]
The decrease in QCT equipment and services revenues in the second quarter of fiscal 2019 was primarily due to:

[0001728949-19-000036:mdna:102]
| - | $424 million in lower MSM and accompanying unit shipments, primarily due to a decline in share at Apple |

[0001728949-19-000036:mdna:103]
| - | $223 million decrease due to lower average selling prices |

[0001728949-19-000036:mdna:104]
| + | $453 million due to favorable product mix |

[0001728949-19-000036:mdna:105]
QCT EBT as a percentage of revenues decreased in the second quarter of fiscal 2019 primarily due to:

[0001728949-19-000036:mdna:106]
[same as prior period, unchanged from 0001728949-19-000012:mdna:80]

[0001728949-19-000036:mdna:107]
[same as prior period, unchanged from 0001728949-19-000012:mdna:81]

[0001728949-19-000036:mdna:108]
[same as prior period, unchanged from 0001728949-19-000012:mdna:82]

[0001728949-19-000036:mdna:109]
First six months 2019 vs. 2018

[0001728949-19-000036:mdna:110]
The decrease in QCT equipment and services revenues in the first six months of fiscal 2019 was primarily due to:

[0001728949-19-000036:mdna:111]
| - | $1.12 billion in lower MSM and accompanying unit shipments, primarily due to a decline in share at Apple |

[0001728949-19-000036:mdna:112]
| - | $454 million decrease due to lower average selling prices |

[0001728949-19-000036:mdna:113]
| - | $239 million in lower RFFE product revenues, primarily due to a decline in share at Apple |

[0001728949-19-000036:mdna:114]
| + | $659 million increase due to favorable product mix |

[0001728949-19-000036:mdna:115]
QCT EBT as a percentage of revenues decreased in the first six months of fiscal 2019 primarily due to:

[0001728949-19-000036:mdna:116]
| - | decrease in QCT revenues |

[0001728949-19-000036:mdna:117]
| - | decrease in gross margin percentage, primarily driven by lower average selling prices, partially offset by higher-margin product mix and lower average unit costs |

[0001728949-19-000036:mdna:118]
| + | decrease in operating expenses, primarily driven by actions under our Cost Plan |

[0001728949-19-000036:mdna:119]
QCT accounts receivable decreased by 10% in the first six months of fiscal 2019 from $1.36 billion to $1.22 billion, primarily due to an increase in the portion of customer incentive arrangements that are included in accounts receivable and a decrease in revenues, partially offset by the timing of integrated circuit shipments. QCT inventories increased by 3% in the

[0001728949-19-000036:mdna:120]
40

[0001728949-19-000036:mdna:121]
first six months of fiscal 2019 from $1.68 billion to $1.72 billion, primarily due to an increase in the overall quantity of units on hand.

[0001728949-19-000036:mdna:122]
[same as prior period, unchanged from 0001728949-19-000012:mdna:84]

[0001728949-19-000036:mdna:123]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | March 31, 2019 |  | March 25, 2018 |  | Change |  | March 31, 2019 |  | March 25, 2018 |  | Change |
| Licensing revenues | $ | 1,122 |  |  | $ | 1,219 |  |  | $ | (97 | ) |  | $ | 2,141 |  |  | $ | 2,485 |  |  | $ | (344 | ) |
| EBT | $ | 674 |  |  | $ | 809 |  |  | $ | (135 | ) |  | $ | 1,264 |  |  | $ | 1,664 |  |  | $ | (400 | ) |
| EBT as a % of revenues | 60 | % |  | 66 | % |  | (6 | %) |  | 59 | % |  | 67 | % |  | (8 | %) |

[0001728949-19-000036:mdna:124]
QTL results in the second quarter and first six months of fiscal 2019 reflected the adoption of the new accounting guidance that requires us to estimate and recognize QTL royalties in the period in which the associated sales occur, resulting in an acceleration of royalty revenues by one quarter as compared to fiscal 2018. Fiscal 2018 results have not been adjusted for the adoption of the new accounting guidance.

[0001728949-19-000036:mdna:125]
QTL results in the first six months of fiscal 2019 and 2018 were negatively impacted by our prior dispute with Apple and its contract manufacturers. Revenues in the first six months of fiscal 2019 and 2018 did not include royalties due on sales of Apple or other products by Apple’s contract manufacturers. In April 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties. Further information is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 12. Subsequent Event.”

[0001728949-19-000036:mdna:126]
QTL revenues in the second quarter and first six months of fiscal 2019 included $150 million and $300 million, respectively, of royalties due under an interim agreement with Huawei. These payments represent minimum, non-refundable amounts for royalties due while negotiations continue. These payments do not reflect the full amount of royalties due under the underlying license agreement. We did not record any revenues in the first six months of fiscal 2018 for royalties due on sales of Huawei’s products.

[0001728949-19-000036:mdna:127]
Second quarter 2019 vs. 2018

[0001728949-19-000036:mdna:128]
QTL licensing revenues in the second quarter of fiscal 2019, which primarily related to royalties due on sales made by our licensees in the March 2019 quarter, decreased compared to licensing revenues in the second quarter of fiscal 2018, which primarily related to royalties due on sales made by our licensees in the December 2017 quarter, primarily due to:

[0001728949-19-000036:mdna:129]
| - | $216 million in lower estimated revenues per unit compared to revenues per reported unit |

[0001728949-19-000036:mdna:130]
| - | $122 million decrease in estimated sales of CDMA-based products (including multi-mode products that also implement OFDMA) compared to reported sales of CDMA-based products |

[0001728949-19-000036:mdna:131]
[same as prior period, unchanged from 0001728949-19-000012:mdna:93]

[0001728949-19-000036:mdna:132]
| + | $91 million increase in royalty revenues recognized related to devices sold in prior periods |

[0001728949-19-000036:mdna:133]
QTL EBT as a percentage of revenues decreased in the second quarter of fiscal 2019 primarily due to:

[0001728949-19-000036:mdna:134]
[same as prior period, unchanged from 0001728949-19-000012:mdna:96]

[0001728949-19-000036:mdna:135]
[same as prior period, unchanged from 0001728949-19-000012:mdna:97]

[0001728949-19-000036:mdna:136]
| + | lower selling, general and administrative expenses, primarily from lower litigation costs |

[0001728949-19-000036:mdna:137]
First six months 2019 vs. 2018

[0001728949-19-000036:mdna:138]
QTL licensing revenues in the first six months of fiscal 2019, which primarily related to royalties due on sales made by our licensees in the December 2018 and March 2019 quarters, decreased compared to licensing revenues in the first six months of fiscal 2018, which primarily related to royalties due on sales made by our licensees in the September and December 2017 quarters, primarily due to:

[0001728949-19-000036:mdna:139]
| - | $404 million in lower estimated revenues per unit compared to revenues per reported unit |

[0001728949-19-000036:mdna:140]
| - | $285 million decrease in estimated sales of CDMA-based products (including multi-mode products that also implement OFDMA) compared to reported sales of CDMA-based products |

[0001728949-19-000036:mdna:141]
| + | $300 million under an interim agreement with Huawei |

[0001728949-19-000036:mdna:142]
| + | $44 million increase in royalty revenues recognized related to devices sold in prior periods |

[0001728949-19-000036:mdna:143]
QTL EBT as a percentage of revenues decreased in the first six months of fiscal 2019 primarily due to:

[0001728949-19-000036:mdna:144]
| - | higher research and development costs due to an increase in the amount of research and development expense allocated to QTL in fiscal 2019 |

[0001728949-19-000036:mdna:145]
| - | lower QTL revenues |

[0001728949-19-000036:mdna:146]
| + | lower selling, general and administrative expenses, primarily from lower bad debt expense and lower litigation costs |

[0001728949-19-000036:mdna:147]
QTL accounts receivable increased by 63% in the first six months of fiscal 2019 from $1.47 billion to $2.41 billion, primarily due to the adoption of the new accounting guidance.

[0001728949-19-000036:mdna:148]
[same as prior period, unchanged from 0001728949-19-000012:mdna:100]

[0001728949-19-000036:mdna:149]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | March 31, 2019 |  | March 25, 2018 |  | Change |  | March 31, 2019 |  | March 25, 2018 |  | Change |
| Equipment and services revenues | $ | 98 |  |  | $ | 30 |  |  | $ | 68 |  |  | $ | 125 |  |  | $ | 60 |  |  | $ | 65 |  |
| EBT | 17 |  |  | 40 |  |  | (23 | ) |  | 25 |  |  | 51 |  |  | (26 | ) |

[0001728949-19-000036:mdna:150]
Second quarter 2019 vs. 2018

[0001728949-19-000036:mdna:151]
The decrease in QSI EBT in the second quarter of fiscal 2019 was primarily due to:

[0001728949-19-000036:mdna:152]
| - | $49 million increase in impairment losses on investments, primarily related to an equity method investee |

[0001728949-19-000036:mdna:153]
| - | $36 million decrease in net gains on investments, primarily driven by a decrease in gains on non-marketable equity investments |

[0001728949-19-000036:mdna:154]
| - | $19 million increase in our share of equity method investee losses |

[0001728949-19-000036:mdna:155]
| + | $78 million increase resulting from higher revenues and lower costs associated with certain development contracts with an equity method investee |

[0001728949-19-000036:mdna:156]
First six months 2019 vs. 2018

[0001728949-19-000036:mdna:157]
The decrease in QSI EBT in the first six months of fiscal 2019 was primarily due to:

[0001728949-19-000036:mdna:158]
| - | $52 million increase in impairment losses on investments, primarily related to an equity method investee |

[0001728949-19-000036:mdna:159]
| - | $37 million decrease in net gains on investments, primarily driven by a decrease in gains on non-marketable equity investments |

[0001728949-19-000036:mdna:160]
| - | $20 million increase in our share of equity method investee losses |

[0001728949-19-000036:mdna:161]
| + | $82 million increase resulting from higher revenues and lower costs associated with certain development contracts with an equity method investee |

[0001728949-19-000036:mdna:162]
[same as prior period, unchanged from 0001728949-19-000012:mdna:106]

[0001728949-19-000036:mdna:163]
In the coming years, we expect consumer demand for 3G/4G multi-mode and 4G products and services to decline as new consumer demand for 3G/4G/5G multi-mode and 5G products and services ramp around the world. We expect growth in new device categories and industries, resulting from the expanding adoption of certain technologies that are already commonly used in smartphones by industry segments outside traditional cellular industries, such as automotive, IoT and networking.

[0001728949-19-000036:mdna:164]
[same as prior period, unchanged from 0001728949-19-000012:mdna:108]

[0001728949-19-000036:mdna:165]
| • | On April 16, 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties. We also entered into a six-year global patent license agreement with Apple, effective as of April 1, 2019, which includes an option for Apple to extend for two additional years, and a multi-year chipset supply agreement with Apple. While we continue to assess the accounting impacts of the agreements, we currently expect to record revenues of $4.5 billion to $4.7 billion in the third quarter of fiscal 2019 resulting from the settlement, consisting of a payment from Apple and the release of our obligations to pay or refund Apple and the contract manufacturers certain customer-related liabilities. In addition, we will begin recording royalty revenues in the third quarter of fiscal 2019 for sales made by Apple and its contract manufacturers on or after April 1, 2019. For the remainder of fiscal 2019, we expect operating expenses to increase primarily as a result of higher employee cash incentive program costs as a result of the settlement, partially offset by lower litigation costs. Further, we expect our engineering costs will increase over time to support the multi-year chipset supply agreement. |

[0001728949-19-000036:mdna:166]
[same as prior period, unchanged from 0001728949-19-000012:mdna:110]

[0001728949-19-000036:mdna:167]
[same as prior period, unchanged from 0001728949-19-000012:mdna:116]

[0001728949-19-000036:mdna:168]
direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. These activities have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs until the respective matters are resolved. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report, including the Risk Factors entitled “Efforts by some communications equipment manufacturers or their customers to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business,” “Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings” and “Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.”

[0001728949-19-000036:mdna:169]
| • | In the first quarter of fiscal 2019, we entered into a second interim agreement with Huawei in which Huawei agreed to make three quarterly payments of $150 million (for sales made in consecutive calendar quarters beginning with the quarter ended December 2018) as minimum, non-refundable payments for royalties due for sales of licensed products by Huawei during the relevant quarter while negotiations continue. We recognized $300 million of royalty revenues in the first six months of fiscal 2019 under the second interim agreement. These payments do not reflect the full amount of royalties due under the underlying license agreement. If we do not reach a final agreement with Huawei prior to the conclusion of the second interim agreement, Huawei may not make any other payments or may not make full payments under the underlying license agreement, which may result in significant legal costs, due to exercising the dispute resolution provision in the license agreement, and will negatively impact our future revenues, as well as our financial condition, results of operations and cash flows until the dispute is resolved. |

[0001728949-19-000036:mdna:170]
[same as prior period, unchanged from 0001728949-19-000012:mdna:114]

[0001728949-19-000036:mdna:171]
[same as prior period, unchanged from 0001728949-19-000012:mdna:115]

[0001728949-19-000036:mdna:172]
[same as prior period, unchanged from 0001728949-19-000012:mdna:117]

[0001728949-19-000036:mdna:173]
| • | Decisions by certain companies to utilize our competitors’ integrated circuit products in all or a portion of their devices. For example, we have not been the sole supplier of modems for iPhone products beginning with products that launched in September 2016, as Apple utilizes modems from one of our competitors in a portion of such devices. Apple began solely using one or more of our competitors’ modems, rather than our modems, in its 2018 iPhone release and is expected to do so in its upcoming 2019 iPhone release. As a result, QCT revenues from modem sales for iPhones have declined in the first six months of fiscal 2019. For new chipset models, QCT does not expect to begin recording revenues under our recently announced multi-year chipset agreement with Apple until the second half of fiscal 2020. Apple’s sourcing of integrated circuit products does not impact our licensing revenues since our licensing revenues from Apple products are not dependent upon whether such products include our chipsets; |

[0001728949-19-000036:mdna:174]
[same as prior period, unchanged from 0001728949-19-000012:mdna:119]

[0001728949-19-000036:mdna:175]
[same as prior period, unchanged from 0001728949-19-000012:mdna:120]

[0001728949-19-000036:mdna:176]
[same as prior period, unchanged from 0001728949-19-000012:mdna:121]

[0001728949-19-000036:mdna:177]
[same as prior period, unchanged from 0001728949-19-000012:mdna:131]

[0001728949-19-000036:mdna:178]
| • | Increasing consumer demand for 3G/4G smartphone products in emerging regions driven by availability of lower-tier 3G/4G devices, partially offset by lengthening replacement cycles in China. |

[0001728949-19-000036:mdna:179]
[same as prior period, unchanged from 0001728949-19-000012:mdna:123]

[0001728949-19-000036:mdna:180]
[same as prior period, unchanged from 0001728949-19-000012:mdna:124]

[0001728949-19-000036:mdna:181]
| • | Initial commercial 5G network deployments and device launches have begun and will continue in calendar 2019 and beyond. We believe that 5G technologies will empower a new era of smartphones and connected devices. We also believe that 5G will drive transformation across industries beyond traditional cellular communications that will create new business models and new services. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing of 5G technologies, and to be a leading developer and supplier of 5G integrated circuit products and services in order to sustain and grow our business long term. |

[0001728949-19-000036:mdna:182]
[same as prior period, unchanged from 0001728949-19-000012:mdna:126]

[0001728949-19-000036:mdna:183]
[same as prior period, unchanged from 0001728949-19-000012:mdna:127]

[0001728949-19-000036:mdna:184]
[same as prior period, unchanged from 0001728949-19-000012:mdna:128]

[0001728949-19-000036:mdna:185]
[same as prior period, unchanged from 0001728949-19-000012:mdna:129]

[0001728949-19-000036:mdna:186]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. The following table presents selected financial information related to our liquidity as of March 31, 2019 and September 30, 2018 and for the first six months of fiscal 2019 and 2018 (in millions):

[0001728949-19-000036:mdna:187]
|  | March 31, 2019 |  | September 30, 2018 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 10,366 |  |  | $ | 12,123 |  |  | $ | (1,757 | ) |  | (14 | %) |
| Accounts receivable, net | 3,638 |  |  | 2,904 |  |  | 734 |  |  | 25 | % |
| Inventories | 1,725 |  |  | 1,693 |  |  | 32 |  |  | 2 | % |
| Short-term debt | 998 |  |  | 1,005 |  |  | (7 | ) |  | (1 | %) |
| Long-term debt | 15,405 |  |  | 15,365 |  |  | 40 |  |  | — | % |
| Noncurrent income taxes payable | 1,849 |  |  | 2,312 |  |  | (463 | ) |  | (20 | %) |

[0001728949-19-000036:mdna:188]
|  | Six Months Ended |
|  | March 31, 2019 |  | March 25, 2018 |  | $ Change |  | % Change |
| Net cash provided by operating activities | $ | 1,150 |  |  | $ | 2,278 |  |  | $ | (1,128 | ) |  | (50 | %) |
| Net cash (used) provided by investing activities | (261 | ) |  | 1,481 |  |  | (1,742 | ) |  | (118 | %) |
| Net cash used by financing activities | (2,531 | ) |  | (874 | ) |  | (1,657 | ) |  | 190 | % |

[0001728949-19-000036:mdna:189]
44

[0001728949-19-000036:mdna:190]
The net decrease in cash, cash equivalents and marketable securities was primarily due to $1.5 billion in cash dividends paid, $1.0 billion in payments to repurchase shares of our common stock, $322 million in capital expenditures and $143 million in payments of tax withholdings related to the vesting of share-based awards, partially offset by net cash provided by operating activities. Total cash provided by operating activities decreased primarily due to lower revenues. Total cash provided by operating activities was also negatively impacted by actions taken by Apple and its contract manufacturers who did not report or pay royalties due on sales of Apple products in the first six months of fiscal 2019 and the first six months of fiscal 2018.

[0001728949-19-000036:mdna:191]
Our days sales outstanding, on a consolidated basis, increased to 67 at March 31, 2019, as compared to 49 at September 30, 2018. The increase in accounts receivable and the related days sales outstanding were primarily due to the adoption of the new revenue recognition accounting guidance in the first quarter of fiscal 2019. Inventories remained largely flat in the first six-months of fiscal 2019.

[0001728949-19-000036:mdna:192]
As a result of the agreements signed with Apple and its contract manufacturers in April 2019, we expect our liquidity to be positively impacted by the settlement payment due from Apple, royalties to be paid by Apple for sales made on or after April 1, 2019 and lower litigation costs, partially offset by higher employee cash incentive program costs as a result of the settlement. Further, we expect our engineering costs will increase over time to support the multi-year chipset supply agreement.

[0001728949-19-000036:mdna:193]
Debt. Our Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in the aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. At March 31, 2019, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-19-000036:mdna:194]
We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At March 31, 2019, we had $1.0 billion of commercial paper outstanding with a weighted-average interest rate of 2.74% and weighted-average remaining days to maturity of 29 days.

[0001728949-19-000036:mdna:195]
In May 2017, we issued an aggregate principal amount of $11.0 billion in nine tranches of unsecured floating- and fixed-rate notes, of which $7.0 billion remains outstanding with maturity dates in 2023 through 2047. Effective interest rates were between 2.70% and 4.47% at March 31, 2019. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001728949-19-000036:mdna:196]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, of which $8.5 billion remains outstanding with maturity dates in 2020 through 2045. Effective interest rates were between 3.09% and 4.73% at March 31, 2019. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001728949-19-000036:mdna:197]
[same as prior period, unchanged from 0001728949-19-000012:mdna:143]

[0001728949-19-000036:mdna:198]
Additional information regarding our outstanding debt at March 31, 2019 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt.”

[0001728949-19-000036:mdna:199]
Income Taxes. Tax Legislation, which was signed into law during the first quarter of fiscal 2018, resulted in a $5.2 billion charge recognized in fiscal 2018 related to the Toll Charge. The first payment was made on January 15, 2019. At March 31, 2019, we estimated remaining future payments of $1.8 billion for the Toll Charge, after application of certain tax credits (including excess tax credits that are expected to be generated in fiscal 2019), which is payable in installments over the next seven years (8% in each of the next four years, 15% in year five, 20% in year six and 25% in year seven).

[0001728949-19-000036:mdna:200]
[same as prior period, unchanged from 0001728949-19-000012:mdna:146]

[0001728949-19-000036:mdna:201]
Capital Return Program. In the fourth quarter of fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. In fiscal 2018, we entered into three accelerated share repurchase agreements (ASR Agreements) to repurchase an aggregate of $16.0 billion of our common stock, with 178.4 million shares initially delivered to us under the ASR Agreements and retired. Pursuant to the terms of the ASR Agreements, the final number of shares and the average purchase price will be determined at the end of the applicable purchase periods, which are scheduled to occur in early September 2019 but may occur earlier in certain circumstances. In the first six months of fiscal 2019, we repurchased and retired 16.8 million shares of our common stock for $1.0 billion, before commissions. At March 31, 2019, $7.8 billion remained authorized for repurchase under the stock repurchase program.

[0001728949-19-000036:mdna:202]
[same as prior period, unchanged from 0001728949-19-000012:mdna:148]

[0001728949-19-000036:mdna:203]
In the first six months of fiscal 2019, we paid cash dividends totaling $1.5 billion, or $1.24 per share. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-19-000036:mdna:204]
[same as prior period, unchanged from 0001728949-19-000012:mdna:150]

[0001728949-19-000036:mdna:205]
| • | Our purchase obligations at March 31, 2019, some of which relate to research and development activities and capital expenditures, totaled $2.9 billion and $637 million for fiscal 2019 and 2020, respectively, and $487 million thereafter. |

[0001728949-19-000036:mdna:206]
| • | Our research and development expenditures were $2.6 billion in the first six months of fiscal 2019 and $5.6 billion in fiscal 2018, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications. |

[0001728949-19-000036:mdna:207]
| • | Cash outflows for capital expenditures were $322 million in the first six months of fiscal 2019 and $784 million in fiscal 2018. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. |

[0001728949-19-000036:mdna:208]
| • | The EC imposed a fine on us, of which $1.1 billion was accrued at March 31, 2019 (based on the exchange rate at March 31, 2019, including related foreign currency gains and accrued interest). In the third quarter of 2018, we provided financial guarantees in lieu of cash payment to satisfy the obligation while we appeal the EU’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. |

[0001728949-19-000036:mdna:209]
| • | Beginning on August 4, 2019, for a period of 60 days, we have the option to acquire (and the minority owner has the option to sell) the minority ownership interest in the RF360 Holdings joint venture for $1.15 billion, and we expect one of such options to be exercised during this period. At March 31, 2019 and September 30, 2018, the accreted value of such amount was included in other current liabilities. |

[0001728949-19-000036:mdna:210]
[same as prior period, unchanged from 0001728949-19-000012:mdna:158]

[0001728949-19-000036:mdna:211]
Further, regulatory authorities in certain jurisdictions continue to investigate our business practices and institute proceedings against us, including the lawsuit filed against us by the United States Federal Trade Commission (FTC), which trial took place in January 2019, and other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees, have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0001728949-19-000036:mdna:212]
[same as prior period, unchanged from 0001728949-19-000012:mdna:160]

[0001728949-19-000036:mdna:213]
[same as prior period, unchanged from 0001728949-19-000012:mdna:161]

[0001728949-19-000036:mdna:214]
Additional information regarding our financial commitments at March 31, 2019 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes,” “Note 5. Debt” and “Note 6. Commitments and Contingencies.”

[0001728949-19-000036:mdna:215]
[same as prior period, unchanged from 0001728949-19-000012:mdna:163]

[0001728949-19-000036:mdna:216]
[same as prior period, unchanged from 0001728949-19-000012:mdna:164]

[0001728949-19-000036:mdna:217]
We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops, which in general, effectively provide for a maximum royalty amount per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such royalties. Our estimates of sales-based royalties are based largely on an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property. We estimate sales-based royalties taking into consideration the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products, and considers all information (historical, current and forecasted) that is reasonably available to us. Our licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter, which is generally the following quarter. As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

[0001728949-19-000036:mdna:218]
From time to time, companies initiate various strategies to attempt to renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. Certain licensees have disputed, underreported, underpaid, not reported and/or not paid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and such licensees may continue to do so in the future. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in ASC 606, and to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us.

[0001728949-19-000036:mdna:219]
[same as prior period, unchanged from 0001728949-19-000012:mdna:168]

[0001728949-19-000036:mdna:220]
Information regarding recent accounting pronouncements and the impact of those pronouncements on our consolidated financial statements is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 1. Basis of Presentation and Significant Accounting Policies Update.”

[0001728949-19-000036:mdna:221]
[same as prior period, unchanged from 0001728949-19-000012:mdna:170]

[0001728949-19-000036:mdna:222]
[same as prior period, unchanged from 0001728949-19-000012:mdna:171]

[0001728949-19-000036:mdna:223]
[same as prior period, unchanged from 0001728949-19-000012:mdna:172]

[0001728949-19-000036:mdna:224]
[same as prior period, unchanged from 0001728949-19-000012:mdna:173]

[0001728949-19-000036:mdna:225]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on operators of wireless networks and our customers and licensees to adopt and implement the latest generation of these technologies for use in their networks, devices and services. We also depend on our customers and licensees to develop devices and services based on these technologies with value-added features

[0001728949-19-000036:mdna:226]
47

[0001728949-19-000036:mdna:227]
to drive consumer demand for new 3G/4G and 3G/4G/5G multi-mode devices, as well as 3G, 4G and 5G single-mode devices, and to establish the selling prices for such devices. Further, we depend on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries and applications beyond traditional cellular communications, such as automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), networking, computing and artificial intelligence (AI), such as machine learning, among others.

[0001728949-19-000036:mdna:228]
We have historically been successful during wireless technology transitions. The next generation of wireless technologies is 5G, which we expect will empower a new era of connected devices and will be utilized not only in handsets but in new device types, industries and applications beyond traditional cellular communications. Initial commercial deployments of 5G networks and devices have begun and will continue in 2019 and beyond. We believe it is important that we be a leader in 5G technology development, standardization, intellectual property creation and licensing, and that we develop, commercialize and be a leading supplier of 5G integrated circuit products and services, in order to sustain and grow our business long-term.

[0001728949-19-000036:mdna:229]
[same as prior period, unchanged from 0001728949-19-000012:mdna:176]

[0001728949-19-000036:mdna:230]
[same as prior period, unchanged from 0001728949-19-000012:mdna:177]

[0001728949-19-000036:mdna:231]
[same as prior period, unchanged from 0001728949-19-000012:mdna:178]

[0001728949-19-000036:mdna:232]
[same as prior period, unchanged from 0001728949-19-000012:mdna:179]

[0001728949-19-000036:mdna:233]
[same as prior period, unchanged from 0001728949-19-000012:mdna:180]

[0001728949-19-000036:mdna:234]
[same as prior period, unchanged from 0001728949-19-000012:mdna:181]

[0001728949-19-000036:mdna:235]
[same as prior period, unchanged from 0001728949-19-000012:mdna:182]

[0001728949-19-000036:mdna:236]
[same as prior period, unchanged from 0001728949-19-000012:mdna:183]

[0001728949-19-000036:mdna:237]
[same as prior period, unchanged from 0001728949-19-000012:mdna:184]

[0001728949-19-000036:mdna:238]
[same as prior period, unchanged from 0001728949-19-000012:mdna:185]

[0001728949-19-000036:mdna:239]
[same as prior period, unchanged from 0001728949-19-000012:mdna:186]

[0001728949-19-000036:mdna:240]
[same as prior period, unchanged from 0001728949-19-000012:mdna:187]

[0001728949-19-000036:mdna:241]
Our products, services and technologies face significant competition. We expect competition to increase as our current competitors expand their product offerings or reduce the prices of their products as part of a strategy to attract new business and customers, as new opportunities develop, and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: device manufacturer concentrations; vertical integration; growth in demand, consumption and competition in certain geographic regions; government intervention or support of national industries or competitors; evolving industry standards and business models; evolving methods of transmission of voice and data communications; increasing data traffic and densification of wireless networks; convergence and aggregation of connectivity technologies (including Wi-Fi and LTE) in both devices and access points; consolidation of wireless technologies and infrastructure at the network edge; networking and connectivity trends (including cloud services); use of licensed, shared and unlicensed spectrum; the evolving nature of computing (including demand for always on, always connected capabilities); the speed of technological change (including the transition to smaller geometry process technologies); value-added features that drive selling prices and consumer demand for new 3G/4G and 3G/4G/5G multi-mode devices, as well as 3G, 4G and 5G single-mode devices; turnkey, integrated products that incorporate hardware, software, user interface, applications and reference designs; scalability; and the ability of the system technology to meet customers’ immediate and future network requirements. We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, technological and public policy changes and relatively low barriers to entry in certain segments of the industry.

[0001728949-19-000036:mdna:242]
[same as prior period, unchanged from 0001728949-19-000012:mdna:198]

[0001728949-19-000036:mdna:243]
Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape.

[0001728949-19-000036:mdna:244]
[same as prior period, unchanged from 0001728949-19-000012:mdna:189]

[0001728949-19-000036:mdna:245]
[same as prior period, unchanged from 0001728949-19-000012:mdna:190]

[0001728949-19-000036:mdna:246]
[same as prior period, unchanged from 0001728949-19-000012:mdna:191]

[0001728949-19-000036:mdna:247]
[same as prior period, unchanged from 0001728949-19-000012:mdna:192]

[0001728949-19-000036:mdna:248]
[same as prior period, unchanged from 0001728949-19-000012:mdna:193]

[0001728949-19-000036:mdna:249]
[same as prior period, unchanged from 0001728949-19-000012:mdna:194]

[0001728949-19-000036:mdna:250]
| • | be a leader in 5G technology development, standardization, intellectual property creation and licensing, and develop, commercialize and be a leading supplier of 5G integrated circuit products and services; |

[0001728949-19-000036:mdna:251]
[same as prior period, unchanged from 0001728949-19-000012:mdna:197]

[0001728949-19-000036:mdna:252]
[same as prior period, unchanged from 0001728949-19-000012:mdna:201]

[0001728949-19-000036:mdna:253]
[same as prior period, unchanged from 0001728949-19-000012:mdna:200]

[0001728949-19-000036:mdna:254]
[same as prior period, unchanged from 0001728949-19-000012:mdna:195]

[0001728949-19-000036:mdna:255]
[same as prior period, unchanged from 0001728949-19-000012:mdna:196]

[0001728949-19-000036:mdna:256]
| • | identify potential acquisition targets that will grow or sustain our business or address strategic needs, reach agreement on terms acceptable to us, close the transactions and effectively integrate these new businesses, products and technologies; and |

[0001728949-19-000036:mdna:257]
[same as prior period, unchanged from 0001728949-19-000012:mdna:203]

[0001728949-19-000036:mdna:258]
[same as prior period, unchanged from 0001728949-19-000012:mdna:204]

[0001728949-19-000036:mdna:259]
We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application market segment or standard product, including those that produce products for automotive, IoT and networking applications. Most of these competitors compete with us with respect to some, but not

[0001728949-19-000036:mdna:260]
all, of our businesses. Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM) as well as companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Actions (Zhuhai) Technology Co., LTD, Advanced Micro Devices, Inc., Altair Engineering, Inc., Ambarella, Inc., AMLogic Co., Inc., Broadcom Inc., Cypress Semiconductor Corporation, Fuzhou Rockchip Electronics Co., LTD., HiSilicon Technologies, Intel, Marvell Technology, MediaTek, Murata Manufacturing Co., Ltd., Nvidia, NXP Semiconductors N.V., Qorvo Inc., Renesas Electronics Corporation, Samsung Electronics, Skyworks Solutions Inc., Spreadtrum Communications (which is controlled by Tsinghua Unigroup), STMicroelectronics International N.V., Texas Instruments Incorporated and Quantenna Communications, Inc. Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to use our competitors’ integrated circuit products, to utilize their own internally-developed integrated circuit products or sell such products to others, including by bundling with other products, or to choose alternative technologies; lower cost structures or a willingness and ability to accept lower prices and lower or negative margins for their products, particularly in China; foreign government support of other technologies or competitors or original equipment manufacturers (OEMs) that sell devices that do not contain our chipsets; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and OEMs in certain geographic regions (such as China); more experience in adjacent industry segments outside traditional cellular industries (such as automotive, IoT and computing); and a more established presence in certain regions.

[0001728949-19-000036:mdna:261]
[same as prior period, unchanged from 0001728949-19-000012:mdna:206]

[0001728949-19-000036:mdna:262]
[same as prior period, unchanged from 0001728949-19-000012:mdna:207]

[0001728949-19-000036:mdna:263]
In addition, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past chosen to utilize in certain of their devices and may in the future choose to utilize in certain (or all) of their devices, rather than our products (and may sell their integrated circuit products to third parties in competition with us). Also, Apple, which has historically been one of our largest customers, now utilizes products of one of our competitors in many of their devices rather than our products, is solely utilizing one or more of our competitor’s products in its most recent smartphone launch and may continue to use our competitors’ products, and may develop and utilize their own modem products, rather than our products in their future devices.

[0001728949-19-000036:mdna:264]
[same as prior period, unchanged from 0001728949-19-000012:mdna:209]

[0001728949-19-000036:mdna:265]
Further, to the extent Apple purchases our modem products, it purchases our Mobile Data Modem (MDM) products, which do not include our integrated application processor technology, and which have lower revenue and margin contributions than our combined modem and application processor products. To the extent Apple takes device share from our customers who purchase our integrated modem and application processor products, our revenues and margins may be negatively impacted.

[0001728949-19-000036:mdna:266]
Further, companies that develop HLOS for devices, including leading technology companies, now sell their own devices. If we fail to effectively partner or continue partnering with these companies, or with their partners or customers, they may

[0001728949-19-000036:mdna:267]
decide not to purchase (either directly or through their contract manufacturers), or to reduce or discontinue their purchases of, our integrated circuit products.

[0001728949-19-000036:mdna:268]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products or intellectual property, and rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001728949-19-000036:mdna:269]
[same as prior period, unchanged from 0001728949-19-000012:mdna:213]

[0001728949-19-000036:mdna:270]
[same as prior period, unchanged from 0001728949-19-000012:mdna:214]

[0001728949-19-000036:mdna:271]
[same as prior period, unchanged from 0001728949-19-000012:mdna:215]

[0001728949-19-000036:mdna:272]
[same as prior period, unchanged from 0001728949-19-000012:mdna:216]

[0001728949-19-000036:mdna:273]
[same as prior period, unchanged from 0001728949-19-000012:mdna:217]

[0001728949-19-000036:mdna:274]
[same as prior period, unchanged from 0001728949-19-000012:mdna:218]

[0001728949-19-000036:mdna:275]
From time to time, companies initiate various strategies to attempt to renegotiate, reduce or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, of seeking to impose some form of compulsory licensing or of weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies to attempt to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated.

[0001728949-19-000036:mdna:276]
[same as prior period, unchanged from 0001728949-19-000012:mdna:222]

[0001728949-19-000036:mdna:277]
[same as prior period, unchanged from 0001728949-19-000012:mdna:220]

[0001728949-19-000036:mdna:278]
We are currently subject to various litigation and governmental investigations and proceedings, including the lawsuit filed against us by the United States Federal Trade Commission (FTC), which trial took place in January 2019, some of which have arisen and may continue to arise out of the strategies described above. Certain legal matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. If some or all of our license agreements are declared invalid or unenforceable and we are required to renegotiate these license agreements, or if as part of a settlement we agree to renegotiate certain of our license agreements, we may not receive, or may not be able to recognize, any licensing or royalty revenues on the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any licensing or royalty revenues on such agreements. The renegotiation of new license agreements could lead to arbitration or litigation to resolve the licensing terms (which could be less favorable to us than existing terms), each of which could take several months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition to these issues concerning future licensing and royalty revenues, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. Such events could result in a materially negative impact on our financial condition, in which case we would have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies such as 5G. Further, depending on the breadth and severity of the circumstances above, we may have to reduce or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted. If these events occur, our financial outlook and stock price would decline, possibly significantly. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. These activities have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs until the respective matters are resolved.

[0001728949-19-000036:mdna:279]
[same as prior period, unchanged from 0001728949-19-000012:mdna:224]

[0001728949-19-000036:mdna:280]
Further, some companies or entities have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for patent

[0001728949-19-000036:mdna:281]
52

[0001728949-19-000036:mdna:282]
infringement (e.g., by severely limiting the base upon which the royalty percentage may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies. Some SDOs, courts and governmental agencies have adopted and may in the future adopt some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001728949-19-000036:mdna:283]
[same as prior period, unchanged from 0001728949-19-000012:mdna:227]

[0001728949-19-000036:mdna:284]
[same as prior period, unchanged from 0001728949-19-000012:mdna:228]

[0001728949-19-000036:mdna:285]
We are currently subject to various governmental investigations and proceedings, particularly with respect to our licensing business, including the lawsuit filed against us by the United States Federal Trade Commission (FTC), which trial took place in January 2019, and certain such matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations in those matters include, among others, that we do not license our cellular standard-essential patents separately from our other patents, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high, that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions), that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets, that we have entered into exclusive agreements with chipset customers that foreclose competition, and that we violate antitrust laws, engage in anticompetitive conduct and unfair methods of competition. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. If some or all of our license agreements are declared invalid or unenforceable and we are required to renegotiate these license agreements, or if as part of a settlement we agree to renegotiate certain of our license agreements, we may not receive, or may not be able to recognize, any licensing or royalty revenues on the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any licensing or royalty revenues on such agreements. The renegotiation of new license agreements could lead to arbitration or litigation to resolve the licensing terms (which could be less favorable to us than existing terms), each of which could take several months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition to these issues concerning future licensing and royalty revenues, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. Such events could result in a materially negative impact on our financial condition, in which case we would have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies such as 5G. Further, depending on the breadth and severity of the circumstances above, we may have to reduce or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted. If these events occur, our financial outlook and stock price would decline, possibly significantly. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. These activities have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs until the respective matters are resolved.

[0001728949-19-000036:mdna:286]
Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.

[0001728949-19-000036:mdna:287]
We are currently subject to various governmental investigations and proceedings and private legal proceedings challenging our patent licensing and chipset sales practices, including the lawsuit filed against us by the United States Federal Trade Commission (FTC),which trial took place in January 2019, as described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations in those matters include, among others, that we do not license our cellular standard-essential patents separately from our other patents, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high, that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions), that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets, that we have entered into exclusive agreements with chipset customers that foreclose competition, and that we violate antitrust laws, engage in anticompetitive conduct and unfair methods of competition. We believe that one intent of these investigations and legal proceedings is to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0001728949-19-000036:mdna:288]
[same as prior period, unchanged from 0001728949-19-000012:mdna:233]

[0001728949-19-000036:mdna:289]
[same as prior period, unchanged from 0001728949-19-000012:mdna:234]

[0001728949-19-000036:mdna:290]
[same as prior period, unchanged from 0001728949-19-000012:mdna:236]

[0001728949-19-000036:mdna:291]
[same as prior period, unchanged from 0001728949-19-000012:mdna:237]

[0001728949-19-000036:mdna:292]
[same as prior period, unchanged from 0001728949-19-000012:mdna:238]

[0001728949-19-000036:mdna:293]
[same as prior period, unchanged from 0001728949-19-000012:mdna:239]

[0001728949-19-000036:mdna:294]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our proprietary information, technologies and processes, including our patent portfolio. Policing unauthorized use of our products, technologies and proprietary information is difficult and time consuming. The steps we have taken have not always prevented, and we cannot be certain the steps we will take in the future will prevent, the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as U.S. laws or where the enforcement of such laws may be lacking or ineffective. Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that the European Union will adopt a unitary patent system in the next few years that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-19-000036:mdna:295]
We have had, and may in the future have, difficulty in certain circumstances in protecting or enforcing our intellectual property rights and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies of foreign governments; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business and the pricing and integration of additional features and functionality into our chipset products. Certain licensees have disputed, underreported, underpaid, not reported and not paid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or have delayed entering into or renewing license agreements for their use of our intellectual property, and such licensees and companies may continue to do so in the future. The fact that one or more licensees dispute, underreport, underpay, do not report and do not pay royalties owed to us may encourage other licensees to take similar actions and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements. Similarly, we provide access to certain of our intellectual property and proprietary and confidential business information to our direct and indirect customers and licensees, who may wrongfully use such intellectual property and information or wrongfully disclose such intellectual property and information to third parties, including our competitors.

[0001728949-19-000036:mdna:296]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. We are currently engaged in litigation matters related to protecting or enforcing our contract and intellectual property rights, and certain such matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation) and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0001728949-19-000036:mdna:297]
Our growth increasingly depends on our ability to extend our technologies, products and services into new and expanded product areas, such as RFFE, and adjacent industry segments and applications outside of traditional cellular industries, such as automotive, IoT and networking, among others. Our research, development and other investments in these new and expanded product areas, industry segments and applications, and related technologies, products and services, as well

[0001728949-19-000036:mdna:298]
[same as prior period, unchanged from 0001728949-19-000012:mdna:248]

[0001728949-19-000036:mdna:299]
as in our existing technologies, products and services and new technologies, such as 5G, may not generate operating income or contribute to future results of operations that meet our expectations.

[0001728949-19-000036:mdna:300]
[same as prior period, unchanged from 0001728949-19-000012:mdna:245]

[0001728949-19-000036:mdna:301]
In particular, our future growth significantly depends on new and expanded product areas, such as RFFE, and adjacent industry segments and applications outside of traditional cellular industries, such as automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), networking, computing and AI, such as machine learning, among others; our ability to develop leading and cost-effective technologies, products and services for new and expanded product areas, adjacent industry segments and applications; and third parties incorporating our technology, products and services into devices used in these product areas, industry segments and applications. Accordingly, we intend to continue to make substantial investments in these new and expanded product areas and adjacent industry segments and applications, and in developing new products, services and technologies for these product areas, industry segments and applications.

[0001728949-19-000036:mdna:302]
Our growth also depends significantly on our ability to develop 5G technologies, and to develop and commercialize products using 5G technologies.

[0001728949-19-000036:mdna:303]
However, our research, development and other investments in these new and expanded product areas and adjacent industry segments and applications, and corresponding technologies, products and services, as well as in our existing, technologies, products and services and new technologies, such as 5G, use of licensed, shared and unlicensed spectrum and convergence of cellular and Wi-Fi, may not succeed due to, among other reasons: new industry segments, applications and consumer demand may not develop or grow as anticipated; our strategies or the strategies of our customers, licensees or partners may not be successful; improvements in alternate technologies in ways that reduce the advantages we anticipate from our investments; competitors’ technologies, products or services being more cost effective, having more capabilities or fewer limitations or being brought to market faster than our new technologies, products and services; and competitors having longer operating histories in industry segments that are new to us. We may also underestimate the costs of or overestimate the future revenues or margins that could result from these investments, and these investments may not, or may take many years to, generate material returns. Further, the automotive industry is subject to long design-in time frames, long product life cycles and a high degree of regulatory and safety requirements, necessitating suppliers to the industry to comply with stringent qualification processes, very low defect rates and high reliability standards, all of which results in a significant barrier to entry and increased costs.

[0001728949-19-000036:mdna:304]
[same as prior period, unchanged from 0001728949-19-000012:mdna:250]

[0001728949-19-000036:mdna:305]
[same as prior period, unchanged from 0001728949-19-000012:mdna:251]

[0001728949-19-000036:mdna:306]
[same as prior period, unchanged from 0001728949-19-000012:mdna:252]

[0001728949-19-000036:mdna:307]
We are subject to many environmental, health and safety laws and regulations in each jurisdiction in which we operate our manufacturing facilities, which govern, among other things, emissions of pollutants into the air, wastewater discharges, the use and handling of hazardous substances, waste disposal, the investigation and remediation of soil and ground water contamination and the health and safety of our employees. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. We cannot make assurances that we will be at all times in compliance with such laws, regulations and permits. Certain environmental laws impose strict, and in certain circumstances, joint and several, liability on current or previous owners or operators of real property for the cost of investigation, removal or remediation of hazardous substances. Certain of these laws also assess liability on persons who arrange for hazardous substances to be sent to disposal or treatment facilities when such facilities are found to be contaminated. In addition, we

[0001728949-19-000036:mdna:308]
[same as prior period, unchanged from 0001728949-19-000012:mdna:258]

[0001728949-19-000036:mdna:309]
could also be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage.

[0001728949-19-000036:mdna:310]
We have manufacturing facilities in Asia and Europe. If tsunamis, flooding, earthquakes, volcanic eruptions or other natural disasters, or geopolitical conflicts, were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, delay new production and shipments of inventory and result in costly repairs, replacements or other costs. In addition, natural disasters or geopolitical conflicts may result in disruptions in transportation, distribution channels and supply chains, and significant increases in the prices of raw materials.

[0001728949-19-000036:mdna:311]
[same as prior period, unchanged from 0001728949-19-000012:mdna:255]

[0001728949-19-000036:mdna:312]
[same as prior period, unchanged from 0001728949-19-000012:mdna:256]

[0001728949-19-000036:mdna:313]
[same as prior period, unchanged from 0001728949-19-000012:mdna:257]

[0001728949-19-000036:mdna:314]
[same as prior period, unchanged from 0001728949-19-000012:mdna:259]

[0001728949-19-000036:mdna:315]
[same as prior period, unchanged from 0001728949-19-000012:mdna:260]

[0001728949-19-000036:mdna:316]
Further, the licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, many of our license agreements (including essentially all of our agreements in China and our recent worldwide standard-essential patent only agreements) are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of the specified term, and to receive royalties after the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. Accordingly, to the extent not renewed on their terms or by election for an additional (generally multi-year) period, if applicable, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. We might not be able to extend or modify those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001728949-19-000036:mdna:317]
[same as prior period, unchanged from 0001728949-19-000012:mdna:271]

[0001728949-19-000036:mdna:318]
[same as prior period, unchanged from 0001728949-19-000012:mdna:262]

[0001728949-19-000036:mdna:319]
[same as prior period, unchanged from 0001728949-19-000012:mdna:263]

[0001728949-19-000036:mdna:320]
[same as prior period, unchanged from 0001728949-19-000012:mdna:264]

[0001728949-19-000036:mdna:321]
[same as prior period, unchanged from 0001728949-19-000012:mdna:265]

[0001728949-19-000036:mdna:322]
[same as prior period, unchanged from 0001728949-19-000012:mdna:266]

[0001728949-19-000036:mdna:323]
[same as prior period, unchanged from 0001728949-19-000012:mdna:267]

[0001728949-19-000036:mdna:324]
[same as prior period, unchanged from 0001728949-19-000012:mdna:268]

[0001728949-19-000036:mdna:325]
[same as prior period, unchanged from 0001728949-19-000012:mdna:269]

[0001728949-19-000036:mdna:326]
[same as prior period, unchanged from 0001728949-19-000012:mdna:270]

[0001728949-19-000036:mdna:327]
Additionally, supply of and costs of raw materials may be negatively impacted by trade protection policies such as tariffs, or escalating trade tensions, particularly with countries in Asia. While we have established alternate suppliers for certain technologies, we rely on sole- or limited-source suppliers for certain products, subjecting us to significant risks, including: possible shortages of raw materials or manufacturing capacity; poor product performance; and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established alternate suppliers, these suppliers may require significant levels of support to bring complex technologies to production. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, any future consolidation of foundry suppliers could increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions and could increase our manufacturing costs. Our arrangements with our suppliers may obligate us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies, and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Any of the above could negatively impact our business, our results of operations and cash flows.

[0001728949-19-000036:mdna:328]
[same as prior period, unchanged from 0001728949-19-000012:mdna:273]

[0001728949-19-000036:mdna:329]
[same as prior period, unchanged from 0001728949-19-000012:mdna:274]

[0001728949-19-000036:mdna:330]
[same as prior period, unchanged from 0001728949-19-000012:mdna:279]

[0001728949-19-000036:mdna:331]
In addition, we may not receive reasonable pricing, manufacturing or delivery terms from our suppliers. We cannot guarantee that the actions of our suppliers will not cause disruptions in our operations that could harm our ability to meet our delivery obligations to our customers or increase our cost of sales. To the extent we are unable to obtain adequate supply, we may be obligated to make payment to our customers for such shortfalls.

[0001728949-19-000036:mdna:332]
[same as prior period, unchanged from 0001728949-19-000012:mdna:276]

[0001728949-19-000036:mdna:333]
[same as prior period, unchanged from 0001728949-19-000012:mdna:277]

[0001728949-19-000036:mdna:334]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products or services sold or provided by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales or reductions in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-19-000036:mdna:335]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset or licensing revenues.

[0001728949-19-000036:mdna:336]
Certain legal matters, which may include certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-19-000036:mdna:337]
[same as prior period, unchanged from 0001728949-19-000012:mdna:283]

[0001728949-19-000036:mdna:338]
We engage in strategic acquisitions and other transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. We acquire businesses and other assets, including patents, technology, wireless spectrum and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies that may be private and early-

[0001728949-19-000036:mdna:339]
59

[0001728949-19-000036:mdna:340]
stage. Our strategic activities are generally focused on opening or expanding opportunities for our products and technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications and new industry segments. Recent material transactions include our RF360 Holdings joint venture with TDK Corporation. Many of our strategic activities entail a high degree of risk and require the use of significant amounts of capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies, products or services. We may underestimate the costs or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our financial condition and results of operations, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001728949-19-000036:mdna:341]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, technology, products, processes, operations (including manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development and supply operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models (including manufacturing), geographic regions, industry segments or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of the combination.

[0001728949-19-000036:mdna:342]
[same as prior period, unchanged from 0001728949-19-000012:mdna:286]

[0001728949-19-000036:mdna:343]
In fiscal 2018, we terminated our proposed acquisition of NXP because the acquisition had not been approved by the State Administration for Market Regulation (SAMR) in China by the date specified in the acquisition agreement. As a result, we will not realize the anticipated benefits of that acquisition. In addition, future acquisitions may now be more difficult, complex or expensive to the extent that our reputation for our ability to consummate acquisitions has been harmed. Further, if U.S./China trade relations remain strained, our ability to consummate any transaction that would require approval from SAMR may be severely impacted.

[0001728949-19-000036:mdna:344]
[same as prior period, unchanged from 0001728949-19-000012:mdna:291]

[0001728949-19-000036:mdna:345]
[same as prior period, unchanged from 0001728949-19-000012:mdna:292]

[0001728949-19-000036:mdna:346]
Government policies, particularly in China, that regulate the amount and timing of funds that may flow out of a country have impacted and may continue to impact the timing of our receipt of payments from our customers and licensees in such country, which may negatively impact our cash flows.

[0001728949-19-000036:mdna:347]
60

[0001728949-19-000036:mdna:348]
[same as prior period, unchanged from 0001728949-19-000012:mdna:294]

[0001728949-19-000036:mdna:349]
National, state and local environmental laws and regulations affect our operations around the world. These laws may make it more expensive to manufacture, have manufactured and sell products, and our costs could increase if our vendors (e.g., suppliers, third-party manufacturers or utility companies) pass on their costs to us. The imposition of tariffs on raw materials or our products could have a negative impact on our revenues and results of operations. We are also subject to laws and regulations impacting the manufacturing operations of our RF360 Holdings joint venture. See the Risk Factor entitled “There are numerous risks associated with our operation and control of the manufacturing facilities of our joint venture with TDK, RF360 Holdings, including a higher portion of fixed costs relative to a fabless model, environmental compliance and liability, exposure to natural disasters, timely supply of equipment and materials and manufacturing difficulties.”

[0001728949-19-000036:mdna:350]
Regulations in the United States require that we determine whether certain materials used in our products, referred to as conflict minerals, originated in the Democratic Republic of the Congo or an adjoining country (collectively, the Covered Countries), or were from recycled or scrap sources. Other countries and regions are imposing similar regulations, which may require us to undertake additional verification and reporting, including regarding countries in addition to the Covered Countries and minerals in addition to conflict minerals. The verification and reporting requirements, in addition to customer demands for conflict free sourcing, impose additional costs on us and on our suppliers and may limit the sources or increase the prices of materials used in our products. Further, if we are unable to determine that the conflict minerals used in our products do not directly or indirectly finance or benefit armed groups in the Covered Countries, we may face challenges with our customers that place us at a competitive disadvantage, and our reputation may be harmed. Similarly, other laws and regulations have been adopted or proposed that require additional transparency regarding the employment practices of our suppliers, and any failure to maintain responsible sourcing practices could also adversely affect our relationships with customers and our reputation.

[0001728949-19-000036:mdna:351]
[same as prior period, unchanged from 0001728949-19-000012:mdna:298]

[0001728949-19-000036:mdna:352]
[same as prior period, unchanged from 0001728949-19-000012:mdna:299]

[0001728949-19-000036:mdna:353]
[same as prior period, unchanged from 0001728949-19-000012:mdna:300]

[0001728949-19-000036:mdna:354]
[same as prior period, unchanged from 0001728949-19-000012:mdna:301]

[0001728949-19-000036:mdna:355]
Our stock price and earnings have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and earnings include those identified throughout this Risk Factors section; volatility of the stock market in general and technology-based companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. Further, increased volatility in the financial markets and overall economic conditions may reduce the amounts that we realize in the future on our cash equivalents and marketable securities and may reduce our earnings as a result of any reductions in the fair values of marketable securities.

[0001728949-19-000036:mdna:356]
In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities. Due to changes in our stock price, we are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-19-000036:mdna:357]
[same as prior period, unchanged from 0001728949-19-000012:mdna:306]

[0001728949-19-000036:mdna:358]
[same as prior period, unchanged from 0001728949-19-000012:mdna:307]

[0001728949-19-000036:mdna:359]
[same as prior period, unchanged from 0001728949-19-000012:mdna:308]

[0001728949-19-000036:mdna:360]
[same as prior period, unchanged from 0001728949-19-000012:mdna:309]

[0001728949-19-000036:mdna:361]
[same as prior period, unchanged from 0001728949-19-000012:mdna:310]

[0001728949-19-000036:mdna:362]
[same as prior period, unchanged from 0001728949-19-000012:mdna:311]

[0001728949-19-000036:mdna:363]
[same as prior period, unchanged from 0001728949-19-000012:mdna:312]

[0001728949-19-000036:mdna:364]
Our variable rate indebtedness may use LIBOR as a benchmark for establishing the interest rate. LIBOR is the subject of recent national, international and other regulatory guidance and proposals for reform. These reforms and other pressures may cause LIBOR to disappear entirely or to perform differently than in the past. The consequences of these developments cannot be entirely predicted but could include an increase in the cost of our variable rate indebtedness.

[0001728949-19-000036:mdna:365]
[same as prior period, unchanged from 0001728949-19-000012:mdna:313]

[0001728949-19-000036:mdna:366]
[same as prior period, unchanged from 0001728949-19-000012:mdna:314]

[0001728949-19-000036:mdna:367]
[same as prior period, unchanged from 0001728949-19-000012:mdna:315]

[0001728949-19-000036:mdna:368]
[same as prior period, unchanged from 0001728949-19-000012:mdna:316]

[0001728949-19-000036:mdna:369]
In addition, employees and former employees, in particular former employees who become employees of our competitors, customers or licensees, may misappropriate, use, publish or provide to our competitors, customers or licensees our intellectual property or proprietary or confidential business information. This risk is exacerbated as competitors for talent, particularly engineering talent, increasingly attempt to hire our employees. See the Risk Factor entitled “We may not be able to attract and retain qualified employees.” Similarly, we provide access to certain of our intellectual property or proprietary or confidential business information to our direct and indirect customers and licensees, who may wrongfully use such intellectual property or information or wrongfully disclose such intellectual property or information to third parties, including our competitors.

[0001728949-19-000036:mdna:370]
[same as prior period, unchanged from 0001728949-19-000012:mdna:318]

[0001728949-19-000036:mdna:371]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-U.S. headquarters is located. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed. Our current examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-19-000036:mdna:372]
The United States Treasury Department has issued proposed regulations on several provisions of the Tax Legislation, including foreign tax credits, FDII, GILTI, BEAT and interest expense deduction limitations, which are expected to be finalized in the next several months. When finalized, these proposed regulations may adversely affect our provision for income taxes, results of operations and/or cash flows.

[0001728949-19-000036:mdna:373]
[same as prior period, unchanged from 0001728949-19-000012:mdna:321]

[0001728949-19-000036:mdna:374]
Tax rules may change in a manner that adversely affects our future reported results of operations or the way we conduct our business. Further changes in the tax laws of foreign jurisdictions could arise as a result of the base erosion and profit shifting (BEPS) project that was undertaken by the Organization for Economic Co-operation and Development (OECD). The OECD, which represents a coalition of member countries, recommended changes to numerous long-standing tax principles related to transfer pricing. These changes, as adopted by countries, may increase tax uncertainty and may adversely affect our provision for income taxes, results of operations and cash flows. Partially to address BEPS, we moved certain IP from Singapore to the United States. As a result, if tax rates were to increase in the United States, our results of operations, cash flows and financial condition could be adversely affected.

[0001728949-19-000036:mdna:375]
[same as prior period, unchanged from 0001728949-19-000012:mdna:324]

[0001728949-19-000036:mdna:376]
A decline in global, regional or local economic conditions or a slow-down in economic growth, or political actions including trade protection policies such as tariffs, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could have adverse, wide-ranging effects on demand for our products and services and for the products and services of our customers or licensees, particularly equipment manufacturers or others in the wireless communications industry who buy their products, such as wireless operators. Any

[0001728949-19-000036:mdna:377]
prolonged economic downturn or “trade war” may result in a decrease in demand for our products and technologies; a decrease in demand for the products of our customers or licensees; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our licensees or customers; failures by counterparties; and negative effects on wireless device inventories. In addition, our customers’ ability to purchase or pay for our products and services and network operators’ ability to upgrade their wireless networks could be adversely affected by economic conditions, leading to a reduction, cancelation or delay of orders for our products and services.

[0001728949-19-000036:mdna:378]
[same as prior period, unchanged from 0001728949-19-000012:mdna:326]

[0001728949-19-000036:mdna:379]
Our future success depends largely upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them, which may become increasingly difficult in an environment of cost reductions. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. The market for employees in our industry is extremely competitive, and competitors for talent, particularly engineering talent, increasingly attempt to hire, and to varying degrees have been successful in hiring, our employees, including by establishing local offices in San Diego. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001728949-19-000036:mdna:380]
[same as prior period, unchanged from 0001728949-19-000012:mdna:328]

[0001728949-19-000036:mdna:381]
[same as prior period, unchanged from 0001728949-19-000012:mdna:329]

[0001728949-19-000036:mdna:382]
[same as prior period, unchanged from 0001728949-19-000012:mdna:330]

[0001728949-19-000036:mdna:383]
[same as prior period, unchanged from 0001728949-19-000012:mdna:331]

[0001728949-19-000036:mdna:384]
[same as prior period, unchanged from 0001728949-19-000012:mdna:332]

[0001728949-19-000036:mdna:385]
[same as prior period, unchanged from 0001728949-19-000012:mdna:333]

[0001728949-19-000036:mdna:386]
[same as prior period, unchanged from 0001728949-19-000012:mdna:334]

[0001728949-19-000036:mdna:387]
[same as prior period, unchanged from 0001728949-19-000012:mdna:335]

[0001728949-19-000036:mdna:388]
[same as prior period, unchanged from 0001728949-19-000012:mdna:336]

[0001728949-19-000036:mdna:389]
The use of devices containing our products to interact with untrusted systems or otherwise access untrusted content creates a risk of exposing the system hardware and software in those devices to malicious attacks. While we continue to focus on this issue and are taking measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and applications, and increasing the risk of security failures. Further, our products are inherently complex and may contain defects or errors that are detected only when the products are in use. Because our products and services are responsible for critical functions in our customers’ products and networks, security failures, defects or errors in our products or services could have an adverse impact on us, on our customers and the end users of our customers’ products. Such adverse impact could include shipment delays; product liability claims or recalls; write-offs of our inventories, property, plant and equipment and intangible assets; unfavorable purchase commitments; a shift of business to our competitors; a decrease in demand for connected devices and wireless services; damage to our reputation and our customer relationships; regulatory actions; and other financial liability or harm to our business. Further, security failures, defects or errors in the products of our customers or licensees could have an adverse impact on our results of operations and cash flows due to a delay or decrease in demand for our products or services generally, and our premium-tier products in particular, among other factors. Development of products and features in new domains of technology and the migration to integrated circuit technologies with smaller geometric feature sizes are complex, add risk to manufacturing yields and

[0001728949-19-000036:mdna:390]
64

[0001728949-19-000036:mdna:391]
reliability and increase the likelihood of product defects or errors. Further, failures, defects or errors in our products or those of our customers or licensees entail the risk of product liability claims.
