# QCOM 8-K — 0001728949-19-000034 filed 2019-05-01

## item codes, every 8-K on or before 2019-05-01

- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2019-05-01

- none on or before 2019-05-01

## item 2.02 — earnings release, exhibit 99.1

[0001728949-19-000034:8k_2_02:1]
EX-99.1
2
qcom033119erex991.htm
EXHIBIT 99.1

[0001728949-19-000034:8k_2_02:2]
Exhibit

[0001728949-19-000034:8k_2_02:3]
Exhibit 99.1

[0001728949-19-000034:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001728949-19-000034:8k_2_02:5]
Qualcomm Contact:

[0001728949-19-000034:8k_2_02:6]
Mauricio Lopez-Hodoyan

[0001728949-19-000034:8k_2_02:7]
Vice President, Investor Relations

[0001728949-19-000034:8k_2_02:8]
Phone: 1-858-658-4813

[0001728949-19-000034:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001728949-19-000034:8k_2_02:10]
Qualcomm Announces Second Quarter Fiscal 2019 Results

[0001728949-19-000034:8k_2_02:11]
GAAP Revenues $5.0 billion

[0001728949-19-000034:8k_2_02:12]
GAAP EPS $0.55, Non-GAAP EPS $0.77

[0001728949-19-000034:8k_2_02:13]
SAN DIEGO - May 1, 2019 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal second quarter ended March 31, 2019.

[0001728949-19-000034:8k_2_02:14]
“We delivered a better than expected quarter with earnings per share above the high end of our estimates, reflecting stronger QTL results and solid execution in QCT,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “We are also pleased to have reached multi-year agreements with Apple and look forward to continuing to support them as a customer.  We are executing well on our strategic priorities as 5G commercial launches begin around the world.  Our 5G technology and product leadership, as well as our expansion into new industries and product categories, creates a strong foundation for long-term revenue and earnings growth.”

[0001728949-19-000034:8k_2_02:15]
Second Quarter Results (GAAP)*

[0001728949-19-000034:8k_2_02:16]
|  | Q2 Fiscal 2019 |  | Q2 Fiscal 2018 3 |  | Year-Over-Year Change 1 |  | Q1 Fiscal 2019 |  | Sequential Change 1 |
| Revenues | $5.0B |  | $5.2B |  | (5%) |  | $4.8B |  | +3% |
| Operating income | $0.9B |  | $0.4B |  | +135% |  | $0.7B |  | +32% |
| Net income | $0.7B |  | $0.3B |  | +101% |  | $1.1B |  | (38%) |
| Diluted earnings per share | $0.55 |  | $0.22 |  | +150% |  | $0.87 |  | (37%) |
| Operating cash flow 2 | $0.8B |  | $0.5B |  | +54% |  | $0.4B |  | +123% |

[0001728949-19-000034:8k_2_02:17]
1 Throughout this news release, percentage changes are calculated based on the dollar amounts as disclosed in millions.

[0001728949-19-000034:8k_2_02:18]
2 In the first quarter of fiscal 2019, we adopted new accounting guidance that changed the classification and presentation of certain cash receipts and cash payments and that requires companies to include changes in restricted cash and cash equivalents in the statement of cash flows.  As a result, prior period cash flow amounts presented herein have been adjusted to conform to the current year presentation.

[0001728949-19-000034:8k_2_02:19]
3 As previously disclosed, we identified an immaterial error related to the recognition of certain royalty revenues of our QTL (Qualcomm Technology Licensing) segment in the quarterly and annual periods in fiscal 2018 and third and fourth quarters and annual period in fiscal 2017.  We have corrected this error in our GAAP and Non-GAAP results for all impacted prior periods presented herein.  See “Notes to Condensed Consolidated Financial Statements, Note 1. Basis of Presentation and Significant Accounting Policies Update” and “Note 11. Revision of Prior Period Financial Statements” included in our Quarterly Report on Form 10-Q for the fiscal quarter ended March 31, 2019 filed with the SEC.

[0001728949-19-000034:8k_2_02:20]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 2 of 15 |

[0001728949-19-000034:8k_2_02:21]
Second Quarter Results (Non-GAAP)*

[0001728949-19-000034:8k_2_02:22]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding the Company’s use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001728949-19-000034:8k_2_02:23]
|  | Q2 Fiscal 2019 |  | Q2 Fiscal 2018 |  | Year-Over-Year Change |  | Q1 Fiscal 2019 |  | Sequential Change |
| Revenues | $4.9B |  | $5.2B |  | (6%) |  | $4.8B |  | +1% |
| Operating income | $1.2B |  | $1.2B |  | (6%) |  | $1.2B |  | (2%) |
| Net income | $0.9B |  | $1.2B |  | (19%) |  | $1.5B |  | (36%) |
| Diluted earnings per share | $0.77 |  | $0.78 |  | (1%) |  | $1.20 |  | (36%) |

[0001728949-19-000034:8k_2_02:24]
* Beginning in the third quarter of fiscal 2017, GAAP and Non-GAAP results have been negatively impacted by our prior disputes with Apple and its contract manufacturers.  QTL revenues in the first and second quarters of fiscal 2019 and fiscal 2018 did not include royalties due on sales of Apple or other products by Apple’s contract manufacturers.  On April 16, 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties.  QTL revenues in the first and second quarters of fiscal 2019 each included $150 million of royalties due under an interim agreement with Huawei as minimum, non-refundable payments for royalties due for sales of licensed products by Huawei during the relevant quarter while negotiations continue.  We did not record any revenues in the first or second quarter of fiscal 2018 for royalties due on the sales of Huawei’s products.  If we do not reach a final agreement with Huawei prior to the conclusion of the interim agreement, Huawei may not make any other payments or may not make full payments under the existing license agreement.

[0001728949-19-000034:8k_2_02:25]
The following should be considered in regard to the sequential and year-over-year comparisons:

[0001728949-19-000034:8k_2_02:26]
| • | The second quarter of fiscal 2019 GAAP and Non-GAAP results included: |

[0001728949-19-000034:8k_2_02:27]
| ◦ | $150 million of revenues, or $0.10 per share for GAAP and $0.11 per share for Non-GAAP, resulting from an interim agreement with Huawei while negotiations continue. |

[0001728949-19-000034:8k_2_02:28]
| • | The second quarter of fiscal 2018 GAAP results included: |

[0001728949-19-000034:8k_2_02:29]
| ◦ | $310 million restructuring and restructuring-related charges, or ($0.18) per share, related to our Cost Plan that was announced in the second quarter of fiscal 2018. |

[0001728949-19-000034:8k_2_02:30]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 3 of 15 |

[0001728949-19-000034:8k_2_02:31]
| • | The first quarter of fiscal 2019 GAAP results included: |

[0001728949-19-000034:8k_2_02:32]
| ◦ | $180 million of restructuring and restructuring-related charges, or ($0.13) per share, related to our Cost Plan. |

[0001728949-19-000034:8k_2_02:33]
| • | The first quarter of fiscal 2019 GAAP and Non-GAAP results included: |

[0001728949-19-000034:8k_2_02:34]
| ◦ | $570 million tax benefit, or $0.47 per share, for GAAP and $552 million tax benefit, or $0.45 per share, for Non-GAAP relating to certain tax elections made in the first quarter of fiscal 2019. |

[0001728949-19-000034:8k_2_02:35]
| ◦ | $150 million of revenues, or $0.11 per share, resulting from an interim agreement with Huawei while negotiations continue. |

[0001728949-19-000034:8k_2_02:36]
Segment Results

[0001728949-19-000034:8k_2_02:37]
Second Quarter Fiscal 2019

[0001728949-19-000034:8k_2_02:38]
| (in millions, except percentages) | Q2 Fiscal 2019 |  | Q2 Fiscal 2018 |  | Year-Over-Year Change |  | Q1 Fiscal 2019 |  | Sequential Change |
| QCT |  |  |  |  |  |  |  |  |  |
| Revenues | $3,722 |  | $3,897 |  | (4%) |  | $3,739 |  | —% |
| EBT 1 | $542 |  | $608 |  | (11%) |  | $598 |  | (9%) |
| EBT as % of revenues | 15% |  | 16% |  | (1%) |  | 16% |  | (1%) |
| MSMTM chip shipments | 155 |  | 187 |  | (17%) |  | 186 |  | (17%) |
| QTL |  |  |  |  |  |  |  |  |  |
| Revenues | $1,122 |  | $1,219 |  | (8%) |  | $1,018 |  | +10% |
| EBT 1 | $674 |  | $809 |  | (17%) |  | $590 |  | +14% |
| EBT as % of revenues | 60% |  | 66% |  | (6%) |  | 58% |  | +2% |

[0001728949-19-000034:8k_2_02:39]
1 Earnings (loss) before taxes

[0001728949-19-000034:8k_2_02:40]
We adopted accounting guidance (ASC 606) in the first quarter of fiscal 2019 that requires us to estimate and recognize QTL royalty revenues in the period in which the licensees’ sales occur, resulting in an acceleration of royalty revenues by one quarter.  As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

[0001728949-19-000034:8k_2_02:41]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 4 of 15 |

[0001728949-19-000034:8k_2_02:42]
Return of Capital to Stockholders

[0001728949-19-000034:8k_2_02:43]
During the second quarter of fiscal 2019, we paid cash dividends totaling $752 million, or $0.62 per share. In the fourth quarter of fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock.  At March 31, 2019, $7.8 billion remained authorized for repurchase under our stock repurchase program.

[0001728949-19-000034:8k_2_02:44]
Cash and Marketable Securities

[0001728949-19-000034:8k_2_02:45]
Our cash, cash equivalents and marketable securities totaled $10.4 billion at the end of the second quarter of fiscal 2019, compared to $39.6 billion a year ago and $10.4 billion at the end of the first quarter of fiscal 2019.  Stock repurchases and repayment of long-term debt significantly reduced our cash, cash equivalents and marketable securities balance at the end of the second quarter of fiscal 2019, compared to a year ago.

[0001728949-19-000034:8k_2_02:46]
Effective Income Tax Rates

[0001728949-19-000034:8k_2_02:47]
Our second quarter of fiscal 2019 results reflected estimated annual effective income tax rates of 6% benefit for GAAP and 1% provision for Non-GAAP, including the impact of income tax benefits recorded discretely in the first quarter of fiscal 2019 of $570 million and $552 million for GAAP and Non-GAAP, respectively.  The effective income tax rates for the second quarter of fiscal 2019 were 18% for GAAP and 15% for Non-GAAP.  The annual and second quarter rates excluded the effects of the agreements with Apple and its contract manufacturers reached in April 2019 since the agreements were signed after the end of the second quarter.

[0001728949-19-000034:8k_2_02:48]
Looking forward to the third quarter of fiscal 2019, we expect our estimated annual effective tax rates to increase to 8% for GAAP and 2% for Non-GAAP, reflecting the impact of the agreements reached with Apple and its contract manufacturers in April 2019.  We estimate our tax rates for the third quarter of fiscal 2019 to be 16% to 17% for GAAP and 14% to 15% for Non-GAAP.

[0001728949-19-000034:8k_2_02:49]
Business Outlook

[0001728949-19-000034:8k_2_02:50]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 5 of 15 |

[0001728949-19-000034:8k_2_02:51]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as certain investment, certain derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001728949-19-000034:8k_2_02:52]
On April 16, 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties.  We also entered into a six-year global patent license agreement with Apple, effective as of April 1, 2019, which includes an option for Apple to extend for an additional two years, and a multi-year chipset supply agreement with Apple.  While we continue to assess the accounting impacts of the agreements, our financial guidance for the third quarter of fiscal 2019 includes estimated revenues of $4.5 billion to $4.7 billion resulting from the settlement (which will be excluded from our Non-GAAP results), consisting of a payment from Apple and the release of our obligations to pay or refund Apple and the contract manufacturers certain customer-related liabilities.  In addition, our financial guidance for the third quarter of fiscal 2019 includes estimated QTL revenues for royalties due from Apple and its contract manufacturers for sales made in the June 2019 quarter.  Our financial guidance for the third quarter of fiscal 2019 also includes $150 million of QTL revenues from Huawei, which represents a minimum, non-refundable amount for royalties due by Huawei while negotiations continue.  This payment does not reflect the full amount of royalties due under the underlying license agreement.

[0001728949-19-000034:8k_2_02:53]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 6 of 15 |

[0001728949-19-000034:8k_2_02:54]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001728949-19-000034:8k_2_02:55]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001728949-19-000034:8k_2_02:56]
|  |  | Q3 FY18Results (1) | Current Guidance Q3 FY19 Estimates (2)(3) |  |
|  | GAAP Revenues | $5.6B | $9.2B - $10.2B |  |  |
|  | Year-over-year change |  | increase 65% - 83% |  |  |
|  | Less revenues attributable to QSI | $20M | $0B |  |  |
|  | Less revenues attributable to other items | ($50M) | $4.5B - $4.7B |  |  |
|  | Non-GAAP Revenues | $5.6B | $4.7B - $5.5B |  |  |
|  | Year-over-year change |  | decrease 2% - 16% |  |  |
|  | GAAP diluted earnings (loss) per share (EPS) | $0.81 | $3.57 - $3.77 |  |  |
|  | Year-over-year change |  | N/M |  |  |
|  | Less diluted EPS attributable to QSI | $0.00 |  | $0.01 |  |  |
|  | Less diluted EPS attributable to share-based compensation | ($0.10) |  | ($0.16 | ) |  |
|  | Less diluted EPS attributable to other items | ($0.09) | $3.02 - $3.12 |  |  |
|  | Non-GAAP diluted EPS | $1.00 | $0.70 - $0.80 |  |  |
|  | Year-over-year change |  | decrease 20% - 30% |  |  |
|  | Other Information |  |  |  |
|  | MSM chip shipments | 199 | M | 150M - 170M |  |  |
|  | Year-over-year change |  | decrease 15% - 25% |  |  |
|  | QTL revenues | $1.4B | $1.225B - $1.325B |  |  |
|  | Year-over-year change |  | decrease 8% - 15% |  |  |

[0001728949-19-000034:8k_2_02:57]
| (1) | The third quarter of fiscal 2018 results excluded QTL revenues for royalties due on sales of Apple and other products by Apple’s contract manufacturers. The third quarter of fiscal 2018 results included $500 million of QTL revenues from Huawei under an interim agreement for royalties due after the second quarter of fiscal 2017, while negotiations continued. Other items excluded from Non-GAAP revenues for the third quarter of fiscal 2018 consisted of a reduction to licensing revenues related to a portion of a business arrangement that resolves a legal dispute. Diluted EPS attributable to other items for the third quarter of fiscal 2018 was primarily attributable to acquisition-related items and restructuring and restructuring-related charges related to our Cost Plan. |

[0001728949-19-000034:8k_2_02:58]
| (2) | Our GAAP and Non-GAAP financial guidance for the third quarter of fiscal 2019 includes estimated QTL revenues for royalties due from Apple and its contract manufacturers for sales made in the June 2019 quarter and also includes $150 million of QTL revenues from Huawei. |

[0001728949-19-000034:8k_2_02:59]
| (3) | Our guidance for revenues and diluted EPS attributable to other items for the third quarter of fiscal 2019 is primarily attributable to the settlement of our prior disputes with Apple and the contract manufacturers, resulting in estimated revenues of $4.5 billion to $4.7 billion and estimated EPS of $3.10 to $3.20 per share. Our guidance for diluted EPS attributable to other items for the third quarter of fiscal 2019 also includes acquisition-related items. |

[0001728949-19-000034:8k_2_02:60]
Sums may not equal total due to rounding.

[0001728949-19-000034:8k_2_02:61]
N/M - Not Meaningful

[0001728949-19-000034:8k_2_02:62]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 7 of 15 |

[0001728949-19-000034:8k_2_02:63]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-19-000034:8k_2_02:64]
The following tables reconcile our GAAP results to our Non-GAAP results (in millions, except per share data):

[0001728949-19-000034:8k_2_02:65]
|  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) | Non-GAAP Results |
| Q2 FISCAL 2019 |  |  |  |  |  |  |  |
| Revenues | $4,982 |  | $98 |  |  | $— |  |  |  | $— |  |  | $4,884 |  |
| Operating income (loss) | 940 |  | 88 |  | (221) |  | (89) |  | 1,162 |  |
| EBT | 806 |  | 17 |  | (221) |  | (81) |  | 1,091 |  |
| EBT as % of revenues | 16 | % |  |  |  |  |  |  |  | 22 | % |  |
| Net income (loss) | 663 |  | 21 |  | (191) |  | (99) |  | 932 |  |
| Diluted EPS | $0.55 |  | $0.02 |  | ($0.16) |  | ($0.08) |  | $0.77 |  |
| Diluted shares | 1,217 |  | 1,217 |  | 1,217 |  | 1,217 |  | 1,217 |  |
| Q1 FISCAL 2019 |  |  |  |  |  |  |  |
| Revenues | $4,842 |  | $27 |  |  | $— |  |  |  | $— |  |  | $4,815 |  |
| Operating income (loss) | 710 |  | 13 |  | (230) |  | (260) |  | 1,187 |  |
| EBT | 559 |  | 8 |  | (230) |  | (263) |  | 1,044 |  |
| EBT as % of revenues | 12 | % |  |  |  |  |  |  |  | 22 | % |  |
| Net income (loss) | 1,068 |  | 7 |  | (182) |  | (221) |  | 1,464 |  |
| Diluted EPS | $0.87 |  | $0.01 |  | ($0.15) |  | ($0.18) |  | $1.20 |  |
| Diluted shares | 1,223 |  | 1,223 |  | 1,223 |  | 1,223 |  | 1,223 |  |
| Q2 FISCAL 2018 |  |  |  |  |  |  |  |
| Revenues | $5,220 |  | $30 |  |  | $— |  |  |  | $— |  |  | $5,190 |  |
| Operating income (loss) | 400 |  | 10 |  | (222) |  | (628) |  | 1,240 |  |
| EBT | 317 |  | 40 |  | (222) |  | (696) |  | 1,195 |  |
| EBT as % of revenues | 6 | % |  |  |  |  |  |  |  | 23 | % |  |
| Net income (loss) | 330 |  | 30 |  | (193) |  | (661) |  | 1,154 |  |
| Diluted EPS | $0.22 |  | $0.02 |  | ($0.13) |  | ($0.44) |  | $0.78 |  |
| Diluted shares | 1,494 |  | 1,494 |  | 1,494 |  | 1,494 |  | 1,494 |  |

[0001728949-19-000034:8k_2_02:66]
| (a) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” herein for further details. |

[0001728949-19-000034:8k_2_02:67]
| (b) | Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” sections herein. Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001728949-19-000034:8k_2_02:68]
Sums may not equal totals due to rounding.

[0001728949-19-000034:8k_2_02:69]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 8 of 15 |

[0001728949-19-000034:8k_2_02:70]
Supplemental Information and Reconciliations

[0001728949-19-000034:8k_2_02:71]
(Unaudited)

[0001728949-19-000034:8k_2_02:72]
|  | Q2 FISCAL 2019 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results |
|  | Cost of revenues |  | $2,179 |  |  | $7 |  |  | $7 |  |  | $99 |  |  | $2,066 |  |
|  | Research and development (R&D) expenses |  | 1,308 |  |  | — |  |  |  | 157 |  |  | 1 |  |  | 1,150 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 573 |  |  | 3 |  |  | 57 |  |  | 7 |  |  | 506 |  |
|  | Other income |  | (18) |  |  | — |  |  |  | — |  |  |  | (18) |  |  | — |  |  |
|  | Interest expense |  | 162 |  |  | — |  |  |  | — |  |  |  | 5 |  |  | 157 |  |
|  | Investment and other income (loss), net |  | 28 |  |  | (71) |  |  | — |  |  |  | 13 |  |  | 86 | (b) |
|  | Diluted EPS impact of the interim agreement with Huawei |  | $0.10 |  |  | $0.00 |  |  | $0.00 |  |  | ($0.01) | (c) |  | $0.11 |  |

[0001728949-19-000034:8k_2_02:73]
| (a) | Other items excluded from Non-GAAP results included $107 million of acquisition-related charges, $25 million of net charges related to our Cost Plan and $5 million of interest expense related to the European Commission fine, partially offset by a $43 million gain (and $13 million of interest) due to the partial recovery of a fine imposed in fiscal 2009 resulting from our appeal of the Korea Fair Trade Commission (KFTC) decision. |

[0001728949-19-000034:8k_2_02:74]
| (b) | Included $61 million in interest and dividend income and $36 million in net gains on marketable securities, partially offset by $9 million in our share in equity method investee net losses, $1 million of net losses on derivative instruments and $1 million in net foreign currency losses. |

[0001728949-19-000034:8k_2_02:75]
| (c) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. |

[0001728949-19-000034:8k_2_02:76]
Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates

[0001728949-19-000034:8k_2_02:77]
(Unaudited)

[0001728949-19-000034:8k_2_02:78]
| ($ in millions) |  | GAAP Results |  |  | Less QSI | Less Share-Based Compensation | Less Other Items (b) (c) (d) |  | Non-GAAP Results |  |
| Q2 FISCAL 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 806 |  |  |  | $ | 17 |  |  |  | $ | (221 | ) |  |  | $ | (81 | ) |  |  | $ | 1,091 |  |  |
| Income tax (expense) benefit |  | (143 | ) |  |  | 4 |  |  |  | 30 |  |  |  | (18 | ) |  |  | (159 | ) |  |
| Net income (loss) |  | $ | 663 |  |  |  | $ | 21 |  |  |  | $ | (191 | ) |  |  | $ | (99 | ) |  |  | $ | 932 |  |  |
| Tax rate |  | 18 | % |  |  | (1 | %) | (a) |  |  |  | 1 | % | (a) |  |  | 3 | % | (a) |  |  |  | 15 | % |  |
| FISCAL 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Estimated annual tax rate |  | (6 | %) |  |  | 0 | % | (a) |  |  |  | (5 | %) | (a) |  |  |  | (2 | %) | (a) |  |  |  | 1 | % |  |
| Q3 FISCAL 2019 Guidance (e) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Estimated annual tax rate |  | 8 | % |  |  | — | % |  |  | (1 | %) |  |  | 7 | % |  |  | 2 | % |  |
| Estimated Q3 Fiscal 2019 tax rate |  | 16% - 17% |  |  |  | — | % |  |  | 1 | % |  |  | 1 | % |  |  | 14% - 15% |  |  |

[0001728949-19-000034:8k_2_02:79]
| (a) | The incremental effect of our adjustments to the Non-GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001728949-19-000034:8k_2_02:80]
| (b) | In the second quarter of fiscal 2019, the tax expense in the “Other Items” column included a $43 million expense for the combined effect of other items in EBT and a $10 million expense to reconcile the tax provision for each column to the total GAAP tax provision for the quarter, partially offset by a $18 million benefit for the tax effect of acquisition-related items in EBT and a $17 million benefit for release of a valuation allowance. |

[0001728949-19-000034:8k_2_02:81]
| (c) | In fiscal 2019, the estimated annual effective tax rate for the “Other Items” column included a $69 million benefit for the tax effect of acquisition-related items in EBT and a $17 million benefit for release of a valuation allowance, partially offset by a $30 million expense for the combined effect of other items in EBT. |

[0001728949-19-000034:8k_2_02:82]
| (d) | Our guidance for the third quarter of fiscal 2019 for the estimated tax rate included in the “Other Items” column is primarily attributed to the combined effect of other items in EBT, partially offset by a benefit for the tax effect of acquisition-related items in EBT. |

[0001728949-19-000034:8k_2_02:83]
| (e) | Our estimated annual tax rate guidance for the third quarter of fiscal 2019 includes the effects of the agreements with Apple and its contract manufacturers. |

[0001728949-19-000034:8k_2_02:84]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 9 of 15 |

[0001728949-19-000034:8k_2_02:85]
Conference Call

[0001728949-19-000034:8k_2_02:86]
Qualcomm’s fiscal second quarter 2019 earnings conference call will be broadcast live on May 1, 2019, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415.  Callers should use reservation number 13689810.

[0001728949-19-000034:8k_2_02:87]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-19-000034:8k_2_02:88]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results used herein are presented herein.

[0001728949-19-000034:8k_2_02:89]
The Company uses Non-GAAP financial information: (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income (loss) and diluted earnings (loss) per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial

[0001728949-19-000034:8k_2_02:90]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 10 of 15 |

[0001728949-19-000034:8k_2_02:91]
information is also used by institutional investors and analysts in evaluating the Company’s business and assessing trends and future expectations.

[0001728949-19-000034:8k_2_02:92]
Non-GAAP information used by management excludes its QSI segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-19-000034:8k_2_02:93]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001728949-19-000034:8k_2_02:94]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001728949-19-000034:8k_2_02:95]
| • | Certain other items are excluded because management views such items as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001728949-19-000034:8k_2_02:96]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of these items, as well as any effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition. |

[0001728949-19-000034:8k_2_02:97]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing businesses, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. |

[0001728949-19-000034:8k_2_02:98]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after-tax earnings. In fiscal 2018, the Company excluded the full impact of the estimated one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries, including the portion that relates to earnings and profits of U.S.-owned foreign subsidiaries generated in the first quarter of fiscal 2018. |

[0001728949-19-000034:8k_2_02:99]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 11 of 15 |

[0001728949-19-000034:8k_2_02:100]
About Qualcomm

[0001728949-19-000034:8k_2_02:101]
Qualcomm invents breakthrough technologies that transform how the world connects, computes and communicates.  When we connected the phone to the Internet, the mobile revolution was born.  Today, our inventions are the foundation for life-changing products, experiences, and industries.  As we lead the world to 5G, we envision this next big change in cellular technology spurring a new era of intelligent, connected devices and enabling new opportunities in connected cars, remote delivery of health care services, and the IoT - including smart cities, smart homes, and wearables.  Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, all of our engineering, research and development functions, and all of our products and services businesses, including, our QCT semiconductor business.  For more information, visit www.qualcomm.com.

[0001728949-19-000034:8k_2_02:102]
Note Regarding Forward-Looking Statements

[0001728949-19-000034:8k_2_02:103]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 12 of 15 |

[0001728949-19-000034:8k_2_02:104]
###

[0001728949-19-000034:8k_2_02:105]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries. Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-19-000034:8k_2_02:106]
MSM is a product of Qualcomm Technologies, Inc.

[0001728949-19-000034:8k_2_02:107]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 13 of 15 |

[0001728949-19-000034:8k_2_02:108]
Qualcomm Incorporated

[0001728949-19-000034:8k_2_02:109]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001728949-19-000034:8k_2_02:110]
(In millions, except per share data)

[0001728949-19-000034:8k_2_02:111]
(Unaudited)

[0001728949-19-000034:8k_2_02:112]
|  | March 31, 2019 |  | September 30, 2018 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 10,135 |  |  | $ | 11,777 |  |
| Marketable securities | 195 |  |  | 311 |  |
| Accounts receivable, net | 3,638 |  |  | 2,904 |  |
| Inventories | 1,725 |  |  | 1,693 |  |
| Other current assets | 631 |  |  | 699 |  |
| Total current assets | 16,324 |  |  | 17,384 |  |
| Deferred tax assets | 3,832 |  |  | 936 |  |
| Property, plant and equipment, net | 2,945 |  |  | 2,975 |  |
| Goodwill | 6,299 |  |  | 6,498 |  |
| Other intangible assets, net | 2,510 |  |  | 2,955 |  |
| Other assets | 2,113 |  |  | 1,970 |  |
| Total assets | $ | 34,023 |  |  | $ | 32,718 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,667 |  |  | $ | 1,825 |  |
| Payroll and other benefits related liabilities | 633 |  |  | 1,081 |  |
| Unearned revenues | 478 |  |  | 500 |  |
| Short-term debt | 998 |  |  | 1,005 |  |
| Other current liabilities | 6,741 |  |  | 6,978 |  |
| Total current liabilities | 10,517 |  |  | 11,389 |  |
| Unearned revenues | 1,330 |  |  | 1,620 |  |
| Income taxes payable | 1,849 |  |  | 2,312 |  |
| Long-term debt | 15,405 |  |  | 15,365 |  |
| Other liabilities | 1,056 |  |  | 1,225 |  |
| Total liabilities | 30,157 |  |  | 31,911 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,214 and 1,219 shares issued and outstanding, respectively | 384 |  |  | — |  |
| Retained earnings | 3,309 |  |  | 542 |  |
| Accumulated other comprehensive income | 173 |  |  | 265 |  |
| Total stockholders’ equity | 3,866 |  |  | 807 |  |
| Total liabilities and stockholders’ equity | $ | 34,023 |  |  | $ | 32,718 |  |

[0001728949-19-000034:8k_2_02:113]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 14 of 15 |

[0001728949-19-000034:8k_2_02:114]
Qualcomm Incorporated

[0001728949-19-000034:8k_2_02:115]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-19-000034:8k_2_02:116]
(In millions, except per share data)

[0001728949-19-000034:8k_2_02:117]
(Unaudited)

[0001728949-19-000034:8k_2_02:118]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2019 |  | March 25, 2018 |  | March 31, 2019 |  | March 25, 2018 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,753 |  |  | $ | 3,936 |  |  | $ | 7,506 |  |  | $ | 8,639 |  |
| Licensing | 1,229 |  |  | 1,284 |  |  | 2,318 |  |  | 2,616 |  |
| Total revenues | 4,982 |  |  | 5,220 |  |  | 9,824 |  |  | 11,255 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of revenues | 2,179 |  |  | 2,239 |  |  | 4,367 |  |  | 4,902 |  |
| Research and development | 1,308 |  |  | 1,402 |  |  | 2,577 |  |  | 2,822 |  |
| Selling, general and administrative | 573 |  |  | 869 |  |  | 1,100 |  |  | 1,641 |  |
| Other | (18 | ) |  | 310 |  |  | 130 |  |  | 1,493 |  |
| Total costs and expenses | 4,042 |  |  | 4,820 |  |  | 8,174 |  |  | 10,858 |  |
| Operating income | 940 |  |  | 400 |  |  | 1,650 |  |  | 397 |  |
| Interest expense | (162 | ) |  | (179 | ) |  | (317 | ) |  | (350 | ) |
| Investment and other income, net | 28 |  |  | 96 |  |  | 33 |  |  | 211 |  |
| Income before income taxes | 806 |  |  | 317 |  |  | 1,366 |  |  | 258 |  |
| Income tax (expense) benefit | (143 | ) |  | 13 |  |  | 365 |  |  | (5,911 | ) |
| Net income (loss) | $ | 663 |  |  | $ | 330 |  |  | $ | 1,731 |  |  | $ | (5,653 | ) |
| Basic earnings (loss) per share | $ | 0.55 |  |  | $ | 0.22 |  |  | $ | 1.43 |  |  | $ | (3.82 | ) |
| Diluted earnings (loss) per share | $ | 0.55 |  |  | $ | 0.22 |  |  | $ | 1.42 |  |  | $ | (3.82 | ) |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,213 |  |  | 1,482 |  |  | 1,213 |  |  | 1,479 |  |
| Diluted | 1,217 |  |  | 1,494 |  |  | 1,220 |  |  | 1,479 |  |

[0001728949-19-000034:8k_2_02:119]
| Qualcomm Announces Second Quarter Fiscal 2019 Results | Page 15 of 15 |

[0001728949-19-000034:8k_2_02:120]
Qualcomm Incorporated

[0001728949-19-000034:8k_2_02:121]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-19-000034:8k_2_02:122]
(In millions)

[0001728949-19-000034:8k_2_02:123]
(Unaudited)

[0001728949-19-000034:8k_2_02:124]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, 2019 |  | March 25, 2018 |  | March 31, 2019 |  | March 25, 2018 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 663 |  |  | $ | 330 |  |  | $ | 1,731 |  |  | $ | (5,653 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 345 |  |  | 388 |  |  | 698 |  |  | 751 |  |
| Income tax provision (less than) in excess of income tax payments | (295 | ) |  | (228 | ) |  | (958 | ) |  | 5,466 |  |
| Non-cash portion of share-based compensation expense | 221 |  |  | 222 |  |  | 452 |  |  | 470 |  |
| Net gains on marketable securities and other investments | (46 | ) |  | (50 | ) |  | (9 | ) |  | (73 | ) |
| Indefinite and long-lived asset impairment charges | 53 |  |  | 33 |  |  | 203 |  |  | 33 |  |
| Impairment losses on marketable securities and other investments | 60 |  |  | 11 |  |  | 69 |  |  | 20 |  |
| Other items, net | (155 | ) |  | 70 |  |  | (190 | ) |  | 52 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (215 | ) |  | (487 | ) |  | 200 |  |  | 94 |  |
| Inventories | (31 | ) |  | 81 |  |  | (49 | ) |  | 243 |  |
| Other assets | 173 |  |  | 138 |  |  | 25 |  |  | 58 |  |
| Trade accounts payable | 230 |  |  | (273 | ) |  | (173 | ) |  | (511 | ) |
| Payroll, benefits and other liabilities | (149 | ) |  | 331 |  |  | (727 | ) |  | 1,453 |  |
| Unearned revenues | (60 | ) |  | (50 | ) |  | (122 | ) |  | (125 | ) |
| Net cash provided by operating activities | 794 |  |  | 516 |  |  | 1,150 |  |  | 2,278 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (170 | ) |  | (185 | ) |  | (322 | ) |  | (411 | ) |
| Purchases of debt and equity marketable securities | — |  |  | (131 | ) |  | — |  |  | (5,758 | ) |
| Proceeds from sales and maturities of debt and equity marketable securities | 57 |  |  | 4,955 |  |  | 92 |  |  | 7,659 |  |
| Acquisitions and other investments, net of cash acquired | (62 | ) |  | (48 | ) |  | (118 | ) |  | (170 | ) |
| Proceeds from other investments | 16 |  |  | 159 |  |  | 39 |  |  | 159 |  |
| Other items, net | 50 |  |  | (8 | ) |  | 48 |  |  | 2 |  |
| Net cash (used) provided by investing activities | (109 | ) |  | 4,742 |  |  | (261 | ) |  | 1,481 |  |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 1,513 |  |  | 3,447 |  |  | 3,297 |  |  | 5,563 |  |
| Repayment of short-term debt | (1,513 | ) |  | (3,181 | ) |  | (3,303 | ) |  | (4,330 | ) |
| Proceeds from issuance of common stock | 149 |  |  | 201 |  |  | 177 |  |  | 335 |  |
| Repurchases and retirements of common stock | — |  |  | (200 | ) |  | (1,019 | ) |  | (425 | ) |
| Dividends paid | (752 | ) |  | (845 | ) |  | (1,502 | ) |  | (1,689 | ) |
| Payments of tax withholdings related to vesting of share-based awards | (4 | ) |  | (4 | ) |  | (143 | ) |  | (196 | ) |
| Payment of purchase consideration related to RF360 joint venture | — |  |  | (115 | ) |  | — |  |  | (115 | ) |
| Other items, net | (37 | ) |  | (12 | ) |  | (38 | ) |  | (17 | ) |
| Net cash used by financing activities | (644 | ) |  | (709 | ) |  | (2,531 | ) |  | (874 | ) |
| Changes in cash and cash equivalents held for sale | 25 |  |  | — |  |  | — |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents | 3 |  |  | 35 |  |  | — |  |  | 32 |  |
| Net increase (decrease) in total cash and cash equivalents | 69 |  |  | 4,584 |  |  | (1,642 | ) |  | 2,917 |  |
| Total cash and cash equivalents at beginning of period | 10,066 |  |  | 35,362 |  |  | 11,777 |  |  | 37,029 |  |
| Total cash and cash equivalents at end of period | $ | 10,135 |  |  | $ | 39,946 |  |  | $ | 10,135 |  |  | $ | 39,946 |  |
| Reconciliation to the condensed consolidated balance sheets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 10,135 |  |  | $ | 37,946 |  |  | $ | 10,135 |  |  | $ | 37,946 |  |
| Restricted cash and restricted cash equivalents included in other assets | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Total cash and cash equivalents at end of period | $ | 10,135 |  |  | $ | 39,946 |  |  | $ | 10,135 |  |  | $ | 39,946 |  |
