# QCOM notes — 0001728949-19-000055


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-19-000055:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for the fiscal year ended September 30, 2018. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 30, 2019 and June 24, 2018 included 13 weeks and 39 weeks, respectively.

[0001728949-19-000055:notes:2]
[same as prior period, unchanged from 0001728949-19-000036:notes:131]

[0001728949-19-000055:notes:3]
Revision of Prior Period Financial Statements. As previously disclosed, in connection with the preparation of our condensed consolidated financial statements for the three months ended December 30, 2018, we identified an immaterial error related to the recognition of certain royalty revenues of our QTL (Qualcomm Technology Licensing) segment in the quarterly and annual periods in fiscal 2018 and third and fourth quarters and annual period in fiscal 2017. In accordance with SAB No. 99, “Materiality,” and SAB No. 108, “Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements,” we evaluated the error and determined that the related impact was not material to our financial statements for any prior annual or interim period, but that correcting the cumulative impact of the error would be significant to our results of operations for the three months ended December 30, 2018. Accordingly, we have revised previously reported financial information for such immaterial error, as previously disclosed in our Quarterly Report on Form 10-Q for the first and second quarters of fiscal 2019. A summary of revisions to certain previously reported financial information presented herein for comparative purposes is included in Note 11. We will also correct previously reported financial information for such immaterial error in our future filings, as applicable.

[0001728949-19-000055:notes:4]
Earnings (Loss) Per Common Share. Basic earnings (loss) per common share is computed by dividing net income (loss) by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans and shares subject to accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Due to the net loss for the nine months ended June 24, 2018, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share. The following table provides information about the diluted earnings (loss) per share calculation (in millions):

[0001728949-19-000055:notes:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | June 30, 2019 |  | June 24, 2018 |
| Dilutive common share equivalents included in diluted shares | 13.9 |  |  | 9.0 |  |  | 9.3 |  |  | — |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 0.7 |  |  | 0.6 |  |  | 9.9 |  |  | 43.2 |  |

[0001728949-19-000055:notes:6]
[same as prior period, unchanged from 0001728949-19-000036:notes:135]

[0001728949-19-000055:notes:7]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | June 30, 2019 |  | June 24, 2018 |
| Cost of revenues | $ | 8 |  |  | $ | 9 |  |  | $ | 23 |  |  | $ | 30 |  |
| Research and development | 164 |  |  | 140 |  |  | 479 |  |  | 447 |  |
| Selling, general and administrative | 74 |  |  | 40 |  |  | 196 |  |  | 182 |  |
| Share-based compensation expense before income taxes | 246 |  |  | 189 |  |  | 698 |  |  | 659 |  |
| Related income tax benefit | (48 | ) |  | (34 | ) |  | (127 | ) |  | (111 | ) |
|  | $ | 198 |  |  | $ | 155 |  |  | $ | 571 |  |  | $ | 548 |  |

[0001728949-19-000055:notes:8]
At June 30, 2019, total unrecognized compensation expense related to nonvested restricted stock units granted prior to that date was $1.2 billion, which is expected to be recognized over a weighted-average period of 2.1 years. At June 30, 2019, we had outstanding 26.9 million restricted stock units and 1.1 million stock options that contain only a service requirement.

[0001728949-19-000055:notes:9]
Recently Adopted Accounting Pronouncements.

[0001728949-19-000055:notes:10]
[same as prior period, unchanged from 0001728949-19-000036:notes:139]

[0001728949-19-000055:notes:11]
Adoption of this new accounting guidance most significantly impacts the timing of sales-based royalty revenues, which are the vast majority of our QTL segment’s revenues. Prior to adoption, we recognized sales-based royalties as revenues in the period in which such royalties were reported by licensees, which was after the conclusion of the quarter in which the licensees’ sales occurred and when all other revenue recognition criteria had been met. Under the new accounting guidance, we estimate and recognize sales-based royalties in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such amounts, resulting in an acceleration of revenue recognition compared to the historical method under ASC 605. Since we do not invoice for sales-based royalties estimated and recognized in any given quarter until after the conclusion of that quarter (which is generally the following quarter when such royalties are reported by licensees), revenues recognized from sales-based royalties results in unbilled receivables (included in accounts receivable, net on the consolidated balance sheet). The adoption of ASC 606 did not otherwise have a material impact.

[0001728949-19-000055:notes:12]
The new accounting guidance also impacts the timing of recognizing certain customer incentives, which are recorded as a reduction to revenues in the period that the related revenues are earned. Prior to adoption, we accounted for certain customer incentive arrangements, including volume-related and other pricing rebates or cost reimbursements for marketing and other activities involving certain of our products and technologies, in part based on the maximum potential liability. Under the new accounting guidance, we estimate the amount of all customer incentives.

[0001728949-19-000055:notes:13]
The following table summarizes the cumulative effects of adopting the new revenue accounting guidance (substantially all of which related to the impact to QTL’s sales-based royalties) on our condensed consolidated balance sheet at October 1, 2018 (in millions):

[0001728949-19-000055:notes:14]
|  | Balance as of September 30, 2018 |  | Adjustment |  | Opening Balance as of October 1, 2018 |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 2,904 |  |  | $ | 957 |  |  | $ | 3,861 |  |
| Other current assets | 699 |  |  | 1 |  |  | 700 |  |
| Deferred tax assets | 936 |  |  | (98 | ) |  | 838 |  |
| Other assets | 1,970 |  |  | 1 |  |  | 1,971 |  |
| Liabilities |  |  |  |  |  |
| Unearned revenues, current | $ | 500 |  |  | $ | 6 |  |  | $ | 506 |  |
| Other current liabilities | 6,978 |  |  | 125 |  |  | 7,103 |  |
| Unearned revenues | 1,620 |  |  | (110 | ) |  | 1,510 |  |
| Stockholders’ equity |  |  |  |  |  |
| Retained earnings | $ | 542 |  |  | $ | 840 |  |  | $ | 1,382 |  |

[0001728949-19-000055:notes:15]
The following tables summarize the impacts of adopting the new revenue accounting guidance on our condensed consolidated balance sheet and statements of operations (in millions):

[0001728949-19-000055:notes:16]
|  | As of June 30, 2019 |
| Balance Sheet | As ReportedASC 606 |  | Adjustment |  | ASC 605 |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 2,390 |  |  | $ | (1,070 | ) |  | $ | 1,320 |  |
| Other current assets | 682 |  |  | (32 | ) |  | 650 |  |
| Deferred tax assets | 1,172 |  |  | 106 |  |  | 1,278 |  |
| Other assets | 2,062 |  |  | (1 | ) |  | 2,061 |  |
| Liabilities |  |  |  |  |  |
| Unearned revenues, current | $ | 527 |  |  | $ | (41 | ) |  | $ | 486 |  |
| Other current liabilities | 4,725 |  |  | (31 | ) |  | 4,694 |  |
| Unearned revenues | 1,251 |  |  | 138 |  |  | 1,389 |  |
| Stockholders’ equity |  |  |  |  |  |
| Retained earnings | $ | 4,687 |  |  | $ | (1,063 | ) |  | $ | 3,624 |  |

[0001728949-19-000055:notes:17]
|  | Three Months Ended June 30, 2019 |  | Nine Months Ended June 30, 2019 |
| Statements of Operations | As Reported ASC 606 |  | Adjustment |  | ASC 605 |  | As Reported ASC 606 |  | Adjustment |  | ASC 605 |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,531 |  |  | $ | (10 | ) |  | $ | 3,521 |  |  | $ | 11,037 |  |  | $ | (80 | ) |  | $ | 10,957 |  |
| Licensing | 6,104 |  |  | (239 | ) |  | 5,865 |  |  | 8,422 |  |  | (196 | ) |  | 8,226 |  |
| Investment and other income, net | 344 |  |  | (1 | ) |  | 343 |  |  | 377 |  |  | — |  |  | 377 |  |
| Income tax (expense) benefit | (3,352 | ) |  | 49 |  |  | (3,303 | ) |  | (2,987 | ) |  | 53 |  |  | (2,934 | ) |
| Net income | 2,149 |  |  | (201 | ) |  | 1,948 |  |  | 3,880 |  |  | (223 | ) |  | 3,657 |  |

[0001728949-19-000055:notes:18]
Adoption of the new accounting guidance had no impact to net cash provided (used) by operating, financing or investing activities on our condensed consolidated statement of cash flows for the nine months ended June 30, 2019.

[0001728949-19-000055:notes:19]
Financial Assets: In January 2016, the FASB issued new accounting guidance on classifying and measuring financial instruments, which requires that all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings in the statement of operations. Additionally, it changes the disclosure requirements for financial instruments. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the modified retrospective transition method for investments in marketable securities, which have readily determinable fair values, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings. Upon adoption, we reclassified $50 million of unrealized gains, net of the associated tax effects, related to our investments in marketable securities from accumulated other comprehensive income to opening retained earnings. We have applied the prospective transition method for investments in non-marketable securities, which are investments in privately held companies that do not have readily determinable fair values and will recognize, through earnings, any unrealized gains that have accumulated in the period in which there is an observable transaction, if any.

[0001728949-19-000055:notes:20]
Hedge Instruments: In August 2017, the FASB issued new accounting guidance that expands and refines hedge accounting for both financial and non-financial risks, aligns the recognition and presentation of the effects of hedging instruments and hedged items in the financial statements, and includes targeted improvements related to the assessment of hedge effectiveness. The new accounting guidance also modifies disclosure requirements for hedging activities. We adopted the new accounting guidance in the first quarter of 2019 using the modified retrospective transition method and recorded a negligible adjustment to opening retained earnings. The new accounting guidance did not have a material impact on our condensed consolidated financial statements.

[0001728949-19-000055:notes:21]
Statement of Cash Flows: In August 2016, the FASB issued new accounting guidance related to the classification of certain cash receipts and cash payments in the statement of cash flows. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the retrospective transition method for each period presented, which did not have a material impact on our condensed consolidated statements of cash flows.

[0001728949-19-000055:notes:22]
In November 2016, the FASB issued new accounting guidance that requires companies to include restricted cash and cash equivalents as a component in total cash and cash equivalents on the statement of cash flows. As a result, the consolidated statement of cash flows no longer reflects transfers between cash and cash equivalents and restricted cash and cash equivalents. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the retrospective transition method, which results in certain amounts in fiscal 2018 being adjusted to conform to the new accounting guidance. This includes restricted cash and cash equivalents held during fiscal 2018 related to funds deposited as collateral for outstanding letters of credit in connection with a then proposed acquisition. Restricted cash and cash equivalents related to the outstanding letters of credit totaled $2.0 billion at the end of the fourth quarter of fiscal 2017 and third quarter of fiscal 2018. Additionally, amounts for the nine months ended June 24, 2018 have been adjusted for restricted cash and cash equivalents of $2.8 billion that was irrevocably deposited to redeem long-term debt in July 2018, resulting in a decrease in net cash used by financing activities by such amount, with a corresponding increase in total cash and cash equivalents presented on the condensed consolidated statement of cash flows.

[0001728949-19-000055:notes:23]
Income Taxes: In October 2016, the FASB issued new accounting guidance that changes the accounting for the income tax effects of intra-entity transfers of assets other than inventory. Under the new accounting guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related

[0001728949-19-000055:notes:24]
deferred tax benefit or expense, upon receipt of the asset. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings of $2.6 billion, primarily as the result of establishing a deferred tax asset on the basis difference of certain intellectual property distributed from one of our foreign subsidiaries to a subsidiary in the United States in fiscal 2018. During the third quarter of fiscal 2019, the United States Treasury Department issued new temporary regulations that resulted in a change to the deductibility of dividend income received by a U.S. stockholder from a foreign corporation. As a result of this change, pursuant to an agreement with the Internal Revenue Service, we will forgo the federal tax basis step-up in such distributed intellectual property. Therefore, the related deferred tax asset was written-off, resulting in a $2.5 billion charge to income tax expense in the third quarter of fiscal 2019 (Note 3). The ongoing impact of this accounting guidance will be dependent on the facts and circumstances of any transactions within its scope.

[0001728949-19-000055:notes:25]
Recent Accounting Pronouncements Not Yet Adopted.

[0001728949-19-000055:notes:26]
Leases: In February 2016, the FASB issued new accounting guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease accounting guidance. The new accounting guidance requires lessees to recognize right-of-use assets and corresponding lease liabilities on the balance sheet for leases with a lease term of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. We will adopt the new accounting guidance in the first quarter of fiscal 2020 using the modified retrospective approach as of the effective date, and we will elect certain practical expedients. We do not expect finance leases to be material at the time of adoption. We are in the process of determining the effects the adoption will have on our consolidated financial statements.

[0001728949-19-000055:notes:27]
Financial Assets: In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost will be estimated based on expected losses rather than the current incurred loss impairment model. The new accounting guidance also modifies the impairment model for available-for-sale debt securities. The new accounting guidance generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. We will adopt the new accounting guidance in the first quarter of fiscal 2021, and the impact of this new accounting guidance will largely depend on the composition and credit quality of our investment portfolio, as well as economic conditions at the time of adoption.

[0001728949-19-000055:notes:28]
[same as prior period, unchanged from 0001728949-19-000036:notes:140]

[0001728949-19-000055:notes:29]
[same as prior period, unchanged from 0001728949-19-000036:notes:141]

[0001728949-19-000055:notes:30]
[same as prior period, unchanged from 0001728949-19-000036:notes:142]

[0001728949-19-000055:notes:31]
[same as prior period, unchanged from 0001728949-19-000036:notes:143]

[0001728949-19-000055:notes:32]
We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops, which in general, effectively provide for a maximum royalty amount per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such royalties. Our estimates of sales-based royalties are based largely on an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property. We estimate sales-based royalties taking into consideration the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products, and consider all information

[0001728949-19-000055:notes:33]
(historical, current and forecasted) that is reasonably available to us. Our licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter, which is generally the following quarter. As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

[0001728949-19-000055:notes:34]
[same as prior period, unchanged from 0001728949-19-000036:notes:145]

[0001728949-19-000055:notes:35]
[same as prior period, unchanged from 0001728949-19-000036:notes:146]

[0001728949-19-000055:notes:36]
From time to time, regulatory authorities investigate our business practices, particularly with respect to our licensing business, and institute proceedings against us. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. Additionally, from time to time, companies initiate various strategies in an attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property, which may include disputing, underreporting, underpaying, not reporting and/or not paying royalties owed to us under their license agreements with us, or reporting to us in a manner that is not in compliance with their contractual obligations. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in ASC 606, and to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur, both of which may require significant judgment. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us.

[0001728949-19-000055:notes:37]
On May 21, 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief (Note 6). While we believe that our business practices do not violate either antitrust law or our FRAND (fair, reasonable and non-discriminatory) licensing commitments, significant evaluation and judgment were required in determining the impact of such ruling on the amount of licensing revenues estimated and recognized in the third quarter of fiscal 2019. This included, among other items: (i) evaluating whether our license agreements remain valid and enforceable, (ii) evaluating licensees’ conduct and whether they remain committed to perform their respective obligations and (iii) determining the expected impact, if any, to the current period of any license agreements that may be renegotiated and/or are newly entered into as a result of the ruling while the stay and appeal are pending. Based on this evaluation, the impact of the ruling was not material to QTL licensing revenues in the third quarter of fiscal 2019 based on facts and factors currently known by us. As new information becomes available, we may be required to make adjustments to revenues in subsequent periods to reflect changes in estimates and/or this matter could have a material adverse effect on our ability to recognize future licensing revenues.

[0001728949-19-000055:notes:38]
We measure revenues (including our estimates of sales-based royalties) based on the amount of consideration we expect to receive in exchange for products or services. We record reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of our products and technologies, in the period that the related revenues are earned. The charges for such arrangements are recorded as a reduction to accounts receivable, net or as other current liabilities based on whether we have the intent and contractual right of offset. Certain of these charges are considered variable consideration and are included in the transaction price primarily based on estimating the most likely amount expected to be provided to the customer/licensee.

[0001728949-19-000055:notes:39]
[same as prior period, unchanged from 0001728949-19-000036:notes:149]

[0001728949-19-000055:notes:40]
[same as prior period, unchanged from 0001728949-19-000036:notes:150]

[0001728949-19-000055:notes:41]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were $4.8 billion and $4.1 billion for the three and nine months ended June 30, 2019, respectively, and primarily related to licensing revenues of $4.7 billion recognized in the third quarter of fiscal 2019 (a portion of which was attributable to the first and second quarters of fiscal 2019) resulting from the settlement with Apple and its contract manufacturers (Note 6), consisting of a payment from Apple and the release of certain of our obligations to pay Apple and the contract manufacturers customer-related liabilities.

[0001728949-19-000055:notes:42]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In the nine months ended June 30, 2019, we recognized revenues of $371 million that were recorded as unearned revenues at October 1, 2018.

[0001728949-19-000055:notes:43]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront. At June 30, 2019, we had $1.8 billion of remaining performance obligations, of which $129 million, $516 million, $436 million, $429 million and $195 million was expected to be recognized as revenues for the remainder of fiscal 2019 and each of the subsequent four years from fiscal 2020 through 2023, respectively, and $77 million thereafter.

[0001728949-19-000055:notes:44]
[same as prior period, unchanged from 0001728949-19-000036:notes:154]

[0001728949-19-000055:notes:45]
Prior to the adoption of the new accounting guidance in the first quarter of fiscal 2019, investments in non-marketable equity securities were recorded at cost less impairment, if any, with any losses resulting from an impairment recognized in investment and other income, net. Beginning in fiscal 2019, investments in non-marketable equity securities are recorded at cost, less impairments (if any), adjusted for observable price changes in orderly transactions for identical or similar securities (if any). All gains and losses on investments in non-marketable equity securities, realized and unrealized, are recognized in investment and other income, net.

[0001728949-19-000055:notes:46]
In addition, prior to adoption, we recorded impairment losses in earnings on investments in non-marketable equity securities when an impairment was considered other than temporary. Beginning in fiscal 2019, we record impairment losses in earnings when we believe an investment has experienced a decline in value.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-19-000055:notes:47]
[same as prior period, unchanged from 0001728949-19-000036:notes:17]

[0001728949-19-000055:notes:48]
| Accounts Receivable (in millions) |  |  |  |
|  | June 30, 2019 |  | September 30, 2018 |
| Trade, net of allowances for doubtful accounts of $47 and $56, respectively | $ | 1,036 |  |  | $ | 2,667 |  |
| Unbilled receivables | 1,332 |  |  | 201 |  |
| Other | 22 |  |  | 36 |  |
|  | $ | 2,390 |  |  | $ | 2,904 |  |

[0001728949-19-000055:notes:49]
The increase in unbilled receivables was primarily due to the adoption of ASC 606 (Note 1). Accounts receivable, trade at September 30, 2018 included approximately $960 million related to the short payment in the second quarter of fiscal 2017 of royalties reported by and deemed collectible from Apple’s contract manufacturers. This same amount was recorded in customer-related liabilities (in other current liabilities) for Apple, since we did not have the contractual right to offset these amounts. In the third quarter of fiscal 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties, and as a result, these amounts, as well as others, were settled (Note 6).

[0001728949-19-000055:notes:50]
| Inventories (in millions) |  |  |  |
|  | June 30, 2019 |  | September 30, 2018 |
| Raw materials | $ | 81 |  |  | $ | 72 |  |
| Work-in-process | 896 |  |  | 715 |  |
| Finished goods | 797 |  |  | 906 |  |
|  | $ | 1,774 |  |  | $ | 1,693 |  |

[0001728949-19-000055:notes:51]
[same as prior period, unchanged from 0001728949-19-000036:notes:21]

[0001728949-19-000055:notes:52]
|  | June 30, 2019 |  | September 30, 2018 |
| Equity method investments | $ | 330 |  |  | $ | 402 |  |
| Non-marketable equity investments | 800 |  |  | 650 |  |
|  | $ | 1,130 |  |  | $ | 1,052 |  |

[0001728949-19-000055:notes:53]
In the second quarter of fiscal 2019, non-marketable debt and equity securities (non-cash consideration) with an aggregate fair value of $98 million were received related to a development contract with one of our equity method investees, which was recognized as revenues in the second quarter of fiscal 2019. In addition, in the second quarter of fiscal 2019, non-marketable equity securities (non-cash consideration) with a fair value of $53 million were received in connection with the sale of certain assets as part of the Cost Plan (Note 8).

[0001728949-19-000055:notes:54]
| Other Current Liabilities (in millions) |  |  |  |
|  | June 30, 2019 |  | September 30, 2018 |
| Customer incentives and other customer-related liabilities | $ | 1,105 |  |  | $ | 3,500 |  |
| Accrual for EC fines (Note 6) | 1,430 |  |  | 1,167 |  |
| Income taxes payable | 668 |  |  | 453 |  |
| RF360 Holdings put and call option | 1,149 |  |  | 1,137 |  |
| Other | 373 |  |  | 721 |  |
|  | $ | 4,725 |  |  | $ | 6,978 |  |

[0001728949-19-000055:notes:55]
Beginning on August 4, 2019, for a period of 60 days, we have the option to acquire (and the minority owner has the option to sell) the minority ownership interest in the RF360 Holdings joint venture for $1.15 billion, and we expect one of such options to be exercised during this period. At June 30, 2019 and September 30, 2018, the accreted value of such amount was included in other current liabilities.

[0001728949-19-000055:notes:56]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in stockholders’ equity in the nine months ended June 30, 2019 were as follows (in millions):

[0001728949-19-000055:notes:57]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized (Loss) Gain on Derivative Instruments |  | Other Gains |  | Total Accumulated Other Comprehensive Income |
| Balance at September 30, 2018 | $ | 11 |  |  | $ | 23 |  |  | $ | 243 |  |  | $ | (13 | ) |  | $ | 1 |  |  | $ | 265 |  |
| Other comprehensive (loss) income before reclassifications | (27 | ) |  | — |  |  | (6 | ) |  | 23 |  |  | (5 | ) |  | (15 | ) |
| Reclassifications from accumulated other comprehensive income | 1 |  |  | — |  |  | (51 | ) |  | (5 | ) |  | — |  |  | (55 | ) |
| Other comprehensive (loss) income | (26 | ) |  | — |  |  | (57 | ) |  | 18 |  |  | (5 | ) |  | (70 | ) |
| Balance at June 30, 2019 | $ | (15 | ) |  | $ | 23 |  |  | $ | 186 |  |  | $ | 5 |  |  | $ | (4 | ) |  | $ | 195 |  |

[0001728949-19-000055:notes:58]
Reclassifications from accumulated other comprehensive income included adjustments of $51 million to the opening retained earnings balance as a result of the adoption of new accounting guidance in the first quarter of fiscal 2019 related to financial instruments and hedge instruments (Note 1). Reclassifications from accumulated other comprehensive income (excluding adjustments to opening retained earnings) related to available-for-sale securities were negligible in the three and nine months ended June 30, 2019 and June 24, 2018 and were recorded in investment and other income, net.

[0001728949-19-000055:notes:59]
Other Income, Costs and Expenses. Other expenses in the three months ended June 30, 2019 consisted of a $275 million charge related to the fine imposed by the European Commission (EC) related to the Icera complaint (2019 EC fine) (Note 6) and negligible net charges related to our Cost Plan. Other expenses in the nine months ended June 30, 2019 included $275 million related to the 2019 EC fine, $207 million in net restructuring and restructuring-related charges related to our Cost Plan, partially offset by a $43 million gain due to the partial recovery of a fine we previously paid to the Korea Fair Trade Commission (KFTC) and a $31 million gain related to a favorable legal settlement.

[0001728949-19-000055:notes:60]
Other expenses in the three and nine months ended June 24, 2018 consisted of $112 million and $422 million, respectively, in restructuring and restructuring-related charges related to our Cost Plan. Other expenses in the nine months ended June 24, 2018 also included a $1.2 billion charge related to an EC fine (2018 EC fine) (Note 6).

[0001728949-19-000055:notes:61]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | June 30, 2019 |  | June 24, 2018 |
| Interest and dividend income | $ | 81 |  |  | $ | 182 |  |  | $ | 237 |  |  | $ | 461 |  |
| Net gains on marketable securities | 326 |  |  | 10 |  |  | 293 |  |  | 24 |  |
| Net gains on other investments | 6 |  |  | 16 |  |  | 47 |  |  | 77 |  |
| Impairment losses on marketable securities and other investments | (42 | ) |  | (19 | ) |  | (111 | ) |  | (40 | ) |
| Net losses on derivative investments | — |  |  | (30 | ) |  | (10 | ) |  | (21 | ) |
| Equity in net losses of investees | (22 | ) |  | (28 | ) |  | (79 | ) |  | (67 | ) |
| Net (losses) gains on foreign currency transactions | (5 | ) |  | 112 |  |  | — |  |  | 20 |  |
|  | $ | 344 |  |  | $ | 243 |  |  | $ | 377 |  |  | $ | 454 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-19-000055:notes:62]
Income Taxes
The 2017 Tax Cuts and Jobs Act (the Tax Legislation), which was enacted during the first quarter of fiscal 2018, significantly revised the United States corporate income tax by, among other things, lowering the corporate income tax rate to 21% and imposing a one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge). The Tax Legislation fundamentally changed the taxation of multinational entities, including a shift from a system of worldwide taxation with deferral to a hybrid territorial system, featuring a participation exemption regime with current taxation of certain foreign income, a minimum tax on low-taxed foreign earnings and new measures to deter base erosion and promote U.S. production. As a fiscal-year taxpayer, certain provisions of the Tax Legislation became effective starting at the beginning of fiscal 2019, including GILTI (global intangible low-taxed income), a new tax on income of foreign corporations, BEAT (base-erosion and anti-abuse tax) and FDII (foreign-derived intangible income). In response to the Tax Legislation and to better align our profits with activities, we implemented certain tax restructuring in fiscal 2018 and 2019. As a result, beginning in fiscal 2019, substantially all of our income is in the U.S., of which a significant portion qualifies for preferential treatment as FDII at a 13% effective tax rate. The impact of GILTI and BEAT is negligible. Accordingly, our estimated annual effective tax rate for fiscal 2019 reflects the effects of these components of the Tax Legislation. Our annual effective tax rate for fiscal 2018 reflected a blended federal statutory rate of approximately 25%.

[0001728949-19-000055:notes:63]
As a result of the Tax Legislation, in fiscal 2019, several of our foreign subsidiaries made tax elections to be treated as U.S. branches for federal income tax purposes (commonly referred to as “check-the-box” elections) effective beginning in fiscal 2018 and 2019. Although beginning in fiscal 2019 the income of these entities will be included in our consolidated U.S. tax return, we believe that by treating these foreign subsidiaries as U.S. branches for federal income taxes, rather than controlled foreign corporations, we will significantly reduce the risk of being subject to GILTI and BEAT taxes. As a result of making these check-the-box elections, we recorded a tax benefit of $570 million in the first quarter of fiscal 2019 due to establishing new U.S. net deferred tax assets resulting from the difference between the GAAP basis and the U.S. federal tax carryover basis of the existing assets and liabilities of those foreign subsidiaries, primarily related to customer incentive liabilities that have not been deducted for tax purposes. Additionally, during fiscal 2018, one of our foreign subsidiaries distributed certain intellectual property to a U.S. subsidiary resulting in a difference between the GAAP basis and the U.S. federal tax basis of the distributed intellectual property. Upon adoption of new accounting guidance in the first quarter of fiscal 2019, we recorded a deferred tax asset of approximately $2.6 billion, primarily related to the distributed intellectual property, with an adjustment to opening retained earnings (Note 1). During the third quarter of fiscal 2019, the United States Treasury Department issued new temporary regulations that resulted in a change to the deductibility of dividend income received by a U.S. stockholder from a foreign corporation. As a result of this change, pursuant to an agreement with the Internal Revenue Service, we will forgo the federal tax basis step-up in such distributed intellectual property. Therefore, the related deferred tax asset was written-off, resulting in a $2.5 billion charge to income tax expense in the third quarter of fiscal 2019.

[0001728949-19-000055:notes:64]
We estimate our annual effective income tax rate to be 41% for fiscal 2019, which included the impact of the $2.5 billion charge recorded discretely in the third quarter to income tax expense resulting from the write-off of the deferred tax asset related to the distributed intellectual property and the impact of the tax benefit of $570 million recorded discretely in the first quarter due to establishing new U.S. net deferred tax assets from making certain check-the-box elections. The estimated annual effective tax rate for fiscal 2019 was also impacted by the 2019 EC fine recorded in the third quarter of fiscal 2019, which is not deductible for tax purposes, and also reflected benefits from our FDII deduction and research and development tax credits. The annual effective tax rate for fiscal 2018 was impacted by the combined effect of the Toll Charge, the remeasurement of deferred tax assets and liabilities and our decision to no longer indefinitely reinvest certain foreign earnings, all of which resulted from the Tax Legislation. The annual effective tax rate for fiscal 2018 was also impacted by the termination fee paid to NXP Semiconductors N.V. (NXP), the 2018 EC fine, settlement with the Taiwan Fair Trade Commission (TFTC), allocation of expenses to our U.S. operations and new Singapore tax incentives.

[0001728949-19-000055:notes:65]
The effective tax rate of 61% for the third quarter of fiscal 2019 was higher than the estimated annual effective tax rate of 41% primarily due to the $2.5 billion charge to income tax expense recorded discretely in the third quarter of fiscal 2019 resulting from the write-off of the deferred tax asset related to the distributed intellectual property. The estimated annual effective tax rate for fiscal 2019 was also impacted by the tax benefit of $570 million recorded discretely in the first quarter of fiscal 2019 due to establishing new U.S. net deferred tax assets from making certain check-the-box elections.

[0001728949-19-000055:notes:66]
Unrecognized tax benefits were $230 million and $217 million at June 30, 2019 and September 30, 2018, respectively. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at June 30, 2019 may increase or decrease in the next 12 months.

[0001728949-19-000055:notes:67]
The United States Treasury Department has issued proposed regulations on several provisions of the Tax Legislation, including foreign tax credits, FDII, BEAT and interest expense deduction limitations, which are expected to be finalized in the next several months. When finalized, these proposed regulations may adversely affect our provision for income taxes, results of operations and/or cash flows.

[0001728949-19-000055:notes:68]
We are subject to income taxes in the United States and numerous foreign jurisdictions and are currently under examination by various tax authorities worldwide, most notably in countries where we earn a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2000. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts giving rise to a revision become known. As of June 30, 2019, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-19-000055:notes:69]
Capital Stock
Stock Repurchase Program. On July 26, 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. The stock repurchase program has no expiration date.

[0001728949-19-000055:notes:70]
[same as prior period, unchanged from 0001728949-19-000036:notes:172]

[0001728949-19-000055:notes:71]
In the nine months ended June 30, 2019 and June 24, 2018, we repurchased and retired 17.7 million and 24.2 million shares for $1.1 billion and $1.4 billion, respectively, before commissions. To reflect share repurchases in the consolidated balance sheet, we (i) reduce common stock for the par value of the shares, (ii) reduce paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) record the residual amount to retained earnings, if any. At June 30, 2019, $7.8 billion remained authorized for repurchase under our stock repurchase program. 
Dividends. On July 24, 2019, we announced a cash dividend of $0.62 per share on our common stock, payable on September 26, 2019 to stockholders of record as of the close of business on September 12, 2019.


## us-gaap:DebtDisclosureTextBlock

[0001728949-19-000055:notes:72]
Debt
Revolving Credit Facility. We have an Amended and Restated Revolving Credit Facility (Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. Proceeds from the Revolving Credit Facility, if drawn, are expected to be used for general corporate purposes. Loans under the Revolving Credit Facility will bear interest, at our option, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the Revolving Credit Facility) or the Base Rate (determined in accordance with the Revolving Credit Facility), in each case plus an applicable margin based on our long-term unsecured senior, non-credit enhanced debt ratings. The margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.805% and 0.00%, respectively. The Revolving Credit Facility has a facility fee, which accrues at a rate of 0.07% per annum. At June 30, 2019 and September 30, 2018, we had not borrowed any funds under the Revolving Credit Facility.

[0001728949-19-000055:notes:73]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At June 30, 2019 and September 30, 2018, we had $998 million and $1.0 billion, respectively, of outstanding commercial paper included in short-term debt with a weighted-average interest rate of 2.57% and 2.35%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 28 days and 16 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at June 30, 2019 and September 30, 2018.

[0001728949-19-000055:notes:74]
Long-term Debt. The following table provides a summary of our long-term debt (in millions, except percentages):

[0001728949-19-000055:notes:75]
|  |  | June 30, 2019 |  | September 30, 2018 |
|  |  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | $ | 250 |  |  | 3.13% |  | $ | 250 |  |  | 2.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 2.84% |  | 1,750 |  |  | 3.13% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 3.16% |  | 2,000 |  |  | 3.73% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.73% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.72% |  | 1,500 |  |  | 4.72% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 3.38% |  | 500 |  |  | 3.14% |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | 1,500 |  |  | 2.70% |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | 1,500 |  |  | 3.01% |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.47% |  | 1,500 |  |  | 4.47% |
|  | Total principal | 15,500 |  |  |  |  | 15,500 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (77 | ) |  |  |  | (85 | ) |  |  |
|  | Hedge accounting fair value adjustments | 5 |  |  |  |  | (50 | ) |  |  |
|  | Total long-term debt | $ | 15,428 |  |  |  |  | $ | 15,365 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | 2,002 |  |  |  |  | $ | — |  |  |  |
|  | Long-term debt | 13,426 |  |  |  |  | 15,365 |  |  |  |
|  | Total | $ | 15,428 |  |  |  |  | $ | 15,365 |  |  |  |

[0001728949-19-000055:notes:76]
At June 30, 2019 and September 30, 2018, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $16.1 billion and $15.1 billion, respectively.

[0001728949-19-000055:notes:77]
We may redeem the outstanding fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. We may not redeem the outstanding floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of our other senior unsecured indebtedness and will effectively rank junior to all liabilities of our subsidiaries.

[0001728949-19-000055:notes:78]
At June 30, 2019, we had outstanding interest rate swaps with an aggregate notional amount of $1.8 billion related to the May 2015 Notes, which effectively converted approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recorded as interest expense in the current period. We did not enter into interest rate swaps in connection with issuance of the May 2017 Notes.

[0001728949-19-000055:notes:79]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to our commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $516 million and $594 million in the nine months ended June 30, 2019 and June 24, 2018, respectively.

[0001728949-19-000055:notes:80]
Debt Covenants. The Revolving Credit Facility requires that we comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. We are not subject to any financial covenants under the notes nor any covenants that would prohibit us from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by us or our subsidiaries. At June 30, 2019 and September 30, 2018, we were in compliance with the applicable covenants under the Revolving Credit Facility.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-19-000055:notes:81]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0001728949-19-000055:notes:82]
Apple Inc. v. QUALCOMM Incorporated, QUALCOMM Incorporated v. Compal Electronics, Inc. et al. and QUALCOMM Incorporated v. Apple Inc.: On April 16, 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties. These matters and related financial guarantees either have been, or are in the process of being, dismissed or canceled.

[0001728949-19-000055:notes:83]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, a securities class action complaint was filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers. On April 29, 2016, the plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, the plaintiffs filed a second amended complaint, alleging that we and certain of our current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding our business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint sought unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, we filed a motion to dismiss the second amended complaint. On October 20, 2017, the court entered an order granting in part our motion to dismiss, and on November 29, 2017, the court entered an order granting the remaining portions of our motion to dismiss. On December 28, 2017, the plaintiffs filed an appeal to the United States Court of Appeals for the Ninth Circuit. A hearing was held on July 11, 2019, and on July 23, 2019, the United States Court of Appeals for the Ninth Circuit affirmed the District Court’s dismissal of the second amended complaint in its entirety.

[0001728949-19-000055:notes:84]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss the complaint. Discovery has commenced and is scheduled to be completed by March 3, 2020. We believe the plaintiffs’ claims are without merit.

[0001728949-19-000055:notes:85]
In re Qualcomm/Broadcom Merger Securities Litigation (formerly Camp v. Qualcomm Incorporated et al): On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints allege, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints seek unspecified damages, interest, fees and costs. On January 22, 2019, the Court appointed the lead plaintiff in the action and designated that the case be captioned “In re Qualcomm/Broadcom Merger Securities Litigation.” On March 18, 2019, the plaintiffs filed a consolidated complaint. On May 10, 2019, we filed a motion to dismiss the consolidated complaint. A hearing on our motion to dismiss is scheduled for September 19, 2019. We believe the plaintiffs’ claims are without merit.

[0001728949-19-000055:notes:86]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Twenty-two such cases remain outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion,

[0001728949-19-000055:notes:87]
except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the Ninth Circuit Court of Appeals granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. We believe the plaintiffs’ claims are without merit.

[0001728949-19-000055:notes:88]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, eight consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the U.S. consumer class action complaint. The complaints seek unspecified damages. One of the complaints in the Supreme Court of British Columbia has since been discontinued by the plaintiffs. We have not yet answered the complaints. On April 15, 2019, the Quebec Superior Court held a class certification hearing, and on April 30, 2019, the court issued an order certifying a class. We believe the plaintiffs’ claims are without merit.

[0001728949-19-000055:notes:89]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that we violated Korean law by offering certain discounts and rebates for purchases of our CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents expired. The KFTC levied a fine of 273.2 billion Korean won (approximately $230 million), which we recorded as an expense in fiscal 2009 and paid in fiscal 2010. We appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, we filed an appeal with the Korea Supreme Court. On January 31, 2019, the Korea Supreme Court reversed in part the decision of the Seoul High Court and remanded the case for further proceedings consistent with its decision. In March 2019, the KFTC refunded $56 million (including interest) to us, representing a portion of the fine we previously paid to the KFTC. In the second quarter of fiscal 2019, we recorded a gain of $43 million in other income and interest income of $13 million in investment and other income, net. In light of the Korea Supreme Court’s reversal in part of the decision of the Seoul High Court and the refund we received from the KFTC, on May 8, 2019, we filed to withdraw the case from the Seoul High Court. On May 19, 2019, the KFTC filed its consent to our withdrawal, ending the case as of that date.

[0001728949-19-000055:notes:90]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (iii) not demand unjustifiable conditions in our license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred to in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred to in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean Won (approximately $927 million), which we paid on March 30, 2017. We believe that our business practices do not violate the MRFTA, and on February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. On the same day, we filed an application with the Seoul High Court to stay the decision’s remedial order pending the Seoul High Court’s final judgment on our action to cancel the KFTC’s decision. On September 4, 2017, the Seoul High Court denied our application to stay the remedial order, and on November 27, 2017, the Korea Supreme Court dismissed our appeal of the Seoul High Court’s decision on the application to stay. Hearings on our action to cancel the KFTC’s decision are scheduled to be held before the Seoul High Court on August 12 and 14, 2019. Under the current procedural plan of the Seoul High Court, we believe these will be the final hearings before that court issues its decision.

[0001728949-19-000055:notes:91]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, we were engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. On August 15, 2016, we submitted our response to the Statement of Objections. On July 19, 2018, the EC announced that it had issued a Supplementary Statement of Objections which focuses on certain elements of the “price-cost” test applied by the EC to assess the extent to which we sold certain baseband chipsets allegedly below cost. On October 22, 2018, we submitted our response to the Supplementary Statement of Objections. On January 10, 2019, the EC held a hearing regarding the Supplementary Statement of Objections and our response to it. On July 18, 2019, the EC issued a decision confirming their preliminary view that between 2009 and 2011 we engaged in predatory pricing with respect to two customers and imposed a fine of approximately 242 million Euros (approximately $275 million based on the exchange rate at June 30, 2019), which was recorded as a charge to other expenses in the third quarter of fiscal 2019. We intend to file an appeal of the EC’s decision with the General Court of the European Union. We intend to provide financial guarantees to satisfy the obligation in lieu of a cash payment during our appeal. We believe that our business practices do not violate the EU competition rules.

[0001728949-19-000055:notes:92]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that, pursuant to an agreement with Apple Inc., since 2011, we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets. This conduct allegedly reduced Apple’s incentives to source baseband chipsets from our competitors and harmed competition and innovation for certain baseband chipsets. On January 24, 2018, the EC issued a decision finding that certain terms of that agreement violate EU competition law and imposed a fine of 997 million Euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the EU competition rules.

[0001728949-19-000055:notes:93]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to such EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. As of October 1, 2018, we have designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At June 30, 2019, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.16 billion and included in other current liabilities.

[0001728949-19-000055:notes:94]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of cellular modem chipsets on the purchaser first agreeing to a license to our cellular standard-essential patents, paying incentives to purchasers of cellular modem chipsets to induce them to accept certain license terms, refusing to license our cellular standard-essential patents to our competitors, and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint sought a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief.

[0001728949-19-000055:notes:95]
On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to rival sellers of cellular modem chipsets. On November 6, 2018, the court granted the FTC’s partial summary judgment motion. Trial was held January 4-29, 2019.

[0001728949-19-000055:notes:96]
On May 21, 2019, the court issued an Order setting forth its Findings of Fact and Conclusions of Law. The court concluded that we had monopoly power in the CDMA and premium-tier LTE cellular modem chip markets, and that we had used that power in these two markets to engage in anticompetitive acts, including (1) using threats of lack of access to cellular modem chip supply to coerce OEMs to accept license terms that include unreasonably high royalty rates; (2) refusing to license our cellular standard-essential patents to competitors selling cellular modem chips; and (3) entering into exclusive

[0001728949-19-000055:notes:97]
dealing arrangements with OEMs that foreclosed our rivals. The court further found that the royalties we charge OEMs are unreasonably high and reflect the use of our monopoly power over CDMA and premium-tier LTE cellular modem chips rather than just the value of our patents. The court concluded that our unreasonably high royalties constitute an anticompetitive surcharge on cellular modem chips sold by our competitors, which increases the effective price of our competitors’ cellular modem chips, reduces their margins and results in exclusivity. The court also found that our practice of not licensing competitors’ cellular modem chips violated our commitments to certain standard-development organizations and a duty under the antitrust laws to license competing cellular modem chip makers and helped us maintain our royalties at unreasonably high levels. Finally, the court found that incentive funds entered into with certain OEMs further harmed competing cellular modem chip makers’ ability to undermine our monopoly position, prevented rivals from entering the market and restricted the sales of those competitors that do enter. The court concluded that the combined effect of our conduct, together with our monopoly power, harmed the competitive process.

[0001728949-19-000055:notes:98]
The court imposed the following injunctive relief: (1) we must not condition the supply of cellular modem chips on a customer’s patent license status, and we must negotiate or renegotiate license terms with customers in good faith under conditions free from the threat of lack of access to or discriminatory provision of cellular modem chip supply or associated technical support or access to software; (2) we must make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers on fair, reasonable and non-discriminatory (FRAND) terms and submit, as necessary, to arbitral or judicial dispute resolution to determine such terms; (3) we may not enter into express or de facto exclusive dealing agreements for the supply of cellular modem chips; and (4) we may not interfere with the ability of any customer to communicate with a government agency about a potential law enforcement or regulatory matter. The court also ordered us to submit to compliance and monitoring procedures for a period of seven years and to report to the FTC on an annual basis regarding our compliance with the above remedies.

[0001728949-19-000055:notes:99]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. Accordingly, on May 28, 2019, we filed a Motion to Stay Pending Appeal in the court, which was denied on July 3, 2019. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On July 10, 2019, the Ninth Circuit granted our Motion to Expedite Appeal, and we expect briefing to be completed before the end of the calendar year. The Partial Stay motion is pending.

[0001728949-19-000055:notes:100]
Contingent losses and other considerations: We will continue to vigorously defend ourself in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at June 30, 2019 for contingent losses associated with these matters based on our belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0001728949-19-000055:notes:101]
Indemnifications. We generally do not indemnify our customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by us, or by intellectual property provided by us to chipset foundries and semiconductor assembly and test service providers. Our obligations under these agreements may be limited in terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us.

[0001728949-19-000055:notes:102]
Through June 30, 2019, we have received a number of claims from our direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by our products. Reimbursements under indemnification arrangements have not been material to our consolidated financial statements. We have not recorded any accrual for contingent liabilities at June 30, 2019 associated with these indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001728949-19-000055:notes:103]
Purchase Obligations and Operating Leases. We have agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe,

[0001728949-19-000055:notes:104]
assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization. We lease certain of our land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 15 years and with provisions in certain leases for cost-of-living increases.

[0001728949-19-000055:notes:105]
Obligations under our purchase agreements, which primarily relate to integrated circuit product inventory obligations, and future minimum lease payments under our operating leases at June 30, 2019 were as follows (in millions):

[0001728949-19-000055:notes:106]
|  | Purchase Obligations |  | Operating Leases |
| Remainder of fiscal 2019 | $ | 2,249 |  |  | $ | 42 |  |
| 2020 | 890 |  |  | 123 |  |
| 2021 | 308 |  |  | 95 |  |
| 2022 | 111 |  |  | 66 |  |
| 2023 | 53 |  |  | 28 |  |
| Thereafter | 17 |  |  | 45 |  |
| Total | $ | 3,628 |  |  | $ | 399 |  |

[0001728949-19-000055:notes:107]
Other Commitments. At June 30, 2019, we committed to fund certain strategic investments up to $194 million, of which $30 million is expected to be funded in the remainder of fiscal 2019. The remaining commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-19-000055:notes:108]
Segment Information
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices, wireless networks, devices used in the Internet of Things (IoT), broadband gateway equipment, consumer electronic devices and automotive telematics and infotainment systems. QTL grants licenses to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an equity method investee. We also have nonreportable segments, including Qualcomm Government Technologies or QGOV (formerly Qualcomm Cyber Security Solutions) and other wireless technology and service initiatives.

[0001728949-19-000055:notes:109]
We evaluate the performance of our segments based on earnings (loss) before income taxes (EBT). In fiscal 2018, all of the costs related to pre-commercial research and development of 5G technologies, of which we recorded $124 million and $340 million in the third quarter and first nine months of fiscal 2018, respectively, were included in unallocated corporate research and development expenses. Beginning in the first quarter of fiscal 2019, all research and development costs associated with 5G technologies are included in segment results. Additionally, beginning in the first quarter of fiscal 2019, certain research and development costs associated with early research and development that were historically included in our QCT segment are allocated to our QTL segment. The net effect of these changes negatively impacted QTL’s EBT by $127 million and $368 million in the third quarter and first nine months of fiscal 2019, respectively. QCT’s EBT was positively impacted by $53 million and $97 million in the third quarter and first nine months of fiscal 2019, respectively.

[0001728949-19-000055:notes:110]
[same as prior period, unchanged from 0001728949-19-000036:notes:169]

[0001728949-19-000055:notes:111]
The table below presents revenues, EBT and total assets for reportable segments (in millions):

[0001728949-19-000055:notes:112]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | June 30, 2019 |  | June 24, 2018 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 3,567 |  |  | $ | 4,087 |  |  | $ | 11,028 |  |  | $ | 12,635 |  |
| QTL | 1,292 |  |  | 1,443 |  |  | 3,433 |  |  | 3,930 |  |
| QSI | 18 |  |  | 20 |  |  | 143 |  |  | 80 |  |
| Reconciling items | 4,758 |  |  | 27 |  |  | 4,855 |  |  | 188 |  |
| Total | $ | 9,635 |  |  | $ | 5,577 |  |  | $ | 19,459 |  |  | $ | 16,833 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 504 |  |  | $ | 607 |  |  | $ | 1,644 |  |  | $ | 2,170 |  |
| QTL | 898 |  |  | 1,027 |  |  | 2,162 |  |  | 2,691 |  |
| QSI | 312 |  |  | (7 | ) |  | 337 |  |  | 44 |  |
| Reconciling items | 3,787 |  |  | (693 | ) |  | 2,724 |  |  | (3,712 | ) |
| Total | $ | 5,501 |  |  | $ | 934 |  |  | $ | 6,867 |  |  | $ | 1,193 |  |

[0001728949-19-000055:notes:113]
|  | June 30, 2019 |  | September 30, 2018 |
| Assets |  |  |  |
| QCT | $ | 2,608 |  |  | $ | 3,041 |  |
| QTL | 1,535 |  |  | 1,472 |  |
| QSI | 1,703 |  |  | 1,279 |  |
| Reconciling items | 28,287 |  |  | 26,926 |  |
| Total | $ | 34,133 |  |  | $ | 32,718 |  |

[0001728949-19-000055:notes:114]
Reconciling items for revenues and EBT in the previous table were as follows (in millions):

[0001728949-19-000055:notes:115]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | June 30, 2019 |  | June 24, 2018 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 35 |  |  | $ | 77 |  |  | $ | 132 |  |  | $ | 238 |  |
| Other unallocated revenues | 4,723 |  |  | (50 | ) |  | 4,723 |  |  | (50 | ) |
|  | $ | 4,758 |  |  | $ | 27 |  |  | $ | 4,855 |  |  | $ | 188 |  |
| EBT |  |  |  |  |  |  |  |
| Other unallocated revenues | $ | 4,723 |  |  | $ | (50 | ) |  | $ | 4,723 |  |  | $ | (50 | ) |
| Unallocated cost of revenues | (103 | ) |  | (135 | ) |  | (321 | ) |  | (362 | ) |
| Unallocated research and development expenses | (307 | ) |  | (293 | ) |  | (645 | ) |  | (844 | ) |
| Unallocated selling, general and administrative expenses | (139 | ) |  | (60 | ) |  | (285 | ) |  | (480 | ) |
| Unallocated other expenses (Note 2) | (277 | ) |  | (112 | ) |  | (408 | ) |  | (1,605 | ) |
| Unallocated interest expense | (158 | ) |  | (208 | ) |  | (471 | ) |  | (556 | ) |
| Unallocated investment and other income, net | 58 |  |  | 255 |  |  | 188 |  |  | 461 |  |
| Nonreportable segments | (10 | ) |  | (90 | ) |  | (57 | ) |  | (276 | ) |
|  | $ | 3,787 |  |  | $ | (693 | ) |  | $ | 2,724 |  |  | $ | (3,712 | ) |

[0001728949-19-000055:notes:116]
Other unallocated revenues in the three and nine months ended June 30, 2019 were comprised of licensing revenues resulting from the settlement with Apple and its contract manufacturers (Note 6) and were not allocated to our segments in our management reports because they were not considered in evaluating segment results.

[0001728949-19-000055:notes:117]
Unallocated acquisition-related expenses were comprised as follows (in millions):

[0001728949-19-000055:notes:118]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | June 30, 2019 |  | June 24, 2018 |
| Cost of revenues | $ | 96 |  |  | $ | 127 |  |  | $ | 298 |  |  | $ | 335 |  |
| Research and development expenses | 1 |  |  | 2 |  |  | 3 |  |  | 5 |  |
| Selling, general and administrative expenses | 9 |  |  | 20 |  |  | 22 |  |  | 310 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001728949-19-000055:notes:119]
Cost Plan
In the second quarter of fiscal 2018, we announced a Cost Plan designed to align our cost structure to our long-term margin targets. As part of this plan, we initiated a series of targeted actions across our businesses with the objective to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. Actions taken under this plan have been completed and have resulted in us achieving substantially all of this target in fiscal 2019 based on our run rate exiting the second quarter of fiscal 2019, excluding litigation costs that are in excess of the baseline spend.

[0001728949-19-000055:notes:120]
During the nine months ended June 30, 2019, we recorded net restructuring and restructuring-related charges related to our Cost Plan of $207 million in other expenses. This consisted of restructuring-related charges of $151 million, primarily related to asset impairment charges (and included a $52 million net gain from the sale of certain assets related to wireless electric vehicle charging applications and the sale of our mobile health nonreportable segment), and restructuring charges of $56 million, primarily related to severance and consulting costs. Since inception of the Cost Plan, we have incurred a total of $894 million in net restructuring and restructuring-related charges. The remaining restructuring and restructuring-related charges to be incurred related to the plan are expected to be negligible.

[0001728949-19-000055:notes:121]
The restructuring accrual, a portion of which was included in payroll and other benefits related liabilities with the remainder included in other current liabilities, is expected to be substantially paid within the next 12 months. At June 30, 2019 and September 30, 2018, the restructuring accrual was $21 million and $83 million, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-19-000055:notes:122]
Fair Value Measurements
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at June 30, 2019 (in millions):

[0001728949-19-000055:notes:123]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 8,135 |  |  | $ | 4,000 |  |  | $ | — |  |  | $ | 12,135 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 19 |  |  | — |  |  | 19 |  |
| Auction rate securities | — |  |  | — |  |  | 35 |  |  | 35 |  |
| Equity securities | 417 |  |  | — |  |  | — |  |  | 417 |  |
| Total marketable securities | 417 |  |  | 19 |  |  | 35 |  |  | 471 |  |
| Derivative instruments | — |  |  | 19 |  |  | — |  |  | 19 |  |
| Other investments | 415 |  |  | — |  |  | 64 |  |  | 479 |  |
| Total assets measured at fair value | $ | 8,967 |  |  | $ | 4,038 |  |  | $ | 99 |  |  | $ | 13,104 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Other liabilities | 415 |  |  | — |  |  | 41 |  |  | 456 |  |
| Total liabilities measured at fair value | $ | 415 |  |  | $ | 4 |  |  | $ | 41 |  |  | $ | 460 |  |

[0001728949-19-000055:notes:124]
Activity between Levels of the Fair Value Hierarchy. There were no transfers of marketable securities into or out of Level 3 during the nine months ended June 30, 2019 and June 24, 2018. Other investments and other liabilities included in

[0001728949-19-000055:notes:125]
Level 3 at June 30, 2019 were comprised of debt instruments issued by private companies and contingent consideration related to business combinations, respectively. There were no transfers of debt instruments or contingent consideration amounts into or out of Level 3 during the nine months ended June 30, 2019 and June 24, 2018. 
Assets Measured and Recorded at Fair Value on a Nonrecurring Basis. During the nine months ended June 30, 2019, certain intangible assets and goodwill were written down to their estimated fair values (Note 8). We also measured certain non-marketable equity securities received as non-cash consideration at fair value on a nonrecurring basis (Note 2). The estimation of fair value required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During the nine months ended June 30, 2019 and June 24, 2018, we did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-19-000055:notes:126]
Marketable Securities
Our marketable securities were comprised as follows (in millions):

[0001728949-19-000055:notes:127]
|  | Current |  | Noncurrent (1) |
|  | June 30, 2019 |  | September 30, 2018 |  | June 30, 2019 |  | September 30, 2018 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 19 |  |  | $ | 144 |  |  | $ | — |  |  | $ | — |  |
| Auction rate securities | — |  |  | — |  |  | 35 |  |  | 35 |  |
| Total available-for-sale debt securities | 19 |  |  | 144 |  |  | 35 |  |  | 35 |  |
| Equity securities | 416 |  |  | 167 |  |  | 1 |  |  | — |  |
| Total marketable securities | $ | 435 |  |  | $ | 311 |  |  | $ | 36 |  |  | $ | 35 |  |

[0001728949-19-000055:notes:128]
(1) Noncurrent marketable securities were included in other assets.

[0001728949-19-000055:notes:129]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001728949-19-000055:notes:130]
|  | June 30, 2019 |
| Years to Maturity |  |
| Less than one year | $ | 19 |  |
| No single maturity date | 35 |  |
| Total | $ | 54 |  |

[0001728949-19-000055:notes:131]
Debt securities with no single maturity date included auction rate securities.
During the three and nine months ended June 30, 2019, there were no realized gains or losses on sales of available-for-sale debt securities, and during the three months ended June 24, 2018, gross realized gains and losses were negligible. During the nine months ended June 24, 2018, gross realized gains and losses were $15 million and negligible, respectively. As of June 30, 2019 and September 30, 2018, unrealized gains and losses on available-for-sale debt securities were negligible. As of September 30, 2018, available-for-sale securities also included equity securities with a fair value of $167 million, including an unrealized gain of $63 million.


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001728949-19-000055:notes:132]
Revision of Prior Period Financial Statements
We revised certain prior period financial statements for an immaterial error related to the recognition of certain royalty revenues of our QTL segment (Note 1). A summary of revisions to our previously reported financial statements presented herein for comparative purposes is included below (in millions, except per share data).

[0001728949-19-000055:notes:133]
Revised Consolidated Balance Sheet.

[0001728949-19-000055:notes:134]
|  | As of September 30, 2018 |
|  | As reported |  | Adjustment |  | As revised |
| Deferred tax assets (non-current) | $ | 904 |  |  | $ | 32 |  |  | $ | 936 |  |
| Total assets | 32,686 |  |  | 32 |  |  | 32,718 |  |
| Other current liabilities | 6,825 |  |  | 153 |  |  | 6,978 |  |
| Total current liabilities | 11,236 |  |  | 153 |  |  | 11,389 |  |
| Total liabilities | 31,758 |  |  | 153 |  |  | 31,911 |  |
| Retained earnings | 663 |  |  | (121 | ) |  | 542 |  |
| Total stockholders’ equity | 928 |  |  | (121 | ) |  | 807 |  |
| Total liabilities and stockholders’ equity | 32,686 |  |  | 32 |  |  | 32,718 |  |

[0001728949-19-000055:notes:135]
Revised Consolidated Statements of Operations.

[0001728949-19-000055:notes:136]
|  | Three Months Ended June 24, 2018 |  | Nine Months Ended June 24, 2018 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Licensing revenues | $ | 1,489 |  |  | $ | (22 | ) |  | $ | 1,467 |  |  | $ | 4,178 |  |  | $ | (95 | ) |  | $ | 4,083 |  |
| Total revenues | 5,599 |  |  | (22 | ) |  | 5,577 |  |  | 16,928 |  |  | (95 | ) |  | 16,833 |  |
| Operating income | 925 |  |  | (22 | ) |  | 903 |  |  | 1,395 |  |  | (95 | ) |  | 1,300 |  |
| Income before income taxes | 956 |  |  | (22 | ) |  | 934 |  |  | 1,288 |  |  | (95 | ) |  | 1,193 |  |
| Income tax benefit (expense) | 263 |  |  | 5 |  |  | 268 |  |  | (5,659 | ) |  | 15 |  |  | (5,644 | ) |
| Net income (loss) | 1,219 |  |  | (17 | ) |  | 1,202 |  |  | (4,371 | ) |  | (80 | ) |  | (4,451 | ) |
| Basic earnings (loss) per share | 0.82 |  |  | (0.01 | ) |  | 0.81 |  |  | (2.96 | ) |  | (0.05 | ) |  | (3.01 | ) |
| Diluted earnings (loss) per share | 0.82 |  |  | (0.01 | ) |  | 0.81 |  |  | (2.96 | ) |  | (0.05 | ) |  | (3.01 | ) |

[0001728949-19-000055:notes:137]
Revised Consolidated Statements of Comprehensive Income (Loss).

[0001728949-19-000055:notes:138]
|  | Three Months Ended June 24, 2018 |  | Nine Months Ended June 24, 2018 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Net income (loss) | $ | 1,219 |  |  | $ | (17 | ) |  | $ | 1,202 |  |  | $ | (4,371 | ) |  | $ | (80 | ) |  | $ | (4,451 | ) |
| Total comprehensive income (loss) | 997 |  |  | (17 | ) |  | 980 |  |  | (4,432 | ) |  | (80 | ) |  | (4,512 | ) |

[0001728949-19-000055:notes:139]
Revised Consolidated Statement of Cash Flows.

[0001728949-19-000055:notes:140]
We revised our condensed consolidated statement of cash flows for the nine months ended June 24, 2018 for this correction, which had no impact to net cash provided by operating activities in the period.

[0001728949-19-000055:notes:141]
|  | Nine Months Ended June 24, 2018 |
|  | As reported |  | Reclassification adjustment (1) |  | Revision adjustment |  | As revised |
| Operating Activities: |  |  |  |  |  |  |  |
| Net loss | $ | (4,371 | ) |  | $ | — |  |  | $ | (80 | ) |  | $ | (4,451 | ) |
| Income tax provision in excess of (less than) income tax payments | 4,973 |  |  | — |  |  | (15 | ) |  | 4,958 |  |
| Other items, net | 25 |  |  | (71 | ) |  | — |  |  | (46 | ) |
| Other assets | 90 |  |  | (18 | ) |  | — |  |  | 72 |  |
| Payroll, benefits and other liabilities | 1,514 |  |  | 89 |  |  | 95 |  |  | 1,698 |  |
| Net cash provided by operating activities | 4,331 |  |  | — |  |  | — |  |  | 4,331 |  |

[0001728949-19-000055:notes:142]
(1) Certain previously reported amounts have been reclassified to conform to the current year presentation.

[0001728949-19-000055:notes:143]
Revised Segment Information. 
QTL segment results were revised for this correction (Note 7), which resulted in a decrease in QTL revenues and EBT (earnings before income taxes) of $22 million and $95 million for the three and nine months ended June 24, 2018, respectively.
