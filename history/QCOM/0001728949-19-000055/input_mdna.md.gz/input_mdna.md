# QCOM MD&A — 0001728949-19-000055


## mdna

[0001728949-19-000055:mdna:1]
[same as prior period, unchanged from 0001728949-19-000036:mdna:1]

[0001728949-19-000055:mdna:2]
[same as prior period, unchanged from 0001728949-19-000036:mdna:2]

[0001728949-19-000055:mdna:3]
This Quarterly Report (including, but not limited to, this section regarding Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements regarding our business, investments, financial condition, results of operations and prospects. Additionally, statements concerning future matters that are not historical are forward-looking statements, such as statements regarding our expectations concerning: industry, market, business, commercial, competitive or consumer trends; our businesses, growth potential or strategies, or factors that may impact them; challenges to our licensing business, including by licensees, customers, governments, governmental agencies or regulators, standards bodies or others; other legal or regulatory matters; competition; product or technology trends; new or expanded product areas, adjacent industry segments or applications; costs or expenditures including research and development, selling, general and administrative, restructuring or restructuring-related charges, working capital or information technology systems; our financing, stock repurchase or dividend programs; strategic investments or acquisitions; adoption and application of future accounting guidance; tax law changes; our tax structure or strategies; or the potential business or financial statement impacts of any of the above. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001728949-19-000055:mdna:4]
Third Quarter Fiscal 2019 Overview and Other Recent Events

[0001728949-19-000055:mdna:5]
Revenues for the third quarter of fiscal 2019 were $9.6 billion, an increase of 73% compared to the year ago quarter, with net income of $2.1 billion, an increase of 79% compared to the year ago quarter. Highlights and other events from the third quarter of fiscal 2019 and other recent events included:

[0001728949-19-000055:mdna:6]
| • | On April 16, 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties. We also entered into a six-year global patent license agreement with Apple, effective as of April 1, 2019, which includes an option for Apple to extend for two additional years, and a multi-year chipset supply agreement with Apple. In the third quarter of fiscal 2019, we recognized licensing revenues of $4.7 billion resulting from the settlement, consisting of a payment from Apple and the release of certain of our obligations to pay Apple and its contract manufacturers customer-related liabilities. In addition, our QTL results for the third quarter of fiscal 2019 included royalties from Apple and its contract manufacturers for sales made in the June 2019 quarter. |

[0001728949-19-000055:mdna:7]
| • | On May 21, 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief. We disagree with the court’s conclusions, interpretation of the facts and application of the law. Accordingly, we have filed a motion to stay certain of the remedies with, and have appealed the decision to, the Ninth Circuit Court of Appeals. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” in this Quarterly Report. The impact of the ruling was not material to QTL licensing revenues in the third quarter of fiscal 2019 based on facts and factors currently known by us. |

[0001728949-19-000055:mdna:8]
| • | The transition of wireless networks and devices to 3G/4G (CDMA-single mode, OFDMA-single mode and CDMA/OFDMA multi-mode) continued around the world. 3G/4G connections grew sequentially by approximately 2% to |

[0001728949-19-000055:mdna:9]
30

[0001728949-19-000055:mdna:10]
approximately 5.8 billion, which was approximately 74% of total mobile connections at the end of the third quarter of fiscal 2019.(1)

[0001728949-19-000055:mdna:11]
| • | We continued to invest significant resources toward advancements primarily in support of 4G- and 5G-based technologies as well as other technologies to extend the demand for our products and generate new or expanded licensing opportunities, including within adjacent industry segments outside traditional cellular industries, such as automotive, the Internet of Things (IoT) and networking. |

[0001728949-19-000055:mdna:12]
| • | QCT results in the third quarter of fiscal 2019 were negatively impacted by lower modem sales to Apple and a decline in demand from OEMs in China. |

[0001728949-19-000055:mdna:13]
| • | We adopted new revenue recognition accounting guidance in the first quarter of fiscal 2019 that requires us to estimate and recognize QTL royalties in the period in which the associated sales occur, resulting in an acceleration of royalty revenues by one quarter compared to the prior method. As a result of recognizing royalties using estimates, adjustments are recorded in subsequent quarters to reflect changes in estimates as new information becomes available, primarily when actual amounts are reported by licensees. Prior period results have not been restated for the adoption of the new accounting guidance and continue to be reported in accordance with the accounting guidance in effect for those periods. |

[0001728949-19-000055:mdna:14]
| • | During the third quarter of fiscal 2019, the United States Treasury Department issued new temporary regulations that resulted in a change to the deductibility of dividend income received by a U.S. stockholder from a foreign corporation. As a result of this change, pursuant to an agreement with the Internal Revenue Service, we will forgo the federal tax basis step-up of intellectual property that was distributed in fiscal 2018 by one of our foreign subsidiaries to a U.S. subsidiary. Therefore, the related deferred tax asset previously recognized was written-off, resulting in a $2.5 billion charge to income tax expense in the third quarter of fiscal 2019. See “Notes to Condensed Consolidated Financial Statements, Note 1. Basis of Presentation and Significant Accounting Policies Update” in this Quarterly Report. |

[0001728949-19-000055:mdna:15]
| • | On July 18, 2019, the European Commission (EC) issued a decision ruling that between 2009 and 2011 we engaged in predatory pricing with respect to two customers and imposed a fine (2019 EC fine) of approximately 242 million Euros (approximately $275 million based on the exchange rate at June 30, 2019), which was recorded as a charge to other expenses in the third quarter of fiscal 2019. We intend to file an appeal of the EC’s decision with the General Court of the European Union. |

[0001728949-19-000055:mdna:16]
| (1) | According to GSMA Intelligence estimates as of July 29, 2019 (estimates excluded Wireless Local Loop). |

[0001728949-19-000055:mdna:17]
[same as prior period, unchanged from 0001728949-19-000036:mdna:15]

[0001728949-19-000055:mdna:18]
We develop and commercialize foundational technologies and products used in mobile devices and other wireless products, including network equipment, broadband gateway equipment and consumer electronic devices. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents, software and other rights.

[0001728949-19-000055:mdna:19]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices, wireless networks, devices used in IoT, broadband gateway equipment, consumer electronic devices and automotive telematics and infotainment systems. QTL grants licenses to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including Qualcomm Government Technologies or QGOV (formerly Qualcomm Cyber Security Solutions) and other wireless technology and service initiatives.

[0001728949-19-000055:mdna:20]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering, research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001728949-19-000055:mdna:21]
Seasonality. Many of our products and/or much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has historically tended to have

[0001728949-19-000055:mdna:22]
31

[0001728949-19-000055:mdna:23]
stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons and due to the timing of Apple’s device launch in the fall. Similarly, because QTL historically has recognized royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made in the fourth calendar quarter. These trends did not occur in the first nine months of fiscal 2019 due to QCT’s decline in share of modem sales for iPhone products and the lack of QTL royalty revenues recognized related to the sales of Apple’s products in the first six months of fiscal 2019 resulting from our prior dispute with Apple and its contract manufacturers. These trends may or may not continue in the future. Additionally, QTL’s revenues have been impacted by the adoption of the new revenue recognition guidance in fiscal 2019 pursuant to which we estimate and recognize sales-based royalties in the period in which the associated sales occur, resulting in an acceleration of royalty revenue recognition by one quarter compared to the prior method. The trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings, including the lawsuit filed against us by the FTC.

[0001728949-19-000055:mdna:24]
We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 4G networks by wireless operators and the timing of launches of flagship wireless devices and consumer demand for wireless devices that incorporate our products and/or intellectual property. These trends may or may not continue in the future, including as a result of 5G network deployments and flagship device launches.

[0001728949-19-000055:mdna:25]
[same as prior period, unchanged from 0001728949-19-000036:mdna:22]

[0001728949-19-000055:mdna:26]
| Revenues (in millions) |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | Change |  | June 30, 2019 |  | June 24, 2018 |  | Change |
| Equipment and services | $ | 3,531 |  |  | $ | 4,110 |  |  | $ | (579 | ) |  | $ | 11,037 |  |  | $ | 12,750 |  |  | $ | (1,713 | ) |
| Licensing | 6,104 |  |  | 1,467 |  |  | 4,637 |  |  | 8,422 |  |  | 4,083 |  |  | 4,339 |  |
|  | $ | 9,635 |  |  | $ | 5,577 |  |  | $ | 4,058 |  |  | $ | 19,459 |  |  | $ | 16,833 |  |  | $ | 2,626 |  |

[0001728949-19-000055:mdna:27]
Third quarter 2019 vs. 2018

[0001728949-19-000055:mdna:28]
The increase in revenues in the third quarter of fiscal 2019 was primarily due to:

[0001728949-19-000055:mdna:29]
| + | $4.7 billion in licensing revenues recorded in the third quarter of fiscal 2019 resulting from the settlement with Apple and its contract manufacturers (which were not allocated to our segment results) |

[0001728949-19-000055:mdna:30]
| - | $554 million in lower equipment and services revenues from our QCT segment |

[0001728949-19-000055:mdna:31]
| - | $151 million in lower licensing revenues from our QTL segment |

[0001728949-19-000055:mdna:32]
First nine months 2019 vs. 2018

[0001728949-19-000055:mdna:33]
The increase in revenues in the first nine months of fiscal 2019 was primarily due to:

[0001728949-19-000055:mdna:34]
| + | $4.7 billion in licensing revenues recorded in the third quarter of fiscal 2019 resulting from the settlement with Apple and its contract manufacturers |

[0001728949-19-000055:mdna:35]
| - | $1.7 billion in lower equipment and services revenues from our QCT segment |

[0001728949-19-000055:mdna:36]
| - | $497 million in lower licensing revenues from our QTL segment |

[0001728949-19-000055:mdna:37]
| Costs and Expenses (in millions) |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | Change |  | June 30, 2019 |  | June 24, 2018 |  | Change |
| Cost of revenues | $ | 2,114 |  |  | $ | 2,491 |  |  | $ | (377 | ) |  | $ | 6,481 |  |  | $ | 7,394 |  |  | $ | (913 | ) |
| Gross margin | 78 | % |  | 55 | % |  |  |  | 67 | % |  | 56 | % |  |  |

[0001728949-19-000055:mdna:38]
Third quarter and first nine months 2019 vs. 2018

[0001728949-19-000055:mdna:39]
Gross margin percentage increased in the third quarter and first nine months of fiscal 2019 primarily due to:

[0001728949-19-000055:mdna:40]
| + | higher licensing revenues resulting from the settlement with Apple and its contract manufacturers in the third quarter of fiscal 2019 |

[0001728949-19-000055:mdna:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | Change |  | June 30, 2019 |  | June 24, 2018 |  | Change |
| Research and development | $ | 1,380 |  |  | $ | 1,416 |  |  | $ | (36 | ) |  | $ | 3,957 |  |  | $ | 4,237 |  |  | $ | (280 | ) |
| % of revenues | 14 | % |  | 25 | % |  |  |  | 20 | % |  | 25 | % |  |  |

[0001728949-19-000055:mdna:42]
Third quarter 2019 vs. 2018

[0001728949-19-000055:mdna:43]
The dollar decrease in research and development expenses in the third quarter of fiscal 2019 was primarily due to:

[0001728949-19-000055:mdna:44]
| - | $49 million decrease primarily driven by actions under our Cost Plan, partially offset by higher employee cash incentive program costs |

[0001728949-19-000055:mdna:45]
First nine months 2019 vs. 2018

[0001728949-19-000055:mdna:46]
The dollar decrease in research and development expenses in the first nine months of fiscal 2019 was primarily due to:

[0001728949-19-000055:mdna:47]
| - | $293 million decrease primarily driven by actions under our Cost Plan, partially offset by higher costs related to the development of 5G wireless and integrated circuit technologies |

[0001728949-19-000055:mdna:48]
In fiscal 2018, all of the costs related to pre-commercial research and development of 5G technologies, of which we recorded $124 million and $340 million in the third quarter and first nine months of fiscal 2018, respectively, were included in unallocated corporate research and development expenses. Beginning in the first quarter of fiscal 2019, all research and development costs associated with 5G technologies are included in segment results. Additionally, beginning in the first quarter of fiscal 2019, certain research and development costs associated with early research and development that were historically included in our QCT segment are allocated to our QTL segment. The net effect of these changes negatively impacted QTL’s EBT by $127 million and $368 million in the third quarter and first nine months of fiscal 2019, respectively. QCT’s EBT was positively impacted by $53 million and $97 million in the third quarter and first nine months of fiscal 2019, respectively.

[0001728949-19-000055:mdna:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | Change |  | June 30, 2019 |  | June 24, 2018 |  | Change |
| Selling, general and administrative | $ | 547 |  |  | $ | 655 |  |  | $ | (108 | ) |  | $ | 1,646 |  |  | $ | 2,297 |  |  | $ | (651 | ) |
| % of revenues | 6 | % |  | 12 | % |  |  |  | 8 | % |  | 14 | % |  |  |

[0001728949-19-000055:mdna:50]
Third quarter 2019 vs. 2018

[0001728949-19-000055:mdna:51]
The dollar decrease in selling, general and administrative expenses in the third quarter of fiscal 2019 was primarily due to:

[0001728949-19-000055:mdna:52]
| - | $111 million in lower litigation costs, primarily resulting from the settlement agreements with Apple and its contract manufacturers |

[0001728949-19-000055:mdna:53]
First nine months 2019 vs. 2018

[0001728949-19-000055:mdna:54]
The dollar decrease in selling, general and administrative expenses in the first nine months of fiscal 2019 was primarily due to:

[0001728949-19-000055:mdna:55]
| - | $296 million in lower professional fees and costs, primarily driven by Broadcom’s withdrawn takeover proposal in fiscal 2018 and our proposed acquisition of NXP Semiconductors N.V. in fiscal 2018 |

[0001728949-19-000055:mdna:56]
| - | $140 million in lower litigation costs, primarily resulting from the settlement agreements with Apple and its contract manufacturers |

[0001728949-19-000055:mdna:57]
| - | $53 million in lower employee-related expenses, primarily driven by actions under our Cost Plan |

[0001728949-19-000055:mdna:58]
| - | $48 million in lower sales and marketing expenses |

[0001728949-19-000055:mdna:59]
[same as prior period, unchanged from 0001728949-19-000036:mdna:60]

[0001728949-19-000055:mdna:60]
Selling, general and administrative expenses included $50 million and $273 million in the third quarter and first nine months of fiscal 2019, respectively, related to litigation costs.

[0001728949-19-000055:mdna:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | Change |  | June 30, 2019 |  | June 24, 2018 |  | Change |
| Other | $ | 277 |  |  | $ | 112 |  |  | $ | 165 |  |  | $ | 408 |  |  | $ | 1,605 |  |  | $ | (1,197 | ) |

[0001728949-19-000055:mdna:62]
Third quarter 2019

[0001728949-19-000055:mdna:63]
Other expenses in the third quarter of fiscal 2019 consisted of:

[0001728949-19-000055:mdna:64]
+    $275 million charge related to the 2019 EC fine

[0001728949-19-000055:mdna:65]
+    $2 million in net restructuring and restructuring-related charges related to our Cost Plan

[0001728949-19-000055:mdna:66]
Third quarter 2018

[0001728949-19-000055:mdna:67]
Other expenses in the third quarter of fiscal 2018 consisted of:

[0001728949-19-000055:mdna:68]
+    $112 million in restructuring and restructuring-related charges related to our Cost Plan

[0001728949-19-000055:mdna:69]
First nine months 2019

[0001728949-19-000055:mdna:70]
Other expenses in the first nine months of fiscal 2019 consisted of:

[0001728949-19-000055:mdna:71]
+    $275 million charge related to the 2019 EC fine

[0001728949-19-000055:mdna:72]
| + | $207 million net charges related to our Cost Plan, which included $259 million in restructuring and restructuring-related charges, partially offset by a $52 million net gain from the sale of certain assets related to wireless electric vehicle charging applications and the sale of our mobile health nonreportable segment |

[0001728949-19-000055:mdna:73]
| - | $43 million gain recorded in the second quarter of fiscal 2019 due to the partial recovery of a fine imposed in fiscal 2009 resulting from our appeal of the KFTC decision |

[0001728949-19-000055:mdna:74]
-    $31 million gain recorded in the second quarter of fiscal 2019 related to a favorable legal settlement

[0001728949-19-000055:mdna:75]
First nine months 2018

[0001728949-19-000055:mdna:76]
Other expenses in the first nine months of fiscal 2018 consisted of:

[0001728949-19-000055:mdna:77]
+    $1.2 billion charge related to the 2018 EC fine

[0001728949-19-000055:mdna:78]
+    $422 million in restructuring and restructuring-related charges related to our Cost Plan

[0001728949-19-000055:mdna:79]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | Change |  | June 30, 2019 |  | June 24, 2018 |  | Change |
| Interest expense | $ | 160 |  |  | $ | 212 |  |  | $ | (52 | ) |  | $ | 477 |  |  | $ | 561 |  |  | $ | (84 | ) |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 81 |  |  | $ | 182 |  |  | $ | (101 | ) |  | $ | 237 |  |  | $ | 461 |  |  | $ | (224 | ) |
| Net gains on marketable securities | 326 |  |  | 10 |  |  | 316 |  |  | 293 |  |  | 24 |  |  | 269 |  |
| Net gains on other investments | 6 |  |  | 16 |  |  | (10 | ) |  | 47 |  |  | 77 |  |  | (30 | ) |
| Impairment losses on marketable securities and other investments | (42 | ) |  | (19 | ) |  | (23 | ) |  | (111 | ) |  | (40 | ) |  | (71 | ) |
| Net losses on derivative instruments | — |  |  | (30 | ) |  | 30 |  |  | (10 | ) |  | (21 | ) |  | 11 |  |
| Equity in net losses of investees | (22 | ) |  | (28 | ) |  | 6 |  |  | (79 | ) |  | (67 | ) |  | (12 | ) |
| Net (losses) gains on foreign currency transactions | (5 | ) |  | 112 |  |  | (117 | ) |  | — |  |  | 20 |  |  | (20 | ) |
|  | $ | 344 |  |  | $ | 243 |  |  | $ | 101 |  |  | $ | 377 |  |  | $ | 454 |  |  | $ | (77 | ) |

[0001728949-19-000055:mdna:80]
[same as prior period, unchanged from 0001728949-19-000036:mdna:82]

[0001728949-19-000055:mdna:81]
The increase in net gains on marketable securities in the three and nine months ended June 30, 2019 was primarily driven by a gain resulting from the initial public offering of one of our non-marketable equity investments.

[0001728949-19-000055:mdna:82]
34

[0001728949-19-000055:mdna:83]
| Income Tax Expense (Benefit) (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | Change |  | June 30, 2019 |  | June 24, 2018 |  | Change |
| Income tax expense (benefit) | $ | 3,352 |  |  | $ | (268 | ) |  | $ | 3,620 |  |  | $ | 2,987 |  |  | $ | 5,644 |  |  | $ | (2,657 | ) |
| Effective tax rate | 61 | % |  | (29 | %) |  | 90 | % |  | 43 | % |  | N/M |  |  | N/M |  |

[0001728949-19-000055:mdna:84]
[same as prior period, unchanged from 0001728949-19-000036:mdna:84]

[0001728949-19-000055:mdna:85]
[same as prior period, unchanged from 0001728949-19-000036:mdna:86]

[0001728949-19-000055:mdna:86]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | June 30, 2019 |  | June 24, 2018 |
| Expected income tax provision at federal statutory tax rate | $ | 1,155 |  |  | $ | 231 |  |  | $ | 1,442 |  |  | $ | 295 |  |
| Write-off of deferred tax asset on distributed intellectual property | 2,472 |  |  | — |  |  | 2,472 |  |  | — |  |
| Benefits from establishing new U.S. net deferred tax assets | — |  |  | — |  |  | (570 | ) |  | — |  |
| Benefit from foreign-derived intangible income (FDII) deduction | (296 | ) |  | — |  |  | (384 | ) |  | — |  |
| Benefits related to the research and development tax credit | (46 | ) |  | (42 | ) |  | (92 | ) |  | (70 | ) |
| Benefits from foreign income taxed at other than U.S. rates | (13 | ) |  | (381 | ) |  | (1 | ) |  | (481 | ) |
| Toll Charge from U.S. tax reform | — |  |  | 5 |  |  | — |  |  | 5,320 |  |
| Remeasurement of deferred taxes due to changes in statutory tax rate | — |  |  | (119 | ) |  | — |  |  | 439 |  |
| Foreign withholding taxes | — |  |  | — |  |  | — |  |  | 93 |  |
| Nondeductible charges related to the KFTC and EC investigations | 53 |  |  | 4 |  |  | 53 |  |  | 19 |  |
| Other | 27 |  |  | 34 |  |  | 67 |  |  | 29 |  |
| Income tax expense (benefit) | $ | 3,352 |  |  | $ | (268 | ) |  | $ | 2,987 |  |  | $ | 5,644 |  |

[0001728949-19-000055:mdna:87]
The 2017 Tax Cuts and Jobs Act (the Tax Legislation), which was enacted during the first quarter of fiscal 2018, significantly revised the United States corporate income tax by, among other things, lowering the corporate income tax rate to 21% and imposing a one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge). The Tax Legislation fundamentally changed the taxation of multinational entities, including a shift from a system of worldwide taxation with deferral to a hybrid territorial system, featuring a participation exemption regime with current taxation of certain foreign income, a minimum tax on low-taxed foreign earnings and new measures to deter base erosion and promote U.S. production. As a fiscal-year taxpayer, certain provisions of the Tax Legislation became effective starting at the beginning of fiscal 2019, including GILTI (global intangible low-taxed income), a new tax on income of foreign corporations, BEAT (base-erosion and anti-abuse tax) and FDII (foreign-derived intangible income). In response to the Tax Legislation and to better align our profits with activities, we implemented certain tax restructuring in fiscal 2018 and 2019. As a result, beginning in fiscal 2019, substantially all of our income is in the U.S., of which a significant portion qualifies for preferential treatment as FDII at a 13% effective tax rate. The impact of GILTI and BEAT is negligible. Accordingly, our estimated annual effective tax rate for fiscal 2019 reflects the effects of these components of the Tax Legislation. Our federal statutory income tax rate for fiscal 2018 reflected a blended rate of approximately 25%.

[0001728949-19-000055:mdna:88]
As a result of the Tax Legislation, in fiscal 2019, several of our foreign subsidiaries made tax elections to be treated as U.S. branches for federal income tax purposes (commonly referred to as “check-the-box” elections) effective beginning in fiscal 2018 and 2019. Although beginning in fiscal 2019 the income of these entities will be included in our consolidated U.S. tax return, we believe that by treating these foreign subsidiaries as U.S. branches for federal income taxes, rather than controlled foreign corporations, we will significantly reduce the risk of being subject to GILTI and BEAT taxes. As a result of making these check-the-box elections, we recorded a tax benefit of $570 million due to establishing new U.S. net deferred tax assets resulting from the difference between the GAAP basis and the U.S. federal tax carryover basis of the existing assets and liabilities of those foreign subsidiaries, primarily related to customer incentive liabilities that have not been deducted for tax purposes. During the third quarter of fiscal 2019, the United States Treasury Department issued new temporary regulations that resulted in a change to the deductibility of dividend income received by a U.S. stockholder from a foreign corporation. As a result of this change, pursuant to an agreement with the Internal Revenue Service, we will forgo the federal

[0001728949-19-000055:mdna:89]
35

[0001728949-19-000055:mdna:90]
tax basis step-up of intellectual property that was distributed in fiscal 2018 by one of our foreign subsidiaries to a U.S. subsidiary. Therefore, the related deferred tax asset previously recognized was written-off, resulting in a $2.5 billion charge to income tax expense in the third quarter of fiscal 2019.

[0001728949-19-000055:mdna:91]
The effective tax rate of 61% for the third quarter of fiscal 2019 was higher than the estimated annual effective tax rate of 41% primarily due to the $2.5 billion charge to income tax expense recorded discretely in the third quarter of fiscal 2019 resulting from the write-off of the deferred tax asset related to the distributed intellectual property. The estimated annual effective tax rate for fiscal 2019 was also impacted by the tax benefit of $570 million recorded discretely in the first quarter of fiscal 2019 due to establishing new U.S. net deferred tax assets from making certain check-the-box elections.

[0001728949-19-000055:mdna:92]
Unrecognized tax benefits were $230 million and $217 million at June 30, 2019 and September 30, 2018, respectively. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at June 30, 2019 may increase or decrease in the next 12 months.

[0001728949-19-000055:mdna:93]
The United States Treasury Department has issued proposed regulations on several provisions of the Tax Legislation, including foreign tax credits, FDII, BEAT and interest expense deduction limitations, which are expected to be finalized in the next several months. When finalized, these proposed regulations may adversely affect our provision for income taxes, results of operations and/or cash flows.

[0001728949-19-000055:mdna:94]
[same as prior period, unchanged from 0001728949-19-000036:mdna:93]

[0001728949-19-000055:mdna:95]
The following should be read in conjunction with the financial results for the third quarter and first nine months of fiscal 2019 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0001728949-19-000055:mdna:96]
[same as prior period, unchanged from 0001728949-19-000036:mdna:95]

[0001728949-19-000055:mdna:97]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | June 30, 2019 |  | June 24, 2018 |  | Change |  | June 30, 2019 |  | June 24, 2018 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,484 |  |  | $ | 4,038 |  |  | $ | (554 | ) |  | $ | 10,785 |  |  | $ | 12,486 |  |  | $ | (1,701 | ) |
| Licensing | 83 |  |  | 49 |  |  | 34 |  |  | 243 |  |  | 149 |  |  | 94 |  |
| Total revenues | $ | 3,567 |  |  | $ | 4,087 |  |  | $ | (520 | ) |  | $ | 11,028 |  |  | $ | 12,635 |  |  | $ | (1,607 | ) |
| EBT (1) | $ | 504 |  |  | $ | 607 |  |  | $ | (103 | ) |  | $ | 1,644 |  |  | $ | 2,170 |  |  | $ | (526 | ) |
| EBT as a % of revenues | 14 | % |  | 15 | % |  | (1 | %) |  | 15 | % |  | 17 | % |  | (2 | %) |

[0001728949-19-000055:mdna:98]
[same as prior period, unchanged from 0001728949-19-000036:mdna:97]

[0001728949-19-000055:mdna:99]
[same as prior period, unchanged from 0001728949-19-000036:mdna:98]

[0001728949-19-000055:mdna:100]
Equipment and services revenues mostly relate to sales of Mobile Station Modem (MSM), Radio Frequency (RF), Power Management (PM) and wireless connectivity integrated circuits. Approximately 156 million and 199 million MSM integrated circuits were sold in the third quarter of fiscal 2019 and 2018, respectively, and approximately 497 million and 623 million MSM integrated circuits were sold in the first nine months of fiscal 2019 and 2018, respectively.

[0001728949-19-000055:mdna:101]
Third quarter 2019 vs. 2018

[0001728949-19-000055:mdna:102]
QCT results in the third quarter of fiscal 2019 were negatively impacted by lower modem sales to Apple and a decline in demand from OEMs in China. The decrease in QCT equipment and services revenues was primarily due to:

[0001728949-19-000055:mdna:103]
| - | $554 million in lower MSM and accompanying unit shipments |

[0001728949-19-000055:mdna:104]
| - | $219 million decrease due to lower average selling prices |

[0001728949-19-000055:mdna:105]
| - | $135 million in lower RFFE product revenues |

[0001728949-19-000055:mdna:106]
| + | $364 million due to favorable product mix |

[0001728949-19-000055:mdna:107]
QCT EBT as a percentage of revenues decreased in the third quarter of fiscal 2019 primarily due to:

[0001728949-19-000055:mdna:108]
[same as prior period, unchanged from 0001728949-19-000036:mdna:106]

[0001728949-19-000055:mdna:109]
| + | decrease in operating expenses, primarily driven by actions under our Cost Plan and a decrease in the amount of research and development expense allocated to QCT in fiscal 2019 |

[0001728949-19-000055:mdna:110]
First nine months 2019 vs. 2018

[0001728949-19-000055:mdna:111]
QCT results in the first nine months of fiscal 2019 were negatively impacted by lower modem sales to Apple. The decrease in QCT equipment and services revenues in the first nine months of fiscal 2019 was primarily due to:

[0001728949-19-000055:mdna:112]
| - | $1.67 billion in lower MSM and accompanying unit shipments |

[0001728949-19-000055:mdna:113]
| - | $575 million decrease due to lower average selling prices |

[0001728949-19-000055:mdna:114]
| - | $374 million in lower RFFE product revenues |

[0001728949-19-000055:mdna:115]
| + | $910 million increase due to favorable product mix |

[0001728949-19-000055:mdna:116]
QCT EBT as a percentage of revenues decreased in the first nine months of fiscal 2019 primarily due to:

[0001728949-19-000055:mdna:117]
[same as prior period, unchanged from 0001728949-19-000036:mdna:116]

[0001728949-19-000055:mdna:118]
| + | decrease in operating expenses, primarily driven by actions under our Cost Plan and a decrease in the amount of research and development expense allocated to QCT in fiscal 2019 |

[0001728949-19-000055:mdna:119]
QCT accounts receivable decreased by 39% in the first nine months of fiscal 2019 from $1.36 billion to $836 million, primarily due to a decrease in revenues, as well as the impact of settling certain receivables in connection with the settlement agreements with Apple and its contract manufacturers. QCT inventories increased by 5% in the first nine months of fiscal 2019 from $1.68 billion to $1.77 billion, primarily due to an increase in the overall quantity of units on hand.

[0001728949-19-000055:mdna:120]
[same as prior period, unchanged from 0001728949-19-000036:mdna:122]

[0001728949-19-000055:mdna:121]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | June 30, 2019 |  | June 24, 2018 |  | Change |  | June 30, 2019 |  | June 24, 2018 |  | Change |
| Licensing revenues | $ | 1,292 |  |  | $ | 1,443 |  |  | $ | (151 | ) |  | $ | 3,433 |  |  | $ | 3,930 |  |  | $ | (497 | ) |
| EBT | $ | 898 |  |  | $ | 1,027 |  |  | $ | (129 | ) |  | $ | 2,162 |  |  | $ | 2,691 |  |  | $ | (529 | ) |
| EBT as a % of revenues | 70 | % |  | 71 | % |  | (1 | %) |  | 63 | % |  | 68 | % |  | (5 | %) |

[0001728949-19-000055:mdna:122]
QTL results in the third quarter and first nine months of fiscal 2019 reflected the adoption of the new accounting guidance that requires us to estimate and recognize QTL royalties in the period in which the associated sales occur, resulting in an acceleration of royalty revenues by one quarter as compared to fiscal 2018. Fiscal 2018 results have not been adjusted for the adoption of the new accounting guidance.

[0001728949-19-000055:mdna:123]
As a result of the settlement with Apple and its contract manufacturers, QTL results for the third quarter of fiscal 2019 included royalties from Apple and its contract manufactures for sales made in the June 2019 quarter. Revenues in the first six months of fiscal 2019 and the first nine months of fiscal 2018 did not include royalties due on sales of Apple or other products by Apple’s contract manufacturers.

[0001728949-19-000055:mdna:124]
QTL revenues in the third quarter and first nine months of fiscal 2019 included $150 million and $450 million, respectively, of royalties due under a second interim agreement with Huawei. These payments represent minimum, non-refundable amounts for royalties due. QTL revenues in the third quarter and first nine months of fiscal 2018 included $500 million paid under an interim agreement with Huawei for royalties due after the second quarter of fiscal 2017. These payments do not reflect the full amount of royalties due under the underlying license agreement.

[0001728949-19-000055:mdna:125]
Third quarter 2019 vs. 2018

[0001728949-19-000055:mdna:126]
QTL licensing revenues in the third quarter of fiscal 2019, which primarily related to royalties due on sales made by our licensees in the June 2019 quarter, decreased compared to licensing revenues in the third quarter of fiscal 2018, which primarily related to royalties due on sales made by our licensees in the March 2018 quarter, primarily due to:

[0001728949-19-000055:mdna:127]
| - | $350 million in lower royalty revenues from Huawei under the interim agreements |

[0001728949-19-000055:mdna:128]
| - | $163 million in lower estimated revenues per unit compared to revenues per reported unit |

[0001728949-19-000055:mdna:129]
| + | $328 million increase in estimated sales of CDMA-based products (including multi-mode products that also implement OFDMA) compared to reported sales of CDMA-based products |

[0001728949-19-000055:mdna:130]
| + | $34 million increase in royalty revenues recognized related to devices sold in prior periods, excluding the impact of Huawei |

[0001728949-19-000055:mdna:131]
QTL EBT as a percentage of revenues decreased in the third quarter of fiscal 2019 primarily due to:

[0001728949-19-000055:mdna:132]
[same as prior period, unchanged from 0001728949-19-000036:mdna:135]

[0001728949-19-000055:mdna:133]
[same as prior period, unchanged from 0001728949-19-000036:mdna:134]

[0001728949-19-000055:mdna:134]
| + | lower selling, general and administrative expenses, primarily from lower litigation costs |

[0001728949-19-000055:mdna:135]
First nine months 2019 vs. 2018

[0001728949-19-000055:mdna:136]
QTL licensing revenues in the first nine months of fiscal 2019, which primarily related to royalties due on sales made by our licensees in the December 2018, March 2019 and June 2019 quarters, decreased compared to licensing revenues in the first nine months of fiscal 2018, which primarily related to royalties due on sales made by our licensees in the September 2017, December 2017 and March 2018 quarters, primarily due to:

[0001728949-19-000055:mdna:137]
| - | $532 million in lower estimated revenues per unit compared to revenues per reported unit |

[0001728949-19-000055:mdna:138]
| - | $50 million in lower royalty revenues from Huawei under the interim agreements |

[0001728949-19-000055:mdna:139]
| + | $47 million increase in royalty revenues recognized related to devices sold in prior periods, excluding the impact of Huawei |

[0001728949-19-000055:mdna:140]
| + | $39 million increase in estimated sales of CDMA-based products (including multi-mode products that also implement OFDMA) compared to reported sales of CDMA-based products |

[0001728949-19-000055:mdna:141]
QTL EBT as a percentage of revenues decreased in the first nine months of fiscal 2019 primarily due to:

[0001728949-19-000055:mdna:142]
[same as prior period, unchanged from 0001728949-19-000036:mdna:145]

[0001728949-19-000055:mdna:143]
[same as prior period, unchanged from 0001728949-19-000036:mdna:144]

[0001728949-19-000055:mdna:144]
| + | lower selling, general and administrative expenses, primarily from lower litigation costs and lower bad debt expense |

[0001728949-19-000055:mdna:145]
QTL accounts receivable increased by 4% in the first nine months of fiscal 2019 from $1.47 billion to $1.54 billion, primarily due to the adoption of the new accounting guidance, partially offset by the impact of settling approximately $960 million of receivables that were related to the short payment in the second quarter of fiscal 2017 of royalties due from Apple’s contract manufacturers in connection with the settlement agreements with Apple and its contract manufacturers.

[0001728949-19-000055:mdna:146]
[same as prior period, unchanged from 0001728949-19-000036:mdna:148]

[0001728949-19-000055:mdna:147]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | June 30, 2019 |  | June 24, 2018 |  | Change |  | June 30, 2019 |  | June 24, 2018 |  | Change |
| Equipment and services revenues | $ | 18 |  |  | $ | 20 |  |  | $ | (2 | ) |  | $ | 143 |  |  | $ | 80 |  |  | $ | 63 |  |
| EBT | 312 |  |  | (7 | ) |  | 319 |  |  | 337 |  |  | 44 |  |  | 293 |  |

[0001728949-19-000055:mdna:148]
Third quarter 2019 vs. 2018

[0001728949-19-000055:mdna:149]
The increase in QSI EBT in the third quarter of fiscal 2019 was primarily due to:

[0001728949-19-000055:mdna:150]
| + | $305 million increase in net gains on investments, primarily driven by a gain resulting from the initial public offering of one of our non-marketable equity investments |

[0001728949-19-000055:mdna:151]
First nine months 2019 vs. 2018

[0001728949-19-000055:mdna:152]
The increase in QSI EBT in the first nine months of fiscal 2019 was primarily due to:

[0001728949-19-000055:mdna:153]
| + | $268 million increase in net gains on investments, primarily driven by a gain resulting from the initial public offering of one of our non-marketable equity investments |

[0001728949-19-000055:mdna:154]
| + | $90 million increase resulting from higher revenues and lower costs associated with certain development contracts with an equity method investee |

[0001728949-19-000055:mdna:155]
| - | $46 million increase in impairment losses on investments, primarily related to an equity method investee |

[0001728949-19-000055:mdna:156]
| - | $21 million increase in our share of losses of an equity method investee |

[0001728949-19-000055:mdna:157]
[same as prior period, unchanged from 0001728949-19-000036:mdna:162]

[0001728949-19-000055:mdna:158]
[same as prior period, unchanged from 0001728949-19-000036:mdna:163]

[0001728949-19-000055:mdna:159]
[same as prior period, unchanged from 0001728949-19-000036:mdna:164]

[0001728949-19-000055:mdna:160]
| • | On April 16, 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties. We also entered into a six-year global patent license agreement with Apple, effective as of April 1, 2019, which includes an option for Apple to extend for two additional years, and a multi-year chipset supply agreement with Apple. We began recognizing royalty revenues in the third quarter of fiscal 2019 for sales made by Apple and its contract manufacturers on or after April 1, 2019. Further, we expect our engineering costs will increase over time to support the multi-year chipset supply agreement. |

[0001728949-19-000055:mdna:161]
| • | On May 21, 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief. We disagree with the court’s conclusions, interpretation of the facts and application of the law. Accordingly, we have filed a motion to stay certain of the remedies with, and have appealed the decision to, the Ninth Circuit Court of Appeals. Regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us, and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. These activities have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs until the respective matters are resolved. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report, including the Risk Factors entitled “Efforts by some communications equipment manufacturers or their customers to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business,” “Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings” and “Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.” |

[0001728949-19-000055:mdna:162]
| • | In the first quarter of fiscal 2019, we entered into a second interim agreement with Huawei in which Huawei agreed to make three quarterly payments of $150 million (for sales made in consecutive calendar quarters beginning with the quarter ended December 2018) as minimum, non-refundable payments for royalties due for sales of licensed products by Huawei during the relevant quarter. We recognized $450 million of royalty revenues in the first nine months of fiscal 2019 under the second interim agreement. These payments do not reflect the full amount of royalties due under the underlying license agreement. The second interim agreement concluded in the third quarter of fiscal 2019, and although negotiations continue, we have not reached a final agreement with Huawei. If no agreement is reached, Huawei may not make any other payments or may not make full payments under the underlying license agreement, which may result in significant legal costs and will negatively impact our future revenues, as well as our financial condition, results of operations and cash flows, until the dispute is resolved. |

[0001728949-19-000055:mdna:163]
[same as prior period, unchanged from 0001728949-19-000036:mdna:170]

[0001728949-19-000055:mdna:164]
| • | Increased concentration of device share among a few companies, particularly within the premium tier, resulting in significant supply chain leverage for those companies, and exacerbating the negative impact to our business and financial results to the extent those companies do not utilize our chipsets. For example, Huawei has taken, and we believe will continue to take, share in China from other Chinese OEMs, negatively impacting QCT as we sell a limited number of chipsets to Huawei as compared to many of those other OEMs, and the negative impact to our overall business of Huawei share gains at the expense of other Chinese OEMs may be further exacerbated if Huawei does not pay royalties to us under its license agreement, since our interim agreement has ended; |

[0001728949-19-000055:mdna:165]
[same as prior period, unchanged from 0001728949-19-000036:mdna:172]

[0001728949-19-000055:mdna:166]
39

[0001728949-19-000055:mdna:167]
| • | Decisions by certain companies to utilize our competitors’ integrated circuit products in all or a portion of their devices. For example, we have not been the sole supplier of modems for iPhone products beginning with products that launched in September 2016, as Apple utilizes modems from one of our competitors in a portion of such devices. Apple began solely using one or more of our competitors’ modems, rather than our modems, in its 2018 iPhone release and is expected to do so in its upcoming 2019 iPhone release. As a result, QCT revenues from modem sales for iPhones have declined in the first nine months of fiscal 2019. For new chipset models, QCT does not expect to begin recording revenues under our recently announced multi-year chipset agreement with Apple until the second half of fiscal 2020; |

[0001728949-19-000055:mdna:168]
[same as prior period, unchanged from 0001728949-19-000036:mdna:174]

[0001728949-19-000055:mdna:169]
| • | Slow-down in handset demand as the industry transitions from 4G to 5G and continued reduction in demand in China, which is driven by further lengthening of replacement cycles as smartphone penetration increases and consumer demand is increasingly driven by new product launches and/or innovation cycles, as well as an increase in channel inventory in China that we expect will be drawn down in the second half of calendar 2019; |

[0001728949-19-000055:mdna:170]
[same as prior period, unchanged from 0001728949-19-000036:mdna:176]

[0001728949-19-000055:mdna:171]
[same as prior period, unchanged from 0001728949-19-000036:mdna:178]

[0001728949-19-000055:mdna:172]
| • | Current U.S./China trade relations and/or national security protection policies may negatively impact our business, growth prospects and results of operations. |

[0001728949-19-000055:mdna:173]
[same as prior period, unchanged from 0001728949-19-000036:mdna:180]

[0001728949-19-000055:mdna:174]
| • | Initial commercial 5G network deployments and device launches have begun and will continue in calendar 2019 and beyond. We believe that 5G technologies will empower a new era of smartphones and connected devices. We also believe that 5G will drive transformation across industries beyond traditional cellular communications that will create new business models and new services. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing of 5G technologies, and to be a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long term. |

[0001728949-19-000055:mdna:175]
[same as prior period, unchanged from 0001728949-19-000036:mdna:182]

[0001728949-19-000055:mdna:176]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless value chain and governments as to the benefits of our licensing program and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not welcome the success of our licensing program in enabling new, highly cost-effective competitors to their products. Accordingly, such companies, and/or governments or regulators, may continue to challenge our business model in various forums throughout the world.

[0001728949-19-000055:mdna:177]
[same as prior period, unchanged from 0001728949-19-000036:mdna:184]

[0001728949-19-000055:mdna:178]
[same as prior period, unchanged from 0001728949-19-000036:mdna:185]

[0001728949-19-000055:mdna:179]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. The following table presents selected financial information related to our liquidity as of June 30, 2019 and September 30, 2018 and for the first nine months of fiscal 2019 and 2018 (in millions):

[0001728949-19-000055:mdna:180]
[same as prior period, unchanged from 0001728949-19-000036:mdna:120]

[0001728949-19-000055:mdna:181]
|  | June 30, 2019 |  | September 30, 2018 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 14,394 |  |  | $ | 12,123 |  |  | $ | 2,271 |  |  | 19 | % |
| Accounts receivable, net | 2,390 |  |  | 2,904 |  |  | (514 | ) |  | (18 | %) |
| Inventories | 1,774 |  |  | 1,693 |  |  | 81 |  |  | 5 | % |
| Short-term debt | 3,000 |  |  | 1,005 |  |  | 1,995 |  |  | 199 | % |
| Long-term debt | 13,426 |  |  | 15,365 |  |  | (1,939 | ) |  | (13 | %) |
| Noncurrent income taxes payable | 2,114 |  |  | 2,312 |  |  | (198 | ) |  | (9 | %) |

[0001728949-19-000055:mdna:182]
|  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | $ Change |  | % Change |
| Net cash provided by operating activities | $ | 6,059 |  |  | $ | 4,331 |  |  | $ | 1,728 |  |  | 40 | % |
| Net cash (used) provided by investing activities | (469 | ) |  | 2,615 |  |  | (3,084 | ) |  | (118 | %) |
| Net cash used by financing activities | (3,446 | ) |  | (3,506 | ) |  | 60 |  |  | (2 | %) |

[0001728949-19-000055:mdna:183]
The net increase in cash, cash equivalents and marketable securities was primarily due to net cash provided by operating activities, partially offset by $2.3 billion in cash dividends paid, $1.1 billion in payments to repurchase shares of our common stock, $570 million in capital expenditures and $225 million in payments of tax withholdings related to the vesting of share-based awards. The net increase in total cash provided by operating activities included the settlement with Apple and its contract manufacturers, as well as lower segment revenues and the impact of timing of payments of customer-related liabilities.

[0001728949-19-000055:mdna:184]
Our days sales outstanding, on a consolidated basis (excluding the impact of the settlement agreements with Apple and its contract manufacturers), increased to 44 at June 30, 2019, as compared to 30 at September 30, 2018. The increase in days sales outstanding was primarily due to the adoption of the new revenue recognition accounting guidance in the first quarter of fiscal 2019. The decrease in accounts receivable was primarily due to the settlement with Apple and its contract manufacturers and decrease in integrated circuit shipments, partially offset by the adoption of the new revenue recognition accounting guidance in the first quarter of fiscal 2019. Inventories remained largely flat in the first nine-months of fiscal 2019.

[0001728949-19-000055:mdna:185]
Debt. Our Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in the aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. At June 30, 2019, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-19-000055:mdna:186]
We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At June 30, 2019, we had $998 million of commercial paper outstanding with a weighted-average interest rate of 2.57% and weighted-average remaining days to maturity of 28 days.

[0001728949-19-000055:mdna:187]
In May 2017, we issued an aggregate principal amount of $11.0 billion in nine tranches of unsecured floating- and fixed-rate notes, of which $7.0 billion remains outstanding with maturity dates in 2023 through 2047. Effective interest rates were between 2.70% and 4.47% at June 30, 2019. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001728949-19-000055:mdna:188]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, of which $8.5 billion remains outstanding with maturity dates in 2020 through 2045. Effective interest rates were between 2.84% and 4.73% at June 30, 2019. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001728949-19-000055:mdna:189]
[same as prior period, unchanged from 0001728949-19-000036:mdna:197]

[0001728949-19-000055:mdna:190]
Additional information regarding our outstanding debt at June 30, 2019 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt.”

[0001728949-19-000055:mdna:191]
Income Taxes. The Tax Legislation, which was signed into law during the first quarter of fiscal 2018, resulted in a $5.2 billion charge recognized in fiscal 2018 related to the Toll Charge. After application of certain tax credits (including excess

[0001728949-19-000055:mdna:192]
tax credits that are expected to be generated in fiscal 2019), the total cash payment is expected to be $2.5 billion. The first payment was made on January 15, 2019. At June 30, 2019, we estimated remaining future payments of $2.3 billion for the Toll Charge, after application of certain tax credits (including excess tax credits that are expected to be generated in fiscal 2019), which is payable in installments over the next seven years. At June 30, 2019, we estimated the next installment due in January 2020 is $209 million and was included in other current liabilities.

[0001728949-19-000055:mdna:193]
[same as prior period, unchanged from 0001728949-19-000036:mdna:200]

[0001728949-19-000055:mdna:194]
Capital Return Program. In the fourth quarter of fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. In fiscal 2018, we entered into three accelerated share repurchase agreements (ASR Agreements) to repurchase an aggregate of $16 billion of our common stock, with 178.4 million shares initially delivered to us under the ASR Agreements and retired. Pursuant to the terms of the ASR Agreements, the final number of shares and the average purchase price will be determined at the end of the applicable purchase periods, which are scheduled to occur in early September 2019 but may occur earlier in certain circumstances. In the first nine months of fiscal 2019, we repurchased and retired 17.7 million shares of our common stock for $1.1 billion, before commissions. At June 30, 2019, $7.8 billion remained authorized for repurchase under the stock repurchase program.

[0001728949-19-000055:mdna:195]
Our stock repurchase program has significantly reduced and we expect that it will continue to reduce the amount of cash that we have available to fund our operations including research and development, working capital, capital expenditures, acquisitions, investments, dividends and other corporate purposes; and increases our exposure to adverse economic, market, industry and competitive conditions and developments, and other changes in our business and our industry. This stock repurchase program has no expiration date. However, we periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders and may accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-19-000055:mdna:196]
In the first nine months of fiscal 2019, we paid cash dividends totaling $2.3 billion, or $1.86 per share. On July 24, 2019, we announced a cash dividend of $0.62 per share on our common stock, payable on September 26, 2019 to stockholders of record as of the close of business on September 12, 2019. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-19-000055:mdna:197]
[same as prior period, unchanged from 0001728949-19-000036:mdna:204]

[0001728949-19-000055:mdna:198]
| • | Our purchase obligations at June 30, 2019, some of which relate to research and development activities and capital expenditures, totaled $2.2 billion and $890 million for fiscal 2019 and 2020, respectively, and $489 million thereafter. |

[0001728949-19-000055:mdna:199]
| • | Our research and development expenditures were $4.0 billion in the first nine months of fiscal 2019 and $5.6 billion in fiscal 2018, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications. |

[0001728949-19-000055:mdna:200]
| • | Cash outflows for capital expenditures were $570 million in the first nine months of fiscal 2019 and $784 million in fiscal 2018. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. |

[0001728949-19-000055:mdna:201]
| • | The EC imposed two fines on us, and $1.4 billion was accrued at June 30, 2019 (based on the exchange rate at June 30, 2019, including related foreign currency gains and accrued interest). We have provided, or intend to provide, additional financial guarantees in lieu of cash payment to satisfy the obligations while we appeal the EU’s decisions. |

[0001728949-19-000055:mdna:202]
| • | Beginning on August 4, 2019, for a period of 60 days, we have the option to acquire (and the minority owner has the option to sell) the minority ownership interest in the RF360 Holdings joint venture for $1.15 billion, and we expect one of such options to be exercised during this period. At June 30, 2019 and September 30, 2018, the accreted value of such amount was included in other current liabilities. |

[0001728949-19-000055:mdna:203]
[same as prior period, unchanged from 0001728949-19-000036:mdna:210]

[0001728949-19-000055:mdna:204]
[same as prior period, unchanged from 0001728949-19-000036:mdna:167]

[0001728949-19-000055:mdna:205]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us, including the lawsuit filed against us in the United States District Court for the Northern District of California by the FTC, in which a ruling was issued in favor of the FTC in May 2019, and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees, have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0001728949-19-000055:mdna:206]
[same as prior period, unchanged from 0001728949-19-000036:mdna:212]

[0001728949-19-000055:mdna:207]
[same as prior period, unchanged from 0001728949-19-000036:mdna:213]

[0001728949-19-000055:mdna:208]
Additional information regarding our financial commitments at June 30, 2019 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes,” “Note 5. Debt” and “Note 6. Commitments and Contingencies.”

[0001728949-19-000055:mdna:209]
[same as prior period, unchanged from 0001728949-19-000036:mdna:215]

[0001728949-19-000055:mdna:210]
[same as prior period, unchanged from 0001728949-19-000036:mdna:216]

[0001728949-19-000055:mdna:211]
We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops, which in general, effectively provide for a maximum royalty amount per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such royalties. Our estimates of sales-based royalties are based largely on an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property. We estimate sales-based royalties taking into consideration the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products, and consider all information (historical, current and forecasted) that is reasonably available to us. Our licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter, which is generally the following quarter. As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

[0001728949-19-000055:mdna:212]
From time to time, regulatory authorities investigate our business practices, particularly with respect to our licensing business, and institute proceedings against us. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. Additionally, from time to time, companies initiate various strategies in an attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property, which may include disputing, underreporting, underpaying, not reporting and/or not paying royalties owed to us under their license agreements with us, or reporting to us in a manner that is not in compliance with their contractual obligations. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in ASC 606, and to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur, both of which may require significant judgment. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us.

[0001728949-19-000055:mdna:213]
[same as prior period, unchanged from 0001728949-19-000036:mdna:177]

[0001728949-19-000055:mdna:214]
On May 21, 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief (see “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies”). While we believe that our business practices do not violate either antitrust law or our FRAND (fair, reasonable and non-discriminatory) licensing commitments, significant evaluation and judgment were required in determining the impact of such ruling on the amount of licensing revenues estimated and recognized in the third quarter of fiscal 2019. This included, among other items: (i) evaluating whether our license agreements remain valid and enforceable, (ii) evaluating licensees’ conduct and whether they remain committed to perform their respective obligations and (iii) determining the expected impact, if any, to the current period of any license agreements that may be renegotiated and/or are newly entered into as a result of the ruling while the stay and appeal are pending. Based on this evaluation, the impact of the ruling was not material to QTL licensing revenues in the third quarter of fiscal 2019 based on facts and factors currently known by us. As new information becomes available, we may be required to make adjustments to revenues in subsequent periods to reflect changes in estimates and/or this matter could have a material adverse effect on our ability to recognize future licensing revenues.

[0001728949-19-000055:mdna:215]
[same as prior period, unchanged from 0001728949-19-000036:mdna:219]

[0001728949-19-000055:mdna:216]
[same as prior period, unchanged from 0001728949-19-000036:mdna:220]

[0001728949-19-000055:mdna:217]
[same as prior period, unchanged from 0001728949-19-000036:mdna:221]

[0001728949-19-000055:mdna:218]
[same as prior period, unchanged from 0001728949-19-000036:mdna:222]

[0001728949-19-000055:mdna:219]
[same as prior period, unchanged from 0001728949-19-000036:mdna:223]

[0001728949-19-000055:mdna:220]
[same as prior period, unchanged from 0001728949-19-000036:mdna:224]

[0001728949-19-000055:mdna:221]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on operators of wireless networks and our customers and licensees to adopt and implement the latest generation of these technologies for use in their networks, devices and services. We also depend on our customers and licensees to develop devices and services based on these technologies with value-added features to drive consumer demand for new 3G/4G and 3G/4G/5G multi-mode devices, as well as 3G, 4G and 5G single-mode devices, and to establish the selling prices for such devices. Further, we depend on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries and applications beyond traditional cellular communications, such as automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), networking, computing and artificial intelligence (AI), such as machine learning, among others.

[0001728949-19-000055:mdna:222]
[same as prior period, unchanged from 0001728949-19-000036:mdna:228]

[0001728949-19-000055:mdna:223]
[same as prior period, unchanged from 0001728949-19-000036:mdna:229]

[0001728949-19-000055:mdna:224]
[same as prior period, unchanged from 0001728949-19-000036:mdna:230]

[0001728949-19-000055:mdna:225]
[same as prior period, unchanged from 0001728949-19-000036:mdna:231]

[0001728949-19-000055:mdna:226]
[same as prior period, unchanged from 0001728949-19-000036:mdna:189]

[0001728949-19-000055:mdna:227]
[same as prior period, unchanged from 0001728949-19-000036:mdna:232]

[0001728949-19-000055:mdna:228]
[same as prior period, unchanged from 0001728949-19-000036:mdna:233]

[0001728949-19-000055:mdna:229]
[same as prior period, unchanged from 0001728949-19-000036:mdna:234]

[0001728949-19-000055:mdna:230]
[same as prior period, unchanged from 0001728949-19-000036:mdna:235]

[0001728949-19-000055:mdna:231]
[same as prior period, unchanged from 0001728949-19-000036:mdna:236]

[0001728949-19-000055:mdna:232]
[same as prior period, unchanged from 0001728949-19-000036:mdna:237]

[0001728949-19-000055:mdna:233]
[same as prior period, unchanged from 0001728949-19-000036:mdna:238]

[0001728949-19-000055:mdna:234]
[same as prior period, unchanged from 0001728949-19-000036:mdna:239]

[0001728949-19-000055:mdna:235]
[same as prior period, unchanged from 0001728949-19-000036:mdna:240]

[0001728949-19-000055:mdna:236]
Our products, services and technologies face significant competition. We expect competition to increase as our current competitors expand their product offerings or reduce the prices of their products as part of a strategy to attract new business and customers, as new opportunities develop, and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: device manufacturer concentrations; vertical integration; growth in demand, consumption and competition in certain geographic regions; government intervention or support of national industries or competitors; evolving industry standards and business models; evolving methods of transmission of voice and data communications; increasing data traffic and densification of wireless networks; convergence and aggregation of connectivity technologies (including Wi-Fi and LTE) in both devices and access points; consolidation of wireless technologies and infrastructure at the network edge; networking and connectivity trends (including cloud services); use of licensed, shared and unlicensed spectrum; the evolving nature of computing (including demand for always on, always connected capabilities); the speed of technological change (including the transition to smaller geometry process technologies); value-added features that drive selling prices and consumer demand for new 3G/4G and 3G/4G/5G multi-mode devices, as well as 3G, 4G and 5G single-mode devices; turnkey, integrated products that incorporate hardware, software, user interface, applications and reference designs; scalability; and the ability of the system technology to meet customers’ immediate and future network requirements. We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, technological and public policy changes and relatively low barriers to entry in certain segments of the industry. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape.

[0001728949-19-000055:mdna:237]
[same as prior period, unchanged from 0001728949-19-000036:mdna:244]

[0001728949-19-000055:mdna:238]
[same as prior period, unchanged from 0001728949-19-000036:mdna:245]

[0001728949-19-000055:mdna:239]
[same as prior period, unchanged from 0001728949-19-000036:mdna:246]

[0001728949-19-000055:mdna:240]
[same as prior period, unchanged from 0001728949-19-000036:mdna:247]

[0001728949-19-000055:mdna:241]
[same as prior period, unchanged from 0001728949-19-000036:mdna:248]

[0001728949-19-000055:mdna:242]
[same as prior period, unchanged from 0001728949-19-000036:mdna:249]

[0001728949-19-000055:mdna:243]
45

[0001728949-19-000055:mdna:244]
[same as prior period, unchanged from 0001728949-19-000036:mdna:250]

[0001728949-19-000055:mdna:245]
[same as prior period, unchanged from 0001728949-19-000036:mdna:251]

[0001728949-19-000055:mdna:246]
[same as prior period, unchanged from 0001728949-19-000036:mdna:252]

[0001728949-19-000055:mdna:247]
[same as prior period, unchanged from 0001728949-19-000036:mdna:253]

[0001728949-19-000055:mdna:248]
[same as prior period, unchanged from 0001728949-19-000036:mdna:254]

[0001728949-19-000055:mdna:249]
[same as prior period, unchanged from 0001728949-19-000036:mdna:255]

[0001728949-19-000055:mdna:250]
[same as prior period, unchanged from 0001728949-19-000036:mdna:256]

[0001728949-19-000055:mdna:251]
[same as prior period, unchanged from 0001728949-19-000036:mdna:257]

[0001728949-19-000055:mdna:252]
[same as prior period, unchanged from 0001728949-19-000036:mdna:258]

[0001728949-19-000055:mdna:253]
We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application market segment or standard product, including those that produce products for automotive, IoT and networking applications. Most of these competitors compete with us with respect to some, but not all, of our businesses. Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM) as well as companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Actions (Zhuhai) Technology Co., LTD, Advanced Micro Devices, Inc., Altair Engineering, Inc., Ambarella, Inc., AMLogic Co., Inc., Broadcom Inc., Cypress Semiconductor Corporation, Fuzhou Rockchip Electronics Co., LTD., HiSilicon Technologies, Intel, Marvell Technology, MediaTek, Murata Manufacturing Co., Ltd., Nvidia, NXP Semiconductors N.V., Qorvo Inc., Renesas Electronics Corporation, Samsung Electronics, Skyworks Solutions Inc., Spreadtrum Communications (which is controlled by Tsinghua Unigroup), STMicroelectronics International N.V., Texas Instruments Incorporated and Quantenna Communications, Inc. Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to use our competitors’ integrated circuit products, to utilize their own internally-developed integrated circuit products or sell such products to others, including by bundling with other products, or to choose alternative technologies; lower cost structures or a willingness and ability to accept lower prices and lower or negative margins for their products, particularly in China; foreign government support of other technologies or competitors or original equipment manufacturers (OEMs) that sell devices that do not contain our chipsets; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and OEMs in certain geographic regions (such as China); more experience in adjacent industry segments outside traditional cellular industries (such as automotive, IoT and computing); and a more established presence in certain regions.

[0001728949-19-000055:mdna:254]
46

[0001728949-19-000055:mdna:255]
[same as prior period, unchanged from 0001728949-19-000036:mdna:261]

[0001728949-19-000055:mdna:256]
[same as prior period, unchanged from 0001728949-19-000036:mdna:262]

[0001728949-19-000055:mdna:257]
In addition, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past chosen to utilize in certain of their devices and may in the future choose to utilize in certain (or all) of their devices, rather than our products (and may sell their integrated circuit products to third parties in competition with us). Also, Apple, which has historically been one of our largest customers, now utilizes products of one of our competitors in many of their devices rather than our products, is solely utilizing one or more of our competitor’s products in its most recent smartphone launch. On April 16, 2019, we entered into a new multi-year chipset supply agreement with Apple. We do not expect to begin recording revenues under this agreement until the second half of fiscal 2020. However, Apple may continue to use our competitors’ products in one or more of its future devices and may develop and utilize its own modem products, rather than our products, in one or more of its future devices.

[0001728949-19-000055:mdna:258]
Further, political actions, including trade and/or national security protection policies, or other actions by governments, could limit or prevent us from transacting business with certain of our customers, or limit or prevent certain of our customers from transacting business with us.

[0001728949-19-000055:mdna:259]
The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or the cancelation of significant purchases by any of these customers, whether due to the use of their own integrated circuit products, our competitors’ integrated circuit products, government restrictions or otherwise, would reduce our revenues and could harm our ability to achieve or sustain expected results of operations, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development. Further, the concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have no control, and the timing and success of such introductions may cause our revenues and results of operations to fluctuate. Accordingly, if current industry dynamics and concentrations continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases, and the timing and size of any such future purchases, by these significant customers.

[0001728949-19-000055:mdna:260]
[same as prior period, unchanged from 0001728949-19-000036:mdna:265]

[0001728949-19-000055:mdna:261]
Further, companies that develop HLOS for devices, including leading technology companies, now sell their own devices. If we fail to effectively partner or continue partnering with these companies, or with their partners or customers, they may decide not to purchase (either directly or through their contract manufacturers), or to reduce or discontinue their purchases of, our integrated circuit products.

[0001728949-19-000055:mdna:262]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products or intellectual property, and rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001728949-19-000055:mdna:263]
Although we have more than 300 licensees, our QTL segment derives a significant portion of its revenues from a limited number of licensees, which increasingly includes a small number of Chinese OEMs. In the event that one or more of our significant licensees fail to meet their reporting and payment obligations, or we are unable to renew or modify one or more of such license agreements, including standard-essential patent only license agreements, under similar terms, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have no control over the product development, sales efforts or pricing of

[0001728949-19-000055:mdna:264]
[same as prior period, unchanged from 0001728949-19-000036:mdna:226]

[0001728949-19-000055:mdna:265]
products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues. Such adverse impact may be mitigated by the per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops.

[0001728949-19-000055:mdna:266]
[same as prior period, unchanged from 0001728949-19-000036:mdna:270]

[0001728949-19-000055:mdna:267]
We derive a significant portion of our revenues from the premium-tier device segment, and we expect this trend to continue in the foreseeable future. We have experienced, and expect to continue to experience, slowing growth in the premium-tier device segment due to, among other factors, lengthening replacement cycles in developed regions, where premium-tier smartphones are common; increasing consumer demand in emerging regions where premium-tier smartphones are less common and replacement cycles are on average longer than in developed regions and are continuing to lengthen; and a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and innovation cycles.

[0001728949-19-000055:mdna:268]
[same as prior period, unchanged from 0001728949-19-000036:mdna:272]

[0001728949-19-000055:mdna:269]
[same as prior period, unchanged from 0001728949-19-000036:mdna:273]

[0001728949-19-000055:mdna:270]
[same as prior period, unchanged from 0001728949-19-000036:mdna:274]

[0001728949-19-000055:mdna:271]
From time to time, companies initiate various strategies to attempt to renegotiate, reduce or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, of seeking to impose some form of compulsory licensing or of weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies to attempt to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated.

[0001728949-19-000055:mdna:272]
[same as prior period, unchanged from 0001728949-19-000036:mdna:277]

[0001728949-19-000055:mdna:273]
We are currently subject to various litigation and governmental investigations and proceedings, including the lawsuit filed against us by the United States Federal Trade Commission (FTC). Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain

[0001728949-19-000055:mdna:274]
of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues on the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any licensing or royalty revenues on such agreements. The renegotiation of new license agreements could lead to arbitration or litigation to resolve the licensing terms (which could be less favorable to us than existing terms), each of which could take several months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition to these issues concerning future licensing and royalty revenues, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. Further, if our Partial Stay motion in the FTC lawsuit is denied, even if the remedies imposed in that lawsuit are later overturned, it would cause irreparable harm to our business. Any such events could result in a materially negative impact on our financial condition, in which case we would have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies such as 5G. Further, depending on the breadth and severity of the circumstances above, we may have to reduce or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted. If these events occur, our financial outlook and stock price could decline, possibly significantly. Further, a governmental body in a particular country or region may successfully assert and impose, remedies with effects that extend beyond the borders of that country or region. These challenges have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs until the respective matters are resolved.

[0001728949-19-000055:mdna:275]
[same as prior period, unchanged from 0001728949-19-000036:mdna:279]

[0001728949-19-000055:mdna:276]
Further, some companies or entities have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by severely limiting the base upon which the royalty percentage may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies. Some SDOs, courts and governmental agencies have adopted and may in the future adopt some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001728949-19-000055:mdna:277]
We expect that such proposals, interpretations and strategies will continue in the future, and if successful, our business model would be harmed, either by limiting or eliminating our ability to collect royalties (or by reducing the royalties we can collect) on all or a portion of our patent portfolio, limiting our return on investment with respect to new technologies, limiting our ability to seek injunctions against infringers of our standard-essential patents, constraining our ability to make licensing commitments when submitting our technology for inclusion in future standards (which could make our technology less likely to be included in such standards) or forcing us to work outside of SDOs or other industry groups to promote our new technologies, and our revenues, results of operations and cash flows could be negatively impacted. In addition, the legal and other costs associated with asserting or defending our positions have been and continue to be significant. We assume that

[0001728949-19-000055:mdna:278]
49

[0001728949-19-000055:mdna:279]
such challenges, regardless of their merits, will continue into the foreseeable future and will require the investment of substantial management time and financial resources.

[0001728949-19-000055:mdna:280]
[same as prior period, unchanged from 0001728949-19-000036:mdna:284]

[0001728949-19-000055:mdna:281]
We are currently subject to various governmental investigations and proceedings, particularly with respect to our licensing business, including the lawsuit filed against us by the FTC. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations or findings in those matters include, among others, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high, that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions), that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets, that we have entered into exclusive agreements with chipset customers that foreclose competition, and that we violate antitrust laws, engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues on the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any licensing or royalty revenues on such agreements. The renegotiation of new license agreements could lead to arbitration or litigation to resolve the licensing terms (which could be less favorable to us than existing terms), each of which could take several months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition to these issues concerning future licensing and royalty revenues, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. Further, if our Partial Stay motion in the FTC lawsuit is denied, even if the remedies imposed in that lawsuit are later overturned, it would cause irreparable harm to our business. Any such events could result in a materially negative impact on our financial condition, in which case we would have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies such as 5G. Further, depending on the breadth and severity of the circumstances above, we may have to reduce or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted. If these events occur, our financial outlook and stock price could decline, possibly significantly. Further, a governmental body in a particular country or region may successfully assert and impose, remedies with effects that extend beyond the borders of that country or region. These challenges have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs until the respective matters are resolved.

[0001728949-19-000055:mdna:282]
Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.

[0001728949-19-000055:mdna:283]
We are currently subject to various governmental investigations and proceedings and private legal proceedings challenging our patent licensing and chipset sales practices, including the lawsuit filed against us by the FTC. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations in those matters include, among others, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high, that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions), that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets, that we have entered into exclusive agreements with chipset customers that foreclose competition, and that we violate antitrust laws, engage in anticompetitive conduct and unfair methods of competition. We believe that one intent of these investigations and legal proceedings is to reduce the amount of royalties that licensees are

[0001728949-19-000055:mdna:284]
required to pay to us for their use of our intellectual property. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-19-000055:mdna:285]
We historically licensed our cellular standard-essential patents together with our other patents that may be useful to licensed products because licensees desired to obtain the commercial benefits of receiving such broad patent rights from us. However, we also licensed only our cellular standard-essential patents to certain licensees who have requested such licenses. In connection with our resolution with the China National Development and Reform Commission (NDRC), our standard practice in China since 2015 is to offer licenses to our 3G and 4G standard-essential Chinese patents for devices sold for use in China separately from our other patents. We currently offer licenses to only our cellular standard-essential patents (including 3G, 4G and 5G) for both single mode and multi-mode devices worldwide. A number of our licensees have entered into standard-essential patent only agreements on a worldwide basis, and we expect more of our licensees will do so in the future. Our royalty rates for licenses to only our cellular standard-essential patents are lower than our royalty rates for licenses to substantially all of our patent portfolio. If more licensees choose a license to only our cellular standard-essential patents instead of a portfolio license than has historically been the case, our licensing revenues and earnings would be negatively impacted unless we were able to license our other patents at rates that offset all or a portion of any difference between the royalties previously received for licenses of substantially all of our patent portfolio as compared to licenses of only our cellular standard-essential patents or there was a sufficient increase in the overall volume of sales of devices upon which royalties are paid.

[0001728949-19-000055:mdna:286]
If we were required to grant patent licenses to chipset manufacturers (which could lead to implementing a more complex, tiered licensing structure in which we license certain portions of our patent portfolio to chipset manufacturers and other portions to device manufacturers), we would incur additional transaction costs, which may be significant, and we could incur delays in recognizing revenues until license negotiations were completed. In addition, our licensing revenues and earnings would be negatively impacted if we were not able to obtain, in the aggregate, equivalent revenues under such a multi-level licensing structure.

[0001728949-19-000055:mdna:287]
[same as prior period, unchanged from 0001728949-19-000036:mdna:291]

[0001728949-19-000055:mdna:288]
If we are required to sell chipsets to OEMs that do not have a license to our patents, our licensing program could be negatively impacted by patent exhaustion claims raised by such unlicensed OEMs (i.e., claims that our sale of chipsets to such OEMs forecloses us from asserting any patents substantially embodied by the chipsets against such OEMs). Such sales would provide OEMs with a defense in the event we asserted our patents against them to obtain licensing revenue for those patents. This would have a material adverse effect on our licensing program and our results of operations, financial condition and cash flows.

[0001728949-19-000055:mdna:289]
To the extent that we were required to implement any of these new licensing and/or business practices, including by modifying, renegotiating our existing license agreements or pursuing other commercial arrangements, we would incur additional transaction costs, which may be significant, and we could incur delays in recognizing revenues until license negotiations were completed. The impact of any such changes to our licensing practices could vary widely and by jurisdiction, depending on the specific outcomes and the geographic scope of such outcomes. In addition, if we were required to make modifications to our licensing practices in one jurisdiction, licensees or governmental agencies in other jurisdictions may attempt to obtain similar outcomes for themselves or for such other jurisdictions, as applicable.

[0001728949-19-000055:mdna:290]
Finally, if our Partial Stay motion in the FTC lawsuit is denied, even if the remedies imposed in that lawsuit are later overturned, it would cause irreparable harm to our business.

[0001728949-19-000055:mdna:291]
[same as prior period, unchanged from 0001728949-19-000036:mdna:293]

[0001728949-19-000055:mdna:292]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our proprietary information, technologies and processes, including our patent portfolio. Policing unauthorized use of our products, technologies and proprietary information is difficult and time consuming. The steps we have taken have not always prevented, and we cannot be certain the steps we will take in

[0001728949-19-000055:mdna:293]
the future will prevent, the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as U.S. laws or where the enforcement of such laws may be lacking or ineffective. Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that the European Union will adopt a unitary patent system in the next few years that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-19-000055:mdna:294]
We have had, and may in the future have, difficulty in certain circumstances in protecting or enforcing our intellectual property rights and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies of foreign governments; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business and the pricing and integration of additional features and functionality into our chipset products. Certain licensees have disputed, underreported, underpaid, not reported and not paid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or have delayed entering into or renewing license agreements for their use of our intellectual property, and such licensees and companies may continue to do so in the future. The fact that one or more licensees dispute, underreport, underpay, do not report and do not pay royalties owed to us may encourage other licensees to take similar actions and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements. Similarly, we provide access to certain of our intellectual property and proprietary and confidential business information to our direct and indirect customers and licensees, who may wrongfully use such intellectual property and information or wrongfully disclose such intellectual property and information to third parties, including our competitors.

[0001728949-19-000055:mdna:295]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation) and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0001728949-19-000055:mdna:296]
Our growth increasingly depends on our ability to extend our technologies, products and services into new and expanded product areas, such as RFFE, and adjacent industry segments and applications outside of traditional cellular industries, such as automotive, IoT and networking, among others. Our research, development and other investments in these new and expanded product areas, industry segments and applications, and related technologies, products and services, as well as in our existing technologies, products and services and new technologies, such as 5G, may not generate operating income or contribute to future results of operations that meet our expectations.

[0001728949-19-000055:mdna:297]
Our industry is subject to rapid technological change, evolving industry standards and frequent new product introductions, and we must make substantial research, development and other investments, such as acquisitions, in new products, services and technologies to compete successfully. Technological innovations generally require significant research and development efforts before they are commercially viable. While we continue to invest significant resources toward advancements primarily in support of 4G- and 5G-based technologies, we also invest in new and expanded product areas, and

[0001728949-19-000055:mdna:298]
[same as prior period, unchanged from 0001728949-19-000036:mdna:281]

[0001728949-19-000055:mdna:299]
adjacent industry segments and applications by leveraging our existing technical and business expertise and through acquisitions.

[0001728949-19-000055:mdna:300]
In particular, our future growth significantly depends on new and expanded product areas, such as RFFE, and adjacent industry segments and applications outside of traditional cellular industries, such as automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), networking, computing and AI, such as machine learning, among others; our ability to develop leading and cost-effective technologies, products and services for new and expanded product areas, adjacent industry segments and applications; and third parties incorporating our technologies, products and services into devices used in these product areas, industry segments and applications. Accordingly, we intend to continue to make substantial investments in these new and expanded product areas and adjacent industry segments and applications, and in developing new products, services and technologies for these product areas, industry segments and applications.

[0001728949-19-000055:mdna:301]
[same as prior period, unchanged from 0001728949-19-000036:mdna:302]

[0001728949-19-000055:mdna:302]
However, our research, development and other investments in these new and expanded product areas and adjacent industry segments and applications, and corresponding technologies, products and services, as well as in our existing, technologies, products and services and new technologies, such as 5G, use of licensed, shared and unlicensed spectrum and convergence of cellular and Wi-Fi, may not succeed due to, among other reasons: new and expanded product areas and adjacent industry segments, applications and consumer demand may not develop or grow as anticipated; our strategies or the strategies of our customers, licensees or partners may not be successful; improvements in alternate technologies in ways that reduce the advantages we anticipate from our investments; competitors’ technologies, products or services being more cost effective, having more capabilities or fewer limitations or being brought to market faster than our new technologies, products and services; and competitors having longer operating histories in industry segments that are new to us. We may also underestimate the costs of or overestimate the future revenues or margins that could result from these investments, and these investments may not, or may take many years to, generate material returns. Further, the automotive industry is subject to long design-in time frames, long product life cycles and a high degree of regulatory and safety requirements, necessitating suppliers to the industry to comply with stringent qualification processes, very low defect rates and high reliability standards, all of which results in a significant barrier to entry and increased costs.

[0001728949-19-000055:mdna:303]
[same as prior period, unchanged from 0001728949-19-000036:mdna:304]

[0001728949-19-000055:mdna:304]
[same as prior period, unchanged from 0001728949-19-000036:mdna:305]

[0001728949-19-000055:mdna:305]
[same as prior period, unchanged from 0001728949-19-000036:mdna:306]

[0001728949-19-000055:mdna:306]
We are subject to many environmental, health and safety laws and regulations in each jurisdiction in which we operate our manufacturing facilities, which govern, among other things, emissions of pollutants into the air, wastewater discharges, the use and handling of hazardous substances, waste disposal, the investigation and remediation of soil and ground water contamination and the health and safety of our employees. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. We cannot make assurances that we will be at all times in compliance with such laws, regulations and permits. Certain environmental laws impose strict, and in certain circumstances, joint and several, liability on current or previous owners or operators of real property for the cost of investigation, removal or remediation of hazardous substances. Certain of these laws also assess liability on persons who arrange for hazardous substances to be sent to disposal or treatment facilities when such facilities are found to be contaminated. In addition, we could also be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage.

[0001728949-19-000055:mdna:307]
[same as prior period, unchanged from 0001728949-19-000036:mdna:310]

[0001728949-19-000055:mdna:308]
53

[0001728949-19-000055:mdna:309]
Our manufacturing operations depend on securing raw materials and other supplies in adequate quality and quantity in a timely manner from multiple suppliers, and in some cases, we rely on a limited number of suppliers, particularly in Asia. Accordingly, there may be cases where supplies of raw materials and other products are interrupted by disaster, accident or some other event at a supplier, supply is suspended due to quality or other issues, or there is a shortage of supply due to a rapid increase in demand, which could impact production and prevent us from supplying products to our customers. If the supply-demand balance is disrupted, it may considerably increase costs of manufacturing due to increased prices we pay for raw materials or fuel. From time to time, suppliers may extend lead times, limit the amounts supplied to us or increase prices due to capacity constraints or other factors. Additionally, supply of and costs of raw materials may be negatively impacted by trade and/or national security protection policies, such as tariffs, or actions by governments that limit or prevent us from transacting business with certain companies or that limit or prevent certain companies from transacting business with us, or escalating trade tensions, particularly with countries in Asia. Further, it may be difficult or impossible to substitute one piece of equipment for another or replace one type of material with another. A failure by our suppliers to deliver our requirements could result in disruptions to our manufacturing operations.

[0001728949-19-000055:mdna:310]
[same as prior period, unchanged from 0001728949-19-000036:mdna:312]

[0001728949-19-000055:mdna:311]
The continued and future success of our licensing programs requires us to continue to evolve our patent portfolio, and our licensing programs may be impacted by the proliferation of devices in new industry segments such as automotive and IoT, as well as the need to renew or renegotiate license agreements that are expiring or to cover additional future patents.

[0001728949-19-000055:mdna:312]
[same as prior period, unchanged from 0001728949-19-000036:mdna:314]

[0001728949-19-000055:mdna:313]
[same as prior period, unchanged from 0001728949-19-000036:mdna:315]

[0001728949-19-000055:mdna:314]
Further, the licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, many of our license agreements (including essentially all of our agreements in China and our recent worldwide standard-essential patent only agreements) are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of the specified term, and to receive royalties after the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. Accordingly, to the extent not renewed on their terms or by election for an additional (generally multi-year) period, if applicable, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. We might not be able to extend or modify those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001728949-19-000055:mdna:315]
[same as prior period, unchanged from 0001728949-19-000036:mdna:318]

[0001728949-19-000055:mdna:316]
[same as prior period, unchanged from 0001728949-19-000036:mdna:319]

[0001728949-19-000055:mdna:317]
[same as prior period, unchanged from 0001728949-19-000036:mdna:320]

[0001728949-19-000055:mdna:318]
[same as prior period, unchanged from 0001728949-19-000036:mdna:321]

[0001728949-19-000055:mdna:319]
[same as prior period, unchanged from 0001728949-19-000036:mdna:322]

[0001728949-19-000055:mdna:320]
[same as prior period, unchanged from 0001728949-19-000036:mdna:323]

[0001728949-19-000055:mdna:321]
[same as prior period, unchanged from 0001728949-19-000036:mdna:324]

[0001728949-19-000055:mdna:322]
[same as prior period, unchanged from 0001728949-19-000036:mdna:325]

[0001728949-19-000055:mdna:323]
[same as prior period, unchanged from 0001728949-19-000036:mdna:326]

[0001728949-19-000055:mdna:324]
Additionally, supply and costs of raw materials may be negatively impacted by trade or national security protection policies, such as tariffs, or actions by governments that limit or prevent us from transacting business with certain companies or that limit or prevent certain companies from transacting business with us, or escalating trade tensions, particularly with countries in Asia.

[0001728949-19-000055:mdna:325]
While we have established alternate suppliers for certain technologies, we rely on sole- or limited-source suppliers for certain products, subjecting us to significant risks, including: possible shortages of raw materials or manufacturing capacity; poor product performance; and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established alternate suppliers, these suppliers may require significant levels of support to bring complex technologies to production. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, any future consolidation of foundry suppliers could increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions and could increase our manufacturing costs. Our arrangements with our suppliers may obligate us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies, and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Any of the above could negatively impact our business, results of operations and cash flows.

[0001728949-19-000055:mdna:326]
[same as prior period, unchanged from 0001728949-19-000036:mdna:328]

[0001728949-19-000055:mdna:327]
[same as prior period, unchanged from 0001728949-19-000036:mdna:329]

[0001728949-19-000055:mdna:328]
In addition, we may not receive reasonable pricing, manufacturing or delivery terms from our suppliers. We cannot guarantee that the actions of our suppliers will not cause disruptions in our operations that could harm our ability to meet our

[0001728949-19-000055:mdna:329]
[same as prior period, unchanged from 0001728949-19-000036:mdna:298]

[0001728949-19-000055:mdna:330]
delivery obligations to our customers or increase our cost of sales. To the extent we are unable to obtain adequate supply, we may be obligated to make payment to our customers for such shortfalls.

[0001728949-19-000055:mdna:331]
[same as prior period, unchanged from 0001728949-19-000036:mdna:332]

[0001728949-19-000055:mdna:332]
[same as prior period, unchanged from 0001728949-19-000036:mdna:333]

[0001728949-19-000055:mdna:333]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products or services sold or provided by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or reductions in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-19-000055:mdna:334]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset or licensing revenues.

[0001728949-19-000055:mdna:335]
Certain legal matters, which may include certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-19-000055:mdna:336]
[same as prior period, unchanged from 0001728949-19-000036:mdna:337]

[0001728949-19-000055:mdna:337]
We engage in strategic acquisitions and other transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. From time to time, we acquire businesses and other assets, including patents, technology, wireless spectrum and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our products and technologies and supporting the design and introduction of new products and services (or enhancing existing

[0001728949-19-000055:mdna:338]
[same as prior period, unchanged from 0001728949-19-000036:mdna:308]

[0001728949-19-000055:mdna:339]
products or services) for voice and data communications and new industry segments. Recently, this included our RF360 Holdings joint venture with TDK Corporation. Many of our strategic activities entail a high degree of risk and require the use of significant amounts of capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies, products or services. We may underestimate the costs or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our financial condition and results of operations, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001728949-19-000055:mdna:340]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, technology, products, processes, operations (including manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development and supply operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models (including manufacturing), geographic regions, industry segments or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of the combination.

[0001728949-19-000055:mdna:341]
[same as prior period, unchanged from 0001728949-19-000036:mdna:342]

[0001728949-19-000055:mdna:342]
[same as prior period, unchanged from 0001728949-19-000036:mdna:343]

[0001728949-19-000055:mdna:343]
[same as prior period, unchanged from 0001728949-19-000036:mdna:344]

[0001728949-19-000055:mdna:344]
[same as prior period, unchanged from 0001728949-19-000036:mdna:345]

[0001728949-19-000055:mdna:345]
Government policies, particularly in China, that regulate the amount and timing of funds that may flow out of a country have impacted and may continue to impact the timing of our receipt of and/or ability to receive payments from our customers and licensees in China, which may negatively impact our cash flows.

[0001728949-19-000055:mdna:346]
Delays in government approvals or other governmental activities that could result from, among others, a decrease in or a lack of funding for certain agencies or branches of the government or political changes, could result in our incurring higher

[0001728949-19-000055:mdna:347]
costs, could negatively impact our ability to timely consummate strategic transactions and could have other negative impacts on our business and the businesses of our customers and licensees.

[0001728949-19-000055:mdna:348]
Import/export regulations, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce, are complex, change frequently, have generally become more stringent over time and have intensified under the current U.S. administration. If our customers or suppliers fail to comply with these regulations, we may be required to suspend activities with these customers or suppliers, which could negatively impact our results of operations. Additionally, we may be required to incur significant expense to comply with, or to remedy violations of, these regulations.

[0001728949-19-000055:mdna:349]
[same as prior period, unchanged from 0001728949-19-000036:mdna:349]

[0001728949-19-000055:mdna:350]
[same as prior period, unchanged from 0001728949-19-000036:mdna:350]

[0001728949-19-000055:mdna:351]
[same as prior period, unchanged from 0001728949-19-000036:mdna:351]

[0001728949-19-000055:mdna:352]
[same as prior period, unchanged from 0001728949-19-000036:mdna:352]

[0001728949-19-000055:mdna:353]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe we will continue to see, an increase in customers requesting that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of a product’s source code and may expose related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of the open source software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Furthermore, in the course of product development, we may make contributions to third party open source projects that could obligate our intellectual property to adverse licensing conditions. For example, to encourage the growth of a software ecosystem that is interoperable with our products, we may need to contribute certain implementations under the open source licensing terms that govern such projects, which may adversely impact certain of our associated intellectual property. Developing open source products, while adequately protecting the intellectual property rights upon which our licensing business depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property rights. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ

[0001728949-19-000055:mdna:354]
adequate controls to protect our intellectual property rights, our contributions to and use of open source software presents risks that could have an adverse effect on these rights and on our business.

[0001728949-19-000055:mdna:355]
[same as prior period, unchanged from 0001728949-19-000036:mdna:354]

[0001728949-19-000055:mdna:356]
[same as prior period, unchanged from 0001728949-19-000036:mdna:355]

[0001728949-19-000055:mdna:357]
In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities. Due to changes in our stock price, we are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-19-000055:mdna:358]
[same as prior period, unchanged from 0001728949-19-000036:mdna:357]

[0001728949-19-000055:mdna:359]
[same as prior period, unchanged from 0001728949-19-000036:mdna:358]

[0001728949-19-000055:mdna:360]
[same as prior period, unchanged from 0001728949-19-000036:mdna:359]

[0001728949-19-000055:mdna:361]
[same as prior period, unchanged from 0001728949-19-000036:mdna:360]

[0001728949-19-000055:mdna:362]
[same as prior period, unchanged from 0001728949-19-000036:mdna:361]

[0001728949-19-000055:mdna:363]
[same as prior period, unchanged from 0001728949-19-000036:mdna:362]

[0001728949-19-000055:mdna:364]
Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to general economic conditions, industry cycles and financial, business and other factors, including factors which negatively impact our cash flows, such as licensees withholding some or all of the royalty payments they owe to us or our paying fines or modifying our business practices in connection with regulatory investigations or litigation, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations in the future to service our debt, we may be required to, among other things: refinance or restructure all or a portion of our indebtedness; reduce or delay planned capital or operating expenditures; reduce or eliminate our dividend payments; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing or restructuring are higher than our current rates, interest expense related to such refinancing or restructuring would increase. If there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt in the future and the terms of such debt could be adversely affected.

[0001728949-19-000055:mdna:365]
[same as prior period, unchanged from 0001728949-19-000036:mdna:364]

[0001728949-19-000055:mdna:366]
[same as prior period, unchanged from 0001728949-19-000036:mdna:365]

[0001728949-19-000055:mdna:367]
[same as prior period, unchanged from 0001728949-19-000036:mdna:366]

[0001728949-19-000055:mdna:368]
Third parties regularly attempt to gain unauthorized access to our information technology systems, and most of such attempts are increasingly more sophisticated. These attempts, which might be related to industrial or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks,

[0001728949-19-000055:mdna:369]
including those in our manufacturing operations, and impersonating authorized users, among others. Such attempts could result in the misappropriation, theft, misuse, disclosure or loss or destruction of the intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our information technology systems. These threats are constantly evolving, thereby increasing the difficulty of successfully defending against them or implementing adequate preventative measures.

[0001728949-19-000055:mdna:370]
[same as prior period, unchanged from 0001728949-19-000036:mdna:368]

[0001728949-19-000055:mdna:371]
[same as prior period, unchanged from 0001728949-19-000036:mdna:369]

[0001728949-19-000055:mdna:372]
[same as prior period, unchanged from 0001728949-19-000036:mdna:370]

[0001728949-19-000055:mdna:373]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-U.S. headquarters is located. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed. Our current examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts giving rise to a revision become known. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-19-000055:mdna:374]
The United States Treasury Department has issued proposed regulations on several provisions of the Tax Legislation, including foreign tax credits, FDII, BEAT and interest expense deduction limitations, which are expected to be finalized in the next several months. When finalized, these proposed regulations may adversely affect our provision for income taxes, results of operations and/or cash flows.

[0001728949-19-000055:mdna:375]
[same as prior period, unchanged from 0001728949-19-000036:mdna:373]

[0001728949-19-000055:mdna:376]
[same as prior period, unchanged from 0001728949-19-000036:mdna:374]

[0001728949-19-000055:mdna:377]
Global, regional or local economic conditions, or political actions including trade and/or national security protection policies, such as tariffs, that impact the mobile communications industry or the other industries in which we operate could negatively affect the demand for our products and services and our customers’ or licensees’ products and services, which may negatively affect our revenues.

[0001728949-19-000055:mdna:378]
[same as prior period, unchanged from 0001728949-19-000036:mdna:347]

[0001728949-19-000055:mdna:379]
A decline in global, regional or local economic conditions or a slow-down in economic growth, or political actions including trade and/or national security protection policies, such as tariffs, or actions by governments that limit or prevent us from transacting business with certain companies or that limit or prevent certain companies from transacting business with us, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could have adverse, wide-ranging effects on demand for our products and services and for the products and services of our customers or licensees, particularly equipment manufacturers or others in the wireless communications industry who buy their products, such as wireless operators. Any prolonged economic downturn or “trade war” may result in a decrease in demand for our products and technologies; a decrease in demand for the products of our customers or licensees; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our licensees or customers; failures by counterparties; and negative effects on wireless device inventories. In addition, our customers’ ability to purchase or pay for our products and services and network operators’ ability to upgrade their wireless networks could be adversely affected by economic conditions, leading to a reduction, cancelation or delay of orders for our products and services.

[0001728949-19-000055:mdna:380]
[same as prior period, unchanged from 0001728949-19-000036:mdna:378]

[0001728949-19-000055:mdna:381]
Our future success depends largely upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. The market for employees in our industry is extremely competitive, and competitors for talent, particularly engineering talent, increasingly attempt to hire, and to varying degrees have been successful in hiring, our employees, including by establishing local offices in San Diego. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001728949-19-000055:mdna:382]
[same as prior period, unchanged from 0001728949-19-000036:mdna:380]

[0001728949-19-000055:mdna:383]
Our customers sell their products throughout the world in various currencies. Our consolidated revenues from international customers and licensees accounted for a significant portion of our total revenues in each of the last three fiscal years. Adverse movements in currency exchange rates may negatively affect our business, revenues, results of operations and cash flows due to a number of factors, including, among others:

[0001728949-19-000055:mdna:384]
[same as prior period, unchanged from 0001728949-19-000036:mdna:382]

[0001728949-19-000055:mdna:385]
[same as prior period, unchanged from 0001728949-19-000036:mdna:383]

[0001728949-19-000055:mdna:386]
[same as prior period, unchanged from 0001728949-19-000036:mdna:384]

[0001728949-19-000055:mdna:387]
[same as prior period, unchanged from 0001728949-19-000036:mdna:385]

[0001728949-19-000055:mdna:388]
[same as prior period, unchanged from 0001728949-19-000036:mdna:386]

[0001728949-19-000055:mdna:389]
[same as prior period, unchanged from 0001728949-19-000036:mdna:387]

[0001728949-19-000055:mdna:390]
[same as prior period, unchanged from 0001728949-19-000036:mdna:388]

[0001728949-19-000055:mdna:391]
The use of devices containing our products to interact with untrusted systems or otherwise access untrusted content creates a risk of exposing the system hardware and software in those devices to malicious attacks. While we continue to focus on this issue and are taking measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and applications, and increasing the risk of security failures. Further, our products are inherently complex and may contain defects or errors that are detected only when the products are in use. Because our products and services are responsible for critical functions in our customers’ products and networks, security failures, defects or errors in our products or services could have an adverse impact on us, on our customers and the end users of our customers’ products. Such adverse impact could include shipment delays; product liability claims or recalls; write-offs of our inventories, property, plant and equipment and intangible assets; unfavorable purchase commitments; a shift of

[0001728949-19-000055:mdna:392]
61

[0001728949-19-000055:mdna:393]
business to our competitors; a decrease in demand for connected devices and wireless services; damage to our reputation and our customer relationships; regulatory actions; and other financial liability or harm to our business. Further, security failures, defects or errors in the products of our customers or licensees could have an adverse impact on our results of operations and cash flows due to a delay or decrease in demand for our products or services generally, and our premium-tier products in particular, among other factors. Development of products and features in new domains of technology and the migration to integrated circuit technologies with smaller geometric feature sizes are complex, add risk to manufacturing yields and reliability and increase the likelihood of product defects or errors. Further, failures, defects or errors in our products or those of our customers or licensees entail the risk of product liability claims.
