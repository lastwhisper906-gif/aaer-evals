# QCOM note change history — 0001234452-14-000238 → 0001234452-15-000024


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2015-01-28):
[0001234452-15-000024:note_history:1]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of approximately $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The parties are currently submitting appeal briefs to the Court of Appeals for the Federal Circuit, which will schedule a hearing once briefing is completed. On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision now alleges that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. The Company was served with the complaint in this second action on August 28, 2014 and answered on November 17, 2014. The judge has not yet set a schedule, but the parties have jointly proposed a claim construction hearing date in September 2015, a date for the close of discovery in the first half of 2016 and a trial date in early 2017.

- added (2015-01-28):
[0001234452-15-000024:note_history:2]
Nvidia Corporation v. Qualcomm Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd., and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chip products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District of Delaware complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. The evidentiary hearing for the investigation is set for June 22 to June 26, 2015. The Initial Determination of the Administrative Law Judge is due October 9, 2015, and the target date for completion of the investigation by the Commission is set for February 10, 2016. The district court case was stayed on October 23, 2014 pending completion of the ITC investigation including appeals.

- added (2015-01-28):
[0001234452-15-000024:note_history:3]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. The Company continues to cooperate with the Commission’s preliminary investigation.

- added (2015-01-28):
[0001234452-15-000024:note_history:4]
European Commission Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Article 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU) and Article 53 and/or 54 of the Agreement for the European Economic Area (EEA Agreement). The Company understands that the investigation concerns the sale and/or marketing of the Company’s baseband chipsets, including alleged conditions relating to the provision by the Company of rebates and/or other financial incentives. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. Given that this investigation is in its early stages, it is difficult to predict the outcome or what remedies, if any, may be imposed by the Commission. The Company continues to cooperate with the Commission as it conducts its investigation.

- changed (2015-01-28):
[0001234452-15-000024:note_history:5]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chips and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments with respect to this matter.
  (was, 2014-07-23, similarity 0.9069):
[0001234452-14-000238:note_history:5]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chips and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid in the second quarter of fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court.

- changed (2015-01-28):
[0001234452-15-000024:note_history:6]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 25 different dates, with the next hearing scheduled for February 25, 2015.
  (was, 2014-07-23, similarity 0.9751):
[0001234452-14-000238:note_history:6]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 23 different dates, with additional hearing dates yet to be scheduled.

- changed (2015-01-28):
[0001234452-15-000024:note_history:7]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). As discussed below, FCPA compliance is also the focus of the SEC investigation. The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee has completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.
  (was, 2014-07-23, similarity 0.6281):
[0001234452-14-000238:note_history:7]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee has completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.

- changed (2015-01-28):
[0001234452-15-000024:note_history:8]
China National Development and Reform Commission (NDRC) Investigation: In November 2013, the NDRC notified the Company that it had commenced an investigation of the Company relating to the Chinese Anti-Monopoly Law (AML). The investigation concerns primarily the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business, including how royalties are calculated in the Company’s patent licenses, the value exchanged for cross-licenses to patents of the Company’s licensees, whether the Company will offer license agreements limited to patents essential to certain standards, whether royalties are sought for the Company’s expired patents, the Company’s policy of selling chipsets only to the Company’s patent licensees, the alleged refusal of the Company to grant patent licenses to chipset manufacturers, and certain other terms and conditions in the Company’s patent license and chipset sale agreements. A broad range of remedies with respect to business practices deemed to violate the AML is potentially available to the NDRC, including but not limited to issuing an order to cease conduct deemed illegal, confiscating gains deemed illegally obtained, imposing a fine in the range of 1% to 10% of the prior year’s revenues and requiring modifications to business practices. Given the limited precedent of enforcement actions and penalties under the AML, it is difficult to predict the outcome of this matter or what remedies may be imposed by the NDRC. The Company continues to cooperate with the NDRC as it conducts its investigation.
  (was, 2014-07-23, similarity 0.991):
[0001234452-14-000238:note_history:8]
China National Development and Reform Commission (NDRC) Investigation: In November 2013, the NDRC notified the Company that it had commenced an investigation of the Company relating to the Chinese Anti-Monopoly Law (AML). The Company understands that the investigation concerns primarily the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business, including how royalties are calculated in the Company’s patent licenses, the value exchanged for cross-licenses to patents of the Company’s licensees, whether the Company will offer license agreements limited to patents essential to certain standards, whether royalties are sought for the Company’s expired patents, the Company’s policy of selling chipsets only to the Company’s patent licensees, the alleged refusal of the Company to grant patent licenses to chipset manufacturers, and certain other terms and conditions in the Company’s patent license and chipset sale agreements. A broad range of remedies with respect to business practices deemed to violate the AML is potentially available to the NDRC, including but not limited to issuing an order to cease conduct deemed illegal, confiscating gains deemed illegally obtained, imposing a fine in the range of 1% to 10% of the prior year’s revenues and requiring modifications to business practices. Given the limited precedent of enforcement actions and penalties under the AML, it is difficult to predict the outcome of this matter or what remedies may be imposed by the NDRC. The Company continues to cooperate with the NDRC as it conducts its investigation.

- added (2015-01-28):
[0001234452-15-000024:note_history:9]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act. The Company understands that the investigation concerns primarily the Company’s licensing business, including potential breach of FRAND commitments. If a violation of Section 5 is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s licensing practices. Given that this investigation is in its early stages, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company has responded to the FTC’s initial request for documents and continues to cooperate with the FTC as it conducts its investigation.

- changed (2015-01-28):
[0001234452-15-000024:note_history:10]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at December 28, 2014 for contingent losses associated with these matters based on its belief that, with the exception of the NDRC matter, losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. Regarding the NDRC matter, the Company believes that a loss is probable but that any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.
  (was, 2014-07-23, similarity 0.9949):
[0001234452-14-000238:note_history:10]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at June 29, 2014 for contingent losses associated with these matters based on its belief that, with the exception of the NDRC matter, losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. Regarding the NDRC matter, the Company believes that a loss is probable but that any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

- changed (2015-01-28):
[0001234452-15-000024:note_history:11]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through December 28, 2014, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.
  (was, 2014-07-23, similarity 0.7619):
[0001234452-14-000238:note_history:11]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through June 29, 2014, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

- changed (2015-01-28):
[0001234452-15-000024:note_history:12]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at December 28, 2014 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.
  (was, 2014-07-23, similarity 0.9935):
[0001234452-14-000238:note_history:12]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at June 29, 2014 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- added (2015-01-28):
[0001234452-15-000024:note_history:13]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at December 28, 2014 for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 were approximately $3.8 billion, $1.1 billion, $1.2 billion, $959 million and $892 million, respectively, and $242 million thereafter. Of these amounts, for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019, commitments to purchase integrated circuit product inventories comprised $3.3 billion, $986 million, $956 million, $919 million and $874 million, respectively, and $214 million thereafter. Integrated circuit product inventory obligations represent purchase commitments for wafers, die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

- added (2015-01-28):
[0001234452-15-000024:note_history:14]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 25 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 are $69 million, $80 million, $61 million, $32 million, $21 million, respectively, and $27 million thereafter.

- removed (2015-01-28):
[0001234452-14-000238:note_history:15]
Legal Proceedings. Tessera, Inc. v. QUALCOMM Incorporated: On April 17, 2007, Tessera filed a patent infringement lawsuit in the United States District Court for the Eastern District of Texas and a complaint with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company and other companies, alleging infringement of two patents. The district court action was stayed pending resolution of the ITC proceeding, including all appeals. On January 18, 2012, pursuant to the parties’ stipulation, the District Court for the Eastern District of Texas lifted the stay and ordered that the case be moved to the United States District Court for the Northern District of California. On March 27, 2014, Tessera and the Company reached an agreement that the lawsuit against the Company would be dismissed with prejudice, and the parties will engage in discussions to explore potential technical collaborations. The court dismissed the lawsuit on April 1, 2014 based on the parties’ stipulation.

- removed (2015-01-28):
[0001234452-14-000238:note_history:16]
ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. The trial began on October 7, 2013. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of approximately $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. On June 25, 2014, ParkerVision filed a notice of appeal with the court. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company has reversed all recorded amounts related to the damages verdict. On May 1, 2014, ParkerVision filed another complaint, captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation and HTC America, Inc., also in the United States District Court for the Middle District of Florida, alleging that certain of the Company’s products infringe seven additional ParkerVision patents. The complaint seeks damages and injunctive and other relief. The Company has not been served with the complaint in this action.

- removed (2015-01-28):
[0001234452-14-000238:note_history:17]
Icera Complaint to the European Commission: On June 7, 2010, the European Commission (the Commission) notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. The Company continues to cooperate fully with the Commission’s preliminary investigation.

- removed (2015-01-28):
[0001234452-14-000238:note_history:18]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations, which generally have a remaining term of less than one year, under these agreements at June 29, 2014 for the remainder of fiscal 2014 and for each of the subsequent four years from fiscal 2015 through fiscal 2018 were approximately $3.0 billion, $387 million, $64 million, $19 million and $17 million, respectively, and $40 million thereafter. Of these amounts, for the remainder of fiscal 2014 and for fiscal 2015, commitments to purchase integrated circuit product inventories comprised $2.6 billion and $228 million, respectively. Integrated circuit product inventory obligations represent purchase commitments for wafers, die and assembly and test services. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase orders is generally allowed but requires payment of costs incurred through the date of cancelation.

- removed (2015-01-28):
[0001234452-14-000238:note_history:19]
Leases. The future minimum lease payments for all capital leases and operating leases at June 29, 2014 by fiscal year were as follows (in millions):

- removed (2015-01-28):
[0001234452-14-000238:note_history:20]
|  | CapitalLeases |  | OperatingLeases |  | Total |
| Remainder of fiscal 2014 | $ | — |  |  | $ | 25 |  |  | $ | 25 |  |
| 2015 | 1 |  |  | 93 |  |  | 94 |  |
| 2016 | 1 |  |  | 79 |  |  | 80 |  |
| 2017 | 1 |  |  | 58 |  |  | 59 |  |
| 2018 | 1 |  |  | 31 |  |  | 32 |  |
| Thereafter | 18 |  |  | 50 |  |  | 68 |  |
| Total minimum lease payments | 22 |  |  | $ | 336 |  |  | $ | 358 |  |
| Deduct: Amounts representing interest | 10 |  |  |  |  |  |
| Present value of minimum lease payments | 12 |  |  |  |  |  |
| Deduct: Current portion of capital lease obligations | 1 |  |  |  |  |  |
| Long-term portion of capital lease obligations | $ | 11 |  |  |  |  |  |

- removed (2015-01-28):
[0001234452-14-000238:note_history:21]
The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 25 years and with provisions in certain leases for cost-of-living increases. The Company leases certain property under capital lease agreements primarily related to site leases that have an initial term of five years with renewal options of up to five additional renewal periods. Capital lease obligations are included in other liabilities.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-01-28):
[0001234452-15-000024:note_history:22]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 28, 2014. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month periods ended December 28, 2014 and December 29, 2013 included 13 weeks.
  (was, 2014-07-23, similarity 0.9416):
[0001234452-14-000238:note_history:22]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim data includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 29, 2013. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 29, 2014 and June 30, 2013 included 13 weeks and 39 weeks, respectively.

- changed (2015-01-28):
[0001234452-15-000024:note_history:23]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three months ended December 28, 2014 and December 29, 2013 were 25,003,000 and 34,322,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 1,470,000 and 814,000 during the three months ended December 28, 2014 and December 29, 2013, respectively.
  (was, 2014-07-23, similarity 0.8232):
[0001234452-14-000238:note_history:23]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 29, 2014 were 30,642,000 and 31,985,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 30, 2013 were 37,927,000 and 40,132,000, respectively.

- changed (2015-01-28):
[0001234452-15-000024:note_history:24]
Share-Based Compensation. Total share-based compensation expense, related to all of the Company’s share-based awards, was comprised as follows (in millions):
  (was, 2014-07-23, similarity 0.9691):
[0001234452-14-000238:note_history:24]
Share-Based Compensation. Total estimated share-based compensation expense, related to all of the Company’s share-based awards, was comprised as follows (in millions):

- changed (2015-01-28):
[0001234452-15-000024:note_history:25]
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |
| Cost of equipment and services revenues | $ | 12 |  |  | $ | 12 |  |
| Research and development | 174 |  |  | 173 |  |
| Selling, general and administrative | 87 |  |  | 96 |  |
| Share-based compensation expense before income taxes | 273 |  |  | 281 |  |
| Related income tax benefit | (44 | ) |  | (55 | ) |
|  | $ | 229 |  |  | $ | 226 |  |
  (was, 2014-07-23, similarity 0.7133):
[0001234452-14-000238:note_history:25]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | June 29, 2014 |  | June 30, 2013 |
| Cost of equipment and services revenues | $ | 12 |  |  | $ | 18 |  |  | $ | 37 |  |  | $ | 55 |  |
| Research and development | 174 |  |  | 166 |  |  | 510 |  |  | 479 |  |
| Selling, general and administrative | 88 |  |  | 96 |  |  | 259 |  |  | 297 |  |
| Share-based compensation expense before income taxes | 274 |  |  | 280 |  |  | 806 |  |  | 831 |  |
| Related income tax benefit | (42 | ) |  | (58 | ) |  | (151 | ) |  | (169 | ) |
|  | $ | 232 |  |  | $ | 222 |  |  | $ | 655 |  |  | $ | 662 |  |

- added (2015-01-28):
[0001234452-15-000024:note_history:26]
The Company recorded $31 million in share-based compensation expense during each of the three months ended December 28, 2014 and December 29, 2013, related to share-based awards granted during those periods. At December 28, 2014, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.5 billion, which is expected to be recognized over a weighted-average period of 2.0 years. During the three months ended December 28, 2014 and December 29, 2013, net share-based awards granted, after forfeitures and cancelations, represented 0.4% of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.4% and 0.5%, respectively, of outstanding shares as of the end of each fiscal period.

- added (2015-01-28):
[0001234452-15-000024:note_history:27]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. This ASU will be effective for the Company starting in the first quarter of fiscal 2018. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the fiscal 2018 opening retained earnings balance. The Company is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.

- removed (2015-01-28):
[0001234452-14-000238:note_history:28]
Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 7,000 and 278,000 during the three and nine months ended June 29, 2014, respectively, and 720,000 and 589,000 during the three and nine months ended June 30, 2013, respectively.

- removed (2015-01-28):
[0001234452-14-000238:note_history:29]
The Company recorded $177 million and $152 million in share-based compensation expense during the nine months ended June 29, 2014 and June 30, 2013, respectively, related to share-based awards granted during those periods.

- removed (2015-01-28):
[0001234452-14-000238:note_history:30]
At June 29, 2014, total unrecognized compensation costs related to non-vested restricted stock units granted prior to that date were $1.5 billion, which are expected to be recognized over a weighted-average period of 2.0 years. During the nine months ended June 29, 2014 and June 30, 2013, net share-based awards granted, after forfeitures and cancelations, represented 0.8% and 0.7%, respectively, of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.9% and 0.8%, respectively, of outstanding shares as of the end of each fiscal period.

- removed (2015-01-28):
[0001234452-14-000238:note_history:31]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers.” ASU 2014-09 outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. ASU 2014-09 will be effective for the Company starting in the first quarter of fiscal 2018. ASU 2014-09 allows for two methods of adoption: (a) “full retrospective” adoption, meaning the standard is applied to all periods presented, or (b) “modified retrospective” adoption, meaning the cumulative effect of applying ASU 2014-09 is recognized as an adjustment to the fiscal 2018 opening retained earnings balance. The Company is in the process of determining the adoption method as well as the effects the adoption of ASU 2014-09 will have on its consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-01-28):
[0001234452-15-000024:note_history:32]
|  | Current |  | Noncurrent |
|  | December 28, 2014 |  | September 28, 2014 |  | December 28, 2014 |  | September 28, 2014 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 314 |  |  | $ | 320 |  |  | $ | 30 |  |  | $ | 38 |  |
| Corporate bonds and notes | 195 |  |  | 191 |  |  | 367 |  |  | 367 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 224 |  |  | 237 |  |
| Total trading | 509 |  |  | 511 |  |  | 621 |  |  | 642 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 500 |  |  | 805 |  |  | 660 |  |  | 392 |  |
| Corporate bonds and notes | 7,612 |  |  | 6,274 |  |  | 7,420 |  |  | 7,649 |  |
| Mortgage- and asset-backed securities | 1,111 |  |  | 1,063 |  |  | 201 |  |  | 195 |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | 83 |  |
| Common and preferred stock | 1,008 |  |  | 192 |  |  | 805 |  |  | 1,605 |  |
| Equity funds | — |  |  | — |  |  | 763 |  |  | 541 |  |
| Debt funds | 723 |  |  | 813 |  |  | 2,514 |  |  | 2,560 |  |
| Total available-for-sale | 10,954 |  |  | 9,147 |  |  | 12,410 |  |  | 13,025 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 784 |  |  | 790 |  |
| Total marketable securities | $ | 11,463 |  |  | $ | 9,658 |  |  | $ | 13,815 |  |  | $ | 14,457 |  |
  (was, 2014-07-23, similarity 0.9683):
[0001234452-14-000238:note_history:32]
|  | Current |  | Noncurrent |
|  | June 29, 2014 |  | September 29, 2013 |  | June 29, 2014 |  | September 29, 2013 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 317 |  |  | $ | 241 |  |  | $ | 47 |  |  | $ | 49 |  |
| Corporate bonds and notes | 195 |  |  | 269 |  |  | 380 |  |  | 256 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 215 |  |  | 104 |  |
| Total trading | 512 |  |  | 510 |  |  | 642 |  |  | 409 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 872 |  |  | 721 |  |  | 390 |  |  | 71 |  |
| Corporate bonds and notes | 6,553 |  |  | 4,533 |  |  | 7,687 |  |  | 6,812 |  |
| Mortgage- and asset-backed securities | 860 |  |  | 745 |  |  | 200 |  |  | 328 |  |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | 83 |  |
| Common and preferred stock | 342 |  |  | 8 |  |  | 1,664 |  |  | 2,351 |  |
| Equity funds | 160 |  |  | — |  |  | 521 |  |  | 960 |  |
| Debt funds | 910 |  |  | 2,307 |  |  | 2,589 |  |  | 2,889 |  |
| Total available-for-sale | 9,697 |  |  | 8,314 |  |  | 13,134 |  |  | 13,494 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 787 |  |  | 537 |  |
| Total marketable securities | $ | 10,209 |  |  | $ | 8,824 |  |  | $ | 14,563 |  |  | $ | 14,440 |  |

- added (2015-01-28):
[0001234452-15-000024:note_history:33]
In connection with the pending acquisition of CSR (Note 8), the Company agreed to set aside certain cash, cash equivalents and marketable securities to be held for purposes of satisfying payment of the consideration to effect the acquisition, which is expected to close by the end of the summer of 2015. At December 28, 2014, the fair values of the marketable securities that were set aside were $2.8 billion of corporate bonds and notes, $777 million of mortgage- and asset-backed securities and $146 million in U.S. Treasury securities and government-related securities. Additionally, $38 million in cash equivalents, which were recorded as other current assets, were set aside. If the combined fair values fall below approximately £1.9 billion (approximately $2.8 billion using an exchange rate of 1.51571), the Company may be required to set aside additional amounts. Additionally, if certain conditions are met, such as a reduction in the liquidity of any of the securities that are set aside, the Company may be required to liquidate the securities and transfer the cash to a third party until the acquisition closes.

- changed (2015-01-28):
[0001234452-15-000024:note_history:34]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At December 28, 2014, the Company had an effective ownership interest in the debt fund of 26%. Changes in fair value associated with this investment are recognized in net investment income. During the three months ended December 28, 2014, the net decrease in fair value associated with this investment was $6 million. During the three months ended December 29, 2013, the net increase in fair value associated with this investment was $13 million.
  (was, 2014-07-23, similarity 0.761):
[0001234452-14-000238:note_history:34]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At June 29, 2014, the Company had an effective ownership interest in the debt fund of 27%. Changes in fair value associated with this investment are recognized in net investment income. During the three and nine months ended June 29, 2014, net increases in fair value associated with this investment were $12 million and $30 million, respectively. During the three months ended June 30, 2013, the net decrease in fair value associated with this investment was $4 million. During the nine months ended June 30, 2013, the net increase in fair value associated with this investment was $14 million.

- changed (2015-01-28):
[0001234452-15-000024:note_history:35]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net losses recognized on debt securities classified as trading held at December 28, 2014 and December 29, 2013 were $12 million for the three months ended December 28, 2014 and negligible for the three months ended December 29, 2013, respectively.
  (was, 2014-07-23, similarity 0.6372):
[0001234452-14-000238:note_history:35]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains recognized on debt securities classified as trading held at June 29, 2014 were $7 million and $8 million for the three and nine months ended June 29, 2014, respectively. Net losses recognized on debt securities classified as trading held at June 30, 2013 were $21 million and $36 million for the three and nine months ended June 30, 2013, respectively.

- changed (2015-01-28):
[0001234452-15-000024:note_history:36]
At December 28, 2014, the contractual maturities of available-for-sale debt securities were as follows (in millions):
  (was, 2014-07-23, similarity 0.9541):
[0001234452-14-000238:note_history:36]
At June 29, 2014, the contractual maturities of available-for-sale debt securities were as follows (in millions):

- changed (2015-01-28):
[0001234452-15-000024:note_history:37]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities, auction rate securities and corporate bonds and notes.
  (was, 2014-07-23, similarity 0.8797):
[0001234452-14-000238:note_history:37]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities and auction rate securities.

- changed (2015-01-28):
[0001234452-15-000024:note_history:38]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| December 28, 2014 | $ | 180 |  |  | $ | (8 | ) |  | $ | 172 |  |
| December 29, 2013 | 116 |  |  | (3 | ) |  | 113 |  |
  (was, 2014-07-23, similarity 0.7243):
[0001234452-14-000238:note_history:38]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| June 29, 2014 | $ | 267 |  |  | $ | (8 | ) |  | $ | 259 |  |
| June 30, 2013 | 52 |  |  | (5 | ) |  | 47 |  |
| For the nine months ended |  |  |  |  |  |
| June 29, 2014 | $ | 610 |  |  | $ | (16 | ) |  | $ | 594 |  |
| June 30, 2013 | 204 |  |  | (14 | ) |  | 190 |  |

- added (2015-01-28):
[0001234452-15-000024:note_history:39]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| December 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 2,133 |  |  | $ | 465 |  |  | $ | (22 | ) |  | $ | 2,576 |  |
| Debt securities (including debt funds) | 20,690 |  |  | 242 |  |  | (144 | ) |  | 20,788 |  |
|  | $ | 22,823 |  |  | $ | 707 |  |  | $ | (166 | ) |  | $ | 23,364 |  |
| September 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,769 |  |  | $ | 575 |  |  | $ | (6 | ) |  | $ | 2,338 |  |
| Debt securities (including debt funds) | 19,582 |  |  | 312 |  |  | (60 | ) |  | 19,834 |  |
|  | $ | 21,351 |  |  | $ | 887 |  |  | $ | (66 | ) |  | $ | 22,172 |  |

- changed (2015-01-28):
[0001234452-15-000024:note_history:40]
|  | December 28, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 669 |  |  | $ | (12 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 9,172 |  |  | (115 | ) |  | 77 |  |  | (7 | ) |
| Mortgage- and asset-backed securities | 747 |  |  | (2 | ) |  | 37 |  |  | — |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | (1 | ) |
| Common and preferred stock | 128 |  |  | (10 | ) |  | 23 |  |  | (1 | ) |
| Debt funds | 384 |  |  | (7 | ) |  | 5 |  |  | — |  |
| Equity funds | 388 |  |  | (11 | ) |  | — |  |  | — |  |
|  | $ | 11,488 |  |  | $ | (157 | ) |  | $ | 189 |  |  | $ | (9 | ) |
  (was, 2014-07-23, similarity 0.9763):
[0001234452-14-000238:note_history:40]
|  | September 29, 2013 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 42 |  |  | $ | (1 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 2,084 |  |  | (31 | ) |  | 24 |  |  | (1 | ) |
| Mortgage- and asset-backed securities | 367 |  |  | (5 | ) |  | 24 |  |  | — |  |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Common and preferred stock | 291 |  |  | (41 | ) |  | — |  |  | — |  |
| Debt funds | 2,776 |  |  | (123 | ) |  | 4 |  |  | — |  |
| Equity funds | 82 |  |  | (3 | ) |  | — |  |  | — |  |
|  | $ | 5,642 |  |  | $ | (204 | ) |  | $ | 135 |  |  | $ | (2 | ) |

- added (2015-01-28):
[0001234452-15-000024:note_history:41]
|  | September 28, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 279 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,924 |  |  | (31 | ) |  | 104 |  |  | (4 | ) |
| Mortgage- and asset-backed securities | 484 |  |  | (1 | ) |  | 52 |  |  | (1 | ) |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Common and preferred stock | 86 |  |  | (3 | ) |  | 52 |  |  | (3 | ) |
| Debt funds | 133 |  |  | (1 | ) |  | 384 |  |  | (19 | ) |
|  | $ | 5,906 |  |  | $ | (38 | ) |  | $ | 675 |  |  | $ | (28 | ) |

- changed (2015-01-28):
[0001234452-15-000024:note_history:42]
At December 28, 2014, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common and preferred stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.
  (was, 2014-07-23, similarity 0.9894):
[0001234452-14-000238:note_history:42]
At June 29, 2014, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common and preferred stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

- changed (2015-01-28):
[0001234452-15-000024:note_history:43]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was negligible for each of the three months ended December 28, 2014 and December 29, 2013.
  (was, 2014-07-23, similarity 0.6742):
[0001234452-14-000238:note_history:43]
The following table shows the activity for the credit loss portion of other-than-temporary impairments on debt securities held by the Company (in millions):

- removed (2015-01-28):
[0001234452-14-000238:note_history:44]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| June 29, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 2,000 |  |  | $ | 692 |  |  | $ | (5 | ) |  | $ | 2,687 |  |
| Debt securities (including debt funds) | 19,741 |  |  | 423 |  |  | (20 | ) |  | 20,144 |  |
|  | $ | 21,741 |  |  | $ | 1,115 |  |  | $ | (25 | ) |  | $ | 22,831 |  |
| September 29, 2013 |  |  |  |  |  |  |  |
| Equity securities | $ | 2,570 |  |  | $ | 793 |  |  | $ | (44 | ) |  | $ | 3,319 |  |
| Debt securities (including debt funds) | 18,255 |  |  | 396 |  |  | (162 | ) |  | 18,489 |  |
|  | $ | 20,825 |  |  | $ | 1,189 |  |  | $ | (206 | ) |  | $ | 21,808 |  |

- removed (2015-01-28):
[0001234452-14-000238:note_history:45]
|  | June 29, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| Corporate bonds and notes | $ | 2,033 |  |  | $ | (5 | ) |  | $ | 96 |  |  | $ | (2 | ) |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Debt funds | 50 |  |  | (1 | ) |  | 394 |  |  | (11 | ) |
| Equity funds | 30 |  |  | — |  |  | 115 |  |  | (5 | ) |
|  | $ | 2,113 |  |  | $ | (6 | ) |  | $ | 688 |  |  | $ | (19 | ) |

- removed (2015-01-28):
[0001234452-14-000238:note_history:46]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | June 29, 2014 |  | June 30, 2013 |
| Beginning balance of credit losses | $ | 8 |  |  | $ | 8 |  |  | $ | 4 |  |  | $ | 31 |  |
| Reduction in credit losses related to securities the Company intends to sell | — |  |  | — |  |  | — |  |  | (6 | ) |
| Credit losses recognized on securities not previously impaired | — |  |  | — |  |  | 5 |  |  | 1 |  |
| Additional credit losses recognized on securities previously impaired | — |  |  | — |  |  | — |  |  | 1 |  |
| Reductions in credit losses related to securities sold | (3 | ) |  | (3 | ) |  | (4 | ) |  | (21 | ) |
| Accretion of credit losses due to an increase in cash flows expected to be collected | — |  |  | — |  |  | — |  |  | (1 | ) |
| Ending balance of credit losses | $ | 5 |  |  | $ | 5 |  |  | $ | 5 |  |  | $ | 5 |  |
