# QCOM notes — 0001234452-15-000024


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001234452-15-000024:notes:1]
Note 8 — Acquisitions

[0001234452-15-000024:notes:2]
In October 2014, the Company announced that it had reached agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.4 billion based upon an exchange rate of USD: GBP 1.51571). CSR is an innovator in the development of multifunction semiconductor platforms and technologies for the automotive, consumer and voice and music market categories. The acquisition complements the Company’s current offerings by adding products, channels and customers in the growth categories of the Internet of Everything and automotive infotainment, accelerating the Company’s presence and path to leadership. The acquisition has received approval of CSR’s shareholders and regulatory approval in the United States. The completion of the acquisition remains subject to satisfaction of a number of additional conditions, including other regulatory approvals. Subject to the satisfaction of these conditions, the acquisition is expected to close by the end of the summer of 2015. In connection with the pending acquisition, the Company agreed to set aside certain cash, cash equivalents and marketable securities (Note 11).


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001234452-15-000024:notes:3]
Note 6 — Commitments and Contingencies

[0001234452-15-000024:notes:4]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of approximately $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The parties are currently submitting appeal briefs to the Court of Appeals for the Federal Circuit, which will schedule a hearing once briefing is completed. On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision now alleges that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. The Company was served with the complaint in this second action on August 28, 2014 and answered on November 17, 2014. The judge has not yet set a schedule, but the parties have jointly proposed a claim construction hearing date in September 2015, a date for the close of discovery in the first half of 2016 and a trial date in early 2017.

[0001234452-15-000024:notes:5]
Nvidia Corporation v. Qualcomm Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd., and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chip products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District of Delaware complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. The evidentiary hearing for the investigation is set for June 22 to June 26, 2015. The Initial Determination of the Administrative Law Judge is due October 9, 2015, and the target date for completion of the investigation by the Commission is set for February 10, 2016. The district court case was stayed on October 23, 2014 pending completion of the ITC investigation including appeals.

[0001234452-15-000024:notes:6]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. The Company continues to cooperate with the Commission’s preliminary investigation.

[0001234452-15-000024:notes:7]
European Commission Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Article 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU) and Article 53 and/or 54 of the Agreement for the European Economic Area (EEA Agreement). The Company understands that the investigation concerns the sale and/or marketing of the Company’s baseband chipsets, including alleged conditions relating to the provision by the Company of rebates and/or other financial incentives. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. Given that this investigation is in its early stages, it is difficult to predict the outcome or what remedies, if any, may be imposed by the Commission. The Company continues to cooperate with the Commission as it conducts its investigation.

[0001234452-15-000024:notes:8]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chips and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments with respect to this matter.

[0001234452-15-000024:notes:9]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 25 different dates, with the next hearing scheduled for February 25, 2015.

[0001234452-15-000024:notes:10]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). As discussed below, FCPA compliance is also the focus of the SEC investigation. The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee has completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.

[0001234452-15-000024:notes:11]
As previously disclosed, the Company discovered, and as a part of its cooperation with these investigations informed the SEC and the DOJ of, instances in which special hiring consideration, gifts or other benefits (collectively, benefits) were provided to several individuals associated with Chinese state-owned companies or agencies. Based on the facts currently known, the Company believes the aggregate monetary value of the benefits in question to be less than $250,000, excluding employment compensation.

[0001234452-15-000024:notes:12]
On March 13, 2014, the Company received a Wells Notice from the SEC’s Los Angeles Regional Office indicating that the staff has made a preliminary determination to recommend that the SEC file an enforcement action against the Company for violations of the anti-bribery, books and records and internal control provisions of the FCPA. The bribery allegations relate to benefits offered or provided to individuals associated with Chinese state-owned companies or agencies. The Wells Notice indicated that the recommendation could involve a civil injunctive action and could seek remedies that include disgorgement of profits, the retention of an independent compliance monitor to review the Company’s FCPA policies and procedures, an injunction, civil monetary penalties and prejudgment interest.

[0001234452-15-000024:notes:13]
A Wells Notice is not a formal allegation or finding by the SEC of wrongdoing or violation of law. Rather, the purpose of a Wells Notice is to give the recipient an opportunity to make a “Wells submission” setting forth reasons why the proposed enforcement action should not be filed and/or bringing additional facts to the SEC’s attention before any decision is made by the SEC as to whether to commence a proceeding. On April 4, 2014 and May 29, 2014, the Company made Wells submissions to the staff of the Los Angeles Regional Office explaining why the Company believes it has not violated the FCPA and therefore enforcement action is not warranted.

[0001234452-15-000024:notes:14]
The Company is continuing to cooperate with the SEC and the DOJ, but is unable to predict the outcome of their investigations or any action that the SEC may decide to file.

[0001234452-15-000024:notes:15]
China National Development and Reform Commission (NDRC) Investigation: In November 2013, the NDRC notified the Company that it had commenced an investigation of the Company relating to the Chinese Anti-Monopoly Law (AML). The investigation concerns primarily the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business, including how royalties are calculated in the Company’s patent licenses, the value exchanged for cross-licenses to patents of the Company’s licensees, whether the Company will offer license agreements limited to patents essential to certain standards, whether royalties are sought for the Company’s expired patents, the Company’s policy of selling chipsets only to the Company’s patent licensees, the alleged refusal of the Company to grant patent licenses to chipset manufacturers, and certain other terms and conditions in the Company’s patent license and chipset sale agreements. A broad range of remedies with respect to business practices deemed to violate the AML is potentially available to the NDRC, including but not limited to issuing an order to cease conduct deemed illegal, confiscating gains deemed illegally obtained, imposing a fine in the range of 1% to 10% of the prior year’s revenues and requiring modifications to business practices. Given the limited precedent of enforcement actions and penalties under the AML, it is difficult to predict the outcome of this matter or what remedies may be imposed by the NDRC. The Company continues to cooperate with the NDRC as it conducts its investigation.

[0001234452-15-000024:notes:16]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act. The Company understands that the investigation concerns primarily the Company’s licensing business, including potential breach of FRAND commitments. If a violation of Section 5 is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s licensing practices. Given that this investigation is in its early stages, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company has responded to the FTC’s initial request for documents and continues to cooperate with the FTC as it conducts its investigation.

[0001234452-15-000024:notes:17]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at December 28, 2014 for contingent losses associated with these matters based on its belief that, with the exception of the NDRC matter, losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. Regarding the NDRC matter, the Company believes that a loss is probable but that any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001234452-15-000024:notes:18]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through December 28, 2014, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

[0001234452-15-000024:notes:19]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at December 28, 2014 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001234452-15-000024:notes:20]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at December 28, 2014 for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 were approximately $3.8 billion, $1.1 billion, $1.2 billion, $959 million and $892 million, respectively, and $242 million thereafter. Of these amounts, for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019, commitments to purchase integrated circuit product inventories comprised $3.3 billion, $986 million, $956 million, $919 million and $874 million, respectively, and $214 million thereafter. Integrated circuit product inventory obligations represent purchase commitments for wafers, die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

[0001234452-15-000024:notes:21]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 25 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 are $69 million, $80 million, $61 million, $32 million, $21 million, respectively, and $27 million thereafter.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001234452-15-000024:notes:22]
Note 9 — Discontinued Operations

[0001234452-15-000024:notes:23]
On November 25, 2013, the Company completed its sale of the North and Latin America operations of its Omnitracs division to a U.S.-based private equity firm for cash consideration of $788 million (net of cash sold). As a result, the Company recorded a gain in discontinued operations of $665 million ($430 million net of income tax expense) during fiscal 2014. The revenues and operating results of the North and Latin America operations of the Omnitracs division, which comprised substantially all of the Omnitracs division, were not presented as discontinued operations in any fiscal period because they were immaterial.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001234452-15-000024:notes:24]
Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three months ended December 28, 2014 and December 29, 2013 were 25,003,000 and 34,322,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 1,470,000 and 814,000 during the three months ended December 28, 2014 and December 29, 2013, respectively


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001234452-15-000024:notes:25]
The following table includes the activity for marketable securities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-15-000024:notes:26]
|  | Three Months Ended December 28, 2014 |  | Three Months Ended December 29, 2013 |
|  | Auction RateSecurities |  | Mortgage- and Asset-BackedSecurities |  | Auction RateSecurities |  | Mortgage- and Asset-BackedSecurities |
| Beginning balance of Level 3 | $ | 83 |  |  | $ | 186 |  |  | $ | 83 |  |  | $ | 239 |  |
| Total realized and unrealized gains or losses: |  |  |  |  |  |  |  |
| Included in investment income, net | — |  |  | — |  |  | — |  |  | 2 |  |
| Included in other comprehensive income | 1 |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Purchases | — |  |  | 29 |  |  | — |  |  | 23 |  |
| Sales | — |  |  | (24 | ) |  | — |  |  | (9 | ) |
| Settlements | (37 | ) |  | (7 | ) |  | — |  |  | (8 | ) |
| Ending balance of Level 3 | $ | 47 |  |  | $ | 183 |  |  | $ | 83 |  |  | $ | 246 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001234452-15-000024:notes:27]
Note 10 — Fair Value Measurements

[0001234452-15-000024:notes:28]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at December 28, 2014 (in millions):

[0001234452-15-000024:notes:29]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 3,226 |  |  | $ | 2,692 |  |  | $ | — |  |  | $ | 5,918 |  |
| Marketable securities (a) |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 389 |  |  | 1,115 |  |  | — |  |  | 1,504 |  |
| Corporate bonds and notes | — |  |  | 15,594 |  |  | — |  |  | 15,594 |  |
| Mortgage- and asset-backed securities | — |  |  | 1,353 |  |  | 183 |  |  | 1,536 |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | 47 |  |
| Common and preferred stock | 1,126 |  |  | 687 |  |  | — |  |  | 1,813 |  |
| Equity funds | 763 |  |  | — |  |  | — |  |  | 763 |  |
| Debt funds | 473 |  |  | 3,548 |  |  | — |  |  | 4,021 |  |
| Total marketable securities | 2,751 |  |  | 22,297 |  |  | 230 |  |  | 25,278 |  |
| Derivative instruments | 1 |  |  | 5 |  |  | — |  |  | 6 |  |
| Other investments (a) | 326 |  |  | — |  |  | — |  |  | 326 |  |
| Total assets measured at fair value | $ | 6,304 |  |  | $ | 24,994 |  |  | $ | 230 |  |  | $ | 31,528 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 6 |  |  | $ | — |  |  | $ | 6 |  |
| Other liabilities | 288 |  |  | — |  |  | — |  |  | 288 |  |
| Total liabilities measured at fair value | $ | 288 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 294 |  |

[0001234452-15-000024:notes:30]
(a) Included amounts that are restricted (Note 11).

[0001234452-15-000024:notes:31]
Activity between Levels of the Fair Value Hierarchy. There were no significant transfers between Level 1 and Level 2 during the three months ended December 28, 2014 or December 29, 2013. When a determination is made to classify an asset or liability within Level 3, the determination is based upon the significance of the unobservable inputs to the overall fair value measurement. The following table includes the activity for marketable securities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-15-000024:notes:32]
The Company recognizes transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. There were no transfers in or out of Level 3 during the three months ended December 28, 2014 or December 29, 2013.

[0001234452-15-000024:notes:33]
Nonrecurring Fair Value Measurements. The Company measures certain assets at fair value on a nonrecurring basis. These assets include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During the three months ended December 28, 2014, the Company updated the business plan and related internal forecasts related to the Company’s business that provides push-to-talk enablement services to wireless operators, resulting in a goodwill impairment charge of $69 million. During the three months ended December 29, 2013, the Company recorded impairment charges of $444 million and $16 million to write down certain property, plant and equipment related to the Company’s QMT division and goodwill related to its former QRS division, respectively. The impairment charges were recorded in other operating expenses. The Company determined the fair values using cost, income and market approaches. The estimation of fair value and cash flows used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During the three months ended December 28, 2014 and December 29, 2013, the Company did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001234452-15-000024:notes:34]
[same as prior period, unchanged from 0001234452-14-000238:notes:47]

[0001234452-15-000024:notes:35]
The Company estimates its annual effective income tax rate for continuing operations to be approximately 17% for fiscal 2015, which is greater than its 14% effective income tax rate for fiscal 2014. Tax benefits from foreign income taxed at rates lower than rates in the United States are expected to be approximately 16% in fiscal 2015, compared to 20% in fiscal 2014. During the first quarter of fiscal 2015, the United States government reinstated the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. As a result of the reinstatement, the Company recorded a tax benefit of $101 million related to fiscal 2014 in the first quarter of fiscal 2015. Additionally, the estimated annual effective tax rate for fiscal 2015 reflects the United States federal research and development tax credit generated through December 31, 2014, the date on which the credit expired. The annual effective tax rate for fiscal 2014 reflected the tax benefit from the credit generated through December 31, 2013, the date on which the credit previously expired. The effective tax rate of 14% for the first quarter of fiscal 2015 was less than the estimated annual effective tax rate of 17% primarily as a result of the retroactive reinstatement of the United States federal research and development tax credit.

[0001234452-15-000024:notes:36]
The Company believes that it is reasonably possible that several tax audits will be resolved within the next 12 months, thereby decreasing some or all of its $76 million unrecognized tax liability, which will reduce the effective tax rate to the extent tax benefits are sustained or in the settlement of the liability with the tax authorities to the extent not sustained.


## us-gaap:InterestAndOtherIncomeTextBlock

[0001234452-15-000024:notes:37]
[same as prior period, unchanged from 0001234452-14-000238:notes:50]

[0001234452-15-000024:notes:38]
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |
| Interest and dividend income | $ | 134 |  |  | $ | 156 |  |
| Interest expense | (1 | ) |  | (3 | ) |
| Net realized gains on marketable securities | 156 |  |  | 128 |  |
| Net realized gains on other investments | 10 |  |  | 17 |  |
| Impairment losses on marketable securities | (62 | ) |  | (30 | ) |
| Impairment losses on other investments | (3 | ) |  | (7 | ) |
| Net gains on derivative instruments | 4 |  |  | 4 |  |
| Equity in net losses of investees | (4 | ) |  | (1 | ) |
|  | $ | 234 |  |  | $ | 264 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001234452-15-000024:notes:39]
At December 28, 2014, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001234452-15-000024:notes:40]
| Years to Maturity |  |  |  |  |
| Less Than One Year |  | One to Five Years |  | Five to Ten Years |  | Greater Than Ten Years |  | No Single Maturity Date |  | Total |
| $ | 3,069 |  |  | $ | 11,054 |  |  | $ | 1,439 |  |  | $ | 626 |  |  | $ | 4,600 |  |  | $ | 20,788 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001234452-15-000024:notes:41]
Note 11 — Marketable Securities

[0001234452-15-000024:notes:42]
Marketable securities were comprised as follows (in millions):

[0001234452-15-000024:notes:43]
|  | Current |  | Noncurrent |
|  | December 28, 2014 |  | September 28, 2014 |  | December 28, 2014 |  | September 28, 2014 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 314 |  |  | $ | 320 |  |  | $ | 30 |  |  | $ | 38 |  |
| Corporate bonds and notes | 195 |  |  | 191 |  |  | 367 |  |  | 367 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 224 |  |  | 237 |  |
| Total trading | 509 |  |  | 511 |  |  | 621 |  |  | 642 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 500 |  |  | 805 |  |  | 660 |  |  | 392 |  |
| Corporate bonds and notes | 7,612 |  |  | 6,274 |  |  | 7,420 |  |  | 7,649 |  |
| Mortgage- and asset-backed securities | 1,111 |  |  | 1,063 |  |  | 201 |  |  | 195 |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | 83 |  |
| Common and preferred stock | 1,008 |  |  | 192 |  |  | 805 |  |  | 1,605 |  |
| Equity funds | — |  |  | — |  |  | 763 |  |  | 541 |  |
| Debt funds | 723 |  |  | 813 |  |  | 2,514 |  |  | 2,560 |  |
| Total available-for-sale | 10,954 |  |  | 9,147 |  |  | 12,410 |  |  | 13,025 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 784 |  |  | 790 |  |
| Total marketable securities | $ | 11,463 |  |  | $ | 9,658 |  |  | $ | 13,815 |  |  | $ | 14,457 |  |

[0001234452-15-000024:notes:44]
In connection with the pending acquisition of CSR (Note 8), the Company agreed to set aside certain cash, cash equivalents and marketable securities to be held for purposes of satisfying payment of the consideration to effect the acquisition, which is expected to close by the end of the summer of 2015. At December 28, 2014, the fair values of the marketable securities that were set aside were $2.8 billion of corporate bonds and notes, $777 million of mortgage- and asset-backed securities and $146 million in U.S. Treasury securities and government-related securities. Additionally, $38 million in cash equivalents, which were recorded as other current assets, were set aside. If the combined fair values fall below approximately £1.9 billion (approximately $2.8 billion using an exchange rate of 1.51571), the Company may be required to set aside additional amounts. Additionally, if certain conditions are met, such as a reduction in the liquidity of any of the securities that are set aside, the Company may be required to liquidate the securities and transfer the cash to a third party until the acquisition closes.

[0001234452-15-000024:notes:45]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At December 28, 2014, the Company had an effective ownership interest in the debt fund of 26%. Changes in fair value associated with this investment are recognized in net investment income. During the three months ended December 28, 2014, the net decrease in fair value associated with this investment was $6 million. During the three months ended December 29, 2013, the net increase in fair value associated with this investment was $13 million.

[0001234452-15-000024:notes:46]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net losses recognized on debt securities classified as trading held at December 28, 2014 and December 29, 2013 were $12 million for the three months ended December 28, 2014 and negligible for the three months ended December 29, 2013, respectively.

[0001234452-15-000024:notes:47]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities, auction rate securities and corporate bonds and notes.

[0001234452-15-000024:notes:48]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001234452-15-000024:notes:49]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| December 28, 2014 | $ | 180 |  |  | $ | (8 | ) |  | $ | 172 |  |
| December 29, 2013 | 116 |  |  | (3 | ) |  | 113 |  |

[0001234452-15-000024:notes:50]
Available-for-sale securities were comprised as follows (in millions):

[0001234452-15-000024:notes:51]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| December 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 2,133 |  |  | $ | 465 |  |  | $ | (22 | ) |  | $ | 2,576 |  |
| Debt securities (including debt funds) | 20,690 |  |  | 242 |  |  | (144 | ) |  | 20,788 |  |
|  | $ | 22,823 |  |  | $ | 707 |  |  | $ | (166 | ) |  | $ | 23,364 |  |
| September 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,769 |  |  | $ | 575 |  |  | $ | (6 | ) |  | $ | 2,338 |  |
| Debt securities (including debt funds) | 19,582 |  |  | 312 |  |  | (60 | ) |  | 19,834 |  |
|  | $ | 21,351 |  |  | $ | 887 |  |  | $ | (66 | ) |  | $ | 22,172 |  |

[0001234452-15-000024:notes:52]
The following table shows the gross unrealized losses and fair values of the Company’s investments in individual securities that are classified as available-for-sale and have been in a continuous unrealized loss position deemed to be temporary for less than 12 months and for more than 12 months, aggregated by investment category (in millions):

[0001234452-15-000024:notes:53]
|  | December 28, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 669 |  |  | $ | (12 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 9,172 |  |  | (115 | ) |  | 77 |  |  | (7 | ) |
| Mortgage- and asset-backed securities | 747 |  |  | (2 | ) |  | 37 |  |  | — |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | (1 | ) |
| Common and preferred stock | 128 |  |  | (10 | ) |  | 23 |  |  | (1 | ) |
| Debt funds | 384 |  |  | (7 | ) |  | 5 |  |  | — |  |
| Equity funds | 388 |  |  | (11 | ) |  | — |  |  | — |  |
|  | $ | 11,488 |  |  | $ | (157 | ) |  | $ | 189 |  |  | $ | (9 | ) |

[0001234452-15-000024:notes:54]
|  | September 28, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 279 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,924 |  |  | (31 | ) |  | 104 |  |  | (4 | ) |
| Mortgage- and asset-backed securities | 484 |  |  | (1 | ) |  | 52 |  |  | (1 | ) |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Common and preferred stock | 86 |  |  | (3 | ) |  | 52 |  |  | (3 | ) |
| Debt funds | 133 |  |  | (1 | ) |  | 384 |  |  | (19 | ) |
|  | $ | 5,906 |  |  | $ | (38 | ) |  | $ | 675 |  |  | $ | (28 | ) |

[0001234452-15-000024:notes:55]
At December 28, 2014, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common and preferred stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

[0001234452-15-000024:notes:56]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was negligible for each of the three months ended December 28, 2014 and December 29, 2013.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001234452-15-000024:notes:57]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. This ASU will be effective for the Company starting in the first quarter of fiscal 2018. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the fiscal 2018 opening retained earnings balance. The Company is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001234452-15-000024:notes:58]
[same as prior period, unchanged from 0001234452-14-000238:notes:70]

[0001234452-15-000024:notes:59]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 28, 2014. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month periods ended December 28, 2014 and December 29, 2013 included 13 weeks.

[0001234452-15-000024:notes:60]
[same as prior period, unchanged from 0001234452-14-000238:notes:72]

[0001234452-15-000024:notes:61]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three months ended December 28, 2014 and December 29, 2013 were 25,003,000 and 34,322,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 1,470,000 and 814,000 during the three months ended December 28, 2014 and December 29, 2013, respectively.

[0001234452-15-000024:notes:62]
Share-Based Compensation. Total share-based compensation expense, related to all of the Company’s share-based awards, was comprised as follows (in millions):

[0001234452-15-000024:notes:63]
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |
| Cost of equipment and services revenues | $ | 12 |  |  | $ | 12 |  |
| Research and development | 174 |  |  | 173 |  |
| Selling, general and administrative | 87 |  |  | 96 |  |
| Share-based compensation expense before income taxes | 273 |  |  | 281 |  |
| Related income tax benefit | (44 | ) |  | (55 | ) |
|  | $ | 229 |  |  | $ | 226 |  |

[0001234452-15-000024:notes:64]
The Company recorded $31 million in share-based compensation expense during each of the three months ended December 28, 2014 and December 29, 2013, related to share-based awards granted during those periods. At December 28, 2014, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.5 billion, which is expected to be recognized over a weighted-average period of 2.0 years. During the three months ended December 28, 2014 and December 29, 2013, net share-based awards granted, after forfeitures and cancelations, represented 0.4% of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.4% and 0.5%, respectively, of outstanding shares as of the end of each fiscal period.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001234452-15-000024:notes:65]
| Other Current Liabilities (in millions) |  |  |  |
|  | December 28, 2014 |  | September 28, 2014 |
| Customer incentives and other customer-related liabilities | $ | 1,838 |  |  | $ | 1,777 |  |
| Other | 414 |  |  | 466 |  |
|  | $ | 2,252 |  |  | $ | 2,243 |  |


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001234452-15-000024:notes:66]
[same as prior period, unchanged from 0001234452-14-000238:notes:82]

[0001234452-15-000024:notes:67]
|  | December 28, 2014 |  | September 28, 2014 |
| QCT | $ | 3,577 |  |  | $ | 3,639 |  |
| QTL | 365 |  |  | 161 |  |
| QSI | 588 |  |  | 484 |  |
| Reconciling items | 43,917 |  |  | 44,290 |  |
| Total consolidated assets | $ | 48,447 |  |  | $ | 48,574 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001234452-15-000024:notes:68]
[same as prior period, unchanged from 0001234452-14-000238:notes:88]

[0001234452-15-000024:notes:69]
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |
| Cost of equipment and services revenues | $ | 67 |  |  | $ | 61 |  |
| Research and development expenses | 4 |  |  | 1 |  |
| Selling, general and administrative expenses | 12 |  |  | 7 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001234452-15-000024:notes:70]
Reconciling items in the previous table were as follows (in millions):

[0001234452-15-000024:notes:71]
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |
| Revenues |  |  |  |
| Nonreportable segments | $ | 43 |  |  | $ | 108 |  |
| Intersegment eliminations | (2 | ) |  | (2 | ) |
|  | $ | 41 |  |  | $ | 106 |  |
| EBT |  |  |  |
| Unallocated cost of equipment and services revenues | $ | (79 | ) |  | $ | (73 | ) |
| Unallocated research and development expenses | (210 | ) |  | (217 | ) |
| Unallocated selling, general and administrative expenses | (150 | ) |  | (125 | ) |
| Unallocated other expense | (69 | ) |  | (12 | ) |
| Unallocated investment income, net | 231 |  |  | 257 |  |
| Nonreportable segments | (148 | ) |  | (653 | ) |
| Intersegment eliminations | (1 | ) |  | — |  |
|  | $ | (426 | ) |  | $ | (823 | ) |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001234452-15-000024:notes:72]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity during the three months ended December 28, 2014 were as follows (in millions):

[0001234452-15-000024:notes:73]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Total Accumulated Other Comprehensive Income |
| Balance at September 28, 2014 | $ | (113 | ) |  | $ | 24 |  |  | $ | 723 |  |  | $ | — |  |  | $ | 634 |  |
| Other comprehensive loss before reclassifications | (21 | ) |  | (8 | ) |  | (104 | ) |  | (2 | ) |  | (135 | ) |
| Reclassifications from accumulated other comprehensive income | — |  | (a) | 6 |  | (a) | (77 | ) | (a) | — |  | (b) | (71 | ) |
| Other comprehensive loss | (21 | ) |  | (2 | ) |  | (181 | ) |  | (2 | ) |  | (206 | ) |
| Balance at December 28, 2014 | $ | (134 | ) |  | $ | 22 |  |  | $ | 542 |  |  | $ | (2 | ) |  | $ | 428 |  |

[0001234452-15-000024:notes:74]
| (a) | Reclassifications from accumulated other comprehensive income of $71 million and $53 million for the three months ended December 28, 2014 and December 29, 2013, respectively, were recorded in investment income, net (Note 3). |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001234452-15-000024:notes:75]
| Inventories (in millions) |  |  |  |
|  | December 28, 2014 |  | September 28, 2014 |
| Raw materials | $ | 1 |  |  | $ | 1 |  |
| Work-in-process | 753 |  |  | 656 |  |
| Finished goods | 1,007 |  |  | 801 |  |
|  | $ | 1,761 |  |  | $ | 1,458 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001234452-15-000024:notes:76]
[same as prior period, unchanged from 0001234452-14-000238:notes:95]

[0001234452-15-000024:notes:77]
|  | QCT |  | QTL |  | QSI |  | ReconcilingItems |  | Total |
| For the three months ended: |  |  |  |  |  |  |  |  |  |
| December 28, 2014 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 5,242 |  |  | $ | 1,816 |  |  | $ | — |  |  | $ | 41 |  |  | $ | 7,099 |  |
| EBT | 1,146 |  |  | 1,579 |  |  | (1 | ) |  | (426 | ) |  | 2,298 |  |
| December 29, 2013 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 4,616 |  |  | $ | 1,900 |  |  | $ | — |  |  | $ | 106 |  |  | $ | 6,622 |  |
| EBT | 906 |  |  | 1,670 |  |  | 4 |  |  | (823 | ) |  | 1,757 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001234452-15-000024:notes:78]
Changes in stockholders’ equity for the three months ended December 28, 2014 were as follows (in millions):

[0001234452-15-000024:notes:79]
|  | Qualcomm Stockholders’ Equity |  | Noncontrolling Interests |  | Total Stockholders’ Equity |
| Balance at September 28, 2014 | $ | 39,169 |  |  | $ | (3 | ) |  | $ | 39,166 |  |
| Net income (loss) | 1,972 |  |  | (1 | ) |  | 1,971 |  |
| Other comprehensive loss | (206 | ) |  | — |  |  | (206 | ) |
| Common stock issued under employee benefit plans and related tax benefits | 162 |  |  | — |  |  | 162 |  |
| Share-based compensation | 286 |  |  | — |  |  | 286 |  |
| Tax withholding related to vesting of restricted stock units | (185 | ) |  | — |  |  | (185 | ) |
| Dividends | (710 | ) |  | — |  |  | (710 | ) |
| Stock repurchases | (1,664 | ) |  | — |  |  | (1,664 | ) |
| Other | (1 | ) |  | — |  |  | (1 | ) |
| Balance at December 28, 2014 | $ | 38,823 |  |  | $ | (4 | ) |  | $ | 38,819 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001234452-15-000024:notes:80]
[same as prior period, unchanged from 0001234452-14-000238:notes:100]

[0001234452-15-000024:notes:81]
[same as prior period, unchanged from 0001234452-14-000238:notes:101]

[0001234452-15-000024:notes:82]
[same as prior period, unchanged from 0001234452-14-000238:notes:102]

[0001234452-15-000024:notes:83]
| • | QTL (Qualcomm Technology Licensing) segment — grants licenses or otherwise provides rights to use portions of the Company’s intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD (including TD-SCDMA), GSM/GPRS/EDGE and/or OFDMA (including LTE) standards and their derivatives. |

[0001234452-15-000024:notes:84]
| • | QSI (Qualcomm Strategic Initiatives) segment — comprised of the Company’s Qualcomm Ventures and Structured Finance & Strategic Investments divisions. QSI makes strategic investments that are focused on opening new or expanding opportunities for its technologies and supporting the design and introduction of new products or services (or enhancing existing products or services) for voice and data communications. Many of these strategic investments are in early-stage companies. QSI also holds wireless spectrum. |

[0001234452-15-000024:notes:85]
Nonreportable segments include the Company’s QMT (Qualcomm MEMS Technologies), Pixtronix and Small Cells divisions and other wireless technology and service initiatives. QMT plans to license its next generation IMOD (interferometric modulator) display technology and to focus on wearable devices. Pixtronix develops and licenses display technologies based on MEMS (micro-electro-mechanical-systems) structure optimized for portable multimedia devices. Small Cells develops and supplies 3G/LTE and Wi-Fi products designed for implementation of small mobile base stations (known as small cells). Other nonreportable segments develop and offer products and services that include, but are not limited to: software products, content and push-to-talk enablement services to wireless operators; development, other services and related products to U.S. government agencies and their contractors; device-to-device communication, including software for the connected home; data center products; medical device connectivity and related data management; and augmented reality.

[0001234452-15-000024:notes:86]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT) from continuing operations. Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization and impairment of certain intangible assets and certain other acquisition-related charges, and beginning in the first quarter of fiscal 2015, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. The table below presents revenues and EBT for reportable segments (in millions):

[0001234452-15-000024:notes:87]
Intersegment revenues included in QCT revenues were negligible in all periods presented. All other revenues for reportable segments were from external customers for all periods presented.

[0001234452-15-000024:notes:88]
Unallocated other expense for the three months ended December 28, 2014 included a $69 million goodwill impairment charge related to the Company’s business that provides push-to-talk enablement services to wireless operators (Note 10). Nonreportable segments EBT for the three months ended December 29, 2013 included a total of $444 million in impairment charges related to the Company’s QMT division.

[0001234452-15-000024:notes:89]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets include certain marketable securities, notes receivable, wireless spectrum, other investments and all assets of consolidated subsidiaries included in QSI. Total segment assets differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable securities, property, plant and equipment, deferred tax assets, goodwill, other intangible assets and assets of nonreportable segments. Segment assets and reconciling items were as follows (in millions):


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001234452-15-000024:notes:90]
[same as prior period, unchanged from 0001234452-14-000238:notes:110]

[0001234452-15-000024:notes:91]
| (b) | Reclassifications from accumulated other comprehensive income of $6 million for the three months ended December 29, 2013 were recorded in revenues, cost of equipment and services revenues, research and development expenses and selling, general and administrative expenses. |

[0001234452-15-000024:notes:92]
Stock Repurchase Program. During the three months ended December 28, 2014 and December 29, 2013, the Company repurchased and retired 22,940,000 and 14,196,000 shares of common stock, respectively, for $1.7 billion and $1.0 billion, respectively, before commissions. On March 4, 2014, the Company announced a stock repurchase program authorizing it to repurchase up to $7.8 billion of the Company’s common stock. The stock repurchase program has no expiration date. At December 28, 2014, approximately $3.6 billion remained authorized for repurchase under the Company’s stock repurchase program. Since December 28, 2014, the Company repurchased and retired 6,841,000 shares of common stock for $502 million.

[0001234452-15-000024:notes:93]
Dividends. Cash dividends announced in the three months ended December 28, 2014 and December 29, 2013 were $0.42 and $0.35 per share, respectively. During the three months ended December 28, 2014 and December 29, 2013, dividends charged to retained earnings were $710 million and $599 million, respectively. On January 14, 2015, the Company announced a cash dividend of $0.42 per share on the Company’s common stock, payable on March 25, 2015 to stockholders of record as of the close of business on March 4, 2015.


## qcom:CompositionOfCertainFinancialStatementCaptionsTextBlock

[0001234452-15-000024:notes:94]
[same as prior period, unchanged from 0001234452-14-000238:notes:113]
