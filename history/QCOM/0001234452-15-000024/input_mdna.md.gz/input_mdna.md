# QCOM MD&A — 0001234452-15-000024


## mdna

[0001234452-15-000024:mdna:1]
[same as prior period, unchanged from 0001234452-14-000238:mdna:1]

[0001234452-15-000024:mdna:2]
This information should be read in conjunction with the condensed consolidated financial statements and the notes thereto included in Part I, Item 1 of this Quarterly Report and with Management’s Discussion and Analysis of Financial Condition and Results of Operations for the year ended September 28, 2014 contained in our 2014 Annual Report on Form 10-K.

[0001234452-15-000024:mdna:3]
[same as prior period, unchanged from 0001234452-14-000238:mdna:3]

[0001234452-15-000024:mdna:4]
[same as prior period, unchanged from 0001234452-14-000238:mdna:5]

[0001234452-15-000024:mdna:5]
Revenues for the first quarter of fiscal 2015 were $7.1 billion, with net income attributable to Qualcomm of $2.0 billion, which primarily resulted from the following key items:

[0001234452-15-000024:mdna:6]
| • | We shipped approximately 270 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, an increase of approximately 27%, compared to approximately 213 million MSM integrated circuits in the year ago quarter. |

[0001234452-15-000024:mdna:7]
| • | Total reported device sales were approximately $56.4 billion, a decrease of approximately 8%, compared to approximately $61.6 billion in the year ago quarter.(1) |

[0001234452-15-000024:mdna:8]
Against this backdrop, the following recent developments occurred during the first quarter of fiscal 2015 with respect to key elements of our business or our industry:

[0001234452-15-000024:mdna:9]
| • | Worldwide cellular connections grew sequentially by approximately 2% to reach approximately 7.1 billion.(2) |

[0001234452-15-000024:mdna:10]
| • | Worldwide 3G/4G connections (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) grew sequentially by approximately 5% to approximately 2.9 billion, which was approximately 41% of total cellular connections.(2) |

[0001234452-15-000024:mdna:11]
[same as prior period, unchanged from 0001234452-14-000238:mdna:12]

[0001234452-15-000024:mdna:12]
| (2) | According to GSMA Intelligence estimates as of January 26, 2015, for the quarter ended December 31, 2014. |

[0001234452-15-000024:mdna:13]
[same as prior period, unchanged from 0001234452-14-000238:mdna:15]

[0001234452-15-000024:mdna:14]
[same as prior period, unchanged from 0001234452-14-000238:mdna:16]

[0001234452-15-000024:mdna:15]
We have three reportable segments. We conduct business primarily through two reportable segments: QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing), and our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering, research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001234452-15-000024:mdna:16]
QCT is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products and system software are sold to or licensed to manufacturers that use our products in wireless devices, particularly mobile phones, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards and infrastructure equipment, and in wired devices, particularly broadband gateway equipment, desktop computers and streaming media players. Our MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Qualcomm Snapdragon processors, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon processors provide advanced application and graphics processing capabilities. QCT’s system software enables the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits. QCT revenues comprised 74% and 70% of total consolidated revenues in the first quarter of fiscal 2015 and 2014, respectively.

[0001234452-15-000024:mdna:17]
QCT utilizes a fabless production business model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Integrated circuits are die cut from silicon wafers that have completed the package assembly and test manufacturing processes. We rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits based primarily on our proprietary designs and test programs. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Turnkey is when our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die or wafers from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services, such as wafer bump, probe, assembly and final test.

[0001234452-15-000024:mdna:18]
QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD (including TD-SCDMA), GSM/GPRS/EDGE and/or OFDMA standards and their derivatives. QTL licensing revenues are comprised of license fees as well as royalties based on sales by licensees of products incorporating or using our intellectual property. License fees are fixed amounts paid in one or more installments. Royalties are generally based upon a percentage of the wholesale selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). QTL recognizes royalty revenues based on royalties reported by licensees during the quarter and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. QTL revenues comprised 26% and 29% of total consolidated revenues in the first quarter of fiscal 2015 and 2014, respectively. The vast majority of such revenues were generated through our licensees’ sales of CDMA2000- and WCDMA-based products, such as feature phones and smartphones.

[0001234452-15-000024:mdna:19]
QSI makes strategic investments that are focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications. Many of these strategic investments are in early-stage companies in a variety of industries, including, but not limited to, digital media, e-commerce, energy, healthcare and wearable devices. Investments primarily include non-marketable equity instruments, which generally are recorded using the cost method or

[0001234452-15-000024:mdna:20]
22

[0001234452-15-000024:mdna:21]
the equity method, and convertible debt instruments, which are recorded at fair value. QSI also holds wireless spectrum, which at December 28, 2014, consisted of L-Band spectrum in the United Kingdom. As part of our strategic investment activities, we intend to pursue various exit strategies for each of our QSI investments in the foreseeable future.

[0001234452-15-000024:mdna:22]
Nonreportable segments include our QMT (Qualcomm MEMS Technologies), Pixtronix and Small Cells divisions and other wireless technology and service initiatives. QMT plans to license its next generation IMOD (interferometric modulator) display technology and to focus on wearable devices. Pixtronix develops and licenses display technologies based on MEMS (micro-electro-mechanical-systems) structure optimized for portable multimedia devices. Small Cells develops and supplies 3G/LTE and Wi-Fi products designed for implementation of small mobile base stations (known as small cells). Other nonreportable segments develop and offer products and services that include, but are not limited to: software products and content and push-to-talk enablement services to wireless operators; development, other services and related products to U.S. government agencies and their contractors; device-to-device communication, including software for the connected home; data center products; medical device connectivity and related data management; and augmented reality.

[0001234452-15-000024:mdna:23]
Seasonality. Many of our products or intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has tended historically to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons; and because QTL recognizes royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made during the fourth calendar quarter. We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 3G/4G networks by wireless operators and the timing of launches of flagship wireless devices that incorporate our products and/or intellectual property.

[0001234452-15-000024:mdna:24]
[same as prior period, unchanged from 0001234452-14-000238:mdna:28]

[0001234452-15-000024:mdna:25]
We expect continued growth in the coming years in consumer demand for 3G, 3G/4G multimode and 4G products and services around the world, driven primarily by smartphones. We also expect growth in new device categories and industries, driven by the expanding adoption of certain technologies that are already commonly used in smartphones. As we look forward to the next several months, we expect our business to be impacted by the following key items:

[0001234452-15-000024:mdna:26]
| • | Further expansion of 3G and 3G/4G multimode in emerging regions, particularly in China. We expect that the increased availability of low-tier 3G/4G smartphone products will help enable such expansion. |

[0001234452-15-000024:mdna:27]
| • | We expect that 3G/4G device prices will continue to vary broadly due to the increased penetration of smartphones combined with competition throughout the world at all price tiers. Additionally, varying rates of economic growth by region, and stronger growth of device shipments in emerging regions as compared to developed regions, are expected to continue to impact the average and range of selling prices of 3G/4G devices. |

[0001234452-15-000024:mdna:28]
| • | China continues to present significant opportunities for us, particularly with the rollout of 3G/4G LTE multimode. We expect the rollout of 4G services in China will encourage competition and growth, bring the benefits of 3G/4G LTE multimode to consumers, encourage consumers to replace 2G (GSM) and 3G devices and enable new opportunities (e.g., machine-to-machine) for the industry. |

[0001234452-15-000024:mdna:29]
| • | China also presents significant challenges, as our business practices continue to be the subject of an investigation by the China National Development and Reform Commission (NDRC). We resolved the previously disclosed dispute with a licensee in China in the first quarter of fiscal 2015. However, we continue to believe that certain licensees in China are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes certain licensees underreporting a portion of their 3G/4G device sales) and that unlicensed companies may seek to delay execution of new licenses while the NDRC investigation is ongoing. Litigation and/or other actions may be necessary to compel these licensees to report such sales and pay the required royalties for such sales and unlicensed companies to execute new licenses. Further, our success in China is in part dependent upon the rate of commercialization of 4G LTE products in China. |

[0001234452-15-000024:mdna:30]
| • | We anticipate that our results of operations for our semiconductor business, QCT, will be adversely impacted in the second half of fiscal 2015 by the effects of: a shift in share among our customers at the premium tier, which has reduced our near-term opportunity for sales of our integrated Snapdragon processors and has skewed our product mix towards more modem chipsets in this tier; expectations that our Snapdragon 810 processor will not be in the upcoming design cycle of a large customer’s flagship device; and heightened competition in China. |

[0001234452-15-000024:mdna:31]
[same as prior period, unchanged from 0001234452-14-000238:mdna:14]

[0001234452-15-000024:mdna:32]
| • | We continue to invest significant resources toward advancements in 3G, 3G/4G multimode and 4G LTE (an OFDMA-based standard) technologies, audio and video codecs, wireless baseband chips, our converged computing/communications (Snapdragon) chips, graphics, connectivity, multimedia products, software and services. We are also investing across a broad spectrum of opportunities that leverage our existing technical and business expertise to deploy new business models and enter into new industry segments, such as products designed for implementation of small cells and addressing the challenge of meeting the increased demand for data; products for the connected home and the Internet of Things; automotive; very high speed connectivity; new display technologies; data centers; mobile health; wireless charging; and machine learning, including robotics. |

[0001234452-15-000024:mdna:33]
| • | In October 2014, we announced that we had reached agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.4 billion based upon an exchange rate of USD: GBP 1.51571). CSR is an innovator in the development of multifunction semiconductor platforms and technologies for the automotive, consumer and voice and music market categories. The acquisition complements our current offerings by adding products, channels and customers in the growth categories of the Internet of Everything and automotive infotainment, accelerating our presence and path to leadership. The acquisition has received approval of CSR’s shareholders and regulatory approval in the United States. The completion of the acquisition remains subject to the satisfaction of a number of additional conditions, including other regulatory approvals. Subject to the satisfaction of these conditions, the acquisition is expected to close by the end of the summer of 2015. |

[0001234452-15-000024:mdna:34]
[same as prior period, unchanged from 0001234452-14-000238:mdna:38]

[0001234452-15-000024:mdna:35]
[same as prior period, unchanged from 0001234452-14-000238:mdna:39]

[0001234452-15-000024:mdna:36]
[same as prior period, unchanged from 0001234452-14-000238:mdna:40]

[0001234452-15-000024:mdna:37]
| Revenues (in millions) |
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |  | Change |
| Equipment and services | $ | 5,216 |  |  | $ | 4,653 |  |  | $ | 563 |  |
| Licensing | 1,883 |  |  | 1,969 |  |  | (86 | ) |
|  | $ | 7,099 |  |  | $ | 6,622 |  |  | $ | 477 |  |

[0001234452-15-000024:mdna:38]
The increase in equipment and services revenues was primarily due to an increase in QCT revenues of $622 million, partially offset by a decrease of $57 million as a result of the sale of the North and Latin America operations of our Omnitracs division during fiscal 2014. The decrease in licensing revenues was primarily due to a decrease in QTL revenues of $84 million.

[0001234452-15-000024:mdna:39]
| Costs and Expenses (in millions) |
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |  | Change |
| Cost of equipment and services (E&S) revenues | $ | 3,047 |  |  | $ | 2,706 |  |  | $ | 341 |  |
| Cost as % of E&S revenues | 58 | % |  | 58 | % |  |  |

[0001234452-15-000024:mdna:40]
Margin percentage, driven primarily by QCT, remained flat in the first quarter of fiscal 2015. Our margin percentage may fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors.

[0001234452-15-000024:mdna:41]
24

[0001234452-15-000024:mdna:42]
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |  | Change |
| Research and development | $ | 1,352 |  |  | $ | 1,328 |  |  | $ | 24 |  |
| % of revenues | 19 | % |  | 20 | % |  |  |
| Selling, general, and administrative | $ | 567 |  |  | $ | 623 |  |  | $ | (56 | ) |
| % of revenues | 8 | % |  | 9 | % |  |  |
| Other | $ | 69 |  |  | $ | 472 |  |  | $ | (403 | ) |

[0001234452-15-000024:mdna:43]
The dollar increase in research and development expenses was primarily attributable to an increase of $40 million in costs related to the development of CDMA-based 3G, OFDMA-based 4G LTE and other technologies for integrated circuit and related software products, including small cells and data center products, and to expand our intellectual property portfolio.

[0001234452-15-000024:mdna:44]
The dollar decrease in selling, general and administrative expenses was primarily attributable to a $16 million gain related to the sale of certain assets of our QMT division, the effect of which is a decrease in selling, general and administrative expenses, and decreases of $13 million in patent-related expenses, $10 million in selling and marketing expenses and $10 million in share-based compensation expenses.

[0001234452-15-000024:mdna:45]
Other expenses in the first quarter of fiscal 2015 were attributable to a $69 million goodwill impairment charge related to our business that provides push-to-talk enablement services to wireless operators. Other expenses in the first quarter of fiscal 2014 were comprised of a $444 million impairment charge related to our QMT division, a $16 million goodwill impairment charge related to our former QRS division and a $12 million charge related to the ParkerVision verdict.

[0001234452-15-000024:mdna:46]
| Net Investment Income (in millions) |  |  |  |  |  |
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |  | Change |
| Interest and dividend income | $ | 134 |  |  | $ | 156 |  |  | $ | (22 | ) |
| Interest expense | (1 | ) |  | (3 | ) |  | 2 |  |
| Net realized gains on marketable securities | 156 |  |  | 128 |  |  | 28 |  |
| Net realized gains on other investments | 10 |  |  | 17 |  |  | (7 | ) |
| Impairment losses on marketable securities and other investments | (65 | ) |  | (37 | ) |  | (28 | ) |
| Net gains on derivative instruments | 4 |  |  | 4 |  |  | — |  |
| Equity in net losses of investees | (4 | ) |  | (1 | ) |  | (3 | ) |
|  | $ | 234 |  |  | $ | 264 |  |  | $ | (30 | ) |

[0001234452-15-000024:mdna:47]
The decrease in interest and dividend income was primarily due to lower interest rates earned on cash, cash equivalents and marketable securities. The increase in net realized gains on marketable securities was primarily due to the increased impact of portfolio rebalancing in the first quarter of fiscal 2015. The increase in impairment losses on marketable securities and other investments was primarily due to an increase in our recognition of unrealized losses on debt funds that are not expected to recover over a reasonable period of time.

[0001234452-15-000024:mdna:48]
| Income Tax Expense (in millions) |
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |  | Change |
| Income tax expense | $ | 327 |  |  | $ | 313 |  |  | $ | 14 |  |
| Effective tax rate | 14 | % |  | 18 | % |  | (4 | %) |

[0001234452-15-000024:mdna:49]
[same as prior period, unchanged from 0001234452-14-000238:mdna:33]

[0001234452-15-000024:mdna:50]
The following table summarizes the primary factors that caused our effective tax rates for the first quarter of fiscal 2015 and 2014 to be less than the United States federal statutory rate:

[0001234452-15-000024:mdna:51]
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (16 | %) |  | (17 | %) |
| Benefits related to the research and development tax credit | (5 | %) |  | (1 | %) |
| Other | — | % |  | 1 | % |
| Effective tax rate | 14 | % |  | 18 | % |

[0001234452-15-000024:mdna:52]
The effective tax rate of 14% for the first quarter of fiscal 2015 was less than our estimated annual effective tax rate of 17% primarily as a result of the retroactive reinstatement of the federal research and development tax credit. During the first quarter of fiscal 2015, the United States government reinstated the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. As a result of the reinstatement, we recorded a tax benefit of $101 million related to fiscal 2014 in the first quarter of fiscal 2015. Additionally, the estimated annual effective tax rate for fiscal 2015 reflects the United States federal research and development tax credit generated through December 31, 2014, the date on which the credit expired. The annual effective tax rate for fiscal 2014 reflected the United States federal research and development tax credit generated through December 31, 2013, the date on which the credit previously expired.

[0001234452-15-000024:mdna:53]
[same as prior period, unchanged from 0001234452-14-000238:mdna:59]

[0001234452-15-000024:mdna:54]
The following should be read in conjunction with the first quarter financial results of fiscal 2015 for each reportable segment. See “Notes to Condensed Consolidated Financial Statements, Note 7 - Segment Information.”

[0001234452-15-000024:mdna:55]
| (in millions) | QCT |  | QTL |  | QSI |
| Three Months Ended December 28, 2014 |  |  |  |  |  |
| Revenues | $ | 5,242 |  |  | $ | 1,816 |  |  | $ | — |  |
| EBT (1) | 1,146 |  |  | 1,579 |  |  | (1 | ) |
| EBT as a % of revenues | 22 | % |  | 87 | % |  |  |
| Three Months Ended December 29, 2013 |  |  |  |  |  |
| Revenues | $ | 4,616 |  |  | $ | 1,900 |  |  | $ | — |  |
| EBT | 906 |  |  | 1,670 |  |  | 4 |  |
| EBT as a % of revenues | 20 | % |  | 88 | % |  |  |

[0001234452-15-000024:mdna:56]
[same as prior period, unchanged from 0001234452-14-000238:mdna:62]

[0001234452-15-000024:mdna:57]
QCT Segment. The increase in QCT revenues of $626 million was primarily due to an increase in equipment and services revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying Radio Frequency (RF) and Power Management (PM) integrated circuits, were $5.19 billion and $4.56 billion in the first quarter of fiscal 2015 and 2014, respectively. The increase in equipment and services revenues resulted primarily from an increase of $996 million, related to higher MSM and accompanying RF and PM unit shipments, partially offset by a net decrease of $431 million, resulting from lower average selling prices and lower-priced product mix. Approximately 270 million and 213 million MSM integrated circuits were sold during the first quarter of fiscal 2015 and 2014, respectively.

[0001234452-15-000024:mdna:58]
QCT EBT as a percentage of revenues increased primarily due to an increase of 14% in QCT revenues relative to a combined increase of 3% in research and development expenses and selling, general and administrative expenses. QCT gross margin percentage decreased slightly primarily as a result of lower average selling prices, higher excess inventory charges and lower-margin product mix, partially offset by lower average unit costs.

[0001234452-15-000024:mdna:59]
QCT inventories increased by 21% in the first quarter of fiscal 2015 from $1.46 billion to $1.76 billion, primarily due to improved supply and an increase in work-in-process related to the timing of inventory receipts to meet near-term demand.

[0001234452-15-000024:mdna:60]
QTL Segment. The decrease in QTL revenues of $84 million was primarily due to a decrease in revenues per reported unit, partially offset by an increase in sales of CDMA-based products, including multimode products that also

[0001234452-15-000024:mdna:61]
implement OFDMA, reported by licensees. The decrease in QTL EBT as a percentage of revenues was primarily due to an increase in patent amortization expense. QTL revenues and EBT for the first quarter of fiscal 2015 were impacted by units that we believe are being underreported by certain licensees and sales of certain unlicensed products in China.

[0001234452-15-000024:mdna:62]
QSI Segment. The decrease in QSI EBT of $5 million was primarily due to a $3 million decrease in net investment income related to our strategic investments.

[0001234452-15-000024:mdna:63]
[same as prior period, unchanged from 0001234452-14-000238:mdna:69]

[0001234452-15-000024:mdna:64]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. Cash, cash equivalents and marketable securities were $31.6 billion at December 28, 2014, a decrease of $419 million from September 28, 2014. Our cash, cash equivalents and marketable securities at December 28, 2014 consisted of $4.1 billion held by United States-based entities and $27.5 billion held by foreign entities. Most of our cash, cash equivalents and marketable securities held by foreign entities is indefinitely reinvested and would be subject to material tax effects if repatriated. However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate the funds. Total cash provided by operating activities decreased to $2.4 billion during the first quarter of fiscal 2015, compared to $2.8 billion during the first quarter of fiscal 2014.

[0001234452-15-000024:mdna:65]
Accounts receivable decreased 7% during the first quarter of fiscal 2015. Days sales outstanding, on a consolidated basis, were 28 days at December 28, 2014, compared to 32 days at September 28, 2014. The decreases in accounts receivable and the related days sales outstanding were primarily due to the timing of integrated circuit shipments, partially offset by an increase in accounts receivable from certain of our licensees.

[0001234452-15-000024:mdna:66]
During the first quarter of fiscal 2015, we repurchased and retired 22,940,000 shares of our common stock for $1.7 billion, before commissions. On March 4, 2014, the Company announced that it had been authorized to repurchase up to $7.8 billion of the Company’s common stock. At December 28, 2014, approximately $3.6 billion remained authorized for repurchase under our stock repurchase program. Since December 28, 2014, we repurchased and retired 6,841,000 shares of common stock for $502 million. We continue to evaluate repurchases as a means of returning capital to stockholders, subject to our periodic determinations that repurchases are in the best interests of our stockholders.

[0001234452-15-000024:mdna:67]
We paid cash dividends totaling $697 million, or $0.42 per share, on December 18, 2014. On January 14, 2015, we announced a cash dividend of $0.42 per share on our common stock, payable on March 25, 2015 to stockholders of record as of the close of business on March 4, 2015. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-15-000024:mdna:68]
We intend to return a minimum of 75% of our free cash flow to stockholders through stock repurchases and dividends over the foreseeable future, where free cash flow is defined as net cash provided by operating activities less capital expenditures. To meet this goal, we expect to use existing cash and marketable securities held by, and cash flow generated from, United States-based entities, and we anticipate that we will supplement this by issuing debt, a process that we expect to begin in the second quarter of fiscal 2015. The amount and timing of such borrowing will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001234452-15-000024:mdna:69]
[same as prior period, unchanged from 0001234452-14-000238:mdna:75]

[0001234452-15-000024:mdna:70]
| • | Our research and development expenditures were $1.4 billion during the first quarter of fiscal 2015 and $5.5 billion in fiscal 2014, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications, primarily in the wireless industry. |

[0001234452-15-000024:mdna:71]
| • | Cash outflows for capital expenditures were $253 million during the first quarter of fiscal 2015 and $1.2 billion in fiscal 2014. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-15-000024:mdna:72]
| • | Our purchase obligations for the remainder of fiscal 2015 and for fiscal 2016, some of which relate to research and development activities and capital expenditures, totaled $3.8 billion and $1.1 billion, respectively, at December 28, 2014. |

[0001234452-15-000024:mdna:73]
| • | In October 2014, we announced that we had reached agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.4 billion based upon an exchange rate of USD: GBP 1.51571). We expect to use existing cash resources to fund the acquisition. The acquisition has received approval from CSR’s shareholders and regulatory approval in the United States. The completion of the acquisition remains subject to the satisfaction of a number of additional conditions, including regulatory approvals. Subject to the satisfaction of these conditions, the acquisition is expected to close by the end of the summer of 2015. |

[0001234452-15-000024:mdna:74]
[same as prior period, unchanged from 0001234452-14-000238:mdna:79]

[0001234452-15-000024:mdna:75]
In connection with the pending acquisition of CSR, we agreed to set aside certain cash, cash equivalents and marketable securities to be held for purposes of satisfying payment of the consideration to effect the acquisition. At December 28, 2014, the fair value of the marketable securities that were set aside was $3.8 billion. Additionally, $38 million of cash equivalents, which were recorded as other current assets, were set aside. If the combined fair values falls below approximately £1.9 billion (approximately $2.8 billion using an exchange rate of 1.51571), we may be required to set aside additional securities. Additionally, if certain conditions are met, such as a reduction in the liquidity of any of the securities that are set aside, we may be required to liquidate the securities and transfer the cash to a third party until the acquisition closes.

[0001234452-15-000024:mdna:76]
[same as prior period, unchanged from 0001234452-14-000238:mdna:80]

[0001234452-15-000024:mdna:77]
[same as prior period, unchanged from 0001234452-14-000238:mdna:81]

[0001234452-15-000024:mdna:78]
Additional information regarding our financial commitments at December 28, 2014 is provided in the notes to our condensed consolidated financial statements. See “Notes to Condensed Consolidated Financial Statements, Note 4 — Income Taxes” and “Note 6 — Commitments and Contingencies.”

[0001234452-15-000024:mdna:79]
[same as prior period, unchanged from 0001234452-14-000238:mdna:83]

[0001234452-15-000024:mdna:80]
In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. This ASU will be effective for us starting in the first quarter of fiscal 2018. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the fiscal 2018 opening retained earnings balance. We are in the process of determining the adoption method as well as the effects the adoption will have on our consolidated financial statements.

[0001234452-15-000024:mdna:81]
[same as prior period, unchanged from 0001234452-14-000238:mdna:85]

[0001234452-15-000024:mdna:82]
You should consider each of the following factors as well as the other information in this Quarterly Report in evaluating our business and our prospects. The risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also impair our business operations. If any of the following risks actually occur, our business and financial results could be harmed. In that case, the trading price of our common stock could decline. You should also refer to the other information set forth in this Quarterly Report and in our Annual Report on Form 10-K for the fiscal year ended September 28, 2014, including our financial statements and the related notes.

[0001234452-15-000024:mdna:83]
[same as prior period, unchanged from 0001234452-14-000238:mdna:57]

[0001234452-15-000024:mdna:84]
[same as prior period, unchanged from 0001234452-14-000238:mdna:87]

[0001234452-15-000024:mdna:85]
Our revenues depend on commercial network deployments, expansions and upgrades of CDMA, OFDMA and other communications technologies, our customers’ and licensees’ sales of products and services based on these technologies and our ability to drive our customers’ demand for our products and services.

[0001234452-15-000024:mdna:86]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on our customers, our licensees and operators of wireless networks to use these technologies in their adoption of our products and services into their devices and networks and on the timing of their deployments of new products and services. We also depend on our customers and licensees to develop products and services with value-added features to drive consumer demand for new 3G, 3G/4G multimode and 4G devices, as well as the selling prices for such devices. Further, our rate of revenue growth may depend on third parties incorporating our technology, products and/or services into new device types used in industries beyond traditional cellular communications. Our revenues and/or growth in revenues could be negatively impacted, our business may be harmed and our substantial investments in these technologies may not provide us an adequate return, if:

[0001234452-15-000024:mdna:87]
| • | wireless operators and industries beyond traditional cellular communications deploy alternative technologies; |

[0001234452-15-000024:mdna:88]
| • | wireless operators delay 3G and 3G/4G multimode network deployments, expansions or upgrades and/or delay moving 2G customers to 3G, 3G/4G multimode or 4G wireless devices; |

[0001234452-15-000024:mdna:89]
| • | LTE, an OFDMA-based 4G wireless technology, is not more widely deployed or further commercial deployment is delayed; |

[0001234452-15-000024:mdna:90]
| • | government regulators delay making sufficient spectrum available for 3G and/or 3G/4G networks, thereby restricting the expansion of 3G/4G wireless connectivity to keep pace with consumer demand; |

[0001234452-15-000024:mdna:91]
[same as prior period, unchanged from 0001234452-14-000238:mdna:94]

[0001234452-15-000024:mdna:92]
| • | our customers’ and licensees’ revenues and sales of products, particularly premium-tier products, and services using these technologies, do not grow or do not grow as quickly as anticipated, due to, for example, the maturity of smartphone penetration in developed regions (where premium-tier products are common); and/or |

[0001234452-15-000024:mdna:93]
[same as prior period, unchanged from 0001234452-14-000238:mdna:96]

[0001234452-15-000024:mdna:94]
[same as prior period, unchanged from 0001234452-14-000238:mdna:97]

[0001234452-15-000024:mdna:95]
Our products, services and technologies face significant competition, and the revenues they generate and/or the timing of such revenues, which depend on deployments and/or actions by others, may not meet expectations. We expect competition to increase as our current competitors expand their product offerings and as new opportunities develop, putting continued pressure on the pricing of our products and services. Competition in wireless communications is affected by various factors that include, among others: device manufacturer concentrations; growth in emerging geographic regions; government intervention; evolving industry standards and business models; evolving methods of transmission of voice and data communications; increasing data traffic and densification of wireless networks; convergence of transmission platforms (including Wi-Fi and small cell infrastructures), which is also described as the consolidation of access points at the edge of the Internet; networking and connectivity trends (including cloud services); evolving nature of computing (including demand for always on, always connected capabilities); the speed of technological change (including the transition to smaller geometry process technologies); value-added features that drive selling prices as well as consumer demand for new 3G, 3G/4G multimode and 4G devices; turnkey, integrated products that incorporate hardware, software, user interface, applications and reference designs; rapid growth in mobile data consumption; scalability; and the ability of the system technology to meet customers’ immediate and future network requirements. We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, technological and public policy changes and relatively low barriers to entry in certain segments of the industry.

[0001234452-15-000024:mdna:96]
[same as prior period, unchanged from 0001234452-14-000238:mdna:99]

[0001234452-15-000024:mdna:97]
29

[0001234452-15-000024:mdna:98]
| • | develop innovative, differentiated integrated circuit products and technologies across multiple products and features (e.g., modem, radio frequency front end, central, graphics and/or other processors and connectivity) and with smaller geometry process technologies; |

[0001234452-15-000024:mdna:99]
| • | develop and offer integrated circuit products at competitive cost and price points to effectively cover both emerging and developed geographic regions and all device tiers; |

[0001234452-15-000024:mdna:100]
| • | continue to drive the adoption of our integrated circuit products into the most popular device models and across a broad spectrum of devices, such as smartphones, tablets and other connected devices, and infrastructure products; |

[0001234452-15-000024:mdna:101]
| • | maintain and/or accelerate demand for our integrated circuit products at the premium device tier, while increasing the adoption of our products in mid- and low-tier devices and in the turnkey product channel, in part by strengthening our integrated circuit product roadmap for, and developing channel relationships in, emerging geographic regions, such as China and India, and by providing turnkey products, which incorporate our integrated circuits, for low- and mid-tier smartphones and tablets; |

[0001234452-15-000024:mdna:102]
[same as prior period, unchanged from 0001234452-14-000238:mdna:104]

[0001234452-15-000024:mdna:103]
[same as prior period, unchanged from 0001234452-14-000238:mdna:105]

[0001234452-15-000024:mdna:104]
| • | be a preferred partner (and sustain preferred relationships) providing integrated circuit products that support multiple operating system and infrastructure platforms to industry participants that effectively commercialize new devices using these platforms; |

[0001234452-15-000024:mdna:105]
[same as prior period, unchanged from 0001234452-14-000238:mdna:106]

[0001234452-15-000024:mdna:106]
| • | become a leading supplier of small cell modems (which enable inexpensive cell sites deployed by users to connect to traditional cellular networks through wired internet connections) and products that enable Wi-Fi access to support significant network capacity expansion that will be needed to meet anticipated growth in mobile data traffic; |

[0001234452-15-000024:mdna:107]
| • | identify potential acquisition targets that will grow or sustain our business or address strategic needs, reach agreement on terms acceptable to us and effectively integrate these new businesses and/or technologies; |

[0001234452-15-000024:mdna:108]
| • | create stand-alone value and/or contribute to the success of our existing businesses through acquisitions and other investments (and/or by developing customer, licensee and/or vendor relationships) in new industry segments and/or disruptive technologies, products and/or services (such as the connected home and the Internet of Things, automotive products, new display technologies, mobile health, machine learning, including robotics and wireless charging, among others); and/or |

[0001234452-15-000024:mdna:109]
| • | continue to develop brand recognition to effectively compete against better known companies in mobile computing and other consumer driven segments and to deepen our presence in significant emerging geographic regions. |

[0001234452-15-000024:mdna:110]
Competition in any or all product tiers, customer concentration and/or growth in sales of mid- and low-tier products, particularly relative to premium-tier products, may reduce average selling prices for our chipset products and the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging geographic regions (e.g. China). Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0001234452-15-000024:mdna:111]
Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM, Wi-Fi) as well as companies that design integrated circuits based on CDMA, OFDMA or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom, Ericsson, HiSilicon Technologies, Intel, Lantiq, Marvell Technology, Maxim Integrated Products, MediaTek, Nvidia,

[0001234452-15-000024:mdna:112]
Realtek Semiconductor, Samsung Electronics, Spreadtrum Communications (which is controlled by Tsinghua Unigroup), Texas Instruments and VIA Telecom. Some of these current and potential competitors have advantages over us that include, among others: lower cost structures; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; motivation by our customers in certain circumstances to find alternate suppliers or choose alternative technologies; foreign government support of other technologies or competitors; more extensive relationships with local distribution companies and original equipment manufacturers in emerging geographic regions (such as China); and/or a more established presence in certain device markets.

[0001234452-15-000024:mdna:113]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe we will continue to see, an increase in customers requesting that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of a product’s source code and may expose related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of the open source software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers, or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Developing open source products, while adequately protecting the intellectual property rights upon which our licensing business depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ adequate controls to protect our intellectual property rights, our use of open source software presents risks that could have an adverse effect on these rights and on our business.

[0001234452-15-000024:mdna:114]
[same as prior period, unchanged from 0001234452-14-000238:mdna:114]

[0001234452-15-000024:mdna:115]
Our QCT segment derives a significant portion of revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience an increasing concentration of device share among a few companies, contributing to this trend. In addition, one of our integrated circuit competitors is part of a conglomerate that includes one of our largest integrated circuit customers. The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or cancelation of significant purchases from any of these customers would reduce our revenues and could harm our ability to achieve or sustain expected operating results, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Further, concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have little or no control, and the timing of such introductions may cause our operating results to fluctuate. Accordingly, if current industry dynamics and concentrations continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases and the timing and size of any such future purchases by these significant customers.

[0001234452-15-000024:mdna:116]
Further, companies that develop HLOS for devices, including leading technology companies, have entered the device market. If we fail to effectively partner or continue partnering with these companies, or with their partners or customers, they may decide not to purchase (either directly or through their contract manufacturers), or to reduce or discontinue their purchases of, our integrated circuit products.

[0001234452-15-000024:mdna:117]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products and/or intellectual property or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001234452-15-000024:mdna:118]
Although we have more than 265 CDMA-based licensees, our QTL segment derives a significant portion of licensing revenues from a limited number of licensees. In the event that one or more of our significant licensees fail to meet their reporting and/or payment requirements or we are unable to renew one or more of such license agreements, our revenues, operating results and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume

[0001234452-15-000024:mdna:119]
products that achieve and sustain customer acceptance. We have little or no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our major licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues.

[0001234452-15-000024:mdna:120]
[same as prior period, unchanged from 0001234452-14-000238:mdna:120]

[0001234452-15-000024:mdna:121]
Although we own a very strong portfolio of issued and pending patents related to GSM, GPRS, EDGE, OFDM, OFDMA, WLAN, MIMO and other technologies, our patent portfolio licensing program in these areas is less established and might not be as successful in generating licensing revenues as our CDMA licensing program. Many wireless operators are investigating, have selected or have deployed OFDMA-based LTE as their next-generation 4G technology in existing (or future if not yet deployed) wireless spectrum bands as complementary to their existing CDMA-based networks. While 3G/4G multimode products are generally covered by our existing 3G licensing agreements, products that implement 4G that do not also implement 3G are generally not covered by these agreements. Although we believe that our patented technology is essential and useful to implementation of the LTE industry standards and have granted royalty-bearing licenses to more than 120 companies (including Huawei, LG, Microsoft, Samsung, Sony Mobile and ZTE) that have realized that they need a license under our patents to make and sell products implementing 4G standards but not implementing 3G standards, it may be difficult to agree on material terms and/or conditions of new license agreements that are acceptable to us with companies that are currently unlicensed, particularly in China. Further, the royalty rates for single mode 4G products are generally lower than our royalty rates for 3G and 3G/4G multimode products, and therefore, we might not achieve the same licensing revenues on such LTE products as on 3G and 3G/4G multimode products. In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the connected home or the Internet of Things. We also seek to diversify and broaden our technology licensing programs to new industry segments in which we can leverage our technology leadership, such as wireless charging, display and other technologies. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties that are equivalent to those that we receive for 3G and 3G/4G multimode products used in cellular communications. Although we believe that our patented technology is essential and useful to the commercialization of such services, the royalties we receive may be lower than those we receive from our current licensing program.

[0001234452-15-000024:mdna:122]
[same as prior period, unchanged from 0001234452-14-000238:mdna:122]

[0001234452-15-000024:mdna:123]
The licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date and, in a small number of agreements, royalties are payable on those patents for a specified time period. As a result, there are agreements with some licensees where later patents are not licensed by or to us and/or royalties are not owed to us under such license agreements after the specified time period. In order to license or to obtain a license to such later patents, or to receive royalties after the specified time period, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to modify those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in renewing a license agreement prior to its expiration, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001234452-15-000024:mdna:124]
[same as prior period, unchanged from 0001234452-14-000238:mdna:125]

[0001234452-15-000024:mdna:125]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, or some form of unfair competition; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including

[0001234452-15-000024:mdna:126]
working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the imposition of some form of compulsory licensing and/or to weaken a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies in attempts to shift their royalty obligation to their suppliers. In addition, particularly in China, certain licensees have disputed or underreported royalties owed to us under their license agreements with us, and certain companies have yet to enter into or delayed entering into license agreements with us for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future.

[0001234452-15-000024:mdna:127]
We are currently subject to various litigation and governmental investigations and/or proceedings, some of which may arise out of the strategies described above. Certain legal matters are described more fully in the notes to our condensed consolidated financial statements. See “Notes to Condensed Consolidated Financial Statements, Note 6 - Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or modify our business practices.

[0001234452-15-000024:mdna:128]
[same as prior period, unchanged from 0001234452-14-000238:mdna:127]

[0001234452-15-000024:mdna:129]
Further, some companies or entities have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions not be an available remedy for infringement of standard-essential patents and/or have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by severely limiting the base upon which the royalty percentage may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (and/or other companies’) alleged failure to abide by these policies.

[0001234452-15-000024:mdna:130]
[same as prior period, unchanged from 0001234452-14-000238:mdna:129]

[0001234452-15-000024:mdna:131]
[same as prior period, unchanged from 0001234452-14-000238:mdna:130]

[0001234452-15-000024:mdna:132]
33

[0001234452-15-000024:mdna:133]
The enforcement and protection of our intellectual property rights may be expensive, could fail to prevent misappropriation or unauthorized use of our proprietary intellectual property rights, could result in the loss of our ability to enforce one or more patents, or could be adversely affected by changes in patent laws, by laws in certain foreign jurisdictions that may not effectively protect our intellectual property rights or by ineffective enforcement of laws in such jurisdictions.

[0001234452-15-000024:mdna:134]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our proprietary information, technologies and processes, including our patent portfolio. Policing unauthorized use of our products, technologies and proprietary information is difficult and time consuming. We cannot be certain that the steps we have taken, or may take in the future, will prevent the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as United States laws or where the enforcement of such laws may be lacking or ineffective. Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that in the next few years the European Union will adopt a unitary patent system that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technology.

[0001234452-15-000024:mdna:135]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property rights and/or contracts, including collecting royalties for use of our patent portfolio in particular foreign jurisdictions due to, among others: policies of foreign governments; challenges to our licensing practices under such jurisdictions’ competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and/or challenges pending before foreign competition agencies to the pricing and integration of additional features and functionality into our chipset products. Although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Particularly in China, certain licensees have disputed or underreported royalties owed to us under their license agreements with us, and certain companies have yet to enter into or delayed entering into license agreements for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future.

[0001234452-15-000024:mdna:136]
We may need to litigate in the United States or elsewhere in the world to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable and/or we could incur substantial unexpected operating costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our operating results. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues in the period prior to conclusion.

[0001234452-15-000024:mdna:137]
We are subject to government regulations and policies. Our business may suffer as a result of new or changed laws, regulations or policies, our failure or inability to comply with laws, regulations or policies or adverse rulings in enforcement or other proceedings.

[0001234452-15-000024:mdna:138]
Our business, products and services, and those of our customers and licensees, are subject to various laws and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies. The adoption of new laws, regulations or policies, changes in the interpretation of existing laws, regulations or policies, changes in the regulation of our activities by a government or standards body and/or adverse rulings in court, regulatory, administrative or other proceedings relating to such laws, regulations or policies, including, among others, those affecting licensing practices, competitive business practices, the use of our technology or products, protection of intellectual property, trade, foreign investments or loans, spectrum availability and license issuance, adoption of standards, the provision of device subsidies by wireless operators to their customers, taxation, environmental protection or employment, could have an adverse effect on our business.

[0001234452-15-000024:mdna:139]
We are currently subject to various governmental investigations and/or proceedings, and certain matters are described more fully in the notes to our condensed consolidated financial statements. See “Notes to Condensed Consolidated Financial Statements, Note 6 - Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices.

[0001234452-15-000024:mdna:140]
[same as prior period, unchanged from 0001234452-14-000238:mdna:167]

[0001234452-15-000024:mdna:141]
[same as prior period, unchanged from 0001234452-14-000238:mdna:168]

[0001234452-15-000024:mdna:142]
Regulations in the United States require that we determine whether certain materials used in our products, referred to as conflict minerals, originated in the Democratic Republic of the Congo or an adjoining country, or were from recycled or scrap sources. The verification and reporting requirements, in addition to customer demands for conflict free sourcing, impose additional costs on us and on our suppliers, and may limit the sources or increase the prices of materials used in our products. Further, if we are unable to determine that our products are “conflict free,” we may face challenges with our customers that place us at a competitive disadvantage, and our reputation may be harmed. Laws, regulations and standards relating to corporate governance, business conduct, public disclosure and health care are complex and changing and may create uncertainty regarding compliance. Laws, regulations and standards are subject to varying interpretations in many cases, and their application in practice may evolve over time. As a result, our efforts to comply may fail, particularly if there is ambiguity as to how they should be applied in practice. New laws, regulations and standards or evolving interpretations of legal requirements may cause us to incur higher costs as we revise current practices, policies and/or procedures and may divert management time and attention to compliance activities.

[0001234452-15-000024:mdna:143]
[same as prior period, unchanged from 0001234452-14-000238:mdna:136]

[0001234452-15-000024:mdna:144]
Our industry is subject to rapid technological change, evolving industry standards and frequent new product introductions, and we must make substantial research, development and other investments, such as acquisitions, in new products, services and technologies to compete successfully. Technological innovations generally require significant research and development efforts before they are commercially viable. We intend to continue to make substantial investments in developing new products, services and technologies that we believe can create stand-alone value and/or contribute to the success of our existing businesses. However, it is possible that these initiatives will not be successful and/or will not result in meaningful revenues or generate operating income that meets expectations. While we continue to focus our development efforts primarily in support of 3G CDMA- and 4G OFDMA-based technologies, we innovate across a broad spectrum of opportunities to deploy new business models and enter into new industry segments by leveraging our existing technical and business expertise and/or through acquisitions. Our recent investment initiatives relate to, among others, networking, mobile computing, small cell technology and addressing the challenge of meeting the increased demand for data; products for the connected home and the Internet of Things; automotive; very high speed connectivity; new display technologies; data centers; mobile health; wireless charging; and machine learning, including robotics.

[0001234452-15-000024:mdna:145]
Our research, development and other investments in new technologies, products or services may not succeed due to, among others: improvements in alternate technologies in ways that reduce the advantages we anticipate from our investments; competitors’ products or services being more cost effective, having more capabilities or fewer limitations or being brought to market faster than our new products and services; and competitors having longer operating histories in industry segments that are new to us. We may also underestimate the costs of or overestimate the future operating income and/or margins that could result from these investments; and these investments may not, or may take many years to, generate material returns. If our new technologies, products or services are not successful, or are not successful in the time frame we anticipate, we may incur significant costs and/or asset impairments, our business may not grow as anticipated, our revenues and/or margins may be negatively impacted and/or our reputation may be harmed.

[0001234452-15-000024:mdna:146]
[same as prior period, unchanged from 0001234452-14-000238:mdna:132]

[0001234452-15-000024:mdna:147]
[same as prior period, unchanged from 0001234452-14-000238:mdna:139]

[0001234452-15-000024:mdna:148]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe on another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products through a licensed supplier, we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our operating results.

[0001234452-15-000024:mdna:149]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages, royalty payments and/or an injunction on the sale of certain of our integrated circuit products (and on the sale of our customers’ devices using such products). A negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our share of worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001234452-15-000024:mdna:150]
A number of other companies have claimed to own patents applicable to products implementing various CDMA standards, GSM standards and OFDMA standards. In addition, existing standards continue to evolve, and new standards, including those applicable to new industry segments, continue to be developed. If future standards diminish, or fail to include, a base level of interoperability, our business may be harmed, and our investments in these new segments may not succeed.

[0001234452-15-000024:mdna:151]
[same as prior period, unchanged from 0001234452-14-000238:mdna:171]

[0001234452-15-000024:mdna:152]
We engage in acquisitions and strategic transactions and make strategic investments, which are important to our business strategy, with the goal of maximizing stockholder value. We acquire businesses and other assets, including patents, technology, wireless spectrum and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies that may be private and early-stage. Our strategic activities are generally focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications. Many of our acquisitions or strategic investments entail a high degree of risk and require the use of domestic and/or foreign capital, and investments may not become liquid for several years after the date of the investment, if at all. Our acquisitions or strategic investments may not generate financial returns or result in increased adoption or continued use of our technologies, products or services. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our acquisitions or strategic investments. Any losses or impairment charges that we incur related to strategic investments or other transactions will have a negative impact on our financial results, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001234452-15-000024:mdna:153]
Achieving the anticipated benefits of business acquisitions depends in part upon our ability to integrate the acquired businesses in an efficient and effective manner. The integration of companies that have previously operated

[0001234452-15-000024:mdna:154]
independently may result in significant challenges, including, among others: retaining key employees; successfully integrating new employees, business systems and technology; retaining customers and suppliers of the acquired business; consolidating research and development and/or supply operations; minimizing the diversion of management’s attention from ongoing business matters; and consolidating corporate and administrative infrastructures. We may not derive any commercial value from acquired technologies or products or from future technologies or products based on the acquired technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, or we may become subject to litigation. Additionally, we may not be successful in expanding into geographic regions and/or categories of products served by or adjacent to an acquired business or in addressing potential new opportunities that may arise out of the combination. In part due to our inexperience with technologies and/or products of and/or geographic regions served by acquired businesses, we may underestimate the costs and/or overestimate the benefits, including product and other synergies and growth opportunities that we expect to realize, and we may not achieve them. If we do not achieve the anticipated benefits of business acquisitions, our results of operations may be adversely affected, and we may not enhance stockholder value by engaging in these transactions.

[0001234452-15-000024:mdna:155]
[same as prior period, unchanged from 0001234452-14-000238:mdna:143]

[0001234452-15-000024:mdna:156]
Our QCT segment purchases wafers, die and fully-assembled and tested integrated circuits from third-party semiconductor manufacturing foundries, primarily located in Asia. We also contract with third-party suppliers for assembly, test and other services related to the manufacture of our products. The following could have an adverse effect on our ability to meet customer demands and/or negatively impact our revenues, business operations, profitability and/or cash flows:

[0001234452-15-000024:mdna:157]
| • | a reduction, interruption, delay or limitation in our product supply sources; |

[0001234452-15-000024:mdna:158]
| • | a failure by our suppliers to procure raw materials or to provide or allocate adequate manufacturing or test capacity for our products; |

[0001234452-15-000024:mdna:159]
| • | our suppliers’ inability to react to shifts in product demand or an increase in raw material or component prices; |

[0001234452-15-000024:mdna:160]
| • | the loss of a supplier or the inability of a supplier to meet performance or quality specifications or delivery schedules; and/or |

[0001234452-15-000024:mdna:161]
| • | additional expense and/or production delays as a result of qualifying a new supplier and commencing volume production or testing in the event of a loss of or a decision to add or change a supplier. |

[0001234452-15-000024:mdna:162]
While we have established alternate suppliers for certain technologies that we consider critical, we rely on sole- or limited-source suppliers for some products, subjecting us to significant risks, including: possible shortages of raw materials or manufacturing capacity; poor product performance; and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established alternate suppliers, these suppliers may require significant levels of support to bring complex technologies to production. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, any future consolidation of foundry suppliers could increase our vulnerability to sole- or limited-source arrangements. Our arrangements with our suppliers may obligate us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies, and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Our inability to meet customer demand due to sole- or limited-sourcing and/or the additional costs that we incur because of these or other supply constraints or because of the need to support alternate suppliers could negatively impact our business, our revenues and our results of operations.

[0001234452-15-000024:mdna:163]
Although we have long-term contracts with our suppliers, many of these contracts do not provide for long-term capacity commitments. To the extent that we do not have firm commitments from our suppliers over a specific time period, or for any specific quantity, our suppliers may allocate, and in the past have allocated, capacity to the production and testing of products for their other customers while reducing or limiting capacity to manufacture or test our products. Accordingly, capacity for our products may not be available when we need it or at reasonable prices. To the extent we do obtain long-term capacity commitments, we may incur additional costs related to those commitments and/or make non-refundable payments for capacity commitments that are not used.

[0001234452-15-000024:mdna:164]
[same as prior period, unchanged from 0001234452-14-000238:mdna:146]

[0001234452-15-000024:mdna:165]
[same as prior period, unchanged from 0001234452-14-000238:mdna:149]

[0001234452-15-000024:mdna:166]
[same as prior period, unchanged from 0001234452-14-000238:mdna:150]

[0001234452-15-000024:mdna:167]
Our stock price and earnings have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and/or earnings include those identified throughout this “Risk Factors” section, volatility of the stock market in general and technology-based companies in particular, announcements concerning us, our suppliers, our competitors or our customers and variations between our actual results and expectations of securities analysts, among others. Further, increased volatility in the financial markets and/or overall economic conditions may reduce the amounts that we realize in the future on our cash equivalents and/or marketable securities and may reduce our earnings as a result of any impairment charges that we record to reduce recorded values of marketable securities to their fair values.

[0001234452-15-000024:mdna:168]
In the past, securities class action litigation often has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we may be the target of securities litigation in the future. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources.

[0001234452-15-000024:mdna:169]
[same as prior period, unchanged from 0001234452-14-000238:mdna:196]

[0001234452-15-000024:mdna:170]
Our future success depends largely upon the continued service of our executive officers and other key management and technical personnel and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. The market for employees in our industry is extremely competitive. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. We continue to anticipate increases in human resource needs, particularly in engineering. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001234452-15-000024:mdna:171]
[same as prior period, unchanged from 0001234452-14-000238:mdna:176]

[0001234452-15-000024:mdna:172]
A decline in global economic conditions or a slow-down in economic growth, particularly in geographic regions with high concentrations of wireless voice and data users, could have adverse, wide-ranging effects on demand for our products and for the products and services of our customers or licensees, particularly equipment manufacturers or others in the wireless communications industry who buy their products, such as wireless operators. Any prolonged economic downturn may result in a decrease in demand for our products or technologies; the insolvency of key suppliers; delays in reporting and/or payments from our licensees and/or customers; failures by counterparties; and negative effects on wireless device inventories. In addition, our customers’ ability to purchase or pay for our products and services and network operators’ ability to upgrade their wireless networks could be adversely affected by economic conditions, leading to a reduction, cancelation or delay of orders for our products or services.

[0001234452-15-000024:mdna:173]
[same as prior period, unchanged from 0001234452-14-000238:mdna:178]

[0001234452-15-000024:mdna:174]
Our customers sell their products throughout the world in various currencies. Our consolidated revenues from international customers as a percentage of our total revenues were greater than 90% during each of the last three fiscal years. Adverse movements in currency exchange rates may negatively affect our business and our operating results due to a number of factors, including, among others:

[0001234452-15-000024:mdna:175]
[same as prior period, unchanged from 0001234452-14-000238:mdna:180]

[0001234452-15-000024:mdna:176]
[same as prior period, unchanged from 0001234452-14-000238:mdna:181]

[0001234452-15-000024:mdna:177]
| • | Our foreign suppliers may raise their prices if they are impacted by currency fluctuations, resulting in higher than expected costs and lower margins; and/or |

[0001234452-15-000024:mdna:178]
| • | Foreign exchange hedging transactions that we engage in to reduce the impact of currency fluctuations may require the payment of structuring fees, limit the U.S. dollar value of royalties from licensees’ sales that are denominated in foreign currencies, cause earnings volatility if the hedges do not qualify for hedge accounting and expose us to counterparty risk if the counterparty fails to perform. |

[0001234452-15-000024:mdna:179]
Failures in our products or services or in the products or services of our customers or licensees, including those resulting from security vulnerabilities, defects or errors, could harm our business.

[0001234452-15-000024:mdna:180]
The use of devices containing our products to access untrusted content creates a risk of exposing the system software in those devices to viral or malicious attacks. While we continue to focus on this issue and are taking measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more data and processes, such as mobile computing, and increasing the risk of security failures. Further, our products are inherently complex and may contain defects or errors that are detected only when the products are in use. As our chipset product complexities increase, we are required to migrate to integrated circuit technologies with smaller geometric feature sizes. The design process interface in new domains of technology is complex and adds risk to manufacturing yields and reliability. Further, manufacturing, testing, marketing and use of our products and those of our customers and licensees entail the risk of product liability. Because our products and services are responsible for critical functions in our customers’ products and/or networks, security failures, defects or errors in our products and services could have an adverse impact on us, on our customers and on the end users of our customers’ products. Such adverse impact could include product liability claims or recalls, write-offs of our inventories and/or intangible assets; unfavorable purchase commitments; a shift of business to our competitors; a decrease in demand for connected devices and wireless services, damage to our reputation and to our customer relationships and other financial liability or harm to our business.

[0001234452-15-000024:mdna:181]
[same as prior period, unchanged from 0001234452-14-000238:mdna:188]

[0001234452-15-000024:mdna:182]
[same as prior period, unchanged from 0001234452-14-000238:mdna:189]

[0001234452-15-000024:mdna:183]
[same as prior period, unchanged from 0001234452-14-000238:mdna:190]

[0001234452-15-000024:mdna:184]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-United States headquarters is located. Significant judgment is required in determining our provision for income taxes. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related litigation could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision and results of operations in the period or periods in which that determination is made could be negatively affected.

[0001234452-15-000024:mdna:185]
We have tax incentives in Singapore provided that we meet specified employment and other criteria, and as a result of expiration of these incentives, our Singapore tax rate is expected to increase in fiscal 2017 and again in fiscal 2027. If we do not meet the criteria required to retain such incentives, our Singapore tax rate could increase prior to those dates, and our results of operations could be adversely affected.

[0001234452-15-000024:mdna:186]
Tax rules may change in a manner that adversely affects our future reported financial results or the way we conduct our business. For example, we consider the operating earnings of certain non-United States subsidiaries to be indefinitely reinvested outside the United States based on our current needs for those earnings to be reinvested offshore as well as estimates that future domestic cash generated from operations and/or borrowings will be sufficient to meet future domestic cash needs for the foreseeable future. No provision has been made for United States federal, state or foreign taxes that may result from future remittances of the undistributed earnings of these foreign subsidiaries. Our future

[0001234452-15-000024:mdna:187]
financial results and liquidity may be adversely affected if tax rules regarding unrepatriated earnings change, if domestic cash needs require us to repatriate foreign earnings, if the shares of these foreign subsidiaries were sold or otherwise transferred or if the United States international tax rules change as part of comprehensive tax reform or other tax legislation. If our effective tax rates were to increase, particularly in the United States or Singapore, our operating results, cash flows and/or financial condition could be adversely affected.
