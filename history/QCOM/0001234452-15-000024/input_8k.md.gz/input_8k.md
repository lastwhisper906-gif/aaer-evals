# QCOM 8-K — 0001234452-15-000022 filed 2015-01-28

## item codes, every 8-K on or before 2015-01-28

- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2015-01-28

- none on or before 2015-01-28

## item 2.02 — earnings release, exhibit 99.1

[0001234452-15-000022:8k_2_02:1]
EX-99.1
2
qcom122814erex991.htm
EXHIBIT 99.1

[0001234452-15-000022:8k_2_02:2]
QCOM 12.28.14 ER EX 99.1

[0001234452-15-000022:8k_2_02:3]
Exhibit 99.1

[0001234452-15-000022:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-15-000022:8k_2_02:5]
Qualcomm Contact:

[0001234452-15-000022:8k_2_02:6]
Warren Kneeshaw

[0001234452-15-000022:8k_2_02:7]
Vice President, Investor Relations

[0001234452-15-000022:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-15-000022:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-15-000022:8k_2_02:10]
Qualcomm Announces First Quarter Fiscal 2015 Results

[0001234452-15-000022:8k_2_02:11]
Revenues $7.1 billion

[0001234452-15-000022:8k_2_02:12]
GAAP EPS $1.17, Non-GAAP EPS $1.34

[0001234452-15-000022:8k_2_02:13]
- Record Quarterly Revenues, Non-GAAP Operating Income and MSM Chip Shipments -

[0001234452-15-000022:8k_2_02:14]
SAN DIEGO - January 28, 2015 - Qualcomm Incorporated (Nasdaq:  QCOM), a leading developer and innovator of advanced wireless technologies, products and services, today announced results for the first quarter of fiscal 2015 ended December 28, 2014.

[0001234452-15-000022:8k_2_02:15]
“We delivered a strong quarter, achieving record quarterly revenues and Non-GAAP operating income, and we also are very pleased to have resolved our previously disclosed dispute with a licensee in China,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “Looking ahead, we have lowered our revenue outlook for our semiconductor business for the second half of the fiscal year and lowered our EPS expectations.  These changes reflect our revised expectations related to OEM mix, sales to a large customer and heightened competition in China.”

[0001234452-15-000022:8k_2_02:16]
First Quarter Results (GAAP)*

[0001234452-15-000022:8k_2_02:17]
|  | Q1 Fiscal 2015 |  | Q1 Fiscal 2014 |  | Year-Over-Year Change |  | Q4 Fiscal 2014 |  | Sequential Change |
| Revenues 1 | $7.1B |  | $6.6B |  | +7% |  | $6.7B |  | +6% |
| Operating income 1 | $2.1B |  | $1.5B |  | +38% |  | $2.0B |  | +4% |
| Net income 2 | $2.0B |  | $1.9B |  | +5% |  | $1.9B |  | +4% |
| Diluted earnings per share 2 | $1.17 |  | $1.09 |  | +7% |  | $1.11 |  | +5% |
| Operating cash flow | $2.4B |  | $2.8B |  | (15%) |  | $1.6B |  | +46% |

[0001234452-15-000022:8k_2_02:18]
_________________________

[0001234452-15-000022:8k_2_02:19]
1 Throughout this news release, revenues, operating expenses, operating income, earnings before tax (EBT) and effective tax rates are from continuing operations (i.e., before adjustments for noncontrolling interests and discontinued operations), unless otherwise stated.

[0001234452-15-000022:8k_2_02:20]
2 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests and discontinued operations), unless otherwise stated.

[0001234452-15-000022:8k_2_02:21]
Non-GAAP First Quarter Results*

[0001234452-15-000022:8k_2_02:22]
|  | Q1 Fiscal 2015 |  | Q1 Fiscal 2014 |  | Year-Over-Year Change |  | Q4 Fiscal 2014 |  | Sequential Change |
| Revenues | $7.1B |  | $6.6B |  | +7% |  | $6.7B |  | +6% |
| Operating income | $2.5B |  | $1.8B |  | +37% |  | $2.3B |  | +9% |
| Net income | $2.3B |  | $2.2B |  | +5% |  | $2.1B |  | +6% |
| Diluted earnings per share | $1.34 |  | $1.26 |  | +6% |  | $1.26 |  | +6% |

[0001234452-15-000022:8k_2_02:23]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Beginning in the first quarter of fiscal 2015, we changed our methodology for reporting Non-GAAP results to exclude third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages.  Detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-15-000022:8k_2_02:24]
* The following should be considered in regards to the year-over-year comparisons:

[0001234452-15-000022:8k_2_02:25]
| • | The first quarter of fiscal 2014 results included: |

[0001234452-15-000022:8k_2_02:26]
| ◦ | $665 million gain, or $0.25 per share, in discontinued operations associated with the sale of substantially all of the operations of our Omnitracs division; and |

[0001234452-15-000022:8k_2_02:27]
| ◦ | $444 million charge, or $0.20 per share, that resulted from an impairment on long-lived assets related to our QMT (Qualcomm MEMS Technologies) division. |

[0001234452-15-000022:8k_2_02:28]
First Quarter Key Business Metrics

[0001234452-15-000022:8k_2_02:29]
|  | Q1 Fiscal 2015 |  | Q1 Fiscal 2014 |  | Year-Over-Year Change (1) |  | Q4 Fiscal 2014 |  | Sequential Change (1) |
| MSMTM chip shipments | 270M |  | 213M |  | +27% |  | 236M |  | +14% |
| Total reported device sales (2) | $56.4B |  | $61.6B |  | (8%) |  | $57.4B |  | (2%) |
| Est. reported 3G/4G device shipments (approx.) (2) | 284M - 288M |  | 276M - 280M |  | +3% |  | 256M - 260M |  | +11% |
| Est. reported 3G/4G average selling price (approx.) (2) | $194 - $200 |  | $219 - $225 |  | (11%) |  | $220 - $226 |  | (12%) |

[0001234452-15-000022:8k_2_02:30]
| (1) | The midpoints of the estimated ranges are identified for comparison purposes only and do not indicate a higher degree of confidence in the midpoints. |

[0001234452-15-000022:8k_2_02:31]
| (2) | The first quarter of fiscal 2014 and 2015 are based on sales by our licensees in the September quarter as reported to us in the December quarter, and the fourth quarter of fiscal 2014 is based on sales by our licensees in the June quarter as reported to us in the September quarter. |

[0001234452-15-000022:8k_2_02:32]
Cash and Marketable Securities

[0001234452-15-000022:8k_2_02:33]
Our cash, cash equivalents and marketable securities totaled $31.6 billion at the end of the first quarter of fiscal 2015, compared to $31.6 billion a year ago and $32.0 billion at the end of the fourth quarter of fiscal 2014.

[0001234452-15-000022:8k_2_02:34]
Return of Capital to Stockholders

[0001234452-15-000022:8k_2_02:35]
During the first quarter of fiscal 2015, we returned $2.4 billion to stockholders, including $1.7 billion through repurchases of 22.9 million shares of common stock and $697 million, or $0.42 per share, of cash dividends paid.  On January 14, 2015, we announced a cash dividend of $0.42 per share payable on March 25, 2015 to stockholders of record as of the close of business on March 4, 2015.  Since December 28, 2014, we repurchased and retired 6.8 million shares of common stock for $502 million.

[0001234452-15-000022:8k_2_02:36]
Effective Income Tax Rates

[0001234452-15-000022:8k_2_02:37]
Our fiscal 2015 annual effective income tax rates are estimated to be approximately 17 percent for GAAP and approximately 18 percent for Non-GAAP, both of which include the United States federal research and development (R&D) tax credit generated through December 31, 2014, the date on which the credit expired.  The first quarter of fiscal 2015 effective income tax rates were 14 percent for GAAP and 18 percent for Non-GAAP.  As a result of the retroactive reinstatement of the federal R&D tax credit during the first quarter of fiscal 2015, a tax benefit related to fiscal 2014 of $0.06 per share was excluded from Non-GAAP results.

[0001234452-15-000022:8k_2_02:38]
Business Outlook

[0001234452-15-000022:8k_2_02:39]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment and certain derivative gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001234452-15-000022:8k_2_02:40]
We have lowered our outlook for the second half of fiscal 2015 in our semiconductor business, QCT, largely driven by the effects of:

[0001234452-15-000022:8k_2_02:41]
| • | A shift in share among OEMs at the premium tier, which has reduced our near-term opportunity for sales of our integrated SnapdragonTM processors and has skewed our product mix towards more modem chipsets in this tier; |

[0001234452-15-000022:8k_2_02:42]
| • | Expectations that our Snapdragon 810 processor will not be in the upcoming design cycle of a large customer’s flagship device; and |

[0001234452-15-000022:8k_2_02:43]
| • | Heightened competition in China. |

[0001234452-15-000022:8k_2_02:44]
China continues to present significant opportunities for us, particularly with the rollout of 3G/4G LTE multimode, but also presents significant challenges, as our business practices continue to be the subject of an investigation by the China National Development and Reform Commission (NDRC).  Please refer to our Quarterly Report on Form 10-Q for the first quarter ended December 28, 2014 filed with the SEC for our most recent disclosures regarding the NDRC investigation.

[0001234452-15-000022:8k_2_02:45]
Our current outlook for our licensing business, QTL, reflects the following:

[0001234452-15-000022:8k_2_02:46]
| • | We resolved the previously disclosed dispute with a licensee in China in the first quarter of fiscal 2015. However, we continue to believe that certain licensees in China are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes certain licensees underreporting a portion of their 3G/4G device sales) and that unlicensed companies may seek to delay execution of new licenses while the NDRC investigation is ongoing. We are taking steps to address these issues, although the outcome and timing of any resolutions are uncertain. |

[0001234452-15-000022:8k_2_02:47]
| • | We expect global 3G/4G device shipments to be approximately 1.35 billion for calendar year 2014. However, due to the issues described above, we do not believe that all of the global 3G/4G device shipments for calendar year 2014 will be reported to us within the time periods required by our license agreements. Accordingly, we currently estimate approximately 1.135 billion to 1.175 billion calendar year 2014 3G/4G device shipments will actually be reported to us through the first calendar quarter of 2015. |

[0001234452-15-000022:8k_2_02:48]
| • | We expect global 3G/4G device shipments to be approximately 1.5 billion to 1.6 billion for calendar year 2015. At this time, we are not providing a forecast for calendar year 2015 reported 3G/4G device shipments. |

[0001234452-15-000022:8k_2_02:49]
| • | In the following table, we do provide guidance for estimated second fiscal quarter and fiscal 2015 3G/4G total reported device sales. That guidance includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-15-000022:8k_2_02:50]
Our outlook for fiscal 2015 includes an estimate of the benefit related to stock repurchases that we plan to complete over the remainder of fiscal 2015 under our current stock repurchase program.

[0001234452-15-000022:8k_2_02:51]
We have not included any estimates related to the proposed acquisition of CSR plc in our fiscal 2015 outlook.  The acquisition is expected to close by the end of the summer of 2015.  We expect the acquisition to be accretive to Non-GAAP earnings per share in fiscal 2016, the first full year of combined operations.

[0001234452-15-000022:8k_2_02:52]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-15-000022:8k_2_02:53]
Qualcomm’s Business Outlook Summary

[0001234452-15-000022:8k_2_02:54]
| SECOND FISCAL QUARTER |
|  |  | Q2 FY14 Results | Current Guidance Q2 FY15 Estimates |
|  | Revenues | $6.4B | $6.5B - $7.1B |  |
|  | Year-over-year change |  | increase 2% - 12% |  |
|  | Non-GAAP diluted earnings per share (EPS) |  | $1.31 |  | $1.28 - $1.40 |  |
|  | Year-over-year change |  | decrease 2% - increase 7% |  |
|  | Diluted EPS attributable to QSI |  | ($0.01 | ) |  | ($0.01 | ) |
|  | Diluted EPS attributable to share-based compensation |  | ($0.11 | ) |  | ($0.13 | ) |
|  | Diluted EPS attributable to other items |  | ($0.05 | ) |  | ($0.06 | ) |
|  | GAAP diluted EPS |  | $1.14 |  | $1.08 - $1.20 |  |
|  | Year-over-year change |  | decrease 5% - increase 5% |  |
|  | Metrics |  |  |
|  | MSM chip shipments | 188M |  | 220M - 240M |  |
|  | Year-over-year change |  | increase 17% - 28% |  |
|  | Total reported device sales* (1) | approx. $66.5B |  | approx. $69.5B - $75.5B (3) |  |
|  | Year-over-year change |  | increase 5% - 14% |  |
|  | *Est. sales in December quarter, reported in March quarter |  |  |

[0001234452-15-000022:8k_2_02:55]
| FISCAL YEAR |
|  |  | FY 2014 Results | Prior Guidance FY 2015 Estimates (2) | Current Guidance FY 2015 Estimates (2) |
|  | Revenues |  | $26.5 | B | $26.8B - $28.8B |  | $26.0B - $28.0B |  |
|  | Year-over-year change |  | increase 1% - 9% |  | decrease 2% - increase 6% |  |
|  | Non-GAAP diluted EPS |  | $5.27 |  | $5.05 - $5.35 |  | $4.75 - $5.05 |  |
|  | Year-over-year change |  | decrease 4% - increase 2% |  | decrease 4% - 10% |  |
|  | Diluted EPS attributable to QSI |  | $0.01 |  |  | ($0.01 | ) |  | ($0.02 | ) |
|  | Diluted EPS attributable to share-based compensation |  | ($0.50 | ) |  | ($0.55 | ) |  | ($0.54 | ) |
|  | Diluted EPS attributable to other items |  | ($0.13 | ) |  | ($0.16 | ) |  | ($0.15 | ) |
|  | GAAP diluted EPS |  | $4.65 |  | $4.33 - $4.63 |  | $4.04 - $4.34 |  |
|  | Year-over-year change |  | decrease 7% - even |  | decrease 7% - 13% |  |
|  | Metrics |  |  |  |
|  | Total reported device sales* (1) | approx. $243.6B |  | approx. $240.0B - $270.0B (3) |  | approx. $245.0B - $270.0B (3) |  |
|  | Year-over-year change |  | decrease 1% - increase 11% |  | increase 1% - 11% |  |
|  | *Est. sales in Sept. to June quarters, reported in Dec. to Sept. quarters |  |  |  |

[0001234452-15-000022:8k_2_02:56]
| CALENDAR YEAR Reported 3G/4G Device Estimates (1) |
|  |  | Prior Guidance Calendar 2014 Estimates | Current GuidanceCalendar 2014Estimates |
|  | Est. reported 3G/4G device shipments |  |  |
|  | March quarter | approx. 250M - 254M | approx. 250M - 254M |
|  | June quarter | approx. 256M - 260M | approx. 256M - 260M |
|  | September quarter | not provided | approx. 284M - 288M |
|  | December quarter | not provided | not provided |
|  | Est. calendar year range (approx.) | 1,040M - 1,130M (4) | 1,135M - 1,175M (4) |

[0001234452-15-000022:8k_2_02:57]
| (1) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). The reported quarterly estimated ranges of average selling prices (ASPs) and unit shipments are determined based on the information as reported to us by our licensees during the relevant period and our own estimates of the selling prices and unit shipments for licensees that do not provide such information. Not all licensees report sales, selling prices and/or unit shipments the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales, estimated unit shipments and estimated ASPs for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-15-000022:8k_2_02:58]
| (2) | Our prior and current guidance for fiscal 2015 includes an estimate of the benefit related to stock repurchases that we plan to complete over the remainder of fiscal 2015 under our current stock repurchase program. |

[0001234452-15-000022:8k_2_02:59]
| (3) | Our guidance range for the second quarter of fiscal 2015 and fiscal 2015 total reported device sales reflects estimated 3G/4G total reported device sales that we currently expect to be reported to us, which includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-15-000022:8k_2_02:60]
| (4) | We expect global 3G/4G device shipments to be approximately 1.35 billion for calendar year 2014. However, we do not believe that all of the global 3G/4G device shipments for calendar year 2014 will be reported to us within the time periods required by our license agreements. Accordingly, we currently estimate approximately 1.135 billion to 1.175 billion calendar year 2014 3G/4G device shipments will actually be reported to us through the first calendar quarter of 2015. |

[0001234452-15-000022:8k_2_02:61]
Sums may not equal totals due to rounding.

[0001234452-15-000022:8k_2_02:62]
Results of Business Segments

[0001234452-15-000022:8k_2_02:63]
The following table reconciles our Non-GAAP results to our GAAP results ($ in millions, except per share data):

[0001234452-15-000022:8k_2_02:64]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (a) | Non-GAAP | QSI | Share-Based Compensation | Other Items (b) (c) |  | GAAP |
| Q1 - FISCAL 2015 |  |  |  |  |  |
| Revenues | $5,242 | $1,816 | $41 | $7,099 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $7,099 |  |
| Change from prior year | 14 | % | (4 | %) | (61 | %) | 7 | % |  |  |  |  |  |  | 7 | % |  |
| Change from prior quarter | 8 | % | 1 | % | (15 | %) | 6 | % |  |  |  |  |  |  | 6 | % |  |
| Cost of equipment and services revenues |  |  |  | $2,968 |  |  | $— |  |  | $12 | $67 |  | $3,047 |  |
| Research and development |  |  |  | 1,173 |  | 1 |  | 174 | 4 |  | 1,352 |  |
| Selling, general and administrative |  |  |  | 427 |  | 6 |  | 87 | 47 |  | 567 |  |
| Other expenses |  |  |  | — |  |  | — |  |  | — |  | 69 |  | 69 |  |
| Operating income (loss) |  |  |  | $2,531 |  | ($7) |  | ($273) | ($187) |  | $2,064 |  |
| Change from prior year |  |  |  | 37 | % |  | (40 | %) |  | 3 | % | N/M |  |  | 38 | % |  |
| Change from prior quarter |  |  |  | 9 | % |  | N/M |  |  | (8 | %) | N/M |  |  | 4 | % |  |
| Investment income, net |  |  |  | $228 | (d) | $6 | (e) |  | $— |  |  | $— |  |  | $234 |  |
| EBT | $1,146 | $1,579 | $34 | $2,759 |  | ($1) |  | ($273) | ($187) |  | $2,298 |  |
| Change from prior year | 26 | % | (5 | %) | N/M |  | 31 | % |  | N/M |  |  | 3 | % | N/M |  |  | 31 | % |  |
| Change from prior quarter | 10 | % | 3 | % | N/M |  | 8 | % |  | N/M |  |  | (8 | %) | N/M |  |  | 2 | % |  |
| EBT as % of revenues | 22 | % | 87 | % | 83 | % | 39 | % |  |  |  |  |  |  | 32 | % |  |
| Net income (loss) |  |  |  | $2,263 |  |  | $— |  |  | ($229) | ($62) |  | $1,972 |  |
| Change from prior year |  |  |  | 5 | % |  | N/M |  |  | (1 | %) | 6 | % |  | 5 | % |  |
| Change from prior quarter |  |  |  | 6 | % |  | N/M |  |  | (15 | %) | 21 | % |  | 4 | % |  |
| Diluted EPS |  |  |  | $1.34 |  | $0.00 |  | ($0.14) | ($0.04) |  | $1.17 |  |
| Change from prior year |  |  |  | 6 | % |  | — | % |  | (8 | %) | — | % |  | 7 | % |  |
| Change from prior quarter |  |  |  | 6 | % |  | N/M |  |  | (17 | %) | 20 | % |  | 5 | % |  |
| Diluted shares used |  |  |  | 1,686 |  | 1,686 |  | 1,686 | 1,686 |  | 1,686 |  |
| Q4 - FISCAL 2014 |  |  |  |  |  |
| Revenues | $4,849 | $1,795 | $48 | $6,692 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $6,692 |  |
| Operating income (loss) |  |  |  | 2,323 |  | (3) |  | (252) | (76) |  | 1,992 |  |
| EBT | $1,045 | $1,536 | ($30) | 2,551 |  | 29 |  | (252) | (76) |  | 2,252 |  |
| Net income (loss) |  |  |  | 2,143 |  | 28 |  | (199) | (78) |  | 1,894 |  |
| Diluted EPS |  |  |  | $1.26 |  | $0.02 |  | ($0.12) | ($0.05) |  | $1.11 |  |
| Diluted shares used |  |  |  | 1,701 |  | 1,701 |  | 1,701 | 1,701 |  | 1,701 |  |
| Q1 - FISCAL 2014 |  |  |  |  |  |
| Revenues | $4,616 | $1,900 | $106 | $6,622 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $6,622 |  |
| Operating income (loss) |  |  |  | 1,848 |  | (5) |  | (281) | (69) |  | 1,493 |  |
| EBT | $906 | $1,670 | ($473) | 2,103 |  | 4 |  | (281) | (69) |  | 1,757 |  |
| Discontinued operations, net of tax |  |  |  | 430 |  | — |  |  | — |  | — |  |  | 430 |  |
| Net income (loss) |  |  |  | 2,163 |  | 4 |  | (226) | (66) |  | 1,875 |  |
| Diluted EPS |  |  |  | $1.26 |  | $0.00 |  | ($0.13) | ($0.04) |  | $1.09 |  |
| Diluted shares used |  |  |  | 1,722 |  | 1,722 |  | 1,722 | 1,722 |  | 1,722 |  |
| Q2 - FISCAL 2014 |  |  |  |  |  |
| Revenues | $4,243 | $2,071 | $53 | $6,367 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $6,367 |  |
| Operating income (loss) |  |  |  | 2,337 |  | (6) |  | (251) | (90) |  | 1,990 |  |
| EBT | $740 | $1,834 | $78 | 2,652 |  | (39) |  | (251) | (90) |  | 2,272 |  |
| Net income (loss) |  |  |  | 2,255 |  | (17) |  | (198) | (81) |  | 1,959 |  |
| Diluted EPS |  |  |  | $1.31 |  | ($0.01) |  | ($0.11) | ($0.05) |  | $1.14 |  |
| Diluted shares used |  |  |  | 1,719 |  | 1,719 |  | 1,719 | 1,719 |  | 1,719 |  |
| 12 MONTHS - FISCAL 2014 |  |  |  |  |  |
| Revenues | $18,665 | $7,569 | $253 | $26,487 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $26,487 |  |
| Operating income (loss) |  |  |  | 8,933 |  | (18) |  | (1,059) | (306) |  | 7,550 |  |
| EBT | $3,807 | $6,590 | ($247) | 10,150 |  | (7) |  | (1,059) | (306) |  | 8,778 |  |
| Discontinued operations, net of tax |  |  |  | 430 |  | — |  |  | — |  | — |  |  | 430 |  |
| Net income (loss) |  |  |  | 9,032 |  | 15 |  | (856) | (224) |  | 7,967 |  |
| Diluted EPS |  |  |  | $5.27 |  | $0.01 |  | ($0.50) | ($0.13) |  | $4.65 |  |
| Diluted shares used |  |  |  | 1,714 |  | 1,714 |  | 1,714 | 1,714 |  | 1,714 |  |

[0001234452-15-000022:8k_2_02:65]
| (a) | Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations. Non-GAAP reconciling items related to earnings before taxes consisted primarily of certain research and development expenses, selling, general and administrative expenses, other expenses or income and certain investment income that are not allocated to the segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit. |

[0001234452-15-000022:8k_2_02:66]
| (b) | Beginning in the first quarter of fiscal 2015, we changed our methodology for reporting Non-GAAP results to exclude third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. In the first quarter of fiscal 2015, other items excluded from Non-GAAP EBT included $83 million of acquisition-related items, $69 million due to the impairment of goodwill related to our business that provides push-to-talk enablement services to wireless operators and $35 million of severance costs related to a restructuring. |

[0001234452-15-000022:8k_2_02:67]
| (c) | The tax benefit in the “Other Items” column included a $101 million tax benefit related to fiscal 2014 as a result of the retroactive reinstatement of the federal R&D tax credit, a $21 million tax benefit for the tax effect of other items in EBT, a $4 million tax benefit related to fiscal 2014 as a result of the retroactive reinstatement of other tax laws and a $2 million tax benefit to reconcile the tax provisions for each column to the total GAAP tax provision for the quarter, partially offset by a $3 million tax expense for the tax effect of acquisition-related items. At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. In interim quarters of prior year, this difference was allocated to the tax provisions (benefits) among the columns. See the “Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates” below. |

[0001234452-15-000022:8k_2_02:68]
| (d) | Included $156 million in net realized gains on investments, $133 million in interest and dividend income and $1 million in other net investment income, partially offset by $62 million in other-than-temporary losses on investments. |

[0001234452-15-000022:8k_2_02:69]
| (e) | Included $10 million in net realized gains on investments, partially offset by $4 million in other net investment expense. |

[0001234452-15-000022:8k_2_02:70]
N/M - Not Meaningful

[0001234452-15-000022:8k_2_02:71]
Sums may not equal totals due to rounding.

[0001234452-15-000022:8k_2_02:72]
Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates

[0001234452-15-000022:8k_2_02:73]
(Unaudited)

[0001234452-15-000022:8k_2_02:74]
| Three Months Ended December 28, 2014 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Other Items |  |  | GAAP Results |  |
| Income (loss) from continuing operations before income taxes |  | $ | 2,759 |  |  |  | $ | (1 | ) |  |  | $ | (273 | ) |  |  | $ | (187 | ) |  |  | $ | 2,298 |  |  |
| Income tax (expense) benefit |  | (496 | ) |  |  | — |  |  |  | 44 |  |  |  | 125 |  |  |  | (327 | ) |  |
| Income (loss) from continuing operations |  | $ | 2,263 |  |  |  | $ | (1 | ) |  |  | $ | (229 | ) |  |  | $ | (62 | ) |  |  | $ | 1,971 |  |  |
| Tax rate |  | 18 | % |  |  | — | % |  |  | 16 | % |  |  | 67% |  |  |  | 14 | % |  |

[0001234452-15-000022:8k_2_02:75]
Conference Call

[0001234452-15-000022:8k_2_02:76]
Qualcomm’s first quarter fiscal 2015 earnings conference call will be broadcast live on January 28, 2015, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 55501467.

[0001234452-15-000022:8k_2_02:77]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-15-000022:8k_2_02:78]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for, or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-15-000022:8k_2_02:79]
The Company uses Non-GAAP financial information (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against each other and against competitors.  Non-GAAP measurements used by the Company include revenues, cost of equipment and services revenues, R&D expenses, SG&A expenses, other expenses, operating income, net investment income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  As a result, management compensation decisions and the review of executive compensation by the Compensation Committee of the Board of Directors focus primarily on Non-GAAP financial measures applicable to the Company and its business segments.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.

[0001234452-15-000022:8k_2_02:80]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items, tax items and other items.

[0001234452-15-000022:8k_2_02:81]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-15-000022:8k_2_02:82]
| • | Share-based compensation expense primarily relates to restricted stock units. Non-cash share-based compensation is excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses. |

[0001234452-15-000022:8k_2_02:83]
| • | Certain other items are excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core business, including: |

[0001234452-15-000022:8k_2_02:84]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items starting with acquisitions completed in the third quarter of fiscal 2011, as well as any tax effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property. Starting in the first quarter of fiscal 2015, the Company excludes third-party |

[0001234452-15-000022:8k_2_02:85]
acquisition and integration services costs.  Prior year amounts have not been reclassified to conform to the current presentation.

[0001234452-15-000022:8k_2_02:86]
| • | Starting in the first quarter of fiscal 2015, the Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and long-lived asset impairments and litigation settlements and/or damages. Prior year amounts have not been reclassified to conform to the current presentation. |

[0001234452-15-000022:8k_2_02:87]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. Also, the provision (benefit) to reconcile the tax provisions (benefits) for each column to the total GAAP tax provision for the quarter is excluded. At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. In interim quarters of prior fiscal years, this difference was allocated to the tax provisions (benefits) among the columns. |

[0001234452-15-000022:8k_2_02:88]
About Qualcomm

[0001234452-15-000022:8k_2_02:89]
Qualcomm Incorporated (Nasdaq:  QCOM) is a world leader in 3G, 4G and next-generation wireless technologies.  Qualcomm Incorporated includes Qualcomm’s licensing business, QTL, and the vast majority of its patent portfolio.  Qualcomm Technologies, Inc., a wholly-owned subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of Qualcomm’s engineering, research and development functions, and substantially all of its products and services businesses, including its semiconductor business, QCT.  For more than 25 years, Qualcomm ideas and inventions have driven the evolution of digital communications, linking people everywhere more closely to information, entertainment and each other.  For more information, visit www.qualcomm.com.

[0001234452-15-000022:8k_2_02:90]
Note Regarding Forward-Looking Statements

[0001234452-15-000022:8k_2_02:91]
In addition to the historical information contained herein, this news release contains forward-looking statements that are inherently subject to risks and uncertainties, including but not limited to statements regarding: our lowered outlook for our semiconductor business for the second half of the fiscal year and our lowered EPS expectations, largely driven by the effects of a shift in share among OEMs at the premium tier, expectations that our Snapdragon 810 processor will not be in the upcoming design cycle of a large customer’s flagship device and heightened competition in China; stock repurchases that we

[0001234452-15-000022:8k_2_02:92]
###

[0001234452-15-000022:8k_2_02:93]
Qualcomm, Snapdragon and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-15-000022:8k_2_02:94]
Qualcomm Incorporated

[0001234452-15-000022:8k_2_02:95]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001234452-15-000022:8k_2_02:96]
(In millions, except per share data)

[0001234452-15-000022:8k_2_02:97]
(Unaudited)

[0001234452-15-000022:8k_2_02:98]
|  | December 28, 2014 |  | September 28, 2014 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 6,325 |  |  | $ | 7,907 |  |
| Marketable securities | 11,463 |  |  | 9,658 |  |
| Accounts receivable, net | 2,239 |  |  | 2,412 |  |
| Inventories | 1,761 |  |  | 1,458 |  |
| Deferred tax assets | 445 |  |  | 577 |  |
| Other current assets | 528 |  |  | 401 |  |
| Total current assets | 22,761 |  |  | 22,413 |  |
| Marketable securities | 13,815 |  |  | 14,457 |  |
| Deferred tax assets | 1,329 |  |  | 1,174 |  |
| Property, plant and equipment, net | 2,531 |  |  | 2,487 |  |
| Goodwill | 4,413 |  |  | 4,488 |  |
| Other intangible assets, net | 2,497 |  |  | 2,580 |  |
| Other assets | 1,101 |  |  | 975 |  |
| Total assets | $ | 48,447 |  |  | $ | 48,574 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 2,482 |  |  | $ | 2,183 |  |
| Payroll and other benefits related liabilities | 786 |  |  | 802 |  |
| Unearned revenues | 885 |  |  | 785 |  |
| Other current liabilities | 2,252 |  |  | 2,243 |  |
| Total current liabilities | 6,405 |  |  | 6,013 |  |
| Unearned revenues | 2,763 |  |  | 2,967 |  |
| Other liabilities | 460 |  |  | 428 |  |
| Total liabilities | 9,628 |  |  | 9,408 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,654 and 1,669 shares issued and outstanding, respectively | 6,334 |  |  | 7,736 |  |
| Retained earnings | 32,061 |  |  | 30,799 |  |
| Accumulated other comprehensive income | 428 |  |  | 634 |  |
| Total Qualcomm stockholders’ equity | 38,823 |  |  | 39,169 |  |
| Noncontrolling interests | (4 | ) |  | (3 | ) |
| Total stockholders’ equity | 38,819 |  |  | 39,166 |  |
| Total liabilities and stockholders’ equity | $ | 48,447 |  |  | $ | 48,574 |  |

[0001234452-15-000022:8k_2_02:99]
Qualcomm Incorporated

[0001234452-15-000022:8k_2_02:100]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-15-000022:8k_2_02:101]
(In millions, except per share data)

[0001234452-15-000022:8k_2_02:102]
(Unaudited)

[0001234452-15-000022:8k_2_02:103]
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |
| Revenues: |  |  |  |
| Equipment and services | $ | 5,216 |  |  | $ | 4,653 |  |
| Licensing | 1,883 |  |  | 1,969 |  |
| Total revenues | 7,099 |  |  | 6,622 |  |
| Costs and expenses: |  |  |  |
| Cost of equipment and services revenues | 3,047 |  |  | 2,706 |  |
| Research and development | 1,352 |  |  | 1,328 |  |
| Selling, general and administrative | 567 |  |  | 623 |  |
| Other | 69 |  |  | 472 |  |
| Total costs and expenses | 5,035 |  |  | 5,129 |  |
| Operating income | 2,064 |  |  | 1,493 |  |
| Investment income, net | 234 |  |  | 264 |  |
| Income from continuing operations before income taxes | 2,298 |  |  | 1,757 |  |
| Income tax expense | (327 | ) |  | (313 | ) |
| Income from continuing operations | 1,971 |  |  | 1,444 |  |
| Discontinued operations, net of income taxes | — |  |  | 430 |  |
| Net income | 1,971 |  |  | 1,874 |  |
| Net loss attributable to noncontrolling interests | 1 |  |  | 1 |  |
| Net income attributable to Qualcomm | $ | 1,972 |  |  | $ | 1,875 |  |
| Basic earnings per share attributable to Qualcomm: |  |  |  |
| Continuing operations | $ | 1.19 |  |  | $ | 0.86 |  |
| Discontinued operations | — |  |  | 0.25 |  |
| Net income | $ | 1.19 |  |  | $ | 1.11 |  |
| Diluted earnings per share attributable to Qualcomm: |  |  |  |
| Continuing operations | $ | 1.17 |  |  | $ | 0.84 |  |
| Discontinued operations | — |  |  | 0.25 |  |
| Net income | $ | 1.17 |  |  | $ | 1.09 |  |
| Shares used in per share calculations: |  |  |  |
| Basic | 1,661 |  |  | 1,688 |  |
| Diluted | 1,686 |  |  | 1,722 |  |
| Dividends per share announced | $ | 0.42 |  |  | $ | 0.35 |  |

[0001234452-15-000022:8k_2_02:104]
Qualcomm Incorporated

[0001234452-15-000022:8k_2_02:105]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-15-000022:8k_2_02:106]
(In millions)

[0001234452-15-000022:8k_2_02:107]
(Unaudited)

[0001234452-15-000022:8k_2_02:108]
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |
| Operating Activities: |  |  |  |
| Net income | $ | 1,971 |  |  | $ | 1,874 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization expense | 287 |  |  | 272 |  |
| Gain on sale of discontinued operations | — |  |  | (665 | ) |
| Long-lived asset and goodwill impairment charges | 75 |  |  | 460 |  |
| Income tax provision (less than) in excess of income tax payments | (7 | ) |  | 258 |  |
| Non-cash portion of share-based compensation expense | 273 |  |  | 282 |  |
| Incremental tax benefits from share-based compensation | (48 | ) |  | (99 | ) |
| Net realized gains on marketable securities and other investments | (166 | ) |  | (145 | ) |
| Impairment losses on marketable securities and other investments | 65 |  |  | 37 |  |
| Other items, net | (31 | ) |  | 2 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable, net | 173 |  |  | 788 |  |
| Inventories | (303 | ) |  | 237 |  |
| Other assets | (140 | ) |  | 69 |  |
| Trade accounts payable | 268 |  |  | (148 | ) |
| Payroll, benefits and other liabilities | 20 |  |  | (342 | ) |
| Unearned revenues | (73 | ) |  | (99 | ) |
| Net cash provided by operating activities | 2,364 |  |  | 2,781 |  |
| Investing Activities: |  |  |  |
| Capital expenditures | (253 | ) |  | (210 | ) |
| Purchases of available-for-sale securities | (5,966 | ) |  | (2,055 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 4,578 |  |  | 2,168 |  |
| Purchases of trading securities | (302 | ) |  | (785 | ) |
| Proceeds from sales and maturities of trading securities | 296 |  |  | 773 |  |
| Proceeds from sale of discontinued operations, net of cash sold | — |  |  | 788 |  |
| Acquisitions and other investments, net of cash acquired | (98 | ) |  | (315 | ) |
| Other items, net | 9 |  |  | 81 |  |
| Net cash (used) provided by investing activities | (1,736 | ) |  | 445 |  |
| Financing Activities: |  |  |  |
| Proceeds from issuance of common stock | 116 |  |  | 441 |  |
| Incremental tax benefits from share-based compensation | 48 |  |  | 99 |  |
| Repurchases and retirements of common stock | (1,664 | ) |  | (1,002 | ) |
| Dividends paid | (697 | ) |  | (590 | ) |
| Other items, net | (6 | ) |  | (21 | ) |
| Net cash used by financing activities | (2,203 | ) |  | (1,073 | ) |
| Changes in cash and cash equivalents held for sale | — |  |  | (4 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (7 | ) |  | 1 |  |
| Net (decrease) increase in cash and cash equivalents | (1,582 | ) |  | 2,150 |  |
| Cash and cash equivalents at beginning of period | 7,907 |  |  | 6,142 |  |
| Cash and cash equivalents at end of period | $ | 6,325 |  |  | $ | 8,292 |  |
