# QCOM note change history — 0001728949-20-000031 → 0001728949-20-000057


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2020-07-29):
[0001728949-20-000057:note_history:1]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by

- changed (2020-07-29):
[0001728949-20-000057:note_history:2]
making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss the complaint. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.
  (was, 2020-04-29, similarity 0.6535):
[0001728949-20-000031:note_history:2]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss the complaint. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

- changed (2020-07-29):
[0001728949-20-000057:note_history:3]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On January 22, 2019, the court appointed the lead plaintiff in the action. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint, and on March 10, 2020, the court granted our motion. On May 11, 2020, the plaintiffs filed a second amended complaint, and on June 25, 2020, we filed a motion to dismiss that complaint. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.
  (was, 2020-04-29, similarity 0.8676):
[0001728949-20-000031:note_history:3]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On January 22, 2019, the court appointed the lead plaintiff in the action. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint, and on March 10, 2020, the court granted our motion. The plaintiffs have until May 11, 2020 to file an amended complaint. We believe the plaintiffs’ claims are without merit.

- changed (2020-07-29):
[0001728949-20-000057:note_history:4]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Currently, twenty-two such cases remained outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. The Ninth Circuit has not yet ruled on our appeal. We believe the plaintiffs’ claims are without merit.
  (was, 2020-04-29, similarity 0.9136):
[0001728949-20-000031:note_history:4]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Currently, twenty-two such cases remained outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) granted us

- changed (2020-07-29):
[0001728949-20-000057:note_history:5]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, eight consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the U.S. consumer class action complaints. The complaints seek unspecified damages. One of the complaints in the Supreme Court of British Columbia has since been discontinued by the plaintiffs. We have not yet answered the complaints. We expect the Ontario and British Columbia complaints will be consolidated into one proceeding in British Columbia with a class certification hearing no earlier than late 2020. Once the certification hearing is scheduled, we expect the court to set a timetable for the exchange of evidence and briefing. As to the complaint filed in Quebec, on April 15, 2019, the Quebec Superior Court held a class certification hearing, and on April 30, 2019, the court issued an order certifying a class. We are awaiting the court to set a timetable for pre-trial steps, including discovery, as well as the exchange of expert evidence. We do not expect the trial to occur before 2022. We believe the plaintiffs’ claims are without merit.
  (was, 2020-04-29, similarity 0.9996):
[0001728949-20-000031:note_history:5]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, eight consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the U.S. consumer class action complaint. The complaints seek unspecified damages. One of the complaints in the Supreme Court of British Columbia has since been discontinued by the plaintiffs. We have not yet answered the complaints. We expect the Ontario and British Columbia complaints will be consolidated into one proceeding in British Columbia with a class certification hearing no earlier than late 2020. Once the certification hearing is scheduled, we expect the court to set a timetable for the exchange of evidence and briefing. As to the complaint filed in Quebec, on April 15, 2019, the Quebec Superior Court held a class certification hearing, and on April 30, 2019, the court issued an order certifying a class. We are awaiting the court to set a timetable for pre-trial steps, including discovery, as well as the exchange of expert evidence. We do not expect the trial to occur before 2022. We believe the plaintiffs’ claims are without merit.

- added (2020-07-29):
[0001728949-20-000057:note_history:6]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts

- changed (2020-07-29):
[0001728949-20-000057:note_history:7]
violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.
  (was, 2020-04-29, similarity 0.8981):
[0001728949-20-000031:note_history:7]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

- added (2020-07-29):
[0001728949-20-000057:note_history:8]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of their investigation, but we believe it concerns our business practices in connection with our sale of radio frequency front end (RFFE) components. We are responding to several Requests for Information. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

- changed (2020-07-29):
[0001728949-20-000057:note_history:9]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision confirming their preliminary view that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.
  (was, 2020-04-29, similarity 0.8733):
[0001728949-20-000031:note_history:9]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision confirming their preliminary view that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the

- changed (2020-07-29):
[0001728949-20-000057:note_history:10]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At June 28, 2020, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $275 million and included in other current liabilities.
  (was, 2020-04-29, similarity 0.9893):
[0001728949-20-000031:note_history:10]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At March 29, 2020, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other (expense) income, net), was $272 million and included in other current liabilities.

- changed (2020-07-29):
[0001728949-20-000057:note_history:11]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At June 28, 2020, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.2 billion and included in other current liabilities.
  (was, 2020-04-29, similarity 0.9892):
[0001728949-20-000031:note_history:11]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At March 29, 2020, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other (expense) income, net), was $1.1 billion and included in other current liabilities.

- changed (2020-07-29):
[0001728949-20-000057:note_history:12]
European Commission (EC) Investigation regarding Radio Frequency Front End (RFFE): On December 3, 2019, we received a Request for Information from the EC notifying us that it is investigating whether we engaged in anti-competitive behavior in the European Union (EU)/European Economic Area (EEA) by leveraging our market position in 5G baseband processors in the RFFE space. We have responded to the Request for Information. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of our annual revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. We believe that our business practices do not violate the EU competition rules.
  (was, 2020-04-29, similarity 0.9994):
[0001728949-20-000031:note_history:12]
European Commission (EC) Investigation regarding Radio Frequency Front Ends (RFFE): On December 3, 2019, we received a Request for Information from the EC notifying us that it is investigating whether we engaged in anti-competitive behavior in the European Union (EU)/European Economic Area (EEA) by leveraging our market position in 5G baseband processors in the RFFE space. We have responded to the Request for Information. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of our annual revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. We believe that our business practices do not violate the EU competition rules.

- added (2020-07-29):
[0001728949-20-000057:note_history:13]
On May 21, 2019, the court issued an Order setting forth its Findings of Fact and Conclusions of Law. The court concluded that we had monopoly power in the CDMA and premium-tier Long Term Evolution (LTE) cellular modem chip markets, and that we had used that power in these two markets to engage in anticompetitive acts, including (1) using threats of lack of access to cellular modem chip supply to coerce OEMs to accept license terms that include unreasonably high royalty rates; (2) refusing to license our cellular standard-essential patents to competitors selling cellular modem chips; and (3) entering into exclusive dealing arrangements with OEMs that foreclosed our rivals. The court further found that the royalties we charge OEMs are unreasonably high and reflect the use of our monopoly power over CDMA and premium-tier LTE cellular modem chips rather than just the value of our patents. The court concluded that our unreasonably high royalties constitute an anticompetitive surcharge on cellular modem chips sold by our competitors, which increases the effective price of our competitors’ cellular modem chips, reduces their margins and results in exclusivity. The court also found that our practice of not licensing competitors’ cellular modem chips violated our commitments to certain standard-development organizations and a duty under the antitrust laws to license competing cellular modem chip makers and helped us maintain our royalties at unreasonably high levels. Finally, the court found that incentive funds entered into with certain OEMs further harmed competing cellular modem chip makers’ ability to undermine our monopoly position, prevented rivals from entering the market and restricted the sales of those competitors that do enter. The court concluded that the combined effect of our conduct, together with our monopoly power, harmed the competitive process.

- added (2020-07-29):
[0001728949-20-000057:note_history:14]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On August 23, 2019, the Ninth Circuit granted our Motion for Partial Stay. Thus, pending the resolution of the appeal in the Ninth Circuit or until further order of the Ninth Circuit, the portions of the court’s injunction requiring that we must (i) make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers and (ii) not condition the supply of cellular modem chips on a customer’s patent license status and must negotiate or renegotiate license terms with customers are stayed. On July 10, 2019, the Ninth Circuit granted our Motion to Expedite Appeal. On February 13, 2020, the Ninth Circuit heard oral argument, but has not yet ruled on our appeal.

- changed (2020-07-29):
[0001728949-20-000057:note_history:15]
Contingent losses and other considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at June 28, 2020 for contingent losses associated with these matters based on our belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.
  (was, 2020-04-29, similarity 0.9942):
[0001728949-20-000031:note_history:15]
Contingent losses and other considerations: We will continue to vigorously defend ourself in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at March 29, 2020 for contingent losses associated with these matters based on our belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- changed (2020-07-29):
[0001728949-20-000057:note_history:16]
Claims and reimbursements under indemnification arrangements have not been material to our consolidated financial statements. At June 28, 2020, accruals for contingent liabilities associated with these indemnification arrangements were negligible. We have not recorded accruals for certain claims under indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.
  (was, 2020-04-29, similarity 0.9908):
[0001728949-20-000031:note_history:16]
Claims and reimbursements under indemnification arrangements have not been material to our consolidated financial statements. At March 29, 2020, accruals for contingent liabilities associated with these indemnification arrangements were negligible. We have not recorded accruals for certain claims under indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- changed (2020-07-29):
[0001728949-20-000057:note_history:17]
Operating Leases. We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years. At June 28, 2020, other assets included $458 million of operating lease assets, with corresponding lease liabilities of $128 million recorded in other current liabilities and $374 million recorded in other liabilities.
  (was, 2020-04-29, similarity 0.9892):
[0001728949-20-000031:note_history:17]
Operating Leases. We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years. At March 29, 2020, other assets included $475 million of operating lease assets, with corresponding lease liabilities of $132 million recorded in other current liabilities and $389 million recorded in other liabilities.

- changed (2020-07-29):
[0001728949-20-000057:note_history:18]
Operating lease expense for the three and nine months ended June 28, 2020 was $45 million and $132 million, respectively, and $38 million and $110 million for the three and nine months ended June 30, 2019, respectively. Cash paid under our operating leases was $114 million for the nine months ended June 28, 2020. As of June 28, 2020, the weighted-average remaining lease term and weighted-average discount rate for operating leases were 6.0 years and 4%, respectively.
  (was, 2020-04-29, similarity 0.8389):
[0001728949-20-000031:note_history:18]
Operating lease expense for the three and six months ended March 29, 2020 was $44 million and $88 million, respectively, and $35 million and $72 million for the three and six months ended March 31, 2019, respectively. Cash paid under our operating leases was $74 million for the six months ended March 29, 2020. As of March 29, 2020, the weighted-average remaining lease term and weighted-average discount rate for operating leases were 6.0 years and 4%, respectively.

- changed (2020-07-29):
[0001728949-20-000057:note_history:19]
At June 28, 2020, future lease payments under our operating leases were as follows (in millions):
  (was, 2020-04-29, similarity 0.9508):
[0001728949-20-000031:note_history:19]
At March 29, 2020, future lease payments under our operating leases were as follows (in millions):

- changed (2020-07-29):
[0001728949-20-000057:note_history:20]
|  |  |  | June 28,2020 |
| Remainder of fiscal 2020 |  |  | $ | 38 |  |
| 2021 |  |  | 132 |  |
| 2022 |  |  | 112 |  |
| 2023 |  |  | 68 |  |
| 2024 |  |  | 49 |  |
| Thereafter |  |  | 178 |  |
| Total future lease payments |  |  | 577 |  |
| Imputed interest |  |  | (75) |  |
| Total lease liability balance |  |  | $ | 502 |  |
  (was, 2020-04-29, similarity 0.9597):
[0001728949-20-000031:note_history:20]
|  |  |  | Operating Leases |
| Remainder of fiscal 2020 |  |  | $ | 76 |  |
| 2021 |  |  | 130 |  |
| 2022 |  |  | 109 |  |
| 2023 |  |  | 66 |  |
| 2024 |  |  | 47 |  |
| Thereafter |  |  | 172 |  |
| Total future lease payments |  |  | 600 |  |
| Imputed interest |  |  | (79) |  |
| Total lease liability balance |  |  | $ | 521 |  |

- changed (2020-07-29):
[0001728949-20-000057:note_history:21]
|  |  |  | September 29,2019 |
| 2020 |  |  | $ | 138 |  |
| 2021 |  |  | 97 |  |
| 2022 |  |  | 66 |  |
| 2023 |  |  | 31 |  |
| 2024 |  |  | 18 |  |
| Thereafter |  |  | 35 |  |
| Total |  |  | $ | 385 |  |
  (was, 2020-04-29, similarity 0.9265):
[0001728949-20-000031:note_history:21]
|  |  |  | Operating Leases |
| 2020 |  |  | $ | 138 |  |
| 2021 |  |  | 97 |  |
| 2022 |  |  | 66 |  |
| 2023 |  |  | 31 |  |
| 2024 |  |  | 18 |  |
| Thereafter |  |  | 35 |  |
| Total |  |  | $ | 385 |  |

- removed (2020-07-29):
[0001728949-20-000031:note_history:22]
permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. The Ninth Circuit has not yet ruled on our appeal. We believe the plaintiffs’ claims are without merit.

- removed (2020-07-29):
[0001728949-20-000031:note_history:23]
EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

- removed (2020-07-29):
[0001728949-20-000031:note_history:24]
On May 21, 2019, the court issued an Order setting forth its Findings of Fact and Conclusions of Law. The court concluded that we had monopoly power in the CDMA and premium-tier Long Term Evolution (LTE) cellular modem chip markets, and that we had used that power in these two markets to engage in anticompetitive acts, including (1) using threats of lack of access to cellular modem chip supply to coerce OEMs to accept license terms that include unreasonably high royalty rates; (2) refusing to license our cellular standard-essential patents to competitors selling cellular modem chips; and

- removed (2020-07-29):
[0001728949-20-000031:note_history:25]
(3) entering into exclusive dealing arrangements with OEMs that foreclosed our rivals. The court further found that the royalties we charge OEMs are unreasonably high and reflect the use of our monopoly power over CDMA and premium-tier LTE cellular modem chips rather than just the value of our patents. The court concluded that our unreasonably high royalties constitute an anticompetitive surcharge on cellular modem chips sold by our competitors, which increases the effective price of our competitors’ cellular modem chips, reduces their margins and results in exclusivity. The court also found that our practice of not licensing competitors’ cellular modem chips violated our commitments to certain standard-development organizations and a duty under the antitrust laws to license competing cellular modem chip makers and helped us maintain our royalties at unreasonably high levels. Finally, the court found that incentive funds entered into with certain OEMs further harmed competing cellular modem chip makers’ ability to undermine our monopoly position, prevented rivals from entering the market and restricted the sales of those competitors that do enter. The court concluded that the combined effect of our conduct, together with our monopoly power, harmed the competitive process.

- removed (2020-07-29):
[0001728949-20-000031:note_history:26]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On August 23, 2019, the Ninth Circuit granted our Motion. Thus, pending the resolution of the appeal in the Ninth Circuit or until further order of the Ninth Circuit, the portions of the court’s injunction requiring that we must (i) make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers and (ii) not condition the supply of cellular modem chips on a customer’s patent license status and must negotiate or renegotiate license terms with customers are stayed. On July 10, 2019, the Ninth Circuit granted our Motion to Expedite Appeal. On February 13, 2020, the Ninth Circuit heard oral argument, but has not yet ruled on our appeal.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-07-29):
[0001728949-20-000057:note_history:27]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 29, 2019. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and nine months ended June 28, 2020 and June 30, 2019 included 13 weeks and 39 weeks, respectively.
  (was, 2020-04-29, similarity 0.9687):
[0001728949-20-000031:note_history:27]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 29, 2019. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 29, 2020 and March 31, 2019 included 13 weeks and 26 weeks, respectively.

- changed (2020-07-29):
[0001728949-20-000057:note_history:28]
Financial Assets: In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) will be estimated based on expected losses rather than the current incurred loss impairment model. The new accounting guidance also eliminates the concept of other-than-temporary impairment and requires credit losses related to available-for-sale debt securities to be recorded through an allowance for credit losses rather than as a reduction in the amortized cost basis of the securities. These changes will result in earlier recognition of credit losses, if any. The new accounting guidance generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt 
securities for which an other-than-temporary impairment has been recorded. We will adopt the new accounting guidance in the first quarter of fiscal 2021, and the impact of this new accounting guidance will largely depend on the composition and credit quality of our investment portfolio and accounts receivable, as well as economic conditions, at the time of adoption. Based on facts and factors currently known by us, we do not expect the impact of adoption to be material to our consolidated financial statements.
  (was, 2020-04-29, similarity 0.9019):
[0001728949-20-000031:note_history:28]
Financial Assets: In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) will be estimated based on expected losses rather than the current incurred loss impairment model. The new accounting guidance also modifies the impairment model for available-for-sale debt securities. These changes will result in earlier recognition of credit losses, if any. The new accounting guidance generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. We will adopt the new accounting guidance in the first quarter of fiscal 2021, and the impact of this new 
accounting guidance will largely depend on the composition and credit quality of our investment portfolio and accounts receivable, as well as economic conditions, at the time of adoption. Based on facts and factors currently known by us, we do not expect the impact of adoption to be material to our consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-07-29):
[0001728949-20-000057:note_history:29]
Debt
Long-term Debt. In May 2020, we issued unsecured fixed-rate notes, consisting of $1.2 billion fixed-rate 2.15% notes and $800 million fixed-rate 3.25% notes (May 2020 Notes) that mature on May 20, 2030 and May 20, 2050, respectively. The proceeds from the May 2020 Notes, net of underwriting discounts and offering expenses, were used to repay the $250 million floating-rate and $1.75 billion fixed-rate notes that matured on May 20, 2020, which were classified as short-term debt at September 29, 2019. We are not subject to any financial covenants under the May 2020 Notes nor any covenants that would prohibit us from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by us or our subsidiaries. The May 2020 Notes are senior unsecured obligations and rank equally with our other senior debt from time to time outstanding. We may redeem the outstanding fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable note.

- added (2020-07-29):
[0001728949-20-000057:note_history:30]
The following table provides a summary of our long-term debt:

- added (2020-07-29):
[0001728949-20-000057:note_history:31]
|  | June 28, 2020 |  |  |  |  |  | September 29, 2019 |  |  |  |  |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2022 - 2045 |  | $ | 6,500 |  |  | 2.62% - 4.73% |  | 2020 - 2045 |  | $ | 8,500 |  |  | 2.64% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 7,000 |  |  | 1.55% - 4.46% |  | 2023 - 2047 |  | 7,000 |  |  | 2.70% - 4.47% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.31% - 3.30% |  |  |  | — |  |  |  |
| Total principal |  |  | 15,500 |  |  |  |  |  |  | 15,500 |  |  |  |
| Unamortized discount, including debt issuance costs |  |  | (91) |  |  |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 16 |  |  |  |  |  |  | 9 |  |  |  |
| Total long-term debt |  |  | $ | 15,425 |  |  |  |  |  |  | $ | 15,434 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | — |  |  |  |  |  |  | $ | 1,997 |  |  |  |
| Long-term debt |  |  | 15,425 |  |  |  |  |  |  | 13,437 |  |  |  |
| Total |  |  | $ | 15,425 |  |  |  |  |  |  | $ | 15,434 |  |  |  |

- added (2020-07-29):
[0001728949-20-000057:note_history:32]
At September 29, 2019, we had outstanding interest rate swaps with an aggregate notional amount of $1.8 billion related to certain of our May 2015 Notes. During the second quarter of fiscal 2020, we terminated interest rate swaps related to our fixed-rate 3.00% notes due May 20, 2022 resulting in a deferred gain of $19 million, which is being amortized to interest expense over the remaining term of such notes. During the third quarter of fiscal 2020, the remaining interest rate swaps on our fixed-rate 2.25% notes due May 20, 2020 terminated upon maturity of the notes.

- added (2020-07-29):
[0001728949-20-000057:note_history:33]
At June 28, 2020 and September 29, 2019, the aggregate fair value of our remaining outstanding principal floating- and fixed-rate notes, including the current portion of long-term debt, based on Level 2 inputs, was approximately $17.6 billion and $16.5 billion, respectively.

- added (2020-07-29):
[0001728949-20-000057:note_history:34]
Commercial Paper Program. In the third quarter of fiscal 2020, we reduced the total amount available for issuance under our unsecured commercial paper program from $5.0 billion to $4.5 billion. At June 28, 2020 and September 29, 2019, we had $500 million and $499 million, respectively, of outstanding commercial paper recorded as short-term debt.

- added (2020-07-29):
[0001728949-20-000057:note_history:35]
Revolving Credit Facility. We have an Amended and Restated Revolving Credit Facility (Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion which expires on November 8, 2021. At June 28, 2020, no amounts were outstanding under the Revolving Credit Facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-07-29):
[0001728949-20-000057:note_history:36]
|  | Current |  |  |  | Noncurrent (1) |  |  |
|  | June 28,2020 |  | September 29,2019 |  | June 28,2020 |  | September 29,2019 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 6 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,005 |  |  | 4 |  |  | — |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 84 |  |  | — |  |  | 34 |  |  | 35 |  |
| Total available-for-sale debt securities | 4,095 |  |  | 4 |  |  | 34 |  |  | 35 |  |
| Equity securities | 355 |  |  | 417 |  |  | — |  |  | 1 |  |
| Time deposit (2) | 30 |  |  | — |  |  | — |  |  | — |  |
| Total marketable securities | $ | 4,480 |  |  | $ | 421 |  |  | $ | 34 |  |  | $ | 36 |  |
  (was, 2020-04-29, similarity 0.9382):
[0001728949-20-000031:note_history:36]
|  | Current |  |  |  | Noncurrent (1) |  |  |
|  | March 29,2020 |  | September 29,2019 |  | March 29,2020 |  | September 29,2019 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 1,253 |  |  | 4 |  |  | — |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 48 |  |  | — |  |  | 33 |  |  | 35 |  |
| Total available-for-sale debt securities | 1,304 |  |  | 4 |  |  | 33 |  |  | 35 |  |
| Equity securities | 239 |  |  | 417 |  |  | — |  |  | 1 |  |
| Total marketable securities | $ | 1,543 |  |  | $ | 421 |  |  | $ | 33 |  |  | $ | 36 |  |

- added (2020-07-29):
[0001728949-20-000057:note_history:37]
(2) At June 28, 2020, marketable securities also included a time deposit with an original maturity of greater than 90 days.

- changed (2020-07-29):
[0001728949-20-000057:note_history:38]
The contractual maturities of available-for-sale debt securities were as follows (in millions):
  (was, 2020-04-29, similarity 0.9453):
[0001728949-20-000031:note_history:38]
The contractual maturities of available-for-sale marketable debt securities were as follows (in millions):

- changed (2020-07-29):
[0001728949-20-000057:note_history:39]
|  | June 28,2020 |
| Years to Maturity |  |
| Less than one year | $ | 2,730 |  |
| One to five years | 1,281 |  |
| No single maturity date | 118 |  |
| Total | $ | 4,129 |  |
  (was, 2020-04-29, similarity 0.9703):
[0001728949-20-000031:note_history:39]
|  | March 29,2020 |
| Years to Maturity |  |
| Less than one year | $ | 813 |  |
| One to five years | 443 |  |
| No single maturity date | 81 |  |
| Total | $ | 1,337 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-07-29):
[0001728949-20-000057:note_history:40]
The following table provides a summary of our long-term debt:

- added (2020-07-29):
[0001728949-20-000057:note_history:41]
|  | June 28, 2020 |  |  |  |  |  | September 29, 2019 |  |  |  |  |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2022 - 2045 |  | $ | 6,500 |  |  | 2.62% - 4.73% |  | 2020 - 2045 |  | $ | 8,500 |  |  | 2.64% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 7,000 |  |  | 1.55% - 4.46% |  | 2023 - 2047 |  | 7,000 |  |  | 2.70% - 4.47% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.31% - 3.30% |  |  |  | — |  |  |  |
| Total principal |  |  | 15,500 |  |  |  |  |  |  | 15,500 |  |  |  |
| Unamortized discount, including debt issuance costs |  |  | (91) |  |  |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 16 |  |  |  |  |  |  | 9 |  |  |  |
| Total long-term debt |  |  | $ | 15,425 |  |  |  |  |  |  | $ | 15,434 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | — |  |  |  |  |  |  | $ | 1,997 |  |  |  |
| Long-term debt |  |  | 15,425 |  |  |  |  |  |  | 13,437 |  |  |  |
| Total |  |  | $ | 15,425 |  |  |  |  |  |  | $ | 15,434 |  |  |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2020-07-29):
[0001728949-20-000031:note_history:42]
| Short-term Debt (in millions) |  |  |  |
|  | March 29,2020 |  | September 29,2019 |
| Commercial paper | $ | 499 |  |  | $ | 499 |  |
| Current portion of long-term debt | 2,000 |  |  | 1,997 |  |
|  | $ | 2,499 |  |  | $ | 2,496 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-07-29):
[0001728949-20-000057:note_history:43]
Note 10. Subsequent Events

- added (2020-07-29):
[0001728949-20-000057:note_history:44]
In July 2020, we entered into a settlement agreement with Huawei to resolve our prior dispute related to our license agreement that expired on December 31, 2019. We also entered into a new long-term, global patent license agreement, including a cross license granting back rights to certain of Huawei’s patents, covering sales beginning January 1, 2020. Amounts due under the settlement agreement (which are incremental to the $1.2 billion previously paid under two interim agreements) are expected to be paid in installments within one year in accordance with an agreed upon payment schedule, with the first payment due in the fourth quarter of fiscal 2020. While we continue to assess the accounting impacts of the agreements, including consideration of the geopolitical environment, we currently expect to record revenues in the fourth quarter of fiscal 2020 resulting from such agreements, including certain amounts related to previously satisfied performance obligations. Such event is considered a nonrecognized subsequent event.
