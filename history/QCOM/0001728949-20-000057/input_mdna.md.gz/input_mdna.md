# QCOM MD&A — 0001728949-20-000057


## mdna

[0001728949-20-000057:mdna:1]
[same as prior period, unchanged from 0001728949-20-000031:mdna:1]

[0001728949-20-000057:mdna:2]
[same as prior period, unchanged from 0001728949-20-000031:mdna:2]

[0001728949-20-000057:mdna:3]
This Quarterly Report (including but not limited to this section entitled Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements regarding our business, investments, financial condition, results of operations and prospects. Forward-looking statements also include but are not limited to statements regarding the rapid, global spread of the recent coronavirus (COVID-19) pandemic, and its potential future impact on the global economy, including the potential for a global recession; economic uncertainty and consumer and business confidence; demand for devices that incorporate our products and intellectual property; our and the global wireless industry’s supply chains, transportation and distribution networks and workforces; 5G network deployments; and our business, revenues, results of operations, cash flows and financial condition; as well as statements regarding our planning assumptions, workforce practices, the duration and severity of the pandemic, and government and other actions to mitigate the spread of, and to treat, COVID-19. Forward-looking statements further include but are not limited to statements regarding industry, market, business, product, technology, commercial, competitive or consumer trends; our businesses, growth potential or strategies, or factors that may impact them; challenges to our licensing business, including by licensees, governments, governmental agencies or regulators, standards bodies or others; challenges to our QCT business; other legal or regulatory matters; competition; new or expanded product areas, adjacent industry segments or applications; costs or expenditures including research and development, selling, general and administrative, restructuring or restructuring-related charges, working capital or information technology systems; our financing, stock repurchase or dividend programs; strategic investments or acquisitions; adoption and application of future accounting guidance; tax law changes; our tax structure or strategies; U.S./China trade or national security policies; or the potential business or financial statement impacts of any of the above, among others. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001728949-20-000057:mdna:4]
Third Quarter Fiscal 2020 Overview and Other Recent Events

[0001728949-20-000057:mdna:5]
Revenues for the third quarter of fiscal 2020 were $4.9 billion, a decrease of 49% compared to the year ago quarter, with net income of $845 million, a decrease of 61% compared to the year ago quarter. Year-over-year comparisons were significantly impacted by $4.7 billion in licensing revenues recorded in the third quarter of fiscal 2019, which were not allocated to our segment results, resulting from the settlement with Apple and its contract manufacturers in April 2019, as well as a $2.5 billion tax expense recorded in the third quarter of fiscal 2019 due to the derecognition of a deferred tax asset as a result of an agreement with the Internal Revenue Service under which we forwent the federal tax basis step-up in certain distributed intellectual property. Highlights and other key developments from the third quarter of fiscal 2020 and other recent events included:

[0001728949-20-000057:mdna:6]
•The rapid, global spread of COVID-19 has negatively impacted consumer demand for devices that incorporate our products and intellectual property, which negatively impacted our business and results of operations in the third quarter of fiscal 2020. The impact of COVID-19 on sales of devices that incorporate our products and intellectual

[0001728949-20-000057:mdna:7]
property varied during the June quarter, with developed regions and China experiencing a less significant impact than emerging regions. The impact of COVID-19 on our ability to fulfill customer orders has continued to be minimal. Workforce changes that we implemented in the second quarter of fiscal 2020 remained in effect throughout the third quarter of fiscal 2020.

[0001728949-20-000057:mdna:8]
•QCT revenues increased by 7% in the third quarter of fiscal 2020 compared to the year ago quarter, primarily due to an increase in demand for 5G products and products used in adjacent industry segments beyond mobile, partially offset by the negative impact of COVID-19.

[0001728949-20-000057:mdna:9]
•QTL revenues decreased by 19% in the third quarter of fiscal 2020 compared to the year ago quarter, primarily due to lower royalty revenues from Huawei due to the expiration of the interim agreement and the negative impact of COVID-19 on licensees’ sales.

[0001728949-20-000057:mdna:10]
•In July 2020, we entered into a settlement agreement with Huawei to resolve our prior disputes related to our license agreement that expired on December 31, 2019. We also entered into a new long-term, global patent license agreement, including a cross license granting back rights to certain of Huawei’s patents, covering sales beginning January 1, 2020. Amounts due under the settlement agreement (which are incremental to the $1.2 billion previously paid under two interim agreements) are expected to be paid in installments within one year in accordance with an agreed upon payment schedule, with the first payment due in the fourth quarter of fiscal 2020.

[0001728949-20-000057:mdna:11]
[same as prior period, unchanged from 0001728949-20-000031:mdna:13]

[0001728949-20-000057:mdna:12]
[same as prior period, unchanged from 0001728949-20-000031:mdna:14]

[0001728949-20-000057:mdna:13]
[same as prior period, unchanged from 0001728949-20-000031:mdna:15]

[0001728949-20-000057:mdna:14]
[same as prior period, unchanged from 0001728949-20-000031:mdna:16]

[0001728949-20-000057:mdna:15]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when the related royalties were recognized, which prior to fiscal 2019 was when licensees reported their sales and beginning in fiscal 2019 when the licensees’ sales occurred. Our historical trends were impacted by our prior dispute with Apple and its contract manufacturers, which was settled in April 2019. Looking forward, we expect QCT revenues to be impacted by seasonal trends related to product launch timing for sales made to Apple under our multi-year chipset agreement. These trends may or may not continue in the future and have been impacted by the decline in consumer demand resulting from COVID-19. Further, the trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees (such as our recent settlement of our prior dispute with Huawei) and/or governmental investigations or proceedings, including the lawsuit filed against us by the FTC.

[0001728949-20-000057:mdna:16]
23

[0001728949-20-000057:mdna:17]
[same as prior period, unchanged from 0001728949-20-000031:mdna:18]

[0001728949-20-000057:mdna:18]
| Revenues (in millions) |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | June 28,2020 |  | June 30,2019 |  | Change |  | June 28,2020 |  | June 30,2019 |  | Change |
| Equipment and services | $ | 3,794 |  |  | $ | 3,531 |  |  | $ | 263 |  |  | $ | 11,376 |  |  | $ | 11,037 |  |  | $ | 339 |  |
| Licensing | 1,099 |  |  | 6,104 |  |  | (5,005) |  |  | 3,809 |  |  | 8,422 |  |  | (4,613) |  |
|  | $ | 4,893 |  |  | $ | 9,635 |  |  | $ | (4,742) |  |  | $ | 15,185 |  |  | $ | 19,459 |  |  | $ | (4,274) |  |

[0001728949-20-000057:mdna:19]
Third quarter 2020 vs. 2019

[0001728949-20-000057:mdna:20]
The decrease in revenues in the third quarter of fiscal 2020 was primarily due to:

[0001728949-20-000057:mdna:21]
- $4.7 billion in licensing revenues recorded in the third quarter of fiscal 2019 resulting from the settlement with Apple and its contract manufacturers in April 2019 (which were not allocated to our segment results)

[0001728949-20-000057:mdna:22]
- $248 million in lower licensing revenues from our QTL segment

[0001728949-20-000057:mdna:23]
+ $272 million in higher equipment and services revenues from our QCT segment

[0001728949-20-000057:mdna:24]
First nine months 2020 vs. 2019

[0001728949-20-000057:mdna:25]
The decrease in revenues in the first nine months of fiscal 2020 was primarily due to:

[0001728949-20-000057:mdna:26]
- $4.7 billion in licensing revenues recorded in the third quarter of fiscal 2019 resulting from the settlement with Apple and its contract manufacturers

[0001728949-20-000057:mdna:27]
- $110 million in lower equipment and services revenues from our QSI segment

[0001728949-20-000057:mdna:28]
+ $467 million in higher equipment and services revenues from our QCT segment

[0001728949-20-000057:mdna:29]
+ $87 million in higher licensing revenues from our QTL segment

[0001728949-20-000057:mdna:30]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | June 28,2020 |  | June 30,2019 |  | Change |  | June 28,2020 |  | June 30,2019 |  | Change |
| Cost of revenues | $ | 2,080 |  |  | $ | 2,114 |  |  | $ | (34) |  |  | $ | 6,489 |  |  | $ | 6,481 |  |  | $ | 8 |  |
| Gross margin | 57 | % |  | 78 | % |  |  |  | 57 | % |  | 67 | % |  |  |

[0001728949-20-000057:mdna:31]
Third quarter 2020 vs. 2019

[0001728949-20-000057:mdna:32]
Gross margin percentage decreased in the third quarter of fiscal 2020 primarily due to:

[0001728949-20-000057:mdna:33]
- lower licensing revenues resulting from the settlement with Apple and its contract manufacturers in the third quarter of fiscal 2019

[0001728949-20-000057:mdna:34]
- decrease in higher margin QTL licensing revenues in proportion to QCT revenues

[0001728949-20-000057:mdna:35]
[same as prior period, unchanged from 0001728949-20-000031:mdna:34]

[0001728949-20-000057:mdna:36]
First nine months 2020 vs. 2019

[0001728949-20-000057:mdna:37]
Gross margin percentage decreased in the first nine months of fiscal 2020 primarily due to:

[0001728949-20-000057:mdna:38]
- lower licensing revenues resulting from the settlement with Apple and its contract manufacturers in the third quarter of fiscal 2019

[0001728949-20-000057:mdna:39]
+ increase in QCT gross margin

[0001728949-20-000057:mdna:40]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | June 28,2020 |  | June 30,2019 |  | Change |  | June 28,2020 |  | June 30,2019 |  | Change |
| Research and development | $ | 1,520 |  |  | $ | 1,380 |  |  | $ | 140 |  |  | $ | 4,393 |  |  | $ | 3,957 |  |  | $ | 436 |  |
| % of revenues | 31 | % |  | 14 | % |  |  |  | 29 | % |  | 20 | % |  |  |

[0001728949-20-000057:mdna:41]
Third quarter 2020 vs. 2019

[0001728949-20-000057:mdna:42]
The increase in research and development expenses in the third quarter of fiscal 2020 was primarily due to:

[0001728949-20-000057:mdna:43]
+ $67 million increase driven by higher costs related to the development of wireless and integrated circuit technologies, including 5G and RFFE technologies, partially offset by a decrease in employee cash incentive program costs

[0001728949-20-000057:mdna:44]
+ $52 million in higher share-based compensation expense

[0001728949-20-000057:mdna:45]
First nine months 2020 vs. 2019

[0001728949-20-000057:mdna:46]
The increase in research and development expenses in the first nine months of fiscal 2020 was primarily due to:

[0001728949-20-000057:mdna:47]
+ $280 million increase driven by higher costs related to the development of wireless and integrated circuit technologies, including 5G and RFFE technologies, partially offset by a decrease in employee cash incentive program costs

[0001728949-20-000057:mdna:48]
+ $167 million in higher share-based compensation expense

[0001728949-20-000057:mdna:49]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | June 28,2020 |  | June 30,2019 |  | Change |  | June 28,2020 |  | June 30,2019 |  | Change |
| Selling, general and administrative | $ | 511 |  |  | $ | 547 |  |  | $ | (36) |  |  | $ | 1,523 |  |  | $ | 1,646 |  |  | $ | (123) |  |
| % of revenues | 10 | % |  | 6 | % |  |  |  | 10 | % |  | 8 | % |  |  |

[0001728949-20-000057:mdna:50]
Third quarter 2020 vs. 2019

[0001728949-20-000057:mdna:51]
The decrease in selling, general and administrative expenses in the third quarter of fiscal 2020 was primarily due to a decrease in employee cash incentive program costs.

[0001728949-20-000057:mdna:52]
First nine months 2020 vs. 2019

[0001728949-20-000057:mdna:53]
The decrease in selling, general and administrative expenses in the first nine months of fiscal 2020 was primarily due to:

[0001728949-20-000057:mdna:54]
- $152 million in lower litigation costs, primarily resulting from the settlement of our prior dispute with Apple and its contract manufacturers in April 2019

[0001728949-20-000057:mdna:55]
+ $32 million in higher share-based compensation expense

[0001728949-20-000057:mdna:56]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | June 28,2020 |  | June 30,2019 |  | Change |  | June 28,2020 |  | June 30,2019 |  | Change |
| Other expense (income) | $ | — |  |  | $ | 277 |  |  | $ | (277) |  |  | $ | (23) |  |  | $ | 408 |  |  | $ | (431) |  |

[0001728949-20-000057:mdna:57]
Third quarter 2019

[0001728949-20-000057:mdna:58]
Other expenses in the third quarter of fiscal 2019 consisted of:

[0001728949-20-000057:mdna:59]
+ $275 million charge related to a fine imposed by the European Commission related to the Icera complaint (2019 EC fine)

[0001728949-20-000057:mdna:60]
+ $2 million in net restructuring and restructuring-related charges related to our Cost Plan that concluded in fiscal 2019

[0001728949-20-000057:mdna:61]
First nine months 2020

[0001728949-20-000057:mdna:62]
Other income in the first nine months of fiscal 2020 consisted of:

[0001728949-20-000057:mdna:63]
[same as prior period, unchanged from 0001728949-20-000031:mdna:62]

[0001728949-20-000057:mdna:64]
First nine months 2019

[0001728949-20-000057:mdna:65]
Other expenses in the first nine months of fiscal 2019 consisted of:

[0001728949-20-000057:mdna:66]
+ $275 million charge related to the 2019 EC fine

[0001728949-20-000057:mdna:67]
+ $207 million in net charges related to our Cost Plan, which included $259 million in restructuring and restructuring-related charges, partially offset by a $52 million net gain from the sale of certain assets related to wireless electric vehicle charging applications and the sale of our mobile health nonreportable segment

[0001728949-20-000057:mdna:68]
- $43 million gain recorded in the second quarter of fiscal 2019 due to the partial recovery of a fine imposed in fiscal 2009 resulting from our appeal of the KFTC decision

[0001728949-20-000057:mdna:69]
- $31 million gain recorded in the second quarter of fiscal 2019 related to a favorable legal settlement

[0001728949-20-000057:mdna:70]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | June 28,2020 |  | June 30,2019 |  | Change |  | June 28,2020 |  | June 30,2019 |  | Change |
| Interest expense | $ | 143 |  |  | $ | 160 |  |  | $ | (17) |  |  | $ | 436 |  |  | $ | 477 |  |  | $ | (41) |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 30 |  |  | $ | 80 |  |  | $ | (50) |  |  | $ | 135 |  |  | $ | 224 |  |  | $ | (89) |  |
| Net gains on marketable securities | 117 |  |  | 315 |  |  | (198) |  |  | 183 |  |  | 296 |  |  | (113) |  |
| Net gains on other investments | 48 |  |  | 6 |  |  | 42 |  |  | 84 |  |  | 47 |  |  | 37 |  |
| Net gains on deferred compensation plan assets | 57 |  |  | 12 |  |  | 45 |  |  | 16 |  |  | 10 |  |  | 6 |  |
| Impairment losses on other investments | (12) |  |  | (42) |  |  | 30 |  |  | (349) |  |  | (111) |  |  | (238) |  |
| Net gains (losses) on derivative instruments | 1 |  |  | — |  |  | 1 |  |  | 2 |  |  | (10) |  |  | 12 |  |
| Equity in net losses of investees | (6) |  |  | (22) |  |  | 16 |  |  | (21) |  |  | (79) |  |  | 58 |  |
| Net losses on foreign currency transactions | (6) |  |  | (5) |  |  | (1) |  |  | (4) |  |  | — |  |  | (4) |  |
|  | $ | 229 |  |  | $ | 344 |  |  | $ | (115) |  |  | $ | 46 |  |  | $ | 377 |  |  | $ | (331) |  |

[0001728949-20-000057:mdna:71]
COVID-19 had an impact on certain companies in which we hold non-marketable investments, resulting in an increase in impairment losses on other investments for the nine months ended June 28, 2020. A significant portion of the impairment losses related to our investment in OneWeb who filed for bankruptcy in the second quarter of fiscal 2020. The decrease in net gains on marketable securities in the three and nine months ended June 28, 2020 was primarily driven by a prior year gain resulting from the initial public offering of one of our non-marketable equity investments in fiscal 2019.

[0001728949-20-000057:mdna:72]
Income Tax Expense (in millions, except percentages)

[0001728949-20-000057:mdna:73]
[same as prior period, unchanged from 0001728949-20-000031:mdna:75]

[0001728949-20-000057:mdna:74]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 28,2020 |  | June 30,2019 |  | June 28,2020 |  | June 30,2019 |
| Expected income tax provision at federal statutory tax rate | $ | 182 |  |  | $ | 1,155 |  |  | $ | 507 |  |  | $ | 1,442 |  |
| Benefit from foreign-derived intangible income (FDII) deduction | (52) |  |  | (296) |  |  | (140) |  |  | (384) |  |
| Benefit related to the research and development tax credit | (24) |  |  | (46) |  |  | (84) |  |  | (92) |  |
| Excess tax benefit associated with share-based awards | (20) |  |  | (21) |  |  | (76) |  |  | (22) |  |
| Benefit from releasing valuation allowance on capital losses | (41) |  |  | — |  |  | (72) |  |  | — |  |
| Derecognition of deferred tax asset on distributed intellectual property | — |  |  | 2,472 |  |  | — |  |  | 2,472 |  |
| Benefit from establishing new U.S. net deferred tax assets | — |  |  | — |  |  | — |  |  | (570) |  |
| Nondeductible charges related to the KFTC and EC investigations | — |  |  | 53 |  |  | — |  |  | 53 |  |
| Other | (22) |  |  | 35 |  |  | 40 |  |  | 88 |  |
| Income tax expense | $ | 23 |  |  | $ | 3,352 |  |  | $ | 175 |  |  | $ | 2,987 |  |
| Effective tax rate | 3 | % |  | 61 | % |  | 7 | % |  | 43 | % |

[0001728949-20-000057:mdna:75]
As of the third quarter of fiscal 2020, we estimated our annual effective income tax rate to be 9% for fiscal 2020, which excluded the effects of the agreements with Huawei signed in July 2020 and the U.S. Treasury Regulations that were issued in July 2020 as described below. Such estimated annual effective tax rate was lower than the U.S. federal statutory rate, primarily due to a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, benefits from our research and development tax credit and benefits from certain releases of our valuation allowance on capital losses. The third quarter of fiscal 2019 included a $2.5 billion tax expense due to the

[0001728949-20-000057:mdna:76]
[same as prior period, unchanged from 0001728949-20-000031:mdna:127]

[0001728949-20-000057:mdna:77]
derecognition of a deferred tax asset as a result of an agreement with the Internal Revenue Service under which we forwent the federal tax basis step-up in certain distributed intellectual property.

[0001728949-20-000057:mdna:78]
In the fourth quarter of fiscal 2020, the United States Treasury Department issued final regulations on deductions for FDII. While we continue to evaluate the impact of these new regulations and the agreements reached with Huawei in July 2020, we currently expect our annual effective tax rate to increase from 9% to 11% for fiscal 2020. The United States Treasury Department is expected to finalize additional provisions of the 2017 Tax Cuts and Jobs Act, including certain foreign tax credit regulations, in the next several months. When finalized, these regulations may adversely affect our provision for income taxes, results of operations and/or cash flows.

[0001728949-20-000057:mdna:79]
[same as prior period, unchanged from 0001728949-20-000031:mdna:80]

[0001728949-20-000057:mdna:80]
The following should be read in conjunction with our financial results for the third quarter and first nine months of fiscal 2020 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0001728949-20-000057:mdna:81]
[same as prior period, unchanged from 0001728949-20-000031:mdna:82]

[0001728949-20-000057:mdna:82]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | June 28,2020 |  | June 30,2019 |  | Change |  | June 28,2020 |  | June 30,2019 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,756 |  |  | $ | 3,484 |  |  | $ | 272 |  |  | $ | 11,252 |  |  | $ | 10,785 |  |  | $ | 467 |  |
| Licensing | 51 |  |  | 83 |  |  | (32) |  |  | 274 |  |  | 243 |  |  | 31 |  |
| Total revenues | $ | 3,807 |  |  | $ | 3,567 |  |  | $ | 240 |  |  | $ | 11,526 |  |  | $ | 11,028 |  |  | $ | 498 |  |
| Earnings before taxes (EBT) | $ | 603 |  |  | $ | 504 |  |  | $ | 99 |  |  | $ | 1,748 |  |  | $ | 1,644 |  |  | $ | 104 |  |
| EBT as a % of revenues | 16 | % |  | 14 | % |  | 2 | % |  | 15 | % |  | 15 | % |  | — | % |

[0001728949-20-000057:mdna:83]
Equipment and services revenues primarily relate to sales of Mobile Station Modem (MSM™), Radio Frequency (RF), Power Management (PM) and wireless connectivity chipsets. MSM integrated circuits include our stand-alone Mobile Data Modems (MDMs) and Snapdragon platforms, which include processors and modems. Approximately 130 million and 156 million MSM integrated circuits were sold in the third quarter of fiscal 2020 and 2019, respectively, and approximately 413 million and 497 million MSM integrated circuits were sold in the first nine months of fiscal 2020 and 2019, respectively. We use the volume of MSM integrated circuit shipments to allow management and investors to, in part, evaluate, assess and benchmark our QCT segment’s performance. MSM integrated circuit shipments do not fully reflect the performance of our QCT segment, which can be impacted by other factors including changes in mix and average selling price of our MSM integrated circuits and revenues generated from products other than MSM integrated circuits, such as RFFE products, among others.

[0001728949-20-000057:mdna:84]
Third quarter 2020 vs. 2019

[0001728949-20-000057:mdna:85]
The increase in QCT equipment and services revenues in the third quarter of fiscal 2020 was primarily due to:

[0001728949-20-000057:mdna:86]
+ $551 million in higher revenues per MSM and accompanying RF, PM and wireless connectivity chipset shipments, primarily driven by a favorable shift in product mix due to an increase in demand for 5G products

[0001728949-20-000057:mdna:87]
+ $67 million in higher RFFE product revenues, primarily driven by an increase in demand for 5G products

[0001728949-20-000057:mdna:88]
- $331 million in lower MSM and accompanying chipset shipments, primarily driven by a decrease in demand due to COVID-19, lower sales to Huawei and lower legacy MDM sales to Apple, partially offset by an increase in demand in adjacent industry segments beyond mobile

[0001728949-20-000057:mdna:89]
QCT EBT as a percentage of revenues increased in the third quarter of fiscal 2020 primarily due to:

[0001728949-20-000057:mdna:90]
+ higher revenues and gross margin, primarily driven by a favorable shift in product mix due to an increase in demand for 5G products

[0001728949-20-000057:mdna:91]
[same as prior period, unchanged from 0001728949-20-000031:mdna:93]

[0001728949-20-000057:mdna:92]
First nine months 2020 vs. 2019

[0001728949-20-000057:mdna:93]
The increase in QCT equipment and services revenues in the first nine months of fiscal 2020 was primarily due to:

[0001728949-20-000057:mdna:94]
+ $972 million in higher revenues per MSM and accompanying RF, PM and wireless connectivity chipset shipments, primarily driven by a favorable shift in product mix due to an increase in demand for 5G products

[0001728949-20-000057:mdna:95]
+ $361 million in higher RFFE product revenues, primarily driven by an increase in demand for 5G products

[0001728949-20-000057:mdna:96]
- $913 million in lower MSM and accompanying chipset shipments, primarily driven by a decrease in demand due to COVID-19, lower legacy MDM sales to Apple and lower sales to Huawei

[0001728949-20-000057:mdna:97]
QCT EBT as a percentage of revenues remained flat in the first nine months of fiscal 2020 primarily due to:

[0001728949-20-000057:mdna:98]
+ higher revenues and gross margin, primarily driven by a favorable shift in product mix due to an increase in demand for 5G products

[0001728949-20-000057:mdna:99]
[same as prior period, unchanged from 0001728949-20-000031:mdna:101]

[0001728949-20-000057:mdna:100]
QCT accounts receivable decreased by 37% in the first nine months of fiscal 2020 from $908 million to $571 million, primarily driven by an increase in the customer incentive amounts recorded as a reduction to accounts receivable. QCT inventories increased by 67% in the first nine months of fiscal 2020 from $1.40 billion to $2.34 billion, primarily driven by the ramp in 5G and certain near-term changes in the timing of customer demand resulting from the impacts of COVID-19.

[0001728949-20-000057:mdna:101]
[same as prior period, unchanged from 0001728949-20-000031:mdna:105]

[0001728949-20-000057:mdna:102]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | June 28,2020 |  | June 30,2019 |  | Change |  | June 28,2020 |  | June 30,2019 |  | Change |
| Licensing revenues | $ | 1,044 |  |  | $ | 1,292 |  |  | $ | (248) |  |  | $ | 3,520 |  |  | $ | 3,433 |  |  | $ | 87 |  |
| EBT | 646 |  |  | 898 |  |  | (252) |  |  | 2,335 |  |  | 2,162 |  |  | 173 |  |
| EBT as a % of revenues | 62 | % |  | 70 | % |  | (8 | %) |  | 66 | % |  | 63 | % |  | 3 | % |

[0001728949-20-000057:mdna:103]
As a result of the settlement with Apple and its contract manufacturers in April 2019, QTL results for the third quarters of fiscal 2020 and fiscal 2019 and first nine months of fiscal 2020 included royalties from Apple and its contract manufactures. Revenues in the first and second quarters of fiscal 2019 did not include royalties from sales of Apple or other products by Apple’s contract manufacturers.

[0001728949-20-000057:mdna:104]
QTL revenues in the third quarter and first nine months of fiscal 2019 included $150 million and $450 million, respectively, of royalties from Huawei under a second interim agreement that concluded in the third quarter of fiscal 2019. This represented a minimum, non-refundable amount for royalties due and does not reflect the full amount of royalties due under the underlying license agreement, which expired on December 31, 2019. We did not record any revenues in the first nine months of fiscal 2020 for royalties due on the sales of Huawei’s consumer wireless products. In July 2020, we entered into a settlement agreement with Huawei to resolve our prior licensing dispute. Further information is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 10. Subsequent Events.”

[0001728949-20-000057:mdna:105]
Third quarter 2020 vs. 2019

[0001728949-20-000057:mdna:106]
The decrease in QTL licensing revenues in the third quarter of fiscal 2020 was primarily due to:

[0001728949-20-000057:mdna:107]
[same as prior period, unchanged from 0001728949-20-000031:mdna:111]

[0001728949-20-000057:mdna:108]
- $94 million decrease in estimated sales of 3G/4G/5G-based products (including multimode products), primarily due to the negative impact of COVID-19 on demand for licensees’ products that incorporate our intellectual property

[0001728949-20-000057:mdna:109]
QTL EBT as a percentage of revenues decreased in the third quarter of fiscal 2020 primarily due to:

[0001728949-20-000057:mdna:110]
[same as prior period, unchanged from 0001728949-20-000031:mdna:117]

[0001728949-20-000057:mdna:111]
[same as prior period, unchanged from 0001728949-20-000031:mdna:116]

[0001728949-20-000057:mdna:112]
First nine months 2020 vs. 2019

[0001728949-20-000057:mdna:113]
The increase in QTL licensing revenues in the first nine months of fiscal 2020 was primarily due to:

[0001728949-20-000057:mdna:114]
+ $744 million increase in estimated sales of 3G/4G/5G-based products (including multimode products), primarily due to the new license agreement with Apple, partially offset by the negative impact of COVID-19 on demand for licensees’ products that incorporate our intellectual property

[0001728949-20-000057:mdna:115]
+ $59 million increase in royalty revenues recognized related to devices sold in prior periods

[0001728949-20-000057:mdna:116]
- $450 million in lower royalty revenues from Huawei due to the expiration of the interim agreement

[0001728949-20-000057:mdna:117]
- $266 million in lower estimated revenues per unit, in part reflecting licensees entering into new 5G multimode license agreements with rights to our cellular standard-essential patents only (compared to previous licenses which also included rights to certain other non-cellular essential patents) and decreases in our per unit royalty

[0001728949-20-000057:mdna:118]
QTL EBT as a percentage of revenues increased in the first nine months of fiscal 2020 primarily due to:

[0001728949-20-000057:mdna:119]
+ lower selling, general and administrative expenses, primarily from lower litigation costs

[0001728949-20-000057:mdna:120]
[same as prior period, unchanged from 0001728949-20-000031:mdna:126]

[0001728949-20-000057:mdna:121]
QTL accounts receivable decreased by 19% in the first nine months of fiscal 2020 from $1.54 billion to $1.25 billion, primarily driven by scheduled payments received from Guangdong OPPO Mobile Telecommunications Corp., Ltd. (Oppo) and BBK Communication Technology Co., Ltd. (vivo) under the previously disclosed agreements reached requiring payment of certain amounts due under the prior license agreements that expired on March 31, 2020 (for which certain of such amounts were previously withheld while good faith negotiations occurred), as well as a decrease in QTL revenues in the third quarter of fiscal 2020. The remaining amounts from Oppo and vivo are due in the near term in accordance with previously agreed upon payment schedules.

[0001728949-20-000057:mdna:122]
[same as prior period, unchanged from 0001728949-20-000031:mdna:128]

[0001728949-20-000057:mdna:123]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | June 28,2020 |  | June 30,2019 |  | Change |  | June 28,2020 |  | June 30,2019 |  | Change |
| Equipment and services revenues | $ | 3 |  |  | $ | 18 |  |  | $ | (15) |  |  | $ | 33 |  |  | $ | 143 |  |  | $ | (110) |  |
| EBT | 153 |  |  | 312 |  |  | (159) |  |  | (58) |  |  | 337 |  |  | (395) |  |

[0001728949-20-000057:mdna:124]
Third quarter 2020 vs. 2019

[0001728949-20-000057:mdna:125]
The decrease in QSI EBT in the third quarter of fiscal 2020 was primarily due to:

[0001728949-20-000057:mdna:126]
-  $159 million decrease in net gains on investments, primarily driven by a gain in the third quarter of fiscal 2019 resulting from the initial public offering of one of our non-marketable equity investments

[0001728949-20-000057:mdna:127]
First nine months 2020 vs. 2019

[0001728949-20-000057:mdna:128]
The decrease in QSI EBT in the first nine months of fiscal 2020 was primarily due to:

[0001728949-20-000057:mdna:129]
-  $260 million increase in impairment losses on other investments, of which a significant portion related to our investment in OneWeb

[0001728949-20-000057:mdna:130]
-  $110 million decrease in revenues associated with certain development contracts with OneWeb

[0001728949-20-000057:mdna:131]
-  $77 million decrease in net gains on investments, primarily driven by a gain in the third quarter of fiscal 2019 resulting from the initial public offering of one of our non-marketable equity investments

[0001728949-20-000057:mdna:132]
+  $37 million decrease in our share of equity method investee losses

[0001728949-20-000057:mdna:133]
[same as prior period, unchanged from 0001728949-20-000031:mdna:143]

[0001728949-20-000057:mdna:134]
In the coming years, we expect new consumer demand for 3G/4G/5G multimode and 5G products and services to ramp around the world as we transition from 3G/4G multimode and 4G products and services. We expect growth in emerging device categories and industries, resulting from the expanding adoption of certain technologies that are already commonly used in smartphones by industry segments outside traditional cellular industries, such as automotive, computing, IoT and networking.

[0001728949-20-000057:mdna:135]
[same as prior period, unchanged from 0001728949-20-000031:mdna:145]

[0001728949-20-000057:mdna:136]
•It is likely that the economic slowdown caused by the COVID-19 pandemic will continue, potentially for an extended duration, and there may be a global recession. We expect the pandemic will continue to have a negative impact on QTL and QCT revenues in the near term based on a reduction in consumer demand for smartphones and other products. Our current planning assumption is that sales of devices that incorporate our products and intellectual property will gradually recover in the September quarter, which reflects regional trends seen during the June quarter. We have not experienced, and we currently do not anticipate a material adverse impact on our ability,

[0001728949-20-000057:mdna:137]
29

[0001728949-20-000057:mdna:138]
or our suppliers’ ability, to manufacture and test our products or on our ability to provide our products to our customers. Workforce changes that we implemented in the second quarter of fiscal 2020 are expected to remain in effect in the near term. The degree to which the COVID-19 pandemic impacts our business, financial condition and results of operations will depend on future developments, which are highly uncertain. See “Risk Factors” in this Quarterly Report, specifically the Risk Factor entitled “The recent coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and we expect its impact will continue, at least in the near term.”

[0001728949-20-000057:mdna:139]
•In July 2020, we entered into a settlement agreement with Huawei to resolve our prior dispute related to our license agreement that expired on December 31, 2019. We also entered into a new long-term, global patent license agreement, including a cross license granting back rights to certain of Huawei’s patents, covering sales beginning January 1, 2020. Amounts due under the settlement agreement (which are incremental to the $1.2 billion previously paid under two interim agreements) are expected to be paid in installments within one year in accordance with an agreed upon payment schedule, with the first payment due in the fourth quarter of fiscal 2020. While we continue to assess the accounting impacts of the agreements, including consideration of the geopolitical environment, we currently expect to record revenues of approximately $1.8 billion in the fourth quarter of fiscal 2020 related to the amounts due from Huawei under the settlement agreement and estimated amounts due for the March 2020 and June 2020 quarters under the new global patent license agreement. In addition, we currently expect to begin recording royalty revenues in the fourth quarter of fiscal 2020 for sales made by Huawei in the September 2020 quarter.

[0001728949-20-000057:mdna:140]
•In May 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief. We disagree with the court’s conclusions, interpretation of the facts and application of the law. Accordingly, we filed a motion to stay certain of the remedies with, and appealed the decision to, the Ninth Circuit Court of Appeals (Ninth Circuit). In July 2019, the Ninth Circuit granted our appeal. In August 2019, the Ninth Circuit granted our partial motion to stay in its entirety. In February 2020, the Ninth Circuit heard oral arguments. Regulatory authorities in certain other jurisdictions are investigating and/or have investigated our business practices and instituted proceedings against us, and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. These activities have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in significant legal costs until the respective matters are resolved. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report, including the Risk Factors entitled “Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations” and “Efforts by some OEMs or their customers to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.”

[0001728949-20-000057:mdna:141]
•We have not been the sole supplier of modems for iPhone products beginning with products that launched in September 2016, and Apple is not utilizing our modems for iPhone products that launched in September 2019. We expect QCT revenues to be favorably impacted in the near-term as we anticipate a ramp in volume of MSM shipments under the multi-year chipset agreement to support future iPhone product launches.

[0001728949-20-000057:mdna:142]
[same as prior period, unchanged from 0001728949-20-000031:mdna:151]

[0001728949-20-000057:mdna:143]
◦Increased concentration of device share among a few companies, particularly within the premium tier, resulting in significant supply chain leverage for those companies, and exacerbating the negative impact to our business and financial results to the extent those companies do not utilize our chipsets. For example,

[0001728949-20-000057:mdna:144]
[same as prior period, unchanged from 0001728949-20-000031:mdna:180]

[0001728949-20-000057:mdna:145]
Huawei has taken, and may continue to take, share in China from other Chinese OEMs, negatively impacting QCT as we sell a limited number of chipsets to Huawei as compared to many of those other OEMs;

[0001728949-20-000057:mdna:146]
[same as prior period, unchanged from 0001728949-20-000031:mdna:153]

[0001728949-20-000057:mdna:147]
[same as prior period, unchanged from 0001728949-20-000031:mdna:154]

[0001728949-20-000057:mdna:148]
[same as prior period, unchanged from 0001728949-20-000031:mdna:155]

[0001728949-20-000057:mdna:149]
[same as prior period, unchanged from 0001728949-20-000031:mdna:157]

[0001728949-20-000057:mdna:150]
[same as prior period, unchanged from 0001728949-20-000031:mdna:158]

[0001728949-20-000057:mdna:151]
•Current U.S./China trade relations and/or national security protection policies may negatively impact our business, growth prospects and results of operations. See “Risk Factors” in this Quarterly Report, including the Risk Factor entitled “Global, regional or local economic conditions, or political actions including trade and/or national security protection policies that impact the mobile communications industry or the other industries in which we operate could negatively affect the demand for our products and services and our customers’ or licensees’ products and services, which may negatively affect our business, revenues, results of operations, cash flows and financial position.”

[0001728949-20-000057:mdna:152]
•Commercial 5G network deployments and device launches will continue through calendar 2020 and beyond. We currently anticipate no significant delays in the timing of 5G network deployments and device launches in key regions resulting from the impacts of COVID-19; however, the timing of such deployments and device launches have been and may in the future be delayed and consumer demand for devices that are launched has been and may continue to be negatively impacted by COVID-19. The degree to which any such delays and lower demand impacts our future business, financial condition and results of operations will depend on future developments, which are uncertain. We believe that 5G technologies will empower a new era of smartphones and connected devices. We also believe that 5G will drive transformation across industries beyond traditional cellular communications that will create new business models and new services. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing of 5G technologies, and to be a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long term.

[0001728949-20-000057:mdna:153]
[same as prior period, unchanged from 0001728949-20-000031:mdna:161]

[0001728949-20-000057:mdna:154]
[same as prior period, unchanged from 0001728949-20-000031:mdna:162]

[0001728949-20-000057:mdna:155]
[same as prior period, unchanged from 0001728949-20-000031:mdna:163]

[0001728949-20-000057:mdna:156]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following table presents selected financial information related to our liquidity at June 28, 2020 and September 29, 2019 and for the first nine months of fiscal 2020 and 2019 (in millions):

[0001728949-20-000057:mdna:157]
[same as prior period, unchanged from 0001728949-20-000031:mdna:194]

[0001728949-20-000057:mdna:158]
|  | June 28,2020 |  | September 29,2019 |  | Change |  |  |
| Cash, cash equivalents and marketable securities | $ | 10,634 |  |  | $ | 12,296 |  |  | $ | (1,662) |  |  |  |
| Accounts receivable, net | 1,847 |  |  | 2,471 |  |  | (624) |  |  |  |
| Inventories | 2,343 |  |  | 1,400 |  |  | 943 |  |  |  |
| Short-term debt | 500 |  |  | 2,496 |  |  | (1,996) |  |  |  |
| Long-term debt | 15,425 |  |  | 13,437 |  |  | 1,988 |  |  |  |
| Noncurrent income taxes payable | 1,872 |  |  | 2,088 |  |  | (216) |  |  |  |

[0001728949-20-000057:mdna:159]
|  | Nine Months Ended |  |  |  |  |  |  |
|  | June 28,2020 |  | June 30,2019 |  | Change |  |  |
| Net cash provided by operating activities | $ | 4,073 |  |  | $ | 6,059 |  |  | $ | (1,986) |  |  |  |
| Net cash used by investing activities | (4,925) |  |  | (469) |  |  | (4,456) |  |  |  |
| Net cash used by financing activities | (4,871) |  |  | (3,446) |  |  | (1,425) |  |  |  |

[0001728949-20-000057:mdna:160]
The net decrease in cash, cash equivalents and marketable securities was primarily due to $2.5 billion in payments to repurchase shares of our common stock, $2.1 billion in cash dividends paid, $1.1 billion in capital expenditures and $326 million in payments of tax withholdings related to the vesting of share-based awards, partially offset by net cash provided by operating activities and $176 million in proceeds from the issuance of common stock.

[0001728949-20-000057:mdna:161]
The decrease in accounts receivable was primarily due to a decrease in QCT accounts receivable resulting from an increase in customer incentive amounts recorded as a reduction to QCT accounts receivable and a decrease in QTL accounts receivable driven by certain payments received from Oppo and vivo, as well as a decrease in QTL revenues in the third quarter of fiscal 2020. The increase in inventories was primarily driven by the ramp in 5G and certain near-term changes in the timing of customer demand resulting from the impacts of COVID-19.

[0001728949-20-000057:mdna:162]
As a result of the agreements entered into with Huawei in July 2020, we expect our liquidity to be positively impacted by the settlement payments due and royalties to be paid by Huawei for sales made under the new global patent license agreement. Amounts due under the settlement agreement are expected to be paid in installments within one year in accordance with an agreed upon payment schedule, with the first payment due in the fourth quarter of fiscal 2020.

[0001728949-20-000057:mdna:163]
Debt. In the third quarter of fiscal 2020, we issued an aggregate principal amount of $2.0 billion of unsecured fixed-rate notes with varying maturities (May 2020 Notes). The net proceeds were used to repay the $250 million floating-rate and $1.75 billion fixed-rate notes that matured on May 20, 2020, which were classified as short-term debt at September 29, 2019. At June 28, 2020, we had $15.5 billion of principal floating- and fixed-rate notes outstanding. The remaining debt has maturity dates in 2022 through 2050.

[0001728949-20-000057:mdna:164]
We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At June 28, 2020, we had $500 million of commercial paper outstanding.

[0001728949-20-000057:mdna:165]
Our Amended and Restated Revolving Credit Facility (Revolving Credit Facility) provides for unsecured revolving facility loans, swing line loans and letters of credit in the aggregate amount of up to $4.5 billion and expires on November 8, 2021. At June 28, 2020, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-20-000057:mdna:166]
We may issue new debt in the near future. COVID-19 has led to disruption and volatility in the global capital markets, which may adversely impact the cost of and access to capital. The amount and timing of additional borrowings, if any, will depend on a number of factors, including but not limited to maturities of our existing debt, acquisitions and strategic investments, favorable and/or acceptable interest rates and changes in corporate income tax law. Additional information regarding our outstanding debt at June 28, 2020 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt”.

[0001728949-20-000057:mdna:167]
Income Taxes. At June 28, 2020, we estimated remaining future payments of $2.0 billion for the one-time U.S. repatriation tax accrued in fiscal 2018 (Toll Charge), after application of certain tax credits, which is payable in installments over the next six years. At June 28, 2020, other current liabilities included $174 million, reflecting the next installment due in January 2021. Additional information regarding our income taxes is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes.”

[0001728949-20-000057:mdna:168]
Capital Return Program. In fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. In the first nine months of fiscal 2020, we repurchased and retired 30.9 million shares of our common stock for $2.5 billion, before commissions. At June 28, 2020, $4.6 billion remained authorized for repurchase under the stock repurchase program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time. In the third quarter of fiscal 2020, to maintain our financial liquidity position and flexibility, we suspended our stock repurchases, at least for the near-term, in light of COVID-19. We have the ability to reinstate repurchases when and if we determine it to be in the best interest of stockholders.

[0001728949-20-000057:mdna:169]
In the first nine months of fiscal 2020, we paid cash dividends totaling $2.1 billion, or $1.89 per share. On July 15, 2020, we announced a cash dividend of $0.65 per share on our common stock, payable on September 24, 2020 to stockholders of record as of the close of business on September 3, 2020. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability, which may be impacted by COVID-19, and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-20-000057:mdna:170]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2019 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” We expect our capital expenditures to increase in the near term to support the increase in our manufacturing capacity needs for our internal fabrication facilities that manufacture RFFE modules and RF filter products, primarily resulting from the ramp in 5G devices. At June 28, 2020, other than changes disclosed in the “Notes to Condensed Consolidated Financial Statements” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no material changes to our expected working and other capital requirements described in our 2019 Annual Report on Form 10-K. At June 28, 2020, $1.4 billion was accrued related to two fines imposed by the EC (based on the exchange rate at June 28, 2020, including related foreign currency gains and accrued interest). We have provided financial guarantees in lieu of cash payment to satisfy the obligations while we appeal the EC’s decisions.

[0001728949-20-000057:mdna:171]
Further, regulatory authorities in certain jurisdictions are investigating and/or have investigated our business practices and instituted proceedings against us, including the lawsuit filed against us by the FTC in which a ruling was issued in favor of the FTC in May 2019, and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees, have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0001728949-20-000057:mdna:172]
Although we expect future estimated operating cash flows to be adversely affected by the impact of COVID-19, most significantly through reduced QTL royalty revenues and QCT equipment revenues, we believe, based on our current business plan and the facts and factors known by us, our cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months. See “Risk Factors” in this Quarterly Report, including the Risk Factor entitled “The recent coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and we expect its impact will continue, at least in the near term.”

[0001728949-20-000057:mdna:173]
[same as prior period, unchanged from 0001728949-20-000031:mdna:182]

[0001728949-20-000057:mdna:174]
[same as prior period, unchanged from 0001728949-20-000031:mdna:183]

[0001728949-20-000057:mdna:175]
Additional information regarding our financial commitments at June 28, 2020 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes,” “Note 5. Debt” and “Note 6. Commitments and Contingencies.”

[0001728949-20-000057:mdna:176]
[same as prior period, unchanged from 0001728949-20-000031:mdna:185]

[0001728949-20-000057:mdna:177]
[same as prior period, unchanged from 0001728949-20-000031:mdna:186]

[0001728949-20-000057:mdna:178]
[same as prior period, unchanged from 0001728949-20-000031:mdna:217]

[0001728949-20-000057:mdna:179]
[same as prior period, unchanged from 0001728949-20-000031:mdna:187]

[0001728949-20-000057:mdna:180]
You should consider each of the following factors in evaluating our business and our prospects. The risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also negatively impact our business, results of operations, financial condition and cash flows, and require significant management time and attention. In that case, the trading price of our common stock could decline. In addition to the risks and uncertainties set forth in the Risk Factor below entitled “The recent coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and we expect its impact will continue, at least in the near term,” many of the risks and uncertainties set forth in the other Risk Factors below are exacerbated by the COVID-19 pandemic, government and business responses thereto and any further resulting decline in the global business and economic environment, as well as the extent and/or speed of global economic recovery. You should also consider the other information set forth in this Quarterly Report in evaluating our business and our prospects, including but not limited to our financial statements and the related notes, and “Part I, Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” References to “and” and “or” should be read to include the other as well as “and/or,” as appropriate.

[0001728949-20-000057:mdna:181]
[same as prior period, unchanged from 0001728949-20-000031:mdna:189]

[0001728949-20-000057:mdna:182]
The recent coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and we expect its impact will continue, at least in the near term.

[0001728949-20-000057:mdna:183]
[same as prior period, unchanged from 0001728949-20-000031:mdna:191]

[0001728949-20-000057:mdna:184]
We expect that demand for our products and demand for the products of our customers or licensees will continue to be negatively impacted in the near term, and to the extent that economic uncertainty, business and consumer confidence, demand for our products and demand for the products of our customers or licensees does not improve, our business and results of operations will continue to be, and may be further, negatively impacted.

[0001728949-20-000057:mdna:185]
The COVID-19 pandemic, and government policies and business measures in response thereto, such as those described above, have also negatively impacted the global wireless supply chain and workforce, including the manufacturing facilities and workforces of our suppliers, customers and licensees. In particular, travel bans and restrictions, quarantines, shelter-in-place and social distancing orders, declarations of states of emergency and shutdowns have resulted in longer product cycle times, transportation, shipment and delivery delays, additional costs and reductions in output across the supply chain. However, to date, we have not seen a significant impact on our manufacturing facilities, the ability of our suppliers to deliver on their commitments to us, or our ability to ship our products to our customers, and we expect this to continue to be true, at least in the near term.

[0001728949-20-000057:mdna:186]
[same as prior period, unchanged from 0001728949-20-000031:mdna:196]

[0001728949-20-000057:mdna:187]
Further, the spread of COVID-19 has caused us to modify our workforce practices, and we may take further actions that we determine are in the best interests of our employees or as mandated by governments in the states and countries we operate. Since January 2020, we have complied with government restrictions in China which limited our employees’ ability to work in our offices in China, although such restrictions have since lessened. In March 2020, we announced a global mandatory work from home policy for all of our other employees who are able to perform their jobs remotely, which remains in place. Prior to this announcement, we took various other measures to mitigate the risk to our employees and operations globally, including certain employee travel and visitor restrictions, and cancellation of or limitations on physical participation in meetings, events and conferences, among others. California, where our corporate headquarters is located, and other states and countries where we have employees have implemented restrictions to varying degrees that limit people’s ability to move freely. While this has not been the case to date, our business and results of operations could be negatively affected if a significant number of our employees, or employees who perform critical functions, such as certain engineering employees, employees necessary to maintain the continuity of our business operations, or employees that are critical to complete and support our key accounting close processes, financial reporting systems, internal control over financial reporting and disclosure controls and procedures, become ill and/or are quarantined as the result of exposure to COVID-19, or if government policies restrict the ability of those employees to perform their critical functions. Any actions we take with respect to our workforce may not be sufficient to mitigate the risks posed by COVID-19, and our ability to perform critical functions could be harmed.

[0001728949-20-000057:mdna:188]
We expect the foregoing demand, supply and workforce issues to continue, at least in the near term. Our business, financial condition and results of operations could also be impacted by delayed, reduced or cancelled customer orders; the inability of our customers or licensees to purchase or pay for our products or technologies; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our customers or licensees; or failures by other counterparties.

[0001728949-20-000057:mdna:189]
Further, trade and/or national security protection policies may be adjusted as a result of the COVID-19 pandemic, such as actions by governments that limit, restrict or prevent the movement of certain goods into a country and/or region, and current U.S./China trade relations may be further exacerbated by the pandemic. Additionally, state or federal governments may in the future increase corporate tax rates, increase employer payroll tax obligations and/or otherwise change tax laws to pay for stimulus and other actions taken or that may be taken as a result of COVID-19.

[0001728949-20-000057:mdna:190]
We monitor goodwill and other long-lived assets for events or changes in circumstances in interim periods that could indicate such assets may be impaired. At September 29, 2019, the estimated fair values of our QCT and QTL reporting units were substantially in excess of their respective carrying values. Based on facts and factors currently known by us, we did not record any impairment of goodwill or other long-lived assets during the first nine months of fiscal 2020 as a result of the impact of the COVID-19 pandemic on our business. Although we believe that our estimates and the assumptions supporting our impairment assessments are reasonable, future events or changes in circumstances could cause us to conclude that impairment indicators exist, and that goodwill or other long-lived assets are impaired.

[0001728949-20-000057:mdna:191]
In addition, in the first nine months of fiscal 2020, we recorded impairment losses on certain of our equity method and non-marketable equity and debt investments in part resulting from the impact of COVID-19, and we may in the future record additional impairment losses in part or entirely resulting from COVID-19. Any resulting impairment losses in the future could have an adverse impact on our financial condition and results of operations. Further, while we have experienced minimal impact to date, our customers or licensees may experience a negative impact to their cash flow, which may impact our ability to recognize revenues and/or result in the recognition of an allowance for doubtful accounts related to our accounts receivables, both of which would adversely impact our results of operations.

[0001728949-20-000057:mdna:192]
[same as prior period, unchanged from 0001728949-20-000031:mdna:203]

[0001728949-20-000057:mdna:193]
[same as prior period, unchanged from 0001728949-20-000031:mdna:204]

[0001728949-20-000057:mdna:194]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on operators of wireless networks and our customers and licensees to adopt and implement the latest generation of these technologies for use in their networks, devices and services. We also depend on our customers and licensees to develop devices and services based on these technologies with value-added features

[0001728949-20-000057:mdna:195]
35

[0001728949-20-000057:mdna:196]
to drive consumer demand for new 3G/4G and 3G/4G/5G multimode devices, as well as 3G, 4G and 5G single-mode devices, and to establish the selling prices for such devices. Further, the timing of our shipment of products and completion of services is dependent on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries and applications beyond traditional cellular communications, such as automotive, computing, IoT (including the connected home, smart cities, wearables, voice and music and robotics) and networking, among others.

[0001728949-20-000057:mdna:197]
[same as prior period, unchanged from 0001728949-20-000031:mdna:206]

[0001728949-20-000057:mdna:198]
[same as prior period, unchanged from 0001728949-20-000031:mdna:207]

[0001728949-20-000057:mdna:199]
[same as prior period, unchanged from 0001728949-20-000031:mdna:208]

[0001728949-20-000057:mdna:200]
[same as prior period, unchanged from 0001728949-20-000031:mdna:209]

[0001728949-20-000057:mdna:201]
[same as prior period, unchanged from 0001728949-20-000031:mdna:210]

[0001728949-20-000057:mdna:202]
[same as prior period, unchanged from 0001728949-20-000031:mdna:211]

[0001728949-20-000057:mdna:203]
[same as prior period, unchanged from 0001728949-20-000031:mdna:212]

[0001728949-20-000057:mdna:204]
[same as prior period, unchanged from 0001728949-20-000031:mdna:213]

[0001728949-20-000057:mdna:205]
[same as prior period, unchanged from 0001728949-20-000031:mdna:214]

[0001728949-20-000057:mdna:206]
[same as prior period, unchanged from 0001728949-20-000031:mdna:215]

[0001728949-20-000057:mdna:207]
[same as prior period, unchanged from 0001728949-20-000031:mdna:216]

[0001728949-20-000057:mdna:208]
[same as prior period, unchanged from 0001728949-20-000031:mdna:218]

[0001728949-20-000057:mdna:209]
Our products, services and technologies face significant competition. We expect competition to increase as our current competitors expand their product offerings, improve their products or reduce the prices of their products as part of a strategy to maintain existing business and customers or attract new business and customers, as new opportunities develop, and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: OEM concentrations; vertical integration; growth in demand, consumption and competition in certain geographic regions; government intervention or support of national industries or competitors; evolving industry standards and business models; evolving methods of transmission of voice and data communications; increasing data traffic and densification of wireless networks; convergence and aggregation of connectivity technologies (including Wi-Fi and LTE) in both devices and access points; consolidation of wireless technologies and infrastructure at the network edge; networking and connectivity trends (including cloud services); use of licensed, shared and unlicensed spectrum; the evolving nature of computing (including demand for always on, always connected capabilities); the speed of technological change (including the transition to smaller geometry process technologies); value-added features that drive selling prices and consumer demand for new 3G/4G and 3G/4G/5G multimode devices, as well as 3G, 4G and 5G single-mode devices; turnkey, integrated products that

[0001728949-20-000057:mdna:210]
incorporate hardware, software, user interface, applications and reference designs; scalability; and the ability of the system technology to meet customers’ immediate and future network requirements.

[0001728949-20-000057:mdna:211]
[same as prior period, unchanged from 0001728949-20-000031:mdna:220]

[0001728949-20-000057:mdna:212]
[same as prior period, unchanged from 0001728949-20-000031:mdna:221]

[0001728949-20-000057:mdna:213]
[same as prior period, unchanged from 0001728949-20-000031:mdna:222]

[0001728949-20-000057:mdna:214]
[same as prior period, unchanged from 0001728949-20-000031:mdna:223]

[0001728949-20-000057:mdna:215]
[same as prior period, unchanged from 0001728949-20-000031:mdna:224]

[0001728949-20-000057:mdna:216]
[same as prior period, unchanged from 0001728949-20-000031:mdna:225]

[0001728949-20-000057:mdna:217]
[same as prior period, unchanged from 0001728949-20-000031:mdna:226]

[0001728949-20-000057:mdna:218]
[same as prior period, unchanged from 0001728949-20-000031:mdna:227]

[0001728949-20-000057:mdna:219]
[same as prior period, unchanged from 0001728949-20-000031:mdna:228]

[0001728949-20-000057:mdna:220]
[same as prior period, unchanged from 0001728949-20-000031:mdna:229]

[0001728949-20-000057:mdna:221]
[same as prior period, unchanged from 0001728949-20-000031:mdna:230]

[0001728949-20-000057:mdna:222]
[same as prior period, unchanged from 0001728949-20-000031:mdna:231]

[0001728949-20-000057:mdna:223]
[same as prior period, unchanged from 0001728949-20-000031:mdna:232]

[0001728949-20-000057:mdna:224]
[same as prior period, unchanged from 0001728949-20-000031:mdna:233]

[0001728949-20-000057:mdna:225]
[same as prior period, unchanged from 0001728949-20-000031:mdna:234]

[0001728949-20-000057:mdna:226]
We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application, industry segment or standard product, including those that produce products for RFFE, automotive, computing, IoT and networking applications. Most of these competitors compete with us with respect to some, but not all, of our businesses. Companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom, Cirrus Logic, Cypress Semiconductor, HiSilicon, Intel, Marvell, Maxim, MediaTek, Microchip Technology, Murata, Nordic Semiconductor, Nvidia, NXP Semiconductors, Qorvo, Realtek Semiconductor, Renesas, Samsung, Sequans Communications, Skyworks and Spreadtrum Communications (which is controlled by Tsinghua Unigroup). Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to use our competitors’ integrated circuit products, to utilize their own internally-developed integrated circuit products or sell such products to others, or to choose alternative technologies; lower

[0001728949-20-000057:mdna:227]
[same as prior period, unchanged from 0001728949-20-000031:mdna:260]

[0001728949-20-000057:mdna:228]
cost structures or a willingness and ability to accept lower prices or lower or negative margins for their products, particularly in China; foreign government support of other technologies, competitors or OEMs that sell devices that do not contain our chipsets; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and OEMs in certain geographic regions (such as China); more experience in adjacent industry segments outside traditional cellular industries (such as automotive, computing, IoT and networking); and a more established presence in certain regions.

[0001728949-20-000057:mdna:229]
In particular, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past utilized, and currently utilize, in certain of their devices and may in the future choose to utilize in certain (or all) of their devices, rather than our products (and they may sell their integrated circuit products to third parties, discretely or together with certain of their other products, in competition with us).

[0001728949-20-000057:mdna:230]
Also, Apple, which has historically been one of our largest customers, has utilized products of one of our competitors in many of its devices rather than our products, and is solely utilizing one of our competitors’ products in its most recent smartphone launches. In April 2019, we entered into a new multi-year chipset supply agreement with Apple. We began shipping chipsets under this agreement in the third quarter of fiscal 2020. However, Apple may choose to use our competitors’ products or its own modem products in one or more of its future devices.

[0001728949-20-000057:mdna:231]
Similarly, certain of our Chinese customers have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products, or our competitors’ integrated circuit products, in their devices rather than our integrated circuit products, including due to pressure from or policies of the Chinese government, concerns over losing access to our integrated circuit products as a result of U.S./China trade tensions, or otherwise. Further, political actions, including trade and/or national security protection policies, or other actions by governments, particularly the U.S. and Chinese governments, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our customers, limit or prevent certain of our customers from transacting business with us, or make it more expensive to do so. This could advantage our competitors by enabling them with increased sales, economies of scale, operating income and/or cash flows and/or enable critical technology transfer, allowing them to increase their investments in technology development, research and development and commercialization of products.

[0001728949-20-000057:mdna:232]
[same as prior period, unchanged from 0001728949-20-000031:mdna:237]

[0001728949-20-000057:mdna:233]
[same as prior period, unchanged from 0001728949-20-000031:mdna:238]

[0001728949-20-000057:mdna:234]
[same as prior period, unchanged from 0001728949-20-000031:mdna:239]

[0001728949-20-000057:mdna:235]
Our QCT segment derives a significant portion of its revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. Chinese OEMs continue to grow their device share in China and are increasing their device share in regions outside of China, and we derive a significant and increasing portion of our revenues from a small number of these OEMs.

[0001728949-20-000057:mdna:236]
In addition, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past utilized, and currently utilize, in certain of their devices and may in the future choose to utilize in certain (or all) of their devices, rather than our products (and they may sell their integrated circuit products to third parties, discretely or together with certain of their other products, in competition with us).

[0001728949-20-000057:mdna:237]
Also, Apple, which has historically been one of our largest customers, has utilized products of one of our competitors in many of its devices rather than our products, and is solely utilizing one of our competitor’s products in its most recent smartphone launches. In April 2019, we entered into a new multi-year chipset supply agreement with Apple. We began shipping chipsets under this agreement in the third quarter of fiscal 2020. However, Apple may choose to use our competitors’ products or its own modem products in one or more of its future devices.

[0001728949-20-000057:mdna:238]
Similarly, certain of our Chinese OEM customers have developed and others may in the future develop their own integrated circuit products and use such integrated circuit products, or our competitors’ integrated circuit products, in their devices rather than our integrated circuit products, including due to pressure from or policies of the U.S. and/or Chinese governments, the OEMs’ concerns over losing access to our integrated circuit products as a result of U.S./China tensions, or otherwise. Further, political actions, including trade and/or national security protection policies, or other actions by governments, particularly the U.S. and Chinese governments, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our customers, or limit or prevent certain of our customers from transacting business with us, or make it more expensive to do so. See also the Risk Factor entitled “Global, regional or local economic conditions, or political actions including trade and/or national security protection policies, that impact the mobile communications industry or the other industries in which we operate could negatively affect the demand for our products and services and our customers’ or licensees’ products and services, which may negatively affect our business, revenues, results of operations, cash flows and financial position.”

[0001728949-20-000057:mdna:239]
[same as prior period, unchanged from 0001728949-20-000031:mdna:244]

[0001728949-20-000057:mdna:240]
[same as prior period, unchanged from 0001728949-20-000031:mdna:245]

[0001728949-20-000057:mdna:241]
[same as prior period, unchanged from 0001728949-20-000031:mdna:246]

[0001728949-20-000057:mdna:242]
[same as prior period, unchanged from 0001728949-20-000031:mdna:247]

[0001728949-20-000057:mdna:243]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products or intellectual property, and rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001728949-20-000057:mdna:244]
Although we have more than 300 licensees, our QTL segment derives a significant portion of its revenues from a limited number of licensees, which increasingly includes a small number of Chinese OEMs. In the event that one or more of our significant licensees fail to meet their reporting and payment obligations, or we are unable to renew or modify one or more of such license agreements under similar terms, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We do not have control

[0001728949-20-000057:mdna:245]
over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in sales of our licensees’ products, or reductions in the average selling prices of wireless devices sold by our licensees without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues. Such adverse impact may be mitigated by our per unit royalty caps that apply to certain categories of our licensees’ complete wireless devices, namely smartphones, tablets, laptops and smartwatches.

[0001728949-20-000057:mdna:246]
[same as prior period, unchanged from 0001728949-20-000031:mdna:252]

[0001728949-20-000057:mdna:247]
[same as prior period, unchanged from 0001728949-20-000031:mdna:253]

[0001728949-20-000057:mdna:248]
[same as prior period, unchanged from 0001728949-20-000031:mdna:254]

[0001728949-20-000057:mdna:249]
[same as prior period, unchanged from 0001728949-20-000031:mdna:255]

[0001728949-20-000057:mdna:250]
[same as prior period, unchanged from 0001728949-20-000031:mdna:256]

[0001728949-20-000057:mdna:251]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, taking a position that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) various attempts by licensees to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated.

[0001728949-20-000057:mdna:252]
[same as prior period, unchanged from 0001728949-20-000031:mdna:258]

[0001728949-20-000057:mdna:253]
40

[0001728949-20-000057:mdna:254]
We have been in the past and are currently subject to various litigation and governmental investigations and proceedings, including the lawsuit filed against us by the FTC. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See also the Risk Factors below entitled “Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings” and “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations.”

[0001728949-20-000057:mdna:255]
[same as prior period, unchanged from 0001728949-20-000031:mdna:262]

[0001728949-20-000057:mdna:256]
Further, some companies or entities have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions should not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by severely limiting the base upon which the royalty rate may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies. Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001728949-20-000057:mdna:257]
[same as prior period, unchanged from 0001728949-20-000031:mdna:264]

[0001728949-20-000057:mdna:258]
[same as prior period, unchanged from 0001728949-20-000031:mdna:265]

[0001728949-20-000057:mdna:259]
We have been in the past and are currently subject to various governmental investigations and proceedings, particularly with respect to our licensing business, including the lawsuit filed against us by the FTC. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations or findings in those matters include, among others, that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers, that our royalty rates are too high, that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions), that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets, that we have entered into exclusive agreements with chipset customers that foreclose competition, and that we violate antitrust laws, engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-20-000057:mdna:260]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more

[0001728949-20-000057:mdna:261]
of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any licensing or royalty revenues under such agreements. The renegotiation of license agreements could lead to arbitration or litigation to resolve the licensing terms, which could be less favorable to us than existing terms, and each of which could take months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. Further, if our appeal in the FTC lawsuit is unsuccessful, it could have a material adverse effect on our business. The occurrence of any of the above could have a material adverse effect on our business, results of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies such as 5G. Further, depending on the breadth and severity of the circumstances above, we may have to reduce, suspend or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region.

[0001728949-20-000057:mdna:262]
[same as prior period, unchanged from 0001728949-20-000031:mdna:269]

[0001728949-20-000057:mdna:263]
Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations.

[0001728949-20-000057:mdna:264]
As described in the Risk Factor above entitled “Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings,” we have been in the past and are currently subject to various governmental investigations and proceedings, as well as private legal proceedings, challenging our patent licensing and chipset sales practices, including the lawsuit filed against us by the FTC. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We believe that one intent of certain of these investigations and legal proceedings is to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-20-000057:mdna:265]
[same as prior period, unchanged from 0001728949-20-000031:mdna:272]

[0001728949-20-000057:mdna:266]
If we were required to grant patent licenses to chipset manufacturers (which could lead to implementing a more complex, multi-level licensing structure in which we license certain portions of our patent portfolio to chipset manufacturers and other portions to OEMs), we would incur additional transaction costs, which may be significant, and we could incur delays in

[0001728949-20-000057:mdna:267]
[same as prior period, unchanged from 0001728949-20-000031:mdna:299]

[0001728949-20-000057:mdna:268]
recognizing revenues until license negotiations were completed. In addition, our licensing revenues and earnings would be negatively impacted if we were not able to obtain, in the aggregate, equivalent revenues under such a multi-level licensing structure.

[0001728949-20-000057:mdna:269]
[same as prior period, unchanged from 0001728949-20-000031:mdna:276]

[0001728949-20-000057:mdna:270]
[same as prior period, unchanged from 0001728949-20-000031:mdna:277]

[0001728949-20-000057:mdna:271]
[same as prior period, unchanged from 0001728949-20-000031:mdna:278]

[0001728949-20-000057:mdna:272]
[same as prior period, unchanged from 0001728949-20-000031:mdna:279]

[0001728949-20-000057:mdna:273]
[same as prior period, unchanged from 0001728949-20-000031:mdna:280]

[0001728949-20-000057:mdna:274]
[same as prior period, unchanged from 0001728949-20-000031:mdna:281]

[0001728949-20-000057:mdna:275]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that the European Union (EU) will adopt a unitary patent system in the next few years that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-20-000057:mdna:276]
We have had, currently have, and may in the future have, difficulty in certain circumstances in protecting or enforcing our intellectual property rights and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies of foreign governments; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business and the pricing and

[0001728949-20-000057:mdna:277]
[same as prior period, unchanged from 0001728949-20-000031:mdna:314]

[0001728949-20-000057:mdna:278]
integration of additional features and functionality into our chipset products. Certain licensees have disputed, underreported, underpaid, not reported or not paid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or have delayed entering into or renewing license agreements for their use of our intellectual property. Further, certain licensees and companies are currently engaged in such behavior and they or others may engage in such behavior in the future. The fact that one or more licensees dispute, underreport, underpay, do not report or do not pay royalties owed to us may encourage other licensees to take similar actions or not renew their existing license agreements, and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements. Similarly, we provide access to certain of our intellectual property and proprietary and confidential business information to our direct and indirect customers and licensees, who have in the past and may in the future wrongfully use such intellectual property and information or wrongfully disclose such intellectual property and information to third parties, including our competitors. See also the Risk Factor entitled “Efforts by some OEMs or their customers to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.”

[0001728949-20-000057:mdna:279]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0001728949-20-000057:mdna:280]
[same as prior period, unchanged from 0001728949-20-000031:mdna:286]

[0001728949-20-000057:mdna:281]
[same as prior period, unchanged from 0001728949-20-000031:mdna:287]

[0001728949-20-000057:mdna:282]
[same as prior period, unchanged from 0001728949-20-000031:mdna:288]

[0001728949-20-000057:mdna:283]
[same as prior period, unchanged from 0001728949-20-000031:mdna:289]

[0001728949-20-000057:mdna:284]
44

[0001728949-20-000057:mdna:285]
[same as prior period, unchanged from 0001728949-20-000031:mdna:291]

[0001728949-20-000057:mdna:286]
[same as prior period, unchanged from 0001728949-20-000031:mdna:292]

[0001728949-20-000057:mdna:287]
[same as prior period, unchanged from 0001728949-20-000031:mdna:293]

[0001728949-20-000057:mdna:288]
[same as prior period, unchanged from 0001728949-20-000031:mdna:294]

[0001728949-20-000057:mdna:289]
[same as prior period, unchanged from 0001728949-20-000031:mdna:295]

[0001728949-20-000057:mdna:290]
[same as prior period, unchanged from 0001728949-20-000031:mdna:296]

[0001728949-20-000057:mdna:291]
Further, the licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, all of our patent license agreements in China that were entered into in 2015 or thereafter, as well as our recent worldwide cellular standard-essential patent only agreements, are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of the specified term, and to receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms and may impact the financial or other terms of license agreements not subject to the litigation or arbitration. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001728949-20-000057:mdna:292]
45

[0001728949-20-000057:mdna:293]
We depend on a limited number of third-party suppliers for the procurement, manufacture and testing of our products manufactured in a fabless production model. If we fail to execute supply strategies that provide technology leadership, supply assurance and reasonable margins, our business and results of operations may be harmed. We are also subject to order and shipment uncertainties that could negatively impact our results of operations.

[0001728949-20-000057:mdna:294]
[same as prior period, unchanged from 0001728949-20-000031:mdna:301]

[0001728949-20-000057:mdna:295]
[same as prior period, unchanged from 0001728949-20-000031:mdna:302]

[0001728949-20-000057:mdna:296]
[same as prior period, unchanged from 0001728949-20-000031:mdna:303]

[0001728949-20-000057:mdna:297]
[same as prior period, unchanged from 0001728949-20-000031:mdna:304]

[0001728949-20-000057:mdna:298]
[same as prior period, unchanged from 0001728949-20-000031:mdna:305]

[0001728949-20-000057:mdna:299]
[same as prior period, unchanged from 0001728949-20-000031:mdna:306]

[0001728949-20-000057:mdna:300]
[same as prior period, unchanged from 0001728949-20-000031:mdna:307]

[0001728949-20-000057:mdna:301]
[same as prior period, unchanged from 0001728949-20-000031:mdna:308]

[0001728949-20-000057:mdna:302]
[same as prior period, unchanged from 0001728949-20-000031:mdna:309]

[0001728949-20-000057:mdna:303]
[same as prior period, unchanged from 0001728949-20-000031:mdna:310]

[0001728949-20-000057:mdna:304]
[same as prior period, unchanged from 0001728949-20-000031:mdna:311]

[0001728949-20-000057:mdna:305]
[same as prior period, unchanged from 0001728949-20-000031:mdna:312]

[0001728949-20-000057:mdna:306]
Although we have long-term contracts with our suppliers, most of these contracts do not provide for long-term capacity commitments. To the extent we do not have firm commitments from our suppliers over a specific time period or for any specific quantity, our suppliers may allocate, and in the past have allocated, capacity to the production and testing of products for their other customers while reducing or limiting capacity to manufacture or test our products. Accordingly, capacity for our products may not be available when we need it or at reasonable prices. To the extent we do obtain long-term capacity

[0001728949-20-000057:mdna:307]
46

[0001728949-20-000057:mdna:308]
commitments, we may incur additional costs related to those commitments or make non-refundable payments for capacity commitments that are not used.

[0001728949-20-000057:mdna:309]
[same as prior period, unchanged from 0001728949-20-000031:mdna:315]

[0001728949-20-000057:mdna:310]
[same as prior period, unchanged from 0001728949-20-000031:mdna:316]

[0001728949-20-000057:mdna:311]
[same as prior period, unchanged from 0001728949-20-000031:mdna:317]

[0001728949-20-000057:mdna:312]
[same as prior period, unchanged from 0001728949-20-000031:mdna:318]

[0001728949-20-000057:mdna:313]
Through our QCT segment, we also own and operate various facilities that manufacture our RFFE modules and RF filter acoustic products. Manufacturing facilities are characterized by a higher portion of fixed costs relative to a fabless model. We may be faced with a decline in the utilization rates of our manufacturing facilities due to decreases in demand for our products, including in less favorable industry environments. During such periods, our manufacturing facilities could operate at lower capacity levels, while the fixed costs associated with such facilities continue to be incurred, resulting in lower gross profit.

[0001728949-20-000057:mdna:314]
[same as prior period, unchanged from 0001728949-20-000031:mdna:320]

[0001728949-20-000057:mdna:315]
[same as prior period, unchanged from 0001728949-20-000031:mdna:321]

[0001728949-20-000057:mdna:316]
We have manufacturing facilities in Asia and Europe. If tsunamis, flooding, earthquakes, volcanic eruptions or other natural disasters, or geopolitical conflicts, were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, delay new production and shipments of inventory and result in costly repairs, replacements or other costs. In addition, natural disasters or geopolitical conflicts may result in disruptions in transportation, distribution channels and supply chains, and significant increases in the prices of raw materials. Further, health crises, including epidemics or

[0001728949-20-000057:mdna:317]
[same as prior period, unchanged from 0001728949-20-000031:mdna:346]

[0001728949-20-000057:mdna:318]
pandemics, such as the COVID-19 pandemic, and government and business responses thereto, could affect our manufacturing facilities, including by resulting in quarantines and/or closures, which would result in disruptions to and potentially closures of our manufacturing operations.

[0001728949-20-000057:mdna:319]
[same as prior period, unchanged from 0001728949-20-000031:mdna:324]

[0001728949-20-000057:mdna:320]
[same as prior period, unchanged from 0001728949-20-000031:mdna:325]

[0001728949-20-000057:mdna:321]
[same as prior period, unchanged from 0001728949-20-000031:mdna:326]

[0001728949-20-000057:mdna:322]
[same as prior period, unchanged from 0001728949-20-000031:mdna:327]

[0001728949-20-000057:mdna:323]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, or to license such rights or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling such products or providing such services. Similarly, our suppliers could be found to infringe another company’s intellectual property rights, and such suppliers could then be enjoined from providing products or services to us.

[0001728949-20-000057:mdna:324]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products or services sold or provided by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-20-000057:mdna:325]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some

[0001728949-20-000057:mdna:326]
48

[0001728949-20-000057:mdna:327]
of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset or licensing revenues.

[0001728949-20-000057:mdna:328]
Certain legal matters, which may include certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-20-000057:mdna:329]
[same as prior period, unchanged from 0001728949-20-000031:mdna:333]

[0001728949-20-000057:mdna:330]
[same as prior period, unchanged from 0001728949-20-000031:mdna:334]

[0001728949-20-000057:mdna:331]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models (including manufacturing), geographic regions, industry segments or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0001728949-20-000057:mdna:332]
[same as prior period, unchanged from 0001728949-20-000031:mdna:336]

[0001728949-20-000057:mdna:333]
Many of our acquisitions and other strategic investments require approval by the United States and/or foreign government agencies. Certain agencies in the past have, and may in the future, deny the transaction or fail to approve in a timely manner, resulting in us not realizing the anticipated benefits of the transaction. Future acquisitions or other strategic investments may be more difficult, complex or expensive to the extent that our reputation for our ability to consummate acquisitions has been harmed. Further, if U.S./China relations remain strained, our ability to consummate any transaction that would require approval from the State Administration for Market Regulation (SAMR) in China may be severely impacted.

[0001728949-20-000057:mdna:334]
[same as prior period, unchanged from 0001728949-20-000031:mdna:338]

[0001728949-20-000057:mdna:335]
[same as prior period, unchanged from 0001728949-20-000031:mdna:339]

[0001728949-20-000057:mdna:336]
[same as prior period, unchanged from 0001728949-20-000031:mdna:340]

[0001728949-20-000057:mdna:337]
[same as prior period, unchanged from 0001728949-20-000031:mdna:341]

[0001728949-20-000057:mdna:338]
[same as prior period, unchanged from 0001728949-20-000031:mdna:342]

[0001728949-20-000057:mdna:339]
[same as prior period, unchanged from 0001728949-20-000031:mdna:343]

[0001728949-20-000057:mdna:340]
Further, political actions, including trade and/or national security protection policies, or other actions by governments, particularly the U.S. and Chinese governments, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our customers, limit or prevent certain of our customers from transacting business with us, or make it more expensive to do so. Similarly, due to pressure from the Chinese government as part of its broader economic policies, our Chinese OEMs’ concerns over losing access to our integrated circuit products as a result of U.S./China trade tensions, or other policies, regulations or decisions arising out of U.S./China trade tensions, our Chinese OEM customers may develop their own integrated circuit products and use such products, or use our competitors’ integrated circuit products, in their devices rather than our integrated circuit products, and our Chinese licensees may delay or cease payments of license fees they owe to us. See also the Risk Factor entitled “Global, regional or local economic conditions, or political actions including trade and/or national security protection policies, that impact the mobile communications industry or the other industries in which we operate could negatively affect the demand for our products and services and our customers’ or licensees’ products and services, which may negatively affect our business, revenues, results of operations, cash flows and financial position.”

[0001728949-20-000057:mdna:341]
[same as prior period, unchanged from 0001728949-20-000031:mdna:345]

[0001728949-20-000057:mdna:342]
[same as prior period, unchanged from 0001728949-20-000031:mdna:347]

[0001728949-20-000057:mdna:343]
[same as prior period, unchanged from 0001728949-20-000031:mdna:348]

[0001728949-20-000057:mdna:344]
[same as prior period, unchanged from 0001728949-20-000031:mdna:349]

[0001728949-20-000057:mdna:345]
[same as prior period, unchanged from 0001728949-20-000031:mdna:350]

[0001728949-20-000057:mdna:346]
[same as prior period, unchanged from 0001728949-20-000031:mdna:351]

[0001728949-20-000057:mdna:347]
[same as prior period, unchanged from 0001728949-20-000031:mdna:352]

[0001728949-20-000057:mdna:348]
[same as prior period, unchanged from 0001728949-20-000031:mdna:353]

[0001728949-20-000057:mdna:349]
51

[0001728949-20-000057:mdna:350]
[same as prior period, unchanged from 0001728949-20-000031:mdna:354]

[0001728949-20-000057:mdna:351]
In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-20-000057:mdna:352]
There are risks associated with our indebtedness and our stock repurchase program.

[0001728949-20-000057:mdna:353]
[same as prior period, unchanged from 0001728949-20-000031:mdna:357]

[0001728949-20-000057:mdna:354]
[same as prior period, unchanged from 0001728949-20-000031:mdna:358]

[0001728949-20-000057:mdna:355]
[same as prior period, unchanged from 0001728949-20-000031:mdna:359]

[0001728949-20-000057:mdna:356]
[same as prior period, unchanged from 0001728949-20-000031:mdna:360]

[0001728949-20-000057:mdna:357]
[same as prior period, unchanged from 0001728949-20-000031:mdna:361]

[0001728949-20-000057:mdna:358]
Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to economic and political conditions, industry cycles and financial, business and other factors, including factors which negatively impact our cash flows, such as licensees withholding some or all of the royalty payments they owe to us or our paying fines or modifying our business practices in connection with regulatory investigations or litigation, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations in the future to service our debt, we may be required to, among other things: refinance or restructure all or a portion of our indebtedness; reduce or delay planned capital or operating expenditures; reduce, suspend or eliminate our dividend payments and/or our stock repurchase program; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing or restructuring are higher than our current rates, interest expense related to such refinancing or restructuring would increase. If there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt in the future and the terms of such debt could be adversely affected.

[0001728949-20-000057:mdna:359]
[same as prior period, unchanged from 0001728949-20-000031:mdna:363]

[0001728949-20-000057:mdna:360]
We have implemented a stock repurchase program to repurchase up to $30 billion of our outstanding common stock. In the third quarter of fiscal 2020, we suspended our stock repurchases, at least for the near term, in light of COVID-19. We have the ability to reinstate repurchases at any time if we determine it to be in the best interest of our stockholders. At June 28, 2020, $4.6 billion remained authorized for repurchase under the stock repurchase program. This stock repurchase program has significantly reduced and, if/when repurchases are resumed, will continue to reduce the amount of cash that we have available to fund our operations, including research and development, working capital, capital expenditures, acquisitions, investments, dividends and other corporate purposes; and increases our exposure to adverse economic, market, industry and competitive conditions and developments, and other changes in our business and our industry.

[0001728949-20-000057:mdna:361]
[same as prior period, unchanged from 0001728949-20-000031:mdna:365]

[0001728949-20-000057:mdna:362]
Third parties regularly attempt to gain unauthorized access to our information technology systems, and most of such attempts are increasingly more sophisticated. These attempts, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and

[0001728949-20-000057:mdna:363]
networks, including those in our manufacturing operations, and impersonating authorized users, among others. In addition, third party suppliers that we may rely on to store and/or process our confidential information may also be subject to similar attacks. Such attempts could result in the misappropriation, theft, misuse, disclosure or loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our information technology systems. These threats are constantly evolving, thereby increasing the difficulty of successfully defending against them or implementing adequate preventative measures. We seek to detect and investigate all security incidents and to prevent their recurrence, but attempts to gain unauthorized access to our information technology systems may be successful, and in some cases, we might be unaware of an incident or its magnitude and effects.

[0001728949-20-000057:mdna:364]
[same as prior period, unchanged from 0001728949-20-000031:mdna:368]

[0001728949-20-000057:mdna:365]
[same as prior period, unchanged from 0001728949-20-000031:mdna:369]

[0001728949-20-000057:mdna:366]
[same as prior period, unchanged from 0001728949-20-000031:mdna:370]

[0001728949-20-000057:mdna:367]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed. Our current examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts giving rise to a revision become known. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-20-000057:mdna:368]
In the fourth quarter of fiscal 2020, the United States Treasury Department issued final regulations on deductions for FDII. The United States Treasury Department is expected to finalize additional provisions of the 2017 Tax Cuts and Jobs Act, including certain foreign tax credit regulations, in the next several months. When finalized, these regulations may adversely affect our provision for income taxes, results of operations and/or cash flows.

[0001728949-20-000057:mdna:369]
Tax rules may change in a manner that adversely affects our future reported results of operations or the way we conduct our business. In response to the 2017 Tax Cuts and Jobs Act and to better align our profits with our activities, we implemented certain restructuring in fiscal 2018 and 2019. After our restructuring, most of our income is taxable in the United States with a significant portion qualifying for preferential treatment as FDII. Beginning in fiscal 2027, the effective tax rate for FDII increases from 13% to 16%. Further, if U.S. tax rates increase or the FDII deduction is eliminated or reduced, our provision for income taxes, results of operations and cash flows would be adversely affected. Also, if our customers move manufacturing operations to the United States, our FDII deduction will be reduced.

[0001728949-20-000057:mdna:370]
53

[0001728949-20-000057:mdna:371]
We have tax incentives in Singapore that require we meet specified employment and other criteria. Although our profit in Singapore has declined as a result of our 2018 restructuring, failure to meet these incentive requirements through March 2022 could result in a retroactive Singapore tax increase for 2017 and 2018.

[0001728949-20-000057:mdna:372]
Further changes in the tax laws of foreign jurisdictions could arise as a result of the base erosion and profit shifting (BEPS) project that was undertaken by the Organization for Economic Co-operation and Development (OECD). The OECD, which represents a coalition of member countries, recommended changes to numerous long-standing tax principles related to transfer pricing and continues to develop new proposals including allocating greater taxing rights to countries where customers are located and establishing a minimum tax on global income. These changes, as adopted by countries, may increase tax uncertainty and may adversely affect our provision for income taxes, results of operations and cash flows. Partially to address BEPS, we moved certain intellectual property from Singapore to the United States as part of our 2018 and 2019 restructuring.

[0001728949-20-000057:mdna:373]
Global, regional or local economic conditions, or political actions including trade and/or national security protection policies, that impact the mobile communications industry or the other industries in which we operate could negatively affect the demand for our products and services and our customers’ or licensees’ products and services, which may negatively affect our business, revenues, results of operations, cash flows and financial position.

[0001728949-20-000057:mdna:374]
A decline in global, regional or local economic conditions, a slow-down in economic growth, political actions including trade and/or national security protection policies, such as tariffs, bans or placing companies on restricted entity lists, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could have adverse, wide-ranging effects on demand for our products and services and for the products and services of our customers or licensees, particularly equipment manufacturers or others in the wireless communications industry who buy their products, such as wireless operators.

[0001728949-20-000057:mdna:375]
Political actions, including trade and/or national security protection policies, or other actions by governments, particularly the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our customers, limit or prevent certain of our customers from transacting business with us, or make it more expensive to do so. We derive a significant and increasing portion of our revenues from Chinese OEMs and a significant portion of our revenues from devices that are ultimately sold into China. If, due to U.S. or Chinese government actions or policies: we were further limited in or prohibited from selling our integrated circuit products to Chinese OEMs; if device manufacturers were limited in or prohibited from selling devices that incorporate our integrated circuit products into China; if Chinese OEMs develop and use their own integrated circuit products or our competitors’ integrated circuit products in their devices rather than our integrated circuit products, due to pressure from or policies of the Chinese government or the OEMs’ concerns over losing access to our integrated circuit products as a result of actual, threatened or potential U.S. or Chinese government actions or policies, or otherwise; if tariffs on our integrated circuit products or devices which incorporate our integrated circuit products made purchasing such devices or our integrated circuit products more expensive; or if our Chinese licensees delayed or ceased making payments of license fees they owe us, our business, revenues, results of operations, cash flows and financial position could be materially adversely impacted.

[0001728949-20-000057:mdna:376]
[same as prior period, unchanged from 0001728949-20-000031:mdna:380]

[0001728949-20-000057:mdna:377]
Any such prolonged economic downturn, trade or national security tensions, or health crisis may result in a decrease in demand for our products and technologies; a decrease in demand for the products and services of our customers or licensees; the inability of our suppliers to deliver on their supply commitments to us, our inability to supply our products to our customers and/or the inability of our customers or licensees to supply their products to end users; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our licensees or customers; failures by counterparties; and/or negative effects on wireless device inventories. In addition, our customers’ ability to purchase or pay for our products and services and network operators’ ability to upgrade their wireless networks could be adversely affected by economic conditions, leading to a reduction, cancellation or delay of orders for our products and services.

[0001728949-20-000057:mdna:378]
[same as prior period, unchanged from 0001728949-20-000031:mdna:382]

[0001728949-20-000057:mdna:379]
[same as prior period, unchanged from 0001728949-20-000031:mdna:383]

[0001728949-20-000057:mdna:380]
[same as prior period, unchanged from 0001728949-20-000031:mdna:384]

[0001728949-20-000057:mdna:381]
[same as prior period, unchanged from 0001728949-20-000031:mdna:385]

[0001728949-20-000057:mdna:382]
[same as prior period, unchanged from 0001728949-20-000031:mdna:386]

[0001728949-20-000057:mdna:383]
[same as prior period, unchanged from 0001728949-20-000031:mdna:387]

[0001728949-20-000057:mdna:384]
[same as prior period, unchanged from 0001728949-20-000031:mdna:388]

[0001728949-20-000057:mdna:385]
[same as prior period, unchanged from 0001728949-20-000031:mdna:389]

[0001728949-20-000057:mdna:386]
[same as prior period, unchanged from 0001728949-20-000031:mdna:390]

[0001728949-20-000057:mdna:387]
[same as prior period, unchanged from 0001728949-20-000031:mdna:391]

[0001728949-20-000057:mdna:388]
[same as prior period, unchanged from 0001728949-20-000031:mdna:392]

[0001728949-20-000057:mdna:389]
[same as prior period, unchanged from 0001728949-20-000031:mdna:393]

[0001728949-20-000057:mdna:390]
[same as prior period, unchanged from 0001728949-20-000031:mdna:394]

[0001728949-20-000057:mdna:391]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and to the end users of such devices. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products, repairing or replacing defective products, writing down defective inventory, or indemnification

[0001728949-20-000057:mdna:392]
clauses in our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, losses on unfavorable purchase commitments, and a decrease in demand for connected devices and wireless services generally. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products generally and our premium-tier products in particular.

[0001728949-20-000057:mdna:393]
In addition, the occurrence of defects may give rise to product liability claims, particularly if defects in our products or the products into which they are integrated result in personal injury or death. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the efforts of our technical and management personnel and harm our business. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. Further, our business liability insurance may be inadequate, or future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as automobiles, including autonomous driver assistance programs; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and extended reality (XR) for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0001728949-20-000057:mdna:394]
[same as prior period, unchanged from 0001728949-20-000031:mdna:398]
