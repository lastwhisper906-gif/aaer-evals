# QCOM 8-K — 0001728949-20-000056 filed 2020-07-29

## item codes, every 8-K on or before 2020-07-29

- 2020-07-29 0001728949-20-000056 — 2.02, 9.01
- 2020-07-24 0001728949-20-000047 — 5.02
- 2020-05-11 0001104659-20-058923 — 1.01, 8.01, 9.01
- 2020-05-04 0001728949-20-000037 — 5.02
- 2020-04-29 0001728949-20-000030 — 2.02, 9.01
- 2020-03-13 0001728949-20-000015 — 5.07
- 2020-02-05 0001728949-20-000010 — 2.02, 9.01
- 2019-11-06 0001728949-19-000074 — 5.02
- 2019-11-06 0001728949-19-000071 — 2.02, 9.01
- 2019-08-28 0001728949-19-000058 — 5.02
- 2019-07-31 0001728949-19-000053 — 2.02, 9.01
- 2019-05-10 0001728949-19-000044 — 5.02
- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2020-07-29

- none on or before 2020-07-29

## item 2.02 — earnings release, exhibit 99.1

[0001728949-20-000056:8k_2_02:1]
EX-99.1
2
qcom062820erex991.htm
EX-99.1

[0001728949-20-000056:8k_2_02:2]
Document

[0001728949-20-000056:8k_2_02:3]
Exhibit 99.1

[0001728949-20-000056:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001728949-20-000056:8k_2_02:5]
Qualcomm Contact:

[0001728949-20-000056:8k_2_02:6]
Mauricio Lopez-Hodoyan

[0001728949-20-000056:8k_2_02:7]
Vice President, Investor Relations

[0001728949-20-000056:8k_2_02:8]
Phone: 1-858-658-4813 | e-mail: ir@qualcomm.com

[0001728949-20-000056:8k_2_02:9]
Qualcomm Announces Third Quarter Fiscal 2020 Results

[0001728949-20-000056:8k_2_02:10]
Revenues $4.9 billion

[0001728949-20-000056:8k_2_02:11]
GAAP EPS $0.74, Non-GAAP EPS $0.86

[0001728949-20-000056:8k_2_02:12]
—EPS Exceeded High End of Guidance Range—

[0001728949-20-000056:8k_2_02:13]
—Resolved Dispute with Huawei and Signed a New License Agreement—

[0001728949-20-000056:8k_2_02:14]
SAN DIEGO - July 29, 2020 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal third quarter ended June 28, 2020.

[0001728949-20-000056:8k_2_02:15]
“As 5G continues to roll out, we are realizing the benefits of the investments we have made in building the most extensive licensing program in mobile and are turning the technical challenges of 5G into leadership opportunities and commercial wins,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “We delivered earnings above the high end of our range, continued to execute in our product and licensing businesses and entered into a new long-term patent license agreement with Huawei, all of which position us well for the balance of 2020 and beyond.”

[0001728949-20-000056:8k_2_02:16]
Third Quarter Results 1, 2

[0001728949-20-000056:8k_2_02:17]
Our third quarter fiscal 2020 GAAP and Non-GAAP results do not include revenues from the Huawei settlement or global patent license agreements.

[0001728949-20-000056:8k_2_02:18]
|  | GAAP |  |  |  |  |  | Non-GAAP |  |  |  |  |  |  |  |  |
| (in millions, except per share data and percentages) | Q3 Fiscal 2020 |  | Q3 Fiscal 20193 |  | Change |  | Q3 Fiscal 2020 |  | Q3 Fiscal 2019 |  |  |  |  | Change |  |
| Revenues | $4,893 |  | $9,635 |  | N/M |  | $4,890 |  | $4,894 |  |  |  |  | —% |  |
| Earnings before taxes (EBT) | $868 |  | $5,501 |  | N/M |  | $1,104 |  | $1,101 |  |  |  |  | —% |  |
| Net income | $845 |  | $2,149 |  | N/M |  | $982 |  | $982 |  |  |  |  | —% |  |
| Diluted earnings per share (EPS) | $0.74 |  | $1.75 |  | N/M |  | $0.86 |  | $0.80 |  |  |  |  | +8% |  |

[0001728949-20-000056:8k_2_02:19]
(1)   Discussion regarding our use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results is included at the end of this news release.

[0001728949-20-000056:8k_2_02:20]
(2)  The third quarter of fiscal 2019 GAAP and Non-GAAP results included $150 million of QTL revenues resulting from an interim agreement with Huawei.  The third quarter of fiscal 2020 GAAP and Non-GAAP results do not include revenues from the Huawei settlement or global patent license agreements.

[0001728949-20-000056:8k_2_02:21]
(3)  The third quarter of fiscal 2019 GAAP results included $4.7 billion of revenues, or $3.23 per share, resulting from settlement agreements with Apple and its contract manufacturers, which were not allocated to our segment results.  Results also included a $2.5 billion tax expense, or ($2.01) per share, due to the derecognition of a deferred tax asset as a result of an agreement with the Internal Revenue Service under which we forwent the federal tax basis step-up in certain distributed intellectual property.

[0001728949-20-000056:8k_2_02:22]
N/M: Not meaningful

[0001728949-20-000056:8k_2_02:23]
| Qualcomm Announces Third Quarter Fiscal 2020 Results | Page 2 of 9 |

[0001728949-20-000056:8k_2_02:24]
Segment Results

[0001728949-20-000056:8k_2_02:25]
|  | QCT |  |  |  |  |  | QTL |  |  |  |  |  |  |  |
| (in millions, except percentages) | Q3 Fiscal 2020 |  | Q3 Fiscal 2019 |  | Change |  | Q3 Fiscal 2020 |  | Q3 Fiscal 2019 |  | Change |  |  |  |
| Revenues | $3,807 |  | $3,567 |  | +7% |  | $1,044 |  | $1,292 |  | (19%) |  |  |  |
| EBT | $603 |  | $504 |  | +20% |  | $646 |  | $898 |  | (28%) |  |  |  |
| EBT as % of revenues | 16% |  | 14% |  | +2 points |  | 62% |  | 70% |  | -8 points |  |  |  |
| MSMTM chip shipments | 130 |  | 156 |  | (17%) |  |  |  |  |  |  |  |  |  |

[0001728949-20-000056:8k_2_02:26]
Return of Capital to Stockholders

[0001728949-20-000056:8k_2_02:27]
During the third quarter of fiscal 2020, we returned $843 million to stockholders, including $733 million, or $0.65 per share, of cash dividends paid and $110 million through repurchases of 1.6 million shares of common stock.

[0001728949-20-000056:8k_2_02:28]
| Qualcomm Announces Third Quarter Fiscal 2020 Results | Page 3 of 9 |

[0001728949-20-000056:8k_2_02:29]
Business Outlook

[0001728949-20-000056:8k_2_02:30]
In July 2020, we entered into a settlement agreement, as well as a new long-term, global patent license agreement with Huawei, including a cross license granting back rights to certain of Huawei’s patents, covering sales beginning January 1, 2020.  While we continue to assess the accounting impacts of the agreements, our financial guidance for the fourth quarter of fiscal 2020 includes the following:

[0001728949-20-000056:8k_2_02:31]
•Estimated QTL revenues for royalties due on sales made by Huawei in the September 2020 quarter.

[0001728949-20-000056:8k_2_02:32]
•Estimated revenues of approximately $1.8 billion related to amounts due from Huawei under the settlement agreement (which are incremental to amounts previously paid under two interim agreements) and estimated amounts due for the March 2020 and June 2020 quarters under the new global patent license agreement.  This amount will be excluded from our Non-GAAP results.

[0001728949-20-000056:8k_2_02:33]
Our guidance for the fourth quarter of fiscal 2020 includes an impact of greater than ($0.25) to EPS attributable to a planning assumption of an approximate 15% year-over-year reduction in handset shipments due to COVID-19, including a partial impact from the delay of a global 5G flagship phone launch.  However, the actual impact may differ materially due to the challenging economic environment and highly uncertain effects of COVID-19.  The “Note Regarding Forward-Looking Statements” in this news release provides a description of certain risks that we face, and our most recent quarterly report on file with the Securities and Exchange Commission (SEC) provides a more complete description of our risks.

[0001728949-20-000056:8k_2_02:34]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.

[0001728949-20-000056:8k_2_02:35]
|  |  |  | Current Guidance Q4 FY20 Estimates1, 2 |  |
|  | GAAP Revenues |  | $7.3B - $8.1B |  |
|  | Less revenues attributable to other items3 |  | ~$1.8B |  |
|  | Non-GAAP Revenues |  | $5.5B - $6.3B |  |
|  | GAAP diluted EPS |  | $2.12 - $2.32 |  |
|  | Less diluted EPS attributable to QSI |  | ($0.01) |  |  |
|  | Less diluted EPS attributable to share-based compensation |  | ($0.23) |  |  |
|  | Less diluted EPS attributable to other items3 |  | $1.31 |  |  |
|  | Non-GAAP diluted EPS |  | $1.05 - $1.25 |  |
|  | Other Information |  |  |  |
|  | MSM chip shipments |  | 145M - 165M |  |
|  | QCT revenues |  | $4.3B - $4.9B |  |
|  | QTL revenues |  | $1.2B - $1.4B |  |

[0001728949-20-000056:8k_2_02:36]
(1)   Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable. Further, due to their nature, certain income and expense items, such as certain investments, derivative and foreign currency transaction gains or losses, cannot be accurately forecast. Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001728949-20-000056:8k_2_02:37]
(2)   Our GAAP and Non-GAAP financial guidance for the fourth quarter of fiscal 2020 includes estimated QTL revenues for royalties due on sales made by Huawei in the September 2020 quarter.

[0001728949-20-000056:8k_2_02:38]
(3)  Our guidance for revenues and diluted EPS attributable to other items for the fourth quarter of fiscal 2020 includes estimated revenues of approximately $1.8 billion and estimated EPS of $1.38 per share related to amounts due from Huawei under the settlement agreement and estimated amounts due for the March 2020 and June 2020 quarters under the new global patent license agreement. Our guidance for diluted EPS attributable to other items for the fourth quarter of fiscal 2020 also includes acquisition-related items.

[0001728949-20-000056:8k_2_02:39]
| Qualcomm Announces Third Quarter Fiscal 2020 Results | Page 4 of 9 |

[0001728949-20-000056:8k_2_02:40]
Conference Call

[0001728949-20-000056:8k_2_02:41]
Qualcomm’s third quarter fiscal 2020 earnings conference call will be broadcast live on July 29, 2020, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm. This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to our financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at http://investor.qualcomm.com/ immediately prior to the commencement of the call. An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415. Callers should use reservation number 13706353.

[0001728949-20-000056:8k_2_02:42]
About Qualcomm

[0001728949-20-000056:8k_2_02:43]
Qualcomm is the world’s leading wireless technology innovator and the driving force behind the development, launch and expansion of 5G. When we connected the phone to the internet, the mobile revolution was born.  Today, our foundational technologies enable the mobile ecosystem and are found in every 3G, 4G and 5G smartphone.  We bring the benefits of mobile to new industries, including automotive, the internet of things and computing, and are leading the way to a world where everything and everyone can communicate and interact seamlessly.

[0001728949-20-000056:8k_2_02:44]
Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of our engineering, research and development functions, and substantially all of our products and services businesses, including our QCT semiconductor business.

[0001728949-20-000056:8k_2_02:45]
Note Regarding Forward-Looking Statements

[0001728949-20-000056:8k_2_02:46]
###

[0001728949-20-000056:8k_2_02:47]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-20-000056:8k_2_02:48]
MSM is a product of Qualcomm Technologies, Inc.

[0001728949-20-000056:8k_2_02:49]
| Qualcomm Announces Third Quarter Fiscal 2020 Results | Page 5 of 9 |

[0001728949-20-000056:8k_2_02:50]
QUALCOMM Incorporated

[0001728949-20-000056:8k_2_02:51]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001728949-20-000056:8k_2_02:52]
(In millions, except par value amounts)

[0001728949-20-000056:8k_2_02:53]
(Unaudited)

[0001728949-20-000056:8k_2_02:54]
|  | June 28,2020 |  | September 29,2019 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 6,120 |  |  | $ | 11,839 |  |
| Marketable securities | 4,480 |  |  | 421 |  |
| Accounts receivable, net | 1,847 |  |  | 2,471 |  |
| Inventories | 2,343 |  |  | 1,400 |  |
| Other current assets | 768 |  |  | 634 |  |
| Total current assets | 15,558 |  |  | 16,765 |  |
| Deferred tax assets | 1,345 |  |  | 1,196 |  |
| Property, plant and equipment, net | 3,487 |  |  | 3,081 |  |
| Goodwill | 6,299 |  |  | 6,282 |  |
| Other intangible assets, net | 1,749 |  |  | 2,172 |  |
| Other assets | 3,890 |  |  | 3,461 |  |
| Total assets | $ | 32,328 |  |  | $ | 32,957 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 2,046 |  |  | $ | 1,368 |  |
| Payroll and other benefits related liabilities | 1,020 |  |  | 1,048 |  |
| Unearned revenues | 550 |  |  | 565 |  |
| Short-term debt | 500 |  |  | 2,496 |  |
| Other current liabilities | 3,798 |  |  | 3,458 |  |
| Total current liabilities | 7,914 |  |  | 8,935 |  |
| Unearned revenues | 864 |  |  | 1,160 |  |
| Income taxes payable | 1,872 |  |  | 2,088 |  |
| Long-term debt | 15,425 |  |  | 13,437 |  |
| Other liabilities | 2,947 |  |  | 2,428 |  |
| Total liabilities | 29,022 |  |  | 28,048 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,128 and 1,145 shares issued and outstanding, respectively | 113 |  |  | 343 |  |
| Retained earnings | 3,081 |  |  | 4,466 |  |
| Accumulated other comprehensive income | 112 |  |  | 100 |  |
| Total stockholders’ equity | 3,306 |  |  | 4,909 |  |
| Total liabilities and stockholders’ equity | $ | 32,328 |  |  | $ | 32,957 |  |

[0001728949-20-000056:8k_2_02:55]
| Qualcomm Announces Third Quarter Fiscal 2020 Results | Page 6 of 9 |

[0001728949-20-000056:8k_2_02:56]
QUALCOMM Incorporated

[0001728949-20-000056:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-20-000056:8k_2_02:58]
(In millions, except per share data)

[0001728949-20-000056:8k_2_02:59]
(Unaudited)

[0001728949-20-000056:8k_2_02:60]
|  |  |  |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  |  |  |  |  |  | June 28,2020 |  | June 30,2019 |  | June 28,2020 |  | June 30,2019 |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services |  |  |  |  |  | $ | 3,794 |  |  | $ | 3,531 |  |  | $ | 11,376 |  |  | $ | 11,037 |  |
| Licensing |  |  |  |  |  | 1,099 |  |  | 6,104 |  |  | 3,809 |  |  | 8,422 |  |
| Total revenues |  |  |  |  |  | 4,893 |  |  | 9,635 |  |  | 15,185 |  |  | 19,459 |  |
| Costs and expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  |  |  |  | 2,080 |  |  | 2,114 |  |  | 6,489 |  |  | 6,481 |  |
| Research and development |  |  |  |  |  | 1,520 |  |  | 1,380 |  |  | 4,393 |  |  | 3,957 |  |
| Selling, general and administrative |  |  |  |  |  | 511 |  |  | 547 |  |  | 1,523 |  |  | 1,646 |  |
| Other |  |  |  |  |  | — |  |  | 277 |  |  | (23) |  |  | 408 |  |
| Total costs and expenses |  |  |  |  |  | 4,111 |  |  | 4,318 |  |  | 12,382 |  |  | 12,492 |  |
| Operating income |  |  |  |  |  | 782 |  |  | 5,317 |  |  | 2,803 |  |  | 6,967 |  |
| Interest expense |  |  |  |  |  | (143) |  |  | (160) |  |  | (436) |  |  | (477) |  |
| Investment and other income, net |  |  |  |  |  | 229 |  |  | 344 |  |  | 46 |  |  | 377 |  |
| Income before income taxes |  |  |  |  |  | 868 |  |  | 5,501 |  |  | 2,413 |  |  | 6,867 |  |
| Income tax expense |  |  |  |  |  | (23) |  |  | (3,352) |  |  | (175) |  |  | (2,987) |  |
| Net income |  |  |  |  |  | $ | 845 |  |  | $ | 2,149 |  |  | $ | 2,238 |  |  | $ | 3,880 |  |
| Basic earnings per share |  |  |  |  |  | $ | 0.75 |  |  | $ | 1.77 |  |  | $ | 1.97 |  |  | $ | 3.20 |  |
| Diluted earnings per share |  |  |  |  |  | $ | 0.74 |  |  | $ | 1.75 |  |  | $ | 1.95 |  |  | $ | 3.17 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  | 1,127 |  |  | 1,217 |  |  | 1,137 |  |  | 1,214 |  |
| Diluted |  |  |  |  |  | 1,139 |  |  | 1,231 |  |  | 1,150 |  |  | 1,224 |  |

[0001728949-20-000056:8k_2_02:61]
| Qualcomm Announces Third Quarter Fiscal 2020 Results | Page 7 of 9 |

[0001728949-20-000056:8k_2_02:62]
QUALCOMM Incorporated

[0001728949-20-000056:8k_2_02:63]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-20-000056:8k_2_02:64]
(In millions)

[0001728949-20-000056:8k_2_02:65]
(Unaudited)

[0001728949-20-000056:8k_2_02:66]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 28, 2020 |  | June 30,2019 |  | June 28, 2020 |  | June 30,2019 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 845 |  |  | $ | 2,149 |  |  | $ | 2,238 |  |  | $ | 3,880 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 363 |  |  | 353 |  |  | 1,054 |  |  | 1,051 |  |
| Income tax provision (less than) in excess of income tax payments | (109) |  |  | 3,164 |  |  | (459) |  |  | 2,206 |  |
| Non-cash portion of share-based compensation expense | 296 |  |  | 246 |  |  | 899 |  |  | 698 |  |
| Net gains on marketable securities and other investments | (220) |  |  | (332) |  |  | (269) |  |  | (340) |  |
| Indefinite and long-lived asset impairment charges | — |  |  | — |  |  | — |  |  | 203 |  |
| Impairment losses on other investments | 12 |  |  | 42 |  |  | 349 |  |  | 111 |  |
| Other items, net | (33) |  |  | (16) |  |  | (108) |  |  | (207) |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | 1,229 |  |  | 1,251 |  |  | 622 |  |  | 1,451 |  |
| Inventories | (641) |  |  | (46) |  |  | (938) |  |  | (95) |  |
| Other assets | (68) |  |  | (10) |  |  | (139) |  |  | 15 |  |
| Trade accounts payable | (10) |  |  | (94) |  |  | 745 |  |  | (267) |  |
| Payroll, benefits and other liabilities | 253 |  |  | (1,807) |  |  | 277 |  |  | (2,534) |  |
| Unearned revenues | (45) |  |  | 9 |  |  | (198) |  |  | (113) |  |
| Net cash provided by operating activities | 1,872 |  |  | 4,909 |  |  | 4,073 |  |  | 6,059 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (418) |  |  | (248) |  |  | (1,059) |  |  | (570) |  |
| Purchases of debt and equity marketable securities | (3,536) |  |  | — |  |  | (4,848) |  |  | — |  |
| Proceeds from sales and maturities of debt and equity marketable securities | 755 |  |  | 77 |  |  | 1,011 |  |  | 174 |  |
| Acquisitions and other investments, net of cash acquired | (31) |  |  | (67) |  |  | (159) |  |  | (185) |  |
| Other items, net | 74 |  |  | 30 |  |  | 130 |  |  | 112 |  |
| Net cash used by investing activities | (3,156) |  |  | (208) |  |  | (4,925) |  |  | (469) |  |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 1,170 |  |  | 1,511 |  |  | 2,286 |  |  | 4,808 |  |
| Repayment of short-term debt | (1,169) |  |  | (1,510) |  |  | (2,285) |  |  | (4,813) |  |
| Proceeds from long-term debt | 1,989 |  |  | — |  |  | 1,989 |  |  | — |  |
| Repayment of long-term debt | (2,000) |  |  | — |  |  | (2,000) |  |  | — |  |
| Proceeds from issuance of common stock | 2 |  |  | 87 |  |  | 176 |  |  | 264 |  |
| Repurchases and retirements of common stock | (110) |  |  | (69) |  |  | (2,450) |  |  | (1,088) |  |
| Dividends paid | (733) |  |  | (755) |  |  | (2,148) |  |  | (2,257) |  |
| Payments of tax withholdings related to vesting of share-based awards | (94) |  |  | (82) |  |  | (326) |  |  | (225) |  |
| Other items, net | (58) |  |  | (97) |  |  | (113) |  |  | (135) |  |
| Net cash used by financing activities | (1,003) |  |  | (915) |  |  | (4,871) |  |  | (3,446) |  |
| Effect of exchange rate changes on cash and cash equivalents | 4 |  |  | 2 |  |  | 4 |  |  | 2 |  |
| Net (decrease) increase in total cash and cash equivalents | (2,283) |  |  | 3,788 |  |  | (5,719) |  |  | 2,146 |  |
| Total cash and cash equivalents at beginning of period | 8,403 |  |  | 10,135 |  |  | 11,839 |  |  | 11,777 |  |
| Total cash and cash equivalents at end of period | $ | 6,120 |  |  | $ | 13,923 |  |  | $ | 6,120 |  |  | $ | 13,923 |  |

[0001728949-20-000056:8k_2_02:67]
| Qualcomm Announces Third Quarter Fiscal 2020 Results | Page 8 of 9 |

[0001728949-20-000056:8k_2_02:68]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-20-000056:8k_2_02:69]
The Non-GAAP financial measures presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, our Non-GAAP financial measures might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP financial measures are presented herein.

[0001728949-20-000056:8k_2_02:70]
We use Non-GAAP financial information: (i) to evaluate, assess and benchmark our operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of our ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by us include revenues, cost of revenues, research and development (R&D) expenses, selling, general and administrative (SG&A) expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  We are able to assess what we believe is a more meaningful and comparable set of financial performance measures for Qualcomm and its business segments by using Non-GAAP information.  In addition, the HR and Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  We present Non-GAAP financial information to provide greater transparency to investors with respect to our use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0001728949-20-000056:8k_2_02:71]
Non-GAAP information excludes our QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-20-000056:8k_2_02:72]
•QSI is excluded because we expect to exit our strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed as unrelated to our operational performance.

[0001728949-20-000056:8k_2_02:73]
•Share-based compensation expense primarily relates to restricted stock units.  We believe that excluding non-cash share-based compensation from the Non-GAAP financial information allows us and investors to make additional comparisons of the operating activities of our ongoing core businesses over time and with respect to other companies.

[0001728949-20-000056:8k_2_02:74]
•Certain other items are excluded because we view such items as unrelated to the operating activities of our ongoing core businesses, as follows:

[0001728949-20-000056:8k_2_02:75]
◦Acquisition-related items include amortization of acquisition-related intangible assets starting with acquisitions in the third quarter of fiscal 2011, substantially all of which relate to the amortization of technology-based intangible assets that is recorded in cost of revenues and will recur in future periods until the related intangible assets have been fully amortized.  We view acquisition-related intangible assets as items arising from pre-acquisition activities determined at the time of an acquisition.  Acquisition-related intangible assets contribute to revenue generation that has not been excluded from our Non-GAAP financial information.  Acquisition-related items also include recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of acquisition-related items, as well as any effects from restructuring the ownership of such acquired assets.  Additionally, we exclude third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition.

[0001728949-20-000056:8k_2_02:76]
◦We exclude certain other items that we view as unrelated to our ongoing businesses, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters.  Beginning in the second quarter of fiscal 2020, we exclude gains and losses driven by the revaluation of our deferred compensation plan liabilities recognized in operating expenses and the offsetting gains and losses on the related plan assets recognized in investment and other income.  Amounts prior to the second quarter of fiscal 2020, which were not material, continue to be included in Non-GAAP results.

[0001728949-20-000056:8k_2_02:77]
◦Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of our ongoing Non-GAAP tax rate and after-tax earnings.

[0001728949-20-000056:8k_2_02:78]
| Qualcomm Announces Third Quarter Fiscal 2020 Results | Page 9 of 9 |

[0001728949-20-000056:8k_2_02:79]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-20-000056:8k_2_02:80]
| (in millions, except per share data and percentages) |  |  |  | GAAP to Non-GAAP Reconciliation |  |  |  |  |  |  |  |  |  | Non-GAAP Supplemental Information |  |  |  |  |  |
|  |  |  |  | GAAP Results |  | Less QSI |  | Less Share-Based Compensation |  | Less Other Items2 |  | Non-GAAP Results |  | QCT |  | QTL3 |  | Non-GAAP Reconciling Items4 |  |
| Q3 FISCAL 20201 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $4,893 |  | $3 |  | $— |  |  | $— |  |  | $4,890 |  | $3,807 |  | $1,044 |  | $39 |  |
| Operating income (loss) |  |  |  | 782 |  | (2) |  | (296) |  | (143) |  | 1,223 |  |  |  |  |  |  |  |
| EBT |  |  |  | 868 |  | 153 |  | (296) |  | (93) |  | 1,104 |  | 603 |  | 646 |  | (145) |  |
| EBT as % of revenues |  |  |  | 18 | % |  |  |  |  |  |  |  | 23 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 845 |  | 179 |  | (241) |  | (75) |  | 982 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $0.74 |  | $0.16 |  | ($0.21) |  | ($0.07) |  | $0.86 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,139 |  | 1,139 |  | 1,139 |  | 1,139 |  | 1,139 |  |  |  |  |  |  |  |
| Q3 FISCAL 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $9,635 |  | $18 |  | $— |  |  | $4,723 |  | $4,894 |  | $3,567 |  | $1,292 |  | $35 |  |
| Operating income (loss) |  |  |  | 5,317 |  | 10 |  | (246) |  | 4,339 |  | 1,214 |  |  |  |  |  |  |  |
| EBT |  |  |  | 5,501 |  | 312 |  | (246) |  | 4,334 |  | 1,101 |  | 504 |  | 898 |  | (301) |  |
| EBT as % of revenues |  |  |  | 57 | % |  |  |  |  |  |  |  | 22 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 2,149 |  | 237 |  | (198) |  | 1,128 |  | 982 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $1.75 |  | $0.19 |  | ($0.16) |  | $0.92 |  | $0.80 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,231 |  | 1,231 |  | 1,231 |  | 1,231 |  | 1,231 |  |  |  |  |  |  |  |

[0001728949-20-000056:8k_2_02:81]
(1)   The rapid, global spread of COVID-19 negatively impacted consumer demand for devices that incorporate our products and intellectual property, which negatively impacted our GAAP and Non-GAAP results in the third quarter of fiscal 2020.

[0001728949-20-000056:8k_2_02:82]
(2)   Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” section herein.  Details of amounts included in the “Other Items” column for the prior period are included in the news release for that period.

[0001728949-20-000056:8k_2_02:83]
(3)  The third quarter of fiscal 2019 GAAP and Non-GAAP results included $150 million of QTL revenues resulting from an interim agreement with Huawei.  The third quarter of fiscal 2020 GAAP and Non-GAAP results do not include QTL revenues from Huawei.

[0001728949-20-000056:8k_2_02:84]
(4)   Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations.  Non-GAAP reconciling items related to EBT consisted primarily of certain R&D expenses, SG&A expenses, other expenses or income, interest expense and certain investment income that are not allocated to segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit.

[0001728949-20-000056:8k_2_02:85]
Sums may not equal totals due to rounding.

[0001728949-20-000056:8k_2_02:86]
|  | Q3 FISCAL 2020 Supplemental Information and Reconciliations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | ($ in millions) | GAAP Results |  |  | Less QSI |  |  | Less Share-Based Compensation |  |  | Less Other Items1, 2 |  |  | Non-GAAP Results |  |  |
|  | Cost of revenues |  | $2,080 |  |  | $2 |  |  | $8 |  |  | $79 |  |  | $1,991 |  |
|  | Research and development expenses |  | 1,520 |  |  | — |  |  |  | 217 |  |  | 27 |  |  | 1,276 |  |
|  | Selling, general and administrative expenses |  | 511 |  |  | 3 |  |  | 71 |  |  | 37 |  |  | 400 |  |
|  | Interest expense |  | 143 |  |  | — |  |  |  | — |  |  |  | 7 |  |  | 136 |  |
|  | Investment and other income, net |  | 229 |  |  | 155 |  |  | — |  |  |  | 57 |  |  | 17 |  |
|  | Income tax expense (benefit) |  | 23 |  |  | (26) |  |  | (55) |  |  | (18) |  |  | 122 |  |

[0001728949-20-000056:8k_2_02:87]
(1)  Other items excluded from Non-GAAP results included $84 million of acquisition-related charges, $7 million of interest expense related to the 2018 and 2019 European Commission fines and a $2 million charge related to restructuring-related activities. Other items excluded from Non-GAAP results also included $57 million of losses driven by the revaluation of our deferred compensation plan liabilities, which increased operating expenses, offset by corresponding $57 million of gains driven by the revaluation of the associated plan assets, which were included within investment and other income, net.

[0001728949-20-000056:8k_2_02:88]
(2)   At fiscal year end, the quarterly tax provision for each column equals the annual tax provision for each column computed in accordance with GAAP.  In interim quarters, the sum of these provisions may not equal the total GAAP tax provision, and this difference is included in the tax provision in the “Other Items” column.  The tax benefit in the “Other Items” column included a $21 million tax benefit related to a prior year, an $11 million tax benefit for the tax effect of acquisition-related charges and a $9 million foreign currency gain related to a noncurrent receivable resulting from our refund claim of Korean withholding taxes paid in prior periods, partially offset by a $12 million charge to reconcile the tax provision of each column to the total GAAP tax provision for the quarter and an $11 million charge related to a foreign tax audit.
