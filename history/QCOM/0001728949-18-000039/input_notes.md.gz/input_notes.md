# QCOM notes — 0001728949-18-000039


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-18-000039:notes:1]
[same as prior period, unchanged from 0001728949-18-000011:notes:1]

[0001728949-18-000039:notes:2]
| Inventories (in millions) |  |  |  |
|  | March 25, 2018 |  | September 24, 2017 |
| Raw materials | $ | 93 |  |  | $ | 103 |  |
| Work-in-process | 643 |  |  | 799 |  |
| Finished goods | 1,061 |  |  | 1,133 |  |
|  | $ | 1,797 |  |  | $ | 2,035 |  |

[0001728949-18-000039:notes:3]
| Other Current Liabilities (in millions) |  |  |  |
|  | March 25, 2018 |  | September 24, 2017 |
| Customer incentives and other customer-related liabilities | $ | 2,882 |  |  | $ | 2,804 |  |
| Accrual for EC fine (Note 6) | 1,232 |  |  | — |  |
| Income taxes payable | 575 |  |  | 312 |  |
| Accrual for TFTC fine (Note 6) | 156 |  |  | 778 |  |
| Other | 864 |  |  | 862 |  |
|  | $ | 5,709 |  |  | $ | 4,756 |  |

[0001728949-18-000039:notes:4]
Other Income, Costs and Expenses. Other expenses in the three months ended March 25, 2018 consisted of $310 million in restructuring and restructuring-related charges related to the Company’s Cost Plan (Note 9). Other expenses in the six months ended March 25, 2018 also included a $1.2 billion charge related to the European Commission (EC) fine (Note 6).

[0001728949-18-000039:notes:5]
Other expenses in the three months ended March 26, 2017 consisted of $53 million in foreign currency losses related to the fine imposed by the Korea Fair Trade Commission (KFTC), which was accrued in the first quarter of fiscal 2017, and $25 million in restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan. Other expenses in the six months ended March 26, 2017 consisted of a $921 million charge related to the KFTC fine, including related foreign currency losses, and $33 million in restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan.

[0001728949-18-000039:notes:6]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | March 25, 2018 |  | March 26, 2017 |
| Interest and dividend income | $ | 154 |  |  | $ | 153 |  |  | $ | 280 |  |  | $ | 320 |  |
| Net realized gains on marketable securities | 3 |  |  | 67 |  |  | 13 |  |  | 206 |  |
| Net realized gains on other investments | 47 |  |  | 21 |  |  | 60 |  |  | 30 |  |
| Impairment losses on marketable securities | — |  |  | (3 | ) |  | (1 | ) |  | (125 | ) |
| Impairment losses on other investments | (11 | ) |  | (2 | ) |  | (19 | ) |  | (23 | ) |
| Net gains on derivative investments | 10 |  |  | 13 |  |  | 9 |  |  | 20 |  |
| Equity in net losses of investees | (17 | ) |  | (14 | ) |  | (38 | ) |  | (11 | ) |
| Net losses on foreign currency transactions | (90 | ) |  | — |  |  | (93 | ) |  | — |  |
|  | $ | 96 |  |  | $ | 235 |  |  | $ | 211 |  |  | $ | 417 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001728949-18-000039:notes:7]
[same as prior period, unchanged from 0001728949-18-000011:notes:6]

[0001728949-18-000039:notes:8]
On October 27, 2016, the Company announced a definitive agreement (the Purchase Agreement) under which Qualcomm River Holdings, B.V. (Qualcomm River Holdings), an indirect, wholly owned subsidiary of QUALCOMM Incorporated, will acquire NXP Semiconductors N.V. (NXP). NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products. Pursuant to the Purchase Agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP. On February 20, 2018, Qualcomm River Holdings and NXP entered into Amendment No. 1 to the Purchase Agreement, which (i) increased the price payable in the tender offer from $110.00 per share in cash to $127.50 per share in cash, representing estimated total cash consideration to be paid to NXP’s shareholders of $44 billion, and (ii) reduced the Minimum Condition (as defined in the Purchase Agreement) from 80% of the issued and outstanding common shares of NXP to 70% of the issued and outstanding common shares of NXP. On April 19, 2018, Qualcomm River Holdings and NXP entered into Amendment No. 2 to the Purchase Agreement (Amendment No. 2), which, among other things, extended the End Date (as defined in the Purchase Agreement) from April 25, 2018 to July 25, 2018.

[0001728949-18-000039:notes:9]
The transaction is subject to receipt of regulatory clearance from the Ministry of Commerce in the People’s Republic of China (MOFCOM) and other closing conditions, including the tender of at least 70% of the issued and outstanding common shares of NXP in the tender offer. At an Extraordinary General Meeting of NXP’s shareholders held on January 27, 2017, NXP’s shareholders approved certain matters relating to the transaction, including the appointment of designees of Qualcomm River Holdings to NXP’s board of directors (effective upon the closing of the transaction) and certain transactions that are intended to be consummated after the completion of the tender offer.

[0001728949-18-000039:notes:10]
In May 2017, the Company issued an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes with varying maturities, of which a portion will be used to fund the purchase price and other related transactions. In addition, the Company has secured $4.0 billion and $3.0 billion in committed financing through the 2016 Term Loan Facility and the 2018 Term Loan Facility, respectively, which are expected to be drawn on at the close of the NXP transaction. The Company has also secured $3.0 billion in committed financing through the 2018 Revolving Credit Facility, which is available, in part, to finance the transaction (Note 5). The remaining amount will be funded with cash held by foreign entities.

[0001728949-18-000039:notes:11]
Qualcomm River Holdings and NXP may terminate the Purchase Agreement under certain circumstances. If the Purchase Agreement is terminated in certain circumstances, including termination by NXP to enter into a superior proposal for an alternative acquisition transaction or a termination following a change of recommendation by NXP’s board of directors, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the Purchase Agreement is terminated under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion. Under Amendment No. 2, in addition to its existing rights, NXP will be entitled to receive the termination fee (i) if the Purchase Agreement is terminated in accordance with its terms for any reason (subject to certain exceptions) and, at the time of any such termination, approval by MOFCOM, or in any jurisdiction where the parties’ previously obtained clearance will expire or where the applicable antitrust authority has required or requested a resubmission for clearance, has not been received, or (ii) at any time after July 25, 2018 if, at such time, approval by MOFCOM, or in any jurisdiction where the parties’ previously obtained clearance will expire or where the applicable antitrust authority has required or requested a resubmission for clearance, has not been received.

[0001728949-18-000039:notes:12]
In November 2016, as required by the Purchase Agreement, Qualcomm River Holdings entered into four letters of credit for an aggregate amount of $2.0 billion related to the potential termination fee payable to NXP. Pursuant to the terms of each letter of credit, NXP will have the right to draw amounts to fund certain termination compensation owed by Qualcomm River Holdings to NXP if the Purchase Agreement is terminated under certain circumstances, as described above. The letters of credit expire on June 30, 2018 or if drawn on by NXP or surrendered by Qualcomm River Holdings, provided that under Amendment No. 2, Qualcomm River Holdings is required to cause the letters of credit to be amended to, among other things, extend the expiration date. Each letter of credit is required to be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. Qualcomm River Holdings is restricted from using the funds deposited as collateral while the letters of credit are outstanding. At March 25, 2018, the letters of credit were fully collateralized through bank time and demand deposits, which were included in other noncurrent assets.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-18-000039:notes:13]
Commitments and Contingencies

[0001728949-18-000039:notes:14]
Legal and Regulatory Proceedings.

[0001728949-18-000039:notes:15]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe certain ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 ParkerVision patents and seeks damages and injunctive and other relief. On December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against the Company and other parties with the United States International Trade Commission (ITC) described below. Subsequently, ParkerVision announced that it had reached a settlement with Samsung which dismissed the Samsung entities from the District Court case. The Company had previously filed Inter-Partes Review petitions with the United States Patent and Trademark Office (USPTO) to invalidate all asserted claims of several of the remaining patents. On March 7, 2017, the USPTO decided in the Company’s favor with respect to all asserted claims of one such patent. After the ITC action described below was closed, and upon agreement among the parties, on May 24, 2017, the District Court further stayed the District Court case pending ParkerVision’s appeal of the USPTO’s invalidation decisions.

[0001728949-18-000039:notes:16]
On December 14, 2015, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. are also named defendants. The complaint asserts that certain of the Company’s products infringe four additional ParkerVision patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. On February 12, 2016, the District Court case was stayed pending completion of the ITC investigation. Subsequently, ParkerVision announced that it had reached a settlement with Samsung which dismissed the Samsung entities from the ITC investigation and related District Court case. On February 2, 2017, the ITC granted ParkerVision’s motion to drop all but one patent and one accused product from the ITC investigation. On March 12, 2017, one day before the ITC hearing was scheduled to begin, ParkerVision moved to withdraw its ITC complaint in its entirety. The Company and the other defendants did not oppose the withdrawal of the complaint. On April 28, 2017, the ITC formally closed the investigation. On May 4, 2017, ParkerVision filed a motion to reopen the related District Court Case, and on May 26, 2017, the District Court granted the motion. On March 16, 2018, the parties agreed to dismiss three of ParkerVision’s patents from the case without prejudice, leaving only one patent at issue. No trial date has been set.

[0001728949-18-000039:notes:17]
Apple Inc. (Apple) v. QUALCOMM Incorporated: On January 20, 2017, Apple filed a complaint against the Company in the United States District Court for the Southern District of California seeking declarations with respect to several of the Company’s patents and alleging that the Company breached certain agreements and violated federal antitrust and California state unfair competition laws. In its initial complaint, Apple sought declaratory judgments of non-infringement by Apple of nine of the Company’s patents, or in the alternative, a declaration of royalties Apple must pay for the patents. Apple further sought a declaration that the Company’s sale of baseband chipsets exhausts the Company’s patent rights for patents embodied in those chipsets. Separately, Apple sought to enjoin the Company from seeking excessive royalties from Apple and to disgorge royalties paid by Apple’s contract manufacturers that the court finds were not fair, reasonable and non-discriminatory (FRAND). Apple also claimed that the Company’s refusal to make certain payments to Apple under a Business Cooperation and Patent Agreement (Cooperation Agreement) constitutes a breach of contract in violation of California law and sought damages in the amount of the unpaid payments, alleged to be approximately $1 billion. In addition, Apple claimed that the Company has refused to deal with competitors in contravention of the Company’s agreements with applicable standard setting organizations, has used its market position to impose contractual obligations on Apple that prevented Apple from challenging the Company’s licensing practices, has tied the purchase of the Company’s CDMA-enabled and “premium” LTE-enabled chipsets to licensing certain of the Company’s patents and has required Apple to purchase baseband chipsets exclusively from the Company as a condition of the Company’s payment to Apple of certain rebates, in violation of Section 2 of the Sherman Act and the California Unfair Competition Law. Apple sought injunctive relief with respect to these claims and a judgment awarding its expenses, costs and attorneys’ fees.

[0001728949-18-000039:notes:18]
On April 10, 2017, the Company filed its Answer and Counterclaims (amended on May 24, 2017) in response to Apple’s complaint denying Apple’s claims and asserting claims against Apple. The counterclaims against Apple include tortious interference with the Company’s long-standing Subscriber Unit License Agreements (SULAs) with third-party contract manufacturers of Apple devices, causing those contract manufacturers to withhold certain royalty payments owed to the Company and violate their audit obligations; breach of contract and the implied covenant of good faith and fair dealing relating to the parties’ Cooperation Agreement; unjust enrichment and declaratory relief relating to the Cooperation Agreement; breach of contract based on Apple’s failure to pay amounts owed to the Company under a Statement of Work relating to a high-speed feature of the Company’s chipsets; breach of the parties’ software agreement; and violation of California Unfair Competition Law based on Apple’s threatening the Company to prevent it from promoting the superior performance of the Company’s own chipsets. The Company also seeks declaratory judgments that the Company has satisfied its FRAND commitments with respect to Apple, and that the Company’s SULAs with the contract manufacturers do not violate either competition law or the Company’s FRAND commitments. On June 19, 2017, Apple filed a Partial Motion to Dismiss the Company’s counterclaim for violation of the California Unfair Competition Law. The court granted that motion on November 8, 2017. On June 20, 2017, Apple filed an Answer and Affirmative Defenses to the rest of the Company’s counterclaims, and also filed an Amended Complaint reiterating all of the original claims and adding claims for declaratory judgments of invalidity of the nine patents that are subject to declaratory judgment claims in the original complaint, adding new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for nine more patents. Apple also added claims for declaratory judgments that certain of the Company’s agreements are unenforceable. On July 21, 2017, the Company filed an Answer to Apple’s Amended Complaint as well as a motion to dismiss the new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for the nine additional patents. The court granted the Company’s motion on November 8, 2017. On July 18, 2017, Apple filed a motion to consolidate this action with QUALCOMM Incorporated v. Compal Electronics, Inc., et al., discussed below, and on September 13, 2017, the court granted that motion. Fact discovery is set to close in these cases on May 11, 2018. A final pretrial conference is scheduled for September 28, 2018. The trials have not been scheduled.

[0001728949-18-000039:notes:19]
On January 23, 2017, an Apple subsidiary in China filed two complaints against the Company in the Beijing Intellectual Property Court. On March 31, 2017, the court granted an application by Apple Inc. to join the actions as a plaintiff, and Apple amended the complaints. One of the complaints alleges a violation of China’s Anti-Monopoly Law (AML complaint); the other complaint requests a determination of the terms of a patent license between the Company and Apple (FRAND complaint). The AML complaint alleges that (i) the Company has abused its dominant position in communication standard-essential patents licensing markets and certain global baseband chipset markets by charging and offering royalty terms that were excessively high; (ii) the Company refused to license certain implementers of standardized technologies, including Apple and baseband chipset manufacturers; (iii) the Company forced Apple to use only the Company’s products and services; and (iv) the Company bundled licenses to standard-essential patents with licenses to non-standard-essential patents and imposed other unreasonable or discriminatory trading terms on Apple in violation of the AML. The AML complaint seeks a decree that the Company cease the alleged abuse of dominance, as well as damages in the amount of 1 billion Chinese Renminbi (approximately $158 million based on the exchange rate on March 25, 2018). The FRAND complaint makes allegations similar to the AML complaint and further alleges that the Company refused to offer licensing terms for the Company’s cellular standard-essential patents consistent with the Company’s FRAND licensing commitments and failed to provide to Apple certain information about the Company’s patents. The FRAND complaint seeks (i) a declaration that the license terms offered to Apple by the Company for its mobile communication standard essential patents are not compliant with FRAND; (ii) an order that the Company cease its actions that allegedly violate the Company’s FRAND obligations, including pricing on unfair, unreasonable and excessive terms, refusing to deal, imposing unreasonable trade conditions and failing to provide information on the Company’s patents; and (iii) a determination of FRAND-compliant license terms for the Company’s Chinese standard-essential patents. Apple also seeks its expenses in each of the cases. On August 3, 2017, the Company received three additional complaints filed by an Apple subsidiary and Apple Inc. against the Company in the Beijing Intellectual Property Court. The complaints seek declaratory judgments of non-infringement of three Qualcomm patents. The Company has filed jurisdictional and other objections to the complaints.

[0001728949-18-000039:notes:20]
On February 16, 2017, Apple and one of its Japanese subsidiaries filed four complaints against the Company in the Tokyo District Court. In three of the complaints, Apple seeks declaratory judgment of non-infringement by Apple of three of the Company’s patents. Apple further seeks a declaration that the Company’s patent rights with respect to those three patents are exhausted by the Company’s SULAs with the contract manufacturers of Apple’s devices as well as the Company’s sale of baseband chipsets. Apple also seeks an award of fees. On January 30, 2018, the court dismissed one of the complaints, finding that Apple lacked standing based on the facts it alleged in that complaint. The court has yet to rule on whether Apple has standing in the remaining complaints. On May 15, 2017, the Company learned of the fourth complaint. In that complaint, Apple and one of its Japanese subsidiaries seek damages of 100 million Japanese Yen (approximately $1 million based on the exchange rate on March 25, 2018) from the Company, based on allegations that the Company violated the Japanese Antimonopoly Act and the Japanese Civil Code. In particular, the fourth complaint alleges that (i) the Company holds a monopoly position in the market for baseband processor chipsets that implement certain cellular standards; (ii) the Company collects double royalties through its license agreements and the sale of chipsets; (iii) the Company refused to grant Apple a license on FRAND terms and forced Apple to execute a rebate agreement under unreasonable conditions; (iv) the Company refused to grant Apple a direct license; and (v) the Company demanded a license fee based on the market value of the total device. The Company has filed jurisdictional and other objections to all four of the complaints.

[0001728949-18-000039:notes:21]
On March 2, 2017, the Company learned that Apple and certain of its European subsidiaries issued a Claim Form against the Company in the UK High Court of Justice, Chancery Division, Patents Court on January 23, 2017. Apple subsequently filed an Amended Claim Form and Particulars of Claim. Both the Amended Claim Form and the Particulars of Claim allege several European competition law claims, including refusal to license competing chipmakers, failure to offer Apple a direct license to the Company’s standard-essential patents on FRAND terms, demanding excessive royalties for the Company’s standard-essential patents, and demanding excessive license fees for the use of the Company’s standard-essential patents in connection with chipsets purchased from the Company. Apple also seeks declarations that the Company is obliged to offer a direct patent license to Apple in respect of standard-essential patents actually practiced on fair, reasonable and non-discriminatory terms and that using the Company’s chipsets does not infringe any of the Company’s patents because the Company exhausted its patent rights. Finally, Apple seeks declarations that five of the Company’s European (UK) patents are invalid and not essential, and an order that each of those patents be revoked.

[0001728949-18-000039:notes:22]
On April 18, 2017, Apple and one of its Taiwanese subsidiaries filed a complaint against the Company in the Taiwan Intellectual Property Court alleging that the Company has abused a dominant market position in licensing wireless standard-essential patents and selling baseband chipsets, including improper pricing, refusal to deal, exclusive dealing, tying, imposing unreasonable trade terms and discriminatory treatment. The complaint seeks rulings that the Company not use the sales price of the terminal device as the royalty base for standard-essential patents; not leverage its cellular standard-essential patents to obtain licenses of its non-standard-essential patents or demand cross-licenses without proper compensation; not refuse, reduce, delay or take any other action to limit the supply of its baseband chipsets to non-licensees; that the Company must license its standard-essential patents on FRAND terms; and that the Company shall not, based on standard-essential patents, seek injunctions. The complaint also seeks damages of 10 million Taiwan Dollars (less than $1 million based on the exchange rate on March 25, 2018), among other relief.

[0001728949-18-000039:notes:23]
On November 30, 2017, Apple and certain of its Chinese subsidiaries filed three patent infringement complaints against the Company in the Beijing Intellectual Property Court. Apple seeks damages and costs. The Company has filed jurisdictional objections to the complaints.

[0001728949-18-000039:notes:24]
The Company believes Apple’s claims in the above matters are without merit.

[0001728949-18-000039:notes:25]
QUALCOMM Incorporated v. Compal Electronics, Inc. et al.: On May 17, 2017, the Company filed a complaint in the United States District Court for the Southern District of California against Compal Electronics, Inc. (Compal), FIH Mobile, Ltd., Hon Hai Precision Industry Co., Ltd. (together with FIH Mobile, Ltd., Foxconn), Pegatron Corporation (Pegatron) and Wistron Corporation (Wistron) asserting claims for injunctive relief, specific performance, declaratory relief and damages stemming from the defendants’ breach of contracts by ceasing the payment of royalties for iPhones and other devices which they manufacture for Apple. On July 17, 2017, Compal, Foxconn, Pegatron and Wistron each filed third-party complaints for contractual indemnity against Apple seeking to join Apple as a party to the action. On July 18, 2017, Apple filed an answer to these third-party complaints acknowledging its indemnity agreements and consenting to be joined. On July 18, 2017, the defendants filed an Answer and Counterclaims to the complaint, asserting defenses and counterclaims similar to allegations previously made by Apple in the Apple Inc. v. QUALCOMM Incorporated case in the Southern District of California discussed above. In addition, the defendants asserted certain new claims, including claims under Section 1 of the Sherman Act and California’s Cartwright Act. The defendants seek damages, declaratory relief, injunctive relief, restitution of certain royalties and other relief. On July 18, 2017, Apple filed a motion to consolidate this action with the Apple Inc. v. QUALCOMM Incorporated case in the Southern District of California. On September 13, 2017, the court granted Apple’s consolidation motion. Fact discovery is set to close in these cases on May 11, 2018. A final pretrial conference is scheduled for September 28, 2018. No trial date has been set.

[0001728949-18-000039:notes:26]
The Company believes Compal’s, Foxconn’s, Pegatron’s and Wistron’s claims in the above matter are without merit.

[0001728949-18-000039:notes:27]
QUALCOMM Incorporated v. Apple Inc.: On July 6, 2017, the Company filed a complaint against Apple in the United States District Court for the Southern District of California asserting claims for damages and injunctive relief for infringement of six of the Company’s patents directed to a variety of features found in iPhone models. On July 7, 2017, the Company filed a complaint against Apple in the United States International Trade Commission (ITC) requesting that the ITC institute an investigation pursuant to Section 337 of the Tariff Act of 1930 based on Apple’s infringement of the same six patents. The Company is seeking a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple filed an Answer and Counterclaims in the District Court case on September 26, 2017. On November 29, 2017, Apple filed a First Amended Answer and Counterclaims asserting that the Company’s Snapdragon processors infringe eight Apple patents. On August 8, 2017, the ITC issued a notice of institution of an investigation. On August 25, 2017, the Company withdrew allegations as to one patent in both the ITC investigation and the District Court case. On April 25, 2018, the Company withdrew allegations as to two additional patents in the ITC investigation, but not the district court case, in order to satisfy certain briefing limitations and to narrow the issues for hearing. The ITC investigation is scheduled for evidentiary hearing by the Administrative Law Judge (ALJ) from June 18-26, 2018.  The ALJ’s Initial Determination on the merits is due on September 14, 2018, and the target date for final determination by the ITC is set for January 14, 2019. A case management conference in the district court case was held on January 26, 2018. On March 2, 2018, the court granted the Company’s motion to sever, for separate trial, Apple’s counterclaims for patent infringement against the Company. With respect to the Company’s patent claims against Apple, fact discovery is scheduled to close on June 11, 2018 and trial is scheduled to begin on March 4, 2019. With respect to Apple’s patent claims against the Company, fact discovery is scheduled to close on December 3, 2018, and trial is scheduled to begin on July 15, 2019.

[0001728949-18-000039:notes:28]
On November 1, 2017, the Company filed a complaint against Apple in San Diego Superior Court for breach of the Master Software Agreement between the companies. The complaint recounts instances when Apple failed to protect the Company’s software as required by the agreement and failed to provide sufficient information to which the Company is entitled under the agreement in order to understand whether other breaches have occurred. The complaint seeks specific performance of Apple’s obligations to cooperate with an audit of its handling of the Company’s software, damages and injunctive relief. Apple filed its Answer to the Complaint on December 29, 2017. A case management conference is scheduled for July 20, 2018. No trial date has been set.

[0001728949-18-000039:notes:29]
On November 29, 2017, the Company filed three additional complaints against Apple in the United States District Court for the Southern District of California alleging infringement of a total of 16 of the Company’s patents. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. The complaints seek damages and injunctive relief. On January 22, 2018, Apple filed Answers and Counterclaims in each of these cases seeking declaratory judgments that the asserted patents are invalid and/or not infringed. Case management conferences were held on February 7, 2018 and March 1, 2018. Tutorials and presentation of claim construction arguments for two of the cases are scheduled for September 10 and 11, 2018 and October 10 and 11, 2018, respectively. For the case relating to the November 30, 2017 ITC investigation described below, a mandatory settlement conference is scheduled for October 19, 2018, fact discovery is scheduled to close on March 13, 2019, and trial is scheduled to begin on October 21, 2019. No trial date has been set for the other two cases.

[0001728949-18-000039:notes:30]
On November 30, 2017, the Company filed a complaint in the ITC accusing certain Apple products of infringing five of the Company’s patents. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. The Company seeks a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor. On January 2, 2018, the ITC instituted an investigation. The ITC investigation is scheduled for evidentiary hearing by the Administrative Law Judge (ALJ) from September 17 through 21, 2018. The ALJ’s Initial Determination on the merits is due on January 22, 2019, and the target date for final determination by the ITC is set for May 22, 2019.

[0001728949-18-000039:notes:31]
On July 17, 2017, the Company filed complaints against Apple and certain of its subsidiaries in the Federal Republic of Germany, asserting infringement of one of the Company’s patents in the Mannheim District Court and infringement of another patent in the Munich District Court. On October 2, 2017, the Company filed claim extensions in these actions against Apple and certain of its subsidiaries, asserting infringement of two additional patents in the Mannheim District Court and infringement of five additional patents in the Munich District Court. The complaints seek remedies including, among other relief, declaratory relief confirming liability on the merits for damages and injunctive relief. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

[0001728949-18-000039:notes:32]
On September 29, 2017, the Company filed three complaints against Apple and certain of its subsidiaries in the Beijing (China) Intellectual Property Court, asserting infringement of three of the Company’s patents.  The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

[0001728949-18-000039:notes:33]
On November 13, 2017, the Company filed three complaints against certain of Apple’s subsidiaries in the Beijing (China) High People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief, damages and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On December 19, 2017, Apple’s subsidiaries filed invalidation requests with the Chinese Patent Review Board (PRB) for each of the three asserted patents. PRB hearings regarding the validity of the patents are scheduled for April and May 2018.

[0001728949-18-000039:notes:34]
On November 15, 2017, the Company filed three complaints against certain of Apple’s subsidiaries in the Fuzhou (China) Intermediate People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. The court has set hearings on the merits of infringement to begin on August 16, 2018 for one of the cases and August 18, 2018 for the other two cases. Apple’s subsidiaries filed invalidation requests with the Chinese Patent Review Board (PRB) on December 8, 2017 for one of the patents and December 11, 2017 for the other two patents. PRB hearings regarding the validity of the patents are scheduled for April and May 2018.

[0001728949-18-000039:notes:35]
On January 12, 2018, the Company filed three additional complaints against Apple and certain of its subsidiaries in the Fuzhou (China) Intermediate People’s Court, asserting infringement of three additional Company patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

[0001728949-18-000039:notes:36]
Also on January 12, 2018, the Company filed three complaints against certain of Apple’s subsidiaries in the Jiangsu (China) High People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief, damages and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On February 5, 2018 and March 5, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents are expected to begin in June 2018.

[0001728949-18-000039:notes:37]
On February 2, 2018, the Company filed three additional complaints against certain of Apple’s subsidiaries in the Qingdao (China) Intermediate People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On February 26, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents are expected to begin in June 2018.

[0001728949-18-000039:notes:38]
Also on February 2, 2018, the Company filed three additional complaints against certain of Apple’s subsidiaries in the Guangzhou (China) Intermediate People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On March 14, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents are expected to begin in July 2018.

[0001728949-18-000039:notes:39]
The Company believes Apple’s counterclaims and invalidation requests in the above matters are without merit.

[0001728949-18-000039:notes:40]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, plaintiffs filed a securities class action complaint against the Company and certain of its current and former officers in the United States District Court for the Southern District of California. On April 29, 2016, plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, plaintiffs filed a second amended complaint, alleging that the Company and certain of its current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding the Company’s business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint sought unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, the Company filed a motion to dismiss the second amended complaint. On October 20, 2017, the court entered an order granting in part the Company’s motion to dismiss, and on November 29, 2017, the court entered an order granting the remaining portions of the Company’s motion to dismiss. On December 28, 2017, the plaintiffs filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit. The Company believes the plaintiffs’ claims are without merit.

[0001728949-18-000039:notes:41]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of the Company in the United States District Court for the Southern District of California against the Company and certain of its current and former officers and directors. The complaints alleged, among other things, that the defendants violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that the Company is or was engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, the defendants filed a motion to dismiss the consolidated amended complaint. The court has not yet ruled on the motion. The Company believes the plaintiffs’ claims are without merit.

[0001728949-18-000039:notes:42]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against the Company in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Twenty-two such cases remain outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel, and on May 25, 2017, set a trial date of April 29, 2019. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that the Company violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to its competitors, conditioning the supply of certain of its baseband chipsets on the purchaser first agreeing to license the Company’s entire patent portfolio, entering into exclusive deals with companies including Apple Inc., and charging unreasonably high royalties that do not comply with the Company’s commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that the Company be enjoined from further unlawful conduct. On August 11, 2017, the Company filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied the Company’s motion to dismiss the consolidated amended complaint, except to the extent that certain claims seek damages under the Sherman Antitrust Act. Trial is scheduled to begin on January 19, 2019. The Company believes the plaintiffs’ claims are without merit.

[0001728949-18-000039:notes:43]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, five consumer class action complaints have been filed against the Company in Canada alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the FTC and U.S. consumer class action complaints. The complaints seek unspecified damages. The Company has not yet answered the complaints.

[0001728949-18-000039:notes:44]
Hays v. Jacobs, et. al.: On May 24, 2017, the plaintiff filed a complaint in the United States District Court for the District of Delaware asserting derivative claims on behalf of the Company against certain of the Company’s current and former directors and officers. On November 13, 2017, the plaintiff filed an amended derivative complaint alleging that certain current and former directors and officers (i) breached their fiduciary duties by failing to oversee the Company’s operations, (ii) breached their fiduciary duties and Section 14(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding the Company’s business outlook, business practices and product development between November 6, 2013 and January 21, 2016 and (iii) were unjustly enriched as a result of the foregoing conduct. The amended complaint sought unspecified damages, interest, attorneys’ fees and other costs. The defendants filed a Motion to Dismiss the amended complaint, which was scheduled for hearing by the court on March 14, 2018. The parties filed a Joint Stipulation for Voluntary Dismissal and Proposed Order (the Order), which the court granted on March 9, 2018. Accordingly, the case has been dismissed, and the Order required this disclosure in this filing.

[0001728949-18-000039:notes:45]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 37 different dates. No further hearings are currently scheduled. Fines or other monetary remedies are not available in this matter.

[0001728949-18-000039:notes:46]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments since then with respect to this matter.

[0001728949-18-000039:notes:47]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it was conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that the Company violated provisions of the MRFTA. On January 22, 2017, the Company received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with the Company; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders the Company to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chips; (iii) not demand unjustifiable conditions in the Company’s license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on the Company and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between the Company and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred to in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred to in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of approximately 1.03 trillion Korean Won (approximately $927 million), which was paid on March 30, 2017. The Company believes that its business practices do not violate the MRFTA, and on February 21, 2017 filed an action in the Seoul High Court to cancel the KFTC’s decision. On the same day, the Company filed an application with the Seoul High Court to stay the decision’s remedial order pending the Seoul High Court’s final judgment on the Company’s action to cancel the KFTC’s decision. On September 4, 2017, the Seoul High Court denied the Company’s application to stay the remedial order, and on November 27, 2017, the Korea Supreme Court dismissed the Company’s appeal of the Seoul High Court’s decision on the application to stay. The Seoul High Court has not ruled on the Company’s action to cancel the KFTC’s decision.

[0001728949-18-000039:notes:48]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided the Company with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the EC to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company provided additional documents and information as requested by the EC. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On August 15, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. The Company believes that its business practices do not violate the European Union (EU) competition rules.

[0001728949-18-000039:notes:49]
European Commission (EC) Investigation: On October 15, 2014, the EC notified the Company that it was conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that pursuant to an agreement with a customer, since 2011 the Company paid significant amounts to that customer on condition that it exclusively use the Company’s baseband chipsets in its smartphones and tablets. This conduct allegedly reduced the customer’s incentives to source chipsets from the Company’s competitors and harmed competition and innovation for certain baseband chipsets. On January 24, 2018, the EC issued a decision finding that certain terms of that agreement violate EU competition law and imposed a fine of approximately 997 million Euros. On April 6, 2018, the Company filed an appeal of the EC’s decision with the General Court of the European Union. The Company believes that its business practices do not violate the EU competition rules.

[0001728949-18-000039:notes:50]
The Company recorded a charge of $1.18 billion to other expenses related to the EC fine in the first quarter of fiscal 2018. The Company intends to provide financial guarantees by April 30, 2018 to satisfy the obligation in lieu of cash payment while the Company appeals the EC’s decision. Beginning on April 30, 2018, the fine will accrue interest at a rate of 1.50% per annum until it has been paid or annulled. At March 25, 2018, the liability, including related foreign currency losses (which were recorded in investment and other income, net), was $1.23 billion and included in other current liabilities.

[0001728949-18-000039:notes:51]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against the Company in the United States District Court for the Northern District of California alleging that the Company engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of baseband processors on the purchaser first agreeing to a license to the Company’s standard-essential patents, paying incentives to purchasers of baseband processors to induce them to accept certain license terms, refusing to license its standard-essential patents to the Company’s competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint seeks a permanent injunction against the Company’s alleged violations of the FTCA and other unspecified ancillary equitable relief. A fine is not an available remedy in this matter, and the Company does not believe that other monetary remedies are likely in this matter. On April 19, 2017, the court set a trial date for January 4, 2019. The Company believes the FTC’s claims are without merit.

[0001728949-18-000039:notes:52]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified the Company that it was conducting an investigation into whether the Company’s patent licensing practices violate the Taiwan Fair Trade Act (TFTA). On April 27, 2016, the TFTC specified that the allegations under investigation included whether: (i) the Company jointly licensed its patents rather than separately licensing standard-essential patents and non-standard-essential patents; (ii) the Company’s royalty charges are unreasonable; (iii) the Company unreasonably required licensees to grant it cross-licenses; (iv) the Company failed to provide lists of licensed patents to licensees; (v) the Company violated a FRAND licensing commitment by declining to grant licenses to chipset makers; (vi) the Company declined to sell chipsets to unlicensed potential customers; and (vii) the Company provided royalty rebates to certain companies in exchange for their exclusive use of the Company’s chipsets. On October 11, 2017, the TFTC announced that it had reached a decision in the investigation, finding that the Company violated the TFTA. On October 23, 2017, the Company received TFTC’s formal written decision, which found that the following conducts violate the TFTA: (i) refusing to license and demanding restrictive covenants from chip competitors; (ii) refusing to supply baseband processors to companies that do not have an executed license; and (iii) providing a royalty discount to Apple in exchange for its exclusive use of the Company’s chipsets. The TFTC’s decision orders the Company to: (1) cease the following conduct within 60 days of the day after receipt of the decision: (a) applying the clauses in an agreement entered into with a competing chip supplier requesting it to provide sensitive sales information such as chip prices, customers, sales volumes, product types and serial numbers; (b) applying clauses in component supply agreements entered into with handset manufacturers relating to the refusal to sell chips to unlicensed manufacturers; and (c) applying discount clauses in the exclusive agreement entered into with a relevant enterprise; (2) notify competing chip companies and handset manufacturers in writing within 30 days after receipt of the decision that those companies may request to amend or enter into patent license agreements and other relevant agreements within 60 days of the day following the day such notices are received, and upon receipt of such requests, the Company shall commence negotiation in good faith; (3) submit status reports to the TFTC on any such negotiations every six months beginning from the day after receipt of the decision, as well as to submit a report to the TFTC within 30 days after amendments to any license agreements or newly signed license agreements are executed. The TFTC’s decision also imposed a fine of 23.4 billion Taiwan Dollars.  The Company believes that its business practices do not violate the TFTA, and on November 10, 2017, the Company filed an Application for Stay of Enforcement of the TFTC’s decision in the Taiwan Intellectual Property Court (IPC). The TFTC filed an opposition brief on December 8, 2017, and the IPC held a hearing on December 11, 2017. The IPC has not yet ruled on the Company’s Application. On December 22, 2017, the Company filed an Administrative Litigation Complaint in the IPC to revoke the TFTC’s decision. The TFTC has not yet filed its response.

[0001728949-18-000039:notes:53]
The Company recorded a charge of $778 million to other expenses related to the TFTC fine in the fourth quarter of fiscal 2017. The fine will be paid in monthly installments through December 2022. At March 25, 2018, the remaining liability, including related foreign currency losses (which were recorded in investment and other income, net), was approximately $771 million, of which $615 million was included in other noncurrent liabilities.

[0001728949-18-000039:notes:54]
Contingent losses: The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. Other than with respect to the TFTC and EC fines, the Company has not recorded any accrual at March 25, 2018 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001728949-18-000039:notes:55]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company, or by intellectual property provided by the Company to chipset foundries and semiconductor assembly and test service providers. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0001728949-18-000039:notes:56]
Through March 25, 2018, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at March 25, 2018 associated with these indemnification arrangements based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001728949-18-000039:notes:57]
Purchase Obligations and Operating Leases. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

[0001728949-18-000039:notes:58]
The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases.

[0001728949-18-000039:notes:59]
Obligations under these purchase agreements and future minimum lease payments under these operating leases at March 25, 2018 were as follows:

[0001728949-18-000039:notes:60]
|  | Integrated Circuit Purchase Obligations |  | Other Purchase Obligations |  | Operating Leases |
| Remainder of fiscal 2018 | $ | 2,277 |  |  | $ | 894 |  |  | $ | 63 |  |
| 2019 | 1,074 |  |  | 286 |  |  | 114 |  |
| 2020 | 318 |  |  | 165 |  |  | 85 |  |
| 2021 | 63 |  |  | 60 |  |  | 64 |  |
| 2022 | 24 |  |  | 12 |  |  | 44 |  |
| Thereafter | — |  |  | 4 |  |  | 57 |  |
| Total | $ | 3,756 |  |  | $ | 1,421 |  |  | $ | 427 |  |

[0001728949-18-000039:notes:61]
Other Commitments. At March 25, 2018, the Company was committed to fund certain strategic investments up to $414 million, of which $77 million and $72 million is expected to be funded in the remainder of fiscal 2018 and in fiscal 2021, respectively. The remaining commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all.

[0001728949-18-000039:notes:62]
In March 2018, the Company’s RF360 Holdings joint venture entered into an agreement for a build-to-suit construction project with a third-party lessor for the development of a manufacturing facility located in Singapore. The agreement includes a long-term lease commitment with a noncancelable 10-year term commencing upon completion of the construction project and four optional renewal terms of five years each. At March 25, 2018, the minimum lease commitment under the agreement based on the noncancelable term was approximately $90 million and the maximum lease commitment, including all optional renewal terms, was approximately $315 million.


## us-gaap:DebtDisclosureTextBlock

[0001728949-18-000039:notes:63]
Debt

[0001728949-18-000039:notes:64]
Revolving Credit Facilities. The Company has an Amended and Restated Revolving Credit Facility (2016 Amended and Restated Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. Proceeds from the 2016 Amended and Restated Revolving Credit Facility are expected to be used for general corporate purposes. At March 25, 2018 and September 24, 2017, the Company had not borrowed any funds under the 2016 Amended and Restated Revolving Credit Facility.

[0001728949-18-000039:notes:65]
In March 2018, the Company entered into a credit agreement, which was amended on April 20, 2018 in connection with Amendment No. 2 to the NXP purchase agreement (Amendment No. 2) (Note 8), that provides for senior unsecured delayed-draw revolving facility loans in an aggregate amount of $3.0 billion (as amended, the 2018 Revolving Credit Facility). Proceeds from the 2018 Revolving Credit Facility, if drawn, will be used in part to finance the proposed acquisition of NXP (Note 8) and for general corporate purposes. Commitments under the 2018 Revolving Credit Facility will expire on the first to occur of (i) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP, (ii) if the closing date under the 2018 Revolving Credit Facility has not occurred, the date that is five business days following July 25, 2018 and (iii) the termination of the commitments in accordance with the provisions of the 2018 Revolving Credit Facility providing for voluntary and mandatory commitment reductions. Loans under the 2018 Revolving Credit Facility will mature on December 31, 2018 and will bear interest, at the option of the Company, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the 2018 Revolving Credit Facility) or the Base Rate (determined in accordance with the 2018 Revolving Credit Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate based on Qualcomm’s debt ratings as of March 25, 2018 will be 0.75% and 0.00% per annum, respectively. The 2018 Revolving Credit Facility has a ticking fee, which is based on Qualcomm’s debt ratings and initially accrues at a rate of 0.05% per annum commencing on March 6, 2018. At March 25, 2018, the Company had not borrowed any funds under the 2018 Revolving Credit Facility.

[0001728949-18-000039:notes:66]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At March 25, 2018 and September 24, 2017, the Company had $2.2 billion and $999 million, respectively, of outstanding commercial paper included in short-term debt with a weighted-average interest rate of 1.98% and 1.19%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 44 days and 45 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at March 25, 2018 and September 24, 2017.

[0001728949-18-000039:notes:67]
Term Loan Facilities. The Company is party to a credit agreement, which was amended on April 20, 2018, in connection with Amendment No. 2, that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion (as amended, the 2016 Term Loan Facility). Proceeds from the 2016 Term Loan Facility, if drawn, will be used to finance the proposed acquisition of NXP. Commitments under the 2016 Term Loan Facility will expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the 2016 Term Loan Facility, (ii) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP and (iii) the date that is five business days following July 25, 2018. At March 25, 2018 and September 24, 2017, the Company had not borrowed any funds under the 2016 Term Loan Facility.

[0001728949-18-000039:notes:68]
In March 2018, the Company entered into a credit agreement, which was amended on April 20, 2018 in connection with Amendment No. 2, that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $3.0 billion (as amended, the 2018 Term Loan Facility). Proceeds from the 2018 Term Loan Facility, if drawn, will be used in part to finance the proposed acquisition of NXP and for general corporate purposes. Commitments under the 2018 Term Loan Facility will expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the 2018 Term Loan Facility, (ii) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP, (iii) the date that is five business days following July 25, 2018 and (iv) the termination of the commitments in accordance with the provisions of the 2018 Term Loan Facility providing for voluntary and mandatory commitment reductions. Loans under the 2018 Term Loan Facility will mature on December 31, 2018 and will bear interest, at the option of the Company, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the 2018 Term Loan Facility) or the Base Rate (determined in accordance with the 2018 Term Loan Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate based on Qualcomm’s debt ratings as of March 25, 2018 will be 0.875% and 0.00% per annum, respectively. The 2018 Term Loan Facility has a ticking fee, which is based on Qualcomm’s debt ratings and initially accrues at a rate of 0.05% per annum commencing on March 6, 2018. At March 25, 2018, the Company had not borrowed any funds under the 2018 Term Loan Facility.

[0001728949-18-000039:notes:69]
Long-term Debt. The following table provides a summary of the Company’s long-term debt (in millions, except percentages):

[0001728949-18-000039:notes:70]
|  |  | March 25, 2018 |  | September 24, 2017 |
|  |  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.27% notes due May 18, 2018 | $ | 250 |  |  | 2.21% |  | $ | 250 |  |  | 1.65% |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | 250 |  |  | 2.49% |  | 250 |  |  | 1.92% |
|  | Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 2.94% |  | 1,250 |  |  | 1.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 2.79% |  | 1,750 |  |  | 2.20% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 3.34% |  | 2,000 |  |  | 2.65% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.36% notes due May 20, 2019 | 750 |  |  | 2.37% |  | 750 |  |  | 1.80% |
|  | Floating-rate three-month LIBOR plus 0.45% notes due May 20, 2020 | 500 |  |  | 2.43% |  | 500 |  |  | 1.86% |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 2.56% |  | 500 |  |  | 2.11% |
|  | Fixed-rate 1.85% notes due May 20, 2019 | 1,250 |  |  | 2.00% |  | 1,250 |  |  | 2.00% |
|  | Fixed-rate 2.10% notes due May 20, 2020 | 1,500 |  |  | 2.19% |  | 1,500 |  |  | 2.19% |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | 1,500 |  |  | 2.70% |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | 1,500 |  |  | 3.01% |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.47% |  | 1,500 |  |  | 4.47% |
| Total principal | 21,000 |  |  |  |  | 21,000 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (97 | ) |  |  |  | (106 | ) |  |  |
|  | Hedge accounting fair value adjustments | (43 | ) |  |  |  | — |  |  |  |
|  | Total | $ | 20,860 |  |  |  |  | $ | 20,894 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | 1,499 |  |  |  |  | $ | 1,496 |  |  |  |
|  | Long-term debt | 19,361 |  |  |  |  | 19,398 |  |  |  |
|  | Total | $ | 20,860 |  |  |  |  | $ | 20,894 |  |  |  |

[0001728949-18-000039:notes:71]
The Company’s 2019 floating-rate notes, 2020 floating-rate notes, 2019 fixed-rate notes and 2020 fixed-rate notes issued in May 2017 for an aggregate principal amount of $4.0 billion are subject to a special mandatory redemption at a price equal to 101% of the aggregate principal amount, plus accrued and unpaid interest to, but excluding, the date of such mandatory redemption. The redemption is required on the first to occur of (i) the termination of the NXP purchase agreement or (ii) if the NXP transaction has not closed, by June 1, 2018. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the other floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of the Company’s other senior unsecured indebtedness and will effectively rank junior to all liabilities of the Company’s subsidiaries. At March 25, 2018 and September 24, 2017, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $20.5 billion and $21.5 billion, respectively.

[0001728949-18-000039:notes:72]
In connection with issuance of the May 2015 Notes, the Company entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recorded in earnings in interest expense in the current period. The Company did not enter into similar interest rate swaps in connection with issuance of the May 2017 Notes.

[0001728949-18-000039:notes:73]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $317 million and $150 million in the six months ended March 25, 2018 and March 26, 2017, respectively.

[0001728949-18-000039:notes:74]
Debt Covenants. The 2016 Amended and Restated Revolving Credit Facility, the 2016 Term Loan Facility, the 2018 Revolving Credit Facility and the 2018 Term Loan Facility require that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At March 25, 2018 and September 24, 2017, the Company was in compliance with the applicable covenants under each facility outstanding at such time.


## us-gaap:DividendsDeclaredTableTextBlock

[0001728949-18-000039:notes:75]
In the six months ended March 25, 2018 and March 26, 2017, dividends charged to retained earnings were as follows (in millions, except per share data):

[0001728949-18-000039:notes:76]
|  | 2018 |  | 2017 |
|  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.57 |  |  | $ | 862 |  |  | $ | 0.53 |  |  | $ | 801 |  |
| Second quarter | 0.57 |  |  | 857 |  |  | 0.53 |  |  | 798 |  |
|  | $ | 1.14 |  |  | $ | 1,719 |  |  | $ | 1.06 |  |  | $ | 1,599 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001728949-18-000039:notes:77]
Earnings (Loss) Per Common Share. Basic earnings (loss) per common share is computed by dividing net income (loss) attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans, if any, and the weighted-average number of common shares outstanding during the reporting period. Due to the net loss for the six months ended March 25, 2018, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share.


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-18-000039:notes:78]
[same as prior period, unchanged from 0001728949-18-000011:notes:71]

[0001728949-18-000039:notes:79]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at March 25, 2018 (in millions):

[0001728949-18-000039:notes:80]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 26,328 |  |  | $ | 10,573 |  |  | $ | — |  |  | $ | 36,901 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 10 |  |  | 2 |  |  | — |  |  | 12 |  |
| Corporate bonds and notes | — |  |  | 1,498 |  |  | — |  |  | 1,498 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 73 |  |  | 35 |  |  | 108 |  |
| Equity and preferred securities and equity funds | 40 |  |  | — |  |  | — |  |  | 40 |  |
| Total marketable securities | 50 |  |  | 1,573 |  |  | 35 |  |  | 1,658 |  |
| Derivative instruments | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Other investments | 408 |  |  | — |  |  | 13 |  |  | 421 |  |
| Total assets measured at fair value | $ | 26,786 |  |  | $ | 12,153 |  |  | $ | 48 |  |  | $ | 38,987 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 65 |  |  | $ | — |  |  | $ | 65 |  |
| Other liabilities | 408 |  |  | — |  |  | 194 |  |  | 602 |  |
| Total liabilities measured at fair value | $ | 408 |  |  | $ | 65 |  |  | $ | 194 |  |  | $ | 667 |  |

[0001728949-18-000039:notes:81]
Activity between Levels of the Fair Value Hierarchy. There were no transfers between Level 1 and Level 2 in the six months ended March 25, 2018 and March 26, 2017. There were no transfers of marketable securities into or out of Level 3 during the six months ended March 25, 2018 and March 26, 2017. Other investments and other liabilities included in Level 3 at March 25, 2018 were comprised of convertible debt instruments issued by private companies and contingent consideration related to business combinations, respectively. There were no transfers of convertible debt instruments or contingent consideration amounts into or out of Level 3 during the six months ended March 25, 2018 and March 26, 2017.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-18-000039:notes:82]
[same as prior period, unchanged from 0001728949-18-000011:notes:75]

[0001728949-18-000039:notes:83]
[same as prior period, unchanged from 0001728949-18-000011:notes:76]

[0001728949-18-000039:notes:84]
Pursuant to the Securities and Exchange Commission Staff Accounting Bulletin No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act (SAB 118), given the amount and complexity of the changes in tax law resulting from the Tax Legislation, the Company has not finalized the accounting for the income tax effects of the Tax Legislation. This includes the provisional amounts recorded related to the Toll Charge, the remeasurement of deferred taxes and the change in the Company’s indefinite reinvestment assertion. Further, the Company is in the process of analyzing the effects of new taxes due on certain foreign income, such as GILTI (global intangible low-taxed income), BEAT (base-erosion anti-abuse tax) and FDII (foreign-derived intangible income), and limitations on interest expense deductions (if certain conditions apply), all of which are effective starting in fiscal 2019, as well as other provisions of the Tax Legislation. The Company has elected to account for GILTI as period costs if and when incurred. As a result of recognizing the impact of the Tax Legislation in income tax expense (benefit), certain tax effects, which were nominal, were stranded in accumulated other comprehensive income, and the Company will not reclassify such amounts to retained earnings. The impact of the Tax Legislation may differ from this estimate, possibly materially, during the one-year measurement period due to, among other things, further refinement of the Company’s calculations, changes in interpretations and assumptions the Company has made, guidance that may be issued and actions the Company may take as a result of the Tax Legislation.

[0001728949-18-000039:notes:85]
The Company has preliminarily accounted for the effects of the Tax Legislation, which resulted in a charge of $5.87 billion to income tax expense recorded discretely in the first quarter of fiscal 2018, comprised of $5.3 billion related to the estimated Toll Charge and $562 million resulting from the estimated impact of remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate. The Company recorded a $15 million net tax benefit discretely in the second quarter of fiscal 2018 related to refining estimates associated with the Toll Charge and impact of remeasurement of U.S. deferred tax assets and liabilities.

[0001728949-18-000039:notes:86]
The Toll Charge is based on the Company’s post-1986 earnings and profits of U.S.-owned foreign subsidiaries through December 31, 2017 for which the Company had previously deferred U.S. income taxes. The total estimated Toll Charge of $5.3 billion was recorded discretely in the first six months of fiscal 2018. The Company has not yet finalized its calculation of the total post-1986 foreign earnings and profits for the respective foreign subsidiaries. Further, the Toll Charge is based in part on the amount of those earnings held in cash and other specific assets. The Company remeasured its deferred tax assets and liabilities that existed at the end of fiscal 2017 based on the income tax rate at which they are expected to reverse, which primarily assumes the reduced income tax rate of 21% applicable in fiscal 2019, resulting in a reduction to noncurrent deferred tax assets of $540 million in the first six months of fiscal 2018.

[0001728949-18-000039:notes:87]
As of December 24, 2017, the Company no longer considers available cash balances that existed at the end of fiscal 2017 related to undistributed pre-fiscal 2018 earnings and profits of certain U.S.-owned foreign subsidiaries to be indefinitely reinvested and recorded a tax expense of $93 million related to foreign withholding taxes during the first six months of fiscal 2018, of which $86 million was recorded discretely in the first quarter of fiscal 2018. The Company otherwise continues to consider other undistributed earnings of certain U.S.-owned foreign subsidiaries to be indefinitely reinvested based on its current plans for use and/or investment outside of the U.S., and therefore, no liability has been recorded for such taxes. However, as a result of the Tax Legislation, the Company is reassessing its intentions related to its indefinite reinvestment assertion. Should the Company decide to no longer indefinitely reinvest such earnings outside the U.S., the Company would have to adjust the income tax provision in the period such determination is made.

[0001728949-18-000039:notes:88]
As a result of the Toll Charge imposed by the Tax Legislation, the Company expects to fully utilize all of its unused federal tax credits that existed at the end of fiscal 2017 of $1.1 billion, which resulted in a reduction to noncurrent deferred tax assets in the first quarter of fiscal 2018, and the federal tax credits that are expected to be generated in fiscal 2018. The Company will elect to pay the Toll Charge, interest free, over a period of eight years, with payments beginning on January 15, 2019. The Company did not discount the amount of the Toll Charge. The cash amount the Company currently estimates will be paid for the Toll Charge, net of tax credit carryforwards and expected tax credits estimated to be generated in fiscal 2018, is $3.2 billion. The estimated first installment of $251 million is due on January 15, 2019 and was included in other current liabilities. The remaining liability was included in noncurrent income taxes payable.

[0001728949-18-000039:notes:89]
The Company estimates its annual effective income tax rate to be approximately 438% for fiscal 2018, as compared to the 18% effective income tax rate for fiscal 2017, primarily as a result of the estimated charge of $5.95 billion recorded to income tax expense in the first six months of fiscal 2018 related to the combined effect of the Toll Charge, the remeasurement of deferred tax assets and liabilities and the Company’s decision to no longer indefinitely reinvest certain foreign earnings, all of which resulted from the Tax Legislation. The estimated annual effective tax rate for fiscal 2018 was also impacted by the EC fine (Note 6) recorded in the first quarter of fiscal 2018, which is not deductible for tax purposes and is attributable to a foreign jurisdiction. Tax benefits from foreign income taxed at rates lower than rates in the U.S. are expected to be approximately 31% in fiscal 2018, compared to 32% in fiscal 2017, primarily due to the lower U.S. federal statutory income tax rate enacted by the Tax Legislation, partially offset by lower estimated U.S. revenues primarily related to decreased royalty revenues from Apple’s contract manufacturers and the other licensee in dispute. The estimated annual effective tax rate for fiscal 2018 also reflects a blended U.S. federal statutory income tax rate of 25% as a result of the Tax Legislation and the increase in the Company’s Singapore tax rate due to the expiration of certain of its tax incentives in March 2017. The annual effective tax rate of 18% for fiscal 2017 reflected the KFTC and TFTC fines (Note 6), which were not deductible for tax purposes and were each attributable to the U.S. and foreign jurisdictions.

[0001728949-18-000039:notes:90]
The effective tax rate of 1% benefit for the second quarter of fiscal 2018 was lower than the estimated annual effective tax rate primarily due to the estimated charge of $5.96 billion recorded discretely to income tax expense in the first quarter of fiscal 2018 related to the effects of certain components of the Tax Legislation and the EC fine recorded in the first quarter of fiscal 2018, as well as the $15 million tax benefit recorded discretely in the second quarter of fiscal 2018 related to refining estimates associated with the Tax Legislation.

[0001728949-18-000039:notes:91]
Unrecognized tax benefits were $347 million and $372 million at March 25, 2018 and September 24, 2017, respectively. The Company believes that it is reasonably possible that the total amounts of unrecognized tax benefits at March 25, 2018 may increase or decrease in the next 12 months.

[0001728949-18-000039:notes:92]
The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions, and is currently under examination by various tax authorities worldwide, most notably in countries where the Company earns a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2000. The Company continually assesses the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of March 25, 2018, the Company believes that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in the Company’s income tax provision and the related accruals.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001728949-18-000039:notes:93]
[same as prior period, unchanged from 0001728949-18-000011:notes:86]

[0001728949-18-000039:notes:94]
|  | March 25, 2018 |
| Years to Maturity |  |
| Less than one year | $ | 610 |  |
| One to five years | 900 |  |
| Five to ten years | — |  |
| Greater than ten years | — |  |
| No single maturity date | 108 |  |
| Total | $ | 1,618 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-18-000039:notes:95]
Marketable Securities

[0001728949-18-000039:notes:96]
Marketable securities were comprised as follows (in millions):

[0001728949-18-000039:notes:97]
|  | Current |  | Noncurrent |
|  | March 25, 2018 |  | September 24, 2017 |  | March 25, 2018 |  | September 24, 2017 |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 12 |  |  | $ | 23 |  |  | $ | — |  |  | $ | 959 |  |
| Corporate bonds and notes | 1,498 |  |  | 2,014 |  |  | — |  |  | 271 |  |
| Mortgage- and asset-backed and auction rate securities | 73 |  |  | 93 |  |  | 35 |  |  | 40 |  |
| Equity and preferred securities and equity funds | 40 |  |  | 36 |  |  | — |  |  | — |  |
| Debt funds | — |  |  | 109 |  |  | — |  |  | — |  |
| Total available-for-sale | 1,623 |  |  | 2,275 |  |  | 35 |  |  | 1,270 |  |
| Time deposits | 2 |  |  | 4 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 1,625 |  |  | $ | 2,279 |  |  | $ | 35 |  |  | $ | 1,270 |  |

[0001728949-18-000039:notes:98]
Debt securities with no single maturity date included mortgage- and asset-backed securities and auction rate securities.

[0001728949-18-000039:notes:99]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001728949-18-000039:notes:100]
|  | For the three months ended |  | For the six months ended |
|  | March 25, 2018 |  | March 26, 2017 |  | March 25, 2018 |  | March 26, 2017 |
| Gross realized gains | $ | 11 |  |  | $ | 57 |  |  | $ | 13 |  |  | $ | 303 |  |
| Gross realized losses | — |  |  | — |  |  | — |  |  | (107 | ) |
| Net realized gains | $ | 11 |  |  | $ | 57 |  |  | $ | 13 |  |  | $ | 196 |  |

[0001728949-18-000039:notes:101]
Available-for-sale securities were comprised as follows (in millions):

[0001728949-18-000039:notes:102]
|  | March 25, 2018 |  | September 24, 2017 |
| Equity securities |  |  |  |
| Cost | $ | 8 |  |  | $ | 8 |  |
| Unrealized gains | 32 |  |  | 28 |  |
| Fair value | 40 |  |  | 36 |  |
| Debt securities (including debt funds) |  |  |  |
| Cost | 1,621 |  |  | 3,497 |  |
| Unrealized gains | 3 |  |  | 13 |  |
| Unrealized losses | (6 | ) |  | (1 | ) |
| Fair value | 1,618 |  |  | 3,509 |  |
|  | $ | 1,658 |  |  | $ | 3,545 |  |

[0001728949-18-000039:notes:103]
In connection with the proposed NXP transaction (Note 8), the Company divested a substantial portion of its marketable securities portfolio in order to finance, in part, that transaction. Marketable securities that are expected to be used to finance the NXP transaction were fully liquidated and classified as cash and cash equivalents at March 25, 2018. Given the Company’s intention to sell certain marketable securities, the Company recorded other-than-temporary impairment losses in fiscal 2017 for certain marketable securities and no additional losses were recorded in the six months ended March 25, 2018 (Note 2). For the available-for-sale securities that are not expected to be sold to finance the NXP transaction, the Company concluded that the unrealized losses were temporary at March 25, 2018. Further, for debt securities with unrealized losses, the Company did not have the intent to sell, nor was it more likely than not that the Company would be required to sell, such securities before recovery or maturity.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001728949-18-000039:notes:104]
Recent Accounting Pronouncements.

[0001728949-18-000039:notes:105]
Share-based Awards: In March 2016, the Financial Accounting Standards Board (FASB) issued new guidance that changed the accounting for share-based awards, including income taxes, classification of awards and classification in the statement of cash flows. The Company adopted the new guidance in the first quarter of fiscal 2018. In accordance with the new guidance, excess tax benefits or deficiencies associated with share-based awards are recognized through earnings when the awards vest or settle, rather than in stockholders’ equity. In the six months ended March 25, 2018, net excess tax benefits associated with share-based awards of $21 million were recognized in the Company’s income tax provision. In addition, cash flows related to excess tax benefits are presented as an operating activity and cash payments made on an employee’s behalf for withheld shares are presented as financing activities, with the prior periods adjusted accordingly. As a result of these changes, amounts for the six months ended March 26, 2017 have been adjusted as follows: net cash provided by operating activities increased by $212 million with a corresponding offset to net cash used in financing activities. The new guidance also impacts the Company’s earnings per share calculation as the estimate of dilutive common share equivalents under the treasury stock method no longer assumes that the estimated tax benefits realized when an award is settled are used to repurchase shares. There was no impact of this change on the Company’s calculation of earnings per share as a result of the net loss for the six months ended March 25, 2018. The Company elected to continue its practice of estimating forfeitures expected to occur in determining the amount of compensation cost to be recognized each period.

[0001728949-18-000039:notes:106]
Revenue Recognition: In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue as control of goods or services transfers to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The Company will adopt the new guidance in the first quarter of fiscal 2019 using the modified retrospective approach, with the cumulative effect of applying the new guidance recognized as an adjustment to the opening retained earnings balance. Given the scope of work required to implement the recognition and disclosure requirements under the new guidance, the Company has made progress in the identification of changes to policy, processes, systems and controls, and the Company continues to assess data availability and presentation necessary to meet the additional disclosure requirements of the guidance in the notes to the consolidated financial statements.

[0001728949-18-000039:notes:107]
The Company currently expects the adoption of this new guidance to most significantly impact its licensing business. Specifically, the Company expects a change in the timing of revenues recognized from sales-based royalties. The Company currently recognizes sales-based royalties as revenues in the period in which such royalties are reported by licensees, which is after the conclusion of the quarter in which the licensees’ sales occur and when all other revenue recognition criteria are met. Under the new guidance, the Company will be required to estimate and recognize sales-based royalties in the period in which the associated sales occur, resulting in an acceleration of revenue recognition compared to the current method. Upon adoption of the new guidance, licenses to use portions of the Company’s intellectual property portfolio will be considered one performance obligation, and license fees will be recognized as revenues on a straight-line basis over the term of the license agreement, which is similar to the recognition of license revenues under the current guidance. The Company currently accounts for customer incentive arrangements in its licensing and semiconductor businesses, including volume-related and other pricing rebates or cost reimbursements for marketing and other activities involving certain of the Company’s products and technologies, in part based on the maximum potential liability. Under the new guidance, the Company will estimate the amount of all customer incentives. The Company does not otherwise expect the adoption of the new guidance to have a material impact on its businesses.

[0001728949-18-000039:notes:108]
Financial Assets: In January 2016, the FASB issued new guidance on classifying and measuring financial instruments, which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk be recognized separately in other comprehensive income. Additionally, it changes the disclosure requirements for financial instruments. The Company will adopt the new guidance in the first quarter of fiscal 2019 and is in the process of determining the effects the adoption will have on its consolidated financial statements.

[0001728949-18-000039:notes:109]
In June 2016, the FASB issued new guidance that changes the accounting for recognizing impairments of financial assets. Under the new guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The new guidance also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The new guidance will be effective for the Company starting in the first quarter of fiscal 2021. Early adoption is permitted starting in the first quarter of fiscal 2020. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements and whether to adopt the new guidance early.

[0001728949-18-000039:notes:110]
Leases: In February 2016, the FASB issued new guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease guidance. The new guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. The Company will adopt the new guidance in the first quarter of fiscal 2020 and expects to use the modified retrospective approach, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements and whether to apply any of the optional practical expedients.

[0001728949-18-000039:notes:111]
Hedge Instruments: In August 2017, the FASB issued new guidance that expands and refines hedge accounting for both financial and non-financial risks, aligns the recognition and presentation of the effects of hedging instruments and hedged items in the financial statements, and includes targeted improvements related to the assessment of hedge effectiveness. The new guidance also modifies disclosure requirements for hedging activities. The Company plans to adopt the new guidance in the first quarter of fiscal 2019 and does not expect the effects of the adoption to have a material impact on its consolidated financial statements.

[0001728949-18-000039:notes:112]
Other: In August 2016, the FASB issued new guidance related to the classification of certain cash receipts and cash payments on the statement of cash flows. The Company will adopt the new guidance in the first quarter of fiscal 2019 and does not expect the effects of the adoption to have a material impact on its consolidated statements of cash flows.

[0001728949-18-000039:notes:113]
In October 2016, the FASB issued new guidance that changes the accounting for income tax effects of intra-entity transfers of assets other than inventory. Under the new guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. The Company will adopt the new guidance in the first quarter of fiscal 2019 and is in the process of determining the effects the adoption will have on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-18-000039:notes:114]
[same as prior period, unchanged from 0001728949-18-000011:notes:107]

[0001728949-18-000039:notes:115]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 24, 2017. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and six-month periods ended March 25, 2018 and March 26, 2017 included 13 weeks and 26 weeks, respectively.

[0001728949-18-000039:notes:116]
[same as prior period, unchanged from 0001728949-18-000011:notes:109]

[0001728949-18-000039:notes:117]
Earnings (Loss) Per Common Share. Basic earnings (loss) per common share is computed by dividing net income (loss) attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans, if any, and the weighted-average number of common shares outstanding during the reporting period. Due to the net loss for the six months ended March 25, 2018, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share. The following table provides information about the diluted earnings per share calculation (in millions):

[0001728949-18-000039:notes:118]
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | March 25, 2018 |  | March 26, 2017 |
| Dilutive common share equivalents included in diluted shares | 12.2 |  |  | 11.3 |  |  | — |  |  | 14.2 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 0.1 |  |  | 10.8 |  |  | 44.9 |  |  | 5.4 |  |

[0001728949-18-000039:notes:119]
[same as prior period, unchanged from 0001728949-18-000011:notes:112]

[0001728949-18-000039:notes:120]
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | March 25, 2018 |  | March 26, 2017 |
| Cost of revenues | $ | 10 |  |  | $ | 10 |  |  | $ | 21 |  |  | $ | 20 |  |
| Research and development | 151 |  |  | 155 |  |  | 307 |  |  | 308 |  |
| Selling, general and administrative | 61 |  |  | 81 |  |  | 142 |  |  | 157 |  |
| Share-based compensation expense before income taxes | 222 |  |  | 246 |  |  | 470 |  |  | 485 |  |
| Related income tax benefit | (29 | ) |  | (36 | ) |  | (77 | ) |  | (84 | ) |
|  | $ | 193 |  |  | $ | 210 |  |  | $ | 393 |  |  | $ | 401 |  |

[0001728949-18-000039:notes:121]
At March 25, 2018, total unrecognized compensation expense related to nonvested restricted stock units granted prior to that date was $1.3 billion, which is expected to be recognized over a weighted-average period of 1.9 years. At March 25, 2018, the Company had 28.4 million restricted stock units outstanding and 7.8 million stock options outstanding.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001728949-18-000039:notes:122]
[same as prior period, unchanged from 0001728949-18-000011:notes:117]

[0001728949-18-000039:notes:123]
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | March 25, 2018 |  | March 26, 2017 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 74 |  |  | $ | 65 |  |  | $ | 162 |  |  | $ | 138 |  |
| Reduction to revenues related to BlackBerry arbitration decision | — |  |  | (974 | ) |  | — |  |  | (974 | ) |
|  | $ | 74 |  |  | $ | (909 | ) |  | $ | 162 |  |  | $ | (836 | ) |
| EBT |  |  |  |  |  |  |  |
| Reduction to revenues related to BlackBerry arbitration decision | $ | — |  |  | $ | (974 | ) |  | $ | — |  |  | $ | (974 | ) |
| Unallocated cost of revenues | (111 | ) |  | (119 | ) |  | (228 | ) |  | (213 | ) |
| Unallocated research and development expenses | (271 | ) |  | (277 | ) |  | (551 | ) |  | (546 | ) |
| Unallocated selling, general and administrative expenses | (258 | ) |  | (138 | ) |  | (420 | ) |  | (283 | ) |
| Unallocated other expenses (Note 2) | (310 | ) |  | (78 | ) |  | (1,493 | ) |  | (954 | ) |
| Unallocated interest expense | (179 | ) |  | (106 | ) |  | (348 | ) |  | (195 | ) |
| Unallocated investment and other income, net | 82 |  |  | 223 |  |  | 206 |  |  | 407 |  |
| Nonreportable segments | (93 | ) |  | (108 | ) |  | (186 | ) |  | (189 | ) |
|  | $ | (1,140 | ) |  | $ | (1,577 | ) |  | $ | (3,020 | ) |  | $ | (2,947 | ) |

[0001728949-18-000039:notes:124]
[same as prior period, unchanged from 0001728949-18-000011:notes:115]

[0001728949-18-000039:notes:125]
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | March 25, 2018 |  | March 26, 2017 |
| Cost of revenues | $ | 102 |  |  | $ | 106 |  |  | $ | 208 |  |  | $ | 191 |  |
| Research and development expenses | 2 |  |  | 12 |  |  | 3 |  |  | 14 |  |
| Selling, general and administrative expenses | 214 |  |  | 57 |  |  | 290 |  |  | 118 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001728949-18-000039:notes:126]
Note 9. Cost Plan

[0001728949-18-000039:notes:127]
On January 16, 2018, the Company announced a Cost Plan designed to align the Company’s cost structure to its long-term margin targets. As part of this plan, the Company has initiated a series of targeted actions across the Company’s businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. The Company expects these cost reductions to be fully captured in fiscal 2019.

[0001728949-18-000039:notes:128]
In connection with this plan, the Company expects to incur total restructuring and restructuring-related charges of approximately $400 million to $525 million, which primarily consist of severance costs, and the majority of which are expected to be settled in cash. During the three months ended March 25, 2018, the Company recorded restructuring and restructuring-related charges of $310 million in other expenses (Note 2), which consisted of restructuring charges of $277 million, primarily related to severance costs, and restructuring-related charges of $33 million related to certain asset impairments. A negligible amount of cash payments was made related to this plan in the three months ended March 25, 2018.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001728949-18-000039:notes:129]
Changes in the components of accumulated other comprehensive income, net of income taxes, in stockholders’ equity in the six months ended March 25, 2018 were as follows (in millions):

[0001728949-18-000039:notes:130]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized (Loss) Gain on Derivative Instruments |  | Other Gains |  | Total Accumulated Other Comprehensive Income |
| Balance at September 24, 2017 | $ | 147 |  |  | $ | 23 |  |  | $ | 218 |  |  | $ | (8 | ) |  | $ | 4 |  |  | $ | 384 |  |
| Other comprehensive income (loss) before reclassifications | 173 |  |  | — |  |  | (1 | ) |  | (6 | ) |  | — |  |  | 166 |  |
| Reclassifications from accumulated other comprehensive income | — |  |  | 1 |  |  | (9 | ) |  | 3 |  |  | — |  |  | (5 | ) |
| Other comprehensive income (loss) | 173 |  |  | 1 |  |  | (10 | ) |  | (3 | ) |  | — |  |  | 161 |  |
| Balance at March 25, 2018 | $ | 320 |  |  | $ | 24 |  |  | $ | 208 |  |  | $ | (11 | ) |  | $ | 4 |  |  | $ | 545 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001728949-18-000039:notes:131]
[same as prior period, unchanged from 0001728949-18-000011:notes:121]

[0001728949-18-000039:notes:132]
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | March 25, 2018 |  | March 26, 2017 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 3,897 |  |  | $ | 3,676 |  |  | $ | 8,548 |  |  | $ | 7,777 |  |
| QTL | 1,260 |  |  | 2,249 |  |  | 2,559 |  |  | 4,060 |  |
| QSI | 30 |  |  | — |  |  | 60 |  |  | 14 |  |
| Reconciling items | 74 |  |  | (909 | ) |  | 162 |  |  | (836 | ) |
| Total | $ | 5,261 |  |  | $ | 5,016 |  |  | $ | 11,329 |  |  | $ | 11,015 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 608 |  |  | $ | 475 |  |  | $ | 1,563 |  |  | $ | 1,199 |  |
| QTL | 850 |  |  | 1,959 |  |  | 1,738 |  |  | 3,492 |  |
| QSI | 40 |  |  | — |  |  | 51 |  |  | (17 | ) |
| Reconciling items | (1,140 | ) |  | (1,577 | ) |  | (3,020 | ) |  | (2,947 | ) |
| Total | $ | 358 |  |  | $ | 857 |  |  | $ | 332 |  |  | $ | 1,727 |  |

[0001728949-18-000039:notes:133]
|  | March 25, 2018 |  | September 24, 2017 |
| Assets |  |  |  |
| QCT | $ | 3,336 |  |  | $ | 3,830 |  |
| QTL | 1,907 |  |  | 1,735 |  |
| QSI | 1,193 |  |  | 1,037 |  |
| Reconciling items | 57,690 |  |  | 58,884 |  |
| Total | $ | 64,126 |  |  | $ | 65,486 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001728949-18-000039:notes:134]
Changes in stockholders’ equity in the six months ended March 25, 2018 were as follows (in millions):

[0001728949-18-000039:notes:135]
|  | Total Stockholders’ Equity |
| Balance at September 24, 2017 | $ | 30,746 |  |
| Net loss | (5,590 | ) |
| Other comprehensive income | 161 |  |
| Common stock issued under employee benefit plans and related tax benefits | 343 |  |
| Share-based compensation | 499 |  |
| Tax withholdings related to vesting of share-based payments | (196 | ) |
| Dividends | (1,719 | ) |
| Stock repurchases | (425 | ) |
| Balance at March 25, 2018 | $ | 23,819 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-18-000039:notes:136]
[same as prior period, unchanged from 0001728949-18-000011:notes:125]

[0001728949-18-000039:notes:137]
[same as prior period, unchanged from 0001728949-18-000011:notes:126]

[0001728949-18-000039:notes:138]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT). In fiscal 2018, all of the costs related to pre-commercial research and development of 5G (fifth generation) technology, of which $115 million and $216 million was recorded in the three and six months ended March 25, 2018, respectively, are included in unallocated corporate research and development expenses, whereas similar costs related to the research and development of other technology, including 3G (third generation) and 4G (fourth generation) technology, were recorded in both the QCT and QTL segments.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-18-000039:notes:139]
[same as prior period, unchanged from 0001728949-18-000011:notes:129]

[0001728949-18-000039:notes:140]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in stockholders’ equity in the six months ended March 25, 2018 were as follows (in millions):

[0001728949-18-000039:notes:141]
Reclassifications from accumulated other comprehensive income related to available-for-sale securities were negligible in both the three and six months ended March 25, 2018 and $35 million and $48 million in the three and six months ended March 26, 2017, respectively, and were recorded in investment and other income, net (Note 2).

[0001728949-18-000039:notes:142]
Stock Repurchase Program. On March 9, 2015, the Company announced a stock repurchase program authorizing it to repurchase up to $15 billion of the Company’s common stock. The stock repurchase program has no expiration date. In the six months ended March 25, 2018 and March 26, 2017, the Company repurchased and retired 6.8 million and 11.5 million shares for $425 million and $727 million, respectively, before commissions. At March 25, 2018, $1.2 billion remained authorized for repurchase under the Company’s stock repurchase program.

[0001728949-18-000039:notes:143]
Dividends. On March 8, 2018, the Company announced a 9% increase in its quarterly dividend per share of common stock from $0.57 to $0.62, which is effective for dividends payable after March 21, 2018. On April 17, 2018, the Company announced a cash dividend of $0.62 per share on the Company’s common stock, payable on June 20, 2018 to stockholders of record as of the close of business on May 30, 2018. In the six months ended March 25, 2018 and March 26, 2017, dividends charged to retained earnings were as follows (in millions, except per share data):

[0001728949-18-000039:notes:144]
Employee Benefit Plans. On March 23, 2018, the Company’s stockholders approved an amendment to the Amended and Restated QUALCOMM Incorporated 2001 Employee Stock Purchase Plan to increase the share reserve by 30,000,000 shares to approximately 101,709,000.
