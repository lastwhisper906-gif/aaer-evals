# QCOM MD&A — 0001728949-18-000039


## mdna

[0001728949-18-000039:mdna:1]
[same as prior period, unchanged from 0001728949-18-000011:mdna:1]

[0001728949-18-000039:mdna:2]
[same as prior period, unchanged from 0001728949-18-000011:mdna:2]

[0001728949-18-000039:mdna:3]
[same as prior period, unchanged from 0001728949-18-000011:mdna:3]

[0001728949-18-000039:mdna:4]
Second Quarter of Fiscal 2018 Overview

[0001728949-18-000039:mdna:5]
Revenues for the second quarter of fiscal 2018 were $5.3 billion, an increase of 5% compared to the year ago quarter, with net income attributable to Qualcomm of $363 million, a decrease of 52% compared to the year ago quarter. Highlights and other events from the second quarter of fiscal 2018 included:

[0001728949-18-000039:mdna:6]
| • | The transition of wireless networks and devices to 3G/4G (CDMA single-mode, OFDMA single-mode and CDMA/OFDMA multi-mode) continued around the world. 3G/4G connections grew sequentially by approximately 3% to approximately 5.0 billion, which was approximately 64% of total mobile connections at the end of the second quarter of fiscal 2018.(1) |

[0001728949-18-000039:mdna:7]
[same as prior period, unchanged from 0001728949-18-000011:mdna:7]

[0001728949-18-000039:mdna:8]
| • | QCT results were positively impacted by results from our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017. |

[0001728949-18-000039:mdna:9]
| • | QTL results were negatively impacted by our continued dispute with Apple and its contract manufacturers (who are Qualcomm licensees), as well as the previously disclosed dispute with another licensee. We did not record any revenues in the second quarter of fiscal 2018 for royalties due on sales of Apple’s or the other licensee’s products. |

[0001728949-18-000039:mdna:10]
| • | On November 6, 2017, Broadcom Limited (Broadcom) announced an unsolicited proposal to acquire all of the outstanding shares of our common stock (collectively with Broadcom’s subsequent proposal, the Proposed Transaction). On December 4, 2017, Broadcom delivered a Notice of Stockholder Proposal and Nomination of Candidates for Election to the Board of Qualcomm informing the Company, among other things, of Broadcom’s intent to nominate 11 directors (later reduced to 6) to Qualcomm’s Board, in opposition to the Board’s slate of director nominees. On January 5, 2018, Broadcom filed its definitive proxy statement. On March 4, 2018, the Committee on Foreign Investment in the United States (CFIUS) issued an Interim Order Regarding the Proposed Acquisition of Qualcomm, Inc. by Broadcom Limited stating that there were national security risks to the United States that arose as a result of, and in connection with, the Proposed Transaction, and prohibiting Qualcomm from accepting or taking any action in furtherance of accepting the Proposed Transaction or any other proposed merger, acquisition or takeover agreement with Broadcom. On March 12, 2018, the President of the United States of |

[0001728949-18-000039:mdna:11]
[same as prior period, unchanged from 0001728949-18-000011:mdna:11]

[0001728949-18-000039:mdna:12]
America issued an Order Regarding the Proposed Takeover of Qualcomm Incorporated by Broadcom Limited (the Presidential Order) that prohibited the Proposed Transaction and any substantially equivalent merger, acquisition or takeover, disqualified all of Broadcom’s nominees from standing for election as directors to the Board of Qualcomm, and ordered Qualcomm and Broadcom to immediately and permanently abandon the Proposed Transaction. On March 14, 2018, in order to comply with the Presidential Order, Broadcom withdrew the Proposed Transaction and its slate of director nominees. Responding to the Proposed Transaction required us to devote significant resources and Board and management time and attention and incur expenses and costs in the second quarter of fiscal 2018.

[0001728949-18-000039:mdna:13]
| • | On January 16, 2018, we announced a Cost Plan designed to align our cost structure to our long-term margin targets. As part of this plan, we have initiated a series of targeted actions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. We expect these cost reductions to be fully captured in fiscal 2019. In the second quarter of fiscal 2018, we recorded restructuring and restructuring-related charges of $310 million related to the plan. |

[0001728949-18-000039:mdna:14]
| (1) | According to GSMA Intelligence estimates as of April 23, 2018 (estimates excluded Wireless Local Loop). |

[0001728949-18-000039:mdna:15]
[same as prior period, unchanged from 0001728949-18-000011:mdna:15]

[0001728949-18-000039:mdna:16]
[same as prior period, unchanged from 0001728949-18-000011:mdna:16]

[0001728949-18-000039:mdna:17]
[same as prior period, unchanged from 0001728949-18-000011:mdna:17]

[0001728949-18-000039:mdna:18]
[same as prior period, unchanged from 0001728949-18-000011:mdna:18]

[0001728949-18-000039:mdna:19]
Seasonality. Many of our products and/or intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has tended historically to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons; and because QTL recognizes royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made in the fourth calendar quarter. We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 4G networks by wireless operators and the timing of launches of flagship wireless devices that incorporate our products and/or intellectual property. The seasonal trends for QTL may be impacted by disputes and/or resolutions with licensees. These trends may or may not continue in the future.

[0001728949-18-000039:mdna:20]
[same as prior period, unchanged from 0001728949-18-000011:mdna:20]

[0001728949-18-000039:mdna:21]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | Change |  | March 25, 2018 |  | March 26, 2017 |  | Change |
| Equipment and services | $ | 3,936 |  |  | $ | 3,689 |  |  | $ | 247 |  |  | $ | 8,639 |  |  | $ | 7,828 |  |  | $ | 811 |  |
| Licensing | 1,325 |  |  | 1,327 |  |  | (2 | ) |  | 2,690 |  |  | 3,187 |  |  | (497 | ) |
|  | $ | 5,261 |  |  | $ | 5,016 |  |  | $ | 245 |  |  | $ | 11,329 |  |  | $ | 11,015 |  |  | $ | 314 |  |

[0001728949-18-000039:mdna:22]
31

[0001728949-18-000039:mdna:23]
The increases in equipment and services revenues in the second quarter and first six months of fiscal 2018 were primarily due to increases in QCT and QSI revenues. The decreases in licensing revenues in the second quarter and first six months of fiscal 2018 were primarily due to decreases in QTL revenues, partially offset by the reduction to licensing revenues of $974 million recorded in the second quarter of fiscal 2017 related to the BlackBerry arbitration decision.

[0001728949-18-000039:mdna:24]
| Costs and Expenses (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | Change |  | March 25, 2018 |  | March 26, 2017 |  | Change |
| Cost of revenues | $ | 2,239 |  |  | $ | 2,208 |  |  | $ | 31 |  |  | $ | 4,902 |  |  | $ | 4,651 |  |  | $ | 251 |  |
| Gross margin | 57 | % |  | 56 | % |  |  |  | 57 | % |  | 58 | % |  |  |

[0001728949-18-000039:mdna:25]
Excluding the reduction to licensing revenues recorded in the second quarter of fiscal 2017 related to the BlackBerry arbitration decision, the margin percentage decreased in the second quarter and first six months of fiscal 2018 primarily due to decreases in higher margin QTL licensing revenues as a proportion of total revenues, partially offset by increases in QCT margin percentage. Our margin percentage may continue to fluctuate in future periods depending on the mix of segment results as well as products sold, competitive pricing, new product introduction costs and other factors, including disputes and/or resolutions with licensees.

[0001728949-18-000039:mdna:26]
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | Change |  | March 25, 2018 |  | March 26, 2017 |  | Change |
| Research and development | $ | 1,402 |  |  | $ | 1,386 |  |  | $ | 16 |  |  | $ | 2,822 |  |  | $ | 2,697 |  |  | $ | 125 |  |
| % of revenues | 27 | % |  | 28 | % |  |  |  | 25 | % |  | 24 | % |  |  |
| Selling, general and administrative | $ | 869 |  |  | $ | 615 |  |  | $ | 254 |  |  | $ | 1,641 |  |  | $ | 1,206 |  |  | $ | 435 |  |
| % of revenues | 17 | % |  | 12 | % |  |  |  | 14 | % |  | 11 | % |  |  |
| Other | $ | 310 |  |  | $ | 78 |  |  | $ | 232 |  |  | $ | 1,493 |  |  | $ | 954 |  |  | $ | 539 |  |

[0001728949-18-000039:mdna:27]
The dollar increases in research and development expenses in the second quarter and first six months of fiscal 2018 were primarily attributable to increases of $19 million and $160 million, respectively, in costs related to the development of integrated circuit technologies, including 5G technology and radio frequency front-end (RFFE) technologies from our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017. The increase in research and development expenses in the first six months of fiscal 2018 was partially offset by a $30 million impairment charge on certain intangible assets recorded in the first quarter of fiscal 2017.

[0001728949-18-000039:mdna:28]
Selling, general and administrative expenses included $145 million and $250 million in the second quarter and first six months of fiscal 2018, respectively, related to litigation costs, an increase of $102 million and $171 million, respectively. The remaining dollar increases in selling, general and administrative expenses in the second quarter and first six months of fiscal 2018 were primarily attributable to increases of $77 million in each period in other professional fees and $63 million and $65 million, respectively, in costs related to other legal matters, all of which were primarily driven by Broadcom’s withdrawn takeover proposal, and $14 million and $38 million, respectively, in employee-related expenses, which included our RF360 Holdings joint venture. The dollar increase in selling, general and administrative expenses in the first six months of fiscal 2018 was also attributable to increases of $45 million in bad debt expenses and $35 million in marketing expenses.

[0001728949-18-000039:mdna:29]
Other expenses in the second quarter and first six months of fiscal 2018 included $310 million in restructuring and restructuring-related charges related to our Cost Plan. Other expenses in the first six months of fiscal 2018 also included a $1.2 billion charge related to the European Commission (EC) fine. Other expenses in the second quarter of fiscal 2017 consisted of $53 million in foreign currency losses related to the Korea Fair Trade Commission (KFTC) fine, which was accrued in the first quarter of fiscal 2017, and $25 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan. Other expenses in the first six months of fiscal 2017 consisted of a $921 million charge related to the KFTC fine, including related foreign currency losses, and $33 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan.

[0001728949-18-000039:mdna:30]
[same as prior period, unchanged from 0001728949-18-000011:mdna:31]

[0001728949-18-000039:mdna:31]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | Change |  | March 25, 2018 |  | March 26, 2017 |  | Change |
| Interest expense | $ | 179 |  |  | $ | 107 |  |  | $ | 72 |  |  | $ | 350 |  |  | $ | 197 |  |  | $ | 153 |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 154 |  |  | $ | 153 |  |  | $ | 1 |  |  | $ | 280 |  |  | $ | 320 |  |  | $ | (40 | ) |
| Net realized gains on marketable securities | 3 |  |  | 67 |  |  | (64 | ) |  | 13 |  |  | 206 |  |  | (193 | ) |
| Net realized gains on other investments | 47 |  |  | 21 |  |  | 26 |  |  | 60 |  |  | 30 |  |  | 30 |  |
| Impairment losses on marketable securities and other investments | (11 | ) |  | (5 | ) |  | (6 | ) |  | (20 | ) |  | (148 | ) |  | 128 |  |
| Equity in net losses of investees | (17 | ) |  | (14 | ) |  | (3 | ) |  | (38 | ) |  | (11 | ) |  | (27 | ) |
| Net losses on foreign currency transactions | (90 | ) |  | — |  |  | (90 | ) |  | (93 | ) |  | — |  |  | (93 | ) |
| Net gains on derivative instruments | 10 |  |  | 13 |  |  | (3 | ) |  | 9 |  |  | 20 |  |  | (11 | ) |
|  | $ | 96 |  |  | $ | 235 |  |  | $ | (139 | ) |  | $ | 211 |  |  | $ | 417 |  |  | $ | (206 | ) |

[0001728949-18-000039:mdna:32]
The increases in interest expense in the second quarter and first six months of fiscal 2018 were primarily attributable to the issuance of an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes in May 2017. In the first quarter of fiscal 2017, we began divesting a substantial portion of our marketable securities portfolio in order to finance, in part, the proposed acquisition of NXP. As a result, we recorded net realized gains and impairment losses on such marketable securities that we sold and expected to sell before their anticipated recovery, respectively, in fiscal 2017. The net losses on foreign currency transactions in the second quarter and first six months of fiscal 2018 were primarily attributable to currency exchange rate movements on amounts accrued for the EC and Taiwan Fair Trade Commission (TFTC) fines.

[0001728949-18-000039:mdna:33]
| Income Tax Expense (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | Change |  | March 25, 2018 |  | March 26, 2017 |  | Change |
| Income tax (benefit) expense | $ | (5 | ) |  | $ | 108 |  |  | $ | (113 | ) |  | $ | 5,922 |  |  | $ | 296 |  |  | $ | 5,626 |  |
| Effective tax rate | (1 | %) |  | 13 | % |  | (14 | %) |  | N/M |  |  | 17 | % |  | N/M |  |

[0001728949-18-000039:mdna:34]
[same as prior period, unchanged from 0001728949-18-000011:mdna:34]

[0001728949-18-000039:mdna:35]
The following table summarizes the primary factors that caused our effective tax rates for the second quarter of fiscal 2018 and 2017 to be less than the United States federal statutory rate:

[0001728949-18-000039:mdna:36]
|  | Three Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |
| Expected income tax provision at federal statutory tax rate | 25 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (30 | %) |  | (25 | %) |
| Benefits related to the research and development tax credit | (8 | %) |  | (2 | %) |
| Toll Charge measurement period adjustments | 2 | % |  | — |  |
| Remeasurement of deferred tax assets due to changes in statutory tax rate | (4 | %) |  | — |  |
| Foreign withholding taxes | 2 | % |  | — |  |
| Nondeductible charges related to the KFTC, TFTC and EC investigations | 5 | % |  | 3 | % |
| Other | 7 | % |  | 2 | % |
| Effective Tax Rate | (1 | %) |  | 13 | % |

[0001728949-18-000039:mdna:37]
The Tax Cuts and Jobs Act (the Tax Legislation) in the United States (U.S.) enacted on December 22, 2017 significantly revises the U.S. corporate income tax by, among other things, lowering the corporate income tax rate to 21% effective

[0001728949-18-000039:mdna:38]
January 1, 2018, implementing a modified territorial tax system and imposing a one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge). As a fiscal-year taxpayer, certain provisions of the Tax Legislation impacted us in fiscal 2018, including the change in the corporate income tax rate and the Toll Charge, while other provisions will be effective starting at the beginning of fiscal 2019, including the implementation of a modified territorial tax system. Accordingly, our federal statutory income tax rate for fiscal 2018 reflects a blended rate of approximately 25%.

[0001728949-18-000039:mdna:39]
We have preliminarily accounted for the effects of the Tax Legislation, which resulted in a charge of $5.87 billion to income tax expense recorded discretely in the first quarter of fiscal 2018, comprised of $5.3 billion related to the estimated Toll Charge and $562 million resulting from the estimated impact of remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate. We recorded a $15 million net tax benefit discretely in the second quarter of fiscal 2018 related to refining estimates associated with the estimated Toll Charge and the estimated impact of remeasurement of U.S. deferred tax assets and liabilities.

[0001728949-18-000039:mdna:40]
Our annual effective tax rate is estimated to be approximately 438% for fiscal 2018 as compared to the 18% effective income tax rate for fiscal 2017, primarily as a result of the estimated charge of $5.95 billion recorded to income tax expense in the first six months of fiscal 2018 related to the combined effect of the Toll Charge, the remeasurement of deferred tax assets and liabilities and our decision to no longer indefinitely reinvest certain foreign earnings. Our estimated annual effective tax rate for fiscal 2018 was also impacted by the EC fine recorded in the first quarter of fiscal 2018, which is not deductible for tax purposes and is attributable to a foreign jurisdiction. Tax benefits from foreign income taxed at rates lower than rates in the U.S. are expected to be approximately 31% in fiscal 2018, compared to 32% in fiscal 2017, primarily due to the lower U.S federal statutory income tax rate enacted by the Tax Legislation, partially offset by lower estimated U.S. revenues primarily related to decreased royalty revenues from Apple’s contract manufacturers and the other licensee in dispute. The estimated annual effective tax rate for fiscal 2018 also reflects a blended U.S federal statutory income tax rate of 25% as a result of the Tax Legislation and the increase in our Singapore tax rate due to the expiration of certain tax incentives in March 2017. The annual effective tax rate of 18% for fiscal 2017 reflected the KFTC and TFTC fines (see “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” in this Quarterly Report), which were not deductible for tax purposes and were each attributable to both the U.S. and foreign jurisdictions.

[0001728949-18-000039:mdna:41]
The effective tax rate for the second quarter of fiscal 2018 was lower than the estimated annual effective tax rate primarily resulting from the estimated charge of $5.96 billion recorded discretely to income tax expense in the first quarter of fiscal 2018 related to the effects of certain components of the Tax Legislation and the EC fine recorded in the first quarter of fiscal 2018, as well as the $15 million net tax benefit recorded discretely in the second quarter of fiscal 2018 related to refining estimates associated with the Tax Legislation.

[0001728949-18-000039:mdna:42]
The effective tax rates of 13% and 17% for the second quarter and first six months of fiscal 2017, respectively, reflected tax benefits from foreign income taxed at rates lower than rates in the U.S. of 25% and 20%, respectively, primarily resulting from the reduction to our United States revenues related to the BlackBerry arbitration decision, as well as the KFTC fine recorded in the first six months of fiscal 2017.

[0001728949-18-000039:mdna:43]
Unrecognized tax benefits were $347 million and $372 million at March 25, 2018 and September 24, 2017, respectively. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at March 25, 2018 may increase or decrease in the next 12 months.

[0001728949-18-000039:mdna:44]
We are subject to income taxes in the U.S. and numerous foreign jurisdictions, and are currently under examination by various tax authorities worldwide, most notably in countries where we earn a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2000. We continually assess the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of March 25, 2018, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0001728949-18-000039:mdna:45]
[same as prior period, unchanged from 0001728949-18-000011:mdna:42]

[0001728949-18-000039:mdna:46]
The following should be read in conjunction with the financial results for the second quarter and first six months of fiscal 2018 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0001728949-18-000039:mdna:47]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | March 25, 2018 |  | March 26, 2017 |  | Change |  | March 25, 2018 |  | March 26, 2017 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| QCT | $ | 3,897 |  |  | $ | 3,676 |  |  | $ | 221 |  |  | $ | 8,548 |  |  | $ | 7,777 |  |  | $ | 771 |  |
| QTL | 1,260 |  |  | 2,249 |  |  | (989 | ) |  | 2,559 |  |  | 4,060 |  |  | (1,501 | ) |
| QSI | 30 |  |  | — |  |  | 30 |  |  | 60 |  |  | 14 |  |  | 46 |  |
| EBT (1) |  |  |  |  |  |  |  |  |  |  |  |
| QCT | $ | 608 |  |  | $ | 475 |  |  | $ | 133 |  |  | $ | 1,563 |  |  | $ | 1,199 |  |  | $ | 364 |  |
| QTL | 850 |  |  | 1,959 |  |  | (1,109 | ) |  | 1,738 |  |  | 3,492 |  |  | (1,754 | ) |
| QSI | 40 |  |  | — |  |  | 40 |  |  | 51 |  |  | (17 | ) |  | 68 |  |
| EBT as a % of revenues |  |  |  |  |  |  |  |  |  |  |  |
| QCT | 16 | % |  | 13 | % |  | 3 | % |  | 18 | % |  | 15 | % |  | 3 | % |
| QTL | 67 | % |  | 87 | % |  | (20 | %) |  | 68 | % |  | 86 | % |  | (18 | %) |

[0001728949-18-000039:mdna:48]
[same as prior period, unchanged from 0001728949-18-000011:mdna:45]

[0001728949-18-000039:mdna:49]
QCT Segment. The increases in QCT revenues in the second quarter and first six months of fiscal 2018 were primarily due to increases in equipment and services revenues. Equipment and services revenues, mostly related to sales of Mobile Station Modem (MSM) and accompanying Radio Frequency (RF), Power Management (PM) and wireless connectivity integrated circuits, were $3.85 billion and $3.63 billion in the second quarter of fiscal 2018 and 2017, respectively, and $8.45 billion and $7.70 billion in the first six months of fiscal 2018 and 2017, respectively. Approximately 187 million and 179 million MSM integrated circuits were sold in the second quarter of fiscal 2018 and 2017, respectively, and approximately 424 million and 397 million MSM integrated circuits were sold in the first six months of fiscal 2018 and 2017, respectively.

[0001728949-18-000039:mdna:50]
The increases in equipment and services revenues in the second quarter and first six months of fiscal 2018 were primarily due to increases in RFFE product revenues of $314 million and $748 million, respectively, primarily driven by revenues from our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017, and increases of $99 million and $374 million, respectively, related to higher MSM and accompanying PM unit shipments. The increases in equipment and services revenues in the second quarter and first six months of fiscal 2018 were partially offset by decreases of $51 million and $179 million, respectively, resulting from the net impact of lower average selling prices and favorable product mix, and decreases in connectivity product revenues of $97 million and $100 million, respectively.

[0001728949-18-000039:mdna:51]
QCT EBT as a percentage of revenues in the second quarter and first six months of fiscal 2018 increased primarily due to increases in gross margin percentage and the favorable impact of higher revenues relative to operating expenses. The increases in QCT gross margin percentage were primarily due to lower average unit costs and favorable product mix, partially offset by lower average selling prices.

[0001728949-18-000039:mdna:52]
QCT accounts receivable decreased by 14% in the first six months of fiscal 2018 from $1.81 billion to $1.56 billion, primarily due to a 16% decline in revenues in the second quarter of fiscal 2018 compared to the fourth quarter of fiscal 2017, partially offset by the timing of integrated circuit shipments. QCT inventories decreased by 12% in the first six months of fiscal 2018 from $2.02 billion to $1.77 billion primarily due to a decrease in the overall quantity of units on hand.

[0001728949-18-000039:mdna:53]
QTL Segment. QTL results in the second quarter and first six months of fiscal 2018 were negatively impacted by our continued dispute with Apple and its contract manufacturers (who are Qualcomm licensees), as well as the previously disclosed dispute with another licensee. We did not record any revenues in the first six months of fiscal 2018 for royalties due on sales of Apple’s or the other licensee’s products. Royalty revenues related to the products of Apple’s contract manufacturers and the other licensee in dispute were approximately $970 million and $1.7 billion in the second quarter and first six months of fiscal 2017, respectively. The decreases in QTL revenues in the second quarter and first six months of fiscal 2018 were also attributable to lower royalty revenues recognized related to devices sold in prior periods. Excluding the impact of these items, QTL revenues in the second quarter and first six months of fiscal 2018 increased primarily due to increases in revenues per reported unit. QTL revenues for the first six months of fiscal 2018 were also positively impacted by an increase in reported sales of CDMA-based products (including multi-mode products that also implement OFDMA).

[0001728949-18-000039:mdna:54]
QTL EBT as a percentage of revenues in the second quarter and first six months of fiscal 2018 decreased primarily due decreases in QTL revenues and increases in selling, general and administrative expenses resulting from higher litigation costs. QTL revenues and EBT also continued to be impacted negatively by units that we believe are not being reported by

[0001728949-18-000039:mdna:55]
[same as prior period, unchanged from 0001728949-18-000011:mdna:58]

[0001728949-18-000039:mdna:56]
certain other licensees and sales of certain unlicensed products. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing, particularly in emerging regions, including China, and additional litigation may become necessary if negotiations fail to resolve the relevant issues.

[0001728949-18-000039:mdna:57]
QSI Segment. The increases in QSI EBT in the second quarter and first six months of fiscal 2018 were primarily due to the impact of $26 million and $36 million, respectively, resulting from the net impact of higher revenues and higher costs associated with certain development contracts with one of our equity method investees and increases of $25 million and $37 million, respectively, in net realized gains on investments. The increase in QSI EBT in the second quarter of fiscal 2018 was partially offset by an increase of $10 million in impairment losses on investments.

[0001728949-18-000039:mdna:58]
[same as prior period, unchanged from 0001728949-18-000011:mdna:52]

[0001728949-18-000039:mdna:59]
In the coming years, we expect continued growth in consumer demand for 3G, 3G/4G multi-mode and 4G products and services, and new consumer demand for 5G products and services, around the world, driven primarily by smartphones. We also expect growth in new device categories and industries, driven by the expanding adoption of certain technologies that are already commonly used in smartphones by industry segments outside traditional cellular industries, such as automotive, IoT and networking.

[0001728949-18-000039:mdna:60]
As we look forward to the next several months and beyond, we expect our business to be impacted by the following key items:

[0001728949-18-000039:mdna:61]
| • | On October 27, 2016, we announced a definitive agreement (the Purchase Agreement) under which Qualcomm River Holdings, B.V. (Qualcomm River Holdings), an indirect, wholly owned subsidiary of QUALCOMM Incorporated, will acquire NXP Semiconductors N.V. (NXP). NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products. Pursuant to the Purchase Agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP. On February 20, 2018, Qualcomm River Holdings and NXP entered into Amendment No. 1 to the Purchase Agreement, which (i) increased the price payable in the tender offer from $110.00 per share in cash to $127.50 per share in cash, representing estimated total cash consideration to be paid to NXP’s shareholders of $44 billion, and (ii) reduced the Minimum Condition (as defined in the Purchase Agreement) from 80% of the issued and outstanding common shares of NXP to 70% of the issued and outstanding common shares of NXP. On April 19, 2018, Qualcomm River Holdings and NXP entered into Amendment No. 2 to the Purchase Agreement, which, among other things, extended the End Date (as defined in the Purchase Agreement) from April 25, 2018 to July 25, 2018. The transaction is subject to receipt of regulatory clearance from the Ministry of Commerce in the People’s Republic of China (MOFCOM), which we believe is being impacted by the current state of U.S./China trade relations, and other closing conditions. We intend to fund the transaction with cash generated from our May 2017 debt offering as well as cash and cash equivalents held by our foreign entities and use of our term loans, which we expect to draw on at close. We expect that this acquisition will continue to require us to devote significant resources and management time and attention and utilize a substantial portion of our cash and cash equivalents. |

[0001728949-18-000039:mdna:62]
| • | On January 16, 2018, we announced a cost plan designed to align our cost structure to our long-term margin targets. As part of this plan, we have initiated a series of targeted actions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. We expect these cost reductions to be fully captured in fiscal 2019. In connection with this plan, we expect to incur approximately $400 million to $525 million in restructuring and restructuring-related charges, of which $310 million was incurred in the second quarter of fiscal 2018. |

[0001728949-18-000039:mdna:63]
| • | Regulatory authorities in certain jurisdictions continue to investigate our business practices, and other regulatory authorities may do so in the future. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business with remedies that include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Additionally, certain of our direct and indirect customers and licensees, including Apple, have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have in the past had a material adverse effect on our business, and could in the future have a material adverse effect on our business including, among others, monetary damages, the loss of our ability to enforce one or more of our patents, and/or portions of our license agreements could be determined to be invalid or unenforceable. These activities have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect |

[0001728949-18-000039:mdna:64]
that they will continue to result, in increased legal costs. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” and “Risk Factors” included in this Quarterly Report.

[0001728949-18-000039:mdna:65]
| • | We are currently in dispute with Apple surrounding what we believe is an attempt by Apple to reduce the amount of royalties that its contract manufacturers (who are Qualcomm licensees) are required to pay to us for use of our intellectual property. In the first six months of fiscal 2018, such contract manufacturers did not fully report, and did not pay, royalties due on sales of Apple products. We have taken action against Apple’s contract manufacturers to compel such licensees to pay the required royalties, and against Apple, as described more fully elsewhere in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Additionally, the other licensee in dispute did not report or pay royalties due in the first six months of fiscal 2018. We did not record any revenues in the first six months of fiscal 2018 for royalties due on sales of Apple’s or the other licensee’s products, and as a result, QTL revenues and EBT were negatively impacted by these continued disputes. We expect these companies will continue to take such actions in the future, resulting in increased legal costs and negatively impacting our future revenues, as well as our financial condition, results of operations and cash flows until the respective disputes are resolved. |

[0001728949-18-000039:mdna:66]
| • | We continue to believe that certain licensees, particularly in China, are not fully complying with their contractual obligations to report their sales of licensed products to us, and certain companies, including unlicensed companies, particularly in emerging regions, including China, are delaying execution of new license agreements. We have made substantial progress in reaching agreements with many companies, primarily in China. However, negotiations with certain licensees and unlicensed companies are ongoing. We believe that the conclusion of new agreements with these companies will result in improved reporting. Additionally, we believe our increased efforts in the area of compliance will improve reporting but will also result in increased costs to the business. Litigation and/or other actions, such as those recently taken against Apple and its contract manufacturers, may be necessary to compel licensees to report and pay the required royalties for sales they have not previously reported and/or to compel unlicensed companies to execute licenses. Such litigation or other actions would result in increased legal costs. |

[0001728949-18-000039:mdna:67]
| • | To position QTL for stability on a long-term basis, we have announced that our standard essential patent (SEP) only licensing terms through 5G, Release 15 will remain at the same rate, consistent with our licensing program established in China for 3G and 4G devices. We expect that more of our licensees may enter into SEP-only agreements on a worldwide basis as existing agreements come up for renewal and/ or renegotiation. In addition, we are reducing the per unit cap on smartphones, which is the base on which our royalties are calculated. While we expect these developments to enhance stability for the long term, they may impact QTL royalty revenues in the shorter term. |

[0001728949-18-000039:mdna:68]
[same as prior period, unchanged from 0001728949-18-000011:mdna:61]

[0001728949-18-000039:mdna:69]
[same as prior period, unchanged from 0001728949-18-000011:mdna:62]

[0001728949-18-000039:mdna:70]
[same as prior period, unchanged from 0001728949-18-000011:mdna:63]

[0001728949-18-000039:mdna:71]
| • | Decisions by certain companies to utilize our competitors’ integrated circuit products in all or a portion of their devices. For example, commencing with the iPhone 7 (which was released in September 2016), we are no longer the sole supplier of modems for new iPhone product launches, as Apple utilizes modems from one of our competitors in a portion of such devices. We expect that in the future Apple will utilize our competitors’ modems in a portion of or potentially all iPhones. Accordingly, QCT revenues from modem sales for iPhones declined in fiscal 2017 and may continue to decline in the future, in part depending on the extent of Apple’s utilization of competitors’ modems and the mix of the various versions of its products that are sold. Overall QCT revenues, as well as profitability, may similarly decline unless offset by sales of integrated circuit products to other customers, including those outside of traditional cellular industries, such as the Internet of Things (IoT), automotive and networking. Apple’s sourcing of integrated circuit products does not impact our licensing revenues since our licensing revenues from Apple products are not dependent upon whether such products include our chipsets; |

[0001728949-18-000039:mdna:72]
[same as prior period, unchanged from 0001728949-18-000011:mdna:65]

[0001728949-18-000039:mdna:73]
37

[0001728949-18-000039:mdna:74]
[same as prior period, unchanged from 0001728949-18-000011:mdna:66]

[0001728949-18-000039:mdna:75]
[same as prior period, unchanged from 0001728949-18-000011:mdna:67]

[0001728949-18-000039:mdna:76]
[same as prior period, unchanged from 0001728949-18-000011:mdna:68]

[0001728949-18-000039:mdna:77]
| • | Current U.S./China trade relations may negatively impact our business, growth prospects and results of operations. |

[0001728949-18-000039:mdna:78]
[same as prior period, unchanged from 0001728949-18-000011:mdna:69]

[0001728949-18-000039:mdna:79]
| • | We continue to invest significant resources toward advancements in 4G and 5G technologies, OFDM-based WLAN technologies, wireless baseband chips, our converged computing/communications (Snapdragon) chips, radio frequency front-end (RFFE), connectivity, power management, graphics, audio and video codecs, multimedia products and software, which contribute to the expansion of our intellectual property portfolio. We are also investing in targeted opportunities that leverage our existing technical and business expertise to deploy new business models and enter and/or expand into new industry segments, such as products for automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), data center, networking, computing and machine learning, among others. |

[0001728949-18-000039:mdna:80]
[same as prior period, unchanged from 0001728949-18-000011:mdna:73]

[0001728949-18-000039:mdna:81]
[same as prior period, unchanged from 0001728949-18-000011:mdna:74]

[0001728949-18-000039:mdna:82]
[same as prior period, unchanged from 0001728949-18-000011:mdna:75]

[0001728949-18-000039:mdna:83]
On February 20, 2018, we announced that Qualcomm River Holdings reached an agreement with NXP to increase to $127.50 per share its previously announced cash tender offer to acquire all of the issued and outstanding common shares of NXP, for estimated total cash consideration to be paid to NXP’s shareholders of $44 billion. The transaction is subject to receipt of regulatory approvals from the Ministry of Commerce in the People’s Republic of China (MOFCOM) and other closing conditions. In May 2017, we issued an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes with varying maturities, of which a portion will be used to fund the purchase price and other related transactions. In addition, we have secured $4.0 billion and $3.0 billion through a 2016 Term Loan Facility and a 2018 Term Loan Facility respectively, which are expected to be drawn on at the close of the NXP transaction. We have also secured $3.0 billion in committed financing through a 2018 Revolving Credit Facility, which is available to, in part, finance the transaction. The remaining amount will be funded with cash held by our foreign entities, which will result in the use of a substantial portion of our cash and cash equivalents.

[0001728949-18-000039:mdna:84]
Qualcomm River Holdings and NXP may terminate the Purchase Agreement under certain circumstances. If the Purchase Agreement is terminated in certain circumstances, including termination by NXP to enter into a superior proposal for an alternative acquisition transaction or a termination following a change of recommendation by NXP’s board of directors, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the Purchase Agreement is terminated under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion. Under Amendment No. 2, in addition to its existing rights, NXP will be entitled to receive the termination fee (i) if the Purchase Agreement is terminated in accordance with its terms for any reason (subject to certain exceptions) and, at the time of any such termination, approval by MOFCOM, or in any jurisdiction where the parties’ previously obtained clearance will expire or where the applicable antitrust authority has required or requested a resubmission for clearance, has not been received, or (ii) at any time after July 25, 2018 if, at such time, approval by MOFCOM, or in any jurisdiction where the parties’ previously obtained clearance will expire or where the applicable antitrust authority has required or requested a resubmission for clearance, has not been received.

[0001728949-18-000039:mdna:85]
In November 2016, as required by the Purchase Agreement, we entered into four letters of credit for an aggregate amount of $2.0 billion pursuant to which NXP will have the right to draw amounts to fund the potential termination fee payable to NXP. Each letter of credit is required to be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. We are restricted from using the funds deposited as collateral while the letters of credit are outstanding. At March 25, 2018, the letters of credit were fully collateralized through bank time and demand deposits.

[0001728949-18-000039:mdna:86]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. The following table presents selected financial information related to our liquidity as of March 25, 2018 and September 24, 2017 and for the first six months of fiscal 2018 and 2017 (in millions):

[0001728949-18-000039:mdna:87]
|  | March 25, 2018 |  | September 24, 2017 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 39,606 |  |  | $ | 38,578 |  |  | $ | 1,028 |  |  | 3 | % |
| Accounts receivable, net | 3,535 |  |  | 3,632 |  |  | (97 | ) |  | (3 | %) |
| Inventories | 1,797 |  |  | 2,035 |  |  | (238 | ) |  | (12 | %) |
| Short-term debt | 3,733 |  |  | 2,495 |  |  | 1,238 |  |  | 50 | % |
| Long-term debt | 19,361 |  |  | 19,398 |  |  | (37 | ) |  | — | % |
| Noncurrent income taxes payable | 3,277 |  |  | — |  |  | 3,277 |  |  | N/M |  |

[0001728949-18-000039:mdna:88]
[same as prior period, unchanged from 0001728949-18-000011:mdna:80]

[0001728949-18-000039:mdna:89]
|  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | $ Change |  | % Change |
| Net cash provided by operating activities | $ | 2,278 |  |  | $ | 2,406 |  |  | $ | (128 | ) |  | (5 | %) |
| Net cash provided by investing activities | 1,481 |  |  | 760 |  |  | 721 |  |  | 95 | % |
| Net cash used by financing activities | (874 | ) |  | (1,982 | ) |  | 1,108 |  |  | (56 | %) |

[0001728949-18-000039:mdna:90]
The net increase in cash, cash equivalents and marketable securities was primarily due to net cash provided by operating activities and $1.2 billion of net issuances of our outstanding commercial paper debt, partially offset by $1.7 billion in cash dividends paid, $425 million in payments to repurchase shares of our common stock and $411 million in capital expenditures. Total cash provided by operating activities was impacted by continued actions taken by Apple and its contract manufacturers, as well as the previously disclosed dispute with another licensee, who did not report or pay royalties due in the first six months of fiscal 2018.

[0001728949-18-000039:mdna:91]
Our days sales outstanding, on a consolidated basis, increased to 61 days at March 25, 2018 as compared to 56 days at September 24, 2017 primarily due to the timing of the collection of payments from certain of our licensees. The decrease in inventories was primarily due to a decrease in the overall quantity of units on hand.

[0001728949-18-000039:mdna:92]
Debt. Our 2016 Amended and Restated Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in the aggregate amount of $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. Our 2018 Revolving Credit Facility provides for unsecured delayed-draw revolving facility loans in the aggregate amount of $3.0 billion. Proceeds from the 2018 Revolving Credit Facility, if drawn, will be used to finance, in part, the proposed acquisition of NXP. At March 25, 2018, no amounts were outstanding under the revolving credit facilities.

[0001728949-18-000039:mdna:93]
We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At March 25, 2018, we had $2.2 billion of commercial paper outstanding with weighted-average net interest rates of 1.98% and weighted-average remaining days to maturity of 44 days.

[0001728949-18-000039:mdna:94]
Our 2016 Term Loan Facility provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion, and our 2018 Term Loan Facility provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $3.0 billion. Proceeds from the term loan facilities, if drawn, will be used to finance, in part, the proposed acquisition of NXP. At March 25, 2018, no amounts were outstanding under the term loan facilities.

[0001728949-18-000039:mdna:95]
In May 2017, we issued an aggregate principal amount of $11.0 billion in nine tranches of unsecured floating- and fixed-rate notes, with maturity dates starting in 2019 through 2047. Effective interest rates were between 2.00% and 4.47% at March 25, 2018. Net proceeds from the issuance of the notes of $10.95 billion are intended to be used to fund a portion of the purchase price of our planned acquisition of NXP and other related transactions and also for general corporate purposes. Our 2019 floating-rate notes, 2020 floating-rate notes, 2019 fixed-rate notes and 2020 fixed-rate notes issued in May 2017 for an aggregate principal amount of $4.0 billion are subject to a special mandatory redemption at a price equal to 101% of the aggregate principal amount, plus accrued and unpaid interest to, but excluding, the date of such mandatory redemption. The redemption is required on the first to occur of (i) the termination of the NXP purchase agreement or (ii) if the NXP transaction has not closed, by June 1, 2018.

[0001728949-18-000039:mdna:96]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, with $1.5 billion maturing in 2018 and the remaining with maturity dates in 2020 through 2045. Effective interest rates were between 2.21% and 4.74% at March 25, 2018. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001728949-18-000039:mdna:97]
[same as prior period, unchanged from 0001728949-18-000011:mdna:90]

[0001728949-18-000039:mdna:98]
Additional information regarding our outstanding debt at March 25, 2018 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt.”

[0001728949-18-000039:mdna:99]
Income Taxes. The Tax Legislation, which was signed into law during the first quarter of fiscal 2018, resulted in an estimated $5.3 billion charge related to the Toll Charge. We currently estimate that we will pay $3.2 billion for the Toll Charge, after application of certain tax credits (including those that are expected to be generated in fiscal 2018), which is payable in installments over eight years (8% in each of the first five years, 15% in year six, 20% in year seven and 25% in year eight) beginning on January 15, 2019.

[0001728949-18-000039:mdna:100]
Our cash, cash equivalents and marketable securities at March 25, 2018 consisted of $8.0 billion held by our United States-based entities and $31.6 billion held by our foreign entities. The Tax Legislation eliminated certain material tax effects on the repatriation of cash to the United States. As of March 25, 2018, we no longer consider available cash balances that existed at the end of fiscal 2017 related to undistributed pre-fiscal 2018 earnings and profits of certain U.S.-owned foreign subsidiaries to be indefinitely reinvested. We otherwise continue to consider other undistributed earnings of certain U.S.-owned foreign subsidiaries to be indefinitely reinvested based on our current plans for use and/or investment outside of the U.S., and therefore, no liability has been recorded for such taxes. However, as a result of the Tax Legislation, we are reassessing our intentions related to our indefinite reinvestment assertion. Should we decide to no longer indefinitely reinvest such earnings outside the U.S., we would have to adjust the income tax provision in the period such determination is made.

[0001728949-18-000039:mdna:101]
[same as prior period, unchanged from 0001728949-18-000011:mdna:94]

[0001728949-18-000039:mdna:102]
Capital Return Program. In the first six months of fiscal 2018, we repurchased and retired 6.8 million shares of our common stock for $425 million, before commissions. At March 25, 2018, $1.2 billion remained authorized for repurchase under our stock repurchase program. As a result of our proposed acquisition of NXP and the pending use of our cash and marketable securities, we currently expect to repurchase shares in the next few years to offset dilution from the issuance of common stock under our employee benefit plans.

[0001728949-18-000039:mdna:103]
In the first six months of fiscal 2018, we paid cash dividends totaling $1.7 billion, or $1.14 per share. On April 17, 2018, we announced a cash dividend of $0.62 per share on our common stock, payable on June 20, 2018 to stockholders of record as of the close of business on May 30, 2018. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001728949-18-000039:mdna:104]
Additional Capital Requirements. We believe our current cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements, in addition to the above matters, also include the items described below.

[0001728949-18-000039:mdna:105]
| • | In connection with our Cost Plan announced on January 16, 2018, we expect to incur approximately $400 million to $525 million in restructuring and restructuring-related charges, the majority of which are expected to result in cash payments. |

[0001728949-18-000039:mdna:106]
40

[0001728949-18-000039:mdna:107]
| • | Our purchase obligations at March 25, 2018, some of which relate to research and development activities and capital expenditures, totaled $3.2 billion and $1.4 billion for fiscal 2018 and 2019, respectively, and $646 million thereafter. |

[0001728949-18-000039:mdna:108]
| • | Our research and development expenditures were $2.8 billion in the first six months of fiscal 2018 and $5.5 billion in fiscal 2017, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications. |

[0001728949-18-000039:mdna:109]
| • | Cash outflows for capital expenditures were $411 million in the first six months of fiscal 2018 and $690 million in fiscal 2017. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001728949-18-000039:mdna:110]
| • | The TFTC imposed a fine on us, of which $771 million remained outstanding at March 25, 2018 (based on the exchange rate at March 25, 2018), which will be paid in monthly installments through December 2022. |

[0001728949-18-000039:mdna:111]
| • | The EC imposed a fine on us of approximately 997 million Euros (approximately $1.2 billion based on the exchange rate at March 25, 2018). We intend to provide financial guarantees by April 30, 2018 in lieu of cash payment to satisfy the obligation. Beginning on April 30, 2018, the fine will accrue interest at a rate of 1.50% per annum until it has been paid or annulled. |

[0001728949-18-000039:mdna:112]
[same as prior period, unchanged from 0001728949-18-000011:mdna:105]

[0001728949-18-000039:mdna:113]
[same as prior period, unchanged from 0001728949-18-000011:mdna:106]

[0001728949-18-000039:mdna:114]
[same as prior period, unchanged from 0001728949-18-000011:mdna:107]

[0001728949-18-000039:mdna:115]
Additional information regarding our financial commitments at March 25, 2018 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes,” “Note 5. Debt,” “Note 6. Commitments and Contingencies” and “Note 8. Acquisitions.”

[0001728949-18-000039:mdna:116]
[same as prior period, unchanged from 0001728949-18-000011:mdna:109]

[0001728949-18-000039:mdna:117]
[same as prior period, unchanged from 0001728949-18-000011:mdna:110]

[0001728949-18-000039:mdna:118]
[same as prior period, unchanged from 0001728949-18-000011:mdna:111]

[0001728949-18-000039:mdna:119]
[same as prior period, unchanged from 0001728949-18-000011:mdna:112]

[0001728949-18-000039:mdna:120]
[same as prior period, unchanged from 0001728949-18-000011:mdna:113]

[0001728949-18-000039:mdna:121]
Our proposed acquisition of NXP Semiconductors N.V. involves a number of risks, including, among others, the risk that we fail to complete the acquisition, regulatory risks, risks associated with our use of a significant portion of our cash and our taking on significant indebtedness, other financial risks, integration risks, and risk associated with the reactions of customers, suppliers and employees.

[0001728949-18-000039:mdna:122]
Our and NXP’s obligations to consummate the proposed transaction are subject to the satisfaction or waiver of certain conditions, including, among others: (i) the tender of a minimum number of NXP’s outstanding common shares in the tender offer commenced by a subsidiary of QUALCOMM Incorporated; (ii) the receipt of regulatory clearance from the Ministry of Commerce of the People’s Republic of China (MOFCOM), which we believe is being impacted by the current state of U.S./China trade relations; (iii) the absence of any law or order prohibiting the proposed transaction; (iv) there being no event that would have a material adverse effect on NXP; (v) the accuracy of the representations and warranties of NXP, subject to

[0001728949-18-000039:mdna:123]
certain exceptions, and NXP’s material compliance with its covenants, in the Purchase Agreement; and (vi) the completion of certain internal reorganization steps with respect to NXP and the disposition of certain non-core assets of NXP. We cannot provide assurance that the conditions to the completion of the proposed transaction will be satisfied, and if the proposed transaction is not completed, we would not realize any of the expected benefits.

[0001728949-18-000039:mdna:124]
The final regulatory approval required in connection with the proposed transaction may not be obtained or may contain materially burdensome conditions. If any conditions or changes to the structure of the proposed transaction are required to obtain this regulatory approval, they may have the effect of jeopardizing or delaying completion of the proposed transaction or reducing our anticipated benefits. If we agree to any material conditions in order to obtain this approval, our business and results of operations may be adversely affected.

[0001728949-18-000039:mdna:125]
[same as prior period, unchanged from 0001728949-18-000011:mdna:120]

[0001728949-18-000039:mdna:126]
If the proposed transaction is not completed, our stock price could fall to the extent that our current price reflects an assumption that we will complete it. Furthermore, if the proposed transaction is not completed and the Purchase Agreement is terminated, we would not realize any of the expected benefits of the proposed transaction, and we may suffer other consequences that could adversely affect our business, results of operations and stock price, including, among others:

[0001728949-18-000039:mdna:127]
[same as prior period, unchanged from 0001728949-18-000011:mdna:122]

[0001728949-18-000039:mdna:128]
[same as prior period, unchanged from 0001728949-18-000011:mdna:123]

[0001728949-18-000039:mdna:129]
[same as prior period, unchanged from 0001728949-18-000011:mdna:124]

[0001728949-18-000039:mdna:130]
| • | we may be subject to legal proceedings related to the proposed transaction or the failure to complete the proposed transaction; |

[0001728949-18-000039:mdna:131]
[same as prior period, unchanged from 0001728949-18-000011:mdna:126]

[0001728949-18-000039:mdna:132]
[same as prior period, unchanged from 0001728949-18-000011:mdna:127]

[0001728949-18-000039:mdna:133]
[same as prior period, unchanged from 0001728949-18-000011:mdna:128]

[0001728949-18-000039:mdna:134]
[same as prior period, unchanged from 0001728949-18-000011:mdna:129]

[0001728949-18-000039:mdna:135]
The proposed transaction may also result in significant charges or other liabilities that could adversely affect our results of operations, such as cash expenses and non-cash accounting charges incurred in connection with our acquisition and/or integration of the business and operations of NXP. Further, our failure to identify or accurately assess the magnitude of certain liabilities we are assuming in the proposed transaction could result in unexpected litigation or regulatory exposure, unfavorable accounting charges, unexpected increases in taxes due, a loss of anticipated tax benefits or other adverse effects on our business, results of operations, financial condition or cash flows.

[0001728949-18-000039:mdna:136]
[same as prior period, unchanged from 0001728949-18-000011:mdna:131]

[0001728949-18-000039:mdna:137]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on operators of wireless networks and our customers and licensees to adopt and/or implement the latest generation of these technologies for use in their networks, devices and services. We also depend on our customers and licensees to develop devices and services based on these technologies with value-added features to drive consumer demand for new 3G, 3G/4G multi-mode and 4G devices, and in the future 5G devices, as well as establishing the selling prices for such devices. Further, we depend on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries beyond traditional cellular communications, such as automotive, the internet of things (IoT) (including the connected home, smart cities, wearables, voice and music and robotics), data center, networking, computing, and machine learning, among others. We are also impacted by consumers’ rates of replacement of smartphones and other computing devices.

[0001728949-18-000039:mdna:138]
[same as prior period, unchanged from 0001728949-18-000011:mdna:134]

[0001728949-18-000039:mdna:139]
[same as prior period, unchanged from 0001728949-18-000011:mdna:135]

[0001728949-18-000039:mdna:140]
[same as prior period, unchanged from 0001728949-18-000011:mdna:136]

[0001728949-18-000039:mdna:141]
[same as prior period, unchanged from 0001728949-18-000011:mdna:137]

[0001728949-18-000039:mdna:142]
| • | government regulators delay making sufficient spectrum available for 3G, 4G, new spectrum sharing technologies that we are developing in conjunction with 3G and 4G, as well as for 5G, thereby restricting the ability of wireless operators to deploy or expand the use of these technologies; |

[0001728949-18-000039:mdna:143]
[same as prior period, unchanged from 0001728949-18-000011:mdna:139]

[0001728949-18-000039:mdna:144]
[same as prior period, unchanged from 0001728949-18-000011:mdna:140]

[0001728949-18-000039:mdna:145]
[same as prior period, unchanged from 0001728949-18-000011:mdna:141]

[0001728949-18-000039:mdna:146]
[same as prior period, unchanged from 0001728949-18-000011:mdna:142]

[0001728949-18-000039:mdna:147]
[same as prior period, unchanged from 0001728949-18-000011:mdna:143]

[0001728949-18-000039:mdna:148]
[same as prior period, unchanged from 0001728949-18-000011:mdna:144]

[0001728949-18-000039:mdna:149]
Our products, services and technologies face significant competition. We expect competition to increase as our current competitors expand their product offerings or reduce the prices of their products as part of a strategy to attract new business and/or customers, as new opportunities develop and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: device manufacturer concentrations and vertical integration; growth in demand, consumption and competition in certain geographic regions; government intervention and/or support of national industries and/or competitors; evolving industry standards and business models; evolving methods of transmission of voice and data communications; increasing data traffic and densification of wireless networks; convergence and aggregation of connectivity technologies (including Wi-Fi and LTE) in both devices and access points; consolidation of wireless technologies and infrastructure at the network edge; networking and connectivity trends (including cloud services); use of both licensed and unlicensed spectrum; the evolving nature of computing (including demand for always on, always connected capabilities); the speed of technological change (including the transition to smaller geometry process technologies); value-added features that drive selling prices as well as consumer demand for new 3G, 3G/4G multi-mode and 4G devices; turnkey, integrated products that incorporate hardware, software, user interface, applications and reference

[0001728949-18-000039:mdna:150]
43

[0001728949-18-000039:mdna:151]
designs; scalability; and the ability of the system technology to meet customers’ immediate and future network requirements. We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, technological and public policy changes and relatively low barriers to entry in certain segments of the industry. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape.

[0001728949-18-000039:mdna:152]
[same as prior period, unchanged from 0001728949-18-000011:mdna:146]

[0001728949-18-000039:mdna:153]
[same as prior period, unchanged from 0001728949-18-000011:mdna:147]

[0001728949-18-000039:mdna:154]
[same as prior period, unchanged from 0001728949-18-000011:mdna:149]

[0001728949-18-000039:mdna:155]
[same as prior period, unchanged from 0001728949-18-000011:mdna:150]

[0001728949-18-000039:mdna:156]
| • | maintain and/or accelerate demand for our integrated circuit products at the premium device tier, while increasing the adoption of our products in mid- and low-tier devices, in part by strengthening our integrated circuit product roadmap for, and developing channel relationships in, emerging regions, such as China and India, and by providing turnkey products, which incorporate our integrated circuits, for low- and mid-tier smartphones, tablets and laptops; |

[0001728949-18-000039:mdna:157]
[same as prior period, unchanged from 0001728949-18-000011:mdna:152]

[0001728949-18-000039:mdna:158]
[same as prior period, unchanged from 0001728949-18-000011:mdna:153]

[0001728949-18-000039:mdna:159]
[same as prior period, unchanged from 0001728949-18-000011:mdna:154]

[0001728949-18-000039:mdna:160]
[same as prior period, unchanged from 0001728949-18-000011:mdna:155]

[0001728949-18-000039:mdna:161]
| • | identify potential acquisition targets that will grow or sustain our business or address strategic needs, reach agreement on terms acceptable to us, close the transactions and effectively integrate these new businesses and/or technologies; |

[0001728949-18-000039:mdna:162]
[same as prior period, unchanged from 0001728949-18-000011:mdna:157]

[0001728949-18-000039:mdna:163]
[same as prior period, unchanged from 0001728949-18-000011:mdna:158]

[0001728949-18-000039:mdna:164]
| • | be a leader in 5G technology development, standardization, intellectual property creation and licensing, and develop and commercialize 5G integrated circuit products and services; and/or |

[0001728949-18-000039:mdna:165]
| • | continue to develop brand recognition to effectively compete against better known companies in computing and other consumer driven segments and to deepen our presence in significant emerging regions. |

[0001728949-18-000039:mdna:166]
Competition in any or all product tiers may result in the loss of certain business or customers, which would negatively impact our revenues, results of operations and cash flows. Such competition may also reduce average selling prices for our chipset products and/or the products of our customers and licensees. Certain of these dynamics are particularly pronounced in

[0001728949-18-000039:mdna:167]
emerging regions where competitors may have lower cost structures and/or may have a willingness and ability to accept lower prices and/or lower or negative margins on their products (particularly in China). Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0001728949-18-000039:mdna:168]
Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM) as well as companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Advanced Micro Devices, Inc., Broadcom Limited, Cirrus Logic, Cypress Semiconductor Corporation, HiSilicon Technologies, Intel, Marvell Technology, Maxim Integrated Products, MediaTek, Microchip Technology Inc., Murata Manufacturing Co., Ltd., Nordic Semiconductor, Nvidia, Qorvo Inc., Realtek Semiconductor, Renesas Electronics Corporation, Samsung Electronics, Sequans Communications S.A., Skyworks Solutions Inc., Sony Corporation and Spreadtrum Communications (which is controlled by Tsinghua Unigroup). Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to utilize their own internally-developed integrated circuit products, to use our competitors’ integrated circuit products and/or sell such products to others, including by bundling with other products, or to choose alternative technologies; lower cost structures and/or a willingness and ability to accept lower prices and lower or negative margins for their products, particularly in China; foreign government support of other technologies or competitors; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and original equipment manufacturers in certain geographic regions (such as China) and/or experience in adjacent industry segments outside traditional cellular industries (such as automotive and IoT); and/or a more established presence in certain regions.

[0001728949-18-000039:mdna:169]
[same as prior period, unchanged from 0001728949-18-000011:mdna:164]

[0001728949-18-000039:mdna:170]
[same as prior period, unchanged from 0001728949-18-000011:mdna:165]

[0001728949-18-000039:mdna:171]
The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or the cancelation of significant purchases by any of these customers, whether due to the use of their own integrated circuit products, our competitors’ integrated circuit products or otherwise, would reduce our revenues and could harm our ability to achieve or sustain expected results of operations, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development. Further, the concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have no control, and the timing and/or success of such introductions may cause our revenues and results of operations to fluctuate. Accordingly, if current industry dynamics and concentrations continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases, and the timing and size of any such future purchases, by these significant customers.

[0001728949-18-000039:mdna:172]
[same as prior period, unchanged from 0001728949-18-000011:mdna:167]

[0001728949-18-000039:mdna:173]
Further, companies that develop HLOS for devices, including leading technology companies, now sell their own devices. If we fail to effectively partner or continue partnering with these companies, or with their partners or customers, they may

[0001728949-18-000039:mdna:174]
decide not to purchase (either directly or through their contract manufacturers), or to reduce or discontinue their purchases of, our integrated circuit products.

[0001728949-18-000039:mdna:175]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products and/or intellectual property, or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001728949-18-000039:mdna:176]
Although we have several hundred licensees, our QTL segment derives a significant portion of its licensing revenues from a limited number of licensees. In the event that one or more of our significant licensees fail to meet their reporting and/or payment obligations, or we are unable to renew or modify one or more of such license agreements under similar terms, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our significant licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues.

[0001728949-18-000039:mdna:177]
[same as prior period, unchanged from 0001728949-18-000011:mdna:172]

[0001728949-18-000039:mdna:178]
[same as prior period, unchanged from 0001728949-18-000011:mdna:173]

[0001728949-18-000039:mdna:179]
In addition, as discussed in the prior risk factor, our industry is experiencing concentration of device share among a few companies at the premium tier, which gives them significant supply chain leverage. Further, those companies may utilize their own internally-developed integrated circuit products, or our competitors’ integrated circuit products, rather than our products in all or a portion of their devices. These dynamics may result in lower prices for and/or reduced sales of our premium-tier integrated circuit products.

[0001728949-18-000039:mdna:180]
[same as prior period, unchanged from 0001728949-18-000011:mdna:175]

[0001728949-18-000039:mdna:181]
[same as prior period, unchanged from 0001728949-18-000011:mdna:176]

[0001728949-18-000039:mdna:182]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, the imposition of some form of compulsory licensing and/or to weaken a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies to attempt to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated. In addition, certain licensees have disputed, underreported, underpaid, not reported and/or not paid royalties owed to us under their license agreements or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into or renewing license agreements

[0001728949-18-000039:mdna:183]
46

[0001728949-18-000039:mdna:184]
with us for their use of our intellectual property, and licensees and/or companies may continue to do so in the future. The fact that one or more licensees dispute, underreport, underpay, do not report and/or do not pay royalties owed to us may encourage other licensees to take similar actions and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Further, to the extent such licensees and/or companies increase their device share, the negative impact of their underreporting, underpayment, non-payment and/or non-reporting on our business, revenues, results of operations, financial condition and/or cash flows will be exacerbated.

[0001728949-18-000039:mdna:185]
We are currently subject to various litigation and governmental investigations and/or proceedings, some of which have arisen and may continue to arise out of the strategies described above. Certain legal matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money and/or the issuance of orders to cease certain conduct and/or modify our business practices. In addition, decisions or orders arising out of governmental investigations or proceedings could require us to renegotiate, or could encourage or embolden our licensees to demand to renegotiate, their license agreements with us (which could be on terms that are less favorable to us than existing terms), and such licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. See also the Risk Factor entitled “Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.”

[0001728949-18-000039:mdna:186]
[same as prior period, unchanged from 0001728949-18-000011:mdna:180]

[0001728949-18-000039:mdna:187]
[same as prior period, unchanged from 0001728949-18-000011:mdna:181]

[0001728949-18-000039:mdna:188]
Some SDOs, courts and governmental agencies have adopted and may in the future adopt some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001728949-18-000039:mdna:189]
[same as prior period, unchanged from 0001728949-18-000011:mdna:183]

[0001728949-18-000039:mdna:190]
[same as prior period, unchanged from 0001728949-18-000011:mdna:184]

[0001728949-18-000039:mdna:191]
We are currently subject to various governmental investigations and/or proceedings, particularly with respect to our licensing business, and certain such matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations in those matters include,

[0001728949-18-000039:mdna:192]
47

[0001728949-18-000039:mdna:193]
among others, that we do not license our cellular standard-essential patents separately from our other patents, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high and/or that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions). The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money, and/or the issuance of orders to cease certain conduct and/or modify our business practices. In addition, decisions or orders arising out of such governmental investigations or proceedings could require us to renegotiate, or could encourage or embolden our licensees to demand to renegotiate, their license agreements with us (which could be on terms that are less favorable to us than existing terms), and such licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. See also the Risk Factor entitled “Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.”

[0001728949-18-000039:mdna:194]
Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.

[0001728949-18-000039:mdna:195]
We are currently subject to various governmental investigations and private legal proceedings challenging our patent licensing practices as described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations in those matters include, among others, that we do not license our cellular standard-essential patents separately from our other patents, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high and/or that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions). We believe that the ultimate intent of these investigations and legal proceedings is to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0001728949-18-000039:mdna:196]
[same as prior period, unchanged from 0001728949-18-000011:mdna:189]

[0001728949-18-000039:mdna:197]
[same as prior period, unchanged from 0001728949-18-000011:mdna:190]

[0001728949-18-000039:mdna:198]
[same as prior period, unchanged from 0001728949-18-000011:mdna:191]

[0001728949-18-000039:mdna:199]
To the extent that we were required to implement any of these new licensing practices by modifying or renegotiating our existing license agreements, we would incur additional transaction costs, which may be significant, and we may incur delays in recognizing revenues until license negotiations were completed. The impact of any such changes to our licensing practices

[0001728949-18-000039:mdna:200]
could vary widely and by jurisdiction, depending on the specific outcomes and the geographic scope of such outcomes. In addition, if we were required to make modifications to our licensing practices in one jurisdiction, licensees and/or governmental agencies in other jurisdictions may attempt to obtain similar outcomes for themselves and/or for such other jurisdictions, as applicable.

[0001728949-18-000039:mdna:201]
[same as prior period, unchanged from 0001728949-18-000011:mdna:193]

[0001728949-18-000039:mdna:202]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our proprietary information, technologies and processes, including our patent portfolio. Policing unauthorized use of our products, technologies and proprietary information is difficult and time consuming. The steps we have taken have not always prevented, and we cannot be certain the steps we will take in the future will prevent, the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as United States laws or where the enforcement of such laws may be lacking or ineffective. Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that the European Union will adopt a unitary patent system in the next few years that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-18-000039:mdna:203]
We have had, and may in the future have, difficulty in certain circumstances in protecting or enforcing our intellectual property rights and/or contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and/or pay all or a portion of the royalties they owe to us; policies of foreign governments; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and/or challenges before competition agencies to our licensing business and/or the pricing and integration of additional features and functionality into our chipset products. Certain licensees have disputed, underreported, underpaid, not reported and/or not paid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into or renewing license agreements for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future. The fact that one or more licensees dispute, underreport, underpay, do not report and/or do not pay royalties owed to us may encourage other licensees to take similar actions and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements. Similarly, we provide access to certain of our intellectual property and/or proprietary and/or confidential business information to our direct and indirect customers and licensees, who may wrongfully use such intellectual property and/or information and/or wrongfully disclose such intellectual property and/or information to third parties, including our competitors.

[0001728949-18-000039:mdna:204]
We have entered into litigation in the past and may need to further litigate in the future to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. We are currently engaged in litigation matters related to protecting or enforcing our contract and/or intellectual property rights, and certain such matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” As a result of any such litigation, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in

[0001728949-18-000039:mdna:205]
49

[0001728949-18-000039:mdna:206]
turn result in other licensees either not complying with their existing license agreements and/or initiating litigation) and/or we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and/or cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion. See also the Risk Factor entitled “Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.”

[0001728949-18-000039:mdna:207]
[same as prior period, unchanged from 0001728949-18-000011:mdna:198]

[0001728949-18-000039:mdna:208]
[same as prior period, unchanged from 0001728949-18-000011:mdna:200]

[0001728949-18-000039:mdna:209]
[same as prior period, unchanged from 0001728949-18-000011:mdna:201]

[0001728949-18-000039:mdna:210]
However, our research, development and other investments in these new and expanded product areas and adjacent industry segments, and corresponding technologies, products and services, as well as in our existing, technologies, products and services and new technologies, such as 5G, use of both licensed and unlicensed spectrum, and convergence of cellular and Wi-Fi, may not succeed due to, among other reasons: new industry segments and/or consumer demand may not develop and/or grow as anticipated; our strategies and/or the strategies of our customers, licensees or partners may not be successful; improvements in alternate technologies in ways that reduce the advantages we anticipate from our investments; competitors’ products or services being more cost effective, having more capabilities or fewer limitations or being brought to market faster than our new products and services; and competitors having longer operating histories in industry segments that are new to us. We may also underestimate the costs of or overestimate the future revenues and/or margins that could result from these investments, and these investments may not, or may take many years to, generate material returns. Further, the automotive industry is subject to long design-in time frames, long product life cycles and a high degree of regulatory and safety requirements, necessitating suppliers to the industry to comply with stringent qualification processes, very low defect rates and high reliability standards, all of which results in a significant barrier to entry and increased costs.

[0001728949-18-000039:mdna:211]
[same as prior period, unchanged from 0001728949-18-000011:mdna:203]

[0001728949-18-000039:mdna:212]
[same as prior period, unchanged from 0001728949-18-000011:mdna:204]

[0001728949-18-000039:mdna:213]
[same as prior period, unchanged from 0001728949-18-000011:mdna:205]

[0001728949-18-000039:mdna:214]
We are subject to many environmental, health and safety laws and regulations in each jurisdiction in which we operate our manufacturing facilities, which govern, among other things, emissions of pollutants into the air, wastewater discharges,

[0001728949-18-000039:mdna:215]
50

[0001728949-18-000039:mdna:216]
the use and handling of hazardous substances, waste disposal, the investigation and remediation of soil and ground water contamination and the health and safety of our employees. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. We cannot make assurances that we will be at all times in compliance with such laws, regulations and permits. Certain environmental laws impose strict, and in certain circumstances, joint and several, liability on current or previous owners or operators of real property for the cost of investigation, removal or remediation of hazardous substances. Certain of these laws also assess liability on persons who arrange for hazardous substances to be sent to disposal or treatment facilities when such facilities are found to be contaminated. In addition, we could also be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage.

[0001728949-18-000039:mdna:217]
We have manufacturing facilities in Asia and Europe. If tsunamis, flooding, earthquakes, volcanic eruptions or other natural disasters, or geopolitical conflicts, were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, delay new production and shipments of inventory or result in costly repairs, replacements or other costs. In addition, natural disasters or geopolitical conflicts may result in disruptions in transportation, distribution channels or supply chains, or significant increases in the prices of raw materials.

[0001728949-18-000039:mdna:218]
[same as prior period, unchanged from 0001728949-18-000011:mdna:208]

[0001728949-18-000039:mdna:219]
[same as prior period, unchanged from 0001728949-18-000011:mdna:209]

[0001728949-18-000039:mdna:220]
[same as prior period, unchanged from 0001728949-18-000011:mdna:210]

[0001728949-18-000039:mdna:221]
We own a very strong portfolio of issued and pending patents related to 3G, 4G, 5G and other technologies. It is critical that we continue to evolve our patent portfolio, particularly in 5G. If we do not maintain a strong portfolio that is applicable to current and future standards (such as 5G), products and services, our future licensing revenues could be negatively impacted.

[0001728949-18-000039:mdna:222]
In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the IoT and automotive industry segments. We also seek to diversify and broaden our technology licensing programs to new industry segments in which we can utilize our technology leadership, such as wireless charging and other technologies. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties at all or that are equivalent to those that we receive for products used in cellular communications. Although we believe that our patented technologies are essential and useful to the commercialization of such services, any royalties we receive may be lower than those we receive from our current licensing program.

[0001728949-18-000039:mdna:223]
Further, the licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, certain of our license agreements (including essentially all of our recent agreements in China) are effective for a specified term. In order to license or to obtain a license to such later patents after the expiration of a specified term, or to receive royalties after the specified time period, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. Accordingly, to the extent not renewed on their terms or by election for an additional (generally multi-year) period, if applicable, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. We

[0001728949-18-000039:mdna:224]
[same as prior period, unchanged from 0001728949-18-000011:mdna:227]

[0001728949-18-000039:mdna:225]
might not be able to renew those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in renewing a license agreement prior to its expiration, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001728949-18-000039:mdna:226]
[same as prior period, unchanged from 0001728949-18-000011:mdna:213]

[0001728949-18-000039:mdna:227]
Our QCT segment primarily utilizes a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Other than the manufacturing facilities we now operate through our RF360 Holdings joint venture, we rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Under the turnkey model, our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services such as wafer bump, probe, assembly and the majority of our final test requirements. The semiconductor manufacturing foundries that supply products to our QCT segment are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders. The following could have an adverse effect on our ability to meet customer demands and/or negatively impact our revenues, business operations, profitability and/or cash flows:

[0001728949-18-000039:mdna:228]
[same as prior period, unchanged from 0001728949-18-000011:mdna:216]

[0001728949-18-000039:mdna:229]
[same as prior period, unchanged from 0001728949-18-000011:mdna:217]

[0001728949-18-000039:mdna:230]
[same as prior period, unchanged from 0001728949-18-000011:mdna:218]

[0001728949-18-000039:mdna:231]
[same as prior period, unchanged from 0001728949-18-000011:mdna:219]

[0001728949-18-000039:mdna:232]
[same as prior period, unchanged from 0001728949-18-000011:mdna:220]

[0001728949-18-000039:mdna:233]
[same as prior period, unchanged from 0001728949-18-000011:mdna:221]

[0001728949-18-000039:mdna:234]
[same as prior period, unchanged from 0001728949-18-000011:mdna:222]

[0001728949-18-000039:mdna:235]
[same as prior period, unchanged from 0001728949-18-000011:mdna:223]

[0001728949-18-000039:mdna:236]
Although we have long-term contracts with our suppliers, many of these contracts do not provide for long-term capacity commitments. To the extent we do not have firm commitments from our suppliers over a specific time period or for any

[0001728949-18-000039:mdna:237]
52

[0001728949-18-000039:mdna:238]
specific quantity, our suppliers may allocate, and in the past, have allocated, capacity to the production and testing of products for their other customers while reducing or limiting capacity to manufacture or test our products. Accordingly, capacity for our products may not be available when we need it or at reasonable prices. To the extent we do obtain long-term capacity commitments, we may incur additional costs related to those commitments and/or make non-refundable payments for capacity commitments that are not used.

[0001728949-18-000039:mdna:239]
[same as prior period, unchanged from 0001728949-18-000011:mdna:225]

[0001728949-18-000039:mdna:240]
[same as prior period, unchanged from 0001728949-18-000011:mdna:226]

[0001728949-18-000039:mdna:241]
[same as prior period, unchanged from 0001728949-18-000011:mdna:228]

[0001728949-18-000039:mdna:242]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and/or cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-18-000039:mdna:243]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (and/or on the sale of our customers’ devices using such products) and/or the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001728949-18-000039:mdna:244]
Certain legal matters, including certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-18-000039:mdna:245]
[same as prior period, unchanged from 0001728949-18-000011:mdna:232]

[0001728949-18-000039:mdna:246]
We engage in strategic acquisitions and other transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. We acquire businesses and other assets, including patents, technology, wireless spectrum and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications and new industry segments. Recent material transactions include our RF360 Holdings joint venture with TDK Corporation and our proposed acquisition of NXP. Many of our strategic activities entail a high degree of risk and require the use of domestic and/or foreign capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies, products or services. We may underestimate the costs and/or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our financial condition and results of operations, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001728949-18-000039:mdna:247]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, technology, products, processes, operations (including manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development and/or supply operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models (including manufacturing), geographic regions, industry segments and/or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of the combination.

[0001728949-18-000039:mdna:248]
[same as prior period, unchanged from 0001728949-18-000011:mdna:236]

[0001728949-18-000039:mdna:249]
If we are unsuccessful in executing our cost plan, our business and results of operations may be adversely affected.

[0001728949-18-000039:mdna:250]
On January 16, 2018, we announced a cost plan designed to align our cost structure to our long-term margin targets. As part of this plan, we will implement a series of targeted reductions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. We expect these cost reductions to be fully captured in fiscal 2019.

[0001728949-18-000039:mdna:251]
We cannot provide assurance that our cost plan will be successful, that anticipated cost savings will be realized, that our operations, business and financial results will improve and/or that these efforts will not disrupt our operations (beyond what is intended). Our ability to achieve the anticipated cost savings and other benefits within the expected time frames is subject to many estimates and assumptions, which are subject to significant economic, competitive and other uncertainties, some of which are beyond our control. Further, we may experience delays in the timing of these efforts and/or higher than expected or unanticipated costs in implementing them. Moreover, changes in the size, alignment or organization of our workforce could adversely affect employee morale and retention, relations with customers and business partners, our ability to develop and deliver products and services as anticipated and/or impair our ability to realize our current or future business and financial objectives. If we do not succeed in these efforts, if these efforts are more costly or time-consuming than expected, if our estimates and assumptions are not correct, if we experience delays or if other unforeseen events occur, our business and results of operations may be adversely affected.

[0001728949-18-000039:mdna:252]
[same as prior period, unchanged from 0001728949-18-000011:mdna:240]

[0001728949-18-000039:mdna:253]
Our business, products and services, and those of our customers and licensees, are subject to various laws and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies. Compliance with existing laws, regulations, policies and standards, the adoption of new laws, regulations, policies or standards, changes in the interpretation of existing laws, regulations, policies or standards, changes in the regulation of our activities by a government or standards body and/or rulings in court, regulatory, administrative or other proceedings relating to such laws, regulations, policies or standards, including, among others, those affecting licensing practices, competitive business practices, the use of our technology or products, protection of intellectual property, trade and trade protection including tariffs, foreign currency, investments or loans, spectrum availability and license issuance, adoption of standards, the provision of device subsidies by wireless operators to their customers, taxation, export control, privacy and data protection, environmental protection, health and safety, labor and employment, human rights, corporate governance, public disclosure or business conduct could have an adverse effect on our business and results of operations.

[0001728949-18-000039:mdna:254]
Government policies, particularly in China, that regulate the amount and timing of funds that may flow out of a country may impact the timing of our receipt of payments from our customers and/or licensees in such country, which may negatively impact our cash flows.

[0001728949-18-000039:mdna:255]
[same as prior period, unchanged from 0001728949-18-000011:mdna:243]

[0001728949-18-000039:mdna:256]
National, state and local environmental laws and regulations affect our operations around the world. These laws may make it more expensive to manufacture, have manufactured and sell products, and our costs could increase if our vendors (e.g., suppliers, third-party manufacturers or utility companies) pass on their costs to us. Any imposition of tariffs on our raw materials or our products could have a negative impact on our revenues and/or results of operations. We are also subject to laws and regulations impacting the manufacturing operations of our RF360 Holdings joint venture. See the Risk Factor entitled “There are numerous risks associated with our operation and control of manufacturing facilities of our joint venture with TDK, RF360 Holdings, including high fixed costs, environmental compliance and liability, exposure to natural disasters, timely supply of equipment and materials and manufacturing difficulties.”

[0001728949-18-000039:mdna:257]
[same as prior period, unchanged from 0001728949-18-000011:mdna:245]

[0001728949-18-000039:mdna:258]
[same as prior period, unchanged from 0001728949-18-000011:mdna:246]

[0001728949-18-000039:mdna:259]
[same as prior period, unchanged from 0001728949-18-000011:mdna:247]

[0001728949-18-000039:mdna:260]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe we will continue to see, an increase in customers requesting that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of a product’s source code and may expose related intellectual property to adverse licensing conditions. Licensing of such software may impose

[0001728949-18-000039:mdna:261]
certain obligations on us if we were to distribute derivative works of the open source software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Developing open source products, while adequately protecting the intellectual property rights upon which our licensing business depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property rights. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ adequate controls to protect our intellectual property rights, our use of open source software presents risks that could have an adverse effect on these rights and on our business.

[0001728949-18-000039:mdna:262]
[same as prior period, unchanged from 0001728949-18-000011:mdna:249]

[0001728949-18-000039:mdna:263]
Our stock price and earnings have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and/or earnings include those identified throughout this Risk Factors section; volatility of the stock market in general and technology-based companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. Further, increased volatility in the financial markets and/or overall economic conditions may reduce the amounts that we realize in the future on our cash equivalents and/or marketable securities and may reduce our earnings as a result of any impairment charges that we record to reduce recorded values of marketable securities to their fair values.

[0001728949-18-000039:mdna:264]
In the past, securities class action litigation has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-18-000039:mdna:265]
We maintain an extensive investment portfolio of varied holdings, which are generally classified as available-for-sale and are therefore recorded on our consolidated balance sheet at fair value, with unrealized gains or losses reported as a component of accumulated other comprehensive income. The fair values of our investments are subject to fluctuation based primarily on market price volatility, as well as the underlying operations of the associated investment, among other things. If the fair value of such investments decreases below their cost basis, as some of our previous investments have, we may be required in certain circumstances to recognize a loss in our results of operations. The sensitivity of and risks associated with the market value of our investment portfolio are described more fully in our Annual Report on Form 10-K for our fiscal year ended September 24, 2017 and in “Part I, Item 3. Quantitative and Qualitative Disclosures About Market Risk” in this Quarterly Report.

[0001728949-18-000039:mdna:266]
[same as prior period, unchanged from 0001728949-18-000011:mdna:254]

[0001728949-18-000039:mdna:267]
[same as prior period, unchanged from 0001728949-18-000011:mdna:255]

[0001728949-18-000039:mdna:268]
[same as prior period, unchanged from 0001728949-18-000011:mdna:256]

[0001728949-18-000039:mdna:269]
[same as prior period, unchanged from 0001728949-18-000011:mdna:257]

[0001728949-18-000039:mdna:270]
[same as prior period, unchanged from 0001728949-18-000011:mdna:258]

[0001728949-18-000039:mdna:271]
[same as prior period, unchanged from 0001728949-18-000011:mdna:259]

[0001728949-18-000039:mdna:272]
Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to general economic conditions, industry cycles and financial, business and other factors, including factors which negatively impact our cash flows, such as licensees withholding some or all of the royalty payments they owe to us or paying fines in connection with regulatory investigations, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations in the future to service our debt, we may be required to, among other things: refinance or restructure all or a portion of our indebtedness; reduce or delay planned capital or operating expenditures; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring

[0001728949-18-000039:mdna:273]
[same as prior period, unchanged from 0001728949-18-000011:mdna:272]

[0001728949-18-000039:mdna:274]
or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing and/or restructuring are higher than our current rates, interest expense related to such refinancing and/or restructuring would increase. If there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt in the future and/or the terms of such debt could be adversely affected.

[0001728949-18-000039:mdna:275]
[same as prior period, unchanged from 0001728949-18-000011:mdna:261]

[0001728949-18-000039:mdna:276]
Attempts by others to gain unauthorized access to our information technology systems are increasingly more sophisticated. These attempts, which might be related to industrial or other espionage, include covertly introducing malware to our computers and networks, including those in our manufacturing operations, and impersonating authorized users, among others. In addition, employees and former employees, in particular former employees who become employees of our competitors, customers or licensees, may misappropriate, use, publish or provide to our competitors, customers or licensees our intellectual property and/or proprietary or confidential business information. Similarly, we provide access to certain of our intellectual property and/or proprietary and/or confidential business information to our direct and indirect customers and licensees, who may wrongfully use such intellectual property and/or information and/or wrongfully disclose such intellectual property and/or information to third parties, including our competitors. We seek to detect and investigate all security incidents and to prevent their recurrence, but in some cases, we might be unaware of an incident or its magnitude and effects. The theft, unauthorized use or publication of our intellectual property and/or proprietary or confidential business information could harm our competitive position, reduce the value of our investment in research and development and other strategic initiatives and/or otherwise adversely affect our business. To the extent any security breach results in inappropriate disclosure of our customers’ or licensees’ proprietary or confidential information, we may incur liability. We expect to continue to devote significant resources to the security of our information technology systems.

[0001728949-18-000039:mdna:277]
[same as prior period, unchanged from 0001728949-18-000011:mdna:263]

[0001728949-18-000039:mdna:278]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-United States headquarters is located. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed. Our current examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. Although we believe that our tax estimates are reasonable at March 25, 2018, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision, results of operations and/or cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-18-000039:mdna:279]
On December 22, 2017, tax reform legislation known as the Tax Cuts and Jobs Act (the Tax Legislation) was enacted in the United States. Given the amount and complexity of the changes in tax law resulting from the Tax Legislation, we have not finalized the accounting for the income tax effects of the Tax Legislation. This includes the provisional amounts recorded in the six months ended March 25, 2018 related to the repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (Toll Charge) and the remeasurement of deferred taxes. Further, we are in the process of analyzing the effects of new taxes due on certain foreign income, such as GILTI (global intangible low-taxed income), BEAT (base-erosion anti-abuse tax), FDII (foreign-derived intangible income) and limitations on interest expense deductions (if certain conditions apply) that are effective starting in fiscal 2019, and other provisions of the Tax Legislation. The impact of the Tax Legislation may differ from this estimate, possibly materially, during the one-year measurement period due to, among other things, further refinement of our calculations, changes in interpretations and assumptions we have made, guidance that may be issued and actions we may take as a result of the Tax Legislation.

[0001728949-18-000039:mdna:280]
[same as prior period, unchanged from 0001728949-18-000011:mdna:266]

[0001728949-18-000039:mdna:281]
Tax rules may change in a manner that adversely affects our future reported results of operations or the way we conduct our business. Further changes in the tax laws of foreign jurisdictions could arise as a result of the base erosion and profit shifting (BEPS) project that was undertaken by the Organization for Economic Co-operation and Development (OECD). The OECD, which represents a coalition of member countries, recommended changes to numerous long-standing tax principles

[0001728949-18-000039:mdna:282]
57

[0001728949-18-000039:mdna:283]
related to transfer pricing. These changes, if adopted by countries, could increase tax uncertainty and may adversely affect our provision for income taxes, results of operations and/or cash flow. We have not yet determined what changes, if any, may be needed to our operations or structure to address BEPS. If our effective tax rates were to increase, particularly in the United States or Singapore, our results of operations, cash flows and/or financial condition could be adversely affected.

[0001728949-18-000039:mdna:284]
[same as prior period, unchanged from 0001728949-18-000011:mdna:268]

[0001728949-18-000039:mdna:285]
A decline in global, regional or local economic conditions or a slow-down in economic growth, including as a result of  trade protection policies, such as tariffs, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could have adverse, wide-ranging effects on demand for our products and for the products and services of our customers or licensees, particularly equipment manufacturers or others in the wireless communications industry who buy their products, such as wireless operators. Any prolonged economic downturn may result in a decrease in demand for our products or technologies; the insolvency of key suppliers, customers or licensees; delays in reporting and/or payments from our licensees and/or customers; failures by counterparties; and negative effects on wireless device inventories. In addition, our customers’ ability to purchase or pay for our products and services and network operators’ ability to upgrade their wireless networks could be adversely affected by economic conditions, leading to a reduction, cancelation or delay of orders for our products or services.

[0001728949-18-000039:mdna:286]
[same as prior period, unchanged from 0001728949-18-000011:mdna:270]

[0001728949-18-000039:mdna:287]
Our future success depends largely upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them, which may become increasingly difficult in an environment of cost reductions. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. The market for employees in our industry is extremely competitive. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001728949-18-000039:mdna:288]
[same as prior period, unchanged from 0001728949-18-000011:mdna:274]

[0001728949-18-000039:mdna:289]
[same as prior period, unchanged from 0001728949-18-000011:mdna:275]

[0001728949-18-000039:mdna:290]
[same as prior period, unchanged from 0001728949-18-000011:mdna:276]

[0001728949-18-000039:mdna:291]
[same as prior period, unchanged from 0001728949-18-000011:mdna:277]

[0001728949-18-000039:mdna:292]
[same as prior period, unchanged from 0001728949-18-000011:mdna:278]

[0001728949-18-000039:mdna:293]
[same as prior period, unchanged from 0001728949-18-000011:mdna:279]

[0001728949-18-000039:mdna:294]
[same as prior period, unchanged from 0001728949-18-000011:mdna:280]

[0001728949-18-000039:mdna:295]
[same as prior period, unchanged from 0001728949-18-000011:mdna:281]

[0001728949-18-000039:mdna:296]
The use of devices containing our products to interact with untrusted systems or otherwise access untrusted content creates a risk of exposing the system hardware and software in those devices to malicious attacks. While we continue to focus on this issue and are taking measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and use cases, and increasing the risk of security failures. Further, our products are inherently complex and may contain defects or errors that are detected only when the products are in use. Because our

[0001728949-18-000039:mdna:297]
58

[0001728949-18-000039:mdna:298]
products and services are responsible for critical functions in our customers’ products and/or networks, security failures, defects or errors in our products or services could have an adverse impact on us, on our customers and/or on the end users of our customers’ products. Such adverse impact could include shipment delays; product liability claims or recalls; write-offs of our inventories, property, plant and equipment and/or intangible assets; unfavorable purchase commitments; a shift of business to our competitors; a decrease in demand for connected devices and wireless services; damage to our reputation and our customer relationships; regulatory actions; and other financial liability or harm to our business. Further, security failures, defects or errors in the products of our customers or licensees could have an adverse impact on our results of operations and/or cash flows due to a delay or decrease in demand for our products or services generally, and our premium-tier products in particular, among other factors. Development of products and features in new domains of technology and the migration to integrated circuit technologies with smaller geometric feature sizes are complex and add risk to manufacturing yields and reliability. Further, manufacturing, testing, marketing and use of our products and those of our customers and licensees entail the risk of product liability.
