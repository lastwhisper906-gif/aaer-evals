# QCOM 8-K — 0001728949-18-000038 filed 2018-04-25

## item codes, every 8-K on or before 2018-04-25

- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2018-04-25

- none on or before 2018-04-25

## item 2.02 — earnings release, exhibit 99.1

[0001728949-18-000038:8k_2_02:1]
EX-99.1
2
qcom032518erex991.htm
EXHIBIT 99.1

[0001728949-18-000038:8k_2_02:2]
Exhibit

[0001728949-18-000038:8k_2_02:3]
Exhibit 99.1

[0001728949-18-000038:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001728949-18-000038:8k_2_02:5]
Qualcomm Contact:

[0001728949-18-000038:8k_2_02:6]
John Sinnott

[0001728949-18-000038:8k_2_02:7]
Vice President, Investor Relations

[0001728949-18-000038:8k_2_02:8]
Phone: 1-858-658-4813

[0001728949-18-000038:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001728949-18-000038:8k_2_02:10]
Qualcomm Announces Second Quarter Fiscal 2018 Results

[0001728949-18-000038:8k_2_02:11]
GAAP Revenues $5.3 billion

[0001728949-18-000038:8k_2_02:12]
GAAP EPS $0.24, Non-GAAP EPS $0.80

[0001728949-18-000038:8k_2_02:13]
SAN DIEGO - April 25, 2018 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal second quarter ended March 25, 2018.

[0001728949-18-000038:8k_2_02:14]
“Our fiscal second quarter results reflect better than expected performance in our semiconductor business and lower operating expenses,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “Looking forward, we remain committed to driving improved performance in fiscal 2019, consistent with our prior guidance.  We are making good progress on executing our $1 billion cost plan, are focused on closing our pending acquisition of NXP and are well positioned to drive the global commercialization of 5G.”

[0001728949-18-000038:8k_2_02:15]
Second Quarter Results (GAAP)*

[0001728949-18-000038:8k_2_02:16]
|  | Q2 Fiscal 2018 |  | Q2 Fiscal 2017 |  | Year-Over-Year Change |  | Q1 Fiscal 2018 |  | Sequential Change |
| Revenues | $5.3B |  | $5.0B |  | +5% |  | $6.1B |  | (13%) |
| Operating income | $0.4B |  | $0.7B |  | (40%) |  | $0.0B |  | N/M |
| Net income (loss) 1 | $0.4B |  | $0.7B |  | (52%) |  | ($6.0B) |  | N/M |
| Diluted earnings (loss) per share 1 | $0.24 |  | $0.50 |  | (52%) |  | ($4.03) |  | N/M |
| Operating cash flow 2 | $0.5B |  | $0.8B |  | (37%) |  | $1.8B |  | (71%) |

[0001728949-18-000038:8k_2_02:17]
1 Throughout this news release, net income (loss) and diluted earnings (loss) per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests), unless otherwise stated.

[0001728949-18-000038:8k_2_02:18]
2 In the first quarter of fiscal 2018, we adopted new accounting guidance that changed the presentation of certain cash flows related to share-based awards in the statement of cash flows. As a result, prior period cash flow amounts presented in this news release have been adjusted to conform to the current year presentation as follows: net cash provided by operating activities for the three months and six months ended March 26, 2017 increased by $5 million and $212 million, respectively, with corresponding offsets to net cash used in financing activities.

[0001728949-18-000038:8k_2_02:19]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 2 of 15 |

[0001728949-18-000038:8k_2_02:20]
Second Quarter Results (Non-GAAP)*

[0001728949-18-000038:8k_2_02:21]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding the Company’s use of Non-GAAP financial measures and detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001728949-18-000038:8k_2_02:22]
|  | Q2 Fiscal 2018 |  | Q2 Fiscal 2017 |  | Year-Over-Year Change |  | Q1 Fiscal 2018 |  | Sequential Change |
| Revenues | $5.2B |  | $6.0B |  | (13%) |  | $6.0B |  | (13%) |
| Operating income | $1.3B |  | $2.2B |  | (42%) |  | $1.6B |  | (22%) |
| Net income | $1.2B |  | $2.0B |  | (40%) |  | $1.5B |  | (19%) |
| Diluted earnings per share | $0.80 |  | $1.34 |  | (40%) |  | $0.98 |  | (18%) |

[0001728949-18-000038:8k_2_02:23]
* The first and second quarters of fiscal 2018 GAAP and Non-GAAP results were negatively impacted by our dispute with Apple and its contract manufacturers (who are Qualcomm licensees), as well as the previously disclosed dispute with another licensee.  We did not record any QTL revenues in the first or second quarters of fiscal 2018 for royalties due on sales of Apple’s or the other licensee’s products.  The second quarter of fiscal 2017 results included approximately $970 million in QTL revenues for royalties on sales of Apple’s or the other licensee’s products.  We expect the actions taken by these licensees will continue until the respective disputes are resolved.

[0001728949-18-000038:8k_2_02:24]
The following also should be considered in regard to the year-over-year and sequential comparisons:

[0001728949-18-000038:8k_2_02:25]
| • | The second quarter of fiscal 2018 GAAP results included: |

[0001728949-18-000038:8k_2_02:26]
| ◦ | $310 million of charges, or ($0.18) per share, that resulted from restructuring and restructuring-related costs related to our Cost Plan that was announced in January 2018. |

[0001728949-18-000038:8k_2_02:27]
| • | The second quarter of fiscal 2017 GAAP results included: |

[0001728949-18-000038:8k_2_02:28]
| ◦ | $974 million reduction to revenues, or ($0.48) per share, which was accrued, related to the BlackBerry arbitration decision. |

[0001728949-18-000038:8k_2_02:29]
| • | The first quarter of fiscal 2018 GAAP results included: |

[0001728949-18-000038:8k_2_02:30]
| ◦ | $6.0 billion charge, or ($4.03) per share, relating to the enactment of the Tax Cuts and Jobs Act (the Tax Legislation) in the United States (U.S.), which was comprised of $5.3 billion related to the estimated one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge), $562 million resulting from the estimated impact of remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate and $86 |

[0001728949-18-000038:8k_2_02:31]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 3 of 15 |

[0001728949-18-000038:8k_2_02:32]
million resulting from our decision to no longer indefinitely reinvest certain foreign earnings. We currently estimate that we will pay $3.2 billion for the Toll Charge, after application of certain tax credits, which is payable in installments over eight years beginning in January 2019.

[0001728949-18-000038:8k_2_02:33]
| ◦ | $1.2 billion charge, or ($0.76) per share, for the fine imposed by the European Commission (EC), for which we intend to provide financial guarantees by April 30, 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision to the General Court of the European Union. |

[0001728949-18-000038:8k_2_02:34]
Segment Results

[0001728949-18-000038:8k_2_02:35]
Second Quarter Fiscal 2018

[0001728949-18-000038:8k_2_02:36]
| (in millions except percentages) | Q2 Fiscal 2018 |  | Q2 Fiscal 2017 |  | Year-Over-Year Change |  | Q1 Fiscal 2018 |  | Sequential Change |
| QCT |  |  |  |  |  |  |  |  |  |
| Revenues | $3,897 |  | $3,676 |  | +6% |  | $4,651 |  | (16%) |
| EBT 1 | $608 |  | $475 |  | +28% |  | $955 |  | (36%) |
| EBT as % of revenues | 16% |  | 13% |  | +3% |  | 21% |  | (5%) |
| MSMTM chip shipments | 187 |  | 179 |  | +4% |  | 237 |  | (21%) |
| QTL |  |  |  |  |  |  |  |  |  |
| Revenues | $1,260 |  | $2,249 |  | (44%) |  | $1,299 |  | (3%) |
| EBT | $850 |  | $1,959 |  | (57%) |  | $887 |  | (4%) |
| EBT as % of revenues | 67% |  | 87% |  | (20%) |  | 68% |  | (1%) |

[0001728949-18-000038:8k_2_02:37]
1 Earnings (loss) before taxes

[0001728949-18-000038:8k_2_02:38]
Cash and Marketable Securities

[0001728949-18-000038:8k_2_02:39]
Our cash, cash equivalents and marketable securities totaled $39.6 billion at the end of the second quarter of fiscal 2018, compared to $28.9 billion a year ago and $39.9 billion at the end of the first quarter of fiscal 2018.  In addition, funds of $2.0 billion were held to collateralize the letters of credit related to our proposed acquisition of NXP, which have been included in other noncurrent assets since the end of the first quarter of fiscal 2017.

[0001728949-18-000038:8k_2_02:40]
Agreement to Acquire NXP

[0001728949-18-000038:8k_2_02:41]
We have entered into a definitive agreement, as amended, to acquire NXP Semiconductors N.V. (NXP) for estimated total cash consideration to be paid to NXP’s shareholders of $44 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers,

[0001728949-18-000038:8k_2_02:42]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 4 of 15 |

[0001728949-18-000038:8k_2_02:43]
secure identification, network processing and RF power products. The transaction is subject to receipt of regulatory clearance from the Ministry of Commerce in the People’s Republic of China and other closing conditions, including the tender of at least 70% of the issued and outstanding common shares of NXP in the offer.  We intend to fund the transaction with cash generated from our May 2017 debt offering, cash and cash equivalents held by our foreign entities, which will result in the use of a substantial portion of our cash and cash equivalents, and the use of our term loan facilities, which are expected to be drawn on at close.

[0001728949-18-000038:8k_2_02:44]
Return of Capital to Stockholders

[0001728949-18-000038:8k_2_02:45]
During the second quarter of fiscal 2018, we returned $1.0 billion to stockholders, including $845 million, or $0.57 per share, of cash dividends paid and $200 million through repurchases of 3.1 million shares of common stock.  On April 17, 2018, we announced a cash dividend of $0.62 per share payable on June 20, 2018 to stockholders of record as of the close of business on May 30, 2018, which represents a 9 percent increase over our prior quarterly dividend.

[0001728949-18-000038:8k_2_02:46]
Effective Income Tax Rates

[0001728949-18-000038:8k_2_02:47]
Our effective income tax rates for the second quarter of fiscal 2018 were 1 percent benefit for GAAP and 4 percent provision for Non-GAAP.  The estimated fiscal 2018 GAAP and Non-GAAP effective tax rates included the impact of lower income from U.S. operations, primarily related to decreased QTL revenues from Apple’s contract manufacturers and the other licensee in dispute, as well as the reduced U.S. corporate tax rate, which was effective January 1, 2018. The estimated fiscal 2018 GAAP effective tax rate included the impact of the Tax Legislation and EC fine, which is not deductible for tax purposes and is attributable to a foreign jurisdiction.

[0001728949-18-000038:8k_2_02:48]
As a result of Tax Legislation, we are currently evaluating potential restructuring options that will reduce our fiscal 2018 estimated annual effective tax rates to approximately 410 percent to 417 percent provision for GAAP and approximately 1 percent benefit to 1 percent provision for Non-GAAP (compared to the annual estimated effective rates of 438 percent provision for GAAP and 5 percent provision for Non-GAAP that were estimated for purposes of our second quarter of fiscal 2018).  Our third quarter fiscal 2018 outlook assumes such restructuring occurs, which results in third quarter fiscal 2018 estimated effective tax rates of 38 percent to 47 percent benefit for GAAP and 20 percent to 25 percent benefit for Non-GAAP.

[0001728949-18-000038:8k_2_02:49]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 5 of 15 |

[0001728949-18-000038:8k_2_02:50]
Business Outlook

[0001728949-18-000038:8k_2_02:51]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment, certain derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001728949-18-000038:8k_2_02:52]
We have not included estimates related to the operating results of our proposed acquisition of NXP in our third quarter fiscal 2018 outlook.

[0001728949-18-000038:8k_2_02:53]
Our financial guidance for the third quarter of fiscal 2018 excludes QTL revenues for royalties due on sales of Apple products by Apple’s contract manufacturers, as well as sales of products by the other licensee in dispute, as we expect the actions taken by these licensees will continue until the respective disputes are resolved.

[0001728949-18-000038:8k_2_02:54]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 6 of 15 |

[0001728949-18-000038:8k_2_02:55]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001728949-18-000038:8k_2_02:56]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001728949-18-000038:8k_2_02:57]
|  |  | Q3 FY17Results (1) | Current Guidance Q3 FY18 Estimates (2) (3) |  |
|  | Revenues | $5.4B | $4.8B - $5.6B |  |  |
|  | Year-over-year change |  | decrease 11% - increase 4% |  |  |
|  | GAAP diluted earnings per share (EPS) | $0.58 | $0.35 - $0.50 |  |  |
|  | Year-over-year change |  | decrease 14% - 40% |  |  |
|  | Less diluted EPS attributable to QSI | $0.02 |  | $0.03 |  |  |
|  | Less diluted EPS attributable to share-based compensation | ($0.13) |  | ($0.13 | ) |  |
|  | Less diluted EPS attributable to other items | ($0.14) | ($0.15) - ($0.20) |  |  |
|  | Non-GAAP diluted EPS | $0.83 | $0.65 - $0.75 |  |  |
|  | Year-over-year change |  | decrease 10% - 22% |  |  |
|  | Other Information |  |  |  |
|  | MSM chip shipments | 187 | M | 185M - 205M |  |  |
|  | Year-over-year change |  | decrease 1% - increase 10% |  |  |
|  | QTL revenues | $1.2B | $0.85B - $1.05B |  |  |
|  | Year-over-year change |  | decrease 10% - 27% |  |  |

[0001728949-18-000038:8k_2_02:58]
| (1) | Our financial guidance for the third quarter of fiscal 2018 excludes QTL revenues for royalties due on sales of Apple’s products by Apple’s contract manufacturers, as well as sales of products by the other licensee in dispute, as we expect the actions taken by these licensees will continue until the respective disputes are resolved. The third quarter of fiscal 2017 results also excluded QTL revenues for royalties due on sales of Apple’s products by Apple’s contract manufacturers, as well as sales of products by the other licensee in dispute. |

[0001728949-18-000038:8k_2_02:59]
| (2) | Our guidance for diluted EPS attributable to other items for the third quarter of fiscal 2018 is primarily attributable to acquisition-related items and restructuring and restructuring-related items. Our guidance for Non-GAAP diluted EPS excludes a reduction to revenues related to a portion of a business arrangement that resolves a legal dispute. |

[0001728949-18-000038:8k_2_02:60]
| (3) | As a result of Tax Legislation, we are currently evaluating potential restructuring options that will reduce our fiscal 2018 GAAP and Non-GAAP estimated annual effective tax rates, which results in third quarter fiscal 2018 GAAP and Non-GAAP estimated effective tax rates of 38 percent to 47 percent benefit and 20 percent to 25 percent benefit, respectively. Our guidance for GAAP and Non-GAAP diluted EPS includes an estimated tax benefit resulting from such potential restructuring options of $0.07 to $0.12 per share and $0.10 to $0.15 per share, respectively. |

[0001728949-18-000038:8k_2_02:61]
Sums may not equal total due to rounding.

[0001728949-18-000038:8k_2_02:62]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 7 of 15 |

[0001728949-18-000038:8k_2_02:63]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-18-000038:8k_2_02:64]
The following tables reconcile our GAAP results to our Non-GAAP results ($ and shares in millions, except per share data):

[0001728949-18-000038:8k_2_02:65]
|  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) | Non-GAAP Results |
| Q2 FISCAL 2018 |  |  |  |  |  |  |  |
| Revenues | $5,261 |  | $30 |  |  | $— |  |  |  | $— |  |  | $5,231 |  |
| Operating income (loss) | 441 |  | 10 |  | (222) |  | (628) |  | 1,281 |  |
| EBT | 358 |  | 40 |  | (222) |  | (696) |  | 1,236 |  |
| EBT as % of revenues | 7 | % |  |  |  |  |  |  |  | 24 | % |  |
| Net income (loss) | 363 |  | 30 |  | (193) |  | (661) |  | 1,187 |  |
| Diluted EPS | $0.24 |  | $0.02 |  | ($0.13) |  | ($0.44) |  | $0.80 |  |
| Diluted shares | 1,494 |  | 1,494 |  | 1,494 |  | 1,494 |  | 1,494 |  |
| Q1 FISCAL 2018 |  |  |  |  |  |  |  |
| Revenues | $6,068 |  | $30 |  |  | $— |  |  |  | $— |  |  | $6,038 |  |
| Operating income (loss) | 29 |  | 9 |  | (248) |  | (1,367) |  | 1,635 |  |
| EBT | (27) |  | 11 |  | (248) |  | (1,373) |  | 1,583 |  |
| EBT as % of revenues | — | % |  |  |  |  |  |  |  | 26 | % |  |
| Net (loss) income | (5,953) |  | 8 |  | (199) |  | (7,230) |  | 1,468 |  |
| Diluted EPS (c) | ($4.03) |  | $0.01 |  | ($0.13) |  | ($4.89) |  | $0.98 |  |
| Diluted shares (c) | 1,477 |  | 1,491 |  | 1,491 |  | 1,491 |  | 1,491 |  |
| Q2 FISCAL 2017 |  |  |  |  |  |  |  |
| Revenues | $5,016 |  |  | $— |  |  |  | $— |  |  |  | ($974 | ) |  | $5,990 |  |
| Operating income (loss) | 729 |  | (17) |  | (246) |  | (1,228) |  | 2,220 |  |
| EBT | 857 |  | — |  |  | (246) |  | (1,239) |  | 2,342 |  |
| EBT as % of revenues | 17 | % |  |  |  |  |  |  |  | 39 | % |  |
| Net income (loss) | 749 |  | — |  |  | (210) |  | (1,030) |  | 1,989 |  |
| Diluted EPS | $0.50 |  | $0.00 |  | ($0.14) |  | ($0.69) |  | $1.34 |  |
| Diluted shares | 1,489 |  | 1,489 |  | 1,489 |  | 1,489 |  | 1,489 |  |

[0001728949-18-000038:8k_2_02:66]
| (a) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” herein for further details. |

[0001728949-18-000038:8k_2_02:67]
| (b) | Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates.” Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001728949-18-000038:8k_2_02:68]
| (c) | As a result of the net loss in our GAAP results in the first quarter of fiscal 2018, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of GAAP diluted loss per share. The diluted EPS impacts of the $6.0 billion charge resulting from the Tax Legislation and the $1.2 billion charge related to the fine imposed by the EC were calculated using the GAAP diluted shares. Amounts in all other columns included the common share equivalents issuable under share-based compensation plans in the calculation of diluted earnings per share because the Company reported Non-GAAP net income. |

[0001728949-18-000038:8k_2_02:69]
Sums may not equal totals due to rounding.

[0001728949-18-000038:8k_2_02:70]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 8 of 15 |

[0001728949-18-000038:8k_2_02:71]
Supplemental Information and Reconciliations

[0001728949-18-000038:8k_2_02:72]
(Unaudited)

[0001728949-18-000038:8k_2_02:73]
|  | Q2 FISCAL 2018 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results |
|  | Cost of revenues |  | $2,239 |  |  | $17 |  |  | $10 |  |  | $102 |  |  | $2,110 |  |
|  | Research and development (R&D) expenses |  | 1,402 |  |  | — |  |  |  | 151 |  |  | 2 |  |  | 1,249 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 869 |  |  | 3 |  |  | 61 |  |  | 214 |  |  | 591 |  |
|  | Other expenses |  | 310 |  |  | — |  |  |  | — |  |  |  | 310 |  |  | — |  |  |
|  | Interest expense |  | 179 |  |  | — |  |  |  | — |  |  |  | 3 |  |  | 176 |  |
|  | Investment and other income (loss), net |  | 96 |  |  | 30 |  |  | — |  |  |  | (65) |  |  | 131 | (b) |

[0001728949-18-000038:8k_2_02:74]
| (a) | Other items excluded from Non-GAAP results included $321 million of acquisition-related charges, $310 million of restructuring and restructuring-related charges related to our Cost Plan and $65 million of foreign currency transaction losses related to the EC and Taiwan Fair Trade Commission fines, net of associated gains on derivative instruments. |

[0001728949-18-000038:8k_2_02:75]
| (b) | Included $149 million in interest and dividend income, $6 million of net gains on derivative instruments and $4 million in net realized gains on investments, partially offset by $20 million in foreign currency losses and $8 million in equity in net losses of investees. |

[0001728949-18-000038:8k_2_02:76]
Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates

[0001728949-18-000038:8k_2_02:77]
(Unaudited)

[0001728949-18-000038:8k_2_02:78]
| ($ in millions) |  | GAAP Results |  |  | Less QSI | Less Share-Based Compensation | Less Other Items (c) (d) (e) |  | Non-GAAP Results |  |
| Q2 FISCAL 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 358 |  |  |  | $ | 40 |  |  |  | $ | (222 | ) |  |  | $ | (696 | ) |  |  | $ | 1,236 |  |  |
| Income tax benefit (expense) |  | 5 |  |  |  | (10 | ) |  |  | 29 |  |  |  | 35 |  |  |  | (49 | ) |  |
| Net income (loss) (a) |  | $ | 363 |  |  |  | $ | 30 |  |  |  | $ | (193 | ) |  |  | $ | (661 | ) |  |  | $ | 1,187 |  |  |
| Tax rate |  | (1 | %) |  |  | 1 | % | (b) |  |  |  | (3 | %) | (b) |  |  | (3 | %) | (b) |  |  | 4 | % |  |
| FISCAL 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Estimated annual tax rate |  | 438 | % |  |  | 1 | % | (b) |  |  |  | (3 | %) | (b) |  |  | 435 | % | (b) |  |  | 5 | % |  |
| FISCAL 2018 Guidance (f) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Estimated annual tax rate |  | 410% - 417% |  |  |  | 1% |  |  |  | (5%) |  |  |  | 415% - 420% |  |  |  | (1%) - 1% |  |  |
| Estimated Q3 Fiscal 2018 tax rate |  | (38%) - (47%) |  |  |  | 4% |  |  |  | (16%) |  |  |  | (6%) - (10%) |  |  |  | (20%) - (25%) |  |  |
| Estimated Q3 Fiscal 2018 Diluted EPS impact of potential tax restructuring |  | $0.07 - $0.12 |  |  |  | $0.00 |  |  |  | $0.01 |  |  |  | ($0.04) |  |  |  | $0.10 - $0.15 |  |  |

[0001728949-18-000038:8k_2_02:79]
| (a) | Before adjustments for noncontrolling interests. |

[0001728949-18-000038:8k_2_02:80]
| (b) | The incremental effect of our adjustments to the Non-GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001728949-18-000038:8k_2_02:81]
| (c) | In the second quarter of fiscal 2018, the tax benefit in the “Other Items” column included a $65 million tax benefit for the combined effect of other items in EBT, a $54 million tax benefit for the tax effect of acquisition-related items in EBT and an $8 million net benefit related to the refinement of estimates related to the combined effect of the Toll Charge, the remeasurement of deferred tax assets and liabilities and our decision to no longer indefinitely reinvest certain foreign earnings, all of which resulted from the Tax Legislation, partially offset by a $92 million tax expense to reconcile the tax provision for each column to the total GAAP tax provision for the quarter. |

[0001728949-18-000038:8k_2_02:82]
| (d) | In fiscal 2018, the estimated annual effective tax rate for the “Other Items” column included a $5.9 billion charge related to the combined effect of the Toll Charge, the remeasurement of deferred tax assets and liabilities and our decision to no longer indefinitely reinvest certain foreign earnings, all of which resulted from the Tax Legislation, partially offset by a $131 million tax benefit for the tax effect of acquisition-related items in EBT and an $87 million tax benefit for the combined effect of other items in EBT. |

[0001728949-18-000038:8k_2_02:83]
| (e) | Our guidance for the third quarter of fiscal 2018 for the estimated tax rate included in the “Other Items” column is primarily attributed to tax expense to reconcile the tax provision for each column to the total GAAP tax provision for the quarter, partially offset by a tax benefit for the tax effect of acquisition-related items in EBT. |

[0001728949-18-000038:8k_2_02:84]
| (f) | As a result of Tax Legislation, we are currently evaluating potential restructuring options that will reduce our fiscal 2018 GAAP and Non-GAAP estimated annual tax rates, which we have reflected in our third quarter fiscal 2018 outlook. |

[0001728949-18-000038:8k_2_02:85]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 9 of 15 |

[0001728949-18-000038:8k_2_02:86]
Conference Call

[0001728949-18-000038:8k_2_02:87]
Qualcomm’s fiscal second quarter 2018 earnings conference call will be broadcast live on April 25, 2018, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 39466125.

[0001728949-18-000038:8k_2_02:88]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-18-000038:8k_2_02:89]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results used herein are presented herein.

[0001728949-18-000038:8k_2_02:90]
The Company uses Non-GAAP financial information: (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income (loss) and diluted earnings (loss) per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial

[0001728949-18-000038:8k_2_02:91]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 10 of 15 |

[0001728949-18-000038:8k_2_02:92]
information is also used by institutional investors and analysts in evaluating the Company’s business and assessing trends and future expectations.

[0001728949-18-000038:8k_2_02:93]
Non-GAAP information used by management excludes its QSI segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-18-000038:8k_2_02:94]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001728949-18-000038:8k_2_02:95]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001728949-18-000038:8k_2_02:96]
| • | Certain other items are excluded because management views such items as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001728949-18-000038:8k_2_02:97]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items, as well as any effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property, third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition. Starting with acquisitions in the second quarter of fiscal 2017, the Company excludes recognition of the step-up of property, plant and equipment from the net book value based on the original cost basis to fair value. Such charges related to acquisitions that were completed prior to the second quarter of fiscal 2017 continue to be allocated to the segments, and such amounts are not material. |

[0001728949-18-000038:8k_2_02:98]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. |

[0001728949-18-000038:8k_2_02:99]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. In the first six months of fiscal 2018, the Company excluded the full impact |

[0001728949-18-000038:8k_2_02:100]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 11 of 15 |

[0001728949-18-000038:8k_2_02:101]
of the Toll Charge, including the portion that relates to earnings and profits of U.S.-owned foreign subsidiaries generated in the first quarter of fiscal 2018.

[0001728949-18-000038:8k_2_02:102]
About Qualcomm

[0001728949-18-000038:8k_2_02:103]
Qualcomm invents breakthrough technologies that transform how the world connects and communicates.  When we connected the phone to the Internet, the mobile revolution was born.  Today, our inventions are the foundation for life-changing products, experiences, and industries.  As we lead the world to 5G, we envision this next big change in cellular technology spurring a new era of intelligent, connected devices and enabling new opportunities in connected cars, remote delivery of health care services, and the IoT - including smart cities, smart homes, and wearables.  Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, all of our engineering, research and development functions, and all of our products and services businesses, including, our QCT semiconductor business.  For more information, visit www.qualcomm.com.

[0001728949-18-000038:8k_2_02:104]
Note Regarding Forward-Looking Statements

[0001728949-18-000038:8k_2_02:105]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 12 of 15 |

[0001728949-18-000038:8k_2_02:106]
###

[0001728949-18-000038:8k_2_02:107]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries. Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-18-000038:8k_2_02:108]
MSM is a product of Qualcomm Technologies, Inc.

[0001728949-18-000038:8k_2_02:109]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 13 of 15 |

[0001728949-18-000038:8k_2_02:110]
Qualcomm Incorporated

[0001728949-18-000038:8k_2_02:111]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001728949-18-000038:8k_2_02:112]
(In millions, except per share data)

[0001728949-18-000038:8k_2_02:113]
(Unaudited)

[0001728949-18-000038:8k_2_02:114]
|  | March 25, 2018 |  | September 24, 2017 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 37,946 |  |  | $ | 35,029 |  |
| Marketable securities | 1,625 |  |  | 2,279 |  |
| Accounts receivable, net | 3,535 |  |  | 3,632 |  |
| Inventories | 1,797 |  |  | 2,035 |  |
| Other current assets | 641 |  |  | 618 |  |
| Total current assets | 45,544 |  |  | 43,593 |  |
| Marketable securities | 35 |  |  | 1,270 |  |
| Deferred tax assets | 1,126 |  |  | 2,900 |  |
| Property, plant and equipment, net | 3,224 |  |  | 3,216 |  |
| Goodwill | 6,676 |  |  | 6,623 |  |
| Other intangible assets, net | 3,435 |  |  | 3,737 |  |
| Other assets | 4,086 |  |  | 4,147 |  |
| Total assets | $ | 64,126 |  |  | $ | 65,486 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,454 |  |  | $ | 1,971 |  |
| Payroll and other benefits related liabilities | 1,262 |  |  | 1,183 |  |
| Unearned revenues | 502 |  |  | 502 |  |
| Short-term debt | 3,733 |  |  | 2,495 |  |
| Other current liabilities | 5,709 |  |  | 4,756 |  |
| Total current liabilities | 12,660 |  |  | 10,907 |  |
| Unearned revenues | 1,803 |  |  | 2,003 |  |
| Income taxes payable | 3,277 |  |  | — |  |
| Long-term debt | 19,361 |  |  | 19,398 |  |
| Other liabilities | 3,206 |  |  | 2,432 |  |
| Total liabilities | 40,307 |  |  | 34,740 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,482 and 1,474 shares issued and outstanding, respectively | 495 |  |  | 274 |  |
| Retained earnings | 22,779 |  |  | 30,088 |  |
| Accumulated other comprehensive income | 545 |  |  | 384 |  |
| Total stockholders’ equity | 23,819 |  |  | 30,746 |  |
| Total liabilities and stockholders’ equity | $ | 64,126 |  |  | $ | 65,486 |  |

[0001728949-18-000038:8k_2_02:115]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 14 of 15 |

[0001728949-18-000038:8k_2_02:116]
Qualcomm Incorporated

[0001728949-18-000038:8k_2_02:117]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-18-000038:8k_2_02:118]
(In millions, except per share data)

[0001728949-18-000038:8k_2_02:119]
(Unaudited)

[0001728949-18-000038:8k_2_02:120]
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | March 25, 2018 |  | March 26, 2017 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,936 |  |  | $ | 3,689 |  |  | $ | 8,639 |  |  | $ | 7,828 |  |
| Licensing | 1,325 |  |  | 1,327 |  |  | 2,690 |  |  | 3,187 |  |
| Total revenues | 5,261 |  |  | 5,016 |  |  | 11,329 |  |  | 11,015 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of revenues | 2,239 |  |  | 2,208 |  |  | 4,902 |  |  | 4,651 |  |
| Research and development | 1,402 |  |  | 1,386 |  |  | 2,822 |  |  | 2,697 |  |
| Selling, general and administrative | 869 |  |  | 615 |  |  | 1,641 |  |  | 1,206 |  |
| Other | 310 |  |  | 78 |  |  | 1,493 |  |  | 954 |  |
| Total costs and expenses | 4,820 |  |  | 4,287 |  |  | 10,858 |  |  | 9,508 |  |
| Operating income | 441 |  |  | 729 |  |  | 471 |  |  | 1,507 |  |
| Interest expense | (179 | ) |  | (107 | ) |  | (350 | ) |  | (197 | ) |
| Investment and other income, net | 96 |  |  | 235 |  |  | 211 |  |  | 417 |  |
| Income before income taxes | 358 |  |  | 857 |  |  | 332 |  |  | 1,727 |  |
| Income tax benefit (expense) | 5 |  |  | (108 | ) |  | (5,922 | ) |  | (296 | ) |
| Net income (loss) | $ | 363 |  |  | $ | 749 |  |  | $ | (5,590 | ) |  | $ | 1,431 |  |
| Basic earnings (loss) per share | $ | 0.25 |  |  | $ | 0.51 |  |  | $ | (3.78 | ) |  | $ | 0.97 |  |
| Diluted earnings (loss) per share | $ | 0.24 |  |  | $ | 0.50 |  |  | $ | (3.78 | ) |  | $ | 0.96 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,482 |  |  | 1,477 |  |  | 1,479 |  |  | 1,478 |  |
| Diluted | 1,494 |  |  | 1,489 |  |  | 1,479 |  |  | 1,492 |  |
| Dividends per share announced | $ | 0.57 |  |  | $ | 0.53 |  |  | $ | 1.14 |  |  | $ | 1.06 |  |

[0001728949-18-000038:8k_2_02:121]
| Qualcomm Announces Second Quarter Fiscal 2018 Results | Page 15 of 15 |

[0001728949-18-000038:8k_2_02:122]
Qualcomm Incorporated

[0001728949-18-000038:8k_2_02:123]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-18-000038:8k_2_02:124]
(In millions)

[0001728949-18-000038:8k_2_02:125]
(Unaudited)

[0001728949-18-000038:8k_2_02:126]
|  | Three Months Ended |  | Six Months Ended |
|  | March 25, 2018 |  | March 26, 2017 |  | March 25, 2018 |  | March 26, 2017 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 363 |  |  | $ | 749 |  |  | $ | (5,590 | ) |  | $ | 1,431 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 388 |  |  | 342 |  |  | 751 |  |  | 671 |  |
| Income tax provision (less than) in excess of income tax payments | (220 | ) |  | (117 | ) |  | 5,477 |  |  | (230 | ) |
| Interest expense in excess of interest payments | 115 |  |  | 88 |  |  | 207 |  |  | 129 |  |
| Non-cash portion of share-based compensation expense | 222 |  |  | 246 |  |  | 470 |  |  | 485 |  |
| Net realized gains on marketable securities and other investments | (50 | ) |  | (88 | ) |  | (73 | ) |  | (236 | ) |
| Indefinite and long-lived asset impairment charges | 33 |  |  | 2 |  |  | 33 |  |  | 34 |  |
| Impairment losses on marketable securities and other investments | 11 |  |  | 5 |  |  | 20 |  |  | 148 |  |
| Other items, net | 81 |  |  | 13 |  |  | 46 |  |  | (32 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (487 | ) |  | (1,822 | ) |  | 94 |  |  | (1,691 | ) |
| Inventories | 81 |  |  | 109 |  |  | 243 |  |  | (245 | ) |
| Other assets | 126 |  |  | 123 |  |  | 70 |  |  | 107 |  |
| Trade accounts payable | (263 | ) |  | (469 | ) |  | (511 | ) |  | (677 | ) |
| Payroll, benefits and other liabilities | 166 |  |  | 1,635 |  |  | 1,166 |  |  | 2,592 |  |
| Unearned revenues | (50 | ) |  | 4 |  |  | (125 | ) |  | (80 | ) |
| Net cash provided by operating activities | 516 |  |  | 820 |  |  | 2,278 |  |  | 2,406 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (185 | ) |  | (122 | ) |  | (411 | ) |  | (251 | ) |
| Purchases of available-for-sale marketable securities | (131 | ) |  | (4,685 | ) |  | (5,758 | ) |  | (8,802 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 4,955 |  |  | 6,255 |  |  | 7,659 |  |  | 13,146 |  |
| Deposits of investments designated as collateral | — |  |  | (50 | ) |  | — |  |  | (2,000 | ) |
| Acquisitions and other investments, net of cash acquired | (48 | ) |  | (1,325 | ) |  | (170 | ) |  | (1,382 | ) |
| Proceeds from other investments | 149 |  |  | 1 |  |  | 159 |  |  | 7 |  |
| Other items, net | 2 |  |  | 5 |  |  | 2 |  |  | 42 |  |
| Net cash provided by investing activities | 4,742 |  |  | 79 |  |  | 1,481 |  |  | 760 |  |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 3,447 |  |  | 2,386 |  |  | 5,563 |  |  | 5,113 |  |
| Repayment of short-term debt | (3,181 | ) |  | (2,137 | ) |  | (4,330 | ) |  | (4,864 | ) |
| Proceeds from issuance of common stock | 201 |  |  | 159 |  |  | 335 |  |  | 290 |  |
| Repurchases and retirements of common stock | (200 | ) |  | (283 | ) |  | (425 | ) |  | (727 | ) |
| Dividends paid | (845 | ) |  | (783 | ) |  | (1,689 | ) |  | (1,567 | ) |
| Payments of tax withholdings related to vesting of share-based awards | (4 | ) |  | (3 | ) |  | (196 | ) |  | (175 | ) |
| Payment of purchase consideration related to RF360 joint venture | (115 | ) |  | — |  |  | (115 | ) |  | — |  |
| Other items, net | (12 | ) |  | (10 | ) |  | (17 | ) |  | (52 | ) |
| Net cash used by financing activities | (709 | ) |  | (671 | ) |  | (874 | ) |  | (1,982 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 35 |  |  | 11 |  |  | 32 |  |  | (6 | ) |
| Net increase in cash and cash equivalents | 4,584 |  |  | 239 |  |  | 2,917 |  |  | 1,178 |  |
| Cash and cash equivalents at beginning of period | 33,362 |  |  | 6,885 |  |  | 35,029 |  |  | 5,946 |  |
| Cash and cash equivalents at end of period | $ | 37,946 |  |  | $ | 7,124 |  |  | $ | 37,946 |  |  | $ | 7,124 |  |
