# QCOM notes — 0000804328-26-000017


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000804328-26-000017:notes:1]
[same as prior period, unchanged from 0000804328-25-000045:notes:1]

[0000804328-26-000017:notes:2]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 28, 2025. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year.

[0000804328-26-000017:notes:3]
We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 28, 2025 and December 29, 2024 included 13 weeks. Our fiscal year for 2026 will include 52 weeks.

[0000804328-26-000017:notes:4]
[same as prior period, unchanged from 0000804328-25-000045:notes:4]

[0000804328-26-000017:notes:5]
[same as prior period, unchanged from 0000804328-25-000045:notes:5]

[0000804328-26-000017:notes:6]
Income Tax Disclosures: In December 2023, the FASB issued new requirements to disclose annually certain additional detailed income tax information related to the effective tax rate reconciliation and income taxes paid, among other items. We will adopt the new requirements for our annual periods starting in fiscal 2026, which can be applied on a retrospective or prospective basis.

[0000804328-26-000017:notes:7]
[same as prior period, unchanged from 0000804328-25-000045:notes:8]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-26-000017:notes:8]
[same as prior period, unchanged from 0000804328-25-000045:notes:9]

[0000804328-26-000017:notes:9]
| Inventories (in millions) |  |  |  |
|  | December 28,2025 |  | September 28,2025 |
| Raw materials | $ | 352 |  |  | $ | 336 |  |
| Work-in-process | 4,026 |  |  | 3,985 |  |
| Finished goods | 2,287 |  |  | 2,205 |  |
|  | $ | 6,665 |  |  | $ | 6,526 |  |

[0000804328-26-000017:notes:10]
We have multi-year capacity purchase commitments with certain suppliers of our integrated circuit products. Total advance payments related to multi-year capacity purchase commitments recorded on our condensed consolidated balance sheets at December 28, 2025 and September 28, 2025 were $1.2 billion and $1.9 billion, respectively, of which $831 million and $1.5 billion were recorded in other current assets, respectively, and $331 million and $357 million were recorded in other assets, respectively.

[0000804328-26-000017:notes:11]
| Other Current Liabilities (in millions) |  |  |  |
|  | December 28,2025 |  | September 28,2025 |
| Customer incentives and other customer-related liabilities | $ | 2,639 |  |  | $ | 1,948 |  |
| Income taxes payable | 1,245 |  |  | 1,007 |  |
| Other | 1,345 |  |  | 1,201 |  |
|  | $ | 5,229 |  |  | $ | 4,156 |  |

[0000804328-26-000017:notes:12]
Interest Rate Swaps. At December 28, 2025 and September 28, 2025, we had outstanding interest rate swaps with an aggregate notional amount of $5.0 billion and $3.6 billion, respectively, that are designated as fair value hedges and allow us to effectively convert fixed-rate payments into floating-rate payments on a portion of our outstanding long-term debt.

[0000804328-26-000017:notes:13]
[same as prior period, unchanged from 0000804328-25-000045:notes:16]

[0000804328-26-000017:notes:14]
[same as prior period, unchanged from 0000804328-25-000045:notes:17]

[0000804328-26-000017:notes:15]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | December 28,2025 |  | December 29,2024 |  |  |  |  |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 7,824 |  |  | $ | 7,574 |  |  |  |  |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 1,101 |  |  | 961 |  |  |  |  |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,688 |  |  | 1,549 |  |  |  |  |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 10,613 |  |  | $ | 10,084 |  |  |  |  |  |

[0000804328-26-000017:notes:16]
[same as prior period, unchanged from 0000804328-25-000045:notes:19]

[0000804328-26-000017:notes:17]
[same as prior period, unchanged from 0000804328-25-000045:notes:20]

[0000804328-26-000017:notes:18]
(3) Primarily includes products sold for use in the following industries and applications: consumer (including personal computers (PCs), extended reality (XR) and other personal computing devices), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, tracking and logistics and utilities).

[0000804328-26-000017:notes:19]
[same as prior period, unchanged from 0000804328-25-000045:notes:22]

[0000804328-26-000017:notes:20]
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  |  |  |  |
| Revenues recognized from previously satisfied performance obligations | $ | 206 |  |  | $ | 263 |  |  |  |  |  |

[0000804328-26-000017:notes:21]
Remaining performance obligations, which are primarily included in unearned revenues (as presented on our condensed consolidated balance sheets), represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our patent license agreements with key OEMs are generally long-term, with remaining terms expiring between fiscal 2027 and 2031. We generally seek to renew or renegotiate such license agreements prior to expiration.

[0000804328-26-000017:notes:22]
[same as prior period, unchanged from 0000804328-25-000045:notes:25]

[0000804328-26-000017:notes:23]
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  |  |  |  |
| Customer/licensee (x) | 25 | % |  | 24 | % |  |  |  |  |
| Customer/licensee (y) | 16 |  |  | 15 |  |  |  |  |  |
| Customer/licensee (z) | 11 |  |  | 14 |  |  |  |  |  |

[0000804328-26-000017:notes:24]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  |  |  |  |
| Interest and dividend income | $ | 136 |  |  | $ | 169 |  |  |  |  |  |
| Net (losses) gains on marketable securities | (55) |  |  | 19 |  |  |  |  |  |
| Net gains on other investments | 210 |  |  | 30 |  |  |  |  |  |
| Net gains on deferred compensation plan assets | 43 |  |  | 15 |  |  |  |  |  |
| Impairment losses on other investments | (12) |  |  | (24) |  |  |  |  |  |
| Other | 28 |  |  | 34 |  |  |  |  |  |
|  | $ | 350 |  |  | $ | 243 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-26-000017:notes:25]
[same as prior period, unchanged from 0000804328-25-000045:notes:29]

[0000804328-26-000017:notes:26]
We estimate our annual effective income tax rate to be 15% for fiscal 2026, which is lower than the U.S. federal statutory rate, primarily because a significant portion of our income qualifies as foreign-derived deduction eligible income (FDDEI) at a 13% effective tax rate, and due to benefits from the federal research and development tax credit. These benefits are partially offset by changes in the valuation allowance on our federal deferred tax assets (because we expect to be perpetually subject to corporate alternative minimum tax (CAMT)) and foreign currency losses related to our refund claim of Korean withholding tax.

[0000804328-26-000017:notes:27]
Our effective tax rate for the first quarter of fiscal 2026 was 15%. Our effective tax rate for the first quarter of fiscal 2025 was 13%, which reflected additional FDDEI benefits from the requirement to capitalize research and development expenditures for federal tax purposes (under prior tax law), partially offset by $107 million of net discrete tax charges, which principally related to foreign currency losses related to our refund claim of Korean withholding tax.

[0000804328-26-000017:notes:28]
During the fourth quarter of fiscal 2025, tax reform legislation included in the One Big Beautiful Bill Act (OBBB) was enacted in the United States. The OBBB included significant corporate tax reforms, including changes to the FDDEI regime and changes allowing domestic research and development expenditures to be deducted as incurred beginning in fiscal 2026 (under prior law such expenditures were capitalized and amortized over five years). The current deduction of domestic research and development expenditures will have a favorable effect on our cash flows from operations due to significantly lower cash tax payments compared to fiscal 2025. However, it adversely affects our effective tax rate by reducing our FDDEI benefits beginning in fiscal 2026. As a result of these changes, we expect to be subject to CAMT, which imposes a 15% federal minimum tax on adjusted financial statement income, reduced by general business credits, including research and development credits. As we expect to perpetually be subject to CAMT, we have established a valuation allowance on substantially all of our existing federal deferred tax assets since the fourth quarter of fiscal 2025. Changes in future taxable income (including less of our income qualifying for preferential treatment as FDDEI), tax laws (including changes to the CAMT rules) and other factors may change our determination regarding whether we will be able to realize our deferred tax assets.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-26-000017:notes:29]
[same as prior period, unchanged from 0000804328-25-000045:notes:34]

[0000804328-26-000017:notes:30]
Stock Repurchase Program. On November 6, 2024, we announced a $15.0 billion stock repurchase program. The stock repurchase program has no expiration date. At December 28, 2025, $4.6 billion remained authorized for repurchase under our stock repurchase program.

[0000804328-26-000017:notes:31]
Shares Outstanding. Shares of common stock outstanding at December 28, 2025 were as follows (in millions):

[0000804328-26-000017:notes:32]
| Balance at September 28, 2025 | 1,074 |  |
| Issued | 15 |  |
| Repurchased | (15) |  |
| Balance at December 28, 2025 | 1,074 |  |

[0000804328-26-000017:notes:33]
Earnings Per Common Share. Basic earnings per share is computed by dividing net income by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of the weighted-average number of common shares outstanding and the weighted-average number of dilutive common share equivalents, primarily comprised of shares issuable under our share-based compensation plans, during the reporting period, using the treasury stock method. The following table provides information about the diluted earnings per share calculation (in millions):

[0000804328-26-000017:notes:34]
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  |  |  |  |
| Dilutive common share equivalents included in diluted shares | 9 |  |  | 12 |  |  |  |  |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 11 |  |  | 1 |  |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-26-000017:notes:35]
Note 5. Commitments and Contingencies

[0000804328-26-000017:notes:36]
Legal and Regulatory Proceedings.

[0000804328-26-000017:notes:37]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision, Inc. (ParkerVision) filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the district court entered judgment in our favor on all claims and closed the case. ParkerVision appealed to the United States Court of Appeals for the Federal Circuit (Federal Circuit), and on September 6, 2024, the Federal Circuit reversed the judgment of the district court, citing certain substantive and procedural issues, and remanded the case to the district court for further proceedings. Following a claim construction ruling by the district court, the parties agreed to a stipulated judgment of non-infringement with respect to certain of ParkerVision’s claims (Receiver Claims). On October 2, 2025, the court entered a final judgment in our favor with respect to the Receiver Claims and severed and stayed ParkerVision’s remaining claims (Transmitter Claims), pending appeal of the court’s claim construction ruling and resulting determination of non-infringement of the Receiver Claims. ParkerVision has appealed to the Federal Circuit. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-26-000017:notes:38]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with Arm (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. Arm is seeking specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology (which Arm alleges includes our custom Qualcomm Oryon CPU cores). On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm, and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia) and System-on-Chip (SoC) products incorporating such cores are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm (the Qualcomm TLA). A trial was held beginning on

[0000804328-26-000017:notes:39]
December 16, 2024, and on December 20, 2024, the jury found that (i) Qualcomm did not breach the Nuvia ALA and (ii) Qualcomm CPUs that include designs acquired in the Nuvia acquisition are licensed under the Qualcomm ALA. The jury was unable to reach a verdict with respect to Arm’s claim as to whether Nuvia breached the Nuvia ALA. The parties filed various post-trial motions, including motions for judgment as a matter of law. On September 30, 2025, the court entered a final judgment upholding the jury’s verdict in favor of Qualcomm, granting judgment to Nuvia, and dismissing Arm’s remaining claims. On October 1, 2025, Arm filed a notice of appeal to the United States Court of Appeals for the Third Circuit. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.

[0000804328-26-000017:notes:40]
On April 18, 2024, we filed a separate complaint, captioned QUALCOMM Incorporated v. Arm Holdings plc f/k/a Arm Ltd., in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief. On December 16, 2024, we filed a First Amended Complaint alleging additional causes of action based on Arm improperly seeking to terminate the Qualcomm ALA and improperly publicizing that it was seeking to terminate the Qualcomm ALA. On June 3, 2025, we filed a Second Amended Complaint to add a claim that Arm has breached the Qualcomm TLA by failing to provide license offers at commercially reasonable prices and terms. Arm has moved to dismiss our amended complaint. On January 8, 2026, we filed a substantially identical complaint against Arm Ltd., which was subsequently consolidated with the Arm Holdings plc complaint. Trial is scheduled to begin on October 5, 2026.

[0000804328-26-000017:notes:41]
On October 22, 2024, Arm provided us with a notice alleging that we have breached the Qualcomm ALA by marketing products that contain CPUs that Arm alleges use designs, technology and code created by Nuvia employees prior to our acquisition of Nuvia; by seeking support and verification from Arm for additional products that use such alleged designs, technology and code; and by suing Arm for breach of the Qualcomm ALA. Arm’s notice asserts that it will have the right to terminate the Qualcomm ALA if such alleged breaches are not cured within 60 days of such notice. We disagree with Arm’s allegations, including that we are, or have been, in breach of the Qualcomm ALA. On January 8, 2025, Arm notified us that it was withdrawing its October 22, 2024 notice of breach and indicated that it has no current plan to terminate the Qualcomm ALA, while reserving its rights pending the outcome of the ongoing litigation.

[0000804328-26-000017:notes:42]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at December 28, 2025 for contingent losses associated with the matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (including matters arising in the ordinary course of our business, such as those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights, among others) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-26-000017:notes:43]
[same as prior period, unchanged from 0000804328-25-000045:notes:48]

[0000804328-26-000017:notes:44]
We are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarities and the level of centralized resource planning within our operating segments, such as the nature of products, the level of shared products, technology and other resources, production processes and customer base. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuit platforms and system software with advanced connectivity and high-performance, low-power computing technologies for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices, industrial devices and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our Data Center business.

[0000804328-26-000017:notes:45]
Our CODM uses revenues and earnings (loss) before income taxes (EBT) to evaluate performance and allocate resources for our segments primarily through our budget and forecasting process. Our CODM primarily uses these metrics by comparing actual results to forecasted and prior period results. Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense (as presented on the condensed consolidated statements of cash flows, the majority of which is allocated to QCT). Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense, certain net investment income, share-based compensation, gains and losses on our deferred compensation plan liabilities and related assets, certain research and development (R&D) expenses, certain selling, general and administrative (SG&A) expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, asset impairment charges and awards, settlements and/or damages arising from legal or regulatory matters and recognition of the step-up of inventories and property, plant and equipment to fair value. Our CODM does not evaluate our operating segments using discrete asset information.

[0000804328-26-000017:notes:46]
The table below presents revenues and EBT for reportable segments (in millions):

[0000804328-26-000017:notes:47]
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  |  |  |  |
| QCT: |  |  |  |  |  |  |  |
| Revenues | $ | 10,613 |  |  | $ | 10,084 |  |  |  |  |  |
| Cost of revenues | 5,446 |  |  | 5,064 |  |  |  |  |  |
| Operating expenses (R&D and SG&A) | 1,865 |  |  | 1,774 |  |  |  |  |  |
| EBT | $ | 3,302 |  |  | $ | 3,246 |  |  |  |  |  |
| QTL: |  |  |  |  |  |  |  |
| Revenues | $ | 1,592 |  |  | $ | 1,535 |  |  |  |  |  |
| Costs and expenses (1) | 361 |  |  | 377 |  |  |  |  |  |
| EBT | $ | 1,231 |  |  | $ | 1,158 |  |  |  |  |  |
| QSI: |  |  |  |  |  |  |  |
| Revenues | $ | — |  |  | $ | — |  |  |  |  |  |
| Operating expenses | 3 |  |  | 3 |  |  |  |  |  |
| Investment and other income, net | 182 |  |  | 22 |  |  |  |  |  |
| EBT | $ | 179 |  |  | $ | 19 |  |  |  |  |  |

[0000804328-26-000017:notes:48]
(1) Substantially all of QTL’s costs and expenses are comprised of operating expenses.

[0000804328-26-000017:notes:49]
Consolidated revenues and EBT include the following reconciling items (in millions):

[0000804328-26-000017:notes:50]
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |
| Reportable segments | $ | 12,205 |  |  | $ | 11,619 |  |  |  |  |  |
| Nonreportable segments | 47 |  |  | 50 |  |  |  |  |  |
|  | $ | 12,252 |  |  | $ | 11,669 |  |  |  |  |  |
| EBT |  |  |  |  |  |  |  |
| Reportable segments | $ | 4,712 |  |  | $ | 4,423 |  |  |  |  |  |
| Nonreportable segments | (85) |  |  | — |  |  |  |  |  |
| Unallocated cost of revenues | (82) |  |  | (59) |  |  |  |  |  |
| Unallocated R&D expenses | (698) |  |  | (598) |  |  |  |  |  |
| Unallocated SG&A expenses | (300) |  |  | (189) |  |  |  |  |  |
| Unallocated interest expense | (169) |  |  | (163) |  |  |  |  |  |
| Unallocated investment and other income, net | 169 |  |  | 221 |  |  |  |  |  |
|  | $ | 3,547 |  |  | $ | 3,635 |  |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-26-000017:notes:51]
[same as prior period, unchanged from 0000804328-25-000045:notes:55]

[0000804328-26-000017:notes:52]
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at December 28, 2025 (in millions):

[0000804328-26-000017:notes:53]
|  | Level 1 |  | Level 2 |  |  |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 1,863 |  |  | $ | 559 |  |  |  |  | $ | 2,422 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 3,344 |  |  |  |  | 3,344 |  |
| Mortgage- and asset-backed securities | — |  |  | 869 |  |  |  |  | 869 |  |
| U.S. Treasury securities and government-related securities | 91 |  |  | 106 |  |  |  |  | 197 |  |
| Equity securities | 207 |  |  | — |  |  |  |  | 207 |  |
| Total marketable securities | 298 |  |  | 4,319 |  |  |  |  | 4,617 |  |
| Derivative instruments | — |  |  | 65 |  |  |  |  | 65 |  |
| Other investments (1) | 1,196 |  |  | — |  |  |  |  | 1,196 |  |
| Total assets measured at fair value | $ | 3,357 |  |  | $ | 4,943 |  |  |  |  | $ | 8,300 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 168 |  |  |  |  | $ | 168 |  |
| Other liabilities (1) | 1,192 |  |  | — |  |  |  |  | 1,192 |  |
| Total liabilities measured at fair value | $ | 1,192 |  |  | $ | 168 |  |  |  |  | $ | 1,360 |  |

[0000804328-26-000017:notes:54]
[same as prior period, unchanged from 0000804328-25-000045:notes:58]

[0000804328-26-000017:notes:55]
Long-term Debt. At December 28, 2025, the aggregate fair value of our outstanding fixed-rate notes, based on Level 2 inputs, was approximately $14.2 billion.

[0000804328-26-000017:notes:56]
Marketable Securities. At December 28, 2025 and September 28, 2025, our marketable securities were all classified as current and were primarily comprised of available-for-sale debt securities (the vast majority of which were corporate bonds and notes).

[0000804328-26-000017:notes:57]
[same as prior period, unchanged from 0000804328-25-000045:notes:60]

[0000804328-26-000017:notes:58]
|  | December 28,2025 |
| Years to Maturity |  |
| Less than one year | $ | 910 |  |
| One to five years | 2,631 |  |
| No single maturity date | 869 |  |
| Total | $ | 4,410 |  |

[0000804328-26-000017:notes:59]
[same as prior period, unchanged from 0000804328-25-000045:notes:62]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000804328-26-000017:notes:60]
[same as prior period, unchanged from 0000804328-25-000045:notes:63]

[0000804328-26-000017:notes:61]
Alphawave. On December 18, 2025 (the Closing Date), we completed the acquisition of Alphawave IP Group plc (Alphawave) for $2.3 billion, which primarily consisted of $1.8 billion of equity consideration from the issuance of 11 million shares of our common stock, which includes certain securities exchangeable for shares of our common stock (Exchangeable Shares), and $301 million of cash consideration. Alphawave develops high-speed wired connectivity technologies delivering IP, custom silicon and connectivity products. The acquisition is intended to further accelerate, and provide key assets for, our expansion into data centers.

[0000804328-26-000017:notes:62]
In connection with the acquisition, we issued Exchangeable Shares of Aqua ExchangeCo ULC, an indirect, wholly-owned subsidiary of QUALCOMM Incorporated, to certain Alphawave executives in exchange for their outstanding capital stock. The Exchangeable Shares (no par value; unlimited shares authorized; 4 million shares issued and outstanding as of December 28, 2025) are exchangeable for our common stock on a one-for-one basis and are substantially the economic equivalent of our common stock. The issued and outstanding Exchangeable Shares have been presented together with our common stock in our condensed consolidated financial statements. The Exchangeable Shares had an estimated fair value of $746 million, of which $453 million is included within the $2.3 billion purchase price and the remainder is subject to a four-year service requirement post-acquisition and will be recognized as compensation expense.

[0000804328-26-000017:notes:63]
The preliminary purchase price allocation shown below could change as the fair values of the tangible and intangible assets acquired and liabilities assumed, and the related income tax effects, are finalized during the remainder of the measurement period (which will not exceed 12 months from the Closing Date). The preliminary allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0000804328-26-000017:notes:64]
| Cash | $ | 51 |  |
| Intangible assets subject to amortization | 239 |  |
| In-process research and development (IPR&D) | 107 |  |
| Goodwill | 2,210 |  |
| Other assets | 316 |  |
| Total assets | 2,923 |  |
| Convertible debt (1) | (278) |  |
| Other liabilities | (366) |  |
| Total liabilities | (644) |  |
| Net assets acquired | $ | 2,279 |  |

[0000804328-26-000017:notes:65]
(1) Alphawave's outstanding unsecured convertible bonds are expected to settle within approximately 60 days of the Closing Date. At December 28, 2025, the fair value of the convertible debt, based on Level 3 inputs, was approximately $279 million.

[0000804328-26-000017:notes:66]
Goodwill related to this transaction was allocated to our Data Center operating segment and is not deductible for tax purposes. Goodwill is primarily attributable to assembled workforce which we expect will help accelerate our expansion into data centers, and certain revenue synergies expected to arise after the acquisition such as anticipated growth from new product sales. Acquired intangible assets subject to amortization primarily consists of completed technology that will be amortized on a straight-line basis over the weighted-average useful life of five years. We valued the completed technology and IPR&D using an income approach based on significant unobservable inputs.

[0000804328-26-000017:notes:67]
Pro forma results of operations have not been presented because the effects of this acquisition were not material to our consolidated results of operations.

[0000804328-26-000017:notes:68]
Other. During the first quarter of fiscal 2026, we acquired four other businesses for a total accounting purchase price of $846 million. These acquisitions were primarily for the purpose of executing on certain products and technology that support our QCT business, including our diversification strategy. The acquired assets primarily consisted of $226 million of intangible assets and $611 million of goodwill, which was allocated to our QCT segment and which is primarily attributable to assembled workforce and certain synergies expected to arise after the acquisitions.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000804328-26-000017:notes:69]
On December 8, 2025, Akash Palkhiwala, our EVP, Chief Financial Officer and Chief Operating Officer, adopted a Rule 10b5-1 trading arrangement (as defined in Item 408 of Regulation S-K) providing for the sale of up to 30,000 shares of our common stock. The plan is scheduled to terminate on February 26, 2027.

[0000804328-26-000017:notes:70]
On December 11, 2025, Patricia Grech, our SVP and Chief Accounting Officer, acting as trustee on behalf of her family trust, adopted a Rule 10b5-1 trading arrangement providing for the sale of (i) 100% of the net shares issued to Ms. Grech upon the vesting of restricted stock unit awards representing 14,122 shares of our common stock, including accrued dividend-equivalents and excluding any shares withheld to satisfy tax withholding obligations in connection with the settlement of such equity awards, plus (ii) an unknown number of shares to be purchased under the Company's Employee Stock Purchase Plan during the term of the plan. The plan is scheduled to terminate on November 30, 2026.

[0000804328-26-000017:notes:71]
On December 12, 2025, Cristiano Amon, our President and Chief Executive Officer, acting as trustee on behalf of his family trust, adopted a Rule 10b5-1 trading arrangement providing for the sale of up to 40,000 shares of our common stock. The plan is scheduled to terminate on March 12, 2027.
