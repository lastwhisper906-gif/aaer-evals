# QCOM MD&A — 0000804328-26-000017


## mdna

[0000804328-26-000017:mdna:1]
[same as prior period, unchanged from 0000804328-25-000045:mdna:1]

[0000804328-26-000017:mdna:2]
This information should be read in conjunction with the condensed consolidated financial statements and the notes thereto included in “Part I, Item 1” of this Quarterly Report and with “Management’s Discussion and Analysis of Financial Condition and Results of Operations” for the fiscal year ended September 28, 2025 contained in our 2025 Annual Report on Form 10-K.

[0000804328-26-000017:mdna:3]
This Quarterly Report (including but not limited to this section titled Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements. Words such as “expect,” “anticipate,” “intend,” “plan,” “believe,” “seek,” “estimate,” “may,” “will,” “would” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report. Additionally, statements concerning future matters such as our future business, prospects, results of operations or financial condition; research and development or technology investments; new or enhanced products, services or technologies; emerging industries or business models; design wins or product launches; industry, market or technology trends, dynamics or transitions; our expectations regarding future demand or supply conditions; strategic investments or acquisitions, and the anticipated timing or benefits thereof; legal or regulatory matters, including the expected impacts of recently enacted or pending tax or other regulatory changes; U.S./China trade or national security tensions; vertical integration by our customers; competition; annual effective tax rates; and other statements regarding matters that are not historical are also forward-looking statements.

[0000804328-26-000017:mdna:4]
First Quarter Fiscal 2026 Overview

[0000804328-26-000017:mdna:5]
Revenues for the first quarter of fiscal 2026 were $12.3 billion, an increase of 5% compared to the year ago quarter, with net income of $3.0 billion, a decrease of 6% compared to the year ago quarter. Key items from the first quarter of fiscal 2026 included:

[0000804328-26-000017:mdna:6]
•QCT revenues increased by 5% in the first quarter of fiscal 2026 compared to the year ago quarter due to higher handsets, automotive and IoT revenues.

[0000804328-26-000017:mdna:7]
•QTL revenues increased by 4% in the first quarter of fiscal 2026 compared to the year ago quarter, primarily due to an increase in estimated sales of cellular products.

[0000804328-26-000017:mdna:8]
•On December 18, 2025, we completed the acquisition of Alphawave IP Group plc (Alphawave) for $2.3 billion. Alphawave develops high-speed wired connectivity technologies delivering IP, custom silicon and connectivity products. The acquisition is intended to further accelerate, and provide key assets for, our expansion into data centers. Additional information related to this acquisition is included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 8. Acquisitions.”

[0000804328-26-000017:mdna:9]
[same as prior period, unchanged from 0000804328-25-000045:mdna:8]

[0000804328-26-000017:mdna:10]
We develop and commercialize foundational technologies and products used across industries and applications from mobile devices to other areas including automotive and the internet of things (IoT). We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents and other rights.

[0000804328-26-000017:mdna:11]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our Data Center business.

[0000804328-26-000017:mdna:12]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering and research and development functions are operated by Qualcomm Technologies, Inc. (QTI), a subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0000804328-26-000017:mdna:13]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when licensees’ sales occur. These trends may or may not continue in the future. Further, the trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings.

[0000804328-26-000017:mdna:14]
[same as prior period, unchanged from 0000804328-25-000045:mdna:13]

[0000804328-26-000017:mdna:15]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  | Change |  |  |  |  |  |  |
| Equipment and services | $ | 10,466 |  |  | $ | 9,942 |  |  | $ | 524 |  |  |  |  |  |  |  |
| Licensing | 1,786 |  |  | 1,727 |  |  | 59 |  |  |  |  |  |  |  |
|  | $ | 12,252 |  |  | $ | 11,669 |  |  | $ | 583 |  |  |  |  |  |  |  |

[0000804328-26-000017:mdna:16]
First quarter 2026 vs. 2025

[0000804328-26-000017:mdna:17]
The increase in revenues in the first quarter fiscal 2026 was primarily due to:

[0000804328-26-000017:mdna:18]
+    $528 million in higher equipment and services revenues from our QCT segment

[0000804328-26-000017:mdna:19]
+    $57 million in higher licensing revenues from our QTL segment

[0000804328-26-000017:mdna:20]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  | Change |  |  |  |  |  |  |
| Cost of revenues | $ | 5,568 |  |  | $ | 5,161 |  |  | $ | 407 |  |  |  |  |  |  |  |
| Gross margin | 55 | % |  | 56 | % |  |  |  |  |  |  |  |  |

[0000804328-26-000017:mdna:21]
First quarter 2026 vs. 2025

[0000804328-26-000017:mdna:22]
Gross margin percentage decreased in the first quarter of fiscal 2026 primarily due to a decrease in QCT gross margin percentage.

[0000804328-26-000017:mdna:23]
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  | Change |  |  |  |  |  |  |
| Research and development | $ | 2,453 |  |  | $ | 2,230 |  |  | $ | 223 |  |  |  |  |  |  |  |
| % of revenues | 20 | % |  | 19 | % |  |  |  |  |  |  |  |  |

[0000804328-26-000017:mdna:24]
First quarter 2026 vs. 2025

[0000804328-26-000017:mdna:25]
The increase in research and development expenses in the first quarter of fiscal 2026 was primarily due to:

[0000804328-26-000017:mdna:26]
+    $121 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including investments in key growth and diversification opportunities)

[0000804328-26-000017:mdna:27]
+    $85 million increase in share-based compensation expense

[0000804328-26-000017:mdna:28]
We expect to continue investing in key growth and diversification initiatives. The increase in our share-based compensation expense includes the replacement of our annual cash incentive awards for fiscal 2026 and 2027 with a two-year equity award for our broader non-executive leadership team. This approach is designed to motivate and retain our team to execute our long-term diversification strategy, while further aligning their compensation with the interests of our stockholders.

[0000804328-26-000017:mdna:29]
19

[0000804328-26-000017:mdna:30]
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  | Change |  |  |  |  |  |  |
| Selling, general and administrative | $ | 865 |  |  | $ | 723 |  |  | $ | 142 |  |  |  |  |  |  |  |
| % of revenues | 7 | % |  | 6 | % |  |  |  |  |  |  |  |  |

[0000804328-26-000017:mdna:31]
First quarter 2026 vs. 2025

[0000804328-26-000017:mdna:32]
The increase in selling, general and administrative expenses in the first quarter of fiscal 2026 was primarily due to:

[0000804328-26-000017:mdna:33]
+    $50 million increase in share-based compensation expense

[0000804328-26-000017:mdna:34]
+    $40 million increase in acquisition-related expenses

[0000804328-26-000017:mdna:35]
+    $31 million increase in sales and marketing expenses (including investments in key growth and diversification initiatives)

[0000804328-26-000017:mdna:36]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  | Change |  |  |  |  |  |  |
| Interest expense | $ | 169 |  |  | $ | 163 |  |  | $ | 6 |  |  |  |  |  |  |  |
| Investment and other income, net |
| Interest and dividend income | $ | 136 |  |  | $ | 169 |  |  | $ | (33) |  |  |  |  |  |  |  |
| Net (losses) gains on marketable securities | (55) |  |  | 19 |  |  | (74) |  |  |  |  |  |  |  |
| Net gains on other investments | 210 |  |  | 30 |  |  | 180 |  |  |  |  |  |  |  |
| Net gains on deferred compensation plan assets | 43 |  |  | 15 |  |  | 28 |  |  |  |  |  |  |  |
| Impairment losses on other investments | (12) |  |  | (24) |  |  | 12 |  |  |  |  |  |  |  |
| Other | 28 |  |  | 34 |  |  | (6) |  |  |  |  |  |  |  |
|  | $ | 350 |  |  | $ | 243 |  |  | $ | 107 |  |  |  |  |  |  |  |

[0000804328-26-000017:mdna:37]
Net gains on other investments in the first quarter of fiscal 2026 was primarily driven by observable price changes on certain of our QSI non-marketable equity investments.

[0000804328-26-000017:mdna:38]
[same as prior period, unchanged from 0000804328-25-000045:mdna:42]

[0000804328-26-000017:mdna:39]
[same as prior period, unchanged from 0000804328-25-000045:mdna:43]

[0000804328-26-000017:mdna:40]
|  | Three Months Ended |  |  |  |  |
|  | December 28,2025 |  | December 29,2024 |  |  |  |  |
| Expected income tax provision at federal statutory tax rate | $ | 745 |  |  | $ | 763 |  |  |  |  |  |
| Benefit from foreign-derived deduction eligible income (FDDEI) | (209) |  |  | (359) |  |  |  |  |  |
| Benefit related to the federal research and development tax credit | (71) |  |  | (74) |  |  |  |  |  |
| Foreign currency loss related to foreign withholding tax receivable | 58 |  |  | 166 |  |  |  |  |  |
| Excess tax benefit associated with share-based awards | (29) |  |  | (37) |  |  |  |  |  |
| Other | 49 |  |  | (4) |  |  |  |  |  |
| Income tax expense | $ | 543 |  |  | $ | 455 |  |  |  |  |  |
| Effective tax rate | 15 | % |  | 13 | % |  |  |  |  |

[0000804328-26-000017:mdna:41]
We estimate our annual effective income tax rate to be 15% for fiscal 2026, which is lower than the U.S. federal statutory rate. Additional information regarding our annual effective income tax rate and income tax expense is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes.”

[0000804328-26-000017:mdna:42]
During the fourth quarter of fiscal 2025, tax reform legislation included in the One Big Beautiful Bill Act (OBBB) was enacted in the United States. The OBBB included significant corporate tax reforms, including changes to the FDDEI regime and changes allowing domestic research and development expenditures to be deducted as incurred beginning in fiscal 2026

[0000804328-26-000017:mdna:43]
[same as prior period, unchanged from 0000804328-25-000045:mdna:47]

[0000804328-26-000017:mdna:44]
(under prior law such expenditures were capitalized and amortized over five years). The current deduction of domestic research and development expenditures will have a favorable effect on our cash flows from operations due to significantly lower cash tax payments compared to fiscal 2025. However, it adversely affects our effective tax rate by reducing our FDDEI benefits beginning in fiscal 2026. As a result of these changes, we expect to be subject to corporate alternative minimum tax (CAMT), which imposes a 15% federal minimum tax on adjusted financial statement income, reduced by general business credits, including research and development credits. As we expect to perpetually be subject to CAMT, we have established a valuation allowance on substantially all of our existing federal deferred tax assets since the fourth quarter of fiscal 2025. Changes in future taxable income (including less of our income qualifying for preferential treatment as FDDEI), tax laws (including changes to the CAMT rules) and other factors may change our determination regarding whether we will be able to realize our deferred tax assets.

[0000804328-26-000017:mdna:45]
Unrecognized tax benefits were $2.9 billion and $2.7 billion at December 28, 2025 and September 28, 2025, respectively. We believe that it is reasonably possible that our unrecognized tax benefits will change within the next twelve months.

[0000804328-26-000017:mdna:46]
[same as prior period, unchanged from 0000804328-25-000045:mdna:52]

[0000804328-26-000017:mdna:47]
The following should be read in conjunction with our financial results for the first quarter of fiscal 2026 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0000804328-26-000017:mdna:48]
[same as prior period, unchanged from 0000804328-25-000045:mdna:54]

[0000804328-26-000017:mdna:49]
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  | Change |  |  |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets | $ | 7,824 |  |  | $ | 7,574 |  |  | $ | 250 |  |  |  |  |  |  |
| Automotive | 1,101 |  |  | 961 |  |  | 140 |  |  |  |  |  |  |
| IoT (internet of things) | 1,688 |  |  | 1,549 |  |  | 139 |  |  |  |  |  |  |
| Total revenues (1) | $ | 10,613 |  |  | $ | 10,084 |  |  | $ | 529 |  |  |  |  |  |  |
| EBT (2) | $ | 3,302 |  |  | $ | 3,246 |  |  | $ | 56 |  |  |  |  |  |  |
| EBT as a % of revenues | 31 | % |  | 32 | % |  | -1 point |  |  |  |  |  |  |

[0000804328-26-000017:mdna:50]
[same as prior period, unchanged from 0000804328-25-000045:mdna:56]

[0000804328-26-000017:mdna:51]
(2) Earnings before income taxes.

[0000804328-26-000017:mdna:52]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $10.4 billion and $9.9 billion in the first quarter of fiscal 2026 and 2025, respectively. QCT revenues mostly relate to sales of our Snapdragon and Dragonwing platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets as well as sales of 4G, 5G sub 6 and 5G millimeter wave RFFE products.

[0000804328-26-000017:mdna:53]
First quarter 2026 vs. 2025

[0000804328-26-000017:mdna:54]
The increase in QCT revenues in the first quarter of fiscal 2026 was primarily due to:

[0000804328-26-000017:mdna:55]
+    higher handsets revenues, primarily due to higher chipset shipments to certain major OEMs

[0000804328-26-000017:mdna:56]
[same as prior period, unchanged from 0000804328-25-000045:mdna:63]

[0000804328-26-000017:mdna:57]
+    higher IoT revenues, due to $244 million in higher shipments primarily across edge networking and consumer products, partially offset by unfavorable product mix

[0000804328-26-000017:mdna:58]
QCT EBT as a percentage of revenues decreased in the first quarter of fiscal 2026 primarily due to:

[0000804328-26-000017:mdna:59]
-    higher operating expenses, primarily driven by higher research and development and selling, general and administrative expenses

[0000804328-26-000017:mdna:60]
-    lower gross margin, primarily driven by unfavorable product cost, partially offset by higher average selling prices

[0000804328-26-000017:mdna:61]
+    higher revenues

[0000804328-26-000017:mdna:62]
[same as prior period, unchanged from 0000804328-25-000045:mdna:74]

[0000804328-26-000017:mdna:63]
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  | Change |  |  |  |  |  |  |
| Licensing revenues | $ | 1,592 |  |  | $ | 1,535 |  |  | $ | 57 |  |  |  |  |  |  |  |
| EBT | 1,231 |  |  | 1,158 |  |  | 73 |  |  |  |  |  |  |  |
| EBT as a % of revenues | 77 | % |  | 75 | % |  | 2 points |  |  |  |  |  |  |

[0000804328-26-000017:mdna:64]
First quarter 2026 vs. 2025

[0000804328-26-000017:mdna:65]
The increase in QTL licensing revenues in the first quarter of fiscal 2026 was primarily due to an increase in estimated sales of cellular products.

[0000804328-26-000017:mdna:66]
QTL EBT as a percentage of revenues increased in the first quarter of fiscal 2026 due to:

[0000804328-26-000017:mdna:67]
+    lower operating expenses, primarily driven by lower research and development expenses

[0000804328-26-000017:mdna:68]
+    higher revenues

[0000804328-26-000017:mdna:69]
[same as prior period, unchanged from 0000804328-25-000045:mdna:80]

[0000804328-26-000017:mdna:70]
|  | Three Months Ended |  |  |
|  | December 28,2025 |  | December 29,2024 |  | Change |  |  |  |  |  |  |
| Equipment and services revenues | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |
| EBT | 179 |  |  | 19 |  |  | 160 |  |  |  |  |  |  |  |

[0000804328-26-000017:mdna:71]
First quarter 2026 vs. 2025

[0000804328-26-000017:mdna:72]
QSI EBT increased in the first quarter of fiscal 2026 primarily due to higher net gains from observable price changes on certain of our non-marketable equity investments, partially offset by losses from the change in fair value of certain of our marketable equity investments.

[0000804328-26-000017:mdna:73]
[same as prior period, unchanged from 0000804328-25-000045:mdna:85]

[0000804328-26-000017:mdna:74]
We believe that on-device AI and high-performance, low-power computing combined with cellular technology (such as 5G) will continue to drive adoption of certain technologies that are already commonly used in smartphones by industries and applications beyond mobile handsets, such as automotive and IoT. We believe it is important that we remain a leader in such technology development, standardization, intellectual property creation and licensing, and a leading developer and supplier of integrated circuit products in order to sustain and grow our business long-term.

[0000804328-26-000017:mdna:75]
[same as prior period, unchanged from 0000804328-25-000045:mdna:87]

[0000804328-26-000017:mdna:76]
•We expect recent memory supply constraints and related pricing increases to adversely affect demand from several handset customers, which will negatively impact our financial results. The extent to which these conditions may affect our business will depend on future developments, including memory supply availability, memory and handset pricing dynamics and end‑consumer demand for handsets, all of which remain uncertain.

[0000804328-26-000017:mdna:77]
[same as prior period, unchanged from 0000804328-25-000045:mdna:88]

[0000804328-26-000017:mdna:78]
•We expect leading process technology nodes to continue to drive product cost increases from certain of our key semiconductor wafer suppliers.

[0000804328-26-000017:mdna:79]
•We expect continued intense competition, including from vertical integration by certain of our customers (for example, Apple and Samsung). In particular, Apple utilizes its own modem (rather than our products) in certain of its smartphones and we expect that Apple will increasingly use its own modem products, rather than our products, in

[0000804328-26-000017:mdna:80]
its future devices, which will have a significant negative impact on our QCT revenues, results of operations and cash flows.

[0000804328-26-000017:mdna:81]
•U.S./China trade relations and/or national security protection policies may negatively impact our business, growth prospects and results of operations. See “Risk Factors” in this Quarterly Report, including the Risk Factor titled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0000804328-26-000017:mdna:82]
We are also involved in certain legal proceedings, including those described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Litigation is inherently uncertain, and, while we intend to continue to vigorously defend ourselves in such matters, the unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0000804328-26-000017:mdna:83]
[same as prior period, unchanged from 0000804328-25-000045:mdna:93]

[0000804328-26-000017:mdna:84]
[same as prior period, unchanged from 0000804328-25-000045:mdna:94]

[0000804328-26-000017:mdna:85]
[same as prior period, unchanged from 0000804328-25-000045:mdna:96]

[0000804328-26-000017:mdna:86]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at December 28, 2025 and September 28, 2025 and for the first three months of fiscal 2026 and 2025 (in millions):

[0000804328-26-000017:mdna:87]
|  | December 28,2025 |  | September 28,2025 |  | Change |  |  |
| Cash, cash equivalents and marketable securities (including restricted cash) |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 7,205 |  |  | $ | 5,520 |  |  | $ | 1,685 |  |  |  |
| Restricted cash (1) | — |  |  | 2,323 |  |  | (2,323) |  |  |  |
| Marketable securities | 4,617 |  |  | 4,635 |  |  | (18) |  |  |  |
|  | $ | 11,822 |  |  | $ | 12,478 |  |  | $ | (656) |  |  |  |
| Debt (2) | $ | 14,817 |  |  | $ | 14,811 |  |  | $ | 6 |  |  |  |

[0000804328-26-000017:mdna:88]
(1) In connection with the acquisition of Alphawave, which closed in the first quarter of fiscal 2026, we agreed to restrict the use of approximately $2.3 billion of cash to be held for purposes of satisfying payment of the consideration to effect the acquisition. Additional information regarding our acquisition of Alphawave is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 8. Acquisitions.”

[0000804328-26-000017:mdna:89]
(2) Includes our issued debt which is reported as long-term. At December 28, 2025, our credit facility was undrawn, and we had no commercial paper outstanding.

[0000804328-26-000017:mdna:90]
|  | Three Months Ended |
|  | December 28,2025 |  | December 29,2024 |  | Change |  |  |
| Net cash provided by operating activities | $ | 4,965 |  |  | $ | 4,587 |  |  | $ | 378 |  |  |  |
| Net cash used by investing activities | (1,721) |  |  | (671) |  |  | (1,050) |  |  |  |
| Net cash used by financing activities | (3,882) |  |  | (3,008) |  |  | (874) |  |  |  |

[0000804328-26-000017:mdna:91]
Cash, cash equivalents and marketable securities (including restricted cash). The net decrease in cash, cash equivalents and marketable securities (including restricted cash) for the first three months of fiscal 2026 was primarily due to $2.65 billion in payments to repurchase 15 million shares of our common stock (which includes repurchases that offset share issuances in connection with the acquisition of Alphawave), $1.1 billion in cash paid for acquisitions and other investments (net of cash acquired), $949 million in cash dividends paid and $549 million in capital expenditures, partially offset by net cash provided by operating activities.

[0000804328-26-000017:mdna:92]
Net changes in our operating assets and liabilities for the first three months of fiscal 2026 positively impacted our operating cash flows primarily from a decrease in other assets which was primarily driven by utilization of prior advanced supply agreement payments.

[0000804328-26-000017:mdna:93]
Capital Return Program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors. Additional information regarding our capital returns is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 4. Capital Stock.”

[0000804328-26-000017:mdna:94]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2025 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At December 28, 2025, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements”, “Looking Forward” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2025 Annual Report on Form 10-K.

[0000804328-26-000017:mdna:95]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Risk Factors” in this Quarterly Report.

[0000804328-26-000017:mdna:96]
[same as prior period, unchanged from 0000804328-25-000045:mdna:110]

[0000804328-26-000017:mdna:97]
[same as prior period, unchanged from 0000804328-25-000045:mdna:111]

[0000804328-26-000017:mdna:98]
[same as prior period, unchanged from 0000804328-25-000045:mdna:112]
