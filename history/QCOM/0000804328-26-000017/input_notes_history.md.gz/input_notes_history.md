# QCOM note change history — 0000804328-25-000045 → 0000804328-26-000017


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2026-02-04):
[0000804328-26-000017:note_history:1]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision, Inc. (ParkerVision) filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the district court entered judgment in our favor on all claims and closed the case. ParkerVision appealed to the United States Court of Appeals for the Federal Circuit (Federal Circuit), and on September 6, 2024, the Federal Circuit reversed the judgment of the district court, citing certain substantive and procedural issues, and remanded the case to the district court for further proceedings. Following a claim construction ruling by the district court, the parties agreed to a stipulated judgment of non-infringement with respect to certain of ParkerVision’s claims (Receiver Claims). On October 2, 2025, the court entered a final judgment in our favor with respect to the Receiver Claims and severed and stayed ParkerVision’s remaining claims (Transmitter Claims), pending appeal of the court’s claim construction ruling and resulting determination of non-infringement of the Receiver Claims. ParkerVision has appealed to the Federal Circuit. We intend to continue to vigorously defend ourselves in this matter.

- changed (2026-02-04):
[0000804328-26-000017:note_history:2]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with Arm (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. Arm is seeking specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology (which Arm alleges includes our custom Qualcomm Oryon CPU cores). On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm, and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia) and System-on-Chip (SoC) products incorporating such cores are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm (the Qualcomm TLA). A trial was held beginning on
  (was, 2025-07-30, similarity 0.7738):
[0000804328-25-000045:note_history:2]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (Arm) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with Arm (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. Arm is seeking specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology (which Arm alleges includes our custom Qualcomm Oryon CPU cores). Arm’s complaint also contended that we violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of Arm’s trademarks and sought associated injunctive and declaratory relief; however, Arm dismissed these claims prior to trial. On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm, and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia) and System-on-Chip (SoC) products incorporating such cores are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm (the Qualcomm TLA). A trial was held beginning on December 16, 2024, and on December 20, 2024, the jury found that (i) Qualcomm did not breach the Nuvia ALA and (ii) Qualcomm CPUs that include designs acquired in the Nuvia acquisition are licensed under the Qualcomm ALA. The jury was unable to reach a verdict with respect to Arm’s claim as to whether Nuvia breached the Nuvia ALA. The parties have filed various post-trial motions in this matter, including motions for judgment as a matter of law. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.

- added (2026-02-04):
[0000804328-26-000017:note_history:3]
December 16, 2024, and on December 20, 2024, the jury found that (i) Qualcomm did not breach the Nuvia ALA and (ii) Qualcomm CPUs that include designs acquired in the Nuvia acquisition are licensed under the Qualcomm ALA. The jury was unable to reach a verdict with respect to Arm’s claim as to whether Nuvia breached the Nuvia ALA. The parties filed various post-trial motions, including motions for judgment as a matter of law. On September 30, 2025, the court entered a final judgment upholding the jury’s verdict in favor of Qualcomm, granting judgment to Nuvia, and dismissing Arm’s remaining claims. On October 1, 2025, Arm filed a notice of appeal to the United States Court of Appeals for the Third Circuit. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.

- added (2026-02-04):
[0000804328-26-000017:note_history:4]
On April 18, 2024, we filed a separate complaint, captioned QUALCOMM Incorporated v. Arm Holdings plc f/k/a Arm Ltd., in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief. On December 16, 2024, we filed a First Amended Complaint alleging additional causes of action based on Arm improperly seeking to terminate the Qualcomm ALA and improperly publicizing that it was seeking to terminate the Qualcomm ALA. On June 3, 2025, we filed a Second Amended Complaint to add a claim that Arm has breached the Qualcomm TLA by failing to provide license offers at commercially reasonable prices and terms. Arm has moved to dismiss our amended complaint. On January 8, 2026, we filed a substantially identical complaint against Arm Ltd., which was subsequently consolidated with the Arm Holdings plc complaint. Trial is scheduled to begin on October 5, 2026.

- added (2026-02-04):
[0000804328-26-000017:note_history:5]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at December 28, 2025 for contingent losses associated with the matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (including matters arising in the ordinary course of our business, such as those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights, among others) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- removed (2026-02-04):
[0000804328-25-000045:note_history:6]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the district court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit (Federal Circuit). On September 6, 2024, the Federal Circuit reversed the judgment of the district court, citing certain substantive and procedural issues, and remanded the case to the district court for further proceedings. We intend to continue to vigorously defend ourselves in this matter.

- removed (2026-02-04):
[0000804328-25-000045:note_history:7]
On April 18, 2024, we filed a separate complaint (captioned QUALCOMM Incorporated v. Arm Ltd.) against Arm in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief. Arm moved to dismiss this complaint, and on October 30, 2024, the court denied Arm’s motion to dismiss. On December 16, 2024, we filed a First Amended Complaint alleging additional causes of action based on Arm improperly seeking to terminate the Qualcomm ALA and improperly publicizing that it was seeking to terminate the Qualcomm ALA. On June 3, 2025, we filed a Second Amended Complaint to add a claim that Arm has breached the Qualcomm TLA by failing to provide license offers at commercially reasonable prices and terms. Arm has moved to dismiss our amended complaint. Trial is scheduled to begin on March 9, 2026.

- removed (2026-02-04):
[0000804328-25-000045:note_history:8]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at June 29, 2025 for contingent losses associated with the matters described

- removed (2026-02-04):
[0000804328-25-000045:note_history:9]
above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (for example, certain consumer class action lawsuits in jurisdictions outside the United States, and other matters arising in the ordinary course of our business, including those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000804328-26-000017:note_history:10]
We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 28, 2025 and December 29, 2024 included 13 weeks. Our fiscal year for 2026 will include 52 weeks.
  (was, 2025-07-30, similarity 0.7373):
[0000804328-25-000045:note_history:10]
We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and nine months ended June 29, 2025 and June 23, 2024 included 13 weeks and 39 weeks, respectively. Our fiscal year for 2025 will include 52 weeks.

- changed (2026-02-04):
[0000804328-26-000017:note_history:11]
Income Tax Disclosures: In December 2023, the FASB issued new requirements to disclose annually certain additional detailed income tax information related to the effective tax rate reconciliation and income taxes paid, among other items. We will adopt the new requirements for our annual periods starting in fiscal 2026, which can be applied on a retrospective or prospective basis.
  (was, 2025-07-30, similarity 0.807):
[0000804328-25-000045:note_history:11]
Income Tax Disclosures: In December 2023, the FASB issued new requirements to disclose annually certain additional detailed income tax information related to the effective tax rate reconciliation and income taxes paid, among other items. We will adopt the new requirements starting in fiscal 2026 on a retrospective basis.

- removed (2026-02-04):
[0000804328-25-000045:note_history:12]
Segment Reporting Disclosures: In November 2023, the Financial Accounting Standards Board (FASB) issued new requirements to disclose certain incremental segment information on an annual and interim basis, including (among other items) additional disclosure about significant segment expenses. We will adopt the new requirements for our annual periods starting in fiscal 2025 (and interim periods thereafter) on a retrospective basis.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000804328-26-000017:note_history:13]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | December 28,2025 |  | December 29,2024 |  |  |  |  |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 7,824 |  |  | $ | 7,574 |  |  |  |  |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 1,101 |  |  | 961 |  |  |  |  |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,688 |  |  | 1,549 |  |  |  |  |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 10,613 |  |  | $ | 10,084 |  |  |  |  |  |
  (was, 2025-07-30, similarity 0.7732):
[0000804328-25-000045:note_history:13]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  | June 29,2025 |  | June 23,2024 |  | June 29,2025 |  | June 23,2024 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,328 |  |  | $ | 5,899 |  |  | $ | 20,831 |  |  | $ | 18,766 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 984 |  |  | 811 |  |  | 2,904 |  |  | 2,012 |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,681 |  |  | 1,359 |  |  | 4,811 |  |  | 3,740 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 8,993 |  |  | $ | 8,069 |  |  | $ | 28,546 |  |  | $ | 24,518 |  |

- added (2026-02-04):
[0000804328-26-000017:note_history:14]
(3) Primarily includes products sold for use in the following industries and applications: consumer (including personal computers (PCs), extended reality (XR) and other personal computing devices), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, tracking and logistics and utilities).

- removed (2026-02-04):
[0000804328-25-000045:note_history:15]
(3) Primarily includes products sold for use in the following industries and applications: consumer (including personal computers (PCs), tablets, voice and music and extended reality (XR)), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, tracking and logistics and utilities).
