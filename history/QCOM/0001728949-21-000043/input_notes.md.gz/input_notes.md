# QCOM notes — 0001728949-21-000043


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-21-000043:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 27, 2020. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 28, 2021 and March 29, 2020 included 13 weeks and 26 weeks, respectively.

[0001728949-21-000043:notes:2]
[same as prior period, unchanged from 0001728949-21-000022:notes:2]

[0001728949-21-000043:notes:3]
Recently Adopted Accounting Guidance.

[0001728949-21-000043:notes:4]
[same as prior period, unchanged from 0001728949-21-000022:notes:4]

[0001728949-21-000043:notes:5]
[same as prior period, unchanged from 0001728949-21-000022:notes:5]

[0001728949-21-000043:notes:6]
Marketable Securities: As a result of the adoption of the new accounting guidance described above, we revised our accounting policy beginning in fiscal 2021 as follows.

[0001728949-21-000043:notes:7]
Marketable securities include marketable equity securities, available-for-sale debt securities and, from time-to-time, certain time deposits. We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value with all realized and unrealized gains and losses on investments in marketable equity securities and realized gains and losses on available-for-sale debt securities recognized in investment and other income (expense), net. Debt securities are classified as available for sale or held to maturity at the time of purchase and reevaluated at each balance sheet date. The realized and unrealized gains and losses on marketable securities are determined using the specific identification method.

[0001728949-21-000043:notes:8]
If a debt security has an unrealized loss and we either intend to sell the security or it is more likely than not that we will be required to sell the security before its anticipated recovery, we record an impairment charge to investment and other income (expense), net for the entire amount of the unrealized loss and adjust the amortized cost basis of the security. For the remaining debt securities, if an unrealized loss exists, we separate the impairment into the portion of the loss related to credit factors and the portion of the loss that is not related to credit factors. Unrealized gains or unrealized losses that are not related to credit factors on available-for-sale debt securities are recorded as a component of accumulated other comprehensive income, net of income taxes. Unrealized losses that are related to credit loss factors on available-for-sale debt securities and subsequent adjustments to the credit loss are recorded as an allowance for credit losses, which is included in investment and other income, net. In evaluating whether a credit loss exists, we consider a variety of factors, including the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; the security’s relative performance versus its peers, sector or asset class; the market and economy in general; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-21-000043:notes:9]
[same as prior period, unchanged from 0001728949-21-000022:notes:9]

[0001728949-21-000043:notes:10]
| Inventories (in millions) |  |  |  |
|  | March 28,2021 |  | September 27,2020 |
| Raw materials | $ | 167 |  |  | $ | 94 |  |
| Work-in-process | 1,207 |  |  | 1,155 |  |
| Finished goods | 1,294 |  |  | 1,349 |  |
|  | $ | 2,668 |  |  | $ | 2,598 |  |

[0001728949-21-000043:notes:11]
Revolving Credit Facility. On December 8, 2020, we entered into a Revolving Credit Facility replacing our prior Amended and Restated Revolving Credit Facility. There were no outstanding borrowings under the Amended and Restated Revolving Credit Facility at the time of termination. The Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At March 28, 2021, no amounts were outstanding under the Revolving Credit Facility. The Revolving Credit Facility requires that we comply with certain financial covenants, including that we maintain an interest coverage ratio, as defined in the agreement. At March 28, 2021, we were in compliance with the applicable covenants under the Revolving Credit Facility.

[0001728949-21-000043:notes:12]
Interest Rate Swaps. Beginning in the second quarter of 2021, we entered into forward-starting interest rate swaps to hedge the variability of forecasted interest payments on anticipated debt issuances through 2025. At March 28, 2021, the notional amount of the forward-starting interest rate swaps outstanding, which are denominated in U.S. dollars, was $1.2 billion. The fair values of the forward-starting interest rate swaps recorded in other noncurrent assets and other noncurrent liabilities were $23 million and negligible, respectively, at March 28, 2021. Since March 28, 2021, we entered into additional forward-starting interest rate swaps with an aggregate notional amount of $1.1 billion.

[0001728949-21-000043:notes:13]
Revenues. We disaggregate our revenues by segment (Note 6) and type of products and services (as presented on our condensed consolidated statement of operations), and for our QCT (Qualcomm CDMA Technologies) segment by revenue stream, which is based on industry segment and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry segment and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s (Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets. QCT revenue streams were as follows (in millions):

[0001728949-21-000043:notes:14]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  | March 28,2021 |  | March 29,2020 |  | March 28,2021 |  | March 29,2020 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 4,065 |  |  | $ | 2,652 |  |  | $ | 8,281 |  |  | $ | 5,004 |  |
| RFFE (2) |  |  |  |  |  |  |  |  | 903 |  |  | 650 |  |  | 1,964 |  |  | 1,063 |  |
| Automotive (3) |  |  |  |  |  |  |  |  | 240 |  |  | 171 |  |  | 452 |  |  | 318 |  |
| IoT (Internet of Things) (4) |  |  |  |  |  |  |  |  | 1,073 |  |  | 627 |  |  | 2,117 |  |  | 1,334 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 6,281 |  |  | $ | 4,100 |  |  | $ | 12,814 |  |  | $ | 7,719 |  |

[0001728949-21-000043:notes:15]
[same as prior period, unchanged from 0001728949-21-000022:notes:14]

[0001728949-21-000043:notes:16]
[same as prior period, unchanged from 0001728949-21-000022:notes:15]

[0001728949-21-000043:notes:17]
[same as prior period, unchanged from 0001728949-21-000022:notes:16]

[0001728949-21-000043:notes:18]
(4) Primarily includes products sold for use in cellular and non-cellular connected devices within the following industry segments and applications: consumer, computing, industrial, fixed wireless broadband, voice and music and wireless networking.

[0001728949-21-000043:notes:19]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were $122 million and $150 million for the three months ended March 28, 2021 and March 29, 2020, respectively, and $176 million and $178 million for the six months ended March 28, 2021 and March 29, 2020, respectively, and primarily related to QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, in part based on actual reporting of royalties by our licensees) and certain QCT customer incentives.

[0001728949-21-000043:notes:20]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In the six months ended March 28, 2021 and March 29, 2020, we recognized revenues of $314 million and $307 million, respectively, that were recorded as unearned revenues at September 27, 2020 and September 29, 2019, respectively.

[0001728949-21-000043:notes:21]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront. At March 28, 2021, we had $1.2 billion of remaining performance obligations, of which $272 million, $535 million, $258 million, $75 million and $26 million was expected to be recognized as revenues for the remainder of fiscal 2021 and each of the subsequent four years from fiscal 2022 through 2025, respectively, and no amounts thereafter.

[0001728949-21-000043:notes:22]
Concentrations. A significant portion of our revenues are concentrated with a small number of customers/licensees of our QCT and QTL segments. The comparability of customer/licensee concentrations for the interim periods presented are impacted by the timing of customer/licensees device launches and/or innovation cycles and other seasonal trends, among other fluctuations in demand. Revenues from each customer/licensee that were 10% or greater of total revenues were as follows:

[0001728949-21-000043:notes:23]
|  | Three Months Ended |  | Six Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | March 28,2021 |  | March 29,2020 |  | March 28,2021 |  | March 29,2020 |  |  |  |  |  |  |  |  |  |  |
| Customer/licensee (w) | 16 | % |  | * |  | 25 | % |  | 10 | % |  |  |  |  |  |  |  |  |  |  |
| Customer/licensee (x) | 16 |  |  | 25 | % |  | 14 |  |  | 21 |  |  |  |  |  |  |  |  |  |  |  |
| Customer/licensee (y) | 15 |  |  | 19 |  |  | 13 |  |  | 16 |  |  |  |  |  |  |  |  |  |  |  |
| Customer/licensee (z) | 13 |  |  | * |  | 11 |  |  | * |  |  |  |  |  |  |  |  |  |  |

[0001728949-21-000043:notes:24]
* Less than 10%

[0001728949-21-000043:notes:25]
Accounts receivable at March 28, 2021 and September 27, 2020 included approximately $700 million and $1.3 billion, respectively, excluding the impact of foreign withholding taxes, from Huawei related to the remaining amounts due under the previously disclosed settlement agreement to be paid in installments by the end of June 2021 and estimated royalties for sales made in the March 2021 and September 2020 quarters, respectively, under the global patent license agreement with Huawei. Subsequent to March 28, 2021, Huawei paid the third installment of $300 million (excluding the impact of foreign withholding taxes) under the settlement agreement in accordance with the agreed upon payment schedule.

[0001728949-21-000043:notes:26]
Other Income, Costs and Expenses. Other income in the three and six months ended March 29, 2020 consisted of a $23 million gain related to a favorable legal settlement.

[0001728949-21-000043:notes:27]
| Investment and Other Income (Expense), Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | March 28,2021 |  | March 29,2020 |
| Interest and dividend income | $ | 22 |  |  | $ | 47 |  |  | $ | 42 |  |  | $ | 107 |  |
| Net (losses) gains on marketable securities | (85) |  |  | 55 |  |  | 33 |  |  | 66 |  |
| Net gains (losses) on other investments | 176 |  |  | (12) |  |  | 209 |  |  | 36 |  |
| Net gains (losses) on deferred compensation plan assets | 23 |  |  | (72) |  |  | 77 |  |  | (42) |  |
| Impairment losses on other investments | (15) |  |  | (265) |  |  | (16) |  |  | (337) |  |
| Net (losses) gains on derivative investments | (17) |  |  | — |  |  | (7) |  |  | 1 |  |
| Equity in net earnings (losses) of investees | 12 |  |  | (6) |  |  | 11 |  |  | (16) |  |
| Net (losses) gains on foreign currency transactions | (12) |  |  | 6 |  |  | (26) |  |  | 3 |  |
|  | $ | 104 |  |  | $ | (247) |  |  | $ | 323 |  |  | $ | (182) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-21-000043:notes:28]
Income Taxes
We estimate our annual effective income tax rate to be 12% for fiscal 2021, which is lower than the U.S. federal statutory rate, primarily due to a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, benefits from our federal research and development tax credit and excess tax benefits associated with share-based awards. The effective tax rate of 17% for the second quarter of fiscal 2021 was higher than the estimated annual effective tax rate of 12% primarily due to $87 million of discrete net tax charges recorded in the second quarter of fiscal 2021, which principally related to a tax audit settlement with the Internal Revenue Service and foreign currency losses on a noncurrent receivable related to our refund claim of Korean withholding tax. The effective tax rate of 22% for the second quarter of fiscal 2020 included $28 million of discrete net tax charges recorded in the second quarter of fiscal 2020, which principally related to foreign currency losses on a noncurrent receivable related to our refund claim of Korean withholding tax.

[0001728949-21-000043:notes:29]
Unrecognized tax benefits were $2.0 billion and $1.9 billion at March 28, 2021 and September 27, 2020, respectively, and primarily related to our refund claim of Korean withholding tax. If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We expect that the total amount of unrecognized tax benefits at March 28, 2021 will increase in the next 12 months as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-21-000043:notes:30]
Capital Stock
Stock Repurchase Program. On July 26, 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. The stock repurchase program has no expiration date.

[0001728949-21-000043:notes:31]
In the six months ended March 28, 2021 and March 29, 2020, we repurchased and retired 14 million and 29 million shares, respectively, for $2.0 billion and $2.3 billion, respectively, before commissions. To reflect share repurchases in the consolidated balance sheet, we (i) reduce common stock for the par value of the shares, (ii) reduce paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) record the residual amount, if any, to retained earnings. At March 28, 2021, $2.6 billion remained authorized for repurchase under our stock repurchase program.

[0001728949-21-000043:notes:32]
Dividends. On March 10, 2021, we announced a 5% increase in our quarterly dividend per share of common stock from $0.65 to $0.68, which is effective for dividends payable after March 25, 2021. On April 14, 2021, we announced a cash dividend of $0.68 per share on our common stock, payable on June 24, 2021 to stockholders of record as of the close of business on June 3, 2021.

[0001728949-21-000043:notes:33]
[same as prior period, unchanged from 0001728949-21-000022:notes:30]

[0001728949-21-000043:notes:34]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | March 28,2021 |  | March 29,2020 |
| Dilutive common share equivalents included in diluted shares | 18 |  |  | 12 |  |  | 20 |  |  | 13 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | — |  |  | — |  |  | — |  |  | — |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-21-000043:notes:35]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0001728949-21-000043:notes:36]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by

[0001728949-21-000043:notes:37]
making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000043:notes:38]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our then current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On January 22, 2019, the court appointed the lead plaintiff in the action. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint, and on March 10, 2020, the court granted our motion. On May 11, 2020, the plaintiffs filed a second amended complaint, and on October 8, 2020, the court granted our motion to dismiss the case with prejudice. On November 7, 2020, the plaintiffs filed a notice of appeal. No hearing date has been set. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000043:notes:39]
Consumer Class Action Lawsuits: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. The Ninth Circuit has not yet ruled on our appeal. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000043:notes:40]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000043:notes:41]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, then captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision has subsequently reduced the number of patents asserted to four, granted covenants not to sue on the other patents and dismissed the Samsung and HTC entities from the case. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 26, 2021, the court issued an order stating that trial is extremely unlikely to occur before November or December 2021, if then. We believe that ParkerVision’s claims are without merit.

[0001728949-21-000043:notes:42]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0001728949-21-000043:notes:43]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019 and, on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-21-000043:notes:44]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of their investigation, but we believe it concerns our business practices in connection with our sale of radio frequency front-end (RFFE) components. We continue to cooperate with the KFTC as it conducts its investigation. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-21-000043:notes:45]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision confirming their preliminary view that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

[0001728949-21-000043:notes:46]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation

[0001728949-21-000043:notes:47]
adjustment. At March 28, 2021, the liability, including related foreign currency losses and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $292 million and included in other current liabilities.

[0001728949-21-000043:notes:48]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. A hearing before the court is scheduled for May 4-6, 2021. We believe that our business practices do not violate the EU competition rules.

[0001728949-21-000043:notes:49]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At March 28, 2021, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.2 billion and included in other current liabilities.

[0001728949-21-000043:notes:50]
European Commission (EC) Investigation regarding Radio Frequency Front End (RFFE): On December 3, 2019, we received a Request for Information from the EC notifying us that it was investigating whether we engaged in anti-competitive behavior in the European Union (EU)/European Economic Area (EEA) by leveraging our market position in 5G baseband processors in the RFFE space. We responded to the Request for Information and had several discussions with the EC. In March 2021, the EC informed us that it had closed its investigation.

[0001728949-21-000043:notes:51]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of cellular modem chipsets on the purchaser first agreeing to a license to our cellular standard-essential patents, paying incentives to purchasers of cellular modem chipsets to induce them to accept certain license terms, refusing to license our cellular standard-essential patents to our competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint sought a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief. On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to rival sellers of cellular modem chipsets. On November 6, 2018, the court granted the FTC’s partial summary judgment motion. Trial was held January 4-29, 2019.

[0001728949-21-000043:notes:52]
On May 21, 2019, the court issued an Order setting forth its Findings of Fact and Conclusions of Law. The court concluded that we had monopoly power in the CDMA and premium-tier Long Term Evolution (LTE) cellular modem chip markets, and that we had used that power in these two markets to engage in anticompetitive acts, including (1) using threats of lack of access to cellular modem chip supply to coerce OEMs to accept license terms that include unreasonably high royalty rates; (2) refusing to license our cellular standard-essential patents to competitors selling cellular modem chips; and (3) entering into exclusive dealing arrangements with OEMs that foreclosed our rivals. The court further found that the royalties we charge OEMs are unreasonably high and reflect the use of our monopoly power over CDMA and premium-tier LTE cellular modem chips rather than just the value of our patents. The court concluded that our unreasonably high royalties constitute an anticompetitive surcharge on cellular modem chips sold by our competitors, which increases the effective price of our competitors’ cellular modem chips, reduces their margins and results in exclusivity. The court also found that our practice of not licensing competitors’ cellular modem chips violated our commitments to certain standard-development organizations and a duty under the antitrust laws to license competing cellular modem chip makers and helped us maintain our royalties at unreasonably high levels. Finally, the court found that incentive funds entered into with certain OEMs further harmed competing cellular modem chip makers’ ability to undermine our monopoly position, prevented rivals from entering

[0001728949-21-000043:notes:53]
the market and restricted the sales of those competitors that do enter. The court concluded that the combined effect of our conduct, together with our monopoly power, harmed the competitive process.

[0001728949-21-000043:notes:54]
The court imposed the following injunctive relief: (1) we must not condition the supply of cellular modem chips on a customer’s patent license status, and we must negotiate or renegotiate license terms with customers in good faith under conditions free from the threat of lack of access to or discriminatory provision of cellular modem chip supply or associated technical support or access to software; (2) we must make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers on fair, reasonable and non-discriminatory (FRAND) terms and submit, as necessary, to arbitral or judicial dispute resolution to determine such terms; (3) we may not enter into express or de facto exclusive dealing agreements for the supply of cellular modem chips; and (4) we may not interfere with the ability of any customer to communicate with a government agency about a potential law enforcement or regulatory matter. The court also ordered us to submit to compliance and monitoring procedures for a period of seven years and to report to the FTC on an annual basis regarding our compliance with the above remedies.

[0001728949-21-000043:notes:55]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On August 23, 2019, the Ninth Circuit granted our Motion for Partial Stay. On February 13, 2020, the Ninth Circuit heard oral argument.

[0001728949-21-000043:notes:56]
On August 11, 2020, the Ninth Circuit issued its opinion, which reversed the district court’s judgment, vacated its injunction and vacated its partial grant of summary judgment. The Ninth Circuit stated that the district court erred in holding that we are under an antitrust duty to license rival chip manufacturers and noted that our practice of licensing our standard-essential patents exclusively at the OEM level does not violate the antitrust laws. The Ninth Circuit also held that the district court’s “anticompetitive surcharge” theory failed to state a cogent theory of anticompetitive harm and that our patent-licensing royalties and “no license, no chips” policy do not impose an anticompetitive surcharge on rivals’ modem chip sales and do not undermine competition in either the CDMA or premium LTE chip markets. While agreeing with the district court that our 2011 and 2013 agreements with Apple were structured like exclusive dealing contracts, the Ninth Circuit nonetheless held that neither agreement had the actual or practical effect of substantially foreclosing competition in the CDMA modem chip market, and because Apple terminated these agreements years ago, the district court had improperly issued an injunction. The Ninth Circuit noted that neither the Sherman Act nor any other law prohibits companies like us from (1) licensing their standard-essential patents independently from their chip sales and collecting royalties, and/or (2) limiting their chip customer base to licensed OEMs. On September 25, 2020, the FTC filed a Petition for Rehearing En Banc. On October 28, 2020, the Ninth Circuit denied the FTC’s petition. On March 26, 2021, the FTC’s deadline for filing a petition for certiorari with the U.S. Supreme Court to seek review of the Ninth Circuit’s decision expired. The case is now over.

[0001728949-21-000043:notes:57]
Contingent losses and other considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at March 28, 2021 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-21-000043:notes:58]
Segment InformationWe are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarity of business activities within our operating segments, such as the nature of products, the level of shared products, technology and other resources, production processes and customer base. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. 
QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies for use in mobile devices, wireless networks, devices used in the IoT, broadband gateway equipment, consumer electronic devices and automotive systems for telematics and infotainment. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an investee. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies), our cloud AI inference processing initiative and other technology and service initiatives.

[0001728949-21-000043:notes:59]
Our CODM allocates resources to and evaluates the performance of our segments based on revenues and earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense, certain net investment income, certain share-based compensation, gains and losses on our deferred compensation plan liabilities and related assets and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories and property, plant and equipment to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and awards, settlements and/or damages arising from legal or regulatory matters.

[0001728949-21-000043:notes:60]
[same as prior period, unchanged from 0001728949-21-000022:notes:57]

[0001728949-21-000043:notes:61]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | March 28,2021 |  | March 29,2020 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 6,281 |  |  | $ | 4,100 |  |  | $ | 12,814 |  |  | $ | 7,719 |  |
| QTL | 1,614 |  |  | 1,072 |  |  | 3,273 |  |  | 2,477 |  |
| QSI | 10 |  |  | 10 |  |  | 19 |  |  | 30 |  |
| Reconciling items | 30 |  |  | 34 |  |  | 64 |  |  | 66 |  |
| Total | $ | 7,935 |  |  | $ | 5,216 |  |  | $ | 16,170 |  |  | $ | 10,292 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 1,584 |  |  | $ | 667 |  |  | $ | 3,503 |  |  | $ | 1,145 |  |
| QTL | 1,191 |  |  | 671 |  |  | 2,461 |  |  | 1,689 |  |
| QSI | 98 |  |  | (208) |  |  | 256 |  |  | (210) |  |
| Reconciling items | (744) |  |  | (532) |  |  | (1,488) |  |  | (1,079) |  |
| Total | $ | 2,129 |  |  | $ | 598 |  |  | $ | 4,732 |  |  | $ | 1,545 |  |

[0001728949-21-000043:notes:62]
[same as prior period, unchanged from 0001728949-21-000022:notes:59]

[0001728949-21-000043:notes:63]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | March 28,2021 |  | March 29,2020 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 30 |  |  | $ | 34 |  |  | $ | 64 |  |  | $ | 66 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of revenues | $ | (72) |  |  | $ | (84) |  |  | $ | (148) |  |  | $ | (175) |  |
| Unallocated research and development expenses | (415) |  |  | (216) |  |  | (821) |  |  | (475) |  |
| Unallocated selling, general and administrative expenses | (113) |  |  | (56) |  |  | (291) |  |  | (172) |  |
| Unallocated other income (Note 2) | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Unallocated interest expense | (141) |  |  | (145) |  |  | (282) |  |  | (293) |  |
| Unallocated investment and other income (expense), net | 14 |  |  | (30) |  |  | 85 |  |  | 52 |  |
| Nonreportable segments | (17) |  |  | (24) |  |  | (31) |  |  | (39) |  |
|  | $ | (744) |  |  | $ | (532) |  |  | $ | (1,488) |  |  | $ | (1,079) |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001728949-21-000043:notes:64]
Acquisitions 
On March 16, 2021 (the Closing Date), we completed the acquisition of NuVia, Inc. (NUVIA) for $1.1 billion (net of cash acquired), substantially all of which was paid in cash. In connection with the acquisition, we assumed or replaced unvested NUVIA stock awards with Qualcomm stock awards with an estimated fair value of $258 million, for which $10 million was attributable to pre-acquisition services and included in the purchase price, and the remaining amount will be recognized as compensation expense over the related post-acquisition requisite service period of up to four years.

[0001728949-21-000043:notes:65]
NUVIA has certain in-process technologies and is comprised of a CPU (central processing unit) and technology design team with expertise in high performance processors, SoC (system-on-chip) and power management for compute-intensive devices and applications. Upon completion of development, NUVIA’s technologies are expected to be integrated into certain QCT products.

[0001728949-21-000043:notes:66]
We have not finalized the purchase price allocation. Accordingly, the preliminary purchase price allocation shown below could change as the fair values of the tangible and intangible assets acquired and liabilities assumed, and the related income tax effects, are finalized during the remainder of the measurement period (which will not exceed 12 months from the Closing Date). The preliminary allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0001728949-21-000043:notes:67]
| Cash | $ | 174 |  |
| In-process research and development (IPR&D) | 247 |  |
| Goodwill | 887 |  |
| Other assets | 25 |  |
| Total assets | 1,333 |  |
| Liabilities | (69) |  |
| Net assets acquired | $ | 1,264 |  |

[0001728949-21-000043:notes:68]
Goodwill recognized in this transaction is not deductible for tax purposes and was allocated to our QCT segment for annual impairment testing purposes. Goodwill is primarily attributable to assembled workforce and certain revenue and cost synergies expected to arise after the acquisition. IPR&D related to a single project, which is expected to be completed in fiscal 2023 and, upon completion, will be amortized over its useful life (which is expected to be 7 years). The estimated fair value of the IPR&D asset acquired was determined using an income approach based on significant inputs that were not observable.

[0001728949-21-000043:notes:69]
Our results of operations for the second quarter of fiscal 2021 included the operating results of NUVIA since the Closing Date, the amounts of which were not material. Pro forma results of operations have not been presented because the effects of this acquisition were not material to our condensed consolidated results of operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-21-000043:notes:70]
Fair Value Measurements
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at March 28, 2021 (in millions):

[0001728949-21-000043:notes:71]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 1,789 |  |  | $ | 2,869 |  |  | $ | — |  |  | $ | 4,658 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Corporate bonds and notes | — |  |  | 5,003 |  |  | — |  |  | 5,003 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 176 |  |  | 35 |  |  | 211 |  |
| Equity securities | 336 |  |  | — |  |  | — |  |  | 336 |  |
| Total marketable securities | 336 |  |  | 5,190 |  |  | 35 |  |  | 5,561 |  |
| Derivative instruments | — |  |  | 78 |  |  | — |  |  | 78 |  |
| Other investments | 617 |  |  | — |  |  | 10 |  |  | 627 |  |
| Total assets measured at fair value | $ | 2,742 |  |  | $ | 8,137 |  |  | $ | 45 |  |  | $ | 10,924 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |
| Other liabilities | 617 |  |  | — |  |  | — |  |  | 617 |  |
| Total liabilities measured at fair value | $ | 617 |  |  | $ | 18 |  |  | $ | — |  |  | $ | 635 |  |

[0001728949-21-000043:notes:72]
Activity within Level 3 of the Fair Value Hierarchy. Other investments included in Level 3 at March 28, 2021 were comprised of non-marketable debt instruments. Activity for marketable securities and other investments classified within Level 3 was insignificant during the six months ended March 28, 2021 (primarily related to settlements of non-marketable debt instruments) and the six months ended March 29, 2020 (primarily related to impairments of certain non-marketable debt instruments and purchases of non-marketable debt instruments). Activity for other liabilities classified within Level 3 was insignificant during the six months ended March 29, 2020.

[0001728949-21-000043:notes:73]
Assets Measured and Recorded at Fair Value on a Nonrecurring Basis. We measure certain assets and liabilities at fair value on a nonrecurring basis. These assets and liabilities include equity method and non-marketable equity investments, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During the six months ended March 28, 2021 and March 29, 2020, certain of our non-marketable equity investments were written down to their estimated fair values, which was recorded as a component of impairment losses on other investments in investment and other income (expense), net (Note 2), and certain other non-marketable equity investments were remeasured to their estimated fair values based on observable price changes in orderly transactions for identical or similar securities, which is recorded as a component of net gains on other investments in investment and other income (expense), net (Note 2). The estimation of fair value used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3.

[0001728949-21-000043:notes:74]
Long-term Debt. At March 28, 2021 and September 27, 2020, the aggregate fair value of our outstanding floating- and fixed-rate notes, based on Level 2 inputs, was approximately $16.6 billion and $17.5 billion, respectively.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-21-000043:notes:75]
Marketable Securities
Our marketable securities were comprised as follows (in millions):

[0001728949-21-000043:notes:76]
|  | Current |  | Noncurrent (1) |
|  | March 28,2021 |  | September 27,2020 |  | March 28,2021 |  | September 27,2020 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 11 |  |  | $ | 10 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 5,003 |  |  | 4,049 |  |  | — |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 176 |  |  | 66 |  |  | 35 |  |  | 35 |  |
| Total available-for-sale debt securities | 5,190 |  |  | 4,125 |  |  | 35 |  |  | 35 |  |
| Equity securities | 336 |  |  | 352 |  |  | — |  |  | — |  |
| Time deposit (2) | — |  |  | 30 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 5,526 |  |  | $ | 4,507 |  |  | $ | 35 |  |  | $ | 35 |  |

[0001728949-21-000043:notes:77]
(1) Noncurrent marketable securities were included in other assets.

[0001728949-21-000043:notes:78]
(2) At September 27, 2020, marketable securities also included a time deposit with an original maturity of greater than 90 days.

[0001728949-21-000043:notes:79]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001728949-21-000043:notes:80]
|  | March 28,2021 |
| Years to Maturity |  |
| Less than one year | $ | 2,103 |  |
| One to five years | 2,911 |  |
| No single maturity date | 211 |  |
| Total | $ | 5,225 |  |

[0001728949-21-000043:notes:81]
Debt securities with no single maturity date included mortgage- and asset-backed securities and auction rate securities.
