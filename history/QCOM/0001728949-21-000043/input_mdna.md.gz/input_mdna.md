# QCOM MD&A — 0001728949-21-000043


## mdna

[0001728949-21-000043:mdna:1]
[same as prior period, unchanged from 0001728949-21-000022:mdna:1]

[0001728949-21-000043:mdna:2]
[same as prior period, unchanged from 0001728949-21-000022:mdna:2]

[0001728949-21-000043:mdna:3]
This Quarterly Report (including but not limited to this section titled Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements regarding our business, investments, financial condition, results of operations, cash flows and prospects. Forward-looking statements also include but are not limited to statements regarding the coronavirus (COVID-19) pandemic and its potential future impact on the global economy, economic uncertainty and consumer and business confidence; demand for devices that incorporate our products and intellectual property; our and the global wireless industry’s supply chains, transportation and distribution networks and workforces; 5G network deployments; and our business, revenues, results of operations, cash flows and financial condition; as well as statements regarding our planning assumptions, workforce practices, the duration and severity of the pandemic, and government and other actions to mitigate the spread of, and to treat, COVID-19. Forward-looking statements further include but are not limited to statements regarding industry, market, business, product, technology, commercial, competitive or consumer trends, including seasonality; the 5G transition; our businesses, growth potential or strategies, or factors that may impact them; challenges to our licensing business, including by licensees, governments, governmental agencies or regulators, standards bodies or others; challenges to our QCT business; other legal or regulatory matters; competition; new or expanded product areas, adjacent industry segments and applications; costs or expenditures including research and development, selling, general and administrative, restructuring or restructuring-related charges, working capital or information technology systems; our debt, financing, stock repurchase or dividend programs; our liquidity and capital resources, including our expected increase in operating cash outflows to secure long-term capacity commitments with certain of our suppliers; strategic investments or acquisitions, and the anticipated timing or benefits thereof; adoption and application of future accounting guidance; tax law changes; our tax structure or strategies; U.S./China trade or national security policies; and the potential business or financial statement impacts of any of the above, among others. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001728949-21-000043:mdna:4]
Second Quarter Fiscal 2021 Overview

[0001728949-21-000043:mdna:5]
Revenues for the second quarter of fiscal 2021 were $7.9 billion, an increase of 52% compared to the year ago quarter, with net income of $1.8 billion, an increase of 276% compared to the year ago quarter. Highlights from the second quarter of fiscal 2021 and other recent events included:

[0001728949-21-000043:mdna:6]
•QCT revenues increased by 53% in the second quarter of fiscal 2021 compared to the year ago quarter, primarily due to an increase in demand for 5G products across handsets and RFFE, along with higher automotive and IoT revenues.

[0001728949-21-000043:mdna:7]
23

[0001728949-21-000043:mdna:8]
•QTL revenues increased by 51% in the second quarter of fiscal 2021 compared to the year ago quarter, primarily due to an increase in estimated sales of 3G/4G/5G-based multimode products, which was primarily driven by a recovery from the negative impacts of COVID-19.

[0001728949-21-000043:mdna:9]
•On March 16, 2021, we completed the acquisition of NuVia, Inc. (NUVIA) for $1.1 billion, net of cash acquired. NUVIA has certain in-process technologies and is comprised of a CPU (central processing unit) and technology design team with expertise in high performance processors, SoC (system-on-chip) and power management for compute-intensive devices and applications. Upon completion of development, NUVIA’s technologies are expected to be integrated into certain QCT products.

[0001728949-21-000043:mdna:10]
•On March 26, 2021, the FTC’s deadline for filing a petition for certiorari with the U.S. Supreme Court to seek review of the Ninth Circuit’s decision in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated expired. The case is now over.

[0001728949-21-000043:mdna:11]
[same as prior period, unchanged from 0001728949-21-000022:mdna:11]

[0001728949-21-000043:mdna:12]
[same as prior period, unchanged from 0001728949-21-000022:mdna:12]

[0001728949-21-000043:mdna:13]
[same as prior period, unchanged from 0001728949-21-000022:mdna:13]

[0001728949-21-000043:mdna:14]
[same as prior period, unchanged from 0001728949-21-000022:mdna:14]

[0001728949-21-000043:mdna:15]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when licensees’ sales occur. We expect QCT revenues to continue to be impacted by seasonal trends related to product launch timing for sales made to Apple under our multi-year chipset supply agreement. These trends may or may not continue in the future and have been impacted by past declines in consumer demand resulting from COVID-19. Further, the trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings.

[0001728949-21-000043:mdna:16]
[same as prior period, unchanged from 0001728949-21-000022:mdna:16]

[0001728949-21-000043:mdna:17]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | Change |  | March 28,2021 |  | March 29,2020 |  | Change |
| Equipment and services | $ | 6,239 |  |  | $ | 4,050 |  |  | $ | 2,189 |  |  | $ | 12,681 |  |  | $ | 7,583 |  |  | $ | 5,098 |  |
| Licensing | 1,696 |  |  | 1,166 |  |  | 530 |  |  | 3,489 |  |  | 2,709 |  |  | 780 |  |
|  | $ | 7,935 |  |  | $ | 5,216 |  |  | $ | 2,719 |  |  | $ | 16,170 |  |  | $ | 10,292 |  |  | $ | 5,878 |  |

[0001728949-21-000043:mdna:18]
Second quarter 2021 vs. 2020

[0001728949-21-000043:mdna:19]
The increase in revenues in the second quarter of fiscal 2021 was primarily due to:

[0001728949-21-000043:mdna:20]
+    $2.2 billion in higher equipment and services revenues from our QCT segment

[0001728949-21-000043:mdna:21]
+    $542 million in higher licensing revenues from our QTL segment

[0001728949-21-000043:mdna:22]
First six months 2021 vs. 2020

[0001728949-21-000043:mdna:23]
The increase in revenues in the first six months of fiscal 2021 was primarily due to:

[0001728949-21-000043:mdna:24]
+    $5.1 billion in higher equipment and services revenues from our QCT segment

[0001728949-21-000043:mdna:25]
+    $796 million in higher licensing revenues from our QTL segment

[0001728949-21-000043:mdna:26]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | Change |  | March 28,2021 |  | March 29,2020 |  | Change |
| Cost of revenues | $ | 3,432 |  |  | $ | 2,297 |  |  | $ | 1,135 |  |  | $ | 6,921 |  |  | $ | 4,410 |  |  | $ | 2,511 |  |
| Gross margin | 57 | % |  | 56 | % |  |  |  | 57 | % |  | 57 | % |  |  |

[0001728949-21-000043:mdna:27]
Second quarter 2021 vs. 2020

[0001728949-21-000043:mdna:28]
Gross margin percentage increased in the second quarter of fiscal 2021 primarily due to a decrease in charges related to the amortization of intangible assets as a percentage of revenues.

[0001728949-21-000043:mdna:29]
First six months 2021 vs. 2020

[0001728949-21-000043:mdna:30]
Gross margin percentage remained flat in the first six months of fiscal 2021 primarily due to:

[0001728949-21-000043:mdna:31]
[same as prior period, unchanged from 0001728949-21-000022:mdna:25]

[0001728949-21-000043:mdna:32]
[same as prior period, unchanged from 0001728949-21-000022:mdna:26]

[0001728949-21-000043:mdna:33]
+    decrease in charges related to the amortization of intangible assets as a percentage of revenues

[0001728949-21-000043:mdna:34]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | Change |  | March 28,2021 |  | March 29,2020 |  | Change |
| Research and development | $ | 1,780 |  |  | $ | 1,468 |  |  | $ | 312 |  |  | $ | 3,433 |  |  | $ | 2,873 |  |  | $ | 560 |  |
| % of revenues | 22 | % |  | 28 | % |  |  |  | 21 | % |  | 28 | % |  |  |

[0001728949-21-000043:mdna:35]
Second quarter 2021 vs. 2020

[0001728949-21-000043:mdna:36]
The increase in research and development expenses in the second quarter of fiscal 2021 was primarily due to:

[0001728949-21-000043:mdna:37]
+    $167 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), a portion of which was attributable to higher employee cash incentive program costs

[0001728949-21-000043:mdna:38]
+    $90 million increase in share-based compensation expense

[0001728949-21-000043:mdna:39]
+    $56 million increase in expenses driven by revaluation of our deferred compensation obligation on improved stock market performance (which resulted in a corresponding increase in net gains on deferred compensation plan assets within investment and other income (expense), net due to the revaluation of the related assets)

[0001728949-21-000043:mdna:40]
First six months 2021 vs. 2020

[0001728949-21-000043:mdna:41]
The increase in research and development expenses in the first six months of fiscal 2021 was primarily due to:

[0001728949-21-000043:mdna:42]
+    $337 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), a portion of which was attributable to higher employee cash incentive program costs

[0001728949-21-000043:mdna:43]
+    $164 million increase in share-based compensation expense

[0001728949-21-000043:mdna:44]
+    $59 million increase in expenses driven by revaluation of our deferred compensation obligation on improved stock market performance (which resulted in a corresponding increase in net gains on deferred compensation plan assets within investment and other income (expense), net due to the revaluation of the related assets)

[0001728949-21-000043:mdna:45]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | Change |  | March 28,2021 |  | March 29,2020 |  | Change |
| Selling, general and administrative | $ | 557 |  |  | $ | 483 |  |  | $ | 74 |  |  | $ | 1,124 |  |  | $ | 1,011 |  |  | $ | 113 |  |
| % of revenues | 7 | % |  | 9 | % |  |  |  | 7 | % |  | 10 | % |  |  |

[0001728949-21-000043:mdna:46]
[same as prior period, unchanged from 0001728949-21-000022:mdna:44]

[0001728949-21-000043:mdna:47]
Second quarter 2021 vs. 2020

[0001728949-21-000043:mdna:48]
The increase in selling, general and administrative expenses in the second quarter of fiscal 2021 was primarily due to:

[0001728949-21-000043:mdna:49]
+    $38 million increase in expenses driven by revaluation of our deferred compensation obligation on improved stock market performance (which resulted in a corresponding increase in net gains on deferred compensation plan assets within investment and other income (expense), net due to the revaluation of the related assets)

[0001728949-21-000043:mdna:50]
+    $31 million increase in employee-related expenses driven primarily by higher employee cash incentive program costs

[0001728949-21-000043:mdna:51]
+    $21 million increase in share-based compensation expense

[0001728949-21-000043:mdna:52]
-    $20 million decrease in litigation costs

[0001728949-21-000043:mdna:53]
First six months 2021 vs. 2020

[0001728949-21-000043:mdna:54]
The increase in selling, general and administrative expenses in the first six months of fiscal 2021 was primarily due to:

[0001728949-21-000043:mdna:55]
+    $58 million increase in expenses driven by revaluation of our deferred compensation obligation on improved stock market performance (which resulted in a corresponding increase in net gains on deferred compensation plan assets within investment and other income (expense), net due to the revaluation of the related assets)

[0001728949-21-000043:mdna:56]
+    $43 million increase in share-based compensation expense

[0001728949-21-000043:mdna:57]
+    $19 million increase in employee-related expenses driven by higher employee cash incentive program costs

[0001728949-21-000043:mdna:58]
-    $38 million decrease in litigation costs

[0001728949-21-000043:mdna:59]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | Change |  | March 28,2021 |  | March 29,2020 |  | Change |
| Other income | $ | — |  |  | $ | (23) |  |  | $ | 23 |  |  | $ | — |  |  | $ | (23) |  |  | $ | 23 |  |

[0001728949-21-000043:mdna:60]
Second quarter and first six months 2020

[0001728949-21-000043:mdna:61]
Other income in the second quarter and first six months of fiscal 2020 consisted of:

[0001728949-21-000043:mdna:62]
+    $23 million gain related to a favorable legal settlement

[0001728949-21-000043:mdna:63]
| Interest Expense and Investment and Other Income (Expense), Net (in millions) |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | Change |  | March 28,2021 |  | March 29,2020 |  | Change |
| Interest expense | $ | 141 |  |  | $ | 146 |  |  | $ | (5) |  |  | $ | 283 |  |  | $ | 294 |  |  | $ | (11) |  |
| Investment and other income (expense), net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 22 |  |  | $ | 47 |  |  | $ | (25) |  |  | $ | 42 |  |  | $ | 107 |  |  | $ | (65) |  |
| Net (losses) gains on marketable securities | (85) |  |  | 55 |  |  | (140) |  |  | 33 |  |  | 66 |  |  | (33) |  |
| Net gains (losses) on other investments | 176 |  |  | (12) |  |  | 188 |  |  | 209 |  |  | 36 |  |  | 173 |  |
| Net gains (losses) on deferred compensation plan assets | 23 |  |  | (72) |  |  | 95 |  |  | 77 |  |  | (42) |  |  | 119 |  |
| Impairment losses on other investments | (15) |  |  | (265) |  |  | 250 |  |  | (16) |  |  | (337) |  |  | 321 |  |
| Net (losses) gains on derivative instruments | (17) |  |  | — |  |  | (17) |  |  | (7) |  |  | 1 |  |  | (8) |  |
| Equity in net earnings (losses) of investees | 12 |  |  | (6) |  |  | 18 |  |  | 11 |  |  | (16) |  |  | 27 |  |
| Net (losses) gains on foreign currency transactions | (12) |  |  | 6 |  |  | (18) |  |  | (26) |  |  | 3 |  |  | (29) |  |
|  | $ | 104 |  |  | $ | (247) |  |  | $ | 351 |  |  | $ | 323 |  |  | $ | (182) |  |  | $ | 505 |  |

[0001728949-21-000043:mdna:64]
Net gains on other investments for the three and six months ended March 28, 2021 was driven primarily by realized gains resulting from the sale of certain of our QSI non-marketable investments.

[0001728949-21-000043:mdna:65]
The impairment losses on other investments for the three and six months ended March 29, 2020 were due in part to the impact COVID-19 had on certain of our investees. A significant portion of the impairment losses related to our investment in OneWeb who filed for bankruptcy in the second quarter of fiscal 2020. Additionally, COVID-19 had a negative impact on the fair values of our deferred compensation plan assets, resulting in a net loss on such assets in the three and six months ended March 29, 2020.

[0001728949-21-000043:mdna:66]
[same as prior period, unchanged from 0001728949-21-000022:mdna:39]

[0001728949-21-000043:mdna:67]
[same as prior period, unchanged from 0001728949-21-000022:mdna:40]

[0001728949-21-000043:mdna:68]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | March 28,2021 |  | March 29,2020 |
| Expected income tax provision at federal statutory tax rate | $ | 447 |  |  | $ | 126 |  |  | $ | 994 |  |  | $ | 324 |  |
| Benefit from foreign-derived intangible income (FDII) deduction | (115) |  |  | (43) |  |  | (189) |  |  | (89) |  |
| Excess tax benefit associated with share-based awards | (22) |  |  | (10) |  |  | (184) |  |  | (56) |  |
| Benefit related to the research and development tax credit | (39) |  |  | (35) |  |  | (98) |  |  | (60) |  |
| Audit settlement with Internal Revenue Service | 55 |  |  | — |  |  | 55 |  |  | — |  |
| Foreign currency loss (gain) related to foreign withholding tax receivable | 33 |  |  | 47 |  |  | (46) |  |  | 4 |  |
| Other | 8 |  |  | 45 |  |  | (17) |  |  | 29 |  |
| Income tax expense | $ | 367 |  |  | $ | 130 |  |  | $ | 515 |  |  | $ | 152 |  |
| Effective tax rate | 17 | % |  | 22 | % |  | 11 | % |  | 10 | % |

[0001728949-21-000043:mdna:69]
We estimate our annual effective income tax rate to be 12% for fiscal 2021, which is lower than the U.S. federal statutory rate, primarily due to a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, benefits from our federal research and development tax credit and excess tax benefits associated with share-based awards.

[0001728949-21-000043:mdna:70]
[same as prior period, unchanged from 0001728949-21-000022:mdna:43]

[0001728949-21-000043:mdna:71]
27

[0001728949-21-000043:mdna:72]
[same as prior period, unchanged from 0001728949-21-000022:mdna:45]

[0001728949-21-000043:mdna:73]
The following should be read in conjunction with our financial results for the second quarter and first six months of fiscal 2021 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0001728949-21-000043:mdna:74]
[same as prior period, unchanged from 0001728949-21-000022:mdna:47]

[0001728949-21-000043:mdna:75]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | Change |  | March 28,2021 |  | March 29,2020 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets (1) | $ | 4,065 |  |  | $ | 2,652 |  |  | $ | 1,413 |  |  | $ | 8,281 |  |  | $ | 5,004 |  |  | $ | 3,277 |  |
| RFFE (2) | 903 |  |  | 650 |  |  | 253 |  |  | 1,964 |  |  | 1,063 |  |  | 901 |  |
| Automotive (3) | 240 |  |  | 171 |  |  | 69 |  |  | 452 |  |  | 318 |  |  | 134 |  |
| IoT (Internet of Things) (4) | 1,073 |  |  | 627 |  |  | 446 |  |  | 2,117 |  |  | 1,334 |  |  | $ | 783 |  |
| Total revenues | $ | 6,281 |  |  | $ | 4,100 |  |  | $ | 2,181 |  |  | $ | 12,814 |  |  | $ | 7,719 |  |  | $ | 5,095 |  |
| EBT (5) | $ | 1,584 |  |  | $ | 667 |  |  | $ | 917 |  |  | $ | 3,503 |  |  | $ | 1,145 |  |  | $ | 2,358 |  |
| EBT as a % of revenues | 25 | % |  | 16 | % |  | 9 points |  | 27 | % |  | 15 | % |  | 12 points |

[0001728949-21-000043:mdna:76]
[same as prior period, unchanged from 0001728949-21-000022:mdna:49]

[0001728949-21-000043:mdna:77]
[same as prior period, unchanged from 0001728949-21-000022:mdna:50]

[0001728949-21-000043:mdna:78]
[same as prior period, unchanged from 0001728949-21-000022:mdna:51]

[0001728949-21-000043:mdna:79]
(4) Primarily includes products sold for use in cellular and non-cellular connected devices within the following industry segments and applications: consumer, computing, industrial, fixed wireless broadband, voice and music and wireless networking.

[0001728949-21-000043:mdna:80]
(5) Earnings (loss) before income taxes.

[0001728949-21-000043:mdna:81]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $6.2 billion and $4.0 billion in the second quarter of fiscal 2021 and 2020, respectively, and $12.6 billion and $7.5 billion in the first six months of fiscal 2021 and 2020, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our stand-alone Mobile Data Modems, Snapdragon platforms (which include processors and modems), radio frequency, power management and wireless connectivity integrated chipsets.

[0001728949-21-000043:mdna:82]
Second quarter 2021 vs. 2020

[0001728949-21-000043:mdna:83]
The increase in QCT revenues in the second quarter of fiscal 2021 was primarily due to:

[0001728949-21-000043:mdna:84]
+    higher handsets revenues, primarily driven by $1.5 billion in higher chipset shipments, which was primarily due to an increase in demand for 5G products from major OEMs, including Apple, partially offset by $155 million in lower revenues per chipset primarily due to unfavorable mix

[0001728949-21-000043:mdna:85]
+    higher RFFE revenues, primarily driven by an increase in demand for 4G/5G products from major OEMs, including Apple

[0001728949-21-000043:mdna:86]
+    higher automotive revenues, primarily driven by an increase in demand for infotainment and telematics products

[0001728949-21-000043:mdna:87]
[same as prior period, unchanged from 0001728949-21-000022:mdna:60]

[0001728949-21-000043:mdna:88]
QCT EBT as a percentage of revenues increased in the second quarter of fiscal 2021 primarily due to:

[0001728949-21-000043:mdna:89]
[same as prior period, unchanged from 0001728949-21-000022:mdna:62]

[0001728949-21-000043:mdna:90]
-    higher operating expenses, primarily driven by higher research and development expenses

[0001728949-21-000043:mdna:91]
First six months 2021 vs. 2020

[0001728949-21-000043:mdna:92]
The increase in QCT revenues in the first six months of fiscal 2021 was primarily due to:

[0001728949-21-000043:mdna:93]
+    higher handsets revenues, primarily driven by $2.3 billion in higher chipset shipments and $904 million in higher revenues per chipset, both of which were primarily due to an increase in demand for 5G products from Apple and other major OEMs

[0001728949-21-000043:mdna:94]
+    higher RFFE revenues, primarily driven by an increase in demand for 4G/5G products from Apple and other major OEMs

[0001728949-21-000043:mdna:95]
+    higher automotive revenues, primarily driven by an increase in demand for telematics and infotainment products

[0001728949-21-000043:mdna:96]
+    higher IoT revenues, primarily driven by an increase in demand for connected devices due to the continued work and learn from home environment

[0001728949-21-000043:mdna:97]
[same as prior period, unchanged from 0001728949-21-000022:mdna:94]

[0001728949-21-000043:mdna:98]
QCT EBT as a percentage of revenues increased in the first six months of fiscal 2021 primarily due to:

[0001728949-21-000043:mdna:99]
+    higher revenues

[0001728949-21-000043:mdna:100]
+    higher gross margin percentage, primarily driven by higher average selling prices, partially offset by higher average unit costs

[0001728949-21-000043:mdna:101]
-    higher research and development expenses

[0001728949-21-000043:mdna:102]
[same as prior period, unchanged from 0001728949-21-000022:mdna:65]

[0001728949-21-000043:mdna:103]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | Change |  | March 28,2021 |  | March 29,2020 |  | Change |
| Licensing revenues | $ | 1,614 |  |  | $ | 1,072 |  |  | $ | 542 |  |  | $ | 3,273 |  |  | $ | 2,477 |  |  | $ | 796 |  |
| EBT | 1,191 |  |  | 671 |  |  | 520 |  |  | 2,461 |  |  | 1,689 |  |  | 772 |  |
| EBT as a % of revenues | 74 | % |  | 63 | % |  | 11 points |  | 75 | % |  | 68 | % |  | 7 points |

[0001728949-21-000043:mdna:104]
As a result of the global patent license agreement entered into with Huawei in July 2020, QTL results for the first six months of fiscal 2021 included revenues for royalties due on sales made by Huawei in the December 2020 and March 2021 quarters. We did not record any revenues in the first six months of fiscal 2020 for royalties due on the sales of Huawei’s consumer wireless products.

[0001728949-21-000043:mdna:105]
Second quarter 2021 vs. 2020

[0001728949-21-000043:mdna:106]
The increase in QTL licensing revenues in the second quarter of fiscal 2021 was primarily due to:

[0001728949-21-000043:mdna:107]
+    $561 million in higher estimated sales of 3G/4G/5G-based multimode products, primarily due to a recovery from the negative impacts of COVID-19 and to a lesser extent, due to the new license agreement with Huawei

[0001728949-21-000043:mdna:108]
+    $58 million in higher estimated revenues per unit, primarily due to favorable OEM mix

[0001728949-21-000043:mdna:109]
-    $78 million in lower royalty revenues recognized related to devices sold in prior periods

[0001728949-21-000043:mdna:110]
QTL EBT as a percentage of revenues increased in the second quarter of fiscal 2021 primarily due to:

[0001728949-21-000043:mdna:111]
+    higher revenues

[0001728949-21-000043:mdna:112]
-    higher research and development expenses

[0001728949-21-000043:mdna:113]
First six months 2021 vs. 2020

[0001728949-21-000043:mdna:114]
The increase in QTL licensing revenues in the first six months of fiscal 2021 was primarily due to:

[0001728949-21-000043:mdna:115]
+    $765 million in higher estimated sales of 3G/4G/5G-based multimode products, primarily due to a recovery from the negative impacts of COVID-19 and to a lesser extent, due to the new license agreement with Huawei

[0001728949-21-000043:mdna:116]
+    $104 million in higher estimated revenues per unit, primarily due to favorable OEM mix

[0001728949-21-000043:mdna:117]
-    $72 million in lower royalty revenues recognized related to devices sold in prior periods

[0001728949-21-000043:mdna:118]
QTL EBT as a percentage of revenues increased in the first six months of fiscal 2021 primarily due to:

[0001728949-21-000043:mdna:119]
+    higher revenues

[0001728949-21-000043:mdna:120]
-    higher research and development expenses

[0001728949-21-000043:mdna:121]
[same as prior period, unchanged from 0001728949-21-000022:mdna:71]

[0001728949-21-000043:mdna:122]
|  | Three Months Ended |  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | Change |  | March 28,2021 |  | March 29,2020 |  | Change |
| Equipment and services revenues | $ | 10 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 19 |  |  | $ | 30 |  |  | $ | (11) |  |
| EBT | 98 |  |  | (208) |  |  | 306 |  |  | 256 |  |  | (210) |  |  | 466 |  |

[0001728949-21-000043:mdna:123]
Second quarter 2021 vs. 2020

[0001728949-21-000043:mdna:124]
The increase in QSI EBT in the second quarter of fiscal 2021 was primarily due to:

[0001728949-21-000043:mdna:125]
+    $247 million decrease in impairment losses on other investments, of which a significant portion related to our investment in OneWeb

[0001728949-21-000043:mdna:126]
+    $41 million increase in net gains on investments

[0001728949-21-000043:mdna:127]
[same as prior period, unchanged from 0001728949-21-000022:mdna:105]

[0001728949-21-000043:mdna:128]
First six months 2021 vs. 2020

[0001728949-21-000043:mdna:129]
The increase in QSI EBT in the first six months of fiscal 2021 was primarily due to:

[0001728949-21-000043:mdna:130]
+     $318 million decrease in impairment losses on other investments, of which a significant portion related to our investment in OneWeb

[0001728949-21-000043:mdna:131]
+     $129 million increase in net gains on investments

[0001728949-21-000043:mdna:132]
[same as prior period, unchanged from 0001728949-21-000022:mdna:77]

[0001728949-21-000043:mdna:133]
In the coming years, we expect new consumer demand for 3G/4G/5G multimode and 5G products and services to continue to ramp around the world as we transition from 3G/4G multimode and 4G products and services. We believe that 5G will continue to drive adoption of certain technologies that are already commonly used in smartphones by industry segments and applications beyond mobile, such as automotive and IoT. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing, and a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long-term.

[0001728949-21-000043:mdna:134]
[same as prior period, unchanged from 0001728949-21-000022:mdna:79]

[0001728949-21-000043:mdna:135]
•We expect QCT revenues to continue to be favorably impacted compared to the prior year as we make shipments to support Apple’s iPhone products, as well as to reflect increased demand for connected devices resulting from the continued work and learn from home environment.

[0001728949-21-000043:mdna:136]
•We have also seen and expect to continue to see increased demand for integrated circuit products, particularly from certain Chinese OEMs as they position to gain device share in China. However, since it will take time for us to adapt our supply chain processes, and due to the limited supply capacity across the semiconductor industry, we do not expect to realize the full benefit from this increased demand. We currently expect to see improvements in supply capacity by the end of the calendar year.

[0001728949-21-000043:mdna:137]
[same as prior period, unchanged from 0001728949-21-000022:mdna:85]

[0001728949-21-000043:mdna:138]
•We expect our research and development costs will increase compared to the prior year, primarily due to increased investment towards advancements in 5G and application processor technologies and certain other long-term initiatives, as well as an increase in share-based compensation expense.

[0001728949-21-000043:mdna:139]
•We expect continued intense competition, particularly in China.

[0001728949-21-000043:mdna:140]
[same as prior period, unchanged from 0001728949-21-000022:mdna:88]

[0001728949-21-000043:mdna:141]
•The COVID-19 pandemic has resulted in significant economic uncertainty, which resulted in a global recession. While the pandemic has had a negative impact on consumer demand for some devices that incorporate our products and intellectual property, as compared to economic conditions and consumer demand prior to the pandemic, we currently do not expect a significant impact on our results of operations in the future. The degree to which the COVID-19 pandemic impacts our business, financial condition and results of operations will depend on future developments, which are highly uncertain. See “Risk Factors” in this Quarterly Report, specifically the Risk Factor titled “The coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and may continue to impact us in the future.”

[0001728949-21-000043:mdna:142]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless industry and governments as to the benefits of our licensing program and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technologies and not welcome the success of our licensing program in enabling new, highly cost-effective competitors to their products. Accordingly, such companies, and/or governments or regulators, may continue to challenge our business model in various forums throughout the world.

[0001728949-21-000043:mdna:143]
[same as prior period, unchanged from 0001728949-21-000022:mdna:90]

[0001728949-21-000043:mdna:144]
[same as prior period, unchanged from 0001728949-21-000022:mdna:117]

[0001728949-21-000043:mdna:145]
[same as prior period, unchanged from 0001728949-21-000022:mdna:91]

[0001728949-21-000043:mdna:146]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at March 28, 2021 and September 27, 2020 and for the first six months of fiscal 2021 and 2020 (in millions):

[0001728949-21-000043:mdna:147]
|  | March 28,2021 |  | September 27,2020 |  | Change |  |  |
| Cash, cash equivalents and marketable securities | $ | 11,561 |  |  | $ | 11,249 |  |  | $ | 312 |  |  |  |
| Accounts receivable, net | 3,346 |  |  | 4,003 |  |  | (657) |  |  |  |
| Inventories | 2,668 |  |  | 2,598 |  |  | 70 |  |  |  |
| Short-term debt | 500 |  |  | 500 |  |  | — |  |  |  |
| Long-term debt | 15,235 |  |  | 15,226 |  |  | 9 |  |  |  |
| Noncurrent income taxes payable | 1,715 |  |  | 1,872 |  |  | (157) |  |  |  |

[0001728949-21-000043:mdna:148]
|  | Six Months Ended |
|  | March 28,2021 |  | March 29,2020 |  | Change |  |  |
| Net cash provided by operating activities | $ | 6,086 |  |  | $ | 2,201 |  |  | $ | 3,885 |  |  |  |
| Net cash used by investing activities | (3,034) |  |  | (1,769) |  |  | (1,265) |  |  |  |
| Net cash used by financing activities | (3,788) |  |  | (3,868) |  |  | 80 |  |  |  |

[0001728949-21-000043:mdna:149]
The net increase in cash, cash equivalents and marketable securities was primarily due to net cash provided by operating activities, $174 million in proceeds from the issuance of common stock (primarily under our Employee Stock Purchase Plan), and $167 million in proceeds from other investments, partially offset by $2.0 billion in payments to repurchase shares of our common stock, $1.5 billion in cash dividends paid, $1.2 billion in cash paid for acquisitions and other investments (primarily related to the acquisition of NUVIA), $952 million in capital expenditures and $501 million in payments of tax withholdings related to the vesting of share-based awards.

[0001728949-21-000043:mdna:150]
The decrease in accounts receivable was primarily due to the payment of the second installment of $500 million (excluding the impact of foreign withholding taxes) under the previously disclosed settlement agreement with Huawei. Huawei paid the third installment of $300 million (excluding the impact of foreign withholding taxes) subsequent to March 28, 2021 in accordance with the agreed upon payment schedule. The decrease in accounts receivable was also attributable to the timing of settlement of certain QCT incentives, partially offset by an increase in QCT revenues during the quarter.

[0001728949-21-000043:mdna:151]
Debt. At March 28, 2021, we had $15.5 billion of principal floating- and fixed-rate notes outstanding. Our remaining debt has maturity dates in 2022 through 2050.

[0001728949-21-000043:mdna:152]
We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At March 28, 2021, we had $500 million of commercial paper outstanding.

[0001728949-21-000043:mdna:153]
On December 8, 2020, we entered into a Revolving Credit Facility replacing our prior Amended and Restated Revolving Credit Facility. There were no outstanding borrowings under the Amended and Restated Revolving Credit Facility at the time of termination. The Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At March 28, 2021, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-21-000043:mdna:154]
We expect to issue new debt in the future. The amount and timing of any such new debt will depend on a number of factors, including but not limited to maturities of our existing debt, acquisitions and strategic investments, favorable and/or acceptable interest rates and changes in corporate income tax law. Additional information regarding our outstanding debt is provided in “Notes to Consolidated Financial Statements, Note 6. Debt” in our 2020 Annual Report on Form 10-K.

[0001728949-21-000043:mdna:155]
Income Taxes. At March 28, 2021, we estimated remaining future payments of $1.9 billion for the one-time U.S. repatriation tax accrued in fiscal 2018, after application of certain tax credits, which is payable in installments over the next five years. At March 28, 2021, other current liabilities included $213 million for the next installment due in January 2022. Additional information regarding our income taxes is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes.”

[0001728949-21-000043:mdna:156]
Capital Return Program. In fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. The stock repurchase program has no expiration date. In the first six months of fiscal 2021, we repurchased and retired 14 million shares of our common stock for $2.0 billion, before commissions. At March 28, 2021, $2.6 billion remained authorized for repurchase under the stock repurchase program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-21-000043:mdna:157]
On March 10, 2021, we announced a 5% increase in our quarterly dividend per share of common stock from $0.65 to $0.68, which is effective for dividends payable after March 25, 2021. In the first six months of fiscal 2021, we paid cash dividends totaling $1.5 billion, or $1.30 per share. On April 14, 2021, we announced a cash dividend of $0.68 per share on our common stock, payable on June 24, 2021 to stockholders of record as of the close of business on June 3, 2021. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-21-000043:mdna:158]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2020 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” We expect an increase in operating cash outflows to secure long-term capacity commitments with certain suppliers of our integrated circuit products. At March 28, 2021, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements or contractual obligations described in our 2020 Annual Report on Form 10-K.

[0001728949-21-000043:mdna:159]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0001728949-21-000043:mdna:160]
We believe, based on our current business plan and the facts and factors known by us, our cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months and thereafter for the foreseeable future. See “Risk Factors” in this Quarterly Report.

[0001728949-21-000043:mdna:161]
[same as prior period, unchanged from 0001728949-21-000022:mdna:110]

[0001728949-21-000043:mdna:162]
[same as prior period, unchanged from 0001728949-21-000022:mdna:111]

[0001728949-21-000043:mdna:163]
[same as prior period, unchanged from 0001728949-21-000022:mdna:112]

[0001728949-21-000043:mdna:164]
You should consider each of the following factors in evaluating our business and our prospects. However, the risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also negatively impact our business, results of operations, cash flows and financial condition, and require significant management time and attention. In that case, the trading price of our common stock could decline. In addition to the risks and uncertainties set forth in the Risk Factor below titled “The coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and may continue to impact us in the future,” many of the risks and uncertainties set forth in the other Risk Factors below could be exacerbated by the COVID-19 pandemic, government and business responses thereto and any further resulting decline in the global business and economic environment, and may be impacted by the extent and speed of the global economic recovery. You should also consider the other information set forth in this Quarterly Report in evaluating our business and our prospects, including but not limited to our financial statements and the related notes, and “Part I, Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” References to “and,” “or” and “and/or” should be read to include the others, as appropriate.

[0001728949-21-000043:mdna:165]
[same as prior period, unchanged from 0001728949-21-000022:mdna:114]

[0001728949-21-000043:mdna:166]
[same as prior period, unchanged from 0001728949-21-000022:mdna:115]

[0001728949-21-000043:mdna:167]
The rapid, global spread of COVID-19 and the fear it has created has resulted in significant economic uncertainty, significant declines in business and consumer confidence and global demand in the wireless industry (among others) and a global economic slowdown, which resulted in a global recession. Specifically, the decline in demand for smartphones and other consumer devices sold by our customers or licensees has resulted in decreased demand for our integrated circuit products (which are incorporated into such devices) and a decrease in the royalties we earn on the licensing of our intellectual property (which is dependent upon the number of such devices sold that utilize our intellectual property). However, we currently do not expect a significant impact on our results of operations in the future.

[0001728949-21-000043:mdna:168]
Further, while to date we have not seen a significant impact on our manufacturing facilities or our supply chain due to the COVID-19 pandemic, the ability of our suppliers to deliver on their commitments to us, or our ability to ship our products to our customers, may be negatively impacted by the pandemic and/or government responses thereto, such as travel bans and restrictions, quarantines, shelter-in-place and social distancing orders, declarations of states of emergency and shutdowns.

[0001728949-21-000043:mdna:169]
Although the spread of COVID-19 has caused us to modify our workforce practices, such as having the vast majority of our employees working from home, we have not experienced a significant negative impact to our business or results of operations. However, we could be negatively affected in the future if, among others, a significant number of our employees, or employees who perform critical functions, become ill and/or are quarantined as the result of exposure to COVID-19, or if government policies restrict the ability of those employees to perform their critical functions. For example, we have offices and a significant number of employees located in India, which is currently experiencing a high rate of COVID-19 infections.

[0001728949-21-000043:mdna:170]
The COVID-19 pandemic could also impact our business, results of operations and financial condition through delayed, reduced or cancelled customer orders; the inability of our customers or licensees to purchase or pay for our products or technologies; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our customers or licensees; or failures by other counterparties. Additionally, federal, state or foreign governments may in the future increase corporate tax rates, increase employer payroll tax obligations and/or otherwise change tax laws to pay for stimulus and other actions that may be taken as a result of COVID-19.

[0001728949-21-000043:mdna:171]
The degree to which the COVID-19 pandemic impacts our future business, results of operations and financial condition will depend on future developments, which are uncertain, including but not limited to the duration, spread and severity of the pandemic, the availability, adoption and efficacy of vaccines, government responses and other actions to mitigate the spread of and to treat COVID-19, and when and to what extent normal business, economic and social activity and conditions resume. We are similarly unable to predict the extent to which the pandemic impacts our customers, licensees, suppliers and other partners and their financial conditions, but adverse effects on these parties could also adversely affect us. Finally, the COVID-19 pandemic makes it challenging for management to estimate the future performance of our business.

[0001728949-21-000043:mdna:172]
[same as prior period, unchanged from 0001728949-21-000022:mdna:123]

[0001728949-21-000043:mdna:173]
[same as prior period, unchanged from 0001728949-21-000022:mdna:124]

[0001728949-21-000043:mdna:174]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on our customers and licensees to develop devices and services based on these technologies with value-added features to drive consumer demand for new 3G/4G and 3G/4G/5G multimode devices, as well as 3G and 4G single-mode devices, and to establish the selling prices for such devices. Further, the timing of our shipments of our products is dependent on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries and applications beyond mobile, such as automotive and IoT, among others.

[0001728949-21-000043:mdna:175]
[same as prior period, unchanged from 0001728949-21-000022:mdna:126]

[0001728949-21-000043:mdna:176]
[same as prior period, unchanged from 0001728949-21-000022:mdna:127]

[0001728949-21-000043:mdna:177]
33

[0001728949-21-000043:mdna:178]
[same as prior period, unchanged from 0001728949-21-000022:mdna:128]

[0001728949-21-000043:mdna:179]
[same as prior period, unchanged from 0001728949-21-000022:mdna:129]

[0001728949-21-000043:mdna:180]
Our products and technologies face significant competition. Competition may intensify as our current competitors expand their product offerings, improve their products or reduce the prices of their products as part of a strategy to maintain existing business and customers or attract new business and customers, as new opportunities develop, and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: OEM concentrations; vertical integration; competition in certain geographic regions; government intervention or support of national industries or competitors; the ability to maintain product differentiation as the result of evolving industry standards and speed of technological change (including the transition to smaller geometry process technologies and the demand for always on, always connected capabilities); access to capacity in the supply chain; and value-added features that drive selling prices and consumer demand for new 3G/4G and 3G/4G/5G multimode devices, as well as 3G and 4G single-mode devices.

[0001728949-21-000043:mdna:181]
We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, and technological and public policy changes. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape. For example, if any key supplier of technologies and intellectual property to the semiconductor industry was sold to one of our competitors, it could negatively affect our ability to procure or license such technologies and intellectual property in the future, at all or upon acceptable terms, which could have wide-ranging impacts on our business and operations.

[0001728949-21-000043:mdna:182]
[same as prior period, unchanged from 0001728949-21-000022:mdna:132]

[0001728949-21-000043:mdna:183]
•differentiate our integrated circuit products with innovative technologies across multiple products and features (e.g., modem, radio frequency front-end (RFFE), including millimeter wave (mmWave), graphics and other processors, camera and connectivity) and with smaller geometry process technologies that drive both performance and lower power consumption;

[0001728949-21-000043:mdna:184]
[same as prior period, unchanged from 0001728949-21-000022:mdna:134]

[0001728949-21-000043:mdna:185]
[same as prior period, unchanged from 0001728949-21-000022:mdna:135]

[0001728949-21-000043:mdna:186]
•increase or accelerate adoption of our technologies and products in industry segments and applications outside of mobile, including automotive and IoT;

[0001728949-21-000043:mdna:187]
[same as prior period, unchanged from 0001728949-21-000022:mdna:137]

[0001728949-21-000043:mdna:188]
[same as prior period, unchanged from 0001728949-21-000022:mdna:138]

[0001728949-21-000043:mdna:189]
•maintain access to sufficient capacity in the supply chain relative to our competitors to meet customer demand;

[0001728949-21-000043:mdna:190]
•create standalone value and contribute to the success of our existing businesses through acquisitions, joint ventures and other transactions, and by developing customer, licensee, vendor, distributor and other channel relationships in new industry segments and applications and with disruptive technologies and products;

[0001728949-21-000043:mdna:191]
[same as prior period, unchanged from 0001728949-21-000022:mdna:140]

[0001728949-21-000043:mdna:192]
[same as prior period, unchanged from 0001728949-21-000022:mdna:141]

[0001728949-21-000043:mdna:193]
[same as prior period, unchanged from 0001728949-21-000022:mdna:142]

[0001728949-21-000043:mdna:194]
[same as prior period, unchanged from 0001728949-21-000022:mdna:143]

[0001728949-21-000043:mdna:195]
We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application, industry segment or standard product, including those that produce products for mobile, automotive and IoT, among others. Most of these competitors compete with us with respect to some, but not all, of our businesses or product lines. Companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom, HiSilicon, MediaTek, Nvidia, NXP Semiconductors, Qorvo, Samsung, Skyworks, Texas Instruments and UNISOC (formally known as Spreadtrum Communications). Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to use our competitors’ integrated circuit products, to utilize their own internally-developed integrated circuit products, or sell such products to others, or to utilize alternative technologies; lower cost structures or a willingness and ability to accept lower prices or lower margins for their products, particularly in China; foreign government support of other technologies, competitors or OEMs that sell devices that do not contain our integrated circuit products; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and OEMs in certain geographic regions (such as China); more experience in adjacent industry segments and applications beyond mobile (such as automotive and IoT); and a more established presence in certain regions.

[0001728949-21-000043:mdna:196]
[same as prior period, unchanged from 0001728949-21-000022:mdna:145]

[0001728949-21-000043:mdna:197]
Competition in any or all product tiers may result in the loss of business or customers, which would negatively impact our business, revenues, results of operations, cash flows and financial condition. Such competition may also reduce average selling prices for our chipset products or the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging regions and China where competitors may have lower cost structures or may have a willingness and ability to accept lower prices or lower margins on their products. Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average

[0001728949-21-000043:mdna:198]
selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0001728949-21-000043:mdna:199]
[same as prior period, unchanged from 0001728949-21-000022:mdna:147]

[0001728949-21-000043:mdna:200]
[same as prior period, unchanged from 0001728949-21-000022:mdna:148]

[0001728949-21-000043:mdna:201]
We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. Chinese OEMs continue to grow their device share in China and are increasing their device share in regions outside of China, and we derive a significant portion of our revenues from a small number of these OEMs as well. See also “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Concentrations.”

[0001728949-21-000043:mdna:202]
[same as prior period, unchanged from 0001728949-21-000022:mdna:151]

[0001728949-21-000043:mdna:203]
Further, political actions, including trade and/or national security protection policies, or other actions by governments, particularly the U.S. and Chinese governments, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our customers, limit, prevent or discourage those customers from transacting business with us, or make it more expensive to do so, any of which could also significantly reduce the revenues we derive from these customers. See also the Risk Factor titled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0001728949-21-000043:mdna:204]
[same as prior period, unchanged from 0001728949-21-000022:mdna:153]

[0001728949-21-000043:mdna:205]
[same as prior period, unchanged from 0001728949-21-000022:mdna:154]

[0001728949-21-000043:mdna:206]
[same as prior period, unchanged from 0001728949-21-000022:mdna:155]

[0001728949-21-000043:mdna:207]
[same as prior period, unchanged from 0001728949-21-000022:mdna:156]

[0001728949-21-000043:mdna:208]
[same as prior period, unchanged from 0001728949-21-000022:mdna:157]

[0001728949-21-000043:mdna:209]
36

[0001728949-21-000043:mdna:210]
[same as prior period, unchanged from 0001728949-21-000022:mdna:158]

[0001728949-21-000043:mdna:211]
Although we have more than 300 licensees, we derive a significant portion of our licensing revenues from a limited number of licensees, which includes a number of Chinese OEMs. In the event that one or more of our significant licensees fail to meet their reporting and payment obligations, or we are unable to renew or modify one or more of their license agreements under similar terms as their existing agreements, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We do not have control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in sales of our licensees’ products, or reductions in the average selling prices of wireless devices sold by our licensees without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues. Such adverse impact may be mitigated by our per unit royalty caps that apply to certain categories of our licensees’ complete wireless devices, namely smartphones, tablets, laptops and smartwatches.

[0001728949-21-000043:mdna:212]
[same as prior period, unchanged from 0001728949-21-000022:mdna:162]

[0001728949-21-000043:mdna:213]
[same as prior period, unchanged from 0001728949-21-000022:mdna:163]

[0001728949-21-000043:mdna:214]
[same as prior period, unchanged from 0001728949-21-000022:mdna:164]

[0001728949-21-000043:mdna:215]
[same as prior period, unchanged from 0001728949-21-000022:mdna:165]

[0001728949-21-000043:mdna:216]
[same as prior period, unchanged from 0001728949-21-000022:mdna:166]

[0001728949-21-000043:mdna:217]
[same as prior period, unchanged from 0001728949-21-000022:mdna:167]

[0001728949-21-000043:mdna:218]
[same as prior period, unchanged from 0001728949-21-000022:mdna:168]

[0001728949-21-000043:mdna:219]
[same as prior period, unchanged from 0001728949-21-000022:mdna:169]

[0001728949-21-000043:mdna:220]
Political actions, including trade protection and national security policies of the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our Chinese customers or suppliers, limit, prevent or discourage certain of our Chinese customers or suppliers from transacting business with us, or make it more expensive to do so. Given our revenue concentration in China, if, due to actual, threatened or potential U.S. or Chinese government actions or policies, we were further limited in, or prohibited from, selling our integrated circuit products to Chinese OEMs; if our non-Chinese OEM customers were limited in, or prohibited from, selling devices into China that incorporate our integrated circuit products; if Chinese OEMs develop and use their own integrated circuit products or use our competitors’ integrated circuit products in some (or all) of their devices rather than our integrated circuit products; if Chinese tariffs on our integrated circuit products or on devices which incorporate our integrated circuit products made purchasing such products or devices more expensive to Chinese OEMs or Chinese consumers; or if our Chinese licensees delay or cease making payments of license fees they owe us, our business, revenues, results of operations, cash flows and financial position could be materially harmed. Similarly, if, due to U.S. or Chinese government actions or policies, we were limited in or prohibited from obtaining critical integrated circuit products from our suppliers in China, our business, revenues, results of operations, cash flows and financial position could be materially harmed.

[0001728949-21-000043:mdna:221]
[same as prior period, unchanged from 0001728949-21-000022:mdna:172]

[0001728949-21-000043:mdna:222]
[same as prior period, unchanged from 0001728949-21-000022:mdna:173]

[0001728949-21-000043:mdna:223]
[same as prior period, unchanged from 0001728949-21-000022:mdna:174]

[0001728949-21-000043:mdna:224]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, alleging that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) attempts by licensees to shift their royalty obligation to their suppliers in order to lower the wholesale (i.e., licensee’s) selling price on which the royalty is calculated.

[0001728949-21-000043:mdna:225]
[same as prior period, unchanged from 0001728949-21-000022:mdna:176]

[0001728949-21-000043:mdna:226]
We have been in the past and are currently subject to various litigation and governmental investigations and proceedings. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. See also the Risk Factors below titled “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those

[0001728949-21-000043:mdna:227]
practices, or otherwise, could adversely impact our business and results of operations” and “Our business may suffer as a result of adverse rulings in government investigations or proceedings.”

[0001728949-21-000043:mdna:228]
In addition, in connection with our participation in SDOs, we, like other patent owners, generally have made contractual commitments to such organizations to license those of our patents that would necessarily be infringed by standard-compliant products as set forth in those commitments (referred to as standard-essential patents). Some manufacturers and users of standard-compliant products advance interpretations of these commitments that are adverse to our licensing business, including interpretations that would limit the amount of royalties that we could collect on the licensing of our standard-essential patent portfolio.

[0001728949-21-000043:mdna:229]
Further, some third parties have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions should not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by severely limiting the base upon which the royalty rate may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies.

[0001728949-21-000043:mdna:230]
Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party. Further, SDOs in certain countries may attempt to modify widely accepted standards and claim the resulting standard as their own.

[0001728949-21-000043:mdna:231]
[same as prior period, unchanged from 0001728949-21-000022:mdna:182]

[0001728949-21-000043:mdna:232]
Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations.

[0001728949-21-000043:mdna:233]
As described in the Risk Factor below titled “Our business may suffer as a result of adverse rulings in government investigations or proceedings,” we have been in the past and are currently subject to various governmental investigations and proceedings, as well as private legal proceedings, challenging our patent licensing and chipset sales practices. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We believe that one intent of certain of these investigations and legal proceedings has been to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-21-000043:mdna:234]
[same as prior period, unchanged from 0001728949-21-000022:mdna:185]

[0001728949-21-000043:mdna:235]
If we were required to grant patent licenses to chipset manufacturers (which could lead to implementing a more complex, multi-level licensing structure in which we license certain portions of our patent portfolio to chipset manufacturers and other portions to OEMs), we would incur additional transaction costs, which may be significant, and we could incur delays in recognizing revenues until license negotiations were completed. In addition, our licensing revenues and earnings would be

[0001728949-21-000043:mdna:236]
negatively impacted if we were not able to obtain, in the aggregate, equivalent revenues under such a multi-level licensing structure.

[0001728949-21-000043:mdna:237]
[same as prior period, unchanged from 0001728949-21-000022:mdna:187]

[0001728949-21-000043:mdna:238]
To the extent that we were required to implement any of these new licensing and/or business practices, including by modifying or renegotiating our existing license agreements or pursuing other commercial arrangements, we would incur additional transaction costs, which may be significant, we could incur delays in recognizing revenues until license negotiations were completed, and our business, revenues, results of operations, cash flows and financial condition could be harmed. The impact of any such changes to our licensing practices could vary widely and by jurisdiction, depending on the specific outcomes and the geographic scope of such outcomes. In addition, if we were required to make modifications to our licensing practices in one jurisdiction, licensees or governmental agencies in other jurisdictions may attempt to obtain similar outcomes for themselves or for such other jurisdictions, as applicable.

[0001728949-21-000043:mdna:239]
[same as prior period, unchanged from 0001728949-21-000022:mdna:190]

[0001728949-21-000043:mdna:240]
[same as prior period, unchanged from 0001728949-21-000022:mdna:191]

[0001728949-21-000043:mdna:241]
Further, the licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, our patent license agreements in effect that constitute a significant portion of our licensing revenues are effective for a specified term. In order to license or to obtain a license to such later patents, or after the expiration of the specified term, and to receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms and may impact the financial or other terms of license agreements not subject to the litigation or arbitration. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such licensees.

[0001728949-21-000043:mdna:242]
[same as prior period, unchanged from 0001728949-21-000022:mdna:193]

[0001728949-21-000043:mdna:243]
[same as prior period, unchanged from 0001728949-21-000022:mdna:194]

[0001728949-21-000043:mdna:244]
We have been in the past and are currently subject to various governmental investigations and proceedings. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Key allegations or findings in those matters include, among others, that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers; that our royalty rates are too high; that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions); that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets; that we have entered into exclusive agreements with chipset customers that foreclose competition; that we leverage our position in baseband chipsets in the RFFE space; and that we violate antitrust laws, and engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-21-000043:mdna:245]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others: the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease

[0001728949-21-000043:mdna:246]
certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any licensing or royalty revenues under such agreements. The renegotiation of license agreements could result in terms which are less favorable to us than existing terms, or lead to arbitration or litigation to resolve the licensing terms, which could also be less favorable to us than existing terms, and each of which could take months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. The occurrence of any of the above could have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies such as 5G. Further, depending on the breadth and severity of the circumstances above, we may have to reduce, suspend or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region.

[0001728949-21-000043:mdna:247]
[same as prior period, unchanged from 0001728949-21-000022:mdna:198]

[0001728949-21-000043:mdna:248]
[same as prior period, unchanged from 0001728949-21-000022:mdna:199]

[0001728949-21-000043:mdna:249]
[same as prior period, unchanged from 0001728949-21-000022:mdna:200]

[0001728949-21-000043:mdna:250]
We primarily utilize a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Other than the facilities we own that manufacture certain of our RFFE modules and RF (radio frequency) filter products, we rely on third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. There are a limited number of such third-party suppliers, and even fewer who are capable of manufacturing at the leading process technology nodes. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Under the turnkey model, our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services such as wafer bump, probe, assembly and the majority of our final test requirements. The semiconductor manufacturing foundries that supply our products are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders.

[0001728949-21-000043:mdna:251]
[same as prior period, unchanged from 0001728949-21-000022:mdna:202]

[0001728949-21-000043:mdna:252]
[same as prior period, unchanged from 0001728949-21-000022:mdna:203]

[0001728949-21-000043:mdna:253]
[same as prior period, unchanged from 0001728949-21-000022:mdna:204]

[0001728949-21-000043:mdna:254]
[same as prior period, unchanged from 0001728949-21-000022:mdna:205]

[0001728949-21-000043:mdna:255]
[same as prior period, unchanged from 0001728949-21-000022:mdna:206]

[0001728949-21-000043:mdna:256]
[same as prior period, unchanged from 0001728949-21-000022:mdna:207]

[0001728949-21-000043:mdna:257]
[same as prior period, unchanged from 0001728949-21-000022:mdna:208]

[0001728949-21-000043:mdna:258]
[same as prior period, unchanged from 0001728949-21-000022:mdna:209]

[0001728949-21-000043:mdna:259]
[same as prior period, unchanged from 0001728949-21-000022:mdna:210]

[0001728949-21-000043:mdna:260]
•natural disasters, the effects of climate change or geopolitical conflicts impacting our suppliers;

[0001728949-21-000043:mdna:261]
[same as prior period, unchanged from 0001728949-21-000022:mdna:212]

[0001728949-21-000043:mdna:262]
•trade or national security protection policies, particularly U.S. or Chinese government policies, that limit or prevent us from transacting business with suppliers of critical integrated circuit products, or that limit or prevent such suppliers from transacting business with us or from procuring materials, machinery or technology necessary to manufacture goods for us.

[0001728949-21-000043:mdna:263]
While we have established alternate suppliers for certain technologies, there are a limited number of such suppliers, and even fewer who are capable of operating at the leading process technology nodes or who are willing to operate at older process technology nodes. We rely on sole- or limited-source suppliers for certain products, which may exacerbate the risks identified above, and subject us to other significant risks, including: poor product performance and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established or in the future establish alternate suppliers, these suppliers may require significant amounts of time and levels of support to bring such technologies to production, both of which may increase for complex or leading process technologies. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, the elimination or limitation of a foundry supplier’s ability to manufacture components or products for us due to trade or national security protection policies could increase our vulnerability to sole- or limited-source arrangements and limit or prevent us from procuring critical components or products from those suppliers. Future consolidation of foundry suppliers could also increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions, increase our manufacturing costs and limit the amount of capacity available to us. Our arrangements with our suppliers may obligate us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies (which adds risk to manufacturing yields and reliability), and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Any of the above could negatively impact our business, results of operations and cash flows.

[0001728949-21-000043:mdna:264]
[same as prior period, unchanged from 0001728949-21-000022:mdna:217]

[0001728949-21-000043:mdna:265]
Our suppliers or potential alternate suppliers may manufacture integrated circuits, for themselves or for other companies, that compete with our products. Such suppliers have in the past and could again elect to allocate raw materials and manufacturing capacity to their own products or products of our competitors and reduce or limit the production of our products.

[0001728949-21-000043:mdna:266]
In addition, we may not receive reasonable pricing, manufacturing or delivery terms from our suppliers, and our ability to obtain favorable terms may be diminished during times of high demand and/or limited manufacturing capacity for integrated circuit products. We cannot guarantee that the actions of our suppliers will not cause disruptions in our operations that could harm our ability to meet our delivery obligations to our customers or increase our cost of sales. To the extent we are unable to obtain adequate supply, we may be obligated to make payment to our customers for such shortfalls.

[0001728949-21-000043:mdna:267]
Additionally, we place orders with our suppliers using our and our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates. As we move to smaller geometry process technologies, the

[0001728949-21-000043:mdna:268]
42

[0001728949-21-000043:mdna:269]
manufacturing lead-time increases. As a result, the orders we place with our suppliers are generally only partially covered by commitments from our customers. If we, or our customers, overestimate demand, or if demand is impacted by factors outside of our or our customers’ control, such as the COVID-19 pandemic, that is not under a binding commitment from our customers, we may experience increased excess or obsolete inventory, which would negatively impact our results of operations.

[0001728949-21-000043:mdna:270]
Conversely, if we or our customers underestimate demand, or if demand increases significantly and/or rapidly, we have in the past been, currently are and may in the future be unable to obtain, on a timely basis or at all, the additional manufacturing and test capacity necessary to meet such demand, which could result in lost sales opportunities, reduced revenue growth and harm to our customer relationships. Currently, the global semiconductor industry is experiencing demand for integrated circuits that exceeds the industry’s capacity to meet that demand.

[0001728949-21-000043:mdna:271]
See also the Risk Factor below titled “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model, environmental compliance and liability, impacts related to climate change, exposure to natural disasters, timely supply of equipment and materials, and various manufacturing issues” for additional risks that may also be applicable to our third-party suppliers’ manufacturing facilities, which could result in disruptions to our business or additional costs to us, and negatively impact our results of operations.

[0001728949-21-000043:mdna:272]
[same as prior period, unchanged from 0001728949-21-000022:mdna:221]

[0001728949-21-000043:mdna:273]
We own and operate various facilities that manufacture certain of our RFFE modules and RF filter products. Manufacturing facilities are characterized by a higher portion of fixed costs relative to a fabless model. We may be faced with a decline in the utilization rates of our manufacturing facilities due to decreases in demand for our products, including in less favorable industry environments, or due to our failure to win and/or retain designs with OEMs. During such periods, our manufacturing facilities could operate at lower capacity levels, while the fixed costs associated with such facilities would continue to be incurred, resulting in lower gross profit.

[0001728949-21-000043:mdna:274]
[same as prior period, unchanged from 0001728949-21-000022:mdna:224]

[0001728949-21-000043:mdna:275]
Climate change concerns and the potential resulting environmental impact may result in new environmental, health and safety laws and regulations that may affect us, our suppliers and our customers. Such laws or regulations could cause us to incur additional direct costs for compliance, including costs associated with changes to manufacturing processes or the procurement of raw materials used in manufacturing processes, as well as increased indirect costs resulting from our customers, suppliers or both incurring additional compliance costs that are passed on to us. These costs may adversely impact our results of operations and financial condition. In addition, climate change could cause certain natural disasters, such as drought, wildfires, storms, flooding or rising sea levels, to occur more frequently or with greater intensity, which could pose physical risks to our manufacturing facilities or our suppliers’ facilities; could disrupt the availability of water necessary for the operation of our manufacturing facilities or our suppliers’ facilities; and could increase or decrease temperatures resulting in increased operating costs and/or business disruption.

[0001728949-21-000043:mdna:276]
We have manufacturing facilities in Asia and Europe. If tsunamis, flooding, earthquakes, volcanic eruptions, drought or other natural disasters, effects of climate change or geopolitical conflicts, were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, delay production and shipments of inventory and result in costly repairs, replacements or other costs. In addition, natural disasters, effects of climate change or geopolitical conflicts may result in disruptions in transportation, distribution channels and supply chains, and significant increases in the prices of raw materials. Further, health crises, including epidemics or pandemics, such as the COVID-19 pandemic, and government and business responses thereto, could affect our manufacturing facilities, including by resulting in quarantines and/or closures, which would result in disruptions to and potential closures of our manufacturing operations.

[0001728949-21-000043:mdna:277]
[same as prior period, unchanged from 0001728949-21-000022:mdna:227]

[0001728949-21-000043:mdna:278]
Our manufacturing processes are highly complex, require advanced and costly equipment and must be continuously modified to improve yields and performance. Difficulties in the production process can reduce yields or interrupt production, and as a result, we may not be able to deliver our products or do so in a timely, cost-effective or competitive manner. Further, to remain competitive and meet customer demand, we may be required to improve our facilities and process technologies and carry out extensive research and development, each of which may require investment of significant amounts of capital and may have a material adverse effect on our results of operations, cash flows and financial condition.

[0001728949-21-000043:mdna:279]
[same as prior period, unchanged from 0001728949-21-000022:mdna:231]

[0001728949-21-000043:mdna:280]
[same as prior period, unchanged from 0001728949-21-000022:mdna:232]

[0001728949-21-000043:mdna:281]
Our growth depends in part on our ability to extend our technologies and products into new and expanded product areas, and adjacent industry segments and applications beyond mobile. Our research, development and other investments in these new and expanded product areas, industry segments and applications, and related technologies and products, as well as in our existing technologies and products, and new technologies, may not generate operating income or contribute to future results of operations that meet our expectations.

[0001728949-21-000043:mdna:282]
While we continue to invest significant resources toward advancements primarily in support of 4G- and 5G-based technologies, we also invest in new and expanded product areas, and adjacent industry segments and applications, by utilizing our existing technical and business expertise and through acquisitions.

[0001728949-21-000043:mdna:283]
In particular, our future growth depends in part on new and expanded product areas, such as RFFE, and adjacent industry segments and applications beyond mobile, such as automotive and IoT; our ability to develop leading and cost-effective technologies and products for new and expanded product areas, adjacent industry segments and applications; and third parties incorporating our technologies and products into devices used in these product areas, industry segments and applications. Accordingly, we intend to continue to make substantial investments in these new and expanded product areas and adjacent industry segments and applications, and in developing new products and technologies for these product areas, industry

[0001728949-21-000043:mdna:284]
segments and applications. Our growth also depends significantly on our ability to develop and patent 5G technologies, and to develop and commercialize products using 5G technologies.

[0001728949-21-000043:mdna:285]
However, our research, development and other investments in these new and expanded product areas and adjacent industry segments and applications, and corresponding technologies and products, as well as in our existing, technologies and products and new technologies, such as 5G, use of licensed, shared and unlicensed spectrum and convergence of cellular and Wi-Fi, may not succeed because, among other reasons: we may not be issued patents on the technologies we develop; the technologies we develop may not be incorporated into relevant standards; new and expanded product areas, adjacent industry segments and applications, and consumer demand therein, may not develop or grow as anticipated; our strategies or the strategies of our customers, licensees or partners may not be successful; alternate technologies may be better or may reduce the advantages we anticipate from our investments; competitors’ technologies or products may be more cost effective, have more capabilities or fewer limitations or be brought to market faster than our new technologies or products; we may not be able to develop, or our competitors may have more established and/or stronger, customer, vendor, distributor or other channel relationships; and competitors may have longer operating histories in industry segments and applications that are new to us. We may also underestimate the costs of or overestimate the future revenues or margins that could result from these investments, and these investments may not, or may take many years to, generate material returns.

[0001728949-21-000043:mdna:286]
[same as prior period, unchanged from 0001728949-21-000022:mdna:237]

[0001728949-21-000043:mdna:287]
[same as prior period, unchanged from 0001728949-21-000022:mdna:238]

[0001728949-21-000043:mdna:288]
[same as prior period, unchanged from 0001728949-21-000022:mdna:239]

[0001728949-21-000043:mdna:289]
We engage in strategic acquisitions and other transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. From time to time, we acquire businesses and other assets, including patents, technology and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies, including those that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our products and technologies and supporting the design and introduction of new products (or enhancing existing products) for mobile, and for new industry segments and applications beyond mobile. Many of our strategic activities entail a high degree of risk and require the use of significant amounts of capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies or products. We may underestimate the costs or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we have in the past and may record impairment charges in the future related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our results of operations and financial condition, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001728949-21-000043:mdna:290]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models, geographic regions, industry segments and applications served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0001728949-21-000043:mdna:291]
[same as prior period, unchanged from 0001728949-21-000022:mdna:262]

[0001728949-21-000043:mdna:292]
[same as prior period, unchanged from 0001728949-21-000022:mdna:243]

[0001728949-21-000043:mdna:293]
[same as prior period, unchanged from 0001728949-21-000022:mdna:244]

[0001728949-21-000043:mdna:294]
[same as prior period, unchanged from 0001728949-21-000022:mdna:245]

[0001728949-21-000043:mdna:295]
[same as prior period, unchanged from 0001728949-21-000022:mdna:246]

[0001728949-21-000043:mdna:296]
Third parties regularly attempt to gain unauthorized access to our information technology systems, and many such attempts are increasingly more sophisticated. The perception that the COVID-19 pandemic has made companies’ information technology systems more vulnerable has increased the already significant volume of such attempts. These attempts, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, and impersonating authorized users, among others. We may also be subject to ransom-style cyber-attacks, which could impact our information technology systems and cause widespread disruption to our business, including our manufacturing operations, and expose our confidential or propriety information. In addition, third parties that we may rely on to store and/or process our confidential information may also be subject to similar threats. Such threats could result in the misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our information technology systems. We believe that we have a robust cybersecurity program that is aligned to international cybersecurity frameworks, and that we leverage industry best practices across people, processes and technologies in an attempt to mitigate cybersecurity threats. However, we may not be able to anticipate, detect, repel or implement effective preventative measures against all cybersecurity threats, particularly because the techniques used are increasingly sophisticated and constantly evolving. Attempts to gain unauthorized access to our information technology systems or other attacks have in the past, in certain instances and to certain degrees, been successful (but have not caused significant harm), and may in the future be successful, and in some cases, we might be unaware of an incident or its magnitude and effects.

[0001728949-21-000043:mdna:297]
[same as prior period, unchanged from 0001728949-21-000022:mdna:248]

[0001728949-21-000043:mdna:298]
[same as prior period, unchanged from 0001728949-21-000022:mdna:249]

[0001728949-21-000043:mdna:299]
Further, China has implemented, and other countries or regions may implement, cybersecurity laws that require our overall information technology security environment to meet certain standards and/or be certified. Such laws may be

[0001728949-21-000043:mdna:300]
complex, ambiguous and subject to interpretation, which may create uncertainty regarding compliance. As a result, our efforts to comply with such laws may be expensive and may fail, which could adversely affect our business, results of operations and cash flows.

[0001728949-21-000043:mdna:301]
[same as prior period, unchanged from 0001728949-21-000022:mdna:251]

[0001728949-21-000043:mdna:302]
[same as prior period, unchanged from 0001728949-21-000022:mdna:252]

[0001728949-21-000043:mdna:303]
[same as prior period, unchanged from 0001728949-21-000022:mdna:253]

[0001728949-21-000043:mdna:304]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-21-000043:mdna:305]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies or political actions of governments, including trade protection and national security policies; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business and the pricing and integration of additional features and functionality into our chipset products. See also the Risk Factors titled “Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business” and “Our business may suffer as a result of adverse rulings in government investigations or proceedings.”

[0001728949-21-000043:mdna:306]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0001728949-21-000043:mdna:307]
Additionally, although our license agreements generally provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our

[0001728949-21-000043:mdna:308]
47

[0001728949-21-000043:mdna:309]
rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements. Similarly, we provide access to certain of our intellectual property and proprietary and confidential business information to our direct and indirect customers and licensees, who have in the past and may in the future wrongfully use such intellectual property and information or wrongfully disclose such intellectual property and information to third parties, including our competitors. See also the Risk Factor titled “Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.”

[0001728949-21-000043:mdna:310]
[same as prior period, unchanged from 0001728949-21-000022:mdna:259]

[0001728949-21-000043:mdna:311]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property claims against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products were found to infringe another company’s intellectual property, we could be subject to an injunction or be required to redesign our products, or to license such intellectual property or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products, license such intellectual property used in our products or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling our products. Similarly, our suppliers could be found to infringe another company’s intellectual property, and such suppliers could then be enjoined from providing products or services to us.

[0001728949-21-000043:mdna:312]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products sold by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-21-000043:mdna:313]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing corresponding declines in our chipset or licensing revenues.

[0001728949-21-000043:mdna:314]
Certain legal matters, which may include certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0001728949-21-000043:mdna:315]
[same as prior period, unchanged from 0001728949-21-000022:mdna:266]

[0001728949-21-000043:mdna:316]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe that we will continue to see, customers request that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of our products’ source code and may expose our related intellectual property to adverse licensing conditions. Licensing of such software may impose certain

[0001728949-21-000043:mdna:317]
obligations on us if we were to distribute derivative works of that software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Furthermore, in the course of product development, we may make contributions to third-party open source projects that could subject our intellectual property to adverse licensing conditions. For example, to encourage the growth of a software ecosystem that is interoperable with our products, we may need to contribute certain implementations under the open source licensing terms that govern such projects, which may adversely impact our associated intellectual property. Developing open source products, while adequately protecting the intellectual property upon which our licensing program depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental and third-party scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ adequate controls to protect our intellectual property, our contributions to and use of open source software presents risks that could have an adverse effect on these and on our business.

[0001728949-21-000043:mdna:318]
[same as prior period, unchanged from 0001728949-21-000022:mdna:268]

[0001728949-21-000043:mdna:319]
[same as prior period, unchanged from 0001728949-21-000022:mdna:269]

[0001728949-21-000043:mdna:320]
Our future success depends upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. The market for employees in our industry is extremely competitive, and competitors for talent, particularly engineering talent, increasingly attempt to hire, and to varying degrees have been successful in hiring, our employees, including by establishing or expanding local offices near our headquarters in San Diego, California or by allowing employees to permanently work from home. A number of such competitors for talent are significantly larger than us and are able to offer compensation in excess of what we are able to offer. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001728949-21-000043:mdna:321]
[same as prior period, unchanged from 0001728949-21-000022:mdna:271]

[0001728949-21-000043:mdna:322]
[same as prior period, unchanged from 0001728949-21-000022:mdna:272]

[0001728949-21-000043:mdna:323]
Our products (including related software) and the technology we use (which may be developed by us or third parties, and may be designed to meet industry standards) are complex and may contain defects, errors or security vulnerabilities, or experience failures or unsatisfactory performance, due to any number of issues, including issues in materials, design, fabrication, packaging and/or use within a system. Further, because of the complexity of our products, defects, errors or security vulnerabilities might only be detected when the products are in use. Development of products in new domains of technology, such as the transition to 5G, and the migration to integrated circuit technologies with smaller geometric feature sizes, increases complexity and adds risk to manufacturing yields and reliability, and increases the likelihood of product defects, errors or security vulnerabilities. Risks associated with product or technology defects, errors or security vulnerabilities are exacerbated by the fact that our customers typically integrate our products into consumer and other devices.

[0001728949-21-000043:mdna:324]
The use of devices containing our products to interact with untrusted systems or otherwise access untrusted content creates a risk of exposing the system hardware and software in those devices to malicious attacks. Security vulnerabilities in our products or the technologies we use could expose our customers or end users to hackers or other unscrupulous third parties who develop and deploy viruses, worms and other malicious software programs that could attack our products or those of our customers. While we continue to focus on this issue and take measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and applications, and increasing the risk of security failures, and techniques used to perpetrate cybersecurity attacks are increasingly sophisticated and constantly evolving.

[0001728949-21-000043:mdna:325]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and to the end users of such devices. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing

[0001728949-21-000043:mdna:326]
solutions, recalling products, repairing or replacing defective products, writing down defective inventory, or indemnification obligations under our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, and losses on unfavorable purchase commitments. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products.

[0001728949-21-000043:mdna:327]
In addition, the occurrence of defects, errors or security vulnerabilities may give rise to product liability claims, particularly if such defects, errors or security vulnerabilities in our products or the technology we use, or the products into which they are integrated, result in personal injury or death, and could result in significant costs, expenses and losses. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the efforts of our technical and management personnel and harm our business, even if we are successful. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. Further, our business liability insurance may be inadequate, or future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as automobiles, including autonomous driver assistance programs; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and extended reality (XR) for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0001728949-21-000043:mdna:328]
Accordingly, defects, errors or security vulnerabilities in our products or the technologies we use could have an adverse impact on us, on our customers and the end users of our customers’ products. If any of these risks materialize, there could be a material adverse effect on our business, results of operations and financial condition.

[0001728949-21-000043:mdna:329]
[same as prior period, unchanged from 0001728949-21-000022:mdna:278]

[0001728949-21-000043:mdna:330]
[same as prior period, unchanged from 0001728949-21-000022:mdna:279]

[0001728949-21-000043:mdna:331]
The semiconductor industry is highly cyclical, volatile, subject to downturns and characterized by constant and rapid technological change, price erosion, evolving technical standards, frequent new product introductions, short product life cycles and fluctuations in product supply and demand. Periods of downturns have been characterized by diminished demand for end-user products, high inventory levels, excess or obsolete inventory adjustments, underutilization of manufacturing capacity, changes in revenue mix and erosion of average selling prices. We expect our business to continue to be subject to such cyclical downturns. Consequently, our revenues may decline, and our results of operations and financial condition may be adversely impacted.

[0001728949-21-000043:mdna:332]
[same as prior period, unchanged from 0001728949-21-000022:mdna:282]

[0001728949-21-000043:mdna:333]
Our stock price and financial results have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and our financial results include those identified above and throughout this Risk Factors section; volatility of the stock market in general and technology and semiconductor companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. In the past,

[0001728949-21-000043:mdna:334]
securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0001728949-21-000043:mdna:335]
[same as prior period, unchanged from 0001728949-21-000022:mdna:284]

[0001728949-21-000043:mdna:336]
Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). Compliance with, or changes in the interpretation of, existing Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, including, among others, Regulations affecting patent licensing practices; antitrust, competition and competitive business practices; the flow of funds out of certain countries (e.g., China); cybersecurity; import and export regulations such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; protection of intellectual property; trade and trade protection including tariffs; foreign policy and national security; environmental protection, health and safety; supply chain, responsible sourcing, including the use of conflict minerals, and human rights; spectrum availability and license issuance; adoption of standards; taxation; privacy and data protection; labor, employment and human capital; corporate governance; public disclosure; or business conduct, could have an adverse effect on our business and results of operations. See also the Risk Factors titled “Our business may suffer as a result of adverse rulings in government investigations or proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model, environmental compliance and liability, issues related to climate change, exposure to natural disasters, timely supply of equipment and materials, and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

[0001728949-21-000043:mdna:337]
[same as prior period, unchanged from 0001728949-21-000022:mdna:286]

[0001728949-21-000043:mdna:338]
[same as prior period, unchanged from 0001728949-21-000022:mdna:287]

[0001728949-21-000043:mdna:339]
Our outstanding debt and any additional debt we incur may have negative consequences on our business, including, among others: requiring us to use cash to pay the principal of and interest on our debt, thereby reducing the amount of cash available for other purposes; limiting our ability to obtain additional financing for working capital, capital expenditures, acquisitions, stock repurchases, dividends, general corporate or other purposes; and limiting our flexibility in planning for, or reacting to, changes in our business, industries or the market. Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to economic and political conditions, industry cycles and financial, business and other factors, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations to service our debt, we may be required to, among other things: refinance or restructure all or a portion of our debt; reduce or delay planned capital or operating expenditures; reduce, suspend or eliminate our dividend payments and/or our stock repurchase program; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing or restructuring are higher than our current rates, interest expense related to such refinancing or restructuring would increase. Further, if there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt financing in the future and the terms of such debt could be adversely affected.

[0001728949-21-000043:mdna:340]
[same as prior period, unchanged from 0001728949-21-000022:mdna:291]

[0001728949-21-000043:mdna:341]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in

[0001728949-21-000043:mdna:342]
countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed, as well as countries where we own intellectual property. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-21-000043:mdna:343]
Tax rules may change in a manner that adversely affects our future reported results of operations or the way we conduct our business. In response to the 2017 Tax Cuts and Jobs Act and to better align our profits with our activities, we implemented certain restructuring in fiscal 2018 and 2019. After our restructuring, most of our income is taxable in the United States with a significant portion qualifying for preferential treatment as FDII (foreign-derived intangible income). Beginning in fiscal 2027, the effective tax rate for FDII increases from 13% to 16%. Further, if U.S. tax rates increase and/or the FDII deduction is eliminated or reduced, both of which have been proposed by the current U.S. presidential administration and Congress, our provision for income taxes, results of operations and cash flows would be adversely (potentially materially) affected. Also, if our customers move manufacturing operations to the United States, our FDII deduction may be reduced.

[0001728949-21-000043:mdna:344]
We have tax incentives in Singapore that require we meet specified employment and other criteria. Although our profit in Singapore has declined as a result of our 2018 restructuring, failure to meet these incentive requirements through March 2022 could result in a retroactive Singapore tax increase for 2017 and 2018.

[0001728949-21-000043:mdna:345]
[same as prior period, unchanged from 0001728949-21-000022:mdna:295]
