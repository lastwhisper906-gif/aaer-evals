# QCOM notes — 0001234452-17-000154


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001234452-17-000154:notes:1]
[same as prior period, unchanged from 0001234452-17-000077:notes:1]

[0001234452-17-000154:notes:2]
| Accounts Receivable (in millions) |  |  |  |
|  | June 25, 2017 |  | September 25, 2016 |
| Trade, net of allowances for doubtful accounts of $11 and $1, respectively | $ | 3,500 |  |  | $ | 2,194 |  |
| Long-term contracts | 22 |  |  | 20 |  |
| Other | 10 |  |  | 5 |  |
|  | $ | 3,532 |  |  | $ | 2,219 |  |

[0001234452-17-000154:notes:3]
Approximately 75% of the increase in accounts receivable was due to the short payment of royalties reported by and deemed collectible from Apple’s contract manufacturers. This same amount is recorded in customer-related liabilities for Apple, since the Company does not have the contractual right to offset these amounts. The remaining increase in accounts receivable resulted from the accounts receivable relating to the Company’s recently formed RF360 Holdings joint venture (Note 8) and the timing of the collection of payments from certain of the Company’s other licensees.

[0001234452-17-000154:notes:4]
| Inventories (in millions) |  |  |  |
|  | June 25, 2017 |  | September 25, 2016 |
| Raw materials | $ | 80 |  |  | $ | 1 |  |
| Work-in-process | 902 |  |  | 847 |  |
| Finished goods | 1,020 |  |  | 708 |  |
|  | $ | 2,002 |  |  | $ | 1,556 |  |

[0001234452-17-000154:notes:5]
| Other Current Liabilities (in millions) |  |  |  |
|  | June 25, 2017 |  | September 25, 2016 |
| Customer incentives and other customer-related liabilities | $ | 2,589 |  |  | $ | 1,710 |  |
| Other | 969 |  |  | 551 |  |
|  | $ | 3,558 |  |  | $ | 2,261 |  |

[0001234452-17-000154:notes:6]
Customer incentives and other customer-related liabilities substantially consist of amounts payable to customers for incentive and other arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of the Company’s products and technologies. The corresponding charges for such arrangements were recorded as a reduction to revenues.

[0001234452-17-000154:notes:7]
Other Income, Costs and Expenses. Other expenses in the nine months ended June 25, 2017 consisted of a $927 million charge related to the KFTC fine (Note 6), including related foreign currency losses, and $35 million in restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan. Other expenses in the three months ended June 26, 2016 consisted of restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan. Other income in the nine months ended June 26, 2016 included a gain of $380 million on the sale of wireless spectrum in the United Kingdom that was held by the QSI (Qualcomm Strategic Initiative) segment in the first quarter of fiscal 2016 for $232 million in cash and $275 million in deferred payments due in 2020 to 2023, which were recorded at their present values in other assets. Other income in the nine months ended June 26, 2016 also included $158 million in restructuring and restructuring-related charges, which were partially offset by a $48 million gain on the sale of the Company’s business that provided augmented reality applications, both of which related to the Company’s Strategic Realignment Plan.

[0001234452-17-000154:notes:8]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | June 25, 2017 |  | June 26, 2016 |
| Interest and dividend income | $ | 147 |  |  | $ | 156 |  |  | $ | 466 |  |  | $ | 451 |  |
| Net realized gains on marketable securities | 124 |  |  | 56 |  |  | 330 |  |  | 99 |  |
| Net realized gains on other investments | 15 |  |  | 13 |  |  | 45 |  |  | 43 |  |
| Impairment losses on marketable securities | (2 | ) |  | (20 | ) |  | (127 | ) |  | (109 | ) |
| Impairment losses on other investments | (13 | ) |  | (13 | ) |  | (36 | ) |  | (29 | ) |
| Equity in net losses of investees | (31 | ) |  | (18 | ) |  | (42 | ) |  | (49 | ) |
| Net losses on foreign currency transactions | (26 | ) |  | — |  |  | (26 | ) |  | — |  |
| Net gains (losses) on derivative investments | 4 |  |  | 2 |  |  | 25 |  |  | (3 | ) |
|  | $ | 218 |  |  | $ | 176 |  |  | $ | 635 |  |  | $ | 403 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001234452-17-000154:notes:9]
[same as prior period, unchanged from 0001234452-17-000077:notes:9]

[0001234452-17-000154:notes:10]
|  | (Unaudited) |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | June 25, 2017 |  | June 26, 2016 |
| Pro forma revenues | $ | 5,371 |  |  | $ | 6,329 |  |  | $ | 16,902 |  |  | $ | 18,139 |  |
| Pro forma net income attributable to Qualcomm | 893 |  |  | 1,471 |  |  | 2,435 |  |  | 4,120 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001234452-17-000154:notes:11]
[same as prior period, unchanged from 0001234452-17-000077:notes:11]

[0001234452-17-000154:notes:12]
[same as prior period, unchanged from 0001234452-17-000077:notes:12]

[0001234452-17-000154:notes:13]
[same as prior period, unchanged from 0001234452-17-000077:notes:13]

[0001234452-17-000154:notes:14]
RF360 Holdings is a variable interest entity, and its results of operations and statement of financial position are included in the Company’s consolidated financial statements (on a one-month reporting lag) as the governance structure of RF360 Holdings provides the Company with the power to direct the activities of the joint venture that most significantly impact its economic performance, such as operating decisions related to research and development, manufacturing and sales and marketing of its products. Since the Put and Call Option is considered a financing of the Company’s purchase of EPCOS’s interest in RF360 Holdings, noncontrolling interest is not recorded in the Company’s consolidated financial statements. Therefore, the Put and Call Option was recorded as a liability at fair value at close and included in other noncurrent liabilities. The liability is being accreted to the Settlement Amount, with the offset recorded as interest expense. The carrying value of the Put and Call Option approximated its estimated fair value at June 25, 2017.

[0001234452-17-000154:notes:15]
[same as prior period, unchanged from 0001234452-17-000077:notes:15]

[0001234452-17-000154:notes:16]
| Cash paid to TDK at close | $ | 1,463 |  |
| Fair value of Put and Call Option | 1,112 |  |
| Fair value of contingent consideration and other deferred payments | 495 |  |
| Total purchase price | $ | 3,070 |  |

[0001234452-17-000154:notes:17]
[same as prior period, unchanged from 0001234452-17-000077:notes:17]

[0001234452-17-000154:notes:18]
| Cash and cash equivalents | $ | 306 |  |
| Accounts receivable | 303 |  |
| Inventories | 261 |  |
| Intangible assets subject to amortization: |  |
| Technology-based intangible assets | 738 |  |
| Customer-related intangible assets | 87 |  |
| Marketing-related intangible assets | 8 |  |
| In-process research and development (IPR&D) | 75 |  |
| Property, plant and equipment | 837 |  |
| Goodwill | 812 |  |
| Other assets | 42 |  |
| Total assets | 3,469 |  |
| Liabilities | (399 | ) |
|  | $ | 3,070 |  |

[0001234452-17-000154:notes:19]
The Company recognized $812 million in goodwill related to this transaction, of which $287 million is expected to be deductible for tax purposes. The goodwill recognized was allocated to the QCT segment for annual impairment testing purposes. The goodwill is primarily attributable to the assembled workforce and synergies expected to arise after the acquisition. Each category of intangible assets acquired will be amortized on a straight-line basis over the weighted-average useful lives of seven years for technology-based intangible assets, nine years for customer-related intangible assets and one year for marketing-related intangible assets. On the acquisition date, IPR&D consisted of four projects. Upon completion, the IPR&D projects will be amortized over their useful lives of six years. The estimated fair values of the intangible assets and the property, plant and equipment acquired were primarily determined using the income approach and cost approach, respectively, both of which were based on significant inputs that were not observable.

[0001234452-17-000154:notes:20]
The Company’s results of operations for the three and nine months ended June 25, 2017 included the operating results of RF360 Holdings on a one-month reporting lag since the date of acquisition, the amounts of which were not material. The following table presents the unaudited pro forma results for the three and nine months ended June 25, 2017 and June 26, 2016. The unaudited pro forma financial information combines the results of operations of Qualcomm and RF360 Holdings as though the companies had been combined as of the beginning of fiscal 2016. The pro forma information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at such time. The unaudited pro forma results presented below include adjustments for the step-up of inventories to fair value, amortization and depreciation of identified intangible assets and property, plant and equipment, adjustments for certain acquisition-related charges, interest expense related to the Put and Call Option and related tax effects (in millions):

[0001234452-17-000154:notes:21]
NXP. On October 27, 2016, the Company announced a definitive agreement under which Qualcomm River Holdings, B.V. (Qualcomm River Holdings), an indirect, wholly owned subsidiary of QUALCOMM Incorporated, will acquire NXP Semiconductors N.V. Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration to be paid to NXP’s shareholders of $38 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products.

[0001234452-17-000154:notes:22]
The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions, including the tender of at least 80% of the issued and outstanding common shares of NXP in the offer (provided that the minimum tender threshold may be reduced to a percentage not less than 70% with the prior written consent of NXP). At an Extraordinary General Meeting of NXP’s shareholders held on January 27, 2017, NXP’s shareholders approved certain matters relating to the transaction, including the appointment of designees of Qualcomm River Holdings to NXP’s board of directors (effective upon the closing of the transaction) and certain transactions that are intended to be consummated after the completion of the tender offer.

[0001234452-17-000154:notes:23]
In May 2017, the Company issued an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes with varying maturities, of which a portion will be used to fund the purchase price and other related transactions. In addition, the Company has secured $4.0 billion in committed financing through a Term Loan Facility, which is expected to be drawn on at the close of the NXP transaction (Note 5). The remaining amount will be funded with cash held by foreign entities.

[0001234452-17-000154:notes:24]
Qualcomm River Holdings and NXP may terminate the definitive agreement under certain circumstances. If the definitive agreement is terminated by NXP in certain circumstances, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the definitive agreement is terminated by Qualcomm River Holdings under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion. In November 2016, as required by the definitive agreement, Qualcomm River Holdings entered into four letters of credit for an aggregate amount of $2.0 billion related to the potential termination fee payable to NXP. Pursuant to the terms of each letter of credit, NXP will have the right to draw amounts to fund certain termination compensation owed by Qualcomm River Holdings to NXP if the definitive agreement is terminated under certain circumstances. The letters of credit expire on June 30, 2018 or if drawn on by NXP or surrendered by Qualcomm River Holdings. Each letter of credit is required to be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. Qualcomm River Holdings is restricted from using the funds deposited as collateral while the letters of credit are outstanding. At June 25, 2017, the letters of credit were fully collateralized through bank time deposits and money market funds, which were recorded as other noncurrent assets.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001234452-17-000154:notes:25]
Commitments and Contingencies

[0001234452-17-000154:notes:26]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe certain ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 ParkerVision patents and seeks damages and injunctive and other relief. On September 25, 2015, ParkerVision filed a motion with the court to sever some claims against the Company and all other defendants into a separate lawsuit. In addition, on December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against the Company and other parties with the United States International Trade Commission (ITC) described below. The Company had previously filed Inter-Partes Review petitions with the United States Patent and Trademark Office (USPTO) to invalidate all asserted claims of several of the remaining patents. On March 7, 2017, the USPTO decided in the Company’s favor with respect to all asserted claims of one such patent. After the ITC action described below was closed, the parties agreed to further stay the District Court case pending ParkerVision’s appeals of the USPTO’s invalidation decisions.

[0001234452-17-000154:notes:27]
On December 14, 2015, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. were also named defendants. The complaint asserts that certain of the Company’s products infringe four additional ParkerVision patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. The District Court case was stayed on February 12, 2016 pending completion of the ITC investigation. Subsequently, ParkerVision announced that it had reached a settlement with Samsung which dismissed the Samsung entities from the ITC investigation and related District Court case. On February 2, 2017, the ITC granted ParkerVision’s motion to drop all but one patent and one accused product from the ITC investigation. On March 12, 2017, one day before the ITC hearing was scheduled to begin, ParkerVision moved to withdraw its ITC complaint in its entirety. The Company and the other defendants did not oppose the withdrawal of the complaint. On April 28, 2017, the ITC formally closed the investigation. On May 4, 2017, ParkerVision filed a motion to reopen the related District Court case, and the District Court granted the motion on May 26, 2017. The parties are currently negotiating a schedule for the District Court proceeding.

[0001234452-17-000154:notes:28]
The Company believes ParkerVision’s claims are without merit.

[0001234452-17-000154:notes:29]
BlackBerry Limited (BlackBerry) Arbitration: On April 20, 2016, the Company and BlackBerry entered into an agreement to arbitrate BlackBerry’s allegation that it overpaid royalties on certain past sales of subscriber units based on the alleged effect of specific provisions in its license agreement. The arbitration hearing was held during the week of February 27, 2017 by a three-judge panel under the rules of the Judicial Arbitration and Mediation Services in San Diego, California. On April 11, 2017, the panel provided its decision, finding that the Company must pay to BlackBerry $815 million, plus interest at a rate of 10% from June 2015. The decision was limited to prepayment provisions unique to BlackBerry’s license agreement with the Company and has no impact on agreements with any other licensee. The decision was binding and not subject to appeal. The decision also found that BlackBerry was entitled to recover its reasonable attorneys’ fees in an amount to be determined by the panel. As a result, the Company recorded a reduction to licensing revenues of $974 million in the second quarter of fiscal 2017. On May 25, 2017, BlackBerry and the Company entered into a Joint Stipulation Regarding Final Award Agreement agreeing that the Company would pay BlackBerry $940 million to cover the award amount, pre-judgment interest and attorneys’ fees. This also reflected certain amounts that were owed to the Company by Blackberry. As a result, in the third quarter of fiscal 2017, the Company recorded royalty revenues in the QTL segment of $22 million, with the remaining amount recorded as an adjustment to revenues related to the arbitration decision. The Company paid this amount to BlackBerry on May 26, 2017.

[0001234452-17-000154:notes:30]
Apple Inc. (Apple) v. QUALCOMM Incorporated: On January 20, 2017, Apple filed a complaint against the Company in the United States District Court for the Southern District of California seeking declarations with respect to several of the Company’s patents and alleging that the Company breached certain agreements and violated federal antitrust and California state unfair competition laws. In particular, Apple seeks declaratory judgments of non-infringement by Apple of nine of the Company’s patents, or in the alternative, a declaration of royalties Apple must pay for the patents. Apple further seeks a declaration that the Company’s sale of baseband chipsets exhausts the Company’s patent rights for patents embodied in those chipsets. Separately, Apple seeks to enjoin the Company from seeking excessive royalties from Apple and to disgorge royalties paid by Apple’s contract manufacturers that the court finds were not fair, reasonable and non-discriminatory (FRAND). Apple also claims that the Company’s refusal to make certain payments to Apple under a Business Cooperation and Patent Agreement (Cooperation Agreement) constitutes a breach of contract in violation of California law and seeks damages in the amount of the unpaid payments, alleged to be approximately $1 billion. In addition, Apple claims that the Company has refused to deal with competitors in contravention of the Company’s agreements with applicable standard setting organizations, has used its market position to impose contractual obligations on Apple that prevented Apple from challenging the Company’s licensing practices, has tied the purchase of the Company’s CDMA-enabled and premium LTE-enabled chipsets to licensing certain of the Company’s patents and has required Apple to purchase baseband chipsets exclusively from the Company as a condition of the Company’s payment to Apple of certain rebates, in violation of Section 2 of the Sherman Act and the California Unfair Competition Law. Apple seeks injunctive relief with respect to these claims and a judgment awarding its expenses, costs and attorneys’ fees.

[0001234452-17-000154:notes:31]
On April 10, 2017, the Company filed its Answer and Counterclaims (amended on May 24, 2017) in response to Apple’s complaint denying Apple’s claims and asserting claims against Apple. The counterclaims against Apple include tortious interference with the Company’s long-standing Subscriber Unit License Agreements (SULAs) with third-party contract manufacturers of Apple devices, causing those contract manufacturers to withhold certain royalty payments owed to the Company; breach of contract and the implied covenant of good faith and fair dealing relating to the parties’ Cooperation Agreement; unjust enrichment and declaratory relief relating to the Cooperation Agreement; breach of contract based on Apple’s failure to pay amounts owed to the Company under a Statement of Work relating to a high-speed feature of the Company’s chipsets; breach of the parties’ software agreement; and violation of California Unfair Competition Law based on (i) Apple’s falsely claiming that there was “no discernible difference” between iPhones using the Company’s chipsets and iPhones using Intel Corp.’s chipsets, and (ii) Apple’s threatening the Company to prevent it from promoting the superior performance of the Company’s own chipsets. The Company also seeks declaratory judgments that the Company has satisfied its FRAND commitments with respect to Apple, and that the Company’s SULAs with the contract manufacturers do not violate either competition law or the Company’s FRAND commitments. On June 19, 2017, Apple filed a Partial Motion to Dismiss the Company’s counterclaim for violation of the California Unfair Competition Law. A hearing on that motion is scheduled for September 29, 2017. On June 20, 2017, Apple filed an Answer and Affirmative Defenses to the rest of the Company’s counterclaims, and also filed an Amended Complaint adding claims for declaratory judgments of invalidity of the nine patents that are subject to declaratory judgment claims in the original complaint, adding new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for nine more patents. Apple also added claims for declaratory judgments that certain of the Company’s agreements are unenforceable. The Company’s deadline to respond to the Amended Complaint is July 21, 2017. On July 18, 2017, Apple filed a motion to consolidate this action with QUALCOMM Incorporated v. Compal Electronics, Inc. et al., discussed below.

[0001234452-17-000154:notes:32]
On January 23, 2017, an Apple subsidiary in China filed two complaints against the Company in the Beijing Intellectual Property Court. On March 31, 2017, the court granted an application by Apple Inc. to join the actions as a plaintiff, and Apple amended the complaints. One of the complaints alleges a violation of China’s Anti-Monopoly Law (AML complaint); the other complaint requests a determination of the terms of a patent license between the Company and Apple (FRAND complaint). In particular, the AML complaint alleges that (i) the Company has abused its dominant position in communication standard-essential patents licensing markets and certain global baseband chipset markets by charging and offering royalty terms that were excessively high; (ii) the Company refused to license certain implementers of standardized technologies, including Apple and baseband chipset manufacturers; (iii) the Company forced Apple to use only the Company’s products and services; and (iv) the Company bundled licenses to standard-essential patents with licenses to non-standard-essential patents and imposed other unreasonable or discriminatory trading terms on Apple in violation of the AML. The AML complaint seeks a decree that the Company cease the alleged abuse of dominance, as well as damages in the amount of 1 billion Chinese Renminbi (approximately $146 million based on the exchange rate on June 25, 2017). The FRAND complaint makes allegations similar to the AML complaint and further alleges that the Company refused to offer licensing terms for the Company’s cellular standard-essential patents consistent with the Company’s FRAND licensing commitments and failed to provide to Apple certain information about the Company’s patents. The FRAND complaint seeks (i) a declaration that the license terms offered to Apple by the Company for its mobile communication standard essential patents are not compliant with FRAND; (ii) an order that the Company cease its actions that allegedly violate the Company’s FRAND obligations, including pricing on unfair, unreasonable and excessive terms, refusing to deal, imposing unreasonable trade conditions and failing to provide information on the Company’s patents; and (iii) a determination of FRAND-compliant license terms for the Company’s Chinese standard-essential patents. Apple also seeks its expenses in each of the cases. On March 3, 2017, the Company filed objections to the court’s jurisdiction in these cases. On April 17, 2017, the Company filed (i) new jurisdictional objections to the amended complaints; and (ii) opinions on Apple Inc.’s application to join the suits as a plaintiff. On May 17, 2017, the Company filed supplemental jurisdictional objections.

[0001234452-17-000154:notes:33]
On February 16, 2017, Apple and one of its Japanese subsidiaries filed four complaints against the Company in the Tokyo District Court. In three of the complaints, Apple seeks declaratory judgment of non-infringement by Apple of three of the Company’s patents. Apple further seeks a declaration that the Company’s patent rights with respect to those three patents are exhausted by the Company’s SULAs with the contract manufacturers of Apple’s devices as well as the Company’s sale of baseband chipsets. Apple also seeks an award of fees. On May 15, 2017, the Company learned of the fourth complaint. In that complaint, Apple and one of its Japanese subsidiaries seek damages of 100 million Japanese Yen (approximately $1 million based on the exchange rate on June 25, 2017) from the Company, based on allegations that the Company violated the Japanese Antimonopoly Act and the Japanese Civil Code. In particular, the fourth complaint alleges that (i) the Company holds a monopoly position in the market for baseband processor chipsets that implement certain cellular standards; (ii) the Company collects double royalties through its license agreements and the sale of chipsets; (iii) the Company refused to grant Apple a license on FRAND terms and forced Apple to execute a rebate agreement under unreasonable conditions; (iv) the Company refused to grant Apple a direct license; and (v) the Company demanded a license fee based on the market value of the total device. The Company has filed answers to two of the complaints and intends to file answers to the others prior to their due dates.

[0001234452-17-000154:notes:34]
On March 2, 2017, the Company learned that Apple and certain of its European subsidiaries issued a Claim Form against the Company in the UK High Court of Justice, Chancery Division, Patents Court on January 23, 2017. The Claim Form alleges several European competition law claims, including refusal to license competing chipmakers, failure to offer Apple a direct license to the Company’s standard-essential patents on FRAND terms, demanding excessive royalties for the Company’s standard-essential patents, and demanding excessive license fees for the use of the Company’s standard-essential patents in connection with chipsets purchased from the Company. Apple also seeks declarations that it is a willing licensee and that commercial activity in relation to its iPhones and iPads attributable to, implemented by, or using the Company’s chipsets does not infringe any of the Company’s patents because the Company either exhausted its patent rights or granted Apple an implied license. Finally, Apple claims that five of the Company’s European (UK) patents are invalid.

[0001234452-17-000154:notes:35]
On April 20, 2017, the Company was informed that on April 18, 2017, Apple and one of its Taiwanese subsidiaries filed a complaint against the Company in the Taiwan Intellectual Property Court alleging that the Company has abused a dominant market position in licensing wireless standard-essential patents and selling baseband chipsets, including improper pricing, refusal to deal, exclusive dealing, tying, imposing unreasonable trade terms and discriminatory treatment. The complaint seeks rulings that the Company not use the sales price of the terminal device as the royalty base for standard-essential patents; not leverage its cellular standard-essential patents to obtain licenses of our non-standard-essential patents or demand cross-licenses without proper compensation; not refuse, reduce, delay or take any other action to limit the supply of its baseband chipsets to non-licensees; that the Company must license its standard-essential patents on FRAND terms; and that the Company shall not, based on standard-essential patents, seek injunctions. The complaint also seeks damages of 10 million New Taiwan Dollars (less than $1 million based on the exchange rate on June 25, 2017), among other relief.

[0001234452-17-000154:notes:36]
On July 14, 2017, the Company filed a motion for anti-suit injunction in the Southern District of California, asking the court to enjoin Apple from pursuing its foreign actions in the UK, China, Japan and Taiwan and from initiating other duplicative foreign actions, while the action in the Southern District of California is pending. Apple’s opposition to this motion is due on August 4, 2017. A hearing on this motion is scheduled for August 18, 2017.

[0001234452-17-000154:notes:37]
The Company believes Apple’s claims in the above matters are without merit.

[0001234452-17-000154:notes:38]
QUALCOMM Incorporated v. Compal Electronics, Inc. et al.: On May 17, 2017, the Company filed a complaint in the United States District Court for the Southern District of California against Compal Electronics, Inc. (Compal), FIH Mobile, Ltd., Hon Hai Precision Industry Co., Ltd. (together with FIH Mobile, Ltd., Foxconn), Pegatron Corporation (Pegatron) and Wistron Corporation (Wistron) asserting claims for injunctive relief, specific performance, declaratory relief and damages stemming from the defendants’ breach of contracts by ceasing the payment of royalties for iPhones and other devices which they manufacture for Apple. On May 24, 2017, the Company filed a Motion for Preliminary Injunction seeking to enjoin each of the defendants from violating their license agreements during the pendency of the litigation. On July 17, 2017, Compal, Foxconn, Pegatron and Wistron each filed third party complaints for contractual indemnity against Apple seeking to join Apple as a party to the action. On July 18, 2017, Apple filed an answer to these third party complaints acknowledging its indemnity agreements and consenting to be joined. On that same date, the defendants and Apple filed papers opposing the motion for preliminary injunction. A hearing on the preliminary injunction motion is scheduled for August 15, 2017. Also on July 18, 2017, the defendants filed an Answer and Counterclaims to the complaint, asserting defenses and counterclaims similar to allegations previously made by Apple in the Southern District of California case, discussed above. In addition, the defendants asserted certain new claims, including claims under Section 1 of the Sherman Act and California’s Cartwright Act. The defendants seek damages, declaratory relief, injunctive relief, restitution of certain royalties and other relief. Finally, on July 18, 2017, Apple filed a motion to consolidate this action with the Apple Inc. v. QUALCOMM Incorporated case in the Southern District of California, discussed above.

[0001234452-17-000154:notes:39]
The Company believes Compal’s, Foxconn’s, Pegatron’s and Wistron’s claims in the above matter are without merit.

[0001234452-17-000154:notes:40]
QUALCOMM Incorporated v. Apple Inc.: On July 6, 2017, the Company filed a complaint in the United States District Court for the Southern District of California against Apple asserting claims for damages and injunctive relief for infringement of six of the Company’s patents directed to a variety of features found in iPhone models. On July 7, 2017, the Company filed a complaint in the United States International Trade Commission (ITC) against Apple requesting that the ITC institute an investigation pursuant to Section 337 of the Tariff Act of 1930 based on Apple’s infringement of the same six patents. The Company is seeking a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

[0001234452-17-000154:notes:41]
On July 17, 2017, the Company filed complaints against Apple and certain of its subsidiaries in the Federal Republic of Germany, asserting infringement of one patent in the Mannheim Regional Court and infringement of another patent in Munich District Court. The complaints seek remedies including damages and injunctive relief. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

[0001234452-17-000154:notes:42]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, plaintiffs filed a securities class action complaint against the Company and certain of its current and former officers in the United States District Court for the Southern District of California. On April 29, 2016, plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, plaintiffs filed a second amended complaint, alleging that the Company and certain of its current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding the Company’s business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint seeks unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, the Company filed a motion to dismiss the second amended complaint, which motion is pending. The Company believes the plaintiffs’ claims are without merit.

[0001234452-17-000154:notes:43]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, respectively, two securities class action complaints were filed by purported stockholders of the Company in the United States District Court for the Southern District of California against the Company and certain of its current and former officers and directors. The complaints alleged, among other things, that the defendants violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that the Company is or was engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. The defendants’ response to the consolidated amended complaint is due on September 1, 2017. The Company believes the plaintiffs’ claims are without merit.

[0001234452-17-000154:notes:44]
Consumer Class Action Lawsuit: Since January 18, 2017, more than thirty consumer class action complaints have been filed against the Company in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel, and on May 25, 2017, set a trial date of April 29, 2019. On July 11, 2017, plaintiffs filed a Consolidated Amended Complaint alleging that the Company violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to its competitors, conditioning the supply of certain of its baseband chipsets on the purchaser first agreeing to license the Company’s entire patent portfolio, entering into exclusive deals with companies including Apple Inc., and charging unreasonably high royalties that do not comply with the Company’s commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that the Company be enjoined from further unlawful conduct. The Company believes the plaintiffs’ claims are without merit.

[0001234452-17-000154:notes:45]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 36 different dates, with the next hearing scheduled for September 5, 2017.

[0001234452-17-000154:notes:46]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments since then with respect to this matter.

[0001234452-17-000154:notes:47]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it was conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that the Company has violated provisions of the MRFTA. On January 22, 2017, the Company received the KFTC’s formal written decision, which finds that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with the Company; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders the Company to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chips; (iii) not demand unjustifiable conditions in the Company’s license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on the Company and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between the Company and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of approximately 1.03 trillion Korean Won (approximately $927 million), which was paid on March 30, 2017. The Company believes that its business practices do not violate the MRFTA, and on February 21, 2017 filed an action in the Seoul High Court to cancel the KFTC’s decision. On the same day, the Company filed an application with the Seoul High Court to stay the decision’s remedial order pending the Seoul High Court’s final judgment on the Company’s action to cancel the KFTC’s decision. The Seoul High Court held hearings on the Company’s application to stay the decision’s remedial order on July 10, 2017 and July 14, 2017. The Seoul High Court has not ruled on the Company’s action to cancel the KFTC’s decision or its application to stay the decision’s remedial order. The Seoul High Court ordered supplemental submissions related to the stay proceeding to be submitted by August 11, 2017.

[0001234452-17-000154:notes:48]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company provided additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On August 15, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the European Union (EU) competition rules.

[0001234452-17-000154:notes:49]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that since 2011 the Company has paid significant amounts to a customer on condition that it exclusively use the Company’s baseband chipsets in its smartphones and tablets. This conduct has allegedly reduced the customer’s incentives to source chipsets from the Company’s competitors and harmed competition and innovation for certain baseband chipsets. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On June 27, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

[0001234452-17-000154:notes:50]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified the Company that it was conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against the Company in the United States District Court for the Northern District of California alleging that the Company engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of baseband processors on the purchaser first agreeing to a license to the Company’s standard-essential patents, paying incentives to purchasers of baseband processors to induce them to accept certain license terms, refusing to license its standard-essential patents to the Company’s competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint seeks a permanent injunction against the Company’s alleged violations of the FTCA and other unspecified ancillary equitable relief. The Company filed a motion to dismiss the FTC’s complaint on April 3, 2017, which the court denied on June 26, 2017. On April 19, 2017, the court set a trial date for January 4, 2019. The Company believes the FTC’s claims are without merit.

[0001234452-17-000154:notes:51]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified the Company that it is conducting an investigation into whether the Company’s patent licensing arrangements violate the Taiwan Fair Trade Act (TFTA). On April 27, 2016, the TFTC specified that the allegations under investigation include whether: (i) the Company jointly licensed its patents rather than separately licensing standard-essential patents and non-standard-essential patents; (ii) the Company’s royalty charges are unreasonable; (iii) the Company unreasonably required licensees to grant it cross-licenses; (iv) the Company failed to provide lists of licensed patents to licensees; (v) the Company violated a FRAND licensing commitment by declining to grant licenses to chipset makers; (vi) the Company declined to sell chipsets to unlicensed potential customers; and (vii) the Company provided royalty rebates to certain companies in exchange for their exclusive use of the Company’s chipsets. If a violation is found, a broad range of remedies is potentially available to the TFTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the TFTC. The Company believes that its business practices do not violate the TFTA. The Company continues to cooperate with the TFTC as it conducts its investigation.

[0001234452-17-000154:notes:52]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at June 25, 2017 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001234452-17-000154:notes:53]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0001234452-17-000154:notes:54]
Through June 25, 2017, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at June 25, 2017 associated with these indemnification arrangements based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001234452-17-000154:notes:55]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at June 25, 2017 for the remainder of fiscal 2017 and for each of the subsequent four years from fiscal 2018 through 2021 were $3.6 billion, $1.8 billion, $1.0 billion, $373 million and $122 million, respectively, and $28 million thereafter. Of these amounts, for the remainder of fiscal 2017 and for each of the subsequent four years from fiscal 2018 through 2021, commitments to purchase integrated circuit product inventories comprised $2.9 billion, $1.5 billion, $875 million, $297 million, $76 million, respectively, and $28 million thereafter. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

[0001234452-17-000154:notes:56]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments at June 25, 2017 for the remainder of fiscal 2017 and for each of the subsequent four years from fiscal 2018 through 2021 were $30 million, $110 million, $93 million, $71 million and $51 million, respectively, and $86 million thereafter.

[0001234452-17-000154:notes:57]
Other Commitments. At June 25, 2017, the Company was committed to fund certain strategic investments up to $537 million. Of this amount, $85 million is expected to be funded in the remainder of fiscal 2017. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.


## us-gaap:DebtDisclosureTextBlock

[0001234452-17-000154:notes:58]
Debt

[0001234452-17-000154:notes:59]
Revolving Credit Facility. In November 2016, the Company amended and restated its existing Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit (Amended and Restated Revolving Credit Facility) to increase the aggregate amount available to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. The Company had not previously borrowed any funds under the existing Revolving Credit Facility. Proceeds from the Amended and Restated Revolving Credit Facility are expected to be used for general corporate purposes. Loans under the Amended and Restated Revolving Credit Facility will bear interest, at the option of the Company, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the Amended and Restated Revolving Credit Facility) or the Base Rate (determined in accordance with the Amended and Restated Revolving Credit Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.70% and 0.00% per annum, respectively. The Amended and Restated Revolving Credit Facility has a facility fee, which initially accrues at a rate of 0.05% per annum. At June 25, 2017, the Company had not borrowed any funds under the Amended and Restated Revolving Credit Facility.

[0001234452-17-000154:notes:60]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At June 25, 2017 and September 25, 2016, the Company had $999 million and $1.7 billion, respectively, of outstanding commercial paper recorded as short-term debt with weighted-average interest rates of 0.97% and 0.52%, respectively, which included fees paid to the commercial paper dealers and weighted-average remaining days to maturity of 28 days and 36 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at June 25, 2017 and September 25, 2016.

[0001234452-17-000154:notes:61]
Bridge Loan Facility. In October 2016, the Company entered into commitment letters pursuant to which the Company received commitments for senior unsecured bridge facility loans in an aggregate principal amount up to $13.6 billion (Bridge Loan Facility). Proceeds from the Bridge Loan Facility, if drawn, were intended to be used to finance, in part, the proposed acquisition of NXP by Qualcomm River Holdings B.V., a wholly owned subsidiary of the Company (Qualcomm River Holdings) (Note 8). Subsequently, the commitments available under the Bridge Loan Facility were reduced to $7.1 billion upon the Company entering into a $4.0 billion Term Loan Facility, described below, and the sale of certain assets by NXP Semiconductors N.V. for estimated net cash proceeds of $2.5 billion in February 2017. In May 2017, in connection with the Company’s issuance of an aggregate principal amount of $11.0 billion of unsecured floating-rate and fixed-rate notes, described below, the commitments available under the Bridge Loan Facility were reduced such that there were no remaining commitments available, and the Bridge Loan Facility was terminated. The Company had not previously borrowed any funds under the Bridge Loan Facility. The Bridge Loan Facility had a ticking fee, which accrued at a rate of 0.05% per annum commencing on December 26, 2016.

[0001234452-17-000154:notes:62]
Term Loan Facility. In November 2016, the Company entered into a Credit Agreement that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion (Term Loan Facility). Proceeds from the Term Loan Facility, if drawn, will be used to finance the proposed acquisition of NXP. Commitments under the Term Loan Facility will expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the Term Loan Facility, (ii) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP and (iii) October 27, 2017 (unless such date is extended in accordance with the NXP purchase agreement). Loans under the Term Loan Facility will mature on the third anniversary of the date on which they are funded and will bear interest at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the Term Loan Facility) or the Base Rate (determined in accordance with the Term Loan Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.875% and 0.00% per annum, respectively. The Term Loan Facility has a ticking fee, which initially accrues at a rate of 0.05% per annum commencing on December 26, 2016. At June 25, 2017, the Company had not borrowed any funds under the Term Loan Facility.

[0001234452-17-000154:notes:63]
Long-Term Debt. In May 2017, the Company issued an aggregate principal amount of $11.0 billion of unsecured floating-rate and fixed-rate notes with varying maturities. The proceeds from the notes of approximately $10.95 billion, net of underwriting discounts and offering expenses, are intended to be used to finance, in part, the Company’s proposed acquisition of NXP and other related transactions and for general corporate purposes. The following table provides a summary of the Company’s long-term debt (in millions except percentages):

[0001234452-17-000154:notes:64]
|  |  | June 25, 2017 |  | September 25, 2016 |
|  |  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| May 2015 Issuance |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.27% notes due May 18, 2018 | $ | 250 |  |  | 1.50% |  | $ | 250 |  |  | 1.14% |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | 250 |  |  | 1.78% |  | 250 |  |  | 1.42% |
|  | Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 1.69% |  | 1,250 |  |  | 0.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 2.07% |  | 1,750 |  |  | 1.69% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.51% |  | 2,000 |  |  | 2.04% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| May 2017 Issuance |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.36% notes due May 20, 2019 | 750 |  |  | 1.68% |  | — |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.45% notes due May 20, 2020 | 500 |  |  | 1.74% |  | — |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 2.00% |  | — |  |  |  |
|  | Fixed-rate 1.85% notes due May 20, 2019 | 1,250 |  |  | 2.00% |  | — |  |  |  |
|  | Fixed-rate 2.10% notes due May 20, 2020 | 1,500 |  |  | 2.20% |  | — |  |  |  |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | — |  |  |  |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | — |  |  |  |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | — |  |  |  |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.47% |  | — |  |  |  |
|  | Total principal | 21,000 |  |  |  |  | 10,000 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (110 | ) |  |  |  | (57 | ) |  |  |
|  | Hedge accounting fair value adjustments | 9 |  |  |  |  | 65 |  |  |  |
|  | Total | $ | 20,899 |  |  |  |  | $ | 10,008 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | 1,496 |  |  |  |  | $ | — |  |  |  |
|  | Long-term debt | 19,403 |  |  |  |  | 10,008 |  |  |  |
|  | Total | $ | 20,899 |  |  |  |  | $ | 10,008 |  |  |  |

[0001234452-17-000154:notes:65]
Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company’s 2019 floating-rate notes, 2020 floating-rate notes, 2019 fixed-rate notes and 2020 fixed-rate notes issued in May 2017 for an aggregate principal amount of $4.0 billion are subject to a special mandatory redemption at a price equal to 101% of the aggregate principal amount, plus accrued and unpaid interest to, but excluding, the date of such mandatory redemption. The redemption is required on the first to occur of (i) the termination of the NXP purchase agreement or (ii) October 27, 2017 (or such later date on or prior to June 1, 2018 to which such date is extended in accordance with the NXP purchase agreement). The Company may redeem the other fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the other floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. The obligations under the notes rank equally in right of payment with all of the Company’s other senior unsecured indebtedness and will effectively rank junior to all liabilities of the Company’s subsidiaries. At June 25, 2017 and September 25, 2016, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $21.5 billion and $10.6 billion, respectively.

[0001234452-17-000154:notes:66]
In connection with the May 2015 debt issuance, the Company entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings in interest expense in the current period. The Company did not enter into similar interest rate swaps in connection with the May 2017 debt issuance.

[0001234452-17-000154:notes:67]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $289 million and $270 million in the nine months ended June 25, 2017 and June 26, 2016.

[0001234452-17-000154:notes:68]
Debt Covenants. The Amended and Restated Revolving Credit Facility and the Term Loan Facility require, and the Bridge Loan Facility and prior Revolving Credit Facility required, that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. At June 25, 2017 and September 25, 2016, the Company was in compliance with the applicable covenants under each facility outstanding at such time.


## us-gaap:DividendsDeclaredTableTextBlock

[0001234452-17-000154:notes:69]
In the nine months ended June 25, 2017 and June 26, 2016, dividends charged to retained earnings were as follows (in millions, except per share data):

[0001234452-17-000154:notes:70]
|  | 2017 |  | 2016 |
|  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.53 |  |  | $ | 801 |  |  | $ | 0.48 |  |  | $ | 730 |  |
| Second quarter | 0.53 |  |  | 798 |  |  | 0.48 |  |  | 726 |  |
| Third quarter | 0.57 |  |  | 858 |  |  | 0.53 |  |  | 794 |  |
|  | $ | 1.63 |  |  | $ | 2,457 |  |  | $ | 1.49 |  |  | $ | 2,250 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001234452-17-000154:notes:71]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and the weighted-average number of common shares outstanding during the reporting period.


## us-gaap:FairValueDisclosuresTextBlock

[0001234452-17-000154:notes:72]
[same as prior period, unchanged from 0001234452-17-000077:notes:70]

[0001234452-17-000154:notes:73]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at June 25, 2017 (in millions):

[0001234452-17-000154:notes:74]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 3,540 |  |  | $ | 10,133 |  |  | $ | — |  |  | $ | 13,673 |  |
| Marketable securities |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 2,766 |  |  | 73 |  |  | — |  |  | 2,839 |  |
| Corporate bonds and notes | — |  |  | 17,822 |  |  | — |  |  | 17,822 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 958 |  |  | 40 |  |  | 998 |  |
| Equity and preferred securities and equity funds | 32 |  |  | — |  |  | — |  |  | 32 |  |
| Debt funds | — |  |  | 447 |  |  | — |  |  | 447 |  |
| Total marketable securities | 2,798 |  |  | 19,300 |  |  | 40 |  |  | 22,138 |  |
| Derivative instruments | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Other investments | 358 |  |  | — |  |  | 135 |  |  | 493 |  |
| Total assets measured at fair value | $ | 6,696 |  |  | $ | 29,454 |  |  | $ | 175 |  |  | $ | 36,325 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |
| Other liabilities | 358 |  |  | — |  |  | 193 |  |  | 551 |  |
| Total liabilities measured at fair value | $ | 358 |  |  | $ | 7 |  |  | $ | 193 |  |  | $ | 558 |  |

[0001234452-17-000154:notes:75]
Activity between Levels of the Fair Value Hierarchy. There were no significant transfers between Level 1 and Level 2 in the nine months ended June 25, 2017 and June 26, 2016. The Company recognizes transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. Transfers of marketable securities out of Level 3 in the nine months ended June 26, 2016 primarily consisted of debt securities with significant upgrades in credit ratings or for which there were observable inputs.

[0001234452-17-000154:notes:76]
Other investments and other liabilities included in Level 3 at June 25, 2017 were comprised of convertible debt instruments issued by private companies and contingent consideration related to business combinations, respectively, in the nine months ended June 25, 2017. There were no transfers of convertible debt instruments or contingent consideration amounts into or out of Level 3 during the nine months ended June 25, 2017. When a determination is made to classify an asset or liability within Level 3, the determination is based upon the significance of the unobservable inputs to the overall fair value measurement. The fair value of convertible debt instruments is estimated by the Company based on the estimated timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery. The fair value of contingent consideration related to business combinations is estimated by the Company using a real options approach, which includes inputs, such as projected financial information, market volatility, discount rates and timing of contractual payments. The inputs used by the Company to estimate the fair values of the convertible debt instruments and contingent consideration are generally unobservable, and therefore, they are included in Level 3.

[0001234452-17-000154:notes:77]
Nonrecurring Fair Value Measurements. The Company measures certain assets at fair value on a nonrecurring basis. These assets include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. In the nine months ended June 25, 2017 and June 26, 2016, the Company did not have any significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001234452-17-000154:notes:78]
[same as prior period, unchanged from 0001234452-17-000077:notes:76]

[0001234452-17-000154:notes:79]
The Company estimates its annual effective income tax rate to be approximately 11% for fiscal 2017, which is less than its 17% effective income tax rate for fiscal 2016. Tax benefits from foreign income taxed at rates lower than rates in the United States are expected to be approximately 27% in fiscal 2017, compared to 16% in fiscal 2016, primarily resulting from lower estimated United States revenues related to decreased royalty revenues from Apple’s contract manufacturers and the BlackBerry arbitration (Note 6). In the nine months ended June 25, 2017, the Company recorded a charge of $927 million related to the KFTC fine (Note 6), which is not deductible for tax purposes and is attributable to both the United States and a foreign jurisdiction. The estimated annual effective tax rate of 11% for fiscal 2017 also reflects the increase in the Company’s Singapore tax rate as a result of the expiration of certain of its tax incentives in March 2017, which is partially offset by tax benefits resulting from the increase in the Singapore tax rate that will be in effect when certain deferred tax assets are scheduled to reverse. The annual effective tax rate of 17% for fiscal 2016 reflected a $101 million tax benefit recorded discretely in the third quarter of fiscal 2016 resulting from a worthless stock deduction on a domestic subsidiary of one of the Company’s former display businesses and a $79 million benefit recorded discretely in the first quarter of fiscal 2016 related to fiscal 2015 resulting from the retroactive and permanent reinstatement of the United States federal research and development tax credit.

[0001234452-17-000154:notes:80]
The effective tax rate of 1% benefit for the third quarter of fiscal 2017 was less than the estimated annual effective tax rate of 11% provision primarily resulting from a reduction in the third quarter of fiscal 2017 to the Company’s expected United States revenues principally related to decreased royalty revenues from Apple’s contract manufacturers (Note 6).

[0001234452-17-000154:notes:81]
Unrecognized tax benefits were $278 million and $271 million at June 25, 2017 and September 25, 2016, respectively. The Company believes that it is reasonably possible that the total amounts of unrecognized tax benefits at June 25, 2017 may increase or decrease in the next 12 months.

[0001234452-17-000154:notes:82]
The Company is subject to income taxes in the United States and numerous foreign jurisdictions and is currently under examination by the United States and various other tax authorities worldwide, most notably in countries where the Company earns a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds. As of June 25, 2017, the Company believes that adequate amounts have been reserved based on facts known. The Company continually assesses the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known, which may have a negative impact on the Company’s results of operations.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001234452-17-000154:notes:83]
At June 25, 2017, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001234452-17-000154:notes:84]
| Years to Maturity |  |  |  |  |
| Less Than One Year |  | One to Five Years |  | Five to Ten Years |  | Greater Than Ten Years |  | No Single Maturity Date |  | Total |
| $ | 9,705 |  |  | $ | 9,910 |  |  | $ | 1,046 |  |  | $ | 1 |  |  | $ | 1,444 |  |  | $ | 22,106 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001234452-17-000154:notes:85]
Marketable Securities

[0001234452-17-000154:notes:86]
Marketable securities were comprised as follows (in millions):

[0001234452-17-000154:notes:87]
|  | Current |  | Noncurrent |
|  | June 25, 2017 |  | September 25, 2016 |  | June 25, 2017 |  | September 25, 2016 |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 2,738 |  |  | $ | 1,116 |  |  | $ | 101 |  |  | $ | 1,099 |  |
| Corporate bonds and notes | 2,769 |  |  | 10,159 |  |  | 15,053 |  |  | 8,584 |  |
| Mortgage- and asset-backed and auction rate securities | 104 |  |  | 1,363 |  |  | 894 |  |  | 534 |  |
| Equity and preferred securities and equity funds | 32 |  |  | 64 |  |  | — |  |  | 1,682 |  |
| Debt funds | 106 |  |  | — |  |  | 341 |  |  | 1,803 |  |
| Total available-for-sale | 5,749 |  |  | 12,702 |  |  | 16,389 |  |  | 13,702 |  |
| Time deposits | 205 |  |  | — |  |  | 500 |  |  | — |  |
| Total marketable securities | $ | 5,954 |  |  | $ | 12,702 |  |  | $ | 16,889 |  |  | $ | 13,702 |  |

[0001234452-17-000154:notes:88]
At June 25, 2017, marketable securities also included $705 million of time deposits with original maturities that range from 91 to 181 days.

[0001234452-17-000154:notes:89]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities and auction rate securities.

[0001234452-17-000154:notes:90]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001234452-17-000154:notes:91]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| June 25, 2017 | $ | 119 |  |  | $ | (8 | ) |  | $ | 111 |  |
| June 26, 2016 | 62 |  |  | (8 | ) |  | 54 |  |
| For the nine months ended |  |  |  |  |  |
| June 25, 2017 | $ | 422 |  |  | $ | (116 | ) |  | $ | 306 |  |
| June 26, 2016 | 146 |  |  | (30 | ) |  | 116 |  |

[0001234452-17-000154:notes:92]
Available-for-sale securities were comprised as follows (in millions):

[0001234452-17-000154:notes:93]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| June 25, 2017 |  |  |  |  |  |  |  |
| Equity securities | $ | 5 |  |  | $ | 27 |  |  | $ | — |  |  | $ | 32 |  |
| Debt securities (including debt funds) | 21,981 |  |  | 136 |  |  | (11 | ) |  | 22,106 |  |
|  | $ | 21,986 |  |  | $ | 163 |  |  | $ | (11 | ) |  | $ | 22,138 |  |
| September 25, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,554 |  |  | $ | 204 |  |  | $ | (12 | ) |  | $ | 1,746 |  |
| Debt securities (including debt funds) | 24,363 |  |  | 388 |  |  | (93 | ) |  | 24,658 |  |
|  | $ | 25,917 |  |  | $ | 592 |  |  | $ | (105 | ) |  | $ | 26,404 |  |

[0001234452-17-000154:notes:94]
The following table shows the gross unrealized losses and fair values of the Company’s investments in individual securities that are classified as available-for-sale and have been in a continuous unrealized loss position deemed to be temporary for less than 12 months and for more than 12 months, aggregated by investment category (in millions):

[0001234452-17-000154:notes:95]
|  | June 25, 2017 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 205 |  |  | $ | (3 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 1,680 |  |  | (8 | ) |  | 5 |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 51 |  |  | — |  |  | 41 |  |  | — |  |
|  | $ | 1,936 |  |  | $ | (11 | ) |  | $ | 46 |  |  | $ | — |  |

[0001234452-17-000154:notes:96]
|  | September 25, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 444 |  |  | $ | (5 | ) |  | $ | 16 |  |  | $ | — |  |
| Corporate bonds and notes | 2,775 |  |  | (12 | ) |  | 1,033 |  |  | (65 | ) |
| Mortgage- and asset-backed and auction rate securities | 337 |  |  | (3 | ) |  | 211 |  |  | (2 | ) |
| Equity and preferred securities and equity funds | 312 |  |  | (4 | ) |  | 130 |  |  | (8 | ) |
| Debt funds | — |  |  | — |  |  | 309 |  |  | (6 | ) |
|  | $ | 3,868 |  |  | $ | (24 | ) |  | $ | 1,699 |  |  | $ | (81 | ) |

[0001234452-17-000154:notes:97]
In connection with the pending NXP transaction (Note 8), the Company has begun, and expects to continue, to divest a substantial portion of its marketable securities portfolio in order to finance, in part, that transaction. Marketable securities that were expected to be used to finance the NXP transaction were classified as noncurrent at June 25, 2017 as they are not considered available for current operations. Given the change in the Company’s intention to sell certain marketable securities, the Company recognized other-than-temporary impairment losses in the nine months ended June 25, 2017 for certain marketable securities (Note 2) and may recognize additional losses prior to the sale of such marketable securities. For the remaining available-for-sale securities, which are not expected to be sold to finance the NXP transaction, the Company concluded that the unrealized losses were temporary at June 25, 2017. Further, for debt securities and preferred stock with unrealized losses, the Company did not have the intent to sell, nor was it more likely than not that the Company would be required to sell, such securities before recovery or maturity.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001234452-17-000154:notes:98]
Recent Accounting Pronouncements. In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue as control of goods or services transfers to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The Company will adopt the new guidance in the first quarter of fiscal 2019. Two methods of adoption are permitted: (a) full retrospective adoption, meaning the standard is applied to all periods presented or (b) modified retrospective adoption, meaning the cumulative effect of applying the new guidance is recognized as an adjustment to the opening retained earnings balance. The Company currently expects the adoption of this new guidance to most significantly impact its licensing business. Specifically, the Company expects a change in the timing of revenues recognized from sales-based royalties. The Company currently recognizes sales-based royalties as revenues in the period in which such royalties are reported by licensees, which is after the conclusion of the quarter in which the licensees’ sales occur and when all other revenue recognition criteria are met. Under the new guidance, the Company will be required to estimate and recognize sales-based royalties in the period in which the associated sales occur, resulting in an acceleration of revenue recognition compared to the current method. Upon adoption of the new guidance, licenses to use portions of the Company’s intellectual property portfolio will be considered one performance obligation, and license fees will be recognized as revenues on a straight-line basis over the term of the license agreement, which is similar to the recognition of license revenues under the current guidance. The Company currently accounts for customer incentive arrangements in its licensing and chip businesses, including volume-related and other pricing rebates or cost reimbursements for marketing and other activities involving certain of the Company’s products and technologies, primarily based on the maximum potential liability. Under the new guidance, the Company expects to estimate the amount of the customer incentive. The Company does not otherwise expect the adoption of the new guidance will have a material impact on its businesses and is in the process of determining the adoption method.

[0001234452-17-000154:notes:99]
In January 2016, the FASB issued new guidance on classifying and measuring financial instruments, which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk be recognized separately in other comprehensive income. Additionally, it changes the disclosure requirements for financial instruments. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Early adoption is permitted for certain provisions. The Company does not intend to adopt any provisions of the new guidance early and is in the process of determining the effects the adoption will have on its consolidated financial statements.

[0001234452-17-000154:notes:100]
In February 2016, the FASB issued new guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease guidance. The new guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. The new guidance must be adopted using the modified retrospective approach and will be effective for the Company starting in the first quarter of fiscal 2020. Early adoption is permitted. The Company does not intend to adopt the new guidance early and is in the process of determining the effects the adoption will have on its consolidated financial statements.

[0001234452-17-000154:notes:101]
In March 2016, the FASB issued new guidance that changes the accounting for share-based payments, including income taxes, classification of awards and classification in the statement of cash flows. The new guidance will increase the number of shares an employer can withhold to cover income taxes on share-based payment awards and still qualify for the exemption to liability classification. In addition, under the new guidance, excess tax benefits or deficiencies associated with share-based payment awards will be recognized through earnings when the awards vest or settle, rather than in stockholders’ equity. As a result, subsequent to adoption, the Company’s income tax expense and associated effective tax rate will be impacted by fluctuations in stock price between the grant dates and vesting dates of equity awards. The new guidance will be effective for the Company starting in the first quarter of fiscal 2018.

[0001234452-17-000154:notes:102]
In June 2016, the FASB issued new guidance that changes the accounting for recognizing impairments of financial assets. Under the new guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The new guidance also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The new guidance will be effective for the Company starting in the first quarter of fiscal 2021. Early adoption is permitted starting in the first quarter of fiscal 2020. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.

[0001234452-17-000154:notes:103]
In August 2016, the FASB issued new guidance related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. The Company does not intend to adopt the new guidance early and is in the process of determining the effects the adoption will have on its consolidated financial statements.

[0001234452-17-000154:notes:104]
In October 2016, the FASB issued new guidance that changes the accounting for income tax effects of intra-entity transfers of assets other than inventory. Under the new guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. The Company does not intend to adopt the new guidance early and is in the process of determining the effects the adoption will have on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001234452-17-000154:notes:105]
[same as prior period, unchanged from 0001234452-17-000077:notes:101]

[0001234452-17-000154:notes:106]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 25, 2016. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 25, 2017 and June 26, 2016 included 13 weeks and 39 weeks, respectively.

[0001234452-17-000154:notes:107]
[same as prior period, unchanged from 0001234452-17-000077:notes:103]

[0001234452-17-000154:notes:108]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and the weighted-average number of common shares outstanding during the reporting period. The dilutive common share equivalents, calculated using the treasury stock method, were 12,221,000 and 13,511,000 in the three and nine months ended June 25, 2017, respectively, and 14,812,000 and 13,325,000 in the three and nine months ended June 26, 2016, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share, because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period, were 561,000 and 3,815,000 in the three and nine months ended June 25, 2017, respectively, and 1,378,000 and 3,150,000 in the three and nine months ended June 26, 2016, respectively.

[0001234452-17-000154:notes:109]
[same as prior period, unchanged from 0001234452-17-000077:notes:104]

[0001234452-17-000154:notes:110]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | June 25, 2017 |  | June 26, 2016 |
| Cost of equipment and services revenues | $ | 10 |  |  | $ | 10 |  |  | $ | 30 |  |  | $ | 31 |  |
| Research and development | 147 |  |  | 152 |  |  | 455 |  |  | 478 |  |
| Selling, general and administrative | 70 |  |  | 73 |  |  | 227 |  |  | 221 |  |
| Share-based compensation expense before income taxes | 227 |  |  | 235 |  |  | 712 |  |  | 730 |  |
| Related income tax benefit | (28 | ) |  | (38 | ) |  | (113 | ) |  | (126 | ) |
|  | $ | 199 |  |  | $ | 197 |  |  | $ | 599 |  |  | $ | 604 |  |

[0001234452-17-000154:notes:111]
At June 25, 2017, total unrecognized compensation expense related to nonvested restricted stock units granted prior to that date was $1.1 billion, which is expected to be recognized over a weighted-average period of 1.8 years.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001234452-17-000154:notes:112]
[same as prior period, unchanged from 0001234452-17-000077:notes:109]

[0001234452-17-000154:notes:113]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | June 25, 2017 |  | June 26, 2016 |
| Cost of revenues | $ | 139 |  |  | $ | 99 |  |  | $ | 330 |  |  | $ | 345 |  |
| Research and development expenses | 3 |  |  | 2 |  |  | 18 |  |  | 7 |  |
| Selling, general and administrative expenses | 77 |  |  | 23 |  |  | 195 |  |  | 79 |  |

[0001234452-17-000154:notes:114]
[same as prior period, unchanged from 0001234452-17-000077:notes:107]

[0001234452-17-000154:notes:115]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | June 25, 2017 |  | June 26, 2016 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 79 |  |  | $ | 142 |  |  | $ | 218 |  |  | $ | 274 |  |
| BlackBerry arbitration (Note 6) | 12 |  |  | — |  |  | (962 | ) |  | — |  |
| Intersegment eliminations | — |  |  | (1 | ) |  | — |  |  | (2 | ) |
|  | $ | 91 |  |  | $ | 141 |  |  | $ | (744 | ) |  | $ | 272 |  |
| EBT |  |  |  |  |  |  |  |
| BlackBerry arbitration (Note 6) | $ | 12 |  |  | $ | — |  |  | $ | (962 | ) |  | $ | — |  |
| Unallocated cost of revenues | (188 | ) |  | (130 | ) |  | (402 | ) |  | (397 | ) |
| Unallocated research and development expenses | (257 | ) |  | (199 | ) |  | (803 | ) |  | (602 | ) |
| Unallocated selling, general and administrative expenses | (197 | ) |  | (121 | ) |  | (481 | ) |  | (373 | ) |
| Unallocated other expenses, net | (9 | ) |  | (30 | ) |  | (962 | ) |  | (110 | ) |
| Unallocated interest expense | (130 | ) |  | (74 | ) |  | (325 | ) |  | (217 | ) |
| Unallocated investment and other income, net | 239 |  |  | 185 |  |  | 646 |  |  | 388 |  |
| Nonreportable segments | (96 | ) |  | (47 | ) |  | (283 | ) |  | (286 | ) |
|  | $ | (626 | ) |  | $ | (416 | ) |  | $ | (3,572 | ) |  | $ | (1,597 | ) |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001234452-17-000154:notes:116]
Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity in the nine months ended June 25, 2017 were as follows (in millions):

[0001234452-17-000154:notes:117]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Total Accumulated Other Comprehensive Income |
| Balance at September 25, 2016 | $ | (161 | ) |  | $ | 6 |  |  | $ | 532 |  |  | $ | 51 |  |  | $ | 428 |  |
| Other comprehensive income (loss) before reclassifications | 128 |  |  | 6 |  |  | (104 | ) |  | (43 | ) |  | (13 | ) |
| Reclassifications from accumulated other comprehensive (loss) income | (1 | ) |  | 11 |  |  | (129 | ) |  | (5 | ) |  | (124 | ) |
| Other comprehensive income (loss) | 127 |  |  | 17 |  |  | (233 | ) |  | (48 | ) |  | (137 | ) |
| Balance at June 25, 2017 | $ | (34 | ) |  | $ | 23 |  |  | $ | 299 |  |  | $ | 3 |  |  | $ | 291 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001234452-17-000154:notes:118]
[same as prior period, unchanged from 0001234452-17-000077:notes:113]

[0001234452-17-000154:notes:119]
|  | QCT |  | QTL |  | QSI |  | ReconcilingItems |  | Total |
| For the three months ended |  |  |  |  |  |  |  |  |  |
| June 25, 2017 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 4,052 |  |  | $ | 1,172 |  |  | $ | 56 |  |  | $ | 91 |  |  | $ | 5,371 |  |
| EBT | 575 |  |  | 854 |  |  | 55 |  |  | (626 | ) |  | 858 |  |
| June 26, 2016 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 3,853 |  |  | $ | 2,038 |  |  | $ | 12 |  |  | $ | 141 |  |  | $ | 6,044 |  |
| EBT | 365 |  |  | 1,749 |  |  | (5 | ) |  | (416 | ) |  | 1,693 |  |
| For the nine months ended |  |  |  |  |  |  |  |  |  |
| June 25, 2017 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 11,829 |  |  | $ | 5,232 |  |  | $ | 70 |  |  | $ | (744 | ) |  | $ | 16,387 |  |
| EBT | 1,774 |  |  | 4,346 |  |  | 38 |  |  | (3,572 | ) |  | 2,586 |  |
| June 26, 2016 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 11,285 |  |  | $ | 5,780 |  |  | $ | 33 |  |  | $ | 272 |  |  | $ | 17,370 |  |
| EBT | 1,125 |  |  | 4,945 |  |  | 400 |  |  | (1,597 | ) |  | 4,873 |  |
| Total assets |  |  |  |  |  |  |  |  |  |
| June 25, 2017 | $ | 3,656 |  |  | $ | 1,814 |  |  | $ | 975 |  |  | $ | 57,934 |  |  | $ | 64,379 |  |
| September 25, 2016 | 2,995 |  |  | 644 |  |  | 910 |  |  | 47,810 |  |  | 52,359 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001234452-17-000154:notes:120]
Changes in stockholders’ equity in the nine months ended June 25, 2017 were as follows (in millions):

[0001234452-17-000154:notes:121]
|  | Qualcomm Stockholders’ Equity |  | Noncontrolling Interests |  | Total Stockholders’ Equity |
| Balance at September 25, 2016 | $ | 31,778 |  |  | $ | (10 | ) |  | $ | 31,768 |  |
| Net income (loss) | 2,297 |  |  | (1 | ) |  | 2,296 |  |
| Other comprehensive loss | (137 | ) |  | — |  |  | (137 | ) |
| Common stock issued under employee benefit plans and related tax benefits | 345 |  |  | — |  |  | 345 |  |
| Share-based compensation | 758 |  |  | — |  |  | 758 |  |
| Tax withholdings related to vesting of share-based payments | (263 | ) |  | — |  |  | (263 | ) |
| Dividends | (2,457 | ) |  | — |  |  | (2,457 | ) |
| Stock repurchases | (1,027 | ) |  | — |  |  | (1,027 | ) |
| Balance at June 25, 2017 | $ | 31,294 |  |  | $ | (11 | ) |  | $ | 31,283 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001234452-17-000154:notes:122]
[same as prior period, unchanged from 0001234452-17-000077:notes:117]

[0001234452-17-000154:notes:123]
[same as prior period, unchanged from 0001234452-17-000077:notes:118]

[0001234452-17-000154:notes:124]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense; certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. Additionally, starting with acquisitions in the second quarter of fiscal 2017, unallocated charges include recognition of the depreciation related to the step-up of property, plant and equipment to fair value. Such charges related to acquisitions that were completed prior to the second quarter of fiscal 2017 continue to be allocated to the respective segment, and such amounts are not material. All of the costs related to the initial research of 5G (fifth generation) technology are included in unallocated corporate research and development expenses, whereas initial costs related to the research of 3G (third generation) and 4G (fourth generation) technology were recorded in both the QCT segment and unallocated corporate research and development expenses based on the nature of the activity. Fiscal 2016 results have not been revised as such costs were incurred prior to fiscal 2014.

[0001234452-17-000154:notes:125]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets are comprised primarily of certain non-marketable equity instruments and other investments and a receivable from the sale of wireless spectrum in fiscal 2016 (Note 2). The increase in QCT segment assets resulted primarily from the Company’s recently formed RF360 Holdings joint venture in the second quarter of fiscal 2017 (Note 8). The increase in QTL segment assets was due to an increase in accounts receivable (Note 2). Total segment assets differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable securities, property, plant and equipment, deferred tax assets, intangible assets and assets of nonreportable segments.

[0001234452-17-000154:notes:126]
The impact to revenues related to the BlackBerry arbitration decision (Note 6) was not allocated to QTL in the Company’s management reports because it will not be considered in evaluating segment results. Unallocated other expenses in the nine months ended June 25, 2017 were comprised of the fine imposed by the KFTC (Note 6) and restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan, which was substantially implemented in fiscal 2016 (Note 2). Unallocated other expenses in the nine months ended June 26, 2016 were comprised of net restructuring and restructuring-related charges associated with the Company’s Strategic Realignment Plan.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001234452-17-000154:notes:127]
[same as prior period, unchanged from 0001234452-17-000077:notes:122]

[0001234452-17-000154:notes:128]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity in the nine months ended June 25, 2017 were as follows (in millions):

[0001234452-17-000154:notes:129]
In the nine months ended June 25, 2017, the Company entered into U.S. Treasury forward starting interest rate swaps in anticipation of its May 2017 debt offering (Note 5), which were designated as cash flow hedges. This resulted in the deferral of losses of $51 million in accumulated other comprehensive income, which will be recognized ratably over the 10- and 30-year terms of the underlying notes associated with the swaps. Reclassifications from accumulated other comprehensive income related to available-for-sale securities of $71 million and $118 million in the three and nine months ended June 25, 2017, respectively, and $22 million and $5 million in the three and nine months ended June 26, 2016, respectively, were recorded in investment and other income, net (Note 2). Reclassifications from accumulated other comprehensive income related to foreign currency translation losses were $15 million and $21 million in the three and nine months ended June 26, 2016 and were recorded in selling, general and administrative expenses and other operating expenses.

[0001234452-17-000154:notes:130]
Stock Repurchase Program. On March 9, 2015, the Company announced a stock repurchase program authorizing it to repurchase up to $15 billion of the Company’s common stock. The stock repurchase program has no expiration date. In the nine months ended June 25, 2017 and June 26, 2016, the Company repurchased and retired 16,669,000 and 70,168,000 shares for $1.0 billion and $3.7 billion, respectively, before commissions. At June 25, 2017, $2.0 billion remained authorized for repurchase under the Company’s stock repurchase program.

[0001234452-17-000154:notes:131]
Dividends. On July 13, 2017, the Company announced a cash dividend of $0.57 per share on the Company’s common stock, payable on September 20, 2017 to stockholders of record as of the close of business on August 30, 2017. In the nine months ended June 25, 2017 and June 26, 2016, dividends charged to retained earnings were as follows (in millions, except per share data):
