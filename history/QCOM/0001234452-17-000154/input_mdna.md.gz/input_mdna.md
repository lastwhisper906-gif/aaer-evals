# QCOM MD&A — 0001234452-17-000154


## mdna

[0001234452-17-000154:mdna:1]
[same as prior period, unchanged from 0001234452-17-000077:mdna:1]

[0001234452-17-000154:mdna:2]
[same as prior period, unchanged from 0001234452-17-000077:mdna:2]

[0001234452-17-000154:mdna:3]
This Quarterly Report (including, but not limited to, this section regarding Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements, including, but not limited to, statements regarding industry trends and dynamics; challenges and opportunities related to our semiconductor and licensing businesses; our proposed acquisition of NXP Semiconductors N.V.; current and future legal proceedings or actions of governmental or quasi governmental bodies or standards or industry organizations; and our future business, investments, financial condition, results of operations and prospects. Additionally, statements concerning other future matters, such as the development of new products, enhancements of technologies, industry or regional trends, consumer demand, sales or price levels, challenges to our business and/or business model, capital expenditures, investments in research and development, strategic investments and acquisitions and other statements regarding matters that are not historical, are forward-looking statements. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001234452-17-000154:mdna:4]
[same as prior period, unchanged from 0001234452-17-000077:mdna:4]

[0001234452-17-000154:mdna:5]
Revenues for the third quarter of fiscal 2017 were $5.4 billion, a decrease of 11% compared to the year ago quarter, with net income attributable to Qualcomm of $866 million, a decrease of 40% compared to the year ago quarter.

[0001234452-17-000154:mdna:6]
| • | We shipped approximately 187 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, a decrease of 7% compared to approximately 201 million MSM integrated circuits in the year ago quarter. Despite the decline in MSM shipments, QCT’s revenues increased compared to the year ago quarter primarily due to an increase in revenues related to radio frequency front end (RFFE) products, primarily from our recently formed RF360 Holdings joint venture, and connectivity shipments, partially offset by a decline in share at a large customer. |

[0001234452-17-000154:mdna:7]
| • | QTL revenues and EBT in the third quarter of fiscal 2017 were negatively impacted as a result of actions taken by Apple’s contract manufacturers, who did not fully report and did not pay royalties due on sales of Apple products, as well as the previously disclosed dispute with another licensee, who did not report or pay royalties due in the third quarter of fiscal 2017. Revenues related to the products of Apple’s contract manufacturers and the other licensee in dispute comprised approximately $700 million in the year ago quarter. QTL revenues in the third quarter of fiscal 2016 included the recognition of previously deferred royalty revenues associated with the dismissal of arbitration with LG Electronics, Inc. and higher royalty revenues associated with devices sold in prior periods relative to the third quarter of fiscal 2017.(1) |

[0001234452-17-000154:mdna:8]
In May 2017, we issued an aggregate principal amount of $11.0 billion in nine tranches of unsecured floating- and fixed-rate notes, with maturity dates starting in 2019 through 2047 and effective interest rates between 1.68% and 4.47%. The proceeds are intended to be used to finance, in part, our proposed acquisition of NXP and other related transactions and for general corporate purposes.

[0001234452-17-000154:mdna:9]
Against this backdrop, the following recent developments occurred in the third quarter of fiscal 2017 with respect to key elements of our industry:

[0001234452-17-000154:mdna:10]
| • | Worldwide cellular connections grew sequentially by approximately 1% to reach approximately 7.7 billion.(2) |

[0001234452-17-000154:mdna:11]
29

[0001234452-17-000154:mdna:12]
| • | Worldwide 3G/4G connections (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) grew sequentially by approximately 3% to approximately 4.5 billion, which was approximately 59% of total cellular connections.(2) |

[0001234452-17-000154:mdna:13]
| (1) | As a result of recent actions taken by Apple’s contract manufacturers and the other licensee in dispute, we currently do not believe total reported device sales is meaningful to measure our QTL business, and therefore, we are not providing such metric for the third quarter of fiscal 2017. |

[0001234452-17-000154:mdna:14]
| (2) | According to GSMA Intelligence estimates as of July 17, 2017 for the quarter ended March 31, 2017. |

[0001234452-17-000154:mdna:15]
[same as prior period, unchanged from 0001234452-17-000077:mdna:17]

[0001234452-17-000154:mdna:16]
[same as prior period, unchanged from 0001234452-17-000077:mdna:18]

[0001234452-17-000154:mdna:17]
[same as prior period, unchanged from 0001234452-17-000077:mdna:19]

[0001234452-17-000154:mdna:18]
QCT is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in wireless voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products are sold and its system software is licensed to manufacturers that use our products in mobile devices, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards and infrastructure equipment, broadband gateway equipment and other consumer electronic devices. Our MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Snapdragon mobile platforms and processors and LTE modems, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon mobile platforms and processors provide advanced application and graphics processing capabilities. Through our joint venture with TDK, RF360 Holdings, QCT also offers an expanded portfolio of radio frequency front-end products, which complements its current product offerings for mobile devices and IoT applications. QCT’s system software helps enable the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits.

[0001234452-17-000154:mdna:19]
QCT primarily utilizes a fabless production model, which means that we generally do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Integrated circuits are die cut from silicon wafers that have completed the package assembly and test manufacturing processes. Other than RF360 Holdings , which uses certain internal fabrication facilities to manufacture RFFE modules and RF filter acoustic products, we primarily rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits based primarily on our proprietary designs and test programs. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Turnkey is when our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services, such as wafer bump, probe, assembly and the majority of our final test requirements. The manufacturing operations of RF360 Holdings consist of front-end and back-end processes. The front-end processes primarily take place at manufacturing facilities located in Germany and Singapore and involve the imprinting of substrate silicon wafers with the circuitry required for semiconductors to function (also known as wafer fabrication). The back-end processes involve the assembly, packaging and test of semiconductors to prepare RFFE modules and RF filter acoustic products for distribution. The back-end manufacturing facilities are located in Germany, China and Singapore.

[0001234452-17-000154:mdna:20]
QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD and/or LTE standards and their derivatives. We have historically licensed our cellular standard-essential patents together with other Qualcomm patents that may be useful to such licensed products because licensees typically have desired to obtain the commercial benefits of receiving such broad patent rights from us. However, we also have licensed only our cellular standard-essential patents to

[0001234452-17-000154:mdna:21]
[same as prior period, unchanged from 0001234452-17-000077:mdna:34]

[0001234452-17-000154:mdna:22]
certain licensees who have requested such licenses. In addition, in connection with our resolution with the China National Development and Reform Commission (NDRC) in China, our practice in China since 2015 is to offer licenses to our 3G and 4G standard-essential Chinese patents for devices sold for use in China separately from licenses to our other patents.

[0001234452-17-000154:mdna:23]
QTL licensing revenues include license fees and royalties based on sales by licensees of products incorporating or using our intellectual property. License fees are fixed amounts paid in one or more installments. License fees are recognized over the estimated period of benefit of the license to the licensee, typically 5 to 15 years. Royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit running royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops, which in general, effectively provide for a maximum running royalty amount per device (i.e., the royalty caps limit the running royalties due on a per unit basis). QTL recognizes royalty revenues based on royalties reported by licensees and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. The vast majority of QTL revenues were generated through our licensees’ sales of CDMA2000-, WCDMA-based and LTE-based products (including 3G and 4G multi-mode devices), such as feature phones and smartphones.

[0001234452-17-000154:mdna:24]
[same as prior period, unchanged from 0001234452-17-000077:mdna:26]

[0001234452-17-000154:mdna:25]
[same as prior period, unchanged from 0001234452-17-000077:mdna:27]

[0001234452-17-000154:mdna:26]
[same as prior period, unchanged from 0001234452-17-000077:mdna:28]

[0001234452-17-000154:mdna:27]
[same as prior period, unchanged from 0001234452-17-000077:mdna:29]

[0001234452-17-000154:mdna:28]
[same as prior period, unchanged from 0001234452-17-000077:mdna:30]

[0001234452-17-000154:mdna:29]
| • | On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings, B.V., an indirect, wholly owned subsidiary of QUALCOMM Incorporated, will acquire NXP Semiconductors N.V. Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration to be paid to NXP’s shareholders of $38 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products. The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions, including the tender of at least 80% of the issued and outstanding common shares of NXP in the offer (provided that the minimum tender threshold may be reduced to a percentage not less than 70% with the prior written consent of NXP). We intend to fund the transaction with cash generated from the recent debt offering as well as cash held by our foreign entities and use of a Term Loan, which we expect to draw on at close. We expect that this acquisition will require us to devote significant resources and management time and attention prior to close and utilize a substantial portion of our cash, cash equivalents and marketable securities. |

[0001234452-17-000154:mdna:30]
| • | Regulatory authorities in certain jurisdictions continue to investigate our business practices, and other regulatory authorities may do so in the future. An unfavorable resolution of one or more of these matters could have a material adverse effect on our business with remedies that include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Additionally, certain of our direct and indirect customers and licensees, including Apple Inc., have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, including monetary damages. These activities may also require the investment of significant management time and attention, and we expect will result in increased legal costs. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” elsewhere in this Quarterly Report. |

[0001234452-17-000154:mdna:31]
| • | We are currently in dispute with Apple surrounding what we believe is an attempt by Apple to reduce the amount of royalties that its contract manufacturers are required to pay to us for use of our intellectual property. QTL revenues and EBT in the third quarter of fiscal 2017 were negatively impacted as a result of actions taken by Apple’s contract manufacturers, who did not fully report and did not pay royalties due on sales of Apple products. We have taken action against Apple’s contract manufacturers to compel such licensees to pay the required royalties. Additionally, QTL royalties and EBT in the third quarter of fiscal 2017 were negatively impacted by the previously disclosed dispute with another licensee, who did not report or pay royalties due in the third quarter of fiscal 2017. We expect these licensees will continue to take such actions in the future, resulting in a negative impact on our future royalty revenues, as well as our financial condition, results of operations and cash flows until the respective disputes are resolved. |

[0001234452-17-000154:mdna:32]
| • | We continue to believe that certain licensees, particularly in China, are not fully complying with their contractual obligations to report their sales of licensed products to us, and certain companies, including unlicensed companies, particularly in emerging regions, including China, are delaying execution of new license agreements. We have made substantial progress in reaching agreements with many companies, primarily in China. However, negotiations with certain licensees and unlicensed companies are ongoing. We believe that the conclusion of new agreements with these companies will result in improved reporting by these licensees, including with respect to sales of three-mode devices (i.e., devices that implement GSM, TD-SCDMA and LTE-TDD) sold in China. Additionally, we believe our increased efforts in the areas of compliance will improve reporting, but will also result in increased costs to the business. Litigation and/or other actions, such as those recently taken against Apple and its contract manufacturers, may be necessary to compel licensees to report and pay the required royalties for sales they have not previously reported and/or to compel unlicensed companies to execute licenses. |

[0001234452-17-000154:mdna:33]
| • | We expect our business, particularly QCT, to continue to be impacted by industry dynamics, including: |

[0001234452-17-000154:mdna:34]
[same as prior period, unchanged from 0001234452-17-000077:mdna:37]

[0001234452-17-000154:mdna:35]
| • | Decisions by companies to utilize their own internally-developed integrated circuit products; |

[0001234452-17-000154:mdna:36]
| • | Decisions by certain companies to utilize our competitors’ integrated circuit products in all or a portion of their devices. For example, commencing with the iPhone 7 (which was released in September 2016), we are no longer the sole supplier of modems for new iPhone product launches, as Apple utilizes modems from one of our competitors in a portion of such devices. We expect that in the future Apple will utilize our competitors’ modems in a portion of (or potentially all) iPhones. Accordingly, QCT revenues from modem sales for iPhones have declined and may continue to decline, in part depending on the extent of Apple’s utilization of competitors’ modems and the mix of the various versions that are sold. Overall QCT revenues, as well as profitability, may similarly decline unless offset by sales of integrated circuit products to other customers, including those outside of traditional cellular industries, such as the Internet of Things (IoT), automotive and computing. Apple’s dual sourcing does not impact our licensing revenues since our licensing revenues from Apple products are not dependent upon whether such products include our chipsets; |

[0001234452-17-000154:mdna:37]
[same as prior period, unchanged from 0001234452-17-000077:mdna:39]

[0001234452-17-000154:mdna:38]
[same as prior period, unchanged from 0001234452-17-000077:mdna:40]

[0001234452-17-000154:mdna:39]
[same as prior period, unchanged from 0001234452-17-000077:mdna:55]

[0001234452-17-000154:mdna:40]
| • | Consumer demand for 3G/4G smartphone products is increasing in emerging regions driven by availability of lower-tier 3G/4G devices. We expect the ongoing rollout of 4G services in emerging regions will encourage competition and growth, bringing the benefits of 3G/4G LTE multimode to consumers. |

[0001234452-17-000154:mdna:41]
| • | We continue to invest significant resources toward advancements in 4G LTE and 5G technologies, OFDM-based WLAN technologies, wireless baseband chips, our converged computing/communications (Snapdragon) chips, radio frequency front-end (RFFE), connectivity, graphics, audio and video codecs, multimedia products and software, which contribute to the expansion of our intellectual property portfolio. We are also investing in targeted opportunities that leverage our existing technical and business expertise to deploy new business models and enter and/or expand into new industry segments, such as products for: automotive; the Internet of Things (IoT), including the connected home, smart cities and wearables; data center; networking; computing; mobile health; and machine learning, including robotics, among others. |

[0001234452-17-000154:mdna:42]
[same as prior period, unchanged from 0001234452-17-000077:mdna:43]

[0001234452-17-000154:mdna:43]
[same as prior period, unchanged from 0001234452-17-000077:mdna:44]

[0001234452-17-000154:mdna:44]
[same as prior period, unchanged from 0001234452-17-000077:mdna:45]

[0001234452-17-000154:mdna:45]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | Change |  | June 25, 2017 |  | June 26, 2016 |  | Change |
| Equipment and services | $ | 4,121 |  |  | $ | 3,875 |  |  | $ | 246 |  |  | $ | 11,949 |  |  | $ | 11,311 |  |  | $ | 638 |  |
| Licensing | 1,250 |  |  | 2,169 |  |  | (919 | ) |  | 4,438 |  |  | 6,059 |  |  | (1,621 | ) |
|  | $ | 5,371 |  |  | $ | 6,044 |  |  | $ | (673 | ) |  | $ | 16,387 |  |  | $ | 17,370 |  |  | $ | (983 | ) |

[0001234452-17-000154:mdna:46]
The increases in equipment and services revenues in the third quarter and first nine months of fiscal 2017 were primarily due to increases in QCT revenues. The decrease in licensing revenues in the third quarter of fiscal 2017 was primarily due to a decrease in QTL revenues. The decrease in licensing revenues in the first nine months of fiscal 2017 was primarily the result of a reduction to licensing revenues of $940 million related to the BlackBerry arbitration and a decrease in QTL revenues.

[0001234452-17-000154:mdna:47]
| Costs and Expenses (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | Change |  | June 25, 2017 |  | June 26, 2016 |  | Change |
| Cost of revenues | $ | 2,488 |  |  | $ | 2,534 |  |  | $ | (46 | ) |  | $ | 7,140 |  |  | $ | 7,210 |  |  | $ | (70 | ) |
| Gross margin | 54 | % |  | 58 | % |  |  |  | 56 | % |  | 58 | % |  |  |

[0001234452-17-000154:mdna:48]
Margin percentage decreased in the third quarter and first nine months of fiscal 2017 primarily due to the decreases in higher margin QTL licensing revenues as a proportion of total revenues, partially offset by increases in QCT margin percentages. The margin percentage in the first nine months of fiscal 2017 was also negatively impacted by the reduction to licensing revenues related to the BlackBerry arbitration. Our margin percentage may fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors, including the outcome of litigation and/or other regulatory matters.

[0001234452-17-000154:mdna:49]
[same as prior period, unchanged from 0001234452-17-000077:mdna:62]

[0001234452-17-000154:mdna:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | Change |  | June 25, 2017 |  | June 26, 2016 |  | Change |
| Research and development | $ | 1,391 |  |  | $ | 1,268 |  |  | $ | 123 |  |  | $ | 4,087 |  |  | $ | 3,922 |  |  | $ | 165 |  |
| % of revenues | 26 | % |  | 21 | % |  |  |  | 25 | % |  | 23 | % |  |  |
| Selling, general, and administrative | $ | 710 |  |  | $ | 620 |  |  | $ | 90 |  |  | $ | 1,917 |  |  | $ | 1,817 |  |  | $ | 100 |  |
| % of revenues | 13 | % |  | 10 | % |  |  |  | 12 | % |  | 10 | % |  |  |
| Other | $ | 9 |  |  | $ | 30 |  |  | $ | (21 | ) |  | $ | 962 |  |  | $ | (270 | ) |  | $ | 1,232 |  |

[0001234452-17-000154:mdna:51]
The dollar increases in research and development expenses in the third quarter and first nine months of fiscal 2017 were primarily attributable to increases of $153 million and $193 million, respectively, in costs related to the development of integrated circuit technologies, including 5G (fifth generation) technology and RF technologies from our recently formed RF360 joint venture, and related software products, partially offset by cost decreases driven by actions initiated under our Strategic Realignment Plan, which was substantially implemented in fiscal 2016.

[0001234452-17-000154:mdna:52]
Selling, general and administrative expenses in the third quarter and first nine months of fiscal 2017 were impacted by the results of our recently formed RF360 joint venture. The dollar increase in selling, general and administrative expenses in the third quarter of fiscal 2017 was primarily attributable to increases of $49 million in professional services fees, primarily related to third-party acquisition and integration services, and $26 million in employee-related expenses. The dollar increase in selling, general and administrative expenses in the first nine months of fiscal 2017 was primarily attributable to an increase of $102 million in professional services fees, primarily related to third-party acquisition and integration services.

[0001234452-17-000154:mdna:53]
Other expenses in the nine months ended June 25, 2017 consisted of a $927 million charge related to the KFTC fine, including related foreign currency losses, and $35 million in restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan. Other expenses in the third quarter of fiscal 2016 were attributable to $30 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan. Other income in the first nine months of fiscal 2016 was primarily attributable to a $380 million gain on the sale of wireless spectrum, partially offset by net charges related to our Strategic Realignment Plan, which included $158 million in restructuring and restructuring-related charges, partially offset by a $48 million gain on the sale of our business that provided augmented reality applications.

[0001234452-17-000154:mdna:54]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | Change |  | June 25, 2017 |  | June 26, 2016 |  | Change |
| Interest expense | $ | 133 |  |  | $ | 75 |  |  | $ | 58 |  |  | $ | 330 |  |  | $ | 221 |  |  | $ | 109 |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 147 |  |  | $ | 156 |  |  | $ | (9 | ) |  | $ | 466 |  |  | $ | 451 |  |  | $ | 15 |  |
| Net realized gains on marketable securities | 124 |  |  | 56 |  |  | 68 |  |  | 330 |  |  | 99 |  |  | 231 |  |
| Net realized gains on other investments | 15 |  |  | 13 |  |  | 2 |  |  | 45 |  |  | 43 |  |  | 2 |  |
| Impairment losses on marketable securities and other investments | (15 | ) |  | (33 | ) |  | 18 |  |  | (163 | ) |  | (138 | ) |  | (25 | ) |
| Equity in net losses of investees | (31 | ) |  | (18 | ) |  | (13 | ) |  | (42 | ) |  | (49 | ) |  | 7 |  |
| Net losses on foreign currency transactions | (26 | ) |  | — |  |  | (26 | ) |  | (26 | ) |  | — |  |  | (26 | ) |
| Net gains (losses) on derivative instruments | 4 |  |  | 2 |  |  | 2 |  |  | 25 |  |  | (3 | ) |  | 28 |  |
|  | $ | 218 |  |  | $ | 176 |  |  | $ | 42 |  |  | $ | 635 |  |  | $ | 403 |  |  | $ | 232 |  |

[0001234452-17-000154:mdna:55]
The increases in interest expense in the third quarter and first nine months of fiscal 2017 were primarily attributable to the issuance of an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes in May 2017 and fees related to the Bridge and Term Loan Facilities entered into during the first quarter of fiscal 2017.

[0001234452-17-000154:mdna:56]
The increases in net realized gains on marketable securities in the third quarter and first nine months of fiscal 2017 were primarily attributable to certain marketable securities that we sold to fund, in part, our proposed acquisition of NXP Semiconductors N.V. The net losses on foreign currency transactions in the third quarter and first nine months of fiscal 2017 are primarily attributable to the impact of currency exchange rate movements on certain monetary assets and liabilities of our recently formed RF360 Holdings joint venture.

[0001234452-17-000154:mdna:57]
| Income Tax Benefit (Expense) (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | Change |  | June 25, 2017 |  | June 26, 2016 |  | Change |
| Income tax benefit (expense) | $ | 7 |  |  | $ | (250 | ) |  | $ | 257 |  |  | $ | (290 | ) |  | $ | (770 | ) |  | $ | 480 |  |
| Effective tax rate | (1 | %) |  | 15 | % |  | (16 | %) |  | 11 | % |  | 16 | % |  | (5 | %) |

[0001234452-17-000154:mdna:58]
The following table summarizes the primary factors that caused our effective tax rates for the third quarter and first nine months of fiscal 2017 and 2016 to be less than the United States federal statutory rate:

[0001234452-17-000154:mdna:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | June 25, 2017 |  | June 26, 2016 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |  | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (41 | %) |  | (14 | %) |  | (27 | %) |  | (15 | %) |
| Benefits related to the research and development tax credit | (3 | %) |  | (1 | %) |  | (2 | %) |  | (3 | %) |
| Worthless stock deduction of domestic subsidiary | — |  |  | (6 | %) |  | — |  |  | (2 | %) |
| Nondeductible charge related to the KFTC investigation | 5 | % |  | — |  |  | 4 | % |  | — |  |
| Other | 3 | % |  | 1 | % |  | 1 | % |  | 1 | % |
| Effective tax rate | (1 | %) |  | 15 | % |  | 11 | % |  | 16 | % |

[0001234452-17-000154:mdna:60]
The effective tax rate of 1% benefit for the third quarter of fiscal 2017 was less than the estimated annual effective tax rate of 11% provision primarily resulting from the reduction in the third quarter of fiscal 2017 to our expected United States revenues primarily related to decreased royalty revenues from Apple’s contract manufacturers. The estimated annual effective tax rate of 11% for fiscal 2017 is less than the 17% effective income tax rate for fiscal 2016, which is impacted by lower estimated United States revenues related to decreased royalty revenues from Apple’s contract manufacturers and the BlackBerry arbitration. Additionally, in the first nine months of fiscal 2017, we recorded a $927 million charge related to the KFTC imposed fine, which is not deductible for tax purposes and is attributable to both the United States and a foreign jurisdiction. The estimated annual effective tax rate of 11% for fiscal 2017 also reflects the increase in our Singapore tax rate as a result of the expiration of certain of our tax incentives in March 2017, which is partially offset by tax benefits resulting from the increase in our Singapore tax rate that will be in effect when certain deferred tax assets are scheduled to reverse. The annual effective tax rate of 17% for fiscal 2016 reflected a $101 million tax benefit recorded discretely in the third quarter of fiscal 2016 resulting from a worthless stock deduction on a domestic subsidiary of one of our former display businesses and a $79 million benefit recorded discretely in the first quarter of fiscal 2016 related to fiscal 2015 resulting from the retroactive and permanent reinstatement of the United States federal research and development tax credit.

[0001234452-17-000154:mdna:61]
Unrecognized tax benefits were $278 million and $271 million at June 25, 2017 and September 25, 2016, respectively. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at June 25, 2017 may increase or decrease in the next 12 months.

[0001234452-17-000154:mdna:62]
We are subject to income taxes in the United States and numerous foreign jurisdictions and are currently under examination by the United States and various other tax authorities worldwide, most notably in countries where we earn a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds. As of June 25, 2017, we believe that adequate amounts have been reserved based on facts known. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known, which may have a negative impact on our results of operations.

[0001234452-17-000154:mdna:63]
[same as prior period, unchanged from 0001234452-17-000077:mdna:80]

[0001234452-17-000154:mdna:64]
[same as prior period, unchanged from 0001234452-17-000077:mdna:65]

[0001234452-17-000154:mdna:65]
The following should be read in conjunction with the financial results for the third quarter and first nine months of fiscal 2017 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0001234452-17-000154:mdna:66]
| (in millions) | QCT |  | QTL |  | QSI |
| Three Months Ended June 25, 2017 |  |  |  |  |  |
| Revenues | $ | 4,052 |  |  | $ | 1,172 |  |  | $ | 56 |  |
| EBT (1) | 575 |  |  | 854 |  |  | 55 |  |
| EBT as a % of revenues | 14 | % |  | 73 | % |  |  |  |
| Three Months Ended June 26, 2016 |  |  |  |  |  |
| Revenues | $ | 3,853 |  |  | $ | 2,038 |  |  | $ | 12 |  |
| EBT (1) | 365 |  |  | 1,749 |  |  | (5 | ) |
| EBT as a % of revenues | 9 | % |  | 86 | % |  |  |
| Nine Months Ended June 25, 2017 |  |  |  |  |  |
| Revenues | $ | 11,829 |  |  | $ | 5,232 |  |  | $ | 70 |  |
| EBT (1) | 1,774 |  |  | 4,346 |  |  | 38 |  |
| EBT as a % of revenues | 15 | % |  | 83 | % |  |  |
| Nine Months Ended June 26, 2016 |  |  |  |  |  |
| Revenues | $ | 11,285 |  |  | $ | 5,780 |  |  | $ | 33 |  |
| EBT (1) | 1,125 |  |  | 4,945 |  |  | 400 |  |
| EBT as a % of revenues | 10 | % |  | 86 | % |  |  |

[0001234452-17-000154:mdna:67]
[same as prior period, unchanged from 0001234452-17-000077:mdna:68]

[0001234452-17-000154:mdna:68]
QCT Segment. QCT results of operations in the third quarter and first nine months of fiscal 2017 were impacted by growth within adjacent industry segments outside traditional cellular industries, our recently formed RF360 Holdings joint venture and cost reduction initiatives achieved under the Strategic Realignment Plan, partially offset by a decline in share at a large customer. QCT revenues in the third quarter and first nine months of fiscal 2017 increased due to increases in equipment and services revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying RF, Power Management (PM) and wireless connectivity integrated circuits, were $4.01 billion and $3.80 billion in the third quarter of fiscal 2017 and 2016, respectively and $11.71 billion and $11.10 billion in the first nine months of fiscal 2017 and 2016, respectively. Equipment and services revenues in the third quarter and first nine months of fiscal 2017 increased primarily due to an increase of $426 million and $807 million, respectively, in revenues related to RFFE products, primarily from our RF360 Holdings joint venture, and higher connectivity shipments, partially offset by a decrease of $199 million and $662 million, respectively, primarily related to lower MSM shipments. Approximately 187 million and 201 million MSM integrated circuits were sold in the third quarter of fiscal 2017 and 2016, respectively, and approximately 584 million and 631 million MSM integrated circuits were sold in the first nine months of fiscal 2017 and 2016, respectively. The increase in equipment and services revenues in the first nine months of fiscal 2017 was also due to an increase of $414 million resulting from the net impact of higher-priced product mix and lower average selling prices.

[0001234452-17-000154:mdna:69]
QCT EBT as a percentage of revenues in the third quarter fiscal 2017 increased primarily due to an increase in gross margin percentage, partially offset by a combined increase of 2% in research and development and selling, general and administrative expenses. QCT EBT as a percentage of revenues in the first nine months of fiscal 2017 increased primarily due to an increase in gross margin percentage and a combined decrease of 2% in research and development and selling, general and administrative expenses. The increases in QCT gross margin percentage resulted primarily from higher-margin product mix and lower average unit costs, partially offset by lower average selling prices and higher excess inventory charges.

[0001234452-17-000154:mdna:70]
QCT accounts receivable increased by 14% in the first nine months of fiscal 2017 from $1.46 billion to $1.67 billion, primarily due to the accounts receivable relating to our RF360 Holdings joint venture and the timing of integrated circuit shipments. QCT inventories increased by 29% in the first nine months of fiscal 2017 from $1.54 billion to $1.99 billion, primarily due to the inventories relating to our RF360 Holdings joint venture and an increase in the overall quantity of units on hand, partially offset by lower average unit cost.

[0001234452-17-000154:mdna:71]
QTL Segment. QTL revenues decreased in the third quarter of fiscal 2017 by $866 million primarily as a result of actions taken by Apple’s contract manufacturers, who did not fully report and did not pay royalties due on sales of Apple

[0001234452-17-000154:mdna:72]
products, and the previously disclosed dispute with another licensee who did not report or pay royalties due. Revenues related to the products of Apple’s contract manufacturers and the other licensee in dispute comprised approximately $700 million in the third quarter of fiscal 2016. QTL revenues in the third quarter of fiscal 2016 included the recognition of previously deferred royalty revenues associated with the dismissal of the arbitration with LG Electronics, Inc. and higher royalty revenues recognized related to devices sold in prior periods relative to the third quarter of fiscal 2017. In addition to the above, the decrease in QTL revenues in the first nine months of fiscal 2017 of $548 million was also attributable to the previously disclosed licensee in dispute who did not properly report royalties due in the second quarter of fiscal 2017, the recognition of revenues in the second quarter of fiscal 2016 relating to the termination of an infrastructure license agreement resulting from the merger of two licensees and decreased recognition of unearned license fees. Revenues also continued to be impacted negatively by units that we believe are not being reported by certain other licensees and sales of certain unlicensed products. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing, particularly in emerging regions, including China, and additional litigation may become necessary if negotiations fail to resolve the relevant issues.

[0001234452-17-000154:mdna:73]
QTL accounts receivable increased by more than 100% in the first nine months of fiscal 2017 from $644 million to $1.81 billion, primarily due to the short payment of royalties reported in the second quarter of fiscal 2017 by, and deemed collectible from, Apple’s contract manufacturers and the timing of the collection of payments from certain of our other licensees.

[0001234452-17-000154:mdna:74]
QSI Segment. The increase in QSI EBT in the third quarter of fiscal 2017 was primarily due to the net impact of $36 million resulting from higher revenues and costs associated with certain development contracts with one of our equity method investees and an increase of $23 million in net realized gains on investments. The decrease in QSI EBT in the first nine months of fiscal 2017 was primarily due to the effect of a $380 million gain on the sale of wireless spectrum recorded in the first quarter of fiscal 2016, a decrease of $21 million in net realized gains on investments and the net impact of $19 million resulting from higher revenues and costs associated with certain development contracts with one of our equity method investees, partially offset by a decrease of $17 million in equity losses.

[0001234452-17-000154:mdna:75]
[same as prior period, unchanged from 0001234452-17-000077:mdna:77]

[0001234452-17-000154:mdna:76]
On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings will acquire NXP. Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration of $38 billion. The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions. In May 2017, we issued an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes with varying maturities, of which a portion will be used to fund the purchase price and other related transactions. In addition, we have secured $4.0 billion in committed financing through a Term Loan Facility, which is expected to be drawn on at the close of the NXP transaction. The remaining amount will be funded with cash held by foreign entities, which will result in the use of a substantial portion of our cash, cash equivalents and marketable securities.

[0001234452-17-000154:mdna:77]
Qualcomm River Holdings and NXP may terminate the definitive agreement under certain circumstances. If the definitive agreement is terminated by NXP in certain circumstances, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the definitive agreement is terminated by Qualcomm River Holdings under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion. In November 2016, as required by the definitive agreement, we entered into four letters of credit for an aggregate amount of $2.0 billion pursuant to which NXP will have the right to draw amounts to fund the potential termination fee payable to NXP. Each letter of credit is required to be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. We are restricted from using the funds deposited as collateral while the letters of credit are outstanding. At June 25, 2017, the letters of credit were fully collateralized through bank time deposits and money market funds.

[0001234452-17-000154:mdna:78]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our employee benefit plans. The following tables present selected financial information related to our liquidity as of June 25, 2017 and September 25, 2016 and for the first nine months of fiscal 2017 and 2016 (in millions):

[0001234452-17-000154:mdna:79]
|  | June 25, 2017 |  | September 25, 2016 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 37,752 |  |  | $ | 32,350 |  |  | $ | 5,402 |  |  | 17 | % |
| Accounts receivable, net | 3,532 |  |  | 2,219 |  |  | 1,313 |  |  | 59 | % |
| Inventories | 2,002 |  |  | 1,556 |  |  | 446 |  |  | 29 | % |
| Short-term debt | 2,495 |  |  | 1,749 |  |  | 746 |  |  | 43 | % |
| Long-term debt | 19,403 |  |  | 10,008 |  |  | 9,395 |  |  | 94 | % |

[0001234452-17-000154:mdna:80]
|  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | $ Change |  | % Change |
| Net cash provided by operating activities | $ | 2,276 |  |  | $ | 5,316 |  |  | $ | (3,040 | ) |  | (57 | %) |
| Net cash used by investing activities | (342 | ) |  | (2,229 | ) |  | 1,887 |  |  | N/M |  |
| Net cash provided (used) by financing activities | 7,001 |  |  | (4,765 | ) |  | 11,766 |  |  | N/M |  |

[0001234452-17-000154:mdna:81]
[same as prior period, unchanged from 0001234452-17-000077:mdna:85]

[0001234452-17-000154:mdna:82]
The net increase in cash, cash equivalents and marketable securities was primarily due to the proceeds from the issuance of unsecured floating-rate and fixed-rate notes in May 2017 of approximately $10.95 billion, net of underwriting discounts and offering expenses, and net cash provided by operating activities, partially offset by $2.4 billion in cash dividends paid, the deposit of $2.0 billion that was used to collateralize the letters of credit related to our proposed acquisition of NXP, $1.4 billion in payments to fund acquisitions and other investments, primarily related to our recently formed RF360 Holdings joint venture, $1.0 billion in payments to repurchase shares of our common stock and $750 million of net repayments of our outstanding commercial paper debt. Total cash provided by operating activities decreased primarily due to the $940 million payment in connection with the BlackBerry arbitration and the $927 million payment of the fine related to the KFTC investigation, as well as changes in working capital related to an increase in accounts receivable and inventories and the timing of related payments. Total cash provided by operating activities was also impacted by actions taken in the third quarter of fiscal 2017 by Apple’s contract manufacturers, who did not fully report and did not pay royalties due on sales of Apple products, as well as the previously disclosed dispute with a licensee who did not report or pay royalties due. We expect these licensees will continue to take such actions in the future until the respective disputes are resolved.

[0001234452-17-000154:mdna:83]
Our days sales outstanding, on a consolidated basis, increased to 60 days at June 25, 2017 compared to 33 days at September 25, 2016. The increases in accounts receivable and the related days sales outstanding were primarily due to the short payment in the second quarter of fiscal 2017 of royalties reported by and deemed collectible from Apple’s contract manufacturers. We expect these receivables to remain outstanding until we resolve our dispute with Apple. The increase in accounts receivable also resulted from the accounts receivable relating to our RF360 Holdings joint venture and the timing of the collection of payments from certain of our other licensees. The increase in inventories was primarily due to inventories relating to our RF360 Holdings joint venture and an increase in the overall quantity of units on hand, partially offset by lower average unit cost.

[0001234452-17-000154:mdna:84]
Our cash, cash equivalents and marketable securities at June 25, 2017 consisted of $10.0 billion held by United States-based entities and $27.8 billion held by foreign entities. Most of our cash, cash equivalents and marketable securities held by foreign entities are indefinitely reinvested and would be subject to material tax effects if repatriated. However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate funds held by foreign entities.

[0001234452-17-000154:mdna:85]
We believe our current cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our financing activities will satisfy our working and other capital requirements, for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements, in addition to our proposed acquisition of NXP, also include the items described below.

[0001234452-17-000154:mdna:86]
| • | Our purchase obligations at June 25, 2017, some of which relate to research and development activities and capital expenditures, totaled $3.6 billion and $1.8 billion for fiscal 2017 and 2018, respectively, and $1.5 billion thereafter. |

[0001234452-17-000154:mdna:87]
| • | Our research and development expenditures were $4.1 billion in the first nine months of fiscal 2017 and $5.2 billion in fiscal 2016, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications. |

[0001234452-17-000154:mdna:88]
[same as prior period, unchanged from 0001234452-17-000077:mdna:119]

[0001234452-17-000154:mdna:89]
| • | Cash outflows for capital expenditures were $428 million in the first nine months of fiscal 2017 and $539 million in fiscal 2016. We anticipate that capital expenditures will be higher in fiscal 2017 as compared to fiscal 2016, primarily due to estimated capital expenditures of approximately $150 million related to the manufacturing operations of our RF360 Holdings joint venture. We also expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-17-000154:mdna:90]
[same as prior period, unchanged from 0001234452-17-000077:mdna:93]

[0001234452-17-000154:mdna:91]
| • | In connection with the BlackBerry arbitration, we paid $940 million on May 26, 2017 to cover the award amount, pre-judgment interest and attorneys’ fees. This also reflected certain amounts that were owed to us by BlackBerry. |

[0001234452-17-000154:mdna:92]
[same as prior period, unchanged from 0001234452-17-000077:mdna:95]

[0001234452-17-000154:mdna:93]
Debt. In November 2016, we amended and restated our existing Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit to increase the aggregate amount available to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. At June 25, 2017, no amounts were outstanding under the Amended and Restated Revolving Credit Facility.

[0001234452-17-000154:mdna:94]
We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At June 25, 2017, we had $999 million of commercial paper outstanding with weighted-average net interest rates of 0.97% and weighted-average remaining days to maturity of 28 days.

[0001234452-17-000154:mdna:95]
In May 2017, we issued an aggregate principal amount of $11.0 billion in nine tranches of unsecured floating- and fixed-rate notes, with maturity dates starting in 2019 through 2047 and effective interest rates between 1.68% and 4.47%. Net proceeds from the issuance of the notes of $11.0 billion are intended to be used to fund a portion of the purchase price of our planned acquisition of NXP and other related transactions and also for general corporate purposes. Our 2019 floating-rate notes, 2020 floating-rate notes, 2019 fixed-rate notes and 2020 fixed-rate notes issued in May 2017 for an aggregate principal amount of $4.0 billion are subject to a special mandatory redemption at a price equal to 101% of the aggregate principal amount, plus accrued and unpaid interest to, but excluding, the date of such mandatory redemption. The redemption is required on the first to occur of (i) the termination of the NXP purchase agreement or (ii) October 27, 2017 (or such later date on or prior to June 1, 2018 to which such date is extended in accordance with the NXP purchase agreement).

[0001234452-17-000154:mdna:96]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, with maturity dates starting in 2018 through 2045 and effective interest rates between 1.50% and 4.74%. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. We may issue additional debt in the future. The amount and timing of such additional borrowings will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001234452-17-000154:mdna:97]
In November 2016, we entered into a Term Loan Facility that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion. Proceeds from the Term Loan Facility, if drawn, will be used to finance, in part, the proposed acquisition of NXP. At June 25, 2017, no amounts were outstanding under the Term Loan Facility.

[0001234452-17-000154:mdna:98]
Additional information regarding our outstanding debt at June 25, 2017 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt.”

[0001234452-17-000154:mdna:99]
Capital Return Program. In the first nine months of fiscal 2017, we repurchased and retired 16,669,000 shares of our common stock for $1.0 billion, before commissions. At June 25, 2017, $2.0 billion remained authorized for repurchase under our stock repurchase program. As a result of our proposed acquisition of NXP and the pending use of our cash and marketable securities, we currently expect to repurchase shares in the next few years to offset dilution from the issuance of common stock under our employee benefit plans.

[0001234452-17-000154:mdna:100]
In the first nine months of fiscal 2017, we paid cash dividends totaling $2.4 billion, or $1.63 per share. On July 13, 2017, we announced a cash dividend of $0.57 per share on our common stock, payable on September 20, 2017 to stockholders of record as of the close of business on August 30, 2017. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-17-000154:mdna:101]
[same as prior period, unchanged from 0001234452-17-000077:mdna:105]

[0001234452-17-000154:mdna:102]
[same as prior period, unchanged from 0001234452-17-000077:mdna:106]

[0001234452-17-000154:mdna:103]
Additional information regarding our financial commitments at June 25, 2017 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes,” “Note 5. Debt,” “Note 6. Commitments and Contingencies” and “Note 8. Acquisitions.”

[0001234452-17-000154:mdna:104]
[same as prior period, unchanged from 0001234452-17-000077:mdna:108]

[0001234452-17-000154:mdna:105]
[same as prior period, unchanged from 0001234452-17-000077:mdna:109]

[0001234452-17-000154:mdna:106]
[same as prior period, unchanged from 0001234452-17-000077:mdna:110]

[0001234452-17-000154:mdna:107]
[same as prior period, unchanged from 0001234452-17-000077:mdna:111]

[0001234452-17-000154:mdna:108]
[same as prior period, unchanged from 0001234452-17-000077:mdna:112]

[0001234452-17-000154:mdna:109]
[same as prior period, unchanged from 0001234452-17-000077:mdna:113]

[0001234452-17-000154:mdna:110]
Our and NXP’s obligations to consummate the proposed transaction are subject to the satisfaction or waiver of certain conditions, including, among others: (i) the tender of a minimum number of NXP’s outstanding common shares in the tender offer commenced by a subsidiary of QUALCOMM Incorporated; (ii) the receipt of regulatory clearance under European Union and certain other foreign antitrust laws; (iii) the absence of any law or order prohibiting the proposed transaction; (iv) there being no event that would have a material adverse effect on NXP; (v) the accuracy of the representations and warranties of NXP, subject to certain exceptions, and NXP’s material compliance with its covenants, in the definitive agreement; and (vi) the completion of certain internal reorganization steps with respect to NXP and the disposition of certain non-core assets of NXP. We cannot provide assurance that the conditions to the completion of the proposed transaction will be satisfied in a timely manner or at all, and if the proposed transaction is not completed, we would not realize any of the expected benefits.

[0001234452-17-000154:mdna:111]
[same as prior period, unchanged from 0001234452-17-000077:mdna:115]

[0001234452-17-000154:mdna:112]
In addition, the use of a significant portion of our cash and the incurrence of substantial indebtedness in connection with the financing of the proposed transaction will reduce our liquidity, and may limit our flexibility in responding to other business opportunities and increase our vulnerability to adverse economic and industry conditions. See the Risk Factor entitled “There are risks associated with our indebtedness.”

[0001234452-17-000154:mdna:113]
[same as prior period, unchanged from 0001234452-17-000077:mdna:117]

[0001234452-17-000154:mdna:114]
[same as prior period, unchanged from 0001234452-17-000077:mdna:118]

[0001234452-17-000154:mdna:115]
[same as prior period, unchanged from 0001234452-17-000077:mdna:120]

[0001234452-17-000154:mdna:116]
[same as prior period, unchanged from 0001234452-17-000077:mdna:121]

[0001234452-17-000154:mdna:117]
| • | we may be subject to legal proceedings related to the proposed transaction or the failure to complete the proposed transaction; |

[0001234452-17-000154:mdna:118]
[same as prior period, unchanged from 0001234452-17-000077:mdna:123]

[0001234452-17-000154:mdna:119]
| • | any disruptions to our business resulting from the pendency of the proposed transaction, including any adverse changes in our relationships with our customers, suppliers, partners or employees, may continue or intensify in the event the proposed transaction is not consummated. |

[0001234452-17-000154:mdna:120]
[same as prior period, unchanged from 0001234452-17-000077:mdna:125]

[0001234452-17-000154:mdna:121]
[same as prior period, unchanged from 0001234452-17-000077:mdna:126]

[0001234452-17-000154:mdna:122]
The proposed transaction may also result in significant charges or other liabilities that could adversely affect our financial results, such as cash expenses and non-cash accounting charges incurred in connection with our acquisition and/or integration of the business and operations of NXP. Further, our failure to identify or accurately assess the magnitude of certain liabilities we are assuming in the proposed transaction could result in unexpected litigation or regulatory exposure, unfavorable accounting charges, unexpected increases in taxes due, a loss of anticipated tax benefits or other adverse effects on our business, operating results or financial condition. The price of our common stock following the proposed transaction could decline to the extent our financial results are materially affected by any of these events.

[0001234452-17-000154:mdna:123]
[same as prior period, unchanged from 0001234452-17-000077:mdna:128]

[0001234452-17-000154:mdna:124]
[same as prior period, unchanged from 0001234452-17-000077:mdna:129]

[0001234452-17-000154:mdna:125]
[same as prior period, unchanged from 0001234452-17-000077:mdna:130]

[0001234452-17-000154:mdna:126]
[same as prior period, unchanged from 0001234452-17-000077:mdna:131]

[0001234452-17-000154:mdna:127]
[same as prior period, unchanged from 0001234452-17-000077:mdna:132]

[0001234452-17-000154:mdna:128]
[same as prior period, unchanged from 0001234452-17-000077:mdna:133]

[0001234452-17-000154:mdna:129]
[same as prior period, unchanged from 0001234452-17-000077:mdna:135]

[0001234452-17-000154:mdna:130]
[same as prior period, unchanged from 0001234452-17-000077:mdna:161]

[0001234452-17-000154:mdna:131]
[same as prior period, unchanged from 0001234452-17-000077:mdna:136]

[0001234452-17-000154:mdna:132]
[same as prior period, unchanged from 0001234452-17-000077:mdna:137]

[0001234452-17-000154:mdna:133]
[same as prior period, unchanged from 0001234452-17-000077:mdna:138]

[0001234452-17-000154:mdna:134]
[same as prior period, unchanged from 0001234452-17-000077:mdna:139]

[0001234452-17-000154:mdna:135]
[same as prior period, unchanged from 0001234452-17-000077:mdna:140]

[0001234452-17-000154:mdna:136]
[same as prior period, unchanged from 0001234452-17-000077:mdna:141]

[0001234452-17-000154:mdna:137]
[same as prior period, unchanged from 0001234452-17-000077:mdna:142]

[0001234452-17-000154:mdna:138]
[same as prior period, unchanged from 0001234452-17-000077:mdna:143]

[0001234452-17-000154:mdna:139]
[same as prior period, unchanged from 0001234452-17-000077:mdna:144]

[0001234452-17-000154:mdna:140]
[same as prior period, unchanged from 0001234452-17-000077:mdna:145]

[0001234452-17-000154:mdna:141]
[same as prior period, unchanged from 0001234452-17-000077:mdna:146]

[0001234452-17-000154:mdna:142]
[same as prior period, unchanged from 0001234452-17-000077:mdna:147]

[0001234452-17-000154:mdna:143]
[same as prior period, unchanged from 0001234452-17-000077:mdna:148]

[0001234452-17-000154:mdna:144]
[same as prior period, unchanged from 0001234452-17-000077:mdna:149]

[0001234452-17-000154:mdna:145]
[same as prior period, unchanged from 0001234452-17-000077:mdna:150]

[0001234452-17-000154:mdna:146]
42

[0001234452-17-000154:mdna:147]
[same as prior period, unchanged from 0001234452-17-000077:mdna:151]

[0001234452-17-000154:mdna:148]
[same as prior period, unchanged from 0001234452-17-000077:mdna:152]

[0001234452-17-000154:mdna:149]
[same as prior period, unchanged from 0001234452-17-000077:mdna:153]

[0001234452-17-000154:mdna:150]
[same as prior period, unchanged from 0001234452-17-000077:mdna:154]

[0001234452-17-000154:mdna:151]
[same as prior period, unchanged from 0001234452-17-000077:mdna:155]

[0001234452-17-000154:mdna:152]
[same as prior period, unchanged from 0001234452-17-000077:mdna:156]

[0001234452-17-000154:mdna:153]
[same as prior period, unchanged from 0001234452-17-000077:mdna:157]

[0001234452-17-000154:mdna:154]
Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM) as well as companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom Limited, Cirrus Logic, HiSilicon Technologies, Intel, Marvell Technology, Maxim Integrated Products, MediaTek, Microchip Technology Inc., Murata Manufacturing Co., Ltd., Nvidia, Qorvo Inc., Realtek Semiconductor, Samsung Electronics, Skyworks Solutions Inc. and Spreadtrum Communications (which is controlled by Tsinghua Unigroup). Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to utilize their own internally-developed integrated circuit products, to use our competitors’ integrated circuit products, or to choose alternative technologies; lower cost structures and/or a willingness and ability to accept lower prices and lower or negative margins for their products, particularly in China; foreign government support of other technologies or competitors; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and original equipment manufacturers in emerging geographic regions (such as China); and/or a more established presence in certain regions.

[0001234452-17-000154:mdna:155]
[same as prior period, unchanged from 0001234452-17-000077:mdna:159]

[0001234452-17-000154:mdna:156]
Our QCT segment derives a significant portion of its revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. In addition, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past chosen, and may in the future choose, to utilize in certain of their devices rather than our integrated circuit products (and/or sell their integrated circuit products to third parties in competition with us). Also, one of our largest integrated circuit customers utilizes products of one of our competitors in certain of their devices rather than our products.

[0001234452-17-000154:mdna:157]
The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or the cancelation of significant purchases by any of these customers, whether due to the use of their own integrated circuit products, our competitors’ integrated circuit products or otherwise, would reduce our revenues and could harm our ability to achieve or sustain expected operating results, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Any such reduction in revenues would also impact our cash resources available for other purposes,

[0001234452-17-000154:mdna:158]
[same as prior period, unchanged from 0001234452-17-000077:mdna:179]

[0001234452-17-000154:mdna:159]
such as research and development. Further, the concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have no control, and the timing of such introductions may cause our operating results to fluctuate. Accordingly, if current industry dynamics and concentrations continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases, and the timing and size of any such future purchases, by these significant customers.

[0001234452-17-000154:mdna:160]
[same as prior period, unchanged from 0001234452-17-000077:mdna:163]

[0001234452-17-000154:mdna:161]
[same as prior period, unchanged from 0001234452-17-000077:mdna:164]

[0001234452-17-000154:mdna:162]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products and/or intellectual property or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001234452-17-000154:mdna:163]
Although we have more than 345 CDMA-based licensees, our QTL segment derives a significant portion of its licensing revenues from a limited number of licensees. In the event that one or more of our significant licensees fail to meet their reporting and/or payment requirements or we are unable to renew or modify one or more of such license agreements under similar terms, our revenues, operating results and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our major licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues.

[0001234452-17-000154:mdna:164]
[same as prior period, unchanged from 0001234452-17-000077:mdna:167]

[0001234452-17-000154:mdna:165]
[same as prior period, unchanged from 0001234452-17-000077:mdna:168]

[0001234452-17-000154:mdna:166]
[same as prior period, unchanged from 0001234452-17-000077:mdna:169]

[0001234452-17-000154:mdna:167]
A reduction in sales of premium-tier devices, or a reduction in sales of our premium-tier integrated circuit products (which have a higher revenue and margin contribution than our lower-tier integrated circuit products), may reduce our revenues and margins and may harm our ability to achieve or sustain expected operating results. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0001234452-17-000154:mdna:168]
Efforts by some communications equipment manufacturers or their customers to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions and/or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.

[0001234452-17-000154:mdna:169]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging

[0001234452-17-000154:mdna:170]
infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the imposition of some form of compulsory licensing and/or to weaken a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies to attempt to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated. In addition, certain licensees have disputed, underreported, underpaid, not reported and/or not paid royalties owed to us under their license agreements or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into or renewing license agreements with us for their use of our intellectual property, and licensees and/or companies may continue to do so in the future. The fact that one or more licensees dispute, underreport, underpay, do not report and/or do not pay royalties owed to us may encourage other licensees to take similar actions and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Further, to the extent such licensees and/or companies increase their device share, the negative impact of their underreporting, underpayment, non-reporting and/or non-payment on our business, results of operations, financial condition and/or cash flows will be exacerbated.

[0001234452-17-000154:mdna:171]
We are currently subject to various litigation and governmental investigations and/or proceedings, some of which have and may continue to arise out of the strategies described above. Certain legal matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. See also the Risk Factor entitled “If we are required to change our patent licensing practices due to governmental investigations and/or private legal proceedings challenging those practices, our business and financial results could be adversely impacted.”

[0001234452-17-000154:mdna:172]
In addition, in connection with our participation in SDOs, we, like other patent owners, generally have made contractual commitments to such organizations to license those of our patents that would necessarily be infringed by standard-compliant products (standard-essential patents) on FRAND terms. Some manufacturers and users of standard-compliant products advance interpretations of these FRAND commitments that are adverse to our licensing business, including interpretations that would limit the amount of royalties that we could collect on the licensing of our patent portfolio.

[0001234452-17-000154:mdna:173]
[same as prior period, unchanged from 0001234452-17-000077:mdna:176]

[0001234452-17-000154:mdna:174]
Some SDOs, courts and governmental agencies have adopted and may in the future adopt some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001234452-17-000154:mdna:175]
We expect that such proposals, interpretations and strategies will continue in the future, and if successful, our business model would be harmed, either by limiting or eliminating our ability to collect royalties (or by reducing the royalties we can collect) on all or a portion of our patent portfolio, limiting our return on investment with respect to new technologies, limiting our ability to seek injunctions against infringers of our standard-essential patents, constraining our ability to make licensing commitments when submitting our technology for inclusion in future standards (which could make our technology less likely to be included in such standards) or forcing us to work outside of SDOs or other industry groups to promote our new technologies, and our results of operations could be negatively impacted. In addition, the legal and other costs associated with asserting or defending our positions have been and continue to be significant. We assume that such challenges, regardless of

[0001234452-17-000154:mdna:176]
45

[0001234452-17-000154:mdna:177]
their merits, will continue into the foreseeable future and may require the investment of substantial management time and financial resources.

[0001234452-17-000154:mdna:178]
If we are required to change our patent licensing practices due to governmental investigations and/or private legal proceedings challenging those practices, our business and financial results could be adversely impacted.

[0001234452-17-000154:mdna:179]
We are currently subject to various governmental investigations and private legal proceedings challenging our patent licensing practices as described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations in those matters include that we do not license our cellular standard-essential patents separately from our other patents, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high and/or that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions). We believe that the ultimate intent of these investigations and legal proceedings is to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0001234452-17-000154:mdna:180]
We have historically licensed our cellular standard-essential patents together with other Qualcomm patents that may be useful to licensed products because licensees typically have desired to obtain the commercial benefits of receiving such broad patent rights from us. However, we also have licensed only our cellular standard-essential patents to certain licensees who have requested such licenses. In addition, in connection with our resolution with the China National Development and Reform Commission (NDRC) in China, our standard practice in China since 2015 is to offer licenses for our 3G and 4G standard-essential Chinese patents for branded devices sold for use in China separately from licenses to our other patents. If we were required to separately license our cellular standard-essential patents to all of our licensees worldwide, and more licensees chose such a license instead of a portfolio license than has historically been the case, our licensing revenues and earnings would be negatively impacted unless we were able to license our other patents at rates that offset all or a portion of any difference between the royalties previously received for licenses of substantially all of our patent portfolio as compared to licenses of only our cellular standard-essential patents and/or there was a sufficient increase in the overall volume of sales of devices upon which royalties are paid.

[0001234452-17-000154:mdna:181]
[same as prior period, unchanged from 0001234452-17-000077:mdna:183]

[0001234452-17-000154:mdna:182]
[same as prior period, unchanged from 0001234452-17-000077:mdna:184]

[0001234452-17-000154:mdna:183]
[same as prior period, unchanged from 0001234452-17-000077:mdna:185]

[0001234452-17-000154:mdna:184]
[same as prior period, unchanged from 0001234452-17-000077:mdna:186]

[0001234452-17-000154:mdna:185]
[same as prior period, unchanged from 0001234452-17-000077:mdna:187]

[0001234452-17-000154:mdna:186]
We are currently subject to various governmental investigations and/or proceedings, and certain matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region.

[0001234452-17-000154:mdna:187]
[same as prior period, unchanged from 0001234452-17-000077:mdna:191]

[0001234452-17-000154:mdna:188]
[same as prior period, unchanged from 0001234452-17-000077:mdna:192]

[0001234452-17-000154:mdna:189]
Regulations in the United States require that we determine whether certain materials used in our products, referred to as conflict minerals, originated in the Democratic Republic of the Congo or an adjoining country (collectively, the Covered Countries), or were from recycled or scrap sources. The verification and reporting requirements, in addition to customer demands for conflict free sourcing, impose additional costs on us and on our suppliers and may limit the sources or increase the prices of materials used in our products. Further, if we are unable to determine that the conflict minerals used in our products do not directly or indirectly finance or benefit armed groups in the Covered Countries, we may face challenges with our customers that place us at a competitive disadvantage, and our reputation may be harmed.

[0001234452-17-000154:mdna:190]
[same as prior period, unchanged from 0001234452-17-000077:mdna:194]

[0001234452-17-000154:mdna:191]
[same as prior period, unchanged from 0001234452-17-000077:mdna:195]

[0001234452-17-000154:mdna:192]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our proprietary information, technologies and processes, including our patent portfolio. Policing unauthorized use of our products, technologies and proprietary information is difficult and time consuming. The steps we have taken have not always prevented, and we cannot be certain the steps we will take in the future will prevent, the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as United States laws or where the enforcement of such laws may be lacking or ineffective. Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that the European Union will adopt a unitary patent system in the next few years that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technology.

[0001234452-17-000154:mdna:193]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property rights and/or contracts, including collecting royalties for use of our patent portfolio in particular foreign jurisdictions

[0001234452-17-000154:mdna:194]
due to, among others: refusal by certain licensees to report and/or pay all or a portion of the royalties they owe to us; policies of foreign governments; challenges to our licensing practices under such jurisdictions’ competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and/or challenges pending before foreign competition agencies to the pricing and integration of additional features and functionality into our chipset products. Certain licensees have disputed, underreported, underpaid, not reported and/or not paid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into or renewing license agreements for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future. The fact that one or more licensees dispute, underreport, underpay, do not report and/or do not pay royalties owed to us may encourage other licensees to take similar actions and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements.

[0001234452-17-000154:mdna:195]
We have entered into litigation in the past and may need to further litigate in the future to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. We are currently engaged in litigation matters related to protecting or enforcing our contract and/or intellectual property rights, and certain such matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” As a result of any such litigation, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements and/or initiating litigation) and/or we could incur substantial unexpected operating costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our operating results. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion. See also the Risk Factor entitled “If we are required to change our patent licensing practices due to governmental investigations and/or private legal proceedings challenging those practices, our business and financial results could be adversely impacted.”

[0001234452-17-000154:mdna:196]
[same as prior period, unchanged from 0001234452-17-000077:mdna:200]

[0001234452-17-000154:mdna:197]
[same as prior period, unchanged from 0001234452-17-000077:mdna:201]

[0001234452-17-000154:mdna:198]
[same as prior period, unchanged from 0001234452-17-000077:mdna:202]

[0001234452-17-000154:mdna:199]
However, our research, development and other investments in these new and expanded product areas and adjacent industry segments, and corresponding technologies, products and services, as well as in our existing, technologies, products and services and new technologies, such as use of both licensed and unlicensed spectrum, convergence of cellular and Wi-Fi and 5G, may not succeed due to, among others: new industry segments and/or consumer demand may not grow as anticipated;

[0001234452-17-000154:mdna:200]
[same as prior period, unchanged from 0001234452-17-000077:mdna:227]

[0001234452-17-000154:mdna:201]
our strategies and/or the strategies of our customers, licensees or partners may not be successful; improvements in alternate technologies in ways that reduce the advantages we anticipate from our investments; competitors’ products or services being more cost effective, having more capabilities or fewer limitations or being brought to market faster than our new products and services; and competitors having longer operating histories in industry segments that are new to us. We may also underestimate the costs of or overestimate the future operating income and/or margins that could result from these investments, and these investments may not, or may take many years to, generate material returns.

[0001234452-17-000154:mdna:202]
[same as prior period, unchanged from 0001234452-17-000077:mdna:204]

[0001234452-17-000154:mdna:203]
There are numerous risks associated with our operation and control of manufacturing facilities we acquired through the formation of our joint venture with TDK, RF360 Holdings, including a higher portion of fixed costs relative to a fabless model, environmental compliance and liability, exposure to natural disasters, timely supply of equipment and materials and manufacturing difficulties.

[0001234452-17-000154:mdna:204]
[same as prior period, unchanged from 0001234452-17-000077:mdna:208]

[0001234452-17-000154:mdna:205]
[same as prior period, unchanged from 0001234452-17-000077:mdna:209]

[0001234452-17-000154:mdna:206]
[same as prior period, unchanged from 0001234452-17-000077:mdna:210]

[0001234452-17-000154:mdna:207]
[same as prior period, unchanged from 0001234452-17-000077:mdna:211]

[0001234452-17-000154:mdna:208]
[same as prior period, unchanged from 0001234452-17-000077:mdna:212]

[0001234452-17-000154:mdna:209]
[same as prior period, unchanged from 0001234452-17-000077:mdna:213]

[0001234452-17-000154:mdna:210]
Although we own a very strong portfolio of issued and pending patents related to EDGE, OFDM, OFDMA, WLAN and other technologies, our patent portfolio licensing program in these areas is less established and might not be as successful in generating licensing revenues as our CDMA licensing program has been. Many wireless operators are investigating, have selected or have deployed OFDMA-based LTE as their next-generation 4G technology in existing (or future if not yet deployed) wireless spectrum bands as complementary to their existing CDMA-based networks. While 3G/4G multimode products are generally covered by our existing 3G licensing agreements, products that implement 4G but do not also implement 3G are generally not covered by these agreements. Although we believe that our patented technology is essential and useful to implementation of the LTE industry standards and have granted royalty-bearing licenses to more than 230 companies (including Huawei, Lenovo, LG, Microsoft, Oppo, Samsung, Sony Mobile, vivo, Xiaomi and ZTE) that have realized that they need a license to our patents to make and sell products implementing 4G standards but not implementing 3G standards, it may be difficult to agree on material terms and/or conditions of new license agreements that are acceptable to us with companies that are currently unlicensed. Further, the royalty rates for single mode 4G products are lower than our royalty rates for 3G and 3G/4G multimode products, so, without a corresponding increase in volumes and/or device ASP, we will not achieve the same licensing revenues on such LTE products as on 3G and 3G/4G multimode products. In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the connected home or the IoT. We also seek to diversify and broaden our technology licensing programs to new industry segments in which we can utilize our technology leadership, such as wireless charging and other technologies. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties that are equivalent to those that we receive for 3G and 3G/4G multimode products used in cellular communications. Although we believe that our patented technology is essential and useful to the commercialization of such services, any royalties we receive may be lower than those we receive from our current licensing program.

[0001234452-17-000154:mdna:211]
[same as prior period, unchanged from 0001234452-17-000077:mdna:216]

[0001234452-17-000154:mdna:212]
The licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, certain of our license agreements (including essentially all of our recent agreements in China) are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of a specified term, or to receive royalties after the specified time period, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. Accordingly, to the extent not renewed on their terms or by election for an additional (generally multi-year) period, if applicable, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. We might not be able to renew those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in renewing a license agreement prior to its expiration, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001234452-17-000154:mdna:213]
[same as prior period, unchanged from 0001234452-17-000077:mdna:218]

[0001234452-17-000154:mdna:214]
Our QCT segment primarily utilizes a fabless production model, which means that we generally do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Other than the manufacturing facilities we now operate through our recently formed RF360 Holdings joint venture, we rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Under the turnkey model, our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services such as wafer bump, probe, assembly and the majority of our final test requirements. The semiconductor manufacturing foundries that supply products to our QCT segment are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders. The following could have an adverse effect on our ability to meet customer demands and/or negatively impact our revenues, business operations, profitability and/or cash flows:

[0001234452-17-000154:mdna:215]
[same as prior period, unchanged from 0001234452-17-000077:mdna:220]

[0001234452-17-000154:mdna:216]
50

[0001234452-17-000154:mdna:217]
[same as prior period, unchanged from 0001234452-17-000077:mdna:221]

[0001234452-17-000154:mdna:218]
[same as prior period, unchanged from 0001234452-17-000077:mdna:222]

[0001234452-17-000154:mdna:219]
[same as prior period, unchanged from 0001234452-17-000077:mdna:223]

[0001234452-17-000154:mdna:220]
[same as prior period, unchanged from 0001234452-17-000077:mdna:224]

[0001234452-17-000154:mdna:221]
[same as prior period, unchanged from 0001234452-17-000077:mdna:225]

[0001234452-17-000154:mdna:222]
[same as prior period, unchanged from 0001234452-17-000077:mdna:226]

[0001234452-17-000154:mdna:223]
[same as prior period, unchanged from 0001234452-17-000077:mdna:228]

[0001234452-17-000154:mdna:224]
[same as prior period, unchanged from 0001234452-17-000077:mdna:229]

[0001234452-17-000154:mdna:225]
[same as prior period, unchanged from 0001234452-17-000077:mdna:230]

[0001234452-17-000154:mdna:226]
[same as prior period, unchanged from 0001234452-17-000077:mdna:231]

[0001234452-17-000154:mdna:227]
[same as prior period, unchanged from 0001234452-17-000077:mdna:232]

[0001234452-17-000154:mdna:228]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become

[0001234452-17-000154:mdna:229]
the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our operating results.

[0001234452-17-000154:mdna:230]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (and/or on the sale of our customers’ devices using such products) and/or the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001234452-17-000154:mdna:231]
Certain legal matters, including certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001234452-17-000154:mdna:232]
[same as prior period, unchanged from 0001234452-17-000077:mdna:237]

[0001234452-17-000154:mdna:233]
We engage in strategic acquisitions and other transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. We acquire businesses and other assets, including patents, technology, wireless spectrum and other intangible assets, enter into joint ventures or other strategic transactions, and purchase minority equity interests in or make loans to companies that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications and new industry segments. Recent material transactions include our acquisition of CSR plc, our RF360 Holdings joint venture with TDK Corporation and our proposed acquisition of NXP. Many of our strategic activities entail a high degree of risk and require the use of domestic and/or foreign capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies, products or services. We may underestimate the costs and/or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our financial results, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001234452-17-000154:mdna:234]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, technology, products, processes, operations (including manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development and/or supply operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or

[0001234452-17-000154:mdna:235]
[same as prior period, unchanged from 0001234452-17-000077:mdna:267]

[0001234452-17-000154:mdna:236]
operational models (including manufacturing), geographic regions, industry segments and/or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of the combination.

[0001234452-17-000154:mdna:237]
If we do not achieve the anticipated benefits of business acquisitions or other strategic activities, our business and results of operations may be adversely affected, and we may not enhance stockholder value by engaging in these transactions.

[0001234452-17-000154:mdna:238]
[same as prior period, unchanged from 0001234452-17-000077:mdna:240]

[0001234452-17-000154:mdna:239]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe we will continue to see, an increase in customers requesting that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of a product’s source code and may expose related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of the open source software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Developing open source products, while adequately protecting the intellectual property rights upon which our licensing business depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property rights. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ adequate controls to protect our intellectual property rights, our use of open source software presents risks that could have an adverse effect on these rights and on our business.

[0001234452-17-000154:mdna:240]
[same as prior period, unchanged from 0001234452-17-000077:mdna:243]

[0001234452-17-000154:mdna:241]
[same as prior period, unchanged from 0001234452-17-000077:mdna:244]

[0001234452-17-000154:mdna:242]
In the past, securities class action litigation has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001234452-17-000154:mdna:243]
[same as prior period, unchanged from 0001234452-17-000077:mdna:246]

[0001234452-17-000154:mdna:244]
[same as prior period, unchanged from 0001234452-17-000077:mdna:247]

[0001234452-17-000154:mdna:245]
[same as prior period, unchanged from 0001234452-17-000077:mdna:248]

[0001234452-17-000154:mdna:246]
[same as prior period, unchanged from 0001234452-17-000077:mdna:249]

[0001234452-17-000154:mdna:247]
[same as prior period, unchanged from 0001234452-17-000077:mdna:250]

[0001234452-17-000154:mdna:248]
[same as prior period, unchanged from 0001234452-17-000077:mdna:251]

[0001234452-17-000154:mdna:249]
[same as prior period, unchanged from 0001234452-17-000077:mdna:252]

[0001234452-17-000154:mdna:250]
[same as prior period, unchanged from 0001234452-17-000077:mdna:253]

[0001234452-17-000154:mdna:251]
[same as prior period, unchanged from 0001234452-17-000077:mdna:254]

[0001234452-17-000154:mdna:252]
A decline in global, regional or local economic conditions or a slow-down in economic growth, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could have adverse, wide-ranging effects on demand for our products and for the products and services of our customers or licensees, particularly equipment manufacturers or others in the wireless communications industry who buy their products, such as wireless operators. Any prolonged economic downturn may result in a decrease in demand for our products or technologies; the insolvency of key suppliers, customers or licensees; delays in reporting and/or payments from our licensees and/or customers; failures by counterparties; and negative effects on wireless device inventories. In addition, our customers’ ability to purchase or pay for our products and services and network operators’ ability to upgrade their wireless networks could be adversely affected by economic conditions, leading to a reduction, cancelation or delay of orders for our products or services.

[0001234452-17-000154:mdna:253]
[same as prior period, unchanged from 0001234452-17-000077:mdna:257]

[0001234452-17-000154:mdna:254]
[same as prior period, unchanged from 0001234452-17-000077:mdna:258]

[0001234452-17-000154:mdna:255]
[same as prior period, unchanged from 0001234452-17-000077:mdna:259]

[0001234452-17-000154:mdna:256]
[same as prior period, unchanged from 0001234452-17-000077:mdna:260]

[0001234452-17-000154:mdna:257]
[same as prior period, unchanged from 0001234452-17-000077:mdna:261]

[0001234452-17-000154:mdna:258]
[same as prior period, unchanged from 0001234452-17-000077:mdna:262]

[0001234452-17-000154:mdna:259]
[same as prior period, unchanged from 0001234452-17-000077:mdna:263]

[0001234452-17-000154:mdna:260]
[same as prior period, unchanged from 0001234452-17-000077:mdna:264]

[0001234452-17-000154:mdna:261]
54

[0001234452-17-000154:mdna:262]
[same as prior period, unchanged from 0001234452-17-000077:mdna:265]

[0001234452-17-000154:mdna:263]
[same as prior period, unchanged from 0001234452-17-000077:mdna:266]

[0001234452-17-000154:mdna:264]
[same as prior period, unchanged from 0001234452-17-000077:mdna:268]

[0001234452-17-000154:mdna:265]
[same as prior period, unchanged from 0001234452-17-000077:mdna:269]

[0001234452-17-000154:mdna:266]
[same as prior period, unchanged from 0001234452-17-000077:mdna:270]

[0001234452-17-000154:mdna:267]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-United States headquarters is located. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed. Our current examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. Although we believe that our tax estimates are reasonable at June 25, 2017, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision, results of operations and/or cash flows in the period or periods in which that determination is made could be negatively affected.

[0001234452-17-000154:mdna:268]
[same as prior period, unchanged from 0001234452-17-000077:mdna:272]

[0001234452-17-000154:mdna:269]
[same as prior period, unchanged from 0001234452-17-000077:mdna:273]

[0001234452-17-000154:mdna:270]
55

[0001234452-17-000154:mdna:271]
[same as prior period, unchanged from 0001234452-17-000077:mdna:274]
