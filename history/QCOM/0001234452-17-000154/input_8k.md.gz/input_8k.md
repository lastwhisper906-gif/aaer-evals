# QCOM 8-K — 0001234452-17-000153 filed 2017-07-19

## item codes, every 8-K on or before 2017-07-19

- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2017-07-19

- none on or before 2017-07-19

## item 2.02 — earnings release, exhibit 99.1

[0001234452-17-000153:8k_2_02:1]
EX-99.1
2
qcom062517erex991.htm
EXHIBIT 99.1

[0001234452-17-000153:8k_2_02:2]
Exhibit

[0001234452-17-000153:8k_2_02:3]
Exhibit 99.1

[0001234452-17-000153:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-17-000153:8k_2_02:5]
Qualcomm Contact:

[0001234452-17-000153:8k_2_02:6]
John Sinnott

[0001234452-17-000153:8k_2_02:7]
Vice President, Investor Relations

[0001234452-17-000153:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-17-000153:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-17-000153:8k_2_02:10]
Qualcomm Announces Third Quarter Fiscal 2017 Results

[0001234452-17-000153:8k_2_02:11]
GAAP Revenues $5.4 billion

[0001234452-17-000153:8k_2_02:12]
GAAP EPS $0.58, Non-GAAP EPS $0.83

[0001234452-17-000153:8k_2_02:13]
SAN DIEGO - July 19, 2017 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal third quarter ended June 25, 2017.

[0001234452-17-000153:8k_2_02:14]
“We delivered better than expected results in our semiconductor business this quarter, which drove EPS above the midpoint of our expectations versus our April updated guidance,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “Our products and technologies continue to enable the global smartphone industry, and we are expanding into many exciting new product categories, including automotive, mobile computing, networking and IoT.  We believe that we hold the high ground with regard to the dispute with Apple, and we have initiated new actions to protect the well-established value of our technologies.”

[0001234452-17-000153:8k_2_02:15]
Third Quarter Results (GAAP)*

[0001234452-17-000153:8k_2_02:16]
|  | Q3 Fiscal 2017 |  | Q3 Fiscal 2016 |  | Year-Over-Year Change |  | Q2 Fiscal 2017 |  | Sequential Change |
| Revenues | $5.4B |  | $6.0B |  | (11%) |  | $5.0B |  | +7% |
| Operating income | $0.8B |  | $1.6B |  | (51%) |  | $0.7B |  | +6% |
| Net income 1 | $0.9B |  | $1.4B |  | (40%) |  | $0.7B |  | +16% |
| Diluted earnings per share 1 | $0.58 |  | $0.97 |  | (40%) |  | $0.50 |  | +16% |
| Operating cash flow | $0.1B |  | $1.8B |  | N/M |  | $0.8B |  | N/M |

[0001234452-17-000153:8k_2_02:17]
1 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests), unless otherwise stated.

[0001234452-17-000153:8k_2_02:18]
Third Quarter Results (Non-GAAP)*

[0001234452-17-000153:8k_2_02:19]
|  | Q3 Fiscal 2017 |  | Q3 Fiscal 2016 |  | Year-Over-Year Change |  | Q2 Fiscal 2017 |  | Sequential Change |
| Revenues | $5.3B |  | $6.0B |  | (12%) |  | $6.0B |  | (11%) |
| Operating income | $1.2B |  | $2.0B |  | (40%) |  | $2.2B |  | (45%) |
| Net income | $1.2B |  | $1.7B |  | (28%) |  | $2.0B |  | (38%) |
| Diluted earnings per share | $0.83 |  | $1.16 |  | (28%) |  | $1.34 |  | (38%) |

[0001234452-17-000153:8k_2_02:20]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding the Company’s use of Non-GAAP financial measures and detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-17-000153:8k_2_02:21]
* The third quarter of fiscal 2017 GAAP and Non-GAAP results were negatively impacted as a result of actions taken by Apple’s contract manufacturers, who did not fully report and did not pay royalties due on sales of Apple products, as well as the previously disclosed dispute with another licensee, who did not report or pay royalties due in the third quarter of fiscal 2017.  We expect these licensees will continue to take such actions in the future until the respective disputes are resolved.

[0001234452-17-000153:8k_2_02:22]
The following should also be considered in regards to the sequential and year-over-year comparisons:

[0001234452-17-000153:8k_2_02:23]
| • | The third quarter of fiscal 2017 GAAP results included: |

[0001234452-17-000153:8k_2_02:24]
| ◦ | A reduction in operating cash flow due to a $940 million payment to BlackBerry and a $927 million payment related to the Korea Free Trade Commission (KFTC) fine, in addition to the impact from the actions taken by Apple’s contract manufacturers and the other licensee in dispute. |

[0001234452-17-000153:8k_2_02:25]
| • | The second quarter of fiscal 2017 GAAP results included: |

[0001234452-17-000153:8k_2_02:26]
| ◦ | $974 million reduction to revenues, or $0.48 per share, related to the BlackBerry arbitration. |

[0001234452-17-000153:8k_2_02:27]
| • | The third quarter of fiscal 2016 GAAP and Non-GAAP results included: |

[0001234452-17-000153:8k_2_02:28]
| ◦ | $235 million of revenues, or $0.11 per share, due to the recognition of previously deferred royalty revenues related to the dismissal of the arbitration with LG Electronics, Inc. |

[0001234452-17-000153:8k_2_02:29]
Third Quarter Segment Results

[0001234452-17-000153:8k_2_02:30]
|  | Q3 Fiscal 2017 |  | Q3 Fiscal 2016 |  | Year-Over-Year Change |  | Q2 Fiscal 2017 |  | Sequential Change |
| QCT |  |  |  |  |  |  |  |  |  |
| Revenues | $4,052M |  | $3,853M |  | +5% |  | $3,676M |  | +10% |
| Earnings before taxes (EBT) | $575M |  | $365M |  | +58% |  | $475M |  | +21% |
| EBT as % of revenues | 14% |  | 9% |  | +5% |  | 13% |  | +1% |
| MSMTM chip shipments | 187M |  | 201M |  | (7%) |  | 179M |  | +4% |
| QTL |  |  |  |  |  |  |  |  |  |
| Revenues | $1,172M |  | $2,038M |  | (42%) |  | $2,249M |  | (48%) |
| EBT | $854M |  | $1,749M |  | (51%) |  | $1,959M |  | (56%) |
| EBT as % of revenues | 73% |  | 86% |  | (13%) |  | 87% |  | (14%) |

[0001234452-17-000153:8k_2_02:31]
As a result of the recent actions taken by Apple’s contract manufacturers and the other licensee in dispute, we currently do not believe total reported device sales and related estimated ranges of device shipment and average selling price are meaningful in measuring our QTL business, and therefore, we are not providing such metrics for the fiscal third quarter.

[0001234452-17-000153:8k_2_02:32]
Cash and Marketable Securities

[0001234452-17-000153:8k_2_02:33]
Our cash, cash equivalents and marketable securities totaled $37.8 billion at the end of the third quarter of fiscal 2017, compared to $31.0 billion a year ago and $28.9 billion at the end of the second quarter of fiscal 2017. In May 2017, we issued an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes, which are intended to be used to finance, in part, our proposed acquisition of NXP and other related transactions and for general corporate purposes.

[0001234452-17-000153:8k_2_02:34]
Announced Agreement to Acquire NXP

[0001234452-17-000153:8k_2_02:35]
On October 27, 2016, we announced a definitive agreement to acquire NXP Semiconductors N.V. for estimated total cash to be paid to shareholders of $38 billion.  NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products.  The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions.  We intend to fund the transaction with cash generated from the recent debt offering as well as cash held by our foreign entities, which will result in the use of a substantial portion of our cash, cash equivalents and marketable securities, and the use of a Term Loan Facility, which is expected to be drawn on at close.

[0001234452-17-000153:8k_2_02:36]
Return of Capital to Stockholders

[0001234452-17-000153:8k_2_02:37]
During the third quarter of fiscal 2017, we returned $1.1 billion to stockholders, including $844 million, or $0.57 per share, of cash dividends paid and $300 million through repurchases of 5.2 million shares of common stock.  On July 13, 2017, we announced a cash dividend of $0.57 per share payable on September 20, 2017 to stockholders of record as of the close of business on August 30, 2017.

[0001234452-17-000153:8k_2_02:38]
Effective Income Tax Rates

[0001234452-17-000153:8k_2_02:39]
Our fiscal 2017 annual effective income tax rates are estimated to be approximately 11 percent for GAAP and approximately 14 percent for Non-GAAP.  Our estimated annual tax rates for fiscal 2017 GAAP and Non-GAAP decreased from our estimates as of the second quarter of fiscal 2017, primarily as a result of a decrease in our estimate of income from United States operations, principally related to decreased QTL revenues from Apple’s contract manufacturers.  As a result, the effective income tax rates for the third quarter of fiscal 2017 were 1 percent benefit for GAAP and 5 percent provision for Non-GAAP, which reflect the cumulative effect of the reduction in our estimated annual effective rates in the third quarter of fiscal 2017.

[0001234452-17-000153:8k_2_02:40]
Business Outlook

[0001234452-17-000153:8k_2_02:41]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment, certain derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001234452-17-000153:8k_2_02:42]
We have not included estimates related to the operating results of any proposed acquisitions in our fourth quarter of fiscal 2017 outlook.

[0001234452-17-000153:8k_2_02:43]
Our financial guidance for the fourth quarter of fiscal 2017 excludes QTL revenues related to the sale of Apple products by Apple’s contract manufacturers as well as the other licensee in dispute as we expect the recent actions taken by these licensees will continue until the respective disputes are resolved.  As a result, we currently do not believe total reported device sales is meaningful in measuring our QTL business.  Alternatively, we are providing guidance for QTL revenues for the fourth quarter of fiscal 2017.

[0001234452-17-000153:8k_2_02:44]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-17-000153:8k_2_02:45]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001234452-17-000153:8k_2_02:46]
|  |  | Q4 FY16 Results | Current Guidance Q4 FY17 Estimates (2) |  |
|  | Revenues | $6.2B | $5.4B - $6.2B |  |  |
|  | Year-over-year change |  | decrease 13% - flat |  |  |
|  | GAAP diluted earnings per share (EPS) | $1.07 | $0.55 - $0.65 |  |  |
|  | Year-over-year change |  | decrease 39% - 49% |  |  |
|  | Less diluted EPS attributable to QSI | ($0.01) |  | $0.01 |  |  |
|  | Less diluted EPS attributable to share-based compensation | ($0.10) |  | ($0.11 | ) |  |
|  | Less diluted EPS attributable to other items (1) | ($0.10) |  | ($0.10 | ) |  |
|  | Non-GAAP diluted EPS | $1.28 | $0.75 - $0.85 |  |  |
|  | Year-over-year change |  | decrease 34% - 41% |  |  |
|  | Other Information |  |  |  |
|  | MSM chip shipments | 211 | M | 205M - 225M |  |  |
|  | Year-over-year change |  | decrease 3% - increase 7% |  |  |
|  | QTL revenues | $1.9B | $1.0B - $1.3B |  |  |
|  | Year-over-year change |  | decrease 31% - 47% |  |  |

[0001234452-17-000153:8k_2_02:47]
| (1) | Our guidance for diluted EPS attributable to other items for the fourth quarter of fiscal 2017 is primarily attributable to acquisition-related items. |

[0001234452-17-000153:8k_2_02:48]
| (2) | Our financial guidance for the fourth quarter of fiscal 2017 excludes QTL revenues related to the sale of Apple products by Apple’s contract manufacturers as well as the other licensee in dispute as we expect the recent actions taken by these licensees will continue until the respective disputes are resolved. |

[0001234452-17-000153:8k_2_02:49]
Sums may not equal total due to rounding.

[0001234452-17-000153:8k_2_02:50]
Reconciliations of GAAP Results to Non-GAAP Results

[0001234452-17-000153:8k_2_02:51]
The following tables reconcile our GAAP results to our Non-GAAP results ($ in millions, except per share data):

[0001234452-17-000153:8k_2_02:52]
|  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) |  | Non-GAAP Results |
| Q3 FISCAL 2017 |  |  |  |  |  |  |  |
| Revenues | $5,371 |  |  | $56 |  |  |  | $— |  |  | $12 |  | (c) | $5,303 |  |
| Operating income (loss) | 773 |  | 34 |  |  | (227) | (259) |  | 1,225 |  |
| EBT | 858 |  | 55 |  |  | (227) | (271) |  | 1,301 |  |
| EBT as % of revenues | 16 | % |  |  |  |  |  |  | 25 | % |  |
| Net income (loss) | 866 |  | 32 |  |  | (199) | (204) |  | 1,237 |  |
| Diluted EPS | $0.58 |  | $0.02 |  | ($0.13) | ($0.14) |  | $0.83 |  |
| Diluted shares | 1,491 |  | 1,491 |  | 1,491 | 1,491 |  | 1,491 |  |
| Q2 FISCAL 2017 |  |  |  |  |  |  |  |
| Revenues | $5,016 |  |  | $— |  |  |  | $— |  |  | ($974 | ) |  | $5,990 |  |
| Operating income (loss) | 729 |  | (17) |  | (246) | (1,228) |  | 2,220 |  |
| EBT | 857 |  | — |  |  | (246) | (1,239) |  | 2,342 |  |
| EBT as % of revenues | 17 | % |  |  |  |  |  |  | 39 | % |  |
| Net income (loss) | 749 |  | — |  |  | (210) | (1,030) |  | 1,989 |  |
| Diluted EPS | $0.50 |  | $0.00 |  | ($0.14) | ($0.69) |  | $1.34 |  |
| Diluted shares | 1,489 |  | 1,489 |  | 1,489 | 1,489 |  | 1,489 |  |
| Q3 FISCAL 2016 |  |  |  |  |  |  |  |
| Revenues | $6,044 |  | $12 |  |  | $— |  |  | $— |  |  | $6,032 |  |
| Operating income (loss) | 1,592 |  | (2) |  | (235) | (203) |  | 2,032 |  |
| EBT | 1,693 |  | (5) |  | (235) | (203) |  | 2,136 |  |
| EBT as % of revenues | 28 | % |  |  |  |  |  |  | 35 | % |  |
| Net income (loss) | 1,444 |  | (4) |  | (197) | (84) |  | 1,729 |  |
| Diluted EPS | $0.97 |  | $0.00 |  | ($0.13) | ($0.06) |  | $1.16 |  |
| Diluted shares | 1,486 |  | 1,486 |  | 1,486 | 1,486 |  | 1,486 |  |

[0001234452-17-000153:8k_2_02:53]
| (a) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” herein for further details. |

[0001234452-17-000153:8k_2_02:54]
| (b) | Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates.” Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001234452-17-000153:8k_2_02:55]
| (c) | Other items excluded from Non-GAAP results consisted of a $12 million benefit related to an adjustment of the BlackBerry arbitration. |

[0001234452-17-000153:8k_2_02:56]
Sums may not equal totals due to rounding.

[0001234452-17-000153:8k_2_02:57]
Supplemental Information and Reconciliations

[0001234452-17-000153:8k_2_02:58]
(Unaudited)

[0001234452-17-000153:8k_2_02:59]
|  | Q3 FISCAL 2017 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results |
|  | Cost of revenues |  | $2,488 |  |  | $18 |  |  | $10 |  |  | $181 |  |  | $2,279 |  |
|  | Research and development (R&D) expenses |  | 1,391 |  |  | — |  |  |  | 147 |  |  | 3 |  |  | 1,241 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 710 |  |  | 4 |  |  | 70 |  |  | 78 |  |  | 558 |  |
|  | Other expenses |  | 9 |  |  | — |  |  |  | — |  |  |  | 9 |  |  | — |  |  |
|  | Interest expense |  | 133 |  |  | — |  |  |  | — |  |  |  | 16 |  |  | 117 |  |
|  | Investment and other income, net |  | 218 |  |  | 21 |  |  | — |  |  |  | 4 |  |  | 193 | (b) |

[0001234452-17-000153:8k_2_02:60]
| (a) | Other items excluded from Non-GAAP results included $235 million of acquisition-related charges, $42 million of asset impairment charges, $4 million of restructuring and restructuring-related charges related to our Strategic Realignment Plan and $2 million in net foreign currency transaction losses related to the fine imposed by the KFTC. |

[0001234452-17-000153:8k_2_02:61]
| (b) | Included $141 million in interest and dividend income and $98 million in net realized gains on investments, partially offset by $26 million in net foreign currency transaction losses and $20 million in other net investment losses. |

[0001234452-17-000153:8k_2_02:62]
Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates

[0001234452-17-000153:8k_2_02:63]
(Unaudited)

[0001234452-17-000153:8k_2_02:64]
|  |  | GAAP Results |  |  | Less QSI |  | Less Share-Based Compensation |  | Less Other Items (c)(d) |  |  | Non-GAAP Results |  |
| Q3 FISCAL 2017 ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 858 |  |  |  | $ | 55 |  |  |  | $ | (227 | ) |  |  | $ | (271 | ) |  |  | $ | 1,301 |  |  |
| Income tax benefit (expense) |  | 7 |  |  |  | (24 | ) |  |  | 28 |  |  |  | 67 |  |  |  | (64 | ) |  |
| Net income (loss) (a) |  | $ | 865 |  |  |  | $ | 31 |  |  |  | $ | (199 | ) |  |  | $ | (204 | ) |  |  | $ | 1,237 |  |  |
| Tax rate |  | (1 | %) |  |  | 2 | % | (b) |  |  |  | (2 | %) | (b) |  |  | (6 | %) | (b) |  |  | 5 | % |  |
| FISCAL 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Estimated annual tax rate |  | 11 | % |  |  | 0 | % | (b) |  |  |  | (1 | %) | (b) |  |  |  | (2 | %) | (b) |  |  |  | 14 | % |  |

[0001234452-17-000153:8k_2_02:65]
| (a) | Before adjustments for noncontrolling interests. |

[0001234452-17-000153:8k_2_02:66]
| (b) | The incremental effect of our adjustments to the Non-GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001234452-17-000153:8k_2_02:67]
| (c) | In the third quarter of fiscal 2017, the tax benefit in the “Other Items” column included a $61 million tax benefit for the tax effect of acquisition-related items in EBT and a $6 million benefit for the combined effect of other items in EBT. |

[0001234452-17-000153:8k_2_02:68]
| (d) | In fiscal 2017, the estimated annual effective tax rate for the “Other Items” column includes a $360 million tax benefit for the combined tax effect of other items in EBT and a $150 million tax benefit for the tax effect of acquisition-related items in EBT, partially offset by a $13 million tax expense related to an increase in unrecognized tax benefits. |

[0001234452-17-000153:8k_2_02:69]
Conference Call

[0001234452-17-000153:8k_2_02:70]
Qualcomm’s fiscal third quarter 2017 earnings conference call will be broadcast live on July 19, 2017, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 38395118.

[0001234452-17-000153:8k_2_02:71]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-17-000153:8k_2_02:72]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-17-000153:8k_2_02:73]
The Company uses the Non-GAAP financial information:  (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating the Company’s business and assessing trends and future expectations.

[0001234452-17-000153:8k_2_02:74]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items, tax items and other items.

[0001234452-17-000153:8k_2_02:75]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-17-000153:8k_2_02:76]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001234452-17-000153:8k_2_02:77]
| • | Certain other items are excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001234452-17-000153:8k_2_02:78]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items, as well as any effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property, third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition. Starting with acquisitions in the second quarter of fiscal 2017, the Company excludes recognition of the step-up of property, plant and equipment from the net book value based on the original cost basis to fair value. Such charges related to acquisitions that were completed prior to the second quarter of fiscal 2017 continue to be allocated to the segments, and such amounts are not material. |

[0001234452-17-000153:8k_2_02:79]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. |

[0001234452-17-000153:8k_2_02:80]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. |

[0001234452-17-000153:8k_2_02:81]
About Qualcomm

[0001234452-17-000153:8k_2_02:82]
Qualcomm’s technologies powered the smartphone revolution and connected billions of people.  We pioneered 3G and 4G - and now we are leading the way to 5G and a new era of intelligent, connected devices.  Our products are revolutionizing industries, including automotive, computing, IoT, healthcare and data center, and are allowing millions of devices to connect with each other in ways never before imagined.  Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, all of our engineering, research and development functions, and all of our products and services businesses, including, our QCT semiconductor business.  For more information, visit www.qualcomm.com.

[0001234452-17-000153:8k_2_02:83]
Note Regarding Forward-Looking Statements

[0001234452-17-000153:8k_2_02:84]
###

[0001234452-17-000153:8k_2_02:85]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-17-000153:8k_2_02:86]
Qualcomm MSM are products of Qualcomm Technologies, Inc.

[0001234452-17-000153:8k_2_02:87]
Qualcomm Incorporated

[0001234452-17-000153:8k_2_02:88]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001234452-17-000153:8k_2_02:89]
(In millions, except per share data)

[0001234452-17-000153:8k_2_02:90]
(Unaudited)

[0001234452-17-000153:8k_2_02:91]
|  | June 25, 2017 |  | September 25, 2016 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 14,909 |  |  | $ | 5,946 |  |
| Marketable securities | 5,954 |  |  | 12,702 |  |
| Accounts receivable, net | 3,532 |  |  | 2,219 |  |
| Inventories | 2,002 |  |  | 1,556 |  |
| Other current assets | 624 |  |  | 558 |  |
| Total current assets | 27,021 |  |  | 22,981 |  |
| Marketable securities | 16,889 |  |  | 13,702 |  |
| Deferred tax assets | 2,747 |  |  | 2,030 |  |
| Property, plant and equipment, net | 3,164 |  |  | 2,306 |  |
| Goodwill | 6,523 |  |  | 5,679 |  |
| Other intangible assets, net | 3,880 |  |  | 3,500 |  |
| Other assets | 4,155 |  |  | 2,161 |  |
| Total assets | $ | 64,379 |  |  | $ | 52,359 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,508 |  |  | $ | 1,858 |  |
| Payroll and other benefits related liabilities | 1,089 |  |  | 934 |  |
| Unearned revenues | 513 |  |  | 509 |  |
| Short-term debt | 2,495 |  |  | 1,749 |  |
| Other current liabilities | 3,558 |  |  | 2,261 |  |
| Total current liabilities | 9,163 |  |  | 7,311 |  |
| Unearned revenues | 2,111 |  |  | 2,377 |  |
| Long-term debt | 19,403 |  |  | 10,008 |  |
| Other liabilities | 2,419 |  |  | 895 |  |
| Total liabilities | 33,096 |  |  | 20,591 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,476 shares issued and outstanding | 225 |  |  | 414 |  |
| Retained earnings | 30,778 |  |  | 30,936 |  |
| Accumulated other comprehensive income | 291 |  |  | 428 |  |
| Total Qualcomm stockholders’ equity | 31,294 |  |  | 31,778 |  |
| Noncontrolling interests | (11 | ) |  | (10 | ) |
| Total stockholders’ equity | 31,283 |  |  | 31,768 |  |
| Total liabilities and stockholders’ equity | $ | 64,379 |  |  | $ | 52,359 |  |

[0001234452-17-000153:8k_2_02:92]
Qualcomm Incorporated

[0001234452-17-000153:8k_2_02:93]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-17-000153:8k_2_02:94]
(In millions, except per share data)

[0001234452-17-000153:8k_2_02:95]
(Unaudited)

[0001234452-17-000153:8k_2_02:96]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | June 25, 2017 |  | June 26, 2016 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 4,121 |  |  | $ | 3,875 |  |  | $ | 11,949 |  |  | $ | 11,311 |  |
| Licensing | 1,250 |  |  | 2,169 |  |  | 4,438 |  |  | 6,059 |  |
| Total revenues | 5,371 |  |  | 6,044 |  |  | 16,387 |  |  | 17,370 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of revenues | 2,488 |  |  | 2,534 |  |  | 7,140 |  |  | 7,210 |  |
| Research and development | 1,391 |  |  | 1,268 |  |  | 4,087 |  |  | 3,922 |  |
| Selling, general and administrative | 710 |  |  | 620 |  |  | 1,917 |  |  | 1,817 |  |
| Other | 9 |  |  | 30 |  |  | 962 |  |  | (270 | ) |
| Total costs and expenses | 4,598 |  |  | 4,452 |  |  | 14,106 |  |  | 12,679 |  |
| Operating income | 773 |  |  | 1,592 |  |  | 2,281 |  |  | 4,691 |  |
| Interest expense | (133 | ) |  | (75 | ) |  | (330 | ) |  | (221 | ) |
| Investment and other income, net | 218 |  |  | 176 |  |  | 635 |  |  | 403 |  |
| Income before income taxes | 858 |  |  | 1,693 |  |  | 2,586 |  |  | 4,873 |  |
| Income tax benefit (expense) | 7 |  |  | (250 | ) |  | (290 | ) |  | (770 | ) |
| Net income | 865 |  |  | 1,443 |  |  | 2,296 |  |  | 4,103 |  |
| Net loss attributable to noncontrolling interests | 1 |  |  | 1 |  |  | 1 |  |  | 3 |  |
| Net income attributable to Qualcomm | $ | 866 |  |  | $ | 1,444 |  |  | $ | 2,297 |  |  | $ | 4,106 |  |
| Basic earnings per share attributable to Qualcomm | $ | 0.59 |  |  | $ | 0.98 |  |  | $ | 1.55 |  |  | $ | 2.76 |  |
| Diluted earnings per share attributable to Qualcomm | $ | 0.58 |  |  | $ | 0.97 |  |  | $ | 1.54 |  |  | $ | 2.74 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,478 |  |  | 1,471 |  |  | 1,478 |  |  | 1,487 |  |
| Diluted | 1,491 |  |  | 1,486 |  |  | 1,491 |  |  | 1,500 |  |
| Dividends per share announced | $ | 0.57 |  |  | $ | 0.53 |  |  | $ | 1.63 |  |  | $ | 1.49 |  |

[0001234452-17-000153:8k_2_02:97]
Qualcomm Incorporated

[0001234452-17-000153:8k_2_02:98]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-17-000153:8k_2_02:99]
(In millions)

[0001234452-17-000153:8k_2_02:100]
(Unaudited)

[0001234452-17-000153:8k_2_02:101]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 25, 2017 |  | June 26, 2016 |  | June 25, 2017 |  | June 26, 2016 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 865 |  |  | $ | 1,443 |  |  | $ | 2,296 |  |  | $ | 4,103 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 393 |  |  | 356 |  |  | 1,064 |  |  | 1,092 |  |
| Indefinite and long-lived asset impairment charges | 42 |  |  | 47 |  |  | 76 |  |  | 94 |  |
| Income tax provision less than income tax payments | (237 | ) |  | (47 | ) |  | (467 | ) |  | (236 | ) |
| Gain on sale of wireless spectrum | — |  |  | — |  |  | — |  |  | (380 | ) |
| Non-cash portion of share-based compensation expense | 227 |  |  | 235 |  |  | 712 |  |  | 730 |  |
| Incremental tax benefits from share-based compensation | (1 | ) |  | (1 | ) |  | (38 | ) |  | (3 | ) |
| Net realized gains on marketable securities and other investments | (139 | ) |  | (69 | ) |  | (375 | ) |  | (142 | ) |
| Impairment losses on marketable securities and other investments | 15 |  |  | 33 |  |  | 163 |  |  | 138 |  |
| Other items, net | (83 | ) |  | (47 | ) |  | 14 |  |  | — |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | 670 |  |  | (215 | ) |  | (1,021 | ) |  | 39 |  |
| Inventories | 63 |  |  | 90 |  |  | (182 | ) |  | 169 |  |
| Other assets | 4 |  |  | 32 |  |  | 111 |  |  | 153 |  |
| Trade accounts payable | 134 |  |  | 126 |  |  | (543 | ) |  | 263 |  |
| Payroll, benefits and other liabilities | (1,802 | ) |  | 176 |  |  | 615 |  |  | (434 | ) |
| Unearned revenues | (69 | ) |  | (319 | ) |  | (149 | ) |  | (270 | ) |
| Net cash provided by operating activities | 82 |  |  | 1,840 |  |  | 2,276 |  |  | 5,316 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (177 | ) |  | (136 | ) |  | (428 | ) |  | (389 | ) |
| Purchases of available-for-sale marketable securities | (6,707 | ) |  | (5,185 | ) |  | (15,509 | ) |  | (12,960 | ) |
| Proceeds from sales and maturities of available-for-sale marketable securities | 6,497 |  |  | 4,497 |  |  | 19,643 |  |  | 10,303 |  |
| Purchases of trading securities | — |  |  | — |  |  | — |  |  | (177 | ) |
| Proceeds from sales and maturities of trading securities | — |  |  | 23 |  |  | — |  |  | 779 |  |
| Purchases of other marketable securities | (705 | ) |  | — |  |  | (705 | ) |  | — |  |
| Proceeds from sales of other marketable securities | — |  |  | — |  |  | — |  |  | 450 |  |
| Deposits of investments designated as collateral | — |  |  | — |  |  | (2,000 | ) |  | — |  |
| Acquisitions and other investments, net of cash acquired | (19 | ) |  | (40 | ) |  | (1,401 | ) |  | (663 | ) |
| Proceeds from sale of wireless spectrum | — |  |  | — |  |  | — |  |  | 232 |  |
| Other items, net | 9 |  |  | 47 |  |  | 58 |  |  | 196 |  |
| Net cash used by investing activities | (1,102 | ) |  | (794 | ) |  | (342 | ) |  | (2,229 | ) |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 1,735 |  |  | 2,305 |  |  | 6,848 |  |  | 6,633 |  |
| Repayment of short-term debt | (2,734 | ) |  | (2,505 | ) |  | (7,598 | ) |  | (5,885 | ) |
| Proceeds from long-term debt | 10,953 |  |  | — |  |  | 10,953 |  |  | — |  |
| Proceeds from issuance of common stock | 41 |  |  | 151 |  |  | 331 |  |  | 422 |  |
| Repurchases and retirements of common stock | (300 | ) |  | (100 | ) |  | (1,027 | ) |  | (3,698 | ) |
| Dividends paid | (844 | ) |  | (781 | ) |  | (2,411 | ) |  | (2,208 | ) |
| Incremental tax benefits from share-based compensation | 1 |  |  | 1 |  |  | 38 |  |  | 3 |  |
| Other items, net | (81 | ) |  | (14 | ) |  | (133 | ) |  | (32 | ) |
| Net cash provided (used) by financing activities | 8,771 |  |  | (943 | ) |  | 7,001 |  |  | (4,765 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 34 |  |  | 7 |  |  | 28 |  |  | 3 |  |
| Net increase (decrease) in cash and cash equivalents | 7,785 |  |  | 110 |  |  | 8,963 |  |  | (1,675 | ) |
| Cash and cash equivalents at beginning of period | 7,124 |  |  | 5,775 |  |  | 5,946 |  |  | 7,560 |  |
| Cash and cash equivalents at end of period | $ | 14,909 |  |  | $ | 5,885 |  |  | $ | 14,909 |  |  | $ | 5,885 |  |
