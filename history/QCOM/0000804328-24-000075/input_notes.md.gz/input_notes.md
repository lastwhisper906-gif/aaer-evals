# QCOM notes — 0000804328-24-000075


## ecd:MtrlTermsOfTrdArrTextBlock

[0000804328-24-000075:notes:1]
On September 12, 2024, Cristiano Amon, our President and Chief Executive Officer, acting as trustee on behalf of his family trust, terminated the trust’s Rule 10b5-1 trading arrangement (as defined in Item 408 of Regulation S-K), which provided for the sale of up to 75,000 shares of our common stock and was previously scheduled to terminate on September 30, 2025, and adopted a new Rule 10b5-1 trading arrangement. The new plan provides for the sale of up to 60,000 shares of our common stock and is scheduled to terminate on September 30, 2025.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000804328-24-000075:notes:2]
Significant Accounting Policies
We are a global technology leader, helping to bring intelligent computing everywhere through the development and commercialization of foundational technologies, including 3G (third generation), 4G (fourth generation) and 5G (fifth generation) wireless connectivity, high-performance and low-power computing and on-device artificial intelligence (AI). Our technologies and products have helped power the growth in smartphones and other connected devices. We are scaling our innovations across industries and applications beyond mobile handsets, including automotive and the internet of things (IoT). We derive revenues principally from sales of integrated circuit products and through the licensing of our intellectual property, including patents and other rights.

[0000804328-24-000075:notes:3]
Principles of Consolidation. The consolidated financial statements include the assets, liabilities and operating results of Qualcomm, its subsidiaries and any variable interest entities for which we are deemed to be the primary beneficiary (Note 2). Intercompany transactions and balances have been eliminated.

[0000804328-24-000075:notes:4]
Financial Statement Preparation. The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in our consolidated financial statements and the accompanying notes. Examples of our significant accounting estimates and policies that may involve a higher degree of judgment and complexity than others include: the estimation of sales-based royalty revenues; the impairment of non-marketable equity investments; the valuation of inventories; the impairment of goodwill, other indefinite-lived assets and long-lived assets; the recognition, measurement and disclosure of loss contingencies related to legal and regulatory proceedings; and the calculation of our income tax provision, including the recognition and measurement of uncertain tax positions. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

[0000804328-24-000075:notes:5]
Fiscal Year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Fiscal 2024 included 53 weeks, and fiscal years 2023 and 2022 included 52 weeks. Our fiscal year for 2025 will include 52 weeks.

[0000804328-24-000075:notes:6]
Cash Equivalents. We consider all highly liquid investments with original maturities of 90 days or less to be cash equivalents. Cash equivalents may be comprised of money market funds, certificates of deposit, commercial paper, corporate bonds and notes and certain bank time deposits, U.S. Treasury securities and government-related securities. The carrying amounts approximate fair value due to the short maturities of these instruments.

[0000804328-24-000075:notes:7]
Marketable Securities. Marketable securities include marketable equity securities, available-for-sale debt securities and, from time-to-time, certain time deposits. We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value with all realized and unrealized gains and losses on investments in marketable equity securities and realized gains and losses on available-for-sale debt securities recognized in investment and other income (expense), net. Debt securities are classified as available-for-sale or held-to-maturity at the time of purchase and reevaluated at each balance sheet date. The realized and unrealized gains and losses on marketable securities are determined using the specific identification method.

[0000804328-24-000075:notes:8]
If a debt security has an unrealized loss and we either intend to sell the security or it is more likely than not that we will be required to sell the security before its anticipated recovery, we record an impairment charge to investment and other income (expense), net for the entire amount of the unrealized loss and adjust the amortized cost basis of the security. For the remaining debt securities, if an unrealized loss exists, we separate the impairment into the portion of the loss related to credit factors and the portion of the loss that is not related to credit factors. Unrealized gains or unrealized losses that are not related to credit factors on available-for-sale debt securities are recorded as a component of accumulated other comprehensive income (loss), net of income taxes. Unrealized losses that are related to credit loss factors on available-for-sale debt securities and subsequent adjustments to the credit loss are recorded as an allowance for credit losses, which is included in investment and other income (expense), net. In evaluating whether a credit loss exists, we consider a variety of factors, including the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; the security’s relative performance versus its peers, sector or asset class; the market and economy in general; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.

[0000804328-24-000075:notes:9]
Equity Method and Non-marketable Equity Investments. Equity investments in common stock or in-substance common stock for which we have significant influence, but not control, over the investee and are not the primary beneficiary of the investee’s activities are accounted for under the equity method. Our share of gains and losses in equity method investments are recorded in investment and other income (expense), net. We eliminate unrealized profit or loss related to transactions with equity method investees in relation to our ownership interest in the investee, which is recorded as a component of equity in net earnings (losses) in investees in investment and other income (expense), net. Non-marketable equity investments (for which we do not have significant influence or control) are investments without readily determinable fair values that are generally recorded based on initial cost minus impairment, if any, plus or minus adjustments resulting from observable price changes in orderly transactions for identical or similar securities, if any. All gains and losses on investments in non-marketable equity securities, realized and unrealized, are recognized in investment and other income (expense), net. We monitor equity method and non-marketable equity investments for events or circumstances that could indicate the investments are impaired, such as a deterioration in the investee’s financial condition and business forecasts and lower

[0000804328-24-000075:notes:10]
valuations in recently completed or anticipated financings, and recognize a charge to investment and other income (expense), net for the difference between the estimated fair value and the carrying value. For equity method investments, we record impairment losses in earnings only when impairments are considered other-than-temporary.

[0000804328-24-000075:notes:11]
Derivatives. Our primary objectives for holding derivative instruments are to manage foreign exchange risk for certain foreign currency revenues, operating expenses, receivables and payables and to manage interest rate risk associated with our cash equivalents, marketable securities and long-term debt. Derivative instruments are recorded at fair value and included in other current or noncurrent assets or liabilities based on their maturity dates. Counterparties to these derivative instruments are all major banking institutions. At September 29, 2024, the aggregate fair value of our derivative instruments recorded in total assets and in total liabilities were $30 million and $138 million, respectively. At September 24, 2023, the aggregate fair value of our derivative instruments recorded in total assets and in total liabilities were $32 million and $317 million, respectively.

[0000804328-24-000075:notes:12]
Foreign Currency Hedges: We manage our exposure to foreign exchange market risks, when deemed appropriate, through the use of derivative instruments, including foreign currency forward and option contracts with financial counterparties, that may or may not be designated as hedging instruments. These derivative instruments generally have maturity dates between one and 24 months. Gains and losses arising from such contracts that are designated as cash flow hedging instruments are recorded as a component of accumulated other comprehensive income (loss) as gains and losses on derivative instruments, net of income taxes. The hedging gains and losses in accumulated other comprehensive income (loss) are subsequently reclassified to revenues or costs and expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect our earnings. For foreign currency forward contracts not designated as hedging instruments, the changes in fair value are recorded in investment and other income (expense), net in the period of change.

[0000804328-24-000075:notes:13]
The cash flows associated with such derivative instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction.

[0000804328-24-000075:notes:14]
Interest Rate Swaps: From time to time, we enter into interest rate swap agreements that allow us to effectively convert fixed-rate payments into floating-rate payments on portions of our outstanding long-term debt. We enter into these agreements to manage interest rate risk associated with our cash equivalents and marketable securities, in addition to changes in the fair value of our outstanding debt. These transactions are designated as fair value hedges, and the gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate debt attributable to the hedged risks, are recognized as interest expense in the current period. The interest settlement payments associated with the interest rate swap agreements are classified as cash flows from operating activities in the consolidated statements of cash flows.

[0000804328-24-000075:notes:15]
From time to time, we also enter into forward-starting interest rate swaps to hedge the variability of forecasted interest payments on certain anticipated debt issuances. These swaps are designated as cash flow hedges of forecasted transactions. The gains and losses arising from such contracts are recorded as a component in accumulated other comprehensive income (loss) as gains and losses on derivative instruments. When the anticipated debt is issued, any associated swaps are terminated, and the hedging gains and losses in accumulated other comprehensive income (loss) are recorded to interest expense over the term of the hedged portions of the related debt issued.

[0000804328-24-000075:notes:16]
Gross Notional Amounts: The gross notional amounts of our foreign currency and interest rate derivatives by instrument type were as follows (in millions):

[0000804328-24-000075:notes:17]
|  | September 29,2024 |  | September 24,2023 |
| Forwards | $ | 2,723 |  |  | $ | 2,432 |  |
| Options | 792 |  |  | 667 |  |
| Swaps | 2,050 |  |  | 2,050 |  |
|  | $ | 5,565 |  |  | $ | 5,149 |  |

[0000804328-24-000075:notes:18]
The gross notional amounts of our derivatives by currency were as follows (in millions):

[0000804328-24-000075:notes:19]
|  | September 29,2024 |  | September 24,2023 |
| Chinese renminbi | $ | 1,456 |  |  | $ | 1,333 |  |
| Indian rupee | 1,373 |  |  | 1,151 |  |
| United States dollar | 2,205 |  |  | 2,181 |  |
| Other | 531 |  |  | 484 |  |
|  | $ | 5,565 |  |  | $ | 5,149 |  |

[0000804328-24-000075:notes:20]
Fair Value Measurements. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants as of the measurement date. Applicable accounting guidance provides an established hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Observable inputs are inputs that market participants would use in valuing the asset or liability and are developed based on market data obtained from sources independent of us. Unobservable inputs are inputs that reflect our assumptions about the factors that market participants would use in valuing the asset or liability. There are three levels of inputs that may be used to measure fair value:

[0000804328-24-000075:notes:21]
•Level 1 includes financial instruments for which quoted market prices for identical instruments are available in active markets.

[0000804328-24-000075:notes:22]
•Level 2 includes financial instruments for which there are inputs other than quoted prices included within Level 1 that are observable for the instrument.

[0000804328-24-000075:notes:23]
•Level 3 includes financial instruments for which fair value is derived from valuation techniques in which one or more significant inputs are unobservable, including our own assumptions.

[0000804328-24-000075:notes:24]
Assets and liabilities measured at fair value are classified based on the lowest level of input that is significant to the fair value measurement. We review the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy. We recognize transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer to occur.

[0000804328-24-000075:notes:25]
Cash Equivalents and Marketable Securities: We obtain pricing information from quoted market prices, pricing vendors or quotes from brokers/dealers. We conduct reviews of our primary pricing vendors to determine whether the inputs used in the vendor’s pricing processes are deemed to be observable. Contractual sale restrictions are not considered in measuring the fair value of marketable equity securities. The fair value for interest-bearing securities includes accrued interest. The fair value of U.S. Treasury securities and government-related securities, corporate bonds and notes and common stock is generally determined using standard observable inputs, including reported trades, market based quotes, matrix pricing, benchmark yields, broker/dealer quotes, issuer spreads, two-sided markets and/or benchmark securities. The fair value of mortgage- and asset-backed securities is derived from the use of matrix pricing (prices for similar securities) or, in some cases, cash flow pricing models with observable inputs, such as contractual terms, maturity, credit rating and/or securitization structure to determine the timing and amount of future cash flows.

[0000804328-24-000075:notes:26]
Derivative Instruments: Derivative instruments that are traded on an exchange are valued using quoted market prices and are included in Level 1. Derivative instruments that are not traded on an exchange are valued using conventional calculations/models that are primarily based on observable inputs, such as foreign currency exchange rates, volatilities and interest rates, and therefore, such derivative instruments are included in Level 2.

[0000804328-24-000075:notes:27]
Other Investments and Other Liabilities: Other investments and other liabilities included in Level 1 are comprised of our deferred compensation plan liabilities and related assets, which consist of mutual funds and are included in other current assets and other assets. Gains and losses on the revaluation of our deferred compensation plan assets are recorded in investment and other income (expense), net. Corresponding offsetting amounts related to the revaluation of our deferred compensation plan liabilities are included in operating expenses. Other investments included in Level 3 are comprised of convertible debt instruments issued by private companies. The inputs we use to estimate the fair values of these instruments are generally unobservable, and therefore, they are included in Level 3.

[0000804328-24-000075:notes:28]
Nonrecurring Fair Value Measurements: We measure certain assets and liabilities at fair value on a nonrecurring basis. These assets and liabilities include equity method and non-marketable equity investments, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired, all of which are generally measured based on unobservable inputs using an income or market approach.

[0000804328-24-000075:notes:29]
Inventories. Inventories are valued at the lower of cost and net realizable value using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers and our own forecasts of customer demand, among other factors. This valuation also requires us to make judgments and assumptions based on information currently available about market conditions, including competition, anticipated technological changes, internal product life cycle and development plans, product pricing and other broader market conditions that may impact customer demand, such as the impact of the macroeconomic environment in fiscal 2022 and 2023. We generally place binding purchase orders with our suppliers in advance of receiving contractually binding forecasts and/or purchase orders from our customers. The time period between placing purchase orders with our suppliers and receiving contractually binding forecasts and/or purchase orders from our customers has increased and may continue to increase as a result of extended manufacturing lead-times, driven in part by a continued transition to leading-edge technologies and/or increased complexity in the manufacturing process of our products. If we overestimate demand for our products, the amount of our loss will be impacted by our ability to reduce inventory purchases from our suppliers. Further, if our customers cancel purchase orders or alter forecasts this may result in excess inventory on hand. Our assumptions of future product demand are

[0000804328-24-000075:notes:30]
inherently uncertain, and changes in our estimates and assumptions may cause us to record additional write-downs in the future if demand forecasted for specific products is greater than actual demand.

[0000804328-24-000075:notes:31]
Property, Plant and Equipment. Property, plant and equipment are recorded at cost and depreciated or amortized using the straight-line method over their estimated useful lives. Upon the retirement or disposition of property, plant and equipment, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded, when appropriate. Buildings on owned land are depreciated over 30 years, and building improvements are depreciated over 15 years. Leasehold improvements and buildings on leased land are amortized over the shorter of their estimated useful lives, not to exceed 15 years and 30 years, respectively, or the remaining term of the related lease. Other property, plant and equipment have useful lives ranging from 2 to 15 years. Maintenance, repairs and minor renewals or betterments are charged to expense as incurred.

[0000804328-24-000075:notes:32]
Operating Leases. Operating lease assets and liabilities are recognized for leases with lease terms greater than 12 months based on the present value of the future lease payments over the lease term at the commencement date. Operating leases are included in other assets, other current liabilities and other liabilities on our consolidated balance sheet. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise such option. We account for substantially all lease and related non-lease components together as a single lease component. Operating lease expense is recognized on a straight-line basis over the lease term.

[0000804328-24-000075:notes:33]
Goodwill and Other Intangible Assets. Goodwill represents the excess of purchase price over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Acquired intangible assets other than goodwill are amortized over their useful lives unless the lives are determined to be indefinite. For intangible assets purchased in a business combination, the estimated fair values of the assets acquired are used to establish their recorded values. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value. An estimate of fair value can be affected by many assumptions that require significant judgment. For example, the income approach generally requires us to use assumptions to estimate the present value of future cash flows including those related to total addressable market, pricing and share forecasts, competition, technology obsolescence, future tax rates and discount rates. Our estimate of the fair value of certain assets may differ materially from that determined by others who use different assumptions or utilize different business models and from the future cash flows actually realized.

[0000804328-24-000075:notes:34]
Impairment of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. Goodwill and other indefinite-lived intangible assets are tested annually for impairment in the fourth fiscal quarter, and in interim periods if events or changes in circumstances indicate that the assets may be impaired. If a qualitative assessment is used and we determine that the fair value of a reporting unit or indefinite-lived intangible asset is more likely than not (i.e., a likelihood of more than 50%) less than its carrying amount, a quantitative impairment test will be performed. If goodwill is quantitatively assessed for impairment and a reporting unit’s carrying value exceeds its fair value, the difference is recorded as an impairment. Other indefinite-lived intangible assets are quantitatively assessed for impairment, if necessary, by comparing their estimated fair values to their carrying values. If the carrying value exceeds the fair value, the difference is recorded as an impairment. Our judgments regarding the existence of impairment indicators and future cash flows related to goodwill, other indefinite-lived assets and long-lived assets may be based on operational performance of our businesses, market conditions, expected selling price and/or other factors. Although there are inherent uncertainties in this assessment process, the estimates and assumptions we use, including estimates of future cash flows and discount rates, are consistent with our internal planning, when appropriate. If these estimates or their related assumptions change in the future, we may be required to record an impairment charge on a portion or all of such assets. Furthermore, we cannot predict the occurrence of future impairment-triggering events nor the impact such events might have on our reported asset values.

[0000804328-24-000075:notes:35]
Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by comparing the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Long-lived assets to be disposed of by sale are reported at the lower of their carrying amounts or their estimated fair values less costs to sell and are not depreciated.

[0000804328-24-000075:notes:36]
Revenue Recognition. We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We also generate revenues from licensing system software and by performing development and other services and from other product sales. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of our performance obligations.

[0000804328-24-000075:notes:37]
Revenues from sales of our products are recognized upon transfer of control to the customer, which is generally at the time of shipment. Revenues from providing services are typically recognized over time as our performance obligation is satisfied. Revenues from providing services and licensing system software were each less than 5% of total revenues for all periods presented.

[0000804328-24-000075:notes:38]
We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products.

[0000804328-24-000075:notes:39]
License agreements contain a single performance obligation that represents ongoing access to a portfolio of intellectual property over the license term since such agreements provide the licensee the right to access a portfolio of intellectual property that exists at inception of the license agreement and to updates and new intellectual property that is added to the licensed portfolio during the term of the agreement that are highly interdependent or interrelated.

[0000804328-24-000075:notes:40]
Licensees pay per-unit royalties based on their sales of products incorporating or using our licensed intellectual property and, to a lesser extent, lump sum payments (license fees, substantially all of which were recognized prior to fiscal 2024). License fees are recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee. Per-unit royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items), with certain products subject to per unit minimums and/or per unit caps. Certain products may also have a fixed royalty amount per unit. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, considering all relevant information (historical, current and forecasted) that is reasonably available to us. Our estimates of sales-based royalties are based largely on preliminary royalty estimates provided by our licensees and, to a lesser extent, an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property, combined with an estimate of the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products. In the periods presented, we have recognized immaterial differences between preliminary royalty estimates provided to us by licensees and actual amounts reported and paid by licensees, which are generally received the following quarter, as licensees have not completed their royalty reporting process at the time estimates are provided to us, and in certain cases, they do not provide all necessary information in order for us to calculate an estimate of royalties due, which requires us to independently estimate certain information. We also consider in our estimates of sales-based royalties any changes in pricing we plan or expect to make and certain constraints on our ability to estimate such royalties. As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

[0000804328-24-000075:notes:41]
We account for a contract with a customer/licensee when it is legally enforceable, the parties are committed to perform their respective obligations, the rights of the parties regarding the goods and/or services to be transferred are identified, payment terms are identified, the contract has commercial substance and collectability of substantially all of the consideration is probable, which for product sales, is generally when a customer purchase order is executed and for licensing revenues, is generally upon execution of a license agreement. If all such conditions are not met, revenues and any associated receivables are generally not recognized until such time that the required conditions are met. Cash collected from customers prior to a contract existing is recorded to other customer-related liabilities in other current liabilities.

[0000804328-24-000075:notes:42]
From time to time, companies initiate various strategies in an attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property, which may include disputing, underreporting, underpaying, not reporting and/or not paying royalties owed to us under their license agreements with us, or reporting to us in a manner that is not in compliance with their contractual obligations. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in the revenue recognition guidance, which includes, among other items, evaluating whether our license agreements remain valid and enforceable and evaluating licensees’ conduct and whether they remain committed to perform their respective obligations. We also estimate and recognize licensing revenues only to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur, which includes, among other items, determining the expected impact, if any, to revenues of any license agreements that may be renegotiated and/or are newly entered into. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us. These aforementioned estimates may require significant judgment.

[0000804328-24-000075:notes:43]
We measure revenues (including our estimates of sales-based royalties) based on the amount of consideration we expect to receive in exchange for products or services. We record reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of our products and technologies, in the period that the related revenues are earned. For certain QCT (Qualcomm CDMA Technologies) customer incentive arrangements, there is complexity in applying certain contractual terms to determine the amount recorded as a reduction to revenues. For the periods presented, no significant reversals of revenues have been made related to such amounts previously recorded. The amounts accrued for customer incentive arrangements are recorded as a reduction to accounts receivable, net or as other current liabilities based on whether we have the intent and enforceable right of offset. Certain amounts recorded as a reduction to revenues for customer incentive arrangements are considered variable consideration and are included in the transaction price primarily based on estimating the most likely amount expected to be provided to the customer/licensee.

[0000804328-24-000075:notes:44]
Adjustments made to revenues in subsequent periods to reflect changes in estimates as new information becomes available are included in our disclosure of revenues recognized from previously satisfied performance obligations (Note 2).

[0000804328-24-000075:notes:45]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied

[0000804328-24-000075:notes:46]
performance obligations. Our payment terms are generally short-term in duration, with payment due shortly after delivery for product sales and within the following quarter for QTL sales-based royalties.

[0000804328-24-000075:notes:47]
Share-Based Compensation. Share-based compensation expense for equity-classified awards, principally related to restricted stock units (RSUs), is measured at the grant date, or at the acquisition date for awards assumed in business combinations, based on the estimated fair value of the award and is recognized over the employee’s requisite service period. The fair values of RSUs are estimated based on the fair market values of the underlying stock on the dates of grant or dates the RSUs are assumed. Share-based compensation expense is adjusted to exclude amounts related to share-based awards that are expected to be forfeited.

[0000804328-24-000075:notes:48]
Legal and Regulatory Proceedings. We are currently involved in certain legal and regulatory proceedings. Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Investigations by antitrust and trade regulation agencies are not conducted in a consistent manner across jurisdictions. Further, each country and agency has different sets of laws, rules and regulations, both substantive and procedural, as well as different legal principles, theories and potential remedies, and some agencies may seek to use the investigation to advance domestic policy goals. Depending on the jurisdiction, these investigations can involve non-transparent procedures under which we may not receive access to evidence relied upon by the enforcement agency or that may be exculpatory and may not be informed of the specific legal theories or evidence considered or relied upon by the agency. Unlike in civil litigation in the United States, in foreign proceedings, we may not be entitled to discovery or depositions, allowed to cross-examine witnesses or confront our accusers. As a result, we may not be aware of, and may not be entitled to know, all allegations against us, or the information or documents provided to, or discovered or prepared by, the agency. Accordingly, we may have little or no idea what an agency’s intent is with respect to liability, penalties or the timing of a decision. In many cases the agencies are given significant discretion, and any available precedent may have limited, if any, predictive value in their jurisdictions or other jurisdictions. Accordingly, we cannot predict the outcome of these matters. A broad range of remedies with respect to our business practices that are deemed to violate applicable laws are potentially available. These remedies may include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or to modify our business practices.

[0000804328-24-000075:notes:49]
If there is at least a reasonable possibility that a material loss may have been incurred associated with pending legal and regulatory proceedings, we disclose such fact, and if reasonably estimable, we provide an estimate of the possible loss or range of possible loss. We record our best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, we record the minimum estimated liability. As additional information becomes available, we assess the potential liability related to pending legal and regulatory proceedings and revise our estimates and update our disclosures accordingly. Significant judgment is required in both the determination of probability and the determination as to whether a loss is reasonably estimable. Our legal costs associated with defending ourselves are recorded to expense as incurred.

[0000804328-24-000075:notes:50]
Foreign Currency. Certain foreign subsidiaries use a local currency as the functional currency. Resulting translation gains or losses are recorded as a component of accumulated other comprehensive income (loss). Transaction gains or losses related to balances denominated in a currency other than the functional currency of the entity involved are recognized in the consolidated statements of operations.

[0000804328-24-000075:notes:51]
Income Taxes. The asset and liability approach is used to recognize deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax bases of assets and liabilities. Tax law and rate changes are reflected in income in the period such changes are enacted. We record a valuation allowance to reduce deferred tax assets to the amount that is more likely than not to be realized. We include interest and penalties related to income taxes, including unrecognized tax benefits, within income tax expense. We classify all deferred tax assets and liabilities as noncurrent in the consolidated balance sheets. We recognize excess tax benefits and shortfall tax detriments associated with share-based awards in the consolidated statements of operations, as a component of income tax expense, when realized.

[0000804328-24-000075:notes:52]
Our income tax returns are based on calculations and assumptions that are subject to examination by the Internal Revenue Service (IRS) and other tax authorities. In addition, the calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts that give rise to a revision become known.

[0000804328-24-000075:notes:53]
We are subject to income taxes in the United States and numerous foreign jurisdictions, and the assessment of our income tax positions involves dealing with uncertainties in the application of complex tax laws and regulations in various taxing jurisdictions. In addition, the application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws and regulations themselves are subject to change as a result of changes in fiscal policy, changes in legislation, the evolution of regulations and court rulings. Significant judgments and estimates are required in

[0000804328-24-000075:notes:54]
determining our provision for income taxes, including those related to special deductions such as FDII (foreign-derived intangible income), tax incentives, intercompany research and development cost-sharing arrangements, transfer pricing, tax credits and the realizability of deferred tax assets. While we believe we have appropriate support for the positions we have taken or that we plan to take on our tax returns, we regularly assess the potential outcomes of examinations by taxing authorities in determining the adequacy of our provision for income taxes. Therefore, the actual liability for U.S. or foreign taxes may be materially different from our estimates, which could result in the need to record additional tax liabilities or potentially reverse previously recorded tax liabilities. For tax years prior to fiscal 2021, we are participating in the IRS Compliance Assurance Process program whereby we endeavor to agree with the IRS on the treatment of all issues prior to filing our federal return.

[0000804328-24-000075:notes:55]
Stock Repurchases. To reflect share repurchases in the consolidated balance sheet, we (i) reduce common stock for the par value of the shares, (ii) reduce paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) record the residual amount, if any, to retained earnings.

[0000804328-24-000075:notes:56]
Earnings Per Share. Basic earnings per share is computed by dividing net income by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of the weighted-average number of common shares outstanding and the weighted-average number of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans, during the reporting period, using the treasury stock method. The following table provides information about the diluted earnings per share calculation (in millions):

[0000804328-24-000075:notes:57]
|  | 2024 |  | 2023 |  | 2022 |
| Dilutive common share equivalents included in diluted shares | 14 |  |  | 9 |  |  | 14 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 4 |  |  | 7 |  |  | 1 |  |

[0000804328-24-000075:notes:58]
Recent Accounting Pronouncements Not Yet Adopted.

[0000804328-24-000075:notes:59]
Segment Reporting Disclosures: In November 2023, the Financial Accounting Standards Board (FASB) issued new requirements to disclose certain incremental segment information on an annual and interim basis, including (among other items) additional disclosure about significant segment expenses. We will adopt the new requirements for our annual periods starting in fiscal 2025 (and interim periods thereafter) on a retrospective basis.

[0000804328-24-000075:notes:60]
Income Tax Disclosures: In December 2023, the FASB issued new requirements to disclose annually certain additional detailed income tax information related to the effective tax rate reconciliation and income taxes paid, among other items. We will adopt the new requirements starting in fiscal 2026 on a retrospective basis.

[0000804328-24-000075:notes:61]
Income Statement - Expense Disaggregation Disclosures: In November 2024, the FASB issued new requirements to disclose certain additional expense information on an annual and interim basis, including (among other items) the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We will adopt the new requirements starting in fiscal 2028 on a prospective basis.


## us-gaap:LesseeLeasesPolicyTextBlock

[0000804328-24-000075:notes:62]
Operating Leases. Operating lease assets and liabilities are recognized for leases with lease terms greater than 12 months based on the present value of the future lease payments over the lease term at the commencement date. Operating leases are included in other assets, other current liabilities and other liabilities on our consolidated balance sheet. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise such option. We account for substantially all lease and related non-lease components together as a single lease component. Operating lease expense is recognized on a straight-line basis over the lease term.
We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000804328-24-000075:notes:63]
performance obligations. Our payment terms are generally short-term in duration, with payment due shortly after delivery for product sales and within the following quarter for QTL sales-based royalties.
We disaggregate our revenues by segment (Note 8), by products and services (as presented on our consolidated statements of operations), and for our QCT segment, by revenue stream, which is based on the industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-24-000075:notes:64]
Composition of Certain Financial Statement Items

[0000804328-24-000075:notes:65]
| Accounts Receivable (in millions) |  |  |  |
|  | September 29,2024 |  | September 24,2023 |
| Trade, net of allowances for doubtful accounts | $ | 2,347 |  |  | $ | 1,923 |  |
| Unbilled | 1,546 |  |  | 1,223 |  |
| Other | 36 |  |  | 37 |  |
|  | $ | 3,929 |  |  | $ | 3,183 |  |

[0000804328-24-000075:notes:66]
| Inventories (in millions) |  |  |  |
|  | September 29,2024 |  | September 24,2023 |
| Raw materials | $ | 340 |  |  | $ | 176 |  |
| Work-in-process | 3,497 |  |  | 4,096 |  |
| Finished goods | 2,586 |  |  | 2,150 |  |
|  | $ | 6,423 |  |  | $ | 6,422 |  |

[0000804328-24-000075:notes:67]
| Property, Plant and Equipment (in millions) |  |  |  |
|  | September 29,2024 |  | September 24,2023 |
| Land | $ | 169 |  |  | $ | 169 |  |
| Buildings and improvements | 1,888 |  |  | 1,849 |  |
| Computer equipment and software | 2,022 |  |  | 1,773 |  |
| Machinery and equipment | 8,647 |  |  | 8,078 |  |
| Furniture and office equipment | 139 |  |  | 130 |  |
| Leasehold improvements | 550 |  |  | 485 |  |
| Construction in progress | 126 |  |  | 226 |  |
|  | 13,541 |  |  | 12,710 |  |
| Less accumulated depreciation and amortization | (8,876) |  |  | (7,668) |  |
|  | $ | 4,665 |  |  | $ | 5,042 |  |

[0000804328-24-000075:notes:68]
Depreciation and amortization expense related to property, plant and equipment for fiscal 2024, 2023 and 2022 was $1.4 billion, $1.4 billion and $1.3 billion, respectively.

[0000804328-24-000075:notes:69]
Goodwill and Other Intangible Assets. We allocate goodwill to our reporting units for impairment testing purposes. The following table presents the goodwill allocated to our segments, as described in Note 8, as well as the changes in the carrying amounts of goodwill during fiscal 2024 and 2023 (in millions):

[0000804328-24-000075:notes:70]
|  |  | QCT |  | QTL |  |  |  | Total |
| Balance at September 25, 2022 |  | $ | 9,777 |  |  | $ | 731 |  |  |  |  | $ | 10,508 |  |
| Acquisitions |  | 76 |  |  | — |  |  |  |  | 76 |  |
| Foreign currency translation adjustments |  | 56 |  |  | 2 |  |  |  |  | 58 |  |
| Balance at September 24, 2023 (1) |  | 9,909 |  |  | 733 |  |  |  |  | 10,642 |  |
| Acquisitions |  | 126 |  |  | — |  |  |  |  | 126 |  |
| Foreign currency translation adjustments |  | 30 |  |  | 1 |  |  |  |  | 31 |  |
| Balance at September 29, 2024 (1) |  | $ | 10,065 |  |  | $ | 734 |  |  |  |  | $ | 10,799 |  |

[0000804328-24-000075:notes:71]
(1) Cumulative goodwill impairments were $812 million at both September 29, 2024 and September 24, 2023.

[0000804328-24-000075:notes:72]
The components of other intangible assets, net were as follows (in millions):

[0000804328-24-000075:notes:73]
|  | September 29, 2024 |  | September 24, 2023 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |
| Technology-based | $ | 2,498 |  |  | $ | (1,275) |  |  | 9 |  | $ | 4,292 |  |  | $ | (2,912) |  |  | 12 |
| Other | 69 |  |  | (48) |  |  | 11 |  | 70 |  |  | (42) |  |  | 11 |
|  | $ | 2,567 |  |  | $ | (1,323) |  |  | 9 |  | $ | 4,362 |  |  | $ | (2,954) |  |  | 11 |

[0000804328-24-000075:notes:74]
All of these intangible assets are subject to amortization, other than acquired in-process research and development which had a carrying value of $188 million and $435 million at September 29, 2024 and September 24, 2023, respectively. Amortization expense related to these intangible assets was $311 million, $418 million and $482 million for fiscal 2024, 2023 and 2022, respectively. At September 29, 2024, amortization expense related to other intangible assets, including acquired in-process research and development beginning upon the completion of the underlying projects, is expected to be $290 million, $274 million, $187 million, $156 million and $129 million for each of the five years from fiscal 2025 through 2029, respectively, and $208 million thereafter.

[0000804328-24-000075:notes:75]
Equity Method and Non-marketable Equity Investments. The carrying values of our equity method and non-marketable equity investments are recorded in other assets and were as follows (in millions):

[0000804328-24-000075:notes:76]
|  | September 29,2024 |  | September 24,2023 |
| Equity method investments | $ | 154 |  |  | $ | 164 |  |
| Non-marketable equity investments (1) | 1,187 |  |  | 1,072 |  |
|  | $ | 1,341 |  |  | $ | 1,236 |  |

[0000804328-24-000075:notes:77]
(1) Cumulative unrealized gains were $370 million and $241 million at September 29, 2024 and September 24, 2023, respectively. Cumulative unrealized losses, including impairments, were $385 million and $335 million at September 29, 2024 and September 24, 2023, respectively.

[0000804328-24-000075:notes:78]
| Other Current Liabilities (in millions) |  |  |  |
|  | September 29,2024 |  | September 24,2023 |
| Customer incentives and other customer-related liabilities | $ | 2,480 |  |  | $ | 1,821 |  |
| Income taxes payable | 1,080 |  |  | 1,717 |  |
| Other | 865 |  |  | 953 |  |
|  | $ | 4,425 |  |  | $ | 4,491 |  |

[0000804328-24-000075:notes:79]
Revenues. We disaggregate our revenues by segment (Note 8), by products and services (as presented on our consolidated statements of operations), and for our QCT segment, by revenue stream, which is based on the industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets. QCT revenue streams were as follows (in millions):

[0000804328-24-000075:notes:80]
|  |  |  |  |  | 2024 |  | 2023 |  | 2022 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 24,863 |  |  | $ | 22,570 |  |  | $ | 28,815 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 2,910 |  |  | 1,872 |  |  | 1,509 |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 5,423 |  |  | 5,940 |  |  | 7,353 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 33,196 |  |  | $ | 30,382 |  |  | $ | 37,677 |  |

[0000804328-24-000075:notes:81]
(1) Includes revenues from products sold for use in mobile handsets.

[0000804328-24-000075:notes:82]
(2) Includes revenues from products sold for use in automobiles, including connectivity, digital cockpit and ADAS/AD.

[0000804328-24-000075:notes:83]
(3) Primarily includes products sold for use in the following industries and applications: consumer (including PCs, tablets, voice and music and XR), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, tracking and logistics and utilities).

[0000804328-24-000075:notes:84]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods generally include certain QCT sales-based royalty revenues related to system software, certain amounts related to QCT customer incentives and QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due) and were as follows (in millions):

[0000804328-24-000075:notes:85]
|  | 2024 |  | 2023 |  | 2022 |
| Revenues recognized from previously satisfied performance obligations | $ | 558 |  |  | $ | 598 |  |  | $ | 788 |  |

[0000804328-24-000075:notes:86]
Unearned revenues (which are considered contract liabilities) consist primarily of certain customer contracts for which QCT received fees upfront and QTL license fees for intellectual property with continuing performance obligations (substantially all of which were recognized prior to fiscal 2024). In fiscal 2024 and fiscal 2023, we recognized revenues of $312 million and $355 million, respectively, that were recorded as unearned revenues at September 24, 2023 and September 25, 2022, respectively.

[0000804328-24-000075:notes:87]
Remaining performance obligations, which are primarily included in unearned revenues (as presented on our consolidated balance sheet), represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license

[0000804328-24-000075:notes:88]
agreements. Our patent license agreements with key OEMs are generally long-term, with terms expiring at varying dates between fiscal 2025 and 2031. We generally seek to renew or renegotiate such license agreements prior to expiration.

[0000804328-24-000075:notes:89]
Concentrations. A significant portion of our revenues are concentrated with a small number of customers/licensees of our QCT and QTL (Qualcomm Technology Licensing) segments. The comparability of customer/licensee concentrations for the periods presented are impacted by the timing of customer/licensees device launches and/or innovation cycles and other seasonal trends, among other fluctuations in demand. Revenues from each customer/licensee that were 10% or greater of total revenues were as follows:

[0000804328-24-000075:notes:90]
|  | September 29,2024 |  | September 24,2023 |  | September 25,2022 |
| Customer/licensee (x) | 22 | % |  | 27 | % |  | 21 | % |
| Customer/licensee (y) | 19 |  |  | 21 |  |  | 21 |  |
| Customer/licensee (z) | 12 |  |  | * |  | * |

[0000804328-24-000075:notes:91]
* Less than 10%

[0000804328-24-000075:notes:92]
We rely on sole- or limited-source suppliers for some products, particularly products in our QCT segment, subjecting us to possible shortages of raw materials or manufacturing capacity. The loss of a supplier or the inability of a supplier to meet performance or quality specifications or delivery schedules could harm our ability to meet our delivery obligations and/or negatively impact our revenues, business operations and ability to compete for future business.

[0000804328-24-000075:notes:93]
Other Income, Costs and Expenses. Other expenses in fiscal 2024 consisted primarily of restructuring and restructuring-related charges (substantially all of which related to severance costs) and a charge related to the settlement of the securities class action lawsuit (Note 7).

[0000804328-24-000075:notes:94]
Other expenses in fiscal 2023 consisted of $712 million in total restructuring and restructuring-related charges (substantially all of which related to severance costs, resulting from certain cost reduction actions committed to in fiscal 2023) and a $150 million intangible asset impairment charge related to in-process research and development.

[0000804328-24-000075:notes:95]
In the third quarter of fiscal 2022, the General Court of the European Union issued a ruling annulling a decision made by the European Commission (EC) in fiscal 2018. As a result of the court’s decision, we recorded a $1.1 billion benefit to other income in fiscal 2022 resulting from the reversal of the previously accrued EC fine.

[0000804328-24-000075:notes:96]
Discontinued Operations. In fiscal 2022, we and SSW Partners, a New York-based investment partnership, entered into and closed a definitive agreement to acquire Veoneer, Inc. (Veoneer). Total cash consideration paid in the transaction was $4.7 billion. We acquired Veoneer’s Arriver business and SSW Partners retained Veoneer’s Tier-1 automotive supplier businesses, primarily consisting of the Active Safety and the Restraint Control Systems businesses (the Non-Arriver businesses), with the intent to sell such businesses in multiple transactions. In exchange for us funding substantially all of the cash consideration payable in the transaction, we obtained the right to receive a majority of the proceeds upon the sale of the Non-Arriver businesses by SSW Partners. On June 1, 2023, SSW Partners completed the sale of Veoneer’s Active Safety business to Magna International Inc. for net cash proceeds of $1.5 billion. On March 1, 2024, SSW Partners completed the sale of Veoneer’s Restraint Control Systems (RCS) business to American Industrial Partners Capital Fund VII.

[0000804328-24-000075:notes:97]
Although we did not own or operate the Non-Arriver businesses, we were the primary beneficiary, within the meaning of the FASB accounting guidance related to consolidation (ASC 810), of these businesses under the variable interest model, until sold by SSW. Factors considered in reaching this conclusion included, among others: (i) our involvement in the design of and our funding of substantially all of the total cash consideration payable in the transaction and (ii) our obligation to absorb losses and rights to receive returns from the Non-Arriver businesses. Accordingly, through the date of disposition by SSW Partners, the assets and liabilities of the Non-Arriver businesses have been consolidated and presented as held for sale on our consolidated balance sheets, and the operating results (including the gain or loss on sale, the amounts of which were not material) have been presented as discontinued operations. Also, the cash flows provided (used) by the Non-Arriver businesses are reflected separately as discontinued operations, with the cash proceeds from the sale of the Active Safety and RCS businesses presented as investing activities.

[0000804328-24-000075:notes:98]
| Investment and Other Income (Expense), Net (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  | 2024 |  | 2023 |  | 2022 |
| Interest and dividend income |  |  |  |  |  |  |  | $ | 675 |  |  | $ | 313 |  |  | $ | 91 |  |
| Net gains (losses) on marketable securities |  |  |  |  |  |  |  | 14 |  |  | 75 |  |  | (363) |  |
| Net gains on other investments |  |  |  |  |  |  |  | 175 |  |  | 21 |  |  | 113 |  |
| Net gains (losses) on deferred compensation plan assets |  |  |  |  |  |  |  | 198 |  |  | 86 |  |  | (141) |  |
| Impairment losses on other investments |  |  |  |  |  |  |  | (79) |  |  | (132) |  |  | (47) |  |
| Other |  |  |  |  |  |  |  | (21) |  |  | (14) |  |  | (25) |  |
|  |  |  |  |  |  |  |  | $ | 962 |  |  | $ | 349 |  |  | $ | (372) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-24-000075:notes:99]
Income Taxes
The components of the income tax provision from continuing operations were as follows (in millions):

[0000804328-24-000075:notes:100]
|  | 2024 |  | 2023 |  | 2022 |
| Current provision: |  |  |  |  |  |
| Federal | $ | 1,306 |  |  | $ | 1,229 |  |  | $ | 1,114 |  |
| State | 3 |  |  | 10 |  |  | 1 |  |
| Foreign (1) | 805 |  |  | 491 |  |  | 906 |  |
|  | 2,114 |  |  | 1,730 |  |  | 2,021 |  |
| Deferred (benefit) provision: |  |  |  |  |  |
| Federal | (1,553) |  |  | (1,475) |  |  | (34) |  |
| State | (4) |  |  | (8) |  |  | 15 |  |
| Foreign (1) | (331) |  |  | (143) |  |  | 10 |  |
|  | (1,888) |  |  | (1,626) |  |  | (9) |  |
|  | $ | 226 |  |  | $ | 104 |  |  | $ | 2,012 |  |

[0000804328-24-000075:notes:101]
(1) The foreign component of the income tax provision included foreign withholding taxes on royalty revenues included in U.S. earnings.

[0000804328-24-000075:notes:102]
The components of income from continuing operations before income taxes by U.S. and foreign jurisdictions were as follows (in millions):

[0000804328-24-000075:notes:103]
|  | 2024 |  | 2023 |  | 2022 |
| United States | $ | 9,169 |  |  | $ | 6,400 |  |  | $ | 12,537 |  |
| Foreign | 1,167 |  |  | 1,043 |  |  | 2,461 |  |
|  | $ | 10,336 |  |  | $ | 7,443 |  |  | $ | 14,998 |  |

[0000804328-24-000075:notes:104]
The following is a reconciliation of the expected statutory federal income tax provision to our actual income tax provision from continuing operations (in millions, except percentages). A significant portion of our U.S. income qualifies for preferential treatment as FDII at a 13% effective tax rate.

[0000804328-24-000075:notes:105]
|  | 2024 |  | 2023 |  | 2022 |
| Expected income tax provision at federal statutory tax rate | $ | 2,171 |  |  | $ | 1,563 |  | $ | 3,150 |  |
| Benefit from FDII deduction, excluding the impact of capitalizing research and development expenditures | (596) |  |  | (447) |  |  | (753) |  |
| Benefit from FDII deduction related to capitalizing research and development expenditures | (585) |  |  | (598) |  |  | — |  |
| Benefit related to the transfer of intellectual property between foreign subsidiaries | (317) |  |  | — |  |  | — |  |
| Benefit related to research and development tax credits | (259) |  |  | (235) |  |  | (224) |  |
| Excess tax (benefit) deficiency associated with share-based awards | (176) |  |  | 3 |  |  | (257) |  |
| Foreign currency (gains) losses related to Korean withholding tax receivable | (21) |  |  | (66) |  |  | 243 |  |
| Benefit from fiscal 2021 and 2022 FDII deductions related to a change in sourcing of research and development expenditures | — |  |  | (126) |  |  | — |  |
| Benefit from releasing valuation allowance on unutilized foreign loss carryforwards | — |  |  | (114) |  |  | — |  |
| Nontaxable reversal of 2018 EC fine | — |  |  | — |  |  | (224) |  |
| Other | 9 |  |  | 124 |  |  | 77 |  |
|  | $ | 226 |  |  | $ | 104 |  |  | $ | 2,012 |  |
| Effective tax rate | 2 | % |  | 1 | % |  | 13 | % |

[0000804328-24-000075:notes:106]
Beginning in fiscal 2023, for federal income tax purposes, we are required to capitalize and amortize domestic research and development expenditures over five years and foreign research and development expenditures over fifteen years (such expenditures were previously deducted as incurred). Our cash flows from operations are adversely affected due to significantly higher cash tax payments. However, since the resulting deferred tax asset is established at the statutory rate of 21% (rather than the current effective tax rate of 13% to 16% after considering the FDII deduction), capitalization favorably

[0000804328-24-000075:notes:107]
affects our total provision for income taxes and results of operations. The adverse cash flow impact and favorable tax provision impact will diminish in future years as capitalized research and development expenditures continue to amortize.

[0000804328-24-000075:notes:108]
In the fourth quarter of fiscal 2024, we completed an intra-group transfer of intellectual property to better align certain intellectual property ownership within our QCT business, which resulted in the recognition of a tax benefit of $317 million during the fourth quarter of fiscal 2024 from the establishment of a deferred tax asset. Such tax benefit was based on the value of the intellectual property transferred, which was measured using an income approach based on significant unobservable inputs.

[0000804328-24-000075:notes:109]
Beginning in fiscal 2019, as a result of certain court rulings in Korea, among other factors, we decided to apply for a partial refund claim for taxes previously withheld from licensees in Korea on payments due under their license agreements to which we have claimed a foreign tax credit in the United States. As a result, $2.2 billion and $2.0 billion was recorded as a noncurrent income taxes receivable (recorded in other assets) at September 29, 2024 and September 24, 2023, respectively, and $2.5 billion and $2.3 billion was recorded as a noncurrent liability for uncertain tax benefits (recorded in other liabilities) at September 29, 2024 and September 24, 2023, respectively.

[0000804328-24-000075:notes:110]
At September 29, 2024, our remaining future payments were $1.0 billion for a one-time repatriation tax accrued in fiscal 2018, after application of certain tax credits, which is payable in installments over the next two years. At September 29, 2024, $530 million was recorded in other current liabilities, reflecting the next installment due in January 2025, with the remaining noncurrent portion presented in other liabilities on our balance sheet.

[0000804328-24-000075:notes:111]
We had deferred tax assets and deferred tax liabilities as follows (in millions):

[0000804328-24-000075:notes:112]
|  | September 29,2024 |  | September 24,2023 |
| Capitalized research and development expenditures | $ | 3,015 |  |  | $ | 1,490 |  |
| Unused tax credits | 2,172 |  |  | 1,819 |  |
| Customer incentives | 769 |  |  | 659 |  |
| Unused net operating losses | 719 |  |  | 364 |  |
| Accrued liabilities and reserves | 397 |  |  | 401 |  |
| Operating lease liabilities | 282 |  |  | 216 |  |
| Share-based compensation | 152 |  |  | 285 |  |
| Unrealized losses on other investments and marketable securities | 146 |  |  | 159 |  |
| Other | 459 |  |  | 409 |  |
| Total gross deferred tax assets | 8,111 |  |  | 5,802 |  |
| Valuation allowance | (2,061) |  |  | (1,803) |  |
| Total net deferred tax assets | 6,050 |  |  | 3,999 |  |
| Intangible assets | (388) |  |  | (335) |  |
| Operating lease assets | (248) |  |  | (194) |  |
| Unrealized gains on other investments and marketable securities | (169) |  |  | (101) |  |
| Other | (197) |  |  | (170) |  |
| Total deferred tax liabilities | (1,002) |  |  | (800) |  |
| Net deferred tax assets | $ | 5,048 |  |  | $ | 3,199 |  |
| Reported as: |  |  |  |
| Non-current deferred tax assets | $ | 5,162 |  |  | $ | 3,310 |  |
| Non-current deferred tax liabilities (1) | (114) |  |  | (111) |  |
|  | $ | 5,048 |  |  | $ | 3,199 |  |

[0000804328-24-000075:notes:113]
(1) Non-current deferred tax liabilities were included in other liabilities in the consolidated balance sheets.

[0000804328-24-000075:notes:114]
At September 29, 2024, we had unused foreign net operating loss carryforwards of $2.6 billion, of which substantially all may be carried forward indefinitely, unused state net operating loss carryforwards of $817 million expiring from 2025 through 2037 and unused federal net operating loss carryforwards of $150 million, of which $102 million expire from 2025 through 2037 and $48 million may be carried forward indefinitely. At September 29, 2024, we had unused state tax credits of $1.9 billion, of which substantially all may be carried forward indefinitely, unused federal tax credits of $219 million expiring from 2028 through 2041 and unused tax credits of $92 million in foreign jurisdictions expiring from 2031 through 2044. We do not expect our federal net operating loss carryforwards to expire unused.

[0000804328-24-000075:notes:115]
At September 29, 2024, we have provided a valuation allowance on certain state tax credits, foreign deferred tax assets and state net operating losses of $1.9 billion, $121 million and $41 million respectively. The valuation allowance reflects the uncertainties surrounding our ability to generate sufficient future taxable income in certain tax jurisdictions to utilize our net deferred tax assets. We believe, more likely than not, that we will have sufficient taxable income to utilize our remaining deferred tax assets.

[0000804328-24-000075:notes:116]
A summary of the changes in the amount of unrecognized tax benefits for fiscal 2024, 2023 and 2022 follows (in millions):

[0000804328-24-000075:notes:117]
|  | 2024 |  | 2023 |  | 2022 |
| Beginning balance of unrecognized tax benefits | $ | 2,296 |  |  | $ | 2,191 |  |  | $ | 2,136 |  |
| Additions based on prior year tax positions | 2 |  |  | 10 |  |  | 58 |  |
| Reductions for prior year tax positions and lapse in statute of limitations | (1) |  |  | (63) |  |  | (136) |  |
| Additions for current year tax positions | 153 |  |  | 158 |  |  | 184 |  |
| Settlements with taxing authorities | — |  |  | — |  |  | (51) |  |
| Ending balance of unrecognized tax benefits | $ | 2,450 |  |  | $ | 2,296 |  |  | $ | 2,191 |  |

[0000804328-24-000075:notes:118]
Of the $2.5 billion of unrecognized tax benefits, $2.3 billion has been recorded to other liabilities. We believe that it is reasonably possible that certain unrecognized tax benefits recorded at September 29, 2024 may result in a cash payment in fiscal 2025. Unrecognized tax benefits at September 29, 2024 included $91 million for tax positions that, if recognized, would impact the effective tax rate. The unrecognized tax benefits differ from the amount that would affect our effective tax rate primarily because the unrecognized tax benefits were included on a gross basis and did not reflect related receivables or secondary impacts, such as the federal deduction for state taxes, adjustments to deferred tax assets and the valuation allowance that might be required if our tax positions are sustained. The increase in unrecognized tax benefits for all periods presented was primarily due to expected refunds of Korean withholding tax previously paid (which such increase had an insignificant impact to our income tax provision). If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We believe that it is likely that the total amount of unrecognized tax benefits at September 29, 2024 will increase in fiscal 2025 as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision. At September 29, 2024, total interest and penalties related to unrecognized tax benefits accrued in other current liabilities and other liabilities was $250 million, with a corresponding noncurrent income taxes receivable of $181 million recorded in other assets for expected refunds of certain tax benefits.

[0000804328-24-000075:notes:119]
We file income tax returns in the U.S. federal jurisdiction and various state and foreign jurisdictions. We are no longer subject to U.S. federal income tax examinations for years prior to fiscal 2018. We are also subject to examination in other taxing jurisdictions in the U.S. and numerous foreign jurisdictions. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2001.

[0000804328-24-000075:notes:120]
Cash amounts paid for income taxes, net of refunds received, were $3.3 billion, $1.4 billion and $2.1 billion for fiscal 2024, 2023 and 2022, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-24-000075:notes:121]
Capital Stock
Stock Repurchase Program. On October 12, 2021, we announced a $10.0 billion stock repurchase program. At September 29, 2024, $1.0 billion remained authorized for repurchase under this stock repurchase program. On November 6, 2024, we announced a new $15.0 billion stock repurchase authorization, which is in addition to the aforementioned program. The stock repurchase programs have no expiration date.

[0000804328-24-000075:notes:122]
Shares Outstanding. Shares of common stock outstanding at September 29, 2024 were as follows (in millions):

[0000804328-24-000075:notes:123]
| Balance at beginning of period | 1,114 |  |
| Issued | 24 |  |
| Repurchased | (25) |  |
|  | 1,113 |

[0000804328-24-000075:notes:124]
Dividends. On October 16, 2024, we announced a cash dividend of $0.85 per share on our common stock, payable on December 19, 2024 to stockholders of record as of the close of business on December 5, 2024.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000804328-24-000075:notes:125]
Employee Benefit Plans
Equity Compensation Plans. On March 5, 2024, our stockholders approved the Amended and Restated Qualcomm Incorporated 2023 Long-Term Incentive Plan (the 2023 Plan), including an increase in the share reserve by 15 million shares. The 2023 Plan provides for the grant of RSUs and other stock-based awards. The RSUs generally include dividend-equivalent rights and vest over three years from the date of grant. The Board of Directors may amend or terminate the 2023 Plan at any time. Certain amendments, including an increase in the share reserve, require stockholder approval. At September 29, 2024, approximately 75 million shares were available for future grant under the 2023 Plan.

[0000804328-24-000075:notes:126]
The following is a summary of employee RSU transactions that contain only service requirements to vest:

[0000804328-24-000075:notes:127]
|  | Number of Shares(in millions) |  | Weighted-AverageGrant Date Fair Value |  |  |
| RSUs outstanding at September 24, 2023 | 35 |  |  | $ | 122.86 |  |  |  |
| RSUs granted | 21 |  |  | 134.31 |  |  |  |
| RSUs canceled/forfeited | (3) |  |  | 124.84 |  |  |  |
| RSUs vested | (25) |  |  | 124.45 |  |  |  |
| RSUs outstanding at September 29, 2024 | 28 |  |  | 129.61 |  |  |  |

[0000804328-24-000075:notes:128]
The weighted-average estimated grant date fair values of employee RSUs that contain only service requirements to vest granted during fiscal 2023 and 2022 were $116.80 and $136.09 per share, respectively. Upon vesting, we issue new shares of common stock. For the majority of RSUs, shares are issued on the vesting dates net of the amount of shares needed to satisfy statutory tax withholding requirements to be paid by us on behalf of the employees. As a result, the actual number of shares issued will be fewer than the number of RSUs outstanding. The annual pre-vest forfeiture rate for RSUs was estimated to be approximately 6%, 7% and 6% in fiscal 2024, 2023 and 2022, respectively.

[0000804328-24-000075:notes:129]
At September 29, 2024, total unrecognized compensation expense related to such non-vested RSUs granted prior to that date was $2.9 billion, which is expected to be recognized over a weighted-average period of 1.7 years. The total vest-date fair value of such RSUs that vested during fiscal 2024, 2023 and 2022 was $4.0 billion, $2.1 billion and $2.9 billion, respectively. The total shares withheld to satisfy statutory tax withholding requirements related to all share-based awards were 6 million, 4 million and 5 million in fiscal 2024, 2023 and 2022, respectively and were based on the value of the awards on their vesting dates as determined by our closing stock price.

[0000804328-24-000075:notes:130]
The total tax benefits realized, including the excess tax benefits, related to share-based awards during fiscal 2024, 2023 and 2022 were $840 million, $435 million and $627 million, respectively.

[0000804328-24-000075:notes:131]
Employee Stock Purchase Plan. We have an employee stock purchase plan that allows eligible employees to purchase shares of common stock at 85% of the value of our common stock on specific dates through periodic payroll deductions. The shares reserved for future issuance under the employee stock purchase plan were 15 million at September 29, 2024. We recorded cash received from the exercise of purchase rights of $379 million, $395 million and $355 million during fiscal 2024, 2023 and 2022, respectively.

[0000804328-24-000075:notes:132]
Share-based Compensation Expense. Total share-based compensation expense, related to all of our share-based awards, was comprised as follows (in millions):

[0000804328-24-000075:notes:133]
|  |  |  |  |  | 2024 |  | 2023 |  | 2022 |
| Cost of revenues |  |  |  |  |  |  |  |  | $ | 89 |  |  | $ | 76 |  |  | $ | 61 |  |
| Research and development |  |  |  |  |  |  |  |  | 2,024 |  |  | 1,911 |  |  | 1,537 |  |
| Selling, general and administrative |  |  |  |  |  |  |  |  | 535 |  |  | 497 |  |  | 463 |  |
| Share-based compensation expense before income taxes |  |  |  |  |  |  |  |  | 2,648 |  |  | 2,484 |  |  | 2,061 |  |
| Related income tax benefit |  |  |  |  |  |  |  |  | (662) |  |  | (463) |  |  | (489) |  |
|  |  |  |  |  |  |  |  |  | $ | 1,986 |  |  | $ | 2,021 |  |  | $ | 1,572 |  |


## us-gaap:DebtDisclosureTextBlock

[0000804328-24-000075:notes:134]
Debt
Long-term Debt. In May 2024, we repaid $914 million of fixed-rate notes that matured in May 2024.

[0000804328-24-000075:notes:135]
The following table provides a summary of our long-term debt and current portion of long-term debt:

[0000804328-24-000075:notes:136]
|  | September 29, 2024 |  | September 24, 2023 |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2025 - 2045 |  | $ | 3,865 |  |  | 3.45% - 4.72% |  | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |
| May 2017 Notes | 2027 - 2047 |  | 3,500 |  |  | 3.81% - 4.45% |  | 2024 - 2047 |  | 4,414 |  |  | 3.00% - 4.45% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.84% - 3.30% |  | 2030 - 2050 |  | 2,000 |  |  | 3.22% - 3.30% |
| August 2020 Notes | 2028 - 2032 |  | 2,207 |  |  | 2.37% - 3.39% |  | 2028 - 2032 |  | 2,207 |  |  | 2.65% - 3.89% |
| May 2022 Notes | 2032 - 2052 |  | 1,500 |  |  | 3.17% - 4.28% |  | 2032 - 2052 |  | 1,500 |  |  | 3.15% - 4.27% |
| November 2022 Notes | 2033 - 2053 |  | 1,900 |  |  | 3.50% - 5.07% |  | 2033 - 2053 |  | 1,900 |  |  | 3.47% - 5.02% |
| Total principal |  |  | 14,972 |  |  |  |  |  |  | 15,886 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (212) |  |  |  |  |  |  | (238) |  |  |  |
| Hedge accounting adjustments |  | (126) |  |  |  |  |  |  | (250) |  |  |  |
| Total long-term debt |  |  | $ | 14,634 |  |  |  |  |  |  | $ | 15,398 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 1,364 |  |  |  |  |  |  | $ | 914 |  |  |  |
| Long-term debt |  |  | 13,270 |  |  |  |  |  |  | 14,484 |  |  |  |
| Total |  |  | $ | 14,634 |  |  |  |  |  |  | $ | 15,398 |  |  |  |

[0000804328-24-000075:notes:137]
At September 29, 2024, future principal payments were $1.4 billion in fiscal 2025, $2.0 billion in fiscal 2027, $1.0 billion in fiscal 2028 and $10.6 billion after fiscal 2029; no principal payments are due in fiscal 2026 or fiscal 2029. At September 29, 2024, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $14.3 billion.

[0000804328-24-000075:notes:138]
At September 29, 2024, all of our outstanding long-term debt is comprised of unsecured fixed-rate notes. We may redeem the outstanding fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The obligations under the notes rank equally in right of payment with all of our other senior unsecured indebtedness and will effectively rank junior to all liabilities of our subsidiaries.

[0000804328-24-000075:notes:139]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears semi-annually for the notes. Cash interest paid related to our commercial paper program and long-term debt was $656 million, $614 million and $491 million during fiscal 2024, 2023 and 2022, respectively.

[0000804328-24-000075:notes:140]
Interest Rate Swaps. At September 29, 2024 and September 24, 2023, we had outstanding interest rate swaps with an aggregate notional amount of $2.1 billion that are designated as fair value hedges and allow us to effectively convert fixed-rate payments into floating-rate payments on a portion of our outstanding long-term debt.

[0000804328-24-000075:notes:141]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion. Net proceeds from this program are for general corporate purposes. Maturities of commercial paper can range from 1 to up to 397 days. At September 29, 2024 and September 24, 2023, we had no amounts of commercial paper outstanding.

[0000804328-24-000075:notes:142]
Revolving Credit Facility. On August 8, 2024, we entered into a Revolving Credit Facility, replacing our prior Amended and Restated Revolving Credit Facility. The Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, which expires on August 8, 2029. At September 29, 2024, no amounts were outstanding under the Revolving Credit Facility. There were no outstanding borrowings under the Amended and Restated Revolving Credit Facility at the time of termination and September 24, 2023.

[0000804328-24-000075:notes:143]
Debt Covenants. The Revolving Credit Facility requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. We are not subject to any financial covenants under the notes nor any covenants that would prohibit us from incurring additional indebtedness ranking equal to the notes, paying dividends or issuing securities or repurchasing securities issued by us or our subsidiaries. At September 29, 2024, we were in compliance with the applicable covenants under the Revolving Credit Facility.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-24-000075:notes:144]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0000804328-24-000075:notes:145]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. The court consolidated the two actions, and on July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On May 23, 2022, the plaintiffs filed a motion for class certification, and on March 20, 2023, the court issued an order granting in part and denying in part the plaintiffs’ motion for class certification. The order denied class certification on the basis of alleged misrepresentations relating to our chip-level licensing practices, but certified a class on the basis of alleged misrepresentations relating to the separate operations of QCT and QTL. We reached a proposed settlement with the plaintiffs to resolve this litigation, and on June 18, 2024, we and the plaintiffs, along with the individual defendants, filed a joint Stipulation and Agreement of Settlement with the court. The settlement was approved by the court on September 27, 2024. In the third quarter of fiscal 2024, we recorded a charge of $75 million to other expenses for the settlement amount, which amount was paid in the fourth quarter of fiscal 2024.

[0000804328-24-000075:notes:146]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. The cases filed in the Southern District of California were subsequently transferred to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On September 27, 2018, the court certified the class. We appealed the court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class, and remanded the case to the district court. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. We filed a motion to dismiss the amended complaint, and on January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. We subsequently filed a motion for summary judgment on the plaintiffs’ remaining claims. The court granted our motion in its entirety and, on October 5, 2023, entered final judgment in Qualcomm’s favor. On November 2, 2023, the plaintiffs filed a notice of appeal to the Ninth Circuit, and on October 15, 2024, the court held a hearing on the appeal. The court has not yet issued a ruling. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-24-000075:notes:147]
Beginning in November 2017, several other consumer class action complaints were filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws and seeking damages. The claims in these complaints are similar to those in the U.S. consumer class action complaints described above. These matters are at various stages of litigation, and we intend to continue to vigorously defend ourselves.

[0000804328-24-000075:notes:148]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the district court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit (Federal Circuit). On September 6, 2024, the Federal Circuit reversed the judgment of the district court, citing certain substantive and procedural issues, and remanded the case to the district court for further proceedings. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-24-000075:notes:149]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (Arm) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with Arm (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. Arm is seeking specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology (which Arm alleges includes our custom Qualcomm Oryon CPU cores). Arm’s complaint also contends that we violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of Arm’s trademarks and seeks associated injunctive and declaratory relief; however, Arm subsequently informed the court of its intent to withdraw such claims.

[0000804328-24-000075:notes:150]
On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm (together with the Nuvia ALA, the Arm-Nuvia Agreements) and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia) and System-on-Chip (SoC) products incorporating such cores are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm (together with the Qualcomm ALA, the Arm-Qualcomm Agreements). We further seek an order enjoining Arm from making any claim that our products are not licensed under the Arm-Qualcomm Agreements, are not Arm-compliant or that we are prohibited from using Arm’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements Arm is making in the marketplace concerning our rights under the Arm-Qualcomm Agreements are false, and that Arm has no right to prevent us from shipping our products, which are validly licensed. On March 22, 2024, we filed a Second Amended Counterclaim asserting that Arm has breached the Arm-Nuvia Agreements by continuing to use Nuvia technology and by failing to return or destroy Nuvia confidential information after the Arm-Nuvia Agreements were terminated. The Second Amended Counterclaim seeks damages related to the asserted breaches. On July 10, 2024, Arm filed a motion for partial summary judgment that the Nuvia ALA was properly terminated, that the Nuvia ALA was breached, and that Arm did not breach the Arm-Nuvia Agreements. We also filed a motion for summary judgment on Arm’s breach of contract claims, that Qualcomm’s architected cores are licensed under the Qualcomm ALA, and that Qualcomm has not infringed Arm’s trademarks. On October 30, 2024, the court denied both parties’ motions for summary judgment. Trial is scheduled to begin on December 16, 2024. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.

[0000804328-24-000075:notes:151]
On April 18, 2024, we filed a separate complaint (captioned QUALCOMM Incorporated v. Arm Ltd.) against Arm in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief. Arm moved to dismiss this complaint, and on October 30, 2024, the court denied Arm’s motion to dismiss. No trial date has been set for this case.

[0000804328-24-000075:notes:152]
On October 22, 2024, Arm provided us with a notice alleging that we have breached the Qualcomm ALA by marketing products that contain CPUs that Arm alleges use designs, technology and code created by Nuvia employees prior to our acquisition of Nuvia; by seeking support and verification from Arm for additional products that use such alleged designs, technology and code; and by suing Arm for breach of the Qualcomm ALA. Arm’s notice asserts that it will have the right to terminate the Qualcomm ALA if such alleged breaches are not cured within 60 days of such notice. We disagree with Arm’s allegations, including that we are in breach of the Qualcomm ALA.

[0000804328-24-000075:notes:153]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at September 29, 2024 for contingent losses associated with the pending matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (for example, our 2010 European Commission matter relating to the Icera complaint, and other matters arising in the ordinary course of our business, including those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0000804328-24-000075:notes:154]
Indemnifications. We generally do not indemnify our customers, licensees and suppliers for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain agreements to defend and/or indemnify certain customers, licensees, and suppliers against certain types of liability and/or damages arising from the infringement of third-party intellectual property rights and to indemnify certain companies that purchased businesses we previously consolidated against certain contingent losses. Our obligations under these agreements may be limited in terms of time and/or amounts, and in some instances, we may have recourse against third parties for certain payments made by us. Claims and reimbursements under indemnification arrangements have not been material to our consolidated financial statements. We have not recorded accruals for certain claims under indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0000804328-24-000075:notes:155]
Purchase Obligations. We have agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Such agreements include multi-year capacity purchase commitments with certain suppliers of our integrated circuit products. Total advance payments related to multi-year capacity purchase commitments recorded on the consolidated balance sheets at September 29, 2024 and September 24, 2023 were $3.0 billion and $3.3 billion, respectively, of which $765 million and $404 million were recorded in other current assets, respectively, and $2.2 billion and $2.9 billion were recorded in other assets, respectively. Integrated circuit product inventory obligations represent purchase commitments (including those under multi-year capacity purchase commitments to the extent such minimum amounts are both fixed and determinable) for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancellation of outstanding purchase commitments is generally allowed but would require payment of costs incurred through the date of cancellation. Also, in some cases, we may be subject to incremental fees and/or the loss of amounts paid in advance due to capacity underutilization and/or the failure to meet minimum purchase volumes under multi-year capacity purchase commitments. Obligations under our purchase agreements, which primarily relate to integrated circuit product inventory obligations, at September 29, 2024 totaled $12.8 billion of which, $9.6 billion is expected to be paid in the next 12 months.

[0000804328-24-000075:notes:156]
Operating Leases. We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years. At September 29, 2024 and September 24, 2023, the weighted-average remaining lease term for operating leases was nine years and eight years, respectively. Operating lease expense for fiscal 2024, 2023 and 2022 was $184 million, $204 million and $207 million, respectively. At September 29, 2024, other assets included $719 million of operating lease assets, with corresponding lease liabilities of $98 million recorded in other current liabilities and $708 million recorded in other liabilities. At September 24, 2023, other assets included $612 million of operating lease assets, with corresponding lease liabilities of $98 million recorded in other current liabilities and $571 million recorded in other liabilities.

[0000804328-24-000075:notes:157]
At September 29, 2024, future lease payments under our operating leases were as follows (in millions):

[0000804328-24-000075:notes:158]
|  |  |  | September 29,2024 |
| 2025 |  |  | $ | 136 |  |
| 2026 |  |  | 134 |  |
| 2027 |  |  | 127 |  |
| 2028 |  |  | 117 |  |
| 2029 |  |  | 102 |  |
| Thereafter |  |  | 468 |  |
| Total future lease payments |  |  | 1,084 |  |
| Imputed interest |  |  | (278) |  |
| Total lease liability balance |  |  | $ | 806 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-24-000075:notes:159]
Segment Information
We are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarities and the level of centralized resource planning within our operating segments, such as the nature of products, the level of shared products, technology and other resources, production processes and customer base. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software with advanced connectivity and high-performance, low-power computing technologies for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices, industrial devices and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our cloud computing processing initiative.

[0000804328-24-000075:notes:160]
Our CODM allocates resources to and evaluates the performance of our segments based on revenues and earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to certain corporate assets. Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense, certain net investment income, share-based compensation, gains and losses on our deferred compensation plan liabilities and related assets and certain research and development

[0000804328-24-000075:notes:161]
expenses, certain selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories and property, plant and equipment to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, asset impairment charges and awards, settlements and/or damages arising from legal or regulatory matters. Our CODM does not evaluate our operating segments using discrete asset information.

[0000804328-24-000075:notes:162]
The table below presents revenues and EBT for reportable segments (in millions):

[0000804328-24-000075:notes:163]
|  | 2024 |  | 2023 |  | 2022 |
| Revenues: |  |  |  |  |  |
| QCT | $ | 33,196 |  |  | $ | 30,382 |  |  | $ | 37,677 |  |
| QTL | 5,572 |  |  | 5,306 |  |  | 6,358 |  |
| QSI | 18 |  |  | 28 |  |  | 31 |  |
| Reconciling items | 176 |  |  | 104 |  |  | 134 |  |
| Total | $ | 38,962 |  |  | $ | 35,820 |  |  | $ | 44,200 |  |
| EBT: |  |  |  |  |  |
| QCT | $ | 9,527 |  |  | $ | 7,924 |  |  | $ | 12,837 |  |
| QTL | 4,027 |  |  | 3,628 |  |  | 4,628 |  |
| QSI | 104 |  |  | (12) |  |  | (279) |  |
| Reconciling items | (3,322) |  |  | (4,097) |  |  | (2,188) |  |
| Total | $ | 10,336 |  |  | $ | 7,443 |  |  | $ | 14,998 |  |

[0000804328-24-000075:notes:164]
Reconciling items for revenues and EBT in the previous table were as follows (in millions):

[0000804328-24-000075:notes:165]
|  |  |  |  | 2024 |  | 2023 |  | 2022 |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonreportable segments |  |  |  |  |  |  |  | $ | 176 |  |  | $ | 144 |  |  | $ | 134 |  |
| Unallocated revenues |  |  |  |  |  |  |  | — |  |  | (40) |  |  | — |  |
|  |  |  |  |  |  |  |  | $ | 176 |  |  | $ | 104 |  |  | $ | 134 |  |
| EBT: |  |  |  |  |  |  |  |  |  |  |  |  |
| Unallocated revenues |  |  |  |  |  |  |  | $ | — |  |  | $ | (40) |  |  | $ | — |  |
| Unallocated cost of revenues |  |  |  |  |  |  |  | (229) |  |  | (205) |  |  | (266) |  |
| Unallocated research and development expenses |  |  |  |  |  |  |  | (2,277) |  |  | (2,034) |  |  | (1,767) |  |
| Unallocated selling, general and administrative expenses |  |  |  |  |  |  |  | (781) |  |  | (588) |  |  | (609) |  |
| Unallocated other (expense) income (Note 2) |  |  |  |  |  |  |  | (179) |  |  | (862) |  |  | 1,059 |  |
| Unallocated interest expense |  |  |  |  |  |  |  | (697) |  |  | (694) |  |  | (490) |  |
| Unallocated investment and other income (expense), net |  |  |  |  |  |  |  | 855 |  |  | 364 |  |  | (91) |  |
| Nonreportable segments |  |  |  |  |  |  |  | (14) |  |  | (38) |  |  | (24) |  |
|  |  |  |  |  |  |  |  | $ | (3,322) |  |  | $ | (4,097) |  |  | $ | (2,188) |  |

[0000804328-24-000075:notes:166]
The net book value of long-lived tangible assets located outside of the U.S. (the majority of which is located in Taiwan and the rest of the Asia-Pacific region) was $3.5 billion and $3.6 billion at September 29, 2024 and September 24, 2023, respectively. The net book value of long-lived tangible assets located in the U.S. was $1.9 billion and $2.0 billion at September 29, 2024 and September 24, 2023, respectively.

[0000804328-24-000075:notes:167]
Beginning in fiscal 2024, revenues by country are presented based on our customer’s/licensee’s headquarter location and were as follows (in millions):

[0000804328-24-000075:notes:168]
|  | 2024 |  | 2023 |  | 2022 |
| China (including Hong Kong) | $ | 17,826 |  |  | 46 | % |  | $ | 13,386 |  |  | 37 | % |  | $ | 18,977 |  |  | 43 | % |
| United States | 9,686 |  |  | 25 |  |  | 10,503 |  |  | 29 |  |  | 10,501 |  |  | 24 |  |
| South Korea | 7,995 |  |  | 20 |  |  | 8,075 |  |  | 23 |  |  | 9,666 |  |  | 22 |  |
| Other foreign | 3,455 |  |  | 9 |  |  | 3,856 |  |  | 11 |  |  | 5,056 |  |  | 11 |  |
|  | $ | 38,962 |  |  | 100 | % |  | $ | 35,820 |  |  | 100 | % |  | $ | 44,200 |  |  | 100 | % |

[0000804328-24-000075:notes:169]
Previously, revenues by country were presented based on the location to which our products or services were delivered. For QCT, this was the country in which our customers manufacture their products and for licensing revenues, the invoiced addresses of our licensees, and was not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices were headquartered. We believe this change generally provides a better representation of the geographic profile of our revenues. However, it is still not necessarily indicative of the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers. Prior period information has been recast to reflect this change.

[0000804328-24-000075:notes:170]
For comparative purposes, based on the location to which our products or services are delivered, revenues from sales into China (including Hong Kong), United States, South Korea, and Vietnam were 66%, 3%, 7%, and 12% of total revenues, respectively, for fiscal 2024.


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-24-000075:notes:171]
Fair Value Measurements and Marketable Securities 
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at September 29, 2024 (in millions):

[0000804328-24-000075:notes:172]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 3,802 |  |  | $ | 446 |  |  | $ | — |  |  | $ | 4,248 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | — |  |  | $ | 4,634 |  |  | $ | — |  |  | $ | 4,634 |  |
| Mortgage- and asset-backed securities | — |  |  | 487 |  |  | — |  |  | 487 |  |
| U.S. Treasury securities and government-related securities | 176 |  |  | 32 |  |  | — |  |  | 208 |  |
| Equity securities | 122 |  |  | — |  |  | — |  |  | 122 |  |
| Total marketable securities | 298 |  |  | 5,153 |  |  | — |  |  | 5,451 |  |
| Derivative instruments | — |  |  | 30 |  |  | — |  |  | 30 |  |
| Other investments (1) | 954 |  |  | — |  |  | 42 |  |  | 996 |  |
| Total assets measured at fair value | $ | 5,054 |  |  | $ | 5,629 |  |  | $ | 42 |  |  | $ | 10,725 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 138 |  |  | $ | — |  |  | $ | 138 |  |
| Other liabilities (1) | 950 |  |  | — |  |  | — |  |  | 950 |  |
| Total liabilities measured at fair value | $ | 950 |  |  | $ | 138 |  |  | $ | — |  |  | $ | 1,088 |  |

[0000804328-24-000075:notes:173]
(1) Other investments and other liabilities included in Level 1 are comprised of our deferred compensation plan assets and liabilities.

[0000804328-24-000075:notes:174]
At September 29, 2024 and September 24, 2023, our marketable securities were all classified as current and were primarily comprised of available-for-sale debt securities (substantially all of which were corporate bonds and notes).

[0000804328-24-000075:notes:175]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0000804328-24-000075:notes:176]
|  | September 29,2024 |
| Years to Maturity: |  |
| Less than one year | $ | 1,387 |  |
| One to five years | 3,455 |  |
| No single maturity date | 487 |  |
| Total | $ | 5,329 |  |

[0000804328-24-000075:notes:177]
Debt securities with no single maturity date included mortgage- and asset-backed securities.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000804328-24-000075:notes:178]
SCHEDULE II

[0000804328-24-000075:notes:179]
QUALCOMM Incorporated

[0000804328-24-000075:notes:180]
VALUATION AND QUALIFYING ACCOUNTS

[0000804328-24-000075:notes:181]
The table below details the activity of the valuation allowance on deferred tax assets for fiscal 2024, 2023 and 2022 (in millions):

[0000804328-24-000075:notes:182]
|  | Balance atBeginning ofPeriod |  | Charged (Credited) toCosts andExpenses |  |  |  | Other |  | Balance atEnd ofPeriod |
| Year ended September 29, 2024 | $ | 1,803 |  |  | $ | 258 |  |  |  |  | $ | — |  |  | $ | 2,061 |  |
| Year ended September 24, 2023 | 2,223 |  |  | (420) |  |  |  |  | — |  |  | 1,803 |  |
| Year ended September 25, 2022 | 1,926 |  |  | 278 |  |  |  |  | 19 |  |  | 2,223 |  |
