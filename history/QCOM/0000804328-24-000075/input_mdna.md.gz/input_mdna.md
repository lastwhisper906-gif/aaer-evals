# QCOM MD&A — 0000804328-24-000075


## mdna

[0000804328-24-000075:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000804328-24-000075:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes included in “Part II, Item 8. Financial Statements and Supplementary Data” of this Annual Report.

[0000804328-24-000075:mdna:3]
The following section generally discusses fiscal 2024 and 2023 items and year-to-year comparisons between fiscal 2024 and 2023. Discussions of fiscal 2022 items and year-to-year comparisons between fiscal 2023 and 2022 that are not included in this Annual Report can be found in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended September 24, 2023.

[0000804328-24-000075:mdna:4]
Our Business and Operating Segments

[0000804328-24-000075:mdna:5]
We develop and commercialize foundational technologies and products used in mobile devices and other wireless products. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents and other rights.

[0000804328-24-000075:mdna:6]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our cloud computing processing initiative.

[0000804328-24-000075:mdna:7]
Further information regarding our business and operating segments is provided in “Part I, Item 1. Business” of this Annual Report.

[0000804328-24-000075:mdna:8]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when licensees’ sales occur. These trends may or may not continue in the future. Further, the trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings.

[0000804328-24-000075:mdna:9]
Fiscal 2024 Overview

[0000804328-24-000075:mdna:10]
Revenues were $39.0 billion, an increase of 9% compared to revenues of $35.8 billion in fiscal 2023, with net income of $10.1 billion, an increase of 40% compared to net income of $7.2 billion in fiscal 2023. Our fiscal 2024 results included:

[0000804328-24-000075:mdna:11]
•QCT revenues increased by 9% in fiscal 2024 compared to the prior year, primarily due to higher handsets and automotive revenues, partially offset by lower IoT revenues.

[0000804328-24-000075:mdna:12]
•QTL revenues increased by 5% in fiscal 2024 compared to the prior year, primarily due to an increase in estimated sales of 3G/4G/5G-based multimode products.

[0000804328-24-000075:mdna:13]
•We recorded other expenses of $179 million in fiscal 2024 compared to $862 million in fiscal 2023, both of which primarily consisted of restructuring and restructuring-related charges.

[0000804328-24-000075:mdna:14]
•Investment and other income, net increased by $613 million in fiscal 2024 compared to the prior year, primarily due to higher interest rates earned on higher balances of interest-bearing securities.

[0000804328-24-000075:mdna:15]
Results of Operations

[0000804328-24-000075:mdna:16]
| Revenues (in millions) |  |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  | Change |  |  |
| Equipment and services | $ | 32,791 |  |  | $ | 30,028 |  |  |  |  | $ | 2,763 |  |  |  |
| Licensing | 6,171 |  |  | 5,792 |  |  |  |  | 379 |  |  |  |
|  | $ | 38,962 |  |  | $ | 35,820 |  |  |  |  | $ | 3,142 |  |  |  |

[0000804328-24-000075:mdna:17]
2024 vs. 2023

[0000804328-24-000075:mdna:18]
The increase in revenues in fiscal 2024 was primarily due to:

[0000804328-24-000075:mdna:19]
+    $2.7 billion in higher equipment and services revenue from our QCT segment

[0000804328-24-000075:mdna:20]
+    $266 million in higher licensing revenues from our QTL segment

[0000804328-24-000075:mdna:21]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  | Change |  |  |
| Cost of revenues | $ | 17,060 |  |  | $ | 15,869 |  |  |  |  | $ | 1,191 |  |  |  |
| Gross margin | 56 | % |  | 56 | % |  |  |  |  |  |  |

[0000804328-24-000075:mdna:22]
2024 vs. 2023

[0000804328-24-000075:mdna:23]
Gross margin percentage remained flat in fiscal 2024.

[0000804328-24-000075:mdna:24]
|  | 2024 |  | 2023 |  |  |  | Change |  |  |
| Research and development | $ | 8,893 |  |  | $ | 8,818 |  |  |  |  | $ | 75 |  |  |  |
| % of revenues | 23 | % |  | 25 | % |  |  |  |  |  |  |

[0000804328-24-000075:mdna:25]
2024 vs. 2023

[0000804328-24-000075:mdna:26]
The increase in research and development expenses in fiscal 2024 was due to:

[0000804328-24-000075:mdna:27]
+    $113 million increase in share-based compensation expense

[0000804328-24-000075:mdna:28]
+    $66 million increase in expenses driven by revaluation of our deferred compensation obligation (which resulted in a corresponding increase in net gains on deferred compensation plan assets within investment and other income, net due to the revaluation of the related assets)

[0000804328-24-000075:mdna:29]
-    $104 million decrease driven by lower costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies). This was primarily driven by a decrease in employee-related costs as a result of certain restructuring actions taken to fund continued investments in key growth and diversification opportunities, partially offset by higher employee cash incentive program costs.

[0000804328-24-000075:mdna:30]
|  | 2024 |  | 2023 |  |  |  | Change |  |  |
| Selling, general and administrative | $ | 2,759 |  |  | $ | 2,483 |  |  |  |  | $ | 276 |  |  |  |
| % of revenues | 7 | % |  | 7 | % |  |  |  |  |  |  |

[0000804328-24-000075:mdna:31]
2024 vs. 2023

[0000804328-24-000075:mdna:32]
The increase in selling, general and administrative expenses in fiscal 2024 was primarily due to:

[0000804328-24-000075:mdna:33]
+    $99 million increase in sales and marketing expenses

[0000804328-24-000075:mdna:34]
+    $42 million increase in expenses driven by revaluation of our deferred compensation obligation

[0000804328-24-000075:mdna:35]
+    $39 million increase in share-based compensation expense

[0000804328-24-000075:mdna:36]
|  | 2024 |  | 2023 |  |  |  | Change |  |  |
| Other expenses | $ | 179 |  |  | $ | 862 |  |  |  |  | $ | (683) |  |  |  |

[0000804328-24-000075:mdna:37]
2024 vs. 2023

[0000804328-24-000075:mdna:38]
Other expenses in fiscal 2024 consisted primarily of $107 million in restructuring and restructuring-related charges (substantially all of which related to severance costs) and a $75 million charge related to the settlement of the securities class action lawsuit.

[0000804328-24-000075:mdna:39]
Other expenses in fiscal 2023 consisted of $712 million in total restructuring and restructuring-related charges (substantially all of which related to severance costs, resulting from certain cost reduction actions committed to in fiscal 2023 and a $150 million intangible asset impairment charge related to in-process research and development.

[0000804328-24-000075:mdna:40]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  | Change |  |  |
| Interest expense | $ | 697 |  |  | $ | 694 |  |  |  |  | $ | 3 |  |  |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 675 |  |  | $ | 313 |  |  |  |  | $ | 362 |  |  |  |
| Net gains on marketable securities | 14 |  |  | 75 |  |  |  |  | (61) |  |  |  |
| Net gains on other investments | 175 |  |  | 21 |  |  |  |  | 154 |  |  |  |
| Net gains on deferred compensation plan assets | 198 |  |  | 86 |  |  |  |  | 112 |  |  |  |
| Impairment losses on other investments | (79) |  |  | (132) |  |  |  |  | 53 |  |  |  |
| Other | (21) |  |  | (14) |  |  |  |  | (7) |  |  |  |
|  | $ | 962 |  |  | $ | 349 |  |  |  |  | $ | 613 |  |  |  |

[0000804328-24-000075:mdna:41]
2024 vs. 2023

[0000804328-24-000075:mdna:42]
The increase in interest and dividend income in fiscal 2024 was primarily due to higher interest rates earned on higher balances of interest-bearing securities. Net gains on other investments in fiscal 2024 was primarily driven by certain of our QSI non-marketable equity investments.

[0000804328-24-000075:mdna:43]
Income Tax Expense (in millions, except percentages)

[0000804328-24-000075:mdna:44]
The following table summarizes the primary factors that caused our annual tax provision from continuing operations to differ from the expected income tax provision at the U.S. federal statutory rate. Substantially all of our income is taxed in the U.S., of which a significant portion qualifies for preferential treatment as FDII at a 13% effective tax rate. Additional information regarding our annual effective tax rate (including discussion related to the impact of the requirement to capitalize research and development expenditures for federal income tax purposes, and the benefit related to the transfer of intellectual property between foreign subsidiaries) is provided in this Annual Report in “Notes to Consolidated Financial Statements, Notes 3. Income Taxes.”

[0000804328-24-000075:mdna:45]
|  | 2024 |  | 2023 |  |  |
| Expected income tax provision at federal statutory tax rate | $ | 2,171 |  |  | $ | 1,563 |  |  |  |
| Benefit from FDII deduction, excluding the impact of capitalizing research and development expenditures | (596) |  |  | (447) |  |  |  |
| Benefit from FDII deduction related to capitalizing research and development expenditures | (585) |  |  | (598) |  |  |  |
| Benefit related to the transfer of intellectual property between foreign subsidiaries | (317) |  |  | — |  |  |  |
| Benefit related to the research and development tax credit | (259) |  |  | (235) |  |  |  |
| Excess tax (benefit) deficiency associated with share-based awards | (176) |  |  | 3 |  |  |  |
| Foreign currency gains related to foreign withholding tax receivable | (21) |  |  | (66) |  |  |  |
| Benefit from fiscal 2021 and 2022 FDII deductions related to a change in sourcing of research and development expenditures | — |  |  | (126) |  |  |  |
| Benefit from releasing valuation allowance on unutilized foreign loss carryforwards | — |  |  | (114) |  |  |  |
| Other | 9 |  |  | 124 |  |  |  |
| Income tax expense | $ | 226 |  |  | $ | 104 |  |  |  |
| Effective tax rate | 2 | % |  | 1 | % |  |  |

[0000804328-24-000075:mdna:46]
The OECD has announced a framework to implement a global minimum tax of 15% (referred to as Pillar Two). Certain countries have implemented or are in the process of implementing the Pillar Two legislation, which will apply to us beginning in fiscal year 2025. While we do not currently expect this to materially impact our consolidated financial statements, we continue to monitor the impact as countries implement legislation and the OECD provides additional guidance.

[0000804328-24-000075:mdna:47]
Discontinued Operations (in millions)

[0000804328-24-000075:mdna:48]
|  | 2024 |  | 2023 |  |  |  | Change |  |  |
| Discontinued operations, net of income taxes | $ | 32 |  |  | $ | (107) |  |  |  |  | $ | 139 |  |  |  |

[0000804328-24-000075:mdna:49]
2024 vs. 2023

[0000804328-24-000075:mdna:50]
Discontinued operations in fiscal 2024 and 2023 primarily related to the Non-Arriver businesses. Fiscal 2023 also included a gain on the sale of the Active Safety business and certain write-down charges related to the Restraint Control Systems business, the individual and aggregate amounts of which were not material. Information regarding the Non-Arriver businesses is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items.”

[0000804328-24-000075:mdna:51]
43

[0000804328-24-000075:mdna:52]
Segment Results

[0000804328-24-000075:mdna:53]
The following should be read in conjunction with the fiscal 2024 and 2023 results of operations for each reportable segment included in this Annual Report in “Notes to Consolidated Financial Statements, Note 8. Segment Information.”

[0000804328-24-000075:mdna:54]
QCT Segment (in millions, except percentages)

[0000804328-24-000075:mdna:55]
|  | 2024 |  | 2023 |  |  |  | Change |  |  |
| Revenues |  |  |  |  |  |  |  |  |  |
| Handsets | $ | 24,863 |  |  | $ | 22,570 |  |  |  |  | $ | 2,293 |  |  |  |
| Automotive | 2,910 |  |  | 1,872 |  |  |  |  | 1,038 |  |  |  |
| IoT (internet of things) | 5,423 |  |  | 5,940 |  |  |  |  | (517) |  |  |  |
| Total revenues (1) | $ | 33,196 |  |  | $ | 30,382 |  |  |  |  | $ | 2,814 |  |  |  |
| EBT (2) | $ | 9,527 |  |  | $ | 7,924 |  |  |  |  | $ | 1,603 |  |  |  |
| EBT as a % of revenues | 29 | % |  | 26 | % |  |  |  | 3 points |  |  |

[0000804328-24-000075:mdna:56]
(1) Descriptions of our three QCT revenue streams can be found in this Annual Report in “Notes to Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items.”

[0000804328-24-000075:mdna:57]
(2) Earnings (loss) before income taxes.

[0000804328-24-000075:mdna:58]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $32.6 billion and $29.9 billion in fiscal 2024 and 2023, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets as well as sales of 4G, 5G sub 6 and 5G millimeter wave RFFE products.

[0000804328-24-000075:mdna:59]
2024 vs. 2023

[0000804328-24-000075:mdna:60]
The increase in QCT revenues in fiscal 2024 was primarily due to:

[0000804328-24-000075:mdna:61]
+    higher handsets revenues, due to $2.8 billion in higher chipset shipments driven by certain major OEMs (primarily driven by the normalization of customer inventory levels, which were elevated in the prior year), partially offset by $533 million in lower revenues per chipset primarily driven by unfavorable mix

[0000804328-24-000075:mdna:62]
+    higher automotive revenues, primarily driven by an increase in demand from new vehicle launches with our Snapdragon digital cockpit and connectivity products

[0000804328-24-000075:mdna:63]
-    lower IoT revenues, due to $834 million in lower revenues per unit primarily driven by unfavorable mix, partially offset by a $317 million increase in demand (primarily in consumer products, partially offset by edge networking products as customers continued drawing down on their elevated inventory levels)

[0000804328-24-000075:mdna:64]
QCT EBT as a percentage of revenues increased in fiscal 2024 primarily due to higher revenues.

[0000804328-24-000075:mdna:65]
Gross margin percentage remained flat in fiscal 2024.

[0000804328-24-000075:mdna:66]
QTL Segment (in millions, except percentages)

[0000804328-24-000075:mdna:67]
|  | 2024 |  | 2023 |  |  |  | Change |  |  |
| Licensing revenues | $ | 5,572 |  |  | $ | 5,306 |  |  |  |  | $ | 266 |  |  |  |
| EBT | 4,027 |  |  | 3,628 |  |  |  |  | 399 |  |  |  |
| EBT as a % of revenues | 72 | % |  | 68 | % |  |  |  | 4 points |  |  |

[0000804328-24-000075:mdna:68]
2024 vs. 2023

[0000804328-24-000075:mdna:69]
The increase in QTL licensing revenues in fiscal 2024 was primarily due to:

[0000804328-24-000075:mdna:70]
+    $402 million increase in estimated sales of 3G/4G/5G-based multimode products

[0000804328-24-000075:mdna:71]
-    $90 million decrease in estimated revenues per unit

[0000804328-24-000075:mdna:72]
-    $68 million decrease in revenues from the ending of the recognition of certain upfront license fee consideration in the first quarter of fiscal 2023 from our long-term license agreement with Nokia

[0000804328-24-000075:mdna:73]
QTL EBT as a percentage of revenues increased in fiscal 2024 primarily due to:

[0000804328-24-000075:mdna:74]
+    lower cost of sales driven by a decrease in amortization expense related to acquired patents

[0000804328-24-000075:mdna:75]
+    higher revenues

[0000804328-24-000075:mdna:76]
QSI Segment (in millions)

[0000804328-24-000075:mdna:77]
|  | 2024 |  | 2023 |  |  |  | Change |  |  |
| Equipment and services revenues | $ | 18 |  |  | $ | 28 |  |  |  |  | $ | (10) |  |  |  |
| EBT | 104 |  |  | (12) |  |  |  |  | 116 |  |  |  |

[0000804328-24-000075:mdna:78]
2024 vs. 2023

[0000804328-24-000075:mdna:79]
QSI EBT increased in fiscal 2024 primarily due to net gains on certain of our non-marketable equity investments.

[0000804328-24-000075:mdna:80]
Looking Forward

[0000804328-24-000075:mdna:81]
We believe that 5G combined with high-performance, low-power computing and on-device artificial intelligence will continue to drive adoption of certain technologies that are already commonly used in smartphones by industries and applications beyond mobile handsets, such as automotive and IoT. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing, and a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long-term.

[0000804328-24-000075:mdna:82]
As we look forward to the next several quarters:

[0000804328-24-000075:mdna:83]
•We expect transitions to new generations of leading process technology nodes to continue to drive product cost increases from certain of our key semiconductor wafer suppliers.

[0000804328-24-000075:mdna:84]
•We expect continued intense competition, including from vertical integration by certain of our customers (e.g., Apple).

[0000804328-24-000075:mdna:85]
•Current U.S./China trade relations and/or national security protection policies may negatively impact our business, growth prospects and results of operations. See “Risk Factors” in this Annual Report, including the Risk Factor titled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0000804328-24-000075:mdna:86]
In fiscal 2024, we extended, renewed or entered into license agreements with several key OEMs. We are currently pursuing negotiations with other key OEMs whose agreements expire in early fiscal 2025 (including Huawei). In addition, in fiscal 2024, we entered into a license agreement with Shenzhen Transsion Holdings Limited (a growing, China-headquartered OEM that sells primarily in developing regions) for its 5G products. While we continue to engage in negotiations toward a comprehensive resolution, we have initiated litigation against Transsion in multiple jurisdictions to enforce our intellectual property rights against certain of its unlicensed products. See “Risk Factors” in this Annual Report, including the Risk Factors titled “The continued and future success of our licensing programs requires us to continue to evolve our patent portfolio and to renew or renegotiate license agreements that are expiring” and “The enforcement and protection of our intellectual property may be expensive, could fail to prevent misappropriation or unauthorized use of our intellectual property, could result in the loss of our ability to enforce one or more patents, and could be adversely affected by changes in patent laws, by laws in certain foreign jurisdictions that may not effectively protect our intellectual property and by ineffective enforcement of laws in such jurisdictions.”

[0000804328-24-000075:mdna:87]
We are also involved in other legal proceedings, including those described in this Annual Report in “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies.” Litigation is inherently uncertain, and, while we intend to continue to vigorously defend ourselves in such matters, the unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0000804328-24-000075:mdna:88]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless industry and governments as to the benefits of our licensing programs and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may be dissatisfied with the need to pay reasonable royalties for the use of our technologies and not welcome the success of our licensing programs in enabling new, highly cost-effective competitors to their products. Accordingly, such companies, and/or governments or regulators, may continue to challenge our business model in various forums throughout the world.

[0000804328-24-000075:mdna:89]
Further discussion of risks related to our business is provided in “Part I, Item 1A. Risk Factors” included in this Annual Report.

[0000804328-24-000075:mdna:90]
Liquidity and Capital Resources

[0000804328-24-000075:mdna:91]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs, which we believe will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans.

[0000804328-24-000075:mdna:92]
The following table presents selected financial information related to our liquidity as of and for the years ended September 29, 2024 and September 24, 2023 (in millions):

[0000804328-24-000075:mdna:93]
|  | September 29,2024 |  | September 24,2023 |  | Change |  |  |
| Cash, cash equivalents and marketable securities |  |  |  |  |  |  |  |
| Cash and cash equivalents (1) | $ | 7,849 |  |  | $ | 8,450 |  |  | $ | (601) |  |  |  |
| Marketable securities | 5,451 |  |  | 2,874 |  |  | 2,577 |  |  |  |
| Cash, cash equivalents and marketable securities | $ | 13,300 |  |  | $ | 11,324 |  |  | $ | 1,976 |  |  |  |
| Debt (2) | $ | 14,634 |  |  | $ | 15,398 |  |  | $ | (764) |  |  |  |

[0000804328-24-000075:mdna:94]
(1) Excludes $77 million of cash and cash equivalents classified as held for sale at September 24, 2023.

[0000804328-24-000075:mdna:95]
(2) Includes our issued debt reported as long-term and short-term.

[0000804328-24-000075:mdna:96]
|  | 2024 |  | 2023 |  | Change |
| Net cash provided by operating activities | $ | 12,202 |  |  | $ | 11,299 |  |  | $ | 903 |  |
| Net cash (used) provided by investing activities | (3,623) |  |  | 762 |  |  | (4,385) |  |
| Net cash used by financing activities | (9,269) |  |  | (6,663) |  |  | (2,606) |  |

[0000804328-24-000075:mdna:97]
Cash, cash equivalents and marketable securities. The net increase in cash, cash equivalents and marketable securities in fiscal 2024 was primarily due to net cash provided by operating activities and $383 million in proceeds from the issuance of common stock (primarily under our Employee Stock Purchase Plan), partially offset by $4.1 billion in payments to repurchase shares of our common stock, $3.7 billion in cash dividends paid, $1.0 billion in capital expenditures, $932 million in payments of tax withholdings related to the vesting of share-based awards and $914 million in repayments of notes that matured in May 2024.

[0000804328-24-000075:mdna:98]
During fiscal 2024, income taxes paid were in excess of our provision, negatively impacting net cash provided by operating activities. This was primarily driven by the adverse impact of the requirement to capitalize and amortize research and development expenditures for federal income tax purposes, our payment of $1.0 billion related to certain previously postponed U.S. federal income tax payments from fiscal 2023 and an installment payment for a one-time U.S. repatriation tax accrued in fiscal 2018 of $414 million.

[0000804328-24-000075:mdna:99]
Net changes in our operating assets and liabilities positively impacted our operating cash flows in fiscal 2024 primarily from an increase in accrued customer incentives, which included the impact of timing of related payments, and an increase in accounts payable due to timing and amount of inventory purchases, partially offset by an increase in accounts receivable due to higher revenues.

[0000804328-24-000075:mdna:100]
Debt. At September 29, 2024, we had $15.0 billion of principal fixed-rate notes outstanding, $1.4 billion of which matures in May 2025. The remaining debt has maturity dates in 2027 through 2053.

[0000804328-24-000075:mdna:101]
We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At September 29, 2024, we had no amounts of commercial paper outstanding. On August 8, 2024, we entered into a Revolving Credit Facility, replacing our prior Amended and Restated Revolving Credit Facility. The Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, which expires on August 8, 2029. At September 29, 2024, no amounts were outstanding under the Revolving Credit Facility.

[0000804328-24-000075:mdna:102]
We expect to issue new debt in the future. The amount and timing of any such new debt will depend on a number of factors, including but not limited to maturities of our existing debt, acquisitions and strategic investments, favorable and/or acceptable interest rates and changes in corporate income tax law. Additional information regarding our outstanding debt at September 29, 2024 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 6. Debt.”

[0000804328-24-000075:mdna:103]
Income Taxes. At September 29, 2024, our remaining future payments were $1.0 billion for a one-time U.S. repatriation tax accrued in fiscal 2018, after application of certain tax credits, which is payable in installments over the next two years. At September 29, 2024, other current liabilities included $530 million for the next installment due in January 2025. Beginning in fiscal 2023, for federal income tax purposes, we are required to capitalize and amortize domestic research and development expenditures over five years and foreign research and development expenditures over fifteen years (such expenditures were previously deducted as incurred). As a result, our cash flows from operations are adversely affected due to significantly higher cash tax payments. However, the adverse cash flow impact will diminish in future years as capitalized research and

[0000804328-24-000075:mdna:104]
development expenditures continue to amortize. Additional information regarding our income taxes is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 3. Income Taxes.”

[0000804328-24-000075:mdna:105]
Capital Return Program. The following table summarizes stock repurchases and dividends paid during fiscal 2024 and 2023 (in millions, except per-share amounts):

[0000804328-24-000075:mdna:106]
|  |  | Stock Repurchase Program |  | Dividends |  | Total |
|  |  | Shares |  | Average Price Paid Per Share |  | Amount |  | Per Share |  | Amount |  | Amount |
| 2024 |  | 25 |  |  | $ | 161.37 |  |  | $ | 4,121 |  |  | $ | 3.30 |  |  | $ | 3,687 |  |  | $ | 7,808 |  |
| 2023 |  | 25 |  |  | 117.93 |  |  | 2,973 |  |  | 3.10 |  |  | 3,462 |  |  | 6,435 |  |

[0000804328-24-000075:mdna:107]
On October 12, 2021, we announced a $10.0 billion stock repurchase program. At September 29, 2024, $1.0 billion remained authorized for repurchase under this stock repurchase program. On November 6, 2024, we announced a new $15.0 billion stock repurchase authorization, which is in addition to the aforementioned program. The stock repurchase programs have no expiration date. The timing of stock repurchases and the number of shares of common stock to be repurchased will depend upon prevailing market conditions and other factors. Repurchases may be made in the open market, through 10b5-1 programs, through accelerated share repurchase programs, in privately negotiated transactions or through the use of derivative instruments. Our stock repurchase programs are subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time.

[0000804328-24-000075:mdna:108]
On October 16, 2024, we announced a cash dividend of $0.85 per share on our common stock, payable on December 19, 2024 to stockholders of record as of the close of business on December 5, 2024. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0000804328-24-000075:mdna:109]
Additional Capital Requirements. Recent and expected working and other capital requirements, in addition to the above matters, also include the items described below:

[0000804328-24-000075:mdna:110]
•Our purchase obligations at September 29, 2024, which primarily relate to purchase commitments with certain suppliers of our integrated circuit products, including those under multi-year capacity commitments, totaled $12.8 billion, of which, $9.6 billion is expected to be paid in the next 12 months.

[0000804328-24-000075:mdna:111]
•Our research and development expenditures were $8.9 billion in fiscal 2024 and $8.8 billion in fiscal 2023.

[0000804328-24-000075:mdna:112]
•Cash outflows for capital expenditures were $1.0 billion in fiscal 2024 and $1.5 billion in fiscal 2023. We expect capital expenditures to increase from fiscal 2024 in the near term to support our production and testing needs related to our growth and diversification initiatives.

[0000804328-24-000075:mdna:113]
•Amounts related to future lease payments for operating lease obligations at September 29, 2024 totaled $1.1 billion, with $136 million expected to be paid within the next 12 months.

[0000804328-24-000075:mdna:114]
•We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly.

[0000804328-24-000075:mdna:115]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us in the past, and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies” and “Part I, Item 1A. Risk Factors” in this Annual Report.

[0000804328-24-000075:mdna:116]
Critical Accounting Estimates

[0000804328-24-000075:mdna:117]
The preparation of our consolidated financial statements in accordance with accounting principles generally accepted in the United States requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and disclosure of contingent assets and liabilities. We base our estimates on historical and anticipated results and trends and on various other assumptions that we believe are reasonable under the circumstances, including assumptions as to future events. By their nature, estimates are inherently subject to a degree of uncertainty. Although we believe that our estimates and the assumptions supporting our assessments are reasonable, actual results could differ materially from our estimates and assumptions, and could be material to our consolidated financial statements.

[0000804328-24-000075:mdna:118]
In addition to our critical accounting estimates and policies below, refer to “Note 1. Significant Accounting Policies” and “Note 2. Composition of Certain Financial Statement Items” included in this Annual Report in “Notes to Consolidated Financial Statements” for further information. If the impact of changes in our critical accounting estimates are material or considered necessary to understand our results of operations for the periods presented, then such information is disclosed within this Annual Report in “Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.”

[0000804328-24-000075:mdna:119]
Revenue Recognition. We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. We estimate and recognize sales-based royalties on such licensed products in the period in which the licensees’ sales occur, which is based largely on preliminary royalty estimates provided by our licensees. For fiscal 2024 and 2023, actual amounts for sales-based royalties have been materially consistent with such estimates, and no significant reversals of revenues have been required as a result of adjustments to prior period royalty estimates.

[0000804328-24-000075:mdna:120]
Impairment of Non-marketable Equity Investments. We monitor our investments for events or circumstances that could indicate impairment, including those that result from observable price adjustments. Key considerations in this assessment include the investee’s financial and liquidity position and business forecasts (including their ability to respond to any significant deterioration), industry performance, development and/or market acceptance of the investee’s products or technologies, as well as considering any appreciation in fair value that has not been recognized in the carrying values of such investments and other relevant events and factors. In fiscal 2024 and 2023, there were no significant impairment losses or adjustments to our previous judgments and estimates recorded.

[0000804328-24-000075:mdna:121]
Inventories. We measure inventory at the lower of cost or net realizable value considering judgments and estimates related to future customer demand and other market conditions, such as the impact of the macroeconomic environment in fiscal 2023, which negatively impacted consumer demand for smartphones and other devices that incorporate our products and technologies. Although we believe these estimates are reasonable, any significant changes in customer demand that are less favorable than our previous estimates may require additional inventory write-downs and would be reflected in cost of sales resulting in a negative impact to our gross margin in that period. For fiscal 2024 and 2023, the net effect from changes in this estimate and related reserves was less than 2% of cost of revenues during each period.

[0000804328-24-000075:mdna:122]
Impairment of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. We monitor our goodwill, other indefinite-lived assets and long-lived assets for the existence of impairment indicators and apply judgments in the valuation methods and underlying assumptions utilized in such assessments. During fiscal 2024, there were no material impairment charges for long-lived or indefinite-lived assets. During fiscal 2023, we recorded total impairment charges of approximately $400 million related to certain long-lived and other indefinite-lived assets. Such impairments (and the related remaining asset values) were not individually material. Additionally, the estimated fair values of our QCT and QTL reporting units, based on our qualitative assessment, were substantially in excess of their respective carrying values at September 29, 2024.

[0000804328-24-000075:mdna:123]
Legal and Regulatory Proceedings. We record our best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. We face difficulties in evaluating or estimating likely outcomes and/or the amount of possible loss in certain legal and regulatory proceedings.

[0000804328-24-000075:mdna:124]
Income Taxes. We make significant judgments and estimates in determining our provision for income taxes, including our assessment of our income tax positions given the uncertainties involved in the interpretation and application of complex tax laws and regulations in various taxing jurisdictions.

[0000804328-24-000075:mdna:125]
Recent Accounting Pronouncements

[0000804328-24-000075:mdna:126]
Information regarding recent accounting pronouncements and the impact of those pronouncements, if any, on our consolidated financial statements is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 1. Significant Accounting Policies.”
