# QCOM note change history — 0001234452-15-000208 → 0001234452-16-000352


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-01-27):
[0001234452-16-000352:note_history:1]
Note 6. Commitments and Contingencies
  (was, 2015-07-22, similarity 0.973):
[0001234452-15-000208:note_history:1]
Note 6 — Commitments and Contingencies

- added (2016-01-27):
[0001234452-16-000352:note_history:2]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict and denied ParkerVision’s motions for injunctive relief and ongoing royalties as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit heard the appeal on May 8, 2015 and issued a decision on July 31, 2015. The decision affirmed the District Court’s finding of non-infringement and granted in part the Company’s cross-appeal, holding 10 of the 11 asserted claims invalid. A subsequent Petition for Rehearing by ParkerVision was denied on October 2, 2015. On December 16, 2015, ParkerVision was granted an extension of the deadline to file a petition requesting that the United States Supreme Court hear ParkerVision’s appeal of the Federal Circuit decision. The petition is now due on January 29, 2016.

- added (2016-01-27):
[0001234452-16-000352:note_history:3]
On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. On September 25, 2015, ParkerVision filed a motion with the court to sever some claims against the Company and all other defendants into a separate lawsuit. In addition, on December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. The close of discovery is scheduled for April 2016, and the trial is scheduled for November 2016. A claim construction ruling and a ruling on ParkerVision’s severance motion are still pending.

- added (2016-01-27):
[0001234452-16-000352:note_history:4]
On December 14, 2015, ParkerVision filed a third complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. are also named defendants. The complaint asserts four additional patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. The ITC has not yet determined a target date for concluding its investigation.

- added (2016-01-27):
[0001234452-16-000352:note_history:5]
Nvidia Corporation v. QUALCOMM Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd. and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chipset products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District Court complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. Nvidia later narrowed the case to three asserted patents. On October 9, 2015, the Administrative Law Judge issued an Initial Determination finding no violation of Section 337 because none of the three patents were both valid and infringed. On October 22, 2015, the Administrative Law Judge issued a recommendation that, if the ITC were to find any violation of Section 337 in the investigation, the ITC should issue a limited exclusion order directed at Samsung’s accused products and a cease and desist order against Samsung but not the Company. On October 26, 2015, Nvidia filed a petition requesting the ITC to review the Initial Determination as to two of the asserted patents, but is no longer pursuing infringement allegations with respect to the third patent. On December 14, 2015, the ITC issued its decision not to review the Initial Determination of the Administrative Law Judge. This made final the determination that the Company did not violate Section 337. Therefore, neither an exclusion order nor a cease and desist order were issued. Nvidia has until February 12, 2016 to file a notice of appeal of the ITC’s determination. The District Court case was stayed on October 23, 2014 pending completion of the ITC investigation, including appeals.

- added (2016-01-27):
[0001234452-16-000352:note_history:6]
LG Electronics, Inc. (LGE) Arbitration: In December 2015, LGE filed an arbitration demand with the International Chamber of Commerce alleging that it overpaid royalties on certain CDMA (including WCDMA) subscriber units based on the alleged effect of specific provisions in its license agreement, and that the Company breached its license agreement with LGE, as well as certain implied covenants. The arbitration demand seeks determination and return of the overpayment and determination of the ongoing royalties owed by LGE. The Company intends to respond to the arbitration demand, denying the allegations and requesting judgment in its favor on all claims. Although the Company believes LGE’s claims are without merit, it has deferred the recognition of revenue related to CDMA subscriber unit royalties reported and paid by LGE in the first quarter of fiscal 2016 because, among other reasons, the matter has been submitted to arbitration for resolution.

- changed (2016-01-27):
[0001234452-16-000352:note_history:7]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 31 different dates, with the next hearing scheduled for February 25, 2016.
  (was, 2015-07-22, similarity 0.9956):
[0001234452-15-000208:note_history:7]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 27 different dates, with the next hearing scheduled for August 4, 2015.

- changed (2016-01-27):
[0001234452-16-000352:note_history:8]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments during fiscal 2016 with respect to this matter.
  (was, 2015-07-22, similarity 0.9958):
[0001234452-15-000208:note_history:8]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments during fiscal 2015 with respect to this matter.

- added (2016-01-27):
[0001234452-16-000352:note_history:9]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it is conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On November 13, 2015, the Company received a case Examiner’s Report (ER) prepared by the KFTC’s investigative staff. The ER alleges, among other things, that the Company is in violation of Korean competition law by licensing its patents exhaustively only to device manufacturers and requiring that its chipset customers be licensed to the Company’s intellectual property. The ER also alleges that the Company obtains certain terms, including royalty terms, that are unfair or unreasonable in its license agreements through negotiations that do not conform to Korean competition law. The ER proposes remedies including modifications to certain business practices and monetary penalties. It remains difficult to predict the outcome of this matter. The Company believes that its business practices do not violate the MRFTA. The Company continues to cooperate with the KFTC as it conducts its investigation.

- added (2016-01-27):
[0001234452-16-000352:note_history:10]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

- added (2016-01-27):
[0001234452-16-000352:note_history:11]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that since 2011 the Company has paid significant amounts to a customer on condition that it exclusively use the Company’s baseband chipsets in its smartphones and tablets. This conduct has allegedly reduced the customer’s incentives to source chipsets from the Company’s competitors and harmed competition and innovation for certain baseband chipsets. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

- added (2016-01-27):
[0001234452-16-000352:note_history:12]
On November 19, 2015, the DOJ notified the Company that it was terminating its investigation and would not pursue charges in this matter. The DOJ’s decision is independent of the SEC’s investigation, with which we continue to cooperate.

- changed (2016-01-27):
[0001234452-16-000352:note_history:13]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act (FTCA). The FTC has notified the Company that it is investigating conduct related to standard essential patents and pricing and contracting practices with respect to baseband processors and related products. If a violation of Section 5 is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company believes that its business practices do not violate the FTCA. The Company continues to cooperate with the FTC as it conducts its investigation.
  (was, 2015-07-22, similarity 0.8774):
[0001234452-15-000208:note_history:13]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act. The FTC has notified the Company that it is investigating conduct related to standard essential patents and pricing and contracting practices with respect to baseband processors and related products. If a violation of Section 5 is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company continues to cooperate with the FTC as it conducts its investigation.

- added (2016-01-27):
[0001234452-16-000352:note_history:14]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified the Company that it is conducting an investigation into whether the Company’s patent licensing arrangements violate the Taiwan Fair Trade Act (TFTA). If a violation is found, a broad range of remedies is potentially available to the TFTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the TFTC. The Company believes that its business practices do not violate the TFTA. The Company continues to cooperate with the TFTC as it conducts its investigation.

- changed (2016-01-27):
[0001234452-16-000352:note_history:15]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. Other than a nominal amount, the Company has not recorded any accrual at December 27, 2015 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.
  (was, 2015-07-22, similarity 0.9357):
[0001234452-15-000208:note_history:15]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at June 28, 2015 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

- changed (2016-01-27):
[0001234452-16-000352:note_history:16]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through December 27, 2015, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.
  (was, 2015-07-22, similarity 0.7619):
[0001234452-15-000208:note_history:16]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through June 28, 2015, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

- added (2016-01-27):
[0001234452-16-000352:note_history:17]
Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at December 27, 2015 associated with these indemnification arrangements, other than nominal amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- added (2016-01-27):
[0001234452-16-000352:note_history:18]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at December 27, 2015 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $3.2 billion, $891 million, $739 million, $718 million and $196 million, respectively, and $14 million thereafter. Of these amounts, for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020, commitments to purchase integrated circuit product inventories comprised $2.6 billion, $742 million, $698 million, $699 million and $177 million, respectively, and there were no purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancellation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancellation, and in some cases, incremental fees related to capacity underutilization.

- changed (2016-01-27):
[0001234452-16-000352:note_history:19]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancellable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments at December 27, 2015 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $75 million, $78 million, $45 million, $30 million and $20 million, respectively, and $27 million thereafter.
  (was, 2015-07-22, similarity 0.8722):
[0001234452-15-000208:note_history:19]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 16 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 are $23 million, $84 million, $64 million, $33 million and $21 million, respectively, and $16 million thereafter.

- changed (2016-01-27):
[0001234452-16-000352:note_history:20]
Other Commitments. At December 27, 2015, the Company was committed to fund certain strategic investments up to $431 million. Of this amount, $197 million is expected to be funded in the remainder of fiscal 2016. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.
  (was, 2015-07-22, similarity 0.926):
[0001234452-15-000208:note_history:20]
Other Commitments. The Company is committed to fund certain strategic investments up to $197 million. Of this amount, $105 million will be funded in fiscal 2015. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.

- removed (2016-01-27):
[0001234452-15-000208:note_history:21]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit heard the appeal on May 8, 2015 and will issue a decision sometime in the coming months. On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision now alleges that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. The Company was served with the complaint in this second action on August 28, 2014 and answered on November 17, 2014. The judge’s schedule sets the claim construction hearing for August 12, 2015, the close of discovery for January 2016 and the trial for August 2016.

- removed (2016-01-27):
[0001234452-15-000208:note_history:22]
Nvidia Corporation v. QUALCOMM Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd., and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chipset products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District of Delaware complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. On April 2, 2015, the Administrative Law Judge in the ITC investigation issued a claim construction order construing seven claim terms from five of the seven asserted patents. The evidentiary hearing for the investigation was held from June 22 to June 26, 2015. Nvidia withdrew the ITC complaint with respect to four of the patents, but is moving forward with infringement allegations with respect to three of the patents. The Initial Determination of the Administrative Law Judge is due October 9, 2015, and the target date for completion of the investigation by the ITC is set for February 10, 2016. The district court case was stayed on October 23, 2014 pending completion of the ITC investigation including appeals.

- removed (2016-01-27):
[0001234452-15-000208:note_history:23]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. The Commission is investigating “alleged practices in the form of predatory pricing on certain UMTS standard-compliant chipsets used to deliver cellular mobile broadband access.” The initiation of proceedings merely means that the Commission will deal with the case as a matter of priority. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that none of the business practices under investigation are in breach of the EU competition rules and will continue to cooperate with the Commission.

- removed (2016-01-27):
[0001234452-15-000208:note_history:24]
The Company is continuing to cooperate with the SEC and the DOJ, but is unable to predict the outcome of their investigations or any actions that the SEC or DOJ may decide to file.

- removed (2016-01-27):
[0001234452-15-000208:note_history:25]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. The Commission is investigating “alleged payments, rebates and/or other consideration granted by Qualcomm Incorporated or any of its affiliates and/or subsidiaries (Qualcomm) to smartphone and/or tablet manufacturers which are conditional upon the exclusive or quasi-exclusive use or purchase of Qualcomm products, in particular baseband chipsets, by the respective manufacturer(s).” The initiation of proceedings merely means that the Commission will deal with the case as a matter of priority. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that none of the business practices under investigation are in breach of the EU competition rules and will continue to cooperate with the Commission.

- removed (2016-01-27):
[0001234452-15-000208:note_history:26]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it is conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA).  The Company understands that this investigation concerns primarily its licensing business. If a violation of the MRFTA is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine or requiring modifications to the Company’s licensing practices. Given that this investigation is in its early stages, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. The Company continues to cooperate with the KFTC as it conducts its investigation.

- removed (2016-01-27):
[0001234452-15-000208:note_history:27]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at June 28, 2015 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- removed (2016-01-27):
[0001234452-15-000208:note_history:28]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at June 28, 2015 for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 were $2.2 billion, $1.2 billion, $921 million, $791 million and $721 million, respectively, and $175 million thereafter. Of these amounts, for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019, commitments to purchase integrated circuit product inventories comprised $1.8 billion, $1.0 billion, $771 million, $703 million and $651 million, respectively, and $152 million thereafter. Integrated circuit product inventory obligations represent purchase commitments for wafers, die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-01-27):
[0001234452-16-000352:note_history:29]
Note 1. Basis of Presentation
  (was, 2015-07-22, similarity 0.9655):
[0001234452-15-000208:note_history:29]
Note 1 — Basis of Presentation

- changed (2016-01-27):
[0001234452-16-000352:note_history:30]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 27, 2015. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month periods ended December 27, 2015 and December 28, 2014 included 13 weeks.
  (was, 2015-07-22, similarity 0.9527):
[0001234452-15-000208:note_history:30]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 28, 2014. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 28, 2015 and June 29, 2014 included 13 weeks and 39 weeks, respectively.

- changed (2016-01-27):
[0001234452-16-000352:note_history:31]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three months ended December 27, 2015 and December 28, 2014 were 14,430,000 and 25,003,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 1,172,000 and 1,470,000 during the three months ended December 27, 2015 and December 28, 2014, respectively.
  (was, 2015-07-22, similarity 0.8887):
[0001234452-15-000208:note_history:31]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 28, 2015 were 20,749,000 and 22,447,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 29, 2014 were 30,642,000 and 31,985,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 16,711,000 and 6,067,000 during the three and nine months ended June 28, 2015, respectively, which were primarily attributable to the ASR Agreements (Note 4), and 7,000 and 278,000 during the three and nine months ended June 29, 2014, respectively.

- changed (2016-01-27):
[0001234452-16-000352:note_history:32]
|  | Three Months Ended |
|  | December 27, 2015 |  | December 28, 2014 |
| Cost of equipment and services revenues | $ | 10 |  |  | $ | 12 |  |
| Research and development | 165 |  |  | 174 |  |
| Selling, general and administrative | 72 |  |  | 87 |  |
| Share-based compensation expense before income taxes | 247 |  |  | 273 |  |
| Related income tax benefit | (60 | ) |  | (44 | ) |
|  | $ | 187 |  |  | $ | 229 |  |
  (was, 2015-07-22, similarity 0.7133):
[0001234452-15-000208:note_history:32]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | June 28, 2015 |  | June 29, 2014 |
| Cost of equipment and services revenues | $ | 10 |  |  | $ | 12 |  |  | $ | 33 |  |  | $ | 37 |  |
| Research and development | 176 |  |  | 174 |  |  | 508 |  |  | 510 |  |
| Selling, general and administrative | 85 |  |  | 88 |  |  | 252 |  |  | 259 |  |
| Share-based compensation expense before income taxes | 271 |  |  | 274 |  |  | 793 |  |  | 806 |  |
| Related income tax benefit | (58 | ) |  | (42 | ) |  | (145 | ) |  | (151 | ) |
|  | $ | 213 |  |  | $ | 232 |  |  | $ | 648 |  |  | $ | 655 |  |

- changed (2016-01-27):
[0001234452-16-000352:note_history:33]
The Company recorded $31 million in share-based compensation expense during each of the three months ended December 27, 2015 and December 28, 2014 related to share-based awards granted during those periods. At December 27, 2015, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.6 billion, which is expected to be recognized over a weighted-average period of 2.2 years. During the three months ended December 27, 2015 and December 28, 2014, net share-based awards granted, after forfeitures and cancellations, represented 0.7% and 0.4%, respectively, of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.9% and 0.4%, respectively, of outstanding shares as of the end of each fiscal period.
  (was, 2015-07-22, similarity 0.8628):
[0001234452-15-000208:note_history:33]
The Company recorded $173 million and $177 million in share-based compensation expense during the nine months ended June 28, 2015 and June 29, 2014, respectively, related to share-based awards granted during those periods. At June 28, 2015, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.5 billion, which is expected to be recognized over a weighted-average period of 2.0 years. During the nine months ended June 28, 2015 and June 29, 2014, net share-based awards granted, after forfeitures and cancelations, represented 0.8% of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.9% of outstanding shares as of the end of each fiscal period.

- changed (2016-01-27):
[0001234452-16-000352:note_history:34]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The new standard will be effective for the Company starting in the first quarter of fiscal 2019. The FASB will permit entities to adopt one year earlier if they choose (i.e., the original effective date). The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the standard early and is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.
  (was, 2015-07-22, similarity 0.9712):
[0001234452-15-000208:note_history:34]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for the Company starting in the first quarter of fiscal 2019. The FASB will also permit entities to adopt one year earlier if they choose (i.e., the original effective date). The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the standard early and is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.

- added (2016-01-27):
[0001234452-16-000352:note_history:35]
In November 2015, the FASB issued ASU No. 2015-17, “Balance Sheet Classification of Deferred Taxes,” which requires all deferred tax assets and liabilities to be classified as noncurrent on the balance sheet. The new accounting guidance is effective for annual reporting periods beginning after December 15, 2016 and interim periods therein. Early adoption is permitted as of the beginning of interim or annual reporting periods. The Company plans to adopt the standard prospectively in the second quarter of fiscal 2016.

- added (2016-01-27):
[0001234452-16-000352:note_history:36]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments-Overall: Recognition and Measurement of Financial Assets and Financial Liabilities,” which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk will be recognized separately in other comprehensive income. Additionally, the ASU changes the disclosure requirements for financial instruments. The new standard will be effective for the Company starting in the first quarter of fiscal 2019. Early adoption is permitted for certain provisions. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt certain provisions early.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-01-27):
[0001234452-16-000352:note_history:37]
Note 5. Debt
  (was, 2015-07-22, similarity 0.9167):
[0001234452-15-000208:note_history:37]
Note 5 — Debt

- changed (2016-01-27):
[0001234452-16-000352:note_history:38]
Revolving Credit Facility. The Company has a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At December 27, 2015 and September 27, 2015, the Company was in compliance with the covenants, and the Company had not borrowed any funds under the Revolving Credit Facility.
  (was, 2015-07-22, similarity 0.6267):
[0001234452-15-000208:note_history:38]
Revolving Credit Facility. In February 2015, the Company entered into a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. Proceeds from the Revolving Credit Facility will be used for general corporate purposes. Loans under the Revolving Credit Facility bear interest, at the option of the Company, at either LIBOR (determined in accordance with the Revolving Credit Facility) plus a margin of 0.7% per annum or the Base Rate (determined in accordance with the Revolving Credit Facility), plus an initial margin of 0% per annum. The Revolving Credit Facility has a facility fee, which initially accrues at a rate of 0.05% per annum. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At June 28, 2015, the Company was in compliance with the covenants, and the Company had not borrowed any funds under the Revolving Credit Facility.

- added (2016-01-27):
[0001234452-16-000352:note_history:39]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At December 27, 2015 and September 27, 2015, the Company had $1.0 billion of outstanding commercial paper recorded as short-term debt with weighted-average interest rates of 0.25% and 0.19%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 30 days and 38 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at December 27, 2015 and September 27, 2015.

- added (2016-01-27):
[0001234452-16-000352:note_history:40]
Long-term Debt. The following table provides a summary of the Company’s long-term debt (dollar amounts in millions):

- added (2016-01-27):
[0001234452-16-000352:note_history:41]
|  | December 27, 2015 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.70% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 0.98% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.71% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.71% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.14% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (62 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 12 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 9,950 |  |  |  |  | $ | 9,969 |  |  |  |

- changed (2016-01-27):
[0001234452-16-000352:note_history:42]
The interest rate on the floating rate notes due in 2018 and 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At December 27, 2015 and September 27, 2015, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $9.6 billion.
  (was, 2015-07-22, similarity 0.9694):
[0001234452-15-000208:note_history:42]
The interest rate on the floating rate notes due in 2018 and the floating rate notes due in 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At June 28, 2015, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $9.8 billion.

- changed (2016-01-27):
[0001234452-16-000352:note_history:43]
The Company has entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings as interest expense in the current period.
  (was, 2015-07-22, similarity 0.6427):
[0001234452-15-000208:note_history:43]
The Company has entered, and may in the future enter, into interest rate swaps to manage interest rate risk on certain notes. Such swaps allow the Company to effectively convert fixed-rate payments into floating-rate payments. These transactions are designated as fair value hedges, and the gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. In the third quarter of fiscal 2015, the Company entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings as interest expense in the current period.

- added (2016-01-27):
[0001234452-16-000352:note_history:44]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $128 million during the three months ended December 27, 2015. No commercial paper or long-term debt was outstanding in the three months ended December 28, 2014.

- removed (2016-01-27):
[0001234452-15-000208:note_history:45]
Commercial Paper Program. In March 2015, the Company began an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At June 28, 2015, the Company had $1.0 billion of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 0.14%, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 51 days. The carrying value of the outstanding commercial paper approximated its estimated fair value at June 28, 2015.

- removed (2016-01-27):
[0001234452-15-000208:note_history:46]
Long-term Debt. In May 2015, the Company issued an aggregate principal amount of $10.0 billion of unsecured floating- and fixed-rate notes (the notes) with varying maturities. The proceeds from the notes of $9.9 billion, net of underwriting discounts and offering expenses, were used to fund the ASR Agreements (Note 4) and are also being used for other general corporate purposes. The following table provides a summary of the Company’s long-term debt as of June 28, 2015 (dollar amounts in millions):

- removed (2016-01-27):
[0001234452-15-000208:note_history:47]
|  |  | PrincipalAmount |  | EffectiveInterest Rate |
| Floating-rate notes due May 18, 2018 |  | $ | 250 |  |  | 0.61% |
| Floating-rate notes due May 20, 2020 |  | 250 |  |  | 0.88% |
| Fixed-rate 1.40% notes due May 18, 2018 |  | 1,250 |  |  | 0.68% |
| Fixed-rate 2.25% notes due May 20, 2020 |  | 1,750 |  |  | 1.78% |
| Fixed-rate 3.00% notes due May 20, 2022 |  | 2,000 |  |  | 2.28% |
| Fixed-rate 3.45% notes due May 20, 2025 |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 |  | 1,500 |  |  | 4.71% |
| Total principal |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments |  | (22 | ) |  |  |
| Total long-term debt |  | $ | 9,913 |  |  |  |

- removed (2016-01-27):
[0001234452-15-000208:note_history:48]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and, if applicable, adjustments related to hedging. The Company recognized $30 million of interest expense on its long-term debt during the three and nine months ended June 28, 2015. The Company did not have any long-term debt outstanding in fiscal 2014.

- removed (2016-01-27):
[0001234452-15-000208:note_history:49]
No principal payments are due on the Company’s notes prior to fiscal 2018. At June 28, 2015, future principal payments were $1.5 billion in fiscal 2018 and $8.5 billion after fiscal 2019; no principal payments were due in fiscal 2019.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-01-27):
[0001234452-16-000352:note_history:50]
Note 11. Marketable Securities
  (was, 2015-07-22, similarity 0.9655):
[0001234452-15-000208:note_history:50]
Note 11 — Marketable Securities

- changed (2016-01-27):
[0001234452-16-000352:note_history:51]
|  | Current |  | Noncurrent |
|  | December 27, 2015 |  | September 27, 2015 |  | December 27, 2015 |  | September 27, 2015 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | — |  |  | $ | — |  |  | $ | 61 |  |  | $ | 12 |  |
| Corporate bonds and notes | — |  |  | — |  |  | 300 |  |  | 364 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | — |  |  | 279 |  |  | 242 |  |
| Total trading | — |  |  | — |  |  | 640 |  |  | 618 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 160 |  |  | 156 |  |  | 782 |  |  | 691 |  |
| Corporate bonds and notes | 7,942 |  |  | 7,926 |  |  | 7,568 |  |  | 7,112 |  |
| Mortgage- and asset-backed and auction rate securities | 1,339 |  |  | 1,302 |  |  | 299 |  |  | 263 |  |
| Equity and preferred securities and equity funds | 174 |  |  | 377 |  |  | 1,321 |  |  | 1,253 |  |
| Debt funds | — |  |  | — |  |  | 2,870 |  |  | 2,909 |  |
| Total available-for-sale | 9,615 |  |  | 9,761 |  |  | 12,840 |  |  | 12,228 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 583 |  |  | 780 |  |
| Total marketable securities | $ | 9,615 |  |  | $ | 9,761 |  |  | $ | 14,063 |  |  | $ | 13,626 |  |
  (was, 2015-07-22, similarity 0.8133):
[0001234452-15-000208:note_history:51]
|  | Current |  | Noncurrent |
|  | June 28, 2015 |  | September 28, 2014 |  | June 28, 2015 |  | September 28, 2014 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 329 |  |  | $ | 320 |  |  | $ | 6 |  |  | $ | 38 |  |
| Corporate bonds and notes | 187 |  |  | 191 |  |  | 379 |  |  | 367 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 252 |  |  | 237 |  |
| Total trading | 516 |  |  | 511 |  |  | 637 |  |  | 642 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 138 |  |  | 805 |  |  | 708 |  |  | 392 |  |
| Corporate bonds and notes | 8,628 |  |  | 6,274 |  |  | 7,078 |  |  | 7,649 |  |
| Mortgage- and asset-backed securities | 1,297 |  |  | 1,063 |  |  | 216 |  |  | 195 |  |
| Auction rate securities | — |  |  | — |  |  | 46 |  |  | 83 |  |
| Common and preferred stock | 550 |  |  | 192 |  |  | 886 |  |  | 1,605 |  |
| Equity funds | — |  |  | — |  |  | 496 |  |  | 541 |  |
| Debt funds | 215 |  |  | 813 |  |  | 3,038 |  |  | 2,560 |  |
| Total available-for-sale | 10,828 |  |  | 9,147 |  |  | 12,468 |  |  | 13,025 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 789 |  |  | 790 |  |
| Total marketable securities | $ | 11,344 |  |  | $ | 9,658 |  |  | $ | 13,894 |  |  | $ | 14,457 |  |

- changed (2016-01-27):
[0001234452-16-000352:note_history:52]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At December 27, 2015, the Company had an effective ownership interest in the debt fund of 22%. Changes in fair value associated with this investment are recognized in net investment income. During the three months ended December 27, 2015 and December 28, 2014, the changes in fair value associated with this investment were negligible.
  (was, 2015-07-22, similarity 0.7282):
[0001234452-15-000208:note_history:52]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At June 28, 2015, the Company had an effective ownership interest in the debt fund of 25%. Changes in fair value associated with this investment are recognized in net investment income. During the three and nine months ended June 28, 2015, the changes in fair value associated with this investment were negligible. During the three and nine months ended June 29, 2014, net increases in fair value associated with this investment were $12 million and $30 million, respectively.

- changed (2016-01-27):
[0001234452-16-000352:note_history:53]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net losses recognized on debt securities classified as trading held at December 27, 2015 and December 28, 2014 were negligible and $12 million during the three months ended December 27, 2015 and December 28, 2014, respectively.
  (was, 2015-07-22, similarity 0.604):
[0001234452-15-000208:note_history:53]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains recognized on debt securities classified as trading held at June 28, 2015 were negligible for both the three and nine months ended June 28, 2015. Net gains recognized on debt securities classified as trading held at June 29, 2014 were negligible for both the three and nine months ended June 29, 2014.

- changed (2016-01-27):
[0001234452-16-000352:note_history:54]
At December 27, 2015, the contractual maturities of available-for-sale debt securities were as follows (in millions):
  (was, 2015-07-22, similarity 0.9541):
[0001234452-15-000208:note_history:54]
At June 28, 2015, the contractual maturities of available-for-sale debt securities were as follows (in millions):

- changed (2016-01-27):
[0001234452-16-000352:note_history:55]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities and auction rate securities.
  (was, 2015-07-22, similarity 0.8797):
[0001234452-15-000208:note_history:55]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities, auction rate securities and corporate bonds and notes.

- changed (2016-01-27):
[0001234452-16-000352:note_history:56]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| December 27, 2015 | $ | 50 |  |  | $ | (12 | ) |  | $ | 38 |  |
| December 28, 2014 | 180 |  |  | (8 | ) |  | 172 |  |
  (was, 2015-07-22, similarity 0.7243):
[0001234452-15-000208:note_history:56]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| June 28, 2015 | $ | 126 |  |  | $ | (10 | ) |  | $ | 116 |  |
| June 29, 2014 | 267 |  |  | (8 | ) |  | 259 |  |
| For the nine months ended |  |  |  |  |  |
| June 28, 2015 | $ | 434 |  |  | $ | (48 | ) |  | $ | 386 |  |
| June 29, 2014 | 610 |  |  | (16 | ) |  | 594 |  |

- added (2016-01-27):
[0001234452-16-000352:note_history:57]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| December 27, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,266 |  |  | $ | 251 |  |  | $ | (22 | ) |  | $ | 1,495 |  |
| Debt securities (including debt funds) | 21,234 |  |  | 132 |  |  | (406 | ) |  | 20,960 |  |
|  | $ | 22,500 |  |  | $ | 383 |  |  | $ | (428 | ) |  | $ | 22,455 |  |
| September 27, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,394 |  |  | $ | 264 |  |  | $ | (28 | ) |  | $ | 1,630 |  |
| Debt securities (including debt funds) | 20,459 |  |  | 185 |  |  | (285 | ) |  | 20,359 |  |
|  | $ | 21,853 |  |  | $ | 449 |  |  | $ | (313 | ) |  | $ | 21,989 |  |

- changed (2016-01-27):
[0001234452-16-000352:note_history:58]
|  | December 27, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 808 |  |  | $ | (12 | ) |  | $ | 20 |  |  | $ | (2 | ) |
| Corporate bonds and notes | 10,466 |  |  | (132 | ) |  | 956 |  |  | (108 | ) |
| Mortgage- and asset-backed and auction rate securities | 1,220 |  |  | (7 | ) |  | 164 |  |  | (1 | ) |
| Equity and preferred securities and equity funds | 360 |  |  | (22 | ) |  | 2 |  |  | — |  |
| Debt funds | 1,923 |  |  | (138 | ) |  | 79 |  |  | (6 | ) |
|  | $ | 14,777 |  |  | $ | (311 | ) |  | $ | 1,221 |  |  | $ | (117 | ) |
  (was, 2015-07-22, similarity 0.6169):
[0001234452-15-000208:note_history:58]
|  | September 28, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 279 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,924 |  |  | (31 | ) |  | 104 |  |  | (4 | ) |
| Mortgage- and asset-backed securities | 484 |  |  | (1 | ) |  | 52 |  |  | (1 | ) |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Common and preferred stock | 86 |  |  | (3 | ) |  | 52 |  |  | (3 | ) |
| Debt funds | 133 |  |  | (1 | ) |  | 384 |  |  | (19 | ) |
|  | $ | 5,906 |  |  | $ | (38 | ) |  | $ | 675 |  |  | $ | (28 | ) |

- changed (2016-01-27):
[0001234452-16-000352:note_history:59]
|  | September 27, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 304 |  |  | $ | (4 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 7,656 |  |  | (93 | ) |  | 368 |  |  | (62 | ) |
| Mortgage- and asset-backed and auction rate securities | 862 |  |  | (3 | ) |  | 108 |  |  | (1 | ) |
| Equity and preferred securities and equity funds | 392 |  |  | (28 | ) |  | 17 |  |  | — |  |
| Debt funds | 1,792 |  |  | (117 | ) |  | 124 |  |  | (5 | ) |
|  | $ | 11,006 |  |  | $ | (245 | ) |  | $ | 617 |  |  | $ | (68 | ) |
  (was, 2015-07-22, similarity 0.6396):
[0001234452-15-000208:note_history:59]
|  | June 28, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 313 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 7,413 |  |  | (59 | ) |  | 142 |  |  | (9 | ) |
| Mortgage- and asset-backed securities | 874 |  |  | (2 | ) |  | 16 |  |  | — |  |
| Auction rate securities | — |  |  | — |  |  | 46 |  |  | (1 | ) |
| Common and preferred stock | 155 |  |  | (2 | ) |  | 18 |  |  | — |  |
| Debt funds | 934 |  |  | (18 | ) |  | 47 |  |  | (1 | ) |
|  | $ | 9,689 |  |  | $ | (83 | ) |  | $ | 269 |  |  | $ | (11 | ) |

- changed (2016-01-27):
[0001234452-16-000352:note_history:60]
At December 27, 2015, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.
  (was, 2015-07-22, similarity 0.9895):
[0001234452-15-000208:note_history:60]
At June 28, 2015, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

- changed (2016-01-27):
[0001234452-16-000352:note_history:61]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was $22 million and negligible at December 27, 2015 and December 28, 2014, respectively.
  (was, 2015-07-22, similarity 0.8925):
[0001234452-15-000208:note_history:61]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company were negligible at June 28, 2015 and June 29, 2014, respectively.

- removed (2016-01-27):
[0001234452-15-000208:note_history:62]
In connection with the pending acquisition of CSR (Note 8), the Company agreed to set aside certain cash, cash equivalents and marketable securities to be held for purposes of satisfying payment of the consideration to effect the acquisition, which is expected to close by the end of the summer of 2015. At June 28, 2015, the fair values of the marketable securities that were set aside were $2.9 billion of corporate bonds and notes, $790 million of mortgage- and asset-backed securities and $79 million in U.S. Treasury securities and government-related securities. Additionally, $47 million in cash equivalents, which were recorded as other current assets, were set aside. If the combined fair values fall below approximately £1.9 billion (approximately $2.9 billion using an exchange rate of USD: GBP 1.5634), the Company may be required to set aside additional amounts. Additionally, if certain conditions are met, such as a reduction in the liquidity of any of the securities that are set aside, the Company may be required to liquidate the securities and transfer the cash to a third party until the acquisition closes.

- removed (2016-01-27):
[0001234452-15-000208:note_history:63]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| June 28, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,543 |  |  | $ | 391 |  |  | $ | (2 | ) |  | $ | 1,932 |  |
| Debt securities (including debt funds) | 21,203 |  |  | 253 |  |  | (92 | ) |  | 21,364 |  |
|  | $ | 22,746 |  |  | $ | 644 |  |  | $ | (94 | ) |  | $ | 23,296 |  |
| September 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,769 |  |  | $ | 575 |  |  | $ | (6 | ) |  | $ | 2,338 |  |
| Debt securities (including debt funds) | 19,582 |  |  | 312 |  |  | (60 | ) |  | 19,834 |  |
|  | $ | 21,351 |  |  | $ | 887 |  |  | $ | (66 | ) |  | $ | 22,172 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: title_similarity, score: 0.9091

- changed (2016-01-27):
[0001234452-16-000352:note_history:64]
The following table provides a summary of the Company’s long-term debt (dollar amounts in millions):
  (was, 2015-07-22, similarity 0.9302):
[0001234452-15-000208:note_history:64]
The following table provides a summary of the Company’s long-term debt as of June 28, 2015 (dollar amounts in millions):

- added (2016-01-27):
[0001234452-16-000352:note_history:65]
|  | December 27, 2015 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.70% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 0.98% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.71% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.71% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.14% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (62 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 12 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 9,950 |  |  |  |  | $ | 9,969 |  |  |  |

- removed (2016-01-27):
[0001234452-15-000208:note_history:66]
|  |  | PrincipalAmount |  | EffectiveInterest Rate |
| Floating-rate notes due May 18, 2018 |  | $ | 250 |  |  | 0.61% |
| Floating-rate notes due May 20, 2020 |  | 250 |  |  | 0.88% |
| Fixed-rate 1.40% notes due May 18, 2018 |  | 1,250 |  |  | 0.68% |
| Fixed-rate 2.25% notes due May 20, 2020 |  | 1,750 |  |  | 1.78% |
| Fixed-rate 3.00% notes due May 20, 2022 |  | 2,000 |  |  | 2.28% |
| Fixed-rate 3.45% notes due May 20, 2025 |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 |  | 1,500 |  |  | 4.71% |
| Total principal |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments |  | (22 | ) |  |  |
| Total long-term debt |  | $ | 9,913 |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2016-01-27):
[0001234452-16-000352:note_history:67]
Note 12. Subsequent Event
  (was, 2015-07-22, similarity 0.9583):
[0001234452-15-000208:note_history:67]
Note 12 - Subsequent Event

- added (2016-01-27):
[0001234452-16-000352:note_history:68]
In January 2016, the Company announced that it had reached agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd., to enable delivery of radio frequency front-end (RFFE) modules and RF filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others. The joint venture will initially be owned 51% by the Company and 49% by TDK. Certain intellectual property, patents and filter and module design and manufacturing assets will be carved out of existing TDK businesses and be acquired by the joint venture, with certain assets acquired by the Company. The purchase price of the Company’s interest in the joint venture and the assets to be transferred to the Company is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, the Company has the option to acquire (and TDK has an option to sell) TDK’s interest in the joint venture for $1.15 billion 30 months after the closing date. TDK will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date, which is a substitute for and in lieu of any right of TDK to receive any profit sharing, distributions, dividends or other payments of any kind or nature. The transaction is subject to receipt of regulatory approvals and other closing conditions and is expected to close by early 2017.

- removed (2016-01-27):
[0001234452-15-000208:note_history:69]
On July 22, 2015, the Company announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as the Company works to create sustainable long-term value for stockholders. As part of this, among other actions, the Company is implementing a cost reduction plan to reduce annual costs from fiscal 2015 levels of $7.3 billion (adjusted for variable compensation) by approximately $1.1 billion through a series of targeted reductions across the Company’s businesses, particularly in QCT. The Company also plans to reduce annual share-based compensation grants by approximately $300 million. The Company expects these cost initiatives to be fully implemented by the end of fiscal 2016. In connection with this plan, the Company expects to incur approximately $350 million to $450 million in restructuring and restructuring-related charges, of which approximately $100 million to $200 million are expected to be incurred in the fourth quarter of fiscal 2015. Restructuring and restructuring-related charges include an estimate of severance costs, lease termination costs, acceleration of depreciation, consultancy fees and other costs.
