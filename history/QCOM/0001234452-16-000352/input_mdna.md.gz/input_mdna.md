# QCOM MD&A — 0001234452-16-000352


## mdna

[0001234452-16-000352:mdna:1]
[same as prior period, unchanged from 0001234452-15-000208:mdna:1]

[0001234452-16-000352:mdna:2]
This information should be read in conjunction with the condensed consolidated financial statements and the notes thereto included in Part I, Item 1 of this Quarterly Report and with Management’s Discussion and Analysis of Financial Condition and Results of Operations for the year ended September 27, 2015 contained in our 2015 Annual Report on Form 10-K.

[0001234452-16-000352:mdna:3]
[same as prior period, unchanged from 0001234452-15-000208:mdna:3]

[0001234452-16-000352:mdna:4]
[same as prior period, unchanged from 0001234452-15-000208:mdna:4]

[0001234452-16-000352:mdna:5]
Revenues for the first quarter of fiscal 2016 were $5.8 billion, a decrease of 19% compared to the year ago quarter, with net income attributable to Qualcomm of $1.5 billion, a decrease of 24% compared to the year ago quarter.

[0001234452-16-000352:mdna:6]
| • | We shipped approximately 242 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, a decrease of 10%, compared to approximately 270 million MSM integrated circuits in the year ago quarter. The decline in MSM shipments contributed in part to a 22% decrease in QCT’s revenues as compared to the year ago quarter as QCT continued to be negatively impacted by the effects of a shift in share among our customers within the premium tier, a decline in share at a large customer and the competitive environment in China. |

[0001234452-16-000352:mdna:7]
| • | Total reported device sales were approximately $60.6 billion, an increase of approximately 7%, compared to approximately $56.4 billion in the year ago quarter.(1) However, despite the increase in total reported device sales, QTL’s revenues decreased by 12% compared to the year ago quarter primarily attributable to the deferral of revenue due to an arbitration with LG Electronics, Inc., the effect of underreported royalties by licensees and a decrease in revenues per reported unit. |

[0001234452-16-000352:mdna:8]
| • | We recorded a gain of $380 million in other income upon the completion of the sale of our wireless spectrum in the United Kingdom. |

[0001234452-16-000352:mdna:9]
Against this backdrop, the following recent developments occurred during the first quarter of fiscal 2016 with respect to key elements of our industry:

[0001234452-16-000352:mdna:10]
| • | Worldwide cellular connections grew sequentially by approximately 1% to reach approximately 7.3 billion.(2) |

[0001234452-16-000352:mdna:11]
| • | Worldwide 3G/4G connections (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) grew sequentially by approximately 4% to approximately 3.5 billion, which was approximately 48% of total cellular connections.(2) |

[0001234452-16-000352:mdna:12]
| (1) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). Not all licensees report sales the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report |

[0001234452-16-000352:mdna:13]
such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales for a particular period may include prior period activity that was not reported by the licensee until such particular period.

[0001234452-16-000352:mdna:14]
| (2) | According to GSMA Intelligence estimates as of January 25, 2016 for the quarter ended December 31, 2015. |

[0001234452-16-000352:mdna:15]
[same as prior period, unchanged from 0001234452-15-000208:mdna:16]

[0001234452-16-000352:mdna:16]
[same as prior period, unchanged from 0001234452-15-000208:mdna:17]

[0001234452-16-000352:mdna:17]
[same as prior period, unchanged from 0001234452-15-000208:mdna:18]

[0001234452-16-000352:mdna:18]
QCT is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products are sold and its system software is licensed to manufacturers that use our products in wireless devices, particularly mobile phones, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards, infrastructure equipment, headsets, sound systems and automobiles and in wired devices, particularly broadband gateway equipment, desktop computers and streaming media players. Our MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Qualcomm Snapdragon processors and LTE modems, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon processors provide advanced application and graphics processing capabilities. QCT’s system software enables the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits. QCT revenues comprised 71% and 74% of total consolidated revenues in the first quarter of fiscal 2016 and 2015, respectively.

[0001234452-16-000352:mdna:19]
QCT utilizes a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Integrated circuits are die cut from silicon wafers that have completed the package assembly and test manufacturing processes. We rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits based primarily on our proprietary designs and test programs. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Turnkey is when our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services, such as wafer bump, probe, assembly and final test.

[0001234452-16-000352:mdna:20]
QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD and/or LTE standards and their derivatives. QTL licensing revenues include license fees and royalties based on sales by licensees of products incorporating or using our intellectual property. License fees are fixed amounts paid in one or more installments. Royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). QTL recognizes royalty revenues based on royalties reported by licensees and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. QTL revenues comprised 28% and 26% of total consolidated revenues in the first quarter of fiscal 2016 and 2015, respectively. The vast majority of such revenues were generated through our licensees’ sales of CDMA2000- and WCDMA-based products, such as feature phones and smartphones.

[0001234452-16-000352:mdna:21]
QSI makes strategic investments that are focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice

[0001234452-16-000352:mdna:22]
and data communications. Many of these strategic investments are in early-stage companies in a variety of industries, including, but not limited to, digital media, e-commerce, healthcare and wearable devices. Investments primarily include non-marketable equity instruments, which generally are recorded using the cost method or the equity method, and convertible debt instruments, which are recorded at fair value. QSI also held wireless spectrum, which was sold in October 2015 for a gain of approximately $380 million. In addition, QSI segment results include revenues and related costs associated with development contracts with one of our equity method investees. As part of our strategic investment activities, we intend to pursue various exit strategies for each of our QSI investments in the foreseeable future.

[0001234452-16-000352:mdna:23]
[same as prior period, unchanged from 0001234452-15-000208:mdna:25]

[0001234452-16-000352:mdna:24]
Seasonality. Many of our products or intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has tended historically to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons; and because QTL recognizes royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made during the fourth calendar quarter. We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 3G/4G networks by wireless operators and the timing of launches of flagship wireless devices that incorporate our products and/or intellectual property. These trends may or may not continue in the future.

[0001234452-16-000352:mdna:25]
[same as prior period, unchanged from 0001234452-15-000208:mdna:27]

[0001234452-16-000352:mdna:26]
[same as prior period, unchanged from 0001234452-15-000208:mdna:28]

[0001234452-16-000352:mdna:27]
| • | China continues to present significant opportunities for us, particularly with the rollout of 3G/4G LTE multimode. We expect the rollout of 4G services in China will encourage competition and growth, bring the benefits of 3G/4G LTE multimode to consumers, encourage consumers to replace 2G (GSM) and 3G devices and enable new opportunities beyond mobile applications (e.g., machine-to-machine). |

[0001234452-16-000352:mdna:28]
| • | We expect that the increased availability of low-tier 3G/4G smartphone products will help enable further expansion of 3G and 3G/4G multimode in emerging regions, particularly in China. |

[0001234452-16-000352:mdna:29]
| • | In February 2015, we reached a resolution with the China National Development and Reform Commission (NDRC) regarding its investigation and agreed to implement a rectification plan that modifies certain of our business practices in China. The rectification plan provides, among other things, that for licenses of only our 3G and 4G essential Chinese patents for branded devices sold for use in China starting on January 1, 2015 (and reported to us starting in the third quarter of fiscal 2015), we will charge running royalties at royalty rates of 5% for 3G CDMA or WCDMA devices (including multimode 3G/4G devices) and 3.5% for 4G devices that do not implement CDMA or WCDMA (including 3-mode LTE-TDD devices), in each case using a royalty base of 65% of the net selling price. |

[0001234452-16-000352:mdna:30]
| • | Despite the resolution of the NDRC investigation, China continues to present significant challenges for us. We continue to believe that certain licensees are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes 3G/4G units that we believe are not being reported by certain licensees), and certain companies, including unlicensed companies, are delaying execution of new license agreements. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing. We believe that the conclusion of new agreements with these licensees will result in improved reporting by these licensees, including with respect to sales of three-mode devices (i.e., devices that implement GSM, TD-SCDMA and LTE-TDD) sold in China. However, litigation and/or other actions may be necessary to compel licensees to report and pay the required royalties for sales they have not previously reported and to compel unlicensed companies to execute new licenses. |

[0001234452-16-000352:mdna:31]
| • | Regulatory authorities in other countries continue to investigate our business practices as well, particularly with respect to our licensing business. In addition, LG Electronics, Inc. has commenced an arbitration over certain terms of its license agreement. |

[0001234452-16-000352:mdna:32]
| • | Our business, particularly our semiconductor business, QCT, continues to be impacted by current industry dynamics, including: concentration of device share among companies within the premium tier, which will continue to negatively impact sales of our integrated Snapdragon processors and skew our product mix towards lower-margin modem chipsets in this tier; and intense competition, particularly in China. |

[0001234452-16-000352:mdna:33]
[same as prior period, unchanged from 0001234452-15-000208:mdna:41]

[0001234452-16-000352:mdna:34]
| • | We continue to invest significant resources toward advancements in 3G, 3G/4G multimode and 4G LTE technologies, OFDM-based WLAN technologies, audio and video codecs, wireless baseband chips, our converged computing/communications (Snapdragon) chips, graphics, connectivity, multimedia products, software and services. We are also investing in targeted opportunities that utilize our existing technical and business expertise to deploy new business models and enter into new industry segments, such as products for the connected home and the Internet of Things; automotive; networking; mobile computing; small cells and addressing the challenge of meeting the increased demand for data; very high speed connectivity; data centers; mobile health; wireless charging; and machine learning, including robotics. |

[0001234452-16-000352:mdna:35]
| • | We expect that 3G/4G device prices will continue to vary broadly due to the increased penetration of smartphones combined with competition throughout the world at all price tiers. Additionally, varying rates of economic growth by region and stronger growth of device shipments in emerging regions as compared to developed regions, are expected to continue to impact the average and range of selling prices of 3G/4G devices. |

[0001234452-16-000352:mdna:36]
| • | In the fourth quarter of fiscal 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders. As part of this Strategic Realignment Plan, among other actions, we are implementing a cost reduction plan and plan to reduce our annual costs from fiscal 2015 levels (adjusted for variable compensation) of $7.3 billion (as announced on July 22, 2015) by approximately $1.1 billion through a series of targeted reductions across Qualcomm’s businesses, particularly in QCT. We are also planning to reduce annual share-based compensation grants by approximately $300 million. We expect these cost reduction initiatives to be substantially implemented by the end of fiscal 2016. Restructuring activities were initiated in the fourth quarter of fiscal 2015, and a total of $196 million in net restructuring and restructuring-related charges were incurred through the first quarter of fiscal 2016. We expect to incur additional restructuring and restructuring-related charges of approximately $100 million to $200 million. |

[0001234452-16-000352:mdna:37]
| • | In January 2016, we announced that we had reached an agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd., to enable delivery of radio frequency front-end (RFFE) modules and RF filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others. The joint venture will initially be owned 51% by us and 49% by TDK. Certain intellectual property, patents and filter and module design and manufacturing assets will be carved out of existing TDK businesses and be acquired by the joint venture, with certain assets acquired by us. The purchase price of our interest in the joint venture and the assets to be transferred to us is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, we have the option to acquire (and TDK has an option to sell) TDK’s interest in the joint venture for $1.15 billion 30 months after the closing date. TDK will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date, which is a substitute for and in lieu of any right of TDK to receive any profit sharing, distributions, dividends or other payments of any kind or nature. The transaction is subject to receipt of regulatory approvals and other closing conditions and is expected to close by early 2017. |

[0001234452-16-000352:mdna:38]
[same as prior period, unchanged from 0001234452-15-000208:mdna:42]

[0001234452-16-000352:mdna:39]
[same as prior period, unchanged from 0001234452-15-000208:mdna:43]

[0001234452-16-000352:mdna:40]
[same as prior period, unchanged from 0001234452-15-000208:mdna:44]

[0001234452-16-000352:mdna:41]
| Revenues (in millions) |
|  | Three Months Ended |
|  | December 27, 2015 |  | December 28, 2014 |  | Change |
| Equipment and services | $ | 4,087 |  |  | $ | 5,216 |  |  | $ | (1,129 | ) |
| Licensing | 1,688 |  |  | 1,883 |  |  | (195 | ) |
|  | $ | 5,775 |  |  | $ | 7,099 |  |  | $ | (1,324 | ) |

[0001234452-16-000352:mdna:42]
The decrease in equipment and services revenues was primarily due to a decrease in QCT revenues of $1.16 billion. The decrease in licensing revenues was primarily due to a decrease in QTL revenues of $209 million.

[0001234452-16-000352:mdna:43]
| Costs and Expenses (in millions) |
|  | Three Months Ended |
|  | December 27, 2015 |  | December 28, 2014 |  | Change |
| Cost of equipment and services (E&S) revenues | $ | 2,534 |  |  | $ | 3,047 |  |  | $ | (513 | ) |
| Cost as % of E&S revenues | 62 | % |  | 58 | % |  |  |

[0001234452-16-000352:mdna:44]
The decrease in margin percentage was driven primarily by the effect of $74 million in additional charges related to the recognition of the step-up of inventories to fair value and amortization of intangible assets during the first quarter of fiscal 2016, primarily related to the acquisition of CSR plc in the fourth quarter of fiscal 2015, and a decrease in QCT margin percentage. Our margin percentage may fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors.

[0001234452-16-000352:mdna:45]
|  | Three Months Ended |
|  | December 27, 2015 |  | December 28, 2014 |  | Change |
| Research and development | $ | 1,352 |  |  | $ | 1,352 |  |  | $ | — |  |
| % of revenues | 23 | % |  | 19 | % |  |  |
| Selling, general, and administrative | $ | 578 |  |  | $ | 583 |  |  | $ | (5 | ) |
| % of revenues | 10 | % |  | 8 | % |  |  |
| Other | $ | (374 | ) |  | $ | 53 |  |  | $ | (427 | ) |

[0001234452-16-000352:mdna:46]
Research and development expenses remained flat in the first quarter of fiscal 2016. Research and development expenses included an increase of $26 million in costs related to the development of CDMA-based 3G, OFDMA-based 4G LTE and other technologies for integrated circuit and related software products, particularly data center products, and to expand our intellectual property portfolio, which was partially offset by a decrease of $16 million related to the development costs of display technologies.

[0001234452-16-000352:mdna:47]
The dollar decrease in selling, general and administrative expenses was primarily attributable to decreases of $15 million in employee-related expenses and $15 million in share-based compensation expenses, partially offset by an increase of $17 million in selling and marketing expenses.

[0001234452-16-000352:mdna:48]
Other income in the first quarter of fiscal 2016 was primarily attributable to a $380 million gain on the sale of wireless spectrum. Other income in the first quarter of fiscal 2016 also included $54 million in restructuring and restructuring-related charges, partially offset by a $48 million gain on the sale of our business that provided augmented reality applications, both of which related to our Strategic Realignment Plan.

[0001234452-16-000352:mdna:49]
Other expenses in the first quarter of fiscal 2015 were comprised of a $69 million goodwill impairment charge related to our business that provides push-to-talk enablement services, partially offset by a $16 million gain on the sale of certain property, plant and equipment.

[0001234452-16-000352:mdna:50]
[same as prior period, unchanged from 0001234452-15-000208:mdna:56]

[0001234452-16-000352:mdna:51]
| Interest Expense and Net Investment Income (in millions) |
|  | Three Months Ended |
|  | December 27, 2015 |  | December 28, 2014 |  | Change |
| Interest expense | $ | 74 |  |  | $ | 1 |  |  | $ | 73 |  |
| Investment income, net |  |  |  |  |  |
| Interest and dividend income | $ | 136 |  |  | $ | 134 |  |  | $ | 2 |  |
| Net realized gains on marketable securities | 43 |  |  | 156 |  |  | (113 | ) |
| Net realized gains on other investments | 6 |  |  | 10 |  |  | (4 | ) |
| Impairment losses on marketable securities and other investments | (63 | ) |  | (65 | ) |  | 2 |  |
| Equity in net losses of investees | (20 | ) |  | (4 | ) |  | (16 | ) |
| Net (losses) gains on derivative instruments | (3 | ) |  | 4 |  |  | (7 | ) |
|  | $ | 99 |  |  | $ | 235 |  |  | $ | (136 | ) |

[0001234452-16-000352:mdna:52]
The increase in interest expense was primarily due to the issuance of an aggregate principal amount of $10.0 billion in floating- and fixed-rate notes in May 2015. The decrease in net realized gains on marketable securities was primarily due to the decreased impact of portfolio rebalancing in the first quarter of fiscal 2016.

[0001234452-16-000352:mdna:53]
| Income Tax Expense (in millions) |
|  | Three Months Ended |
|  | December 27, 2015 |  | December 28, 2014 |  | Change |
| Income tax expense | $ | 214 |  |  | $ | 327 |  |  | $ | (113 | ) |
| Effective tax rate | 13 | % |  | 14 | % |  | (1 | %) |

[0001234452-16-000352:mdna:54]
The following table summarizes the primary factors that caused our effective tax rates for the first quarter of fiscal 2016 and 2015 to be less than the United States federal statutory rate:

[0001234452-16-000352:mdna:55]
|  | Three Months Ended |
|  | December 27, 2015 |  | December 28, 2014 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (17 | %) |  | (16 | %) |
| Benefits related to the research and development tax credit | (6 | %) |  | (5 | %) |
| Other | 1 | % |  | — |  |
| Effective tax rate | 13 | % |  | 14 | % |

[0001234452-16-000352:mdna:56]
The effective tax rate of 13% for the first quarter of fiscal 2016 was less than the estimated annual effective tax rate of 17% primarily as a result of the retroactive reinstatement of the United States federal research and development tax credit, which was permanently reinstated during the first quarter of fiscal 2016 retroactively to January 1, 2015. As a result of the reinstatement, we recorded a tax benefit of $79 million in the first quarter of fiscal 2016 related to fiscal 2015. The annual effective tax rate of 19% for fiscal 2015 reflected the United States federal research and development tax credit generated through December 31, 2014, the date on which the credit previously expired. Unrecognized tax benefits were $113 million and $40 million at December 27, 2015 and September 27, 2015, respectively. Certain of our existing tax positions are expected to continue to generate an increase in unrecognized tax benefits through fiscal 2016.

[0001234452-16-000352:mdna:57]
[same as prior period, unchanged from 0001234452-15-000208:mdna:62]

[0001234452-16-000352:mdna:58]
The following should be read in conjunction with the first quarter financial results of fiscal 2016 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0001234452-16-000352:mdna:59]
| (in millions) | QCT |  | QTL |  | QSI |
| Three Months Ended December 27, 2015 |  |  |  |  |  |
| Revenues | $ | 4,096 |  |  | $ | 1,607 |  |  | $ | 9 |  |
| EBT (1) | 590 |  |  | 1,339 |  |  | 359 |  |
| EBT as a % of revenues | 14 | % |  | 83 | % |  |  |  |
| Three Months Ended December 28, 2014 |  |  |  |  |  |
| Revenues | $ | 5,242 |  |  | $ | 1,816 |  |  | $ | — |  |
| EBT (1) | 1,146 |  |  | 1,579 |  |  | (1 | ) |
| EBT as a % of revenues | 22 | % |  | 87 | % |  |  |

[0001234452-16-000352:mdna:60]
[same as prior period, unchanged from 0001234452-15-000208:mdna:65]

[0001234452-16-000352:mdna:61]
QCT Segment. QCT results of operations in the first quarter of fiscal 2016 continued to be negatively impacted by the effects of a shift in share among our customers within the premium tier, which reduced our sales of integrated Snapdragon processors and skewed our product mix towards lower-margin modem chipsets in this tier, a decline in share at a large customer and the competitive environment in China. The decrease in QCT revenues of $1.15 billion was primarily due to a decrease in equipment and services revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying Radio Frequency (RF) and Power Management (PM) integrated circuits, were $4.02 billion and $5.19 billion in the first quarter of fiscal 2016 and 2015, respectively. The decrease in equipment and services revenues resulted primarily from decreases of $848 million from lower average selling prices and lower-priced product mix and $453 million related to lower MSM and accompanying RF and PM unit shipments, partially offset by a $152 million net increase in revenues related to other products (primarily resulting from the acquisition of CSR in the fourth quarter of fiscal 2015). Approximately 242 million and 270 million MSM integrated circuits were sold during the first quarter of fiscal 2016 and 2015, respectively.

[0001234452-16-000352:mdna:62]
QCT EBT as a percentage of revenues decreased primarily due to the impact of lower revenues relative to operating expenses and a decrease in gross margin percentage. The decrease in QCT gross margin percentage primarily resulted from lower average selling prices and lower-margin product mix, partially offset by lower average unit costs and lower excess inventory charges.

[0001234452-16-000352:mdna:63]
QTL Segment. The decrease in QTL revenues of $209 million was primarily attributable to the deferral of revenue due to an arbitration with LG Electronics, Inc., the effect of underreported royalties by licensees and a decrease in revenues per reported unit, partially offset by an increase in sales of CDMA-based products, including multimode products that also implement OFDMA, reported by licensees. QTL revenues and EBT for the first quarter of fiscal 2016 were impacted negatively by units that we believe are not being reported by certain licensees and sales of certain unlicensed products. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing, and litigation may become necessary if negotiations fail to resolve the relevant issues.

[0001234452-16-000352:mdna:64]
QSI Segment. The increase in QSI EBT was primarily due to a $380 million gain on the sale of wireless spectrum in the first quarter of fiscal 2016, partially offset by increases of $16 million in equity in losses of investees and $10 million in impairment losses on investments. The sale of the wireless spectrum included $275 million in deferred payments due in 2020 to 2023, which were recorded at their present values in other assets.

[0001234452-16-000352:mdna:65]
[same as prior period, unchanged from 0001234452-15-000208:mdna:71]

[0001234452-16-000352:mdna:66]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. The following tables present selected financial information related to our liquidity as of December 27, 2015 and September 27, 2015 and for the first quarter of fiscal 2016 and 2015 (in millions):

[0001234452-16-000352:mdna:67]
|  | December 27, 2015 |  | September 27, 2015 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 30,591 |  |  | $ | 30,947 |  |  | $ | (356 | ) |  | (1 | %) |
| Accounts receivable, net | 1,323 |  |  | 1,964 |  |  | (641 | ) |  | (33 | %) |
| Inventories | 1,216 |  |  | 1,492 |  |  | (276 | ) |  | (18 | %) |
| Short-term debt | 1,000 |  |  | 1,000 |  |  | — |  |  | — | % |
| Long-term debt | 9,950 |  |  | 9,969 |  |  | (19 | ) |  | — | % |

[0001234452-16-000352:mdna:68]
[same as prior period, unchanged from 0001234452-15-000208:mdna:74]

[0001234452-16-000352:mdna:69]
|  | Three Months Ended |  |  |  |  |
|  | December 27, 2015 |  | December 28, 2014 |  | $ Change |  | % Change |
| Net cash provided by operating activities | $ | 2,739 |  |  | $ | 2,364 |  |  | $ | 375 |  |  | 16 | % |
| Net cash used by investing activities | (716 | ) |  | (1,736 | ) |  | 1,020 |  |  | (59 | %) |
| Net cash used by financing activities | (2,665 | ) |  | (2,203 | ) |  | (462 | ) |  | 21 | % |

[0001234452-16-000352:mdna:70]
The net decrease in cash, cash equivalents and marketable securities was primarily the result of $2.05 billion in payments to repurchase shares of our common stock, partially offset by net cash provided by operating activities. Total cash provided by operating activities increased primarily due to changes in working capital related to accounts receivable and inventories, partially offset by a reduction in net income of $475 million. Our days sales outstanding, on a consolidated basis, decreased to 21 days at December 27, 2015 compared to 33 days at September 27, 2015. The decreases in accounts receivable and the related days sales outstanding were primarily due to the timing of integrated circuit shipments and the collection of payments from certain of our licensees. The decrease in inventories was primarily due to a decrease in QCT work-in-process and finished goods related to lower units on hand to align with near-term demand and recognition of the step-up in the fair value of the acquired inventories from the CSR acquisition.

[0001234452-16-000352:mdna:71]
We classify certain of our marketable securities as short-term based on their nature and our plan to make them available, if needed, for use in our current operations. While we do not anticipate using our non-current marketable securities in operations in the foreseeable future, the securities could be liquidated within a short period of time if required. Our cash, cash equivalents and marketable securities at December 27, 2015 consisted of $2.7 billion held by United States-based entities and $27.9 billion held by foreign entities. Most of our cash, cash equivalents and marketable securities held by foreign entities are indefinitely reinvested and would be subject to material tax effects if repatriated. However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate funds held by foreign entities.

[0001234452-16-000352:mdna:72]
We believe our current cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements also include the items described below.

[0001234452-16-000352:mdna:73]
| • | We expect the majority of the charges incurred in connection with our Strategic Realignment Plan will result in cash payment. Our restructuring accrual was $145 million at December 27, 2015, and we expect to incur additional restructuring and restructuring-related charges of approximately $100 million to $200 million. |

[0001234452-16-000352:mdna:74]
| • | Our purchase obligations at December 27, 2015, some of which relate to research and development activities and capital expenditures, totaled $3.2 billion and $891 million for fiscal 2016 and 2017, respectively, and $1.7 billion thereafter. |

[0001234452-16-000352:mdna:75]
| • | Our research and development expenditures were $1.4 billion during the first quarter of fiscal 2016 and $5.5 billion in fiscal 2015, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications, primarily in the wireless industry. |

[0001234452-16-000352:mdna:76]
| • | Cash outflows for capital expenditures were $128 million during the first quarter of fiscal 2016 and $994 million during fiscal 2015. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-16-000352:mdna:77]
| • | In January 2016, we announced that we had reached agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd. The joint venture will initially be owned 51% by us and 49% by TDK. The purchase price due upon close of the transaction is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, we have the option to acquire (and TDK has an option to sell) TDK’s interest in the joint venture for $1.15 billion 30 months after the closing date. We expect to use existing cash resources to fund the acquisition. TDK will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date. The transaction is subject to regulatory approvals and other closing conditions and is expected to close by early 2017. |

[0001234452-16-000352:mdna:78]
[same as prior period, unchanged from 0001234452-15-000208:mdna:83]

[0001234452-16-000352:mdna:79]
Debt. We have a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. At December 27, 2015, no amounts were outstanding under the Revolving Credit Facility.

[0001234452-16-000352:mdna:80]
We have an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At December 27, 2015, we had $1.0 billion of commercial paper outstanding with weighted-average net interest rates of 0.25% and weighted-average remaining days to maturity of 30 days.

[0001234452-16-000352:mdna:81]
We have issued unsecured floating- and fixed-rate notes in an aggregate principal amount of $10.0 billion, with maturity dates in 2018 through 2045 and effective interest rates between 0.70% and 4.74%. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. We may issue additional debt in the future. The amount and timing of additional borrowings will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001234452-16-000352:mdna:82]
Additional information regarding our outstanding debt at December 27, 2015 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt.”

[0001234452-16-000352:mdna:83]
Capital Return Program. During the first quarter of fiscal 2016, we repurchased and retired 36,606,000 shares of our common stock for $2.05 billion, before commissions. We intend to return a minimum of 75% of our free cash flow to stockholders through stock repurchases and dividends over the foreseeable future, where free cash flow is defined as net cash provided by operating activities less capital expenditures. On March 9, 2015, we announced that we had been authorized to repurchase up to $15 billion of our common stock. Additionally, we announced our intention to repurchase $10 billion of stock from March 2015 through March 2016, which we completed during the first quarter of fiscal 2016. At December 27, 2015, $4.9 billion remained authorized for repurchase under our stock repurchase program. To meet our goal, we expect to use existing cash and marketable securities held by, and cash flow generated from, United States-based entities and borrowings. We periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders.

[0001234452-16-000352:mdna:84]
We paid cash dividends totaling $717 million, or $0.48 per share, on December 18, 2015. On January 12, 2016, we announced a cash dividend of $0.48 per share on our common stock, payable on March 23, 2016 to stockholders of record as of the close of business on March 2, 2016. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-16-000352:mdna:85]
[same as prior period, unchanged from 0001234452-15-000208:mdna:93]

[0001234452-16-000352:mdna:86]
We have no significant contractual obligations not fully recorded on our consolidated balance sheets or fully disclosed in the notes to our consolidated financial statements. We have no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001234452-16-000352:mdna:87]
Additional information regarding our financial commitments at December 27, 2015 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes,” “Note 5. Debt” and “Note 6. Commitments and Contingencies.”

[0001234452-16-000352:mdna:88]
[same as prior period, unchanged from 0001234452-15-000208:mdna:96]

[0001234452-16-000352:mdna:89]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The new standard will be effective for us starting in the first quarter of fiscal 2019. The FASB will permit entities to adopt one year earlier if they choose. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. We do not intend to adopt the standard early and are in the process of determining the adoption method as well as the effects the adoption will have on our consolidated financial statements.

[0001234452-16-000352:mdna:90]
In November 2015, the FASB issued ASU No. 2015-17, “Balance Sheet Classification of Deferred Taxes,” which requires all deferred tax assets and liabilities to be classified as noncurrent on the balance sheet. The new accounting

[0001234452-16-000352:mdna:91]
guidance is effective for annual reporting periods beginning after December 15, 2016 and interim periods therein. Early adoption is permitted as of the beginning of interim or annual reporting periods. We plan to adopt the standard prospectively in the second quarter of fiscal 2016.

[0001234452-16-000352:mdna:92]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments-Overall: Recognition and Measurement of Financial Assets and Financial Liabilities,” which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk will be recognized separately in other comprehensive income. Additionally, the ASU changes the disclosure requirements for financial instruments. The new standard will be effective for us starting in the first quarter of fiscal 2019. Early adoption is permitted for certain provisions. We are in the process of determining the effects the adoption will have on our consolidated financial statements as well as whether to adopt certain provisions early.

[0001234452-16-000352:mdna:93]
[same as prior period, unchanged from 0001234452-15-000208:mdna:98]

[0001234452-16-000352:mdna:94]
You should consider each of the following factors as well as the other information in this Quarterly Report in evaluating our business and our prospects. The risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also impair our business operations. If any of these risks occur, our business and financial results could be harmed. In that case, the trading price of our common stock could decline. You should also refer to the other information set forth in this Quarterly Report and in our Annual Report on Form 10-K for the fiscal year ended September 27, 2015, including our financial statements and the related notes.

[0001234452-16-000352:mdna:95]
[same as prior period, unchanged from 0001234452-15-000208:mdna:100]

[0001234452-16-000352:mdna:96]
Our revenues depend on commercial network deployments, expansions and upgrades of CDMA, OFDMA and other communications technologies, our customers’ and licensees’ sales of products and services based on these technologies and our ability to drive our customers’ demand for our products and services.

[0001234452-16-000352:mdna:97]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on our customers, our licensees and operators of wireless networks to use these technologies in their adoption of our products and services into their devices and networks and on the timing of their deployments of new products and services. We also depend on our customers and licensees to develop products and services with value-added features to drive consumer demand for new 3G, 3G/4G multimode and 4G devices, as well as the selling prices for such devices. Further, our rate of revenue growth depends on third parties incorporating our technology, products and/or services into new device types used in industries beyond traditional cellular communications, such as automotive, connected home and wearable uses. Our revenues and/or growth in revenues could be negatively impacted, our business may be harmed and our substantial investments in these technologies may not provide us an adequate return, if:

[0001234452-16-000352:mdna:98]
[same as prior period, unchanged from 0001234452-15-000208:mdna:103]

[0001234452-16-000352:mdna:99]
[same as prior period, unchanged from 0001234452-15-000208:mdna:104]

[0001234452-16-000352:mdna:100]
[same as prior period, unchanged from 0001234452-15-000208:mdna:105]

[0001234452-16-000352:mdna:101]
[same as prior period, unchanged from 0001234452-15-000208:mdna:106]

[0001234452-16-000352:mdna:102]
[same as prior period, unchanged from 0001234452-15-000208:mdna:107]

[0001234452-16-000352:mdna:103]
| • | our customers’ and licensees’ revenues and sales of products, particularly premium-tier products, and services using these technologies do not grow or do not grow as quickly as anticipated due to, for example, the maturity of smartphone penetration in developed regions (where premium-tier products are common) or a reduction in the rate of device replacements by consumers; and/or |

[0001234452-16-000352:mdna:104]
[same as prior period, unchanged from 0001234452-15-000208:mdna:109]

[0001234452-16-000352:mdna:105]
Our industry is subject to competition in an environment of rapid technological change that could result in decreased demand and/or declining average selling prices for our products and/or those of our customers and/or licensees and/or result in placing new specifications or requirements on our products, each of which could negatively affect our revenues and operating results.

[0001234452-16-000352:mdna:106]
Our products, services and technologies face significant competition, and the revenues we generate and/or the timing of such revenues, which depend on deployments and/or actions by others, may not meet expectations. We expect competition to increase as our current competitors expand their product offerings or reduce the prices of their products as part of a strategy to attract new business and/or customers, and as new opportunities develop, any of which would put continued pressure on the pricing of our products and services. Competition in wireless communications is affected by various factors that include, among others: device manufacturer concentrations; growth in emerging geographic regions; government intervention; evolving industry standards and business models; evolving methods of transmission of voice and data communications; increasing data traffic and densification of wireless networks; convergence and aggregation of connectivity technologies (including Wi-Fi and LTE) in both devices and access points; consolidation of wireless technologies and infrastructure at the network edge; networking and connectivity trends (including cloud services); the evolving nature of computing (including demand for always on, always connected capabilities); the speed of technological change (including the transition to smaller geometry process technologies); value-added features that drive selling prices as well as consumer demand for new 3G, 3G/4G multimode and 4G devices; turnkey, integrated products that incorporate hardware, software, user interface, applications and reference designs; rapid growth in mobile data consumption; scalability; and the ability of the system technology to meet customers’ immediate and future network requirements. We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, technological and public policy changes and relatively low barriers to entry in certain segments of the industry. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape.

[0001234452-16-000352:mdna:107]
We expect that our future success will depend on, among other factors, our ability to:

[0001234452-16-000352:mdna:108]
[same as prior period, unchanged from 0001234452-15-000208:mdna:113]

[0001234452-16-000352:mdna:109]
[same as prior period, unchanged from 0001234452-15-000208:mdna:114]

[0001234452-16-000352:mdna:110]
| • | continue to drive the adoption of our integrated circuit products into the most popular device models and across a broad spectrum of devices, such as smartphones, tablets, automobiles, wearable and other connected devices and infrastructure products; |

[0001234452-16-000352:mdna:111]
[same as prior period, unchanged from 0001234452-15-000208:mdna:116]

[0001234452-16-000352:mdna:112]
| • | continue to be a leader in 4G technology evolution, including expansion of our LTE-based single mode licensing program, and continue to innovate and introduce 4G turnkey, integrated products and services that differentiate us from our competition; |

[0001234452-16-000352:mdna:113]
[same as prior period, unchanged from 0001234452-15-000208:mdna:118]

[0001234452-16-000352:mdna:114]
[same as prior period, unchanged from 0001234452-15-000208:mdna:119]

[0001234452-16-000352:mdna:115]
[same as prior period, unchanged from 0001234452-15-000208:mdna:120]

[0001234452-16-000352:mdna:116]
[same as prior period, unchanged from 0001234452-15-000208:mdna:123]

[0001234452-16-000352:mdna:117]
| • | create stand-alone value and/or contribute to the success of our existing businesses through acquisitions and other transactions (and/or by developing customer, licensee and/or vendor relationships) in new industry segments and/or disruptive technologies, products and/or services (such as products for the connected home and the Internet of Things, automotive, networking, mobile computing, mobile health, machine learning, including robotics, and wireless charging, among others); |

[0001234452-16-000352:mdna:118]
[same as prior period, unchanged from 0001234452-15-000208:mdna:122]

[0001234452-16-000352:mdna:119]
| • | become a leading supplier of radio frequency front end products, which are designed to address cellular radio frequency band fragmentation while improving radio frequency performance and assist original equipment manufacturers in developing multiband, multimode mobile devices; and/or |

[0001234452-16-000352:mdna:120]
[same as prior period, unchanged from 0001234452-15-000208:mdna:125]

[0001234452-16-000352:mdna:121]
Competition in any or all product tiers, customer concentration and/or growth in sales of mid- and low-tier products, particularly relative to premium-tier products, may reduce average selling prices for our chipset products and/or the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging geographic regions (e.g., China). Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0001234452-16-000352:mdna:122]
Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM) as well as companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Airoha Technology Corp., Avago Technologies Ltd., Broadcom, Ericsson, HiSilicon Technologies, Intel, Leadcore Technology Co., Ltd., Marvell Technology, Maxim Integrated Products, MediaTek, Microchip Technology Inc., Nvidia, Qorvo Inc., Realtek Semiconductor, Samsung Electronics, Skyworks Solutions Inc. and Spreadtrum Communications (which is controlled by Tsinghua Unigroup). Some of these current and potential competitors may have advantages over us that include, among others: lower cost structures; motivation by our customers in certain circumstances to utilize their own internally-developed integrated circuit products or to find alternate suppliers or choose alternative technologies; foreign government support of other technologies or competitors; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and original equipment manufacturers in emerging geographic regions (such as China); and/or a more established presence in certain regions.

[0001234452-16-000352:mdna:123]
[same as prior period, unchanged from 0001234452-15-000208:mdna:128]

[0001234452-16-000352:mdna:124]
[same as prior period, unchanged from 0001234452-15-000208:mdna:129]

[0001234452-16-000352:mdna:125]
Our QCT segment derives a significant portion of revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience an increasing concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. In addition, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past chosen, and may in the future choose, to utilize in their devices rather than our integrated circuit products (and/or sell their integrated circuit products to third parties in competition with us). The loss of any one of our significant customers, a reduction in the purchases of our products by such customers (due to the use of their own integrated circuit products or otherwise) or cancellation of significant purchases from any of these customers would reduce our revenues and could harm our ability to achieve or sustain expected operating results, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Further, concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and

[0001234452-16-000352:mdna:126]
[same as prior period, unchanged from 0001234452-15-000208:mdna:131]

[0001234452-16-000352:mdna:127]
margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have little or no control, and the timing of such introductions may cause our operating results to fluctuate. Accordingly, if current industry dynamics and concentrations continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases and the timing and size of any such future purchases by these significant customers.

[0001234452-16-000352:mdna:128]
In addition, one of our largest customers purchases our Mobile Data Modem (MDM) products, which do not include our integrated application processor technology. To the extent such customer takes device share from our other customers who purchase our integrated modem and application processor products, which have higher revenue and margin contribution than our MDM products, our revenues and margins may be negatively impacted.

[0001234452-16-000352:mdna:129]
[same as prior period, unchanged from 0001234452-15-000208:mdna:133]

[0001234452-16-000352:mdna:130]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products and/or intellectual property or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001234452-16-000352:mdna:131]
Although we have more than 295 CDMA-based licensees, our QTL segment derives a significant portion of licensing revenues from a limited number of licensees. In the event that one or more of our significant licensees fail to meet their reporting and/or payment requirements or we are unable to renew or modify one or more of such license agreements, our revenues, operating results and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have little or no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our major licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues.

[0001234452-16-000352:mdna:132]
[same as prior period, unchanged from 0001234452-15-000208:mdna:142]

[0001234452-16-000352:mdna:133]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, or some form of unfair competition; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the imposition of some form of compulsory licensing and/or to weaken a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies to attempt to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated. In addition, certain licensees have disputed or underreported royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into license agreements with us for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future. Further, to the extent such licensees and/or companies increase their device share, the negative impact of their underreporting and/or non-reporting on our business and operating results will be exacerbated.

[0001234452-16-000352:mdna:134]
We are currently subject to various litigation and governmental investigations and/or proceedings, some of which may arise out of the strategies described above. Certain legal matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or modify our business practices.

[0001234452-16-000352:mdna:135]
[same as prior period, unchanged from 0001234452-15-000208:mdna:145]

[0001234452-16-000352:mdna:136]
Further, some companies or entities have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions not be an available remedy for infringement of standard-essential patents and/or have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by severely limiting the base upon which the royalty percentage may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (and/or other companies’) alleged failure to abide by these policies.

[0001234452-16-000352:mdna:137]
Some SDOs, courts and governmental agencies have adopted and may in the future adopt some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001234452-16-000352:mdna:138]
We expect that such proposals, interpretations and strategies will continue in the future, and if successful, our business model would be harmed, either by limiting or eliminating our ability to collect royalties (or by reducing the royalties we can collect) on all or a portion of our patent portfolio, limiting our return on investment with respect to new technologies, limiting our ability to seek injunctions against infringers of our standard-essential patents, constraining our ability to make licensing commitments when submitting our technology for inclusion in future standards (which could make our technology less likely to be included in such standards) or forcing us to work outside of SDOs or other industry groups to promote our new technologies, and our results of operations could be negatively impacted. In addition, the legal and other costs associated with asserting or defending our positions have been and continue to be significant. We assume that such challenges, regardless of their merits, will continue into the foreseeable future and may require the investment of substantial management time and financial resources.

[0001234452-16-000352:mdna:139]
[same as prior period, unchanged from 0001234452-15-000208:mdna:150]

[0001234452-16-000352:mdna:140]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our proprietary information, technologies and processes, including our patent portfolio. Policing unauthorized use of our products, technologies and proprietary information is difficult and time consuming. We cannot be certain that the steps we have taken, or may take in the future, have prevented or will prevent the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as United States laws or where the enforcement of such laws may be lacking or ineffective. Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that the European Union will adopt a unitary patent system in the next few years that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technology.

[0001234452-16-000352:mdna:141]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property rights and/or contracts, including collecting royalties for use of our patent portfolio in particular foreign jurisdictions due to, among others: policies of foreign governments; challenges to our licensing practices under such jurisdictions’ competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated

[0001234452-16-000352:mdna:142]
royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and/or challenges pending before foreign competition agencies to the pricing and integration of additional features and functionality into our chipset products. Certain licensees have disputed or underreported royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into license agreements for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements.

[0001234452-16-000352:mdna:143]
We may need to litigate to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements and/or initiating litigation) and/or we could incur substantial unexpected operating costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our operating results. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues in the period prior to conclusion.

[0001234452-16-000352:mdna:144]
[same as prior period, unchanged from 0001234452-15-000208:mdna:136]

[0001234452-16-000352:mdna:145]
Although we own a very strong portfolio of issued and pending patents related to GSM, GPRS, EDGE, OFDM, OFDMA, WLAN, MIMO and other technologies, our patent portfolio licensing program in these areas is less established and might not be as successful in generating licensing revenues as our CDMA licensing program has been. Many wireless operators are investigating, have selected or have deployed OFDMA-based LTE as their next-generation 4G technology in existing (or future if not yet deployed) wireless spectrum bands as complementary to their existing CDMA-based networks. While 3G/4G multimode products are generally covered by our existing 3G licensing agreements, products that implement 4G but do not also implement 3G are generally not covered by these agreements. Although we believe that our patented technology is essential and useful to implementation of the LTE industry standards and have granted royalty-bearing licenses to more than 170 companies (including Alcatel-Lucent, Huawei, LG, Microsoft, Samsung, Sony Mobile and ZTE) that have realized that they need a license to our patents to make and sell products implementing 4G standards but not implementing 3G standards, it may be difficult to agree on material terms and/or conditions of new license agreements that are acceptable to us with companies that are currently unlicensed, particularly in China. Further, the royalty rates for single mode 4G products are generally lower than our royalty rates for 3G and 3G/4G multimode products have been, and therefore, we might not achieve the same licensing revenues on such LTE products as on 3G and 3G/4G multimode products. In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the connected home or the Internet of Things. We also seek to diversify and broaden our technology licensing programs to new industry segments in which we can utilize our technology leadership, such as wireless charging and other technologies. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties that are equivalent to those that we receive for 3G and 3G/4G multimode products used in cellular communications. Although we believe that our patented technology is essential and useful to the commercialization of such services, the royalties we receive may be lower than those we receive from our current licensing program.

[0001234452-16-000352:mdna:146]
[same as prior period, unchanged from 0001234452-15-000208:mdna:140]

[0001234452-16-000352:mdna:147]
The licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date and, in a small number of agreements, royalties are payable on those patents for a specified time period. As a result, there are agreements with some licensees where later patents are not licensed by or to us and/or royalties are not owed to us under such license agreements after the specified time period. Additionally, certain license agreements are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of a specified term, or to receive royalties after the specified time period, we will need to extend or modify such license

[0001234452-16-000352:mdna:148]
[same as prior period, unchanged from 0001234452-15-000208:mdna:153]

[0001234452-16-000352:mdna:149]
agreements or enter into new license agreements with such licensees. We might not be able to modify those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in renewing a license agreement prior to its expiration, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001234452-16-000352:mdna:150]
[same as prior period, unchanged from 0001234452-15-000208:mdna:156]

[0001234452-16-000352:mdna:151]
Our business, products and services, and those of our customers and licensees, are subject to various laws and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies. The adoption of new laws, regulations or policies, changes in the interpretation of existing laws, regulations or policies, changes in the regulation of our activities by a government or standards body and/or adverse rulings in court, regulatory, administrative or other proceedings relating to such laws, regulations or policies, including, among others, those affecting licensing practices, competitive business practices, the use of our technology or products, protection of intellectual property, trade, foreign investments or loans, spectrum availability and license issuance, adoption of standards, the provision of device subsidies by wireless operators to their customers, taxation, privacy and data protection, environmental protection or employment, could have an adverse effect on our business.

[0001234452-16-000352:mdna:152]
We are currently subject to various governmental investigations and/or proceedings, and certain matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices.

[0001234452-16-000352:mdna:153]
[same as prior period, unchanged from 0001234452-15-000208:mdna:159]

[0001234452-16-000352:mdna:154]
[same as prior period, unchanged from 0001234452-15-000208:mdna:160]

[0001234452-16-000352:mdna:155]
Regulations in the United States require that we determine whether certain materials used in our products, referred to as conflict minerals, originated in the Democratic Republic of the Congo (DRC) or an adjoining country, or were from recycled or scrap sources. The verification and reporting requirements, in addition to customer demands for conflict free sourcing, impose additional costs on us and on our suppliers and may limit the sources or increase the prices of materials used in our products. Further, if we are unable to determine that our products are “DRC conflict free,” we may face challenges with our customers that place us at a competitive disadvantage, and our reputation may be harmed.

[0001234452-16-000352:mdna:156]
[same as prior period, unchanged from 0001234452-15-000208:mdna:162]

[0001234452-16-000352:mdna:157]
[same as prior period, unchanged from 0001234452-15-000208:mdna:163]

[0001234452-16-000352:mdna:158]
Our industry is subject to rapid technological change, evolving industry standards and frequent new product introductions, and we must make substantial research, development and other investments, such as acquisitions, in new products, services and technologies to compete successfully. Technological innovations generally require significant research and development efforts before they are commercially viable. Our future growth significantly depends on third parties incorporating our technology, products and/or services into new device types used in industries beyond traditional cellular communications, such as automotive, connected home and wearable uses. Accordingly, we intend to continue to make substantial investments in developing new products, services and technologies that we believe can create stand-alone value

[0001234452-16-000352:mdna:159]
and/or contribute to the success of our existing businesses. However, it is possible that these initiatives will not be successful and/or will not result in meaningful revenues or generate operating income that meets expectations. As a result, we may develop products that fail to meet our customers’ needs and/or develop products that may become obsolete and be replaced by competitors’ products offering more compelling features, technologies or costs.

[0001234452-16-000352:mdna:160]
While we continue to focus our development efforts primarily in support of 3G CDMA- and 4G OFDMA-based technologies, we innovate across a broad spectrum of opportunities to deploy new business models and enter into new industry segments by leveraging our existing technical and business expertise and/or through acquisitions. Our recent investment initiatives relate to, among others, products for the connected home and the Internet of Things; automotive; networking; mobile computing; small cells and addressing the challenge of meeting the increased demand for data; very high speed connectivity; data centers; mobile health; wireless charging; and machine learning, including robotics.

[0001234452-16-000352:mdna:161]
Our research, development and other investments in new technologies, products or services may not succeed due to, among others: improvements in alternate technologies in ways that reduce the advantages we anticipate from our investments; competitors’ products or services being more cost effective, having more capabilities or fewer limitations or being brought to market faster than our new products and services; and competitors having longer operating histories in industry segments that are new to us. We may also underestimate the costs of or overestimate the future operating income and/or margins that could result from these investments, and these investments may not, or may take many years to, generate material returns. If our new technologies, products or services are not successful, or are not successful in the time frame we anticipate, we may incur significant costs and/or asset impairments, our business may not grow as anticipated, our revenues and/or margins may be negatively impacted and/or our reputation may be harmed.

[0001234452-16-000352:mdna:162]
We depend on a limited number of third-party suppliers for the procurement, manufacture and testing of our products. If we fail to execute supply strategies that provide supply assurance, technology leadership and low cost, our operating results and our business may be harmed. We are also subject to order and shipment uncertainties that could negatively impact our operating results.

[0001234452-16-000352:mdna:163]
Our QCT segment utilizes a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Turnkey is when our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services such as wafer bump, probe, assembly and final test. The third-party semiconductor manufacturing foundries that supply products to our QCT segment are primarily located in Asia. The following could have an adverse effect on our ability to meet customer demands and/or negatively impact our revenues, business operations, profitability and/or cash flows:

[0001234452-16-000352:mdna:164]
[same as prior period, unchanged from 0001234452-15-000208:mdna:182]

[0001234452-16-000352:mdna:165]
[same as prior period, unchanged from 0001234452-15-000208:mdna:183]

[0001234452-16-000352:mdna:166]
[same as prior period, unchanged from 0001234452-15-000208:mdna:184]

[0001234452-16-000352:mdna:167]
[same as prior period, unchanged from 0001234452-15-000208:mdna:185]

[0001234452-16-000352:mdna:168]
[same as prior period, unchanged from 0001234452-15-000208:mdna:186]

[0001234452-16-000352:mdna:169]
While we have established alternate suppliers for certain technologies, we rely on sole- or limited-source suppliers for certain products, subjecting us to significant risks, including: possible shortages of raw materials or manufacturing capacity; poor product performance; and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established alternate suppliers, these suppliers may require significant levels of support to bring complex technologies to production. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, any future consolidation of foundry suppliers could increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions and/or increase our manufacturing costs. Our arrangements with our suppliers may obligate us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies, and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new

[0001234452-16-000352:mdna:170]
40

[0001234452-16-000352:mdna:171]
products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Our inability to meet customer demand due to sole- or limited-sourcing and/or the additional costs that we incur because of these or other supply constraints or because of the need to support alternate suppliers could negatively impact our business, our revenues and our results of operations.

[0001234452-16-000352:mdna:172]
Although we have long-term contracts with our suppliers, many of these contracts do not provide for long-term capacity commitments. To the extent we do not have firm commitments from our suppliers over a specific time period or for any specific quantity, our suppliers may allocate, and in the past have allocated, capacity to the production and testing of products for their other customers while reducing or limiting capacity to manufacture or test our products. Accordingly, capacity for our products may not be available when we need it or at reasonable prices. To the extent we do obtain long-term capacity commitments, we may incur additional costs related to those commitments and/or make non-refundable payments for capacity commitments that are not used.

[0001234452-16-000352:mdna:173]
[same as prior period, unchanged from 0001234452-15-000208:mdna:189]

[0001234452-16-000352:mdna:174]
Additionally, we place orders with our suppliers using our forecasts of customer demand, which are based on a number of assumptions and estimates, and are generally only partially covered by commitments from our customers. If we overestimate customer demand, we may experience increased excess and/or obsolete inventory, which would negatively impact our operating results.

[0001234452-16-000352:mdna:175]
[same as prior period, unchanged from 0001234452-15-000208:mdna:170]

[0001234452-16-000352:mdna:176]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe on another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products through a licensed supplier, we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our operating results.

[0001234452-16-000352:mdna:177]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages, royalty payments and/or an injunction on the sale of certain of our integrated circuit products (and on the sale of our customers’ devices using such products). A negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001234452-16-000352:mdna:178]
A number of other companies have claimed to own patents applicable to products implementing various CDMA-based standards, TDMA-based standards such as GSM and OFDMA-based standards. In addition, existing standards continue to evolve, and new standards, including those applicable to new industry segments, continue to be developed. If future standards

[0001234452-16-000352:mdna:179]
diminish, or fail to include, a base level of interoperability, our business may be harmed, and our investments in these new segments may not succeed.

[0001234452-16-000352:mdna:180]
[same as prior period, unchanged from 0001234452-15-000208:mdna:175]

[0001234452-16-000352:mdna:181]
We engage in acquisitions and strategic transactions and make strategic investments, which are important to our business strategy, with the goal of maximizing stockholder value. We acquire businesses and other assets, including patents, technology, wireless spectrum and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies that may be private and early-stage. Our strategic activities are generally focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications. Many of our strategic activities entail a high degree of risk and require the use of domestic and/or foreign capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies, products or services. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our financial results, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.  In part due to our inexperience with technologies and/or products of and/or geographic regions served by our strategic activities, we may underestimate the costs and/or overestimate the benefits, including product and other synergies and growth opportunities that we expect to realize, and we may not achieve them. If we do not achieve the anticipated benefits of business acquisitions or other strategic activities, our results of operations may be adversely affected, and we may not enhance stockholder value by engaging in these transactions.

[0001234452-16-000352:mdna:182]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner. Such integration involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, business systems, technology and products; retaining customers and suppliers of the businesses; consolidating research and development and/or supply operations; minimizing the diversion of management’s attention from ongoing business matters; and consolidating corporate and administrative infrastructures. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, or we may become subject to litigation. Additionally, we may not be successful in expanding into geographic regions and/or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of the combination.

[0001234452-16-000352:mdna:183]
[same as prior period, unchanged from 0001234452-15-000208:mdna:167]

[0001234452-16-000352:mdna:184]
In the fourth quarter of 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders. As part of this Strategic Realignment Plan, among other actions, we are implementing a cost reduction plan, which includes a series of targeted reductions across our businesses, particularly in our semiconductor business, QCT, and a reduction to our annual share-based compensation grants in fiscal 2016. We expect these cost reduction initiatives to be substantially implemented by the end of fiscal 2016. Additional information regarding our Strategic Realignment Plan is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 9. Strategic Realignment Plan.”

[0001234452-16-000352:mdna:185]
We cannot provide assurance that our Strategic Realignment Plan will be successful, that anticipated cost savings will be realized, that our operations, business and financial results will improve and/or that these efforts will not disrupt our operations (beyond what is intended). Our ability to achieve the anticipated cost savings and other benefits within the expected time frames is subject to many estimates and assumptions, which are subject to significant economic, competitive and other uncertainties, some of which are beyond our control. Further, we may experience delays in the timing of these efforts and/or higher than expected or unanticipated costs in implementing them. Moreover, changes in the size, alignment or organization of our workforce could adversely affect employee morale and retention, relations with customers and business partners, our ability to develop and deliver products and services as anticipated and/or impair our ability to realize our current or future business and financial objectives. If we do not succeed in these efforts, if these efforts are more costly or time-consuming than expected, if our estimates and assumptions are not correct, if we experience delays or if other unforeseen events occur, our business and results of operations may be adversely affected.

[0001234452-16-000352:mdna:186]
[same as prior period, unchanged from 0001234452-15-000208:mdna:190]

[0001234452-16-000352:mdna:187]
Our stock price and earnings have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and/or earnings include those identified throughout this “Risk Factors” section, volatility of the stock market in general and technology-based companies in particular, announcements concerning us, our suppliers, our competitors or our customers or licensees and variations between our actual results or guidance and expectations of securities analysts, among others. Further, increased volatility in the financial markets and/or overall economic conditions may reduce the amounts that we realize in the future on our cash equivalents and/or marketable securities and may reduce our earnings as a result of any impairment charges that we record to reduce recorded values of marketable securities to their fair values.

[0001234452-16-000352:mdna:188]
In the past, securities class action litigation often has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we may be the target of securities litigation in the future. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources.

[0001234452-16-000352:mdna:189]
[same as prior period, unchanged from 0001234452-15-000208:mdna:194]

[0001234452-16-000352:mdna:190]
[same as prior period, unchanged from 0001234452-15-000208:mdna:195]

[0001234452-16-000352:mdna:191]
[same as prior period, unchanged from 0001234452-15-000208:mdna:196]

[0001234452-16-000352:mdna:192]
[same as prior period, unchanged from 0001234452-15-000208:mdna:197]

[0001234452-16-000352:mdna:193]
[same as prior period, unchanged from 0001234452-15-000208:mdna:198]

[0001234452-16-000352:mdna:194]
[same as prior period, unchanged from 0001234452-15-000208:mdna:199]

[0001234452-16-000352:mdna:195]
[same as prior period, unchanged from 0001234452-15-000208:mdna:200]

[0001234452-16-000352:mdna:196]
[same as prior period, unchanged from 0001234452-15-000208:mdna:201]

[0001234452-16-000352:mdna:197]
[same as prior period, unchanged from 0001234452-15-000208:mdna:202]

[0001234452-16-000352:mdna:198]
[same as prior period, unchanged from 0001234452-15-000208:mdna:205]

[0001234452-16-000352:mdna:199]
[same as prior period, unchanged from 0001234452-15-000208:mdna:206]

[0001234452-16-000352:mdna:200]
[same as prior period, unchanged from 0001234452-15-000208:mdna:207]

[0001234452-16-000352:mdna:201]
43

[0001234452-16-000352:mdna:202]
[same as prior period, unchanged from 0001234452-15-000208:mdna:208]

[0001234452-16-000352:mdna:203]
[same as prior period, unchanged from 0001234452-15-000208:mdna:209]

[0001234452-16-000352:mdna:204]
[same as prior period, unchanged from 0001234452-15-000208:mdna:210]

[0001234452-16-000352:mdna:205]
[same as prior period, unchanged from 0001234452-15-000208:mdna:203]

[0001234452-16-000352:mdna:206]
A decline in global economic conditions or a slow-down in economic growth, particularly in geographic regions with high concentrations of wireless voice and data users, could have adverse, wide-ranging effects on demand for our products and for the products and services of our customers or licensees, particularly equipment manufacturers or others in the wireless communications industry who buy their products, such as wireless operators. Any prolonged economic downturn may result in a decrease in demand for our products or technologies; the insolvency of key suppliers, customers or licensees; delays in reporting and/or payments from our licensees and/or customers; failures by counterparties; and negative effects on wireless device inventories. In addition, our customers’ ability to purchase or pay for our products and services and network operators’ ability to upgrade their wireless networks could be adversely affected by economic conditions, leading to a reduction, cancellation or delay of orders for our products or services.

[0001234452-16-000352:mdna:207]
[same as prior period, unchanged from 0001234452-15-000208:mdna:211]

[0001234452-16-000352:mdna:208]
The use of devices containing our products to access untrusted content creates a risk of exposing the system software in those devices to viral or malicious attacks. While we continue to focus on this issue and are taking measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more data and processes, such as mobile computing, and increasing the risk of security failures. Further, our products are inherently complex and may contain defects or errors that are detected only when the products are in use. As our chipset product complexities increase, we are required to migrate to integrated circuit technologies with smaller geometric feature sizes. The design process interface in new domains of technology is complex and adds risk to manufacturing yields and reliability. Further, manufacturing, testing, marketing and use of our products and those of our customers and licensees entail the risk of product liability. Because our products and services are responsible for critical functions in our customers’ products and/or networks, security failures, defects or errors in our products and services could have an adverse impact on us, on our customers and on the end users of our customers’ products. Such adverse impact could include product liability claims or recalls, write-offs of our inventories and/or intangible assets; unfavorable purchase commitments; a shift of business to our competitors; a decrease in demand for connected devices and wireless services; damage to our reputation and to our customer relationships; and other financial liability or harm to our business.

[0001234452-16-000352:mdna:209]
[same as prior period, unchanged from 0001234452-15-000208:mdna:213]

[0001234452-16-000352:mdna:210]
Attempts by others to gain unauthorized access to our information technology systems are increasingly more sophisticated. These attempts, which might be related to industrial or other espionage, include covertly introducing malware to our computers and networks and impersonating authorized users, among others. We seek to detect and investigate all security incidents and to prevent their recurrence, but in some cases, we might be unaware of an incident or its magnitude and effects. While we have identified several incidents of unauthorized access, to date none have caused material damage to our business. The theft, unauthorized use or publication of our intellectual property and/or confidential business information could harm our competitive position, reduce the value of our investment in research and development and other strategic initiatives and/or otherwise adversely affect our business. To the extent any security breach results in inappropriate disclosure of our customers’ or licensees’ confidential information, we may incur liability. We expect to continue to devote resources to the security of our information technology systems.

[0001234452-16-000352:mdna:211]
[same as prior period, unchanged from 0001234452-15-000208:mdna:216]

[0001234452-16-000352:mdna:212]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-United States headquarters is located. Significant judgment is required in determining our provision for income taxes. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related litigation could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case,

[0001234452-16-000352:mdna:213]
our income tax provision and results of operations in the period or periods in which that determination is made could be negatively affected.

[0001234452-16-000352:mdna:214]
We have tax incentives in Singapore provided that we meet specified employment and other criteria, and as a result of the expiration of these incentives, our Singapore tax rate is expected to increase in fiscal 2017 and again in fiscal 2027. If we do not meet the criteria required to retain such incentives, our Singapore tax rate could increase prior to those dates, and our results of operations could be adversely affected.

[0001234452-16-000352:mdna:215]
[same as prior period, unchanged from 0001234452-15-000208:mdna:219]
