# QCOM 8-K — 0001234452-16-000350 filed 2016-01-27

## item codes, every 8-K on or before 2016-01-27

- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2016-01-27

- none on or before 2016-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001234452-16-000350:8k_2_02:1]
EX-99.1
2
qcom122715erex991.htm
EXHIBIT 99.1

[0001234452-16-000350:8k_2_02:2]
Exhibit

[0001234452-16-000350:8k_2_02:3]
Exhibit 99.1

[0001234452-16-000350:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-16-000350:8k_2_02:5]
Qualcomm Contact:

[0001234452-16-000350:8k_2_02:6]
Warren Kneeshaw

[0001234452-16-000350:8k_2_02:7]
Vice President, Investor Relations

[0001234452-16-000350:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-16-000350:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-16-000350:8k_2_02:10]
Qualcomm Announces First Quarter Fiscal 2016 Results

[0001234452-16-000350:8k_2_02:11]
Revenues $5.8 billion

[0001234452-16-000350:8k_2_02:12]
GAAP EPS $0.99, Non-GAAP EPS $0.97

[0001234452-16-000350:8k_2_02:13]
-EPS Above High End of Guidance Range-

[0001234452-16-000350:8k_2_02:14]
SAN DIEGO - January 27, 2016 - Qualcomm Incorporated (NASDAQ: QCOM), a leading developer and innovator of advanced wireless technologies, products and services, today announced results for its fiscal first quarter ended December 27, 2015.

[0001234452-16-000350:8k_2_02:15]
“We delivered a stronger than expected quarter with earnings per share above the high end of our initial estimates, driven by better than expected 3G/4G reported device sales and benefits realized from cost actions across the Company,” said Steve Mollenkopf, CEO of Qualcomm Incorporated. “We signed several new license agreements in China and are on track with our cost reduction initiatives.  Design traction for our new Snapdragon 820 processor continues to be strong, and we expect improving trends in our chipset business in the second half of fiscal 2016.”

[0001234452-16-000350:8k_2_02:16]
First Quarter Results (GAAP)*

[0001234452-16-000350:8k_2_02:17]
|  | Q1 Fiscal 2016 |  | Q1 Fiscal 2015 |  | Year-Over-Year Change |  | Q4 Fiscal 2015 |  | Sequential Change |
| Revenues 1 | $5.8B |  | $7.1B |  | (19%) |  | $5.5B |  | +6% |
| Operating income 1 | $1.7B |  | $2.1B |  | (18%) |  | $1.1B |  | +48% |
| Net income 2 | $1.5B |  | $2.0B |  | (24%) |  | $1.1B |  | +41% |
| Diluted earnings per share 2 | $0.99 |  | $1.17 |  | (15%) |  | $0.67 |  | +48% |
| Operating cash flow | $2.7B |  | $2.4B |  | +16% |  | $1.7B |  | +63% |

[0001234452-16-000350:8k_2_02:18]
1 Throughout this news release, revenues, operating expenses, operating income, earnings before tax (EBT) and effective tax rates are from continuing operations (i.e., before adjustments for noncontrolling interests), unless otherwise stated.

[0001234452-16-000350:8k_2_02:19]
2 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests), unless otherwise stated.

[0001234452-16-000350:8k_2_02:20]
Non-GAAP First Quarter Results

[0001234452-16-000350:8k_2_02:21]
|  | Q1 Fiscal 2016 |  | Q1 Fiscal 2015 |  | Year-Over-Year Change |  | Q4 Fiscal 2015 |  | Sequential Change |
| Revenues | $5.8B |  | $7.1B |  | (19%) |  | $5.5B |  | +6% |
| Operating income | $1.7B |  | $2.5B |  | (31%) |  | $1.6B |  | +8% |
| Net income | $1.5B |  | $2.3B |  | (35%) |  | $1.4B |  | +3% |
| Diluted earnings per share | $0.97 |  | $1.34 |  | (28%) |  | $0.91 |  | +7% |

[0001234452-16-000350:8k_2_02:22]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Other items excluded from Non-GAAP results include third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairment charges and litigation settlements and/or damages.  Detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-16-000350:8k_2_02:23]
* The following should be considered in regards to the year-over-year and sequential comparisons:

[0001234452-16-000350:8k_2_02:24]
| • | The first quarter of fiscal 2016 GAAP results included: |

[0001234452-16-000350:8k_2_02:25]
| ◦ | $380 million gain, or $0.20 per share, related to the sale of our wireless spectrum in the United Kingdom. |

[0001234452-16-000350:8k_2_02:26]
| • | The fourth quarter of fiscal 2015 GAAP results included: |

[0001234452-16-000350:8k_2_02:27]
| ◦ | $190 million of charges, or $0.09 per share, that resulted from restructuring and restructuring-related charges related to our Strategic Realignment Plan. |

[0001234452-16-000350:8k_2_02:28]
First Quarter Key Business Metrics

[0001234452-16-000350:8k_2_02:29]
|  | Q1 Fiscal 2016 |  | Q1 Fiscal 2015 |  | Year-Over-Year Change (1) |  | Q4 Fiscal 2015 |  | Sequential Change (1) |
| MSMTM chip shipments | 242M |  | 270M |  | (10%) |  | 203M |  | +19% |
| Total reported device sales (2) | $60.6B |  | $56.4B |  | +7% |  | $58.3B |  | +4% |
| Est. reported 3G/4G device shipments (approx.) (2) | 307M - 311M |  | 284M - 288M |  | +8% |  | 276M - 280M |  | +11% |
| Est. reported 3G/4G average selling price (approx.) (2) | $193 - $199 |  | $194 - $200 |  | (1%) |  | $207 - $213 |  | (7%) |

[0001234452-16-000350:8k_2_02:30]
| (1) | The year-over-year and sequential changes for estimated reported 3G/4G device shipments and average selling prices are calculated at the midpoints. The midpoints of the estimated ranges are used for comparison purposes only and do not indicate a higher degree of confidence in the midpoints. |

[0001234452-16-000350:8k_2_02:31]
| (2) | The first quarter of fiscal 2015 and 2016 are based on sales by our licensees in the September quarter as reported to us in the December quarter, and the fourth quarter of fiscal 2015 is based on sales by our licensees in the June quarter as reported to us in the September quarter. |

[0001234452-16-000350:8k_2_02:32]
Cash and Marketable Securities

[0001234452-16-000350:8k_2_02:33]
Our cash, cash equivalents and marketable securities totaled $30.6 billion at the end of the first quarter of fiscal 2016, compared to $31.6 billion a year ago and $30.9 billion at the end of the fourth quarter of fiscal 2015.

[0001234452-16-000350:8k_2_02:34]
Recently Announced Joint Venture Agreement with TDK

[0001234452-16-000350:8k_2_02:35]
In January 2016, we announced an agreement with TDK Corporation to form a joint venture to enable delivery of radio frequency front-end (RFFE) modules and RF filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others.  The joint venture will initially be owned 51% by Qualcomm and 49% by TDK.  The purchase price upon close of the transaction is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things.  Additionally, we have the option to acquire (and TDK has an option to sell) TDK’s interest in the joint venture for $1.15 billion 30 months after the closing date.  The transaction is subject to regulatory approvals and other closing conditions and is expected to close by early 2017.

[0001234452-16-000350:8k_2_02:36]
Return of Capital to Stockholders

[0001234452-16-000350:8k_2_02:37]
The following table summarizes stock repurchases and dividends paid during the first quarter of fiscal 2016 (in millions, except per-share amounts):

[0001234452-16-000350:8k_2_02:38]
|  | Stock Repurchases |  | Dividends |  | Total |
|  | Shares |  | Amount |  | Per Share |  | Amount |  | Amount |
| Q1 fiscal 2016 | 36.6 |  | $2,050 |  | $0.48 |  | $717 |  | $2,767 |

[0001234452-16-000350:8k_2_02:39]
In the first quarter of fiscal 2016, we completed our previously announced commitment to repurchase $10 billion of stock from March 2015 through March 2016.  On January 12, 2016, we announced a cash dividend of $0.48 per share payable on March 23, 2016 to stockholders of record as of the close of business on March 2, 2016.

[0001234452-16-000350:8k_2_02:40]
Effective Income Tax Rates

[0001234452-16-000350:8k_2_02:41]
Our fiscal 2016 annual effective income tax rates are estimated to be approximately 17 percent for GAAP and approximately 18 percent for Non-GAAP.  The effective income tax rates for the first quarter of fiscal 2016 were 13 percent for GAAP and 17 percent for Non-GAAP.  As a result of the retroactive reinstatement of the federal R&D tax credit during the first quarter of fiscal 2016, a tax benefit related to fiscal 2015 of $0.05 per share was excluded from Non-GAAP results.

[0001234452-16-000350:8k_2_02:42]
Business Outlook

[0001234452-16-000350:8k_2_02:43]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment and certain derivative gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.  Our outlook includes an estimate of the benefit related to stock repurchases that we plan to complete.

[0001234452-16-000350:8k_2_02:44]
We have not included any estimates related to the proposed joint venture with TDK Corporation in our fiscal 2016 outlook.  The joint venture is expected to close by early 2017. We expect the joint venture to be accretive to Non-GAAP earnings per share in the 12 months following the transaction close.

[0001234452-16-000350:8k_2_02:45]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-16-000350:8k_2_02:46]
Qualcomm’s Business Outlook Summary

[0001234452-16-000350:8k_2_02:47]
| SECOND FISCAL QUARTER |
|  |  | Q2 FY15 Results (1) | Current Guidance Q2 FY16 Estimates |
|  | Revenues |  | $6.9 | B | $4.9B - $5.7B |  |
|  | Year-over-year change |  | decrease 17% - 29% |  |
|  | Non-GAAP diluted earnings per share (EPS) |  | $1.40 |  | $0.90 - $1.00 |  |
|  | Year-over-year change |  | decrease 29% - 36% |  |
|  | Diluted EPS attributable to QSI |  | ($0.02 | ) |  | $0.02 |  |
|  | Diluted EPS attributable to share-based compensation |  | ($0.12 | ) |  | ($0.13 | ) |
|  | Diluted EPS attributable to other items (2) |  | ($0.63 | ) |  | ($0.10 | ) |
|  | GAAP diluted EPS |  | $0.63 |  | $0.69 - $0.79 |  |
|  | Year-over-year change |  | increase 10% - 25% |  |
|  | Metrics |  |  |
|  | MSM chip shipments | 233 | M | 175M - 195M |  |
|  | Year-over-year change |  | decrease 16% - 25% |  |
|  | Total reported device sales* (3) | approx. $75.8B | approx. $65.0B - $73.0B (4) |  |
|  | Year-over-year change |  | decrease 4% - 14% |  |
|  | *Est. sales in December quarter, reported in March quarter |  |  |

[0001234452-16-000350:8k_2_02:48]
| (1) | Our results for diluted EPS attributable to other items for the second quarter of fiscal 2015 included a $975 million charge, or $0.58 per share, related to the resolution reached with the China National Development and Reform Commission (NDRC) regarding its investigation of us under China’s Anti-Monopoly Law. |

[0001234452-16-000350:8k_2_02:49]
| (2) | Our guidance for diluted EPS attributable to other items for the second quarter of fiscal 2016 includes a loss per share of $0.08 for acquisition-related items. |

[0001234452-16-000350:8k_2_02:50]
| (3) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). The reported quarterly estimated ranges of average selling prices (ASPs) and unit shipments are determined based on the information as reported to us by our licensees during the relevant period and our own estimates of the selling prices and unit shipments for licensees that do not provide such information. Not all licensees report sales, selling prices and/or unit shipments the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales, estimated unit shipments and estimated ASPs for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-16-000350:8k_2_02:51]
| (4) | Our guidance range for the second quarter of fiscal 2016 total reported device sales reflects estimated 3G/4G total reported device sales that we currently expect to be reported to us, which includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-16-000350:8k_2_02:52]
Sums may not equal totals due to rounding.

[0001234452-16-000350:8k_2_02:53]
Results of Business Segments

[0001234452-16-000350:8k_2_02:54]
The following table reconciles our Non-GAAP results to our GAAP results ($ in millions, except per share data):

[0001234452-16-000350:8k_2_02:55]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (a) | Non-GAAP | QSI | Share-Based Compensation | Other Items (b) (c) (d) |  | GAAP |
| Q1 - FISCAL 2016 |  |  |  |  |  |
| Revenues | $4,096 | $1,607 | $63 | $5,766 |  | $9 |  |  | $— |  |  | $— |  |  | $5,775 |  |
| Change from prior year | (22 | %) | (12 | %) | 54 | % | (19 | %) |  | N/M |  |  |  |  |  | (19 | %) |  |
| Change from prior quarter | 13 | % | (10 | %) | 50 | % | 6 | % |  | N/M |  |  |  |  |  | 6 | % |  |
| Cost of equipment and services revenues |  |  |  | $2,377 |  | $7 |  | $10 | $140 |  | $2,534 |  |
| Research and development |  |  |  | 1,182 |  | 2 |  | 165 | 3 |  | 1,352 |  |
| Selling, general and administrative |  |  |  | 466 |  | 8 |  | 72 | 32 |  | 578 |  |
| Other (income) expenses |  |  |  | — |  |  | (380) | (e) | — |  | 6 |  | (374) |  |
| Operating income (loss) |  |  |  | $1,741 |  | $372 |  | ($247) | ($181) |  | $1,685 |  |
| Change from prior year |  |  |  | (31 | %) |  | N/M |  |  | 10 | % | 3 | % |  | (18 | %) |  |
| Change from prior quarter |  |  |  | 8 | % |  | N/M |  |  | (6 | %) | 23 | % |  | 48 | % |  |
| Interest expense |  |  |  | ($74) |  |  | $— |  |  |  | $— |  |  | $— |  |  | ($74) |  |
| Investment income, net |  |  |  | $112 | (f) | ($13) | (g) |  | $— |  |  | $— |  |  | $99 |  |
| EBT | $590 | $1,339 | ($150) | $1,779 |  | $359 |  | ($247) | ($181) |  | $1,710 |  |
| Change from prior year | (49 | %) | (15 | %) | N/M |  | (36 | %) |  | N/M |  |  | 10 | % | 3 | % |  | (26 | %) |  |
| Change from prior quarter | 111 | % | (10 | %) | N/M |  | 4 | % |  | N/M |  |  | (6 | %) | 23 | % |  | 37 | % |  |
| EBT as % of revenues | 14 | % | 83 | % | N/M |  | 31 | % |  |  |  |  |  |  | 30 | % |  |
| Net income (loss) |  |  |  | $1,469 |  | $234 |  | ($187) | ($18) |  | $1,498 |  |
| Change from prior year |  |  |  | (35 | %) |  | N/M |  |  | 18 | % | 71 | % |  | (24 | %) |  |
| Change from prior quarter |  |  |  | 3 | % |  | N/M |  |  | 1 | % | 90 | % |  | 41 | % |  |
| Diluted EPS |  |  |  | $0.97 |  | $0.15 |  | ($0.12) | ($0.01) |  | $0.99 |  |
| Change from prior year |  |  |  | (28 | %) |  | N/M |  |  | 14 | % | 75 | % |  | (15 | %) |  |
| Change from prior quarter |  |  |  | 7 | % |  | N/M |  |  | — | % | 92 | % |  | 48 | % |  |
| Diluted shares |  |  |  | 1,517 |  | 1,517 |  | 1,517 | 1,517 |  | 1,517 |  |
| Q4 - FISCAL 2015 |  |  |  |  |  |
| Revenues | $3,625 | $1,785 | $42 | $5,452 |  | $4 |  |  | $— |  |  | $— |  |  | $5,456 |  |
| Operating income (loss) |  |  |  | 1,617 |  | (8) |  | (233) | (236) |  | 1,140 |  |
| EBT | $280 | $1,487 | ($54) | 1,713 |  | 8 |  | (233) | (236) |  | 1,252 |  |
| Net income (loss) |  |  |  | 1,427 |  | 8 |  | (188) | (186) |  | 1,061 |  |
| Diluted EPS |  |  |  | $0.91 |  | $0.01 |  | ($0.12) | ($0.12) |  | $0.67 |  |
| Diluted shares |  |  |  | 1,573 |  | 1,573 |  | 1,573 | 1,573 |  | 1,573 |  |
| Q1 - FISCAL 2015 |  |  |  |  |  |
| Revenues | $5,242 | $1,816 | $41 | $7,099 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $7,099 |  |
| Operating income (loss) |  |  |  | 2,531 |  | (7) |  | (273) | (187) |  | 2,064 |  |
| EBT | $1,146 | $1,579 | $34 | 2,759 |  | (1) |  | (273) | (187) |  | 2,298 |  |
| Net income (loss) |  |  |  | 2,263 |  | — |  |  | (229) | (62) |  | 1,972 |  |
| Diluted EPS |  |  |  | $1.34 |  | $0.00 |  | ($0.14) | ($0.04) |  | $1.17 |  |
| Diluted shares |  |  |  | 1,686 |  | 1,686 |  | 1,686 | 1,686 |  | 1,686 |  |

[0001234452-16-000350:8k_2_02:56]
| (a) | Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations. Non-GAAP reconciling items related to earnings before taxes consisted primarily of certain research and development expenses, selling, general and administrative expenses, other expenses or income, interest expense and certain investment income that are not allocated to the segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit. |

[0001234452-16-000350:8k_2_02:57]
| (b) | In the first quarter of fiscal 2016, other items excluded from Non-GAAP EBT included $172 million of acquisition-related charges; $54 million of restructuring and restructuring-related charges and a $48 million gain on the sale of our business that provided augmented reality applications related to our Strategic Realignment Plan; and $3 million of other severance costs. |

[0001234452-16-000350:8k_2_02:58]
| (c) | In the first quarter of fiscal 2016, the tax benefit in the “Other Items” column included a $79 million tax benefit related to fiscal 2015 as a result of the retroactive reinstatement of the federal R&D tax credit; a $48 million tax benefit to reconcile the tax provision for each column to the total GAAP tax provision for the quarter; a $32 million tax benefit for the tax effect of acquisition-related items; and a $4 million tax benefit for the tax effect of other items in EBT. At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates” herein. |

[0001234452-16-000350:8k_2_02:59]
| (d) | Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001234452-16-000350:8k_2_02:60]
| (e) | Comprised of a $380 million gain on the sale of our wireless spectrum in the United Kingdom. |

[0001234452-16-000350:8k_2_02:61]
| (f) | Included $133 million in interest and dividend income and $30 million in net realized gains on investments, partially offset by $49 million in other-than-temporary losses on investments and $2 million in other net investment expense. |

[0001234452-16-000350:8k_2_02:62]
| (g) | Included $18 million in equity in losses of investees and $14 million in other-than-temporary losses on investments, partially offset by $19 million in net realized gains on investments. |

[0001234452-16-000350:8k_2_02:63]
N/M - Not Meaningful

[0001234452-16-000350:8k_2_02:64]
Sums may not equal totals due to rounding.

[0001234452-16-000350:8k_2_02:65]
Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates

[0001234452-16-000350:8k_2_02:66]
(Unaudited)

[0001234452-16-000350:8k_2_02:67]
| Three Months Ended December 27, 2015 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Other Items |  |  | GAAP Results |  |
| Income (loss) before income taxes |  | $ | 1,779 |  |  |  | $ | 359 |  |  |  | $ | (247 | ) |  |  | $ | (181 | ) |  |  | $ | 1,710 |  |  |
| Income tax (expense) benefit |  | (310 | ) |  |  | (127 | ) |  |  | 60 |  |  |  | 163 |  |  |  | (214 | ) |  |
| Net income (loss) (1) |  | $ | 1,469 |  |  |  | $ | 232 |  |  |  | $ | (187 | ) |  |  | $ | (18 | ) |  |  | $ | 1,496 |  |  |
| Tax rate |  | 17 | % |  |  | 35 | % |  |  | 24 | % |  |  | N/M |  |  |  | 13 | % |  |

[0001234452-16-000350:8k_2_02:68]
| (1) | Before adjustments for noncontrolling interests. |

[0001234452-16-000350:8k_2_02:69]
Conference Call

[0001234452-16-000350:8k_2_02:70]
Qualcomm’s fiscal first quarter 2016 earnings conference call will be broadcast live on January 27, 2016, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 24099843.

[0001234452-16-000350:8k_2_02:71]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-16-000350:8k_2_02:72]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-16-000350:8k_2_02:73]
The Company uses the Non-GAAP financial information:  (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against each other and against competitors.  Non-GAAP measurements used by the Company include revenues, cost of equipment and services revenues, R&D

[0001234452-16-000350:8k_2_02:74]
expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial information also is used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0001234452-16-000350:8k_2_02:75]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items, tax items and other items.

[0001234452-16-000350:8k_2_02:76]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-16-000350:8k_2_02:77]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001234452-16-000350:8k_2_02:78]
| • | Certain other items are excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001234452-16-000350:8k_2_02:79]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items starting with acquisitions completed in the third quarter of fiscal 2011, as well as any tax effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property and third-party acquisition and integration services costs. |

[0001234452-16-000350:8k_2_02:80]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and litigation settlements and/or damages. |

[0001234452-16-000350:8k_2_02:81]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. |

[0001234452-16-000350:8k_2_02:82]
About Qualcomm

[0001234452-16-000350:8k_2_02:83]
Qualcomm Incorporated (NASDAQ: QCOM) is a world leader in 3G, 4G and next-generation wireless technologies.  Qualcomm Incorporated includes Qualcomm’s licensing business, QTL, and the vast majority of its patent portfolio.  Qualcomm Technologies, Inc., a wholly-owned subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of Qualcomm’s engineering, research and development functions, and substantially all of its products and services businesses, including its semiconductor business, QCT.  For more than 30 years, Qualcomm ideas and inventions have driven the evolution of digital communications, linking people everywhere more closely to information, entertainment and each other.  For more information, visit www.qualcomm.com.

[0001234452-16-000350:8k_2_02:84]
Note Regarding Forward-Looking Statements

[0001234452-16-000350:8k_2_02:85]
###

[0001234452-16-000350:8k_2_02:86]
Qualcomm, Snapdragon and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-16-000350:8k_2_02:87]
Qualcomm Incorporated

[0001234452-16-000350:8k_2_02:88]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001234452-16-000350:8k_2_02:89]
(In millions, except per share data)

[0001234452-16-000350:8k_2_02:90]
(Unaudited)

[0001234452-16-000350:8k_2_02:91]
|  | December 27, 2015 |  | September 27, 2015 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 6,913 |  |  | $ | 7,560 |  |
| Marketable securities | 9,615 |  |  | 9,761 |  |
| Accounts receivable, net | 1,323 |  |  | 1,964 |  |
| Inventories | 1,216 |  |  | 1,492 |  |
| Deferred tax assets | 607 |  |  | 635 |  |
| Other current assets | 664 |  |  | 687 |  |
| Total current assets | 20,338 |  |  | 22,099 |  |
| Marketable securities | 14,063 |  |  | 13,626 |  |
| Deferred tax assets | 1,616 |  |  | 1,453 |  |
| Property, plant and equipment, net | 2,484 |  |  | 2,534 |  |
| Goodwill | 5,669 |  |  | 5,479 |  |
| Other intangible assets, net | 4,068 |  |  | 3,742 |  |
| Other assets | 1,991 |  |  | 1,863 |  |
| Total assets | $ | 50,229 |  |  | $ | 50,796 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,359 |  |  | $ | 1,300 |  |
| Payroll and other benefits related liabilities | 895 |  |  | 861 |  |
| Unearned revenues | 639 |  |  | 583 |  |
| Short-term debt | 1,000 |  |  | 1,000 |  |
| Other current liabilities | 2,610 |  |  | 2,356 |  |
| Total current liabilities | 6,503 |  |  | 6,100 |  |
| Unearned revenues | 2,630 |  |  | 2,496 |  |
| Long-term debt | 9,950 |  |  | 9,969 |  |
| Other liabilities | 913 |  |  | 817 |  |
| Total liabilities | 19,996 |  |  | 19,382 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,495 and 1,524 shares issued and outstanding, respectively | — |  |  | — |  |
| Retained earnings | 30,172 |  |  | 31,226 |  |
| Accumulated other comprehensive income | 69 |  |  | 195 |  |
| Total Qualcomm stockholders’ equity | 30,241 |  |  | 31,421 |  |
| Noncontrolling interests | (8 | ) |  | (7 | ) |
| Total stockholders’ equity | 30,233 |  |  | 31,414 |  |
| Total liabilities and stockholders’ equity | $ | 50,229 |  |  | $ | 50,796 |  |

[0001234452-16-000350:8k_2_02:92]
Qualcomm Incorporated

[0001234452-16-000350:8k_2_02:93]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-16-000350:8k_2_02:94]
(In millions, except per share data)

[0001234452-16-000350:8k_2_02:95]
(Unaudited)

[0001234452-16-000350:8k_2_02:96]
|  | Three Months Ended |
|  | December 27, 2015 |  | December 28, 2014 |
| Revenues: |  |  |  |
| Equipment and services | $ | 4,087 |  |  | $ | 5,216 |  |
| Licensing | 1,688 |  |  | 1,883 |  |
| Total revenues | 5,775 |  |  | 7,099 |  |
| Costs and expenses: |  |  |  |
| Cost of equipment and services revenues | 2,534 |  |  | 3,047 |  |
| Research and development | 1,352 |  |  | 1,352 |  |
| Selling, general and administrative | 578 |  |  | 583 |  |
| Other | (374 | ) |  | 53 |  |
| Total costs and expenses | 4,090 |  |  | 5,035 |  |
| Operating income | 1,685 |  |  | 2,064 |  |
| Interest expense | (74 | ) |  | (1 | ) |
| Investment income, net | 99 |  |  | 235 |  |
| Income before income taxes | 1,710 |  |  | 2,298 |  |
| Income tax expense | (214 | ) |  | (327 | ) |
| Net income | 1,496 |  |  | 1,971 |  |
| Net loss attributable to noncontrolling interests | 2 |  |  | 1 |  |
| Net income attributable to Qualcomm | $ | 1,498 |  |  | $ | 1,972 |  |
| Basic earnings per share attributable to Qualcomm | $ | 1.00 |  |  | $ | 1.19 |  |
| Diluted earnings per share attributable to Qualcomm | $ | 0.99 |  |  | $ | 1.17 |  |
| Shares used in per share calculations: |  |  |  |
| Basic | 1,502 |  |  | 1,661 |  |
| Diluted | 1,517 |  |  | 1,686 |  |
| Dividends per share announced | $ | 0.48 |  |  | $ | 0.42 |  |

[0001234452-16-000350:8k_2_02:97]
Qualcomm Incorporated

[0001234452-16-000350:8k_2_02:98]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-16-000350:8k_2_02:99]
(In millions)

[0001234452-16-000350:8k_2_02:100]
(Unaudited)

[0001234452-16-000350:8k_2_02:101]
|  | Three Months Ended |
|  | December 27, 2015 |  | December 28, 2014 |
| Operating Activities: |  |  |  |
| Net income | $ | 1,496 |  |  | $ | 1,971 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization expense | 364 |  |  | 287 |  |
| Indefinite and long-lived asset impairment charges | 2 |  |  | 75 |  |
| Income tax provision less than income tax payments | (103 | ) |  | (7 | ) |
| Realized gain on sale of wireless spectrum | (380 | ) |  | — |  |
| Non-cash portion of share-based compensation expense | 247 |  |  | 273 |  |
| Incremental tax benefits from share-based compensation | (2 | ) |  | (48 | ) |
| Net realized gains on marketable securities and other investments | (49 | ) |  | (166 | ) |
| Impairment losses on marketable securities and other investments | 63 |  |  | 65 |  |
| Other items, net | (13 | ) |  | (31 | ) |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable, net | 646 |  |  | 173 |  |
| Inventories | 291 |  |  | (303 | ) |
| Other assets | 66 |  |  | (140 | ) |
| Trade accounts payable | 50 |  |  | 268 |  |
| Payroll, benefits and other liabilities | 98 |  |  | 20 |  |
| Unearned revenues | (37 | ) |  | (73 | ) |
| Net cash provided by operating activities | 2,739 |  |  | 2,364 |  |
| Investing Activities: |  |  |  |
| Capital expenditures | (128 | ) |  | (253 | ) |
| Purchases of available-for-sale securities | (3,737 | ) |  | (5,966 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 3,113 |  |  | 4,578 |  |
| Purchases of trading securities | (149 | ) |  | (302 | ) |
| Proceeds from sales and maturities of trading securities | 121 |  |  | 296 |  |
| Proceeds from sales of other marketable securities | 200 |  |  | — |  |
| Acquisitions and other investments, net of cash acquired | (450 | ) |  | (111 | ) |
| Proceeds from sale of wireless spectrum | 232 |  |  | — |  |
| Other items, net | 82 |  |  | 22 |  |
| Net cash used by investing activities | (716 | ) |  | (1,736 | ) |
| Financing Activities: |  |  |  |
| Proceeds from short-term debt | 1,089 |  |  | — |  |
| Repayment of short-term debt | (1,090 | ) |  | — |  |
| Proceeds from issuance of common stock | 99 |  |  | 116 |  |
| Repurchases and retirements of common stock | (2,050 | ) |  | (1,664 | ) |
| Dividends paid | (717 | ) |  | (697 | ) |
| Incremental tax benefits from share-based compensation | 2 |  |  | 48 |  |
| Other items, net | 2 |  |  | (6 | ) |
| Net cash used by financing activities | (2,665 | ) |  | (2,203 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (5 | ) |  | (7 | ) |
| Net decrease in cash and cash equivalents | (647 | ) |  | (1,582 | ) |
| Cash and cash equivalents at beginning of period | 7,560 |  |  | 7,907 |  |
| Cash and cash equivalents at end of period | $ | 6,913 |  |  | $ | 6,325 |  |
