# QCOM 8-K — 0001234452-17-000026 filed 2017-01-25

## item codes, every 8-K on or before 2017-01-25

- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2017-01-25

- none on or before 2017-01-25

## item 2.02 — earnings release, exhibit 99.1

[0001234452-17-000026:8k_2_02:1]
EX-99.1
2
qcom122516erex991.htm
EXHIBIT 99.1

[0001234452-17-000026:8k_2_02:2]
Exhibit

[0001234452-17-000026:8k_2_02:3]
Exhibit 99.1

[0001234452-17-000026:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-17-000026:8k_2_02:5]
Qualcomm Contact:

[0001234452-17-000026:8k_2_02:6]
John Sinnott

[0001234452-17-000026:8k_2_02:7]
Vice President, Investor Relations

[0001234452-17-000026:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-17-000026:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-17-000026:8k_2_02:10]
Qualcomm Announces First Quarter Fiscal 2017 Results

[0001234452-17-000026:8k_2_02:11]
Revenues $6.0 billion

[0001234452-17-000026:8k_2_02:12]
GAAP EPS $0.46, Non-GAAP EPS $1.19

[0001234452-17-000026:8k_2_02:13]
-Earnings Before Taxes up 23% YoY in QCT and 14% YoY in QTL-

[0001234452-17-000026:8k_2_02:14]
SAN DIEGO - January 25, 2017 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal first quarter ended December 25, 2016.

[0001234452-17-000026:8k_2_02:15]
“We are pleased with the strong start to our fiscal year and the year-over-year earnings growth across both our semiconductor and licensing businesses,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “Looking ahead, the pending NXP acquisition accelerates our strategic transformation in the high growth areas of automotive, IoT, security and networking.  We are very well positioned to lead as the semiconductor engine for the intelligent, connected world.”

[0001234452-17-000026:8k_2_02:16]
Mr. Mollenkopf added, “the recent legal and governmental actions against Qualcomm are at their core driven by commercial disputes.  As we have done in the past, we will vigorously defend our business model and the value of a portfolio of technologies that has been so instrumental to the success of the mobile communications industry.”

[0001234452-17-000026:8k_2_02:17]
First Quarter Results (GAAP)*

[0001234452-17-000026:8k_2_02:18]
|  | Q1 Fiscal 2017 |  | Q1 Fiscal 2016 |  | Year-Over-Year Change |  | Q4 Fiscal 2016 |  | Sequential Change |
| Revenues | $6.0B |  | $5.8B |  | +4% |  | $6.2B |  | (3%) |
| Operating income | $0.8B |  | $1.7B |  | (54%) |  | $1.8B |  | (57%) |
| Net income 1 | $0.7B |  | $1.5B |  | (54%) |  | $1.6B |  | (57%) |
| Diluted earnings per share 1 | $0.46 |  | $0.99 |  | (54%) |  | $1.07 |  | (57%) |
| Operating cash flow | $1.4B |  | $2.7B |  | (50%) |  | $2.1B |  | (34%) |

[0001234452-17-000026:8k_2_02:19]
1 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests), unless otherwise stated.

[0001234452-17-000026:8k_2_02:20]
First Quarter Results (Non-GAAP)

[0001234452-17-000026:8k_2_02:21]
|  | Q1 Fiscal 2017 |  | Q1 Fiscal 2016 |  | Year-Over-Year Change |  | Q4 Fiscal 2016 |  | Sequential Change |
| Revenues | $6.0B |  | $5.8B |  | +4% |  | $6.2B |  | (3%) |
| Operating income | $2.1B |  | $1.7B |  | +19% |  | $2.2B |  | (5%) |
| Net income | $1.8B |  | $1.5B |  | +21% |  | $1.9B |  | (6%) |
| Diluted earnings per share | $1.19 |  | $0.97 |  | +23% |  | $1.28 |  | (7%) |

[0001234452-17-000026:8k_2_02:22]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding the Company’s use of Non-GAAP financial measures and detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-17-000026:8k_2_02:23]
* The following should be considered in regards to the year-over-year comparisons:

[0001234452-17-000026:8k_2_02:24]
| • | The first quarter of fiscal 2017 GAAP results included: |

[0001234452-17-000026:8k_2_02:25]
| ◦ | $868 million charge, or $0.49 per share, which was accrued, related to the Korea Free Trade Commission (KFTC) investigation. |

[0001234452-17-000026:8k_2_02:26]
| • | The first quarter of fiscal 2016 GAAP results included: |

[0001234452-17-000026:8k_2_02:27]
| ◦ | $380 million gain, or $0.20 per share, related to the sale of our wireless spectrum in the United Kingdom. |

[0001234452-17-000026:8k_2_02:28]
First Quarter Segment Results

[0001234452-17-000026:8k_2_02:29]
|  | Q1 Fiscal 2017 |  | Q1 Fiscal 2016 |  | Year-Over-Year Change (1) |  | Q4 Fiscal 2016 |  | Sequential Change (1) |
| QCT |  |  |  |  |  |  |  |  |  |
| Revenues | $4,101M |  | $4,096M |  | —% |  | $4,124M |  | (1%) |
| Earnings before taxes (EBT) | $724M |  | $590M |  | +23% |  | $687M |  | +5% |
| EBT as % of revenues | 18% |  | 14% |  | +4% |  | 17% |  | +1% |
| MSMTM chip shipments | 217M |  | 242M |  | (10%) |  | 211M |  | +3% |
| QTL |  |  |  |  |  |  |  |  |  |
| Revenues | $1,811M |  | $1,607M |  | +13% |  | $1,885M |  | (4%) |
| EBT | $1,532M |  | $1,339M |  | +14% |  | $1,584M |  | (3%) |
| EBT as % of revenues | 85% |  | 83% |  | +2% |  | 84% |  | 1% |
| Total reported device sales (2) (3) | $62.9B |  | $60.6B |  | +4% |  | $74.2B |  | (15%) |
| Est. reported 3G/4G device shipments | 331M - 335M |  | 307M - 311M |  | +8% |  | 401M - 405M |  | (17%) |
| Est. reported 3G/4G average selling price | $186 - $192 |  | $193 - $199 |  | (4%) |  | $181 - $187 |  | +3% |

[0001234452-17-000026:8k_2_02:30]
| (1) | The year-over-year and sequential changes for estimated reported 3G/4G device shipments and average selling prices are calculated at the midpoints. The midpoints of the estimated ranges are used for comparison purposes only and do not indicate a higher degree of confidence in the midpoints. |

[0001234452-17-000026:8k_2_02:31]
| (2) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based |

[0001234452-17-000026:8k_2_02:32]
and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a

[0001234452-17-000026:8k_2_02:33]
particular period (collectively, 3G/4G devices). The reported quarterly estimated ranges of average selling prices (ASPs) and unit shipments are determined based on the information as reported to us by our licensees during the relevant period and our own estimates of the selling prices and unit shipments for licensees that do not provide such information. Not all licensees report sales, selling prices and/or unit shipments the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales, estimated unit shipments and estimated ASPs for a particular period may include prior period activity that was not reported by the licensee until such particular period.

[0001234452-17-000026:8k_2_02:34]
| (3) | The first quarter of fiscal 2016 and 2017 are based on sales by our licensees in the September quarter as reported to us in the December quarter, and the fourth quarter of fiscal 2016 is based on sales by our licensees in the June quarter as reported to us in the September quarter. |

[0001234452-17-000026:8k_2_02:35]
Cash and Marketable Securities

[0001234452-17-000026:8k_2_02:36]
Our cash, cash equivalents and marketable securities totaled $29.8 billion at the end of the first quarter of fiscal 2017, compared to $30.6 billion a year ago and $32.4 billion at the end of the fourth quarter of fiscal 2016.

[0001234452-17-000026:8k_2_02:37]
Announced Agreement to Acquire NXP

[0001234452-17-000026:8k_2_02:38]
On October 27, 2016, we announced a definitive agreement to acquire NXP Semiconductors N.V. for estimated total cash to be paid to shareholders of $38 billion.  NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products.  The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions.  We intend to fund the transaction with cash held by foreign entities, which will result in the use of a substantial portion of our cash, cash equivalents and marketable securities, and new debt.

[0001234452-17-000026:8k_2_02:39]
Return of Capital to Stockholders

[0001234452-17-000026:8k_2_02:40]
During the first quarter of fiscal 2017, we returned $1.2 billion to stockholders, including $784 million, or $0.53 per share, of cash dividends paid and $444 million through repurchases of 6.6 million shares of common stock.  On January 12, 2017, we announced a cash dividend of $0.53 per share payable on March 22, 2017 to stockholders of record as of the close of business on March 1, 2017.

[0001234452-17-000026:8k_2_02:41]
Effective Income Tax Rates

[0001234452-17-000026:8k_2_02:42]
Our fiscal 2017 annual effective income tax rates are estimated to be approximately 22 percent for GAAP and 18 percent for Non-GAAP.  The effective income tax rates for the first quarter of fiscal 2017 were 22 percent for GAAP and 19 percent for Non-GAAP.  Our estimated annual and first quarter of fiscal 2017 effective income tax rates for GAAP included the tax impact of the $868 million charge related to the KFTC investigation, which is not deductible for tax purposes.

[0001234452-17-000026:8k_2_02:43]
Business Outlook

[0001234452-17-000026:8k_2_02:44]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment and certain derivative gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001234452-17-000026:8k_2_02:45]
We have not included any estimates related to any proposed joint ventures or acquisitions in our second quarter of fiscal 2017 outlook.

[0001234452-17-000026:8k_2_02:46]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-17-000026:8k_2_02:47]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001234452-17-000026:8k_2_02:48]
|  |  | Q2 FY16 Results | Current Guidance Q2 FY17 Estimates |  |
|  | Revenues | $5.6B | $5.5B - $6.3B |  |  |
|  | Year-over-year change |  | decrease 1% - increase 13% |  |  |
|  | GAAP diluted earnings per share (EPS) | $0.78 | $0.89 - $0.99 |  |  |
|  | Year-over-year change |  | increase 14% - 27% |  |  |
|  | Less diluted EPS attributable to QSI | $0.02 |  | $0.01 |  |  |
|  | Less diluted EPS attributable to share-based compensation | ($0.15) |  | ($0.14 | ) |  |
|  | Less diluted EPS attributable to other items (1) | ($0.13) |  | ($0.13 | ) |  |
|  | Non-GAAP diluted EPS | $1.04 | $1.15 - $1.25 |  |  |
|  | Year-over-year change |  | increase 11% - 20% |  |  |
|  | Metrics |  |  |  |
|  | MSM chip shipments | 189M | 165M - 185M |  |  |
|  | Year-over-year change |  | decrease 2% - 13% |  |  |
|  | Total reported device sales* | approx. $70.1B | approx. $74.0B - $82.0B |  | (2) |
|  | Year-over-year change |  | increase 6% - 17% |  |  |
|  | *Est. sales in December quarter, reported in March quarter |  |  |  |

[0001234452-17-000026:8k_2_02:49]
| (1) | Our guidance for diluted EPS attributable to other items for the second quarter of fiscal 2017 includes losses per share of $0.09 for acquisition-related items, $0.03 due to the recognition of a tax benefit to reconcile the Non-GAAP tax provision to the total GAAP tax provision primarily resulting from the KFTC charge recorded in the first quarter of fiscal 2017 and $0.01 for other items. |

[0001234452-17-000026:8k_2_02:50]
| (2) | Our guidance range for the second quarter of fiscal 2017 total reported device sales reflects estimated 3G/4G total reported device sales that we currently expect to be reported to us, which includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-17-000026:8k_2_02:51]
Sums may not equal total due to rounding.

[0001234452-17-000026:8k_2_02:52]
Reconciliations of GAAP Results to Non-GAAP Results

[0001234452-17-000026:8k_2_02:53]
The following tables reconcile our GAAP results to our Non-GAAP results ($ in millions, except per share data):

[0001234452-17-000026:8k_2_02:54]
|  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) |  | Non-GAAP Results |
| Q1 FISCAL 2017 |  |  |  |  |  |  |  |
| Revenues | $5,999 |  | $14 |  |  | $— |  |  | $— |  |  | $5,985 |  |
| Operating income (loss) | 778 |  | (2) |  | (239) | (1,054) |  | 2,073 |  |
| EBT | 870 |  | (17) |  | (239) | (1,065) |  | 2,191 |  |
| EBT as % of revenues | 15 | % |  |  |  |  |  |  | 37 | % |  |
| Net income (loss) | 682 |  | (11) |  | (190) | (900) |  | 1,783 |  |
| Diluted EPS | $0.46 |  | ($0.01) |  | ($0.13) | ($0.60) |  | $1.19 |  |
| Diluted shares | 1,495 |  | 1,495 |  | 1,495 | 1,495 |  | 1,495 |  |
| Q4 FISCAL 2016 |  |  |  |  |  |  |  |
| Revenues | $6,184 |  | $14 |  |  | $— |  |  | $— |  |  | $6,170 |  |
| Operating income (loss) | 1,804 |  | (1) |  | (213) | (158) |  | 2,176 |  |
| EBT | 1,960 |  | (14) |  | (213) | (158) |  | 2,345 |  |
| EBT as % of revenues | 32 | % |  |  |  |  |  |  | 38 | % |  |
| Net income (loss) | 1,599 |  | (9) |  | (150) | (147) |  | 1,905 |  |
| Diluted EPS | $1.07 |  | ($0.01) |  | ($0.10) | ($0.10) |  | $1.28 |  |
| Diluted shares | 1,491 |  | 1,491 |  | 1,491 | 1,491 |  | 1,491 |  |
| Q1 FISCAL 2016 |  |  |  |  |  |  |  |
| Revenues | $5,775 |  | $9 |  |  | $— |  |  | $— |  |  | $5,766 |  |
| Operating income (loss) | 1,685 |  | 372 |  | (247) | (181) |  | 1,741 |  |
| EBT | 1,710 |  | 359 |  | (247) | (181) |  | 1,779 |  |
| EBT as % of revenues | 30 | % |  |  |  |  |  |  | 31 | % |  |
| Net income (loss) | 1,498 |  | 234 |  | (187) | (18) |  | 1,469 |  |
| Diluted EPS | $0.99 |  | $0.15 |  | ($0.12) | ($0.01) |  | $0.97 |  |
| Diluted shares | 1,517 |  | 1,517 |  | 1,517 | 1,517 |  | 1,517 |  |

[0001234452-17-000026:8k_2_02:55]
| (a) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” herein for further details. |

[0001234452-17-000026:8k_2_02:56]
| (b) | Details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates.” Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001234452-17-000026:8k_2_02:57]
Sums may not equal totals due to rounding.

[0001234452-17-000026:8k_2_02:58]
Supplemental Information and Reconciliations

[0001234452-17-000026:8k_2_02:59]
(Unaudited)

[0001234452-17-000026:8k_2_02:60]
|  | Q1 FISCAL 2017 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results |
|  | Cost of revenues |  | $2,443 |  |  | $13 |  |  | $9 |  |  | $84 |  |  | $2,337 |  |
|  | Research and development expenses |  | 1,311 |  |  | — |  |  |  | 153 |  |  | 33 |  |  | 1,125 |  |
|  | Selling, general and administrative expenses |  | 591 |  |  | 3 |  |  | 77 |  |  | 61 |  |  | 450 |  |
|  | Other expenses |  | 876 |  |  | — |  |  |  | — |  |  |  | 876 |  |  | — |  |  |
|  | Interest expense |  | 90 |  |  | — |  |  |  | — |  |  |  | 11 |  |  | 79 |  |
|  | Investment income (loss), net |  | 182 |  |  | (15) | (b) |  | — |  |  |  | — |  |  |  | 197 | (c) |

[0001234452-17-000026:8k_2_02:61]
| (a) | Other items excluded from Non-GAAP EBT included an $868 million charge, which was accrued, related to the KFTC investigation, $159 million of acquisition-related charges, $30 million of impairment charges and $8 million of restructuring and restructuring-related charges related to our Strategic Realignment Plan. |

[0001234452-17-000026:8k_2_02:62]
| (b) | Included $21 million in other-than-temporary losses on investments, partially offset by $6 million in other net investment income. |

[0001234452-17-000026:8k_2_02:63]
| (c) | Included $163 million in interest and dividend income, $144 million in net realized gains on investments and $12 million in other net investment income, partially offset by $122 million in other-than-temporary losses on investments. |

[0001234452-17-000026:8k_2_02:64]
Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates

[0001234452-17-000026:8k_2_02:65]
(Unaudited)

[0001234452-17-000026:8k_2_02:66]
|  |  | GAAP Results |  |  | Less QSI |  | Less Share-Based Compensation |  | Less Other Items (c)(d) |  |  | Non-GAAP Results |  |
| Q1 FISCAL 2017 ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 870 |  |  |  | $ | (17 | ) |  |  | $ | (239 | ) |  |  | $ | (1,065 | ) |  |  | $ | 2,191 |  |  |
| Income tax (expense) benefit |  | (189 | ) |  |  | 5 |  |  |  | 49 |  |  |  | 165 |  |  |  | (408 | ) |  |
| Net income (loss) (a) |  | $ | 681 |  |  |  | $ | (12 | ) |  |  | $ | (190 | ) |  |  | $ | (900 | ) |  |  | $ | 1,783 |  |  |
| Tax rate |  | 22 | % |  |  | 0 | % | (b) |  |  |  | 0 | % | (b) |  |  | 3 | % | (b) |  |  | 19 | % |  |
| FISCAL 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Estimated annual tax rate |  | 22 | % |  |  | 0 | % | (b) |  |  |  | 0 | % | (b) |  |  |  | 4 | % | (b) |  |  |  | 18 | % |  |

[0001234452-17-000026:8k_2_02:67]
| (a) | Before adjustments for noncontrolling interests. |

[0001234452-17-000026:8k_2_02:68]
| (b) | The incremental effect of our adjustments to the Non-GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001234452-17-000026:8k_2_02:69]
| (c) | In the first quarter of fiscal 2017, the tax benefit in the “Other Items” column included tax benefits of $130 million to reconcile the tax provision for each column to the total GAAP tax provision for the quarter primarily due to the impact of the charge related to the KFTC investigation, $16 million for the tax effect of acquisition-related items in EBT and $19 million for the combined tax effect of other items in EBT. |

[0001234452-17-000026:8k_2_02:70]
| (d) | In fiscal 2017, the estimated annual effective tax rate for the “Other Items” column includes tax benefits of $56 million for the tax effect of acquisition-related items in EBT and $19 million for the combined tax effect of other items in EBT. |

[0001234452-17-000026:8k_2_02:71]
Conference Call

[0001234452-17-000026:8k_2_02:72]
Qualcomm’s fiscal first quarter 2017 earnings conference call will be broadcast live on January 25, 2017, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 48860663.

[0001234452-17-000026:8k_2_02:73]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-17-000026:8k_2_02:74]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-17-000026:8k_2_02:75]
The Company uses the Non-GAAP financial information:  (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and

[0001234452-17-000026:8k_2_02:76]
efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial information also is used by institutional investors and analysts in evaluating the Company’s business and assessing trends and future expectations.

[0001234452-17-000026:8k_2_02:77]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items, tax items and other items.

[0001234452-17-000026:8k_2_02:78]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-17-000026:8k_2_02:79]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001234452-17-000026:8k_2_02:80]
| • | Certain other items are excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001234452-17-000026:8k_2_02:81]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items, as well as any tax effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property, third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition. |

[0001234452-17-000026:8k_2_02:82]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and litigation settlements and/or damages. |

[0001234452-17-000026:8k_2_02:83]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. |

[0001234452-17-000026:8k_2_02:84]
About Qualcomm

[0001234452-17-000026:8k_2_02:85]
Qualcomm’s technologies powered the smartphone revolution and connected billions of people.  We pioneered 3G and 4G - and now we are leading the way to 5G and a new era of intelligent, connected devices.  Our products are revolutionizing industries, including automotive, computing, IoT, healthcare and data center, and are allowing millions of devices to connect with each other in ways never before imagined.  Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, all of our engineering, research and development functions, and all of our products and services businesses, including, our QCT semiconductor business.  For more information, visit www.qualcomm.com.

[0001234452-17-000026:8k_2_02:86]
Note Regarding Forward-Looking Statements

[0001234452-17-000026:8k_2_02:87]
###

[0001234452-17-000026:8k_2_02:88]
Qualcomm, Snapdragon and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-17-000026:8k_2_02:89]
Qualcomm Snapdragon and MSM are products of Qualcomm Technologies, Inc.

[0001234452-17-000026:8k_2_02:90]
Qualcomm Incorporated

[0001234452-17-000026:8k_2_02:91]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001234452-17-000026:8k_2_02:92]
(In millions, except per share data)

[0001234452-17-000026:8k_2_02:93]
(Unaudited)

[0001234452-17-000026:8k_2_02:94]
|  | December 25, 2016 |  | September 25, 2016 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 6,885 |  |  | $ | 5,946 |  |
| Marketable securities | 3,927 |  |  | 12,702 |  |
| Accounts receivable, net | 2,085 |  |  | 2,219 |  |
| Inventories | 1,910 |  |  | 1,556 |  |
| Other current assets | 972 |  |  | 558 |  |
| Total current assets | 15,779 |  |  | 22,981 |  |
| Marketable securities | 18,973 |  |  | 13,702 |  |
| Deferred tax assets | 2,312 |  |  | 2,030 |  |
| Property, plant and equipment, net | 2,270 |  |  | 2,306 |  |
| Goodwill | 5,686 |  |  | 5,679 |  |
| Other intangible assets, net | 3,338 |  |  | 3,500 |  |
| Other assets | 4,008 |  |  | 2,161 |  |
| Total assets | $ | 52,366 |  |  | $ | 52,359 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,648 |  |  | $ | 1,858 |  |
| Payroll and other benefits related liabilities | 865 |  |  | 934 |  |
| Unearned revenues | 487 |  |  | 509 |  |
| Short-term debt | 1,749 |  |  | 1,749 |  |
| Other current liabilities | 3,245 |  |  | 2,261 |  |
| Total current liabilities | 7,994 |  |  | 7,311 |  |
| Unearned revenues | 2,278 |  |  | 2,377 |  |
| Long-term debt | 9,935 |  |  | 10,008 |  |
| Other liabilities | 953 |  |  | 895 |  |
| Total liabilities | 21,160 |  |  | 20,591 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,478 and 1,476 shares issued and outstanding, respectively | 214 |  |  | 414 |  |
| Retained earnings | 30,815 |  |  | 30,936 |  |
| Accumulated other comprehensive income | 186 |  |  | 428 |  |
| Total Qualcomm stockholders’ equity | 31,215 |  |  | 31,778 |  |
| Noncontrolling interests | (9 | ) |  | (10 | ) |
| Total stockholders’ equity | 31,206 |  |  | 31,768 |  |
| Total liabilities and stockholders’ equity | $ | 52,366 |  |  | $ | 52,359 |  |

[0001234452-17-000026:8k_2_02:95]
Qualcomm Incorporated

[0001234452-17-000026:8k_2_02:96]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-17-000026:8k_2_02:97]
(In millions, except per share data)

[0001234452-17-000026:8k_2_02:98]
(Unaudited)

[0001234452-17-000026:8k_2_02:99]
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |
| Revenues: |  |  |  |
| Equipment and services | $ | 4,139 |  |  | $ | 4,087 |  |
| Licensing | 1,860 |  |  | 1,688 |  |
| Total revenues | 5,999 |  |  | 5,775 |  |
| Costs and expenses: |  |  |  |
| Cost of revenues | 2,443 |  |  | 2,534 |  |
| Research and development | 1,311 |  |  | 1,352 |  |
| Selling, general and administrative | 591 |  |  | 578 |  |
| Other | 876 |  |  | (374 | ) |
| Total costs and expenses | 5,221 |  |  | 4,090 |  |
| Operating income | 778 |  |  | 1,685 |  |
| Interest expense | (90 | ) |  | (74 | ) |
| Investment income, net | 182 |  |  | 99 |  |
| Income before income taxes | 870 |  |  | 1,710 |  |
| Income tax expense | (189 | ) |  | (214 | ) |
| Net income | 681 |  |  | 1,496 |  |
| Net loss attributable to noncontrolling interests | 1 |  |  | 2 |  |
| Net income attributable to Qualcomm | $ | 682 |  |  | $ | 1,498 |  |
| Basic earnings per share attributable to Qualcomm | $ | 0.46 |  |  | $ | 1.00 |  |
| Diluted earnings per share attributable to Qualcomm | $ | 0.46 |  |  | $ | 0.99 |  |
| Shares used in per share calculations: |  |  |  |
| Basic | 1,478 |  |  | 1,502 |  |
| Diluted | 1,495 |  |  | 1,517 |  |
| Dividends per share announced | $ | 0.53 |  |  | $ | 0.48 |  |

[0001234452-17-000026:8k_2_02:100]
Qualcomm Incorporated

[0001234452-17-000026:8k_2_02:101]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-17-000026:8k_2_02:102]
(In millions)

[0001234452-17-000026:8k_2_02:103]
(Unaudited)

[0001234452-17-000026:8k_2_02:104]
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |
| Operating Activities: |  |  |  |
| Net income | $ | 681 |  |  | $ | 1,496 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization expense | 329 |  |  | 364 |  |
| Indefinite and long-lived asset impairment charges | 32 |  |  | 2 |  |
| Income tax provision less than income tax payments | (113 | ) |  | (103 | ) |
| Gain on sale of wireless spectrum | — |  |  | (380 | ) |
| Non-cash portion of share-based compensation expense | 239 |  |  | 247 |  |
| Incremental tax benefits from share-based compensation | (35 | ) |  | (2 | ) |
| Net realized gains on marketable securities and other investments | (147 | ) |  | (49 | ) |
| Impairment losses on marketable securities and other investments | 143 |  |  | 63 |  |
| Other items, net | (4 | ) |  | (13 | ) |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable, net | 131 |  |  | 646 |  |
| Inventories | (354 | ) |  | 291 |  |
| Other assets | (16 | ) |  | 66 |  |
| Trade accounts payable | (208 | ) |  | 50 |  |
| Payroll, benefits and other liabilities | 785 |  |  | 98 |  |
| Unearned revenues | (84 | ) |  | (37 | ) |
| Net cash provided by operating activities | 1,379 |  |  | 2,739 |  |
| Investing Activities: |  |  |  |
| Capital expenditures | (129 | ) |  | (128 | ) |
| Purchases of available-for-sale marketable securities | (4,117 | ) |  | (3,737 | ) |
| Proceeds from sales and maturities of available-for-sale marketable securities | 6,891 |  |  | 3,113 |  |
| Purchases of trading securities | — |  |  | (149 | ) |
| Proceeds from sales and maturities of trading securities | — |  |  | 121 |  |
| Proceeds from sales of other marketable securities | — |  |  | 200 |  |
| Deposit of investments designated as collateral | (1,950 | ) |  | — |  |
| Acquisitions and other investments, net of cash acquired | (57 | ) |  | (450 | ) |
| Proceeds from sale of wireless spectrum | — |  |  | 232 |  |
| Other items, net | 43 |  |  | 82 |  |
| Net cash provided (used) by investing activities | 681 |  |  | (716 | ) |
| Financing Activities: |  |  |  |
| Proceeds from short-term debt | 2,727 |  |  | 1,089 |  |
| Repayment of short-term debt | (2,727 | ) |  | (1,090 | ) |
| Proceeds from issuance of common stock | 131 |  |  | 99 |  |
| Repurchases and retirements of common stock | (444 | ) |  | (2,050 | ) |
| Dividends paid | (784 | ) |  | (717 | ) |
| Incremental tax benefits from share-based compensation | 35 |  |  | 2 |  |
| Other items, net | (42 | ) |  | 2 |  |
| Net cash used by financing activities | (1,104 | ) |  | (2,665 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (17 | ) |  | (5 | ) |
| Net increase (decrease) in cash and cash equivalents | 939 |  |  | (647 | ) |
| Cash and cash equivalents at beginning of period | 5,946 |  |  | 7,560 |  |
| Cash and cash equivalents at end of period | $ | 6,885 |  |  | $ | 6,913 |  |
