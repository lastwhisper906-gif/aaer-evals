# QCOM note change history — 0001234452-16-000483 → 0001234452-17-000028


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2017-01-25):
[0001234452-17-000028:note_history:1]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe certain ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 ParkerVision patents and seeks damages and injunctive and other relief. On September 25, 2015, ParkerVision filed a motion with the court to sever some claims against the Company and all other defendants into a separate lawsuit. In addition, on December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against the Company and other parties with the United States International Trade Commission (ITC) described below.

- added (2017-01-25):
[0001234452-17-000028:note_history:2]
On December 14, 2015, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. are also named defendants. The complaint asserts that certain of the Company’s products infringe four additional ParkerVision patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. The ITC hearing is scheduled to begin on March 13, 2017. The ITC’s target date for completion of the investigation is October 23, 2017. The District Court case was stayed on February 12, 2016 pending completion of the ITC investigation.

- added (2017-01-25):
[0001234452-17-000028:note_history:3]
The Company believes ParkerVision’s claims in the above matters are without merit.

- added (2017-01-25):
[0001234452-17-000028:note_history:4]
QUALCOMM Incorporated v. Meizu Technology Co., Ltd. et al: On June 23, 2016 and June 29, 2016, the Company filed a series of actions against Meizu Technology Co., Ltd., aka Zhuhai Meizu Technology Co., Ltd. (Meizu) and certain of its distributors in the Intellectual Property Courts in Beijing and Shanghai (China). The first complaint, filed in Beijing on June 23, 2016, requests rulings that the terms of a patent license offered by the Company to Meizu comply with China’s Anti-Monopoly Law and the Company’s applicable fair, reasonable and non-discriminatory licensing commitment. The complaint also seeks a ruling that the offered patent license terms should form the basis for a patent license with Meizu for the Company’s fundamental mobile device technologies patented in China, including those relating to 3G (WCDMA and CDMA2000) and 4G (LTE) wireless communications standards, and seeks damages for Meizu’s past use of the Company’s patented inventions. On June 29, 2016, the Company filed patent infringement complaints in the Intellectual Property Courts in Beijing and Shanghai alleging infringement of 17 patents by Meizu. The patent infringement actions concern a broad range of features and technologies used in smartphones, including features relating to 3G (WCDMA and CDMA2000) and 4G (LTE) wireless communications standards, and seek to enjoin Meizu from manufacturing, selling and offering for sale mobile devices that infringe the asserted patents. The courts are currently considering various jurisdictional challenges raised by Meizu. No final schedules have been set by the courts. Meizu has also filed actions before China’s Patent Reexamination Board challenging the validity of each of the asserted patents. These actions are proceeding in parallel with the litigation.

- added (2017-01-25):
[0001234452-17-000028:note_history:5]
On October 14, 2016, the Company filed patent infringement complaints against Meizu in the United States ITC and the Mannheim Regional Court in Germany. The ITC complaint seeks an exclusion order enjoining Meizu and certain of its distributors from the importation, sale for importation and sale after importation of Meizu mobile devices that infringe certain of the Company’s patents related to semiconductor, radio frequency and digital camera technologies. The German complaint seeks damages and to enjoin Meizu from offering, putting into circulation, using, possessing or importing into Germany mobile devices that infringe one of the Company’s patents related to wireless messaging technology. On the same day, the Company also initiated a seizure action in France pursuant to orders from the Paris District Court to obtain evidence for a possible future infringement action in that country.

- added (2017-01-25):
[0001234452-17-000028:note_history:6]
On December 26, 2016, the Company and Meizu entered into a patent license agreement whereby the Company granted Meizu a worldwide royalty-bearing patent license to develop, manufacture and sell CDMA2000, WCDMA and 4G LTE (including “3-mode” GSM, TD-SCDMA and LTE-TDD) complete devices. This agreement resolves all of the patent disputes between the Company and Meizu in China, Germany, France and the United States. Accordingly, the Company and Meizu have agreed to take appropriate steps to terminate or withdraw all of the foregoing complaints and actions.

- added (2017-01-25):
[0001234452-17-000028:note_history:7]
Apple Inc. (Apple) v. Qualcomm Incorporated: On January 20, 2017, Apple filed a complaint against the Company in the United States District Court for the Southern District of California seeking declarations with respect to several of the Company’s patents and alleging that the Company breached certain agreements and violated federal antitrust and California state unfair competition laws. In particular, Apple seeks declaratory judgments of non-infringement by Apple of nine of the Company’s patents, or in the alternative, a declaration of royalties Apple must pay for the patents. Apple further seeks a declaration that the Company’s sale of baseband chipsets exhausts the Company’s patent rights for patents embodied in those chipsets. Separately, Apple seeks to enjoin the Company from seeking excessive royalties from Apple and to disgorge royalties paid by Apple’s contract manufacturers that the court finds were not fair, reasonable and non-discriminatory. Apple also claims the Company’s refusal to make certain payments to Apple under a Business Cooperation and Patent Agreement constitutes a breach of contract in violation of California law and seeks damages in the amount of the unpaid payments, alleged to be approximately $1 billion. In addition, Apple claims that the Company has refused to deal with competitors in contravention of the Company’s agreements with applicable standard setting organizations, has used its market position to impose contractual obligations on Apple that prevented Apple from challenging the Company’s licensing practices, has tied the purchase of the Company’s CDMA-enabled and premium LTE-enabled chipsets to licensing certain of the Company’s patents and has required Apple to purchase baseband processor chipsets exclusively from the Company as a condition of the Company’s payment to Apple of certain rebates, in violation of Section 2 of the Sherman Act and the California Unfair Competition Law. Apple seeks injunctive relief with respect to these claims and a judgment awarding its expenses, costs and attorneys’ fees.

- added (2017-01-25):
[0001234452-17-000028:note_history:8]
On January 25, 2017, the Company learned that an Apple subsidiary, Apple Electronic Products Trading (Beijing) Co., Ltd. (collectively with Apple Inc., Apple), has also filed two complaints against the Company and certain of the Company’s subsidiaries in the Beijing Intellectual Property Court in China. The Company has not yet been served with the complaints. Based on a press release from the Court, the Company understands that one of the complaints alleges a violation of China’s Anti-Monopoly Law (AML), and the other requests a determination of the terms of a patent license between the Company and Apple. In particular, the AML complaint alleges that the Company has abused its dominant position in communication standards-essential patents (SEPs) licensing markets and the global baseband chipset market by offering royalty terms that were excessively high; that the Company refused to license certain implementers of standardized technologies; that the Company restricted Apple to using only products and services provided or approved by the Company; and that the Company engaged in other bundling and discriminatory conduct and imposed unreasonable trading terms on Apple in violation of the AML. Apple seeks economic damages in the amount of 1 billion Chinese Renminbi (approximately $145 million based on current exchange rates). The other complaint alleges that the Company refused to provide a royalty offer to Apple for the Company’s cellular SEPs consistent with the Company’s fair, reasonable and non-discriminatory (FRAND) licensing commitments. Apple has requested the Court make a determination of the terms of a patent license between the Company and Apple consistent with the Company’s FRAND obligations. Apple also seeks its expenses in each of the cases.

- added (2017-01-25):
[0001234452-17-000028:note_history:9]
The Company believes Apple’s claims in the above matters are without merit.

- changed (2017-01-25):
[0001234452-17-000028:note_history:10]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, plaintiffs filed a securities class action complaint against the Company and certain of its current and former officers in the United States District Court for the Southern District of California. On April 29, 2016, plaintiffs filed an amended complaint alleging that the Company and certain of its current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding the Company’s business outlook and product development between April 7, 2014 and July 22, 2015. The amended complaint seeks unspecified damages, interest, attorneys’ fees and other costs. On June 28, 2016, the Company filed a Motion to Dismiss the amended complaint, which Motion was heard by the Court on November 7, 2016. The Company believes the plaintiffs’ claims are without merit.
  (was, 2016-07-20, similarity 0.8969):
[0001234452-16-000483:note_history:10]
3226701 Canada, Inc. v. Qualcomm Incorporated et al. On November 30, 2015, plaintiffs filed a securities class action complaint against the Company and certain of its current and former officers in the United States District Court for the Southern District of California. On April 29, 2016, plaintiffs filed an amended complaint alleging that the Company and certain of its current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding the Company’s business outlook and product development between April 7, 2014 and July 22, 2015. The amended complaint seeks unspecified damages, interest, attorneys’ fees and other costs. On June 28, 2016, the Company filed a Motion to Dismiss. The Company believes the plaintiffs’ claims are without merit.

- added (2017-01-25):
[0001234452-17-000028:note_history:11]
Bornstein et al. v. QUALCOMM Incorporated: On January 18, 2017, a complaint was filed against the Company in the United States District Court for the Northern District of California on behalf of a putative class of purchasers of cellular phones and other cellular devices alleging that the Company violated various federal and state antitrust and consumer protection laws by, among other things, refusing to license standard-essential patents to its competitors, conditioning the supply of certain of its baseband processors on the purchaser first agreeing to license the Company’s entire patent portfolio, entering into alleged exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that allegedly do not comply with the Company’s commitments to standard-setting organizations. The complaint further alleges that, as a result of the foregoing conduct, the Company was unjustly enriched. The complaint seeks unspecified damages, interest, attorneys’ fees and other costs, and that the Company and related parties be enjoined from further unlawful conduct. The Company believes the plaintiffs’ claims are without merit.

- changed (2017-01-25):
[0001234452-17-000028:note_history:12]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 34 different dates, with the next hearing scheduled for April 24, 2017.
  (was, 2016-07-20, similarity 0.9956):
[0001234452-16-000483:note_history:12]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 33 different dates, with the next hearing scheduled for January 17, 2017.

- changed (2017-01-25):
[0001234452-17-000028:note_history:13]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments since then with respect to this matter.
  (was, 2016-07-20, similarity 0.9824):
[0001234452-16-000483:note_history:13]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments during fiscal 2016 with respect to this matter.

- added (2017-01-25):
[0001234452-17-000028:note_history:14]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it was conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that the Company has violated provisions of the MRFTA. On January 22, 2017, the Company received the KFTC’s formal written decision, which finds that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with the Company; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders the Company to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chips; (iii) not demand unjustifiable conditions in the Company’s license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on the Company and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between the Company and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposes a fine of approximately 1.03 trillion Korean Won (approximately $868 million based on exchange rates at December 25, 2016), which was recorded as a charge to other expenses in the first quarter of fiscal 2017. The Company believes that its business practices do not violate the MRFTA, and intends to challenge the decision in the Seoul High Court. The Company will also seek a stay of the decision’s remedial order.

- changed (2017-01-25):
[0001234452-17-000028:note_history:15]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company provided additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On August 15, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.
  (was, 2016-07-20, similarity 0.7366):
[0001234452-16-000483:note_history:15]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company provided additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

- added (2017-01-25):
[0001234452-17-000028:note_history:16]
(United States) Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified the Company that it was conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against the Company in the United States District Court for the Northern District of California alleging that the Company engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of baseband processors on the purchaser first agreeing to a license to the Company’s standard-essential patents, paying incentives to purchasers of baseband processors to induce them to accept certain license terms, refusing to license its standard-essential patents to the Company’s competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint seeks a permanent injunction against the Company’s alleged violations of the FTCA and other unspecified ancillary equitable relief. The Company believes the FTC’s claims are without merit.

- added (2017-01-25):
[0001234452-17-000028:note_history:17]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. Other than with respect to the KFTC Investigation, the Company has not recorded any accrual at December 25, 2016 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

- changed (2017-01-25):
[0001234452-17-000028:note_history:18]
Through December 25, 2016, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at December 25, 2016 associated with these indemnification arrangements based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.
  (was, 2016-07-20, similarity 0.9628):
[0001234452-16-000483:note_history:18]
Through June 26, 2016, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at June 26, 2016 associated with these indemnification arrangements, other than nominal amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- added (2017-01-25):
[0001234452-17-000028:note_history:19]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at December 25, 2016 for the remainder of fiscal 2017 and for each of the subsequent four years from fiscal 2018 through 2021 were $3.7 billion, $879 million, $771 million, $230 million and $42 million, respectively, and $5 million thereafter. Of these amounts, for the remainder of fiscal 2017 and for each of the subsequent three years from fiscal 2018 through 2020, commitments to purchase integrated circuit product inventories comprised $2.9 billion, $761 million, $696 million, $165 million, respectively, and there were no purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

- changed (2017-01-25):
[0001234452-17-000028:note_history:20]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments at December 25, 2016 for the remainder of fiscal 2017 and for each of the subsequent four years from fiscal 2018 through 2021 were $67 million, $77 million, $63 million, $46 million and $38 million, respectively, and $47 million thereafter.
  (was, 2016-07-20, similarity 0.8717):
[0001234452-16-000483:note_history:20]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments at June 26, 2016 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $23 million, $89 million, $64 million, $50 million and $38 million, respectively, and $90 million thereafter.

- changed (2017-01-25):
[0001234452-17-000028:note_history:21]
Other Commitments. At December 25, 2016, the Company was committed to fund certain strategic investments up to $349 million. Of this amount, $113 million is expected to be funded in the remainder of fiscal 2017. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.
  (was, 2016-07-20, similarity 0.9844):
[0001234452-16-000483:note_history:21]
Other Commitments. At June 26, 2016, the Company was committed to fund certain strategic investments up to $316 million. Of this amount, $85 million is expected to be funded in the remainder of fiscal 2016. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.

- removed (2017-01-25):
[0001234452-16-000483:note_history:22]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringed seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims were invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict and denied ParkerVision’s motions for injunctive relief and ongoing royalties as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit heard the appeal on May 8, 2015 and issued a decision on July 31, 2015. The decision affirmed the District Court’s finding of non-infringement and granted in part the Company’s cross-appeal, holding 10 of the 11 asserted claims invalid. A subsequent Petition for Rehearing by ParkerVision was denied on October 2, 2015. On February 29, 2016, ParkerVision filed a petition for certiorari with the United States Supreme Court asking for review of the Federal Circuit’s decision. On March 28, 2016, the United States Supreme Court denied ParkerVision’s petition. No further appeals are available to ParkerVision in this matter.

- removed (2017-01-25):
[0001234452-16-000483:note_history:23]
On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the complaint, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. On September 25, 2015, ParkerVision filed a motion with the court to sever some claims against the Company and all other defendants into a separate lawsuit. In addition, on December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against the Company and other parties with the United States International Trade Commission (ITC) described below.

- removed (2017-01-25):
[0001234452-16-000483:note_history:24]
On December 14, 2015, ParkerVision filed a third complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. are also named defendants. The complaint asserts four additional patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. The ITC scheduled a hearing to begin on August 24, 2016. The ITC’s target date for completion of the investigation is April 21, 2017. The District Court case was stayed on February 12, 2016 pending completion of the ITC investigation. The Company believes ParkerVision’s claims in the above matters are without merit.

- removed (2017-01-25):
[0001234452-16-000483:note_history:25]
Nvidia Corporation v. QUALCOMM Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd. and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia sought an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chipset products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District Court complaint, Nvidia sought an award of damages for the infringement of the asserted patents, a finding that such infringement was willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. Nvidia later narrowed the ITC case to three asserted patents. On October 9, 2015, the Administrative Law Judge in the ITC case issued an Initial Determination finding no violation of Section 337 because none of the three patents were both valid and infringed. On October 26, 2015, Nvidia filed a petition requesting the ITC to review the Initial Determination as to two of the asserted patents, but was no longer pursuing infringement allegations with respect to the third patent. On December 14, 2015, the ITC issued its decision not to review the Initial Determination of the Administrative Law Judge. This made final the determination that the Company did not violate Section 337. Therefore, neither an exclusion order nor a cease and desist order were issued. On February 17, 2016, Nvidia filed a notice of appeal of the ITC’s determination to the United States Court of Appeals for the Federal Circuit. The District Court case was stayed on October 23, 2014 pending completion of the ITC investigation, including appeals. Nvidia has since entered into a confidential settlement agreement with Samsung and dismissed the above actions against Samsung and the Company, including its appeal of the ITC’s determination (dismissed May 11, 2016) and the District Court case (dismissed May 12, 2016).

- removed (2017-01-25):
[0001234452-16-000483:note_history:26]
LG Electronics, Inc. (LGE) Arbitration: In December 2015, LGE filed an arbitration demand with the International Chamber of Commerce (ICC) alleging that it overpaid royalties on certain CDMA (including WCDMA) subscriber units based on the alleged effect of specific provisions in its license agreement, and that the Company breached its license agreement with LGE, as well as certain implied covenants. The arbitration demand sought determination and return of the overpayment and determination of the ongoing royalties owed by LGE. On April 16, 2016, the parties entered into agreements pursuant to which the parties agreed to settle the disputes raised by LGE in its arbitration demand, and LGE agreed to dismiss the arbitration with prejudice and release all claims brought in the arbitration against the Company. On April 18, 2016, the parties jointly moved for dismissal of the arbitration, and on April 19, 2016, the ICC acknowledged the motion for dismissal and the withdrawal of all claims. Although the Company believed LGE’s claims were without merit, it deferred the recognition of revenue related to CDMA subscriber unit royalties reported and paid by LGE in the first and second quarters of fiscal 2016 because, among other reasons, the matter was submitted to arbitration for resolution. As a result of the settlement, commencing with the third quarter of fiscal 2016, the Company is no longer deferring royalty revenues reported by LGE and recorded $235 million of revenues related to prior periods.

- removed (2017-01-25):
[0001234452-16-000483:note_history:27]
QUALCOMM Incorporated v. Meizu Technology Co., Ltd.: On June 23, 2016 and June 29, 2016, the Company filed a series of actions against Meizu Technology Co., Ltd. et al. (Meizu) in the Intellectual Property Courts in Beijing and Shanghai (China). The first complaint, filed in Beijing on June 23, 2016, requests rulings that the terms of a patent license offered by the Company to Meizu comply with China’s Anti-Monopoly Law and the Company’s applicable fair, reasonable and non-discriminatory licensing commitment. The complaint also seeks a ruling that the offered patent license terms should form the basis for a patent license with Meizu for the Company’s fundamental mobile device technologies patented in China, including those relating to 3G (WCDMA and CDMA2000) and 4G (LTE) wireless communications standards, and seeks damages for Meizu’s past use of the Company’s patented inventions. On June 29, 2016, the Company filed patent infringement complaints in the Intellectual Property Courts in Beijing and Shanghai alleging infringement of 17 patents by Zhuhai Meizu Technology Co., Ltd. et al. (Zhuhai Meizu). The patent infringement actions concern a broad range of features and technologies used in smartphones, including features relating to 3G (WCDMA and CDMA2000) and 4G (LTE) wireless communications standards, and seek to enjoin Zhuhai Meizu from manufacturing, selling and offering for sale mobile devices that infringe the asserted patents. No schedules have yet been set by the courts.

- removed (2017-01-25):
[0001234452-16-000483:note_history:28]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it is conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On November 13, 2015, the Company received a case Examiner’s Report (ER) prepared by the KFTC’s investigative staff. The ER alleges, among other things, that the Company is in violation of Korean competition law by licensing its patents exhaustively only to device manufacturers and requiring that its chipset customers be licensed to the Company’s intellectual property. The ER also alleges that the Company obtains certain terms, including royalty terms, that are unfair or unreasonable in its license agreements through negotiations that do not conform to Korean competition law. The ER proposes remedies including modifications to certain business practices and monetary penalties. On May 27, 2016, the Company submitted a written response to the ER. The KFTC is holding hearings, which commenced on July 20, 2016. It remains difficult to predict the outcome of this matter. The Company believes that its business practices do not violate the MRFTA. The Company continues to cooperate with the KFTC as it conducts its investigation.

- removed (2017-01-25):
[0001234452-16-000483:note_history:29]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act (FTCA). The FTC has notified the Company that it is investigating conduct related to standard essential patents and pricing and contracting practices with respect to baseband processors and related products. If a violation of Section 5 is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company believes that its business practices do not violate the FTCA. The Company continues to cooperate with the FTC as it conducts its investigation.

- removed (2017-01-25):
[0001234452-16-000483:note_history:30]
The Company will continue to vigorously defend itself in the foregoing matters in which it is a defendant and which remain outstanding. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at June 26, 2016 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

- removed (2017-01-25):
[0001234452-16-000483:note_history:31]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at June 26, 2016 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $3.0 billion, $1.2 billion, $782 million, $702 million and $206 million, respectively, and $50 million thereafter. Of these amounts, for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020, commitments to purchase integrated circuit product inventories comprised $2.6 billion, $979 million, $700 million, $647 million and $157 million, respectively, and there were no purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancellation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancellation, and in some cases, incremental fees related to capacity underutilization.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-01-25):
[0001234452-17-000028:note_history:32]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 25, 2016. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month periods ended December 25, 2016 and December 27, 2015 included 13 weeks, respectively.
  (was, 2016-07-20, similarity 0.9589):
[0001234452-16-000483:note_history:32]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 27, 2015. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 26, 2016 and June 28, 2015 included 13 weeks and 39 weeks, respectively.

- changed (2017-01-25):
[0001234452-17-000028:note_history:33]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in the Company’s condensed consolidated financial statements and the accompanying notes. Actual results could differ from those estimates.
  (was, 2016-07-20, similarity 0.8742):
[0001234452-16-000483:note_history:33]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in the Company’s condensed consolidated financial statements and the accompanying notes. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

- changed (2017-01-25):
[0001234452-17-000028:note_history:34]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, in the three months ended December 25, 2016 and December 27, 2015 were 17,029,000 and 14,430,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 62,000 and 1,172,000 in the three months ended December 25, 2016 and December 27, 2015, respectively.
  (was, 2016-07-20, similarity 0.7426):
[0001234452-16-000483:note_history:34]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the sum of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 26, 2016 were 14,812,000 and 13,325,000, respectively, and 20,749,000 and 22,447,000 for the three and nine months ended June 28, 2015, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 1,378,000 and 3,150,000 during the three and nine months ended June 26, 2016, respectively, and 16,711,000 and 6,067,000 during the three and nine months ended June 28, 2015, respectively.

- changed (2017-01-25):
[0001234452-17-000028:note_history:35]
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |
| Cost of equipment and services revenues | $ | 9 |  |  | $ | 10 |  |
| Research and development | 153 |  |  | 165 |  |
| Selling, general and administrative | 77 |  |  | 72 |  |
| Share-based compensation expense before income taxes | 239 |  |  | 247 |  |
| Related income tax benefit | (49 | ) |  | (60 | ) |
|  | $ | 190 |  |  | $ | 187 |  |
  (was, 2016-07-20, similarity 0.7133):
[0001234452-16-000483:note_history:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26, 2016 |  | June 28, 2015 |  | June 26, 2016 |  | June 28, 2015 |
| Cost of equipment and services revenues | $ | 10 |  |  | $ | 10 |  |  | $ | 31 |  |  | $ | 33 |  |
| Research and development | 152 |  |  | 176 |  |  | 478 |  |  | 508 |  |
| Selling, general and administrative | 73 |  |  | 85 |  |  | 221 |  |  | 252 |  |
| Share-based compensation expense before income taxes | 235 |  |  | 271 |  |  | 730 |  |  | 793 |  |
| Related income tax benefit | (38 | ) |  | (58 | ) |  | (126 | ) |  | (145 | ) |
|  | $ | 197 |  |  | $ | 213 |  |  | $ | 604 |  |  | $ | 648 |  |

- added (2017-01-25):
[0001234452-17-000028:note_history:36]
At December 25, 2016, total unrecognized compensation expense related to nonvested restricted stock units granted prior to that date was $1.5 billion, which is expected to be recognized over a weighted-average period of 2.1 years.

- changed (2017-01-25):
[0001234452-17-000028:note_history:37]
Recent Accounting Pronouncements. In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Adoption one year early is permitted. Two methods of adoption are permitted: (a) full retrospective adoption, meaning the standard is applied to all periods presented or (b) modified retrospective adoption, meaning the cumulative effect of applying the new guidance is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the new guidance early and is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.
  (was, 2016-07-20, similarity 0.986):
[0001234452-16-000483:note_history:37]
In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Adoption one year early is permitted. Two methods of adoption are permitted: (a) full retrospective adoption, meaning the standard is applied to all periods presented or (b) modified retrospective adoption, meaning the cumulative effect of applying the new guidance is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the new guidance early and is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.

- changed (2017-01-25):
[0001234452-17-000028:note_history:38]
In March 2016, the FASB issued new guidance that changes the accounting for share-based payments. Under the new guidance, excess tax benefits associated with share-based payment awards will be recognized through earnings when the awards vest or settle, rather than in stockholders’ equity. In addition, it will increase the number of shares an employer can withhold to cover income taxes on share-based payment awards and still qualify for the exemption to liability classification. The new guidance will be effective for the Company starting in the first quarter of fiscal 2018. Early adoption is permitted in any annual or interim period. The Company does not intend to adopt the new guidance early and is in the process of determining the effects the adoption will have on its consolidated financial statements.
  (was, 2016-07-20, similarity 0.7812):
[0001234452-16-000483:note_history:38]
In March 2016, the FASB issued new guidance that changes the accounting for share-based payments. Under the new guidance, excess tax benefits associated with share-based payment awards will be recognized in the income statement when the awards vest or settle, rather than in stockholders’ equity. In addition, it will increase the number of shares an employer can withhold to cover income taxes on share-based payment awards and still qualify for the exemption to liability classification. The new guidance will be effective for the Company starting in the first quarter of fiscal 2018. Early adoption is permitted in any annual or interim period. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.

- added (2017-01-25):
[0001234452-17-000028:note_history:39]
In August 2016, the FASB issued new guidance related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its consolidated financial statements as well as whether to adopt the new guidance early.

- added (2017-01-25):
[0001234452-17-000028:note_history:40]
In October 2016, the FASB issued new guidance that changes the accounting for income tax effects of intra-entity transfers of assets other than inventory. Under the new guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its consolidated financial statements as well as whether to adopt the new guidance early.

- removed (2017-01-25):
[0001234452-16-000483:note_history:41]
The Company recorded $170 million and $173 million in share-based compensation expense during the nine months ended June 26, 2016 and June 28, 2015, respectively, related to share-based awards granted during those periods. At June 26, 2016, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.2 billion, which is expected to be recognized over a weighted-average period of 2.0 years. During the nine months ended June 26, 2016 and June 28, 2015, net share-based awards granted, after forfeitures and cancellations, represented 0.7% and 0.8%, respectively, of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 1.0% and 0.9%, respectively, of outstanding shares as of the end of each fiscal period.

- removed (2017-01-25):
[0001234452-16-000483:note_history:42]
Recent Accounting Pronouncements. In November 2015, the Financial Accounting Standards Board (FASB) issued new guidance related to accounting for income taxes, which requires all deferred tax assets and liabilities to be classified as noncurrent on the balance sheet. The Company early adopted the new guidance prospectively in the second quarter of fiscal 2016. Prior period amounts have not been adjusted.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-01-25):
[0001234452-17-000028:note_history:43]
Revolving Credit Facility. In November 2016, the Company amended and restated its existing Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit (Amended and Restated Revolving Credit Facility) to increase the aggregate amount available to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. The Company had not previously borrowed any funds under the existing Revolving Credit Facility. Proceeds from the Amended and Restated Revolving Credit Facility are expected to be used for general corporate purposes. Loans under the Amended and Restated Revolving Credit Facility will bear interest, at the option of the Company, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the Amended and Restated Revolving Credit Facility) or the Base Rate (determined in accordance with the Amended and Restated Revolving Credit Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.70% and 0.00% per annum, respectively. The Amended and Restated Revolving Credit Facility has a facility fee, which initially accrues at a rate of 0.05% per annum. At December 25, 2016, the Company had not borrowed any funds under the Amended and Restated Revolving Credit Facility.

- changed (2017-01-25):
[0001234452-17-000028:note_history:44]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At December 25, 2016 and September 25, 2016, the Company had $1.7 billion of outstanding commercial paper recorded as short-term debt with weighted-average interest rates of 0.64% and 0.52%, respectively, which included fees paid to the commercial paper dealers and weighted-average remaining days to maturity of 41 days and 36 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at December 25, 2016 and September 25, 2016.
  (was, 2016-07-20, similarity 0.9124):
[0001234452-16-000483:note_history:44]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At June 26, 2016 and September 27, 2015, the Company had $1.7 billion and $1.0 billion, respectively, of outstanding commercial paper recorded as short-term debt with weighted-average interest rates of 0.50% and 0.19%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 37 days and 38 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at June 26, 2016 and September 27, 2015.

- added (2017-01-25):
[0001234452-17-000028:note_history:45]
Bridge Loan Facility. In October 2016, the Company entered into commitment letters pursuant to which the Company received commitments for senior unsecured bridge facility loans in an aggregate principal amount up to $13.6 billion (Bridge Loan Facility). In November 2016, the commitments available under the Bridge Loan Facility were reduced to $9.6 billion upon the Company entering into a $4.0 billion Term Loan Facility, described below. Proceeds from the Bridge Loan Facility, if drawn, will be used to finance, in part, the proposed acquisition of NXP Semiconductors N.V. by Qualcomm River Holdings B.V., a wholly owned subsidiary of the Company (Qualcomm River Holdings) (Note 8). Loans under the Bridge Loan Facility will only be available on the closing date of the proposed acquisition of NXP. The commitments available under the Bridge Loan Facility will be reduced on a dollar-for-dollar basis by the net cash proceeds of certain issuances of debt or equity securities and the incurrence of certain indebtedness by the Company, and the sales of certain assets by the Company and NXP. Commitments under the Bridge Loan Facility will expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the Bridge Loan Facility, (ii) the termination of Qualcomm River Holding’s obligation to consummate the proposed acquisition of NXP and (iii) October 27, 2017 (unless such date is extended in accordance with the NXP purchase agreement).

- added (2017-01-25):
[0001234452-17-000028:note_history:46]
Loans drawn under the Bridge Loan Facility will mature 364 days after the date on which the Bridge Loan Facility is funded and will bear interest at either the reserve-adjusted Eurodollar Rate (determined in accordance with the Bridge Loan Facility) or the Base Rate (determined in accordance with the Bridge Loan Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurodollar Rate and the Base Rate will be 0.75% and 0.00% per annum, respectively, and will adjust 90 days, 180 days and 270 days after the Bridge Loan Facility is funded to 1.00% and 0.00%, respectively, 1.25% and 0.25%, respectively, and 1.50% and 0.50%, respectively. Loans outstanding under the Bridge Loan Facility will also incur duration fees equal to 0.50%, 0.75% and 1.00% of the outstanding principal amount of Bridge Loan Facility loans on the dates that are 90 days, 180 days and 270 days after the funding date, respectively. The Bridge Loan Facility also has a ticking fee, which initially accrues at a rate of 0.05% per annum commencing on December 26, 2016. At December 25, 2016, no amounts were outstanding under the Bridge Loan Facility.

- added (2017-01-25):
[0001234452-17-000028:note_history:47]
Term Loan Facility. In November 2016, the Company entered into a Credit Agreement that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion (Term Loan Facility). Proceeds from the Term Loan Facility, if drawn, will be used to finance the proposed acquisition of NXP. Commitments under the Term Loan Facility will expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the Term Loan Facility, (ii) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP and (iii) October 27, 2017 (unless such date is extended in accordance with the NXP purchase agreement). Loans under the Term Loan Facility will mature on the third anniversary of the date on which they are funded and will bear interest at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the Term Loan Facility) or the Base Rate (determined in accordance with the Term Loan Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.875% and 0.00% per annum, respectively. The Term Loan Facility has a ticking fee, which initially accrues at a rate of 0.05% per annum commencing on December 26, 2016. At December 25, 2016, the Company had not borrowed any funds under the Term Loan Facility.

- changed (2017-01-25):
[0001234452-17-000028:note_history:48]
|  | December 25, 2016 |  | September 25, 2016 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 1.24% |  | $ | 250 |  |  | 1.14% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.52% |  | 250 |  |  | 1.42% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 1.36% |  | 1,250 |  |  | 0.93% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 2.04% |  | 1,750 |  |  | 1.69% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.53% |  | 2,000 |  |  | 2.04% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (55 | ) |  |  |  | (57 | ) |  |  |
| Hedge accounting fair value adjustments | (10 | ) |  |  |  | 65 |  |  |  |
| Total long-term debt | $ | 9,935 |  |  |  |  | $ | 10,008 |  |  |  |
  (was, 2016-07-20, similarity 0.9878):
[0001234452-16-000483:note_history:48]
|  | June 26, 2016 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.97% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.24% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.53% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.55% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 1.91% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (59 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 83 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 10,024 |  |  |  |  | $ | 9,969 |  |  |  |

- changed (2017-01-25):
[0001234452-17-000028:note_history:49]
The interest rate on the floating rate notes due in 2018 and 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At December 25, 2016 and September 25, 2016, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $10.2 billion and $10.6 billion, respectively.
  (was, 2016-07-20, similarity 0.9941):
[0001234452-16-000483:note_history:49]
The interest rate on the floating rate notes due in 2018 and 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At June 26, 2016 and September 27, 2015, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $10.4 billion and $9.6 billion, respectively.

- changed (2017-01-25):
[0001234452-17-000028:note_history:50]
In fiscal 2015, the Company entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings in interest expense in the current period.
  (was, 2016-07-20, similarity 0.9802):
[0001234452-16-000483:note_history:50]
The Company has entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings as interest expense in the current period.

- changed (2017-01-25):
[0001234452-17-000028:note_history:51]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $134 million and $128 million and in the three months ended December 25, 2016 and December 27, 2015.
  (was, 2016-07-20, similarity 0.7573):
[0001234452-16-000483:note_history:51]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $270 million during the nine months ended June 26, 2016. Cash interest paid related to the Company’s commercial paper program and long-term debt was negligible in the nine months ended June 28, 2015.

- added (2017-01-25):
[0001234452-17-000028:note_history:52]
Debt Covenants. The Amended and Restated Revolving Credit Facility, the Bridge Loan Facility and the Term Loan Facility require, and the prior Revolving Credit Facility required, that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. At December 25, 2016 and September 25, 2016, the Company was in compliance with the applicable covenants under each facility outstanding at such time.

- removed (2017-01-25):
[0001234452-16-000483:note_history:53]
Revolving Credit Facility. The Company has a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At June 26, 2016 and September 27, 2015, the Company was in compliance with the covenants, and the Company had not borrowed any funds under the Revolving Credit Facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-01-25):
[0001234452-17-000028:note_history:54]
|  | Current |  | Noncurrent |
|  | December 25, 2016 |  | September 25, 2016 |  | December 25, 2016 |  | September 25, 2016 |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 251 |  |  | $ | 1,116 |  |  | $ | 1,639 |  |  | $ | 1,099 |  |
| Corporate bonds and notes | 3,312 |  |  | 10,159 |  |  | 14,435 |  |  | 8,584 |  |
| Mortgage- and asset-backed and auction rate securities | 176 |  |  | 1,363 |  |  | 1,390 |  |  | 534 |  |
| Equity and preferred securities and equity funds | 88 |  |  | 64 |  |  | 476 |  |  | 1,682 |  |
| Debt funds | 100 |  |  | — |  |  | 1,033 |  |  | 1,803 |  |
|  | $ | 3,927 |  |  | $ | 12,702 |  |  | $ | 18,973 |  |  | $ | 13,702 |  |

- changed (2017-01-25):
[0001234452-17-000028:note_history:55]
At December 25, 2016, the contractual maturities of available-for-sale debt securities were as follows (in millions):
  (was, 2016-07-20, similarity 0.9541):
[0001234452-16-000483:note_history:55]
At June 26, 2016, the contractual maturities of available-for-sale debt securities were as follows (in millions):

- changed (2017-01-25):
[0001234452-17-000028:note_history:56]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities and auction rate securities.
  (was, 2016-07-20, similarity 0.9072):
[0001234452-16-000483:note_history:56]
Debt securities with no single maturity date included debt funds, corporate bonds and notes, mortgage- and asset-backed securities and auction rate securities.

- changed (2017-01-25):
[0001234452-17-000028:note_history:57]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| December 25, 2016 | $ | 248 |  |  | $ | (109 | ) |  | $ | 139 |  |
| December 27, 2015 | 50 |  |  | (12 | ) |  | 38 |  |
  (was, 2016-07-20, similarity 0.7243):
[0001234452-16-000483:note_history:57]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| June 26, 2016 | $ | 62 |  |  | $ | (8 | ) |  | $ | 54 |  |
| June 28, 2015 | 126 |  |  | (10 | ) |  | 116 |  |
| For the nine months ended |  |  |  |  |  |
| June 26, 2016 | $ | 146 |  |  | $ | (30 | ) |  | $ | 116 |  |
| June 28, 2015 | 434 |  |  | (48 | ) |  | 386 |  |

- added (2017-01-25):
[0001234452-17-000028:note_history:58]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| December 25, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 478 |  |  | $ | 86 |  |  | $ | — |  |  | $ | 564 |  |
| Debt securities (including debt funds) | 22,269 |  |  | 111 |  |  | (44 | ) |  | 22,336 |  |
|  | $ | 22,747 |  |  | $ | 197 |  |  | $ | (44 | ) |  | $ | 22,900 |  |
| September 25, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,554 |  |  | $ | 204 |  |  | $ | (12 | ) |  | $ | 1,746 |  |
| Debt securities (including debt funds) | 24,363 |  |  | 388 |  |  | (93 | ) |  | 24,658 |  |
|  | $ | 25,917 |  |  | $ | 592 |  |  | $ | (105 | ) |  | $ | 26,404 |  |

- changed (2017-01-25):
[0001234452-17-000028:note_history:59]
|  | December 25, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 263 |  |  | $ | (11 | ) |  | $ | 5 |  |  | $ | — |  |
| Corporate bonds and notes | 1,681 |  |  | (28 | ) |  | 59 |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 89 |  |  | (2 | ) |  | 59 |  |  | (1 | ) |
| Debt funds | 489 |  |  | (2 | ) |  | — |  |  | — |  |
|  | $ | 2,522 |  |  | $ | (43 | ) |  | $ | 123 |  |  | $ | (1 | ) |
  (was, 2016-07-20, similarity 0.7627):
[0001234452-16-000483:note_history:59]
|  | September 27, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 304 |  |  | $ | (4 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 7,656 |  |  | (93 | ) |  | 368 |  |  | (62 | ) |
| Mortgage- and asset-backed and auction rate securities | 862 |  |  | (3 | ) |  | 108 |  |  | (1 | ) |
| Equity and preferred securities and equity funds | 392 |  |  | (28 | ) |  | 17 |  |  | — |  |
| Debt funds | 1,792 |  |  | (117 | ) |  | 124 |  |  | (5 | ) |
|  | $ | 11,006 |  |  | $ | (245 | ) |  | $ | 617 |  |  | $ | (68 | ) |

- added (2017-01-25):
[0001234452-17-000028:note_history:60]
|  | September 25, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 444 |  |  | $ | (5 | ) |  | $ | 16 |  |  | $ | — |  |
| Corporate bonds and notes | 2,775 |  |  | (12 | ) |  | 1,033 |  |  | (65 | ) |
| Mortgage- and asset-backed and auction rate securities | 337 |  |  | (3 | ) |  | 211 |  |  | (2 | ) |
| Equity and preferred securities and equity funds | 312 |  |  | (4 | ) |  | 130 |  |  | (8 | ) |
| Debt funds | — |  |  | — |  |  | 309 |  |  | (6 | ) |
|  | $ | 3,868 |  |  | $ | (24 | ) |  | $ | 1,699 |  |  | $ | (81 | ) |

- added (2017-01-25):
[0001234452-17-000028:note_history:61]
In the first quarter of fiscal 2017, the Company announced that it entered into an agreement to acquire NXP Semiconductors N.V. (Note 8). As a result, prior to the closing, the Company has begun, and expects to continue, to divest a substantial portion of its marketable securities portfolio in order to finance, in part, that transaction. Marketable securities that were expected to be used to finance the NXP transaction were classified as noncurrent at December 25, 2016 as they are not considered available for current operations. Given the change in the Company’s intention to sell certain marketable securities, the Company recognized other-than-temporary impairment losses in the three months ended December 25, 2016 for certain marketable securities (Note 2) and may recognize additional losses prior to the sale of such marketable securities. For the remaining available-for-sale securities, which are not expected to be sold to finance the NXP transaction, the Company concluded that the unrealized losses were temporary at December 25, 2016. Further, for debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which was expected to be within a reasonable period of time, and for debt securities and preferred stock with unrealized losses, the Company did not have the intent to sell, nor was it more likely than not that the Company would be required to sell, such securities before recovery or maturity.

- removed (2017-01-25):
[0001234452-16-000483:note_history:62]
|  | Current |  | Noncurrent |
|  | June 26, 2016 |  | September 27, 2015 |  | June 26, 2016 |  | September 27, 2015 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 12 |  |
| Corporate bonds and notes | — |  |  | — |  |  | — |  |  | 364 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | — |  |  | — |  |  | 242 |  |
| Total trading | — |  |  | — |  |  | — |  |  | 618 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 217 |  |  | 156 |  |  | 1,931 |  |  | 691 |  |
| Corporate bonds and notes | 9,381 |  |  | 7,926 |  |  | 7,778 |  |  | 7,112 |  |
| Mortgage- and asset-backed and auction rate securities | 1,521 |  |  | 1,302 |  |  | 538 |  |  | 263 |  |
| Equity and preferred securities and equity funds | 106 |  |  | 377 |  |  | 1,459 |  |  | 1,253 |  |
| Debt funds | — |  |  | — |  |  | 2,216 |  |  | 2,909 |  |
| Total available-for-sale | 11,225 |  |  | 9,761 |  |  | 13,922 |  |  | 12,228 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | — |  |  | 780 |  |
| Total marketable securities | $ | 11,225 |  |  | $ | 9,761 |  |  | $ | 13,922 |  |  | $ | 13,626 |  |

- removed (2017-01-25):
[0001234452-16-000483:note_history:63]
In the second quarter of fiscal 2016, the Company exited an investment in a debt fund for which the Company elected the fair value option. The investment would have otherwise been recorded using the equity method. Changes in fair value associated with this investment were recognized in net investment income and were negligible for all periods presented.

- removed (2017-01-25):
[0001234452-16-000483:note_history:64]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains or net losses recognized on debt securities classified as trading held at June 28, 2015 were negligible during the three and nine months ended June 28, 2015, respectively.

- removed (2017-01-25):
[0001234452-16-000483:note_history:65]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| June 26, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,355 |  |  | $ | 254 |  |  | $ | (44 | ) |  | $ | 1,565 |  |
| Debt securities (including debt funds) | 23,461 |  |  | 292 |  |  | (171 | ) |  | 23,582 |  |
|  | $ | 24,816 |  |  | $ | 546 |  |  | $ | (215 | ) |  | $ | 25,147 |  |
| September 27, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,394 |  |  | $ | 264 |  |  | $ | (28 | ) |  | $ | 1,630 |  |
| Debt securities (including debt funds) | 20,459 |  |  | 185 |  |  | (285 | ) |  | 20,359 |  |
|  | $ | 21,853 |  |  | $ | 449 |  |  | $ | (313 | ) |  | $ | 21,989 |  |

- removed (2017-01-25):
[0001234452-16-000483:note_history:66]
|  | June 26, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 421 |  |  | $ | (2 | ) |  | $ | 35 |  |  | $ | (1 | ) |
| Corporate bonds and notes | 3,054 |  |  | (36 | ) |  | 1,488 |  |  | (82 | ) |
| Mortgage- and asset-backed and auction rate securities | 537 |  |  | (5 | ) |  | 265 |  |  | (2 | ) |
| Equity and preferred securities and equity funds | 447 |  |  | (43 | ) |  | 5 |  |  | (1 | ) |
| Debt funds | 318 |  |  | (4 | ) |  | 863 |  |  | (39 | ) |
|  | $ | 4,777 |  |  | $ | (90 | ) |  | $ | 2,656 |  |  | $ | (125 | ) |

- removed (2017-01-25):
[0001234452-16-000483:note_history:67]
At June 26, 2016, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company did not have the intent to sell, nor was it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

- removed (2017-01-25):
[0001234452-16-000483:note_history:68]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was $61 million and negligible at June 26, 2016 and June 28, 2015, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-01-25):
[0001234452-17-000028:note_history:69]
|  | December 25, 2016 |  | September 25, 2016 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 1.24% |  | $ | 250 |  |  | 1.14% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.52% |  | 250 |  |  | 1.42% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 1.36% |  | 1,250 |  |  | 0.93% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 2.04% |  | 1,750 |  |  | 1.69% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.53% |  | 2,000 |  |  | 2.04% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (55 | ) |  |  |  | (57 | ) |  |  |
| Hedge accounting fair value adjustments | (10 | ) |  |  |  | 65 |  |  |  |
| Total long-term debt | $ | 9,935 |  |  |  |  | $ | 10,008 |  |  |  |
  (was, 2016-07-20, similarity 0.9878):
[0001234452-16-000483:note_history:69]
|  | June 26, 2016 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.97% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.24% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.53% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.55% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 1.91% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (59 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 83 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 10,024 |  |  |  |  | $ | 9,969 |  |  |  |
