# QCOM MD&A — 0001234452-17-000028


## mdna

[0001234452-17-000028:mdna:1]
[same as prior period, unchanged from 0001234452-16-000483:mdna:1]

[0001234452-17-000028:mdna:2]
This information should be read in conjunction with the condensed consolidated financial statements and the notes thereto included in “Part I, Item 1” of this Quarterly Report and with “Management’s Discussion and Analysis of Financial Condition and Results of Operations” for the year ended September 25, 2016 contained in our 2016 Annual Report on Form 10-K.

[0001234452-17-000028:mdna:3]
This Quarterly Report (including, but not limited to, this section regarding Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements, including, but not limited to, statements regarding industry trends and dynamics; challenges and opportunities related to our semiconductor and licensing businesses; our proposed acquisition of NXP Semiconductors N.V.; our pending joint venture with TDK Corporation; current and future legal proceedings or actions of governmental or quasi governmental bodies or standards or industry organizations; and our future business, investments, financial condition, results of operations and prospects. Additionally, statements concerning other future matters, such as the development of new products, enhancements of technologies, industry or regional trends, consumer demand, sales or price levels, challenges to our business and/or business model, capital expenditures, investments in research and development, strategic investments and acquisitions and other statements regarding matters that are not historical, are forward-looking statements. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001234452-17-000028:mdna:4]
[same as prior period, unchanged from 0001234452-16-000483:mdna:4]

[0001234452-17-000028:mdna:5]
Revenues for the first quarter of fiscal 2017 were $6.0 billion, an increase of 4% compared to the year ago quarter, with net income attributable to Qualcomm of $682 million, a decrease of 54% compared to the year ago quarter.

[0001234452-17-000028:mdna:6]
| • | We shipped approximately 217 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, a decrease of 10% compared to approximately 242 million MSM integrated circuits in the year ago quarter. Despite the decline in MSM shipments, QCT’s revenues remained substantially flat compared to the year ago quarter primarily due to higher-priced product mix and an increase in revenues related to other products, primarily related to higher connectivity shipments. |

[0001234452-17-000028:mdna:7]
| • | Total reported device sales were approximately $62.9 billion, an increase of approximately 4% compared to approximately $60.6 billion in the year ago quarter.(1) QTL’s revenues increased by 13% compared to the prior year quarter primarily due to increases in reported sales of CDMA-based products (including multimode products that also implement OFDMA) and revenues per reported unit. The increase in revenues per reported unit was primarily attributable to the deferral of royalty revenues due to an arbitration with LG Electronics, Inc. in the first quarter of fiscal 2016, partially offset by a decrease in recognition of unearned license fees. QTL revenues and EBT in the first quarter of fiscal 2017 continued to be impacted negatively by units that we believe are not being reported by certain licensees and sales of certain unlicensed products. |

[0001234452-17-000028:mdna:8]
| • | On December 27, 2016, the Korea Fair Trade Commission (KFTC) announced that it had reached a decision in its investigation of us, finding that we have violated provisions of the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On January 22, 2017, we received the KFTC’s formal written decision. The KFTC ordered certain remedial actions and imposed a fine of approximately 1.03 trillion Korean Won (approximately $868 million based on exchange rates at December 25, 2016), which was recorded as a charge to other expenses in the first quarter of fiscal 2017. We believe that our business practices do not violate the MRFTA. We intend to challenge the decision in the Seoul High Court and seek a stay of the decision’s remedial order. |

[0001234452-17-000028:mdna:9]
22

[0001234452-17-000028:mdna:10]
Against this backdrop, the following recent developments occurred in the first quarter of fiscal 2017 with respect to key elements of our industry:

[0001234452-17-000028:mdna:11]
| • | Worldwide cellular connections grew sequentially by approximately 1% to reach approximately 7.5 billion.(2) |

[0001234452-17-000028:mdna:12]
| • | Worldwide 3G/4G connections (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) grew sequentially by approximately 4% to approximately 4.2 billion, which was approximately 56% of total cellular connections.(2) |

[0001234452-17-000028:mdna:13]
| (1) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). Not all licensees report sales the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-17-000028:mdna:14]
| (2) | According to GSMA Intelligence estimates as of January 23, 2017 for the quarter ended December 31, 2016. |

[0001234452-17-000028:mdna:15]
[same as prior period, unchanged from 0001234452-16-000483:mdna:14]

[0001234452-17-000028:mdna:16]
We design, manufacture, have manufactured on our behalf and market digital communications products based on CDMA, OFDMA and other technologies. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents, software and other rights.

[0001234452-17-000028:mdna:17]
[same as prior period, unchanged from 0001234452-16-000483:mdna:16]

[0001234452-17-000028:mdna:18]
QCT is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in wireless voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products are sold and its system software is licensed to manufacturers that use our products in mobile phones, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards and infrastructure equipment, broadband gateway equipment and other consumer electronic devices. Our MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Snapdragon processors and LTE modems, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon processors provide advanced application and graphics processing capabilities. QCT’s system software helps enable the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits. QCT revenues comprised 68% and 71% of total consolidated revenues in the first quarter of fiscal 2017 and 2016, respectively.

[0001234452-17-000028:mdna:19]
QCT currently utilizes a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Integrated circuits are die cut from silicon wafers that have completed the package assembly and test manufacturing processes. We rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits based primarily on our proprietary designs and test programs. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Turnkey is when our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services, such as wafer bump, probe, assembly and the majority or our final test requirements.

[0001234452-17-000028:mdna:20]
QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD and/or LTE standards and their derivatives. QTL licensing revenues include license fees and royalties based on sales by licensees of products incorporating

[0001234452-17-000028:mdna:21]
23

[0001234452-17-000028:mdna:22]
or using our intellectual property. License fees are fixed amounts paid in one or more installments. Royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). QTL recognizes royalty revenues based on royalties reported by licensees and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. QTL revenues comprised 30% and 28% of total consolidated revenues in the first quarter of fiscal 2017 and 2016, respectively. The vast majority of such revenues were generated through our licensees’ sales of CDMA2000- and WCDMA-based products, such as feature phones and smartphones.

[0001234452-17-000028:mdna:23]
QSI makes strategic investments that are focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications. Many of these strategic investments are in early-stage companies in a variety of industries, including, but not limited to, digital media, e-commerce, healthcare and wearable devices. Investments primarily include non-marketable equity instruments, which generally are recorded using the cost method or the equity method, and convertible debt instruments, which are recorded at fair value. In addition, QSI segment results include revenues and related costs associated with development contracts with one of our equity method investees. As part of our strategic investment activities, we intend to pursue various exit strategies for each of our QSI investments in the foreseeable future.

[0001234452-17-000028:mdna:24]
Nonreportable segments include our mobile health, data center, small cell and other wireless technology and service initiatives.

[0001234452-17-000028:mdna:25]
Seasonality. Many of our products or intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has tended historically to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons; and because QTL recognizes royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made in the fourth calendar quarter. We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 3G/4G networks by wireless operators and the timing of launches of flagship wireless devices that incorporate our products and/or intellectual property. These trends may or may not continue in the future.

[0001234452-17-000028:mdna:26]
[same as prior period, unchanged from 0001234452-16-000483:mdna:24]

[0001234452-17-000028:mdna:27]
[same as prior period, unchanged from 0001234452-16-000483:mdna:25]

[0001234452-17-000028:mdna:28]
| • | On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings, B.V., an indirect, wholly owned subsidiary of QUALCOMM Incorporated, will acquire NXP Semiconductors N.V. Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration of $38 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products. The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions, including the tender of specified percentages (which vary from 70% to 95% based on certain circumstances as provided in the definitive agreement) of the issued and outstanding common shares of NXP in the offer. The tender offer is not subject to any financing condition; however, we intend to fund the transaction with cash held by foreign entities and new debt. We expect that this will require us to devote significant resources and management time and attention prior to close; take on significant debt; and utilize a substantial portion of our cash, cash equivalents and marketable securities. |

[0001234452-17-000028:mdna:29]
| • | Consumer demand for 3G/4G smartphone products is increasing in emerging regions driven by availability of lower-tier-3G/4G devices. We expect the ongoing rollout of 4G services in emerging regions will encourage competition and growth, bringing the benefits of 3G/4G LTE multimode to consumers. |

[0001234452-17-000028:mdna:30]
| • | We expect our business, particularly QCT, to continue to be impacted by industry dynamics, including: |

[0001234452-17-000028:mdna:31]
| • | Concentration of device share among a few companies within the premium tier, resulting in significant supply chain leverage for those companies; |

[0001234452-17-000028:mdna:32]
| • | Decisions by companies to utilize their own internally-developed integrated circuit products or our competitors’ integrated circuit products in a portion of their devices; |

[0001234452-17-000028:mdna:33]
24

[0001234452-17-000028:mdna:34]
| • | Intense competition, particularly in China, as our competitors expand their product offerings and/or reduce the prices of their products as part of a strategy to attract new and/or retain customers; and |

[0001234452-17-000028:mdna:35]
| • | Lengthening replacement cycles in developed regions, where the smartphone industry is mature, premium-tier smartphones are common and consumer demand is increasingly driven by new product launches and/or innovation cycles, and from increasing consumer demand in emerging regions where premium-tier smartphones are less common and replacement cycles are on average longer than in developed regions. |

[0001234452-17-000028:mdna:36]
| • | We continue to believe that certain licensees, particularly in China, are not fully complying with their contractual obligations to report their sales of licensed products to us, and certain companies, including unlicensed companies, particularly in emerging regions, including China, are delaying execution of new license agreements. We have made substantial progress in reaching agreements with many companies, primarily in China. However, negotiations with certain licensees and unlicensed companies are ongoing. We believe that the conclusion of new agreements with these companies will result in improved reporting by these licensees, including with respect to sales of three-mode devices (i.e., devices that implement GSM, TD-SCDMA and LTE-TDD) sold in China. Additionally, we believe our increased efforts in the areas of compliance will also improve reporting, but will also result in increased costs to the business. Litigation and/or other actions may be necessary to compel licensees to report and pay the required royalties for sales they have not previously reported and/or to compel unlicensed companies to execute licenses. |

[0001234452-17-000028:mdna:37]
| • | Regulatory authorities in other jurisdictions continue to investigate our business practices, and other regulatory authorities may do so in the future. An unfavorable resolution of one or more of these matters could have a material adverse effect on our business with remedies that include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, including monetary damages. These activities may also require the investment of significant management time and attention and may result in increased legal costs. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” elsewhere in this Quarterly Report. |

[0001234452-17-000028:mdna:38]
| • | We continue to invest significant resources toward advancements in 4G LTE and 5G technologies, OFDM-based WLAN technologies, wireless baseband chips, our converged computing/communications (Snapdragon) chips, radio frequency front-end (RFFE), connectivity, graphics, audio and video codecs, multimedia products, software and services, which contribute to the expansion of our intellectual property portfolio. We are also investing in targeted opportunities that leverage our existing technical and business expertise to deploy new business models and enter into new industry segments, such as products for: automotive; the Internet of Things (IoT), including the connected home, smart cities and wearables; data center; networking; computing; mobile health; and machine learning, including robotics, among others. |

[0001234452-17-000028:mdna:39]
| • | In January 2016, we announced that we had reached an agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd., to enable delivery of RFFE modules and RF filters into fully integrated products for mobile devices and IoT applications, among others. The joint venture will initially be owned 51% by Qualcomm Global Trading Pte. Ltd., a Singapore corporation and wholly-owned subsidiary of ours (Qualcomm Global Trading) and 49% by EPCOS AG, a German Aktiengesellschaft and wholly-owned subsidiary of TDK Corporation (EPCOS). Certain intellectual property, patents and filter and module design and manufacturing assets will be carved out of existing TDK businesses and be owned by the joint venture, and certain assets will be acquired directly by affiliates of ours. The purchase price of Qualcomm Global Trading’s interest in the joint venture and the assets to be transferred to us is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, Qualcomm Global Trading has the option to acquire (and EPCOS has an option to sell) EPCOS’s interest in the joint venture for $1.15 billion 30 months after the closing date. EPCOS will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date, which is a substitute for and in lieu of any right of EPCOS to receive any profit sharing, distributions, dividends or other payments of any kind or nature. Every required regulatory agency has either approved the transaction or declined to exercise jurisdiction. The completion of the transaction remains subject to satisfaction of additional conditions and is expected to close in the second quarter of fiscal 2017. |

[0001234452-17-000028:mdna:40]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless value chain and governments as to the benefits of our business model and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not

[0001234452-17-000028:mdna:41]
welcome the success of our business model in enabling new, highly cost-effective competitors to their products. We expect that such companies, and/or governments or regulators, will continue to challenge our business model in various forums throughout the world.

[0001234452-17-000028:mdna:42]
[same as prior period, unchanged from 0001234452-16-000483:mdna:38]

[0001234452-17-000028:mdna:43]
[same as prior period, unchanged from 0001234452-16-000483:mdna:39]

[0001234452-17-000028:mdna:44]
| Revenues (in millions) |
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |  | Change |
| Equipment and services | $ | 4,139 |  |  | $ | 4,087 |  |  | $ | 52 |  |
| Licensing | 1,860 |  |  | 1,688 |  |  | 172 |  |
|  | $ | 5,999 |  |  | $ | 5,775 |  |  | $ | 224 |  |

[0001234452-17-000028:mdna:45]
The increase in equipment and services revenues was primarily due to an increase in QCT revenues. The increase in licensing revenues was primarily due to an increase in QTL revenues.

[0001234452-17-000028:mdna:46]
| Costs and Expenses (in millions) |
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |  | Change |
| Cost of revenues | $ | 2,443 |  |  | $ | 2,534 |  |  | $ | (91 | ) |
| Gross margin | 59 | % |  | 56 | % |  |  |

[0001234452-17-000028:mdna:47]
The increase in margin percentage was primarily due to the impact of higher-margin segment mix primarily related to QTL, an increase in QCT margin percentage and a decrease of $56 million in charges related to the recognition of the step-up of inventories to fair value and the amortization of intangible assets primarily related to the acquisition of CSR plc in the fourth quarter of fiscal 2015. The increase in margin percentage was partially offset by an increase in a nonreportable segment’s costs. Our margin percentage may fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors.

[0001234452-17-000028:mdna:48]
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |  | Change |
| Research and development | $ | 1,311 |  |  | $ | 1,352 |  |  | $ | (41 | ) |
| % of revenues | 22 | % |  | 23 | % |  |  |
| Selling, general, and administrative | $ | 591 |  |  | $ | 578 |  |  | $ | 13 |  |
| % of revenues | 10 | % |  | 10 | % |  |  |
| Other | $ | 876 |  |  | $ | (374 | ) |  | $ | 1,250 |  |

[0001234452-17-000028:mdna:49]
The dollar decrease in research and development expenses was primarily attributable to a decrease of $55 million in costs related to the development of integrated circuit technologies and related software products. Such decrease was primarily driven by actions initiated under our Strategic Realignment Plan, which was substantially implemented in fiscal 2016, partially offset by a $30 million impairment charge on certain intangible assets recorded in the first quarter of fiscal 2017.

[0001234452-17-000028:mdna:50]
The dollar increase in selling, general and administrative expenses was primarily attributable to increases of $28 million in professional services and $14 million in costs related to litigation and other legal matters, partially offset by decreases of $15 million in selling and marketing expenses and $15 million in depreciation and amortization expense.

[0001234452-17-000028:mdna:51]
Other expenses in the first quarter of fiscal 2017 included an $868 million charge related to the KFTC investigation and $8 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan. Other income in the first quarter of fiscal 2016 was primarily attributable to a $380 million gain on the sale of wireless spectrum and also included $54 million in restructuring and restructuring-related charges, partially offset by a $48 million gain on the sale of our business that provided augmented reality applications, both of which related to our Strategic Realignment Plan.

[0001234452-17-000028:mdna:52]
| Interest Expense and Net Investment Income (in millions) |
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |  | Change |
| Interest expense | $ | 90 |  |  | $ | 74 |  |  | $ | 16 |  |
| Investment income, net |  |  |  |  |  |
| Interest and dividend income | $ | 167 |  |  | $ | 136 |  |  | $ | 31 |  |
| Net realized gains on marketable securities | 139 |  |  | 43 |  |  | 96 |  |
| Net realized gains on other investments | 8 |  |  | 6 |  |  | 2 |  |
| Impairment losses on marketable securities and other investments | (143 | ) |  | (63 | ) |  | (80 | ) |
| Equity in net earnings (losses) of investees | 3 |  |  | (20 | ) |  | 23 |  |
| Net gains (losses) on derivative instruments | 8 |  |  | (3 | ) |  | 11 |  |
|  | $ | 182 |  |  | $ | 99 |  |  | $ | 83 |  |

[0001234452-17-000028:mdna:53]
The increases in net realized gains on marketable securities and impairment losses on marketable securities and other investments were primarily attributable to certain marketable securities that we sold and expect to sell before their anticipated recovery, respectively, to fund, in part, the acquisition of NXP Semiconductors N.V.

[0001234452-17-000028:mdna:54]
| Income Tax Expense (in millions) |
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |  | Change |
| Income tax expense | $ | 189 |  |  | $ | 214 |  |  | $ | (25 | ) |
| Effective tax rate | 22 | % |  | 13 | % |  | 9 | % |

[0001234452-17-000028:mdna:55]
The following table summarizes the primary factors that caused our effective tax rates for the first quarter of fiscal 2017 and 2016 to be less than the United States federal statutory rate:

[0001234452-17-000028:mdna:56]
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (15 | %) |  | (17 | %) |
| Benefits related to the research and development tax credit | (1 | %) |  | (6 | %) |
| Nondeductible charge related to the KFTC investigation | 2 | % |  | — | % |
| Other | 1 | % |  | 1 | % |
| Effective tax rate | 22 | % |  | 13 | % |

[0001234452-17-000028:mdna:57]
The estimated annual effective tax rate of 22% for fiscal 2017 is greater than the 17% effective income tax rate for fiscal 2016. In the first quarter of fiscal 2017, we recorded an $868 million charge related to the KFTC investigation, which is not deductible for tax purposes and is attributable to both the United States and a foreign jurisdiction. The estimated annual effective tax rate of 22% for fiscal 2017 also reflects the increase in our Singapore tax rate as a result of the expiration of its tax exemption in March 2017, which is partially offset by tax benefits resulting from the increase in our Singapore tax rate that will be in effect when certain deferred tax assets are scheduled to reverse. The annual effective tax rate of 17% for fiscal 2016 reflected a $101 million tax benefit recorded discretely in the third quarter of fiscal 2016 resulting from a worthless stock deduction on a domestic subsidiary of one of our former display businesses and a $79 million benefit recorded discretely in the first quarter of fiscal 2016 related to fiscal 2015 resulting from the retroactive and permanent reinstatement of the United States federal research and development tax credit.

[0001234452-17-000028:mdna:58]
Unrecognized tax benefits were $272 million and $271 million at December 25, 2016 and September 25, 2016, respectively. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at December 25, 2016 may increase or decrease in the next 12 months.

[0001234452-17-000028:mdna:59]
27

[0001234452-17-000028:mdna:60]
[same as prior period, unchanged from 0001234452-16-000483:mdna:57]

[0001234452-17-000028:mdna:61]
The following should be read in conjunction with the financial results for the first quarter of fiscal 2017 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0001234452-17-000028:mdna:62]
| (in millions) | QCT |  | QTL |  | QSI |
| Three Months Ended December 25, 2016 |  |  |  |  |  |
| Revenues | $ | 4,101 |  |  | $ | 1,811 |  |  | $ | 14 |  |
| EBT (1) | 724 |  |  | 1,532 |  |  | (17 | ) |
| EBT as a % of revenues | 18 | % |  | 85 | % |  |  |  |
| Three Months Ended December 27, 2015 |  |  |  |  |  |
| Revenues | $ | 4,096 |  |  | $ | 1,607 |  |  | $ | 9 |  |
| EBT (1) | 590 |  |  | 1,339 |  |  | 359 |  |
| EBT as a % of revenues | 14 | % |  | 83 | % |  |  |

[0001234452-17-000028:mdna:63]
[same as prior period, unchanged from 0001234452-16-000483:mdna:61]

[0001234452-17-000028:mdna:64]
QCT Segment. QCT results of operations in the first quarter of fiscal 2017 were impacted by higher demand in China, growth within adjacent industry segments outside traditional cellular industries and cost reduction initiatives achieved under the Strategic Realignment Plan, partially offset by a decline in share at a large customer. Approximately 217 million and 242 million MSM integrated circuits were sold in the first quarter of fiscal 2017 and 2016, respectively. Despite the decline in MSM shipments, QCT revenues remained substantially flat primarily due to an increase in equipment and services revenues, offset by a decrease in licensing revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying Radio Frequency (RF), Power Management (PM) and wireless connectivity integrated circuits, were $4.06 billion and $4.02 billion in the first quarter of fiscal 2017 and 2016, respectively. The increase in equipment and services revenues was primarily due to an increase of $175 million resulting from the net impact of higher-priced product mix and lower average selling prices and an increase of $113 million in revenues related to other products, primarily related to higher connectivity shipments, partially offset by a decrease of $247 million primarily related to lower MSM shipments.

[0001234452-17-000028:mdna:65]
QCT EBT as a percentage of revenues increased primarily due to an increase in gross margin percentage and a combined decrease of 5% in research and development and selling, general and administrative expenses. The increase in QCT gross margin percentage resulted primarily from lower average unit costs and higher-margin product mix, partially offset by lower average selling prices and higher excess inventory charges.

[0001234452-17-000028:mdna:66]
QTL Segment. The increase in QTL revenues of $204 million was primarily attributable to increases in reported sales of CDMA-based products (including multimode products that also implement OFDMA) and revenues per reported unit. The increase in revenues per reported unit was primarily attributable to the deferral of royalty revenues reported by LG Electronics, Inc. in the first quarter of fiscal 2016, partially offset by a decrease in recognition of unearned license fees. QTL revenues and EBT in the first quarter of fiscal 2017 continued to be impacted negatively by units that we believe are not being reported by certain licensees and sales of certain unlicensed products. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing, particularly in emerging regions, including China, and additional litigation may become necessary if negotiations fail to resolve the relevant issues.

[0001234452-17-000028:mdna:67]
QSI Segment. The decrease in QSI EBT was primarily due to the effect of a $380 million gain on the sale of wireless spectrum recorded in the first quarter of fiscal 2016 and a decrease of $15 million in net realized gains on investments, partially offset by a decrease of $17 million in equity losses.

[0001234452-17-000028:mdna:68]
[same as prior period, unchanged from 0001234452-16-000483:mdna:66]

[0001234452-17-000028:mdna:69]
On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings will acquire NXP. Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration of $38 billion. The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions. We intend to fund the transaction with cash held by foreign entities, which will result in the use of a substantial portion of our cash, cash equivalents and marketable securities, as well as new debt, and we secured $13.6 billion in committed financing through a $9.6 billion Bridge Loan Facility and $4.0 billion Term Loan Facility. The Company expects to issue additional debt, including accessing the public debt markets in fiscal 2017, in lieu of drawing on the Bridge Loan Facility at close of the NXP transaction.

[0001234452-17-000028:mdna:70]
Qualcomm River Holdings and NXP may terminate the definitive agreement under certain circumstances. If the definitive agreement is terminated by NXP in certain circumstances, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the definitive agreement is terminated by Qualcomm River Holdings under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion. In November 2016, as required by the definitive agreement, we entered into four letters of credit for an aggregate amount of $2.0 billion pursuant to which NXP will have the right to draw amounts to fund the potential termination fee payable to NXP. Each letter of credit is required to be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. We are restricted from using the funds deposited as collateral while the letters of credit are outstanding. At December 25, 2016, $1.95 billion of the letters of credit were collateralized through bank time deposits and money market funds, and the remaining $50 million was collateralized in the second quarter of fiscal 2017.

[0001234452-17-000028:mdna:71]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our employee benefit plans. The following tables present selected financial information related to our liquidity as of December 25, 2016 and September 25, 2016 and for the first quarter of fiscal 2017 and 2016 (in millions):

[0001234452-17-000028:mdna:72]
|  | December 25, 2016 |  | September 25, 2016 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 29,785 |  |  | $ | 32,350 |  |  | $ | (2,565 | ) |  | (8 | %) |
| Accounts receivable, net | 2,085 |  |  | 2,219 |  |  | (134 | ) |  | (6 | %) |
| Inventories | 1,910 |  |  | 1,556 |  |  | 354 |  |  | 23 | % |
| Short-term debt | 1,749 |  |  | 1,749 |  |  | — |  |  | — | % |
| Long-term debt | 9,935 |  |  | 10,008 |  |  | (73 | ) |  | (1 | %) |

[0001234452-17-000028:mdna:73]
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |  | $ Change |  | % Change |
| Net cash provided by operating activities | $ | 1,379 |  |  | $ | 2,739 |  |  | $ | (1,360 | ) |  | (50 | %) |
| Net cash provided (used) by investing activities | 681 |  |  | (716 | ) |  | 1,397 |  |  | N/M |  |
| Net cash used by financing activities | (1,104 | ) |  | (2,665 | ) |  | 1,561 |  |  | (59 | %) |

[0001234452-17-000028:mdna:74]
[same as prior period, unchanged from 0001234452-16-000483:mdna:71]

[0001234452-17-000028:mdna:75]
The net decrease in cash, cash equivalents and marketable securities was primarily due to the deposit of $1.95 billion that was used to collateralize the letters of credit related to our proposed acquisition of NXP and recorded as other noncurrent assets, $784 million in cash dividends paid, $444 million in payments to repurchase shares of our common stock and the timing of the settlement of sales of marketable securities, partially offset by net cash provided by operating activities. Total cash provided by operating activities decreased primarily due to changes in working capital related to inventories and the timing of related payments and accounts receivable. Our days sales outstanding, on a consolidated basis, decreased to 29 days at December 25, 2016 compared to 33 days at September 25, 2016. The decreases in accounts receivable and the related days sales outstanding were primarily due to the timing of integrated circuit shipments, partially offset by the timing of the collection of payments from certain of our licensees. The increase in inventories was primarily due to an increase in the overall quantity of units on hand, driven by efforts to provide increased assurance in meeting customer demand and the cancelation by a customer of one of its flagship products, and higher average unit costs.

[0001234452-17-000028:mdna:76]
Our cash, cash equivalents and marketable securities at December 25, 2016 consisted of $1.9 billion held by United States-based entities and $27.9 billion held by foreign entities. Most of our cash, cash equivalents and marketable securities held by foreign entities are indefinitely reinvested and would be subject to material tax effects if repatriated. However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate funds held by foreign entities.

[0001234452-17-000028:mdna:77]
We believe our current cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements, for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements, in addition to our proposed acquisition of NXP, also include the items described below.

[0001234452-17-000028:mdna:78]
29

[0001234452-17-000028:mdna:79]
| • | Our purchase obligations at December 25, 2016, some of which relate to research and development activities and capital expenditures, totaled $3.7 billion and $879 million for fiscal 2017 and 2018, respectively, and $1.0 billion thereafter. |

[0001234452-17-000028:mdna:80]
| • | Our research and development expenditures were $1.3 billion in the first quarter of fiscal 2017 and $5.2 billion in fiscal 2016, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications. |

[0001234452-17-000028:mdna:81]
| • | Cash outflows for capital expenditures were $129 million in the first quarter of fiscal 2017 and $539 million in fiscal 2016. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-17-000028:mdna:82]
| • | In connection with the KFTC investigation, we are obligated to pay a fine of approximately 1.03 trillion Korean Won (approximately $868 million based on exchange rates at December 25, 2016) within 60 days of the KFTC’s formal written decision, which was issued on January 22, 2017. |

[0001234452-17-000028:mdna:83]
| • | In January 2016, we announced that we had reached agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd. The joint venture will initially be owned 51% by Qualcomm Global Trading Pte. Ltd., a Singapore corporation and wholly-owned subsidiary of ours (Qualcomm Global Trading) and 49% by EPCOS AG, a German Aktiengesellschaft and wholly-owned subsidiary of TDK Corporation (EPCOS). The purchase price due upon close of the transaction is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, Qualcomm Global Trading has the option to acquire (and EPCOS has an option to sell) EPCOS’s interest in the joint venture for $1.15 billion 30 months after the closing date. We expect to use existing cash resources to fund the acquisition. EPCOS will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date. Every required regulatory agency has either approved the transaction or declined to exercise jurisdiction. The completion of the transaction remains subject to satisfaction of additional conditions and is expected to close in the second quarter of fiscal 2017. |

[0001234452-17-000028:mdna:84]
[same as prior period, unchanged from 0001234452-16-000483:mdna:81]

[0001234452-17-000028:mdna:85]
Debt. In November 2016, we amended and restated our existing Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit to increase the aggregate amount available to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. At December 25, 2016, no amounts were outstanding under the Amended and Restated Revolving Credit Facility.

[0001234452-17-000028:mdna:86]
We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At December 25, 2016, we had $1.7 billion of commercial paper outstanding with weighted-average net interest rates of 0.64% and weighted-average remaining days to maturity of 41 days.

[0001234452-17-000028:mdna:87]
In October 2016, we entered into a Bridge Loan Facility that provides for senior unsecured bridge facility loans in an aggregate amount up to $13.6 billion. In November 2016, the commitments available under the Bridge Loan Facility were reduced to $9.6 billion upon us entering into a $4.0 billion Term Loan Facility. Proceeds from the Bridge Loan Facility, if drawn, will be used to finance, in part, the proposed acquisition of NXP. At December 25, 2016, no amounts were outstanding under the Bridge Loan Facility.

[0001234452-17-000028:mdna:88]
In November 2016, we entered into a Term Loan Facility that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion. Proceeds from the Term Loan Facility, if drawn, will be used to finance, in part, the proposed acquisition of NXP. At December 25, 2016, no amounts were outstanding under the Term Loan Facility.

[0001234452-17-000028:mdna:89]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, with maturity dates in 2018 through 2045 and effective interest rates between 1.24% and 4.74%. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. In addition to the new debt we expect to issue in connection with our proposed acquisition of NXP, we may also issue debt in the future. The amount and timing of such additional borrowings will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001234452-17-000028:mdna:90]
Additional information regarding our outstanding debt at December 25, 2016 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt.”

[0001234452-17-000028:mdna:91]
Capital Return Program. In the first quarter of fiscal 2017, we repurchased and retired 6,647,000 shares of our common stock for $444 million, before commissions. At December 25, 2016, $2.5 billion remained authorized for repurchase under our stock repurchase program. As a result of our proposed acquisition of NXP and the pending use of our cash and marketable securities, we currently expect to repurchase shares in the next few years to offset dilution from the issuance of common stock under our employee benefit plans.

[0001234452-17-000028:mdna:92]
In the first quarter of fiscal 2017, we paid cash dividends totaling $784 million, or $0.53 per share. On January 12, 2017, we announced a cash dividend of $0.53 per share on our common stock, payable on March 22, 2017 to stockholders of record as of the close of business on March 1, 2017. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-17-000028:mdna:93]
[same as prior period, unchanged from 0001234452-16-000483:mdna:88]

[0001234452-17-000028:mdna:94]
We have no significant contractual obligations not fully recorded on our consolidated balance sheets or fully disclosed in the notes to our condensed consolidated financial statements. We have no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001234452-17-000028:mdna:95]
Additional information regarding our financial commitments at December 25, 2016 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes,” “Note 5. Debt,” “Note 6. Commitments and Contingencies” and “Note 8. Acquisitions.”

[0001234452-17-000028:mdna:96]
[same as prior period, unchanged from 0001234452-16-000483:mdna:92]

[0001234452-17-000028:mdna:97]
[same as prior period, unchanged from 0001234452-16-000483:mdna:93]

[0001234452-17-000028:mdna:98]
[same as prior period, unchanged from 0001234452-16-000483:mdna:94]

[0001234452-17-000028:mdna:99]
You should consider each of the following factors as well as the other information in this Quarterly Report in evaluating our business and our prospects. The risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also impair our business operations. If any of these risks occur, our management may be required to invest significant time and attention and our business and financial results could be harmed. In that case, the trading price of our common stock could decline. You should also consider the other information set forth in this Quarterly Report and in our Annual Report on Form 10-K for the fiscal year ended September 25, 2016 in evaluating our business and our prospects, including but not limited to our financial statements and the related notes and “Part I, Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.”

[0001234452-17-000028:mdna:100]
[same as prior period, unchanged from 0001234452-16-000483:mdna:96]

[0001234452-17-000028:mdna:101]
Our proposed acquisition of NXP Semiconductors N.V. involves a number of risks, including, among others, the risk that we fail to complete the acquisition, in a timely manner or at all, regulatory risks, risks associated with our use of a significant portion of our cash and our taking on significant indebtedness, other financial risks, integration risks, and risk associated with the reactions of customers, suppliers and employees.

[0001234452-17-000028:mdna:102]
Our and NXP’s obligations to consummate the proposed transaction are subject to the satisfaction or waiver of certain conditions, including, among others: (i) the tender of a minimum number of NXP’s outstanding common shares in the tender offer commenced by a subsidiary of QUALCOMM Incorporated; (ii) the expiration or termination of any waiting periods under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended; (iii) the receipt of regulatory clearance under European Union and certain other foreign antitrust laws; (iv) the absence of any law or order prohibiting the proposed transaction; (v) there being no event that would have a material adverse effect on NXP; (vi) the accuracy of the representations and warranties of NXP, subject to certain exceptions, and NXP’s material compliance with its covenants, in the definitive agreement; (vii) the approval of certain governance-related resolutions at an extraordinary general meeting of NXP’s shareholders; and (viii) the completion of certain internal reorganization steps with respect to NXP and the disposition of certain non-core assets of NXP. We cannot provide assurance that the conditions to the completion of the proposed transaction will be satisfied in a timely manner or at all, and if the proposed transaction is not completed, we would not realize any of the expected benefits.

[0001234452-17-000028:mdna:103]
31

[0001234452-17-000028:mdna:104]
The regulatory approvals required in connection with the proposed transaction may not be obtained or may contain materially burdensome conditions. If any conditions or changes to the structure of the proposed transaction are required to obtain these regulatory approvals, they may have the effect of jeopardizing or delaying completion of the proposed transaction or reducing our anticipated benefits. If we agree to any material conditions in order to obtain any approvals required to complete the proposed transaction, our business and results of operations may be adversely affected.

[0001234452-17-000028:mdna:105]
In addition, the use of a significant portion of our cash and the incurrence of substantial indebtedness in connection with the financing of the proposed transaction may have an adverse impact on our liquidity, limit our flexibility in responding to other business opportunities and increase our vulnerability to adverse economic and industry conditions. See the Risk Factor entitled “There are risks associated with our indebtedness.”

[0001234452-17-000028:mdna:106]
If the proposed transaction is not completed, our stock price could fall to the extent that our current price reflects an assumption that we will complete it. Furthermore, if the proposed transaction is not completed and the purchase agreement is terminated, we would not realize any of the expected benefits of the proposed transaction, and we may suffer other consequences that could adversely affect our business, results of operations and stock price, including, among others:

[0001234452-17-000028:mdna:107]
| • | we could be required to pay a termination fee to NXP of $2.0 billion; |

[0001234452-17-000028:mdna:108]
| • | we will have incurred and may continue to incur costs relating to the proposed transaction, many of which are payable by us whether or not the proposed transaction is completed; |

[0001234452-17-000028:mdna:109]
| • | matters relating to the proposed transaction (including integration planning) require substantial commitments of time and resources by our management team and numerous others throughout our organization, which could otherwise have been devoted to other opportunities; |

[0001234452-17-000028:mdna:110]
| • | we may be subject to legal proceedings related to the proposed transaction or the failure to complete the proposed transaction; |

[0001234452-17-000028:mdna:111]
| • | the failure to consummate the proposed transaction may result in negative publicity and a negative perception of us in the investment community; and |

[0001234452-17-000028:mdna:112]
| • | any disruptions to our business resulting from the announcement and pendency of the proposed transaction, including any adverse changes in our relationships with our customers, suppliers, partners or employees, may continue or intensify in the event the proposed transaction is not consummated. |

[0001234452-17-000028:mdna:113]
The proposed transaction will be our largest acquisition to date, by a significant margin. The benefits we expect to realize from the proposed transaction will depend, in part, on our ability to integrate the businesses successfully and efficiently. See the Risk Factor entitled “We may engage in strategic acquisitions, transactions or make investments that could adversely affect our financial results or fail to enhance stockholder value.”

[0001234452-17-000028:mdna:114]
Furthermore, uncertainties about the proposed transaction may cause our and/or NXP’s current and prospective employees to experience uncertainty about their futures. These uncertainties may impair our and/or NXP’s ability to retain, recruit or motivate key management, engineering, technical and other personnel. Similarly, our and/or NXP’s existing or prospective customers, licensees, suppliers and/or partners may delay, defer or cease purchasing products or services from or providing products or services to us or NXP; delay or defer other decisions concerning us or NXP; or otherwise seek to change the terms on which they do business with us or NXP. Any of the above could harm us and/or NXP, and thus decrease the benefits we expect to receive from the proposed transaction.

[0001234452-17-000028:mdna:115]
The proposed transaction may also result in significant charges or other liabilities that could adversely affect our financial results, such as cash expenses and non-cash accounting charges incurred in connection with our acquisition and/or integration of the business and operations of NXP. Further, our failure to identify or accurately assess the magnitude of certain liabilities we are assuming in the proposed transaction could result in unexpected litigation or regulatory exposure, unfavorable accounting charges, unexpected increases in taxes due, a loss of anticipated tax benefits or other adverse effects on our business, operating results or financial condition. The price of our common stock following the proposed transaction could decline to the extent our financial results are materially affected by any of these events.

[0001234452-17-000028:mdna:116]
Our revenues depend on commercial network deployments, expansions and upgrades of CDMA, OFDMA and other communications technologies; our customers’ and licensees’ sales of products and services based on these technologies; and customers’ demand for our products and services.

[0001234452-17-000028:mdna:117]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on operators of wireless networks and our customers and licensees to adopt these technologies for use in their networks, devices and services. We also depend on our customers and licensees to

[0001234452-17-000028:mdna:118]
develop devices and services based on these technologies with value-added features to drive consumer demand for new 3G, 3G/4G multimode and 4G devices, as well as establishing the selling prices for such devices. Further, we depend on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries beyond traditional cellular communications, such as automotive, the IoT, including the connected home, smart cities and wearables, data center, networking, computing, mobile health and machine learning, including robotics, among others. We are also impacted by consumers’ rates of replacement of smartphones and other computing devices.

[0001234452-17-000028:mdna:119]
Our revenues and/or growth in revenues could be negatively impacted, our business may be harmed and our substantial investments in these technologies may not provide us an adequate return, if:

[0001234452-17-000028:mdna:120]
[same as prior period, unchanged from 0001234452-16-000483:mdna:99]

[0001234452-17-000028:mdna:121]
[same as prior period, unchanged from 0001234452-16-000483:mdna:100]

[0001234452-17-000028:mdna:122]
[same as prior period, unchanged from 0001234452-16-000483:mdna:101]

[0001234452-17-000028:mdna:123]
| • | government regulators delay making sufficient spectrum available for 3G, 4G, new unlicensed technologies that we are developing in conjunction with 3G and 4G, as well as for 5G, thereby restricting the ability of wireless operators to deploy or expand the use of these technologies; |

[0001234452-17-000028:mdna:124]
| • | wireless operators delay or do not drive improvements in 3G or 3G/4G multimode network performance and/or capacity; |

[0001234452-17-000028:mdna:125]
| • | our customers’ and licensees’ revenues and sales of products, particularly premium-tier products, and services using these technologies do not grow or do not grow as quickly as anticipated due to, for example, the maturity of smartphone penetration in developed regions; |

[0001234452-17-000028:mdna:126]
| • | our intellectual property and technical leadership included in the 5G standardization effort is different than in 3G and 4G standards; |

[0001234452-17-000028:mdna:127]
| • | the standardization and/or deployment of 5G technology is delayed; and/or |

[0001234452-17-000028:mdna:128]
| • | we are unable to drive the adoption of our products and services into networks and devices, including devices beyond traditional cellular applications, based on CDMA, OFDMA and other communications technologies. |

[0001234452-17-000028:mdna:129]
Our industry is subject to competition in an environment of rapid technological change that could result in decreased demand and/or declining average selling prices for our products and/or those of our customers and/or licensees.

[0001234452-17-000028:mdna:130]
Our products, services and technologies face significant competition. We expect competition to increase as our current competitors expand their product offerings or reduce the prices of their products as part of a strategy to attract new business and/or customers, as new opportunities develop and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: device manufacturer concentrations; growth in demand, consumption and competition in emerging geographic regions; government intervention and/or support of national industries and/or competitors; evolving industry standards and business models; evolving methods of transmission of voice and data communications; increasing data traffic and densification of wireless networks; convergence and aggregation of connectivity technologies (including Wi-Fi and LTE) in both devices and access points; consolidation of wireless technologies and infrastructure at the network edge; networking and connectivity trends (including cloud services); use of both licensed and unlicensed spectrum; the evolving nature of computing (including demand for always on, always connected capabilities); the speed of technological change (including the transition to smaller geometry process technologies); value-added features that drive selling prices as well as consumer demand for new 3G, 3G/4G multimode and 4G devices; turnkey, integrated products that incorporate hardware, software, user interface, applications and reference designs; scalability; and the ability of the system technology to meet customers’ immediate and future network requirements. We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, technological and public policy changes and relatively low barriers to entry in certain segments of the industry. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape.

[0001234452-17-000028:mdna:131]
[same as prior period, unchanged from 0001234452-16-000483:mdna:109]

[0001234452-17-000028:mdna:132]
[same as prior period, unchanged from 0001234452-16-000483:mdna:68]

[0001234452-17-000028:mdna:133]
| • | differentiate our integrated circuit products with innovative technologies across multiple products and features (e.g., modem, RFFE, graphics and/or other processors, camera and connectivity) and with smaller geometry process technologies that drive performance; |

[0001234452-17-000028:mdna:134]
[same as prior period, unchanged from 0001234452-16-000483:mdna:111]

[0001234452-17-000028:mdna:135]
| • | continue to drive the adoption of our integrated circuit products into the most popular device models and across a broad spectrum of devices, such as smartphones, tablets, other computing devices, automobiles, wearable and other connected devices and infrastructure products; |

[0001234452-17-000028:mdna:136]
| • | maintain and/or accelerate demand for our integrated circuit products at the premium device tier, while increasing the adoption of our products in mid- and low-tier devices, in part by strengthening our integrated circuit product roadmap for, and developing channel relationships in, emerging geographic regions, such as China and India, and by providing turnkey products, which incorporate our integrated circuits, for low- and mid-tier smartphones and tablets; |

[0001234452-17-000028:mdna:137]
| • | continue to be a leader in 4G technology evolution, including expansion of our LTE-based single mode licensing program in areas where single-mode products are commercialized, and continue to innovate and introduce 4G turnkey, integrated products and services that differentiate us from our competition; |

[0001234452-17-000028:mdna:138]
[same as prior period, unchanged from 0001234452-16-000483:mdna:115]

[0001234452-17-000028:mdna:139]
[same as prior period, unchanged from 0001234452-16-000483:mdna:116]

[0001234452-17-000028:mdna:140]
| • | increase and/or accelerate demand for our semiconductor component products, including RFFE, and our wired and wireless connectivity products, including networking products for consumers, carriers and enterprise equipment and connected devices; |

[0001234452-17-000028:mdna:141]
[same as prior period, unchanged from 0001234452-16-000483:mdna:118]

[0001234452-17-000028:mdna:142]
| • | create standalone value and/or contribute to the success of our existing businesses through acquisitions, joint ventures and other transactions (and/or by developing customer, licensee and/or vendor relationships) in new industry segments and/or disruptive technologies, products and/or services (such as products for automotive, the IoT, including the connected home, smart cities and wearables, data center, networking, computing, mobile health and machine learning, including robotics, among others); |

[0001234452-17-000028:mdna:143]
| • | become a leading supplier of radio frequency front-end products, which are designed to address cellular radio frequency band fragmentation while improving radio frequency performance and assist original equipment manufacturers in developing multiband, multimode mobile devices; |

[0001234452-17-000028:mdna:144]
| • | be a leader in 5G technology development, standardization, intellectual property creation and licensing and develop and commercialize 5G integrated circuit products and services; and/or |

[0001234452-17-000028:mdna:145]
| • | continue to develop brand recognition to effectively compete against better known companies in computing and other consumer driven segments and to deepen our presence in significant emerging geographic regions. |

[0001234452-17-000028:mdna:146]
Competition in any or all product tiers may result in the loss of certain business or customers, which would negatively impact our revenues and operating results. Such competition may also reduce average selling prices for our chipset products and/or the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging geographic regions where competitors may have lower cost structures and/or may have a willingness and ability to accept lower prices and/or lower or negative margins on their products (particularly in China). Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0001234452-17-000028:mdna:147]
Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM) as well as companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom Limited, Cirrus Logic,

[0001234452-17-000028:mdna:148]
Ericsson, HiSilicon Technologies, Intel, Leadcore Technology Co., Ltd., Marvell Technology, Maxim Integrated Products, MediaTek, Microchip Technology Inc., Nvidia, Qorvo Inc., Realtek Semiconductor, Samsung Electronics, Skyworks Solutions Inc. and Spreadtrum Communications (which is controlled by Tsinghua Unigroup). Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to utilize their own internally-developed integrated circuit products, to use our competitors’ integrated circuit products, or to choose alternative technologies; lower cost structures and/or a willingness and ability to accept lower prices and lower or negative margins for their products, particularly in China; foreign government support of other technologies or competitors; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and original equipment manufacturers in emerging geographic regions (such as China); and/or a more established presence in certain regions.

[0001234452-17-000028:mdna:149]
[same as prior period, unchanged from 0001234452-16-000483:mdna:126]

[0001234452-17-000028:mdna:150]
Our QCT segment derives a significant portion of its revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. In addition, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past chosen, and may in the future choose, to utilize in certain of their devices rather than our integrated circuit products (and/or sell their integrated circuit products to third parties in competition with us). Also, one of our largest integrated circuit customers has begun to utilize products of one of our competitors in certain of their devices rather than our products.

[0001234452-17-000028:mdna:151]
The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or the cancelation of significant purchases by any of these customers, whether due to the use of their own integrated circuit products, our competitors’ integrated circuit products or otherwise, would reduce our revenues and could harm our ability to achieve or sustain expected operating results, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Further, the concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have no control, and the timing of such introductions may cause our operating results to fluctuate. Accordingly, if current industry dynamics and concentrations continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases, and the timing and size of any such future purchases, by these significant customers.

[0001234452-17-000028:mdna:152]
One of our largest customers purchases our Mobile Data Modem (MDM) products, which do not include our integrated application processor technology and which have lower revenue and margin contributions than our combined modem and application processor products. To the extent such customer takes device share from our other customers who purchase our integrated modem and application processor products, our revenues and margins may be negatively impacted.

[0001234452-17-000028:mdna:153]
[same as prior period, unchanged from 0001234452-16-000483:mdna:129]

[0001234452-17-000028:mdna:154]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products and/or intellectual property or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001234452-17-000028:mdna:155]
Although we have more than 335 CDMA-based licensees, our QTL segment derives a significant portion of its licensing revenues from a limited number of licensees. In the event that one or more of our significant licensees fail to meet their reporting and/or payment requirements or we are unable to renew or modify one or more of such license agreements under similar terms, our revenues, operating results and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our major licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues.

[0001234452-17-000028:mdna:156]
[same as prior period, unchanged from 0001234452-16-000483:mdna:91]

[0001234452-17-000028:mdna:157]
We derive a significant portion of our consolidated revenues from the premium-tier device segment. If sales of premium-tier devices decrease, and/or sales of our premium-tier integrated circuit products decrease, our operating results could be negatively affected.

[0001234452-17-000028:mdna:158]
We derive a significant portion of our revenues from the premium-tier device segment, and we expect this trend to continue in the foreseeable future. We have experienced, and expect to continue to experience, slowing growth in the premium-tier device segment due to, among other factors, lengthening replacement cycles in developed regions, where premium-tier smartphones are common; increasing consumer demand in emerging regions, particularly China, where premium-tier smartphones are less common and replacement cycles are on average longer than in developed regions; and/or a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and/or innovation cycles.

[0001234452-17-000028:mdna:159]
In addition, as discussed in the prior risk factor, our industry is experiencing concentration of device share among a few companies at the premium tier, which gives them significant supply chain leverage. Further, those companies may utilize their own internally-developed integrated circuit products, or our competitors’ integrated circuit products, rather than our products in a portion of their devices. These dynamics may result in lower prices for and/or reduced sales of our premium-tier integrated circuit products.

[0001234452-17-000028:mdna:160]
A reduction in sales of premium-tier devices, or a reduction in sales of our premium-tier integrated circuit products (which have a higher revenue and margin contribution than our lower-tier integrated circuit products), may reduce our revenues and margins and may harm our ability to achieve or sustain expected operating results.

[0001234452-17-000028:mdna:161]
[same as prior period, unchanged from 0001234452-16-000483:mdna:132]

[0001234452-17-000028:mdna:162]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, or some form of unfair competition; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the imposition of some form of compulsory licensing and/or to weaken a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies to attempt to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated. In addition, certain licensees have disputed or underreported royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into license agreements with us for their use of our intellectual property, and licensees and/or companies may continue to do so in the future. Further, to the extent such licensees and/or companies increase their device share, the negative impact of their underreporting and/or non-reporting on our business and operating results will be exacerbated.

[0001234452-17-000028:mdna:163]
We are currently subject to various litigation and governmental investigations and/or proceedings, some of which may arise out of the strategies described above. Certain legal matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region.

[0001234452-17-000028:mdna:164]
In addition, in connection with our participation in SDOs, we, like other patent owners, generally have made contractual commitments to such organizations to license those of our patents that would necessarily be infringed by standard-compliant products (standard-essential patents) on terms that are fair, reasonable and nondiscriminatory (FRAND). Some manufacturers and users of standard-compliant products advance interpretations of these FRAND commitments that are adverse to our licensing business, including interpretations that would limit the amount of royalties that we could collect on the licensing of our patent portfolio.

[0001234452-17-000028:mdna:165]
[same as prior period, unchanged from 0001234452-16-000483:mdna:138]

[0001234452-17-000028:mdna:166]
Some SDOs, courts and governmental agencies have adopted and may in the future adopt some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001234452-17-000028:mdna:167]
[same as prior period, unchanged from 0001234452-16-000483:mdna:140]

[0001234452-17-000028:mdna:168]
We are subject to government regulations and policies. Our business may suffer as a result of adverse rulings in government investigations or other proceedings, new or changed laws, regulations or policies and/or our failure or inability to comply with laws, regulations or policies.

[0001234452-17-000028:mdna:169]
[same as prior period, unchanged from 0001234452-16-000483:mdna:153]

[0001234452-17-000028:mdna:170]
We are currently subject to various governmental investigations and/or proceedings, and certain matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region.

[0001234452-17-000028:mdna:171]
[same as prior period, unchanged from 0001234452-16-000483:mdna:155]

[0001234452-17-000028:mdna:172]
[same as prior period, unchanged from 0001234452-16-000483:mdna:156]

[0001234452-17-000028:mdna:173]
Regulations in the United States require that we determine whether certain materials used in our products, referred to as conflict minerals, originated in the Democratic Republic of the Congo (DRC) or an adjoining country, or were from recycled or scrap sources. The verification and reporting requirements, in addition to customer demands for conflict free sourcing,

[0001234452-17-000028:mdna:174]
impose additional costs on us and on our suppliers and may limit the sources or increase the prices of materials used in our products. Further, if we are unable to determine that our products are “DRC conflict free,” we may face challenges with our customers that place us at a competitive disadvantage, and our reputation may be harmed.

[0001234452-17-000028:mdna:175]
[same as prior period, unchanged from 0001234452-16-000483:mdna:158]

[0001234452-17-000028:mdna:176]
The enforcement and protection of our intellectual property rights may be expensive, could fail to prevent misappropriation or unauthorized use of our intellectual property rights, could result in the loss of our ability to enforce one or more patents, or could be adversely affected by changes in patent laws, by laws in certain foreign jurisdictions that may not effectively protect our intellectual property rights or by ineffective enforcement of laws in such jurisdictions.

[0001234452-17-000028:mdna:177]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our proprietary information, technologies and processes, including our patent portfolio. Policing unauthorized use of our products, technologies and proprietary information is difficult and time consuming. The steps we have taken have not always prevented, and we cannot be certain the steps we will take in the future will prevent, the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as United States laws or where the enforcement of such laws may be lacking or ineffective. Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that the European Union will adopt a unitary patent system in the next few years that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technology.

[0001234452-17-000028:mdna:178]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property rights and/or contracts, including collecting royalties for use of our patent portfolio in particular foreign jurisdictions due to, among others: policies of foreign governments; challenges to our licensing practices under such jurisdictions’ competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and/or challenges pending before foreign competition agencies to the pricing and integration of additional features and functionality into our chipset products. Certain licensees have disputed or underreported royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into license agreements for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements.

[0001234452-17-000028:mdna:179]
We have entered into litigation in the past and may need to further litigate in the future to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements and/or initiating litigation) and/or we could incur substantial unexpected operating costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our operating results. Further, even a positive

[0001234452-17-000028:mdna:180]
38

[0001234452-17-000028:mdna:181]
resolution to our enforcement efforts may take time to conclude, which may reduce our revenues in the period prior to conclusion.

[0001234452-17-000028:mdna:182]
Our growth increasingly depends on our ability to extend our products and services into new and expanded product areas, such as RFFE, and adjacent industry segments outside of traditional cellular industries, such as the IoT, automotive and computing, among others. Our research, development and other investments in these new and expanded product areas and industry segments, and related technologies, products and services, as well as in our existing technologies, products and services and new technologies, such as 5G, may not generate operating income or contribute to future operating results that meet our expectations.

[0001234452-17-000028:mdna:183]
Our industry is subject to rapid technological change, evolving industry standards and frequent new product introductions, and we must make substantial research, development and other investments, such as acquisitions, in new products, services and technologies to compete successfully. Technological innovations generally require significant research and development efforts before they are commercially viable. While we continue to invest significant resources toward advancements primarily in support of 4G OFDMA- and 5G-based technologies, we also innovate across a broad spectrum of opportunities to deploy new and expanded products and enter into adjacent industry segments by leveraging our existing technical and business expertise and/or through acquisitions.

[0001234452-17-000028:mdna:184]
In particular, our future growth significantly depends on new and expanded product areas, such as RFFE, and adjacent industry segments, such as automotive, IoT, including the connected home, smart cities and wearables, data center, networking, computing, mobile health and machine learning, including robotics, among others; our ability to develop leading and cost-effective technologies, products and services for new and expanded product areas and adjacent industry segments; and third parties incorporating our technology, products and services into device types used in these product areas and industry segments. Accordingly, we intend to continue to make substantial investments in these new and expanded product areas and adjacent industry segments, and in developing new products, services and technologies for these product areas and industry segments.

[0001234452-17-000028:mdna:185]
However, our research, development and other investments in these new and expanded product areas and adjacent industry segments, and corresponding technologies, products and services, as well as in our existing, technologies, products and services and new technologies, such as use of both licensed and unlicensed spectrum, convergence of cellular and Wi-Fi and 5G, may not succeed due to, among others: new industry segments and/or consumer demand may not grow as anticipated; our strategies and/or the strategies of our customers, licensees or partners may not be successful; improvements in alternate technologies in ways that reduce the advantages we anticipate from our investments; competitors’ products or services being more cost effective, having more capabilities or fewer limitations or being brought to market faster than our new products and services; and competitors having longer operating histories in industry segments that are new to us. We may also underestimate the costs of or overestimate the future operating income and/or margins that could result from these investments, and these investments may not, or may take many years to, generate material returns.

[0001234452-17-000028:mdna:186]
If our new technologies, products and/or services are not successful, or are not successful in the time frame we anticipate, we may incur significant costs and/or asset impairments, our business may not grow as anticipated, our revenues and/or margins may be negatively impacted and/or our reputation may be harmed.

[0001234452-17-000028:mdna:187]
The continued and future success of our licensing programs can be impacted by the deployment of other technologies in place of technologies based on CDMA, OFDMA and their derivatives; the success of our licensing programs for 4G single mode products and emerging industry segments; and the need to extend license agreements that are expiring and/or to cover additional future patents.

[0001234452-17-000028:mdna:188]
Although we own a very strong portfolio of issued and pending patents related to GSM, GPRS, EDGE, OFDM, OFDMA, WLAN and other technologies, our patent portfolio licensing program in these areas is less established and might not be as successful in generating licensing revenues as our CDMA licensing program has been. Many wireless operators are investigating, have selected or have deployed OFDMA-based LTE as their next-generation 4G technology in existing (or future if not yet deployed) wireless spectrum bands as complementary to their existing CDMA-based networks. While 3G/4G multimode products are generally covered by our existing 3G licensing agreements, products that implement 4G but do not also implement 3G are generally not covered by these agreements. Although we believe that our patented technology is essential and useful to implementation of the LTE industry standards and have granted royalty-bearing licenses to more than 220 companies (including Huawei, Lenovo, LG, Microsoft, Oppo, Samsung, Sony Mobile, vivo, Xiaomi and ZTE) that have realized that they need a license to our patents to make and sell products implementing 4G standards but not implementing 3G standards, it may be difficult to agree on material terms and/or conditions of new license agreements that are acceptable to us with companies that are currently unlicensed. Further, the royalty rates for single mode 4G products are lower than our royalty rates for 3G and 3G/4G multimode products, so, without a corresponding increase in volumes and/or device ASP, we

[0001234452-17-000028:mdna:189]
will not achieve the same licensing revenues on such LTE products as on 3G and 3G/4G multimode products. In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the connected home or the IoT. We also seek to diversify and broaden our technology licensing programs to new industry segments in which we can utilize our technology leadership, such as wireless charging and other technologies. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties that are equivalent to those that we receive for 3G and 3G/4G multimode products used in cellular communications. Although we believe that our patented technology is essential and useful to the commercialization of such services, the royalties we receive may be lower than those we receive from our current licensing program.

[0001234452-17-000028:mdna:190]
Over the long-term, we need to continue to evolve our patent portfolio. If we do not maintain a strong portfolio that is applicable to current and/or future standards (such as 5G), products and/or services, our future licensing revenues could be negatively impacted.

[0001234452-17-000028:mdna:191]
The licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, certain of our license agreements (including essentially all of our recent agreements in China) are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of a specified term, or to receive royalties after the specified time period, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. Accordingly, to the extent not renewed on their terms or by election for an additional (generally multi-year) period, if applicable, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. We might not be able to renew those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in renewing a license agreement prior to its expiration, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001234452-17-000028:mdna:192]
We depend on a limited number of third-party suppliers for the procurement, manufacture and testing of our products. If we fail to execute supply strategies that provide technology leadership, supply assurance and low cost, our operating results and our business may be harmed. We are also subject to order and shipment uncertainties that could negatively impact our operating results.

[0001234452-17-000028:mdna:193]
Our QCT segment currently utilizes a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Under the turnkey model, our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services such as wafer bump, probe, assembly and the majority of our final test requirements. The semiconductor manufacturing foundries that supply products to our QCT segment are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders. The following could have an adverse effect on our ability to meet customer demands and/or negatively impact our revenues, business operations, profitability and/or cash flows:

[0001234452-17-000028:mdna:194]
[same as prior period, unchanged from 0001234452-16-000483:mdna:166]

[0001234452-17-000028:mdna:195]
[same as prior period, unchanged from 0001234452-16-000483:mdna:167]

[0001234452-17-000028:mdna:196]
[same as prior period, unchanged from 0001234452-16-000483:mdna:168]

[0001234452-17-000028:mdna:197]
| • | our suppliers’ delay in developing leading process technologies, or inability to develop or maintain leading process technologies, including transitions to smaller geometry process technologies; |

[0001234452-17-000028:mdna:198]
| • | the loss of a supplier or the inability of a supplier to meet performance, quality or yield specifications or delivery schedules; and/or |

[0001234452-17-000028:mdna:199]
[same as prior period, unchanged from 0001234452-16-000483:mdna:170]

[0001234452-17-000028:mdna:200]
While we have established alternate suppliers for certain technologies, we rely on sole- or limited-source suppliers for certain products, subjecting us to significant risks, including: possible shortages of raw materials or manufacturing capacity;

[0001234452-17-000028:mdna:201]
40

[0001234452-17-000028:mdna:202]
poor product performance; and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established alternate suppliers, these suppliers may require significant levels of support to bring complex technologies to production. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, any future consolidation of foundry suppliers could increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions and/or increase our manufacturing costs. Our arrangements with our suppliers may obligate us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies, and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Our inability to meet customer demand due to sole- or limited-sourcing and/or the additional costs that we incur because of these or other supply constraints or because of the need to support alternate suppliers could negatively impact our business and our results of operations.

[0001234452-17-000028:mdna:203]
[same as prior period, unchanged from 0001234452-16-000483:mdna:174]

[0001234452-17-000028:mdna:204]
[same as prior period, unchanged from 0001234452-16-000483:mdna:175]

[0001234452-17-000028:mdna:205]
[same as prior period, unchanged from 0001234452-16-000483:mdna:176]

[0001234452-17-000028:mdna:206]
[same as prior period, unchanged from 0001234452-16-000483:mdna:177]

[0001234452-17-000028:mdna:207]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our operating results.

[0001234452-17-000028:mdna:208]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be

[0001234452-17-000028:mdna:209]
successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (and/or on the sale of our customers’ devices using such products) and/or the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001234452-17-000028:mdna:210]
Certain legal matters, including certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001234452-17-000028:mdna:211]
We may engage in strategic acquisitions, transactions or make investments that could adversely affect our financial results or fail to enhance stockholder value.

[0001234452-17-000028:mdna:212]
We engage in strategic acquisitions and other transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. We acquire businesses and other assets, including patents, technology, wireless spectrum and other intangible assets, enter into joint ventures or other strategic transactions, and purchase minority equity interests in or make loans to companies that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications and new industry segments. Recent material transactions include our acquisition of CSR plc, our pending joint venture with TDK Corporation and our proposed acquisition of NXP. Many of our strategic activities entail a high degree of risk and require the use of domestic and/or foreign capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies, products or services. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our financial results, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited. We may underestimate the costs and/or overestimate the benefits, including product and other synergies and growth opportunities that we expect to realize, and we may not achieve them. If we do not achieve the anticipated benefits of business acquisitions or other strategic activities, our results of operations may be adversely affected, and we may not enhance stockholder value by engaging in these transactions.

[0001234452-17-000028:mdna:213]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, technology, products, processes, operations (including manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development and/or supply operations; minimizing the diversion of management’s attention from ongoing business matters; and consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models (including manufacturing), geographic regions, industry segments and/or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of the combination.

[0001234452-17-000028:mdna:214]
Our use of open source software may harm our business.

[0001234452-17-000028:mdna:215]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe we will continue to see, an increase in customers requesting that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of a product’s source code and may expose related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of the open source software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make

[0001234452-17-000028:mdna:216]
such source code available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Developing open source products, while adequately protecting the intellectual property rights upon which our licensing business depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ adequate controls to protect our intellectual property rights, our use of open source software presents risks that could have an adverse effect on these rights and on our business.

[0001234452-17-000028:mdna:217]
Our stock price, earnings and the fair value of our investments are subject to substantial quarterly and annual fluctuations and to market downturns.

[0001234452-17-000028:mdna:218]
Our stock price and earnings have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and/or earnings include those identified throughout this Risk Factors section, volatility of the stock market in general and technology-based companies in particular, announcements concerning us, our suppliers, our competitors or our customers or licensees, and variations between our actual results or guidance and expectations of securities analysts, among others. Further, increased volatility in the financial markets and/or overall economic conditions may reduce the amounts that we realize in the future on our cash equivalents and/or marketable securities and may reduce our earnings as a result of any impairment charges that we record to reduce recorded values of marketable securities to their fair values.

[0001234452-17-000028:mdna:219]
In the past, securities class action litigation has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001234452-17-000028:mdna:220]
We maintain an extensive investment portfolio of varied holdings, which are generally classified as available-for-sale and are therefore recorded on our consolidated balance sheet at fair value, with unrealized gains or losses reported as a component of accumulated other comprehensive income. The fair value of our investments are subject to fluctuation based primarily on market price volatility, as well as the underlying operations of the associated investment, among other things. If the fair value of such investments decreases below their cost basis, as some of our previous investments have, we may be required in certain circumstances to recognize a loss in our results of operations. The sensitivity of and risks associated with the market value of our investment portfolio are described more fully in our Annual Report on Form 10-K for our fiscal year ended September 25, 2016 and “Part 1, Item 3. Quantitative and Qualitative Disclosures About Market Risk” in this Quarterly Report.

[0001234452-17-000028:mdna:221]
[same as prior period, unchanged from 0001234452-16-000483:mdna:191]

[0001234452-17-000028:mdna:222]
Our outstanding indebtedness and any additional indebtedness we incur, including in connection with our proposed acquisition of NXP, may have negative consequences on our business, including, among others:

[0001234452-17-000028:mdna:223]
[same as prior period, unchanged from 0001234452-16-000483:mdna:193]

[0001234452-17-000028:mdna:224]
[same as prior period, unchanged from 0001234452-16-000483:mdna:194]

[0001234452-17-000028:mdna:225]
[same as prior period, unchanged from 0001234452-16-000483:mdna:195]

[0001234452-17-000028:mdna:226]
[same as prior period, unchanged from 0001234452-16-000483:mdna:196]

[0001234452-17-000028:mdna:227]
Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to general economic conditions, industry cycles and financial, business and other factors, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations in the future to service our debt, we may be required to, among other things: repatriate funds to the United States at substantial tax cost; refinance or restructure all or a portion of our indebtedness; reduce or delay planned capital or operating expenditures; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing and/or restructuring are higher than our current rates, interest expense related to such refinancing and/or restructuring would increase. If there are adverse changes in the ratings assigned to our debt securities by credit rating

[0001234452-17-000028:mdna:228]
[same as prior period, unchanged from 0001234452-16-000483:mdna:172]

[0001234452-17-000028:mdna:229]
agencies, our borrowing costs, our ability to access debt in the future and/or the terms of such debt could be adversely affected.

[0001234452-17-000028:mdna:230]
Global, regional or local economic conditions that impact the mobile communications industry or the other industries in which we operate could negatively affect the demand for our products and services and our customers’ or licensees’ products and services, which may negatively affect our revenues.

[0001234452-17-000028:mdna:231]
A decline in global, regional or local economic conditions or a slow-down in economic growth, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could have adverse, wide-ranging effects on demand for our products and for the products and services of our customers or licensees, particularly equipment manufacturers or others in the wireless communications industry who buy their products, such as wireless operators. Any prolonged economic downturn may result in a decrease in demand for our products or technologies; the insolvency of key suppliers, customers or licensees; delays in reporting and/or payments from our licensees and/or customers; failures by counterparties; and negative effects on wireless device inventories. In addition, our customers’ ability to purchase or pay for our products and services and network operators’ ability to upgrade their wireless networks could be adversely affected by economic conditions, leading to a reduction, cancelation or delay of orders for our products or services.

[0001234452-17-000028:mdna:232]
[same as prior period, unchanged from 0001234452-16-000483:mdna:198]

[0001234452-17-000028:mdna:233]
Our future success depends largely upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them, particularly in an environment of cost reductions. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. The market for employees in our industry is extremely competitive. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001234452-17-000028:mdna:234]
[same as prior period, unchanged from 0001234452-16-000483:mdna:200]

[0001234452-17-000028:mdna:235]
Our customers sell their products throughout the world in various currencies. Our consolidated revenues from international customers as a percentage of our total revenues were greater than 90% in each of the last three fiscal years. Adverse movements in currency exchange rates may negatively affect our business and our operating results due to a number of factors, including, among others:

[0001234452-17-000028:mdna:236]
[same as prior period, unchanged from 0001234452-16-000483:mdna:202]

[0001234452-17-000028:mdna:237]
[same as prior period, unchanged from 0001234452-16-000483:mdna:203]

[0001234452-17-000028:mdna:238]
[same as prior period, unchanged from 0001234452-16-000483:mdna:204]

[0001234452-17-000028:mdna:239]
[same as prior period, unchanged from 0001234452-16-000483:mdna:205]

[0001234452-17-000028:mdna:240]
[same as prior period, unchanged from 0001234452-16-000483:mdna:208]

[0001234452-17-000028:mdna:241]
The use of devices containing our products to access untrusted content creates a risk of exposing the system software in those devices to viral or malicious attacks. While we continue to focus on this issue and are taking measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more data and processes, such as computing, and increasing the risk of security failures. Further, our products are inherently complex and may contain defects or errors that are detected only when the products are in use. The design process interface in new domains of technology and the migration to integrated circuit technologies with smaller geometric feature sizes are complex and add risk to manufacturing yields and reliability. Further, manufacturing, testing, marketing and use of our products and those of our customers and licensees entail the risk of product liability. Because our products and services are responsible for critical functions in our customers’ products and/or networks, security failures, defects or errors in our products or services could

[0001234452-17-000028:mdna:242]
have an adverse impact on us, on our customers and/or on the end users of our customers’ products. Such adverse impact could include product liability claims or recalls, write-offs of our inventories and/or intangible assets; unfavorable purchase commitments; a shift of business to our competitors; a decrease in demand for connected devices and wireless services; damage to our reputation and to our customer relationships; and other financial liability or harm to our business. Further, security failures, defects or errors in the products of our customers or licensees, such as the recent issues with the Galaxy Note 6 that caused Samsung to discontinue that product, could have an adverse impact on our operating results due to a delay or decrease in demand for our products or services generally, and our premium-tier products in particular, among other factors.

[0001234452-17-000028:mdna:243]
[same as prior period, unchanged from 0001234452-16-000483:mdna:210]

[0001234452-17-000028:mdna:244]
[same as prior period, unchanged from 0001234452-16-000483:mdna:211]

[0001234452-17-000028:mdna:245]
[same as prior period, unchanged from 0001234452-16-000483:mdna:212]

[0001234452-17-000028:mdna:246]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-United States headquarters is located. Significant judgment is required in determining our provision for income taxes. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision and results of operations in the period or periods in which that determination is made could be negatively affected.

[0001234452-17-000028:mdna:247]
We have tax incentives in Singapore provided that we meet specified employment and other criteria, and as a result of the expiration of these incentives, our Singapore tax rate is expected to increase in fiscal 2017 and again in fiscal 2027. If we do not meet the criteria required to retain such incentives, our Singapore tax rate could increase prior to fiscal 2027, and our results of operations could be adversely affected.

[0001234452-17-000028:mdna:248]
Tax rules may change in a manner that adversely affects our future reported financial results or the way we conduct our business. For example, we consider the operating earnings of certain non-United States subsidiaries to be indefinitely reinvested outside the United States based on our current needs for those earnings to be reinvested offshore as well as estimates that future domestic cash generated from operations and/or borrowings will be sufficient to meet future domestic cash needs for the foreseeable future. No provision has been made for United States federal, state or foreign taxes that may result from future remittances of the undistributed earnings of these foreign subsidiaries. Our future financial results and liquidity may be adversely affected if tax rules regarding unrepatriated earnings change, if domestic cash needs require us to repatriate foreign earnings, if the shares of these foreign subsidiaries were sold or otherwise transferred or if the United States international tax rules change as part of comprehensive tax reform or other tax legislation.

[0001234452-17-000028:mdna:249]
Further changes in the tax laws of foreign jurisdictions could arise as a result of the base erosion and profit shifting (BEPS) project that was undertaken by the Organization for Economic Co-operation and Development (OECD). The OECD, which represents a coalition of member countries, recommended changes to numerous long-standing tax principles related to transfer pricing. These changes, if adopted by countries, could increase tax uncertainty and may adversely affect our provision for income taxes. We have not yet determined what changes, if any, may be needed to our operations or structure to address BEPS. If our effective tax rates were to increase, particularly in the United States or Singapore, our operating results, cash flows and/or financial condition could be adversely affected.
