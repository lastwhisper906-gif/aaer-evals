# QCOM notes — 0001234452-17-000028


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001234452-17-000028:notes:1]
[same as prior period, unchanged from 0001234452-16-000483:notes:1]

[0001234452-17-000028:notes:2]
| Inventories (in millions) |  |  |  |
|  | December 25, 2016 |  | September 25, 2016 |
| Raw materials | $ | — |  |  | $ | 1 |  |
| Work-in-process | 1,016 |  |  | 847 |  |
| Finished goods | 894 |  |  | 708 |  |
|  | $ | 1,910 |  |  | $ | 1,556 |  |

[0001234452-17-000028:notes:3]
| Other Current Liabilities (in millions) |  |  |  |
|  | December 25, 2016 |  | September 25, 2016 |
| Customer incentives and other customer-related liabilities | $ | 1,985 |  |  | $ | 1,710 |  |
| Charge related to the KFTC investigation (Note 6) | 868 |  |  | — |  |
| Other | 392 |  |  | 551 |  |
|  | $ | 3,245 |  |  | $ | 2,261 |  |

[0001234452-17-000028:notes:4]
Other Income, Costs and Expenses. Other expenses in the three months ended December 25, 2016 consisted of an $868 million charge related to the Korea Fair Trade Commission (KFTC) investigation (Note 6) and $8 million in restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan, which was substantially implemented in fiscal 2016.

[0001234452-17-000028:notes:5]
Other income in the three months ended December 27, 2015 included a gain of $380 million on the sale of wireless spectrum in the United Kingdom that was held by the QSI (Qualcomm Strategic Initiatives) segment in the first quarter of fiscal 2016 for $232 million in cash and $275 million in deferred payments due in 2020 to 2023, which were recorded at their present values in other assets. Other income in the three months ended December 27, 2015 also included $54 million in restructuring and restructuring-related charges, which were partially offset by a $48 million gain on the sale of the Company’s business that provided augmented reality applications, both of which related to the Company’s Strategic Realignment Plan.

[0001234452-17-000028:notes:6]
| Investment Income, Net (in millions) |  |  |  |
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |
| Interest and dividend income | $ | 167 |  |  | $ | 136 |  |
| Net realized gains on marketable securities | 139 |  |  | 43 |  |
| Net realized gains on other investments | 8 |  |  | 6 |  |
| Impairment losses on marketable securities | (122 | ) |  | (49 | ) |
| Impairment losses on other investments | (21 | ) |  | (14 | ) |
| Equity in net earnings (losses) of investees | 3 |  |  | (20 | ) |
| Net gains (losses) on derivative investments | 8 |  |  | (3 | ) |
|  | $ | 182 |  |  | $ | 99 |  |

[0001234452-17-000028:notes:7]
There were no net impairment losses on marketable securities related to the noncredit portion of losses on debt securities recognized in other comprehensive income in the three months ended December 25, 2016, and such losses were negligible in the three months ended December 27, 2015. The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was negligible and $22 million at December 25, 2016 and December 27, 2015, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001234452-17-000028:notes:8]
[same as prior period, unchanged from 0001234452-16-000483:notes:8]

[0001234452-17-000028:notes:9]
In January 2016, the Company announced that it had reached agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd., to enable delivery of radio frequency front-end (RFFE) modules and RF filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others. The joint venture will initially be owned 51% by Qualcomm Global Trading Pte. Ltd., a Singapore corporation and wholly-owned subsidiary of the Company (Qualcomm Global Trading) and 49% by EPCOS AG, a German Aktiengesellschaft and wholly-owned subsidiary of TDK Corporation (EPCOS). Certain intellectual property, patents and filter and module design and manufacturing assets will be carved out of existing TDK businesses and be owned by the joint venture, and certain assets will be acquired directly by affiliates of the Company. The purchase price of Qualcomm Global Trading’s interest in the joint venture and the assets to be transferred to the Company is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, Qualcomm Global Trading has the option to acquire (and EPCOS has an option to sell) EPCOS’s interest in the joint venture for $1.15 billion 30 months after the closing date. EPCOS will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date, which is a substitute for and in lieu of any right of EPCOS to receive any profit sharing, distributions, dividends or other payments of any kind or nature. Every required regulatory agency has either approved the transaction or declined to exercise jurisdiction. The completion of the transaction remains subject to satisfaction of additional conditions and is expected to close in the second quarter of fiscal 2017.

[0001234452-17-000028:notes:10]
On October 27, 2016, the Company announced a definitive agreement under which Qualcomm River Holdings, B.V. (Qualcomm River Holdings), an indirect, wholly owned subsidiary of QUALCOMM Incorporated, will acquire NXP Semiconductors N.V. Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration of $38 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products.

[0001234452-17-000028:notes:11]
The transaction is expected to close by the end of calendar 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions, including the tender of specified percentages (which vary from 70% to 95% based on certain circumstances as provided in the definitive agreement) of the issued and outstanding common shares of NXP in the offer. An Extraordinary General Meeting of NXP’s shareholders will be convened in connection with the offer to adopt, among other things, certain resolutions relating to the transaction. The tender offer is not subject to any financing condition; however, the Company intends to fund the transaction with cash held by foreign entities and new debt. As a result, the Company has secured $13.6 billion in committed financing through a $9.6 billion Bridge Loan Facility and $4.0 billion Term Loan Facility (Note 5). The Company expects to issue additional debt, including accessing the public debt markets in fiscal 2017, in lieu of drawing on the Bridge Loan Facility at close of the NXP transaction.

[0001234452-17-000028:notes:12]
Qualcomm River Holdings and NXP may terminate the definitive agreement under certain circumstances. If the definitive agreement is terminated by NXP in certain circumstances, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the definitive agreement is terminated by Qualcomm River Holdings under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion. In November 2016, as required by the definitive agreement, Qualcomm River Holdings entered into four letters of credit for an aggregate amount of $2.0 billion related to the potential termination fee payable to NXP. Pursuant to the terms of each letter of credit, NXP will have the right to draw amounts to fund certain termination compensation owed by Qualcomm River Holdings to NXP if the definitive agreement is terminated under certain circumstances. The letters of credit expire on June 30, 2018 or if drawn on by NXP or surrendered by Qualcomm River Holdings. Each letter of credit is required to be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. Qualcomm River Holdings is restricted from using the funds deposited as collateral while the letters of credit are outstanding. At December 25, 2016, $1.95 billion of the letters of credit were collateralized through bank time deposits and money market funds, which were recorded as other noncurrent assets, and the remaining $50 million was collateralized in the second quarter of fiscal 2017.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001234452-17-000028:notes:13]
Commitments and Contingencies

[0001234452-17-000028:notes:14]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe certain ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 ParkerVision patents and seeks damages and injunctive and other relief. On September 25, 2015, ParkerVision filed a motion with the court to sever some claims against the Company and all other defendants into a separate lawsuit. In addition, on December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against the Company and other parties with the United States International Trade Commission (ITC) described below.

[0001234452-17-000028:notes:15]
On December 14, 2015, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. are also named defendants. The complaint asserts that certain of the Company’s products infringe four additional ParkerVision patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. The ITC hearing is scheduled to begin on March 13, 2017. The ITC’s target date for completion of the investigation is October 23, 2017. The District Court case was stayed on February 12, 2016 pending completion of the ITC investigation.

[0001234452-17-000028:notes:16]
The Company believes ParkerVision’s claims in the above matters are without merit.

[0001234452-17-000028:notes:17]
Blackberry Limited (Blackberry) Arbitration: On April 20, 2016, the Company and Blackberry entered into an agreement to arbitrate Blackberry’s allegation that it overpaid royalties on certain past sales of subscriber units based on the alleged effect of specific provisions in its license agreement. The arbitration, which is scheduled to begin on February 27, 2017, is being conducted under the rules of the Judicial Arbitration and Mediation Services in San Diego, California. Blackberry seeks the return of the alleged overpayment. The Company believes Blackberry’s claims are without merit.

[0001234452-17-000028:notes:18]
QUALCOMM Incorporated v. Meizu Technology Co., Ltd. et al: On June 23, 2016 and June 29, 2016, the Company filed a series of actions against Meizu Technology Co., Ltd., aka Zhuhai Meizu Technology Co., Ltd. (Meizu) and certain of its distributors in the Intellectual Property Courts in Beijing and Shanghai (China). The first complaint, filed in Beijing on June 23, 2016, requests rulings that the terms of a patent license offered by the Company to Meizu comply with China’s Anti-Monopoly Law and the Company’s applicable fair, reasonable and non-discriminatory licensing commitment. The complaint also seeks a ruling that the offered patent license terms should form the basis for a patent license with Meizu for the Company’s fundamental mobile device technologies patented in China, including those relating to 3G (WCDMA and CDMA2000) and 4G (LTE) wireless communications standards, and seeks damages for Meizu’s past use of the Company’s patented inventions. On June 29, 2016, the Company filed patent infringement complaints in the Intellectual Property Courts in Beijing and Shanghai alleging infringement of 17 patents by Meizu. The patent infringement actions concern a broad range of features and technologies used in smartphones, including features relating to 3G (WCDMA and CDMA2000) and 4G (LTE) wireless communications standards, and seek to enjoin Meizu from manufacturing, selling and offering for sale mobile devices that infringe the asserted patents. The courts are currently considering various jurisdictional challenges raised by Meizu. No final schedules have been set by the courts. Meizu has also filed actions before China’s Patent Reexamination Board challenging the validity of each of the asserted patents. These actions are proceeding in parallel with the litigation.

[0001234452-17-000028:notes:19]
On October 14, 2016, the Company filed patent infringement complaints against Meizu in the United States ITC and the Mannheim Regional Court in Germany. The ITC complaint seeks an exclusion order enjoining Meizu and certain of its distributors from the importation, sale for importation and sale after importation of Meizu mobile devices that infringe certain of the Company’s patents related to semiconductor, radio frequency and digital camera technologies. The German complaint seeks damages and to enjoin Meizu from offering, putting into circulation, using, possessing or importing into Germany mobile devices that infringe one of the Company’s patents related to wireless messaging technology. On the same day, the Company also initiated a seizure action in France pursuant to orders from the Paris District Court to obtain evidence for a possible future infringement action in that country.

[0001234452-17-000028:notes:20]
On December 26, 2016, the Company and Meizu entered into a patent license agreement whereby the Company granted Meizu a worldwide royalty-bearing patent license to develop, manufacture and sell CDMA2000, WCDMA and 4G LTE (including “3-mode” GSM, TD-SCDMA and LTE-TDD) complete devices. This agreement resolves all of the patent disputes between the Company and Meizu in China, Germany, France and the United States. Accordingly, the Company and Meizu have agreed to take appropriate steps to terminate or withdraw all of the foregoing complaints and actions.

[0001234452-17-000028:notes:21]
Apple Inc. (Apple) v. Qualcomm Incorporated: On January 20, 2017, Apple filed a complaint against the Company in the United States District Court for the Southern District of California seeking declarations with respect to several of the Company’s patents and alleging that the Company breached certain agreements and violated federal antitrust and California state unfair competition laws. In particular, Apple seeks declaratory judgments of non-infringement by Apple of nine of the Company’s patents, or in the alternative, a declaration of royalties Apple must pay for the patents. Apple further seeks a declaration that the Company’s sale of baseband chipsets exhausts the Company’s patent rights for patents embodied in those chipsets. Separately, Apple seeks to enjoin the Company from seeking excessive royalties from Apple and to disgorge royalties paid by Apple’s contract manufacturers that the court finds were not fair, reasonable and non-discriminatory. Apple also claims the Company’s refusal to make certain payments to Apple under a Business Cooperation and Patent Agreement constitutes a breach of contract in violation of California law and seeks damages in the amount of the unpaid payments, alleged to be approximately $1 billion. In addition, Apple claims that the Company has refused to deal with competitors in contravention of the Company’s agreements with applicable standard setting organizations, has used its market position to impose contractual obligations on Apple that prevented Apple from challenging the Company’s licensing practices, has tied the purchase of the Company’s CDMA-enabled and premium LTE-enabled chipsets to licensing certain of the Company’s patents and has required Apple to purchase baseband processor chipsets exclusively from the Company as a condition of the Company’s payment to Apple of certain rebates, in violation of Section 2 of the Sherman Act and the California Unfair Competition Law. Apple seeks injunctive relief with respect to these claims and a judgment awarding its expenses, costs and attorneys’ fees.

[0001234452-17-000028:notes:22]
On January 25, 2017, the Company learned that an Apple subsidiary, Apple Electronic Products Trading (Beijing) Co., Ltd. (collectively with Apple Inc., Apple), has also filed two complaints against the Company and certain of the Company’s subsidiaries in the Beijing Intellectual Property Court in China. The Company has not yet been served with the complaints. Based on a press release from the Court, the Company understands that one of the complaints alleges a violation of China’s Anti-Monopoly Law (AML), and the other requests a determination of the terms of a patent license between the Company and Apple. In particular, the AML complaint alleges that the Company has abused its dominant position in communication standards-essential patents (SEPs) licensing markets and the global baseband chipset market by offering royalty terms that were excessively high; that the Company refused to license certain implementers of standardized technologies; that the Company restricted Apple to using only products and services provided or approved by the Company; and that the Company engaged in other bundling and discriminatory conduct and imposed unreasonable trading terms on Apple in violation of the AML. Apple seeks economic damages in the amount of 1 billion Chinese Renminbi (approximately $145 million based on current exchange rates). The other complaint alleges that the Company refused to provide a royalty offer to Apple for the Company’s cellular SEPs consistent with the Company’s fair, reasonable and non-discriminatory (FRAND) licensing commitments. Apple has requested the Court make a determination of the terms of a patent license between the Company and Apple consistent with the Company’s FRAND obligations. Apple also seeks its expenses in each of the cases.

[0001234452-17-000028:notes:23]
The Company believes Apple’s claims in the above matters are without merit.

[0001234452-17-000028:notes:24]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, plaintiffs filed a securities class action complaint against the Company and certain of its current and former officers in the United States District Court for the Southern District of California. On April 29, 2016, plaintiffs filed an amended complaint alleging that the Company and certain of its current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding the Company’s business outlook and product development between April 7, 2014 and July 22, 2015. The amended complaint seeks unspecified damages, interest, attorneys’ fees and other costs. On June 28, 2016, the Company filed a Motion to Dismiss the amended complaint, which Motion was heard by the Court on November 7, 2016. The Company believes the plaintiffs’ claims are without merit.

[0001234452-17-000028:notes:25]
Bornstein et al. v. QUALCOMM Incorporated: On January 18, 2017, a complaint was filed against the Company in the United States District Court for the Northern District of California on behalf of a putative class of purchasers of cellular phones and other cellular devices alleging that the Company violated various federal and state antitrust and consumer protection laws by, among other things, refusing to license standard-essential patents to its competitors, conditioning the supply of certain of its baseband processors on the purchaser first agreeing to license the Company’s entire patent portfolio, entering into alleged exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that allegedly do not comply with the Company’s commitments to standard-setting organizations. The complaint further alleges that, as a result of the foregoing conduct, the Company was unjustly enriched. The complaint seeks unspecified damages, interest, attorneys’ fees and other costs, and that the Company and related parties be enjoined from further unlawful conduct. The Company believes the plaintiffs’ claims are without merit.

[0001234452-17-000028:notes:26]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 34 different dates, with the next hearing scheduled for April 24, 2017.

[0001234452-17-000028:notes:27]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments since then with respect to this matter.

[0001234452-17-000028:notes:28]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it was conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that the Company has violated provisions of the MRFTA. On January 22, 2017, the Company received the KFTC’s formal written decision, which finds that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with the Company; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders the Company to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chips; (iii) not demand unjustifiable conditions in the Company’s license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on the Company and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between the Company and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposes a fine of approximately 1.03 trillion Korean Won (approximately $868 million based on exchange rates at December 25, 2016), which was recorded as a charge to other expenses in the first quarter of fiscal 2017. The Company believes that its business practices do not violate the MRFTA, and intends to challenge the decision in the Seoul High Court. The Company will also seek a stay of the decision’s remedial order.

[0001234452-17-000028:notes:29]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company provided additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On August 15, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

[0001234452-17-000028:notes:30]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that since 2011 the Company has paid significant amounts to a customer on condition that it exclusively use the Company’s baseband chipsets in its smartphones and tablets. This conduct has allegedly reduced the customer’s incentives to source chipsets from the Company’s competitors and harmed competition and innovation for certain baseband chipsets. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On June 27, 2016, the Company submitted its response to the Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

[0001234452-17-000028:notes:31]
(United States) Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified the Company that it was conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against the Company in the United States District Court for the Northern District of California alleging that the Company engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of baseband processors on the purchaser first agreeing to a license to the Company’s standard-essential patents, paying incentives to purchasers of baseband processors to induce them to accept certain license terms, refusing to license its standard-essential patents to the Company’s competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint seeks a permanent injunction against the Company’s alleged violations of the FTCA and other unspecified ancillary equitable relief. The Company believes the FTC’s claims are without merit.

[0001234452-17-000028:notes:32]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified the Company that it is conducting an investigation into whether the Company’s patent licensing arrangements violate the Taiwan Fair Trade Act (TFTA). On April 27, 2016, the TFTC specified that the allegations under investigation include whether: (i) the Company jointly licensed its patents rather than separately licensing standard-essential patents and non-standard-essential patents; (ii) the Company’s royalty charges are unreasonable; (iii) the Company unreasonably required licensees to grant it cross-licenses; (iv) the Company failed to provide lists of licensed patents to licensees; (v) the Company violated a FRAND licensing commitment by declining to grant licenses to chipset makers; (vi) the Company declined to sell chipsets to unlicensed potential customers; and (vii) the Company provided royalty rebates to certain companies in exchange for their exclusive use of the Company’s chipsets. If a violation is found, a broad range of remedies is potentially available to the TFTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the TFTC. The Company believes that its business practices do not violate the TFTA. The Company continues to cooperate with the TFTC as it conducts its investigation.

[0001234452-17-000028:notes:33]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. Other than with respect to the KFTC Investigation, the Company has not recorded any accrual at December 25, 2016 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001234452-17-000028:notes:34]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0001234452-17-000028:notes:35]
Through December 25, 2016, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at December 25, 2016 associated with these indemnification arrangements based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001234452-17-000028:notes:36]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at December 25, 2016 for the remainder of fiscal 2017 and for each of the subsequent four years from fiscal 2018 through 2021 were $3.7 billion, $879 million, $771 million, $230 million and $42 million, respectively, and $5 million thereafter. Of these amounts, for the remainder of fiscal 2017 and for each of the subsequent three years from fiscal 2018 through 2020, commitments to purchase integrated circuit product inventories comprised $2.9 billion, $761 million, $696 million, $165 million, respectively, and there were no purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

[0001234452-17-000028:notes:37]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments at December 25, 2016 for the remainder of fiscal 2017 and for each of the subsequent four years from fiscal 2018 through 2021 were $67 million, $77 million, $63 million, $46 million and $38 million, respectively, and $47 million thereafter.

[0001234452-17-000028:notes:38]
Other Commitments. At December 25, 2016, the Company was committed to fund certain strategic investments up to $349 million. Of this amount, $113 million is expected to be funded in the remainder of fiscal 2017. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.


## us-gaap:DebtDisclosureTextBlock

[0001234452-17-000028:notes:39]
Debt

[0001234452-17-000028:notes:40]
Revolving Credit Facility. In November 2016, the Company amended and restated its existing Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit (Amended and Restated Revolving Credit Facility) to increase the aggregate amount available to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. The Company had not previously borrowed any funds under the existing Revolving Credit Facility. Proceeds from the Amended and Restated Revolving Credit Facility are expected to be used for general corporate purposes. Loans under the Amended and Restated Revolving Credit Facility will bear interest, at the option of the Company, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the Amended and Restated Revolving Credit Facility) or the Base Rate (determined in accordance with the Amended and Restated Revolving Credit Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.70% and 0.00% per annum, respectively. The Amended and Restated Revolving Credit Facility has a facility fee, which initially accrues at a rate of 0.05% per annum. At December 25, 2016, the Company had not borrowed any funds under the Amended and Restated Revolving Credit Facility.

[0001234452-17-000028:notes:41]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At December 25, 2016 and September 25, 2016, the Company had $1.7 billion of outstanding commercial paper recorded as short-term debt with weighted-average interest rates of 0.64% and 0.52%, respectively, which included fees paid to the commercial paper dealers and weighted-average remaining days to maturity of 41 days and 36 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at December 25, 2016 and September 25, 2016.

[0001234452-17-000028:notes:42]
Bridge Loan Facility. In October 2016, the Company entered into commitment letters pursuant to which the Company received commitments for senior unsecured bridge facility loans in an aggregate principal amount up to $13.6 billion (Bridge Loan Facility). In November 2016, the commitments available under the Bridge Loan Facility were reduced to $9.6 billion upon the Company entering into a $4.0 billion Term Loan Facility, described below. Proceeds from the Bridge Loan Facility, if drawn, will be used to finance, in part, the proposed acquisition of NXP Semiconductors N.V. by Qualcomm River Holdings B.V., a wholly owned subsidiary of the Company (Qualcomm River Holdings) (Note 8). Loans under the Bridge Loan Facility will only be available on the closing date of the proposed acquisition of NXP. The commitments available under the Bridge Loan Facility will be reduced on a dollar-for-dollar basis by the net cash proceeds of certain issuances of debt or equity securities and the incurrence of certain indebtedness by the Company, and the sales of certain assets by the Company and NXP. Commitments under the Bridge Loan Facility will expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the Bridge Loan Facility, (ii) the termination of Qualcomm River Holding’s obligation to consummate the proposed acquisition of NXP and (iii) October 27, 2017 (unless such date is extended in accordance with the NXP purchase agreement).

[0001234452-17-000028:notes:43]
Loans drawn under the Bridge Loan Facility will mature 364 days after the date on which the Bridge Loan Facility is funded and will bear interest at either the reserve-adjusted Eurodollar Rate (determined in accordance with the Bridge Loan Facility) or the Base Rate (determined in accordance with the Bridge Loan Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurodollar Rate and the Base Rate will be 0.75% and 0.00% per annum, respectively, and will adjust 90 days, 180 days and 270 days after the Bridge Loan Facility is funded to 1.00% and 0.00%, respectively, 1.25% and 0.25%, respectively, and 1.50% and 0.50%, respectively. Loans outstanding under the Bridge Loan Facility will also incur duration fees equal to 0.50%, 0.75% and 1.00% of the outstanding principal amount of Bridge Loan Facility loans on the dates that are 90 days, 180 days and 270 days after the funding date, respectively. The Bridge Loan Facility also has a ticking fee, which initially accrues at a rate of 0.05% per annum commencing on December 26, 2016. At December 25, 2016, no amounts were outstanding under the Bridge Loan Facility.

[0001234452-17-000028:notes:44]
Term Loan Facility. In November 2016, the Company entered into a Credit Agreement that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion (Term Loan Facility). Proceeds from the Term Loan Facility, if drawn, will be used to finance the proposed acquisition of NXP. Commitments under the Term Loan Facility will expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the Term Loan Facility, (ii) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP and (iii) October 27, 2017 (unless such date is extended in accordance with the NXP purchase agreement). Loans under the Term Loan Facility will mature on the third anniversary of the date on which they are funded and will bear interest at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the Term Loan Facility) or the Base Rate (determined in accordance with the Term Loan Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.875% and 0.00% per annum, respectively. The Term Loan Facility has a ticking fee, which initially accrues at a rate of 0.05% per annum commencing on December 26, 2016. At December 25, 2016, the Company had not borrowed any funds under the Term Loan Facility.

[0001234452-17-000028:notes:45]
Long-term Debt. The following table provides a summary of the Company’s long-term debt (in millions except percentages):

[0001234452-17-000028:notes:46]
|  | December 25, 2016 |  | September 25, 2016 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 1.24% |  | $ | 250 |  |  | 1.14% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.52% |  | 250 |  |  | 1.42% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 1.36% |  | 1,250 |  |  | 0.93% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 2.04% |  | 1,750 |  |  | 1.69% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.53% |  | 2,000 |  |  | 2.04% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (55 | ) |  |  |  | (57 | ) |  |  |
| Hedge accounting fair value adjustments | (10 | ) |  |  |  | 65 |  |  |  |
| Total long-term debt | $ | 9,935 |  |  |  |  | $ | 10,008 |  |  |  |

[0001234452-17-000028:notes:47]
The interest rate on the floating rate notes due in 2018 and 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At December 25, 2016 and September 25, 2016, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $10.2 billion and $10.6 billion, respectively.

[0001234452-17-000028:notes:48]
In fiscal 2015, the Company entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings in interest expense in the current period.

[0001234452-17-000028:notes:49]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $134 million and $128 million and in the three months ended December 25, 2016 and December 27, 2015.

[0001234452-17-000028:notes:50]
Debt Covenants. The Amended and Restated Revolving Credit Facility, the Bridge Loan Facility and the Term Loan Facility require, and the prior Revolving Credit Facility required, that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. At December 25, 2016 and September 25, 2016, the Company was in compliance with the applicable covenants under each facility outstanding at such time.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001234452-17-000028:notes:51]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, in the three months ended December 25, 2016 and December 27, 2015 were 17,029,000 and 14,430,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 62,000 and 1,172,000 in the three months ended December 25, 2016 and December 27, 2015, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001234452-17-000028:notes:52]
[same as prior period, unchanged from 0001234452-16-000483:notes:46]

[0001234452-17-000028:notes:53]
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |
| Beginning balance of Level 3 | $ | 43 |  |  | $ | 224 |  |
| Total realized and unrealized gains or losses: |  |  |  |
| Included in other comprehensive income (loss) | — |  |  | (1 | ) |
| Sales | — |  |  | (1 | ) |
| Settlements | (1 | ) |  | (36 | ) |
| Transfers out of Level 3 | — |  |  | (12 | ) |
| Ending balance of Level 3 | $ | 42 |  |  | $ | 174 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001234452-17-000028:notes:54]
[same as prior period, unchanged from 0001234452-16-000483:notes:48]

[0001234452-17-000028:notes:55]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at December 25, 2016 (in millions):

[0001234452-17-000028:notes:56]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 2,385 |  |  | $ | 3,850 |  |  | $ | — |  |  | $ | 6,235 |  |
| Marketable securities |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 915 |  |  | 975 |  |  | — |  |  | 1,890 |  |
| Corporate bonds and notes | — |  |  | 17,747 |  |  | — |  |  | 17,747 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 1,524 |  |  | 42 |  |  | 1,566 |  |
| Equity and preferred securities and equity funds | 88 |  |  | 476 |  |  | — |  |  | 564 |  |
| Debt funds | — |  |  | 1,133 |  |  | — |  |  | 1,133 |  |
| Total marketable securities | 1,003 |  |  | 21,855 |  |  | 42 |  |  | 22,900 |  |
| Derivative instruments | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Other investments | 330 |  |  | — |  |  | — |  |  | 330 |  |
| Total assets measured at fair value | $ | 3,718 |  |  | $ | 25,716 |  |  | $ | 42 |  |  | $ | 29,476 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Other liabilities | 329 |  |  | — |  |  | — |  |  | 329 |  |
| Total liabilities measured at fair value | $ | 329 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 350 |  |

[0001234452-17-000028:notes:57]
Activity between Levels of the Fair Value Hierarchy. There were no significant transfers between Level 1 and Level 2 in the three months ended December 25, 2016 and December 27, 2015. When a determination is made to classify an asset or liability within Level 3, the determination is based upon the significance of the unobservable inputs to the overall fair value measurement. The following table includes the activity for mortgage- and asset-backed and auction rate securities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-17-000028:notes:58]
The Company recognizes transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. Transfers out of Level 3 in the three months ended December 27, 2015 primarily consisted of debt securities with significant upgrades in credit ratings or for which there were observable inputs.

[0001234452-17-000028:notes:59]
Nonrecurring Fair Value Measurements. The Company measures certain assets at fair value on a nonrecurring basis. These assets include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. In the three months ended December 25, 2016 and December 27, 2015, the Company did not have any significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001234452-17-000028:notes:60]
[same as prior period, unchanged from 0001234452-16-000483:notes:54]

[0001234452-17-000028:notes:61]
The Company estimates its annual effective income tax rate to be approximately 22% for fiscal 2017, which is greater than its 17% effective income tax rate for fiscal 2016. Tax benefits from foreign income taxed at rates lower than rates in the United States are expected to be approximately 15% in fiscal 2017, compared to 16% in fiscal 2016. In the first quarter of fiscal 2017, the Company recorded a charge of $868 million related to the KFTC investigation (Note 6), which is not deductible for tax purposes and is attributable to both the United States and a foreign jurisdiction. The estimated annual effective tax rate of 22% for fiscal 2017 also reflects the increase in the Company’s Singapore tax rate as a result of the expiration of its tax exemption in March 2017, which is partially offset by tax benefits resulting from the increase in the Singapore tax rate that will be in effect when certain deferred tax assets are scheduled to reverse. The annual effective tax rate of 17% for fiscal 2016 reflected a $101 million tax benefit recorded discretely in the third quarter of fiscal 2016 resulting from a worthless stock deduction on a domestic subsidiary of one of the Company’s former display businesses and a $79 million benefit recorded discretely in the first quarter of fiscal 2016 related to fiscal 2015 resulting from the retroactive and permanent reinstatement of the United States federal research and development tax credit.

[0001234452-17-000028:notes:62]
Unrecognized tax benefits were $272 million and $271 million at December 25, 2016 and September 25, 2016, respectively. The Company believes that it is reasonably possible that the total amounts of unrecognized tax benefits at December 25, 2016 may increase or decrease in the next 12 months.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001234452-17-000028:notes:63]
At December 25, 2016, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001234452-17-000028:notes:64]
| Years to Maturity |  |  |  |  |
| Less Than One Year |  | One to Five Years |  | Five to Ten Years |  | Greater Than Ten Years |  | No Single Maturity Date |  | Total |
| $ | 5,628 |  |  | $ | 11,797 |  |  | $ | 1,575 |  |  | $ | 637 |  |  | $ | 2,699 |  |  | $ | 22,336 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001234452-17-000028:notes:65]
Marketable Securities

[0001234452-17-000028:notes:66]
Marketable securities were comprised as follows (in millions):

[0001234452-17-000028:notes:67]
|  | Current |  | Noncurrent |
|  | December 25, 2016 |  | September 25, 2016 |  | December 25, 2016 |  | September 25, 2016 |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 251 |  |  | $ | 1,116 |  |  | $ | 1,639 |  |  | $ | 1,099 |  |
| Corporate bonds and notes | 3,312 |  |  | 10,159 |  |  | 14,435 |  |  | 8,584 |  |
| Mortgage- and asset-backed and auction rate securities | 176 |  |  | 1,363 |  |  | 1,390 |  |  | 534 |  |
| Equity and preferred securities and equity funds | 88 |  |  | 64 |  |  | 476 |  |  | 1,682 |  |
| Debt funds | 100 |  |  | — |  |  | 1,033 |  |  | 1,803 |  |
|  | $ | 3,927 |  |  | $ | 12,702 |  |  | $ | 18,973 |  |  | $ | 13,702 |  |

[0001234452-17-000028:notes:68]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities and auction rate securities.

[0001234452-17-000028:notes:69]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001234452-17-000028:notes:70]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| December 25, 2016 | $ | 248 |  |  | $ | (109 | ) |  | $ | 139 |  |
| December 27, 2015 | 50 |  |  | (12 | ) |  | 38 |  |

[0001234452-17-000028:notes:71]
Available-for-sale securities were comprised as follows (in millions):

[0001234452-17-000028:notes:72]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| December 25, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 478 |  |  | $ | 86 |  |  | $ | — |  |  | $ | 564 |  |
| Debt securities (including debt funds) | 22,269 |  |  | 111 |  |  | (44 | ) |  | 22,336 |  |
|  | $ | 22,747 |  |  | $ | 197 |  |  | $ | (44 | ) |  | $ | 22,900 |  |
| September 25, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,554 |  |  | $ | 204 |  |  | $ | (12 | ) |  | $ | 1,746 |  |
| Debt securities (including debt funds) | 24,363 |  |  | 388 |  |  | (93 | ) |  | 24,658 |  |
|  | $ | 25,917 |  |  | $ | 592 |  |  | $ | (105 | ) |  | $ | 26,404 |  |

[0001234452-17-000028:notes:73]
The following table shows the gross unrealized losses and fair values of the Company’s investments in individual securities that are classified as available-for-sale and have been in a continuous unrealized loss position deemed to be temporary for less than 12 months and for more than 12 months, aggregated by investment category (in millions):

[0001234452-17-000028:notes:74]
|  | December 25, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 263 |  |  | $ | (11 | ) |  | $ | 5 |  |  | $ | — |  |
| Corporate bonds and notes | 1,681 |  |  | (28 | ) |  | 59 |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 89 |  |  | (2 | ) |  | 59 |  |  | (1 | ) |
| Debt funds | 489 |  |  | (2 | ) |  | — |  |  | — |  |
|  | $ | 2,522 |  |  | $ | (43 | ) |  | $ | 123 |  |  | $ | (1 | ) |

[0001234452-17-000028:notes:75]
|  | September 25, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 444 |  |  | $ | (5 | ) |  | $ | 16 |  |  | $ | — |  |
| Corporate bonds and notes | 2,775 |  |  | (12 | ) |  | 1,033 |  |  | (65 | ) |
| Mortgage- and asset-backed and auction rate securities | 337 |  |  | (3 | ) |  | 211 |  |  | (2 | ) |
| Equity and preferred securities and equity funds | 312 |  |  | (4 | ) |  | 130 |  |  | (8 | ) |
| Debt funds | — |  |  | — |  |  | 309 |  |  | (6 | ) |
|  | $ | 3,868 |  |  | $ | (24 | ) |  | $ | 1,699 |  |  | $ | (81 | ) |

[0001234452-17-000028:notes:76]
In the first quarter of fiscal 2017, the Company announced that it entered into an agreement to acquire NXP Semiconductors N.V. (Note 8). As a result, prior to the closing, the Company has begun, and expects to continue, to divest a substantial portion of its marketable securities portfolio in order to finance, in part, that transaction. Marketable securities that were expected to be used to finance the NXP transaction were classified as noncurrent at December 25, 2016 as they are not considered available for current operations. Given the change in the Company’s intention to sell certain marketable securities, the Company recognized other-than-temporary impairment losses in the three months ended December 25, 2016 for certain marketable securities (Note 2) and may recognize additional losses prior to the sale of such marketable securities. For the remaining available-for-sale securities, which are not expected to be sold to finance the NXP transaction, the Company concluded that the unrealized losses were temporary at December 25, 2016. Further, for debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which was expected to be within a reasonable period of time, and for debt securities and preferred stock with unrealized losses, the Company did not have the intent to sell, nor was it more likely than not that the Company would be required to sell, such securities before recovery or maturity.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001234452-17-000028:notes:77]
Recent Accounting Pronouncements. In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Adoption one year early is permitted. Two methods of adoption are permitted: (a) full retrospective adoption, meaning the standard is applied to all periods presented or (b) modified retrospective adoption, meaning the cumulative effect of applying the new guidance is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the new guidance early and is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.

[0001234452-17-000028:notes:78]
In January 2016, the FASB issued new guidance on classifying and measuring financial instruments, which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk be recognized separately in other comprehensive income. Additionally, it changes the disclosure requirements for financial instruments. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Early adoption is permitted for certain provisions. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt certain provisions early.

[0001234452-17-000028:notes:79]
In February 2016, the FASB issued new guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease guidance. The new guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. The new guidance must be adopted using the modified retrospective approach and will be effective for the Company starting in the first quarter of fiscal 2020. Early adoption is permitted. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.

[0001234452-17-000028:notes:80]
In March 2016, the FASB issued new guidance that changes the accounting for share-based payments. Under the new guidance, excess tax benefits associated with share-based payment awards will be recognized through earnings when the awards vest or settle, rather than in stockholders’ equity. In addition, it will increase the number of shares an employer can withhold to cover income taxes on share-based payment awards and still qualify for the exemption to liability classification. The new guidance will be effective for the Company starting in the first quarter of fiscal 2018. Early adoption is permitted in any annual or interim period. The Company does not intend to adopt the new guidance early and is in the process of determining the effects the adoption will have on its consolidated financial statements.

[0001234452-17-000028:notes:81]
In June 2016, the FASB issued new guidance that changes the accounting for recognizing impairments of financial assets. Under the new guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The new guidance also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The new guidance will be effective for the Company starting in the first quarter of fiscal 2021. Early adoption is permitted starting in the first quarter of fiscal 2020. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.

[0001234452-17-000028:notes:82]
In August 2016, the FASB issued new guidance related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its consolidated financial statements as well as whether to adopt the new guidance early.

[0001234452-17-000028:notes:83]
In October 2016, the FASB issued new guidance that changes the accounting for income tax effects of intra-entity transfers of assets other than inventory. Under the new guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its consolidated financial statements as well as whether to adopt the new guidance early.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001234452-17-000028:notes:84]
[same as prior period, unchanged from 0001234452-16-000483:notes:81]

[0001234452-17-000028:notes:85]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 25, 2016. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month periods ended December 25, 2016 and December 27, 2015 included 13 weeks, respectively.

[0001234452-17-000028:notes:86]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in the Company’s condensed consolidated financial statements and the accompanying notes. Actual results could differ from those estimates.

[0001234452-17-000028:notes:87]
[same as prior period, unchanged from 0001234452-16-000483:notes:84]

[0001234452-17-000028:notes:88]
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |
| Cost of equipment and services revenues | $ | 9 |  |  | $ | 10 |  |
| Research and development | 153 |  |  | 165 |  |
| Selling, general and administrative | 77 |  |  | 72 |  |
| Share-based compensation expense before income taxes | 239 |  |  | 247 |  |
| Related income tax benefit | (49 | ) |  | (60 | ) |
|  | $ | 190 |  |  | $ | 187 |  |

[0001234452-17-000028:notes:89]
At December 25, 2016, total unrecognized compensation expense related to nonvested restricted stock units granted prior to that date was $1.5 billion, which is expected to be recognized over a weighted-average period of 2.1 years.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001234452-17-000028:notes:90]
[same as prior period, unchanged from 0001234452-16-000483:notes:89]

[0001234452-17-000028:notes:91]
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |
| Cost of revenues | $ | 84 |  |  | $ | 140 |  |
| Research and development expenses | 3 |  |  | 3 |  |
| Selling, general and administrative expenses | 61 |  |  | 29 |  |

[0001234452-17-000028:notes:92]
[same as prior period, unchanged from 0001234452-16-000483:notes:87]

[0001234452-17-000028:notes:93]
|  | Three Months Ended |
|  | December 25, 2016 |  | December 27, 2015 |
| Revenues |  |  |  |
| Nonreportable segments | $ | 73 |  |  | $ | 64 |  |
| Intersegment eliminations | — |  |  | (1 | ) |
|  | $ | 73 |  |  | $ | 63 |  |
| EBT |  |  |  |
| Unallocated cost of revenues | $ | (95 | ) |  | $ | (150 | ) |
| Unallocated research and development expenses | (269 | ) |  | (216 | ) |
| Unallocated selling, general and administrative expenses | (145 | ) |  | (127 | ) |
| Unallocated other expenses, net | (876 | ) |  | (6 | ) |
| Unallocated interest expense | (89 | ) |  | (70 | ) |
| Unallocated investment income, net | 184 |  |  | 114 |  |
| Nonreportable segments | (79 | ) |  | (124 | ) |
| Intersegment eliminations | — |  |  | 1 |  |
|  | $ | (1,369 | ) |  | $ | (578 | ) |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001234452-17-000028:notes:94]
Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity in the three months ended December 25, 2016 were as follows (in millions):

[0001234452-17-000028:notes:95]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Total Accumulated Other Comprehensive Income |
| Balance at September 25, 2016 | $ | (161 | ) |  | $ | 6 |  |  | $ | 532 |  |  | $ | 51 |  |  | $ | 428 |  |
| Other comprehensive (loss) income before reclassifications | (27 | ) |  | 6 |  |  | (210 | ) |  | 2 |  |  | (229 | ) |
| Reclassifications from accumulated other comprehensive income (loss) | — |  |  | 11 |  |  | (24 | ) |  | — |  |  | (13 | ) |
| Other comprehensive (loss) income | (27 | ) |  | 17 |  |  | (234 | ) |  | 2 |  |  | (242 | ) |
| Balance at December 25, 2016 | $ | (188 | ) |  | $ | 23 |  |  | $ | 298 |  |  | $ | 53 |  |  | $ | 186 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001234452-17-000028:notes:96]
[same as prior period, unchanged from 0001234452-16-000483:notes:97]

[0001234452-17-000028:notes:97]
|  | QCT |  | QTL |  | QSI |  | ReconcilingItems |  | Total |
| For the three months ended |  |  |  |  |  |  |  |  |  |
| December 25, 2016 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 4,101 |  |  | $ | 1,811 |  |  | $ | 14 |  |  | $ | 73 |  |  | $ | 5,999 |  |
| EBT | 724 |  |  | 1,532 |  |  | (17 | ) |  | (1,369 | ) |  | 870 |  |
| December 27, 2015 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 4,096 |  |  | $ | 1,607 |  |  | $ | 9 |  |  | $ | 63 |  |  | $ | 5,775 |  |
| EBT | 590 |  |  | 1,339 |  |  | 359 |  |  | (578 | ) |  | 1,710 |  |
| Total assets |  |  |  |  |  |  |  |  |  |
| December 25, 2016 | $ | 3,037 |  |  | $ | 873 |  |  | $ | 956 |  |  | $ | 47,500 |  |  | $ | 52,366 |  |
| September 25, 2016 | 2,995 |  |  | 644 |  |  | 910 |  |  | 47,810 |  |  | 52,359 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001234452-17-000028:notes:98]
Changes in stockholders’ equity in the three months ended December 25, 2016 were as follows (in millions):

[0001234452-17-000028:notes:99]
|  | Qualcomm Stockholders’ Equity |  | Noncontrolling Interests |  | Total Stockholders’ Equity |
| Balance at September 25, 2016 | $ | 31,778 |  |  | $ | (10 | ) |  | $ | 31,768 |  |
| Net income (loss) | 682 |  |  | (1 | ) |  | 681 |  |
| Other comprehensive loss | (242 | ) |  | — |  |  | (242 | ) |
| Common stock issued under employee benefit plans and related tax benefits | 161 |  |  | — |  |  | 161 |  |
| Share-based compensation | 255 |  |  | — |  |  | 255 |  |
| Tax withholdings related to vesting of share-based payments | (172 | ) |  | — |  |  | (172 | ) |
| Dividends | (801 | ) |  | — |  |  | (801 | ) |
| Stock repurchases | (444 | ) |  | — |  |  | (444 | ) |
| Other | (2 | ) |  | 2 |  |  | — |  |
| Balance at December 25, 2016 | $ | 31,215 |  |  | $ | (9 | ) |  | $ | 31,206 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001234452-17-000028:notes:100]
[same as prior period, unchanged from 0001234452-16-000483:notes:101]

[0001234452-17-000028:notes:101]
The Company is organized on the basis of products and services. The Company conducts business primarily through two reportable segments, QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing), and its QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an equity method investee. QCT develops and supplies integrated circuits and system software for use in mobile devices, wireless networks, broadband gateway equipment and consumer electronic devices. QTL grants licenses to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. The Company also has nonreportable segments, including its mobile health, data center, small cell and other wireless technology and service initiatives.

[0001234452-17-000028:notes:102]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense; certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. All of the costs related to the initial research of 5G technology are included in unallocated corporate research and development expenses, whereas initial costs related to the research of 3G and 4G technology were recorded in both the QCT segment and unallocated corporate research and development expenses based on the nature of the activity. Fiscal 2016 results have not been revised as such costs were incurred prior to fiscal 2014.

[0001234452-17-000028:notes:103]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets are comprised primarily of certain non-marketable equity instruments and other investments and a receivable from the sale of wireless spectrum in fiscal 2016 (Note 2). Total segment assets differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable securities, property, plant and equipment, deferred tax assets, intangible assets and assets of nonreportable segments.

[0001234452-17-000028:notes:104]
Unallocated other expense in the three months ended December 25, 2016 was comprised primarily of the charge related to the KFTC investigation (Note 6). Unallocated other expense in the three months ended December 27, 2015 was comprised of net restructuring and restructuring-related charges associated with the Company’s Strategic Realignment Plan, which was substantially implemented in fiscal 2016 (Note 2).


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001234452-17-000028:notes:105]
[same as prior period, unchanged from 0001234452-16-000483:notes:106]

[0001234452-17-000028:notes:106]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity in the three months ended December 25, 2016 were as follows (in millions):

[0001234452-17-000028:notes:107]
Reclassifications from accumulated other comprehensive income related to available-for-sale securities of $13 million and $6 million in the three months ended December 25, 2016 and December 27, 2015, respectively, were recorded in investment income, net (Note 2). Reclassifications from accumulated other comprehensive income related to foreign currency translation losses were negligible in the three months ended December 27, 2015 and were recorded in selling, general and administrative expenses and other operating expenses.

[0001234452-17-000028:notes:108]
Stock Repurchase Program. On March 9, 2015, the Company announced a stock repurchase program authorizing it to repurchase up to $15 billion of the Company’s common stock. The stock repurchase program has no expiration date. In the three months ended December 25, 2016 and December 27, 2015, the Company repurchased and retired 6,647,000 and 36,606,000 shares for $444 million and $2.05 billion, respectively, before commissions. At December 25, 2016, $2.5 billion remained authorized for repurchase under the Company’s stock repurchase program.

[0001234452-17-000028:notes:109]
Dividends. Cash dividends announced in the three months ended December 25, 2016 and December 27, 2015 were $0.53 and $0.48 per share, respectively. Dividends charged to retained earnings in the three months ended December 25, 2016 and December 27, 2015 were $801 million and $730 million, respectively. On January 12, 2017, the Company announced a cash dividend of $0.53 per share on the Company’s common stock, payable on March 22, 2017 to stockholders of record as of the close of business on March 1, 2017.
