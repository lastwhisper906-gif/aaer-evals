# QCOM 8-K — 0001728949-19-000071 filed 2019-11-06

## item codes, every 8-K on or before 2019-11-06

- 2019-11-06 0001728949-19-000074 — 5.02
- 2019-11-06 0001728949-19-000071 — 2.02, 9.01
- 2019-08-28 0001728949-19-000058 — 5.02
- 2019-07-31 0001728949-19-000053 — 2.02, 9.01
- 2019-05-10 0001728949-19-000044 — 5.02
- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2019-11-06

- none on or before 2019-11-06

## item 2.02 — earnings release, exhibit 99.1

[0001728949-19-000071:8k_2_02:1]
EX-99.1
2
qcom092919erex991.htm
EXHIBIT 99.1

[0001728949-19-000071:8k_2_02:2]
Exhibit

[0001728949-19-000071:8k_2_02:3]
Exhibit 99.1

[0001728949-19-000071:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001728949-19-000071:8k_2_02:5]
Qualcomm Contact:

[0001728949-19-000071:8k_2_02:6]
Mauricio Lopez-Hodoyan

[0001728949-19-000071:8k_2_02:7]
Vice President, Investor Relations

[0001728949-19-000071:8k_2_02:8]
Phone: 1-858-658-4813

[0001728949-19-000071:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001728949-19-000071:8k_2_02:10]
Qualcomm Announces Fourth Quarter and Fiscal 2019 Results

[0001728949-19-000071:8k_2_02:11]
Fiscal 2019 GAAP Revenues $24.3 billion

[0001728949-19-000071:8k_2_02:12]
Fiscal 2019 Non-GAAP Revenues $19.4 billion

[0001728949-19-000071:8k_2_02:13]
GAAP EPS $3.59, Non-GAAP EPS $3.54

[0001728949-19-000071:8k_2_02:14]
SAN DIEGO - November 6, 2019 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal fourth quarter and year ended September 29, 2019.

[0001728949-19-000071:8k_2_02:15]
“We delivered a strong quarter, with Non-GAAP earnings per share above the high end of our guidance range, primarily on solid performance in our QTL segment,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “We exit the fiscal year having successfully executed on our strategic priorities: helping to drive the commercialization of 5G globally, completing a number of important anchor license agreements and executing well across our product roadmap.  Our technology and inventions leave us extremely well positioned as 5G accelerates in 2020.”

[0001728949-19-000071:8k_2_02:16]
GAAP Results*

[0001728949-19-000071:8k_2_02:17]
Fourth Quarter Fiscal 2019

[0001728949-19-000071:8k_2_02:18]
|  | Q4 Fiscal 2019 |  | Q4 Fiscal 2018 1 |  | Year-Over-Year Change 2 |  | Q3 Fiscal 2019 |  | Sequential Change 2 |
| Revenues | $4.8B |  | $5.8B |  | (17%) |  | $9.6B |  | (50%) |
| Operating income (loss) | $0.7B |  | ($0.7B) |  | N/M |  | $5.3B |  | (87%) |
| Net income (loss) | $0.5B |  | ($0.5B) |  | N/M |  | $2.1B |  | (76%) |
| Diluted earnings (loss) per share | $0.42 |  | ($0.36) |  | N/M |  | $1.75 |  | (76%) |
| Operating cash flow 3 | $1.2B |  | ($0.4B) |  | N/M |  | $4.9B |  | (75%) |

[0001728949-19-000071:8k_2_02:19]
1 As previously disclosed, we identified an immaterial error related to the recognition of certain royalty revenues of our QTL (Qualcomm Technology Licensing) segment in the quarterly and annual periods in fiscal 2018 and third and fourth quarters and annual period in fiscal 2017.  We have corrected this error in our GAAP and Non-GAAP results for all impacted prior periods presented herein.  See Notes to Consolidated Financial Statements, “Note 1. Significant Accounting Policies” and “Note 12. Revision of Prior Period Financial Statements” included in our Annual Report on Form 10-K for the fiscal year ended September 29, 2019 filed with the SEC.

[0001728949-19-000071:8k_2_02:20]
2 Throughout this news release, percentage changes are calculated based on the dollar amounts as disclosed in millions.

[0001728949-19-000071:8k_2_02:21]
3 In the first quarter of fiscal 2019, we adopted new accounting guidance that changed the classification and presentation of certain cash receipts and cash payments and that requires companies to include restricted cash and cash equivalents as a component in total cash and cash equivalents in the statement of cash flows.  As a result, prior period cash flow amounts presented herein have been adjusted to conform to the current year presentation.

[0001728949-19-000071:8k_2_02:22]
N/M - Not Meaningful

[0001728949-19-000071:8k_2_02:23]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 2 of 17 |

[0001728949-19-000071:8k_2_02:24]
Fiscal 2019

[0001728949-19-000071:8k_2_02:25]
|  | Fiscal 2019 |  | Fiscal2018 |  | Year-Over-Year Change |
| Revenues | $24.3B |  | $22.6B |  | +7% |
| Operating income | $7.7B |  | $0.6B |  | N/M |
| Net income (loss) | $4.4B |  | ($5.0B) |  | N/M |
| Diluted earnings (loss) per share | $3.59 |  | ($3.39) |  | N/M |
| Operating cash flow | $7.3B |  | $3.9B |  | +86% |

[0001728949-19-000071:8k_2_02:26]
Non-GAAP Results*

[0001728949-19-000071:8k_2_02:27]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding our use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001728949-19-000071:8k_2_02:28]
Fourth Quarter Fiscal 2019

[0001728949-19-000071:8k_2_02:29]
|  | Q4 Fiscal 2019 |  | Q4 Fiscal 2018 |  | Year-Over-Year Change |  | Q3 Fiscal 2019 |  | Sequential Change |
| Revenues | $4.8B |  | $5.8B |  | (17%) |  | $4.9B |  | (2%) |
| Operating income | $1.1B |  | $1.3B |  | (9%) |  | $1.2B |  | (6%) |
| Net income | $0.9B |  | $1.3B |  | (25%) |  | $1.0B |  | (4%) |
| Diluted earnings per share | $0.78 |  | $0.89 |  | (12%) |  | $0.80 |  | (3%) |

[0001728949-19-000071:8k_2_02:30]
Fiscal 2019

[0001728949-19-000071:8k_2_02:31]
|  | Fiscal 2019 |  | Fiscal2018 |  | Year-Over-Year Change |
| Revenues | $19.4B |  | $22.6B |  | (14%) |
| Operating income | $4.7B |  | $5.5B |  | (15%) |
| Net income | $4.3B |  | $5.3B |  | (19%) |
| Diluted earnings per share | $3.54 |  | $3.62 |  | (2%) |

[0001728949-19-000071:8k_2_02:32]
* In April 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties.  In the third quarter of fiscal 2019, we recognized licensing revenues of $4.7 billion resulting from the settlement, which have been excluded from our Non-GAAP results.  In addition, our QTL results for the third and fourth quarter of fiscal 2019 included royalties from Apple and its contract manufacturers for sales made in the June 2019 and September 2019 quarter, respectively.  QTL revenues in the fourth quarter and fiscal 2018, and the first six months of fiscal 2019, did not include royalties due on sales of Apple or other products by Apple’s contract manufacturers.

[0001728949-19-000071:8k_2_02:33]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 3 of 17 |

[0001728949-19-000071:8k_2_02:34]
QTL revenues in the fourth quarter and fiscal 2018 included $100 million and $600 million, respectively, received under an interim agreement with Huawei.  QTL revenues in fiscal 2019 included $450 million paid under a second interim agreement with Huawei that concluded in the third quarter of fiscal 2019, and although negotiations continue, we have not reached a final agreement with Huawei.  This represents a minimum, non-refundable amount and does not reflect the full amount of royalties due under the underlying license agreement.  We did not record any revenues in the fourth quarter of fiscal 2019 for royalties due on the sales of Huawei’s products.

[0001728949-19-000071:8k_2_02:35]
The following should be considered in regard to the year-over-year and sequential comparisons:

[0001728949-19-000071:8k_2_02:36]
| • | Fiscal 2019 GAAP results included: |

[0001728949-19-000071:8k_2_02:37]
| ◦ | $4.7 billion of revenues, or $3.23 per share, resulting from settlement agreements with Apple and its contract manufacturers in the third quarter of fiscal 2019, which were not allocated to our segment results. |

[0001728949-19-000071:8k_2_02:38]
| ◦ | $2.5 billion tax expense, or ($2.01) per share, due to the derecognition of a deferred tax asset in the third quarter of fiscal 2019 as a result of an agreement with the Internal Revenue Service (IRS) under which we relinquished the federal tax basis step-up in certain distributed intellectual property. |

[0001728949-19-000071:8k_2_02:39]
| ◦ | $275 million charge, or ($0.22) per share, for the fine imposed by the European Commission (EC) recognized in the third quarter of fiscal 2019 (2019 EC fine), for which we have provided a financial guarantee to satisfy the obligation in lieu of a cash payment while we appeal the EC’s decision. |

[0001728949-19-000071:8k_2_02:40]
| ◦ | $213 million of restructuring and restructuring-related charges, or ($0.16) per share, related to our Cost Plan that was announced in the second quarter of fiscal 2018. |

[0001728949-19-000071:8k_2_02:41]
| • | Fiscal 2019 GAAP and Non-GAAP results included: |

[0001728949-19-000071:8k_2_02:42]
| ◦ | $570 million tax benefit, or $0.47 per share, for GAAP and $552 million tax benefit, or |

[0001728949-19-000071:8k_2_02:43]
$0.45 per share, for Non-GAAP relating to certain tax elections made in the first quarter of

[0001728949-19-000071:8k_2_02:44]
fiscal 2019.

[0001728949-19-000071:8k_2_02:45]
| ◦ | $450 million of revenues, or $0.32 per share, resulting from our second interim agreement with Huawei. |

[0001728949-19-000071:8k_2_02:46]
| • | Fiscal 2018 GAAP results included: |

[0001728949-19-000071:8k_2_02:47]
| ◦ | $6.0 billion charge, or ($4.03) per share, related to the enactment of the Tax Cuts and Jobs Act in the United States in the first quarter of fiscal 2018. |

[0001728949-19-000071:8k_2_02:48]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 4 of 17 |

[0001728949-19-000071:8k_2_02:49]
| ◦ | $2.0 billion charge, or ($1.41) per share, related to a termination fee paid to NXP Semiconductors N.V. (NXP) in the fourth quarter of fiscal 2018 resulting from the termination of the purchase agreement to acquire NXP. |

[0001728949-19-000071:8k_2_02:50]
| ◦ | $1.2 billion charge, or ($0.76) per share, for the fine imposed by the EC (2018 EC fine) recognized in the first quarter of fiscal 2018, for which we have provided financial guarantees to satisfy the obligation in lieu of a cash payment while we appeal the EC’s decision. |

[0001728949-19-000071:8k_2_02:51]
| ◦ | $687 million of restructuring and restructuring-related charges, or ($0.37) per share, related to our Cost Plan. |

[0001728949-19-000071:8k_2_02:52]
| ◦ | $676 million gain, or $0.48 per share, related to the settlement of the Taiwan Fair Trade Commission investigation in the fourth quarter of fiscal 2018. |

[0001728949-19-000071:8k_2_02:53]
| • | Fiscal 2018 GAAP and Non-GAAP results included: |

[0001728949-19-000071:8k_2_02:54]
| ◦ | $600 million of revenues, or $0.31 per share for GAAP and $0.30 per share for Non-GAAP (based on diluted shares of 1,463 million and 1,475 million, respectively), resulting from an interim agreement with Huawei for royalties due after the second quarter of fiscal 2017. |

[0001728949-19-000071:8k_2_02:55]
Segment Results

[0001728949-19-000071:8k_2_02:56]
Fourth Quarter Fiscal 2019

[0001728949-19-000071:8k_2_02:57]
| (in millions, except percentages) | Q4 Fiscal 2019 |  | Q4 Fiscal 2018 |  | Year-Over-Year Change |  | Q3 Fiscal 2019 |  | Sequential Change |
| QCT |  |  |  |  |  |  |  |  |  |
| Revenues | $3,611 |  | $4,647 |  | (22%) |  | $3,567 |  | +1% |
| EBT 1 | $499 |  | $796 |  | (37%) |  | $504 |  | (1%) |
| EBT as % of revenues | 14% |  | 17% |  | (3%) |  | 14% |  | —% |
| MSMTM chip shipments | 152 |  | 232 |  | (34%) |  | 156 |  | (3%) |
| QTL |  |  |  |  |  |  |  |  |  |
| Revenues | $1,158 |  | $1,113 |  | +4% |  | $1,292 |  | (10%) |
| EBT | $792 |  | $714 |  | +11% |  | $898 |  | (12%) |
| EBT as % of revenues | 68% |  | 64% |  | +4% |  | 70% |  | (2%) |

[0001728949-19-000071:8k_2_02:58]
1 Earnings (loss) before taxes

[0001728949-19-000071:8k_2_02:59]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 5 of 17 |

[0001728949-19-000071:8k_2_02:60]
Fiscal 2019

[0001728949-19-000071:8k_2_02:61]
| (in millions, except percentages) | Fiscal 2019 |  | Fiscal 2018 |  | Year-Over-Year Change |
| QCT |  |  |  |  |  |
| Revenues | $14,639 |  | $17,282 |  | (15%) |
| EBT | $2,143 |  | $2,966 |  | (28%) |
| EBT as % of revenues | 15% |  | 17% |  | (2%) |
| MSMTM chip shipments | 650 |  | 855 |  | (24%) |
| QTL |  |  |  |  |  |
| Revenues | $4,591 |  | $5,042 |  | (9%) |
| EBT | $2,954 |  | $3,404 |  | (13%) |
| EBT as % of revenues | 64% |  | 68% |  | (4%) |

[0001728949-19-000071:8k_2_02:62]
We adopted accounting guidance (ASC 606) in the first quarter of fiscal 2019 that requires us to estimate and recognize QTL royalty revenues in the period in which the licensees’ sales occur, resulting in an acceleration of royalty revenues by one quarter.  As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.  Prior period results have not been restated and continue to be reported in accordance with the accounting guidance in effect for those periods (ASC 605).

[0001728949-19-000071:8k_2_02:63]
Return of Capital to Stockholders

[0001728949-19-000071:8k_2_02:64]
The following table summarizes stock repurchases, before commissions, and dividends paid during the fourth quarter and fiscal 2019 (in millions, except per-share amounts):

[0001728949-19-000071:8k_2_02:65]
|  | Stock Repurchases |  | Dividends |  | Total |
|  | Shares (1) |  | Amount |  | Per Share |  | Amount |  | Amount |
| Q4 fiscal 2019 | 9.4 |  | $706 |  | $0.62 |  | $711 |  | $1,417 |
| Fiscal 2019 | 27.1 |  | $1,793 |  | $2.48 |  | $2,968 |  | $4,761 |

[0001728949-19-000071:8k_2_02:66]
| (1) | In fiscal 2018, we entered into three accelerated share repurchase agreements (the ASR Agreements) to repurchase an aggregate of $16.0 billion of our common stock, with 178.4 million shares initially delivered to us under the ASR Agreements and retired. The ASR Agreements were completed during the fourth quarter of fiscal 2019, and an additional 68.7 million shares were delivered to us, comprising the final delivery of shares under the ASR Agreements, which have not been included in the stock repurchase share amounts for the fourth quarter and fiscal 2019. |

[0001728949-19-000071:8k_2_02:67]
At September 29, 2019, $7.1 billion remained authorized for repurchase under our $30 billion stock repurchase program announced in the fourth quarter of fiscal 2018.  Since September 29, 2019, we repurchased and retired 3.9 million shares of common stock for $300 million.  On October 15, 2019, we announced a cash dividend of $0.62 per share, payable on December 19, 2019 to stockholders of record at the close of business on December 5, 2019.

[0001728949-19-000071:8k_2_02:68]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 6 of 17 |

[0001728949-19-000071:8k_2_02:69]
Cash and Marketable Securities

[0001728949-19-000071:8k_2_02:70]
Our cash, cash equivalents and marketable securities totaled $12.3 billion at the end of the fourth quarter of fiscal 2019, compared to $12.1 billion a year ago and $14.4 billion at the end of the third quarter of fiscal 2019.

[0001728949-19-000071:8k_2_02:71]
Effective Income Tax Rates

[0001728949-19-000071:8k_2_02:72]
Our annual effective income tax rates for fiscal 2019 were 41% provision for GAAP and 1% benefit for Non-GAAP.  Our fiscal 2019 GAAP annual effective tax rate reflected the impact of a $2.5 billion charge due to the derecognition of a deferred tax asset as a result of an agreement with the IRS under which we relinquished the federal tax basis step-up in certain distributed intellectual property resulting from temporary regulations issued by the United States Treasury Department (which was recorded discretely in the third quarter of fiscal 2019), the 2019 EC fine (which is not deductible for tax purposes) and the impact of the Apple settlement.  Our GAAP and Non-GAAP annual effective income tax rates reflected income tax benefits of $570 million and $552 million, respectively, related to tax elections made in the first quarter of fiscal 2019, which were recorded discretely.  Our effective income tax rates for the fourth quarter of fiscal 2019 were 18% for GAAP and 10% for Non-GAAP.

[0001728949-19-000071:8k_2_02:73]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 7 of 17 |

[0001728949-19-000071:8k_2_02:74]
Business Outlook

[0001728949-19-000071:8k_2_02:75]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as certain investment, certain derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001728949-19-000071:8k_2_02:76]
The second interim agreement with Huawei concluded in the third quarter of fiscal 2019, and although negotiations continue, we have not reached a final agreement with Huawei.  If no agreement is reached, Huawei may continue to not make any other payments or may not make full payments due under the underlying license agreement.  Our financial guidance for the first quarter of fiscal 2020 excludes QTL revenues for royalties due on sales of products by Huawei.

[0001728949-19-000071:8k_2_02:77]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 8 of 17 |

[0001728949-19-000071:8k_2_02:78]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001728949-19-000071:8k_2_02:79]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001728949-19-000071:8k_2_02:80]
|  |  | Q1 FY19Results (1) | Current Guidance Q1 FY20 Estimates (2)(3) |  |
|  | Revenues | $4.8B | $4.4B - $5.2B |  |  |
|  | Year-over-year change |  | decrease 9% - increase 7% |  |  |
|  | GAAP diluted EPS | $0.87 | $0.51 - $0.61 |  |  |
|  | Year-over-year change |  | decrease 30% - 41% |  |  |
|  | Less diluted EPS attributable to QSI | $0.01 |  | $0.00 |  |  |
|  | Less diluted EPS attributable to share-based compensation | ($0.15) |  | ($0.22 | ) |  |
|  | Less diluted EPS attributable to other items | ($0.18) |  | ($0.07 | ) |  |
|  | Non-GAAP diluted EPS | $1.20 | $0.80 - $0.90 |  |  |
|  | Year-over-year change |  | decrease 25% - 33% |  |  |
|  | Other Information |  |  |  |
|  | MSM chip shipments | 186M | 145M - 165M |  |  |
|  | Year-over-year change |  | decrease 11% - 22% |  |  |
|  | QTL revenues | $1.0B | $1.3B - $1.5B |  |  |
|  | Year-over-year change |  | increase 28% - increase 47% |  |  |

[0001728949-19-000071:8k_2_02:81]
| (1) | The first quarter of fiscal 2019 results excluded QTL revenues for royalties due on sales of Apple or other products by Apple’s contract manufacturers. The first quarter of fiscal 2019 results included a $570 million tax benefit for GAAP and $552 million tax benefit for Non-GAAP relating to certain tax elections made and $150 million of revenues resulting from an interim agreement with Huawei. Diluted EPS attributable to other items for the first quarter of fiscal 2019 was primarily attributable to restructuring and restructuring-related charges related to our Cost Plan and acquisition-related items. |

[0001728949-19-000071:8k_2_02:82]
| (2) | Our guidance for diluted EPS attributable to other items for the first quarter of fiscal 2020 is primarily attributable to acquisition-related items. |

[0001728949-19-000071:8k_2_02:83]
| (3) | Our financial guidance for the first quarter of fiscal 2020 excludes QTL revenues for royalties due on sales of products by Huawei. |

[0001728949-19-000071:8k_2_02:84]
Sums may not equal total due to rounding.

[0001728949-19-000071:8k_2_02:85]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 9 of 17 |

[0001728949-19-000071:8k_2_02:86]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-19-000071:8k_2_02:87]
The following tables reconcile our GAAP results to our Non-GAAP results (in millions, except per share data and percentages):

[0001728949-19-000071:8k_2_02:88]
|  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) | Non-GAAP Results |
| Q4 FISCAL 2019 |  |  |  |  |  |  |  |
| Revenues | $4,814 |  | $10 |  |  | $— |  |  |  | $— |  |  | $4,804 |  |
| Operating income (loss) | 701 |  | 3 |  | (339) |  | (100) |  | 1,137 |  |
| EBT | 615 |  | 7 |  | (339) |  | (102) |  | 1,049 |  |
| EBT as % of revenues | 13 | % |  |  |  |  |  |  |  | 22 | % |  |
| Net income (loss) | 506 |  | 5 |  | (282) |  | (164) |  | 947 |  |
| Diluted EPS | $0.42 |  | $0.00 |  | ($0.23) |  | ($0.14) |  | $0.78 |  |
| Diluted shares | 1,211 |  | 1,211 |  | 1,211 |  | 1,211 |  | 1,211 |  |
| Q3 FISCAL 2019 |  |  |  |  |  |  |  |
| Revenues | $9,635 |  | $18 |  |  | $— |  |  | $4,723 |  | $4,894 |  |
| Operating income (loss) | 5,317 |  | 10 |  | (246) |  | 4,339 |  | 1,214 |  |
| EBT | 5,501 |  | 312 |  | (246) |  | 4,334 |  | 1,101 |  |
| EBT as % of revenues | 57 | % |  |  |  |  |  |  |  | 22 | % |  |
| Net income (loss) | 2,149 |  | 237 |  | (198) |  | 1,128 |  | 982 |  |
| Diluted EPS | $1.75 |  | $0.19 |  | ($0.16) |  | $0.92 |  | $0.80 |  |
| Diluted shares | 1,231 |  | 1,231 |  | 1,231 |  | 1,231 |  | 1,231 |  |
| Q4 FISCAL 2018 |  |  |  |  |  |  |  |
| Revenues | $5,778 |  | $20 |  |  | $— |  |  | ($50) |  | $5,808 |  |
| Operating (loss) income | (679) |  | 2 |  | (224) |  | (1,712) |  | 1,255 |  |
| EBT | (800) |  | (20) |  | (224) |  | (1,800) |  | 1,244 |  |
| EBT as % of revenues | N/M |  |  |  |  |  |  |  |  | 21 | % |  |
| Net (loss) income | (513) |  | (11) |  | (195) |  | (1,567) |  | 1,260 |  |
| Diluted EPS | ($0.36) |  | ($0.01) |  | ($0.14) |  | ($1.10) |  | $0.89 |  |
| Diluted shares | 1,417 |  | 1,429 |  | 1,429 |  | 1,429 |  | 1,429 |  |
| FISCAL 2019 |  |  |  |  |  |  |  |  |  |  |
| Revenues | $24,273 |  | $152 |  |  | $— |  |  | $4,723 | (c) | $19,398 |  |
| Operating income (loss) | 7,667 |  | 113 |  | (1,037) |  | 3,891 |  | 4,700 |  |
| EBT | 7,481 |  | 344 |  | (1,037) |  | 3,889 |  | 4,285 |  |
| EBT as % of revenues | 31 | % |  |  |  |  |  |  |  | 22 | % |  |
| Net income (loss) | 4,386 |  | 271 |  | (853) |  | 645 |  | 4,323 |  |
| Diluted EPS | $3.59 |  | $0.22 |  | ($0.70) |  | $0.53 |  | $3.54 |  |
| Diluted shares | 1,220 |  | 1,220 |  | 1,220 |  | 1,220 |  | 1,220 |  |
| FISCAL 2018 |  |  |  |  |  |  |  |  |  |  |
| Revenues | $22,611 |  | $100 |  |  | $— |  |  | ($100) |  | $22,611 |  |
| Operating income (loss) | 621 |  | 23 |  | (883) |  | (4,018) |  | 5,499 |  |
| EBT | 392 |  | 24 |  | (883) |  | (4,132) |  | 5,383 |  |
| EBT as % of revenues | 2 | % |  |  |  |  |  |  |  | 24 | % |  |
| Net (loss) income | (4,964) |  | 22 |  | (743) |  | (9,586) |  | 5,343 |  |
| Diluted EPS | ($3.39) |  | $0.01 |  | ($0.50) |  | ($6.53) |  | $3.62 |  |
| Diluted shares | 1,463 |  | 1,475 |  | 1,475 |  | 1,475 |  | 1,475 |  |

[0001728949-19-000071:8k_2_02:89]
| (a) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” herein for further details. |

[0001728949-19-000071:8k_2_02:90]
| (b) | Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” sections herein. Details of amounts included in the “Other Items” column for prior periods as well as other notes related to prior periods are included in the news releases for those periods. |

[0001728949-19-000071:8k_2_02:91]
| (c) | In fiscal 2019, other items excluded from Non-GAAP revenues were comprised of licensing revenues resulting from the settlement with Apple and its contract manufacturers, which were not allocated to our segment results. |

[0001728949-19-000071:8k_2_02:92]
Sums may not equal totals due to rounding.

[0001728949-19-000071:8k_2_02:93]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 10 of 17 |

[0001728949-19-000071:8k_2_02:94]
Supplemental Information and Reconciliations

[0001728949-19-000071:8k_2_02:95]
(Unaudited)

[0001728949-19-000071:8k_2_02:96]
|  | Q4 FISCAL 2019 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results |
|  | Cost of revenues |  | $2,118 |  |  | $4 |  |  | $12 |  |  | $88 |  |  | $2,014 |  |
|  | Research and development (R&D) expenses |  | 1,441 |  |  | — |  |  |  | 246 |  |  | 1 |  |  | 1,194 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 548 |  |  | 3 |  |  | 81 |  |  | 5 |  |  | 459 |  |
|  | Other expenses |  | 6 |  |  | — |  |  |  | — |  |  |  | 6 |  |  | — |  |  |
|  | Interest expense |  | 150 |  |  | — |  |  |  | — |  |  |  | 6 |  |  | 144 |  |
|  | Investment and other income, net |  | 64 |  |  | 4 |  |  | — |  |  |  | 4 |  |  | 56 |  |

[0001728949-19-000071:8k_2_02:97]
| (a) | Other items excluded from Non-GAAP results included $96 million of acquisition-related charges, $5 million of interest expense related to the 2018 EC fine and $4 million of net restructuring and restructuring-related charges primarily related to our Cost Plan, partially offset by $3 million of foreign currency transaction gains related to the 2019 EC fine. |

[0001728949-19-000071:8k_2_02:98]
|  | FISCAL 2019 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (b) | Non-GAAP Results |
|  | Cost of revenues |  | $8,599 |  |  | $26 |  |  | $35 |  |  | $387 |  |  | $8,151 |  |
|  | Research and development (R&D) expenses |  | 5,398 |  |  | — |  |  |  | 725 |  |  | 4 |  |  | 4,669 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 2,195 |  |  | 13 |  |  | 277 |  |  | 27 |  |  | 1,878 |  |
|  | Other expenses |  | 414 |  |  | — |  |  |  | — |  |  |  | 414 |  |  | — |  |  |
|  | Interest expense |  | 627 |  |  | — |  |  |  | — |  |  |  | 22 |  |  | 605 |  |
|  | Investment and other income, net |  | 441 |  |  | 231 |  |  | — |  |  |  | 20 |  |  | 190 |  |

[0001728949-19-000071:8k_2_02:99]
| (b) | Other items excluded from Non-GAAP results included $418 million of acquisition-related charges, a $275 million charge related to the 2019 EC fine, $213 million of net restructuring and restructuring-related charges primarily related to our Cost Plan and $21 million of interest expense related to the 2018 EC fine, partially offset by a $43 million gain (and $13 million of interest) due to the partial recovery of a fine imposed in fiscal 2009 resulting from our appeal of the Korea Fair Trade Commission (KFTC) decision, a $31 million benefit related to a favorable legal settlement and $6 million of foreign currency transaction gains related to the 2018 and 2019 EC fines, net of associated losses on derivative instruments. |

[0001728949-19-000071:8k_2_02:100]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 11 of 17 |

[0001728949-19-000071:8k_2_02:101]
Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates

[0001728949-19-000071:8k_2_02:102]
(Unaudited)

[0001728949-19-000071:8k_2_02:103]
| ($ in millions) |  | GAAP Results |  |  | Less QSI | Less Share-Based Compensation | Less Other Items (b) (c) |  | Non-GAAP Results |  |
| Q4 FISCAL 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 615 |  |  |  | $ | 7 |  |  |  | $ | (339 | ) |  |  | $ | (102 | ) |  |  | $ | 1,049 |  |  |
| Income tax (expense) benefit |  | (109 | ) |  |  | (2 | ) |  |  | 57 |  |  |  | (62 | ) |  |  | (102 | ) |  |
| Net income (loss) |  | $ | 506 |  |  |  | $ | 5 |  |  |  | $ | (282 | ) |  |  | $ | (164 | ) |  |  | $ | 947 |  |  |
| Tax rate |  | 18 | % |  |  | — | % | (a) |  |  |  | — | % | (a) |  |  | 8 | % | (a) |  |  |  | 10 | % |  |
| FISCAL 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 7,481 |  |  |  | $ | 344 |  |  |  | $ | (1,037 | ) |  |  | $ | 3,889 |  |  |  | $ | 4,285 |  |  |
| Income tax (expense) benefit |  | (3,095 | ) |  |  | (73 | ) |  |  | 184 |  |  |  | (3,244 | ) |  |  | 38 |  |  |
| Net income (loss) |  | $ | 4,386 |  |  |  | $ | 271 |  |  |  | $ | (853 | ) |  |  | $ | 645 |  |  |  | $ | 4,323 |  |  |
| Tax rate |  | 41 | % |  |  | (2 | %) | (a) |  |  |  | 6 | % | (a) |  |  |  | 38 | % | (a) |  |  |  | (1 | %) |  |

[0001728949-19-000071:8k_2_02:104]
| (a) | The incremental effect of our adjustments to the Non-GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001728949-19-000071:8k_2_02:105]
| (b) | In the fourth quarter of fiscal 2019, the tax expense in the “Other Items” column included a $66 million charge for the foreign currency loss related to a refund claim for withholding taxes paid to Korea in prior periods, a $23 million charge to reconcile the tax provision for each column to the total GAAP tax provision for the quarter, a $20 million charge related to a proposed settlement with the IRS and a $17 million charge for the combined effect of other items in EBT, partially offset by a $47 million benefit for release of a valuation allowance and a $17 million benefit for the tax effect of acquisition-related items in EBT. |

[0001728949-19-000071:8k_2_02:106]
| (c) | In fiscal 2019, the tax expense in the “Other Items” column included a $2.5 billion charge for the write-off of a deferred tax asset, a $786 million charge for the combined effect of other items in EBT, a $70 million charge related to certain other impacts of final U.S. regulations issued in the third quarter of fiscal 2019, a $66 million charge for the foreign currency loss related to a refund claim for withholding taxes paid to Korea in prior periods and a $20 million charge related to a proposed settlement with the IRS, partially offset by a $79 million benefit for release of a valuation allowance, a $72 million benefit for the tax effect of acquisition-related items in EBT and an $18 million tax benefit related to a prior year. |

[0001728949-19-000071:8k_2_02:107]
Conference Call

[0001728949-19-000071:8k_2_02:108]
Qualcomm’s fiscal fourth quarter 2019 earnings conference call will be broadcast live on November 6, 2019, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to our financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at

[0001728949-19-000071:8k_2_02:109]
http://investor.qualcomm.com/ immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415.  Callers should use reservation number 13695634.

[0001728949-19-000071:8k_2_02:110]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 12 of 17 |

[0001728949-19-000071:8k_2_02:111]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-19-000071:8k_2_02:112]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, our measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results used herein are presented herein.

[0001728949-19-000071:8k_2_02:113]
We use Non-GAAP financial information: (i) to evaluate, assess and benchmark our operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of our ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by us include revenues, cost of revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  We are able to assess what we believe is a more meaningful and comparable set of financial performance measures for Qualcomm and its business segments by using Non-GAAP information.  In addition, the HR and Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  We present Non-GAAP financial information to provide greater transparency to investors with respect to our use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0001728949-19-000071:8k_2_02:114]
Non-GAAP information excludes our QSI segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-19-000071:8k_2_02:115]
| • | QSI is excluded because we expect to exit our strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed as unrelated to our operational performance. |

[0001728949-19-000071:8k_2_02:116]
| • | Share-based compensation expense primarily relates to restricted stock units. We believe that excluding non-cash share-based compensation from the Non-GAAP financial information allows us and investors to make additional comparisons of the operating activities of our ongoing core businesses over time and with respect to other companies. |

[0001728949-19-000071:8k_2_02:117]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 13 of 17 |

[0001728949-19-000071:8k_2_02:118]
| • | Certain other items are excluded because we view such items as unrelated to the operating activities of our ongoing core businesses, as follows: |

[0001728949-19-000071:8k_2_02:119]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of these items, as well as any effects from restructuring the ownership of such acquired assets. Additionally, we exclude third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition. |

[0001728949-19-000071:8k_2_02:120]
| • | We exclude certain other items that we view as unrelated to our ongoing businesses, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. |

[0001728949-19-000071:8k_2_02:121]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of our ongoing Non-GAAP tax rate and after-tax earnings. In fiscal 2018, we excluded the full impact of the estimated one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries, including the portion that relates to earnings and profits of U.S.-owned foreign subsidiaries generated in the first quarter of fiscal 2018. |

[0001728949-19-000071:8k_2_02:122]
About Qualcomm

[0001728949-19-000071:8k_2_02:123]
Qualcomm invents breakthrough technologies that transform how the world connects, computes and communicates.  When we connected the phone to the Internet, the mobile revolution was born.  Today, our inventions are the foundation for life-changing products, experiences, and industries.  As we lead the world to 5G, we envision this next big change in cellular technology spurring a new era of intelligent, connected devices and enabling new opportunities in connected cars, remote delivery of health care services, and the IoT - including smart cities, smart homes and wearables.  Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of our engineering, research and development functions, and substantially all of our products and services businesses, including our QCT semiconductor business.  For more information, visit www.qualcomm.com.

[0001728949-19-000071:8k_2_02:124]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 14 of 17 |

[0001728949-19-000071:8k_2_02:125]
Note Regarding Forward-Looking Statements

[0001728949-19-000071:8k_2_02:126]
###

[0001728949-19-000071:8k_2_02:127]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries. Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-19-000071:8k_2_02:128]
MSM is a product of Qualcomm Technologies, Inc.

[0001728949-19-000071:8k_2_02:129]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 15 of 17 |

[0001728949-19-000071:8k_2_02:130]
QUALCOMM Incorporated

[0001728949-19-000071:8k_2_02:131]
CONSOLIDATED BALANCE SHEETS

[0001728949-19-000071:8k_2_02:132]
(In millions, except per share data)

[0001728949-19-000071:8k_2_02:133]
(Unaudited)

[0001728949-19-000071:8k_2_02:134]
|  | September 29, 2019 |  | September 30, 2018 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 11,839 |  |  | $ | 11,777 |  |
| Marketable securities | 421 |  |  | 311 |  |
| Accounts receivable, net | 2,471 |  |  | 2,904 |  |
| Inventories | 1,400 |  |  | 1,693 |  |
| Other current assets | 634 |  |  | 699 |  |
| Total current assets | 16,765 |  |  | 17,384 |  |
| Deferred tax assets | 1,196 |  |  | 936 |  |
| Property, plant and equipment, net | 3,081 |  |  | 2,975 |  |
| Goodwill | 6,282 |  |  | 6,498 |  |
| Other intangible assets, net | 2,172 |  |  | 2,955 |  |
| Other assets | 3,461 |  |  | 1,970 |  |
| Total assets | $ | 32,957 |  |  | $ | 32,718 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,368 |  |  | $ | 1,825 |  |
| Payroll and other benefits related liabilities | 1,048 |  |  | 1,081 |  |
| Unearned revenues | 565 |  |  | 500 |  |
| Short-term debt | 2,496 |  |  | 1,005 |  |
| Other current liabilities | 3,458 |  |  | 6,978 |  |
| Total current liabilities | 8,935 |  |  | 11,389 |  |
| Unearned revenues | 1,160 |  |  | 1,620 |  |
| Income taxes payable | 2,088 |  |  | 2,312 |  |
| Long-term debt | 13,437 |  |  | 15,365 |  |
| Other liabilities | 2,428 |  |  | 1,225 |  |
| Total liabilities | 28,048 |  |  | 31,911 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,145 and 1,219 shares issued and outstanding, respectively | 343 |  |  | — |  |
| Retained earnings | 4,466 |  |  | 542 |  |
| Accumulated other comprehensive income | 100 |  |  | 265 |  |
| Total stockholders’ equity | 4,909 |  |  | 807 |  |
| Total liabilities and stockholders’ equity | $ | 32,957 |  |  | $ | 32,718 |  |

[0001728949-19-000071:8k_2_02:135]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 16 of 17 |

[0001728949-19-000071:8k_2_02:136]
QUALCOMM Incorporated

[0001728949-19-000071:8k_2_02:137]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-19-000071:8k_2_02:138]
(In millions, except per share data)

[0001728949-19-000071:8k_2_02:139]
(Unaudited)

[0001728949-19-000071:8k_2_02:140]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 29, 2019 |  | September 30, 2018 |  | September 29, 2019 |  | September 30, 2018 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,573 |  |  | $ | 4,650 |  |  | $ | 14,611 |  |  | $ | 17,400 |  |
| Licensing | 1,241 |  |  | 1,128 |  |  | 9,662 |  |  | 5,211 |  |
| Total revenues | 4,814 |  |  | 5,778 |  |  | 24,273 |  |  | 22,611 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of revenues | 2,118 |  |  | 2,850 |  |  | 8,599 |  |  | 10,244 |  |
| Research and development | 1,441 |  |  | 1,388 |  |  | 5,398 |  |  | 5,625 |  |
| Selling, general and administrative | 548 |  |  | 689 |  |  | 2,195 |  |  | 2,986 |  |
| Other | 6 |  |  | 1,530 |  |  | 414 |  |  | 3,135 |  |
| Total costs and expenses | 4,113 |  |  | 6,457 |  |  | 16,606 |  |  | 21,990 |  |
| Operating income | 701 |  |  | (679 | ) |  | 7,667 |  |  | 621 |  |
| Interest expense | (150 | ) |  | (207 | ) |  | (627 | ) |  | (768 | ) |
| Investment and other income, net | 64 |  |  | 86 |  |  | 441 |  |  | 539 |  |
| Income before income taxes | 615 |  |  | (800 | ) |  | 7,481 |  |  | 392 |  |
| Income tax (expense) benefit | (109 | ) |  | 287 |  |  | (3,095 | ) |  | (5,356 | ) |
| Net income (loss) | $ | 506 |  |  | $ | (513 | ) |  | $ | 4,386 |  |  | $ | (4,964 | ) |
| Basic earnings (loss) per share attributable to Qualcomm | $ | 0.42 |  |  | $ | (0.36 | ) |  | $ | 3.63 |  |  | $ | (3.39 | ) |
| Diluted earnings (loss) per share attributable to Qualcomm | $ | 0.42 |  |  | $ | (0.36 | ) |  | $ | 3.59 |  |  | $ | (3.39 | ) |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,197 |  |  | 1,417 |  |  | 1,210 |  |  | 1,463 |  |
| Diluted | 1,211 |  |  | 1,417 |  |  | 1,220 |  |  | 1,463 |  |

[0001728949-19-000071:8k_2_02:141]
| Qualcomm Announces Fourth Quarter and Fiscal 2019 Results | Page 17 of 17 |

[0001728949-19-000071:8k_2_02:142]
QUALCOMM Incorporated

[0001728949-19-000071:8k_2_02:143]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-19-000071:8k_2_02:144]
(In millions)

[0001728949-19-000071:8k_2_02:145]
(Unaudited)

[0001728949-19-000071:8k_2_02:146]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 29, 2019 |  | September 30, 2018 |  | September 29, 2019 |  | September 30, 2018 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 506 |  |  | $ | (513 | ) |  | $ | 4,386 |  |  | $ | (4,964 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 350 |  |  | 396 |  |  | 1,401 |  |  | 1,561 |  |
| Income tax provision (less than) in excess of income tax payments | (230 | ) |  | (477 | ) |  | 1,976 |  |  | 4,481 |  |
| Non-cash portion of share-based compensation expense | 339 |  |  | 224 |  |  | 1,037 |  |  | 883 |  |
| Net gains on marketable securities and other investments | (16 | ) |  | (23 | ) |  | (356 | ) |  | (124 | ) |
| Indefinite and long-lived asset impairment charges | — |  |  | 177 |  |  | 203 |  |  | 273 |  |
| Impairment losses on marketable securities and other investments | 24 |  |  | 35 |  |  | 135 |  |  | 75 |  |
| Other items, net | (65 | ) |  | (3 | ) |  | (272 | ) |  | (49 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (78 | ) |  | 264 |  |  | 1,373 |  |  | 734 |  |
| Inventories | 368 |  |  | 92 |  |  | 273 |  |  | 337 |  |
| Other assets | 63 |  |  | (48 | ) |  | 78 |  |  | 24 |  |
| Trade accounts payable | (176 | ) |  | 202 |  |  | (443 | ) |  | (94 | ) |
| Payroll, benefits and other liabilities | 158 |  |  | (693 | ) |  | (2,376 | ) |  | 1,005 |  |
| Unearned revenues | (16 | ) |  | (56 | ) |  | (129 | ) |  | (234 | ) |
| Net cash provided (used) by operating activities | 1,227 |  |  | (423 | ) |  | 7,286 |  |  | 3,908 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (317 | ) |  | (159 | ) |  | (887 | ) |  | (784 | ) |
| Purchases of debt and equity marketable securities | — |  |  | (101 | ) |  | — |  |  | (5,936 | ) |
| Proceeds from sales and maturities of debt and equity marketable securities | 15 |  |  | 83 |  |  | 139 |  |  | 9,188 |  |
| Purchases of other marketable securities | — |  |  | — |  |  | — |  |  | (49 | ) |
| Proceeds from sales and maturities of other marketable securities | — |  |  | 50 |  |  | — |  |  | 50 |  |
| Acquisitions and other investments, net of cash acquired | (67 | ) |  | (134 | ) |  | (252 | ) |  | (326 | ) |
| Proceeds from other investments | 23 |  |  | 15 |  |  | 68 |  |  | 222 |  |
| Other items, net | 9 |  |  | 12 |  |  | 126 |  |  | 16 |  |
| Net cash (used) provided by investing activities | (337 | ) |  | (234 | ) |  | (806 | ) |  | 2,381 |  |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 1,181 |  |  | 1,746 |  |  | 5,989 |  |  | 11,131 |  |
| Repayment of short-term debt | (1,679 | ) |  | (3,929 | ) |  | (6,492 | ) |  | (11,127 | ) |
| Repayment of long-term debt | — |  |  | (3,942 | ) |  | — |  |  | (5,513 | ) |
| Proceeds from issuance of common stock | 150 |  |  | 216 |  |  | 414 |  |  | 603 |  |
| Repurchases and retirements of common stock | (705 | ) |  | (21,155 | ) |  | (1,793 | ) |  | (22,580 | ) |
| Dividends paid | (711 | ) |  | (866 | ) |  | (2,968 | ) |  | (3,466 | ) |
| Payments of tax withholdings related to vesting of share-based awards | (41 | ) |  | (7 | ) |  | (266 | ) |  | (280 | ) |
| Payment of purchase consideration related to RF360 Holdings | (1,119 | ) |  | — |  |  | (1,163 | ) |  | (157 | ) |
| Other items, net | (16 | ) |  | (57 | ) |  | (107 | ) |  | (111 | ) |
| Net cash used by financing activities | (2,940 | ) |  | (27,994 | ) |  | (6,386 | ) |  | (31,500 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (34 | ) |  | (22 | ) |  | (32 | ) |  | (41 | ) |
| Net (decrease) increase in total cash and cash equivalents | (2,084 | ) |  | (28,673 | ) |  | 62 |  |  | (25,252 | ) |
| Total cash and cash equivalents at beginning of period | 13,923 |  |  | 40,450 |  |  | 11,777 |  |  | 37,029 |  |
| Total cash and cash equivalents at end of period | $ | 11,839 |  |  | $ | 11,777 |  |  | $ | 11,839 |  |  | $ | 11,777 |  |
