# QCOM MD&A — 0001728949-19-000072


## mdna

[0001728949-19-000072:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001728949-19-000072:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes included in “Part II, Item 8. Financial Statements and Supplementary Data” of this Annual Report.

[0001728949-19-000072:mdna:3]
Fiscal 2019 Overview

[0001728949-19-000072:mdna:4]
Revenues were $24.3 billion, an increase of 7% from fiscal 2018, with net income of $4.4 billion, compared to net loss of $5.0 billion in fiscal 2018. Highlights and other events from fiscal 2019 included:

[0001728949-19-000072:mdna:5]
| • | From October 2018 through September 2019, approximately 1.4 billion smartphones are estimated to have shipped globally, representing a year-over-year decrease of approximately 4% (IDC, Mobile Phone Tracker, 2019Q3), primarily driven by further lengthening of replacement cycles, particularly in developed regions and China where consumer demand is increasingly driven by new product launches and/or innovation cycles as the industry transitions to 5G. |

[0001728949-19-000072:mdna:6]
| • | QCT results in fiscal 2019 were negatively impacted by lower modem sales to Apple. |

[0001728949-19-000072:mdna:7]
| • | In April 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties. We also entered into a six-year global patent license agreement with Apple, effective as of April 1, 2019, which includes an option for Apple to extend for two additional years, and a multi-year chipset supply agreement with Apple. In the third quarter of fiscal 2019, we recognized licensing revenues of $4.7 billion resulting from the settlement, consisting of a payment from Apple and the release of certain of our obligations to pay Apple and its contract manufacturers customer-related liabilities. In addition, our QTL results for the third and fourth quarters of fiscal 2019 included royalties from Apple and its contract manufacturers for sales made in such quarters. |

[0001728949-19-000072:mdna:8]
| • | QTL results in fiscal 2019 reflected certain reductions made in the per unit royalty caps (which provide a maximum royalty amount payable per device) in fiscal 2019 and 2018. While we expect these changes to enhance stability for the long term, they negatively impacted QTL royalty revenues in fiscal 2019. In addition, an increasing number of new and existing licensees have elected to enter into worldwide license agreements covering only our cellular standard essential patents, resulting in lower QTL royalty revenues in fiscal 2019. |

[0001728949-19-000072:mdna:9]
| • | QTL revenues in fiscal 2019 included $450 million paid under a second interim agreement with Huawei that concluded in the third quarter of fiscal 2019, and although negotiations continue, we have not reached a final agreement with Huawei. This represents a minimum, non-refundable amount for royalties due and does not reflect the full amount of royalties due under the underlying license agreement. We did not record any revenues in the fourth quarter of fiscal 2019 for royalties due on the sales of Huawei’s products. |

[0001728949-19-000072:mdna:10]
| • | In May 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief. We disagree with the court’s conclusions, interpretation of the facts and application of the law. Accordingly, we filed a motion to stay certain of the remedies with, and have appealed the decision to, the Ninth Circuit Court of Appeals (Ninth Circuit). In August 2019, our partial motion to stay was granted in its entirety by the Ninth Circuit. The impact of the Order and the Ninth Circuit granting our motion for partial stay did not have a material impact to QTL licensing revenues recognized in fiscal 2019 based on facts and factors currently known by us. |

[0001728949-19-000072:mdna:11]
| • | In July 2019, the European Commission (EC) issued a decision ruling that between 2009 and 2011 we engaged in predatory pricing with respect to two customers and imposed a fine (2019 EC fine) of approximately 242 million Euros, which resulted in a $275 million charge to other expenses in the third quarter of fiscal 2019. In October 2019, we filed an appeal of the EC’s decision, and we provided a financial guarantee to satisfy the obligation in lieu of a cash payment while we appeal the EC’s decision. |

[0001728949-19-000072:mdna:12]
| • | In the second quarter of fiscal 2018, we announced a Cost Plan designed to align our cost structure to our long-term margin targets. As part of this plan, we initiated a series of targeted actions across our businesses with the objective to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. Actions taken under this plan have been completed and resulted in us achieving substantially all of this target in fiscal |

[0001728949-19-000072:mdna:13]
41

[0001728949-19-000072:mdna:14]
2019 based on our run rate exiting the second quarter of fiscal 2019, excluding litigation costs that were in excess of the baseline spend. We recorded net restructuring and restructuring-related charges of $213 million in fiscal 2019 related to our Cost Plan.

[0001728949-19-000072:mdna:15]
| • | Beginning in fiscal 2019, certain provisions of the 2017 U.S. Tax Cuts and Jobs Act (the Tax Legislation) became effective, including new taxes on certain foreign income. Our estimated annual effective tax rate for fiscal 2019 reflected the effects of these provisions of the Tax Legislation, and it also included the effects of tax elections made by several of our foreign subsidiaries in the first quarter of fiscal 2019 to be treated as U.S. branches for federal income tax purposes effective beginning in fiscal 2018 and 2019, which resulted in an income tax benefit of $570 million recorded discretely in the first quarter of fiscal 2019. |

[0001728949-19-000072:mdna:16]
| • | During the third quarter of fiscal 2019, the United States Treasury Department issued new temporary regulations that resulted in a change to the deductibility of dividend income received by a U.S. stockholder from a foreign corporation. As a result of this change, pursuant to an agreement with the Internal Revenue Service, we relinquished the federal tax basis step-up of intellectual property that was distributed in fiscal 2018 by one of our foreign subsidiaries to a U.S. subsidiary. Therefore, the related deferred tax asset was derecognized, resulting in a $2.5 billion charge to income tax expense in the third quarter of fiscal 2019. |

[0001728949-19-000072:mdna:17]
Our Business and Operating Segments

[0001728949-19-000072:mdna:18]
We develop and commercialize foundational technologies and products used in mobile devices and other wireless products. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents and other rights.

[0001728949-19-000072:mdna:19]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices (primarily smartphones), tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, broadband gateway equipment, data cards and infrastructure equipment, IoT devices and applications, other consumer electronics and automotive telematics and infotainment systems. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale and/or use of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including Qualcomm Government Technologies or QGOV (formerly Qualcomm Cyber Security Solutions) and other wireless technology and service initiatives.

[0001728949-19-000072:mdna:20]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering, research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001728949-19-000072:mdna:21]
Further information regarding our business and operating segments is provided in “Part I, Item 1. Business” of this Annual Report.

[0001728949-19-000072:mdna:22]
Seasonality. Many of our products and/or much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when the related royalties were recognized, which prior to fiscal 2019 was when licensees reported their sales and beginning in fiscal 2019 was when the licensees’ sales occurred. Our historical trends were impacted by our prior dispute with Apple and its contract manufacturers, which was settled in April 2019. We expect to begin recording revenues for new chipset models under our recently announced multi-year chipset agreement with Apple in the second half of fiscal 2020. These trends may or may not continue in the future. Further, the trends for QTL have been, and/or may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings, including the lawsuit filed against us by the FTC.

[0001728949-19-000072:mdna:23]
Results of Operations

[0001728949-19-000072:mdna:24]
| Revenues (in millions) |  |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |  | 2019 vs. 2018 Change |  | 2018 vs. 2017 Change |
| Equipment and services | $ | 14,611 |  |  | $ | 17,400 |  |  | $ | 16,647 |  |  | $ | (2,789 | ) |  | $ | 753 |  |
| Licensing | 9,662 |  |  | 5,211 |  |  | 5,611 |  |  | 4,451 |  |  | (400 | ) |
|  | $ | 24,273 |  |  | $ | 22,611 |  |  | $ | 22,258 |  |  | $ | 1,662 |  |  | $ | 353 |  |

[0001728949-19-000072:mdna:25]
2019 vs. 2018

[0001728949-19-000072:mdna:26]
The increase in revenues in fiscal 2019 was primarily due to:

[0001728949-19-000072:mdna:27]
| + | $4.7 billion in licensing revenues recorded in the third quarter of fiscal 2019 resulting from the settlement with Apple and its contract manufacturers (which were not allocated to our segment results) |

[0001728949-19-000072:mdna:28]
| - | $2.7 billion in lower equipment and services revenues from our QCT segment |

[0001728949-19-000072:mdna:29]
| - | $451 million in lower licensing revenues from our QTL segment |

[0001728949-19-000072:mdna:30]
2018 vs. 2017

[0001728949-19-000072:mdna:31]
The increase in revenues in fiscal 2018 was primarily due to:

[0001728949-19-000072:mdna:32]
| + | $962 million reduction to licensing revenues recorded in fiscal 2017 related to the BlackBerry arbitration (which was not allocated to our segment results) |

[0001728949-19-000072:mdna:33]
| + | $745 million in higher equipment and services revenues from our QCT segment |

[0001728949-19-000072:mdna:34]
| - | $1.4 billion in lower licensing revenues from our QTL segment |

[0001728949-19-000072:mdna:35]
| - | $100 million reduction to licensing revenues recorded in fiscal 2018 related to a portion of a business arrangement that resolved a legal dispute (which was not allocated to our segment results) |

[0001728949-19-000072:mdna:36]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |  | 2019 vs. 2018 Change |  | 2018 vs. 2017 Change |
| Cost of revenues | $ | 8,599 |  |  | $ | 10,244 |  |  | $ | 9,792 |  |  | $ | (1,645 | ) |  | $ | 452 |  |
| Gross margin | 65 | % |  | 55 | % |  | 56 | % |  |  |  |  |

[0001728949-19-000072:mdna:37]
2019 vs. 2018

[0001728949-19-000072:mdna:38]
The increase in margin percentage in fiscal 2019 was primarily due to:

[0001728949-19-000072:mdna:39]
| + | higher licensing revenues resulting from the settlement with Apple and its contract manufacturers in fiscal 2019 |

[0001728949-19-000072:mdna:40]
2018 vs. 2017

[0001728949-19-000072:mdna:41]
The decrease in margin percentage in fiscal 2018 was primarily due to:

[0001728949-19-000072:mdna:42]
| - | decrease in higher margin QTL licensing revenues as a proportion of total revenues |

[0001728949-19-000072:mdna:43]
| - | reduction to licensing revenues recorded in fiscal 2018 related to a portion of a business arrangement that resolved a legal dispute |

[0001728949-19-000072:mdna:44]
| + | reduction to licensing revenues recorded in fiscal 2017 related to the BlackBerry arbitration |

[0001728949-19-000072:mdna:45]
Our margin percentage may continue to fluctuate in future periods depending on the mix of segment results as well as products sold, competitive pricing, new product introduction costs and other factors, including disputes and/or resolutions with licensees and/or governmental investigations or proceedings, including the lawsuit filed against us by the FTC.

[0001728949-19-000072:mdna:46]
|  | 2019 |  | 2018 |  | 2017 |  | 2019 vs. 2018 Change |  | 2018 vs. 2017 Change |
| Research and development | $ | 5,398 |  |  | $ | 5,625 |  |  | $ | 5,485 |  |  | $ | (227 | ) |  | $ | 140 |  |
| % of revenues | 22 | % |  | 25 | % |  | 25 | % |  |  |  |  |

[0001728949-19-000072:mdna:47]
2019 vs. 2018

[0001728949-19-000072:mdna:48]
The dollar decrease in research and development expenses in fiscal 2019 was primarily due to:

[0001728949-19-000072:mdna:49]
| - | $221 million decrease primarily driven by actions taken under our Cost Plan, partially offset by higher share-based compensation expense and higher employee cash incentive programs |

[0001728949-19-000072:mdna:50]
2018 vs. 2017

[0001728949-19-000072:mdna:51]
The dollar increase in research and development expenses in fiscal 2018 was primarily due to:

[0001728949-19-000072:mdna:52]
| + | $168 million, net of cost decreases driven by actions taken under our Cost Plan, in higher costs related to the development of wireless and integrated circuit technologies, including 5G technologies and RFFE technologies from the formation of RF360 Holdings in the second quarter of fiscal 2017 |

[0001728949-19-000072:mdna:53]
| - | $30 million impairment charge on certain intangible assets recorded in fiscal 2017 |

[0001728949-19-000072:mdna:54]
In fiscal 2018, all of the costs ($474 million) related to pre-commercial research and development of 5G technologies were included in unallocated corporate research and development expenses. Beginning in fiscal 2019, all research and development costs associated with 5G technologies were included in segment results. Additionally, beginning in fiscal 2019, certain research and development costs associated with early research and development that were historically included in our QCT segment were allocated to our QTL segment. The net effect of these changes negatively impacted QTL’s EBT by $489 million in fiscal 2019 and positively impacted QCT’s EBT by $160 million in fiscal 2019.

[0001728949-19-000072:mdna:55]
|  | 2019 |  | 2018 |  | 2017 |  | 2019 vs. 2018 Change |  | 2018 vs. 2017 Change |
| Selling, general and administrative | $ | 2,195 |  |  | $ | 2,986 |  |  | $ | 2,658 |  |  | $ | (791 | ) |  | $ | 328 |  |
| % of revenues | 9 | % |  | 13 | % |  | 12 | % |  |  |  |  |

[0001728949-19-000072:mdna:56]
2019 vs. 2018

[0001728949-19-000072:mdna:57]
The dollar decrease in selling, general and administrative expenses in fiscal 2019 was primarily due to:

[0001728949-19-000072:mdna:58]
| - | $287 million in lower professional fees and costs, primarily driven by Broadcom’s withdrawn takeover proposal in fiscal 2018 and our then proposed acquisition of NXP Semiconductors N.V. (NXP) in fiscal 2018 |

[0001728949-19-000072:mdna:59]
| - | $235 million in lower litigation costs, primarily resulting from the settlement of our prior dispute with Apple and its contract manufacturers and the end of the District Court trial in the lawsuit filed against us by the FTC |

[0001728949-19-000072:mdna:60]
| - | $162 million in lower employee-related expenses, primarily driven by actions taken under our Cost Plan |

[0001728949-19-000072:mdna:61]
| - | $75 million in lower sales and marketing expenses, primarily driven by actions taken under our Cost Plan |

[0001728949-19-000072:mdna:62]
2018 vs. 2017

[0001728949-19-000072:mdna:63]
The dollar increase in selling, general and administrative expenses in fiscal 2018 was primarily due to:

[0001728949-19-000072:mdna:64]
| + | $325 million in higher litigation costs, with total litigation costs of $554 million and $229 million in fiscal 2018 and fiscal 2017, respectively |

[0001728949-19-000072:mdna:65]
| + | $45 million in bad debt expense recorded in fiscal 2018 |

[0001728949-19-000072:mdna:66]
| + | $42 million in higher professional fees and costs related to other legal matters, which was primarily driven by Broadcom’s withdrawn takeover proposal, partially offset by lower third-party acquisition and integration services fees |

[0001728949-19-000072:mdna:67]
| - | $40 million in lower amortization expense, primarily from the formation of RF360 Holdings |

[0001728949-19-000072:mdna:68]
| - | $37 million in lower share-based compensation expense, primarily due to actions taken under our Cost Plan |

[0001728949-19-000072:mdna:69]
|  | 2019 |  | 2018 |  | 2017 |  | 2019 vs. 2018 Change |  | 2018 vs. 2017 Change |
| Other | $ | 414 |  |  | $ | 3,135 |  |  | $ | 1,742 |  |  | $ | (2,721 | ) |  | $ | 1,393 |  |

[0001728949-19-000072:mdna:70]
2019

[0001728949-19-000072:mdna:71]
Other expenses in fiscal 2019 consisted of:

[0001728949-19-000072:mdna:72]
+    $275 million charge related to the 2019 EC fine

[0001728949-19-000072:mdna:73]
| + | $213 million net charges related to our Cost Plan |

[0001728949-19-000072:mdna:74]
| - | $43 million gain due to the partial recovery of a fine imposed in fiscal 2009 resulting from our appeal of the Korea Fair Trade Commission (KFTC) decision |

[0001728949-19-000072:mdna:75]
| - | $31 million gain related to a favorable legal settlement |

[0001728949-19-000072:mdna:76]
2018

[0001728949-19-000072:mdna:77]
Other expenses in fiscal 2018 consisted of:

[0001728949-19-000072:mdna:78]
+    $2.0 billion charge related to a fee in connection with the termination of a purchase agreement to acquire NXP

[0001728949-19-000072:mdna:79]
+    $1.2 billion charge related to a fine imposed by the EC

[0001728949-19-000072:mdna:80]
+    $629 million in restructuring and restructuring-related charges related to our Cost Plan

[0001728949-19-000072:mdna:81]
| - | $676 million benefit related to the settlement of the Taiwan Fair Trade Commission (TFTC) investigation |

[0001728949-19-000072:mdna:82]
2017

[0001728949-19-000072:mdna:83]
Other expense in fiscal 2017 consisted of:

[0001728949-19-000072:mdna:84]
| + | $927 million charge related to the KFTC fine, including related foreign currency losses |

[0001728949-19-000072:mdna:85]
+    $778 million charge related to the TFTC fine

[0001728949-19-000072:mdna:86]
+    $37 million in restructuring and restructuring-related charges related to our 2015 Strategic Realignment Plan

[0001728949-19-000072:mdna:87]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |  | 2019 vs. 2018 Change |  | 2018 vs. 2017 Change |
| Interest expense | $ | 627 |  |  | $ | 768 |  |  | $ | 494 |  |  | $ | (141 | ) |  | $ | 274 |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 316 |  |  | $ | 625 |  |  | $ | 619 |  |  | $ | (309 | ) |  | $ | 6 |  |
| Net gains on marketable securities | 288 |  |  | 41 |  |  | 456 |  |  | 247 |  |  | (415 | ) |
| Net gains on other investments | 68 |  |  | 83 |  |  | 74 |  |  | (15 | ) |  | 9 |  |
| Impairment losses on marketable securities and other investments | (135 | ) |  | (75 | ) |  | (177 | ) |  | (60 | ) |  | 102 |  |
| Net (losses) gains on derivative instruments | (14 | ) |  | (27 | ) |  | 32 |  |  | 13 |  |  | (59 | ) |
| Equity in net losses of investees | (93 | ) |  | (145 | ) |  | (74 | ) |  | 52 |  |  | (71 | ) |
| Net gains (losses) on foreign currency transactions | 11 |  |  | 37 |  |  | (30 | ) |  | (26 | ) |  | 67 |  |
|  | $ | 441 |  |  | $ | 539 |  |  | $ | 900 |  |  | $ | (98 | ) |  | $ | (361 | ) |

[0001728949-19-000072:mdna:88]
In the fourth quarter of fiscal 2018, we implemented a stock repurchase program to repurchase up to $30 billion of our outstanding common stock. Stock repurchases made under this program have significantly reduced the amount of our cash, cash equivalents and marketable securities, resulting in a decrease to interest and dividend income in fiscal 2019. The increase in net gains on marketable securities in fiscal 2019 was primarily driven by gains resulting from the initial public offering of certain non-marketable equity investments.

[0001728949-19-000072:mdna:89]
The increase in interest expense in fiscal 2018 was primarily due to the issuance of an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes in May 2017, of which $4.0 billion were repaid between May and August 2018.

[0001728949-19-000072:mdna:90]
In the first quarter of fiscal 2017, we began divesting a substantial portion of our marketable securities portfolio in order to finance, in part, the then proposed acquisition of NXP. As a result, we recorded net realized gains and impairment losses on such marketable securities that we sold and expected to sell before their anticipated recovery, respectively, in fiscal 2017.

[0001728949-19-000072:mdna:91]
| Income Tax Expense (in millions. except percentages) |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |  | 2019 vs. 2018 Change |  | 2018 vs. 2017 Change |
| Income tax expense | $ | 3,095 |  |  | $ | 5,356 |  |  | $ | 543 |  |  | $ | (2,261 | ) |  | $ | 4,813 |  |
| Effective tax rate | 41 | % |  | N/M |  |  | 18 | % |  |  |  |  |  |  |

[0001728949-19-000072:mdna:92]
N/M - Not meaningful

[0001728949-19-000072:mdna:93]
The following table summarizes the primary factors that caused our annual tax provision to differ from the expected income tax provision at the United States federal statutory rate (in millions):

[0001728949-19-000072:mdna:94]
|  | 2019 |  | 2018 |  | 2017 |
| Expected income tax provision at federal statutory tax rate | $ | 1,571 |  |  | $ | 97 |  |  | $ | 1,045 |  |
| State income tax provision, net of federal benefit | 10 |  |  | 2 |  |  | 8 |  |
| Derecognition of deferred tax asset on distributed intellectual property | 2,472 |  |  | — |  |  | — |  |
| Benefits from establishing new U.S. net deferred tax assets | (570 | ) |  | — |  |  | — |  |
| Benefits from foreign-derived intangible income (FDII) deduction | (419 | ) |  | — |  |  | — |  |
| Benefits related to the research and development tax credit | (110 | ) |  | (136 | ) |  | (81 | ) |
| Benefits from foreign income taxed at other than U.S. rates | (54 | ) |  | (834 | ) |  | (963 | ) |
| Nondeductible charges (reversals) related to the EC, KFTC and TFTC investigations | 51 |  |  | (119 | ) |  | 363 |  |
| Impact of changes in tax reserves and audit settlements for prior year tax positions | 20 |  |  | — |  |  | 111 |  |
| Taxes on undistributed foreign earnings | 8 |  |  | 87 |  |  | — |  |
| Toll Charge from U.S. tax reform | — |  |  | 5,236 |  |  | — |  |
| Valuation allowance on deferred tax asset related to NXP termination fee | — |  |  | 494 |  |  | — |  |
| Remeasurement of deferred taxes due to changes in statutory rate due to U.S. tax reform | — |  |  | 443 |  |  | — |  |
| Other | 116 |  |  | 86 |  |  | 60 |  |
| Income tax expense | $ | 3,095 |  |  | $ | 5,356 |  |  | $ | 543 |  |

[0001728949-19-000072:mdna:95]
The 2017 Tax Cuts and Jobs Act (the Tax Legislation), which was enacted during the first quarter of fiscal 2018, significantly revised the United States corporate income tax by, among other things, lowering the corporate income tax rate to 21% and imposing a one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge). The Tax Legislation fundamentally changed the taxation of multinational entities, including a shift from a system of worldwide taxation with deferral to a hybrid territorial system, featuring a participation exemption regime with current taxation of certain foreign income, a minimum tax on low-taxed foreign earnings and new measures to deter base erosion and promote U.S. production. As a fiscal-year taxpayer, certain provisions of the Tax Legislation became effective starting at the beginning of fiscal 2019, including GILTI (global intangible low-taxed income), a new tax on income of foreign corporations, BEAT (base-erosion and anti-abuse tax) and FDII (foreign-derived intangible income). In response to the Tax Legislation and to better align our profits with our activities, we implemented certain tax restructuring in fiscal 2018 and 2019. As a result, beginning in fiscal 2019, substantially all of our income is in the U.S., of which a significant portion qualifies for preferential treatment as FDII at a 13% effective tax rate. The impact of GILTI and BEAT is negligible. Accordingly, our annual effective tax rate for fiscal 2019 reflected the effects of these provisions of the Tax Legislation. Our annual effective tax rate for fiscal 2018 reflected a blended federal statutory rate of approximately 25%.

[0001728949-19-000072:mdna:96]
As a result of the Tax Legislation, in fiscal 2019, several of our foreign subsidiaries made tax elections to be treated as U.S. branches for federal income tax purposes (commonly referred to as “check-the-box” elections) effective beginning in fiscal 2018 and 2019. As a result of making these check-the-box elections, we recorded a tax benefit of $570 million in fiscal 2019. Additionally, in fiscal 2019, the United States Treasury Department issued new temporary regulations that resulted in a change to the deductibility of dividend income received by a U.S. stockholder from a foreign corporation. As a result of this change, pursuant to an agreement with the Internal Revenue Service, we relinquished the federal tax basis step-up of intellectual property that was distributed in fiscal 2018 by one of our foreign subsidiaries to a U.S. subsidiary. Therefore, the related deferred tax asset was derecognized, resulting in a $2.5 billion charge to income tax expense in fiscal 2019.

[0001728949-19-000072:mdna:97]
Income tax expense for fiscal 2019 also reflected benefits from our FDII deduction (including the impact of the Apple settlement) and research and development credits, as well as the impact of the 2019 EC fine, which is not deductible for tax purposes.

[0001728949-19-000072:mdna:98]
In fiscal 2018, as a result of the Tax Legislation, we recorded a charge of $5.7 billion to income tax expense, comprised of $5.2 billion related to the estimated Toll Charge and $438 million resulting from the remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate, which included a $135 million tax benefit in fiscal 2018 related to the remeasurement of a U.S. deferred tax liability that was established as a result of a change in one of our positions due to the Tax Legislation.

[0001728949-19-000072:mdna:99]
46

[0001728949-19-000072:mdna:100]
Income tax expense for fiscal 2018 was also impacted by the charge recorded in the fourth quarter of fiscal 2018 related to the termination fee paid to NXP, which did not result in a tax benefit after the consideration of realizability of such loss. Fiscal 2018 and 2017 income tax expense was impacted by the EC, KFTC and TFTC fines, and settlement with the TFTC, which were not deductible for tax purposes (or taxable in the case of the settlement) and portions of which were attributable to foreign jurisdictions and to the United States. These impacts were partially offset in fiscal 2018 and 2017 by lower U.S. revenues primarily related to decreased royalty revenues from Apple’s contract manufacturers and, for fiscal 2017, a payment to BlackBerry in connection with an arbitration decision.

[0001728949-19-000072:mdna:101]
Income tax expense for fiscal 2017 also reflected the increase in our Singapore tax rate as a result of the expiration of certain of our tax incentives in March 2017, which was substantially offset by tax benefits resulting from the increase in our Singapore tax rate in effect when certain deferred tax assets reversed. During the third quarter of fiscal 2018, we entered into a new tax incentive agreement in Singapore that results in a reduced tax rate from March 2017 through March 2022, provided that we meet specified employment and investment criteria in Singapore. Our Singapore tax rate will increase in March 2022 as a result of expiration of these incentives and again in March 2027 upon the expiration of tax incentives under a prior agreement. Without these tax incentives, our fiscal 2018 income tax expense would have been higher. During fiscal 2018, one of our Singapore subsidiaries distributed certain intellectual property to a U.S. subsidiary, substantially reducing the benefit of these tax incentives going forward.

[0001728949-19-000072:mdna:102]
Unrecognized tax benefits were $1.7 billion and $217 million at September 29, 2019 and September 30, 2018, respectively. The increase in unrecognized tax benefits in fiscal 2019 was primarily due to our plan to apply for a refund of Korean withholding tax (which had an insignificant impact to our income tax provision) as a result of recent court rulings in Korea, among other factors. If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We are subject to income taxes in the United States and numerous foreign jurisdictions and are currently under examination by various tax authorities worldwide, primarily related to transfer pricing. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of September 29, 2019, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0001728949-19-000072:mdna:103]
Segment Results

[0001728949-19-000072:mdna:104]
The following should be read in conjunction with the fiscal 2019, 2018 and 2017 results of operations for each reportable segment included in this Annual Report in “Notes to Consolidated Financial Statements, Note 8. Segment Information.”

[0001728949-19-000072:mdna:105]
QCT Segment (in millions, except percentages)

[0001728949-19-000072:mdna:106]
|  | 2019 |  | 2018 |  | 2017 |  | 2019 vs. 2018 Change |  | 2018 vs. 2017 Change |
| Revenues |  |  |  |  |  |  |  |  |  |
| Equipment and services | $ | 14,318 |  |  | $ | 17,060 |  |  | $ | 16,315 |  |  | $ | (2,742 | ) |  | $ | 745 |  |
| Licensing | 321 |  |  | 222 |  |  | 164 |  |  | 99 |  |  | 58 |  |
| Total revenues | $ | 14,639 |  |  | $ | 17,282 |  |  | $ | 16,479 |  |  | $ | (2,643 | ) |  | $ | 803 |  |
| EBT (1) | $ | 2,143 |  |  | $ | 2,966 |  |  | $ | 2,747 |  |  | $ | (823 | ) |  | $ | 219 |  |
| EBT as a % of revenues | 15 | % |  | 17 | % |  | 17 | % |  | (2 | %) |  | — | % |

[0001728949-19-000072:mdna:107]
| (1) | Earnings (loss) before taxes. |

[0001728949-19-000072:mdna:108]
Beginning in fiscal 2019, we combined our Small Cells business, which sells products designed for the implementation of small cells to address the challenge of meeting the increased demand for mobile data, into our QCT segment. Revenues and operating results related to the Small Cells business were included in nonreportable segments through the end of fiscal 2018. Prior period segment information has not been adjusted to conform to the new segment presentation as such adjustments are insignificant.

[0001728949-19-000072:mdna:109]
Equipment and services revenues mostly relate to sales of Mobile Station Modem (MSM™), Radio Frequency (RF), Power Management (PM) and wireless connectivity integrated circuits. MSM integrated circuits include our stand-alone Mobile Data Modems and Snapdragon platforms, including processors and modems. Approximately 650 million, 855 million and 804 million MSM integrated circuits were sold during fiscal 2019, 2018 and 2017, respectively.

[0001728949-19-000072:mdna:110]
2019 vs. 2018

[0001728949-19-000072:mdna:111]
The decrease in QCT equipment and services revenues was primarily due to:

[0001728949-19-000072:mdna:112]
| - | $2.7 billion in lower MSM and accompanying unit shipments, primarily driven by lower modem sales to Apple and a decline in demand from OEMs in China |

[0001728949-19-000072:mdna:113]
| - | $515 million in lower connectivity product revenues, primarily driven by a decline in demand for Wi-Fi and Bluetooth products from OEMs in China |

[0001728949-19-000072:mdna:114]
| + | $552 million in higher revenues per MSM and accompanying unit shipment, primarily driven by a favorable shift in mix related to our premium-tier products |

[0001728949-19-000072:mdna:115]
QCT EBT as a percentage of revenues decreased in fiscal 2019 primarily due to:

[0001728949-19-000072:mdna:116]
| - | lower QCT revenues |

[0001728949-19-000072:mdna:117]
| + | decrease in operating expenses, primarily driven by a decrease in the amount of research and development expense allocated to QCT in fiscal 2019 and actions under our Cost Plan |

[0001728949-19-000072:mdna:118]
QCT accounts receivable decreased by 33% in fiscal 2019 from $1.36 billion to $908 million, primarily due to the decrease in revenues, as well as the impact of settling certain receivables in connection with the settlement agreements with Apple and its contract manufacturers. QCT inventories decreased by 17% in fiscal 2019 from $1.68 billion to $1.40 billion, primarily due to a decrease in the overall quantity of units on hand.

[0001728949-19-000072:mdna:119]
2018 vs. 2017

[0001728949-19-000072:mdna:120]
The increase in QCT equipment and services revenues in fiscal 2018 was primarily due to:

[0001728949-19-000072:mdna:121]
| + | $825 million in higher RFFE product revenues primarily related to revenues from RF360 Holdings, which was formed in the second quarter of fiscal 2017, and reflected the impact of eliminating a one-month reporting lag in fiscal 2018 |

[0001728949-19-000072:mdna:122]
| + | $737 million in higher MSM and accompanying unit shipments primarily driven by higher demand from OEMs in China, partially offset by a decline in share at Apple |

[0001728949-19-000072:mdna:123]
| - | $719 million decrease due to lower average selling prices and unfavorable product mix |

[0001728949-19-000072:mdna:124]
| - | $83 million in lower connectivity product revenues |

[0001728949-19-000072:mdna:125]
QCT EBT as a percentage of revenues remained flat in fiscal 2018 primarily due to an unchanged gross margin percentage, driven by the net effect of lower average selling prices and lower-margin product mix, offset by lower average unit costs.

[0001728949-19-000072:mdna:126]
QTL Segment (in millions, except percentages)

[0001728949-19-000072:mdna:127]
|  | 2019 |  | 2018 |  | 2017 |  | 2019 vs. 2018 Change |  | 2018 vs. 2017 Change |
| Licensing revenues | $ | 4,591 |  |  | $ | 5,042 |  |  | $ | 6,412 |  |  | $ | (451 | ) |  | $ | (1,370 | ) |
| EBT | $ | 2,954 |  |  | $ | 3,404 |  |  | $ | 5,142 |  |  | $ | (450 | ) |  | $ | (1,738 | ) |
| EBT as a % of revenues | 64 | % |  | 68 | % |  | 80 | % |  | (4 | %) |  | (12 | %) |

[0001728949-19-000072:mdna:128]
QTL results in fiscal 2019 reflected the adoption of new revenue recognition guidance that requires us to estimate and recognize QTL royalties in the period in which the associated sales occur, resulting in an acceleration of royalty revenues by one quarter as compared to prior periods. Prior period results have not been adjusted for the adoption of the new accounting guidance.

[0001728949-19-000072:mdna:129]
As a result of the settlement with Apple and its contract manufacturers, QTL results for fiscal 2019 included royalties from Apple and its contract manufactures for sales made in the June 2019 and September 2019 quarters. Revenues in the first six months of fiscal 2019 and all of fiscal 2018 did not include royalties due on sales of Apple or other products by Apple’s contract manufacturers.

[0001728949-19-000072:mdna:130]
QTL revenues in fiscal 2019 included $450 million of royalties due under a second interim agreement with Huawei that concluded in the third quarter of fiscal 2019, and although negotiations continue, we have not reached a final agreement with Huawei. We did not record any revenues in the fourth quarter of fiscal 2019 for royalties due on the sales of Huawei’s products. QTL revenues in fiscal 2018 included $600 million paid under an interim agreement with Huawei for royalties due after the second quarter of fiscal 2017. These payments represent minimum, non-refundable amounts for royalties due and do not reflect the full amount of royalties due under the underlying license agreement.

[0001728949-19-000072:mdna:131]
We did not record any revenues in the third or fourth quarter of fiscal 2017 for royalties due on the sales of Apple or other products by Apple’s contract manufacturers and Huawei’s products, and Huawei underpaid royalties due in the second quarter of fiscal 2017, which negatively impacted QTL revenues. Royalty revenues related to the products of Apple’s contract manufacturers and Huawei were approximately $1.7 billion in fiscal 2017.

[0001728949-19-000072:mdna:132]
2019 vs. 2018

[0001728949-19-000072:mdna:133]
QTL licensing revenues in fiscal 2019, which primarily related to royalties due on sales made by our licensees in the December 2018, March 2019, June 2019 and September 2019 quarters, decreased compared to licensing revenues in fiscal 2018, which primarily related to royalties due on sales made by our licensees in the September 2017, December 2017, March 2018 and June 2018 quarters, primarily due to:

[0001728949-19-000072:mdna:134]
| - | $757 million in lower estimated revenues per unit compared to revenues per reported unit, in part reflecting licensees entering into new 5G multimode license agreements with rights to our cellular standard-essential patents only (compared to previous licenses which also included rights to certain other non-cellular essential patents), and decreases in our per unit royalty caps |

[0001728949-19-000072:mdna:135]
| - | $150 million in lower royalty revenues from Huawei under the interim agreements |

[0001728949-19-000072:mdna:136]
| + | $484 million increase in estimated sales of 3G/4G/5G-based products (including multimode products) compared to reported sales of 3G/4G-based products, primarily due to the new license agreement with Apple, partially offset by a decline in unit demand and a shift in OEM share towards Huawei |

[0001728949-19-000072:mdna:137]
QTL EBT as a percentage of revenues decreased in fiscal 2019 primarily due to:

[0001728949-19-000072:mdna:138]
| - | higher research and development costs due to an increase in the amount of research and development expense allocated to QTL in fiscal 2019 |

[0001728949-19-000072:mdna:139]
| - | lower QTL revenues |

[0001728949-19-000072:mdna:140]
| + | lower selling, general and administrative expenses, primarily from lower litigation costs and lower bad debt expense |

[0001728949-19-000072:mdna:141]
QTL accounts receivable increased by 5% in fiscal 2019 from $1.47 billion to $1.54 billion, primarily due to the adoption of the new revenue recognition guidance, partially offset by the impact of settling approximately $960 million of receivables that were related to the short payment in the second quarter of fiscal 2017 of royalties due from Apple’s contract manufacturers in connection with the settlement agreements with Apple and its contract manufacturers.

[0001728949-19-000072:mdna:142]
2018 vs. 2017

[0001728949-19-000072:mdna:143]
Excluding the impact of the prior dispute with Apple and its contract manufacturers, as well as the dispute with Huawei, QTL licensing revenues in fiscal 2018 further decreased primarily due to:

[0001728949-19-000072:mdna:144]
| - | $177 million in lower royalty revenues recognized related to devices sold in prior periods from certain other licensees |

[0001728949-19-000072:mdna:145]
QTL EBT as a percentage of revenue decreased in fiscal 2018 primarily due to:

[0001728949-19-000072:mdna:146]
| - | higher selling, general and administrative expenses resulting primarily from higher litigation costs |

[0001728949-19-000072:mdna:147]
| - | lower QTL revenues |

[0001728949-19-000072:mdna:148]
QSI Segment (in millions)

[0001728949-19-000072:mdna:149]
|  | 2019 |  | 2018 |  | 2017 |  | 2019 vs. 2018 Change |  | 2018 vs. 2017 Change |
| Equipment and services revenues | $ | 152 |  |  | $ | 100 |  |  | $ | 113 |  |  | $ | 52 |  |  | $ | (13 | ) |
| EBT | $ | 344 |  |  | $ | 24 |  |  | $ | 65 |  |  | $ | 320 |  |  | $ | (41 | ) |

[0001728949-19-000072:mdna:150]
2019 vs. 2018

[0001728949-19-000072:mdna:151]
The increase in QSI EBT in fiscal 2019 was primarily due to:

[0001728949-19-000072:mdna:152]
| + | $270 million increase in net gains on investments, primarily driven by gains resulting from the initial public offering of certain non-marketable equity investments |

[0001728949-19-000072:mdna:153]
| + | $91 million increase resulting from higher revenues and lower costs associated with certain development contracts with an equity method investee |

[0001728949-19-000072:mdna:154]
| - | $41 million increase in impairment losses on investments, primarily related to an equity method investee |

[0001728949-19-000072:mdna:155]
QSI segment assets, which primarily consist of marketable and non-marketable equity investments, increased by 34% in fiscal 2019 from $1.28 billion to $1.71 billion, primarily due to recording certain non-marketable equity investments at fair value upon becoming publicly traded and acquiring non-marketable equity investments.

[0001728949-19-000072:mdna:156]
2018 vs. 2017

[0001728949-19-000072:mdna:157]
The decrease in QSI EBT in fiscal 2018 was primarily due to:

[0001728949-19-000072:mdna:158]
| - | $14 million decrease in net gains on investments |

[0001728949-19-000072:mdna:159]
| - | $14 million increase in our share of losses in equity method investments |

[0001728949-19-000072:mdna:160]
| - | $13 million decrease resulting from lower revenues from certain development contracts with one of our equity method investees |

[0001728949-19-000072:mdna:161]
Looking Forward

[0001728949-19-000072:mdna:162]
In the coming years, we expect consumer demand for 3G/4G multimode and 4G products and services to decline as new consumer demand for 3G/4G/5G multimode and 5G products and services ramp around the world. We expect growth in new

[0001728949-19-000072:mdna:163]
49

[0001728949-19-000072:mdna:164]
device categories and industries, resulting from the expanding adoption of certain technologies that are already commonly used in smartphones by industry segments outside traditional cellular industries, such as automotive, computing, IoT and networking.

[0001728949-19-000072:mdna:165]
As we look forward to the next several months and beyond, we expect our business to be impacted by the following key items:

[0001728949-19-000072:mdna:166]
| • | In May 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief. We disagree with the court’s conclusions, interpretation of the facts and application of the law. Accordingly, we filed a motion to stay certain of the remedies with, and have appealed the decision to, the Ninth Circuit Court of Appeals (Ninth Circuit). In August 2019, our partial motion to stay was granted in its entirety by the Ninth Circuit. Regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us, and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. These activities have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs until the respective matters are resolved. See “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies” and “Part I, Item 1A. Risk Factors” included in this Annual Report, including the Risk Factors entitled “Efforts by some communications equipment manufacturers or their customers to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business,” “Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings” and “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations.” |

[0001728949-19-000072:mdna:167]
| • | In fiscal 2019, we entered into a second interim agreement with Huawei under which we recognized $450 million of royalty revenues in fiscal 2019. These payments do not reflect the full amount of royalties due under the underlying license agreement. The second interim agreement concluded in the third quarter of fiscal 2019, and although negotiations continue, we have not reached a final agreement with Huawei. We did not record any revenues in the fourth quarter of fiscal 2019 for royalties due on the sales of Huawei’s products. If no agreement is reached, Huawei may not make any other payments or may not make full payments due under the underlying license agreement, which may result in significant legal costs and will negatively impact our future revenues, as well as our financial condition, results of operations and cash flows, until the dispute is resolved. |

[0001728949-19-000072:mdna:168]
| • | We expect our business, particularly QCT, to continue to be impacted by industry dynamics, including: |

[0001728949-19-000072:mdna:169]
| • | Increased concentration of device share among a few companies, particularly within the premium tier, resulting in significant supply chain leverage for those companies, and exacerbating the negative impact to our business and financial results to the extent those companies do not utilize our chipsets. For example, Huawei has taken, and we believe will continue to take, share in China from other Chinese OEMs, negatively impacting QCT as we sell a limited number of chipsets to Huawei as compared to many of those other OEMs, and the negative impact to our overall business of Huawei share gains at the expense of other Chinese OEMs may be further exacerbated if Huawei continues to not pay us royalties or does not make full payment due to us under its license agreement; |

[0001728949-19-000072:mdna:170]
| • | Decisions by companies to utilize their own internally-developed integrated circuit products and/or sell such products to others, including by selling them together with certain of their other products; |

[0001728949-19-000072:mdna:171]
| • | Decisions by certain companies to utilize our competitors’ integrated circuit products in all or a portion of their devices. For example, we have not been the sole supplier of modems for iPhone products beginning |

[0001728949-19-000072:mdna:172]
50

[0001728949-19-000072:mdna:173]
with products that launched in September 2016, as Apple utilizes modems from one of our competitors in a portion of such devices. Apple is solely using one of our competitors’ modems, rather than our modems, in its 2019 iPhone release. For new chipset models, QCT does not expect to begin recording revenues under our recently announced multi-year chipset agreement with Apple until the second half of fiscal 2020;

[0001728949-19-000072:mdna:174]
| • | Intense competition, particularly in China, as our competitors expand their product offerings and/or reduce the prices of their products as part of a strategy to attract new and/or retain existing customers; |

[0001728949-19-000072:mdna:175]
| • | Slow-down in handset demand as the industry transitions from 4G to 5G and continued reduction in demand in developed regions and China; |

[0001728949-19-000072:mdna:176]
| • | Lengthened handset replacement cycles and consumer demand, which is increasingly driven by new product launches and/or innovation cycles; and |

[0001728949-19-000072:mdna:177]
| • | Continued growth of device share by Chinese OEMs in China and in regions outside of China. |

[0001728949-19-000072:mdna:178]
| • | Current U.S./China trade relations and/or national security protection policies may negatively impact our business, growth prospects and results of operations. |

[0001728949-19-000072:mdna:179]
| • | Initial commercial 5G network deployments and device launches have begun and will continue into fiscal 2020 and beyond. We believe that 5G technologies will empower a new era of smartphones and connected devices. We also believe that 5G will drive transformation across industries beyond traditional cellular communications that will create new business models and new services. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing of 5G technologies, and to be a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long term. |

[0001728949-19-000072:mdna:180]
| • | We continue to invest significant resources to develop our wireless baseband chipsets, and our converged computing/communications (Snapdragon) chipsets, which incorporate technologies in the following areas, among others: advancements in 4G and 5G, OFDM-based Wi-Fi, RF, connectivity, power management, graphics, audio and video codecs, multimedia, artificial intelligence and virtual/augmented reality, and all of which contribute to the expansion of our intellectual property portfolio. We are also investing in targeted opportunities that leverage our existing technical and business expertise to deploy new business models and enter and/or expand into new industry segments and applications, such as products for automotive, computing, IoT (including the connected home, smart cities, wearables, voice and music and robotics) and networking, among others. |

[0001728949-19-000072:mdna:181]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless value chain and governments as to the benefits of our licensing program and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not welcome the success of our licensing program in enabling new, highly cost-effective competitors to their products. Accordingly, such companies, and/or governments or regulators, may continue to challenge our business model in various forums throughout the world.

[0001728949-19-000072:mdna:182]
Further discussion of risks related to our business is presented in “Part I, Item 1A. Risk Factors” included in this Annual Report.

[0001728949-19-000072:mdna:183]
51

[0001728949-19-000072:mdna:184]
Liquidity and Capital Resources

[0001728949-19-000072:mdna:185]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following table presents selected financial information related to our liquidity as of and for the years ended September 29, 2019 and September 30, 2018 (in millions, except percentages):

[0001728949-19-000072:mdna:186]
|  | 2019 |  | 2018 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 12,296 |  |  | $ | 12,123 |  |  | $ | 173 |  |  | 1 | % |
| Accounts receivable, net | 2,471 |  |  | 2,904 |  |  | (433 | ) |  | (15 | %) |
| Inventories | 1,400 |  |  | 1,693 |  |  | (293 | ) |  | (17 | %) |
| Short-term debt | 2,496 |  |  | 1,005 |  |  | 1,491 |  |  | 148 | % |
| Long-term debt | 13,437 |  |  | 15,365 |  |  | (1,928 | ) |  | (13 | %) |
| Net cash provided by operating activities | 7,286 |  |  | 3,908 |  |  | 3,378 |  |  | 86 | % |
| Net cash (used) provided by investing activities | (806 | ) |  | 2,381 |  |  | (3,187 | ) |  | (134 | %) |
| Net cash used by financing activities | (6,386 | ) |  | (31,500 | ) |  | 25,114 |  |  | (80 | %) |

[0001728949-19-000072:mdna:187]
The net increase in cash, cash equivalents and marketable securities was primarily due to net cash provided by operating activities and $414 million in proceeds from issuance of common stock, partially offset by $3.0 billion in cash dividends paid, $1.8 billion in payments to repurchase shares of our common stock, a $1.2 billion payment of purchase consideration related to RF360 Holdings, $887 million in capital expenditures, $503 million in net repayments under our commercial paper program and $266 million in payments of tax withholdings related to the vesting of share-based awards. The net increase in total cash provided by operating activities reflected the settlement with Apple and its contract manufacturers, as well as lower segment revenues and the impact of timing of payments of customer-related liabilities.

[0001728949-19-000072:mdna:188]
Our days sales outstanding, on a consolidated basis, increased to 47 days at September 29, 2019 compared to 30 days at September 30, 2018. The increase in days sales outstanding was primarily due to the adoption of the new revenue recognition guidance in fiscal 2019. The decrease in accounts receivable was primarily due to the settlement with Apple and its contract manufacturers and a decrease in integrated circuit shipments, partially offset by the adoption of the new revenue recognition guidance in fiscal 2019. The decrease in inventories was primarily due to a decrease in the overall quantity of units on hand to align with near-term demand.

[0001728949-19-000072:mdna:189]
Debt. In May 2017, we issued an aggregate principal amount of $11.0 billion in nine tranches of unsecured floating- and fixed-rate notes, of which $7.0 billion remains outstanding with maturity dates in 2023 through 2047. Effective interest rates were between 2.70% and 4.47% at September 29, 2019. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001728949-19-000072:mdna:190]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, of which $8.5 billion remains outstanding with maturity dates in 2020 through 2045. Effective interest rates were between 2.64% and 4.73% at September 29, 2019. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001728949-19-000072:mdna:191]
Our Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in the aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. At September 29, 2019, no amounts were outstanding under the revolving credit facility.

[0001728949-19-000072:mdna:192]
We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At September 29, 2019, we had $499 million of commercial paper outstanding with a weighted-average net interest rate of 2.17% and weighted-average remaining days to maturity of 41 days.

[0001728949-19-000072:mdna:193]
We may issue additional debt in the future. The amount and timing of such additional borrowings will be subject to a number of factors, including acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001728949-19-000072:mdna:194]
Additional information regarding our outstanding debt at September 29, 2019 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 6. Debt.”

[0001728949-19-000072:mdna:195]
Income Taxes. The Tax Legislation, which was signed into law during the first quarter of fiscal 2018, resulted in a $5.2 billion charge recognized in fiscal 2018 related to the Toll Charge. After application of certain tax credits (including excess tax credits generated in fiscal 2019), the total cash payment is expected to be $2.5 billion. The first payment was made in

[0001728949-19-000072:mdna:196]
52

[0001728949-19-000072:mdna:197]
January 2019. At September 29, 2019, we estimated future cash payments of $2.3 billion, payable in installments over the next seven years. At September 29, 2019, $209 million was included in other current liabilities, reflecting our next installment due in January 2020.

[0001728949-19-000072:mdna:198]
Additional information regarding our income taxes is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 3. Income Taxes.”

[0001728949-19-000072:mdna:199]
Capital Return Program. The following table summarizes stock repurchases, before commissions, and dividends paid during fiscal 2019, 2018 and 2017 (in millions, except per-share amounts):

[0001728949-19-000072:mdna:200]
|  |  | Stock Repurchase Program |  | Dividends |  | Total |
|  |  | Shares |  | Average Price Paid Per Share (1) |  | Amount |  | Per Share |  | Amount |  | Amount |
| 2019 |  | 95.8 |  |  | $ | 66.18 |  |  | $ | 1,793 |  |  | $ | 2.48 |  |  | $ | 2,968 |  |  | $ | 4,761 |  |
| 2018 |  | 278.8 |  |  | 65.41 |  |  | 22,569 |  |  | 2.38 |  |  | 3,466 |  |  | 26,035 |  |
| 2017 |  | 22.8 |  |  | 58.87 |  |  | 1,342 |  |  | 2.20 |  |  | 3,252 |  |  | 4,594 |  |

[0001728949-19-000072:mdna:201]
| (1) | Average Price Paid Per Share in fiscal 2018 and 2019 excludes the impact of the three accelerated share repurchase agreements (the ASR Agreements) executed in September 2018 and completed in September 2019. The average price per share under the ASR Agreements was $64.76. |

[0001728949-19-000072:mdna:202]
In fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30.0 billion of our common stock. In fiscal 2018, we entered into the ASR Agreements to repurchase an aggregate of $16.0 billion of our common stock, with 178.4 million shares initially delivered to us under the ASR Agreements and retired. The ASR Agreements were completed during the fourth quarter of fiscal 2019, and an additional 68.7 million shares were delivered to us, comprising the final delivery of shares under the ASR Agreements. In total, 247.1 million shares were delivered to us under the ASR Agreements. In fiscal 2019, we repurchased and retired an additional 27.1 million shares of our common stock for $1.8 billion, before commissions. At September 29, 2019, $7.1 billion remained authorized for repurchase under the stock repurchase program. Since September 29, 2019, we repurchased and retired 3.9 million shares of common stock for $300 million.

[0001728949-19-000072:mdna:203]
Our stock repurchase program has significantly reduced and we expect that it will continue to reduce the amount of cash that we have available to fund our operations including research and development, working capital, capital expenditures, acquisitions, investments, dividends and other corporate purposes; and increases our exposure to adverse economic, market, industry and competitive conditions and developments, and other changes in our business and our industry. This stock repurchase program has no expiration date. However, we periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders and may accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-19-000072:mdna:204]
On October 15, 2019, we announced a cash dividend of $0.62 per share on our common stock, payable on December 19, 2019 to stockholders of record as of the close of business on December 5, 2019. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-19-000072:mdna:205]
Additional Capital Requirements. We believe our cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements, in addition to the above matters, also include the items described below:

[0001728949-19-000072:mdna:206]
| • | Our purchase obligations at September 29, 2019, some of which relate to research and development activities and capital expenditures, totaled $2.9 billion and $286 million for fiscal 2020 and 2021, respectively, and $178 million thereafter. |

[0001728949-19-000072:mdna:207]
| • | Our research and development expenditures were $5.4 billion in fiscal 2019 and $5.6 billion in fiscal 2018, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications. |

[0001728949-19-000072:mdna:208]
| • | Cash outflows for capital expenditures were $887 million in fiscal 2019 and $784 million in fiscal 2018. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. |

[0001728949-19-000072:mdna:209]
| • | At September 29, 2019, $1.4 billion was accrued related to two fines imposed by the EC (based on the exchange rate at September 29, 2019, including related foreign currency gains and accrued interest). We have provided financial guarantees in lieu of cash payment to satisfy the obligations while we appeal the EU’s decisions. |

[0001728949-19-000072:mdna:210]
| • | We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly, to open new opportunities for our technologies, obtain development resources, grow our patent portfolio or pursue new businesses. |

[0001728949-19-000072:mdna:211]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us, including the lawsuit filed against us by the FTC, in which a ruling was issued in favor of the FTC in May 2019, and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees, have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies” and “Part I, Item 1A. Risk Factors” in this Annual Report.

[0001728949-19-000072:mdna:212]
Contractual Obligations/Off-Balance Sheet Arrangements

[0001728949-19-000072:mdna:213]
We have no significant contractual obligations not fully recorded on our consolidated balance sheets or fully disclosed in the notes to our consolidated financial statements. We have no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001728949-19-000072:mdna:214]
The following table summarizes the payments due by fiscal period for our outstanding contractual obligations at September 29, 2019 (in millions):

[0001728949-19-000072:mdna:215]
|  | Total |  | 2020 |  | 2021-2022 |  | 2023-2024 |  | Beyond2024 |  | NoExpirationDate |
| Purchase obligations (1) | $ | 3,390 |  |  | $ | 2,926 |  |  | $ | 394 |  |  | $ | 69 |  |  | $ | 1 |  |  | $ | — |  |
| Operating lease obligations | 385 |  |  | 138 |  |  | 163 |  |  | 49 |  |  | 35 |  |  | — |  |
| Capital lease obligations (2) | 28 |  |  | 17 |  |  | 11 |  |  | — |  |  | — |  |  | — |  |
| Equity funding and financing commitments (3) | 154 |  |  | 5 |  |  | 1 |  |  | 1 |  |  | — |  |  | 147 |  |
| Long-term debt (4) | 15,500 |  |  | 2,000 |  |  | 2,000 |  |  | 3,500 |  |  | 8,000 |  |  | — |  |
| Other long-term liabilities (5)(6) | 2,974 |  |  | 250 |  |  | 453 |  |  | 574 |  |  | 1,136 |  |  | 561 |  |
| Total contractual obligations | $ | 22,431 |  |  | $ | 5,336 |  |  | $ | 3,022 |  |  | $ | 4,193 |  |  | $ | 9,172 |  |  | $ | 708 |  |

[0001728949-19-000072:mdna:216]
| (1) | Purchase obligations primarily relate to integrated circuit product inventory obligations, which represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization. |

[0001728949-19-000072:mdna:217]
| (2) | Amounts represent future minimum lease payments including interest payments. Capital lease obligations were included in other current liabilities and other noncurrent liabilities in the consolidated balance sheet at September 29, 2019. |

[0001728949-19-000072:mdna:218]
| (3) | Certain of these commitments do not have fixed funding dates and are subject to certain conditions and have, therefore, been presented as having no expiration date. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all. |

[0001728949-19-000072:mdna:219]
| (4) | The amounts noted herein represent contractual payments of principal only. |

[0001728949-19-000072:mdna:220]
| (5) | Certain long-term liabilities reflected on our balance sheet, such as unearned revenues, are not presented in this table because they do not require cash settlement in the future. Other long-term liabilities as presented in this table include the related current portions, as applicable. |

[0001728949-19-000072:mdna:221]
| (6) | Our consolidated balance sheet at September 29, 2019 included $1.6 billion in other noncurrent liabilities for uncertain tax positions, which primarily relate to a reduction of U.S. foreign tax credits that will occur if we are successful in our claim for a refund of Korean withholding tax (for which a $1.4 billion receivable was recorded at September 29, 2019). The majority of this liability will be payable when we receive the Korean tax refund, with the remainder payable over periods up to and including the last payment of the Toll Charge in January 2026. The future payments related to uncertain tax positions recorded as other noncurrent liabilities have not been presented in the table above due to the uncertainty of the amounts and timing of cash settlement with the taxing authorities. |

[0001728949-19-000072:mdna:222]
54

[0001728949-19-000072:mdna:223]
Additional information regarding our financial commitments at September 29, 2019 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 3. Income Taxes,” “Note 6. Debt” and “Note 7. Commitments and Contingencies.”

[0001728949-19-000072:mdna:224]
Critical Accounting Estimates

[0001728949-19-000072:mdna:225]
The preparation of our consolidated financial statements in accordance with accounting principles generally accepted in the United States requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and disclosure of contingent assets and liabilities. We base our estimates on historical and anticipated results and trends and on various other assumptions that we believe are reasonable under the circumstances, including assumptions as to future events. By their nature, estimates are subject to an inherent degree of uncertainty. Although we believe that our estimates and the assumptions supporting our assessments are reasonable, actual results that differ from our estimates could be material to our consolidated financial statements. A summary of our significant accounting policies is included in this Annual Report in “Notes to Consolidated Financial Statements, Note 1. Significant Accounting Policies.” We consider the following accounting estimates to be critical in the preparation of our consolidated financial statements.

[0001728949-19-000072:mdna:226]
Revenue Recognition. We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets, laptops and smartwatches, and provide for a maximum royalty amount payable per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such royalties. Our estimates of sales-based royalties are based largely on an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property. We estimate sales-based royalties taking into consideration the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products, and consider all information (historical, current and forecasted, which may include certain estimates from licensees) that is reasonably available to us. We also consider in our estimates of sales-based royalties any changes in pricing we plan or expect to make. Our licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter, which is generally the following quarter. As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

[0001728949-19-000072:mdna:227]
From time to time, regulatory authorities investigate our business practices, particularly with respect to our licensing business, and institute proceedings against us. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. Additionally, from time to time, companies initiate various strategies in an attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property, which may include disputing, underreporting, underpaying, not reporting and/or not paying royalties owed to us under their license agreements with us, or reporting to us in a manner that is not in compliance with their contractual obligations. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in the revenue recognition guidance, and to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur, both of which may require significant judgment. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us.

[0001728949-19-000072:mdna:228]
In May 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief (see “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies”). In August 2019, the U.S. Court of Appeals for the Ninth Circuit granted in its entirety Qualcomm’s request for a partial stay of the injunction. While we believe that our business practices do not violate either antitrust law or our FRAND (fair, reasonable and non-discriminatory) licensing commitments, significant evaluation and judgment were required in determining the impact of such ruling on the amount of licensing revenues estimated and

[0001728949-19-000072:mdna:229]
55

[0001728949-19-000072:mdna:230]
recognized in fiscal 2019. This included, among other items: (i) evaluating whether our license agreements remain valid and enforceable, (ii) evaluating licensees’ conduct and whether they remain committed to perform their respective obligations and (iii) determining the expected impact, if any, to revenues of any license agreements that may be renegotiated and/or are newly entered into. Based on this evaluation, the impact of the ruling was not material to QTL licensing revenues in fiscal 2019 based on facts and factors currently known by us. As new information becomes available, we may be required to make adjustments to revenues in subsequent periods to reflect changes in estimates and/or this matter could have a material adverse effect on our ability to recognize future licensing revenues.

[0001728949-19-000072:mdna:231]
Impairment of Other Investments. We hold investments in non-marketable equity instruments in privately held companies, including those accounted for under the equity method. Non-marketable equity instruments do not have readily determinable fair values and are accounted for under the equity method or based on initial cost minus impairment, if any, plus or minus adjustments resulting from observable price changes in orderly transactions for identical or similar securities. Many of these investments are in early-stage companies, which are inherently risky because the markets for the technologies or products of these companies are uncertain and may never develop. We monitor our investments for events or circumstances that could indicate the investments are impaired, such as a deterioration in the investee’s financial condition and business forecasts and lower valuations in recently completed or anticipated financings, and we record impairment losses in earnings when we believe an investment has experienced a decline in value (such decline in value must be considered other-than-temporary for equity method investments).

[0001728949-19-000072:mdna:232]
Valuation of Inventories. Inventories are valued at the lower of cost and net realizable value using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers, among other things. This valuation also requires us to make judgments and assumptions based on information currently available about market conditions, including competition, product pricing, product life cycle and development plans. As we move to smaller geometry process technologies, the manufacturing lead-time increases, resulting in an increased reliance on our own forecasts of customer demand, rather than our customers’ forecasts. If we overestimate demand for our products, the amount of our loss will be impacted by our contractual ability to reduce inventory purchases from our suppliers. Our assumptions of future product demand are inherently uncertain, and changes in our estimates and assumptions may cause us to realize material write-downs in the future.

[0001728949-19-000072:mdna:233]
Valuation of Goodwill and Other Indefinite-Lived and Long-Lived Assets. Our business combinations typically result in the recording of goodwill, other intangible assets and/or property, plant and equipment, and the recorded values of those assets may become impaired in the future. We also acquire intangible assets and property, plant and equipment in other types of transactions. The determination of the recorded value of intangible assets acquired in a business combination requires management to make estimates and assumptions that affect our consolidated financial statements. For intangible assets acquired in a non-monetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value. An estimate of fair value can be affected by many assumptions that require significant judgment. For example, the income approach generally requires us to use assumptions to estimate future cash flows including those related to total addressable market, pricing and share forecasts, competition, technology obsolescence, future tax rates and discount rates. Our estimate of the fair value of certain assets may differ materially from that determined by others who use different assumptions or utilize different business models and from the future cash flows actually realized.

[0001728949-19-000072:mdna:234]
Goodwill and other indefinite-lived intangible assets are tested annually for impairment and in interim periods if events or changes in circumstances indicate that the assets may be impaired. Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Our judgments regarding the existence of impairment indicators and future cash flows related to goodwill and other indefinite-lived intangible assets and long-lived assets may be based on operational performance of our businesses, market conditions, expected selling price and/or other factors. Although there are inherent uncertainties in this assessment process, the estimates and assumptions we use, including estimates of future cash flows and discount rates, are consistent with our internal planning, when appropriate. If these estimates or their related assumptions change in the future, we may be required to record an impairment charge on a portion or all of our goodwill, other indefinite-lived intangible assets and/or long-lived assets. Furthermore, we cannot predict the occurrence of future impairment-triggering events nor the impact such events might have on our reported asset values. Future events could cause us to conclude that impairment indicators exist, and that goodwill or other long-lived assets associated with our acquired businesses are impaired. Any resulting impairment loss could have an adverse impact on our

[0001728949-19-000072:mdna:235]
56

[0001728949-19-000072:mdna:236]
financial condition and results of operations. During fiscal 2019, 2018 and 2017, we recorded $203 million, $273 million and $76 million, respectively, in impairment charges for goodwill, other indefinite-lived intangible assets and long-lived assets. The estimated fair values of our QCT and QTL reporting units were substantially in excess of their respective carrying values at September 29, 2019.

[0001728949-19-000072:mdna:237]
Legal and Regulatory Proceedings. We are currently involved in certain legal and regulatory proceedings, and we intend to continue to vigorously defend ourselves. Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Investigations by antitrust and trade regulation agencies are not conducted in a consistent manner across jurisdictions. Further, each country and agency has different sets of laws, rules and regulations, both substantive and procedural, as well as different legal principles, theories and potential remedies, and some agencies may seek to use the investigation to advance domestic policy goals. Depending on the jurisdiction, these investigations can involve non-transparent procedures under which we may not receive access to evidence relied upon by the enforcement agency or that may be exculpatory and may not be informed of the specific legal theories or evidence considered or relied upon by the agency. Unlike in civil litigation in the United States, in foreign proceedings, we may not be entitled to discovery or depositions, allowed to cross-examine witnesses or confront our accusers. As a result, we may not be aware of, and may not be entitled to know, all allegations against us, or the information or documents provided to, or discovered or prepared by, the agency. Accordingly, we may have little or no idea what an agency’s intent is with respect to liability, penalties or the timing of a decision. In many cases the agencies are given significant discretion, and any available precedent may have limited, if any, predictive value in their jurisdictions, much less in other jurisdictions. Accordingly, we cannot predict the outcome of these matters. However, the unfavorable resolution of one or more of these proceedings could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. A broad range of remedies with respect to our business practices that are deemed to violate applicable laws are potentially available. These remedies may include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or to modify our business practices.

[0001728949-19-000072:mdna:238]
If there is at least a reasonable possibility that a material loss may have been incurred associated with pending legal and regulatory proceedings, we disclose such fact, and if reasonably estimable, we provide an estimate of the possible loss or range of possible loss. We record our best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, we record the minimum estimated liability. As additional information becomes available, we assess the potential liability related to pending legal and regulatory proceedings and revise our estimates and update our disclosures accordingly. Significant judgment is required in both the determination of probability and the determination as to whether a loss is reasonably estimable. Revisions in our estimates of the potential liability could materially impact our results of operations.

[0001728949-19-000072:mdna:239]
Income Taxes. We are subject to income taxes in the United States and numerous foreign jurisdictions, and the assessment of our income tax positions involves dealing with uncertainties in the application of complex tax laws and regulations in various taxing jurisdictions. In addition, the application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws and regulations themselves are subject to change as a result of changes in fiscal policy, changes in legislation, the evolution of regulations and court rulings. Significant judgments and estimates are required in determining our provision for income taxes, including those related to special deductions such as FDII (foreign-derived intangible income), tax incentives, intercompany research and development cost-sharing arrangements, transfer pricing, tax credits and the realizability of deferred tax assets. While we believe we have appropriate support for the positions we have taken or that we plan to take on our tax returns, we regularly assess the potential outcomes of examinations by taxing authorities in determining the adequacy of our provision for income taxes. Therefore, the actual liability for U.S. or foreign taxes may be materially different from our estimates, which could result in the need to record additional tax liabilities or potentially reverse previously recorded tax liabilities. We are participating in the Internal Revenue Service (IRS) Compliance Assurance Process program whereby we endeavor to agree with the IRS on the treatment of all issues prior to filing our federal return. A benefit of participation in this program is that post-filing adjustments by the IRS are less likely to occur.

[0001728949-19-000072:mdna:240]
Recent Accounting Pronouncements

[0001728949-19-000072:mdna:241]
Information regarding recent accounting pronouncements and the impact of those pronouncements, if any, on our consolidated financial statements is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 1. Significant Accounting Policies.”
