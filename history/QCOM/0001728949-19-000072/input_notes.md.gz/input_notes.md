# QCOM notes — 0001728949-19-000072


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-19-000072:notes:1]
Note 1. Significant Accounting Policies

[0001728949-19-000072:notes:2]
We develop, design, manufacture, have manufactured on our behalf and market digital communications products, which principally consist of integrated circuits and system software based on CDMA (Code Division Multiple Access), OFDMA (Orthogonal Frequency Division Multiple Access) and other technologies for use in mobile devices, wireless networks, broadband gateway equipment, consumer electronic devices, devices used in IoT and automotive telematics and infotainment systems. We also grant licenses to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, and receive ongoing royalties based on sales by licensees of wireless products incorporating our patented technologies and may also receive fixed license fees (payable in one or more installments).

[0001728949-19-000072:notes:3]
Principles of Consolidation. The consolidated financial statements include the assets, liabilities and operating results of Qualcomm and its subsidiaries, including our subsidiary RF360 Holdings Singapore Pte. Ltd (RF360 Holdings) since its formation in fiscal 2017 (Note 9). During the third quarter of fiscal 2018, we eliminated the one-month reporting lag previously used to consolidate RF360 Holdings to provide contemporaneous reporting within our consolidated financial statements. The effect of this change was not material to the consolidated financial statements, and therefore, the impact of eliminating the one-month reporting lag was included in our results of operations for fiscal 2018. Intercompany transactions and balances have been eliminated.

[0001728949-19-000072:notes:4]
Financial Statement Preparation. The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in our consolidated financial statements and the accompanying notes. Examples of our significant accounting estimates that may involve a higher degree of judgment and complexity than others include: the estimation of sales-based royalty revenues; the impairment of other investments; the valuation of inventories; the valuation of the recoverability of goodwill and other indefinite-lived and long-lived assets; the recognition, measurement and disclosure of loss contingencies related to legal and regulatory proceedings; and the calculation of our income tax provision, including the recognition and measurement of uncertain tax positions. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

[0001728949-19-000072:notes:5]
Revision of Prior Period Financial Statements. In connection with the preparation of our consolidated financial statements, we identified an immaterial error related to the recognition of certain royalty revenues of our QTL (Qualcomm Technology Licensing) segment in the quarterly and annual periods in fiscal 2018 and third and fourth quarters and annual period in fiscal 2017. In accordance with SAB No. 99, “Materiality,” and SAB No. 108, “Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements,” we evaluated the error and determined that the related impact was not material to our financial statements for any prior annual or interim period, but that correcting the cumulative impact of the error would be significant to our results of operations for the three months ended December 30, 2018. Accordingly, we have revised previously reported financial information for such immaterial error, as previously disclosed in our Quarterly Report on Form 10-Q for the first, second and third quarters of fiscal 2019. A summary of revisions to certain previously reported financial information presented herein for comparative purposes is included in Note 12.

[0001728949-19-000072:notes:6]
Fiscal Year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. The fiscal year ended September 29, 2019 and September 24, 2017 each included 52 weeks. The fiscal years ended September 30, 2018 included 53 weeks.

[0001728949-19-000072:notes:7]
Recently Adopted Accounting Pronouncements.

[0001728949-19-000072:notes:8]
Revenue Recognition: In May 2014, the Financial Accounting Standards Board (FASB) issued new accounting guidance related to revenue recognition (ASC 606), which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition accounting guidance and requires increased disclosures. The new accounting guidance defines a five-step approach that requires a company to recognize revenue as control of goods or services transfers to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. We adopted ASC 606 in the first quarter of fiscal 2019 using the modified retrospective transition method only to those contracts that were not completed as of October 1, 2018. We recognized the cumulative effect of initially applying the new revenue accounting guidance as an adjustment to opening retained earnings. Prior period results have not been restated and continue to be reported in accordance with the accounting guidance in effect for those periods (ASC 605). We have implemented new accounting policies, systems, processes and internal controls necessary to support the requirements of ASC 606.

[0001728949-19-000072:notes:9]
Adoption of this new accounting guidance most significantly impacts the timing of sales-based royalty revenues, which are the vast majority of our QTL segment’s revenues. Prior to adoption, we recognized sales-based royalties as revenues in the period in which such royalties were reported by licensees, which was after the conclusion of the quarter in which the licensees’ sales occurred and when all other revenue recognition criteria had been met. Under the new accounting guidance, we estimate and recognize sales-based royalties in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such amounts, resulting in an acceleration of revenue recognition compared to the historical method under ASC 605. Since we do not invoice for sales-based royalties estimated and recognized in any given quarter until after the conclusion of that quarter (which is generally the following quarter when such royalties are reported by licensees), revenues recognized from sales-based royalties results in unbilled receivables (included in accounts receivable, net on the consolidated balance sheet). The adoption of ASC 606 did not otherwise have a material impact.

[0001728949-19-000072:notes:10]
The new accounting guidance also impacts the timing of recognizing certain customer incentives, which are recorded as a reduction to revenues in the period that the related revenues are earned. Prior to adoption, we accounted for certain customer incentive arrangements, including volume-related and other pricing rebates or cost reimbursements for marketing and other activities involving certain of our products and technologies, in part based on the maximum potential liability. Under the new accounting guidance, we estimate the amount of all customer incentives.

[0001728949-19-000072:notes:11]
The following table summarizes the cumulative effects of adopting the new revenue accounting guidance (substantially all of which related to the impact to QTL’s sales-based royalties) on our consolidated balance sheet at October 1, 2018 (in millions):

[0001728949-19-000072:notes:12]
|  | Balance at September 30, 2018 |  | Adjustment |  | Opening Balance at October 1, 2018 |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 2,904 |  |  | $ | 957 |  |  | $ | 3,861 |  |
| Other current assets | 699 |  |  | 1 |  |  | 700 |  |
| Deferred tax assets | 936 |  |  | (98 | ) |  | 838 |  |
| Other assets | 1,970 |  |  | 1 |  |  | 1,971 |  |
| Liabilities |  |  |  |  |  |
| Unearned revenues, current | $ | 500 |  |  | $ | 6 |  |  | $ | 506 |  |
| Other current liabilities | 6,978 |  |  | 125 |  |  | 7,103 |  |
| Unearned revenues | 1,620 |  |  | (110 | ) |  | 1,510 |  |
| Stockholders’ equity |  |  |  |  |  |
| Retained earnings | $ | 542 |  |  | $ | 840 |  |  | $ | 1,382 |  |

[0001728949-19-000072:notes:13]
The following tables summarize the impacts of adopting the new revenue accounting guidance on our consolidated balance sheet and statement of operations (in millions):

[0001728949-19-000072:notes:14]
|  | Balance at September 29, 2019 |
| Balance Sheet | As ReportedASC 606 |  | Adjustment |  | ASC 605 |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 2,471 |  |  | $ | (1,171 | ) |  | $ | 1,300 |  |
| Other current assets | 634 |  |  | (35 | ) |  | 599 |  |
| Deferred tax assets | 1,196 |  |  | 140 |  |  | 1,336 |  |
| Other assets | 3,461 |  |  | (62 | ) |  | 3,399 |  |
| Liabilities |  |  |  |  |  |
| Unearned revenues, current | $ | 565 |  |  | $ | 55 |  |  | $ | 620 |  |
| Other current liabilities | 3,458 |  |  | (169 | ) |  | 3,289 |  |
| Unearned revenues | 1,160 |  |  | 182 |  |  | 1,342 |  |
| Other liabilities | 2,428 |  |  | (58 | ) |  | 2,370 |  |
| Stockholders’ equity |  |  |  |  |  |
| Retained earnings | $ | 4,466 |  |  | $ | (1,138 | ) |  | $ | 3,328 |  |

[0001728949-19-000072:notes:15]
|  | Year Ended September 29, 2019 |
| Statement of Operations | As Reported ASC 606 |  | Adjustment |  | ASC 605 |
| Revenues |  |  |  |  |  |
| Equipment and services | $ | 14,611 |  |  | $ | (106 | ) |  | $ | 14,505 |  |
| Licensing | 9,662 |  |  | (270 | ) |  | 9,392 |  |
| Income tax expense | (3,095 | ) |  | 78 |  |  | (3,017 | ) |
| Net income | 4,386 |  |  | (298 | ) |  | 4,088 |  |

[0001728949-19-000072:notes:16]
Adoption of the new accounting guidance had no impact to net cash provided (used) by operating, financing or investing activities on our consolidated statement of cash flows for fiscal 2019.

[0001728949-19-000072:notes:17]
Financial Assets: In January 2016, the FASB issued new accounting guidance on classifying and measuring financial instruments, which requires that all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings in the statement of operations. Additionally, it changes the disclosure requirements for financial instruments. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the modified retrospective transition method for investments in marketable securities, which have readily determinable fair values, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings. Upon adoption, we reclassified $50 million of unrealized gains, net of the associated tax effects, related to our investments in marketable securities from accumulated other comprehensive income to opening retained earnings. We have applied the prospective transition method for investments in non-marketable securities, which are investments in privately held companies that do not have readily determinable fair values and will recognize, through earnings, any unrealized gains that have accumulated in the period in which there is an observable transaction, if any.

[0001728949-19-000072:notes:18]
Prior to the adoption of the new accounting guidance in the first quarter of fiscal 2019, investments in marketable equity securities were generally classified as available-for-sale equity investments, with net unrealized gains or losses recorded as a component of accumulated other comprehensive income, net of income taxes. Beginning in fiscal 2019, all gains and losses on investments in marketable equity securities, realized and unrealized, are recognized in investment and other income, net.

[0001728949-19-000072:notes:19]
Prior to the adoption of the new accounting guidance in the first quarter of fiscal 2019, investments in non-marketable equity securities were recorded at cost less impairment, if any, with any losses resulting from an impairment recognized in investment and other income, net. Beginning in fiscal 2019, investments in non-marketable equity securities are recorded at

[0001728949-19-000072:notes:20]
cost, less impairments, adjusted for observable price changes in orderly transactions for identical or similar securities. All gains and losses on investments in non-marketable equity securities, realized and unrealized, are recognized in investment and other income, net.

[0001728949-19-000072:notes:21]
In addition, prior to adoption, we recorded impairment losses in earnings on investments in non-marketable equity securities when an impairment was considered other than temporary. Beginning in fiscal 2019, we record impairment losses in earnings when we believe an investment has experienced a decline in value.

[0001728949-19-000072:notes:22]
Hedge Instruments: In August 2017, the FASB issued new accounting guidance that expands and refines hedge accounting for both financial and non-financial risks, aligns the recognition and presentation of the effects of hedging instruments and hedged items in the financial statements, and includes targeted improvements related to the assessment of hedge effectiveness. The new accounting guidance also modifies disclosure requirements for hedging activities. We adopted the new accounting guidance in the first quarter of 2019 using the modified retrospective transition method and recorded a negligible adjustment to opening retained earnings. The new accounting guidance did not have a material impact on our consolidated financial statements.

[0001728949-19-000072:notes:23]
Statement of Cash Flows: In August 2016, the FASB issued new accounting guidance related to the classification of certain cash receipts and cash payments in the statement of cash flows. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the retrospective transition method for each period presented, which did not have a material impact on our consolidated statements of cash flows.

[0001728949-19-000072:notes:24]
In November 2016, the FASB issued new accounting guidance that requires companies to include restricted cash and cash equivalents as a component in total cash and cash equivalents on the statement of cash flows. As a result, the consolidated statement of cash flows no longer reflects transfers between cash and cash equivalents and restricted cash and cash equivalents. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the retrospective transition method, which resulted in certain amounts in fiscal 2017 and 2018 being adjusted to conform to the new accounting guidance. In fiscal 2017, $2.0 billion was designated as collateral for outstanding letters of credit in connection with the then proposed acquisition of NXP Semiconductors N.V. (NXP). During fiscal 2017, $1.3 billion of the amount held as collateral was invested in time deposits that were not considered cash equivalents, which subsequently matured. This resulted in an adjustment to investing activities for fiscal 2017 to reflect the $1.3 billion purchase and subsequent maturity of time deposits and a $2.0 billion reduction in investing activities to reflect removal of the activity of restricted cash and cash equivalents. In fiscal 2018, such restricted cash and cash equivalents were released from restriction, which resulted in a decrease in investing activities by such amount.

[0001728949-19-000072:notes:25]
Income Taxes: In October 2016, the FASB issued new accounting guidance that changes the accounting for the income tax effects of intra-entity transfers of assets other than inventory. Under the new accounting guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings of $2.6 billion, primarily as the result of establishing a deferred tax asset on the basis difference of certain intellectual property distributed from one of our foreign subsidiaries to a subsidiary in the United States in fiscal 2018. During fiscal 2019, the United States Treasury Department issued new temporary regulations that resulted in a change to the deductibility of dividend income received by a U.S. stockholder from a foreign corporation. As a result of this change, pursuant to an agreement with the Internal Revenue Service, we relinquished the federal tax basis step-up in such distributed intellectual property. Therefore, the related deferred tax asset was derecognized, resulting in a $2.5 billion charge to income tax expense in fiscal 2019 (Note 3). The ongoing impact of this accounting guidance will be dependent on the facts and circumstances of any transactions within its scope.

[0001728949-19-000072:notes:26]
Cash Equivalents. We consider all highly liquid investments with original maturities of 90 days or less to be cash equivalents. Cash equivalents are comprised of money market funds, certificates of deposit, commercial paper, corporate bonds and notes, certain bank time and demand deposits and government agencies’ securities. The carrying amounts approximate fair value due to the short maturities of these instruments.

[0001728949-19-000072:notes:27]
Marketable Securities. Marketable securities include marketable equity securities and available-for-sale debt securities for which classification is determined at the time of purchase and reevaluated at each balance sheet date. We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value with all realized and unrealized gains and losses on investments in marketable equity securities and realized gains and losses on available-for-sale debt securities recognized in investment and

[0001728949-19-000072:notes:28]
other income, net. Net unrealized gains or losses on available-for-sale debt securities are recorded as a component of accumulated other comprehensive income, net of income taxes. The realized gains and losses on marketable securities are determined using the specific identification method.

[0001728949-19-000072:notes:29]
At each balance sheet date, we assess available-for-sale debt securities in an unrealized loss position to determine whether the unrealized loss is other than temporary. We consider factors including: the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; how long the market value of the security has been less than its cost basis; the security’s relative performance versus its peers, sector or asset class; the market and economy in general; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.

[0001728949-19-000072:notes:30]
If a debt security’s market value is below amortized cost and we either intend to sell the security or it is more likely than not that we will be required to sell the security before its anticipated recovery, we record an other-than-temporary impairment charge to investment and other income, net for the entire amount of the impairment. For the remaining debt securities, if an other-than-temporary impairment exists, we separate the other-than-temporary impairment into the portion of the loss related to credit factors, or the credit loss portion, which is recorded as a charge to investment and other income, net, and the portion of the loss that is not related to credit factors, or the noncredit loss portion, which is recorded as a component of other accumulated comprehensive income, net of income taxes.

[0001728949-19-000072:notes:31]
Equity Method and Non-marketable Equity Investments. Equity investments for which we have significant influence, but not control over the investee and are not the primary beneficiary of the investee’s activities, are accounted for under the equity method. Our share of gains and losses in equity method investments are recorded in investment and other income, net. Non-marketable equity investments (for which we do not have significant influence or control) are investments without readily determinable fair values that are recorded based on initial cost minus impairment, if any, plus or minus adjustments resulting from observable price changes in orderly transactions for identical or similar securities. All gains and losses on investments in non-marketable equity securities, realized and unrealized, are recognized in investment and other income, net. We monitor equity method investments and non-marketable equity securities for events or circumstances that could indicate the investments are impaired, such as a deterioration in the investee’s financial condition and business forecasts and lower valuations in recently completed or anticipated financings, and recognize a charge to investment and other income, net for the difference between the estimated fair value and the carrying value. For equity method investments, we record impairment losses in earnings only when impairments are considered other-than-temporary.

[0001728949-19-000072:notes:32]
Derivatives. Our primary objectives for holding derivative instruments are to manage interest rate risk on our long-term debt and to manage foreign exchange risk for certain foreign currency revenues, operating expenses, receivables and payables. Derivative instruments are recorded at fair value and included in other current or noncurrent assets or other current or noncurrent liabilities based on their maturity dates. Counterparties to our derivative instruments are all major banking institutions.

[0001728949-19-000072:notes:33]
Interest Rate Swaps: We manage our exposure to certain interest rate risks related to our long-term debt through the use of interest rate swaps. Such swaps allow us to effectively convert fixed-rate payments into floating-rate payments based on LIBOR. These transactions are designated as fair value hedges, and the gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate debt attributable to the hedged risks, are recognized in earnings as interest expense in the current period. The interest settlement payments associated with the interest rate swap agreements are classified as cash flows from operating activities in the consolidated statements of cash flows.

[0001728949-19-000072:notes:34]
At September 29, 2019 and September 30, 2018, the aggregate fair value of our interest rate swaps related to our long-term debt issued in May 2015 was negligible and $50 million, respectively. The fair values of the swaps were recorded in other current liabilities and other noncurrent assets at September 29, 2019 and in other noncurrent liabilities at September 30, 2018. At September 29, 2019 and September 30, 2018, the swaps had an aggregate notional amount of $1.8 billion, which effectively converted approximately 43% and 50% of the fixed-rate debt due in 2020 and 2022, respectively, into floating-rate debt, with maturities matching our fixed-rate debt due in 2020 and 2022.

[0001728949-19-000072:notes:35]
Foreign Currency Hedges: We manage our exposure to foreign exchange market risks, when deemed appropriate, through the use of derivative instruments, including foreign currency forward and option contracts with financial counterparties, that may or may not be designated as hedging instruments. These derivative instruments have maturity dates of less than twelve months. Gains and losses arising from such contracts that are designated as cash flow hedging instruments

[0001728949-19-000072:notes:36]
are recorded as a component of accumulated other comprehensive income as gains and losses on derivative instruments, net of income taxes. The hedging gains and losses in accumulated other comprehensive income are subsequently reclassified to revenues or costs and expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect our earnings. The cash flows associated with derivative instruments designated as cash flow hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The fair values of our foreign currency forward and option contracts used to hedge foreign currency risk designated as cash flow hedges recorded in total assets were negligible at September 29, 2019. The fair values of our foreign currency forward and option contracts used to hedge foreign currency risk designated as cash flow hedges recorded in total assets and in total liabilities were negligible and $19 million, respectively, at September 30, 2018.

[0001728949-19-000072:notes:37]
For foreign currency forward and option contracts not designated as hedging instruments, the changes in fair value are recorded in investment and other income, net in the period of change. The cash flows associated with derivative instruments not designated as hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The fair values of our foreign currency forward and option contracts not designated as hedging instruments were negligible at September 29, 2019 and September 30, 2018.

[0001728949-19-000072:notes:38]
Gross Notional Amounts: The gross notional amounts of our interest rate and foreign currency derivatives by instrument type were as follows (in millions):

[0001728949-19-000072:notes:39]
|  | September 29, 2019 |  | September 30, 2018 |
| Forwards | $ | 878 |  |  | $ | 682 |  |
| Options | 176 |  |  | 1,375 |  |
| Swaps | 1,750 |  |  | 1,750 |  |
|  | $ | 2,804 |  |  | $ | 3,807 |  |

[0001728949-19-000072:notes:40]
The gross notional amounts of our derivatives by currency were as follows (in millions):

[0001728949-19-000072:notes:41]
|  | September 29, 2019 |  | September 30, 2018 |
| Chinese renminbi | $ | 463 |  |  | $ | 650 |  |
| Euro | — |  |  | 938 |  |
| Indian rupee | 440 |  |  | 336 |  |
| Japanese yen | 12 |  |  | 17 |  |
| United States dollar | 1,889 |  |  | 1,866 |  |
|  | $ | 2,804 |  |  | $ | 3,807 |  |

[0001728949-19-000072:notes:42]
Other Hedging Activities. We have designated $1.4 billion of foreign currency-denominated liabilities related to the fines imposed by the European Commission (Note 7) as hedges of our net investment in certain foreign subsidiaries as of September 29, 2019. Gains and losses arising from the portion of these balances that are designated as net investment hedges are recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment.

[0001728949-19-000072:notes:43]
Fair Value Measurements. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants as of the measurement date. Applicable accounting guidance provides an established hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Observable inputs are inputs that market participants would use in valuing the asset or liability and are developed based on market data obtained from sources independent of us. Unobservable inputs are inputs that reflect our assumptions about the factors that market participants would use in valuing the asset or liability. There are three levels of inputs that may be used to measure fair value:

[0001728949-19-000072:notes:44]
| • | Level 1 includes financial instruments for which quoted market prices for identical instruments are available in active markets. |

[0001728949-19-000072:notes:45]
| • | Level 2 includes financial instruments for which there are inputs other than quoted prices included within Level 1 that are observable for the instrument. |

[0001728949-19-000072:notes:46]
| • | Level 3 includes financial instruments for which fair value is derived from valuation techniques in which one or more significant inputs are unobservable, including our own assumptions. |

[0001728949-19-000072:notes:47]
Assets and liabilities measured at fair value are classified based on the lowest level of input that is significant to the fair value measurement. We review the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy. We recognize transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer to occur.

[0001728949-19-000072:notes:48]
Cash Equivalents and Marketable Securities: With the exception of auction rate securities, we obtain pricing information from quoted market prices, pricing vendors or quotes from brokers/dealers. We conduct reviews of our primary pricing vendors to determine whether the inputs used in the vendor’s pricing processes are deemed to be observable. The fair value for interest-bearing securities includes accrued interest.

[0001728949-19-000072:notes:49]
The fair value of corporate bonds and notes and common and preferred stock is generally determined using standard observable inputs, including reported trades, quoted market prices, matrix pricing, benchmark yields, broker/dealer quotes, issuer spreads, two-sided markets and/or benchmark securities.

[0001728949-19-000072:notes:50]
The fair value of auction rate securities is estimated using a discounted cash flow model that incorporates transaction details, such as contractual terms, maturity and timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery, the future state of the auction rate market and credit valuation adjustments of market participants. Though most of the securities we hold are pools of student loans guaranteed by the United States government, prepayment speeds and illiquidity discounts are considered significant unobservable inputs. These additional inputs are generally unobservable, and therefore, auction rate securities are included in Level 3.

[0001728949-19-000072:notes:51]
Derivative Instruments: Derivative instruments that are traded on an exchange are valued using quoted market prices and are included in Level 1. Derivative instruments that are not traded on an exchange are valued using conventional calculations/models that are primarily based on observable inputs, such as foreign currency exchange rates, volatilities and interest rates, and therefore, such derivative instruments are included in Level 2.

[0001728949-19-000072:notes:52]
Other Investments and Other Liabilities: Other investments and other liabilities included in Level 1 are comprised of our deferred compensation plan liabilities and related assets, which consist of mutual funds and are included in other assets. Other investments and other liabilities included in Level 3 are comprised of convertible debt instruments issued by private companies and contingent consideration related to business combinations, respectively. The fair value of convertible debt instruments is estimated based on the estimated timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery. The fair value of contingent consideration related to business combinations is primarily estimated using either a real options or discounted cash flow model, which includes inputs, such as projected financial information, market volatility, discount rates and timing of contractual payments. The inputs we use to estimate the fair values of the convertible debt instruments and contingent consideration are generally unobservable, and therefore, they are included in Level 3.

[0001728949-19-000072:notes:53]
Allowances for Doubtful Accounts. We maintain allowances for doubtful accounts for estimated losses resulting from receivables that will not be collected. We determine the allowance based on customer credit-worthiness, historical payment experience, the age of outstanding receivables and collateral, to the extent applicable.

[0001728949-19-000072:notes:54]
Inventories. Inventories are valued at the lower of cost and net realizable value using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers and our own forecast of customer demand, among other things.

[0001728949-19-000072:notes:55]
Property, Plant and Equipment. Property, plant and equipment are recorded at cost and depreciated or amortized using the straight-line method over their estimated useful lives. Upon the retirement or disposition of property, plant and equipment, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded, when appropriate. Buildings on owned land are depreciated over 30 years, and building improvements are depreciated over 15 years. Leasehold improvements and buildings on leased land are amortized over the shorter of their estimated useful lives, not to exceed 15 years and 30 years, respectively, or the remaining term of the related lease. Other property, plant and equipment have useful lives ranging from 2 to 25 years. Leased property meeting certain capital lease criteria is capitalized, and the net present value of the related lease payments is recorded as a liability. Amortization of assets under capital leases is recorded using the straight-line method over the shorter of the estimated useful lives or the lease terms. Maintenance, repairs and minor renewals or betterments are charged to expense as incurred.

[0001728949-19-000072:notes:56]
Goodwill and Other Intangible Assets. Goodwill represents the excess of purchase price over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Acquired intangible assets other than goodwill are amortized over their useful lives unless the lives are determined to be indefinite. For intangible assets purchased in a business combination, the estimated fair values of the assets received are used to establish their recorded values. For intangible assets acquired in a non-monetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value.

[0001728949-19-000072:notes:57]
Impairment of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. Goodwill and other indefinite-lived intangible assets are tested annually for impairment in the fourth fiscal quarter and in interim periods if events or changes in circumstances indicate that the assets may be impaired. If a qualitative assessment is used and we determine that the fair value of a reporting unit or indefinite-lived intangible asset is more likely than not (i.e., a likelihood of more than 50%) less than its carrying amount, a quantitative impairment test will be performed. If goodwill is quantitatively assessed for impairment and a reporting unit’s carrying value exceeds its fair value, the difference is recorded as an impairment. Other indefinite-lived intangible assets are quantitatively assessed for impairment, if necessary, by comparing their estimated fair values to their carrying values. If the carrying value exceeds the fair value, the difference is recorded as an impairment.

[0001728949-19-000072:notes:58]
Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by comparing the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Long-lived assets to be disposed of by sale are reported at the lower of their carrying amounts or their estimated fair values less costs to sell and are not depreciated.

[0001728949-19-000072:notes:59]
Revenue Recognition. As a result of the adoption of ASC 606, we revised our revenue recognition policy beginning in fiscal 2019 as follows.

[0001728949-19-000072:notes:60]
We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We also generate revenues from licensing system software and by performing development and other services and from other product sales. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of our performance obligations.

[0001728949-19-000072:notes:61]
Revenues from sales of our products are recognized upon transfer of control to the customer, which is generally at the time of shipment. Revenues from providing services are typically recognized over time as our performance obligation is satisfied. Revenues from providing services and licensing system software were each less than 5% of total revenues for all periods presented.

[0001728949-19-000072:notes:62]
We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets, laptops and smartwatches, and provide for a maximum royalty amount payable per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such royalties. Our estimates of sales-based royalties are based largely on an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property. We estimate sales-based royalties taking into consideration the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products, and consider all information (historical, current and forecasted, which may include certain estimates from licensees) that is reasonably available to us. We also consider in our estimates of sales-based royalties any changes in pricing we plan or expect to make. Our licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter, which is generally the following quarter. As a result of recognizing revenues in the period in which the licensees’ sales occur using

[0001728949-19-000072:notes:63]
estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

[0001728949-19-000072:notes:64]
License agreements that require payment of license fees contain a single performance obligation that represents ongoing access to a portfolio of intellectual property over the license term since such agreements provide the licensee the right to access a portfolio of intellectual property that exists at inception of the license agreement and to updates and new intellectual property that is added to the licensed portfolio during the term of the agreement that are highly interdependent or interrelated. Since we expect to expend efforts to develop and transfer updates to our licensed portfolio on an even basis, license fees are recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee.

[0001728949-19-000072:notes:65]
We account for a contract with a customer/licensee when it is legally enforceable, the parties are committed to perform their respective obligations, the rights of the parties regarding the goods and/or services to be transferred are identified, payment terms are identified, the contract has commercial substance and collectability of substantially all of the consideration is probable. If all such conditions are not met, revenues and any associated receivables are generally not recognized until such time that the required conditions are met. Cash collected from customers prior to a contract existing is recorded to other customer-related liabilities in other current liabilities.

[0001728949-19-000072:notes:66]
From time to time, regulatory authorities investigate our business practices, particularly with respect to our licensing business, and institute proceedings against us. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed original equipment manufacturers (OEMs) or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. Additionally, from time to time, companies initiate various strategies in an attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property, which may include disputing, underreporting, underpaying, not reporting and/or not paying royalties owed to us under their license agreements with us, or reporting to us in a manner that is not in compliance with their contractual obligations. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in the revenue recognition guidance, and to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur, both of which may require significant judgment. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us.

[0001728949-19-000072:notes:67]
In May 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief (Note 7). In August 2019, the U.S. Court of Appeals for the Ninth Circuit granted in its entirety Qualcomm’s request for a partial stay of the injunction. While we believe that our business practices do not violate either antitrust law or our FRAND (fair, reasonable and non-discriminatory) licensing commitments, significant evaluation and judgment were required in determining the impact of such ruling on the amount of licensing revenues estimated and recognized in fiscal 2019. This included, among other items: (i) evaluating whether our license agreements remain valid and enforceable, (ii) evaluating licensees’ conduct and whether they remain committed to perform their respective obligations and (iii) determining the expected impact, if any, to revenues of any license agreements that may be renegotiated and/or are newly entered into. Based on this evaluation, the impact of the ruling was not material to QTL licensing revenues in fiscal 2019 based on facts and factors currently known by us. As new information becomes available, we may be required to make adjustments to revenues in subsequent periods to reflect changes in estimates and/or this matter could have a material adverse effect on our ability to recognize future licensing revenues.

[0001728949-19-000072:notes:68]
We measure revenues (including our estimates of sales-based royalties) based on the amount of consideration we expect to receive in exchange for products or services. We record reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of our products and technologies, in the period that the related revenues are earned. The charges for such arrangements are recorded as a reduction to accounts receivable, net or as other current liabilities based on whether we have the intent and contractual right of offset. Certain of these charges are considered variable consideration and are included in the transaction price primarily based on estimating the most likely amount expected to be provided to the customer/licensee.

[0001728949-19-000072:notes:69]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied performance obligations.

[0001728949-19-000072:notes:70]
We disaggregate our revenues by segment (Note 8) and type of product and services (as presented on our consolidated statement of operations), as we believe this best depicts how the nature, amount, timing and uncertainty of our revenues and cash flows are affected by economic factors. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time.

[0001728949-19-000072:notes:71]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were $4.1 billion for fiscal 2019, and primarily related to licensing revenues of $4.7 billion recognized in the third quarter of fiscal 2019 (a portion of which was attributable to fiscal 2019) resulting from the settlement with Apple and its contract manufacturers, consisting of a payment from Apple and the release of certain of our obligations to pay Apple and the contract manufacturers customer-related liabilities.

[0001728949-19-000072:notes:72]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In fiscal 2019, we recognized revenues of $481 million that were recorded as unearned revenues at October 1, 2018.

[0001728949-19-000072:notes:73]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront. At September 29, 2019, we had $1.7 billion of remaining performance obligations, of which $544 million, $453 million, $440 million, $196 million and $50 million is expected to be recognized as revenues for each of the subsequent five years from fiscal 2020 through 2024, respectively, and $27 million thereafter.

[0001728949-19-000072:notes:74]
Concentrations. A significant portion of our revenues are concentrated with a small number of customers/licensees of our QCT and QTL segments. Revenues from three customers/licensees comprised 24%, 15% and 10% of total consolidated revenues in fiscal 2019 and 11%, 16% and 11% in fiscal 2018. Revenues from two customers/licensees comprised 18% and 17% in fiscal 2017. Revenues in 2018 and 2017 were negatively impacted by our prior dispute with Apple Inc. and its contract manufacturers (Hon Hai Precision Industry Co., Ltd./Foxconn, its affiliates and other suppliers to Apple). Revenues in fiscal 2019 were positively impacted by our settlement of such dispute in the third quarter of fiscal 2019.

[0001728949-19-000072:notes:75]
We rely on sole- or limited-source suppliers for some products, particularly products in the QCT segment, subjecting us to possible shortages of raw materials or manufacturing capacity. While we have established alternate suppliers for certain technologies that we consider critical, the loss of a supplier or the inability of a supplier to meet performance or quality specifications or delivery schedules could harm our ability to meet our delivery obligations and/or negatively impact our revenues, business operations and ability to compete for future business.

[0001728949-19-000072:notes:76]
Shipping and Handling Costs. Costs incurred for shipping and handling are included in cost of revenues. Amounts billed to a customer for shipping and handling are reported as revenues.

[0001728949-19-000072:notes:77]
Share-Based Compensation. Share-based compensation expense for equity-classified awards, principally related to restricted stock units (RSUs), is measured at the grant date, or at the acquisition date for awards assumed in business combinations, based on the estimated fair value of the award and is recognized over the employee’s requisite service period. The fair values of RSUs are estimated based on the fair market values of the underlying stock on the dates of grant or dates the RSUs are assumed. If RSUs do not have the right to participate in dividends, the fair values are discounted by the dividend yield. Share-based compensation expense is adjusted to exclude amounts related to share-based awards that are expected to be forfeited.

[0001728949-19-000072:notes:78]
Legal and Regulatory Proceedings. We are currently involved in certain legal and regulatory proceedings. Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Investigations by antitrust and trade regulation agencies are not conducted in a consistent manner across jurisdictions. Further, each country and agency has different sets of laws, rules and regulations, both substantive and procedural, as well as different legal principles, theories and potential remedies, and some agencies may seek to use the investigation to advance domestic policy goals. Depending on the jurisdiction, these investigations can involve non-transparent procedures under which we may not receive access to evidence relied upon by the enforcement agency or that may be exculpatory and may not be informed of the specific legal theories or evidence considered or relied upon by the agency. Unlike in civil litigation in the United States, in foreign proceedings, we may not be entitled to discovery or depositions, allowed to cross-examine witnesses or confront our accusers. As a result, we

[0001728949-19-000072:notes:79]
may not be aware of, and may not be entitled to know, all allegations against us, or the information or documents provided to, or discovered or prepared by, the agency. Accordingly, we may have little or no idea what an agency’s intent is with respect to liability, penalties or the timing of a decision. In many cases the agencies are given significant discretion, and any available precedent may have limited, if any, predictive value in their jurisdictions, much less in other jurisdictions. Accordingly, we cannot predict the outcome of these matters.

[0001728949-19-000072:notes:80]
If there is at least a reasonable possibility that a material loss may have been incurred associated with pending legal and regulatory proceedings, we disclose such fact, and if reasonably estimable, we provide an estimate of the possible loss or range of possible loss. We record our best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, we record the minimum estimated liability. As additional information becomes available, we assess the potential liability related to pending legal and regulatory proceedings and revise our estimates and update our disclosures accordingly. Our legal costs associated with defending ourself are recorded to expense as incurred.

[0001728949-19-000072:notes:81]
Foreign Currency. Certain foreign subsidiaries use a local currency as the functional currency. Resulting translation gains or losses are recorded as a component of accumulated other comprehensive income. Transaction gains or losses related to balances denominated in a currency other than the functional currency are recognized in the consolidated statements of operations.

[0001728949-19-000072:notes:82]
Income Taxes. The asset and liability approach is used to recognize deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax bases of assets and liabilities. Tax law and rate changes are reflected in income in the period such changes are enacted. We record a valuation allowance to reduce deferred tax assets to the amount that is more likely than not to be realized. We include interest and penalties related to income taxes, including unrecognized tax benefits, within income tax expense. We classify all deferred tax assets and liabilities as noncurrent in the consolidated balance sheets.

[0001728949-19-000072:notes:83]
Our income tax returns are based on calculations and assumptions that are subject to examination by the Internal Revenue Service and other tax authorities. In addition, the calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. While we believe we have appropriate support for the positions taken on our tax returns, we regularly assess the potential outcomes of examinations by tax authorities in determining the adequacy of our provision for income taxes. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts that give rise to a revision become known.

[0001728949-19-000072:notes:84]
We recognize excess tax benefits and shortfall tax detriments associated with share-based awards in the consolidated statements of operations, as a component of income tax expense, when realized.

[0001728949-19-000072:notes:85]
Earnings (Loss) Per Common Share. Basic earnings (loss) per common share is computed by dividing net income (loss) attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share is computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans and shares subject to accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. The accelerated share repurchase agreements were entered into in fiscal 2018 (Note 4) and, due to the net loss in fiscal 2018, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share. The following table provides information about the diluted earnings per share calculation (in millions):

[0001728949-19-000072:notes:86]
|  | 2019 |  | 2018 |  | 2017 |
| Dilutive common share equivalents included in diluted shares | 10.4 |  |  | — |  |  | 13.0 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 7.5 |  |  | 51.2 |  |  | 3.0 |  |

[0001728949-19-000072:notes:87]
Recent Accounting Pronouncements Not Yet Adopted.

[0001728949-19-000072:notes:88]
Leases: In February 2016, the FASB issued new accounting guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease accounting guidance. The new accounting guidance requires lessees to recognize right-of-use assets and corresponding lease liabilities on the balance sheet for leases with a lease term of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. We will adopt the new accounting guidance in the first quarter of fiscal 2020 using the modified retrospective approach and will not restate comparative periods. In addition, we will elect certain practical expedients. We do not expect finance leases to be material at the time of adoption. We currently expect to record lease assets and liabilities of approximately $400 million to $500 million on our consolidated balance sheet upon adoption. We do not expect the adoption of the new accounting guidance will have a material impact on our consolidated statements of operations or consolidated statements of cash flows.

[0001728949-19-000072:notes:89]
Financial Assets: In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost will be estimated based on expected losses rather than the current incurred loss impairment model. The new accounting guidance also modifies the impairment model for available-for-sale debt securities. The new accounting guidance generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. We will adopt the new accounting guidance in the first quarter of fiscal 2021, and the impact of this new accounting guidance will largely depend on the composition and credit quality of our investment portfolio, as well as economic conditions at the time of adoption.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-19-000072:notes:90]
Composition of Certain Financial Statement Items

[0001728949-19-000072:notes:91]
| Accounts Receivable (in millions) |  |  |  |
|  | September 29, 2019 |  | September 30, 2018 |
| Trade, net of allowances for doubtful accounts of $47 and $56, respectively | $ | 1,046 |  |  | $ | 2,667 |  |
| Unbilled receivables | 1,411 |  |  | 201 |  |
| Other | 14 |  |  | 36 |  |
|  | $ | 2,471 |  |  | $ | 2,904 |  |

[0001728949-19-000072:notes:92]
The increase in unbilled receivables was primarily due to the adoption of new revenue recognition guidance in fiscal 2019 (Note 1). Accounts receivable, trade at September 30, 2018 included approximately $960 million related to the short payment in the second quarter of fiscal 2017 of royalties reported by and deemed collectible from Apple’s contract manufacturers. This same amount was recorded in customer-related liabilities (in other current liabilities) for Apple, since we did not have the contractual right to offset these amounts. In the third quarter of fiscal 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties, and as a result, these amounts, as well as others, were settled.

[0001728949-19-000072:notes:93]
| Inventories (in millions) |  |  |  |
|  | September 29, 2019 |  | September 30, 2018 |
| Raw materials | $ | 77 |  |  | $ | 72 |  |
| Work-in-process | 667 |  |  | 715 |  |
| Finished goods | 656 |  |  | 906 |  |
|  | $ | 1,400 |  |  | $ | 1,693 |  |

[0001728949-19-000072:notes:94]
| Property, Plant and Equipment (in millions) | September 29, 2019 |  | September 30, 2018 |
| Land | $ | 170 |  |  | $ | 186 |  |
| Buildings and improvements | 1,546 |  |  | 1,575 |  |
| Computer equipment and software | 1,356 |  |  | 1,419 |  |
| Machinery and equipment | 4,007 |  |  | 3,792 |  |
| Furniture and office equipment | 86 |  |  | 85 |  |
| Leasehold improvements | 301 |  |  | 325 |  |
| Construction in progress | 182 |  |  | 79 |  |
|  | 7,648 |  |  | 7,461 |  |
| Less accumulated depreciation and amortization | (4,567 | ) |  | (4,486 | ) |
|  | $ | 3,081 |  |  | $ | 2,975 |  |

[0001728949-19-000072:notes:95]
Depreciation and amortization expense related to property, plant and equipment for fiscal 2019, 2018 and 2017 was $674 million, $776 million and $684 million, respectively.

[0001728949-19-000072:notes:96]
Goodwill and Other Intangible Assets. We allocate goodwill to our reporting units for annual impairment testing purposes. The following table presents the goodwill allocated to our reportable and nonreportable segments, as described in Note 8, as well as the changes in the carrying amounts of goodwill during fiscal 2019 and 2018 (in millions):

[0001728949-19-000072:notes:97]
|  | QCT |  | QTL |  | Nonreportable Segments |  | Total |
| Balance at September 24, 2017 | $ | 5,581 |  |  | $ | 741 |  |  | $ | 301 |  |  | $ | 6,623 |  |
| Impairments (Note 10) | — |  |  | (22 | ) |  | (107 | ) |  | (129 | ) |
| Other (1) | 6 |  |  | (1 | ) |  | (1 | ) |  | 4 |  |
| Balance at September 30, 2018 (2) | 5,587 |  |  | 718 |  |  | 193 |  |  | 6,498 |  |
| Acquisitions | 18 |  |  | — |  |  | — |  |  | 18 |  |
| Impairments (Note 10) | — |  |  | — |  |  | (146 | ) |  | (146 | ) |
| Other (1) | (40 | ) |  | (1 | ) |  | (47 | ) |  | (88 | ) |
| Balance at September 29, 2019 (2) | $ | 5,565 |  |  | $ | 717 |  |  | $ | — |  |  | $ | 6,282 |  |

[0001728949-19-000072:notes:98]
| (1) | Includes changes in goodwill amounts resulting from the sale of our mobile health nonreportable segment in fiscal 2019, foreign currency translation and purchase accounting adjustments. |

[0001728949-19-000072:notes:99]
| (2) | Cumulative goodwill impairments were $812 million and $666 million at September 29, 2019 and September 30, 2018, respectively. |

[0001728949-19-000072:notes:100]
The components of other intangible assets, net were as follows (in millions):

[0001728949-19-000072:notes:101]
|  | September 29, 2019 |  | September 30, 2018 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |
| Technology-based | $ | 5,958 |  |  | $ | (3,851 | ) |  | 10 |  | $ | 6,334 |  |  | $ | (3,461 | ) |  | 10 |
| Other | 134 |  |  | (69 | ) |  | 9 |  | 149 |  |  | (67 | ) |  | 8 |
|  | $ | 6,092 |  |  | $ | (3,920 | ) |  | 10 |  | $ | 6,483 |  |  | $ | (3,528 | ) |  | 10 |

[0001728949-19-000072:notes:102]
All of these intangible assets are subject to amortization and the amortization expense related to these intangible assets was $727 million, $785 million and $777 million for fiscal 2019, 2018 and 2017, respectively. Amortization expense related to these intangible assets is expected to be $610 million, $496 million, $399 million, $275 million and $121 million for each of the five years from fiscal 2020 through 2024, respectively, and $271 million thereafter. At September 29, 2019 and September 30, 2018, all acquired in-process research and development projects were completed and are being amortized over

[0001728949-19-000072:notes:103]
their useful lives.

[0001728949-19-000072:notes:104]
Equity Method and Non-marketable Equity Investments. The carrying values of our equity method and non-marketable equity investments are recorded in other noncurrent assets and were as follows (in millions):

[0001728949-19-000072:notes:105]
|  | September 29, 2019 |  | September 30, 2018 |
| Equity method investments | $ | 343 |  |  | $ | 402 |  |
| Non-marketable equity investments | 787 |  |  | 650 |  |
|  | $ | 1,130 |  |  | $ | 1,052 |  |

[0001728949-19-000072:notes:106]
Transactions with equity method investees are considered related party transactions. Revenues from certain services contracts were $152 million and $100 million with one of our equity method investees in fiscal 2019 and 2018, respectively, and revenues from certain license and services contracts were $165 million with two of our equity method investees in fiscal 2017. We eliminate unrealized profit or loss related to such transactions in relation to our ownership interest in the investee, which is recorded as a component of equity in net losses in investees in investment and other income, net. At September 29, 2019 and September 30, 2018, we had no accounts receivable from these equity method investees.

[0001728949-19-000072:notes:107]
During fiscal 2019, non-marketable debt and equity securities (non-cash consideration) with an aggregate estimated fair value of $98 million were received related to a development contract with one of our equity method investees, which was recognized as revenues in fiscal 2019. In addition, during fiscal 2019, non-marketable equity securities (non-cash consideration) with an estimated fair value of $53 million were received in connection with the sale of certain assets as part of the Cost Plan (Note 10).

[0001728949-19-000072:notes:108]
| Other Current Liabilities (in millions) |  |  |  |
|  | September 29, 2019 |  | September 30, 2018 |
| Customer incentives and other customer-related liabilities | $ | 1,129 |  |  | $ | 3,500 |  |
| Accrual for EC fines (Note 7) | 1,379 |  |  | 1,167 |  |
| Income taxes payable | 480 |  |  | 453 |  |
| RF360 Holdings Put and Call Option (Note 9) | — |  |  | 1,137 |  |
| Other | 470 |  |  | 721 |  |
|  | $ | 3,458 |  |  | $ | 6,978 |  |

[0001728949-19-000072:notes:109]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in stockholders’ equity during fiscal 2019 were as follows (in millions):

[0001728949-19-000072:notes:110]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gains (Losses) on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Other Gains (Losses) |  | Total Accumulated Other Comprehensive Income |
| Balance at September 30, 2018 | $ | 11 |  |  | $ | 23 |  |  | $ | 243 |  |  | $ | (13 | ) |  | $ | 1 |  |  | $ | 265 |  |
| Other comprehensive (loss) income before reclassifications | (110 | ) |  | — |  |  | (6 | ) |  | 26 |  |  | (19 | ) |  | (109 | ) |
| Reclassifications from accumulated other comprehensive income | — |  |  | — |  |  | (51 | ) |  | (5 | ) |  | — |  |  | (56 | ) |
| Other comprehensive (loss) income | (110 | ) |  | — |  |  | (57 | ) |  | 21 |  |  | (19 | ) |  | (165 | ) |
| Balance at September 29, 2019 | $ | (99 | ) |  | $ | 23 |  |  | $ | 186 |  |  | $ | 8 |  |  | $ | (18 | ) |  | $ | 100 |  |

[0001728949-19-000072:notes:111]
Reclassifications from accumulated other comprehensive income included adjustments of $51 million to the opening retained earnings balance as a result of the adoption of new accounting guidance in the first quarter of fiscal 2019 related to financial instruments and hedge instruments (Note 1). Reclassifications from accumulated other comprehensive income (excluding adjustments to opening retained earnings) related to available-for-sale securities were negligible during fiscal 2019 and 2018. Reclassifications from accumulated other comprehensive income related to available-for-sale securities were $201 million during fiscal 2017 and were recorded in investment and other income, net. Reclassifications from accumulated other comprehensive income related to foreign currency translation adjustments and derivative instruments were negligible for all periods presented.

[0001728949-19-000072:notes:112]
Share-based compensation expense. Total share-based compensation expense, related to all of our share-based awards, was comprised as follows (in millions):

[0001728949-19-000072:notes:113]
|  | 2019 |  | 2018 |  | 2017 |
| Cost of revenues | $ | 35 |  |  | $ | 38 |  |  | $ | 38 |  |
| Research and development | 725 |  |  | 594 |  |  | 588 |  |
| Selling, general and administrative | 277 |  |  | 251 |  |  | 288 |  |
| Share-based compensation expense before income taxes | 1,037 |  |  | 883 |  |  | 914 |  |
| Related income tax benefit | (184 | ) |  | (140 | ) |  | (161 | ) |
|  | $ | 853 |  |  | $ | 743 |  |  | $ | 753 |  |

[0001728949-19-000072:notes:114]
Other Income, Costs and Expenses. Other expenses in fiscal 2019 consisted of a $275 million charge for the fine imposed by the European Commission (EC) related to the Icera complaint (2019 EC fine) (Note 7) and $213 million in net restructuring and restructuring-related charges related to our Cost Plan (Note 10), partially offset by a $43 million gain due to the partial recovery of a fine we previously paid to the Korea Fair Trade Commission (KFTC) and a $31 million gain related to a favorable legal settlement.

[0001728949-19-000072:notes:115]
Other expenses in fiscal 2018 consisted of a $2.0 billion charge related to a fee paid in connection with the termination of our purchase agreement to acquire NXP, a $1.2 billion charge for the fine imposed by the EC related to an investigation (2018 EC fine) (Note 7) and $629 million in restructuring and restructuring-related charges related to our Cost Plan, partially offset by a $676 million benefit related to the settlement of the Taiwan Fair Trade Commission (TFTC) investigation.

[0001728949-19-000072:notes:116]
Other expenses for fiscal 2017 consisted of a $927 million charge related to the a fine imposed by the KFTC (Note 7), including related foreign currency losses, a $778 million charge related to the TFTC fine and $37 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan that was completed in fiscal 2017.

[0001728949-19-000072:notes:117]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
| Interest and dividend income | $ | 316 |  |  | $ | 625 |  |  | $ | 619 |  |
| Net gains on marketable securities | 288 |  |  | 41 |  |  | 456 |  |
| Net gains on other investments | 68 |  |  | 83 |  |  | 74 |  |
| Impairment losses on marketable securities and other investments | (135 | ) |  | (75 | ) |  | (177 | ) |
| Net (losses) gains on derivative instruments | (14 | ) |  | (27 | ) |  | 32 |  |
| Equity in net losses of investees | (93 | ) |  | (145 | ) |  | (74 | ) |
| Net gains (losses) on foreign currency transactions | 11 |  |  | 37 |  |  | (30 | ) |
|  | $ | 441 |  |  | $ | 539 |  |  | $ | 900 |  |

[0001728949-19-000072:notes:118]
Net gains on marketable securities included realized gains and losses of available-for-sale debt securities. During fiscal 2019 and 2018, gross realized gains or losses on sales of available-for-sale debt securities were negligible. During fiscal 2017, gross realized gains and losses on sales of available-for-sale debt securities were $361 million and $98 million, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-19-000072:notes:119]
Income Taxes
The components of the income tax provision were as follows (in millions):

[0001728949-19-000072:notes:120]
|  | 2019 |  | 2018 |  | 2017 |
| Current provision (benefit): |  |  |  |  |  |
| Federal | $ | 1,563 |  |  | $ | 2,559 |  |  | $ | 72 |  |
| State | 2 |  |  | (1 | ) |  | 3 |  |
| Foreign | (407 | ) |  | 777 |  |  | 1,256 |  |
|  | 1,158 |  |  | 3,335 |  |  | 1,331 |  |
| Deferred provision (benefit): |  |  |  |  |  |
| Federal | 2,037 |  |  | 1,846 |  |  | (598 | ) |
| State | 17 |  |  | 1 |  |  | 4 |  |
| Foreign | (117 | ) |  | 174 |  |  | (194 | ) |
|  | 1,937 |  |  | 2,021 |  |  | (788 | ) |
|  | $ | 3,095 |  |  | $ | 5,356 |  |  | $ | 543 |  |

[0001728949-19-000072:notes:121]
The foreign component of the income tax provision (benefit) included foreign withholding taxes on royalty revenues included in U.S. earnings.

[0001728949-19-000072:notes:122]
The components of income before income taxes by U.S. and foreign jurisdictions were as follows (in millions):

[0001728949-19-000072:notes:123]
|  | 2019 |  | 2018 |  | 2017 |
| United States | $ | 7,042 |  |  | $ | (1,834 | ) |  | $ | (795 | ) |
| Foreign | 439 |  |  | 2,226 |  |  | 3,782 |  |
|  | $ | 7,481 |  |  | $ | 392 |  |  | $ | 2,987 |  |

[0001728949-19-000072:notes:124]
In fiscal 2018 and 2017, the foreign component of income before income taxes in foreign jurisdictions consisted primarily of income earned in Singapore.

[0001728949-19-000072:notes:125]
The following is a reconciliation of the expected statutory federal income tax provision to our actual income tax provision (in millions):

[0001728949-19-000072:notes:126]
|  | 2019 |  | 2018 |  | 2017 |
| Expected income tax provision at federal statutory tax rate | $ | 1,571 |  |  | $ | 97 |  |  | $ | 1,045 |  |
| State income tax provision, net of federal benefit | 10 |  |  | 2 |  |  | 8 |  |
| Derecognition of deferred tax asset on distributed intellectual property | 2,472 |  |  | — |  |  | — |  |
| Benefits from establishing new U.S. net deferred tax assets | (570 | ) |  | — |  |  | — |  |
| Benefits from foreign-derived intangible income (FDII) deduction | (419 | ) |  | — |  |  | — |  |
| Benefits related to research and development tax credits | (110 | ) |  | (136 | ) |  | (81 | ) |
| Benefits from foreign income taxed at other than U.S. rates | (54 | ) |  | (834 | ) |  | (963 | ) |
| Nondeductible charges (reversals) related to the EC, KFTC and TFTC investigations | 51 |  |  | (119 | ) |  | 363 |  |
| Impact of changes in tax reserves and audit settlements for prior year tax positions | 20 |  |  | — |  |  | 111 |  |
| Taxes on undistributed foreign earnings | 8 |  |  | 87 |  |  | — |  |
| Toll Charge from U.S. tax reform | — |  |  | 5,236 |  |  | — |  |
| Valuation allowance on deferred tax assets related to NXP termination fee | — |  |  | 494 |  |  | — |  |
| Remeasurement of deferred taxes due to changes in statutory rate due to U.S. tax reform | — |  |  | 443 |  |  | — |  |
| Other | 116 |  |  | 86 |  |  | 60 |  |
|  | $ | 3,095 |  |  | $ | 5,356 |  |  | $ | 543 |  |

[0001728949-19-000072:notes:127]
The 2017 Tax Cuts and Jobs Act (the Tax Legislation), which was enacted during the first quarter of fiscal 2018, significantly revised the United States corporate income tax by, among other things, lowering the corporate income tax rate to 21% and imposing a one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge). The Tax Legislation fundamentally changed the taxation of multinational entities, including a shift from a system of worldwide taxation with deferral to a hybrid territorial system, featuring a participation exemption regime with current taxation of certain foreign income, a minimum tax on low-taxed foreign earnings and new measures to deter base erosion and promote U.S. production. As a fiscal-year taxpayer, certain provisions of the Tax Legislation became effective starting at the beginning of fiscal 2019, including GILTI (global intangible low-taxed income), a new tax on income of foreign corporations, BEAT (base-erosion and anti-abuse tax) and FDII (foreign-derived intangible income). In response to the Tax Legislation and to better align our profits with our activities, we implemented certain tax restructuring in fiscal 2018 and 2019. As a result, beginning in fiscal 2019, substantially all of our income is in the U.S., of which a significant portion qualifies for preferential treatment as FDII at a 13% effective tax rate. The impact of GILTI and BEAT is negligible. Accordingly, our annual effective tax rate for fiscal 2019 reflected the effects of these provisions of the Tax Legislation. Our annual effective tax rate for fiscal 2018 reflected a blended federal statutory rate of approximately 25%.

[0001728949-19-000072:notes:128]
As a result of the Tax Legislation, in fiscal 2019, several of our foreign subsidiaries made tax elections to be treated as U.S. branches for federal income tax purposes (commonly referred to as “check-the-box” elections) effective beginning in fiscal 2018 and 2019. Although beginning in fiscal 2019 the income of these entities will be included in our consolidated U.S. tax return, we believe that by treating these foreign subsidiaries as U.S. branches for federal income taxes, rather than controlled foreign corporations, we will significantly reduce the risk of being subject to GILTI and BEAT taxes. As a result of making these check-the-box elections, we recorded a tax benefit of $570 million in the first quarter of fiscal 2019 due to establishing new U.S. net deferred tax assets resulting from the difference between the GAAP basis and the U.S. federal tax carryover basis of the existing assets and liabilities of those foreign subsidiaries, primarily related to customer incentive liabilities that have not been deducted for tax purposes. Additionally, during fiscal 2018, one of our foreign subsidiaries distributed certain intellectual property to a U.S. subsidiary resulting in a difference between the GAAP basis and the U.S. federal tax basis of the distributed intellectual property. Upon adoption of new accounting guidance in the first quarter of fiscal 2019, we recorded a deferred tax asset of approximately $2.6 billion primarily related to the distributed intellectual property, with an adjustment to opening retained earnings (Note 1). During the third quarter of fiscal 2019, the United States Treasury Department issued new temporary regulations that resulted in a change to the deductibility of dividend income

[0001728949-19-000072:notes:129]
received by a U.S. stockholder from a foreign corporation. As a result of this change, pursuant to an agreement with the Internal Revenue Service, we relinquished the federal tax basis step-up of intellectual property that was distributed in fiscal 2018 by one of our foreign subsidiaries to a U.S. subsidiary. Therefore, the related deferred tax asset was derecognized, resulting in a $2.5 billion charge to income tax expense in fiscal 2019.

[0001728949-19-000072:notes:130]
In the fourth quarter of fiscal 2019, as a result of recent court rulings in Korea, among other factors, we decided to apply for a partial refund claim for taxes previously withheld from licensees in Korea on payments due under their license agreements to which we have claimed a foreign tax credit in the United States. As a result, we established a noncurrent income taxes receivable of $1.4 billion (recorded in other assets and included as foreign current benefit in the components of the income tax provision) and a noncurrent liability for uncertain tax benefits of $1.4 billion (recorded in other liabilities and included as federal current provision in the components of the income tax provision).

[0001728949-19-000072:notes:131]
Income tax expense for fiscal 2019 also reflected benefits from our FDII deduction (including the impact of the Apple settlement) and research and development credits, as well as the impact of the 2019 EC fine, which is not deductible for tax purposes.

[0001728949-19-000072:notes:132]
In fiscal 2018, as a result of the Tax Legislation, we recorded a charge of $5.7 billion to income tax expense, comprised of $5.2 billion related to the estimated Toll Charge and $438 million resulting from the remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate, which included a $135 million tax benefit recorded in fiscal 2018 related to the remeasurement of a U.S. deferred tax liability that was established as a result of a change in one of our tax positions due to Tax Legislation. After application of certain tax credits, the total cash payment is expected to be $2.5 billion. The first payment was made on January 15, 2019. At September 29, 2019, we estimated remaining future payments of $2.3 billion for the Toll Charge, after application of certain tax credits (including excess tax credits generated in fiscal 2019), which is payable in installments over the next seven years. At September 29, 2019, $209 million was included in other current liabilities, reflecting the next installment due in January 2020.

[0001728949-19-000072:notes:133]
Income tax expense for fiscal 2018 was also impacted by the charge recorded in the fourth quarter of fiscal 2018 related to the termination fee paid to NXP, which did not result in a tax benefit after the consideration of realizability of such loss. Fiscal 2018 and 2017 income tax expense was impacted by the EC, KFTC and TFTC fines, and settlement with the TFTC, which were not deductible for tax purposes (or taxable in the case of the settlement) and portions of which were attributable to foreign jurisdictions and to the United States. These impacts were partially offset in fiscal 2018 and 2017 by lower U.S. revenues primarily related to decreased royalty revenues from Apple’s contract manufacturers and, for fiscal 2017, a payment to BlackBerry in connection with an arbitration decision.

[0001728949-19-000072:notes:134]
Income tax expense for fiscal 2017 reflected an increase in our Singapore tax rate as a result of the expiration of certain of our tax incentives in March 2017, which was substantially offset by tax benefits resulting from the increase in our Singapore tax rate in effect when certain deferred tax assets reversed. During the third quarter of fiscal 2018, we entered into a new tax incentive agreement in Singapore that results in a reduced tax rate from March 2017 through March 2022, provided that we meet specified employment and investment criteria in Singapore. Our Singapore tax rate will increase in March 2022 as a result of expiration of these incentives and again in March 2027 upon the expiration of tax incentives under a prior agreement. During fiscal 2018, one of our Singapore subsidiaries distributed certain intellectual property to a U.S. subsidiary reducing the benefit of these tax incentives almost entirely going forward. Without these tax incentives, our income tax expense would have been higher and impacted earnings (loss) per share attributable to Qualcomm as follows (in millions, except per share amounts):

[0001728949-19-000072:notes:135]
|  | 2019 |  | 2018 |  | 2017 |
| Additional income tax expense | $ | — |  |  | $ | 652 |  |  | $ | 493 |  |
| Reduction to diluted earnings (loss) per share | — |  |  | 0.45 |  |  | 0.33 |  |

[0001728949-19-000072:notes:136]
We continue to assert that substantially all of our foreign earnings are not indefinitely reinvested. We recorded a charge of $8 million and $87 million to income tax expense in fiscal 2019 and 2018, respectively, related to outside basis differences that are not permanently reinvested. Income tax expense in fiscal 2018 reflected a one-time charge resulting from a change in our assertion as a result of the Tax Legislation, which eliminated certain material tax effects on the repatriation of cash to the United States. At September 29, 2019, we had not recorded a deferred tax liability of approximately $25 million related to foreign withholding taxes on approximately $225 million of undistributed earnings of certain subsidiaries that we continue to consider to be indefinitely reinvested outside the United States. Should we decide to no longer indefinitely reinvest such

[0001728949-19-000072:notes:137]
earnings outside the United States, we would have to adjust the income tax provision in the period we make such determination.

[0001728949-19-000072:notes:138]
We had deferred tax assets and deferred tax liabilities as follows (in millions):

[0001728949-19-000072:notes:139]
|  | September 29, 2019 |  | September 30, 2018 |
| Unused tax credits | $ | 1,137 |  |  | $ | 1,044 |  |
| Accrued liabilities and reserves | 648 |  |  | 396 |  |
| Unused net operating losses | 619 |  |  | 696 |  |
| Unearned revenues | 376 |  |  | 478 |  |
| Unrealized losses on other investments and marketable securities | 164 |  |  | 126 |  |
| Share-based compensation | 115 |  |  | 97 |  |
| Other | 144 |  |  | 26 |  |
| Total gross deferred tax assets | 3,203 |  |  | 2,863 |  |
| Valuation allowance | (1,672 | ) |  | (1,529 | ) |
| Total net deferred tax assets | 1,531 |  |  | 1,334 |  |
| Intangible assets | (216 | ) |  | (322 | ) |
| Property, plant and equipment | (102 | ) |  | (49 | ) |
| Unrealized gains on other investments and marketable securities | (99 | ) |  | (26 | ) |
| Accrued withholding taxes | (19 | ) |  | (90 | ) |
| Accrued revenues | — |  |  | (202 | ) |
| Other | (2 | ) |  | — |  |
| Total deferred tax liabilities | (438 | ) |  | (689 | ) |
| Net deferred tax assets | $ | 1,093 |  |  | $ | 645 |  |
| Reported as: |  |  |  |
| Non-current deferred tax assets | $ | 1,196 |  |  | $ | 936 |  |
| Non-current deferred tax liabilities (1) | (103 | ) |  | (291 | ) |
|  | $ | 1,093 |  |  | $ | 645 |  |

[0001728949-19-000072:notes:140]
| (1) | Non-current deferred tax liabilities were included in other liabilities in the consolidated balance sheets. |

[0001728949-19-000072:notes:141]
At September 29, 2019, we had unused federal net operating loss carryforwards of $188 million expiring from 2021 through 2035, unused state net operating loss carryforwards of $740 million expiring from 2020 through 2039 and unused foreign net operating loss carryforwards of $2.1 billion, of which $1.8 billion expire in 2027. At September 29, 2019, we had unused state tax credits of $1.0 billion, of which substantially all may be carried forward indefinitely, unused federal tax credits of $169 million expiring from 2026 through 2030 and unused tax credits of $34 million in foreign jurisdictions expiring from 2033 through 2039. We do not expect our federal net operating loss carryforwards to expire unused.

[0001728949-19-000072:notes:142]
At September 29, 2019, we have provided a valuation allowance on certain state tax credits, foreign deferred tax assets, federal capital losses, state net operating losses and federal foreign tax credits of $1.0 billion, $536 million, $83 million, $26 million and $20 million, respectively. The valuation allowances reflect the uncertainties surrounding our ability to generate sufficient future taxable income in certain foreign and state tax jurisdictions to utilize our net operating losses and our ability to generate sufficient capital gains to utilize all capital losses. We believe, more likely than not, that we will have sufficient taxable income after deductions related to share-based awards to utilize our remaining deferred tax assets.

[0001728949-19-000072:notes:143]
A summary of the changes in the amount of unrecognized tax benefits for fiscal 2019, 2018 and 2017 follows (in millions):

[0001728949-19-000072:notes:144]
|  | 2019 |  | 2018 |  | 2017 |
| Beginning balance of unrecognized tax benefits | $ | 217 |  |  | $ | 372 |  |  | $ | 271 |  |
| Additions based on prior year tax positions | 1,238 |  |  | 7 |  |  | 92 |  |
| Reductions for prior year tax positions and lapse in statute of limitations | (3 | ) |  | (11 | ) |  | (11 | ) |
| Additions for current year tax positions | 253 |  |  | 18 |  |  | 23 |  |
| Settlements with taxing authorities | — |  |  | (169 | ) |  | (3 | ) |
| Ending balance of unrecognized tax benefits | $ | 1,705 |  |  | $ | 217 |  |  | $ | 372 |  |

[0001728949-19-000072:notes:145]
Of the $1.7 billion of unrecognized tax benefits, $1.6 billion has been recorded to other noncurrent liabilities. We believe that it is reasonably possible that certain unrecognized tax benefits recorded at September 29, 2019 may result in a cash payment in fiscal 2020. Unrecognized tax benefits at September 29, 2019 included $125 million for tax positions that, if recognized, would impact the effective tax rate. The unrecognized tax benefits differ from the amount that would affect our effective tax rate primarily because the unrecognized tax benefits were included on a gross basis and did not reflect related receivables or secondary impacts such as the federal deduction for state taxes, adjustments to deferred tax assets and the valuation allowance that might be required if our tax positions are sustained. The increase in unrecognized tax benefits in fiscal 2019 was primarily due to our plan to apply for a refund of Korean withholding tax (which had an insignificant impact to our income tax provision). If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. The decrease in unrecognized tax benefits in fiscal 2018 was primarily due to an agreement reached with the Internal Revenue Service (IRS) related to tax positions on the classification of income in our fiscal 2016 federal income tax return. The increase in unrecognized tax benefits in fiscal 2017 was primarily due to tax positions related to transfer pricing. We believe that it is likely that the total amount of unrecognized tax benefits at September 29, 2019 will increase in fiscal 2020 as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision.

[0001728949-19-000072:notes:146]
We file income tax returns in the United States federal jurisdiction and various state and foreign jurisdictions. We are currently a participant in the IRS Compliance Assurance Process, whereby we and the IRS endeavor to agree on the treatment of all tax issues prior to the tax return being filed. We are no longer subject to U.S. federal income tax examinations for years prior to fiscal 2015. We are subject to examination by the California Franchise Tax Board for fiscal years after 2014. We are also subject to examination in other taxing jurisdictions in the United States and numerous foreign jurisdictions. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2000. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. At September 29, 2019, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0001728949-19-000072:notes:147]
Cash amounts paid for income taxes, net of refunds received, were $1.1 billion, $877 million and $1.0 billion for fiscal 2019, 2018 and 2017, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-19-000072:notes:148]
Capital Stock
Stock Repurchase Program. On July 26, 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. The stock repurchase program has no expiration date. In August 2018, we completed a “modified Dutch auction” tender offer and paid an aggregate of $5.1 billion, excluding fees and related expenses, to repurchase 76.2 million shares of our common stock, which were retired, at a price of $67.50 per share.

[0001728949-19-000072:notes:149]
In September 2018, we entered into three accelerated share repurchase agreements (ASR Agreements) with three financial institutions under which we paid an aggregate of $16.0 billion upfront to the financial institutions and received from them an initial delivery of 178.4 million shares of our common stock, which were retired and recorded as a $12.8 billion reduction to stockholders’ equity. The remaining $3.2 billion was recorded as a reduction to stockholders’ equity as an unsettled forward contract indexed to our own stock. During September 2019, the ASR Agreements were completed, and an additional 68.7 million shares were delivered to us, which were retired, and the forward contract was settled with no

[0001728949-19-000072:notes:150]
adjustment to stockholders’ equity. In total, we purchased 247.1 million shares based on the volume-weighted average stock price of our common stock during the terms of the transactions, less a discount.

[0001728949-19-000072:notes:151]
During fiscal 2019, 2018 and 2017, we repurchased and retired an additional 27.1 million, 24.2 million and 22.8 million shares of common stock, respectively, for $1.8 billion, $1.4 billion and $1.3 billion, respectively, before commissions. To reflect share repurchases in the consolidated balance sheet, we (i) reduce common stock for the par value of the shares, (ii) reduce paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) record the residual amount to retained earnings, if any. At September 29, 2019, $7.1 billion remained authorized for repurchase under our stock repurchase program. Since September 29, 2019, we repurchased and retired 3.9 million shares of common stock for $300 million.

[0001728949-19-000072:notes:152]
Shares Outstanding. Shares of common stock outstanding at September 29, 2019 were as follows (in millions):

[0001728949-19-000072:notes:153]
|  | 2019 |
| Balance at beginning of period | 1,219 |  |
| Issued | 22 |  |
| Repurchased | (96 | ) |
| Balance at end of period | 1,145 |  |

[0001728949-19-000072:notes:154]
Dividends. On October 15, 2019, we announced a cash dividend of $0.62 per share on our common stock, payable on December 19, 2019 to stockholders of record as of the close of business on December 5, 2019.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001728949-19-000072:notes:155]
Employee Benefit Plans
Employee Savings and Retirement Plan. We have a 401(k) plan that allows eligible employees to contribute up to 85% of their eligible compensation, subject to annual limits. We match a portion of the employee contributions and may, at our discretion, make additional contributions based upon earnings. Our contribution expense was $64 million, $78 million and $76 million in fiscal 2019, 2018 and 2017, respectively.

[0001728949-19-000072:notes:156]
Equity Compensation Plans. On March 8, 2016, our stockholders approved the Qualcomm Incorporated 2016 Long-Term Incentive Plan (the 2016 Plan), which replaced the Qualcomm Incorporated 2006 Long-Term Incentive Plan (the Prior Plan). Effective on and after that date, no new awards will be granted under the Prior Plan, although all outstanding awards under the Prior Plan will remain outstanding according to their terms and the terms of the Prior Plan. The 2016 Plan provides for the grant of incentive and nonstatutory stock options, stock appreciation rights, restricted stock, unrestricted stock, restricted stock units, performance units, performance shares, deferred compensation awards and other stock-based awards. The share reserve under the 2016 Plan is equal to 90.0 million shares, plus approximately 20.1 million shares that were available for future grant under the Prior Plan on March 8, 2016, for a total of approximately 110.1 million shares initially available for grant under the 2016 Plan. This share reserve is automatically increased as provided in the 2016 Plan by the number of shares subject to stock options that were granted under the Prior Plan and outstanding as of March 8, 2016, which after that date expire or for any reason are forfeited, canceled or terminated, and by two times the number of shares subject to any awards other than stock options that were granted under the Prior Plan and outstanding as of March 8, 2016, which after that date expire, are forfeited, canceled or terminated, fail to vest, are not earned due to any performance goal that is not met, are otherwise reacquired without having become vested, or are paid in cash, exchanged by a participant or withheld by us to satisfy any tax withholding or tax payment obligations related to such award. The Board of Directors may amend or terminate the 2016 Plan at any time. Certain amendments, including an increase in the share reserve, require stockholder approval. At September 29, 2019, approximately 50.4 million shares were available for future grant under the 2016 Plan.

[0001728949-19-000072:notes:157]
RSUs are share awards that entitle the holder to receive shares of our common stock upon vesting. The RSUs generally include dividend-equivalent rights and vest over periods of three years from the date of grant. A summary of RSU transactions that contain only service requirements to vest for all equity compensation plans follows:

[0001728949-19-000072:notes:158]
|  | Number of Shares |  | Weighted-AverageGrant Date FairValue |  | Aggregate IntrinsicValue |
|  | (In thousands) |  |  |  | (In billions) |
| RSUs outstanding at September 30, 2018 | 23,097 |  |  | $ | 62.12 |  |  |  |
| RSUs granted | 20,879 |  |  | 63.10 |  |  |  |
| RSUs canceled/forfeited | (2,812 | ) |  | 62.45 |  |  |  |
| RSUs vested | (14,475 | ) |  | 62.64 |  |  |  |
| RSUs outstanding at September 29, 2019 | 26,689 |  |  | $ | 62.57 |  |  | $ | 2.0 |  |

[0001728949-19-000072:notes:159]
The weighted-average estimated fair values of employee RSUs that contain only service requirements to vest granted during fiscal 2018 and 2017 were $62.61 and $66.54 per share, respectively. Upon vesting, we issue new shares of common stock. For the majority of RSUs, shares are issued on the vesting dates net of the amount of shares needed to satisfy statutory tax withholding requirements to be paid by us on behalf of the employees. As a result, the actual number of shares issued will be fewer than the number of RSUs outstanding. The annual pre-vest forfeiture rate for RSUs was estimated to be approximately 7%, 6% and 5% in fiscal 2019, 2018 and 2017, respectively.

[0001728949-19-000072:notes:160]
At September 29, 2019, total unrecognized compensation expense related to such non-vested RSUs granted prior to that date was $1.1 billion, which is expected to be recognized over a weighted-average period of 1.9 years. The total vest-date fair value of such RSUs that vested during fiscal 2019, 2018 and 2017 was $977 million, $940 million and $820 million, respectively. The total shares withheld to satisfy statutory tax withholding requirements related to all share-based awards were approximately 4.2 million, 4.4 million and 4.2 million in fiscal 2019, 2018 and 2017, respectively, and were based on the value of the awards on their vesting dates as determined by our closing stock price.

[0001728949-19-000072:notes:161]
The Board of Directors may grant stock options to employees, directors and consultants to purchase shares of our common stock at an exercise price not less than the fair market value of the stock at the date of grant. Stock options vest over periods not exceeding five years and are exercisable for up to ten years from the grant date. Total outstanding stock option shares at September 29, 2019 and September 30, 2018, were 1.1 million and 5.1 million, respectively. The decrease in the number of stock option shares outstanding during fiscal 2019 related primarily to stock options exercised.

[0001728949-19-000072:notes:162]
The total tax benefits realized, including the excess tax benefits, related to share-based awards during fiscal 2019, 2018 and 2017 were $237 million, $254 million and $301 million, respectively.

[0001728949-19-000072:notes:163]
Employee Stock Purchase Plan. We have an employee stock purchase plan for eligible employees to purchase shares of common stock at 85% of the lower of the fair market value on the first or the last day of each offering period, which is generally six months. Employees may authorize us to withhold up to 15% of their compensation during any offering period, subject to certain limitations. The employee stock purchase plan includes a non-423(b) plan. On March 23, 2018, our stockholders approved an amendment to the Amended and Restated QUALCOMM Incorporated 2001 Employee Stock Purchase Plan to increase the share reserve by 30.0 million shares. The shares authorized under the plan were approximately 101.7 million at September 29, 2019. The shares reserved for future issuance were approximately 32.8 million at September 29, 2019. During fiscal 2019, 2018 and 2017, approximately 6.1 million, 5.8 million and 5.7 million shares, respectively, were issued under the plan at an average price of $42.13, $49.41 and $45.29 per share, respectively. At September 29, 2019, total unrecognized compensation expense related to non-vested purchase rights granted prior to that date was $27 million. We recorded cash received from the exercise of purchase rights of $257 million, $286 million and $260 million during fiscal 2019, 2018 and 2017, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001728949-19-000072:notes:164]
Debt
Long-term Debt. In May 2015, we issued an aggregate principal amount of $10.0 billion of unsecured floating- and fixed-rate notes (May 2015 Notes) with varying maturities, of which $8.5 billion remained outstanding at September 29, 2019. The proceeds from the May 2015 Notes of $9.9 billion, net of underwriting discounts and offering expenses, were used to fund stock repurchases and other general corporate purposes. In May 2017, we issued an aggregate principal amount of

[0001728949-19-000072:notes:165]
$11.0 billion of unsecured floating- and fixed-rate notes (May 2017 Notes) with varying maturities, of which $7.0 billion remained outstanding at September 29, 2019. The proceeds from the May 2017 Notes of $10.95 billion, net of underwriting discounts and offering expenses, were intended to be used to finance, in part, a then proposed acquisition and other related transactions and for general corporate purposes.

[0001728949-19-000072:notes:166]
The following table provides a summary of our long-term debt and current portion of long-term debt (in millions, except percentages):

[0001728949-19-000072:notes:167]
|  |  | September 29, 2019 |  | September 30, 2018 |
|  |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | $ | 250 |  |  | 2.74% |  | $ | 250 |  |  | 2.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 2.64% |  | 1,750 |  |  | 3.13% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.89% |  | 2,000 |  |  | 3.73% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.73% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.72% |  | 1,500 |  |  | 4.72% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 3.06% |  | 500 |  |  | 3.14% |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | 1,500 |  |  | 2.70% |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | 1,500 |  |  | 3.01% |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.45% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.47% |  | 1,500 |  |  | 4.47% |
|  | Total principal | 15,500 |  |  |  |  | 15,500 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (75 | ) |  |  |  | (85 | ) |  |  |
|  | Hedge accounting fair value adjustments | 9 |  |  |  |  | (50 | ) |  |  |
|  | Total long-term debt | $ | 15,434 |  |  |  |  | $ | 15,365 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | 1,997 |  |  |  |  | $ | — |  |  |  |
|  | Long-term debt | 13,437 |  |  |  |  | 15,365 |  |  |  |
|  | Total | $ | 15,434 |  |  |  |  | $ | 15,365 |  |  |  |

[0001728949-19-000072:notes:168]
At September 29, 2019, future principal payments were $2.0 billion in fiscal 2020, $2.0 billion in fiscal 2022, $2.0 billion in fiscal 2023, $1.5 billion in fiscal 2024 and $8.0 billion after fiscal 2024; no principal payments are due in fiscal 2021. At September 29, 2019 and September 30, 2018, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $16.5 billion and $15.1 billion, respectively.

[0001728949-19-000072:notes:169]
We may redeem the outstanding fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. We may not redeem the outstanding floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of our other senior unsecured indebtedness and will effectively rank junior to all liabilities of our subsidiaries.

[0001728949-19-000072:notes:170]
At September 29, 2019, we had outstanding interest rate swaps with an aggregate notional amount of $1.8 billion, related to the May 2015 Notes, which effectively converted approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recorded as interest expense in the current period. We did not enter into interest rate swaps in connection with issuance of the May 2017 Notes.

[0001728949-19-000072:notes:171]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to our commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $563 million, $662 million and $313 million during fiscal 2019, 2018 and 2017, respectively.

[0001728949-19-000072:notes:172]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At September 29, 2019 and September 30, 2018, we had $499 million and $1.0 billion, respectively, of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 2.17% and 2.35%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 41 days and 16 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at September 29, 2019 and September 30, 2018.

[0001728949-19-000072:notes:173]
Revolving Credit Facility. We have an Amended and Restated Revolving Credit Facility (Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. Proceeds from the Revolving Credit Facility, if drawn, are expected to be used for general corporate purposes. Loans under the Revolving Credit Facility will bear interest, at our option, at either the reserve-adjusted Eurocurrency Rate or the Base Rate (both of which are determined in accordance with the Revolving Credit Facility), in each case plus an applicable margin based on our long-term unsecured senior, non-credit enhanced debt ratings. The margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.805% and 0.00%, respectively. The Revolving Credit Facility has a facility fee, which accrues at a rate of 0.07% per annum. At September 29, 2019 and September 30, 2018, we had not borrowed any funds under the Revolving Credit Facility.

[0001728949-19-000072:notes:174]
Debt Covenants. The Revolving Credit Facility requires that we comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. We are not subject to any financial covenants under the notes nor any covenants that would prohibit us from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by us or our subsidiaries. At September 29, 2019 and September 30, 2018, we were in compliance with the applicable covenants under the Revolving Credit Facility.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-19-000072:notes:175]
Purchase Obligations and Operating Leases. We have agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization. We lease certain of our land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 20 years and with provisions in certain leases for cost-of-living increases. Rental expense for fiscal 2019, 2018 and 2017 was $146 million, $160 million and $129 million, respectively.

[0001728949-19-000072:notes:176]
Obligations under our purchase agreements, which primarily relate to integrated circuit product inventory obligations, and future minimum lease payments under our operating leases at September 29, 2019 were as follows (in millions):

[0001728949-19-000072:notes:177]
|  | Purchase Obligations |  | Operating Leases |
| 2020 | $ | 2,926 |  |  | $ | 138 |  |
| 2021 | 286 |  |  | 97 |  |
| 2022 | 108 |  |  | 66 |  |
| 2023 | 53 |  |  | 31 |  |
| 2024 | 16 |  |  | 18 |  |
| Thereafter | 1 |  |  | 35 |  |
| Total | $ | 3,390 |  |  | $ | 385 |  |

[0001728949-19-000072:notes:178]
Other Commitments. At September 29, 2019, we have committed to fund certain strategic investments up to $154 million, most of which do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-19-000072:notes:179]
Segment Information
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices, wireless networks, devices used in the Internet of Things (IoT), broadband gateway equipment, consumer electronic devices and automotive telematics and infotainment systems. QTL grants licenses to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an equity method

[0001728949-19-000072:notes:180]
investee. We also have nonreportable segments, including Qualcomm Government Technologies or QGOV (formerly Qualcomm Cyber Security Solutions) and other wireless technology and service initiatives.

[0001728949-19-000072:notes:181]
We evaluate the performance of our segments based on earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense; certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories and property, plant and equipment to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages.

[0001728949-19-000072:notes:182]
In fiscal 2018, all of the costs ($474 million) related to pre-commercial research and development of 5G (fifth generation) technologies were included in unallocated corporate research and development expenses, whereas similar costs related to the research and development of other technologies, including 3G (third generation) and 4G (fourth generation) technologies, were recorded in the QCT and QTL segments. Beginning in fiscal 2019, all research and development costs associated with 5G technologies were included in segment results. Additionally, beginning in fiscal 2019, certain research and development costs associated with early research and development that were historically included in our QCT segment were allocated to our QTL segment. The net effect of these changes negatively impacted QTL’s EBT by $489 million in fiscal 2019 and positively impacted QCT’s EBT by $160 million in fiscal 2019.

[0001728949-19-000072:notes:183]
Beginning in fiscal 2019, we combined our Small Cells business, which sells products designed for the implementation of small cells to address the challenge of meeting the increased demand for mobile data, into our QCT segment. Revenues and operating results related to the Small Cells business were included in nonreportable segments through the end of fiscal 2018. Prior period segment information has not been adjusted to conform to the new segment presentation as such adjustments are insignificant.

[0001728949-19-000072:notes:184]
The table below presents revenues, EBT and total assets for reportable segments (in millions):

[0001728949-19-000072:notes:185]
|  | 2019 |  | 2018 |  | 2017 |
| Revenues |  |  |  |  |  |
| QCT | $ | 14,639 |  |  | $ | 17,282 |  |  | $ | 16,479 |  |
| QTL | 4,591 |  |  | 5,042 |  |  | 6,412 |  |
| QSI | 152 |  |  | 100 |  |  | 113 |  |
| Reconciling items | 4,891 |  |  | 187 |  |  | (746 | ) |
| Total | $ | 24,273 |  |  | $ | 22,611 |  |  | $ | 22,258 |  |
| EBT |  |  |  |  |  |
| QCT | $ | 2,143 |  |  | $ | 2,966 |  |  | $ | 2,747 |  |
| QTL | 2,954 |  |  | 3,404 |  |  | 5,142 |  |
| QSI | 344 |  |  | 24 |  |  | 65 |  |
| Reconciling items | 2,040 |  |  | (6,002 | ) |  | (4,967 | ) |
| Total | $ | 7,481 |  |  | $ | 392 |  |  | $ | 2,987 |  |
| Assets |  |  |  |  |  |
| QCT | $ | 2,307 |  |  | $ | 3,041 |  |  | $ | 3,830 |  |
| QTL | 1,541 |  |  | 1,472 |  |  | 1,735 |  |
| QSI | 1,708 |  |  | 1,279 |  |  | 1,037 |  |
| Reconciling items | 27,401 |  |  | 26,926 |  |  | 58,896 |  |
| Total | $ | 32,957 |  |  | $ | 32,718 |  |  | $ | 65,498 |  |

[0001728949-19-000072:notes:186]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets include certain non-marketable equity instruments, accounts receivable and other investments. QSI assets at

[0001728949-19-000072:notes:187]
September 29, 2019, September 30, 2018 and September 24, 2017 included $230 million, $283 million and $254 million, respectively, related to investments in equity method investees. Total segment assets differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable and non-marketable securities, property, plant and equipment, deferred tax assets, goodwill, intangible assets, noncurrent income taxes receivable and assets of nonreportable segments. The net book value of long-lived tangible assets located outside of the United States was $1.4 billion at September 29, 2019, September 30, 2018 and September 24, 2017. The net book values of long-lived tangible assets located in the United States were $1.7 billion, $1.6 billion and $1.8 billion at September 29, 2019, September 30, 2018 and September 24, 2017, respectively.

[0001728949-19-000072:notes:188]
We report revenues from external customers by country based on the location to which our products or services are delivered, which for QCT is generally the country in which our customers manufacture their products, and for licensing revenues, the invoiced addresses of our licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues could include revenues related to shipments of integrated circuits for a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States. Revenues by country were as follows (in millions):

[0001728949-19-000072:notes:189]
|  | 2019 |  | 2018 |  | 2017 |
| China (including Hong Kong) | $ | 11,610 |  |  | $ | 15,149 |  |  | $ | 14,579 |  |
| Ireland | 2,957 |  |  | 1 |  |  | — |  |
| United States | 2,774 |  |  | 603 |  |  | 513 |  |
| South Korea | 2,400 |  |  | 3,175 |  |  | 3,538 |  |
| Other foreign | 4,532 |  |  | 3,683 |  |  | 3,628 |  |
|  | $ | 24,273 |  |  | $ | 22,611 |  |  | $ | 22,258 |  |

[0001728949-19-000072:notes:190]
Reconciling items for revenues and EBT in a previous table were as follows (in millions):

[0001728949-19-000072:notes:191]
|  | 2019 |  | 2018 |  | 2017 |
| Revenues |  |  |  |  |  |
| Nonreportable segments | $ | 168 |  |  | $ | 287 |  |  | $ | 311 |  |
| Reduction to revenues related to BlackBerry arbitration decision | — |  |  | — |  |  | (962 | ) |
| Other unallocated revenues | 4,723 |  |  | (100 | ) |  | (95 | ) |
|  | $ | 4,891 |  |  | $ | 187 |  |  | $ | (746 | ) |
| EBT |  |  |  |  |  |
| Reduction to revenues related to BlackBerry arbitration decision | $ | — |  |  | $ | — |  |  | $ | (962 | ) |
| Other unallocated revenues | 4,723 |  |  | (100 | ) |  | (95 | ) |
| Unallocated cost of revenues | (430 | ) |  | (486 | ) |  | (517 | ) |
| Unallocated research and development expenses | (989 | ) |  | (1,154 | ) |  | (1,056 | ) |
| Unallocated selling, general and administrative expenses | (413 | ) |  | (576 | ) |  | (647 | ) |
| Unallocated other expenses (Note 2) | (414 | ) |  | (3,135 | ) |  | (1,742 | ) |
| Unallocated interest expense | (619 | ) |  | (761 | ) |  | (488 | ) |
| Unallocated investment and other income, net | 243 |  |  | 566 |  |  | 913 |  |
| Nonreportable segments | (61 | ) |  | (356 | ) |  | (373 | ) |
|  | $ | 2,040 |  |  | $ | (6,002 | ) |  | $ | (4,967 | ) |

[0001728949-19-000072:notes:192]
Certain revenues (and reduction to revenues) were not allocated to our segments in our management reports because they were not considered in evaluating segment results. Other unallocated revenues in fiscal 2019 were comprised of licensing revenues resulting from the settlement with Apple and its contract manufacturers. Other unallocated revenues in fiscal 2018 and 2017 were comprised of reductions to licensing revenues related to the portions of business arrangements that resolved legal disputes and were not allocated to our QTL segment. In fiscal 2017, we recognized a reduction to revenues related to an arbitration decision and resulting Joint Stipulation Regarding Final Award Agreement entered into with BlackBerry Limited, the substantial impact of which was not allocated to QTL.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001728949-19-000072:notes:193]
Beginning in fiscal 2019, we combined our Small Cells business, which sells products designed for the implementation of small cells to address the challenge of meeting the increased demand for mobile data, into our QCT segment. Revenues and operating results related to the Small Cells business were included in nonreportable segments through the end of fiscal 2018. Prior period segment information has not been adjusted to conform to the new segment presentation as such adjustments are insignificant.  
We report revenues from external customers by country based on the location to which our products or services are delivered, which for QCT is generally the country in which our customers manufacture their products, and for licensing revenues, the invoiced addresses of our licensees.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001728949-19-000072:notes:194]
Acquisitions 
On February 3, 2017 (the Closing Date), we completed the formation of a joint venture with TDK Corporation (TDK), under the name RF360 Holdings to enable delivery of radio frequency front-end (RFFE) modules and radio frequency (RF) filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others. Upon formation, the joint venture was owned 51% by Qualcomm Global Trading Pte. Ltd. (Qualcomm Global Trading), a Singapore corporation and wholly-owned subsidiary of ours, and 49% by EPCOS AG (EPCOS), a German wholly-owned subsidiary of TDK. We had the option to acquire (and EPCOS had an option to sell) EPCOS’s interest in the joint venture for $1.15 billion (Settlement Amount), beginning on August 4, 2019, for a period of 60 days (the Put and Call Option). The Put and Call Option was recorded as a liability at fair value as part of the total purchase price of $3.1 billion on the Closing Date. The liability was accreted to the Settlement Amount (with the offset recorded as interest expense) and was included in other current liabilities at September 30, 2018 (Note 2). On September 16, 2019, the Put and Call Option was exercised, and we acquired EPCOS’s remaining minority ownership interest in RF360 Holdings for $1.15 billion.

[0001728949-19-000072:notes:195]
At the Closing Date, we determined that RF360 Holdings was a variable interest entity, and its results of operations and statement of financial position have been included in our consolidated financial statements since its formation as the governance structure of RF360 Holdings provided us with the power to direct the activities of the joint venture that most significantly impacted its economic performance. Since the Put and Call Option was considered a financing of our purchase of EPCOS’s interest in RF360 Holdings, noncontrolling interest was not recorded in our consolidated financial statements.

[0001728949-19-000072:notes:196]
At the Closing Date, intangible assets acquired subject to amortization totaled $833 million, which primarily comprised of $738 million of technology-based intangible assets that are being amortized on a straight-line basis over the weighted-average useful lives of seven years.

[0001728949-19-000072:notes:197]
The following table presents the unaudited pro forma results for fiscal 2017. The unaudited pro forma financial information combines the results of operations of Qualcomm and RF360 Holdings as though the companies had been combined as of the beginning of fiscal 2016. The pro forma information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at such time. The unaudited pro forma results presented below include adjustments for the step-up of inventories to fair value, amortization and depreciation of identified intangible assets and property, plant and equipment, adjustments for certain acquisition-related charges, interest expense related to the Put and Call Option and related tax effects (in millions):

[0001728949-19-000072:notes:198]
|  | (Unaudited) |
|  | 2017 |
| Pro forma revenues | $ | 22,806 |  |
| Pro forma net income attributable to Qualcomm | $ | 2,614 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001728949-19-000072:notes:199]
lan
In the second quarter of fiscal 2018, we announced a Cost Plan designed to align our cost structure to our long-term margin targets. As part of this plan, we initiated a series of targeted actions across our businesses with the objective to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. Actions taken under this plan have been completed and resulted in us achieving substantially all of this target in fiscal 2019 based on our run rate exiting the second quarter of fiscal 2019, excluding litigation costs that were in excess of the baseline spend.

[0001728949-19-000072:notes:200]
Total restructuring and restructuring-related charges related to the Cost Plan were as follows (in millions):

[0001728949-19-000072:notes:201]
|  | 2019 |  | 2018 (1) |  | Total |
| Restructuring-related charges (2) | $ | 151 |  |  | $ | 334 |  |  | $ | 485 |  |
| Restructuring charges (3) | 62 |  |  | 353 |  |  | 415 |  |
|  | $ | 213 |  |  | $ | 687 |  |  | $ | 900 |  |

[0001728949-19-000072:notes:202]
| (1) | During fiscal 2018, we recorded restructuring and restructuring-related charges of $629 million in other expenses and charges of $58 million in investment and other income, net. |

[0001728949-19-000072:notes:203]
| (2) | Restructuring-related charges primarily related to asset impairment charges in fiscal 2019 and 2018 and also included a $52 million net gain in fiscal 2019 from the sale of certain assets related to wireless electric vehicle charging applications and the sale of our mobile health nonreportable segment, as well as a $41 million gain in fiscal 2018 resulting from fair value adjustments of certain |

[0001728949-19-000072:notes:204]
contingent consideration related to a business combination.

[0001728949-19-000072:notes:205]
| (3) | Restructuring charges primarily consisted of severance and consulting costs in fiscal 2019 and 2018, which were payable in cash. |

[0001728949-19-000072:notes:206]
The restructuring accrual, a portion of which was included in payroll and other benefits related liabilities with the remainder included in other current liabilities, is expected to be substantially paid within the next 12 months. At September 29, 2019 and September 30, 2018, the restructuring accrual was $17 million and $83 million, respectively.

[0001728949-19-000072:notes:207]
Note 12. Revision of Prior Period Financial Statements

[0001728949-19-000072:notes:208]
We revised certain prior period financial statements for an immaterial error related to the recognition of certain royalty revenues of our QTL segment (Note 1). A summary of revisions to our previously reported financial statements presented herein for comparative purposes is included below (in millions, except per share data).

[0001728949-19-000072:notes:209]
Revised Consolidated Balance Sheets.

[0001728949-19-000072:notes:210]
|  | As of September 30, 2018 |
|  | As reported |  | Adjustment |  | As revised |
| Deferred tax assets (noncurrent) | $ | 904 |  |  | $ | 32 |  |  | $ | 936 |  |
| Total assets | 32,686 |  |  | 32 |  |  | 32,718 |  |
| Other current liabilities | 6,825 |  |  | 153 |  |  | 6,978 |  |
| Total current liabilities | 11,236 |  |  | 153 |  |  | 11,389 |  |
| Total liabilities | 31,758 |  |  | 153 |  |  | 31,911 |  |
| Retained earnings | 663 |  |  | (121 | ) |  | 542 |  |
| Total stockholders’ equity | 928 |  |  | (121 | ) |  | 807 |  |
| Total liabilities and stockholders’ equity | 32,686 |  |  | 32 |  |  | 32,718 |  |

[0001728949-19-000072:notes:211]
Revised Consolidated Statements of Operations.

[0001728949-19-000072:notes:212]
|  | Year Ended |
|  | September 30, 2018 |  | September 24, 2017 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Licensing revenues | $ | 5,332 |  |  | $ | (121 | ) |  | $ | 5,211 |  |  | $ | 5,644 |  |  | $ | (33 | ) |  | $ | 5,611 |  |
| Total revenues | 22,732 |  |  | (121 | ) |  | 22,611 |  |  | 22,291 |  |  | (33 | ) |  | 22,258 |  |
| Operating income | 742 |  |  | (121 | ) |  | 621 |  |  | 2,614 |  |  | (33 | ) |  | 2,581 |  |
| Income before income taxes | 513 |  |  | (121 | ) |  | 392 |  |  | 3,020 |  |  | (33 | ) |  | 2,987 |  |
| Income tax expense | (5,377 | ) |  | 21 |  |  | (5,356 | ) |  | (555 | ) |  | 12 |  |  | (543 | ) |
| Net (loss) income | (4,864 | ) |  | (100 | ) |  | (4,964 | ) |  | 2,465 |  |  | (21 | ) |  | 2,444 |  |
| Net (loss) income attributable to Qualcomm | (4,864 | ) |  | (100 | ) |  | (4,964 | ) |  | 2,466 |  |  | (21 | ) |  | 2,445 |  |
| Basic (loss) earnings per share | (3.32 | ) |  | (0.07 | ) |  | (3.39 | ) |  | 1.67 |  |  | (0.01 | ) |  | 1.66 |  |
| Diluted (loss) earnings per share | (3.32 | ) |  | (0.07 | ) |  | (3.39 | ) |  | 1.65 |  |  | (0.01 | ) |  | 1.64 |  |

[0001728949-19-000072:notes:213]
Revised Consolidated Statements of Comprehensive Income (Loss).

[0001728949-19-000072:notes:214]
|  | Year Ended |
|  | September 30, 2018 |  | September 24, 2017 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Net (loss) income | $ | (4,864 | ) |  | $ | (100 | ) |  | $ | (4,964 | ) |  | $ | 2,465 |  |  | $ | (21 | ) |  | $ | 2,444 |  |
| Total comprehensive (loss) income | (4,983 | ) |  | (100 | ) |  | (5,083 | ) |  | 2,421 |  |  | (21 | ) |  | 2,400 |  |
| Comprehensive (loss) income attributable to Qualcomm | (4,983 | ) |  | (100 | ) |  | (5,083 | ) |  | 2,422 |  |  | (21 | ) |  | 2,401 |  |

[0001728949-19-000072:notes:215]
Revised Consolidated Statements of Cash Flows.

[0001728949-19-000072:notes:216]
We revised our consolidated statements of cash flows for the years ended September 30, 2018 and September 24, 2017 for this correction, which had no impact to net cash provided by operating activities in each such period.

[0001728949-19-000072:notes:217]
|  | Year Ended September 30, 2018 |
|  | As reported |  | Reclassification adjustment (1) |  | Revision adjustment |  | As revised |
| Operating Activities: |  |  |  |  |  |  |  |
| Net loss | $ | (4,864 | ) |  | $ | — |  |  | $ | (100 | ) |  | $ | (4,964 | ) |
| Income tax provision in excess of (less than) income tax payments | 4,502 |  |  | — |  |  | (21 | ) |  | 4,481 |  |
| Other items, net | 129 |  |  | (178 | ) |  | — |  |  | (49 | ) |
| Other assets | 30 |  |  | (6 | ) |  | — |  |  | 24 |  |
| Payroll, benefits and other liabilities | 687 |  |  | 197 |  |  | 121 |  |  | 1,005 |  |
| Net cash provided by operating activities | 3,895 |  |  | 13 |  |  | — |  |  | 3,908 |  |
|  | Year Ended September 24, 2017 |
|  | As reported |  | Reclassification adjustment (1) |  | Revision adjustment |  | As revised |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 2,465 |  |  | $ | — |  |  | $ | (21 | ) |  | $ | 2,444 |  |
| Income tax provision in excess of (less than) income tax payments | (400 | ) |  | — |  |  | (12 | ) |  | (412 | ) |
| Other items, net | 146 |  |  | (172 | ) |  | — |  |  | (26 | ) |
| Other assets | 169 |  |  | (33 | ) |  | — |  |  | 136 |  |
| Payroll, benefits and other liabilities | 2,103 |  |  | 205 |  |  | 33 |  |  | 2,341 |  |
| Net cash provided by operating activities | 5,001 |  |  | — |  |  | — |  |  | 5,001 |  |

[0001728949-19-000072:notes:218]
(1)     Certain previously reported amounts have been reclassified to conform to the current year presentation.

[0001728949-19-000072:notes:219]
Revised Segment Information. 
QTL segment results were revised for this correction (Note 8), which resulted in a decrease in QTL revenues and EBT (earnings before income taxes) of $121 million and $33 million for fiscal 2018 and 2017, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-19-000072:notes:220]
Fair Value Measurements
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at September 29, 2019 (in millions):

[0001728949-19-000072:notes:221]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 6,493 |  |  | $ | 4,084 |  |  | $ | — |  |  | $ | 10,577 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Auction rate securities | — |  |  | — |  |  | 35 |  |  | 35 |  |
| Equity and preferred securities | 418 |  |  | — |  |  | — |  |  | 418 |  |
| Total marketable securities | 418 |  |  | 4 |  |  | 35 |  |  | 457 |  |
| Derivative instruments | — |  |  | 25 |  |  | — |  |  | 25 |  |
| Other investments | 416 |  |  | — |  |  | 73 |  |  | 489 |  |
| Total assets measured at fair value | $ | 7,327 |  |  | $ | 4,113 |  |  | $ | 108 |  |  | $ | 11,548 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Other liabilities | 416 |  |  | — |  |  | 35 |  |  | 451 |  |
| Total liabilities measured at fair value | $ | 416 |  |  | $ | 1 |  |  | $ | 35 |  |  | $ | 452 |  |

[0001728949-19-000072:notes:222]
Activity within Level 3 of the Fair Value Hierarchy. Other investments and other liabilities included in Level 3 at September 29, 2019 and September 30, 2018 were comprised of convertible debt instruments issued by private companies and contingent consideration related to business combinations, respectively. Activity for marketable securities, other investments and other liabilities classified within Level 3 of the valuation hierarchy was insignificant during fiscal 2019, which was primarily related to issuances of convertible debt instruments by private companies and settlements of contingent consideration, and fiscal 2018, which was primarily related to settlements of convertible debt.

[0001728949-19-000072:notes:223]
Nonrecurring Fair Value Measurements. We measure certain assets and liabilities at fair value on a nonrecurring basis. These assets and liabilities include equity method and non-marketable equity investments, assets acquired, and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During fiscal 2019 and 2018, certain property, plant and equipment, non-marketable equity securities, intangible assets and goodwill were written down to their estimated fair values (Note 10). We also measured certain non-marketable equity securities received as non-cash consideration at fair value on a nonrecurring basis (Note 2). We determined the fair values using cost, market and income approaches. The estimation of fair value used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. We did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition for all periods presented.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001728949-19-000072:notes:224]
Summarized Quarterly Data (Unaudited)
The following financial information reflects all normal recurring adjustments that are, in the opinion of management, necessary for a fair statement of the results of the interim periods.

[0001728949-19-000072:notes:225]
The table below presents quarterly data for fiscal 2019 and 2018 (in millions, except per share data):

[0001728949-19-000072:notes:226]
|  | 1st Quarter |  | 2nd Quarter |  | 3rd Quarter |  | 4th Quarter |
| 2019 (1) |  |  |  |  |  |  |  |
| Revenues (2) | $ | 4,842 |  |  | $ | 4,982 |  |  | $ | 9,635 |  |  | $ | 4,814 |  |
| Operating income (2) | 710 |  |  | 940 |  |  | 5,317 |  |  | 701 |  |
| Net income (2) | 1,068 |  |  | 663 |  |  | 2,149 |  |  | 506 |  |
| Basic earnings per share (3): | $ | 0.88 |  |  | $ | 0.55 |  |  | $ | 1.77 |  |  | $ | 0.42 |  |
| Diluted earnings per share (3): | 0.87 |  |  | 0.55 |  |  | 1.75 |  |  | 0.42 |  |
| 2018 (1) (4) |  |  |  |  |  |  |  |
| Revenues | $ | 6,035 |  |  | $ | 5,220 |  |  | $ | 5,577 |  |  | $ | 5,778 |  |
| Operating (loss) income (5) | (4 | ) |  | 400 |  |  | 903 |  |  | (679 | ) |
| Net (loss) income (5) | (5,983 | ) |  | 330 |  |  | 1,202 |  |  | (513 | ) |
| Basic (loss) earnings per share (3): | $ | (4.05 | ) |  | $ | 0.22 |  |  | $ | 0.81 |  |  | $ | (0.36 | ) |
| Diluted (loss) earnings per share (3): | (4.05 | ) |  | 0.22 |  |  | 0.81 |  |  | (0.36 | ) |

[0001728949-19-000072:notes:227]
| (1) | Amounts, other than per share amounts, are rounded to millions each quarter. Therefore, the sum of the quarterly amounts may not equal the annual amounts reported. |

[0001728949-19-000072:notes:228]
| (2) | Revenues, operating income and net income in the third quarter of fiscal 2019 included licensing revenues recognized of $4.7 billion resulting from the settlement with Apple and its contract manufacturers. Operating income and net income in the third quarter of fiscal 2019 were impacted by a $275 million charge related to the 2019 EC Fine. Net income in the first quarter of fiscal 2019 was impacted by an income tax benefit of $570 million due to establishing new U.S. net deferred tax assets from making certain check-the-box elections. Net income in the third quarter of fiscal 2019 was impacted by a $2.5 billion charge to income tax expense resulting from the derecognition of a deferred tax asset related to the distributed intellectual property. |

[0001728949-19-000072:notes:229]
| (3) | Earnings (loss) per share and earnings per share attributable to Qualcomm are computed independently for each quarter and the full year based upon respective average shares outstanding. Therefore, the sum of the quarterly (loss) earnings per share amounts may not equal the annual amounts reported. |

[0001728949-19-000072:notes:230]
| (4) | As previously disclosed in our Quarterly Reports on Form 10-Q for the quarters ended December 30, 2018, March 31, 2019 and June 30, 2019, we revised certain prior period financial information for an immaterial error related to the recognition of certain royalty revenues of our QTL segment (Note 1). |

[0001728949-19-000072:notes:231]
(5)

[0001728949-19-000072:notes:232]
Operating loss and net loss in the fourth quarter of fiscal 2018 were impacted by a $2.0 billion charge related to the NXP termination fee. Net loss in the first quarter of fiscal 2018 was impacted by a $5.9 billion provisional charge to income tax expense due to the effects of the Tax Legislation. Additionally, operating income and net loss in the first quarter of fiscal 2018 were impacted by a $1.2 billion charge related to the 2018 EC fine.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001728949-19-000072:notes:233]
SCHEDULE II

[0001728949-19-000072:notes:234]
QUALCOMM Incorporated

[0001728949-19-000072:notes:235]
VALUATION AND QUALIFYING ACCOUNTS

[0001728949-19-000072:notes:236]
(In millions)

[0001728949-19-000072:notes:237]
|  | Balance atBeginning ofPeriod |  | Charged(Credited) toCosts andExpenses |  | Deductions |  | Balance atEnd ofPeriod |
| Year ended September 29, 2019 |  |  |  |  |  |  |  |
| Allowance on trade receivables | $ | 56 |  |  | $ | 3 |  |  | $ | (12 | ) |  | $ | 47 |  |
| Valuation allowance on deferred tax assets | 1,529 |  |  | 143 |  |  | — |  |  | 1,672 |  |
|  | $ | 1,585 |  |  | $ | 146 |  |  | $ | (12 | ) |  | $ | 1,719 |  |
| Year ended September 30, 2018 |  |  |  |  |  |  |  |
| Allowance on trade receivables | $ | 11 |  |  | $ | 45 |  |  | $ | — |  |  | $ | 56 |  |
| Valuation allowance on deferred tax assets | 863 |  |  | 666 |  |  | — |  |  | 1,529 |  |
|  | $ | 874 |  |  | $ | 711 |  |  | $ | — |  |  | $ | 1,585 |  |
| Year ended September 24, 2017 |  |  |  |  |  |  |  |
| Allowance on trade receivables | $ | 1 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 11 |  |
| Valuation allowance on deferred tax assets | 754 |  |  | 109 |  |  | — |  |  | 863 |  |
|  | $ | 755 |  |  | $ | 119 |  |  | $ | — |  |  | $ | 874 |  |
