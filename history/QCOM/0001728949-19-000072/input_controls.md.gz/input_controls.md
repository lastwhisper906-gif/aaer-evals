# QCOM 10-K controls and the auditor's report


## auditors_report

[0001728949-19-000072:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001728949-19-000072:auditors_report:2]
To the Board of Directors and Stockholders of QUALCOMM Incorporated:

[0001728949-19-000072:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001728949-19-000072:auditors_report:4]
We have audited the accompanying consolidated balance sheets of QUALCOMM Incorporated and its subsidiaries as of September 29, 2019 and September 30, 2018, and the related consolidated statements of operations, comprehensive income (loss), stockholders’ equity and cash flows for each of the three years in the period ended September 29, 2019, including the related notes and financial statement schedule listed in the index appearing under Item 15(a)(2) (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of September 29, 2019, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001728949-19-000072:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of September 29, 2019 and September 30, 2018 and the results of their operations and their cash flows for each of the three years in the period ended September 29, 2019 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of September 29, 2019, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001728949-19-000072:auditors_report:6]
Change in Accounting Principle

[0001728949-19-000072:auditors_report:7]
As discussed in Note 1 to the consolidated financial statements, the Company changed the manner in which it accounts for revenues from contracts with customers in fiscal 2019.

[0001728949-19-000072:auditors_report:8]
As discussed in Note 1 to the consolidated financial statements, the Company changed the manner in which it accounts for income tax effects of intra-entity transfers of assets other than inventory in fiscal 2019.

[0001728949-19-000072:auditors_report:9]
Basis for Opinions

[0001728949-19-000072:auditors_report:10]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (“PCAOB”) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001728949-19-000072:auditors_report:11]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001728949-19-000072:auditors_report:12]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001728949-19-000072:auditors_report:13]
Definition and Limitations of Internal Control over Financial Reporting

[0001728949-19-000072:auditors_report:14]
F-1

[0001728949-19-000072:auditors_report:15]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001728949-19-000072:auditors_report:16]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001728949-19-000072:auditors_report:17]
Critical Audit Matters

[0001728949-19-000072:auditors_report:18]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that (i) relate to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001728949-19-000072:auditors_report:19]
Income Taxes

[0001728949-19-000072:auditors_report:20]
As described in Notes 1 and 3 to the consolidated financial statements, the Company is subject to income taxes in the United States and numerous foreign jurisdictions, and the assessment of tax positions involves dealing with uncertainties in the application of complex tax laws and regulations which are subject to legal and factual interpretation, judgment and uncertainty. The Company recorded a provision for income taxes of $3.1 billion for the year ended September 29, 2019 and net deferred tax assets of $1.1 billion, including a valuation allowance of $1.7 billion, a noncurrent income taxes receivable of $1.4 billion, and unrecognized tax benefits of $1.7 billion as of September 29, 2019. Significant judgments and estimates are required when determining the provision for income taxes and other tax positions, which includes the application of complex tax laws and regulations (including new temporary regulations and evolution of court rulings), special deductions such as FDII (foreign-derived intangible income), tax incentives, intercompany research and development cost-sharing arrangements, transfer pricing, tax credits and the realizability of deferred tax assets.

[0001728949-19-000072:auditors_report:21]
The principal considerations for our determination that performing procedures relating to income taxes is a critical audit matter are the matter involved significant judgment by management when assessing complex tax laws and regulations (including new temporary regulations and recent court rulings) and special deductions such as FDII, transfer pricing and tax credits as it relates to determining the provision for income taxes and other tax positions. This led to a high degree of auditor judgment and significant audit effort in performing our procedures over income taxes, including the use of professionals with specialized skill and knowledge to assist in evaluating the audit evidence obtained from these procedures.

[0001728949-19-000072:auditors_report:22]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. The procedures included testing the effectiveness of controls relating to the provision of income taxes and other tax positions. The procedures also included, among others, testing the provision for income taxes, including the effective tax rate reconciliation, permanent and temporary differences, inspecting correspondence with tax regulators and external tax advisors, and testing the underlying data and evaluating the significant assumptions used in establishing and measuring tax-related assets and liabilities, including the application of new temporary regulations and recent court rulings. Professionals with specialized skill and knowledge were used to assist in evaluating the application of relevant tax laws, the provision for income taxes and the reasonableness of management’s assessments of whether certain tax positions are more-likely-than-not of being sustained.

[0001728949-19-000072:auditors_report:23]
Legal and Regulatory Proceedings

[0001728949-19-000072:auditors_report:24]
As described in Notes 1 and 7 to the consolidated financial statements, the Company is currently involved in certain legal and regulatory proceedings. If there is at least a reasonable possibility that a material loss may have been incurred associated with

[0001728949-19-000072:auditors_report:25]
F-2

[0001728949-19-000072:auditors_report:26]
a pending legal and regulatory proceeding, management discloses such fact, and if reasonably estimable, management provides an estimate of the possible loss or range of possible loss. Management records the best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of a loss can be reasonably estimated with no best estimate in the range, management records the minimum estimated liability. As additional information becomes available, management assesses the potential liability related to pending legal or regulatory proceedings, and revises the estimates and updates the disclosures accordingly. Significant judgment is required by management in both the determination of probability of loss and the determination as to whether a loss is reasonably estimable.

[0001728949-19-000072:auditors_report:27]
The principal considerations for our determination that performing procedures relating to legal and regulatory proceedings is a critical audit matter are the matter involved significant judgment by management when assessing the likelihood of a loss being incurred and when determining whether a reasonable estimate of the loss or range of loss can be made. This led to a high degree of auditor judgment, subjectivity and significant audit effort in evaluating management’s assessment of the loss contingencies associated with the legal and regulatory proceedings.

[0001728949-19-000072:auditors_report:28]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to management’s evaluation of legal and regulatory proceedings, including controls over determining whether a loss is probable and whether the amount of loss can be reasonably estimated, including related financial statement disclosures. These procedures also included, among others: obtaining and evaluating the letters of audit inquiry with external and internal legal counsel, reading certain correspondence the Company received from regulators, reading certain documents the Company has filed with the courts and related counterparty filings, evaluating the reasonableness of management’s process for identifying and assessing loss contingencies regarding whether an unfavorable outcome is probable and reasonably estimable, and evaluating the sufficiency of the Company’s legal and regulatory proceedings disclosures in the consolidated financial statements.

[0001728949-19-000072:auditors_report:29]
Revenue Recognition - Estimation of Sales-based Royalty Revenues

[0001728949-19-000072:auditors_report:30]
As described in Note 1 to the consolidated financial statements, a vast majority of the $4.6 billion of the Qualcomm Technology Licensing (QTL) segment’s revenues for the year ended September 29, 2019 related to sales-based royalty arrangements and is recognized as revenues when a contract exists and to the extent it is probable that a significant reversal of cumulative revenues will not occur. As disclosed in the financial statements, the Company grants licenses or otherwise provides rights to use portions of its intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using the licensed intellectual property, which are generally based upon a percentage of the licensee’s selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). If a contract is determined to exist, management estimates and recognizes sales-based royalties on such licensed products in the period in which the associated sales by the licensee occur, subject to certain constraints on management’s ability to estimate such royalties. As certain licensees have disputed, underreported, underpaid, not reported and/or not paid royalties owed to the Company under their license agreements, management applied significant judgment to determine whether a contract exists and, if so, the extent to which those revenues are constrained. Management analyzes the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrains the amount of estimated revenues recognized, which may result in recognizing revenues less than amounts contractually owed to the Company.

[0001728949-19-000072:auditors_report:31]
The principal considerations for our determination that performing procedures relating to the estimation of sales-based royalty revenues for revenue recognition is a critical audit matter are there was significant judgment by management when determining whether a contract exists and in developing the estimate of sales-based royalties. This in turn led to significant auditor judgment, subjectivity and significant audit effort in performing procedures to evaluate the estimate of sales-based royalties, including management’s assessment of the existence of a contract and significant assumptions related to the extent of any constraint.

[0001728949-19-000072:auditors_report:32]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. The procedures included testing the effectiveness of controls relating to the revenue recognition process, including the estimation of sales-based royalty revenues. The procedures also included, among others, testing management’s process for determining the existence of a contract and management’s estimate of sales-based royalties including evaluating the reasonableness of significant assumptions related to whether any further constraints are

[0001728949-19-000072:auditors_report:33]
F-3

[0001728949-19-000072:auditors_report:34]
required and testing the underlying data used in management’s estimate for a sample of contracts. Evaluating management’s assumptions related to the constraints involved evaluating whether the constraints assumptions used by management were reasonable considering disputes with certain licensees and the impact of any existing litigation on the estimate of sales-based royalties. Evaluating the reasonableness of the estimate of sales-based royalties also involved assessing management’s ability to reasonably estimate those revenues by performing a comparison of the estimate for the prior reporting period to the actual royalties reported by licensees in the subsequent period for a sample of contracts.

[0001728949-19-000072:auditors_report:35]
/s/ PricewaterhouseCoopers LLP

[0001728949-19-000072:auditors_report:36]
San Diego, California

[0001728949-19-000072:auditors_report:37]
November 6, 2019

[0001728949-19-000072:auditors_report:38]
We have served as the Company’s auditor since 1985.

[0001728949-19-000072:auditors_report:39]
F-4

[0001728949-19-000072:auditors_report:40]
QUALCOMM Incorporated


## item_9a

[0001728949-19-000072:item_9a:1]
Item 9A. Controls and Procedures

[0001728949-19-000072:item_9a:2]
Conclusion Regarding the Effectiveness of Disclosure Controls and Procedures

[0001728949-19-000072:item_9a:3]
Under the supervision and with the participation of our management, including our principal executive officer and our principal financial officer, we conducted an evaluation of our disclosure controls and procedures, as such terms are defined under Rule 13a-15(e) promulgated under the Securities Exchange Act of 1934, as amended (the Exchange Act). Based on this evaluation, our principal executive officer and our principal financial officer concluded that our disclosure controls and procedures were effective as of the end of the period covered by this Annual Report.

[0001728949-19-000072:item_9a:4]
Management’s Report on Internal Control over Financial Reporting

[0001728949-19-000072:item_9a:5]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). Under the supervision and with the participation of our management, including our principal executive officer and our principal financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting based on the framework in Internal Control — Integrated Framework (2013)

[0001728949-19-000072:item_9a:6]
59

[0001728949-19-000072:item_9a:7]
issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on our evaluation under this framework, our management concluded that our internal control over financial reporting was effective as of September 29, 2019.

[0001728949-19-000072:item_9a:8]
PricewaterhouseCoopers LLP, the independent registered public accounting firm that audited our consolidated financial statements included in this Annual Report, has also audited the effectiveness of our internal control over financial reporting as of September 29, 2019, as stated in its report which appears on pages F-1 through F-4 in this Annual Report.

[0001728949-19-000072:item_9a:9]
Inherent Limitations over Internal Controls

[0001728949-19-000072:item_9a:10]
Our internal control over financial reporting is designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of consolidated financial statements for external purposes in accordance with generally accepted accounting principles. Our internal control over financial reporting includes those policies and procedures that:

[0001728949-19-000072:item_9a:11]
| i. | pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of our assets; |

[0001728949-19-000072:item_9a:12]
| ii. | provide reasonable assurance that transactions are recorded as necessary to permit preparation of consolidated financial statements in accordance with generally accepted accounting principles, and that our receipts and expenditures are being made only in accordance with authorizations of our management and directors; and |

[0001728949-19-000072:item_9a:13]
| iii. | provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on the consolidated financial statements. |

[0001728949-19-000072:item_9a:14]
Internal control over financial reporting cannot provide absolute assurance of achieving financial reporting objectives because of its inherent limitations, including the possibility of human error and circumvention by collusion or overriding of controls. Accordingly, even an effective internal control system may not prevent or detect material misstatements on a timely basis. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions or that the degree of compliance with the policies or procedures may deteriorate.

[0001728949-19-000072:item_9a:15]
Changes in Internal Control over Financial Reporting

[0001728949-19-000072:item_9a:16]
There were no changes in our internal control over financial reporting during the fourth quarter of fiscal 2019 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
