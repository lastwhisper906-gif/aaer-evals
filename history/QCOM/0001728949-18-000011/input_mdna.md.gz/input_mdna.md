# QCOM MD&A — 0001728949-18-000011


## mdna

[0001728949-18-000011:mdna:1]
[same as prior period, unchanged from 0001234452-17-000154:mdna:1]

[0001728949-18-000011:mdna:2]
This information should be read in conjunction with the condensed consolidated financial statements and the notes thereto included in “Part I, Item 1” of this Quarterly Report and with “Management’s Discussion and Analysis of Financial Condition and Results of Operations” for the year ended September 24, 2017 contained in our 2017 Annual Report on Form 10-K.

[0001728949-18-000011:mdna:3]
This Quarterly Report (including, but not limited to, this section regarding Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements regarding our business, investments, financial condition, results of operations and prospects. Additionally, statements concerning future matters, such as the development of new products, enhancements of technologies, industry and market trends, sales levels, expense levels and other statements regarding matters that are not historical, are forward-looking statements. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001728949-18-000011:mdna:4]
First Quarter of Fiscal 2018 Overview

[0001728949-18-000011:mdna:5]
Revenues for the first quarter of fiscal 2018 were $6.1 billion, an increase of 1% compared to the year ago quarter, with loss before income taxes of $27 million, compared to earnings before taxes of $870 million in the year ago quarter, and net loss of $6.0 billion, compared to net income of $681 million in the year ago quarter. Highlights and other events from the first quarter of fiscal 2018 included:

[0001728949-18-000011:mdna:6]
| • | The transition of wireless networks and devices to 3G/4G (CDMA single-mode, OFDMA single-mode and CDMA/OFDMA multi-mode) continued around the world. 3G/4G connections grew sequentially by approximately 4% to approximately 4.8 billion, which was approximately 62% of total mobile connections at the end of the first quarter of fiscal 2018.(1) |

[0001728949-18-000011:mdna:7]
| • | We continue to invest significant resources toward advancements primarily in support of 4G- and 5G-based technologies as well as other technologies to extend the demand for our products and generate new or expanded licensing opportunities, including within adjacent industry segments outside traditional cellular industries, such as automotive, the Internet of Things (IoT) and networking. |

[0001728949-18-000011:mdna:8]
| • | QCT results were positively impacted by higher modem sales for the new iPhone product launch and results from our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017. |

[0001728949-18-000011:mdna:9]
| • | QTL results were negatively impacted by our continued dispute with Apple and its contract manufacturers (who are Qualcomm licensees), as well as the previously disclosed dispute with another licensee. We did not record any revenues in the first quarter of fiscal 2018 for royalties due on sales of Apple’s or the other licensee’s products. |

[0001728949-18-000011:mdna:10]
| • | On December 22, 2017, tax reform legislation known as the Tax Cuts and Jobs Act (the Tax Legislation) was enacted in the United States (U.S.). As a result of such enactment, net loss for the first quarter of fiscal 2018 included an estimated $6.0 billion charge to income tax expense comprised of a one-time tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge) of $5.3 billion,a charge of $562 million resulting from the remeasurement of deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate tax rate and $86 million resulting from our decision to no longer indefinitely reinvest certain foreign earnings. We currently estimate that we will pay $3.3 billion for the Toll Charge, after application of certain tax credits (including those that are expected to be generated in fiscal 2018), which is payable in installments over eight years beginning on January 15, 2019. Such amounts are subject to change, possibly materially, during a |

[0001728949-18-000011:mdna:11]
[same as prior period, unchanged from 0001234452-17-000154:mdna:21]

[0001728949-18-000011:mdna:12]
one-year measurement period. Further, our federal statutory income tax rate for fiscal 2018 reflects a blended rate of approximately 25%.

[0001728949-18-000011:mdna:13]
| • | On January 24, 2018, the European Commission (EC) issued a decision finding that certain terms of an agreement with a customer violate European Union competition law and imposed a fine of approximately 997 million Euros (approximately $1.2 billion based on the exchange rate at December 24, 2017), which was recorded as a charge to other expenses in the first quarter of fiscal 2018. We intend to appeal the EC’s decision to the General Court of the European Union. |

[0001728949-18-000011:mdna:14]
| (1) | According to GSMA Intelligence estimates as of January 29, 2018 (estimates excluded Wireless Local Loop). |

[0001728949-18-000011:mdna:15]
[same as prior period, unchanged from 0001234452-17-000154:mdna:15]

[0001728949-18-000011:mdna:16]
We develop and commercialize foundational technologies and products used in mobile devices and other wireless products, including network equipment, broadband gateway equipment and consumer electronics devices. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents, software and other rights.

[0001728949-18-000011:mdna:17]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices, wireless networks, devices used in IoT, broadband gateway equipment, consumer electronic devices and automotive telematics and infotainment systems. QTL grants licenses to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including our mobile health, data center, small cell and other wireless technology and service initiatives.

[0001728949-18-000011:mdna:18]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering, research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001728949-18-000011:mdna:19]
Seasonality. Many of our products and/or intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has tended historically to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons; and because QTL recognizes royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made in the fourth calendar quarter. We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 4G networks by wireless operators and the timing of launches of flagship wireless devices that incorporate our products and/or intellectual property. These seasonal trends for QTL may be impacted by disputes and/or resolutions with licensees. These trends may or may not continue in the future.

[0001728949-18-000011:mdna:20]
[same as prior period, unchanged from 0001234452-17-000154:mdna:44]

[0001728949-18-000011:mdna:21]
| Revenues (in millions) |
|  | Three Months Ended |
|  | December 24, 2017 |  | December 25, 2016 |  | Change |
| Equipment and services | $ | 4,704 |  |  | $ | 4,139 |  |  | $ | 565 |  |
| Licensing | 1,364 |  |  | 1,860 |  |  | (496 | ) |
|  | $ | 6,068 |  |  | $ | 5,999 |  |  | $ | 69 |  |

[0001728949-18-000011:mdna:22]
The increase in equipment and services revenues was primarily due to an increase in QCT revenues. The decrease in licensing revenues was primarily due to a decrease in QTL revenues.

[0001728949-18-000011:mdna:23]
| Costs and Expenses (in millions) |
|  | Three Months Ended |
|  | December 24, 2017 |  | December 25, 2016 |  | Change |
| Cost of revenues | $ | 2,663 |  |  | $ | 2,443 |  |  | $ | 220 |  |
| Gross margin | 56 | % |  | 59 | % |  |  |

[0001728949-18-000011:mdna:24]
Margin percentage decreased primarily due to a decrease in higher margin QTL licensing revenues as a proportion of total revenues, partially offset by an increase in QCT margin percentage. Our margin percentage may continue to fluctuate in future periods depending on the mix of segment results as well as products sold, competitive pricing, new product introduction costs and other factors, including disputes and/or resolutions with licensees.

[0001728949-18-000011:mdna:25]
|  | Three Months Ended |
|  | December 24, 2017 |  | December 25, 2016 |  | Change |
| Research and development | $ | 1,420 |  |  | $ | 1,311 |  |  | $ | 109 |  |
| % of revenues | 23 | % |  | 22 | % |  |  |
| Selling, general and administrative | $ | 773 |  |  | $ | 591 |  |  | $ | 182 |  |
| % of revenues | 13 | % |  | 10 | % |  |  |
| Other | $ | 1,183 |  |  | $ | 876 |  |  | $ | 307 |  |

[0001728949-18-000011:mdna:26]
The dollar increase in research and development expenses was primarily attributable to an increase of $141 million in costs related to the development of integrated circuit technologies, including 5G technology and radio frequency front-end (RFFE) technologies from our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017, and related software products, partially offset by a $30 million impairment charge on certain intangible assets recorded in the first quarter of fiscal 2017.

[0001728949-18-000011:mdna:27]
The dollar increase in selling, general and administrative expenses was primarily attributable to increases of $60 million in costs related to litigation and other legal matters, primarily related to our licensing business, $45 million in bad debt expenses, $22 million in marketing expenses and $18 million in employee-related expenses, which included our RF360 Holdings joint venture.

[0001728949-18-000011:mdna:28]
Other expenses in the first quarter of fiscal 2018 consisted of a $1.2 billion charge related to the European Commission fine. Other expenses in the first quarter of fiscal 2017 consisted of a $868 million charge related to the Korea Fair Trade Commission (KFTC) fine and $8 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan.

[0001728949-18-000011:mdna:29]
| Interest Expense and Investment and Other Income, Net (in millions) |
|  | Three Months Ended |
|  | December 24, 2017 |  | December 25, 2016 |  | Change |
| Interest expense | $ | 170 |  |  | $ | 90 |  |  | $ | 80 |  |
| Investment and other income, net |  |  |  |  |  |
| Interest and dividend income | $ | 126 |  |  | $ | 167 |  |  | $ | (41 | ) |
| Net realized gains on marketable securities | 10 |  |  | 139 |  |  | (129 | ) |
| Net realized gains on other investments | 13 |  |  | 8 |  |  | 5 |  |
| Impairment losses on marketable securities and other investments | (9 | ) |  | (143 | ) |  | 134 |  |
| Equity in net (losses) earnings of investees | (21 | ) |  | 3 |  |  | (24 | ) |
| Net losses on foreign currency transactions | (4 | ) |  | — |  |  | (4 | ) |
| Net (losses) gains on derivative instruments | (1 | ) |  | 8 |  |  | (9 | ) |
|  | $ | 114 |  |  | $ | 182 |  |  | $ | (68 | ) |

[0001728949-18-000011:mdna:30]
The increase in interest expense was primarily attributable to the issuance of an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes in May 2017. In the first quarter of fiscal 2017, we began divesting a

[0001728949-18-000011:mdna:31]
[same as prior period, unchanged from 0001234452-17-000154:mdna:39]

[0001728949-18-000011:mdna:32]
substantial portion of our marketable securities portfolio in order to finance, in part, the proposed acquisition of NXP. As a result, we recognized net realized gains and impairment losses on such marketable securities that we sold and expected to sell before their anticipated recovery, respectively, in fiscal 2017.

[0001728949-18-000011:mdna:33]
| Income Tax Expense (in millions) |
|  | Three Months Ended |
|  | December 24, 2017 |  | December 25, 2016 |  | Change |
| Income tax expense | $ | 5,926 |  |  | $ | 189 |  |  | $ | 5,737 |  |
| Effective tax rate | N/M |  | 22 | % |  | N/M |

[0001728949-18-000011:mdna:34]
N/M - Not meaningful

[0001728949-18-000011:mdna:35]
The Tax Legislation enacted on December 22, 2017 significantly revises the U.S. corporate income tax by, among other things, lowering the corporate income tax rate to 21% effective January 1, 2018, implementing a modified territorial tax system and imposing a one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge). As a fiscal-year taxpayer, certain provisions of the Tax Legislation impacted us in fiscal 2018, including the change in the corporate income tax rate and the Toll Charge, while other provisions will be effective starting at the beginning of fiscal 2019, including the implementation of a modified territorial tax system. Accordingly, our federal statutory income tax rate for fiscal 2018 reflects a blended rate of approximately 25%.

[0001728949-18-000011:mdna:36]
We have preliminarily accounted for the effects of the Tax Legislation, which resulted in a charge of $5.9 billion to income tax expense in the first quarter of fiscal 2018, comprised of $5.3 billion related to the estimated Toll Charge and $562 million resulting from the estimated impact of remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate.

[0001728949-18-000011:mdna:37]
Our annual effective tax rate is estimated to be approximately 297% for fiscal 2018, as compared to the 18% effective income tax rate for fiscal 2017, primarily as a result of the estimated charge of $6.0 billion recorded to income tax expense in the first quarter of fiscal 2018 related to the combined effect of the Toll Charge, the remeasurement of deferred tax assets and liabilities and our decision to no longer indefinitely reinvest certain foreign earnings, all of which resulted from the Tax Legislation. Our annual effective tax rate was also impacted by the $1.2 billion fine related to the EC investigation, which is not deductible for tax purposes and is attributable to a foreign jurisdiction. Tax benefits from foreign income taxed at rates lower than rates in the U.S. are expected to be approximately 20% in fiscal 2018, compared to 32% in fiscal 2017, primarily due to the lower U.S federal statutory income tax rate enacted by the Tax Legislation, partially offset by lower estimated U.S. revenues primarily related to decreased royalty revenues from Apple’s contract manufacturers. The estimated annual effective tax rate for fiscal 2018 also reflects a blended U.S federal statutory income tax rate of 25% as a result of the Tax Legislation and the increase in our Singapore tax rate as a result of the expiration of certain tax incentives in March 2017. The annual effective tax rate of 18% for fiscal 2017 reflected the KFTC and TFTC fines (see “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” in this Quarterly Report) of $927 million and $778 million, respectively, which were not deductible for tax purposes and were each attributable to both the U.S. and foreign jurisdictions.

[0001728949-18-000011:mdna:38]
The effective tax rate for the first quarter of fiscal 2018 was higher than the estimated annual effective tax rate primarily resulting from the estimated charge of $6.0 billion recorded to income tax expense in the first quarter of fiscal 2018 related to the effects of certain components of the Tax Legislation, as well as the $1.2 billion fine related to the EC investigation.

[0001728949-18-000011:mdna:39]
The effective tax rate of 22% for the first quarter of fiscal 2017 reflected tax benefits from foreign income taxed at rates lower than rates in the U.S. of 15%, as well as the $868 million charge related to the KFTC fine.

[0001728949-18-000011:mdna:40]
Unrecognized tax benefits were $342 million and $372 million at December 24, 2017 and September 24, 2017, respectively. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at December 24, 2017 may increase or decrease in the next 12 months.

[0001728949-18-000011:mdna:41]
We are subject to income taxes in the U.S. and numerous foreign jurisdictions, and are currently under examination by various tax authorities worldwide, most notably in countries where we earn a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2000. We continually assess the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of December 24, 2017, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0001728949-18-000011:mdna:42]
[same as prior period, unchanged from 0001234452-17-000154:mdna:64]

[0001728949-18-000011:mdna:43]
The following should be read in conjunction with the financial results for the first quarter of fiscal 2018 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0001728949-18-000011:mdna:44]
|  | Three Months Ended |
| (in millions) | December 24, 2017 |  | December 25, 2016 |
| Revenues |  |  |  |
| QCT | $ | 4,651 |  |  | $ | 4,101 |  |
| QTL | 1,299 |  |  | 1,811 |  |
| QSI | 30 |  |  | 14 |  |
| EBT (1) |  |  |  |
| QCT | $ | 955 |  |  | $ | 724 |  |
| QTL | 887 |  |  | 1,532 |  |
| QSI | 11 |  |  | (17 | ) |
| EBT as a % of revenues |  |  |  |
| QCT | 21 | % |  | 18 | % |
| QTL | 68 | % |  | 85 | % |

[0001728949-18-000011:mdna:45]
[same as prior period, unchanged from 0001234452-17-000154:mdna:67]

[0001728949-18-000011:mdna:46]
QCT Segment. The increase in QCT revenues was due to a corresponding fluctuation in equipment and services revenues. Equipment and services revenues, mostly related to sales of Mobile Station Modem (MSM) and accompanying Radio Frequency (RF), Power Management (PM) and wireless connectivity integrated circuits, were $4.60 billion and $4.06 billion in the first quarter of fiscal 2018 and 2017, respectively. Approximately 237 million and 217 million MSM integrated circuits were sold during the first quarter of fiscal 2018 and 2017, respectively. The increase in equipment and services revenues was primarily due to an increase in revenues related to RFFE products of $433 million, primarily due to revenues from our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017, and an increase of $285 million related to higher MSM and accompanying PM unit shipments, primarily resulting from an increase in shipments to Apple. The increase in equipment and services revenues was partially offset by a decrease of $162 million resulting from the net impact of lower average selling prices and favorable product mix.

[0001728949-18-000011:mdna:47]
QCT EBT as a percentage of revenues increased primarily due to an increase in gross margin percentage and the favorable impact of higher revenues relative to operating expenses. The increase in QCT gross margin percentage was primarily due to lower average unit costs and favorable product mix, partially offset by lower average selling prices.

[0001728949-18-000011:mdna:48]
QCT accounts receivable decreased by 29% in the first quarter of fiscal 2018 from $1.81 billion to $1.28 billion, primarily due to the timing of integrated circuit shipments and the collection of receivables related to integrated circuits. QCT inventories decreased by 8% in the first quarter of fiscal 2018 from $2.02 billion to $1.85 billion primarily due to a decrease in the overall quantity of units on hand.

[0001728949-18-000011:mdna:49]
QTL Segment. QTL results were negatively impacted by our continued dispute with Apple and its contract manufacturers (who are Qualcomm licensees), as well as the previously disclosed dispute with another licensee. We did not record any revenues in the first quarter of fiscal 2018 for royalties due on sales of Apple’s or the other licensee’s products. Revenues related to the products of Apple’s contract manufacturers and the other licensee in dispute comprised approximately $740 million in the first quarter of fiscal 2017. Excluding the impact of these disputes, QTL revenues increased primarily as a result of increases in reported sales of CDMA-based products (including multi-mode products that also implement OFDMA) and revenues per reported unit.

[0001728949-18-000011:mdna:50]
QTL EBT as a percentage of revenues decreased primarily due to the decrease in QTL revenues and an increase in selling, general and administrative expenses resulting from higher legal costs and bad debt expense related to a licensee that is facing significant financial difficulties. QTL revenues and EBT also continued to be impacted negatively by units that we believe are not being reported by certain other licensees and sales of certain unlicensed products. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing, particularly in emerging regions, including China, and additional litigation may become necessary if negotiations fail to resolve the relevant issues.

[0001728949-18-000011:mdna:51]
QSI Segment. The increase in QSI EBT was primarily due to the net impact of $10 million resulting from higher revenues and costs associated with certain development contracts with one of our equity method investees and the combined impact of $22 million resulting from higher net realized gains on investments and lower impairment losses.

[0001728949-18-000011:mdna:52]
[same as prior period, unchanged from 0001234452-17-000154:mdna:27]

[0001728949-18-000011:mdna:53]
We expect continued growth in the coming years in consumer demand for 3G, 3G/4G multi-mode and 4G products and services around the world, driven primarily by smartphones. We also expect growth in new device categories and industries, driven by the expanding adoption of certain technologies that are already commonly used in smartphones by industry segments outside traditional cellular industries, such as automotive, IoT and networking. As we look forward to the next several months and beyond, we expect our business to be impacted by the following key items:

[0001728949-18-000011:mdna:54]
| • | On November 6, 2017, Broadcom Limited (Broadcom) announced an unsolicited proposal (the Proposed Transaction) to acquire all of the outstanding shares of our common stock for per share consideration of $70.00, consisting of $60.00 in cash and $10.00 in Broadcom shares. On November 12, 2017, following a comprehensive review conducted in consultation with financial and legal advisors, our Board of Directors unanimously rejected the Proposed Transaction, concluding that it dramatically undervalues the Company. Following our announcement on November 13, 2017, Broadcom announced that it remains fully committed to pursuing its acquisition of Qualcomm for the consideration offered on November 6, 2017. Additionally, on December 11, 2017, Broadcom filed preliminary proxy materials with the Securities and Exchange Commission in connection with its planned solicitation of proxies to elect 11 nominees to our Board of Directors at our 2018 Annual Meeting of Stockholders to be held on March 6, 2018. On December 22, 2017, we announced that our Board of Directors, following the recommendation of the Board’s Governance Committee, unanimously determined not to nominate any of the 11 candidates assembled by Broadcom to replace our current directors. Responding to the Proposed Transaction has required, and may continue to require, that we devote significant resources and management time and attention and incur additional expenses and costs. |

[0001728949-18-000011:mdna:55]
| • | On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings, B.V., an indirect, wholly owned subsidiary of QUALCOMM Incorporated, will acquire NXP Semiconductors N.V. (NXP). Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration to be paid to NXP’s shareholders of $38 billion. NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products. The transaction is subject to receipt of regulatory clearance under applicable laws and other closing conditions, including the tender of at least 80% of the issued and outstanding common shares of NXP in the offer (provided that the minimum tender threshold may be reduced to a percentage not less than 70% with the prior written consent of NXP). The transaction is expected to close in early 2018. We intend to fund the transaction with cash generated from our May 2017 debt offering as well as cash, cash equivalents and marketable securities held by our foreign entities and use of a Term Loan, which we expect to draw on at close. We expect that this acquisition will continue to require us to devote significant resources and management time and attention and utilize a substantial portion of our cash, cash equivalents and marketable securities. |

[0001728949-18-000011:mdna:56]
| • | On January 16, 2018, we announced a cost reduction plan designed to align our cost structure to our long-term margin targets. As part of this plan, we will implement a series of targeted reductions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. We expect these cost reductions to be fully captured in fiscal 2019. We are in the process of finalizing our plan, as well as the restructuring and restructuring-related costs we expect to incur to execute our plan. |

[0001728949-18-000011:mdna:57]
| • | Regulatory authorities in certain jurisdictions continue to investigate our business practices, and other regulatory authorities may do so in the future. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business with remedies that include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Additionally, certain of our direct and indirect customers and licensees, including Apple, have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, including monetary damages. These activities have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” included in this Quarterly Report. |

[0001728949-18-000011:mdna:58]
[same as prior period, unchanged from 0001234452-17-000154:mdna:63]

[0001728949-18-000011:mdna:59]
| • | We are currently in dispute with Apple surrounding what we believe is an attempt by Apple to reduce the amount of royalties that its contract manufacturers (who are Qualcomm licensees) are required to pay to us for use of our intellectual property. Such contract manufacturers did not fully report and did not pay royalties due on sales of Apple products. We have taken action against Apple’s contract manufacturers, to compel such licensees to pay the required royalties, and against Apple, as described more fully elsewhere in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6.” Additionally, the other licensee in dispute did not report or pay royalties due in the first quarter of fiscal 2018. We did not record any revenues in the first quarter of fiscal 2018 for royalties due on sales of Apple’s or the other licensee’s products, and as a result, QTL revenues and EBT were negatively impacted by these continued disputes. We expect these companies will continue to take such actions in the future, resulting in increased legal costs and negatively impacting our future revenues, as well as our financial condition, results of operations and cash flows until the respective disputes are resolved. |

[0001728949-18-000011:mdna:60]
| • | We continue to believe that certain licensees, particularly in China, are not fully complying with their contractual obligations to report their sales of licensed products to us, and certain companies, including unlicensed companies, particularly in emerging regions, including China, are delaying execution of new license agreements. We have made substantial progress in reaching agreements with many companies, primarily in China. However, negotiations with certain licensees and unlicensed companies are ongoing. We believe that the conclusion of new agreements with these companies will result in improved reporting. Additionally, we believe our increased efforts in the areas of compliance will improve reporting but will also result in increased costs to the business. Litigation and/or other actions, such as those recently taken against Apple and its contract manufacturers, may be necessary to compel licensees to report and pay the required royalties for sales they have not previously reported and/or to compel unlicensed companies to execute licenses. Such litigation or other actions would result in increased legal costs. |

[0001728949-18-000011:mdna:61]
[same as prior period, unchanged from 0001234452-17-000154:mdna:33]

[0001728949-18-000011:mdna:62]
[same as prior period, unchanged from 0001234452-17-000154:mdna:34]

[0001728949-18-000011:mdna:63]
| • | Decisions by companies to utilize their own internally-developed integrated circuit products and/or sell such products to others, including by bundling with other products, increasing competition; |

[0001728949-18-000011:mdna:64]
| • | Decisions by certain companies to utilize our competitors’ integrated circuit products in all or a portion of their devices. For example, commencing with the iPhone 7 (which was released in September 2016), we are no longer the sole supplier of modems for new iPhone product launches, as Apple utilizes modems from one of our competitors in a portion of such devices. We expect that in the future Apple will utilize our competitors’ modems in a portion of (or potentially all) iPhones. Accordingly, QCT revenues from modem sales for iPhones declined in fiscal 2017 and may continue to decline in the future, in part depending on the extent of Apple’s utilization of competitors’ modems and the mix of the various versions of its products that are sold. Overall QCT revenues, as well as profitability, may similarly decline unless offset by sales of integrated circuit products to other customers, including those outside of traditional cellular industries, such as the Internet of Things (IoT), automotive and networking. Apple’s dual sourcing does not impact our licensing revenues since our licensing revenues from Apple products are not dependent upon whether such products include our chipsets; |

[0001728949-18-000011:mdna:65]
| • | Intense competition, particularly in China, as our competitors expand their product offerings and/or reduce the prices of their products as part of a strategy to attract new and/or retain existing customers; |

[0001728949-18-000011:mdna:66]
| • | Lengthening replacement cycles in developed regions, where the smartphone industry is mature, premium-tier smartphones are common and consumer demand is increasingly driven by new product launches and/or innovation cycles; |

[0001728949-18-000011:mdna:67]
| • | Lengthening replacement cycles in emerging regions as smartphone penetration increases; and |

[0001728949-18-000011:mdna:68]
| • | Increasing consumer demand for 3G/4G smartphone products in emerging regions driven by availability of lower-tier 3G/4G devices. |

[0001728949-18-000011:mdna:69]
| • | We expect the ongoing rollout of 4G services in emerging regions will encourage competition and growth, bringing the benefits of 3G/4G LTE multi-mode to consumers. |

[0001728949-18-000011:mdna:70]
| • | We continue to invest significant resources toward advancements in 4G and 5G technologies, OFDM-based WLAN technologies, wireless baseband chips, our converged computing/communications (Snapdragon) chips, radio frequency front-end (RFFE), connectivity, power management, graphics, audio and video codecs, multimedia |

[0001728949-18-000011:mdna:71]
36

[0001728949-18-000011:mdna:72]
products and software, which contribute to the expansion of our intellectual property portfolio. We are also investing in targeted opportunities that leverage our existing technical and business expertise to deploy new business models and enter and/or expand into new industry segments, such as products for automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), data center, networking, computing and machine learning, among others.

[0001728949-18-000011:mdna:73]
[same as prior period, unchanged from 0001234452-17-000154:mdna:42]

[0001728949-18-000011:mdna:74]
[same as prior period, unchanged from 0001234452-17-000154:mdna:43]

[0001728949-18-000011:mdna:75]
[same as prior period, unchanged from 0001234452-17-000154:mdna:75]

[0001728949-18-000011:mdna:76]
On October 27, 2016, we announced a definitive agreement under which Qualcomm River Holdings will acquire NXP. Pursuant to the definitive agreement, Qualcomm River Holdings has commenced a tender offer to acquire all of the issued and outstanding common shares of NXP for $110 per share in cash, for estimated total cash consideration to be paid to NXP’s shareholders of $38 billion. The transaction is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions. The transaction is expected to close in early 2018. In May 2017, we issued an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes with varying maturities, of which a portion will be used to fund the purchase price and other related transactions. In addition, we have secured $4.0 billion in committed financing through a Term Loan Facility, which is expected to be drawn on at the close of the NXP transaction. The remaining amount will be funded with cash held by our foreign entities, which will result in the use of a substantial portion of our cash, cash equivalents and marketable securities.

[0001728949-18-000011:mdna:77]
Qualcomm River Holdings and NXP may terminate the definitive agreement under certain circumstances. If the definitive agreement is terminated by NXP in certain circumstances, NXP will be required to pay Qualcomm River Holdings a termination fee of $1.25 billion. If the definitive agreement is terminated by Qualcomm River Holdings under certain circumstances involving the failure to obtain the required regulatory approvals or the failure of NXP to complete certain pre-closing reorganization steps in all material respects, Qualcomm River Holdings will be required to pay NXP a termination fee of $2.0 billion. In November 2016, as required by the definitive agreement, we entered into four letters of credit for an aggregate amount of $2.0 billion pursuant to which NXP will have the right to draw amounts to fund the potential termination fee payable to NXP. Each letter of credit is required to be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. We are restricted from using the funds deposited as collateral while the letters of credit are outstanding. At December 24, 2017, the letters of credit were fully collateralized through bank time and demand deposits.

[0001728949-18-000011:mdna:78]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. The following table presents selected financial information related to our liquidity as of December 24, 2017 and September 24, 2017 and for the first three months of fiscal 2018 and 2017 (in millions):

[0001728949-18-000011:mdna:79]
|  | December 24, 2017 |  | September 24, 2017 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 39,850 |  |  | $ | 38,578 |  |  | $ | 1,272 |  |  | 3 | % |
| Accounts receivable, net | 3,053 |  |  | 3,632 |  |  | (579 | ) |  | (16 | %) |
| Inventories | 1,872 |  |  | 2,035 |  |  | (163 | ) |  | (8 | %) |
| Short-term debt | 3,465 |  |  | 2,495 |  |  | 970 |  |  | 39 | % |
| Long-term debt | 19,381 |  |  | 19,398 |  |  | (17 | ) |  | — | % |
| Long-term income taxes payable | 3,867 |  |  | — |  |  | 3,867 |  |  | N/M |  |

[0001728949-18-000011:mdna:80]
N/M - Not meaningful

[0001728949-18-000011:mdna:81]
|  | Three Months Ended |
|  | December 24, 2017 |  | December 25, 2016 |  | $ Change |  | % Change |
| Net cash provided by operating activities | $ | 1,762 |  |  | $ | 1,586 |  |  | $ | 176 |  |  | 11 | % |
| Net cash (used) provided by investing activities | (3,261 | ) |  | 681 |  |  | (3,942 | ) |  | N/M |  |
| Net cash used by financing activities | (165 | ) |  | (1,311 | ) |  | 1,146 |  |  | N/M |  |

[0001728949-18-000011:mdna:82]
N/M - Not meaningful

[0001728949-18-000011:mdna:83]
The net increase in cash, cash equivalents and marketable securities was primarily due to net cash provided by operating activities and $967 million of net issuances of our outstanding commercial paper debt, partially offset by $844 million in cash dividends paid, $226 million in capital expenditures and $225 million in payments to repurchase shares of our common stock. Total cash provided by operating activities increased primarily due to changes in working capital related to decreases in accounts receivable and inventories. Total cash provided by operating activities was also impacted by continued actions taken by Apple and its contract manufacturers, as well as the previously disclosed dispute with another licensee, who did not report or pay royalties due in the first quarter of fiscal 2018.

[0001728949-18-000011:mdna:84]
Our days sales outstanding, on a consolidated basis, decreased to 46 days at December 24, 2017 compared to 56 days at September 24, 2017. The decrease in accounts receivable and the related days sales outstanding were primarily due to the timing of integrated circuit shipments and the collection of receivables related to integrated circuits. The decrease in days sales outstanding was also attributable to the timing of the collection of payments from certain of our licensees. The decrease in inventories was primarily due to a decrease in the overall quantity of units on hand.

[0001728949-18-000011:mdna:85]
Debt. Our Amended and Restated Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in the aggregate amount of $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. At December 24, 2017, no amounts were outstanding under the Amended and Restated Revolving Credit Facility.

[0001728949-18-000011:mdna:86]
We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At December 24, 2017, we had $2.0 billion of commercial paper outstanding with weighted-average net interest rates of 1.28% and weighted-average remaining days to maturity of 36 days.

[0001728949-18-000011:mdna:87]
Our Term Loan Facility provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion. Proceeds from the Term Loan Facility, if drawn, will be used to finance, in part, the proposed acquisition of NXP. At December 24, 2017, no amounts were outstanding under the Term Loan Facility.

[0001728949-18-000011:mdna:88]
In May 2017, we issued an aggregate principal amount of $11.0 billion in nine tranches of unsecured floating- and fixed-rate notes, with maturity dates starting in 2019 through 2047. Effective interest rates were between 1.92% and 4.47% at December 24, 2017. Net proceeds from the issuance of the notes of $10.95 billion are intended to be used to fund a portion of the purchase price of our planned acquisition of NXP and other related transactions and also for general corporate purposes. Our 2019 floating-rate notes, 2020 floating-rate notes, 2019 fixed-rate notes and 2020 fixed-rate notes issued in May 2017 for an aggregate principal amount of $4.0 billion are subject to a special mandatory redemption at a price equal to 101% of the aggregate principal amount, plus accrued and unpaid interest to, but excluding, the date of such mandatory redemption. The redemption is required on the first to occur of (i) the termination of the NXP purchase agreement or (ii) April 25, 2018 (which reflects a second automatic extension of the original expiration date of October 27, 2017 in accordance with the NXP purchase agreement, and as such date may be further extended in accordance with the NXP purchase agreement to a date on or prior to June 1, 2018).

[0001728949-18-000011:mdna:89]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, with $1.5 billion maturing in 2018 and the remaining with maturity dates in 2020 through 2045. Effective interest rates were between 1.77% and 4.74% at December 24, 2017. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001728949-18-000011:mdna:90]
We may issue additional debt in the future. The amount and timing of such additional borrowings will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001728949-18-000011:mdna:91]
Additional information regarding our outstanding debt at December 24, 2017 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt.”

[0001728949-18-000011:mdna:92]
Income Taxes. The Tax Legislation, which was signed into law during the first quarter of fiscal 2018, resulted in an estimated $5.3 billion charge related to the Toll Charge. We currently estimate that we will pay $3.3 billion for the Toll Charge, after application of certain tax credits (including those that are expected to be generated in fiscal 2018), which is payable in installments over eight years (8% in each of the first five years, 15% in year six, 20% in year seven and 25% in year eight) beginning on January 15, 2019.

[0001728949-18-000011:mdna:93]
Our cash, cash equivalents and marketable securities at December 24, 2017 consisted of $8.5 billion held by our United States-based entities and $31.4 billion held by our foreign entities. The Tax Legislation eliminated certain material tax effects on the repatriation of cash to the United States. As of December 24, 2017, we no longer consider available cash balances that existed at the end of fiscal 2017 related to undistributed pre-fiscal 2018 earnings and profits of certain U.S.-owned foreign subsidiaries to be indefinitely reinvested and recorded a tax expense of $86 million related to foreign withholding taxes during the first quarter of fiscal 2018. We otherwise continue to consider other undistributed earnings of certain U.S.-owned foreign subsidiaries to be indefinitely reinvested based on our current plans for use and/or investment outside of the U.S., and therefore, no liability has been recorded for such taxes. However, as a result of the Tax Legislation, we are reassessing our intentions related to our indefinite reinvestment assertion. Should we decide to no longer indefinitely reinvest such earnings outside the U.S., we would have to adjust the income tax provision in the period such determination is made.

[0001728949-18-000011:mdna:94]
Additional information regarding our income taxes is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes.”

[0001728949-18-000011:mdna:95]
Capital Return Program. In the first quarter of fiscal 2018, we repurchased and retired 3.7 million shares of our common stock for $225 million, before commissions. At December 24, 2017, $1.4 billion remained authorized for repurchase under our stock repurchase program. As a result of our proposed acquisition of NXP and the pending use of our cash and marketable securities, we currently expect to repurchase shares in the next few years to offset dilution from the issuance of common stock under our employee benefit plans.

[0001728949-18-000011:mdna:96]
In the first quarter of fiscal 2018, we paid cash dividends totaling $844 million, or $0.57 per share. On January 12, 2018, we announced a cash dividend of $0.57 per share on our common stock, payable on March 21, 2018 to stockholders of record as of the close of business on February 28, 2018. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001728949-18-000011:mdna:97]
Additional Capital Requirements. We believe our current cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements, for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements, in addition to the above matters, also include the items described below.

[0001728949-18-000011:mdna:98]
| • | In connection with our cost reduction plan announced on January 16, 2018, we expect to incur restructuring and restructuring-related charges, the majority of which are expected to result in cash payments. We are in the process of finalizing our plan, as well as the restructuring and restructuring-related costs we expect to incur to execute our plan. |

[0001728949-18-000011:mdna:99]
| • | Our purchase obligations at December 24, 2017, some of which relate to research and development activities and capital expenditures, totaled $3.8 billion and $1.1 billion for fiscal 2018 and 2019, respectively, and $0.6 billion thereafter. |

[0001728949-18-000011:mdna:100]
| • | Our research and development expenditures were $1.4 billion in the first quarter of fiscal 2018 and $5.5 billion in fiscal 2017, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications. |

[0001728949-18-000011:mdna:101]
| • | Cash outflows for capital expenditures were $226 million in the first quarter of fiscal 2018 and $690 million in fiscal 2017. We anticipate that capital expenditures will be higher in fiscal 2018 as compared to fiscal 2017, primarily due to an increase in estimated capital expenditures of approximately $100 million related to the manufacturing operations of our RF360 Holdings joint venture. We also expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001728949-18-000011:mdna:102]
| • | The TFTC imposed a fine on us of approximately 23.4 billion Taiwan Dollars (approximately $781 million based on the exchange rate at December 24, 2017), which will be paid in 60 monthly installments beginning on January 30, 2018. |

[0001728949-18-000011:mdna:103]
| • | The EC imposed a fine on us of approximately 997 million Euros (approximately $1.2 billion based on the exchange rate at December 24, 2017). We intend to provide a financial guarantee within three months of the notification date to satisfy the obligation. |

[0001728949-18-000011:mdna:104]
39

[0001728949-18-000011:mdna:105]
[same as prior period, unchanged from 0001234452-17-000154:mdna:92]

[0001728949-18-000011:mdna:106]
[same as prior period, unchanged from 0001234452-17-000154:mdna:101]

[0001728949-18-000011:mdna:107]
[same as prior period, unchanged from 0001234452-17-000154:mdna:102]

[0001728949-18-000011:mdna:108]
Additional information regarding our financial commitments at December 24, 2017 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes,” “Note 5. Debt,” “Note 6. Commitments and Contingencies” and “Note 8. Acquisitions.”

[0001728949-18-000011:mdna:109]
[same as prior period, unchanged from 0001234452-17-000154:mdna:104]

[0001728949-18-000011:mdna:110]
[same as prior period, unchanged from 0001234452-17-000154:mdna:105]

[0001728949-18-000011:mdna:111]
[same as prior period, unchanged from 0001234452-17-000154:mdna:106]

[0001728949-18-000011:mdna:112]
You should consider each of the following factors as well as the other information in this Quarterly Report in evaluating our business and our prospects. The risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also negatively impact our business and results of operations, and require significant management time and attention. In that case, the trading price of our common stock could decline. You should also consider the other information set forth in this Quarterly Report and in our Annual Report on Form 10-K for the fiscal year ended September 24, 2017 in evaluating our business and our prospects, including but not limited to our financial statements and the related notes and “Part I, Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.”

[0001728949-18-000011:mdna:113]
[same as prior period, unchanged from 0001234452-17-000154:mdna:108]

[0001728949-18-000011:mdna:114]
We are subject to a disruptive takeover proposal.

[0001728949-18-000011:mdna:115]
Broadcom Limited has made an unsolicited proposal to acquire all of our outstanding common stock and has commenced a proxy contest to replace our Board of Directors with Broadcom nominees. Responding to Broadcom’s unsolicited proposal and proxy contest may divert management attention and may require us to incur significant costs. Moreover, the hostile and unsolicited nature of Broadcom’s actions may disrupt our business and operations by causing uncertainty among and potentially loss of current and prospective employees, customers, licensees, suppliers and other constituencies important to our success, which could negatively impact our business and financial results. The price of our common stock may be volatile and could be subject to price fluctuations due to the uncertainty associated with the unsolicited offer and proxy contest.

[0001728949-18-000011:mdna:116]
[same as prior period, unchanged from 0001234452-17-000154:mdna:109]

[0001728949-18-000011:mdna:117]
Our and NXP’s obligations to consummate the proposed transaction are subject to the satisfaction or waiver of certain conditions, including, among others: (i) the tender of a minimum number of NXP’s outstanding common shares in the tender offer commenced by a subsidiary of QUALCOMM Incorporated; (ii) the receipt of regulatory clearance under applicable laws; (iii) the absence of any law or order prohibiting the proposed transaction; (iv) there being no event that would have a material adverse effect on NXP; (v) the accuracy of the representations and warranties of NXP, subject to certain exceptions, and NXP’s material compliance with its covenants, in the definitive agreement; and (vi) the completion of certain internal reorganization steps with respect to NXP and the disposition of certain non-core assets of NXP. We cannot provide assurance that the conditions to the completion of the proposed transaction will be satisfied in a timely manner or at all, and if the proposed transaction is not completed, we would not realize any of the expected benefits.

[0001728949-18-000011:mdna:118]
The regulatory approvals required in connection with the proposed transaction may not be obtained or may contain materially burdensome conditions. If any conditions or changes to the structure of the proposed transaction are required to obtain these regulatory approvals, they may have the effect of jeopardizing or delaying completion of the proposed

[0001728949-18-000011:mdna:119]
transaction or reducing our anticipated benefits. If we agree to any material conditions in order to obtain any approvals required to complete the proposed transaction, our business and results of operations may be adversely affected.

[0001728949-18-000011:mdna:120]
[same as prior period, unchanged from 0001234452-17-000154:mdna:112]

[0001728949-18-000011:mdna:121]
[same as prior period, unchanged from 0001234452-17-000154:mdna:113]

[0001728949-18-000011:mdna:122]
[same as prior period, unchanged from 0001234452-17-000154:mdna:114]

[0001728949-18-000011:mdna:123]
[same as prior period, unchanged from 0001234452-17-000154:mdna:115]

[0001728949-18-000011:mdna:124]
[same as prior period, unchanged from 0001234452-17-000154:mdna:116]

[0001728949-18-000011:mdna:125]
| • | we may be subject to legal proceedings related to the proposed transaction or the failure to complete the proposed transaction; |

[0001728949-18-000011:mdna:126]
[same as prior period, unchanged from 0001234452-17-000154:mdna:118]

[0001728949-18-000011:mdna:127]
| • | any disruptions to our business resulting from the announcement and pendency of the proposed transaction, including any adverse changes in our relationships with our customers, suppliers, partners or employees, may continue or intensify in the event the proposed transaction is not consummated. |

[0001728949-18-000011:mdna:128]
The proposed transaction will be our largest acquisition to date, by a significant margin. The benefits we expect to realize from the proposed transaction will depend, in part, on our ability to integrate the businesses successfully and efficiently. See the Risk Factor entitled “We may engage in strategic acquisitions, transactions or make investments that could adversely affect our results of operations or fail to enhance stockholder value.”

[0001728949-18-000011:mdna:129]
[same as prior period, unchanged from 0001234452-17-000154:mdna:121]

[0001728949-18-000011:mdna:130]
The proposed transaction may also result in significant charges or other liabilities that could adversely affect our results of operations, such as cash expenses and non-cash accounting charges incurred in connection with our acquisition and/or integration of the business and operations of NXP. Further, our failure to identify or accurately assess the magnitude of certain liabilities we are assuming in the proposed transaction could result in unexpected litigation or regulatory exposure, unfavorable accounting charges, unexpected increases in taxes due, a loss of anticipated tax benefits or other adverse effects on our business, results of operations, financial condition or cash flows.

[0001728949-18-000011:mdna:131]
[same as prior period, unchanged from 0001234452-17-000154:mdna:123]

[0001728949-18-000011:mdna:132]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on operators of wireless networks and our customers and licensees to adopt and/or implement the latest generation of these technologies for use in their networks, devices and services. We also depend on our customers and licensees to develop devices and services based on these technologies with value-added features to drive consumer demand for new 3G, 3G/4G multi-mode and 4G devices, and in the future 5G devices, as well as establishing the selling prices for such devices. Further, we depend on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless

[0001728949-18-000011:mdna:133]
networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries beyond traditional cellular communications, such as automotive, the internet of things (IoT) (including the connected home, smart cities, wearables, voice and music and robotics), data center, networking, computing, and machine learning, among others. We are also impacted by consumers’ rates of replacement of smartphones and other computing devices.

[0001728949-18-000011:mdna:134]
[same as prior period, unchanged from 0001234452-17-000154:mdna:125]

[0001728949-18-000011:mdna:135]
[same as prior period, unchanged from 0001234452-17-000154:mdna:126]

[0001728949-18-000011:mdna:136]
| • | wireless operators delay next-generation network deployments, such as 5G, expansions or upgrades and/or delay moving 2G customers to 3G, 3G/4G multi-mode or 4G wireless devices; |

[0001728949-18-000011:mdna:137]
| • | LTE, an OFDMA-based wireless technology, is not more widely deployed or further commercial deployment is delayed; |

[0001728949-18-000011:mdna:138]
[same as prior period, unchanged from 0001234452-17-000154:mdna:129]

[0001728949-18-000011:mdna:139]
| • | wireless operators delay or do not drive improvements in 3G, 4G or 3G/4G multi-mode network performance and/or capacity; |

[0001728949-18-000011:mdna:140]
[same as prior period, unchanged from 0001234452-17-000154:mdna:132]

[0001728949-18-000011:mdna:141]
[same as prior period, unchanged from 0001234452-17-000154:mdna:133]

[0001728949-18-000011:mdna:142]
[same as prior period, unchanged from 0001234452-17-000154:mdna:134]

[0001728949-18-000011:mdna:143]
[same as prior period, unchanged from 0001234452-17-000154:mdna:135]

[0001728949-18-000011:mdna:144]
[same as prior period, unchanged from 0001234452-17-000154:mdna:136]

[0001728949-18-000011:mdna:145]
Our products, services and technologies face significant competition. We expect competition to increase as our current competitors expand their product offerings or reduce the prices of their products as part of a strategy to attract new business and/or customers, as new opportunities develop and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: device manufacturer concentrations and vertical integration; growth in demand, consumption and competition in certain geographic regions; government intervention and/or support of national industries and/or competitors; evolving industry standards and business models; evolving methods of transmission of voice and data communications; increasing data traffic and densification of wireless networks; convergence and aggregation of connectivity technologies (including Wi-Fi and LTE) in both devices and access points; consolidation of wireless technologies and infrastructure at the network edge; networking and connectivity trends (including cloud services); use of both licensed and unlicensed spectrum; the evolving nature of computing (including demand for always on, always connected capabilities); the speed of technological change (including the transition to smaller geometry process technologies); value-added features that drive selling prices as well as consumer demand for new 3G, 3G/4G multi-mode and 4G devices; turnkey, integrated products that incorporate hardware, software, user interface, applications and reference designs; scalability; and the ability of the system technology to meet customers’ immediate and future network requirements. We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, technological and public policy changes and relatively low barriers to entry in certain segments of the industry. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape.

[0001728949-18-000011:mdna:146]
[same as prior period, unchanged from 0001234452-17-000154:mdna:138]

[0001728949-18-000011:mdna:147]
[same as prior period, unchanged from 0001234452-17-000154:mdna:139]

[0001728949-18-000011:mdna:148]
[same as prior period, unchanged from 0001234452-17-000154:mdna:146]

[0001728949-18-000011:mdna:149]
[same as prior period, unchanged from 0001234452-17-000154:mdna:140]

[0001728949-18-000011:mdna:150]
| • | continue to drive the adoption of our integrated circuit products into the most popular device models and across a broad spectrum of devices, such as smartphones, tablets, laptops, other computing devices, automobiles, wearables and voice and music and other connected devices and infrastructure products; |

[0001728949-18-000011:mdna:151]
| • | maintain and/or accelerate demand for our integrated circuit products at the premium device tier, while increasing the adoption of our products in mid- and low-tier devices, in part by strengthening our integrated circuit product roadmap for, and developing channel relationships in, emerging geographic regions, such as China and India, and by providing turnkey products, which incorporate our integrated circuits, for low- and mid-tier smartphones, tablets and laptops; |

[0001728949-18-000011:mdna:152]
| • | continue to be a leader in 4G technology evolution, including expansion of our LTE-based single-mode licensing program in areas where single-mode products are commercialized, and continue to innovate and introduce 4G turnkey, integrated products and services that differentiate us from our competition; |

[0001728949-18-000011:mdna:153]
| • | be a leader serving original equipment manufacturers, high level operating systems (HLOS) providers, operators, cloud providers and other industry participants as competitors, new industry entrants and other factors continue to affect the industry landscape; |

[0001728949-18-000011:mdna:154]
[same as prior period, unchanged from 0001234452-17-000154:mdna:145]

[0001728949-18-000011:mdna:155]
[same as prior period, unchanged from 0001234452-17-000154:mdna:147]

[0001728949-18-000011:mdna:156]
[same as prior period, unchanged from 0001234452-17-000154:mdna:148]

[0001728949-18-000011:mdna:157]
| • | create standalone value and/or contribute to the success of our existing businesses through acquisitions, joint ventures and other transactions (and/or by developing customer, licensee and/or vendor relationships) in new industry segments and/or disruptive technologies, products and/or services (such as products for automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), data center, networking, computing, and machine learning, among others); |

[0001728949-18-000011:mdna:158]
| • | become a leading supplier of RFFE products, which are designed to address cellular radio frequency band fragmentation while improving radio frequency performance and assist original equipment manufacturers in developing multiband, multi-mode mobile devices; |

[0001728949-18-000011:mdna:159]
[same as prior period, unchanged from 0001234452-17-000154:mdna:151]

[0001728949-18-000011:mdna:160]
[same as prior period, unchanged from 0001234452-17-000154:mdna:152]

[0001728949-18-000011:mdna:161]
Competition in any or all product tiers may result in the loss of certain business or customers, which would negatively impact our revenues, results of operations and cash flows. Such competition may also reduce average selling prices for our chipset products and/or the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging geographic regions where competitors may have lower cost structures and/or may have a willingness and ability to accept lower prices and/or lower or negative margins on their products (particularly in China). Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0001728949-18-000011:mdna:162]
Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM) as well as companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Advanced Micro Devices, Inc., Broadcom Limited, Cirrus Logic, Cypress Semiconductor Corporation, HiSilicon Technologies, Intel, Marvell Technology, Maxim Integrated Products, MediaTek, Microchip Technology Inc., Murata Manufacturing Co., Ltd., Nordic Semiconductor,

[0001728949-18-000011:mdna:163]
Nvidia, Qorvo Inc., Realtek Semiconductor, Renesas Electronics Corporation, Samsung Electronics, Sequans Communications S.A., Skyworks Solutions Inc., Sony Corporation and Spreadtrum Communications (which is controlled by Tsinghua Unigroup). Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to utilize their own internally-developed integrated circuit products, to use our competitors’ integrated circuit products and/or sell such products to others, including by bundling with other products, or to choose alternative technologies; lower cost structures and/or a willingness and ability to accept lower prices and lower or negative margins for their products, particularly in China; foreign government support of other technologies or competitors; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and original equipment manufacturers in certain geographic regions (such as China) and/or experience in adjacent industry segments outside traditional cellular industries (such as automotive and IoT); and/or a more established presence in certain regions.

[0001728949-18-000011:mdna:164]
We derive a significant portion of our consolidated revenues from a small number of customers and licensees. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected.

[0001728949-18-000011:mdna:165]
Our QCT segment derives a significant portion of its revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. In addition, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past chosen to utilize in certain of their devices rather than our products, and may in the future choose to utilize in certain (or all) of their devices rather than our products (and/or sell their integrated circuit products to third parties in competition with us). Also, one of our largest integrated circuit customers has utilized products of one of our competitors in certain of their devices rather than our products, and may in the future utilize products of our competitors in certain (or all) of their devices rather than our products.

[0001728949-18-000011:mdna:166]
The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or the cancelation of significant purchases by any of these customers, whether due to the use of their own integrated circuit products, our competitors’ integrated circuit products or otherwise, would reduce our revenues and could harm our ability to achieve or sustain expected results of operations, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development. Further, the concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have no control, and the timing of such introductions may cause our revenues and results of operations to fluctuate. Accordingly, if current industry dynamics and concentrations continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases, and the timing and size of any such future purchases, by these significant customers.

[0001728949-18-000011:mdna:167]
[same as prior period, unchanged from 0001234452-17-000154:mdna:160]

[0001728949-18-000011:mdna:168]
Further, companies that develop HLOS for devices, including leading technology companies, now sell their own devices. If we fail to effectively partner or continue partnering with these companies, or with their partners or customers, they may decide not to purchase (either directly or through their contract manufacturers), or to reduce or discontinue their purchases of, our integrated circuit products.

[0001728949-18-000011:mdna:169]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products and/or intellectual property, or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001728949-18-000011:mdna:170]
Although we have several hundred licensees, our QTL segment derives a significant portion of its licensing revenues from a limited number of licensees. In the event that one or more of our significant licensees fail to meet their reporting and/or payment obligations, or we are unable to renew or modify one or more of such license agreements under similar terms, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume

[0001728949-18-000011:mdna:171]
products that achieve and sustain customer acceptance. We have no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our significant licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues.

[0001728949-18-000011:mdna:172]
We derive a significant portion of our consolidated revenues from the premium-tier device segment. If sales of premium-tier devices decrease, and/or sales of our premium-tier integrated circuit products decrease, our results of operations could be negatively affected.

[0001728949-18-000011:mdna:173]
We derive a significant portion of our revenues from the premium-tier device segment, and we expect this trend to continue in the foreseeable future. We have experienced, and expect to continue to experience, slowing growth in the premium-tier device segment due to, among other factors, lengthening replacement cycles in developed regions, where premium-tier smartphones are common; increasing consumer demand in emerging regions, particularly China and India, where premium-tier smartphones are less common and replacement cycles are on average longer than in developed regions; lengthening replacement cycles in emerging regions; and/or a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and/or innovation cycles.

[0001728949-18-000011:mdna:174]
[same as prior period, unchanged from 0001234452-17-000154:mdna:166]

[0001728949-18-000011:mdna:175]
A reduction in sales of premium-tier devices, or a reduction in sales of our premium-tier integrated circuit products (which have a higher revenue and margin contribution than our lower-tier integrated circuit products), may reduce our revenues and margins and may harm our ability to achieve or sustain expected financial results. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0001728949-18-000011:mdna:176]
[same as prior period, unchanged from 0001234452-17-000154:mdna:168]

[0001728949-18-000011:mdna:177]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, the imposition of some form of compulsory licensing and/or to weaken a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies to attempt to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated. In addition, certain licensees have disputed, underreported, underpaid, not reported and/or not paid royalties owed to us under their license agreements or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into or renewing license agreements with us for their use of our intellectual property, and licensees and/or companies may continue to do so in the future. The fact that one or more licensees dispute, underreport, underpay, do not report and/or do not pay royalties owed to us may encourage other licensees to take similar actions and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Further, to the extent such licensees and/or companies increase their device share, the negative impact of their underreporting, underpayment, non-payment and/or non-reporting on our business, revenues, results of operations, financial condition and/or cash flows will be exacerbated.

[0001728949-18-000011:mdna:178]
We are currently subject to various litigation and governmental investigations and/or proceedings, some of which have arisen and may continue to arise out of the strategies described above. Certain legal matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an

[0001728949-18-000011:mdna:179]
unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or modify our business practices. In addition, decisions or orders arising out of governmental investigations or proceedings could require us to renegotiate, or could encourage or embolden our licensees to demand to renegotiate, their license agreements with us (which could be on terms that are less favorable to us than existing terms), and such licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. See also the Risk Factor entitled “Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.”

[0001728949-18-000011:mdna:180]
In addition, in connection with our participation in SDOs, we, like other patent owners, generally have made contractual commitments to such organizations to license those of our patents that would necessarily be infringed by standard-compliant products as set forth in those commitments. Some manufacturers and users of standard-compliant products advance interpretations of these commitments that are adverse to our licensing business, including interpretations that would limit the amount of royalties that we could collect on the licensing of our patent portfolio.

[0001728949-18-000011:mdna:181]
[same as prior period, unchanged from 0001234452-17-000154:mdna:173]

[0001728949-18-000011:mdna:182]
Some SDOs, courts and governmental agencies have adopted and may in the future adopt some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001728949-18-000011:mdna:183]
We expect that such proposals, interpretations and strategies will continue in the future, and if successful, our business model would be harmed, either by limiting or eliminating our ability to collect royalties (or by reducing the royalties we can collect) on all or a portion of our patent portfolio, limiting our return on investment with respect to new technologies, limiting our ability to seek injunctions against infringers of our standard-essential patents, constraining our ability to make licensing commitments when submitting our technology for inclusion in future standards (which could make our technology less likely to be included in such standards) or forcing us to work outside of SDOs or other industry groups to promote our new technologies, and our revenues, results of operations and/or cash flows could be negatively impacted. In addition, the legal and other costs associated with asserting or defending our positions have been and continue to be significant. We assume that such challenges, regardless of their merits, will continue into the foreseeable future and may require the investment of substantial management time and financial resources.

[0001728949-18-000011:mdna:184]
Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings.

[0001728949-18-000011:mdna:185]
We are currently subject to various governmental investigations and/or proceedings, particularly with respect to our licensing business, and certain such matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations in those matters include, among others, that we do not license our cellular standard-essential patents separately from our other patents, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high and/or that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions). The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. In addition, decisions or orders arising out of such governmental investigations or proceedings could require us to renegotiate, or could encourage or embolden our licensees to demand to renegotiate, their license agreements with us (which could be on terms that are less favorable to us than existing terms), and such licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend

[0001728949-18-000011:mdna:186]
beyond the borders of that country or region. See also the Risk Factor entitled “Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.”

[0001728949-18-000011:mdna:187]
Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.

[0001728949-18-000011:mdna:188]
We are currently subject to various governmental investigations and private legal proceedings challenging our patent licensing practices as described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations in those matters include, among others, that we do not license our cellular standard-essential patents separately from our other patents, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high and/or that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions). We believe that the ultimate intent of these investigations and legal proceedings is to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0001728949-18-000011:mdna:189]
We have historically licensed our cellular standard-essential patents together with our other patents that may be useful to licensed products because licensees typically have desired to obtain the commercial benefits of receiving such broad patent rights from us. However, we also have licensed only our cellular standard-essential patents to certain licensees who have requested such licenses. In addition, in connection with our resolution with the China National Development and Reform Commission (NDRC), our standard practice in China since 2015 is to offer licenses to our 3G and 4G standard-essential Chinese patents for devices sold for use in China separately from our other patents. In connection with our recent 5G royalty rate announcement, we offer licenses to only our cellular standard-essential patents (including 3G, 4G and 5G) for both single mode and multi-mode devices. Our royalty rates for licenses to only our cellular standard-essential patents are lower than our royalty rates for licenses to substantially all of our patent portfolio. If more licensees choose a license to only our cellular standard-essential patents instead of a portfolio license than has historically been the case, our licensing revenues and earnings would be negatively impacted unless we were able to license our other patents at rates that offset all or a portion of any difference between the royalties previously received for licenses of substantially all of our patent portfolio as compared to licenses of only our cellular standard-essential patents and/or there was a sufficient increase in the overall volume of sales of devices upon which royalties are paid.

[0001728949-18-000011:mdna:190]
[same as prior period, unchanged from 0001234452-17-000154:mdna:181]

[0001728949-18-000011:mdna:191]
If we were required to reduce the royalty rates we charge under our patent license agreements, our revenues and earnings would be negatively impacted absent a sufficient increase in the volume of sales of devices upon which royalties are paid. Similarly, if we were required to reduce the base on which our royalties are calculated, our revenues, results of operations and/or cash flows would be negatively impacted unless there was a sufficient increase in the volume of sales of devices upon which royalties are paid and/or we were able to increase our royalty rates to offset the decrease in revenues resulting from such lower royalty base (assuming the absolute royalty dollars were below any relevant royalty caps).

[0001728949-18-000011:mdna:192]
[same as prior period, unchanged from 0001234452-17-000154:mdna:183]

[0001728949-18-000011:mdna:193]
The enforcement and protection of our intellectual property rights may be expensive, could fail to prevent misappropriation or unauthorized use of our intellectual property rights, could result in the loss of our ability to enforce one or more patents, and/or could be adversely affected by changes in patent laws, by laws in certain foreign jurisdictions that may not effectively protect our intellectual property rights and/or by ineffective enforcement of laws in such jurisdictions.

[0001728949-18-000011:mdna:194]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our proprietary information, technologies and processes,

[0001728949-18-000011:mdna:195]
including our patent portfolio. Policing unauthorized use of our products, technologies and proprietary information is difficult and time consuming. The steps we have taken have not always prevented, and we cannot be certain the steps we will take in the future will prevent, the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as United States laws or where the enforcement of such laws may be lacking or ineffective. Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that the European Union will adopt a unitary patent system in the next few years that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-18-000011:mdna:196]
We have had, and may in the future have, difficulty in certain circumstances in protecting or enforcing our intellectual property rights and/or contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and/or pay all or a portion of the royalties they owe to us; policies of foreign governments; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and/or challenges before competition agencies to our licensing business and/or the pricing and integration of additional features and functionality into our chipset products. Certain licensees have disputed, underreported, underpaid, not reported and/or not paid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into or renewing license agreements for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future. The fact that one or more licensees dispute, underreport, underpay, do not report and/or do not pay royalties owed to us may encourage other licensees to take similar actions and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements.

[0001728949-18-000011:mdna:197]
We have entered into litigation in the past and may need to further litigate in the future to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. We are currently engaged in litigation matters related to protecting or enforcing our contract and/or intellectual property rights, and certain such matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” As a result of any such litigation, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements and/or initiating litigation) and/or we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and/or cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion. See also the Risk Factor entitled “Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.”

[0001728949-18-000011:mdna:198]
Our growth increasingly depends on our ability to extend our technologies, products and services into new and expanded product areas, such as RFFE, and adjacent industry segments outside of traditional cellular industries, such as automotive, IoT and networking, among others. Our research, development and other investments in these new and expanded product areas and industry segments, and related technologies, products and services, as well as in our existing technologies, products and services and new technologies, such as 5G, may not generate operating income or contribute to future results of operations that meet our expectations.

[0001728949-18-000011:mdna:199]
[same as prior period, unchanged from 0001234452-17-000154:mdna:200]

[0001728949-18-000011:mdna:200]
Our industry is subject to rapid technological change, evolving industry standards and frequent new product introductions, and we must make substantial research, development and other investments, such as acquisitions, in new products, services and technologies to compete successfully. Technological innovations generally require significant research and development efforts before they are commercially viable. While we continue to invest significant resources toward advancements primarily in support of 4G- and 5G-based technologies, we also innovate across a broad spectrum of opportunities to deploy new and expanded products and enter into adjacent industry segments by leveraging our existing technical and business expertise and/or through acquisitions.

[0001728949-18-000011:mdna:201]
In particular, our future growth significantly depends on new and expanded product areas, such as RFFE, and adjacent industry segments, such as automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), data center, networking, computing and machine learning, among others; our ability to develop leading and cost-effective technologies, products and services for new and expanded product areas and adjacent industry segments; and third parties incorporating our technology, products and services into devices used in these product areas and industry segments. Accordingly, we intend to continue to make substantial investments in these new and expanded product areas and adjacent industry segments, and in developing new products, services and technologies for these product areas and industry segments.

[0001728949-18-000011:mdna:202]
However, our research, development and other investments in these new and expanded product areas and adjacent industry segments, and corresponding technologies, products and services, as well as in our existing, technologies, products and services and new technologies, such as 5G, use of both licensed and unlicensed spectrum, and convergence of cellular and Wi-Fi, may not succeed due to, among others: new industry segments and/or consumer demand may not grow as anticipated; our strategies and/or the strategies of our customers, licensees or partners may not be successful; improvements in alternate technologies in ways that reduce the advantages we anticipate from our investments; competitors’ products or services being more cost effective, having more capabilities or fewer limitations or being brought to market faster than our new products and services; and competitors having longer operating histories in industry segments that are new to us. We may also underestimate the costs of or overestimate the future revenues and/or margins that could result from these investments, and these investments may not, or may take many years to, generate material returns. Further, the automotive industry is subject to long design-in time frames, long product life cycles and a high degree of regulatory and safety requirements, necessitating suppliers to the industry to comply with stringent qualification processes, very low defect rates and high reliability standards, all of which results in a significant barrier to entry and increased costs.

[0001728949-18-000011:mdna:203]
[same as prior period, unchanged from 0001234452-17-000154:mdna:202]

[0001728949-18-000011:mdna:204]
There are numerous risks associated with our operation and control of manufacturing facilities of our joint venture with TDK, RF360 Holdings, including a higher portion of fixed costs relative to a fabless model, environmental compliance and liability, exposure to natural disasters, timely supply of equipment and materials and manufacturing difficulties.

[0001728949-18-000011:mdna:205]
[same as prior period, unchanged from 0001234452-17-000154:mdna:204]

[0001728949-18-000011:mdna:206]
[same as prior period, unchanged from 0001234452-17-000154:mdna:205]

[0001728949-18-000011:mdna:207]
We have manufacturing facilities in Asia and Europe. If tsunamis, flooding, earthquakes, volcanic eruptions or other natural disasters or geopolitical conflicts were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, delay new production and shipments of inventory or result in costly repairs, replacements or other costs. In addition, natural disasters or geopolitical conflicts may result in disruptions in transportation, distribution channels or supply chains, or significant increases in the prices of raw materials.

[0001728949-18-000011:mdna:208]
Our manufacturing operations depend on securing raw materials and other supplies in adequate quality and quantity in a timely manner from multiple suppliers, and in some cases, we rely on a limited number of suppliers, particularly in Asia. Accordingly, there may be cases where supplies of raw materials and other products are interrupted by disaster, accident or some other event at a supplier, supply is suspended due to quality or other issues, or there is a shortage of supply due to a rapid increase in demand, which could impact production and prevent us from supplying products to our customers. If the supply-demand balance is disrupted, it may considerably increase costs of manufacturing due to increased prices we pay for raw materials or fuel. From time to time, suppliers may extend lead times, limit the amounts supplied to us or increase prices due to capacity constraints or other factors. Further, it may be difficult or impossible to substitute one piece of equipment for another or replace one type of material with another. A failure by our suppliers to deliver our requirements could result in disruptions to our manufacturing operations.

[0001728949-18-000011:mdna:209]
[same as prior period, unchanged from 0001234452-17-000154:mdna:208]

[0001728949-18-000011:mdna:210]
The continued and future success of our licensing programs requires us to continue to evolve our patent portfolio, and our licensing programs may be impacted by the proliferation of devices in new industry segments such as automotive and IoT, as well as the need to extend license agreements that are expiring and/or to cover additional future patents.

[0001728949-18-000011:mdna:211]
We own a very strong portfolio of issued and pending patents related to 3G, 4G, 5G and other technologies. It is critical that we continue to evolve our patent portfolio, particularly in 5G. If we do not maintain a strong portfolio that is applicable to current and future standards (such as 5G), products and services, our future licensing revenues could be negatively impacted. In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the IoT and automotive industry segments. We also seek to diversify and broaden our technology licensing programs to new industry segments in which we can utilize our technology leadership, such as wireless charging and other technologies. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties at all or that are equivalent to those that we receive for products used in cellular communications. Although we believe that our patented technologies are essential and useful to the commercialization of such services, any royalties we receive may be lower than those we receive from our current licensing program.

[0001728949-18-000011:mdna:212]
Further, the licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, certain of our license agreements (including essentially all of our recent agreements in China) are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of a specified term, or to receive royalties after the specified time period, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. Accordingly, to the extent not renewed on their terms or by election for an additional (generally multi-year) period, if applicable, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. We might not be able to renew those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in renewing a license agreement prior to its expiration, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001728949-18-000011:mdna:213]
We depend on a limited number of third-party suppliers for the procurement, manufacture and testing of our products manufactured in a fabless production model. If we fail to execute supply strategies that provide technology leadership, supply assurance and low cost, our business and results of operations may be harmed. We are also subject to order and shipment uncertainties that could negatively impact our results of operations.

[0001728949-18-000011:mdna:214]
Our QCT segment primarily utilizes a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Other than the manufacturing facilities we now operate through our recently formed RF360 Holdings joint venture, we rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Under the turnkey model, our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we

[0001728949-18-000011:mdna:215]
purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services such as wafer bump, probe, assembly and the majority of our final test requirements. The semiconductor manufacturing foundries that supply products to our QCT segment are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders. The following could have an adverse effect on our ability to meet customer demands and/or negatively impact our revenues, business operations, profitability and/or cash flows:

[0001728949-18-000011:mdna:216]
[same as prior period, unchanged from 0001234452-17-000154:mdna:215]

[0001728949-18-000011:mdna:217]
[same as prior period, unchanged from 0001234452-17-000154:mdna:217]

[0001728949-18-000011:mdna:218]
[same as prior period, unchanged from 0001234452-17-000154:mdna:218]

[0001728949-18-000011:mdna:219]
[same as prior period, unchanged from 0001234452-17-000154:mdna:219]

[0001728949-18-000011:mdna:220]
[same as prior period, unchanged from 0001234452-17-000154:mdna:220]

[0001728949-18-000011:mdna:221]
[same as prior period, unchanged from 0001234452-17-000154:mdna:221]

[0001728949-18-000011:mdna:222]
[same as prior period, unchanged from 0001234452-17-000154:mdna:222]

[0001728949-18-000011:mdna:223]
While we have established alternate suppliers for certain technologies, we rely on sole- or limited-source suppliers for certain products, subjecting us to significant risks, including: possible shortages of raw materials or manufacturing capacity; poor product performance; and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established alternate suppliers, these suppliers may require significant levels of support to bring complex technologies to production. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, any future consolidation of foundry suppliers could increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions and/or increase our manufacturing costs. Our arrangements with our suppliers may obligate us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies, and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Our inability to meet customer demand due to sole- or limited-sourcing and/or the additional costs that we incur because of these or other supply constraints or because of the need to support alternate suppliers could negatively impact our business, our results of operations and/or cash flows.

[0001728949-18-000011:mdna:224]
[same as prior period, unchanged from 0001234452-17-000154:mdna:224]

[0001728949-18-000011:mdna:225]
One or more of our suppliers or potential alternate suppliers may manufacture CDMA- or OFDMA-based integrated circuits that compete with our products. Such suppliers could elect to allocate raw materials and manufacturing capacity to their own products and reduce or limit deliveries to us to our detriment. In addition, we may not receive reasonable pricing, manufacturing or delivery terms from our suppliers. We cannot guarantee that the actions of our suppliers will not cause disruptions in our operations that could harm our ability to meet our delivery obligations to our customers or increase our cost of sales.

[0001728949-18-000011:mdna:226]
Additionally, we place orders with our suppliers using our forecasts of customer demand, which are based on a number of assumptions and estimates, and are generally only partially covered by commitments from our customers. If we overestimate customer demand, we may experience increased excess and/or obsolete inventory, which would negatively impact our results of operations.

[0001728949-18-000011:mdna:227]
51

[0001728949-18-000011:mdna:228]
[same as prior period, unchanged from 0001234452-17-000154:mdna:227]

[0001728949-18-000011:mdna:229]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and/or cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-18-000011:mdna:230]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (and/or on the sale of our customers’ devices using such products) and/or the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001728949-18-000011:mdna:231]
Certain legal matters, including certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-18-000011:mdna:232]
We may engage in strategic acquisitions, transactions or make investments that could adversely affect our results of operations or fail to enhance stockholder value.

[0001728949-18-000011:mdna:233]
We engage in strategic acquisitions and other transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. We acquire businesses and other assets, including patents, technology, wireless spectrum and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications and new industry segments. Recent material transactions include our RF360 Holdings joint venture with TDK Corporation and our proposed acquisition of NXP. Many of our strategic activities entail a high degree of risk and require the use of domestic and/or foreign capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies, products or services. We may underestimate the costs and/or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our

[0001728949-18-000011:mdna:234]
financial condition and results of operations, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001728949-18-000011:mdna:235]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, technology, products, processes, operations (including manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development and/or supply operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models (including manufacturing), geographic regions, industry segments and/or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of the combination.

[0001728949-18-000011:mdna:236]
[same as prior period, unchanged from 0001234452-17-000154:mdna:237]

[0001728949-18-000011:mdna:237]
If we are unsuccessful in executing our cost reduction plan, our business and results of operations may be adversely affected.

[0001728949-18-000011:mdna:238]
On January 16, 2018, we announced a cost reduction plan designed to align our cost structure to our long-term margin targets. As part of this plan, we will implement a series of targeted reductions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. We expect these cost reductions to be fully captured in fiscal 2019.

[0001728949-18-000011:mdna:239]
We cannot provide assurance that our cost reduction plan will be successful, that anticipated cost savings will be realized, that our operations, business and financial results will improve and/or that these efforts will not disrupt our operations (beyond what is intended). Our ability to achieve the anticipated cost savings and other benefits within the expected time frames is subject to many estimates and assumptions, which are subject to significant economic, competitive and other uncertainties, some of which are beyond our control. Further, we may experience delays in the timing of these efforts and/or higher than expected or unanticipated costs in implementing them. Moreover, changes in the size, alignment or organization of our workforce could adversely affect employee morale and retention, relations with customers and business partners, our ability to develop and deliver products and services as anticipated and/or impair our ability to realize our current or future business and financial objectives. If we do not succeed in these efforts, if these efforts are more costly or time-consuming than expected, if our estimates and assumptions are not correct, if we experience delays or if other unforeseen events occur, our business and results of operations may be adversely affected.

[0001728949-18-000011:mdna:240]
We are subject to various laws, regulations, policies and standards. Our business may suffer as a result of existing, or new or amended, laws, regulations, policies or standards and/or our failure or inability to comply with laws, regulations, policies or standards.

[0001728949-18-000011:mdna:241]
Our business, products and services, and those of our customers and licensees, are subject to various laws and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies. Compliance with existing laws, regulations, policies and standards, the adoption of new laws, regulations, policies or standards, changes in the interpretation of existing laws, regulations, policies or standards, changes in the regulation of our activities by a government or standards body and/or rulings in court, regulatory, administrative or other proceedings relating to such laws, regulations, policies or standards, including, among others, those affecting licensing practices, competitive business practices, the use of our technology or products, protection of intellectual property, trade, foreign currency, investments or loans, spectrum availability and license issuance, adoption of standards, the provision of device subsidies by wireless operators to their customers, taxation, export control, privacy and data protection, environmental protection, health and safety, labor and employment, human rights, corporate governance, public disclosure or business conduct could have an adverse effect on our business and results of operations.

[0001728949-18-000011:mdna:242]
Government policies, particularly in China, that restrict the timing of funds that may flow out of a country may impact the timing of our receipt of payments from our customers and/or licensees in such country, which may negatively impact our cash flows.

[0001728949-18-000011:mdna:243]
[same as prior period, unchanged from 0001234452-17-000154:mdna:187]

[0001728949-18-000011:mdna:244]
National, state and local environmental laws and regulations affect our operations around the world. These laws may make it more expensive to manufacture, have manufactured and sell products, and our costs could increase if our vendors (e.g., suppliers, third-party manufacturers or utility companies) pass on their costs to us. We are also subject to laws and regulations impacting the manufacturing operations of our RF360 Holdings joint venture. See the Risk Factor entitled “There are numerous risks associated with our operation and control of manufacturing facilities of our joint venture with TDK, RF360 Holdings, including high fixed costs, environmental compliance and liability, exposure to natural disasters, timely supply of equipment and materials and manufacturing difficulties.”

[0001728949-18-000011:mdna:245]
Regulations in the United States require that we determine whether certain materials used in our products, referred to as conflict minerals, originated in the Democratic Republic of the Congo or an adjoining country (collectively, the Covered Countries), or were from recycled or scrap sources. Other countries or regions may impose similar requirements in the future. The verification and reporting requirements, in addition to customer demands for conflict free sourcing, impose additional costs on us and on our suppliers and may limit the sources or increase the prices of materials used in our products. Further, if we are unable to determine that the conflict minerals used in our products do not directly or indirectly finance or benefit armed groups in the Covered Countries, we may face challenges with our customers that place us at a competitive disadvantage, and our reputation may be harmed. Similarly, other laws and regulations have been adopted or proposed that require additional transparency regarding the employment practices of our suppliers, and any failure to maintain responsible sourcing practices could also adversely affect our relationships with customers and our reputation.

[0001728949-18-000011:mdna:246]
Laws, regulations, policies and standards are complex and changing and may create uncertainty regarding compliance. Laws, regulations, policies and standards are subject to varying interpretations in many cases, and their application in practice may evolve over time. As a result, our efforts to comply may fail, particularly if there is ambiguity as to how they should be applied in practice. Failure to comply with any law, regulation, policy or standard may adversely affect our business, results of operations and/or cash flows. New laws, regulations, policies and standards or evolving interpretations of legal requirements may cause us to incur higher costs as we revise current practices, policies and/or procedures and may divert management time and attention to compliance activities.

[0001728949-18-000011:mdna:247]
[same as prior period, unchanged from 0001234452-17-000154:mdna:238]

[0001728949-18-000011:mdna:248]
[same as prior period, unchanged from 0001234452-17-000154:mdna:239]

[0001728949-18-000011:mdna:249]
[same as prior period, unchanged from 0001234452-17-000154:mdna:240]

[0001728949-18-000011:mdna:250]
Our stock price and earnings have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and/or earnings include those identified throughout this Risk Factors section, volatility of the stock market in general and technology-based companies in particular, announcements concerning us, our suppliers, our competitors or our customers or licensees and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. Further, increased volatility in the financial markets and/or overall economic conditions may reduce the amounts that we realize in the future on our cash equivalents and/

[0001728949-18-000011:mdna:251]
or marketable securities and may reduce our earnings as a result of any impairment charges that we record to reduce recorded values of marketable securities to their fair values.

[0001728949-18-000011:mdna:252]
In the past, securities class action litigation has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-18-000011:mdna:253]
We maintain an extensive investment portfolio of varied holdings, which are generally classified as available-for-sale and are therefore recorded on our consolidated balance sheet at fair value, with unrealized gains or losses reported as a component of accumulated other comprehensive income. The fair values of our investments are subject to fluctuation based primarily on market price volatility, as well as the underlying operations of the associated investment, among other things. If the fair value of such investments decreases below their cost basis, as some of our previous investments have, we may be required in certain circumstances to recognize a loss in our results of operations. The sensitivity of and risks associated with the market value of our investment portfolio are described more fully in our Annual Report on Form 10-K for our fiscal year ended September 24, 2017 and “Part I, Item 3. Quantitative and Qualitative Disclosures About Market Risk” in this Quarterly Report.

[0001728949-18-000011:mdna:254]
[same as prior period, unchanged from 0001234452-17-000154:mdna:244]

[0001728949-18-000011:mdna:255]
[same as prior period, unchanged from 0001234452-17-000154:mdna:245]

[0001728949-18-000011:mdna:256]
[same as prior period, unchanged from 0001234452-17-000154:mdna:246]

[0001728949-18-000011:mdna:257]
[same as prior period, unchanged from 0001234452-17-000154:mdna:247]

[0001728949-18-000011:mdna:258]
[same as prior period, unchanged from 0001234452-17-000154:mdna:248]

[0001728949-18-000011:mdna:259]
[same as prior period, unchanged from 0001234452-17-000154:mdna:249]

[0001728949-18-000011:mdna:260]
Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to general economic conditions, industry cycles and financial, business and other factors, including factors which negatively impact our cash flows, such as licensees withholding some or all of the royalty payments they owe to us or paying fines in connection with regulatory investigations, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations in the future to service our debt, we may be required to, among other things: refinance or restructure all or a portion of our indebtedness; reduce or delay planned capital or operating expenditures; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing and/or restructuring are higher than our current rates, interest expense related to such refinancing and/or restructuring would increase. If there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt in the future and/or the terms of such debt could be adversely affected.

[0001728949-18-000011:mdna:261]
Our business and operations could suffer in the event of security breaches or other misappropriation of our intellectual property or proprietary or confidential information.

[0001728949-18-000011:mdna:262]
Attempts by others to gain unauthorized access to our information technology systems are increasingly more sophisticated. These attempts, which might be related to industrial or other espionage, include covertly introducing malware to our computers and networks, including those in our manufacturing operations, and impersonating authorized users, among others. In addition, employees and former employees, in particular former employees who become employees of our competitors, customers or licensees, may misappropriate, use, publish or provide to our competitors, customers or licensees our intellectual property and/or proprietary or confidential business information. We seek to detect and investigate all security incidents and to prevent their recurrence, but in some cases, we might be unaware of an incident or its magnitude and effects. The theft, unauthorized use or publication of our intellectual property and/or proprietary or confidential business information could harm our competitive position, reduce the value of our investment in research and development and other strategic initiatives and/or otherwise adversely affect our business. To the extent any security breach results in inappropriate disclosure of our customers’ or licensees’ proprietary or confidential information, we may incur liability. We expect to continue to devote significant resources to the security of our information technology systems.

[0001728949-18-000011:mdna:263]
[same as prior period, unchanged from 0001234452-17-000154:mdna:266]

[0001728949-18-000011:mdna:264]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-United States headquarters is located. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed. Our current examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. Although we believe that our tax estimates are reasonable at December 24, 2017, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision, results of operations and/or cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-18-000011:mdna:265]
On December 22, 2017, tax reform legislation known as the Tax Cuts and Jobs Act (the Tax Legislation) was enacted in the United States. Given the amount and complexity of the changes in tax law resulting from the Tax Legislation, we have not finalized the accounting for the income tax effects of the Tax Legislation. This includes the provisional amounts recorded in the first quarter of fiscal 2018 related to the repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (Toll Charge) and the remeasurement of deferred taxes. Further, we are in the process of analyzing the effects of new taxes due on certain foreign income, such as GILTI (global intangible low-taxed income), BEAT (base-erosion anti-abuse tax), FDII (foreign-derived intangible income) and limitations on interest expense deductions (if certain conditions apply) that are effective starting in fiscal 2019, and other provisions of the Tax Legislation. The impact of the Tax Legislation may differ from this estimate, possibly materially, during the one-year measurement period due to, among other things, further refinement of our calculations, changes in interpretations and assumptions we have made, guidance that may be issued and actions we may take as a result of the Tax Legislation.

[0001728949-18-000011:mdna:266]
We have tax incentives in Singapore provided that we meet specified employment and other criteria, and as a result of the expiration of these incentives, our Singapore tax rate increased in fiscal 2017 and is expected to increase again in fiscal 2027. If we do not meet the criteria required to retain such incentives, our Singapore tax rate could increase prior to fiscal 2027, and our results of operations and cash flows could be adversely affected.

[0001728949-18-000011:mdna:267]
Tax rules may change in a manner that adversely affects our future reported results of operations or the way we conduct our business. Further changes in the tax laws of foreign jurisdictions could arise as a result of the base erosion and profit shifting (BEPS) project that was undertaken by the Organization for Economic Co-operation and Development (OECD). The OECD, which represents a coalition of member countries, recommended changes to numerous long-standing tax principles related to transfer pricing. These changes, if adopted by countries, could increase tax uncertainty and may adversely affect our provision for income taxes, results of operations and/or cash flow. We have not yet determined what changes, if any, may be needed to our operations or structure to address BEPS. If our effective tax rates were to increase, particularly in the United States or Singapore, our results of operations, cash flows and/or financial condition could be adversely affected.

[0001728949-18-000011:mdna:268]
[same as prior period, unchanged from 0001234452-17-000154:mdna:251]

[0001728949-18-000011:mdna:269]
[same as prior period, unchanged from 0001234452-17-000154:mdna:252]

[0001728949-18-000011:mdna:270]
[same as prior period, unchanged from 0001234452-17-000154:mdna:253]

[0001728949-18-000011:mdna:271]
Our future success depends largely upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them, which may become increasingly difficult given the uncertainty created by Broadcom’s unsolicited bid to acquire the Company and in an environment of cost reductions. Implementing our business strategy requires specialized engineering and other talent, as our

[0001728949-18-000011:mdna:272]
56

[0001728949-18-000011:mdna:273]
revenues are highly dependent on technological and product innovations. The market for employees in our industry is extremely competitive. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001728949-18-000011:mdna:274]
[same as prior period, unchanged from 0001234452-17-000154:mdna:255]

[0001728949-18-000011:mdna:275]
Our customers sell their products throughout the world in various currencies. Our consolidated revenues from international customers and licensees as a percentage of our total revenues were greater than 90% in each of the last three fiscal years. Adverse movements in currency exchange rates may negatively affect our business, revenues, results of operations and/or cash flows due to a number of factors, including, among others:

[0001728949-18-000011:mdna:276]
[same as prior period, unchanged from 0001234452-17-000154:mdna:257]

[0001728949-18-000011:mdna:277]
[same as prior period, unchanged from 0001234452-17-000154:mdna:258]

[0001728949-18-000011:mdna:278]
| • | Our foreign suppliers may raise their prices if they are impacted by currency fluctuations, resulting in higher than expected costs and lower margins; |

[0001728949-18-000011:mdna:279]
| • | Certain of our costs that are derived from supply contracts denominated in foreign currencies could increase; and/or |

[0001728949-18-000011:mdna:280]
[same as prior period, unchanged from 0001234452-17-000154:mdna:260]

[0001728949-18-000011:mdna:281]
[same as prior period, unchanged from 0001234452-17-000154:mdna:262]

[0001728949-18-000011:mdna:282]
The use of devices containing our products to interact with untrusted systems or otherwise access untrusted content creates a risk of exposing the system hardware and software in those devices to malicious attacks. While we continue to focus on this issue and are taking measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and use cases, and increasing the risk of security failures. Further, our products are inherently complex and may contain defects or errors that are detected only when the products are in use. Because our products and services are responsible for critical functions in our customers’ products and/or networks, security failures, defects or errors in our products or services could have an adverse impact on us, on our customers and/or on the end users of our customers’ products. Such adverse impact could include shipment delays; product liability claims or recalls; write-offs of our inventories, property, plant and equipment and/or intangible assets; unfavorable purchase commitments; a shift of business to our competitors; a decrease in demand for connected devices and wireless services; damage to our reputation and to our customer relationships; regulatory actions; and other financial liability or harm to our business. Further, security failures, defects or errors in the products of our customers or licensees could have an adverse impact on our results of operations and/or cash flows due to a delay or decrease in demand for our products or services generally, and our premium-tier products in particular, among other factors. Development of products and features in new domains of technology and the migration to integrated circuit technologies with smaller geometric feature sizes are complex and add risk to manufacturing yields and reliability. Further, manufacturing, testing, marketing and use of our products and those of our customers and licensees entail the risk of product liability.
