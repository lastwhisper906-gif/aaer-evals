# QCOM 8-K — 0001728949-18-000010 filed 2018-01-31

## item codes, every 8-K on or before 2018-01-31

- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2018-01-31

- none on or before 2018-01-31

## item 2.02 — earnings release, exhibit 99.1

[0001728949-18-000010:8k_2_02:1]
EX-99.1
2
qcom122417erex991.htm
EXHIBIT 99.1

[0001728949-18-000010:8k_2_02:2]
Exhibit

[0001728949-18-000010:8k_2_02:3]
Exhibit 99.1

[0001728949-18-000010:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001728949-18-000010:8k_2_02:5]
Qualcomm Contact:

[0001728949-18-000010:8k_2_02:6]
John Sinnott

[0001728949-18-000010:8k_2_02:7]
Vice President, Investor Relations

[0001728949-18-000010:8k_2_02:8]
Phone: 1-858-658-4813

[0001728949-18-000010:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001728949-18-000010:8k_2_02:10]
Qualcomm Announces First Quarter Fiscal 2018 Results

[0001728949-18-000010:8k_2_02:11]
GAAP Revenues $6.1 billion

[0001728949-18-000010:8k_2_02:12]
GAAP Loss per Share $4.03, reflecting Tax Reform and European Commission Fine

[0001728949-18-000010:8k_2_02:13]
Non-GAAP Earnings per Share $0.98

[0001728949-18-000010:8k_2_02:14]
SAN DIEGO - January 31, 2018 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal first quarter ended December 24, 2017.

[0001728949-18-000010:8k_2_02:15]
“Our fiscal first quarter results reflect continued strong performance in our semiconductor business, as well as continued strength in 3G/4G handset ASPs,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “We recently detailed our roadmap for value creation, outlining the significant growth potential for Qualcomm as we enter the 5G world and our products and technologies expand into attractive new markets.”

[0001728949-18-000010:8k_2_02:16]
First Quarter Results (GAAP)*

[0001728949-18-000010:8k_2_02:17]
|  | Q1 Fiscal 2018 |  | Q1 Fiscal 2017 |  | Year-Over-Year Change |  | Q4 Fiscal 2017 |  | Sequential Change |
| Revenues | $6.1B |  | $6.0B |  | +1% |  | $5.9B |  | +3% |
| Operating income | $0.0B |  | $0.8B |  | (96%) |  | $0.3B |  | (91%) |
| Net (loss) income 1 | ($6.0B) |  | $0.7B |  | N/M |  | $0.2B |  | N/M |
| Diluted (loss) earnings per share 1 | ($4.03) |  | $0.46 |  | N/M |  | $0.11 |  | N/M |
| Operating cash flow 2 | $1.8B |  | $1.6B |  | +11% |  | $2.4B |  | (27%) |

[0001728949-18-000010:8k_2_02:18]
1 Throughout this news release, net (loss) income and diluted (loss) earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests), unless otherwise stated.

[0001728949-18-000010:8k_2_02:19]
2 In the first quarter of fiscal 2018, we adopted new accounting guidance that changed the presentation of certain cash flows related to share-based awards in the statement of cash flows. As a result, prior period cash flow amounts presented in this news release have been adjusted to conform to the current year presentation as follows: net cash provided by operating activities for the first and fourth quarters of fiscal 2017 increased by $207 million and $7 million, respectively, with corresponding offsets to net cash used in financing activities.

[0001728949-18-000010:8k_2_02:20]
First Quarter Results (Non-GAAP)*

[0001728949-18-000010:8k_2_02:21]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding the Company’s use of Non-GAAP financial measures and detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001728949-18-000010:8k_2_02:22]
|  | Q1 Fiscal 2018 |  | Q1 Fiscal 2017 |  | Year-Over-Year Change |  | Q4 Fiscal 2017 |  | Sequential Change |
| Revenues | $6.0B |  | $6.0B |  | +1% |  | $6.0B |  | +1% |
| Operating income | $1.6B |  | $2.1B |  | (21%) |  | $1.6B |  | +4% |
| Net income | $1.5B |  | $1.8B |  | (18%) |  | $1.4B |  | +7% |
| Diluted earnings per share | $0.98 |  | $1.19 |  | (18%) |  | $0.92 |  | +7% |

[0001728949-18-000010:8k_2_02:23]
* The first quarter of fiscal 2018 and fourth quarter of fiscal 2017 GAAP and Non-GAAP results were negatively impacted by our continued dispute with Apple and its contract manufacturers (who are Qualcomm licensees), as well as the previously disclosed dispute with another licensee.  We did not record any QTL revenues in the first quarter of fiscal 2018 or fourth quarter of fiscal 2017 for royalties due on sales of Apple’s or the other licensee’s products.  The first quarter of fiscal 2017 results included approximately $740 million in QTL revenues related to the products of Apple and the other licensee in dispute.  We expect the actions taken by these licensees will continue until the respective disputes are resolved.

[0001728949-18-000010:8k_2_02:24]
The following also should be considered in regard to the year-over-year and sequential comparisons:

[0001728949-18-000010:8k_2_02:25]
| • | The first quarter of fiscal 2018 GAAP results included: |

[0001728949-18-000010:8k_2_02:26]
| ◦ | $6.0 billion charge, or ($4.03) per share, relating to the enactment of the Tax Cuts and Jobs Act (the Tax Legislation) in the United States (U.S.), which was comprised of $5.3 billion related to the estimated one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge), $562 million resulting from the estimated impact of remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate and $86 million resulting from our decision to no longer indefinitely reinvest certain foreign earnings. We currently estimate that we will pay $3.3 billion for the Toll Charge, after application of certain tax credits, which is payable in installments over eight years beginning on January 15, 2019. |

[0001728949-18-000010:8k_2_02:27]
| ◦ | $1.2 billion charge, or ($0.76) per share, for the fine imposed by the European Commission (EC), for which we intend to provide a financial guarantee to satisfy the obligation. |

[0001728949-18-000010:8k_2_02:28]
| • | The first quarter of fiscal 2017 GAAP results included: |

[0001728949-18-000010:8k_2_02:29]
| ◦ | $868 million charge, or ($0.49) per share, for the fine imposed by the Korea Fair Trade Commission (KFTC). |

[0001728949-18-000010:8k_2_02:30]
| • | The fourth quarter of fiscal 2017 GAAP results included: |

[0001728949-18-000010:8k_2_02:31]
| ◦ | $778 million charge, or ($0.52) per share, for the fine imposed by the Taiwan Fair Trade Commission (TFTC), which will be paid in 60 monthly installments beginning on January 30, 2018. |

[0001728949-18-000010:8k_2_02:32]
Segment Results

[0001728949-18-000010:8k_2_02:33]
First Quarter Fiscal 2018

[0001728949-18-000010:8k_2_02:34]
| (in millions except percentages) | Q1 Fiscal 2018 |  | Q1 Fiscal 2017 |  | Year-Over-Year Change |  | Q4 Fiscal 2017 |  | Sequential Change |
| QCT |  |  |  |  |  |  |  |  |  |
| Revenues | $4,651 |  | $4,101 |  | +13% |  | $4,650 |  | —% |
| EBT 1 | $955 |  | $724 |  | +32% |  | $973 |  | (2%) |
| EBT as % of revenues | 21% |  | 18% |  | +3% |  | 21% |  | —% |
| MSMTM chip shipments | 237 |  | 217 |  | +9% |  | 220 |  | +8% |
| QTL |  |  |  |  |  |  |  |  |  |
| Revenues | $1,299 |  | $1,811 |  | (28%) |  | $1,213 |  | +7% |
| EBT | $887 |  | $1,532 |  | (42%) |  | $829 |  | +7% |
| EBT as % of revenues | 68% |  | 85% |  | (17%) |  | 68% |  | —% |

[0001728949-18-000010:8k_2_02:35]
1 Earnings (loss) before taxes

[0001728949-18-000010:8k_2_02:36]
Cash and Marketable Securities

[0001728949-18-000010:8k_2_02:37]
Our cash, cash equivalents and marketable securities totaled $39.9 billion at the end of the first quarter of fiscal 2018, compared to $29.8 billion a year ago and $38.6 billion at the end of the fourth quarter of fiscal 2017.  In addition, funds of $2.0 billion were held to collateralize the letters of credit related to our proposed acquisition of NXP, which have been recorded as other noncurrent assets since the end of the first quarter of fiscal 2017.

[0001728949-18-000010:8k_2_02:38]
Announced Agreement to Acquire NXP

[0001728949-18-000010:8k_2_02:39]
On October 27, 2016, we announced a definitive agreement to acquire NXP Semiconductors N.V. (NXP) for estimated total cash to be paid to NXP’s shareholders of $38 billion.  NXP is a leader in high-performance, mixed-signal semiconductor electronics in automotive, broad-based microcontrollers, secure identification, network processing and RF power products.  The transaction is subject to receipt of regulatory clearance under applicable laws and other closing conditions, including the tender of at least

[0001728949-18-000010:8k_2_02:40]
80% of the issued and outstanding common shares of NXP in the offer (provided that the minimum tender threshold may be reduced to a percentage not less than 70% with the prior written consent of NXP).  The transaction is expected to close in early calendar 2018.  We intend to fund the transaction with cash generated from our May 2017 debt offering, as well as cash, cash equivalents and marketable securities held by our foreign entities, which will result in the use of a substantial portion of our cash, cash equivalents and marketable securities, and the use of a Term Loan Facility, which is expected to be drawn on at close.

[0001728949-18-000010:8k_2_02:41]
Return of Capital to Stockholders

[0001728949-18-000010:8k_2_02:42]
During the first quarter of fiscal 2018, we returned $1.1 billion to stockholders, including $844 million, or $0.57 per share, of cash dividends paid and $225 million through repurchases of 3.7 million shares of common stock.  On January 12, 2018, we announced a cash dividend of $0.57 per share payable on March 21, 2018 to stockholders of record as of the close of business on February 28, 2018.

[0001728949-18-000010:8k_2_02:43]
Effective Income Tax Rates

[0001728949-18-000010:8k_2_02:44]
On December 22, 2017, the Tax Legislation was enacted in the U.S., which significantly revises the U.S. corporate income tax by, among other things, lowering the corporate income tax rate to 21%, implementing a modified territorial tax system (effective in fiscal 2019) and imposing the Toll Charge.  Our fiscal 2018 annual effective income tax rates are estimated to be 297 percent for GAAP and 8 percent for Non-GAAP.  The GAAP effective tax rate for the first quarter of fiscal 2018 and estimated annual effective tax rate for fiscal 2018 included a preliminary charge of $6.0 billion recorded discretely in the first quarter of fiscal 2018, which was comprised of $5.3 billion related to the estimated Toll Charge, $562 million resulting from the estimated impact of remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate and $86 million resulting from our decision to no longer indefinitely reinvest certain foreign earnings.  The impact of the Tax Legislation may differ from this estimate, possibly materially.

[0001728949-18-000010:8k_2_02:45]
The GAAP effective tax rate for the first quarter fiscal 2018 and estimated annual effective tax rate for fiscal 2018 also included the tax impact of the $1.2 billion EC fine, which is not deductible for tax purposes and is attributable to a foreign jurisdiction.  The estimated fiscal 2018 GAAP and Non-GAAP effective tax rates included the impact of lower income from U.S. operations, primarily related to decreased QTL revenues from Apple’s contract manufacturers and the other licensee in dispute, as well as the reduced U.S. corporate tax rate, which was effective January 1, 2018.

[0001728949-18-000010:8k_2_02:46]
Business Outlook

[0001728949-18-000010:8k_2_02:47]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment, certain derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001728949-18-000010:8k_2_02:48]
On January 16, 2018, we announced a cost reduction plan designed to align our cost structure to our long-term margin targets.  As part of this plan, we will implement a series of targeted reductions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business.  We expect these cost reductions to be fully captured in fiscal 2019 results.  We are in the process of finalizing our plan, as well as the restructuring and restructuring-related costs we expect to incur to execute our plan. Accordingly, our second quarter of fiscal 2018 outlook does not include any restructuring and restructuring-related costs that will result from this plan.  Such future restructuring and restructuring-related costs will be excluded as “Other Items” from our Non-GAAP results.

[0001728949-18-000010:8k_2_02:49]
We have not included estimates related to the operating results of our proposed acquisition of NXP in our second quarter of fiscal 2018 outlook.

[0001728949-18-000010:8k_2_02:50]
Our financial guidance for the second quarter of fiscal 2018 excludes QTL revenues for royalties due on the sale of Apple products by Apple’s contract manufacturers, as well as the sale of products by the other licensee in dispute as we expect the actions taken by these licensees will continue until the respective disputes are resolved.

[0001728949-18-000010:8k_2_02:51]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001728949-18-000010:8k_2_02:52]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001728949-18-000010:8k_2_02:53]
|  |  | Q2 FY17Results (1) | Current Guidance Q2 FY18 Estimates (2) |  |
|  | Revenues | $5.0B | $4.8B - $5.6B |  |  |
|  | Year-over-year change |  | decrease 4% - increase 12% |  |  |
|  | GAAP diluted earnings per share (EPS) | $0.50 | $0.41 - $0.51 |  |  |
|  | Year-over-year change |  | decrease 18% - increase 2% |  |  |
|  | Less diluted EPS attributable to QSI | $0.00 |  | $0.03 |  |  |
|  | Less diluted EPS attributable to share-based compensation | ($0.14) |  | ($0.14 | ) |  |
|  | Less diluted EPS attributable to other items | ($0.69) |  | ($0.13 | ) |  |
|  | Non-GAAP diluted EPS | $1.34 | $0.65 - $0.75 |  |  |
|  | Year-over-year change |  | decrease 44% - 51% |  |  |
|  | Other Information |  |  |  |
|  | MSM chip shipments | 179 | M | 170M - 190M |  |  |
|  | Year-over-year change |  | decrease 5% - increase 6% |  |  |
|  | QTL revenues | $2.2B | $1.15B - $1.35B |  |  |
|  | Year-over-year change |  | decrease 40% - 49% |  |  |

[0001728949-18-000010:8k_2_02:54]
| (1) | The second quarter of fiscal 2017 GAAP results included a $974 million reduction to revenues, or ($0.48) per share, related to the BlackBerry arbitration decision. Diluted EPS attributable to other items for the second quarter of fiscal 2017 was primarily attributable to the reduction to revenues related to the BlackBerry arbitration decision and acquisition-related items. The second quarter of fiscal 2017 results included QTL revenues related to the products of Apple’s contract manufacturers and the other licensee in dispute. |

[0001728949-18-000010:8k_2_02:55]
| (2) | Our financial guidance for the second quarter of fiscal 2018 excludes QTL revenues for royalties due on the sale of Apple’s products by Apple’s contract manufacturers, as well as the sale of products by the other licensee in dispute as we expect the actions taken by these licensees will continue until the respective disputes are resolved. Our guidance for diluted EPS attributable to other items for the second quarter of fiscal 2018 is primarily attributable to acquisition-related items. |

[0001728949-18-000010:8k_2_02:56]
Sums may not equal total due to rounding.

[0001728949-18-000010:8k_2_02:57]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-18-000010:8k_2_02:58]
The following tables reconcile our GAAP results to our Non-GAAP results ($ in millions, except per share data):

[0001728949-18-000010:8k_2_02:59]
|  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) | Non-GAAP Results |
| Q1 FISCAL 2018 |  |  |  |  |  |  |  |
| Revenues | $6,068 |  | $30 |  |  | $— |  |  |  | $— |  |  | $6,038 |  |
| Operating income (loss) | 29 |  | 9 |  | (248) |  | (1,367) |  | 1,635 |  |
| EBT | (27) |  | 11 |  | (248) |  | (1,373) |  | 1,583 |  |
| EBT as % of revenues | — | % |  |  |  |  |  |  |  | 26 | % |  |
| Net (loss) income | (5,953) |  | 8 |  | (199) |  | (7,230) |  | 1,468 |  |
| Diluted EPS (c) | ($4.03) |  | $0.01 |  | ($0.13) |  | ($4.89) |  | $0.98 |  |
| Diluted shares (c) | 1,477 |  | 1,491 |  | 1,491 |  | 1,491 |  | 1,491 |  |
| Q4 FISCAL 2017 |  |  |  |  |  |  |  |
| Revenues | $5,905 |  | $43 |  | $0 |  | ($95) |  | $5,957 |  |
| Operating income (loss) | 333 |  | 22 |  | (204) |  | (1,063) |  | 1,578 |  |
| EBT | 434 |  | 28 |  | (204) |  | (1,065) |  | 1,675 |  |
| EBT as % of revenues | 7 | % |  |  |  |  |  |  |  | 28 | % |  |
| Net income (loss) | 168 |  | 25 |  | (153) |  | (1,079) |  | 1,375 |  |
| Diluted EPS | $0.11 |  | $0.02 |  | ($0.10) |  | ($0.73) |  | $0.92 |  |
| Diluted shares | 1,488 |  | 1,488 |  | 1,488 |  | 1,488 |  | 1,488 |  |
| Q1 FISCAL 2017 |  |  |  |  |  |  |  |
| Revenues | $5,999 |  | $14 |  |  | $— |  |  |  | $— |  |  | $5,985 |  |
| Operating income (loss) | 778 |  | (2) |  | (239) |  | (1,054) |  | 2,073 |  |
| EBT | 870 |  | (17) |  | (239) |  | (1,065) |  | 2,191 |  |
| EBT as % of revenues | 15 | % |  |  |  |  |  |  |  | 37 | % |  |
| Net income (loss) | 682 |  | (11) |  | (190) |  | (900) |  | 1,783 |  |
| Diluted EPS | $0.46 |  | ($0.01) |  | ($0.13) |  | ($0.60) |  | $1.19 |  |
| Diluted shares | 1,495 |  | 1,495 |  | 1,495 |  | 1,495 |  | 1,495 |  |

[0001728949-18-000010:8k_2_02:60]
| (a) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” herein for further details. |

[0001728949-18-000010:8k_2_02:61]
| (b) | Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates.” Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001728949-18-000010:8k_2_02:62]
| (c) | As a result of the net loss in our GAAP results in the first quarter of fiscal 2018, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of GAAP diluted loss per share. The diluted EPS impacts of the $6.0 billion charge resulting from the Tax Legislation and the $1.2 billion charge related to the fine imposed by the EC were calculated using the GAAP diluted shares. Amounts in all other columns included the common share equivalents issuable under share-based compensation plans in the calculation of diluted earnings per share because the Company reported Non-GAAP net income. |

[0001728949-18-000010:8k_2_02:63]
Sums may not equal totals due to rounding.

[0001728949-18-000010:8k_2_02:64]
Supplemental Information and Reconciliations

[0001728949-18-000010:8k_2_02:65]
(Unaudited)

[0001728949-18-000010:8k_2_02:66]
|  | Q1 FISCAL 2018 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results |
|  | Cost of revenues |  | $2,663 |  |  | $18 |  |  | $10 |  |  | $106 |  |  | $2,529 |  |
|  | Research and development (R&D) expenses |  | 1,420 |  |  | — |  |  |  | 156 |  |  | 2 |  |  | 1,262 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 773 |  |  | 3 |  |  | 82 |  |  | 76 |  |  | 612 |  |
|  | Other expenses |  | 1,183 |  |  | — |  |  |  | — |  |  |  | 1,183 |  |  | — |  |  |
|  | Interest expense |  | 170 |  |  | — |  |  |  | — |  |  |  | 3 |  |  | 167 |  |
|  | Investment and other income, net |  | 114 |  |  | 2 |  |  | — |  |  |  | (3) |  |  | 115 | (b) |

[0001728949-18-000010:8k_2_02:67]
| (a) | Other items excluded from Non-GAAP results included a $1.2 billion charge related to the fine imposed by the EC, $187 million of acquisition-related charges and $3 million of net foreign currency transaction losses related to the TFTC fine. |

[0001728949-18-000010:8k_2_02:68]
| (b) | Included $121 million in interest and dividend income and $10 million in net realized gains on investments, partially offset by $12 million in equity in net losses of investees and $4 million in other net investment losses. |

[0001728949-18-000010:8k_2_02:69]
Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates

[0001728949-18-000010:8k_2_02:70]
(Unaudited)

[0001728949-18-000010:8k_2_02:71]
|  |  | GAAP Results |  |  | Less QSI | Less Share-Based Compensation | Less Other Items (c)(d) |  | Non-GAAP Results |  |
| Q1 FISCAL 2018 ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | (27 | ) |  |  | $ | 11 |  |  |  | $ | (248 | ) |  |  | $ | (1,373 | ) |  |  | $ | 1,583 |  |  |
| Income tax (expense) benefit |  | (5,926 | ) |  |  | (3 | ) |  |  | 49 |  |  |  | (5,857 | ) |  |  | (115 | ) |  |
| Net (loss) income (a) |  | $ | (5,953 | ) |  |  | $ | 8 |  |  |  | $ | (199 | ) |  |  | $ | (7,230 | ) |  |  | $ | 1,468 |  |  |
| Tax rate |  | (21,948 | %) |  |  | 0 | % | (b) |  |  |  | (2 | %) | (b) |  |  | (21,953 | %) | (b) |  |  | 7 | % |  |
| FISCAL 2018 ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Estimated annual tax rate |  | 297 | % |  |  | 0 | % | (b) |  |  |  | (1 | %) | (b) |  |  | 290 | % | (b) |  |  | 8 | % |  |

[0001728949-18-000010:8k_2_02:72]
| (a) | Before adjustments for noncontrolling interests. |

[0001728949-18-000010:8k_2_02:73]
| (b) | The incremental effect of our adjustments to the Non-GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001728949-18-000010:8k_2_02:74]
| (c) | In the first quarter of fiscal 2018, tax expense in the “Other Items” column included a $6.0 billion charge resulting from the enactment of the Tax Legislation, partially offset by a $45 million tax benefit to reconcile the tax provision for each column to the total GAAP tax provision for the quarter, a $30 million tax benefit for the tax effect of acquisition-related items in EBT and a $21 million tax benefit for the combined effect of other items in EBT. |

[0001728949-18-000010:8k_2_02:75]
| (d) | In fiscal 2018, the estimated annual effective tax rate for the “Other Items” column included a $6.0 billion charge resulting from the enactment of the Tax Legislation, partially offset by a $119 million tax benefit for the tax effect of acquisition-related items in EBT and a $24 million tax benefit for the combined effect of other items in EBT. |

[0001728949-18-000010:8k_2_02:76]
Conference Call

[0001728949-18-000010:8k_2_02:77]
Qualcomm’s fiscal first quarter 2018 earnings conference call will be broadcast live on January 31, 2018, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://

[0001728949-18-000010:8k_2_02:78]
investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 39466104.

[0001728949-18-000010:8k_2_02:79]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-18-000010:8k_2_02:80]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results used herein are presented herein.

[0001728949-18-000010:8k_2_02:81]
The Company uses Non-GAAP financial information: (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income (loss) and diluted earnings (loss) per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating the Company’s business and assessing trends and future expectations.

[0001728949-18-000010:8k_2_02:82]
Non-GAAP information used by management excludes its QSI segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-18-000010:8k_2_02:83]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001728949-18-000010:8k_2_02:84]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001728949-18-000010:8k_2_02:85]
| • | Certain other items are excluded because management views such items as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001728949-18-000010:8k_2_02:86]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items, as well as any effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property, third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition. Starting with acquisitions in the second quarter of fiscal 2017, the Company excludes recognition of the step-up of property, plant and equipment from the net book value based on the original cost basis to fair value. Such charges related to acquisitions that were completed prior to the second quarter of fiscal 2017 continue to be allocated to the segments, and such amounts are not material. |

[0001728949-18-000010:8k_2_02:87]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. |

[0001728949-18-000010:8k_2_02:88]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. In the first quarter of fiscal 2018, the Company excluded the full impact of the Toll Charge, including the portion that relates to earnings and profits of U.S.-owned foreign subsidiaries generated in the first quarter of fiscal 2018. |

[0001728949-18-000010:8k_2_02:89]
About Qualcomm

[0001728949-18-000010:8k_2_02:90]
Qualcomm invents breakthrough technologies that transform how the world connects and communicates.  When we connected the phone to the Internet, the mobile revolution was born.  Today, our inventions are the foundation for life-changing products, experiences, and industries.  As we lead the world to 5G, we envision this next big change in cellular technology spurring a new era of intelligent, connected devices and enabling new opportunities in connected cars, remote delivery of health care services, and the IoT - including smart cities, smart homes, and wearables.  Qualcomm Incorporated includes our licensing

[0001728949-18-000010:8k_2_02:91]
business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, all of our engineering, research and development functions, and all of our products and services businesses, including, our QCT semiconductor business.  For more information, visit www.qualcomm.com.

[0001728949-18-000010:8k_2_02:92]
Note Regarding Forward-Looking Statements

[0001728949-18-000010:8k_2_02:93]
respect to, any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0001728949-18-000010:8k_2_02:94]
###

[0001728949-18-000010:8k_2_02:95]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries. Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-18-000010:8k_2_02:96]
MSM is a product of Qualcomm Technologies, Inc.

[0001728949-18-000010:8k_2_02:97]
Qualcomm Incorporated

[0001728949-18-000010:8k_2_02:98]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001728949-18-000010:8k_2_02:99]
(In millions, except per share data)

[0001728949-18-000010:8k_2_02:100]
(Unaudited)

[0001728949-18-000010:8k_2_02:101]
|  | December 24, 2017 |  | September 24, 2017 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 33,362 |  |  | $ | 35,029 |  |
| Marketable securities | 2,041 |  |  | 2,279 |  |
| Accounts receivable, net | 3,053 |  |  | 3,632 |  |
| Inventories | 1,872 |  |  | 2,035 |  |
| Other current assets | 638 |  |  | 618 |  |
| Total current assets | 40,966 |  |  | 43,593 |  |
| Marketable securities | 4,447 |  |  | 1,270 |  |
| Deferred tax assets | 1,241 |  |  | 2,900 |  |
| Property, plant and equipment, net | 3,224 |  |  | 3,216 |  |
| Goodwill | 6,638 |  |  | 6,623 |  |
| Other intangible assets, net | 3,548 |  |  | 3,737 |  |
| Other assets | 4,287 |  |  | 4,147 |  |
| Total assets | $ | 64,351 |  |  | $ | 65,486 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,685 |  |  | $ | 1,971 |  |
| Payroll and other benefits related liabilities | 1,041 |  |  | 1,183 |  |
| Unearned revenues | 487 |  |  | 502 |  |
| Short-term debt | 3,465 |  |  | 2,495 |  |
| Other current liabilities | 5,349 |  |  | 4,756 |  |
| Total current liabilities | 12,027 |  |  | 10,907 |  |
| Unearned revenues | 1,906 |  |  | 2,003 |  |
| Income taxes payable | 3,867 |  |  | — |  |
| Long-term debt | 19,381 |  |  | 19,398 |  |
| Other liabilities | 3,246 |  |  | 2,432 |  |
| Total liabilities | 40,427 |  |  | 34,740 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,480 and 1,474 shares issued and outstanding, respectively | 265 |  |  | 274 |  |
| Retained earnings | 23,273 |  |  | 30,088 |  |
| Accumulated other comprehensive income | 386 |  |  | 384 |  |
| Total stockholders’ equity | 23,924 |  |  | 30,746 |  |
| Total liabilities and stockholders’ equity | $ | 64,351 |  |  | $ | 65,486 |  |

[0001728949-18-000010:8k_2_02:102]
Qualcomm Incorporated

[0001728949-18-000010:8k_2_02:103]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-18-000010:8k_2_02:104]
(In millions, except per share data)

[0001728949-18-000010:8k_2_02:105]
(Unaudited)

[0001728949-18-000010:8k_2_02:106]
|  | Three Months Ended |
|  | December 24, 2017 |  | December 25, 2016 |
| Revenues: |  |  |  |
| Equipment and services | $ | 4,704 |  |  | $ | 4,139 |  |
| Licensing | 1,364 |  |  | 1,860 |  |
| Total revenues | 6,068 |  |  | 5,999 |  |
| Costs and expenses: |  |  |  |
| Cost of revenues | 2,663 |  |  | 2,443 |  |
| Research and development | 1,420 |  |  | 1,311 |  |
| Selling, general and administrative | 773 |  |  | 591 |  |
| Other | 1,183 |  |  | 876 |  |
| Total costs and expenses | 6,039 |  |  | 5,221 |  |
| Operating income | 29 |  |  | 778 |  |
| Interest expense | (170 | ) |  | (90 | ) |
| Investment and other income, net | 114 |  |  | 182 |  |
| (Loss) income before income taxes | (27 | ) |  | 870 |  |
| Income tax expense | (5,926 | ) |  | (189 | ) |
| Net (loss) income | (5,953 | ) |  | 681 |  |
| Net loss attributable to noncontrolling interests | — |  |  | 1 |  |
| Net (loss) income attributable to Qualcomm | $ | (5,953 | ) |  | $ | 682 |  |
| Basic (loss) earnings per share attributable to Qualcomm | $ | (4.03 | ) |  | $ | 0.46 |  |
| Diluted (loss) earnings per share attributable to Qualcomm | $ | (4.03 | ) |  | $ | 0.46 |  |
| Shares used in per share calculations: |  |  |  |
| Basic | 1,477 |  |  | 1,478 |  |
| Diluted | 1,477 |  |  | 1,495 |  |
| Dividends per share announced | $ | 0.57 |  |  | $ | 0.53 |  |

[0001728949-18-000010:8k_2_02:107]
Qualcomm Incorporated

[0001728949-18-000010:8k_2_02:108]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-18-000010:8k_2_02:109]
(In millions)

[0001728949-18-000010:8k_2_02:110]
(Unaudited)

[0001728949-18-000010:8k_2_02:111]
|  | Three Months Ended |
|  | December 24, 2017 |  | December 25, 2016 |
| Operating Activities: |  |  |  |
| Net (loss) income | $ | (5,953 | ) |  | $ | 681 |  |
| Adjustments to reconcile net (loss) income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization expense | 363 |  |  | 329 |  |
| Indefinite and long-lived asset impairment charges | — |  |  | 32 |  |
| Income tax provision in excess of (less than) income tax payments | 5,697 |  |  | (113 | ) |
| Non-cash portion of share-based compensation expense | 248 |  |  | 239 |  |
| Net realized gains on marketable securities and other investments | (23 | ) |  | (147 | ) |
| Impairment losses on marketable securities and other investments | 9 |  |  | 143 |  |
| Other items, net | 57 |  |  | (4 | ) |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable, net | 581 |  |  | 131 |  |
| Inventories | 162 |  |  | (354 | ) |
| Other assets | (56 | ) |  | (16 | ) |
| Trade accounts payable | (248 | ) |  | (208 | ) |
| Payroll, benefits and other liabilities | 1,000 |  |  | 957 |  |
| Unearned revenues | (75 | ) |  | (84 | ) |
| Net cash provided by operating activities | 1,762 |  |  | 1,586 |  |
| Investing Activities: |  |  |  |
| Capital expenditures | (226 | ) |  | (129 | ) |
| Purchases of available-for-sale marketable securities | (5,627 | ) |  | (4,117 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 2,704 |  |  | 6,891 |  |
| Deposits of investments designated as collateral | — |  |  | (1,950 | ) |
| Acquisitions and other investments, net of cash acquired | (122 | ) |  | (57 | ) |
| Other items, net | 10 |  |  | 43 |  |
| Net cash (used) provided by investing activities | (3,261 | ) |  | 681 |  |
| Financing Activities: |  |  |  |
| Proceeds from short-term debt | 2,116 |  |  | 2,727 |  |
| Repayment of short-term debt | (1,149 | ) |  | (2,727 | ) |
| Proceeds from issuance of common stock | 134 |  |  | 131 |  |
| Repurchases and retirements of common stock | (225 | ) |  | (444 | ) |
| Dividends paid | (844 | ) |  | (784 | ) |
| Payments of tax withholdings related to vesting of share-based awards | (192 | ) |  | (172 | ) |
| Other items, net | (5 | ) |  | (42 | ) |
| Net cash used by financing activities | (165 | ) |  | (1,311 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (3 | ) |  | (17 | ) |
| Net (decrease) increase in cash and cash equivalents | (1,667 | ) |  | 939 |  |
| Cash and cash equivalents at beginning of period | 35,029 |  |  | 5,946 |  |
| Cash and cash equivalents at end of period | $ | 33,362 |  |  | $ | 6,885 |  |
