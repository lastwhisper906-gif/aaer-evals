# QCOM 8-K — 0001234452-16-000482 filed 2016-07-20

## item codes, every 8-K on or before 2016-07-20

- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2016-07-20

- none on or before 2016-07-20

## item 2.02 — earnings release, exhibit 99.1

[0001234452-16-000482:8k_2_02:1]
EX-99.1
2
qcom62616erex991.htm
EXHIBIT 99.1

[0001234452-16-000482:8k_2_02:2]
Exhibit

[0001234452-16-000482:8k_2_02:3]
Exhibit 99.1

[0001234452-16-000482:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-16-000482:8k_2_02:5]
Qualcomm Contact:

[0001234452-16-000482:8k_2_02:6]
Warren Kneeshaw

[0001234452-16-000482:8k_2_02:7]
Vice President, Investor Relations

[0001234452-16-000482:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-16-000482:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-16-000482:8k_2_02:10]
Qualcomm Announces Third Quarter Fiscal 2016 Results

[0001234452-16-000482:8k_2_02:11]
Revenues $6.0 billion

[0001234452-16-000482:8k_2_02:12]
GAAP EPS $0.97, Non-GAAP EPS $1.16

[0001234452-16-000482:8k_2_02:13]
-EPS Exceeds High End of Prior Guidance-

[0001234452-16-000482:8k_2_02:14]
SAN DIEGO - July 20, 2016 - Qualcomm Incorporated (NASDAQ: QCOM), a leading developer and innovator of advanced wireless technologies, products and services, today announced results for its fiscal third quarter ended June 26, 2016.

[0001234452-16-000482:8k_2_02:15]
“We delivered strong results this quarter, with EPS well ahead of our guidance based on meaningful progress with licensees in China,” said Steve Mollenkopf, CEO of Qualcomm Incorporated. “Our chipset business is also benefiting from a strong new product ramp across tiers, particularly with fast growing OEMs in China. We are executing well on our strategic priorities, and we remain confident that our focused investments in 5G and other advanced technologies will create a strong foundation for long-term earnings growth.”

[0001234452-16-000482:8k_2_02:16]
Third Quarter Results (GAAP)*

[0001234452-16-000482:8k_2_02:17]
|  | Q3 Fiscal 2016 |  | Q3 Fiscal 2015 |  | Year-Over-Year Change |  | Q2 Fiscal 2016 |  | Sequential Change |
| Revenues | $6.0B |  | $5.8B |  | +4% |  | $5.6B |  | +9% |
| Operating income | $1.6B |  | $1.2B |  | +29% |  | $1.4B |  | +13% |
| Net income 1 | $1.4B |  | $1.2B |  | +22% |  | $1.2B |  | +24% |
| Diluted earnings per share 1 | $0.97 |  | $0.73 |  | +33% |  | $0.78 |  | +24% |
| Operating cash flow | $1.8B |  | $2.1B |  | (13%) |  | $0.7B |  | N/M |

[0001234452-16-000482:8k_2_02:18]
1 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests), unless otherwise stated.

[0001234452-16-000482:8k_2_02:19]
Non-GAAP Third Quarter Results*

[0001234452-16-000482:8k_2_02:20]
|  | Q3 Fiscal 2016 |  | Q3 Fiscal 2015 |  | Year-Over-Year Change |  | Q2 Fiscal 2016 |  | Sequential Change |
| Revenues | $6.0B |  | $5.8B |  | +3% |  | $5.5B |  | +9% |
| Operating income | $2.0B |  | $1.7B |  | +19% |  | $1.9B |  | +8% |
| Net income | $1.7B |  | $1.6B |  | +7% |  | $1.6B |  | +11% |
| Diluted earnings per share | $1.16 |  | $0.99 |  | +17% |  | $1.04 |  | +12% |

[0001234452-16-000482:8k_2_02:21]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding the Company’s use of Non-GAAP financial measures and detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-16-000482:8k_2_02:22]
* The following should be considered in regards to the year-over-year and sequential comparisons:

[0001234452-16-000482:8k_2_02:23]
| • | The third quarter of fiscal 2016 GAAP and Non-GAAP results included: |

[0001234452-16-000482:8k_2_02:24]
| ◦ | $235 million of revenues, or $0.11 per share, due to the recognition of previously deferred royalty revenues related to the dismissal of the arbitration with LG Electronics, Inc. |

[0001234452-16-000482:8k_2_02:25]
| • | The second quarter of fiscal 2016 GAAP and Non-GAAP results included: |

[0001234452-16-000482:8k_2_02:26]
| ◦ | $266 million of revenues, or $0.13 per share, due to the termination of an infrastructure license agreement resulting from the merger of two licensees. |

[0001234452-16-000482:8k_2_02:27]
| • | The third quarter of fiscal 2015 GAAP results included: |

[0001234452-16-000482:8k_2_02:28]
| ◦ | $142 million of charges, or $0.08 per share, that resulted from an impairment of goodwill and long-lived assets related to one of our display businesses. |

[0001234452-16-000482:8k_2_02:29]
Third Quarter Key Business Metrics

[0001234452-16-000482:8k_2_02:30]
|  | Q3 Fiscal 2016 |  | Q3 Fiscal 2015 |  | Year-Over-Year Change (1) |  | Q2 Fiscal 2016 |  | Sequential Change (1) |
| MSMTM chip shipments | 201M |  | 225M |  | (11%) |  | 189M |  | +6% |
| Total reported device sales (2) | $62.6B |  | $60.4B |  | +4% |  | $70.1B |  | (11%) |
| Est. reported 3G/4G device shipments (approx.) (2) | 321M - 325M |  | 289M - 293M |  | +11% |  | 335M - 339M |  | (4%) |
| Est. reported 3G/4G average selling price (approx.) (2) | $191 - $197 |  | $205 - $211 |  | (7%) |  | $205 - $211 |  | (7%) |

[0001234452-16-000482:8k_2_02:31]
| (1) | The year-over-year and sequential changes for estimated reported 3G/4G device shipments and average selling prices are calculated at the midpoints. The midpoints of the estimated ranges are used for comparison purposes only and do not indicate a higher degree of confidence in the midpoints. |

[0001234452-16-000482:8k_2_02:32]
| (2) | The third quarter of fiscal 2015 and 2016 are based on sales by our licensees in the March quarter as reported to us in the June quarter, and the second quarter of fiscal 2016 is based on sales by our licensees in the December quarter as reported to us in the March quarter. |

[0001234452-16-000482:8k_2_02:33]
The third quarter of fiscal 2016 total reported device sales include reporting of certain prior period sales from a small number of licensees in China that have not been reporting under their existing agreements while still in discussions regarding new licenses related to the resolution with the China National

[0001234452-16-000482:8k_2_02:34]
Development and Reform Commission (NDRC).  This development reflects the continued progress in negotiations with these companies.

[0001234452-16-000482:8k_2_02:35]
Cash and Marketable Securities

[0001234452-16-000482:8k_2_02:36]
Our cash, cash equivalents and marketable securities totaled $31.0 billion at the end of the third quarter of fiscal 2016, compared to $35.2 billion a year ago and $30.0 billion at the end of the second quarter of fiscal 2016.

[0001234452-16-000482:8k_2_02:37]
Return of Capital to Stockholders

[0001234452-16-000482:8k_2_02:38]
During the third quarter of fiscal 2016, we returned $881 million to stockholders, including $781 million, or $0.53 per share, of cash dividends paid and $100 million through repurchases of 1.8 million shares of common stock.  On July 12, 2016, we announced a cash dividend of $0.53 per share payable on September 21, 2016 to stockholders of record as of the close of business on August 31, 2016.

[0001234452-16-000482:8k_2_02:39]
Effective Income Tax Rates

[0001234452-16-000482:8k_2_02:40]
Our fiscal 2016 annual effective income tax rates are estimated to be approximately 17 percent for GAAP and approximately 18 percent for Non-GAAP.  The effective income tax rates for the third quarter of fiscal 2016 were 15 percent for GAAP and 19 percent for Non-GAAP.  The effective tax rate for GAAP of 15 percent for the third quarter of fiscal 2016 was less than the estimated annual effective tax rate of 17 percent primarily due to a $101 million tax benefit recorded discretely in the third quarter resulting from a worthless stock deduction on a domestic subsidiary of our former QMT division, partially offset by changes in our estimates related to foreign earnings taxed at rates that are less than the United States federal tax rate and the benefit of the retroactive reinstatement of the United States federal research and development credit recorded discretely during the first quarter of fiscal 2016 related to fiscal 2015.

[0001234452-16-000482:8k_2_02:41]
Business Outlook

[0001234452-16-000482:8k_2_02:42]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment and certain derivative gains or losses, cannot be accurately

[0001234452-16-000482:8k_2_02:43]
forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.  Our outlook includes an estimate of the benefit related to stock repurchases that we plan to complete.  We have not included any estimates related to the proposed joint venture with TDK Corporation in our fiscal 2016 outlook.  The joint venture is expected to close by early calendar 2017.

[0001234452-16-000482:8k_2_02:44]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-16-000482:8k_2_02:45]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001234452-16-000482:8k_2_02:46]
|  |  | Q4 FY15 Results | Current Guidance Q4 FY16 Estimates |
|  | Revenues |  | $5.5 | B | $5.4B - $6.2B |  |  |
|  | Year-over-year change |  | decrease 1% - increase 14% |  |  |
|  | GAAP diluted earnings per share (EPS) |  | $0.67 |  | $0.84 - $0.94 |  |  |
|  | Year-over-year change |  | increase 25% - 40% |  |  |
|  | Less diluted EPS attributable to QSI |  | $0.01 |  |  | $0.01 |  |  |
|  | Less diluted EPS attributable to share-based compensation |  | ($0.12 | ) |  | ($0.13 | ) |  |
|  | Less diluted EPS attributable to other items (1) |  | ($0.12 | ) |  | ($0.09 | ) |  |
|  | Non-GAAP diluted EPS |  | $0.91 |  | $1.05 - $1.15 |  |  |
|  | Year-over-year change |  | increase 15% - 26% |  |  |
|  | Metrics |  |  |  |
|  | MSM chip shipments | 203 | M | 195M - 215M |  |  |
|  | Year-over-year change |  | decrease 4% - increase 6% |  |  |
|  | Total reported device sales* (2) | approx. $58.3B | approx. $57.0B - $65.0B |  | (3) |
|  | Year-over-year change |  | decrease 2% - increase 11% |  |  |
|  | *Est. sales in June quarter, reported in September quarter |  |  |  |

[0001234452-16-000482:8k_2_02:47]
| (1) | Our guidance for diluted EPS attributable to other items for the fourth quarter of fiscal 2016 includes a loss per share of $0.07 for acquisition-related items. |

[0001234452-16-000482:8k_2_02:48]
| (2) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). The reported quarterly estimated ranges of average selling prices (ASPs) and unit shipments are determined based on the information as reported to us by our licensees during the relevant period and our own estimates of the selling prices and unit shipments for licensees that do not provide such information. Not all licensees report sales, selling prices and/or unit shipments the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales, estimated unit shipments and estimated ASPs for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-16-000482:8k_2_02:49]
| (3) | Our guidance range for the fourth quarter of fiscal 2016 total reported device sales reflects estimated 3G/4G total reported device sales that we currently expect to be reported to us, which includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-16-000482:8k_2_02:50]
Sums may not equal totals due to rounding.

[0001234452-16-000482:8k_2_02:51]
Reconciliation of Non-GAAP Results to GAAP Results

[0001234452-16-000482:8k_2_02:52]
The following table reconciles our Non-GAAP results to our GAAP results ($ in millions, except per share data):

[0001234452-16-000482:8k_2_02:53]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (a) | Non-GAAP Results | QSI | Share-Based Compensation | Other Items (b) (c) (d) |  | GAAP Results |
| Q3 - FISCAL 2016 |  |  |  |  |  |
| Revenues | $3,853 | $2,038 | $141 | $6,032 |  | $12 |  |  | $— |  |  | $— |  |  | $6,044 |  |
| Change from prior year | — |  | 6 | % | N/M |  | 3 | % |  | N/M |  |  |  |  |  | 4 | % |  |
| Change from prior quarter | 15 | % | (5 | %) | N/M |  | 9 | % |  | — |  |  |  |  |  | 9 | % |  |
| Operating income (loss) |  |  |  | $2,032 |  | ($2) |  | ($235) | ($203) |  | $1,592 |  |
| Change from prior year |  |  |  | 19 | % |  | 90 | % |  | 13 | % | (12 | %) |  | 29 | % |  |
| Change from prior quarter |  |  |  | 8 | % |  | N/M |  |  | 5 | % | 10 | % |  | 13 | % |  |
| EBT | $365 | $1,749 | $22 | $2,136 |  | ($5) |  | ($235) | ($203) |  | $1,693 |  |
| Change from prior year | 26 | % | 6 | % | N/M |  | 12 | % |  | 90 | % |  | 13 | % | (12 | %) |  | 21 | % |  |
| Change from prior quarter | N/M |  | (6 | %) | N/M |  | 13 | % |  | N/M |  |  | 5 | % | 10 | % |  | 15 | % |  |
| EBT as % of revenues | 9 | % | 86 | % | 16 | % | 35 | % |  |  |  |  |  |  | 28 | % |  |
| Net income (loss) |  |  |  | $1,729 |  | ($4) |  | ($197) | ($84) |  | $1,444 |  |
| Change from prior year |  |  |  | 7 | % |  | 85 | % |  | 8 | % | 55 | % |  | 22 | % |  |
| Change from prior quarter |  |  |  | 11 | % |  | N/M |  |  | 10 | % | 58 | % |  | 24 | % |  |
| Diluted EPS |  |  |  | $1.16 |  | $0.00 |  | ($0.13) | ($0.06) |  | $0.97 |  |
| Change from prior year |  |  |  | 17 | % |  | N/M |  |  | — |  | 50 | % |  | 33 | % |  |
| Change from prior quarter |  |  |  | 12 | % |  | N/M |  |  | 13 | % | 54 | % |  | 24 | % |  |
| Diluted shares |  |  |  | 1,486 |  | 1,486 |  | 1,486 | 1,486 |  | 1,486 |  |
| Q2 - FISCAL 2016 |  |  |  |  |  |
| Revenues | $3,337 | $2,135 | $67 | $5,539 |  | $12 |  |  | $— |  |  | $— |  |  | $5,551 |  |
| Operating income (loss) |  |  |  | 1,885 |  | 3 |  | (247) | (226) |  | 1,415 |  |
| EBT | $170 | $1,857 | ($130) | 1,897 |  | 46 |  | (247) | (226) |  | 1,470 |  |
| Net income (loss) |  |  |  | 1,552 |  | 30 |  | (220) | (198) |  | 1,164 |  |
| Diluted EPS |  |  |  | $1.04 |  | $0.02 |  | ($0.15) | ($0.13) |  | $0.78 |  |
| Diluted shares |  |  |  | 1,498 |  | 1,498 |  | 1,498 | 1,498 |  | 1,498 |  |
| Q3 - FISCAL 2015 |  |  |  |  |  |
| Revenues | $3,853 | $1,931 | $48 | $5,832 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $5,832 |  |
| Operating income (loss) |  |  |  | 1,709 |  | (21) |  | (271) | (182) |  | 1,235 |  |
| EBT | $289 | $1,654 | ($43) | 1,900 |  | (49) |  | (271) | (182) |  | 1,398 |  |
| Net income (loss) |  |  |  | 1,611 |  | (26) |  | (213) | (188) |  | 1,184 |  |
| Diluted EPS |  |  |  | $0.99 |  | ($0.02) |  | ($0.13) | ($0.12) |  | $0.73 |  |
| Diluted shares |  |  |  | 1,629 |  | 1,629 |  | 1,629 | 1,629 |  | 1,629 |  |

[0001234452-16-000482:8k_2_02:54]
| (a) | Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations. Non-GAAP reconciling items related to earnings before taxes consisted primarily of certain research and development expenses, selling, general and administrative expenses, other expenses or income, interest expense and certain investment income that are not allocated to the segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit. |

[0001234452-16-000482:8k_2_02:55]
| (b) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates” herein for further details. |

[0001234452-16-000482:8k_2_02:56]
| (c) | Details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates.” |

[0001234452-16-000482:8k_2_02:57]
| (d) | Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001234452-16-000482:8k_2_02:58]
Supplemental Information and Reconciliations

[0001234452-16-000482:8k_2_02:59]
(Unaudited)

[0001234452-16-000482:8k_2_02:60]
|  | Q3 - FISCAL 2016 |  |
|  | ($ in millions) | Non-GAAP Results | QSI | Share-Based Compensation | Other Items (a) | GAAP Results |
|  | Cost of equipment and services revenues |  | $2,395 |  |  | $9 |  |  | $10 |  |  | $120 |  |  | $2,534 |  |
|  | Research and development expenses |  | 1,093 |  |  | 1 |  |  | 152 |  |  | 22 |  |  | 1,268 |  |
|  | Selling, general and administrative expenses |  | 512 |  |  | 4 |  |  | 73 |  |  | 31 |  |  | 620 |  |
|  | Other expenses |  | — |  |  |  | — |  |  |  | — |  |  |  | 30 |  |  | 30 |  |
|  | Interest expense |  | (75) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (75) |  |
|  | Investment income (loss), net |  | 179 | (b) |  | (3) | (c) |  | — |  |  |  | — |  |  |  | 176 |  |

[0001234452-16-000482:8k_2_02:61]
| (a) | In the third quarter of fiscal 2016, other items excluded from Non-GAAP EBT included $124 million of acquisition-related charges, $44 million in asset impairment charges, $30 million of restructuring and restructuring-related charges related to our Strategic Realignment Plan and $5 million of other severance costs. |

[0001234452-16-000482:8k_2_02:62]
| (b) | Included $152 million in interest and dividend income and $52 million in net realized gains on investments, partially offset by $20 million in other-than-temporary losses on investments and $5 million in other net investment expense. |

[0001234452-16-000482:8k_2_02:63]
| (c) | Included $13 million in other-than-temporary losses on investments and $11 million in equity in losses of investees, partially offset by $17 million in net realized gains on investments and $4 million in interest and dividend income. |

[0001234452-16-000482:8k_2_02:64]
Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates

[0001234452-16-000482:8k_2_02:65]
(Unaudited)

[0001234452-16-000482:8k_2_02:66]
| Q3 - FISCAL 2016 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  | Share-Based Compensation |  | Other Items (c) |  |  | GAAP Results |  |
| Income (loss) before income taxes |  | $ | 2,136 |  |  |  | $ | (5 | ) |  |  | $ | (235 | ) |  |  | $ | (203 | ) |  |  | $ | 1,693 |  |  |
| Income tax (expense) benefit |  | (407 | ) |  |  | — |  |  |  | 38 |  |  |  | 119 |  |  |  | (250 | ) |  |
| Net income (loss) (a) |  | $ | 1,729 |  |  |  | $ | (5 | ) |  |  | $ | (197 | ) |  |  | $ | (84 | ) |  |  | $ | 1,443 |  |  |
| Tax rate |  | 19 | % |  |  | 0 | % | (b) |  |  | 0 | % | (b) |  |  | (4 | %) | (b) |  |  | 15 | % |  |
| 12 MONTHS - FISCAL 2016 |
|  |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  | Other Items (d) |  |  | GAAP Results |  |
| Estimated annual tax rate |  | 18 | % |  |  | 1 | % | (b) |  |  | 0 | % | (b) |  |  | (2 | %) | (b) |  |  | 17 | % |  |

[0001234452-16-000482:8k_2_02:67]
| (a) | Before adjustments for noncontrolling interests. |

[0001234452-16-000482:8k_2_02:68]
| (b) | The incremental effect of our Non-GAAP adjustments to the GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001234452-16-000482:8k_2_02:69]
| (c) | In the third quarter of fiscal 2016, the tax benefit in the “Other Items” column included a $101 million tax benefit for a worthless stock deduction, a $20 million tax benefit for the combined tax effect of other items in EBT and a $16 million tax benefit for the tax effect of acquisition-related items in EBT, partially offset by a $18 million tax expense to reconcile the tax provision for each column to the total GAAP tax provision for the quarter. |

[0001234452-16-000482:8k_2_02:70]
| (d) | In fiscal 2016, the estimated annual effective tax rate for the “Other Items” column includes tax benefits of $101 million for a worthless stock deduction and $79 million related to fiscal 2015 as a result of the retroactive reinstatement of the federal R&D tax credit, along with a tax benefit for the combined tax effect of acquisition-related items and other items in EBT. |

[0001234452-16-000482:8k_2_02:71]
Conference Call

[0001234452-16-000482:8k_2_02:72]
Qualcomm’s fiscal third quarter 2016 earnings conference call will be broadcast live on July 20, 2016, beginning at 1:30 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial

[0001234452-16-000482:8k_2_02:73]
and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 44801007.

[0001234452-16-000482:8k_2_02:74]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-16-000482:8k_2_02:75]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-16-000482:8k_2_02:76]
The Company uses the Non-GAAP financial information:  (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of equipment and services revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial information also is used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0001234452-16-000482:8k_2_02:77]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items, tax items and other items.

[0001234452-16-000482:8k_2_02:78]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-16-000482:8k_2_02:79]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001234452-16-000482:8k_2_02:80]
| • | Certain other items are excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001234452-16-000482:8k_2_02:81]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items starting with acquisitions completed in the third quarter of fiscal 2011, as well as any tax effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property and third-party acquisition and integration services costs. |

[0001234452-16-000482:8k_2_02:82]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and litigation settlements and/or damages. |

[0001234452-16-000482:8k_2_02:83]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. |

[0001234452-16-000482:8k_2_02:84]
About Qualcomm

[0001234452-16-000482:8k_2_02:85]
Qualcomm Incorporated (NASDAQ: QCOM) is a world leader in 3G, 4G and next-generation wireless technologies.  Qualcomm Incorporated includes Qualcomm’s licensing business, QTL, and the vast majority of its patent portfolio.  Qualcomm Technologies, Inc., a wholly-owned subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of Qualcomm’s engineering, research and development functions, and substantially all of its products and services businesses, including its semiconductor business, QCT.  For more than 30 years, Qualcomm ideas and inventions have driven the evolution of digital communications, linking people everywhere more closely to information, entertainment and each other.  For more information, visit www.qualcomm.com.

[0001234452-16-000482:8k_2_02:86]
Note Regarding Forward-Looking Statements

[0001234452-16-000482:8k_2_02:87]
###

[0001234452-16-000482:8k_2_02:88]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-16-000482:8k_2_02:89]
Qualcomm Incorporated

[0001234452-16-000482:8k_2_02:90]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001234452-16-000482:8k_2_02:91]
(In millions, except per share data)

[0001234452-16-000482:8k_2_02:92]
(Unaudited)

[0001234452-16-000482:8k_2_02:93]
|  | June 26, 2016 |  | September 27, 2015 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 5,885 |  |  | $ | 7,560 |  |
| Marketable securities | 11,225 |  |  | 9,761 |  |
| Accounts receivable, net | 1,939 |  |  | 1,964 |  |
| Inventories | 1,338 |  |  | 1,492 |  |
| Deferred tax assets | — |  |  | 635 |  |
| Other current assets | 592 |  |  | 687 |  |
| Total current assets | 20,979 |  |  | 22,099 |  |
| Marketable securities | 13,922 |  |  | 13,626 |  |
| Deferred tax assets | 2,075 |  |  | 1,453 |  |
| Property, plant and equipment, net | 2,341 |  |  | 2,534 |  |
| Goodwill | 5,657 |  |  | 5,479 |  |
| Other intangible assets, net | 3,669 |  |  | 3,742 |  |
| Other assets | 2,143 |  |  | 1,863 |  |
| Total assets | $ | 50,786 |  |  | $ | 50,796 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,572 |  |  | $ | 1,300 |  |
| Payroll and other benefits related liabilities | 874 |  |  | 861 |  |
| Unearned revenues | 535 |  |  | 583 |  |
| Short-term debt | 1,749 |  |  | 1,000 |  |
| Other current liabilities | 2,113 |  |  | 2,356 |  |
| Total current liabilities | 6,843 |  |  | 6,100 |  |
| Unearned revenues | 2,426 |  |  | 2,496 |  |
| Long-term debt | 10,024 |  |  | 9,969 |  |
| Other liabilities | 855 |  |  | 817 |  |
| Total liabilities | 20,148 |  |  | 19,382 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,473 and 1,524 shares issued and outstanding, respectively | 169 |  |  | — |  |
| Retained earnings | 30,134 |  |  | 31,226 |  |
| Accumulated other comprehensive income | 344 |  |  | 195 |  |
| Total Qualcomm stockholders’ equity | 30,647 |  |  | 31,421 |  |
| Noncontrolling interests | (9 | ) |  | (7 | ) |
| Total stockholders’ equity | 30,638 |  |  | 31,414 |  |
| Total liabilities and stockholders’ equity | $ | 50,786 |  |  | $ | 50,796 |  |

[0001234452-16-000482:8k_2_02:94]
Qualcomm Incorporated

[0001234452-16-000482:8k_2_02:95]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-16-000482:8k_2_02:96]
(In millions, except per share data)

[0001234452-16-000482:8k_2_02:97]
(Unaudited)

[0001234452-16-000482:8k_2_02:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26, 2016 |  | June 28, 2015 |  | June 26, 2016 |  | June 28, 2015 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,875 |  |  | $ | 3,840 |  |  | $ | 11,311 |  |  | $ | 13,459 |  |
| Licensing | 2,169 |  |  | 1,992 |  |  | 6,059 |  |  | 6,366 |  |
| Total revenues | 6,044 |  |  | 5,832 |  |  | 17,370 |  |  | 19,825 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of equipment and services revenues | 2,534 |  |  | 2,451 |  |  | 7,210 |  |  | 8,126 |  |
| Research and development | 1,268 |  |  | 1,407 |  |  | 3,922 |  |  | 4,133 |  |
| Selling, general and administrative | 620 |  |  | 621 |  |  | 1,817 |  |  | 1,749 |  |
| Other | 30 |  |  | 118 |  |  | (270 | ) |  | 1,181 |  |
| Total costs and expenses | 4,452 |  |  | 4,597 |  |  | 12,679 |  |  | 15,189 |  |
| Operating income | 1,592 |  |  | 1,235 |  |  | 4,691 |  |  | 4,636 |  |
| Interest expense | (75 | ) |  | (32 | ) |  | (221 | ) |  | (34 | ) |
| Investment income, net | 176 |  |  | 195 |  |  | 403 |  |  | 634 |  |
| Income before income taxes | 1,693 |  |  | 1,398 |  |  | 4,873 |  |  | 5,236 |  |
| Income tax expense | (250 | ) |  | (215 | ) |  | (770 | ) |  | (1,029 | ) |
| Net income | 1,443 |  |  | 1,183 |  |  | 4,103 |  |  | 4,207 |  |
| Net loss attributable to noncontrolling interests | 1 |  |  | 1 |  |  | 3 |  |  | 2 |  |
| Net income attributable to Qualcomm | $ | 1,444 |  |  | $ | 1,184 |  |  | $ | 4,106 |  |  | $ | 4,209 |  |
| Basic earnings per share attributable to Qualcomm | $ | 0.98 |  |  | $ | 0.74 |  |  | $ | 2.76 |  |  | $ | 2.57 |  |
| Diluted earnings per share attributable to Qualcomm | $ | 0.97 |  |  | $ | 0.73 |  |  | $ | 2.74 |  |  | $ | 2.53 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,471 |  |  | 1,608 |  |  | 1,487 |  |  | 1,638 |  |
| Diluted | 1,486 |  |  | 1,629 |  |  | 1,500 |  |  | 1,661 |  |
| Dividends per share announced | $ | 0.53 |  |  | $ | 0.48 |  |  | $ | 1.49 |  |  | $ | 1.32 |  |

[0001234452-16-000482:8k_2_02:99]
Qualcomm Incorporated

[0001234452-16-000482:8k_2_02:100]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-16-000482:8k_2_02:101]
(In millions)

[0001234452-16-000482:8k_2_02:102]
(Unaudited)

[0001234452-16-000482:8k_2_02:103]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26, 2016 |  | June 28, 2015 |  | June 26, 2016 |  | June 28, 2015 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,443 |  |  | $ | 1,183 |  |  | $ | 4,103 |  |  | $ | 4,207 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 356 |  |  | 297 |  |  | 1,092 |  |  | 888 |  |
| Indefinite and long-lived asset impairment charges | 47 |  |  | 166 |  |  | 94 |  |  | 304 |  |
| Income tax provision (less than) in excess of income tax payments | (47 | ) |  | 86 |  |  | (236 | ) |  | 159 |  |
| Gain on sale of wireless spectrum | — |  |  | — |  |  | (380 | ) |  | — |  |
| Non-cash portion of share-based compensation expense | 235 |  |  | 271 |  |  | 730 |  |  | 793 |  |
| Incremental tax benefits from share-based compensation | (1 | ) |  | (20 | ) |  | (3 | ) |  | (98 | ) |
| Net realized gains on marketable securities and other investments | (69 | ) |  | (122 | ) |  | (142 | ) |  | (399 | ) |
| Impairment losses on marketable securities and other investments | 33 |  |  | 55 |  |  | 138 |  |  | 161 |  |
| Other items, net | (47 | ) |  | 2 |  |  | — |  |  | (29 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (215 | ) |  | 100 |  |  | 39 |  |  | 438 |  |
| Inventories | 90 |  |  | 281 |  |  | 169 |  |  | (122 | ) |
| Other assets | 32 |  |  | 241 |  |  | 153 |  |  | (897 | ) |
| Trade accounts payable | 126 |  |  | (261 | ) |  | 263 |  |  | (769 | ) |
| Payroll, benefits and other liabilities | 176 |  |  | (1 | ) |  | (434 | ) |  | (406 | ) |
| Unearned revenues | (319 | ) |  | (162 | ) |  | (270 | ) |  | (408 | ) |
| Net cash provided by operating activities | 1,840 |  |  | 2,116 |  |  | 5,316 |  |  | 3,822 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (136 | ) |  | (366 | ) |  | (389 | ) |  | (815 | ) |
| Purchases of available-for-sale securities | (5,185 | ) |  | (4,360 | ) |  | (12,960 | ) |  | (13,118 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 4,497 |  |  | 3,266 |  |  | 10,303 |  |  | 11,897 |  |
| Purchases of trading securities | — |  |  | (339 | ) |  | (177 | ) |  | (1,034 | ) |
| Proceeds from sales and maturities of trading securities | 23 |  |  | 298 |  |  | 779 |  |  | 1,008 |  |
| Proceeds from sales of other marketable securities | — |  |  | — |  |  | 450 |  |  | — |  |
| Proceeds from sales of property, plant and equipment | 15 |  |  | 128 |  |  | 15 |  |  | 161 |  |
| Acquisitions and other investments, net of cash acquired | (40 | ) |  | (134 | ) |  | (663 | ) |  | (325 | ) |
| Proceeds from sale of wireless spectrum | — |  |  | — |  |  | 232 |  |  | — |  |
| Other items, net | 32 |  |  | (23 | ) |  | 181 |  |  | 6 |  |
| Net cash used by investing activities | (794 | ) |  | (1,530 | ) |  | (2,229 | ) |  | (2,220 | ) |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 2,305 |  |  | 1,718 |  |  | 6,633 |  |  | 2,813 |  |
| Proceeds from long-term debt | — |  |  | 9,937 |  |  | — |  |  | 9,937 |  |
| Repayment of short-term debt | (2,505 | ) |  | (1,813 | ) |  | (5,885 | ) |  | (1,814 | ) |
| Proceeds from issuance of common stock | 151 |  |  | 154 |  |  | 422 |  |  | 571 |  |
| Repurchases and retirements of common stock | (100 | ) |  | (5,405 | ) |  | (3,698 | ) |  | (9,016 | ) |
| Dividends paid | (781 | ) |  | (757 | ) |  | (2,208 | ) |  | (2,142 | ) |
| Incremental tax benefits from share-based compensation | 1 |  |  | 20 |  |  | 3 |  |  | 98 |  |
| Other items, net | (14 | ) |  | 50 |  |  | (32 | ) |  | 41 |  |
| Net cash (used) provided by financing activities | (943 | ) |  | 3,904 |  |  | (4,765 | ) |  | 488 |  |
| Effect of exchange rate changes on cash and cash equivalents | 7 |  |  | 5 |  |  | 3 |  |  | (10 | ) |
| Net increase (decrease) in cash and cash equivalents | 110 |  |  | 4,495 |  |  | (1,675 | ) |  | 2,080 |  |
| Cash and cash equivalents at beginning of period | 5,775 |  |  | 5,492 |  |  | 7,560 |  |  | 7,907 |  |
| Cash and cash equivalents at end of period | $ | 5,885 |  |  | $ | 9,987 |  |  | $ | 5,885 |  |  | $ | 9,987 |  |
