# QCOM MD&A — 0001234452-16-000483


## mdna

[0001234452-16-000483:mdna:1]
[same as prior period, unchanged from 0001234452-16-000429:mdna:1]

[0001234452-16-000483:mdna:2]
[same as prior period, unchanged from 0001234452-16-000429:mdna:2]

[0001234452-16-000483:mdna:3]
[same as prior period, unchanged from 0001234452-16-000429:mdna:3]

[0001234452-16-000483:mdna:4]
[same as prior period, unchanged from 0001234452-16-000429:mdna:4]

[0001234452-16-000483:mdna:5]
Revenues for the third quarter of fiscal 2016 were $6.0 billion, an increase of 4% compared to the year ago quarter, with net income attributable to Qualcomm of $1.4 billion, an increase of 22% compared to the year ago quarter.

[0001234452-16-000483:mdna:6]
| • | We shipped approximately 201 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, a decrease of 11%, compared to approximately 225 million MSM integrated circuits in the year ago quarter. Despite the decline in MSM shipments, QCT’s revenues remained flat compared to the year ago quarter primarily due to the decrease related to lower MSM and accompanying RF and PM unit shipments, offset by net increases in revenues related to higher connectivity shipments resulting from the acquisition of CSR, and the net impact of higher-priced product mix and lower average selling prices. |

[0001234452-16-000483:mdna:7]
| • | Total reported device sales were approximately $62.6 billion, an increase of approximately 4%, compared to approximately $60.4 billion in the year ago quarter.(1) QTL’s revenues increased by 6% compared to the year ago quarter primarily due to the recognition of revenues related to prior periods pertaining to the dismissal of the arbitration with LG Electronics, Inc. (LGE) and an increase in reported sales of CDMA-based products (including multimode products that also implement OFDMA) primarily related to devices shipped in prior periods, partially offset by decreases in revenues per reported unit and recognition of unearned licensed fees. |

[0001234452-16-000483:mdna:8]
Against this backdrop, the following recent developments occurred during the third quarter of fiscal 2016 with respect to key elements of our industry:

[0001234452-16-000483:mdna:9]
[same as prior period, unchanged from 0001234452-16-000429:mdna:9]

[0001234452-16-000483:mdna:10]
| • | Worldwide 3G/4G connections (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) grew sequentially by approximately 4% to approximately 3.8 billion, which was approximately 52% of total cellular connections.(2) |

[0001234452-16-000483:mdna:11]
| (1) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). Not all licensees report sales the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while |

[0001234452-16-000483:mdna:12]
other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales for a particular period may include prior period activity that was not reported by the licensee until such particular period.

[0001234452-16-000483:mdna:13]
| (2) | According to GSMA Intelligence estimates as of July 18, 2016 for the quarter ended June 30, 2016. |

[0001234452-16-000483:mdna:14]
[same as prior period, unchanged from 0001234452-16-000429:mdna:14]

[0001234452-16-000483:mdna:15]
[same as prior period, unchanged from 0001234452-16-000429:mdna:15]

[0001234452-16-000483:mdna:16]
[same as prior period, unchanged from 0001234452-16-000429:mdna:16]

[0001234452-16-000483:mdna:17]
QCT is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products are sold and its system software is licensed to manufacturers that use our products in wireless devices, particularly mobile phones, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards, infrastructure equipment, headsets, sound systems and automobiles and in wired devices, particularly broadband gateway equipment, desktop computers and streaming media players. Our MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Qualcomm Snapdragon processors and LTE modems, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon processors provide advanced application and graphics processing capabilities. QCT’s system software enables the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits. QCT revenues comprised 64% and 66% of total consolidated revenues in the third quarter of fiscal 2016 and 2015, respectively, and 65% and 68% of total consolidated revenues for the first nine months of fiscal 2016 and 2015, respectively.

[0001234452-16-000483:mdna:18]
[same as prior period, unchanged from 0001234452-16-000429:mdna:18]

[0001234452-16-000483:mdna:19]
QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD and/or LTE standards and their derivatives. QTL licensing revenues include license fees and royalties based on sales by licensees of products incorporating or using our intellectual property. License fees are fixed amounts paid in one or more installments. Royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). QTL recognizes royalty revenues based on royalties reported by licensees and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. QTL revenues comprised 34% and 33% of total consolidated revenues in the third quarter of fiscal 2016 and 2015, respectively, and 33% and 31% of total consolidated revenues for the first nine months of fiscal 2016 and 2015, respectively. The vast majority of

[0001234452-16-000483:mdna:20]
such revenues were generated through our licensees’ sales of CDMA-based products (including multimode products that also implement OFDMA), such as feature phones and smartphones.

[0001234452-16-000483:mdna:21]
[same as prior period, unchanged from 0001234452-16-000429:mdna:20]

[0001234452-16-000483:mdna:22]
[same as prior period, unchanged from 0001234452-16-000429:mdna:21]

[0001234452-16-000483:mdna:23]
[same as prior period, unchanged from 0001234452-16-000429:mdna:22]

[0001234452-16-000483:mdna:24]
[same as prior period, unchanged from 0001234452-16-000429:mdna:23]

[0001234452-16-000483:mdna:25]
[same as prior period, unchanged from 0001234452-16-000429:mdna:24]

[0001234452-16-000483:mdna:26]
[same as prior period, unchanged from 0001234452-16-000429:mdna:25]

[0001234452-16-000483:mdna:27]
[same as prior period, unchanged from 0001234452-16-000429:mdna:26]

[0001234452-16-000483:mdna:28]
| • | In February 2015, we reached a resolution with the China National Development and Reform Commission (NDRC) regarding its investigation of us relating to China’s Anti-Monopoly Law and agreed to implement a rectification plan that modifies certain of our business practices in China. The rectification plan provides, among other things, that for licenses of only our 3G and 4G essential Chinese patents for branded devices sold for use in China starting on January 1, 2015 (and reported to us starting in the third quarter of fiscal 2015), we will charge running royalties at royalty rates of 5% for 3G CDMA or WCDMA devices (including multimode 3G/4G devices) and 3.5% for 4G devices that do not implement CDMA or WCDMA (including 3-mode LTE-TDD devices), in each case using a royalty base of 65% of the net selling price. |

[0001234452-16-000483:mdna:29]
| • | Despite the resolution of the NDRC investigation, China continues to present significant challenges for us. We continue to believe that certain licensees are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes 3G/4G units that we believe are not being reported by certain licensees), and certain companies, including unlicensed companies, are delaying execution of new license agreements. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing. We believe that the conclusion of new agreements with these licensees will result in improved reporting by these licensees, including with respect to sales of three-mode devices (i.e., devices that implement GSM, TD-SCDMA and LTE-TDD) sold in China. However, litigation and/or other actions (such as the litigation against Meizu Technology Co., Ltd. described in “Notes to Condensed Consolidated Financial statements, Note 7. Commitments and Contingencies”) may be necessary to compel licensees to report and pay the required royalties for sales they have not previously reported and/or to compel unlicensed companies to execute licenses. |

[0001234452-16-000483:mdna:30]
28

[0001234452-16-000483:mdna:31]
[same as prior period, unchanged from 0001234452-16-000429:mdna:29]

[0001234452-16-000483:mdna:32]
| • | Our business, particularly QCT, expects to be impacted by: concentration of device share among companies within the premium tier; second sourcing decisions made by our large customers with internally or externally sourced alternatives; and intense competition, particularly in China. |

[0001234452-16-000483:mdna:33]
| • | We continue to invest significant resources toward advancements in 4G LTE and 5G technologies, OFDM-based WLAN technologies, audio and video codecs, wireless baseband chips, our converged computing/communications (Snapdragon) chips, graphics, connectivity, multimedia products, software and services, which contribute to the expansion of our intellectual property portfolio. We are also investing in targeted opportunities that utilize our existing technical and business expertise to deploy new business models and enter into new industry segments, such as products for the connected home and the Internet of Things; automotive; networking; mobile computing; small cells and addressing the challenge of meeting the increased demand for data; very high speed connectivity; data centers; mobile health; wireless charging and machine learning, including robotics. |

[0001234452-16-000483:mdna:34]
| • | We expect that 3G/4G device prices will continue to vary broadly due to the increased penetration of smartphones combined with competition throughout the world at all price tiers and growth in sales of non-handset connected devices. Additionally, varying rates of economic growth by region and stronger growth of device shipments in emerging regions as compared to developed regions, are expected to continue to impact the average and range of selling prices of 3G/4G devices. |

[0001234452-16-000483:mdna:35]
| • | In the fourth quarter of fiscal 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders. As part of this Strategic Realignment Plan, among other actions, we are implementing a cost reduction plan and plan to reduce our annual costs from fiscal 2015 levels (adjusted for variable compensation) of $7.3 billion (as announced on July 22, 2015) by approximately $1.1 billion through a series of targeted reductions across Qualcomm’s businesses, particularly in QCT. We also initiated a plan to reduce annual share-based compensation grants by approximately $300 million. We expect these cost reduction initiatives to be substantially implemented by the end of fiscal 2016. Restructuring activities were initiated in the fourth quarter of fiscal 2015, and a total of $300 million in net restructuring and restructuring-related charges were incurred through the third quarter of fiscal 2016. We expect to incur additional restructuring and restructuring-related charges of approximately $25 million to $100 million. |

[0001234452-16-000483:mdna:36]
[same as prior period, unchanged from 0001234452-16-000429:mdna:37]

[0001234452-16-000483:mdna:37]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless value chain and governments as to the benefits of our business model and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not welcome the success of our business model in enabling new, highly cost-effective competitors to their products. We expect that such companies, and/or governments or regulators, will continue to challenge our business model in various forums throughout the world.

[0001234452-16-000483:mdna:38]
[same as prior period, unchanged from 0001234452-16-000429:mdna:39]

[0001234452-16-000483:mdna:39]
[same as prior period, unchanged from 0001234452-16-000429:mdna:40]

[0001234452-16-000483:mdna:40]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26, 2016 |  | June 28, 2015 |  | Change |  | June 26, 2016 |  | June 28, 2015 |  | Change |
| Equipment and services | $ | 3,875 |  |  | $ | 3,840 |  |  | $ | 35 |  |  | $ | 11,311 |  |  | $ | 13,459 |  |  | $ | (2,148 | ) |
| Licensing | 2,169 |  |  | 1,992 |  |  | 177 |  |  | 6,059 |  |  | 6,366 |  |  | (307 | ) |
|  | $ | 6,044 |  |  | $ | 5,832 |  |  | $ | 212 |  |  | $ | 17,370 |  |  | $ | 19,825 |  |  | $ | (2,455 | ) |

[0001234452-16-000483:mdna:41]
The increase in equipment and services revenues in the third quarter of fiscal 2016 was primarily due to increases in revenues from nonreportable segments. The decrease in equipment and services revenues in the first nine months of fiscal 2016 was primarily due to a decrease in QCT revenues of $2.26 billion, partially offset by increases in a nonreportable segment’s revenues and QSI revenues of $51 million and $33 million, respectively. The increase in licensing revenues in the third quarter of fiscal 2016 was primarily due to increases in QTL revenues and a nonreportable segment’s revenues of $107 million and $67 million, respectively. The decrease in licensing revenues in the first nine months of fiscal 2016 was primarily due to a decrease of $382 million in QTL revenues, partially offset by an increase in a nonreportable segment’s revenues of $67 million.

[0001234452-16-000483:mdna:42]
| Costs and Expenses (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26, 2016 |  | June 28, 2015 |  | Change |  | June 26, 2016 |  | June 28, 2015 |  | Change |
| Cost of equipment and services (E&S) revenues | $ | 2,534 |  |  | $ | 2,451 |  |  | $ | 83 |  |  | $ | 7,210 |  |  | $ | 8,126 |  |  | $ | (916 | ) |
| Cost as % of E&S revenues | 65 | % |  | 64 | % |  |  |  | 64 | % |  | 60 | % |  |  |

[0001234452-16-000483:mdna:43]
The decreases in margin percentage in the third quarter and first nine months of fiscal 2016 were driven primarily by the effect of $44 million and $161 million, respectively, in additional charges related to the amortization of intangible assets and recognition of the step-up of inventories to fair value primarily related to the acquisition of CSR plc in the fourth quarter of fiscal 2015 and an increase in a nonreportable segment’s costs. Our margin percentage may fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors.

[0001234452-16-000483:mdna:44]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26, 2016 |  | June 28, 2015 |  | Change |  | June 26, 2016 |  | June 28, 2015 |  | Change |
| Research and development | $ | 1,268 |  |  | $ | 1,407 |  |  | $ | (139 | ) |  | $ | 3,922 |  |  | $ | 4,133 |  |  | $ | (211 | ) |
| % of revenues | 21 | % |  | 24 | % |  |  |  | 23 | % |  | 21 | % |  |  |
| Selling, general, and administrative | $ | 620 |  |  | $ | 621 |  |  | $ | (1 | ) |  | $ | 1,817 |  |  | $ | 1,749 |  |  | $ | 68 |  |
| % of revenues | 10 | % |  | 11 | % |  |  |  | 10 | % |  | 9 | % |  |  |
| Other | $ | 30 |  |  | $ | 118 |  |  | $ | (88 | ) |  | $ | (270 | ) |  | $ | 1,181 |  |  | $ | (1,451 | ) |

[0001234452-16-000483:mdna:45]
The dollar decreases in research and development expenses in the third quarter and first nine months of fiscal 2016 were primarily attributable to decreases of $118 million and $132 million, respectively, in costs related to the development of integrated circuit technologies and related software products. Such decreases were primarily driven by actions initiated under the Strategic Realignment Plan, partially offset by increased research and development costs resulting from acquisitions. The decreases in research and development expenses in the third quarter and first nine months of fiscal 2016 also included decreases of $18 million and $51 million, respectively, in development costs of display technologies and decreases of $24 million and $30 million, respectively, in share-based compensation expense.

[0001234452-16-000483:mdna:46]
The dollar decrease in selling, general and administrative expenses in the third quarter was primarily attributable to decreases of $14 million in professional fees and $12 million in share-based compensation expense, partially offset by an increase of $16 million in costs related to litigation and other legal matters. The dollar increase in selling, general and administrative expenses in the first nine months of fiscal 2016 was primarily attributable to increases of $52 million in costs

[0001234452-16-000483:mdna:47]
[same as prior period, unchanged from 0001234452-16-000429:mdna:57]

[0001234452-16-000483:mdna:48]
related to litigation and other legal matters, $34 million in depreciation and amortization expense and $20 million in selling and marketing expenses, partially offset by a decrease of $31 million in share-based compensation expense.

[0001234452-16-000483:mdna:49]
Other expenses in the third quarter of fiscal 2016 were attributable to $30 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan. Other income in the first nine months of fiscal 2016 was primarily attributable to a $380 million gain on the sale of wireless spectrum and also included $158 million in restructuring and restructuring-related charges, partially offset by a $48 million gain on the sale of our business that provided augmented reality applications, both of which related to our Strategic Realignment Plan.

[0001234452-16-000483:mdna:50]
Other expenses in the third quarter of fiscal 2015 were attributable to $151 million and $11 million in impairment charges on goodwill and intangible assets, respectively, related to the our content services business and one of our display businesses, partially offset by a $44 million gain on the sale of certain property, plant and equipment. Other expenses in the first nine months of fiscal 2015 were attributable to a $975 million charge resulting from the resolution reached with the NDRC and $255 million and $11 million in impairment charges on goodwill and intangible assets, respectively, related to the our content and push-to-talk services and display businesses, partially offset by $60 million in gains on sales of certain property, plant and equipment.

[0001234452-16-000483:mdna:51]
| Interest Expense and Net Investment Income (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26, 2016 |  | June 28, 2015 |  | Change |  | June 26, 2016 |  | June 28, 2015 |  | Change |
| Interest expense | $ | 75 |  |  | $ | 32 |  |  | $ | 43 |  |  | $ | 221 |  |  | $ | 34 |  |  | $ | 187 |  |
| Investment income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 156 |  |  | $ | 128 |  |  | $ | 28 |  |  | $ | 451 |  |  | $ | 400 |  |  | $ | 51 |  |
| Net realized gains on marketable securities | 56 |  |  | 117 |  |  | (61 | ) |  | 99 |  |  | 381 |  |  | (282 | ) |
| Net realized gains on other investments | 13 |  |  | 5 |  |  | 8 |  |  | 43 |  |  | 18 |  |  | 25 |  |
| Impairment losses on marketable securities and other investments | (33 | ) |  | (55 | ) |  | 22 |  |  | (138 | ) |  | (161 | ) |  | 23 |  |
| Equity in net losses of investees | (18 | ) |  | (10 | ) |  | (8 | ) |  | (49 | ) |  | (23 | ) |  | (26 | ) |
| Other | 2 |  |  | 10 |  |  | (8 | ) |  | (3 | ) |  | 19 |  |  | (22 | ) |
|  | $ | 176 |  |  | $ | 195 |  |  | $ | (19 | ) |  | $ | 403 |  |  | $ | 634 |  |  | $ | (231 | ) |

[0001234452-16-000483:mdna:52]
The increase in interest expense in the third quarter and first nine months of fiscal 2016 was primarily due to the issuance of an aggregate principal amount of $10.0 billion in floating- and fixed-rate notes in May 2015.

[0001234452-16-000483:mdna:53]
| Income Tax Expense (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26, 2016 |  | June 28, 2015 |  | Change |  | June 26, 2016 |  | June 28, 2015 |  | Change |
| Income tax expense | $ | 250 |  |  | $ | 215 |  |  | $ | 35 |  |  | $ | 770 |  |  | $ | 1,029 |  |  | $ | (259 | ) |
| Effective tax rate | 15 | % |  | 15 | % |  | — |  |  | 16 | % |  | 20 | % |  | (4 | %) |

[0001234452-16-000483:mdna:54]
The following table summarizes the primary factors that caused our effective tax rates for the third quarter and the first nine months of fiscal 2016 and 2015 to be less than the United States federal statutory rate:

[0001234452-16-000483:mdna:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26, 2016 |  | June 28, 2015 |  | June 26, 2016 |  | June 28, 2015 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |  | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (14 | %) |  | (22 | %) |  | (15 | %) |  | (13 | %) |
| Benefits related to the research and development tax credit | (1 | %) |  | (1 | %) |  | (3 | %) |  | (3 | %) |
| Worthless stock deduction of domestic subsidiary | (6 | %) |  | — |  |  | (2 | %) |  | — |  |
| Tax audit impacts, net | — |  |  | — |  |  | — |  |  | (1 | %) |
| Other | 1 | % |  | 3 | % |  | 1 | % |  | 2 | % |
| Effective tax rate | 15 | % |  | 15 | % |  | 16 | % |  | 20 | % |

[0001234452-16-000483:mdna:56]
The effective tax rate of 15% for the third quarter of fiscal 2016 was less than the estimated annual effective tax rate of 17% primarily due to a $101 million tax benefit recorded discretely in the third quarter resulting from a worthless stock deduction on a domestic subsidiary of our former QMT division, partially offset by changes in our estimates made in the third quarter of fiscal 2016 related to foreign earnings taxed at rates that are less than the United States federal tax rate and the benefit of the retroactive reinstatement of the United States federal research and development credit recorded discretely during the first quarter of fiscal 2016 related to fiscal 2015. The annual effective tax rate of 19% for fiscal 2015 reflected the NDRC fine of $975 million, which was not deductible for tax purposes and was substantially attributable to a foreign jurisdiction, and a $61 million tax benefit as a result of a favorable tax audit settlement with the Internal Revenue Service, both of which were accounted for discretely in the second quarter of fiscal 2015. During the first quarter of fiscal 2015, the United States government reinstated the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. As a result of the reinstatement, the annual effective tax rate for fiscal 2015 also reflected a tax benefit of $101 million in the first quarter of fiscal 2015 related to fiscal 2014. Unrecognized tax benefits were $210 million and $40 million at June 26, 2016 and September 27, 2015, respectively. Certain of our existing tax positions are expected to continue to generate an increase in unrecognized tax benefits through fiscal 2016. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at June 26, 2016 may increase or decrease in the next 12 months.

[0001234452-16-000483:mdna:57]
[same as prior period, unchanged from 0001234452-16-000429:mdna:59]

[0001234452-16-000483:mdna:58]
The following should be read in conjunction with the financial results for the third quarter and first nine months of fiscal 2016 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 8. Segment Information.”

[0001234452-16-000483:mdna:59]
| (in millions) | QCT |  | QTL |  | QSI |
| Three Months Ended June 26, 2016 |  |  |  |  |  |
| Revenues | $ | 3,853 |  |  | $ | 2,038 |  |  | $ | 12 |  |
| EBT (1) | 365 |  |  | 1,749 |  |  | (5 | ) |
| EBT as a % of revenues | 9 | % |  | 86 | % |  |  |  |
| Three Months Ended June 28, 2015 |  |  |  |  |  |
| Revenues | $ | 3,853 |  |  | $ | 1,931 |  |  | $ | — |  |
| EBT (1) | 289 |  |  | 1,654 |  |  | (49 | ) |
| EBT as a % of revenues | 8 | % |  | 86 | % |  |  |
| Nine Months Ended June 26, 2016 |  |  |  |  |  |
| Revenues | $ | 11,285 |  |  | $ | 5,780 |  |  | $ | 33 |  |
| EBT (1) | 1,125 |  |  | 4,945 |  |  | 400 |  |
| EBT as a % of revenues | 10 | % |  | 86 | % |  |  |
| Nine Months Ended June 28, 2015 |  |  |  |  |  |
| Revenues | $ | 13,529 |  |  | $ | 6,162 |  |  | $ | — |  |
| EBT (1) | 2,185 |  |  | 5,395 |  |  | (82 | ) |
| EBT as a % of revenues | 16 | % |  | 88 | % |  |  |

[0001234452-16-000483:mdna:60]
[same as prior period, unchanged from 0001234452-16-000429:mdna:75]

[0001234452-16-000483:mdna:61]
[same as prior period, unchanged from 0001234452-16-000429:mdna:62]

[0001234452-16-000483:mdna:62]
QCT Segment. QCT results of operations in the first nine months of fiscal 2016 were negatively impacted by the effects of a shift in share among our customers within the premium tier, which reduced our sales of integrated Snapdragon processors and skewed our product mix towards lower-margin modem chipsets in this tier, a decline in demand for our thin modem products, a decline in share at a large customer and the competitive environment in China. Equipment and services revenues, mostly related to sales of MSM and accompanying Radio Frequency (RF) and Power Management (PM) integrated circuits, were $3.80 billion in the third quarter of both fiscal 2016 and 2015. Equipment and services revenues in the third quarter of fiscal 2016 remained flat primarily due to a decrease of $343 million related to lower MSM and accompanying RF and PM unit shipments, offset by net increases of $227 million in revenues related to other products, primarily related to higher connectivity shipments resulting from the acquisition of CSR in the fourth quarter of fiscal 2015, and $118 million resulting from the net impact of higher-priced product mix and lower average selling prices. The decrease in QCT revenues in the first nine months of fiscal 2016 of $2.24 billion was primarily due to a decrease in equipment and services revenues. Equipment and services revenues were $11.10 billion and $13.36 billion in the first nine months of fiscal 2016 and 2015, respectively. The decrease in equipment and services revenues in the first nine months of fiscal 2016 resulted primarily from decreases of $1.48 billion related to lower MSM and accompanying RF and PM unit shipments and $1.21 billion from lower average selling prices and lower-priced product mix, partially offset by a net increase of $460 million in revenues related to other products, primarily related to higher connectivity shipments resulting from the acquisition of CSR in the fourth quarter of fiscal 2015. Approximately 201 million and 225 million MSM integrated circuits were sold during the third quarter of fiscal 2016 and 2015, respectively, and approximately 631 million and 728 million MSM integrated circuits were sold during the first nine months of fiscal 2016 and 2015, respectively.

[0001234452-16-000483:mdna:63]
QCT EBT as a percentage of revenues in the third quarter of fiscal 2016 increased primarily due to an increase in gross margin percentage and a combined decrease of 2% in research and development and selling, general and administrative expenses. The increase in QCT gross margin percentage primarily resulted from lower average unit costs and lower excess inventory charges, partially offset by lower average selling prices and lower-margin product mix. QCT EBT as a percentage of revenues in the first nine months of fiscal 2016 decreased primarily due to the impact of lower revenues relative to operating expenses and a decrease in gross margin percentage. The decrease in QCT gross margin percentage primarily resulted from lower average selling prices and lower-margin product mix, partially offset by lower average unit costs and lower excess inventory charges.

[0001234452-16-000483:mdna:64]
QTL Segment. The increase in QTL revenues in the third quarter of fiscal 2016 of $107 million was primarily attributable to the recognition of $235 million of revenues related to prior periods pertaining to the dismissal of the arbitration with LG Electronics, Inc. (LGE) and an increase in reported sales of CDMA-based products (including multimode products that also implement OFDMA) primarily related to devices shipped in prior periods, partially offset by decreases in revenues per reported unit and recognition of unearned license fees. The decrease in QTL revenues in the first nine months of fiscal 2016 of $382 million was primarily attributable to decreases in revenues per reported unit and recognition of unearned license fees, partially offset by $266 million in licensing revenues recorded in the second quarter of fiscal 2016 due to the termination of an infrastructure license agreement resulting from the merger of two licensees and an increase in reported sales of CDMA-based products (including multimode products that also implement OFDMA) primarily related to devices shipped in prior periods. QTL revenues and EBT for the third quarter and first nine months of fiscal 2016 were impacted negatively by units that we believe are not being reported by certain licensees and sales of certain unlicensed products. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing, and additional litigation may become necessary if negotiations fail to resolve the relevant issues.

[0001234452-16-000483:mdna:65]
QSI Segment. The increase in QSI EBT in the third quarter of fiscal 2016 was primarily due to a $28 million decrease in impairment losses on investments and a $15 million decrease in selling, general and administrative expenses. The increase in QSI EBT in the first nine months of fiscal 2016 was primarily due to a $380 million gain on the sale of wireless spectrum, an increase of $58 million in net realized gains on investments and a decrease of $42 million in impairment losses on investments.

[0001234452-16-000483:mdna:66]
[same as prior period, unchanged from 0001234452-16-000429:mdna:70]

[0001234452-16-000483:mdna:67]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. The following tables present selected financial information related to our liquidity as of June 26, 2016 and September 27, 2015 and for the first nine months of fiscal 2016 and 2015 (in millions):

[0001234452-16-000483:mdna:68]
[same as prior period, unchanged from 0001234452-16-000429:mdna:88]

[0001234452-16-000483:mdna:69]
|  | June 26, 2016 |  | September 27, 2015 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 31,032 |  |  | $ | 30,947 |  |  | $ | 85 |  |  | — |  |
| Accounts receivable, net | 1,939 |  |  | 1,964 |  |  | (25 | ) |  | (1 | %) |
| Inventories | 1,338 |  |  | 1,492 |  |  | (154 | ) |  | (10 | %) |
| Short-term debt | 1,749 |  |  | 1,000 |  |  | 749 |  |  | 75 | % |
| Long-term debt | 10,024 |  |  | 9,969 |  |  | 55 |  |  | 1 | % |

[0001234452-16-000483:mdna:70]
|  | Nine Months Ended |  |  |  |  |
|  | June 26, 2016 |  | June 28, 2015 |  | $ Change |  | % Change |
| Net cash provided by operating activities | $ | 5,316 |  |  | $ | 3,822 |  |  | $ | 1,494 |  |  | 39 | % |
| Net cash used by investing activities | (2,229 | ) |  | (2,220 | ) |  | (9 | ) |  | — |  |
| Net cash (used) provided by financing activities | (4,765 | ) |  | 488 |  |  | (5,253 | ) |  | N/M |  |

[0001234452-16-000483:mdna:71]
N/M - Not Meaningful

[0001234452-16-000483:mdna:72]
The net increase in cash, cash equivalents and marketable securities was primarily the result of net cash provided by operating activities and net proceeds from short-term debt, partially offset by $3.7 billion in payments to repurchase shares of our common stock and $2.2 billion in cash dividends paid. Total cash provided by operating activities increased primarily due to changes in working capital, which was impacted by a prepayment of $950 million in the nine months ended June 28, 2015 to secure long-term capacity commitments at a supplier of our integrated circuit products, partially offset by a reduction in net income of $104 million. Our days sales outstanding, on a consolidated basis, decreased to 29 days at June 26, 2016 compared to 33 days at September 27, 2015. The decrease in days sales outstanding was primarily due to the timing of integrated circuit shipments and the collection of receivables related to integrated circuits. The decrease in inventories was primarily due to a decrease in QCT finished goods related to lower units on hand to align with near-term demand and recognition of the step-up in the fair value of the acquired inventories from the CSR acquisition.

[0001234452-16-000483:mdna:73]
We classify certain of our marketable securities as short-term based on their nature and our plan to make them available, if needed, for use in our current operations. While we do not anticipate using our non-current marketable securities in operations in the foreseeable future, the securities could be liquidated within a short period of time if required. Our cash, cash equivalents and marketable securities at June 26, 2016 consisted of $2.4 billion held by United States-based entities and $28.6 billion held by foreign entities. Most of our cash, cash equivalents and marketable securities held by foreign entities are indefinitely reinvested and would be subject to material tax effects if repatriated. However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate funds held by foreign entities.

[0001234452-16-000483:mdna:74]
[same as prior period, unchanged from 0001234452-16-000429:mdna:78]

[0001234452-16-000483:mdna:75]
| • | We expect the majority of the charges incurred in connection with our Strategic Realignment Plan will result in cash payment. Our restructuring accrual was $35 million at June 26, 2016, and we expect to incur additional restructuring and restructuring-related charges of approximately $25 million to $100 million in fiscal 2016 and 2017. |

[0001234452-16-000483:mdna:76]
| • | Our purchase obligations at June 26, 2016, some of which relate to research and development activities and capital expenditures, totaled $3.0 billion and $1.2 billion for fiscal 2016 and 2017, respectively, and $1.7 billion thereafter. |

[0001234452-16-000483:mdna:77]
| • | Our research and development expenditures were $3.9 billion during the first nine months of fiscal 2016 and $5.5 billion in fiscal 2015, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications, primarily in the wireless industry. |

[0001234452-16-000483:mdna:78]
| • | Cash outflows for capital expenditures were $389 million during the first nine months of fiscal 2016 and $994 million in fiscal 2015. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-16-000483:mdna:79]
34

[0001234452-16-000483:mdna:80]
[same as prior period, unchanged from 0001234452-16-000429:mdna:83]

[0001234452-16-000483:mdna:81]
[same as prior period, unchanged from 0001234452-16-000429:mdna:84]

[0001234452-16-000483:mdna:82]
Debt. We have a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. At June 26, 2016, no amounts were outstanding under the Revolving Credit Facility.

[0001234452-16-000483:mdna:83]
We have an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At June 26, 2016, we had $1.7 billion of commercial paper outstanding with weighted-average net interest rates of 0.50% and weighted-average remaining days to maturity of 37 days.

[0001234452-16-000483:mdna:84]
In May 2015, we issued unsecured floating- and fixed-rate notes in an aggregate principal amount of $10.0 billion, with maturity dates in 2018 through 2045 and effective interest rates between 0.53% and 4.74%. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. We may issue additional debt in the future. The amount and timing of additional borrowings will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001234452-16-000483:mdna:85]
Additional information regarding our outstanding debt at June 26, 2016 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Debt.”

[0001234452-16-000483:mdna:86]
Capital Return Program. During the first nine months of fiscal 2016, we repurchased and retired 70,168,000 shares of our common stock for $3.7 billion, before commissions. We intend to return a minimum of 75% of our free cash flow to stockholders through stock repurchases and dividends over the foreseeable future, where free cash flow is defined as net cash provided by operating activities less capital expenditures. To meet our goal, we expect to use existing cash and marketable securities held by, and cash flow generated from, United States-based entities and borrowings. On March 9, 2015, we announced that we had been authorized to repurchase up to $15 billion of our common stock. Additionally, we announced our intention to repurchase $10 billion of stock from March 2015 through March 2016, which we completed during the first quarter of fiscal 2016. At June 26, 2016, $3.2 billion remained authorized for repurchase under our stock repurchase program. We periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders.

[0001234452-16-000483:mdna:87]
During the first nine months of fiscal 2016, we paid cash dividends totaling $2.2 billion, or $1.49 per share. On July 12, 2016, we announced a cash dividend of $0.53 per share on our common stock, payable on September 21, 2016 to stockholders of record as of the close of business on August 31, 2016. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-16-000483:mdna:88]
[same as prior period, unchanged from 0001234452-16-000429:mdna:93]

[0001234452-16-000483:mdna:89]
[same as prior period, unchanged from 0001234452-16-000429:mdna:94]

[0001234452-16-000483:mdna:90]
Additional information regarding our financial commitments at June 26, 2016 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes,” “Note 6. Debt” and “Note 7. Commitments and Contingencies.”

[0001234452-16-000483:mdna:91]
[same as prior period, unchanged from 0001234452-16-000429:mdna:117]

[0001234452-16-000483:mdna:92]
[same as prior period, unchanged from 0001234452-16-000429:mdna:96]

[0001234452-16-000483:mdna:93]
[same as prior period, unchanged from 0001234452-16-000429:mdna:97]

[0001234452-16-000483:mdna:94]
[same as prior period, unchanged from 0001234452-16-000429:mdna:98]

[0001234452-16-000483:mdna:95]
[same as prior period, unchanged from 0001234452-16-000429:mdna:99]

[0001234452-16-000483:mdna:96]
[same as prior period, unchanged from 0001234452-16-000429:mdna:100]

[0001234452-16-000483:mdna:97]
[same as prior period, unchanged from 0001234452-16-000429:mdna:101]

[0001234452-16-000483:mdna:98]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on our customers, our licensees and operators of wireless networks to use these technologies in their adoption of our products and services into their devices and networks and on the timing of their deployments of new products and services. We also depend on our customers and licensees to develop products and services with value-added features to drive consumer demand for new 3G, 3G/4G multimode and 4G devices, as well as the selling prices for such devices. Further, our rate of revenue growth depends on third parties incorporating our technology, products and/or services into new device types used in industries beyond traditional cellular communications, such as automotive, connected home and wearable uses. Our revenues and/or growth in revenues could be negatively impacted, our business may be harmed and our substantial investments in these technologies may not provide us an adequate return, if:

[0001234452-16-000483:mdna:99]
[same as prior period, unchanged from 0001234452-16-000429:mdna:104]

[0001234452-16-000483:mdna:100]
[same as prior period, unchanged from 0001234452-16-000429:mdna:105]

[0001234452-16-000483:mdna:101]
[same as prior period, unchanged from 0001234452-16-000429:mdna:106]

[0001234452-16-000483:mdna:102]
[same as prior period, unchanged from 0001234452-16-000429:mdna:107]

[0001234452-16-000483:mdna:103]
[same as prior period, unchanged from 0001234452-16-000429:mdna:108]

[0001234452-16-000483:mdna:104]
[same as prior period, unchanged from 0001234452-16-000429:mdna:109]

[0001234452-16-000483:mdna:105]
[same as prior period, unchanged from 0001234452-16-000429:mdna:110]

[0001234452-16-000483:mdna:106]
[same as prior period, unchanged from 0001234452-16-000429:mdna:111]

[0001234452-16-000483:mdna:107]
Our products, services and technologies face significant competition, and the revenues we generate and/or the timing of such revenues, which depend on deployments and/or actions by others, may not meet expectations. We expect competition to increase as our current competitors expand their product offerings or reduce the prices of their products as part of a strategy to attract new business and/or customers, and as new opportunities develop, any of which would put continued pressure on the pricing of our products and services. Competition in wireless communications is affected by various factors that include, among others: device manufacturer concentrations; growth in emerging geographic regions; government intervention;

[0001234452-16-000483:mdna:108]
evolving industry standards and business models; evolving methods of transmission of voice and data communications; increasing data traffic and densification of wireless networks; convergence and aggregation of connectivity technologies (including Wi-Fi and LTE) in both devices and access points; consolidation of wireless technologies and infrastructure at the network edge; networking and connectivity trends (including cloud services); the evolving nature of computing (including demand for always on, always connected capabilities); the speed of technological change (including the transition to smaller geometry process technologies); value-added features that drive selling prices as well as consumer demand for new 3G, 3G/4G multimode and 4G devices; turnkey, integrated products that incorporate hardware, software, user interface, applications and reference designs; rapid growth in mobile data consumption; scalability; and the ability of the system technology to meet customers’ immediate and future network requirements. We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, technological and public policy changes and relatively low barriers to entry in certain segments of the industry. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape.

[0001234452-16-000483:mdna:109]
[same as prior period, unchanged from 0001234452-16-000429:mdna:113]

[0001234452-16-000483:mdna:110]
[same as prior period, unchanged from 0001234452-16-000429:mdna:114]

[0001234452-16-000483:mdna:111]
[same as prior period, unchanged from 0001234452-16-000429:mdna:115]

[0001234452-16-000483:mdna:112]
[same as prior period, unchanged from 0001234452-16-000429:mdna:116]

[0001234452-16-000483:mdna:113]
[same as prior period, unchanged from 0001234452-16-000429:mdna:118]

[0001234452-16-000483:mdna:114]
[same as prior period, unchanged from 0001234452-16-000429:mdna:119]

[0001234452-16-000483:mdna:115]
[same as prior period, unchanged from 0001234452-16-000429:mdna:120]

[0001234452-16-000483:mdna:116]
[same as prior period, unchanged from 0001234452-16-000429:mdna:121]

[0001234452-16-000483:mdna:117]
[same as prior period, unchanged from 0001234452-16-000429:mdna:122]

[0001234452-16-000483:mdna:118]
[same as prior period, unchanged from 0001234452-16-000429:mdna:123]

[0001234452-16-000483:mdna:119]
| • | create stand-alone value and/or contribute to the success of our existing businesses through acquisitions and other transactions (and/or by developing customer, licensee and/or vendor relationships) in new industry segments and/or disruptive technologies, products and/or services (such as products for the connected home and the Internet of Things, automotive, networking, mobile computing, mobile health, machine learning, including robotics, and wireless charging among others); |

[0001234452-16-000483:mdna:120]
[same as prior period, unchanged from 0001234452-16-000429:mdna:125]

[0001234452-16-000483:mdna:121]
[same as prior period, unchanged from 0001234452-16-000429:mdna:126]

[0001234452-16-000483:mdna:122]
37

[0001234452-16-000483:mdna:123]
[same as prior period, unchanged from 0001234452-16-000429:mdna:127]

[0001234452-16-000483:mdna:124]
[same as prior period, unchanged from 0001234452-16-000429:mdna:128]

[0001234452-16-000483:mdna:125]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe we will continue to see, an increase in customers requesting that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of a product’s source code and may expose related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of the open source software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers, or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Developing open source products, while adequately protecting the intellectual property rights upon which our licensing business depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ adequate controls to protect our intellectual property rights, our use of open source software presents risks that could have an adverse effect on these rights and on our business.

[0001234452-16-000483:mdna:126]
[same as prior period, unchanged from 0001234452-16-000429:mdna:131]

[0001234452-16-000483:mdna:127]
Our QCT (Qualcomm CDMA Technologies) segment derives a significant portion of revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience an increasing concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. In addition, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past chosen, and may in the future choose, to utilize in their devices rather than our integrated circuit products (and/or sell their integrated circuit products to third parties in competition with us). The loss of any one of our significant customers, a reduction in the purchases of our products by such customers (due to the use of their own integrated circuit products or otherwise) or cancellation of significant purchases from any of these customers would reduce our revenues and could harm our ability to achieve or sustain expected operating results, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Further, concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have little or no control, and the timing of such introductions may cause our operating results to fluctuate. Accordingly, if current industry dynamics and concentrations continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases and the timing and size of any such future purchases by these significant customers.

[0001234452-16-000483:mdna:128]
[same as prior period, unchanged from 0001234452-16-000429:mdna:133]

[0001234452-16-000483:mdna:129]
[same as prior period, unchanged from 0001234452-16-000429:mdna:134]

[0001234452-16-000483:mdna:130]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products and/or intellectual property or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001234452-16-000483:mdna:131]
Although we have more than 320 CDMA-based licensees, our QTL segment derives a significant portion of licensing revenues from a limited number of licensees. In the event that one or more of our significant licensees fail to meet their reporting and/or payment requirements or we are unable to renew or modify one or more of such license agreements, our revenues, operating results and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have little or no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our major licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues.

[0001234452-16-000483:mdna:132]
[same as prior period, unchanged from 0001234452-16-000429:mdna:137]

[0001234452-16-000483:mdna:133]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, or some form of unfair competition; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the imposition of some form of compulsory licensing and/or to weaken a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies to attempt to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated. In addition, certain licensees have disputed or underreported royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into license agreements with us for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future. Further, to the extent such licensees and/or companies increase their device share, the negative impact of their underreporting and/or non-reporting on our business and operating results will be exacerbated.

[0001234452-16-000483:mdna:134]
We are currently subject to various litigation and governmental investigations and/or proceedings, some of which may arise out of the strategies described above. Certain legal matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region.

[0001234452-16-000483:mdna:135]
In addition, in connection with our participation in SDOs, we, like other patent owners, generally have made contractual commitments to such organizations to license those of our patents that would necessarily be infringed by standard-compliant products (standard-essential patents) on terms that are fair, reasonable and nondiscriminatory (FRAND). Some manufacturers and users of standard-compliant products advance interpretations of these FRAND commitments that are adverse to our

[0001234452-16-000483:mdna:136]
39

[0001234452-16-000483:mdna:137]
licensing business, including interpretations that would limit the amount of royalties that we could collect on the licensing of our patent portfolio.

[0001234452-16-000483:mdna:138]
[same as prior period, unchanged from 0001234452-16-000429:mdna:141]

[0001234452-16-000483:mdna:139]
Some SDOs, courts and governmental agencies have adopted and may in the future adopt some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001234452-16-000483:mdna:140]
We expect that such proposals, interpretations and strategies will continue in the future, and if successful, our business model would be harmed, either by limiting or eliminating our ability to collect royalties (or by reducing the royalties we can collect) on all or a portion of our patent portfolio, limiting our return on investment with respect to new technologies, limiting our ability to seek injunctions against infringers of our standard-essential patents, constraining our ability to make licensing commitments when submitting our technology for inclusion in future standards (which could make our technology less likely to be included in such standards) or forcing us to work outside of SDOs or other industry groups to promote our new technologies, and our results of operations could be negatively impacted. In addition, the legal and other costs associated with asserting or defending our positions have been and continue to be significant. We assume that such challenges, regardless of their merits, will continue into the foreseeable future and may require the investment of substantial management time and financial resources.

[0001234452-16-000483:mdna:141]
[same as prior period, unchanged from 0001234452-16-000429:mdna:145]

[0001234452-16-000483:mdna:142]
[same as prior period, unchanged from 0001234452-16-000429:mdna:146]

[0001234452-16-000483:mdna:143]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property rights and/or contracts, including collecting royalties for use of our patent portfolio in particular foreign jurisdictions due to, among others: policies of foreign governments; challenges to our licensing practices under such jurisdictions’ competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and/or challenges pending before foreign competition agencies to the pricing and integration of additional features and functionality into our chipset products. Certain licensees have disputed or underreported royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their

[0001234452-16-000483:mdna:144]
contractual obligations, and certain companies have yet to enter into or delayed entering into license agreements for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements.

[0001234452-16-000483:mdna:145]
We may need to litigate to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements and/or initiating litigation) and/or we could incur substantial unexpected operating costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our operating results. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues in the period prior to conclusion.

[0001234452-16-000483:mdna:146]
[same as prior period, unchanged from 0001234452-16-000429:mdna:149]

[0001234452-16-000483:mdna:147]
Although we own a very strong portfolio of issued and pending patents related to GSM, GPRS, EDGE, OFDM, OFDMA, WLAN, MIMO and other technologies, our patent portfolio licensing program in these areas is less established and might not be as successful in generating licensing revenues as our CDMA licensing program has been. Many wireless operators are investigating, have selected or have deployed OFDMA-based LTE as their next-generation 4G technology in existing (or future if not yet deployed) wireless spectrum bands as complementary to their existing CDMA-based networks. While 3G/4G multimode products are generally covered by our existing 3G licensing agreements, products that implement 4G but do not also implement 3G are generally not covered by these agreements. Although we believe that our patented technology is essential and useful to implementation of the LTE industry standards and have granted royalty-bearing licenses to more than 195 companies (including Huawei, Lenovo, LG, Microsoft, Samsung, Sony Mobile and ZTE) that have realized that they need a license to our patents to make and sell products implementing 4G standards but not implementing 3G standards, it may be difficult to agree on material terms and/or conditions of new license agreements that are acceptable to us with companies that are currently unlicensed, particularly in China. Further, the royalty rates for single mode 4G products are generally lower than our royalty rates for 3G and 3G/4G multimode products have been, and therefore, we might not achieve the same licensing revenues on such LTE products as on 3G and 3G/4G multimode products. In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the connected home or the Internet of Things. We also seek to diversify and broaden our technology licensing programs to new industry segments in which we can utilize our technology leadership, such as wireless charging and other technologies. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties that are equivalent to those that we receive for 3G and 3G/4G multimode products used in cellular communications. Although we believe that our patented technology is essential and useful to the commercialization of such services, the royalties we receive may be lower than those we receive from our current licensing program.

[0001234452-16-000483:mdna:148]
Over the long-term, we need to continue to evolve our patent portfolio. If we do not maintain a strong portfolio that is applicable to current and/or future standards, products and/or services, our future licensing revenues could be negatively impacted.

[0001234452-16-000483:mdna:149]
The licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date and, in a small number of agreements, royalties are payable on those patents for a specified time period. As a result, there are agreements with some licensees where later patents are not licensed by or to us and/or royalties are not owed to us under such license agreements after the specified time period. Additionally, certain license agreements are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of a specified term, or to receive royalties after the specified time period, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to modify those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If

[0001234452-16-000483:mdna:150]
41

[0001234452-16-000483:mdna:151]
there is a delay in renewing a license agreement prior to its expiration, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001234452-16-000483:mdna:152]
[same as prior period, unchanged from 0001234452-16-000429:mdna:154]

[0001234452-16-000483:mdna:153]
[same as prior period, unchanged from 0001234452-16-000429:mdna:155]

[0001234452-16-000483:mdna:154]
We are currently subject to various governmental investigations and/or proceedings, and certain matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region.

[0001234452-16-000483:mdna:155]
[same as prior period, unchanged from 0001234452-16-000429:mdna:158]

[0001234452-16-000483:mdna:156]
[same as prior period, unchanged from 0001234452-16-000429:mdna:159]

[0001234452-16-000483:mdna:157]
[same as prior period, unchanged from 0001234452-16-000429:mdna:160]

[0001234452-16-000483:mdna:158]
[same as prior period, unchanged from 0001234452-16-000429:mdna:161]

[0001234452-16-000483:mdna:159]
[same as prior period, unchanged from 0001234452-16-000429:mdna:162]

[0001234452-16-000483:mdna:160]
Our industry is subject to rapid technological change, evolving industry standards and frequent new product introductions, and we must make substantial research, development and other investments, such as acquisitions, in new products, services and technologies to compete successfully. Technological innovations generally require significant research and development efforts before they are commercially viable. Our future growth significantly depends on third parties incorporating our technology, products and/or services into new device types used in industries beyond traditional cellular communications, such as automotive, connected home and wearable uses. Accordingly, we intend to continue to make substantial investments in developing new products, services and technologies that we believe can create stand-alone value and/or contribute to the success of our existing businesses. However, it is possible that these initiatives will not be successful

[0001234452-16-000483:mdna:161]
and/or will not result in meaningful revenues or generate operating income that meets expectations. As a result, we may develop products that fail to meet our customers’ needs and/or develop products that may become obsolete and be replaced by competitors’ products offering more compelling features, technologies or costs.

[0001234452-16-000483:mdna:162]
[same as prior period, unchanged from 0001234452-16-000429:mdna:164]

[0001234452-16-000483:mdna:163]
[same as prior period, unchanged from 0001234452-16-000429:mdna:165]

[0001234452-16-000483:mdna:164]
[same as prior period, unchanged from 0001234452-16-000429:mdna:166]

[0001234452-16-000483:mdna:165]
Our QCT segment utilizes a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Turnkey is when our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services such as wafer bump, probe, assembly and final test. The third-party semiconductor manufacturing foundries that supply products to our QCT segment are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders. The following could have an adverse effect on our ability to meet customer demands and/or negatively impact our revenues, business operations, profitability and/or cash flows:

[0001234452-16-000483:mdna:166]
[same as prior period, unchanged from 0001234452-16-000429:mdna:168]

[0001234452-16-000483:mdna:167]
[same as prior period, unchanged from 0001234452-16-000429:mdna:169]

[0001234452-16-000483:mdna:168]
[same as prior period, unchanged from 0001234452-16-000429:mdna:170]

[0001234452-16-000483:mdna:169]
[same as prior period, unchanged from 0001234452-16-000429:mdna:171]

[0001234452-16-000483:mdna:170]
[same as prior period, unchanged from 0001234452-16-000429:mdna:172]

[0001234452-16-000483:mdna:171]
While we have established alternate suppliers for certain technologies, we rely on sole- or limited-source suppliers for certain products, subjecting us to significant risks, including: possible shortages of raw materials or manufacturing capacity; poor product performance; and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established alternate suppliers, these suppliers may require significant levels of support to bring complex technologies to production. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, any future consolidation of foundry suppliers could increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions and/or increase our manufacturing costs. Our arrangements with our suppliers may obligate us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies, and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the

[0001234452-16-000483:mdna:172]
[same as prior period, unchanged from 0001234452-16-000429:mdna:184]

[0001234452-16-000483:mdna:173]
risk of excess inventories. Our inability to meet customer demand due to sole- or limited-sourcing and/or the additional costs that we incur because of these or other supply constraints or because of the need to support alternate suppliers could negatively impact our business, our revenues and our results of operations.

[0001234452-16-000483:mdna:174]
[same as prior period, unchanged from 0001234452-16-000429:mdna:174]

[0001234452-16-000483:mdna:175]
[same as prior period, unchanged from 0001234452-16-000429:mdna:175]

[0001234452-16-000483:mdna:176]
[same as prior period, unchanged from 0001234452-16-000429:mdna:176]

[0001234452-16-000483:mdna:177]
[same as prior period, unchanged from 0001234452-16-000429:mdna:178]

[0001234452-16-000483:mdna:178]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe on another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products through a licensed supplier, we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our operating results.

[0001234452-16-000483:mdna:179]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages, royalty payments and/or an injunction on the sale of certain of our integrated circuit products (and/or on the sale of our customers’ devices using such products). A negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001234452-16-000483:mdna:180]
A number of other companies have claimed to own patents applicable to products implementing various CDMA-based standards, TDMA-based standards, such as GSM and OFDMA-based standards. In addition, existing standards continue to evolve, and new standards, including those applicable to new industry segments, continue to be developed. If future standards

[0001234452-16-000483:mdna:181]
diminish, or fail to include, a base level of interoperability, our business may be harmed, and our investments in these new segments may not succeed.

[0001234452-16-000483:mdna:182]
[same as prior period, unchanged from 0001234452-16-000429:mdna:182]

[0001234452-16-000483:mdna:183]
We engage in acquisitions and strategic transactions and make strategic investments, which are important to our business strategy, with the goal of maximizing stockholder value. We acquire businesses and other assets, including patents, technology, wireless spectrum and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies that may be private and early-stage. Our strategic activities are generally focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications. Many of our strategic activities entail a high degree of risk and require the use of domestic and/or foreign capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies, products or services. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our financial results, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited. In part due to our inexperience with technologies and/or products of and/or geographic regions served by our strategic activities, we may underestimate the costs and/or overestimate the benefits, including product and other synergies and growth opportunities that we expect to realize, and we may not achieve them. If we do not achieve the anticipated benefits of business acquisitions or other strategic activities, our results of operations may be adversely affected, and we may not enhance stockholder value by engaging in these transactions.

[0001234452-16-000483:mdna:184]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner. Such integration involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, business systems, technology and products; retaining customers and suppliers of the businesses; consolidating research and development and/or supply operations; minimizing the diversion of management’s attention from ongoing business matters; and consolidating corporate and administrative infrastructures. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, or we may become subject to litigation. Additionally, we may not be successful in expanding into geographic regions and/or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of the combination.

[0001234452-16-000483:mdna:185]
[same as prior period, unchanged from 0001234452-16-000429:mdna:186]

[0001234452-16-000483:mdna:186]
In the fourth quarter of fiscal 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders. As part of this Strategic Realignment Plan, among other actions, we are implementing a cost reduction plan, which includes a series of targeted reductions across our businesses, particularly in QCT, and a reduction to our annual share-based compensation grants in fiscal 2016. We expect these cost reduction initiatives to be substantially implemented by the end of fiscal 2016. Additional information regarding our Strategic Realignment Plan is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 10. Strategic Realignment Plan.”

[0001234452-16-000483:mdna:187]
[same as prior period, unchanged from 0001234452-16-000429:mdna:188]

[0001234452-16-000483:mdna:188]
[same as prior period, unchanged from 0001234452-16-000429:mdna:189]

[0001234452-16-000483:mdna:189]
[same as prior period, unchanged from 0001234452-16-000429:mdna:190]

[0001234452-16-000483:mdna:190]
In the past, securities class action litigation often has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources.

[0001234452-16-000483:mdna:191]
[same as prior period, unchanged from 0001234452-16-000429:mdna:192]

[0001234452-16-000483:mdna:192]
Our outstanding indebtedness and any additional indebtedness we incur may have negative consequences on our business, including, among others:

[0001234452-16-000483:mdna:193]
[same as prior period, unchanged from 0001234452-16-000429:mdna:194]

[0001234452-16-000483:mdna:194]
[same as prior period, unchanged from 0001234452-16-000429:mdna:195]

[0001234452-16-000483:mdna:195]
[same as prior period, unchanged from 0001234452-16-000429:mdna:196]

[0001234452-16-000483:mdna:196]
[same as prior period, unchanged from 0001234452-16-000429:mdna:197]

[0001234452-16-000483:mdna:197]
[same as prior period, unchanged from 0001234452-16-000429:mdna:198]

[0001234452-16-000483:mdna:198]
[same as prior period, unchanged from 0001234452-16-000429:mdna:199]

[0001234452-16-000483:mdna:199]
[same as prior period, unchanged from 0001234452-16-000429:mdna:200]

[0001234452-16-000483:mdna:200]
[same as prior period, unchanged from 0001234452-16-000429:mdna:201]

[0001234452-16-000483:mdna:201]
[same as prior period, unchanged from 0001234452-16-000429:mdna:202]

[0001234452-16-000483:mdna:202]
[same as prior period, unchanged from 0001234452-16-000429:mdna:203]

[0001234452-16-000483:mdna:203]
[same as prior period, unchanged from 0001234452-16-000429:mdna:204]

[0001234452-16-000483:mdna:204]
[same as prior period, unchanged from 0001234452-16-000429:mdna:205]

[0001234452-16-000483:mdna:205]
[same as prior period, unchanged from 0001234452-16-000429:mdna:206]

[0001234452-16-000483:mdna:206]
[same as prior period, unchanged from 0001234452-16-000429:mdna:207]

[0001234452-16-000483:mdna:207]
[same as prior period, unchanged from 0001234452-16-000429:mdna:208]

[0001234452-16-000483:mdna:208]
[same as prior period, unchanged from 0001234452-16-000429:mdna:209]

[0001234452-16-000483:mdna:209]
[same as prior period, unchanged from 0001234452-16-000429:mdna:210]

[0001234452-16-000483:mdna:210]
[same as prior period, unchanged from 0001234452-16-000429:mdna:211]

[0001234452-16-000483:mdna:211]
[same as prior period, unchanged from 0001234452-16-000429:mdna:212]

[0001234452-16-000483:mdna:212]
[same as prior period, unchanged from 0001234452-16-000429:mdna:213]

[0001234452-16-000483:mdna:213]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-United States headquarters is located. Significant judgment is required in determining our provision for income taxes. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related litigation could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case,

[0001234452-16-000483:mdna:214]
our income tax provision and results of operations in the period or periods in which that determination is made could be negatively affected.

[0001234452-16-000483:mdna:215]
[same as prior period, unchanged from 0001234452-16-000429:mdna:215]

[0001234452-16-000483:mdna:216]
[same as prior period, unchanged from 0001234452-16-000429:mdna:216]
