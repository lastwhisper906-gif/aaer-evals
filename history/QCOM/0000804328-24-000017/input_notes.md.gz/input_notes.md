# QCOM notes — 0000804328-24-000017


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000804328-24-000017:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 24, 2023. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 24, 2023 and December 25, 2022 included 13 weeks.

[0000804328-24-000017:notes:2]
[same as prior period, unchanged from 0000804328-23-000043:notes:2]

[0000804328-24-000017:notes:3]
Recent Accounting Pronouncements.

[0000804328-24-000017:notes:4]
Segment Reporting Disclosures: In November 2023, the Financial Accounting Standards Board (FASB) issued new requirements to disclose certain incremental segment information on an annual and interim basis, including (among other items) additional disclosure about significant segment expenses. We will adopt the new requirements for our annual periods starting in fiscal 2025 (and interim periods thereafter) on a retrospective basis.

[0000804328-24-000017:notes:5]
Income Tax Disclosures: In December 2023, the FASB issued new requirements to disclose annually certain additional disaggregated income tax information related to the effective tax rate reconciliation and income taxes paid, among other items. We will adopt the new requirements starting in fiscal 2026 on a retrospective basis.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-24-000017:notes:6]
[same as prior period, unchanged from 0000804328-23-000043:notes:3]

[0000804328-24-000017:notes:7]
| Inventories (in millions) |  |  |  |
|  | December 24,2023 |  | September 24,2023 |
| Raw materials | $ | 178 |  |  | $ | 176 |  |
| Work-in-process | 3,941 |  |  | 4,096 |  |
| Finished goods | 2,128 |  |  | 2,150 |  |
|  | $ | 6,247 |  |  | $ | 6,422 |  |

[0000804328-24-000017:notes:8]
Revenues. We disaggregate our revenues by segment (Note 6), by products and services (as presented on our condensed consolidated statement of operations), and for our QCT (Qualcomm CDMA Technologies) segment, by revenue stream, which is based on the industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s (Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets.

[0000804328-24-000017:notes:9]
[same as prior period, unchanged from 0000804328-23-000043:notes:6]

[0000804328-24-000017:notes:10]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | December 24,2023 |  | December 25,2022 |  |  |  |  |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,687 |  |  | $ | 5,754 |  |  |  |  |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 598 |  |  | 456 |  |  |  |  |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,138 |  |  | 1,682 |  |  |  |  |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 8,423 |  |  | $ | 7,892 |  |  |  |  |  |

[0000804328-24-000017:notes:11]
[same as prior period, unchanged from 0000804328-23-000043:notes:8]

[0000804328-24-000017:notes:12]
[same as prior period, unchanged from 0000804328-23-000043:notes:9]

[0000804328-24-000017:notes:13]
(3) Primarily includes products sold for use in the following industries and applications: consumer (including computing, voice and music and extended reality (XR)), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, tracking and logistics and utilities).

[0000804328-24-000017:notes:14]
[same as prior period, unchanged from 0000804328-23-000043:notes:11]

[0000804328-24-000017:notes:15]
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  |  |  |  |
| Revenues recognized from previously satisfied performance obligations | $ | 176 |  |  | $ | 199 |  |  |  |  |  |

[0000804328-24-000017:notes:16]
Unearned revenues (which are considered contract liabilities) consist primarily of certain customer contracts for which QCT received fees upfront and QTL license fees for intellectual property with continuing performance obligations. In the three months ended December 24, 2023 and December 25, 2022, we recognized revenues of $181 million and $173 million, respectively, that were recorded as unearned revenues at September 24, 2023 and September 25, 2022, respectively.

[0000804328-24-000017:notes:17]
[same as prior period, unchanged from 0000804328-23-000043:notes:14]

[0000804328-24-000017:notes:18]
[same as prior period, unchanged from 0000804328-23-000043:notes:15]

[0000804328-24-000017:notes:19]
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  |  |  |  |
| Customer/licensee (x) | 25 | % |  | 34 | % |  |  |  |  |
| Customer/licensee (y) | 18 |  |  | 14 |  |  |  |  |  |
| Customer/licensee (z) | 14 |  |  | * |  |  |  |  |

[0000804328-24-000017:notes:20]
Other Income, Costs and Expenses. Other income and expenses in the first quarter of fiscal 2024 and 2023 included certain restructuring amounts (primarily related to accrued severance costs) from cost reduction actions initiated in fiscal 2023.

[0000804328-24-000017:notes:21]
| Investment and Other Income (Expense), Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  |  |  |  |
| Interest and dividend income | $ | 149 |  |  | $ | 55 |  |  |  |  |  |
| Net gains on marketable securities | 11 |  |  | 11 |  |  |  |  |  |
| Net gains on other investments | 5 |  |  | — |  |  |  |  |  |
| Net gains on deferred compensation plan assets | 66 |  |  | 26 |  |  |  |  |  |
| Impairment losses on other investments | (12) |  |  | (14) |  |  |  |  |  |
| Other | (7) |  |  | (2) |  |  |  |  |  |
|  | $ | 212 |  |  | $ | 76 |  |  |  |  |  |

[0000804328-24-000017:notes:22]
Discontinued Operations. For the periods presented, Veoneer’s Restraint Control Systems (RCS) business assets and liabilities are reflected as held for sale on our condensed consolidated balance sheets, and the results of operations and cash flows of Veoneer’s Non-Arriver businesses (primarily consisting of the Active Safety and RCS businesses) are presented as discontinued operations on a one quarter reporting lag (through the date of disposition by SSW Partners). Cash flows from investing and financing activities from discontinued operations reported for the periods presented were not material.
On June 1, 2023, SSW Partners completed the sale of the Active Safety business to Magna International Inc. for net cash proceeds of $1.5 billion. In December 2023, SSW Partners entered into a definitive agreement to sell the RCS business. We expect that SSW Partners will complete the sale of the RCS business within early calendar 2024, subject to certain required regulatory approvals and other closing conditions being met.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-24-000017:notes:23]
Income Taxes
We estimate our annual effective income tax rate to be 7% for fiscal 2024, which is lower than the U.S. federal statutory rate, primarily due to (i) a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, which includes certain benefits from the requirement to capitalize research and development expenditures for federal income tax purposes, (ii) a benefit from our federal research and development tax credit and (iii) a benefit related to foreign currency gains on a noncurrent receivable related to our refund claim of Korean withholding tax. Our effective tax rate of 5% for the first quarter of fiscal 2024 was lower than our estimated annual effective tax rate of 7% primarily due to $79 million of net discrete tax benefits. Our effective tax rate of 4% for the first quarter of fiscal 2023 included $150 million of discrete net tax benefits. Such discrete net tax benefits primarily related to foreign currency gains on a noncurrent receivable related to our refund claim of Korean withholding tax.
Income taxes payable (recorded in other current liabilities) were $1.0 billion and $1.7 billion at December 24, 2023 and September 24, 2023, respectively. This decrease was primarily due to certain U.S. federal income tax payments made in the first quarter of fiscal 2024 that were previously postponed by the Internal Revenue Service (IRS).


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-24-000017:notes:24]
Capital Stock
Stock Repurchase Program. On October 12, 2021, we announced a $10.0 billion stock repurchase program. The stock repurchase program has no expiration date. At December 24, 2023, $4.4 billion remained authorized for repurchase under our stock repurchase program.

[0000804328-24-000017:notes:25]
Shares Outstanding. Shares of common stock outstanding at December 24, 2023 were as follows (in millions):

[0000804328-24-000017:notes:26]
| Balance at beginning of period | 1,114 |  |
| Issued | 10 |  |
| Repurchased | (6) |  |
| Balance at end of period | 1,118 |  |

[0000804328-24-000017:notes:27]
Dividends. On January 19, 2024, we announced a cash dividend of $0.80 per share on our common stock, payable on March 21, 2024 to stockholders of record as of the close of business on February 29, 2024.

[0000804328-24-000017:notes:28]
Earnings Per Common Share. Basic earnings per share is computed by dividing net income by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of the weighted-average number of common shares outstanding and the weighted-average number of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans, during the reporting period, using the treasury stock method. The following table provides information about the diluted earnings per share calculation (in millions):

[0000804328-24-000017:notes:29]
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  |  |  |  |
| Dilutive common share equivalents included in diluted shares | 11 |  |  | 9 |  |  |  |  |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 14 |  |  | 5 |  |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-24-000017:notes:30]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0000804328-24-000017:notes:31]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. The court consolidated the two actions, and on July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On May 23, 2022, the plaintiffs filed a motion for class certification, and on March 20, 2023, the court issued an order granting in part and denying in part the plaintiffs’ motion for class certification. The order denied class certification on the basis of alleged misrepresentations relating to our chip-level licensing practices, but certified a class on the basis of alleged misrepresentations relating to the separate operations of QCT and QTL. Trial is scheduled to begin on October 28, 2024. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-24-000017:notes:32]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. The cases filed in the Southern District of California were subsequently transferred to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On September 27, 2018, the court certified the class. We appealed the court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class, and remanded the case to the district court. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. We filed a motion to dismiss the amended complaint, and on January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. We subsequently filed a motion for summary judgment on the plaintiffs’ remaining claims. The court granted our motion in its entirety and, on October 5, 2023, entered final judgment in Qualcomm’s favor. On November 2, 2023, the plaintiffs filed a notice of appeal to the Ninth Circuit. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-24-000017:notes:33]
Beginning in November 2017, several other consumer class action complaints were filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws and seeking damages. The claims in these complaints are similar to those in the U.S. consumer class action complaints described above. These matters are at various stages of litigation, and we intend to continue to vigorously defend ourselves.

[0000804328-24-000017:notes:34]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit, and on November 6, 2023, the court held a hearing on the appeal. The court has not yet issued a ruling. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-24-000017:notes:35]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (ARM) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with ARM (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. The complaint seeks specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology. ARM also contends that we violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of ARM’s trademarks and seeks associated injunctive and declaratory relief. ARM further seeks exemplary or punitive damages, costs, expenses and reasonable attorney’s fees, and equitable relief addressing any infringement occurring after entry of judgment.

[0000804328-24-000017:notes:36]
On September 30, 2022, we filed our Answer and Counterclaim in response to ARM’s complaint denying ARM’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and ARM and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia), server System-on-Chip (SoC) and compute SoC are fully licensed under our existing Architecture License Agreement and Technology License Agreement with ARM (the ARM-Qualcomm Agreements). We further seek an order enjoining ARM from making any claim that our products are not licensed under the ARM-Qualcomm Agreements, are not ARM-compliant or that we are prohibited from using ARM’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements ARM is making in the marketplace concerning our rights under the ARM-Qualcomm Agreements are false, and that ARM has no right to prevent us from shipping our products, which are validly licensed. Trial is scheduled to begin on September 23, 2024. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-24-000017:notes:37]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at December 24, 2023 for contingent losses associated with the pending matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (for example, our 2010 European Commission matter relating to the Icera complaint, and other matters arising in the ordinary course of our business, including those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-24-000017:notes:38]
Segment Information
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies, including RFFE (radio frequency front-end), for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices; industrial devices; and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our cloud computing processing initiative.

[0000804328-24-000017:notes:39]
The table below presents revenues and earnings (loss) before income taxes (EBT) for reportable segments (in millions):

[0000804328-24-000017:notes:40]
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 8,423 |  |  | $ | 7,892 |  |  |  |  |  |
| QTL | 1,460 |  |  | 1,524 |  |  |  |  |  |
| QSI | 13 |  |  | 7 |  |  |  |  |  |
| Reconciling items | 39 |  |  | 40 |  |  |  |  |  |
| Total | $ | 9,935 |  |  | $ | 9,463 |  |  |  |  |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 2,593 |  |  | $ | 2,183 |  |  |  |  |  |
| QTL | 1,080 |  |  | 1,117 |  |  |  |  |  |
| QSI | 11 |  |  | (8) |  |  |  |  |  |
| Reconciling items | (722) |  |  | (921) |  |  |  |  |  |
| Total | $ | 2,962 |  |  | $ | 2,371 |  |  |  |  |  |

[0000804328-24-000017:notes:41]
[same as prior period, unchanged from 0000804328-23-000043:notes:51]

[0000804328-24-000017:notes:42]
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 39 |  |  | $ | 40 |  |  |  |  |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of revenues | $ | (56) |  |  | $ | (65) |  |  |  |  |  |
| Unallocated research and development expenses | (533) |  |  | (522) |  |  |  |  |  |
| Unallocated selling, general and administrative expenses | (185) |  |  | (167) |  |  |  |  |  |
| Unallocated other income (expenses) | 28 |  |  | (80) |  |  |  |  |  |
| Unallocated interest expense | (178) |  |  | (170) |  |  |  |  |  |
| Unallocated investment and other income, net | 208 |  |  | 87 |  |  |  |  |  |
| Nonreportable segments | (6) |  |  | (4) |  |  |  |  |  |
|  | $ | (722) |  |  | $ | (921) |  |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-24-000017:notes:43]
Fair Value Measurements and Marketable Securities
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at December 24, 2023 (in millions):

[0000804328-24-000017:notes:44]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 4,979 |  |  | $ | 1,796 |  |  | $ | — |  |  | $ | 6,775 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 3,220 |  |  | — |  |  | 3,220 |  |
| U.S. Treasury securities and government-related securities | 220 |  |  | 65 |  |  | — |  |  | 285 |  |
| Mortgage- and asset-backed securities | — |  |  | 280 |  |  | — |  |  | 280 |  |
| Equity securities | 136 |  |  | — |  |  | — |  |  | 136 |  |
| Total marketable securities | 356 |  |  | 3,565 |  |  | — |  |  | 3,921 |  |
| Derivative instruments | — |  |  | 30 |  |  | — |  |  | 30 |  |
| Other investments | 815 |  |  | — |  |  | 51 |  |  | 866 |  |
| Total assets measured at fair value | $ | 6,150 |  |  | $ | 5,391 |  |  | $ | 51 |  |  | $ | 11,592 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 205 |  |  | $ | — |  |  | $ | 205 |  |
| Other liabilities | 813 |  |  | — |  |  | — |  |  | 813 |  |
| Total liabilities measured at fair value | $ | 813 |  |  | $ | 205 |  |  | $ | — |  |  | $ | 1,018 |  |

[0000804328-24-000017:notes:45]
Long-term Debt. At December 24, 2023, the aggregate fair value of our outstanding fixed-rate notes, based on Level 2 inputs, was approximately $15.1 billion.

[0000804328-24-000017:notes:46]
Marketable Securities. At December 24, 2023 and September 24, 2023, our marketable securities were all classified as current and were primarily comprised of available-for-sale debt securities (substantially all of which were corporate bonds and notes).

[0000804328-24-000017:notes:47]
[same as prior period, unchanged from 0000804328-23-000043:notes:64]

[0000804328-24-000017:notes:48]
|  | December 24,2023 |
| Years to Maturity |  |
| Less than one year | $ | 1,820 |  |
| One to five years | 1,678 |  |
| Five to ten years | 7 |  |
| No single maturity date | 280 |  |
| Total | $ | 3,785 |  |

[0000804328-24-000017:notes:49]
[same as prior period, unchanged from 0000804328-23-000043:notes:66]


## ecd:MtrlTermsOfTrdArrTextBlock

[0000804328-24-000017:notes:50]
On November 29, 2023, James H. Thompson, our Chief Technology Officer, Qualcomm Technologies, Inc., adopted a Rule 10b5-1 trading arrangement (as defined in Item 408 of Regulation S-K) providing for the sale of up to 72,000 shares of our common stock through November 8, 2024.

[0000804328-24-000017:notes:51]
On December 7, 2023, Akash Palkhiwala, then our Chief Financial Officer (currently our Chief Financial Officer and Chief Operating Officer), adopted a Rule 10b5-1 trading arrangement providing for the sale of up to 40,000 shares of our common stock through February 28, 2025.
