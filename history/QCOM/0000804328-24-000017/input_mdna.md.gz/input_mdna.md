# QCOM MD&A — 0000804328-24-000017


## mdna

[0000804328-24-000017:mdna:1]
[same as prior period, unchanged from 0000804328-23-000043:mdna:1]

[0000804328-24-000017:mdna:2]
This information should be read in conjunction with the condensed consolidated financial statements and the notes thereto included in “Part I, Item 1” of this Quarterly Report and with “Management’s Discussion and Analysis of Financial Condition and Results of Operations” for the fiscal year ended September 24, 2023 contained in our 2023 Annual Report on Form 10-K.

[0000804328-24-000017:mdna:3]
[same as prior period, unchanged from 0000804328-23-000043:mdna:3]

[0000804328-24-000017:mdna:4]
First Quarter Fiscal 2024 Overview

[0000804328-24-000017:mdna:5]
Revenues for the first quarter of fiscal 2024 were $9.9 billion, an increase of 5% compared to the year ago quarter, with net income of $2.8 billion, an increase of 24% compared to the year ago quarter. Key items from the first quarter of fiscal 2024 included:

[0000804328-24-000017:mdna:6]
•QCT revenues increased by 7% in the first quarter of fiscal 2024 compared to the year ago quarter, primarily due to higher handset and automotive revenues, partially offset by lower IoT revenues.

[0000804328-24-000017:mdna:7]
•QTL revenues decreased by 4% in the first quarter of fiscal 2024 compared to the year ago quarter.

[0000804328-24-000017:mdna:8]
[same as prior period, unchanged from 0000804328-23-000043:mdna:9]

[0000804328-24-000017:mdna:9]
[same as prior period, unchanged from 0000804328-23-000043:mdna:10]

[0000804328-24-000017:mdna:10]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our cloud computing processing initiative.

[0000804328-24-000017:mdna:11]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering and research and development functions are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0000804328-24-000017:mdna:12]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when licensees’ sales occur. These trends may or may not continue in the future. Further, the trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings.

[0000804328-24-000017:mdna:13]
[same as prior period, unchanged from 0000804328-23-000043:mdna:15]

[0000804328-24-000017:mdna:14]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  | Change |  |  |  |  |  |  |
| Equipment and services | $ | 8,316 |  |  | $ | 7,784 |  |  | $ | 532 |  |  |  |  |  |  |  |
| Licensing | 1,619 |  |  | 1,679 |  |  | (60) |  |  |  |  |  |  |  |
|  | $ | 9,935 |  |  | $ | 9,463 |  |  | $ | 472 |  |  |  |  |  |  |  |

[0000804328-24-000017:mdna:15]
First quarter 2024 vs. 2023

[0000804328-24-000017:mdna:16]
The increase in revenues in the first quarter of fiscal 2024 was primarily due to:

[0000804328-24-000017:mdna:17]
+    $525 million in higher equipment and services revenues from our QCT segment

[0000804328-24-000017:mdna:18]
-    $64 million in lower licensing revenues from our QTL segment

[0000804328-24-000017:mdna:19]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  | Change |  |  |  |  |  |  |
| Cost of revenues | $ | 4,312 |  |  | $ | 4,044 |  |  | $ | 268 |  |  |  |  |  |  |  |
| Gross margin | 57 | % |  | 57 | % |  |  |  |  |  |  |  |  |

[0000804328-24-000017:mdna:20]
First quarter 2024 vs. 2023

[0000804328-24-000017:mdna:21]
Gross margin percentage remained flat in the first quarter of fiscal 2024.

[0000804328-24-000017:mdna:22]
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  | Change |  |  |  |  |  |  |
| Research and development | $ | 2,096 |  |  | $ | 2,251 |  |  | $ | (155) |  |  |  |  |  |  |  |
| % of revenues | 21 | % |  | 24 | % |  |  |  |  |  |  |  |  |

[0000804328-24-000017:mdna:23]
First quarter 2024 vs. 2023

[0000804328-24-000017:mdna:24]
The decrease in research and development expenses in the first quarter of fiscal 2024 was primarily due to a $156 million decrease driven by lower costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies). This was primarily driven by a decrease in employee-related costs as a result of certain restructuring actions initiated in fiscal 2023 (which were substantially completed by the first quarter of fiscal 2024) to fund continued investments in key growth and diversification opportunities.

[0000804328-24-000017:mdna:25]
19

[0000804328-24-000017:mdna:26]
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  | Change |  |  |  |  |  |  |
| Selling, general and administrative | $ | 627 |  |  | $ | 623 |  |  | $ | 4 |  |  |  |  |  |  |  |
| % of revenues | 6 | % |  | 7 | % |  |  |  |  |  |  |  |  |

[0000804328-24-000017:mdna:27]
First quarter 2024 vs. 2023

[0000804328-24-000017:mdna:28]
Selling, general and administrative expenses remained approximately flat in the first quarter of fiscal 2024.

[0000804328-24-000017:mdna:29]
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  | Change |  |  |  |  |  |  |
| Other (income) expense | $ | (28) |  |  | $ | 80 |  |  | $ | (108) |  |  |  |  |  |  |  |

[0000804328-24-000017:mdna:30]
First quarter 2024 vs. 2023

[0000804328-24-000017:mdna:31]
Other income and expenses in the first quarter of fiscal 2024 and 2023 included certain restructuring amounts (primarily related to accrued severance costs) from cost reduction actions initiated in fiscal 2023.

[0000804328-24-000017:mdna:32]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  | Change |  |  |  |  |  |  |
| Interest expense | $ | 178 |  |  | $ | 170 |  |  | $ | 8 |  |  |  |  |  |  |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 149 |  |  | $ | 55 |  |  | $ | 94 |  |  |  |  |  |  |  |
| Net gains on marketable securities | 11 |  |  | 11 |  |  | — |  |  |  |  |  |  |  |
| Net gains on other investments | 5 |  |  | — |  |  | 5 |  |  |  |  |  |  |  |
| Net gains on deferred compensation plan assets | 66 |  |  | 26 |  |  | 40 |  |  |  |  |  |  |  |
| Impairment losses on other investments | (12) |  |  | (14) |  |  | 2 |  |  |  |  |  |  |  |
| Other | (7) |  |  | (2) |  |  | (5) |  |  |  |  |  |  |  |
|  | $ | 212 |  |  | $ | 76 |  |  | $ | 136 |  |  |  |  |  |  |  |

[0000804328-24-000017:mdna:33]
The increase in interest and dividend income in the first quarter of fiscal 2024 was primarily due to higher interest rates earned on higher balances of interest-bearing securities.

[0000804328-24-000017:mdna:34]
20

[0000804328-24-000017:mdna:35]
[same as prior period, unchanged from 0000804328-23-000043:mdna:58]

[0000804328-24-000017:mdna:36]
[same as prior period, unchanged from 0000804328-23-000043:mdna:59]

[0000804328-24-000017:mdna:37]
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  |  |  |  |
| Expected income tax provision at federal statutory tax rate | $ | 622 |  |  | $ | 498 |  |  |  |  |  |
| Benefit from foreign-derived intangible income (FDII) deduction related to capitalizing research and development expenditures | (189) |  |  | (112) |  |  |  |  |  |
| Benefit from FDII deduction, excluding the impact of capitalizing research and development expenditures | (164) |  |  | (121) |  |  |  |  |  |
| Benefit related to the research and development tax credit | (75) |  |  | (54) |  |  |  |  |  |
| Foreign currency gains related to foreign withholding tax receivable | (39) |  |  | (130) |  |  |  |  |  |
| Excess tax benefit associated with share-based awards | (29) |  |  | (23) |  |  |  |  |  |
| Other | 25 |  |  | 40 |  |  |  |  |  |
| Income tax expense | $ | 151 |  |  | $ | 98 |  |  |  |  |  |
| Effective tax rate | 5 | % |  | 4 | % |  |  |  |  |

[0000804328-24-000017:mdna:38]
We estimate our annual effective income tax rate to be 7% for fiscal 2024, which is lower than the U.S. federal statutory rate. Our estimated annual and first quarter of fiscal 2024 effective tax rates reflect the additional benefit from FDII deductions related to certain changes made in the second half of fiscal 2023 related to income attribution and sourcing of research and development expenditures. Additional information regarding our annual effective income tax rate and income tax expense is provided in this Quarterly Report in “Notes to Condensed Consolidated Statements, Note 3. Income Taxes.”

[0000804328-24-000017:mdna:39]
| Discontinued Operations (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  | Change |  |  |  |  |  |  |
| Discontinued operations, net of income taxes | $ | (44) |  |  | $ | (38) |  |  | $ | (6) |  |  |  |  |  |  |  |

[0000804328-24-000017:mdna:40]
Discontinued operations in the first quarter of fiscal 2024 and 2023 related to the Non-Arriver businesses. Information regarding the Non-Arriver businesses is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Discontinued Operations.”

[0000804328-24-000017:mdna:41]
21

[0000804328-24-000017:mdna:42]
[same as prior period, unchanged from 0000804328-23-000043:mdna:65]

[0000804328-24-000017:mdna:43]
The following should be read in conjunction with our financial results for the first quarter of fiscal 2024 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0000804328-24-000017:mdna:44]
[same as prior period, unchanged from 0000804328-23-000043:mdna:67]

[0000804328-24-000017:mdna:45]
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  | Change |  |  |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets | $ | 6,687 |  |  | $ | 5,754 |  |  | $ | 933 |  |  |  |  |  |  |  |
| Automotive | 598 |  |  | 456 |  |  | 142 |  |  |  |  |  |  |  |
| IoT (internet of things) | 1,138 |  |  | 1,682 |  |  | (544) |  |  |  |  |  |  |  |
| Total revenues (1) | $ | 8,423 |  |  | $ | 7,892 |  |  | $ | 531 |  |  |  |  |  |  |  |
| EBT (2) | $ | 2,593 |  |  | $ | 2,183 |  |  | $ | 410 |  |  |  |  |  |  |  |
| EBT as a % of revenues | 31 | % |  | 28 | % |  | 3 points |  |  |  |  |  |  |

[0000804328-24-000017:mdna:46]
(1) Descriptions of our three QCT revenue streams can be found in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items.”

[0000804328-24-000017:mdna:47]
[same as prior period, unchanged from 0000804328-23-000043:mdna:70]

[0000804328-24-000017:mdna:48]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $8.3 billion and $7.7 billion in the first quarter of fiscal 2024 and 2023, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets as well as sales of 4G, 5G sub 6 and 5G millimeter wave RFFE products.

[0000804328-24-000017:mdna:49]
First quarter 2024 vs. 2023

[0000804328-24-000017:mdna:50]
The increase in QCT revenues in the first quarter of fiscal 2024 was primarily due to:

[0000804328-24-000017:mdna:51]
+    higher handsets revenues, primarily driven by $704 million in higher chipset shipments to certain major OEMs (primarily driven by the normalization of customer inventory levels, which were elevated in the prior year, and the acceleration of certain customer device launches relative to the prior year), and $208 million in higher revenues per chipset primarily driven by increases in average selling prices

[0000804328-24-000017:mdna:52]
-    lower IoT revenues, primarily driven by a decrease in demand across edge networking and industrial products (primarily driven by elevated customer inventory levels and the negative effects of the macroeconomic environment weakness)

[0000804328-24-000017:mdna:53]
+    higher automotive revenues, primarily driven by an increase in demand for connectivity and digital cockpit products

[0000804328-24-000017:mdna:54]
QCT EBT as a percentage of revenues increased in the first quarter of fiscal 2024 primarily due to:

[0000804328-24-000017:mdna:55]
+    lower research and development expenses

[0000804328-24-000017:mdna:56]
+    higher revenues

[0000804328-24-000017:mdna:57]
Gross margin percentage remained flat in the first quarter of fiscal 2024, primarily driven by higher product costs, offset by higher average selling prices.

[0000804328-24-000017:mdna:58]
[same as prior period, unchanged from 0000804328-23-000043:mdna:89]

[0000804328-24-000017:mdna:59]
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  | Change |  |  |  |  |  |  |
| Licensing revenues | $ | 1,460 |  |  | $ | 1,524 |  |  | $ | (64) |  |  |  |  |  |  |  |
| EBT | 1,080 |  |  | 1,117 |  |  | (37) |  |  |  |  |  |  |  |
| EBT as a % of revenues | 74 | % |  | 73 | % |  | 1 point |  |  |  |  |  |  |

[0000804328-24-000017:mdna:60]
First quarter 2024 vs. 2023

[0000804328-24-000017:mdna:61]
The decrease in QTL licensing revenues in the first quarter of fiscal 2024 was primarily due to a $68 million decrease in revenues from the ending of the recognition of certain upfront license fee consideration in the first quarter of fiscal 2023 from our long-term license agreement with Nokia.

[0000804328-24-000017:mdna:62]
QTL EBT as a percentage of revenues increased in the first quarter of fiscal 2024 primarily due to:

[0000804328-24-000017:mdna:63]
+    lower cost of sales primarily driven by a decrease in amortization expense related to acquired patents

[0000804328-24-000017:mdna:64]
[same as prior period, unchanged from 0000804328-23-000043:mdna:77]

[0000804328-24-000017:mdna:65]
[same as prior period, unchanged from 0000804328-23-000043:mdna:101]

[0000804328-24-000017:mdna:66]
|  | Three Months Ended |  |  |
|  | December 24,2023 |  | December 25,2022 |  | Change |  |  |  |  |  |  |
| Equipment and services revenues | $ | 13 |  |  | $ | 7 |  |  | $ | 6 |  |  |  |  |  |  |  |
| Income (loss) before income taxes | 11 |  |  | (8) |  |  | 19 |  |  |  |  |  |  |  |

[0000804328-24-000017:mdna:67]
First quarter 2024 vs. 2023

[0000804328-24-000017:mdna:68]
QSI segment results were not material in the first quarter of fiscal 2024 and 2023.

[0000804328-24-000017:mdna:69]
[same as prior period, unchanged from 0000804328-23-000043:mdna:107]

[0000804328-24-000017:mdna:70]
We believe that 5G combined with high-performance, low-power processing and on-device intelligence will continue to drive adoption of certain technologies that are already commonly used in smartphones by industries and applications beyond mobile handsets, such as automotive and IoT. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing, and a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long-term.

[0000804328-24-000017:mdna:71]
[same as prior period, unchanged from 0000804328-23-000043:mdna:110]

[0000804328-24-000017:mdna:72]
•We expect certain customers will continue to draw down on their inventory (which remains at elevated levels), which will continue to have a negative impact on our revenues, results of operations and cash flows.

[0000804328-24-000017:mdna:73]
•Our inventory levels continue to be elevated, and we expect this will continue in the near term. If we overestimate future customer demand, it may result in increased excess or obsolete inventory or reserve charges, negatively impacting our results of operations and cash flows.

[0000804328-24-000017:mdna:74]
•We expect transitions to new generations of leading process technology nodes to continue to drive product cost increases from certain of our key semiconductor wafer suppliers.

[0000804328-24-000017:mdna:75]
•We expect continued intense competition, including from vertical integration by certain of our customers (for example, Samsung and Huawei).

[0000804328-24-000017:mdna:76]
[same as prior period, unchanged from 0000804328-23-000043:mdna:116]

[0000804328-24-000017:mdna:77]
We have recently extended, renewed or entered into license agreements with several key OEMs, and we are currently negotiating with several other key OEMs whose agreements expire in early fiscal 2025. We have also been engaged in extended negotiations with a growing, as-yet-unlicensed China-headquartered OEM that sells primarily in developing regions. See “Risk Factors” in this Quarterly Report, including the Risk Factor titled “The continued and future success of our licensing programs requires us to continue to evolve our patent portfolio and to renew or renegotiate license agreements that are expiring.”

[0000804328-24-000017:mdna:78]
[same as prior period, unchanged from 0000804328-23-000043:mdna:117]

[0000804328-24-000017:mdna:79]
[same as prior period, unchanged from 0000804328-23-000043:mdna:118]

[0000804328-24-000017:mdna:80]
[same as prior period, unchanged from 0000804328-23-000043:mdna:119]

[0000804328-24-000017:mdna:81]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at December 24, 2023 and September 24, 2023 and for the first three months of fiscal 2024 and 2023 (in millions):

[0000804328-24-000017:mdna:82]
|  | December 24,2023 |  | September 24,2023 |  | Change |  |  |
| Cash, cash equivalents and marketable securities |  |  |  |  |  |  |  |
| Cash and cash equivalents (1) | $ | 8,133 |  |  | $ | 8,450 |  |  | $ | (317) |  |  |  |
| Marketable securities | 3,921 |  |  | 2,874 |  |  | 1,047 |  |  |  |
|  | $ | 12,054 |  |  | $ | 11,324 |  |  | $ | 730 |  |  |  |
| Debt (2) | $ | 15,480 |  |  | $ | 15,398 |  |  | $ | 82 |  |  |  |

[0000804328-24-000017:mdna:83]
(1) Excludes $61 million and $77 million of cash and cash equivalents classified as held for sale at December 24, 2023 and September 24, 2023, respectively.

[0000804328-24-000017:mdna:84]
(2) Includes our issued debt reported as long-term and $914 million reported as short-term debt (which matures in May 2024). As of December 24, 2023 and September 24, 2023, our credit facility was undrawn, and we had no commercial paper outstanding.

[0000804328-24-000017:mdna:85]
|  | Three Months Ended |
|  | December 24,2023 |  | December 25,2022 |  | Change |  |  |
| Net cash provided by operating activities | $ | 2,949 |  |  | $ | 3,095 |  |  | $ | (146) |  |  |  |
| Net cash used by investing activities | (1,256) |  |  | (133) |  |  | (1,123) |  |  |  |
| Net cash used by financing activities | (2,041) |  |  | (1,015) |  |  | (1,026) |  |  |  |

[0000804328-24-000017:mdna:86]
Cash, cash equivalents and marketable securities. The net increase in cash, cash equivalents and marketable securities for the first quarter of fiscal 2024 was primarily due to net cash provided by operating activities, partially offset by $895 million in cash dividends paid, $784 million in payments to repurchase 6 million shares of our common stock, $370 million in payments of tax withholdings related to the vesting of share-based awards and $214 million in capital expenditures.

[0000804328-24-000017:mdna:87]
During the first quarter of fiscal 2024, we paid $1.0 billion related to certain previously postponed U.S. federal income tax-payments from fiscal 2023, negatively impacting net cash provided by operating activities. Net changes in our operating assets and liabilities for the first quarter of fiscal 2024 did not have a material impact on our net cash provided by operating activities.

[0000804328-24-000017:mdna:88]
Capital Return Program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors. Additional information regarding our capital returns is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 4. Capital Stock.”

[0000804328-24-000017:mdna:89]
[same as prior period, unchanged from 0000804328-23-000043:mdna:57]

[0000804328-24-000017:mdna:90]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2023 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At December 24, 2023, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements”, “Looking Forward” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2023 Annual Report on Form 10-K.

[0000804328-24-000017:mdna:91]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Risk Factors” in this Quarterly Report.

[0000804328-24-000017:mdna:92]
[same as prior period, unchanged from 0000804328-23-000043:mdna:133]

[0000804328-24-000017:mdna:93]
Recent Accounting Guidance

[0000804328-24-000017:mdna:94]
Information regarding recent accounting guidance and the impact of such guidance on our condensed consolidated financial statements is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 1. Basis of Presentation and Significant Accounting Policies Update.”

[0000804328-24-000017:mdna:95]
[same as prior period, unchanged from 0000804328-23-000043:mdna:134]

[0000804328-24-000017:mdna:96]
[same as prior period, unchanged from 0000804328-23-000043:mdna:135]

[0000804328-24-000017:mdna:97]
[same as prior period, unchanged from 0000804328-23-000043:mdna:136]

[0000804328-24-000017:mdna:98]
We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier handset devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected.

[0000804328-24-000017:mdna:99]
We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier handset devices, and we expect this trend to continue in the foreseeable future. The mobile industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. Certain Chinese original equipment manufacturers (OEMs) have increased and may continue to increase their device share in China and in certain regions outside of China, and we derive a significant portion of our revenues from a small number of these OEMs as well. See also “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Concentrations.”

[0000804328-24-000017:mdna:100]
In addition, a number of our largest customers have developed, are developing or may develop their own integrated circuit products, or may choose our competitors’ integrated circuit products, which they have in the past utilized, currently utilize and may in the future utilize in some or all of their devices, rather than our products, which could significantly reduce the revenues we derive from these customers. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0000804328-24-000017:mdna:101]
Further, political actions, including trade and/or national security protection policies, or other actions by governments, particularly the U.S. and Chinese governments, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our customers, limit, prevent or discourage those customers from transacting business with us, or make it more expensive to do so, any of which could also significantly reduce the revenues we derive from these

[0000804328-24-000017:mdna:102]
[same as prior period, unchanged from 0000804328-23-000043:mdna:64]

[0000804328-24-000017:mdna:103]
customers. See also the Risk Factor titled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0000804328-24-000017:mdna:104]
[same as prior period, unchanged from 0000804328-23-000043:mdna:141]

[0000804328-24-000017:mdna:105]
The loss of any one of our significant customers, a reduction in the purchases of our products by any of these customers or the cancellation of significant purchases by any of these customers, whether due to the use of their own integrated circuit products or our competitors’ integrated circuit products, government restrictions, a decline in global, regional or local economic conditions, a decline in consumer demand (or a shift in consumer demand away from new devices in favor of refurbished or secondhand devices), elevated inventory levels at our customers or otherwise, would reduce our revenues and could harm our ability to achieve or sustain expected results of operations. A delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0000804328-24-000017:mdna:106]
Further, the concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products, which could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have no control, and the timing and success of such introductions may cause our revenues and results of operations to fluctuate.

[0000804328-24-000017:mdna:107]
[same as prior period, unchanged from 0000804328-23-000043:mdna:144]

[0000804328-24-000017:mdna:108]
The mobile industry has also experienced slowing growth in the premium-tier device segment due to, among other factors, a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and innovation cycles. A reduction in sales of premium-tier devices, a reduction in sales of our premium-tier integrated circuit products (which have a higher revenue and margin contribution than our lower-tier integrated circuit products), a shift in share away from OEMs that utilize our premium-tier products, or a shift in consumer demand in favor of refurbished or secondhand devices, would reduce our revenues and margins and may harm our ability to achieve or sustain expected financial results. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0000804328-24-000017:mdna:109]
[same as prior period, unchanged from 0000804328-23-000043:mdna:146]

[0000804328-24-000017:mdna:110]
Although we have more than 300 licensees, we derive a significant portion of our licensing revenues from a limited number of licensees, which includes a number of Chinese OEMs. In the event that one or more of our significant licensees fail to meet their reporting and payment obligations, or we are unable to renew or modify one or more of their license agreements under similar terms as their existing agreements, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the success of our core licensing business depends in part on the ability of our licensees to continue to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We do not have control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful in these efforts. Reductions in sales of our licensees’ products, or reductions in the average selling prices of such products without a sufficient increase in the volumes sold, would generally have an adverse effect on our licensing revenues.

[0000804328-24-000017:mdna:111]
[same as prior period, unchanged from 0000804328-23-000043:mdna:148]

[0000804328-24-000017:mdna:112]
Certain of our largest customers (for example, Samsung) develop their own integrated circuit products, which they have in the past utilized, and currently utilize, in certain of their devices and we expect will in the future utilize in some or all of their devices, rather than our products (and they have and may continue to sell their integrated circuit products to third parties, discretely or together with certain of their other products, in competition with us).

[0000804328-24-000017:mdna:113]
[same as prior period, unchanged from 0000804328-23-000043:mdna:83]

[0000804328-24-000017:mdna:114]
[same as prior period, unchanged from 0000804328-23-000043:mdna:150]

[0000804328-24-000017:mdna:115]
[same as prior period, unchanged from 0000804328-23-000043:mdna:151]

[0000804328-24-000017:mdna:116]
In addition, periodic supply/capacity constraints within the semiconductor industry may further incentivize our customers to vertically integrate in an effort to secure additional control over their supply chains.

[0000804328-24-000017:mdna:117]
If our customers begin using their own integrated circuit products rather than our products in some or all of their devices, or increase their use of their own integrated circuit products from current levels, our business, revenues, results of operations, cash flows and financial position could be materially adversely impacted. See also the Risk Factor titled “We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier handset devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected.”

[0000804328-24-000017:mdna:118]
[same as prior period, unchanged from 0000804328-23-000043:mdna:155]

[0000804328-24-000017:mdna:119]
We derive a significant portion of our revenues from Chinese OEMs, and from non-Chinese OEMs that utilize our integrated circuit products in devices they sell into China, which has the largest number of smartphone users in the world. We also source certain critical integrated circuit products from suppliers in China.

[0000804328-24-000017:mdna:120]
Due to various factors, including pressure, encouragement or incentives from, or policies of, the Chinese government (including its Made in China 2025 campaign), concerns over losing access to our integrated circuit products as a result of actual, threatened or potential U.S. or Chinese government actions or policies, including trade protection or national security policies, or other reasons, some of our customers in China have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products in their devices, or use our competitors’ integrated circuit products in their devices, rather than our products, which could materially harm our business, revenues, results of operations, cash flows and financial position. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0000804328-24-000017:mdna:121]
Political actions, including trade protection and national security policies of the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our Chinese customers or suppliers, limit, prevent or discourage certain of our Chinese customers or suppliers from transacting business with us, or make it more expensive to do so. Given our revenue concentration in China, if, due to actual, threatened or potential U.S. or Chinese government actions or policies: we were further limited in, or prohibited from, selling our integrated circuit products to Chinese customers; our non-Chinese OEM customers were limited in, or prohibited from, selling devices that incorporate our integrated circuit products into China; Chinese OEMs develop and use their own integrated circuit products or use our competitors’ integrated circuit products in some or all of their devices rather than our integrated circuit products; Chinese tariffs on our integrated circuit products or on devices which incorporate our integrated circuit products made purchasing such products or devices more expensive to our Chinese customers or Chinese consumers; or our Chinese licensees delay or cease making payments of license fees they owe us, our business, revenues, results of operations, cash flows and financial position could be materially harmed. Similarly, if, due to U.S. or Chinese government actions or policies, we were limited in or prohibited from obtaining critical integrated circuit products from our suppliers in China, our business, revenues, results of operations, cash flows and financial position could be materially harmed. See also the Risk Factors titled “We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier handset devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected” and “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0000804328-24-000017:mdna:122]
For example, we currently have export licenses from the U.S. Department of Commerce that allow us to sell 4G and other integrated circuit products, including Wi-Fi products, but excluding 5G products, to Huawei. Recent news reports have indicated that the Department of Commerce is considering not granting any new licenses for sales to Huawei and potentially revoking existing licenses. Further, we do not have a license to sell 5G products to Huawei, and Huawei has recently announced the launch of new 5G-capable devices using its own integrated circuit products. As a result, we do not expect to receive material product revenues from Huawei going forward. Additionally, to the extent that Huawei’s 5G devices take share from Chinese OEMs that utilize our 5G products or from non-Chinese OEMs that utilize our 5G products in devices they sell into China, our revenues, results of operations and cash flows could be further impacted.

[0000804328-24-000017:mdna:123]
[same as prior period, unchanged from 0000804328-23-000043:mdna:159]

[0000804328-24-000017:mdna:124]
[same as prior period, unchanged from 0000804328-23-000043:mdna:160]

[0000804328-24-000017:mdna:125]
[same as prior period, unchanged from 0000804328-23-000043:mdna:161]

[0000804328-24-000017:mdna:126]
[same as prior period, unchanged from 0000804328-23-000043:mdna:163]

[0000804328-24-000017:mdna:127]
In particular, our future growth depends in part on new and expanded product areas, and industries and applications beyond mobile handsets, such as automotive and IoT; our ability to develop leading and cost-effective technologies and products for these new and expanded product areas, industries and applications; and third parties incorporating our technologies and products into devices used in these product areas, industries and applications. Accordingly, we intend to continue to make substantial investments in these new and expanded product areas, industries and applications, and in developing related products and technologies. Our growth also depends significantly on our ability to develop and patent 5G and next-generation wireless technologies, and to develop and commercialize products using these technologies.

[0000804328-24-000017:mdna:128]
[same as prior period, unchanged from 0000804328-23-000043:mdna:165]

[0000804328-24-000017:mdna:129]
For example, the automotive industry is subject to long design-in time frames, long product life cycles and a high degree of regulatory and safety requirements, necessitating suppliers to the industry to comply with stringent qualification processes, very low defect rates and high reliability standards, all of which results in significant barriers to entry and increased costs. Additionally, certain customers have adopted, and other customers may adopt, policies that require us to achieve certain sustainability, climate or other environmental, social and governance (ESG)-related targets, such as our 2040 net-zero global GHG emissions commitment and our interim GHG emissions reduction goals. If we fail to achieve ESG-related targets that meet our customers’ requirements or expectations, these customers may not purchase products or services from us.

[0000804328-24-000017:mdna:130]
If our products fail to perform to specifications, compete with the product quality of our competitors or meet quality or regulatory standards (including product safety and information security standards, which may differ by region, geography and industry, and which are particularly stringent in the automotive industry) or other standards (including sustainability or other ESG-related standards) of a particular industry or application, we may be unable to successfully expand our business in that industry or application, and our growth could be limited.

[0000804328-24-000017:mdna:131]
28

[0000804328-24-000017:mdna:132]
In addition, in order to successfully extend our technologies and products into new and expanded product areas, and industries and applications beyond mobile handsets, we may need to transition to new business models or transform aspects of our organization, and we may not be successful in doing so.

[0000804328-24-000017:mdna:133]
[same as prior period, unchanged from 0000804328-23-000043:mdna:169]

[0000804328-24-000017:mdna:134]
[same as prior period, unchanged from 0000804328-23-000043:mdna:170]

[0000804328-24-000017:mdna:135]
We engage in acquisitions and other strategic transactions, including joint ventures, and make investments, which we believe are important to the future of our business. We routinely acquire businesses and other assets, including patents, technology and other intangible assets, enter into joint ventures or other strategic transactions, and purchase minority equity interests in or make loans to companies, including those that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our products and technologies, supporting the design and introduction of new products (or enhancing existing products) for mobile handsets, and furthering our growth and diversification strategy in industries and applications beyond mobile handsets. Many of our strategic activities entail a high degree of risk and require the use of significant amounts of capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not be successful, generate financial returns or result in increased adoption or continued use of our technologies or products. We may underestimate the costs or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership or variable interests. In addition, we have in the past recorded, and may in the future record, impairment or other charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our results of operations and financial condition, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0000804328-24-000017:mdna:136]
Achieving the anticipated benefits of business acquisitions depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from acquired technologies or products or from future technologies or products based on these technologies, and we may become subject to liabilities, including liabilities arising as a result of litigation, that are not covered by any indemnification protection that we may obtain. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models, geographic regions, industries and applications served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0000804328-24-000017:mdna:137]
[same as prior period, unchanged from 0000804328-23-000043:mdna:175]

[0000804328-24-000017:mdna:138]
If we do not achieve the anticipated benefits of business acquisitions or other strategic activities, or if we are unable to consummate acquisitions or strategic investments that we consider important to the future of our business, our business and results of operations may be adversely affected, our growth and diversification strategy may not be successful, our stock price may decline and our reputation may be harmed.

[0000804328-24-000017:mdna:139]
[same as prior period, unchanged from 0000804328-23-000043:mdna:176]

[0000804328-24-000017:mdna:140]
[same as prior period, unchanged from 0000804328-23-000043:mdna:177]

[0000804328-24-000017:mdna:141]
[same as prior period, unchanged from 0000804328-23-000043:mdna:178]

[0000804328-24-000017:mdna:142]
[same as prior period, unchanged from 0000804328-23-000043:mdna:179]

[0000804328-24-000017:mdna:143]
[same as prior period, unchanged from 0000804328-23-000043:mdna:180]

[0000804328-24-000017:mdna:144]
[same as prior period, unchanged from 0000804328-23-000043:mdna:181]

[0000804328-24-000017:mdna:145]
•an inability to procure or utilize raw materials, components or products from our suppliers due to government prohibitions or restrictions on transactions with certain countries and/or companies, and alternative suppliers, raw material sources or raw materials are not available or not available in acceptable time frames or upon acceptable terms;

[0000804328-24-000017:mdna:146]
[same as prior period, unchanged from 0000804328-23-000043:mdna:185]

[0000804328-24-000017:mdna:147]
[same as prior period, unchanged from 0000804328-23-000043:mdna:186]

[0000804328-24-000017:mdna:148]
[same as prior period, unchanged from 0000804328-23-000043:mdna:187]

[0000804328-24-000017:mdna:149]
[same as prior period, unchanged from 0000804328-23-000043:mdna:188]

[0000804328-24-000017:mdna:150]
[same as prior period, unchanged from 0000804328-23-000043:mdna:189]

[0000804328-24-000017:mdna:151]
[same as prior period, unchanged from 0000804328-23-000043:mdna:190]

[0000804328-24-000017:mdna:152]
[same as prior period, unchanged from 0000804328-23-000043:mdna:191]

[0000804328-24-000017:mdna:153]
[same as prior period, unchanged from 0000804328-23-000043:mdna:192]

[0000804328-24-000017:mdna:154]
[same as prior period, unchanged from 0000804328-23-000043:mdna:193]

[0000804328-24-000017:mdna:155]
We rely on sole- or limited-source suppliers for certain products, which may exacerbate the risks identified above, and subject us to other significant risks, including poor product performance and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. While we have established and may in the future establish alternate suppliers for certain products, these suppliers may require significant amounts of time and levels of support to bring such products to production, both of which may increase for complex or leading process technologies. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, the elimination or limitation of a foundry supplier’s ability to manufacture components or products for us

[0000804328-24-000017:mdna:156]
due to trade or national security protection policies could increase our vulnerability to sole- or limited-source arrangements and limit or prevent us from procuring critical components or products from those suppliers. Future consolidation of foundry suppliers could also increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions, increase our manufacturing costs and limit the amount of capacity available to us. Our arrangements with our suppliers may obligate us to incur costs to manufacture, assemble and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies (which adds risk to manufacturing yields and reliability), and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Any of the above could negatively impact our business, results of operations and cash flows.

[0000804328-24-000017:mdna:157]
Although we have long-term contracts with our suppliers, some of these contracts do not provide for long-term capacity commitments. To the extent we do not have firm commitments from our suppliers over a specific time period or for any specific quantity, our suppliers may allocate, and in the past have allocated, capacity to the manufacture, assembly and testing of products for their other customers (including our competitors) while reducing or limiting capacity to manufacture, assemble or test our products, and such capacity may be limited based on our suppliers’ ability and willingness to invest in the capital required to manufacture in the leading process technologies. Our suppliers or potential alternate suppliers may also manufacture their own integrated circuits that compete with our products. Such suppliers have in the past allocated and may again allocate raw materials and manufacturing capacity to their own products and reduce or limit the production of our products. To the extent we do obtain long-term capacity commitments, we may incur additional costs related to those commitments or make non-refundable payments for capacity commitments that are not used. Further, certain of our suppliers have in the past attempted, and may in the future attempt, to unilaterally reduce their capacity commitments to us. Accordingly, capacity for our products may not be available when we need it. Finally, we may not receive reasonable pricing, manufacturing or delivery terms from our suppliers, and our ability to obtain favorable terms may be diminished during times of high demand and/or limited manufacturing capacity for integrated circuit products.

[0000804328-24-000017:mdna:158]
We cannot guarantee that the actions of our suppliers will not cause disruptions in our operations that could harm our ability to meet our delivery obligations to our customers or increase our cost of sales. To the extent we are unable to obtain adequate supply to meet our delivery obligations, we may be obligated to make payments to our customers for such shortfalls. From time to time, the global semiconductor industry experiences demand for integrated circuits that exceeds the industry’s capacity to meet that demand. Our ability to meet increased demand for our products has been in the past and may in the future be limited due to the inability to obtain the additional manufacturing, assembly and test capacity necessary to fully meet such demand. If we are unable to fully meet customer demand, this could result in lost sales opportunities, reduced revenue growth and harm to our customer relationships. These issues may be exacerbated if customers overstate their expected demand requirements in order to procure additional supply, which could negatively impact our ability to forecast and to allocate supply appropriately among our customers. The above issues may also be exacerbated with respect to our platform solutions, which already entail a great deal of complexity due to differing lead-times, technologies and suppliers for each integrated circuit product included in such solutions. Additionally, our suppliers have in the past and may in the future increase their prices during periods of capacity constraints, or for other reasons, thus increasing our costs.

[0000804328-24-000017:mdna:159]
While capacity constraints have largely abated, we expect to continue to see product cost increases from certain of our key semiconductor wafer suppliers, which, without corresponding increases in the prices of our products, could negatively impact our margins.

[0000804328-24-000017:mdna:160]
[same as prior period, unchanged from 0000804328-23-000043:mdna:199]

[0000804328-24-000017:mdna:161]
See also the Risk Factor below titled “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises, geopolitical conflicts and cyber-

[0000804328-24-000017:mdna:162]
31

[0000804328-24-000017:mdna:163]
attacks; timely supply of equipment and materials; and various manufacturing issues” as similar risks, as well as additional risks, may be applicable to our third-party suppliers’ manufacturing facilities, which could result in disruptions to our business or additional costs to us, and negatively impact our results of operations.

[0000804328-24-000017:mdna:164]
[same as prior period, unchanged from 0000804328-23-000043:mdna:201]

[0000804328-24-000017:mdna:165]
[same as prior period, unchanged from 0000804328-23-000043:mdna:202]

[0000804328-24-000017:mdna:166]
We are subject to many complex environmental, health and safety laws, regulations and rules in each jurisdiction in which we operate our manufacturing (and research and development) facilities. The regulatory landscape in these areas continues to evolve, and we anticipate additional laws, regulations and rules in the future. In particular, new, or changes in, environmental and climate change laws, regulations or rules, including relating to greenhouse gas emissions, could lead to new or additional investments in production processes and could increase environmental compliance expenditures. In addition, certain environmental laws impose strict, and in certain circumstances joint and several, liability on current or previous owners or operators of real property, or parties who arranged for hazardous substances to be sent to disposal or treatment facilities, for the cost of investigation, removal or remediation of hazardous substances. As a result, we may incur clean-up costs in connection with any such removal or remediation efforts, as well as other third-party claims in connection with contaminated sites. In addition, we could be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage. If we, or companies or facilities we acquire or have acquired, in the past failed or in the future fail to comply with any such laws and regulations, then we could incur regulatory penalties, fines and legal liabilities; suspension of production; significant compliance requirements; alteration of our manufacturing, assembly or test processes; restriction on our ability to modify or expand our facilities; damage to our reputation; and restrictions on our operations or sales. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. We cannot make assurances that we will at all times be in compliance with such laws, regulations, rules and permits. See also the risk factor titled “Our business may suffer due to the impact of, or our failure to comply with, the various existing, new or amended laws, regulations, policies or standards to which we are subject.”

[0000804328-24-000017:mdna:167]
[same as prior period, unchanged from 0000804328-23-000043:mdna:205]

[0000804328-24-000017:mdna:168]
[same as prior period, unchanged from 0000804328-23-000043:mdna:206]

[0000804328-24-000017:mdna:169]
[same as prior period, unchanged from 0000804328-23-000043:mdna:207]

[0000804328-24-000017:mdna:170]
Our manufacturing processes are highly complex, require advanced and costly equipment and must be continuously modified to improve yields and performance. Difficulties in the production process can reduce yields or interrupt production, and as a result, we may not be able to deliver our products or do so in a timely, cost-effective or competitive manner. Further, to remain competitive and meet customer demand, we may be required to improve our facilities and process technologies and carry out extensive research and development, each of which may require investment of significant amounts of capital and may have a material adverse effect on our results of operations, cash flows and financial condition.

[0000804328-24-000017:mdna:171]
From time to time, we purchase equipment to meet expected customer demand in advance of any purchase orders or long-term purchase commitments. Further, we typically begin manufacturing our products using our or our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates and may not be covered by long-term purchase commitments. As a result, we may incur increased inventory and manufacturing costs and/or record impairment charges to the extent anticipated sales ultimately do not materialize or are lower than expected. If we or our customers overestimate demand, or if demand is impacted by factors outside of our or our customers’ control, and such demand is not covered by a binding commitment from our customers, we may experience higher inventory carrying and operating costs and/or increased excess or obsolete inventory or reserve charges, which would negatively impact our results of operations.

[0000804328-24-000017:mdna:172]
[same as prior period, unchanged from 0000804328-23-000043:mdna:212]

[0000804328-24-000017:mdna:173]
[same as prior period, unchanged from 0000804328-23-000043:mdna:213]

[0000804328-24-000017:mdna:174]
Third parties regularly attempt to gain unauthorized access to our IT systems, and many such attacks are increasingly more sophisticated. These attacks, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, exploiting vulnerabilities in hardware, software or other IT infrastructure and impersonating authorized users, among others. We are also subject to ransom-style cyber-attacks, which could expose our confidential or proprietary information, demand payment of money and/or impact our IT systems and cause widespread disruption to our business, including our manufacturing operations. Third parties that store and/or process our confidential information, or that provide products, software or services used in our IT infrastructure, may be subject to similar attacks, which could also result in malware being introduced into our IT infrastructure, e.g., through the third parties’ software and/or software updates. Such attacks could result in the misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our IT systems. We believe that we have a robust cybersecurity program that is aligned to international cybersecurity frameworks, and that we leverage industry best practices across people, processes and technologies in an attempt to mitigate cybersecurity threats. However, we cannot anticipate, detect, repel or implement fully effective preventative measures against all cybersecurity threats, particularly because the techniques used are increasingly sophisticated and constantly evolving. For example, as AI continues to evolve, cyber-attackers could also use AI to develop malicious code and sophisticated phishing attempts. As part of our cybersecurity program, we seek to identify and remediate vulnerabilities in our IT systems and software (including third party software used in our IT systems) that could be

[0000804328-24-000017:mdna:175]
33

[0000804328-24-000017:mdna:176]
exploited by hackers or other malicious actors. However, we may not be aware of all such vulnerabilities, and we may fail to identify and/or remediate such vulnerabilities before they are exploited. Attempts to gain unauthorized access to our IT systems or other attacks have in the past, in certain instances and to certain degrees, been successful (but have not caused significant harm), and may in the future be successful, and in some cases, we might be unaware of an incident or its magnitude and effects.

[0000804328-24-000017:mdna:177]
In addition, employees and former employees, in particular former employees who become employees of our competitors, customers, licensees or other third parties, including state actors, have in the past and may in the future misappropriate, wrongfully use, publish or provide to our competitors, customers, licensees or other third parties, including state actors, our technology, intellectual property or other proprietary or confidential information. This risk is exacerbated as competitors for talent, particularly engineering talent, increasingly attempt to hire our employees. See also the Risk Factor titled “We may not be able to attract or retain qualified employees.” Similarly, we provide access to certain of our technology, intellectual property and other proprietary or confidential information to our direct and indirect customers and licensees and certain of our consultants, who have in the past and may in the future wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. We also provide access to certain of our technology, intellectual property and other proprietary or confidential information to certain of our joint venture partners, including those affiliated with state actors and including in foreign jurisdictions where ownership restrictions may require us to take a minority ownership interest in the joint venture. Such joint venture partners may wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. Our technology, intellectual property and other proprietary or confidential information that we have provided to customers, licensees or other business partners could also be wrongfully obtained by third parties through cyber-attacks on such customers’, licensees’ or other business partners’ IT systems.

[0000804328-24-000017:mdna:178]
[same as prior period, unchanged from 0000804328-23-000043:mdna:216]

[0000804328-24-000017:mdna:179]
[same as prior period, unchanged from 0000804328-23-000043:mdna:217]

[0000804328-24-000017:mdna:180]
[same as prior period, unchanged from 0000804328-23-000043:mdna:218]

[0000804328-24-000017:mdna:181]
We may not be able to attract or retain qualified employees.

[0000804328-24-000017:mdna:182]
Our future success depends upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. In addition, in order to extend our business into certain new and expanded product areas and industries and applications beyond mobile handsets, we need to attract, retain and motivate engineering and other technical personnel with specialized skills in these areas, and these skills are in high demand among our competitors. The market for employees in our industry is extremely competitive, and competitors for talent, particularly engineering talent, increasingly attempt to hire, and to varying degrees have been successful in hiring, our employees or employment candidates, including by establishing or expanding local offices near our headquarters in San Diego, California. Further, the increased availability of remote working arrangements has expanded the pool of companies that can compete for our employees and employment candidates. A number of such competitors for talent are significantly larger than us and/or offer compensation in excess of what we offer or other benefits that we do not offer. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller.

[0000804328-24-000017:mdna:183]
The COVID-19 pandemic caused us to modify our workforce practices, including having the vast majority of our employees work from home. Upon the reopening of our offices, we initially operated under a hybrid work model, meaning

[0000804328-24-000017:mdna:184]
that the majority of our employees had the flexibility to work remotely at least some of the time. In fiscal 2023, we implemented changes to our hybrid work model that require the majority of our employees to spend the majority of their working time in the office. This requirement for greater in-office attendance may not meet the needs or expectations of our employees and could negatively impact our ability to attract and retain employees, particularly if it is perceived as less favorable compared to other companies’ remote work policies.

[0000804328-24-000017:mdna:185]
If we are unable to attract or retain qualified employees or fail to maintain employee productivity due to any of the factors described above or for other reasons, our business could be adversely impacted.

[0000804328-24-000017:mdna:186]
[same as prior period, unchanged from 0000804328-23-000043:mdna:222]

[0000804328-24-000017:mdna:187]
[same as prior period, unchanged from 0000804328-23-000043:mdna:223]

[0000804328-24-000017:mdna:188]
[same as prior period, unchanged from 0000804328-23-000043:mdna:224]

[0000804328-24-000017:mdna:189]
Our patent license agreements in effect that generate a significant portion of our licensing revenues are effective for a specified term. To receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms, and may impact the financial or other terms of license agreements not subject to the litigation or arbitration. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such licensees. Finally, certain of our license agreements contain binding renewal provisions which provide that if the parties are unable to agree upon the terms and conditions of a new license agreement by a specified date, either party may initiate binding arbitration proceedings to establish such terms and conditions. Such new license agreement would become effective immediately after the expiration of the prior agreement.  Nonetheless, in either event, we may not be able to recognize some or any revenues related to that licensee’s product sales until such new license agreement is finalized.

[0000804328-24-000017:mdna:190]
Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.

[0000804328-24-000017:mdna:191]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, alleging that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) attempts by licensees to shift their royalty obligation to their suppliers in order to make royalty collection more difficult or reduce the amount of royalties collected.

[0000804328-24-000017:mdna:192]
In addition, certain licensees have disputed, underreported, underpaid, not reported or not paid royalties owed to us under their license agreements or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or have delayed entering into or renewing license agreements with us for their use of our intellectual property, and they or others may engage in such behavior in the future. The fact that one or more licensees dispute, underreport, underpay, do not report or do not pay royalties owed to us may encourage other licensees to take similar actions or not renew their existing license agreements, and may encourage other licensees or unlicensed companies to delay entering into, or to not enter into, new license agreements. Further, to the extent such licensees and companies increase their

[0000804328-24-000017:mdna:193]
device share, the negative impact of their underreporting, underpayment, non-payment or non-reporting on our business, revenues, results of operations, cash flows and financial condition will be exacerbated.

[0000804328-24-000017:mdna:194]
We have been in the past and are currently subject to various litigation and/or governmental investigations and proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. See also the Risk Factors below titled “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.”

[0000804328-24-000017:mdna:195]
[same as prior period, unchanged from 0000804328-23-000043:mdna:231]

[0000804328-24-000017:mdna:196]
Further, some third parties have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions should not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by limiting the base upon which the royalty rate may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies.

[0000804328-24-000017:mdna:197]
Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party. Further, SDOs in certain countries may attempt to modify widely accepted standards and claim the resulting standard as their own. In addition, governments may enact policies concerning standard-essential patents, such as the European Commission’s recently proposed regulations which would create a new regulatory scheme for standard-essential patents, that may have various consequences, some of which may be detrimental, such as by devaluing standard-essential patents or disrupting worldwide technology standards. Other jurisdictions may adopt similar regulatory schemes, which could also have such effects.

[0000804328-24-000017:mdna:198]
[same as prior period, unchanged from 0000804328-23-000043:mdna:235]

[0000804328-24-000017:mdna:199]
[same as prior period, unchanged from 0000804328-23-000043:mdna:236]

[0000804328-24-000017:mdna:200]
As described in the Risk Factor below titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings,” we have been in the past, currently are and may in the future be subject to various governmental investigations and/or legal proceedings challenging our patent licensing practices. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5.

[0000804328-24-000017:mdna:201]
Commitments and Contingencies.” We believe that one intent of certain of these governmental investigations and legal proceedings has been to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0000804328-24-000017:mdna:202]
If we were required to reduce the royalty rates in our patent license agreements, our revenues, earnings and cash flows would be negatively impacted absent a sufficient increase in the volume of sales of devices upon which royalties are paid. Similarly, if we were required to reduce the base on which our royalties are calculated (e.g., license at the chipset level rather than at the device level), our revenues, earnings and cash flows would be negatively impacted unless there was a sufficient increase in the volume of sales of devices upon which royalties are paid or we were able to increase our royalty rates to offset the decrease in revenues resulting from such lower royalty base.

[0000804328-24-000017:mdna:203]
[same as prior period, unchanged from 0000804328-23-000043:mdna:239]

[0000804328-24-000017:mdna:204]
[same as prior period, unchanged from 0000804328-23-000043:mdna:240]

[0000804328-24-000017:mdna:205]
To the extent that we were required to implement any of these licensing and/or business practices, including by modifying or renegotiating our existing license agreements or pursuing other commercial arrangements, we would incur additional transaction costs, which may be significant, we could incur delays in recognizing revenues until license negotiations were completed, and our business, revenues, results of operations, cash flows and financial condition could be harmed. The impact of any such changes to our licensing practices could vary widely and by jurisdiction, depending on the specific outcomes and the geographic scope of such outcomes. In addition, if we were required to make modifications to our licensing practices in one jurisdiction, licensees or governmental agencies in other jurisdictions may attempt to obtain similar outcomes for themselves or for such other jurisdictions, as applicable, which could result in increased legal costs and further harm to our business, revenues, results of operations, cash flows and financial condition.

[0000804328-24-000017:mdna:206]
[same as prior period, unchanged from 0000804328-23-000043:mdna:243]

[0000804328-24-000017:mdna:207]
Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.

[0000804328-24-000017:mdna:208]
We have been in the past and currently are subject to various governmental investigations and/or legal proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Key allegations or findings in those matters include or have in the past included, among others: that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers; that our royalty rates are too high; that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions); that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets; that we have entered into exclusive agreements with chipset customers that foreclose competition; that we leverage our position in baseband chipsets in the RFFE space; and that we violate antitrust laws and engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0000804328-24-000017:mdna:209]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others: the loss of our ability to enforce one or more of our patents; injunctions; monetary damages, fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers or other component suppliers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region. If some or

[0000804328-24-000017:mdna:210]
all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any revenues under such agreements. The renegotiation of license agreements could result in terms that are less favorable to us than existing terms, or lead to arbitration or litigation to resolve the licensing terms, which could also be less favorable to us than existing terms, and each of which could take months or years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. The occurrence of any of the above could have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies. Further, depending on the breadth and severity of the circumstances above, we may have to reduce, suspend or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted.

[0000804328-24-000017:mdna:211]
[same as prior period, unchanged from 0000804328-23-000043:mdna:247]

[0000804328-24-000017:mdna:212]
[same as prior period, unchanged from 0000804328-23-000043:mdna:248]

[0000804328-24-000017:mdna:213]
[same as prior period, unchanged from 0000804328-23-000043:mdna:249]

[0000804328-24-000017:mdna:214]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on our customers and licensees to develop devices and services based on these technologies to drive consumer demand for such devices, and to establish the selling prices for such devices (which impact the amount of royalties we receive for certain devices). Further, the timing of our shipments of our products is dependent on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries and applications beyond mobile handsets, such as automotive and IoT, among others. Commercial deployments of 5G networks and devices have begun and are expected to continue for the foreseeable future. However, the timing and scale of certain such deployments were delayed due to the COVID-19 pandemic, and future deployments may similarly be delayed for reasons that are beyond our control.

[0000804328-24-000017:mdna:215]
Our revenues and growth in revenues could be negatively impacted, our business may be harmed and our substantial investments in these technologies may not provide us an adequate return, if: our customers’ and licensees’ revenues and sales of products, particularly premium-tier handset products, and services using these technologies, or average selling prices of such products, decline due to, for example, the maturity of smartphone penetration in developed regions, including China; we do not continue to maintain our intellectual property and technical leadership in 5G, including in ongoing 5G standardization efforts; we are unable to drive the adoption of our products into networks and devices, including devices beyond mobile handsets; consumers’ rates of replacement of smartphones and other devices decline; or there is a shift in consumer demand away from new devices in favor of refurbished or secondhand devices.

[0000804328-24-000017:mdna:216]
[same as prior period, unchanged from 0000804328-23-000043:mdna:253]

[0000804328-24-000017:mdna:217]
Our products and technologies face significant competition. Competition may intensify as our current competitors expand their product offerings, improve their products or reduce the prices of their products as part of a strategy to maintain existing business and customers or attract new business and customers, as new opportunities develop, and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: OEM concentrations; vertical integration; competition in certain geographic regions; government intervention or support of national industries or competitors; the ability to maintain product differentiation in light of evolving industry standards and speed of technological change (including the transition to smaller geometry process technologies, the demand for always on, always connected capabilities, the increasing use of AI and machine learning technologies and the need to run complex AI-based applications on devices); access to capacity in the supply chain; and value-added features that drive selling prices and consumer demand for new devices.

[0000804328-24-000017:mdna:218]
[same as prior period, unchanged from 0000804328-23-000043:mdna:255]

[0000804328-24-000017:mdna:219]
[same as prior period, unchanged from 0000804328-23-000043:mdna:256]

[0000804328-24-000017:mdna:220]
•differentiate our integrated circuit products with innovative technologies across multiple products and features (e.g., modem, RFFE including millimeter wave (mmWave), graphics and other processors, camera, connectivity and on-device AI) and with smaller geometry process technologies that drive both performance and lower power consumption;

[0000804328-24-000017:mdna:221]
[same as prior period, unchanged from 0000804328-23-000043:mdna:258]

[0000804328-24-000017:mdna:222]
[same as prior period, unchanged from 0000804328-23-000043:mdna:259]

[0000804328-24-000017:mdna:223]
[same as prior period, unchanged from 0000804328-23-000043:mdna:260]

[0000804328-24-000017:mdna:224]
[same as prior period, unchanged from 0000804328-23-000043:mdna:261]

[0000804328-24-000017:mdna:225]
[same as prior period, unchanged from 0000804328-23-000043:mdna:262]

[0000804328-24-000017:mdna:226]
[same as prior period, unchanged from 0000804328-23-000043:mdna:263]

[0000804328-24-000017:mdna:227]
[same as prior period, unchanged from 0000804328-23-000043:mdna:264]

[0000804328-24-000017:mdna:228]
[same as prior period, unchanged from 0000804328-23-000043:mdna:265]

[0000804328-24-000017:mdna:229]
[same as prior period, unchanged from 0000804328-23-000043:mdna:266]

[0000804328-24-000017:mdna:230]
[same as prior period, unchanged from 0000804328-23-000043:mdna:267]

[0000804328-24-000017:mdna:231]
•continue to develop brand recognition to effectively compete against better known companies in computing and other consumer driven segments and to deepen our presence in significant emerging regions.

[0000804328-24-000017:mdna:232]
We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application, industry or standard product, including those that produce products for mobile handsets, automotive or IoT, among others. Most of these competitors compete with us with respect to some, but not all, of our businesses or product lines. Companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Apple, Broadcom, HiSilicon, MediaTek, Mobileye, Nvidia, NXP Semiconductors, Qorvo, Samsung, Skyworks, Texas Instruments and UNISOC. Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to use our competitors’ integrated circuit products, to utilize their own internally-developed integrated circuit products and/or sell such products to others, or to utilize alternative technologies; lower cost structures or a willingness and ability to accept lower prices or lower margins for their products, particularly in China; foreign government support of other technologies, competitors or OEMs that sell devices that

[0000804328-24-000017:mdna:233]
do not contain our integrated circuit products; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; the development and sale of infrastructure equipment for wireless networks, which may enable such competitors to better optimize their integrated circuit products for performance on those networks; more extensive relationships with local distribution companies and OEMs in certain geographic regions (such as China); more experience in industries and applications beyond mobile handsets (such as automotive and IoT); and a more established presence in certain regions.

[0000804328-24-000017:mdna:234]
In addition, certain of our largest customers have in the past utilized, currently utilize and may in the future utilize our competitors’ integrated circuit products in some or all of their devices, rather than our products. Further, certain of those customers have developed, are developing or may develop their own integrated circuit products (effectively making them competitors), which they have in the past utilized, currently utilize and may in the future utilize in some or all of their devices, rather than our products. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0000804328-24-000017:mdna:235]
[same as prior period, unchanged from 0000804328-23-000043:mdna:271]

[0000804328-24-000017:mdna:236]
Competition in any or all product areas or device tiers may result in the loss of business or customers, which would negatively impact our business, revenues, results of operations, cash flows and financial condition. Such competition may also reduce average selling prices for our chipset products or the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging regions and China where competitors may have lower cost structures or may have a willingness and ability to accept lower prices or lower margins on their products. Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0000804328-24-000017:mdna:237]
[same as prior period, unchanged from 0000804328-23-000043:mdna:274]

[0000804328-24-000017:mdna:238]
[same as prior period, unchanged from 0000804328-23-000043:mdna:275]

[0000804328-24-000017:mdna:239]
Our products are complex and may contain defects, errors or security vulnerabilities, or experience failures or unsatisfactory performance, due to any number of issues, including issues in materials, design, fabrication, packaging and/or use within a system. Development of products in new domains of technology, and the migration to integrated circuit technologies with smaller geometric feature sizes, increases complexity and adds risk to manufacturing yields and reliability, and increases the likelihood of product defects, errors or security vulnerabilities. Defects, errors, security vulnerabilities or other unintended functionality could also be introduced into our products by cyber-attacks or other actions by malicious actors, either directly or through third-party products or software used in our products or IT infrastructure. Further, because of the complexity of our products, defects, errors or security vulnerabilities might only be detected when the products are in use. Risks associated with product or technology defects, errors or security vulnerabilities are exacerbated by the fact that our customers typically integrate our products into consumer and other devices.

[0000804328-24-000017:mdna:240]
The use of devices containing our products to interact with untrusted systems or otherwise access untrusted content creates a risk of exposing the system hardware and software in those devices to malicious attacks. Further, security vulnerabilities in our products or the technologies we use could expose our customers, or end users of our customers’ products, to hackers or other unscrupulous third parties who develop and deploy malware that could attack our products or our customers’ products or IT infrastructure. Such attacks could result in the disruption of our customers’ businesses or the misappropriation, theft, misuse, disclosure, loss or destruction of the technology or intellectual property, or the proprietary, confidential or personal information, of our customers, their employees or the end users of our customers’ devices. While we continue to focus on this issue and take measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and applications, and increasing the risk of security failures, and techniques used to perpetrate cybersecurity attacks are increasingly sophisticated and constantly evolving. See also the Risk

[0000804328-24-000017:mdna:241]
40

[0000804328-24-000017:mdna:242]
Factor titled “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0000804328-24-000017:mdna:243]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, meet certain regulatory or industry standards (including product safety and information security standards, which may differ by region, geography and industry, and which are particularly stringent in the automotive industry), or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and the end users of such devices, and potentially to our customers’ IT infrastructure. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products, repairing or replacing defective products, writing down defective inventory or indemnification obligations under our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, and losses on unfavorable purchase commitments. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products.

[0000804328-24-000017:mdna:244]
In addition, the occurrence of defects, errors or security vulnerabilities may give rise to product liability claims, particularly if such defects, errors or security vulnerabilities in our products or the technology we use, or the products into which they are integrated, result in personal injury or death, and could result in significant costs, expenses and losses. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the attention of our technical and management personnel and harm our business, even if we are successful. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. We may also be required to indemnify and/or defend our customers from product liability claims relating to our products. Further, our business liability insurance may be inadequate, may not cover the claims, and future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as: automobiles, including ADAS/AD functions; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and XR for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0000804328-24-000017:mdna:245]
[same as prior period, unchanged from 0000804328-23-000043:mdna:281]

[0000804328-24-000017:mdna:246]
[same as prior period, unchanged from 0000804328-23-000043:mdna:282]

[0000804328-24-000017:mdna:247]
[same as prior period, unchanged from 0000804328-23-000043:mdna:283]

[0000804328-24-000017:mdna:248]
[same as prior period, unchanged from 0000804328-23-000043:mdna:284]

[0000804328-24-000017:mdna:249]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. We cannot predict with certainty the long-term effects of any potential changes. In the United States, Europe (including the

[0000804328-24-000017:mdna:250]
United Kingdom), India, China and elsewhere, there is continued discussion regarding potential patent law changes, and there is current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. Some proposed changes would apply to only standard-essential patents, and such changes may substantially alter the incentives to participate in standardization or develop standards-compliant products. See also the Risk Factor entitled “Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.”

[0000804328-24-000017:mdna:251]
[same as prior period, unchanged from 0000804328-23-000043:mdna:286]

[0000804328-24-000017:mdna:252]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies or political actions of governments, including trade protection and national security policies; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business or the pricing and integration of additional features and functionality into our chipset products. See also the Risk Factors titled “Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.”

[0000804328-24-000017:mdna:253]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0000804328-24-000017:mdna:254]
[same as prior period, unchanged from 0000804328-23-000043:mdna:290]

[0000804328-24-000017:mdna:255]
See also the Risk Factors titled “Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business” and “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0000804328-24-000017:mdna:256]
[same as prior period, unchanged from 0000804328-23-000043:mdna:292]

[0000804328-24-000017:mdna:257]
From time to time, companies have asserted, and may again assert, patent, copyright or other intellectual property claims against us relating to our technologies or products, including those we have acquired from other companies. These claims have resulted and may again result in our involvement in litigation, and we are currently involved in such litigation, including

[0000804328-24-000017:mdna:258]
certain matters described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products were found to infringe another company’s intellectual property, we could be subject to an injunction or be required to redesign our products, or to license such intellectual property or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products, license such intellectual property used in our products or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling our products. Similarly, our suppliers could be found to infringe another company’s intellectual property, and such suppliers could then be enjoined from providing products or services to us.

[0000804328-24-000017:mdna:259]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products sold by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel and/or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0000804328-24-000017:mdna:260]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing corresponding declines in our chipset or licensing revenues.

[0000804328-24-000017:mdna:261]
[same as prior period, unchanged from 0000804328-23-000043:mdna:297]

[0000804328-24-000017:mdna:262]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe that we will continue to see, customers request that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of our products’ source code and may expose our related intellectual property to adverse licensing conditions. Licensing of such open source software may impose certain obligations on us if we were to distribute derivative works of that software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers, or to license such derivative works under a particular type of license that is different than what we customarily use to license our software. Furthermore, in the course of product development, we may make contributions to third-party open source projects that could subject our intellectual property to adverse licensing conditions. For example, to encourage the growth of a software ecosystem that is interoperable with our products, we may need to contribute certain implementations under the open source licensing terms that govern such projects, which may adversely impact our associated intellectual property. Developing open source products, while adequately protecting the intellectual property upon which our licensing programs depend, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental and third-party scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products.

[0000804328-24-000017:mdna:263]
43

[0000804328-24-000017:mdna:264]
[same as prior period, unchanged from 0000804328-23-000043:mdna:299]

[0000804328-24-000017:mdna:265]
[same as prior period, unchanged from 0000804328-23-000043:mdna:305]

[0000804328-24-000017:mdna:266]
The semiconductor industry is highly cyclical, volatile, subject to downturns and characterized by constant and rapid technological change, price erosion, evolving technical standards, frequent new product introductions, short product life cycles and fluctuations in product supply and demand. Periods of downturns have been characterized by diminished demand for end-user products, high inventory levels, excess or obsolete inventory adjustments or reserves, underutilization of manufacturing capacity, changes in revenue mix and erosion of average selling prices. During such downturns, our revenues have declined, and our results of operations and financial condition have been adversely impacted. We expect our business to continue to be subject to such cyclical downturns. In addition, we are currently seeing and expect to continue to see elevated inventory levels at certain of our customers (negatively impacting the volume of chipsets they purchase from us until such inventory is depleted).

[0000804328-24-000017:mdna:267]
A decline in global, regional or local economic conditions, or a slow-down in economic growth, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could also have adverse, wide-ranging effects on our business and financial results, including: a decrease in demand for our products and technologies; a decrease in demand for the products and services of our customers or licensees; the inability of our suppliers to deliver on their supply commitments to us, our inability to supply our products to our customers and/or the inability of our customers or licensees to supply their products to end users; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our customers or licensees; failures by counterparties; and/or negative effects on wireless device inventories. In addition, our customers’ and licensees’ ability to purchase or pay for our products and intellectual property and network operators’ ability to upgrade their wireless networks could be adversely affected, potentially leading to a reduction, cancellation or delay of orders for our products. Further, inflationary pressure may increase our costs, including employee compensation costs, reduce demand for our products or those of our customers or licensees due to increased prices of those products, or result in employee attrition to the extent our compensation does not keep up with inflation, particularly if our competitors’ compensation does.

[0000804328-24-000017:mdna:268]
Our stock price and financial results have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and our financial results include those identified above and throughout this Risk Factors section, as well as: volatility of the stock market in general and technology and semiconductor companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees, including any announcement concerning the initiation of, or any developments in, any lawsuit or governmental investigation or proceeding against us; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0000804328-24-000017:mdna:269]
Geopolitical conflicts, natural disasters, pandemics and other health crises, and other factors outside of our control, could significantly disrupt our business.

[0000804328-24-000017:mdna:270]
We have operations and facilities in the United States and many other countries throughout the world. We derive a significant portion of our revenues from Chinese OEMs and from non-Chinese OEMs that utilize our integrated circuit products in devices they sell into China (which has the largest number of smartphone users in the world); our key suppliers and their manufacturing foundries and assembly, test and other facilities are primarily located in Taiwan and Korea; our manufacturing facilities for RFFE and RF products are located in China, Germany and Singapore; the primary warehouses where we store finished goods for fulfillment of customer orders are located in Singapore; and a significant portion of our workforce (including engineering and other technical personnel) is based in India. Acts of war, terrorism, geopolitical conflicts, political instability or tensions such as the current geopolitical tensions involving China and Taiwan, natural disasters, the effects of climate change, pandemics such as the COVID-19 pandemic, or other health crises affecting any of the regions in which we operate, and particularly those in which our customers, suppliers, manufacturing facilities and/or significant portions of our workforce are concentrated, could significantly disrupt our business by, among others: reducing demand for our products and services or end-user devices incorporating our products or intellectual property; impairing our customers’ or licensees’ ability to purchase or pay for our products, services or intellectual property; delaying or preventing our suppliers from providing us with critical components or raw materials; delaying or preventing our foundry or semiconductor assembly and test providers from manufacturing, assembling or testing our products; preventing us from

[0000804328-24-000017:mdna:271]
manufacturing products or shipping finished products; damaging or destroying inventory; delaying or preventing network operators from upgrading their wireless networks to meet new technology standards; or preventing a significant number of our employees, or employees who perform critical functions, from performing their duties for us. For example, our business depends on our ability to receive consistent and reliable chipset supply from our foundry partners, particularly in Taiwan. Consequently, a significant or prolonged military or other geopolitical conflict involving China and Taiwan could severely limit or prevent us from receiving chipset supply from Taiwan, which would have a material adverse impact on our business (and likely on the semiconductor industry as a whole). In addition, acts of war, terrorism, geopolitical conflicts, political instability or tensions, natural disasters, the effects of climate change, pandemics or other health crises impacting any of these regions could also result in a decline in global, regional or local economic conditions generally, or increased volatility in financial markets, which could have adverse effects on our business and financial results. See also the Risk Factor titled “We operate in the highly cyclical semiconductor industry, which is subject to significant downturns. We are also susceptible to declines in global, regional and local economic conditions generally. Our stock price and financial results are subject to substantial quarterly and annual fluctuations due to these dynamics, among others.” Any such events may also have the effect of exacerbating the other risks discussed in this “Risk Factors” section.

[0000804328-24-000017:mdna:272]
[same as prior period, unchanged from 0000804328-23-000043:mdna:309]

[0000804328-24-000017:mdna:273]
Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). These include, among others, Regulations related to: patent licensing practices; antitrust, competition and competitive business practices; the flow of funds out of certain countries (e.g., China); cybersecurity; privacy and data protection; imports and exports, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; protection of intellectual property; trade and trade protection including tariffs; foreign policy and national security; environmental protection (including climate change), health and safety; supply chain, responsible sourcing, including the use of conflict minerals, and human rights; spectrum availability and license issuance; adoption of standards; taxation; labor, employment and human capital; corporate governance; public disclosure and reporting (including reporting of ESG-related data); automotive industry safety and quality standards; AI technologies; and business conduct. Compliance with, or changes in the interpretation of, existing Regulations, the adoption of new Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, among others, could have an adverse effect on our business and results of operations. See also the Risk Factors titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises, geopolitical conflicts and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

[0000804328-24-000017:mdna:274]
[same as prior period, unchanged from 0000804328-23-000043:mdna:313]

[0000804328-24-000017:mdna:275]
[same as prior period, unchanged from 0000804328-23-000043:mdna:314]

[0000804328-24-000017:mdna:276]
Our outstanding debt and any additional debt we incur may have negative consequences on our business, including, among others: requiring us to use cash to pay the principal of and interest on our debt, thereby reducing the amount of cash available for other purposes; limiting our ability to obtain additional financing for working capital, capital expenditures, acquisitions, stock repurchases, dividends, general corporate or other purposes; and limiting our flexibility in planning for, or reacting to, changes in our business, industries or the market. Our ability to make payments of principal and interest on our debt depends upon our future performance, which is subject to economic and political conditions, industry cycles and financial, business and other factors, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations to service our debt, we may be required to, among others: refinance or restructure all or a portion of our debt;

[0000804328-24-000017:mdna:277]
45

[0000804328-24-000017:mdna:278]
reduce or delay planned capital or operating expenditures; reduce, suspend or eliminate our dividend payments and/or our stock repurchase program; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing or restructuring are higher than our current rates, interest expense related to such refinancing or restructuring would increase. Further, if there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt financing in the future and the terms of such debt could be adversely affected.

[0000804328-24-000017:mdna:279]
[same as prior period, unchanged from 0000804328-23-000043:mdna:316]

[0000804328-24-000017:mdna:280]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed, as well as countries where we own intellectual property. The final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0000804328-24-000017:mdna:281]
Tax rules may change in a manner that adversely affects our future reported results of operations or the way we conduct our business. Most of our income is taxable in the United States with a significant portion qualifying for preferential treatment as FDII (foreign-derived intangible income). Beginning in fiscal 2027, the effective tax rate for FDII increases from 13% to 16%. Further, if U.S. tax rates increase and/or the FDII deduction is eliminated or reduced, both of which have been proposed by the current U.S. presidential administration, our provision for income taxes, results of operations and cash flows would be adversely (potentially materially) affected. Also, if our customers move manufacturing operations to the United States, our FDII deduction may be reduced. Further, if the requirement to capitalize certain research and development expenditures for federal income tax purposes is changed, as has been proposed by Congress, this would negatively affect our provision for income taxes and results of operations (although it would have a favorable impact on our cash flows from operations due to lower cash tax payments).

[0000804328-24-000017:mdna:282]
Further changes in the tax laws of foreign jurisdictions could arise as a result of the base erosion and profit shifting (BEPS) project that was undertaken by the Organization for Economic Co-operation and Development (OECD). The OECD, which represents a coalition of member countries, has made certain changes and is recommending additional changes to numerous long-standing tax principles. These changes, if and as adopted by countries, may increase tax uncertainty and may adversely affect our provision for income taxes, results of operations and cash flows.
