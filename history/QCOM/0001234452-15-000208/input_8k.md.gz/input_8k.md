# QCOM 8-K — 0001234452-15-000206 filed 2015-07-22

## item codes, every 8-K on or before 2015-07-22

- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2015-07-22

- none on or before 2015-07-22

## item 2.02 — earnings release, exhibit 99.1

[0001234452-15-000206:8k_2_02:1]
EX-99.1
2
qcom62815erex991.htm
EXHIBIT 99.1

[0001234452-15-000206:8k_2_02:2]
QCOM 6.28.15 ER EX 99.1

[0001234452-15-000206:8k_2_02:3]
Exhibit 99.1

[0001234452-15-000206:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-15-000206:8k_2_02:5]
Qualcomm Contact:

[0001234452-15-000206:8k_2_02:6]
Warren Kneeshaw

[0001234452-15-000206:8k_2_02:7]
Vice President, Investor Relations

[0001234452-15-000206:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-15-000206:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-15-000206:8k_2_02:10]
Qualcomm Announces Third Quarter Fiscal 2015 Results

[0001234452-15-000206:8k_2_02:11]
Revenues $5.8 billion

[0001234452-15-000206:8k_2_02:12]
GAAP EPS $0.73, Non-GAAP EPS $0.99

[0001234452-15-000206:8k_2_02:13]
- Record $6.2 billion of Capital Returned to Stockholders -

[0001234452-15-000206:8k_2_02:14]
- Announces Strategic Realignment Plan -

[0001234452-15-000206:8k_2_02:15]
SAN DIEGO - July 22, 2015 - Qualcomm Incorporated (Nasdaq:  QCOM), a leading developer and innovator of advanced wireless technologies, products and services, today announced results for the third quarter of fiscal 2015 ended June 28, 2015.

[0001234452-15-000206:8k_2_02:16]
“Our fiscal third quarter revenues, MSM chip shipments and EPS were within prior expectations, and we took a significant step towards our increased capital return commitments through the initiation of a $5 billion accelerated share repurchase as part of our plan to repurchase an additional $10 billion in stock by March 2016,” said Steve Mollenkopf, CEO of Qualcomm Incorporated. “During the quarter, we also launched a comprehensive review of our cost structure and announced today a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth.  Importantly, the changes we are announcing today are designed to enable us to right-size our cost structure and reposition Qualcomm for improved financial and operating performance.  We will continue to invest to build upon our technology leadership position and capitalize on the significant long-term opportunities before us in order to create sustainable long-term value for stockholders.”

[0001234452-15-000206:8k_2_02:17]
Additional details on the Strategic Realignment Plan were released today by Qualcomm in a separate news release.

[0001234452-15-000206:8k_2_02:18]
Third Quarter Results (GAAP)*

[0001234452-15-000206:8k_2_02:19]
|  | Q3 Fiscal 2015 |  | Q3 Fiscal 2014 |  | Year-Over-Year Change |  | Q2 Fiscal 2015 |  | Sequential Change |
| Revenues 1 | $5.8B |  | $6.8B |  | (14%) |  | $6.9B |  | (15%) |
| Operating income 1 | $1.2B |  | $2.1B |  | (40%) |  | $1.3B |  | (8%) |
| Net income 2 | $1.2B |  | $2.2B |  | (47%) |  | $1.1B |  | +12% |
| Diluted earnings per share 2 | $0.73 |  | $1.31 |  | (44%) |  | $0.63 |  | +16% |
| Operating cash flow | $2.1B |  | $2.7B |  | (21%) |  | ($0.7B) |  | N/M |

[0001234452-15-000206:8k_2_02:20]
1 Throughout this news release, revenues, operating expenses, operating income, earnings before tax (EBT) and effective tax rates are from continuing operations (i.e., before adjustments for noncontrolling interests and discontinued operations), unless otherwise stated.

[0001234452-15-000206:8k_2_02:21]
2 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests and discontinued operations), unless otherwise stated.

[0001234452-15-000206:8k_2_02:22]
Non-GAAP Third Quarter Results*

[0001234452-15-000206:8k_2_02:23]
|  | Q3 Fiscal 2015 |  | Q3 Fiscal 2014 |  | Year-Over-Year Change |  | Q2 Fiscal 2015 |  | Sequential Change |
| Revenues | $5.8B |  | $6.8B |  | (14%) |  | $6.9B |  | (15%) |
| Operating income | $1.7B |  | $2.4B |  | (30%) |  | $2.7B |  | (37%) |
| Net income | $1.6B |  | $2.5B |  | (35%) |  | $2.3B |  | (31%) |
| Diluted earnings per share | $0.99 |  | $1.44 |  | (31%) |  | $1.40 |  | (29%) |

[0001234452-15-000206:8k_2_02:24]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Beginning in the first quarter of fiscal 2015, we changed our methodology for reporting Non-GAAP results to exclude third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages.  Detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-15-000206:8k_2_02:25]
* The following should be considered in regards to the year-over-year and sequential comparisons:

[0001234452-15-000206:8k_2_02:26]
| • | The third quarter of fiscal 2015 GAAP results included: |

[0001234452-15-000206:8k_2_02:27]
| ◦ | $142 million of charges, or $0.08 per share, that resulted from an impairment of goodwill and long-lived assets related to one of our display businesses. |

[0001234452-15-000206:8k_2_02:28]
| • | The second quarter of fiscal 2015 GAAP results included: |

[0001234452-15-000206:8k_2_02:29]
| ◦ | $975 million charge, or $0.58 per share, related to the resolution reached with the China National Development and Reform Commission (NDRC) regarding its investigation of us under China’s Anti-Monopoly Law; and |

[0001234452-15-000206:8k_2_02:30]
| ◦ | Operating cash flow also was impacted by the prepayment of $950 million to secure long-term capacity commitments at a supplier of our integrated circuit products. |

[0001234452-15-000206:8k_2_02:31]
| • | The third quarter of fiscal 2014 Non-GAAP and GAAP results included: |

[0001234452-15-000206:8k_2_02:32]
| ◦ | $208 million of income, or $0.12 per share, of which $184 million was recorded in other income, due to the reversal of accruals related to our litigation with ParkerVision; and |

[0001234452-15-000206:8k_2_02:33]
| ◦ | $164 million of charges, or $0.08 per share, that resulted from an impairment of goodwill and long-lived assets related to one of our display businesses. |

[0001234452-15-000206:8k_2_02:34]
Third Quarter Key Business Metrics

[0001234452-15-000206:8k_2_02:35]
|  | Q3 Fiscal 2015 |  | Q3 Fiscal 2014 |  | Year-Over-Year Change (1) |  | Q2 Fiscal 2015 |  | Sequential Change (1) |
| MSMTM chip shipments | 225M |  | 225M |  | —% |  | 233M |  | (3%) |
| Total reported device sales (2) | $60.4B |  | $58.1B |  | +4% |  | $75.8B |  | (20%) |
| Est. reported 3G/4G device shipments (approx.) (2) | 289M - 293M |  | 250M - 254M |  | +15% |  | 384M - 388M |  | (25%) |
| Est. reported 3G/4G average selling price (approx.) (2) | $205 - $211 |  | $228 - $234 |  | (10%) |  | $193 - $199 |  | +6% |

[0001234452-15-000206:8k_2_02:36]
| (1) | The midpoints of the estimated ranges are used for comparison purposes only and do not indicate a higher degree of confidence in the midpoints. |

[0001234452-15-000206:8k_2_02:37]
| (2) | The third quarter of fiscal 2014 and 2015 are based on sales by our licensees in the March quarter as reported to us in the June quarter, and the second quarter of fiscal 2015 is based on sales by our licensees in the December quarter as reported to us in the March quarter. |

[0001234452-15-000206:8k_2_02:38]
Cash and Marketable Securities

[0001234452-15-000206:8k_2_02:39]
Our cash, cash equivalents and marketable securities totaled $35.2 billion at the end of the third quarter of fiscal 2015, compared to $32.7 billion a year ago and $29.6 billion at the end of the second quarter of fiscal 2015.  In May 2015, we issued an aggregate principal amount of $10.0 billion of unsecured floating- and fixed-rate notes.

[0001234452-15-000206:8k_2_02:40]
Return of Capital to Stockholders

[0001234452-15-000206:8k_2_02:41]
During the third quarter of fiscal 2015, we returned $6.2 billion to stockholders, including $5.4 billion through repurchases of 63.7 million shares of common stock (which includes the 57.7 million shares initially delivered under the $5 billion accelerated share repurchase agreements (ASR Agreements)) and $757 million, or $0.48 per share, of cash dividends paid.  The final number and the average purchase price of the shares to be delivered under the ASR Agreements will be determined upon settlement of the transactions, which is expected to occur in or before November 2015.  Since June 28, 2015, we repurchased and retired 8.0 million shares of common stock for $510 million.  On July 7, 2015, we announced a cash dividend of $0.48 per share payable on September 23, 2015 to stockholders of record as of the close of business on September 2, 2015.

[0001234452-15-000206:8k_2_02:42]
Effective Income Tax Rates

[0001234452-15-000206:8k_2_02:43]
Our fiscal 2015 annual effective income tax rates are estimated to be approximately 19 percent for GAAP and approximately 18 percent for Non-GAAP, both of which include the United States federal research and development (R&D) tax credit generated through December 31, 2014, the date on which the credit expired.  The effective income tax rates for the third quarter of fiscal 2015 were 15 percent for both GAAP and Non-GAAP.  Our estimated annual tax rates for fiscal 2015 GAAP and Non-GAAP decreased from our prior estimates of 21 percent and 19 percent, respectively, primarily resulting from an increase in the allocation of expenses to our United States operations.

[0001234452-15-000206:8k_2_02:44]
Business Outlook

[0001234452-15-000206:8k_2_02:45]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment and certain derivative gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.  Our outlook includes an estimate of the benefit related to stock repurchases that we plan to complete.

[0001234452-15-000206:8k_2_02:46]
We have not included any estimates related to the proposed acquisition of CSR plc in our fiscal 2015 outlook.  The acquisition is expected to close by the end of the summer of 2015.  We expect the acquisition to be accretive to Non-GAAP earnings per share in fiscal 2016, the first full year of combined operations.

[0001234452-15-000206:8k_2_02:47]
Strategic Realignment Plan

[0001234452-15-000206:8k_2_02:48]
Today, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders.  As part of this, among other actions, we are implementing a cost reduction plan to reduce our annual costs from fiscal 2015 levels of $7.3 billion (adjusted for variable compensation) by

[0001234452-15-000206:8k_2_02:49]
approximately $1.1 billion through a series of targeted reductions that will not jeopardize our growth objectives or core technology roadmap.  We also plan to reduce annual share-based compensation grants by approximately $300 million.  We expect these cost initiatives to be fully implemented by the end of fiscal 2016.  In connection with this plan, we expect to incur approximately $350 million to $450 million in restructuring and restructuring-related charges, of which approximately $100 million to $200 million is included in our fourth quarter fiscal 2015 GAAP EPS guidance. Refer to the full text of that release on our investor relations website at: http://investor.qualcomm.com/results.cfm

[0001234452-15-000206:8k_2_02:50]
QCT Outlook

[0001234452-15-000206:8k_2_02:51]
We have reduced our outlook for our semiconductor business, QCT, in the fiscal fourth quarter compared to our prior expectations driven primarily by factors impacting premium-tier demand, including:

[0001234452-15-000206:8k_2_02:52]
| • | Increased concentration within the premium tier causing reduced demand for certain OEM devices that include our chipset; |

[0001234452-15-000206:8k_2_02:53]
| • | Lower demand for our premium-tier chipsets from a vertical customer; and |

[0001234452-15-000206:8k_2_02:54]
| • | Lower sell through in China of certain handset models using our premium-tier chipsets. |

[0001234452-15-000206:8k_2_02:55]
QTL Outlook

[0001234452-15-000206:8k_2_02:56]
In the second quarter of fiscal 2015, we reached a resolution with the NDRC regarding its investigation and agreed to implement a rectification plan that modifies certain of our business practices in China.  However, we continue to believe that certain licensees in China are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes 3G/4G units that we believe are not being reported by certain licensees).  We continue to make progress, with licensees executing agreements based on the new China terms, and with several other licensees informing us that they intend to retain the terms of their existing agreements.  Negotiations with certain other licensees are ongoing, and we expect it will take some time to conclude these negotiations.  We believe that the conclusion of new agreements with these licensees will result in improved reporting by these licensees, including with respect to sales of three-mode devices (i.e., devices that implement GSM, TD-SCDMA, and LTE) sold in China.  Our current outlook for our licensing business, QTL, also reflects the following:

[0001234452-15-000206:8k_2_02:57]
| • | We expect global 3G/4G device shipments to be approximately 1.52 billion to 1.6 billion for calendar year 2015. At this time, we are not providing a forecast for calendar year 2015 reported 3G/4G device shipments. |

[0001234452-15-000206:8k_2_02:58]
| • | Our guidance for estimated fiscal fourth quarter and fiscal 2015 3G/4G total reported device sales includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-15-000206:8k_2_02:59]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-15-000206:8k_2_02:60]
Qualcomm’s Business Outlook Summary

[0001234452-15-000206:8k_2_02:61]
| FOURTH FISCAL QUARTER |
|  |  | Q4 FY14 Results | Current Guidance Q4 FY15 Estimates (1) |
|  | Revenues |  | $6.7 | B | $4.7B - $5.7B |  |
|  | Year-over-year change |  | decrease 15% - 30% |  |
|  | Non-GAAP diluted earnings per share (EPS) |  | $1.26 |  | $0.75 - $0.95 |  |
|  | Year-over-year change |  | decrease 25% - 40% |  |
|  | Diluted EPS attributable to QSI |  | $0.02 |  |  | ($0.01 | ) |
|  | Diluted EPS attributable to share-based compensation |  | ($0.12 | ) |  | ($0.13 | ) |
|  | Diluted EPS attributable to other items |  | ($0.05 | ) | ($0.05) - ($0.10) |  |
|  | GAAP diluted EPS |  | $1.11 |  | $0.51 - $0.76 |  |
|  | Year-over-year change |  | decrease 32% - 54% |  |
|  | Metrics |  |  |
|  | MSM chip shipments | 236 | M | 170M - 190M |  |
|  | Year-over-year change |  | decrease 19% - 28% |  |
|  | Total reported device sales* (2) | approx. $57.4B | approx. $60.5B - $66.5B (3) |  |
|  | Year-over-year change |  | increase 5% - 16% |  |
|  | *Est. sales in June quarter, reported in September quarter |  |  |

[0001234452-15-000206:8k_2_02:62]
| FISCAL YEAR |
|  |  | FY 2014 Results | Prior Guidance FY 2015 Estimates | Current Guidance FY 2015 Estimates (1) |
|  | Revenues |  | $26.5 | B | $25.0B - $27.0B |  | $24.5B - $25.5B |  |
|  | Year-over-year change |  | decrease 6% - increase 2% |  | decrease 4% - 8% |  |
|  | Non-GAAP diluted EPS |  | $5.27 |  | $4.60 - $5.00 |  | $4.50 - $4.70 |  |
|  | Year-over-year change |  | decrease 5% - 13% |  | decrease 11% - 15% |  |
|  | Diluted EPS attributable to QSI |  | $0.01 |  |  | ($0.04 | ) |  | ($0.04 | ) |
|  | Diluted EPS attributable to share-based compensation |  | ($0.50 | ) |  | ($0.54 | ) |  | ($0.52 | ) |
|  | Diluted EPS attributable to other items |  | ($0.13 | ) |  | ($0.74 | ) | ($0.84) - ($0.89) |  |
|  | GAAP diluted EPS |  | $4.65 |  | $3.28 - $3.68 |  | $3.05 - $3.30 |  |
|  | Year-over-year change |  | decrease 21% - 29% |  | decrease 29% - 34% |  |
|  | Metrics |  |  |  |
|  | Total reported device sales* (2) | approx. $243.6B | approx. $255.0B - $275.0B (3) |  | approx. $253.0B - $259.0B (3) |  |
|  | Year-over-year change |  | increase 5% - 13% |  | increase 4% - 6% |  |
|  | *Est. sales in Sept. to June quarters, reported in Dec. to Sept. quarters |  |  |  |

[0001234452-15-000206:8k_2_02:63]
| (1) | Our guidance range for GAAP for the fourth quarter of fiscal 2015 includes an estimate of restructuring and restructuring-related charges of $100 million to $200 million; these charges are excluded from our Non-GAAP guidance. |

[0001234452-15-000206:8k_2_02:64]
| (2) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). The reported quarterly estimated ranges of average selling prices (ASPs) and unit shipments are determined based on the information as reported to us by our licensees during the relevant period and our own estimates of the selling prices and unit shipments for licensees that do not provide such information. Not all licensees report sales, selling prices and/or unit shipments the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales, estimated unit shipments and estimated ASPs for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-15-000206:8k_2_02:65]
| (3) | Our guidance range for the fourth quarter of fiscal 2015 and fiscal 2015 total reported device sales reflects estimated 3G/4G total reported device sales that we currently expect to be reported to us, which includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-15-000206:8k_2_02:66]
Sums may not equal totals due to rounding.

[0001234452-15-000206:8k_2_02:67]
Results of Business Segments

[0001234452-15-000206:8k_2_02:68]
The following table reconciles our Non-GAAP results to our GAAP results ($ in millions, except per share data):

[0001234452-15-000206:8k_2_02:69]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (a) | Non-GAAP | QSI | Share-Based Compensation | Other Items (b) (c) (d) |  | GAAP |
| Q3 - FISCAL 2015 |  |  |  |  |  |
| Revenues | $3,853 | $1,931 | $48 | $5,832 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $5,832 |  |
| Change from prior year | (22 | %) | 7 | % | 4 | % | (14 | %) |  |  |  |  |  |  | (14 | %) |  |
| Change from prior quarter | (13 | %) | (20 | %) | 4 | % | (15 | %) |  |  |  |  |  |  | (15 | %) |  |
| Cost of equipment and services revenues |  |  |  | $2,386 |  |  | $— |  |  | $10 | $55 |  | $2,451 |  |
| Research and development |  |  |  | 1,226 |  | 2 |  | 176 | 3 |  | 1,407 |  |
| Selling, general and administrative |  |  |  | 491 |  | 19 |  | 85 | (18) |  | 577 |  |
| Other expenses |  |  |  | 20 |  | — |  |  | — |  | 142 |  | 162 |  |
| Operating income (loss) |  |  |  | $1,709 |  | ($21) |  | ($271) | ($182) |  | $1,235 |  |
| Change from prior year |  |  |  | (30 | %) |  | N/M |  |  | 1 | % | N/M |  |  | (40 | %) |  |
| Change from prior quarter |  |  |  | (37 | %) |  | N/M |  |  | (9 | %) | 84 | % |  | (8 | %) |  |
| Investment income, net |  |  |  | $191 | (e) | ($28) | (f) |  | $— |  |  | $— |  |  | $163 |  |
| EBT | $289 | $1,654 | ($43) | $1,900 |  | ($49) |  | ($271) | ($182) |  | $1,398 |  |
| Change from prior year | (74 | %) | 7 | % | N/M |  | (33 | %) |  | N/M |  |  | 1 | % | N/M |  |  | (44 | %) |  |
| Change from prior quarter | (61 | %) | (23 | %) | N/M |  | (35 | %) |  | (53 | %) |  | (9 | %) | 84 | % |  | (9 | %) |  |
| EBT as % of revenues | 8 | % | 86 | % | N/M |  | 33 | % |  |  |  |  |  |  | 24 | % |  |
| Net income (loss) |  |  |  | $1,611 |  | ($26) |  | ($213) | ($188) |  | $1,184 |  |
| Change from prior year |  |  |  | (35 | %) |  | N/M |  |  | 8 | % | N/M |  |  | (47 | %) |  |
| Change from prior quarter |  |  |  | (31 | %) |  | 4 | % |  | (3 | %) | 82 | % |  | 12 | % |  |
| Diluted EPS |  |  |  | $0.99 |  | ($0.02) |  | ($0.13) | ($0.12) |  | $0.73 |  |
| Change from prior year |  |  |  | (31 | %) |  | N/M |  |  | 7 | % | N/M |  |  | (44 | %) |  |
| Change from prior quarter |  |  |  | (29 | %) |  | — | % |  | (8 | %) | 81 | % |  | 16 | % |  |
| Diluted shares used |  |  |  | 1,629 |  | 1,629 |  | 1,629 | 1,629 |  | 1,629 |  |
| Q2 - FISCAL 2015 |  |  |  |  |  |
| Revenues | $4,434 | $2,414 | $46 | $6,894 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $6,894 |  |
| Operating income (loss) |  |  |  | 2,707 |  | (4) |  | (249) | (1,118) |  | 1,336 |  |
| EBT | $750 | $2,162 | $26 | 2,938 |  | (32) |  | (249) | (1,118) |  | 1,539 |  |
| Net income (loss) |  |  |  | 2,339 |  | (27 | ) |  | (206) | (1,053) |  | 1,053 |  |
| Diluted EPS |  |  |  | $1.40 |  | ($0.02) |  | ($0.12) | ($0.63) |  | $0.63 |  |
| Diluted shares used |  |  |  | 1,667 |  | 1,667 |  | 1,667 | 1,667 |  | 1,667 |  |
| Q3 - FISCAL 2014 |  |  |  |  |  |
| Revenues | $4,957 | $1,803 | $46 | $6,806 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $6,806 |  |
| Operating income (loss) |  |  |  | 2,425 |  | (5) |  | (274) | (71) |  | 2,075 |  |
| EBT | $1,116 | $1,550 | $177 | 2,843 |  | (1) |  | (274) | (71) |  | 2,497 |  |
| Net income (loss) |  |  |  | 2,470 |  | — |  |  | (232) | — |  |  | 2,238 |  |
| Diluted EPS |  |  |  | $1.44 |  | $0.00 |  | ($0.14) | $0.00 |  | $1.31 |  |
| Diluted shares used |  |  |  | 1,714 |  | 1,714 |  | 1,714 | 1,714 |  | 1,714 |  |
| Q4 - FISCAL 2014 |  |  |  |  |  |
| Revenues | $4,849 | $1,795 | $48 | $6,692 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $6,692 |  |
| Operating income (loss) |  |  |  | 2,323 |  | (3) |  | (252) | (76) |  | 1,992 |  |
| EBT | $1,045 | $1,536 | ($30) | 2,551 |  | 29 |  | (252) | (76) |  | 2,252 |  |
| Net income (loss) |  |  |  | 2,143 |  | 28 |  | (199) | (78) |  | 1,894 |  |
| Diluted EPS |  |  |  | $1.26 |  | $0.02 |  | ($0.12) | ($0.05) |  | $1.11 |  |
| Diluted shares used |  |  |  | 1,701 |  | 1,701 |  | 1,701 | 1,701 |  | 1,701 |  |

[0001234452-15-000206:8k_2_02:70]
| (a) | Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations. Non-GAAP reconciling items related to earnings before taxes consisted primarily of certain research and development expenses, selling, general and administrative expenses, other expenses or income and certain investment income that are not allocated to the segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit. |

[0001234452-15-000206:8k_2_02:71]
| (b) | Beginning in the first quarter of fiscal 2015, we changed our methodology for reporting Non-GAAP results to exclude third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. In the third quarter of fiscal 2015, other items excluded from Non-GAAP EBT included impairment charges of $131 million and $11 million related to goodwill and intangible assets, respectively, $78 million of acquisition-related items and $6 million of severance costs related to restructurings, partially offset by a $44 million gain on the sale of certain assets. |

[0001234452-15-000206:8k_2_02:72]
| (c) | In the third quarter of fiscal 2015, the tax expense in the “Other Items” column included a $4 million tax expense to reconcile the tax provision for each column to the total GAAP tax provision for the quarter, a $1 million tax expense for the tax effect of other items in EBT and a $1 million tax expense for the tax effect of acquisition-related items. At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. In interim quarters of prior fiscal years, this difference was allocated to the tax provisions (benefits) among the columns. See the “Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates” herein. |

[0001234452-15-000206:8k_2_02:73]
| (d) | Details of amounts included in the “Other Items” column for prior periods are included in the releases for those periods. |

[0001234452-15-000206:8k_2_02:74]
| (e) | Included $127 million in interest and dividend income, $109 million in net realized gains on investments and $1 million in other net investment income, partially offset by $32 million in interest expense and $14 million in other-than-temporary losses on investments. |

[0001234452-15-000206:8k_2_02:75]
| (f) | Included $41 million in other-than-temporary losses on investments, partially offset by $13 million in other net investment income. |

[0001234452-15-000206:8k_2_02:76]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (a) | Non-GAAP | QSI | Share-Based Compensation | Other Items (d) (g) (h) |  | GAAP |
| 9 MONTHS - FISCAL 2015 |  |  |  |  |  |
| Revenues | $13,529 | $6,162 | $134 | $19,825 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $19,825 |  |
| Change from prior year | (2 | %) | 7 | % | (35 | %) | — | % |  |  |  |  |  |  | — | % |  |
| Cost of equipment and services revenues |  |  |  | $7,909 |  |  | $— |  |  | $33 | $184 |  | $8,126 |  |
| Research and development |  |  |  | 3,582 |  | 5 |  | 508 | 38 |  | 4,133 |  |
| Selling, general and administrative |  |  |  | 1,366 |  | 27 |  | 252 | 44 |  | 1,689 |  |
| Other expenses |  |  |  | 20 |  | — |  |  | — |  | 1,221 |  | 1,241 |  |
| Operating income (loss) |  |  |  | $6,948 |  | ($32) |  | ($793) | ($1,487) |  | $4,636 |  |
| Change from prior year |  |  |  | 5 | % |  | (100 | %) |  | 2 | % | N/M |  |  | (17 | %) |  |
| Investment income, net |  |  |  | $650 | (i) | ($50) | (j) |  | $— |  |  | $— |  |  | $600 |  |
| EBT | $2,185 | $5,395 | $18 | $7,598 |  | ($82) |  | ($793) | ($1,487) |  | $5,236 |  |
| Change from prior year | (21 | %) | 7 | % | N/M |  | — | % |  | N/M |  |  | 2 | % | N/M |  |  | (20 | %) |  |
| EBT as % of revenues | 16 | % | 88 | % | N/M |  | 38 | % |  |  |  |  |  |  | 26 | % |  |
| Net income (loss) |  |  |  | $6,213 |  | ($53) |  | ($648) | ($1,303) |  | $4,209 |  |
| Change from prior year |  |  |  | (10 | %) |  | N/M |  |  | 1 | % | N/M |  |  | (31 | %) |  |
| Diluted EPS |  |  |  | $3.74 |  | ($0.03) |  | ($0.39) | ($0.78) |  | $2.53 |  |
| Change from prior year |  |  |  | (7 | %) |  | N/M |  |  | (3 | %) | N/M |  |  | (28 | %) |  |
| Diluted shares used |  |  |  | 1,661 |  | 1,661 |  | 1,661 | 1,661 |  | 1,661 |  |
| 9 MONTHS - FISCAL 2014 |  |  |  |  |  |
| Revenues | $13,816 | $5,774 | $205 | $19,795 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $19,795 |  |
| Operating income (loss) |  |  |  | 6,611 |  | (16) |  | (806) | (231) |  | 5,558 |  |
| EBT | $2,762 | $5,054 | ($217) | 7,599 |  | (36) |  | (806) | (231) |  | 6,526 |  |
| Discontinued operations, net of tax |  |  |  | 430 |  | — |  |  | — |  | — |  |  | 430 |  |
| Net income (loss) |  |  |  | 6,888 |  | (13) |  | (655) | (147) |  | 6,073 |  |
| Diluted EPS |  |  |  | $4.01 |  | ($0.01) |  | ($0.38) | ($0.08) |  | $3.53 |  |
| Diluted shares used |  |  |  | 1,718 |  | 1,718 |  | 1,718 | 1,718 |  | 1,718 |  |
| 12 MONTHS - FISCAL 2014 |  |  |  |  |  |
| Revenues | $18,665 | $7,569 | $253 | $26,487 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $26,487 |  |
| Operating income (loss) |  |  |  | 8,933 |  | (18) |  | (1,059) | (306) |  | 7,550 |  |
| EBT | $3,807 | $6,590 | ($247) | 10,150 |  | (7) |  | (1,059) | (306) |  | 8,778 |  |
| Discontinued operations, net of tax |  |  |  | 430 |  | — |  |  | — |  | — |  |  | 430 |  |
| Net income (loss) |  |  |  | 9,032 |  | 15 |  | (856) | (224) |  | 7,967 |  |
| Diluted EPS |  |  |  | $5.27 |  | $0.01 |  | ($0.50) | ($0.13) |  | $4.65 |  |
| Diluted shares used |  |  |  | 1,714 |  | 1,714 |  | 1,714 | 1,714 |  | 1,714 |  |

[0001234452-15-000206:8k_2_02:77]
| (g) | In the nine months ended June 28, 2015, other items excluded from Non-GAAP EBT included $975 million related to the resolution reached with the NDRC, $240 million of acquisition-related items, $235 million related to goodwill impairment charges, $43 million of severance costs related to restructurings and $38 million in impairment charges related to intangible assets, partially offset by a $44 million gain on the sale of certain assets. |

[0001234452-15-000206:8k_2_02:78]
| (h) | In the nine months ended June 28, 2015, the tax benefit in the “Other Items” column included a $101 million tax benefit related to fiscal 2014 as a result of the retroactive reinstatement of the federal R&D tax credit, a $61 million tax benefit as a result of an agreement reached with the Internal Revenue Service related to Atheros’ pre-acquisition tax returns, a $25 million tax benefit for the tax effect of other items in EBT and a $3 million tax benefit related to fiscal 2014 as a result of the retroactive reinstatement of other tax laws, partially offset by a $6 million tax expense to reconcile the tax provisions for each column to the total GAAP tax provision for the nine months ended June 28, 2015. See the “Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates” herein. |

[0001234452-15-000206:8k_2_02:79]
| (i) | Included $397 million in interest and dividend income, $371 million in net realized gains on investments and $6 million in other net investment income, partially offset by $90 million in other-than-temporary losses on investments and $34 million in interest expense. |

[0001234452-15-000206:8k_2_02:80]
| (j) | Included $71 million in other-than-temporary losses on investments and $18 million in equity in losses of investees, partially offset by $28 million in net realized gains on investments and $11 million in other net investment income. |

[0001234452-15-000206:8k_2_02:81]
N/M - Not Meaningful

[0001234452-15-000206:8k_2_02:82]
Sums may not equal totals due to rounding.

[0001234452-15-000206:8k_2_02:83]
Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates

[0001234452-15-000206:8k_2_02:84]
(Unaudited)

[0001234452-15-000206:8k_2_02:85]
| Three Months Ended June 28, 2015 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Other Items |  |  | GAAP Results |  |
| Income (loss) from continuing operations before income taxes |  | $ | 1,900 |  |  |  | $ | (49 | ) |  |  | $ | (271 | ) |  |  | $ | (182 | ) |  |  | $ | 1,398 |  |  |
| Income tax (expense) benefit |  | (289 | ) |  |  | 22 |  |  |  | 58 |  |  |  | (6 | ) |  |  | (215 | ) |  |
| Income (loss) from continuing operations |  | $ | 1,611 |  |  |  | $ | (27 | ) |  |  | $ | (213 | ) |  |  | $ | (188 | ) |  |  | $ | 1,183 |  |  |
| Tax rate |  | 15 | % |  |  | 45 | % |  |  | 21 | % |  |  | (3 | %) |  |  | 15 | % |  |

[0001234452-15-000206:8k_2_02:86]
| Nine Months Ended June 28, 2015 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Other Items |  |  | GAAP Results |  |
| Income (loss) from continuing operations before income taxes |  | $ | 7,598 |  |  |  | $ | (82 | ) |  |  | $ | (793 | ) |  |  | $ | (1,487 | ) |  |  | $ | 5,236 |  |  |
| Income tax (expense) benefit |  | (1,385 | ) |  |  | 27 |  |  |  | 145 |  |  |  | 184 |  |  |  | (1,029 | ) |  |
| Income (loss) from continuing operations |  | $ | 6,213 |  |  |  | $ | (55 | ) |  |  | $ | (648 | ) |  |  | $ | (1,303 | ) |  |  | $ | 4,207 |  |  |
| Tax rate |  | 18 | % |  |  | 33 | % |  |  | 18 | % |  |  | 12 | % |  |  | 20 | % |  |

[0001234452-15-000206:8k_2_02:87]
Conference Call

[0001234452-15-000206:8k_2_02:88]
Qualcomm’s fiscal third quarter 2015 earnings conference call will be broadcast live on July 22, 2015, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 78002754.

[0001234452-15-000206:8k_2_02:89]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-15-000206:8k_2_02:90]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for, or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-15-000206:8k_2_02:91]
The Company uses Non-GAAP financial information (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against each other and against competitors.  Non-GAAP measurements used by the Company include revenues, cost of equipment and services revenues, R&D expenses, SG&A expenses, other expenses, operating income, net investment income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  As a result, management compensation decisions and the review of executive compensation by the Compensation Committee of the Board of Directors focus primarily on Non-GAAP financial measures applicable to the Company and its business segments.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.

[0001234452-15-000206:8k_2_02:92]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items, tax items and other items.

[0001234452-15-000206:8k_2_02:93]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-15-000206:8k_2_02:94]
| • | Share-based compensation expense primarily relates to restricted stock units. Non-cash share-based compensation is excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses. |

[0001234452-15-000206:8k_2_02:95]
| • | Certain other items are excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001234452-15-000206:8k_2_02:96]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items starting with acquisitions completed in the third quarter of fiscal 2011, as well as any tax effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property. Starting in the first quarter of fiscal 2015, the Company excludes third-party |

[0001234452-15-000206:8k_2_02:97]
acquisition and integration services costs.  Prior year amounts have not been reclassified to conform to the current presentation.

[0001234452-15-000206:8k_2_02:98]
| • | Starting in the first quarter of fiscal 2015, the Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and long-lived asset impairments and litigation settlements and/or damages. Prior year amounts have not been reclassified to conform to the current presentation. |

[0001234452-15-000206:8k_2_02:99]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. Also, the provision (benefit) to reconcile the tax provisions (benefits) for each column to the total GAAP tax provision for the quarter is excluded. At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. In interim quarters of prior fiscal years, this difference was allocated to the tax provisions (benefits) among the columns. |

[0001234452-15-000206:8k_2_02:100]
About Qualcomm

[0001234452-15-000206:8k_2_02:101]
Qualcomm Incorporated (Nasdaq:  QCOM) is a world leader in 3G, 4G and next-generation wireless technologies.  Qualcomm Incorporated includes Qualcomm’s licensing business, QTL, and the vast majority of its patent portfolio.  Qualcomm Technologies, Inc., a wholly-owned subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of Qualcomm’s engineering, research and development functions, and substantially all of its products and services businesses, including its semiconductor business, QCT.  For more than 30 years, Qualcomm ideas and inventions have driven the evolution of digital communications, linking people everywhere more closely to information, entertainment and each other.  For more information, visit www.qualcomm.com.

[0001234452-15-000206:8k_2_02:102]
Note Regarding Forward-Looking Statements

[0001234452-15-000206:8k_2_02:103]
In addition to the historical information contained herein, this news release contains forward-looking statements that are inherently subject to risks and uncertainties, including but not limited to statements regarding our capital return commitments, including our plan to repurchase an additional $10 billion in stock by March 2016, our ASR program, including the final number and average purchase price of shares to be delivered thereunder and the timing thereof, and the benefit to our outlook related to stock repurchases we intend to complete; our reduced outlook for our semiconductor business and the factors

[0001234452-15-000206:8k_2_02:104]
###

[0001234452-15-000206:8k_2_02:105]
Qualcomm, Snapdragon and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-15-000206:8k_2_02:106]
Qualcomm Incorporated

[0001234452-15-000206:8k_2_02:107]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001234452-15-000206:8k_2_02:108]
(In millions, except per share data)

[0001234452-15-000206:8k_2_02:109]
(Unaudited)

[0001234452-15-000206:8k_2_02:110]
|  | June 28, 2015 |  | September 28, 2014 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 9,987 |  |  | $ | 7,907 |  |
| Marketable securities | 11,344 |  |  | 9,658 |  |
| Accounts receivable, net | 1,961 |  |  | 2,412 |  |
| Inventories | 1,583 |  |  | 1,458 |  |
| Deferred tax assets | 472 |  |  | 577 |  |
| Other current assets | 581 |  |  | 401 |  |
| Total current assets | 25,928 |  |  | 22,413 |  |
| Marketable securities | 13,894 |  |  | 14,457 |  |
| Deferred tax assets | 1,275 |  |  | 1,174 |  |
| Property, plant and equipment, net | 2,574 |  |  | 2,487 |  |
| Goodwill | 4,259 |  |  | 4,488 |  |
| Other intangible assets, net | 2,405 |  |  | 2,580 |  |
| Other assets | 1,960 |  |  | 975 |  |
| Total assets | $ | 52,295 |  |  | $ | 48,574 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,412 |  |  | $ | 2,183 |  |
| Payroll and other benefits related liabilities | 697 |  |  | 802 |  |
| Unearned revenues | 680 |  |  | 785 |  |
| Short-term debt | 1,000 |  |  | — |  |
| Other current liabilities | 2,294 |  |  | 2,243 |  |
| Total current liabilities | 6,083 |  |  | 6,013 |  |
| Unearned revenues | 2,576 |  |  | 2,967 |  |
| Long-term debt | 9,913 |  |  | — |  |
| Other liabilities | 527 |  |  | 428 |  |
| Total liabilities | 19,099 |  |  | 9,408 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,578 and 1,669 shares issued and outstanding, respectively | — |  |  | 7,736 |  |
| Retained earnings | 32,699 |  |  | 30,799 |  |
| Accumulated other comprehensive income | 503 |  |  | 634 |  |
| Total Qualcomm stockholders’ equity | 33,202 |  |  | 39,169 |  |
| Noncontrolling interests | (6 | ) |  | (3 | ) |
| Total stockholders’ equity | 33,196 |  |  | 39,166 |  |
| Total liabilities and stockholders’ equity | $ | 52,295 |  |  | $ | 48,574 |  |

[0001234452-15-000206:8k_2_02:111]
Qualcomm Incorporated

[0001234452-15-000206:8k_2_02:112]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-15-000206:8k_2_02:113]
(In millions, except per share data)

[0001234452-15-000206:8k_2_02:114]
(Unaudited)

[0001234452-15-000206:8k_2_02:115]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | June 28, 2015 |  | June 29, 2014 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,840 |  |  | $ | 4,922 |  |  | $ | 13,459 |  |  | $ | 13,803 |  |
| Licensing | 1,992 |  |  | 1,884 |  |  | 6,366 |  |  | 5,992 |  |
| Total revenues | 5,832 |  |  | 6,806 |  |  | 19,825 |  |  | 19,795 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of equipment and services revenues | 2,451 |  |  | 2,740 |  |  | 8,126 |  |  | 7,929 |  |
| Research and development | 1,407 |  |  | 1,429 |  |  | 4,133 |  |  | 4,113 |  |
| Selling, general and administrative | 577 |  |  | 582 |  |  | 1,689 |  |  | 1,745 |  |
| Other | 162 |  |  | (20 | ) |  | 1,241 |  |  | 450 |  |
| Total costs and expenses | 4,597 |  |  | 4,731 |  |  | 15,189 |  |  | 14,237 |  |
| Operating income | 1,235 |  |  | 2,075 |  |  | 4,636 |  |  | 5,558 |  |
| Investment income, net | 163 |  |  | 422 |  |  | 600 |  |  | 968 |  |
| Income from continuing operations before income taxes | 1,398 |  |  | 2,497 |  |  | 5,236 |  |  | 6,526 |  |
| Income tax expense | (215 | ) |  | (260 | ) |  | (1,029 | ) |  | (886 | ) |
| Income from continuing operations | 1,183 |  |  | 2,237 |  |  | 4,207 |  |  | 5,640 |  |
| Discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | 430 |  |
| Net income | 1,183 |  |  | 2,237 |  |  | 4,207 |  |  | 6,070 |  |
| Net loss attributable to noncontrolling interests | 1 |  |  | 1 |  |  | 2 |  |  | 3 |  |
| Net income attributable to Qualcomm | $ | 1,184 |  |  | $ | 2,238 |  |  | $ | 4,209 |  |  | $ | 6,073 |  |
| Basic earnings per share attributable to Qualcomm: |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.74 |  |  | $ | 1.33 |  |  | $ | 2.57 |  |  | $ | 3.35 |  |
| Discontinued operations | — |  |  | — |  |  | — |  |  | 0.25 |  |
| Net income | $ | 0.74 |  |  | $ | 1.33 |  |  | $ | 2.57 |  |  | $ | 3.60 |  |
| Diluted earnings per share attributable to Qualcomm: |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.73 |  |  | $ | 1.31 |  |  | $ | 2.53 |  |  | $ | 3.28 |  |
| Discontinued operations | — |  |  | — |  |  | — |  |  | 0.25 |  |
| Net income | $ | 0.73 |  |  | $ | 1.31 |  |  | $ | 2.53 |  |  | $ | 3.53 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,608 |  |  | 1,683 |  |  | 1,638 |  |  | 1,686 |  |
| Diluted | 1,629 |  |  | 1,714 |  |  | 1,661 |  |  | 1,718 |  |
| Dividends per share announced | $ | 0.48 |  |  | $ | 0.42 |  |  | $ | 1.32 |  |  | $ | 1.12 |  |

[0001234452-15-000206:8k_2_02:116]
Qualcomm Incorporated

[0001234452-15-000206:8k_2_02:117]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-15-000206:8k_2_02:118]
(In millions)

[0001234452-15-000206:8k_2_02:119]
(Unaudited)

[0001234452-15-000206:8k_2_02:120]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | June 28, 2015 |  | June 29, 2014 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,183 |  |  | $ | 2,237 |  |  | $ | 4,207 |  |  | $ | 6,070 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 297 |  |  | 292 |  |  | 888 |  |  | 853 |  |
| Gain on sale of discontinued operations | — |  |  | — |  |  | — |  |  | (665 | ) |
| Long-lived asset and goodwill impairment charges | 166 |  |  | 164 |  |  | 304 |  |  | 642 |  |
| Income tax provision in excess of (less than) income tax payments | 86 |  |  | (24 | ) |  | 159 |  |  | 244 |  |
| Non-cash portion of share-based compensation expense | 271 |  |  | 274 |  |  | 793 |  |  | 806 |  |
| Incremental tax benefits from share-based compensation | (20 | ) |  | (70 | ) |  | (98 | ) |  | (239 | ) |
| Net realized gains on marketable securities and other investments | (122 | ) |  | (298 | ) |  | (399 | ) |  | (685 | ) |
| Impairment losses on marketable securities and other investments | 55 |  |  | 11 |  |  | 161 |  |  | 170 |  |
| Other items, net | 2 |  |  | 15 |  |  | (29 | ) |  | (5 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | 100 |  |  | 139 |  |  | 438 |  |  | 43 |  |
| Inventories | 281 |  |  | (37 | ) |  | (122 | ) |  | 116 |  |
| Other assets | 241 |  |  | 9 |  |  | (897 | ) |  | 136 |  |
| Trade accounts payable | (261 | ) |  | 286 |  |  | (769 | ) |  | 321 |  |
| Payroll, benefits and other liabilities | (1 | ) |  | (235 | ) |  | (406 | ) |  | (337 | ) |
| Unearned revenues | (162 | ) |  | (90 | ) |  | (408 | ) |  | (202 | ) |
| Net cash provided by operating activities | 2,116 |  |  | 2,673 |  |  | 3,822 |  |  | 7,268 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (366 | ) |  | (158 | ) |  | (815 | ) |  | (955 | ) |
| Purchases of available-for-sale securities | (4,360 | ) |  | (2,488 | ) |  | (13,118 | ) |  | (10,315 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 3,266 |  |  | 4,060 |  |  | 11,897 |  |  | 9,744 |  |
| Purchases of trading securities | (339 | ) |  | (1,054 | ) |  | (1,034 | ) |  | (2,868 | ) |
| Proceeds from sales and maturities of trading securities | 298 |  |  | 826 |  |  | 1,008 |  |  | 2,619 |  |
| Purchases of other marketable securities | — |  |  | (220 | ) |  | — |  |  | (220 | ) |
| Proceeds from sale of discontinued operations, net of cash sold | — |  |  | — |  |  | — |  |  | 788 |  |
| Proceeds from sales of property, plant and equipment | 128 |  |  | 36 |  |  | 161 |  |  | 37 |  |
| Acquisitions and other investments, net of cash acquired | (130 | ) |  | (100 | ) |  | (308 | ) |  | (447 | ) |
| Other items, net | (27 | ) |  | 4 |  |  | (11 | ) |  | 65 |  |
| Net cash (used) provided by investing activities | (1,530 | ) |  | 906 |  |  | (2,220 | ) |  | (1,552 | ) |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 1,718 |  |  | — |  |  | 2,813 |  |  | — |  |
| Proceeds from long-term debt | 9,937 |  |  | — |  |  | 9,937 |  |  | — |  |
| Repayment of short-term debt | (1,813 | ) |  | — |  |  | (1,814 | ) |  | — |  |
| Proceeds from issuance of common stock | 154 |  |  | 194 |  |  | 571 |  |  | 1,147 |  |
| Repurchases and retirements of common stock | (5,405 | ) |  | (1,350 | ) |  | (9,016 | ) |  | (3,354 | ) |
| Dividends paid | (757 | ) |  | (706 | ) |  | (2,142 | ) |  | (1,884 | ) |
| Incremental tax benefits from share-based compensation | 20 |  |  | 70 |  |  | 98 |  |  | 239 |  |
| Other items, net | 50 |  |  | (184 | ) |  | 41 |  |  | (65 | ) |
| Net cash provided (used) by financing activities | 3,904 |  |  | (1,976 | ) |  | 488 |  |  | (3,917 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 5 |  |  | 4 |  |  | (10 | ) |  | 3 |  |
| Net increase in cash and cash equivalents | 4,495 |  |  | 1,607 |  |  | 2,080 |  |  | 1,802 |  |
| Cash and cash equivalents at beginning of period | 5,492 |  |  | 6,337 |  |  | 7,907 |  |  | 6,142 |  |
| Cash and cash equivalents at end of period | $ | 9,987 |  |  | $ | 7,944 |  |  | $ | 9,987 |  |  | $ | 7,944 |  |
