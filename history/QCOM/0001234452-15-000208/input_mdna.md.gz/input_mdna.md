# QCOM MD&A — 0001234452-15-000208


## mdna

[0001234452-15-000208:mdna:1]
[same as prior period, unchanged from 0001234452-15-000134:mdna:1]

[0001234452-15-000208:mdna:2]
[same as prior period, unchanged from 0001234452-15-000134:mdna:2]

[0001234452-15-000208:mdna:3]
[same as prior period, unchanged from 0001234452-15-000134:mdna:3]

[0001234452-15-000208:mdna:4]
[same as prior period, unchanged from 0001234452-15-000134:mdna:4]

[0001234452-15-000208:mdna:5]
Revenues for the third quarter of fiscal 2015 were $5.8 billion, with net income attributable to Qualcomm of $1.2 billion, which primarily resulted from the following key items:

[0001234452-15-000208:mdna:6]
| • | We shipped approximately 225 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, consistent with the approximately 225 million MSM integrated circuits in the year ago quarter. |

[0001234452-15-000208:mdna:7]
| • | Total reported device sales were approximately $60.4 billion, an increase of approximately 4%, compared to approximately $58.1 billion in the year ago quarter.(1) |

[0001234452-15-000208:mdna:8]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, with maturity dates starting in 2018 through 2045 and effective interest rates between 0.61% and 4.74%. Additionally, in May 2015, we entered into two accelerated share repurchase agreements (ASR Agreements) to repurchase an aggregate of $5.0 billion of our common stock. During the third quarter of fiscal 2015, 57.7 million shares were delivered to us under the ASR Agreements, constituting the initial delivery of shares under the ASR Agreements, and were retired. Pursuant to the terms of the ASR Agreements, the final number of shares and the average purchase price of the shares will be determined at the end of the applicable purchase periods based on the volume-weighted average stock price of our common stock during the terms of the transactions, which is expected to occur in or before November 2015.

[0001234452-15-000208:mdna:9]
On July 22, 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders.

[0001234452-15-000208:mdna:10]
Against this backdrop, the following recent developments occurred during the third quarter of fiscal 2015 with respect to key elements of our business or our industry:

[0001234452-15-000208:mdna:11]
| • | Worldwide cellular connections grew sequentially by approximately 1% to reach approximately 7.2 billion.(2) |

[0001234452-15-000208:mdna:12]
23

[0001234452-15-000208:mdna:13]
| • | Worldwide 3G/4G connections (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) grew sequentially by approximately 5% to approximately 3.3 billion, which was approximately 45% of total cellular connections.(2) |

[0001234452-15-000208:mdna:14]
| (1) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). Not all licensees report sales the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-15-000208:mdna:15]
| (2) | According to GSMA Intelligence estimates as of July 20, 2015 for the quarter ended June 30, 2015. |

[0001234452-15-000208:mdna:16]
[same as prior period, unchanged from 0001234452-15-000134:mdna:16]

[0001234452-15-000208:mdna:17]
[same as prior period, unchanged from 0001234452-15-000134:mdna:17]

[0001234452-15-000208:mdna:18]
[same as prior period, unchanged from 0001234452-15-000134:mdna:18]

[0001234452-15-000208:mdna:19]
QCT is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products and system software are sold to or licensed to manufacturers that use our products in wireless devices, particularly mobile phones, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards and infrastructure equipment, and in wired devices, particularly broadband gateway equipment, desktop computers and streaming media players. Our MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Qualcomm Snapdragon processors and LTE modems, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon processors provide advanced application and graphics processing capabilities. QCT’s system software enables the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits. QCT revenues comprised 66% and 73% of total consolidated revenues in the third quarter of fiscal 2015 and 2014, respectively, and 68% and 70% of total consolidated revenues for the first nine months of fiscal 2015 and 2014, respectively.

[0001234452-15-000208:mdna:20]
[same as prior period, unchanged from 0001234452-15-000134:mdna:20]

[0001234452-15-000208:mdna:21]
QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD (including TD-SCDMA), GSM/GPRS/EDGE and/or OFDMA standards and their derivatives. QTL licensing revenues are comprised of

[0001234452-15-000208:mdna:22]
[same as prior period, unchanged from 0001234452-15-000134:mdna:33]

[0001234452-15-000208:mdna:23]
license fees as well as royalties based on sales by licensees of products incorporating or using our intellectual property. License fees are fixed amounts paid in one or more installments. Royalties are generally based upon a percentage of the wholesale selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). QTL recognizes royalty revenues based on royalties reported by licensees and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. QTL revenues comprised 33% and 26% of total consolidated revenues in the third quarter of fiscal 2015 and 2014, respectively, and 31% and 29% of total consolidated revenues for the first nine months of fiscal 2015 and 2014, respectively. The vast majority of such revenues were generated through our licensees’ sales of CDMA2000- and WCDMA-based products, such as feature phones and smartphones.

[0001234452-15-000208:mdna:24]
QSI makes strategic investments that are focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications. Many of these strategic investments are in early-stage companies in a variety of industries, including, but not limited to, digital media, e-commerce, energy, healthcare and wearable devices. Investments primarily include non-marketable equity instruments, which generally are recorded using the cost method or the equity method, and convertible debt instruments, which are recorded at fair value. QSI also holds wireless spectrum, which at June 28, 2015, consisted of L-Band spectrum in the United Kingdom. As part of our strategic investment activities, we intend to pursue various exit strategies for each of our QSI investments in the foreseeable future.

[0001234452-15-000208:mdna:25]
Nonreportable segments include our small cells, data center and other wireless technology and service initiatives.

[0001234452-15-000208:mdna:26]
Seasonality. Many of our products or intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has tended historically to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons; and because QTL recognizes royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made during the fourth calendar quarter. We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 3G/4G networks by wireless operators and the timing of launches of our customers’ and licensees’ flagship wireless devices.

[0001234452-15-000208:mdna:27]
[same as prior period, unchanged from 0001234452-15-000134:mdna:26]

[0001234452-15-000208:mdna:28]
[same as prior period, unchanged from 0001234452-15-000134:mdna:27]

[0001234452-15-000208:mdna:29]
| • | On July 22, 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders. The core elements of this plan include (a) right-sizing our cost structure; (b) reviewing alternatives to our corporate and financial structure; (c) reaffirming our plan to return significant capital to stockholders; (d) adding new Directors with complementary skills while reducing the average tenure of our Board of Directors; (e) further aligning executive compensation with performance and stockholder return objectives; and (f) making disciplined investments in areas that build upon our core technologies and capabilities and offer attractive growth opportunities and returns. |

[0001234452-15-000208:mdna:30]
| • | In order to right-size our cost structure, we are planning to reduce our annual costs from fiscal 2015 levels of $7.3 billion (adjusted for variable compensation) by approximately $1.1 billion through a series of targeted reductions across Qualcomm’s businesses, particularly in QCT. We also plan to reduce annual share-based compensation grants by approximately $300 million. We expect these cost initiatives to be fully implemented by the end of fiscal 2016. In connection with this plan, we expect to incur approximately $350 million to $450 million in restructuring and restructuring-related charges, of which approximately $100 million to $200 million are expected to be incurred in the fourth quarter of fiscal 2015. Restructuring and restructuring-related charges include an estimate of severance costs, lease termination costs, acceleration of depreciation, consultancy fees and other costs. |

[0001234452-15-000208:mdna:31]
| • | Our business has been impacted by changing industry dynamics, including: an increased shift in share among our customers within the premium tier, which will continue to negatively impact sales of our integrated Snapdragon processors and skew our product mix towards lower-margin modem chipsets in this tier; an increased use of internally-developed integrated circuit products by certain of our OEM (original equipment manufacturer) customers, which has led to a decline in share at a large customer; and the acceleration of intense competition in the low-tier, particularly in China. We anticipate that our results of operations, particularly for |

[0001234452-15-000208:mdna:32]
25

[0001234452-15-000208:mdna:33]
our semiconductor business, QCT, will continue to be adversely impacted by these factors in the remainder of fiscal 2015, and continuing into next fiscal year.

[0001234452-15-000208:mdna:34]
| • | We continue to invest significant resources toward advancements in 3G, 3G/4G multimode and 4G LTE technologies, audio and video codecs, wireless baseband chips, our converged computing/communications (Snapdragon) chips, graphics, connectivity, multimedia products, software and services. We are also investing in targeted opportunities that utilize our existing technical and business expertise to deploy new business models and enter into new industry segments, such as products designed for implementation of small cells to address the challenge of meeting the increased demand for data; products for the connected home and the Internet of Things; automotive; networking; mobile computing; very high speed connectivity; data centers; mobile health; wireless charging; and machine learning, including robotics. |

[0001234452-15-000208:mdna:35]
[same as prior period, unchanged from 0001234452-15-000134:mdna:28]

[0001234452-15-000208:mdna:36]
[same as prior period, unchanged from 0001234452-15-000134:mdna:29]

[0001234452-15-000208:mdna:37]
[same as prior period, unchanged from 0001234452-15-000134:mdna:30]

[0001234452-15-000208:mdna:38]
| • | In February 2015, we reached a resolution with the NDRC regarding its investigation and agreed to implement a rectification plan that modifies certain of our business practices in China. The rectification plan provides, among other things, that for licenses of only our 3G and 4G essential Chinese patents for branded devices sold for use in China starting on January 1, 2015 (and reported to us in the third quarter of fiscal 2015), we will charge running royalties at royalty rates of 5% for 3G CDMA or WCDMA devices (including multimode 3G/4G devices) and 3.5% for 4G devices that do not implement CDMA or WCDMA (including 3-mode LTE-TDD devices), in each case using a royalty base of 65% of the net selling price. |

[0001234452-15-000208:mdna:39]
| • | Despite the resolution of the NDRC investigation, China continues to present significant challenges for us. We continue to believe that certain licensees in China are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes 3G/4G units that we believe are not being reported by certain licensees). We continue to make progress, with licensees executing agreements based on the new China terms, and with several other licensees informing us that they intend to retain the terms of their existing agreements. Negotiations with certain other licensees are ongoing, and we expect it will take some time to conclude these negotiations. We believe that the conclusion of new agreements with these licensees will result in improved reporting by these licensees, including with respect to sales of three-mode devices (i.e., devices that implement GSM, TD-SCDMA, and LTE) sold in China. However, litigation and/or other actions may be necessary to compel licensees to report and pay the required royalties for sales they have not previously reported and to compel unlicensed companies to execute new licenses. |

[0001234452-15-000208:mdna:40]
| • | In October 2014, we announced that we had reached agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.4 billion based upon an exchange rate of USD: GBP 1.5634). CSR is an innovator in the development of multifunction semiconductor platforms and technologies for the automotive, consumer and voice and music categories. The acquisition complements our current offerings by adding products, channels and customers in the growth categories of the Internet of Everything and automotive infotainment, accelerating our presence and path to leadership. The acquisition has received approval of CSR’s shareholders, and every required regulatory agency has either provided formal written approval or declined to exercise jurisdiction, except for the Ministry of Commerce in China. The completion of the acquisition remains subject to the satisfaction of additional conditions. Subject to the satisfaction of these conditions, the acquisition is expected to close by the end of the summer of 2015. |

[0001234452-15-000208:mdna:41]
[same as prior period, unchanged from 0001234452-15-000134:mdna:51]

[0001234452-15-000208:mdna:42]
[same as prior period, unchanged from 0001234452-15-000134:mdna:39]

[0001234452-15-000208:mdna:43]
[same as prior period, unchanged from 0001234452-15-000134:mdna:40]

[0001234452-15-000208:mdna:44]
[same as prior period, unchanged from 0001234452-15-000134:mdna:41]

[0001234452-15-000208:mdna:45]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | Change |  | June 28, 2015 |  | June 29, 2014 |  | Change |
| Equipment and services | $ | 3,840 |  |  | $ | 4,922 |  |  | $ | (1,082 | ) |  | $ | 13,459 |  |  | $ | 13,803 |  |  | $ | (344 | ) |
| Licensing | 1,992 |  |  | 1,884 |  |  | 108 |  |  | 6,366 |  |  | 5,992 |  |  | 374 |  |
|  | $ | 5,832 |  |  | $ | 6,806 |  |  | $ | (974 | ) |  | $ | 19,825 |  |  | $ | 19,795 |  |  | $ | 30 |  |

[0001234452-15-000208:mdna:46]
The decreases in equipment and services revenues in the third quarter and the first nine months of fiscal 2015 were primarily due to decreases in QCT revenues of $1.08 billion and $287 million, respectively. Additionally, the sale of the North and Latin America operations of our Omnitracs division during fiscal 2014 contributed $59 million to the decrease for the first nine months of fiscal 2015. The increases in licensing revenues in the third quarter and the first nine months of fiscal 2015 were primarily due to increases in QTL revenues of $128 million and $388 million, respectively.

[0001234452-15-000208:mdna:47]
| Costs and Expenses (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | Change |  | June 28, 2015 |  | June 29, 2014 |  | Change |
| Cost of equipment and services (E&S) revenues | $ | 2,451 |  |  | $ | 2,740 |  |  | $ | (289 | ) |  | $ | 8,126 |  |  | $ | 7,929 |  |  | $ | 197 |  |
| Cost as % of E&S revenues | 64 | % |  | 56 | % |  |  |  | 60 | % |  | 57 | % |  |  |

[0001234452-15-000208:mdna:48]
The decreases in margin percentage for the third quarter and the first nine months of fiscal 2015 were driven primarily by decreases in QCT margin percentage. Our margin percentage may fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors.

[0001234452-15-000208:mdna:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | Change |  | June 28, 2015 |  | June 29, 2014 |  | Change |
| Research and development | $ | 1,407 |  |  | $ | 1,429 |  |  | $ | (22 | ) |  | $ | 4,133 |  |  | $ | 4,113 |  |  | $ | 20 |  |
| % of revenues | 24 | % |  | 21 | % |  |  |  | 21 | % |  | 21 | % |  |  |
| Selling, general, and administrative | $ | 577 |  |  | $ | 582 |  |  | $ | (5 | ) |  | $ | 1,689 |  |  | $ | 1,745 |  |  | $ | (56 | ) |
| % of revenues | 10 | % |  | 9 | % |  |  |  | 9 | % |  | 9 | % |  |  |
| Other | $ | 162 |  |  | $ | (20 | ) |  | $ | 182 |  |  | $ | 1,241 |  |  | $ | 450 |  |  | $ | 791 |  |

[0001234452-15-000208:mdna:50]
The dollar decrease in research and development expenses in the third quarter of fiscal 2015 was primarily due to a decrease of $24 million related to the development costs of display technologies. The dollar increase in research and development expenses in the first nine months of fiscal 2015 was primarily attributable to an increase of $89 million in costs related to the development of CDMA-based 3G, OFDMA-based 4G LTE and other technologies for integrated circuit and related software products, including small cells and data center products, and to expand our intellectual property portfolio, partially offset by a decrease of $54 million related to the development costs of display technologies.

[0001234452-15-000208:mdna:51]
The dollar decrease in selling, general and administrative expenses in the first nine months of fiscal 2015 was primarily attributable to $60 million in gains related to sales of certain assets of one of our display businesses, the effect of which was a decrease in selling, general and administrative expenses.

[0001234452-15-000208:mdna:52]
Other expenses in the third quarter of fiscal 2015 were attributable to impairment charges of $151 million and $11 million related to goodwill and intangible assets, respectively, related to our content services business and one of our display businesses. Other expenses in the first nine months of fiscal 2015 were attributable to a $975 million charge resulting from the resolution reached with the NDRC and charges of $255 million and $11 million for impairment of goodwill and intangible assets, respectively, related to our content and push-to-talk services and display businesses. Other expenses in the first nine months of fiscal 2014 were comprised of $607 million in certain property, plant and equipment and goodwill impairment charges related to one of our display businesses and a $16 million goodwill impairment charge related to our former QRS division, partially offset by the reversal of the $173 million accrual recorded in fiscal 2013 related to the ParkerVision verdict.

[0001234452-15-000208:mdna:53]
| Net Investment Income (in millions) |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | Change |  | June 28, 2015 |  | June 29, 2014 |  | Change |
| Interest and dividend income | $ | 128 |  |  | $ | 139 |  |  | $ | (11 | ) |  | $ | 400 |  |  | $ | 460 |  |  | $ | (60 | ) |
| Interest expense | (32 | ) |  | — |  |  | (32 | ) |  | (34 | ) |  | (4 | ) |  | (30 | ) |
| Net realized gains on marketable securities | 117 |  |  | 290 |  |  | (173 | ) |  | 381 |  |  | 660 |  |  | (279 | ) |
| Net realized gains on other investments | 5 |  |  | 8 |  |  | (3 | ) |  | 18 |  |  | 25 |  |  | (7 | ) |
| Impairment losses on marketable securities and other investments | (55 | ) |  | (11 | ) |  | (44 | ) |  | (161 | ) |  | (170 | ) |  | 9 |  |
| Net gains (losses) on derivative instruments | 10 |  |  | (6 | ) |  | 16 |  |  | 16 |  |  | (1 | ) |  | 17 |  |
| Equity in net losses of investees | (10 | ) |  | (2 | ) |  | (8 | ) |  | (23 | ) |  | (7 | ) |  | (16 | ) |
| Net gains on deconsolidation of subsidiaries | — |  |  | 4 |  |  | (4 | ) |  | 3 |  |  | 5 |  |  | (2 | ) |
|  | $ | 163 |  |  | $ | 422 |  |  | $ | (259 | ) |  | $ | 600 |  |  | $ | 968 |  |  | $ | (368 | ) |

[0001234452-15-000208:mdna:54]
The decrease in interest and dividend income in the first nine months of fiscal 2015 was primarily due to lower interest rates earned on cash equivalents and marketable securities balances held. The increases in interest expense in the third quarter and the first nine months of fiscal 2015 were primarily due to the issuance of an aggregate principal amount of $10.0 billion in floating- and fixed-rate notes in May 2015. The decreases in net realized gains on marketable securities in the third quarter and the first nine months of fiscal 2015 were primarily due to the decreased impact of portfolio rebalancing in the third quarter and the first nine months of fiscal 2015. The increase in impairment losses on marketable securities and other investments in the third quarter of fiscal 2015 was primarily due to an increase in recognition of unrealized losses on marketable equity securities.

[0001234452-15-000208:mdna:55]
| Income Tax Expense (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | Change |  | June 28, 2015 |  | June 29, 2014 |  | Change |
| Income tax expense | $ | 215 |  |  | $ | 260 |  |  | $ | (45 | ) |  | $ | 1,029 |  |  | $ | 886 |  |  | $ | 143 |  |
| Effective tax rate | 15 | % |  | 10 | % |  | 5 | % |  | 20 | % |  | 14 | % |  | 6 | % |

[0001234452-15-000208:mdna:56]
[same as prior period, unchanged from 0001234452-15-000134:mdna:65]

[0001234452-15-000208:mdna:57]
The following table summarizes the primary factors that caused our effective tax rates for the third quarter and first nine months of fiscal 2015 and 2014 to be less than the United States federal statutory rate:

[0001234452-15-000208:mdna:58]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | June 28, 2015 |  | June 29, 2014 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |  | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (22 | %) |  | (23 | %) |  | (19 | %) |  | (21 | %) |
| Benefits related to the research and development tax credit | (1 | %) |  | (1 | %) |  | (3 | %) |  | (1 | %) |
| Tax impact of NDRC fine | — |  |  | — |  |  | 7 | % |  | — |  |
| Tax audit impacts, net | — |  |  | — |  |  | (1 | %) |  | — |  |
| Other | 3 | % |  | (1 | %) |  | 1 | % |  | 1 | % |
| Effective tax rate | 15 | % |  | 10 | % |  | 20 | % |  | 14 | % |

[0001234452-15-000208:mdna:59]
The effective tax rate of 15% for the third quarter of fiscal 2015 was less than the estimated annual effective tax rate of 19% primarily resulting from an increase in the allocation of expenses to our United States operations.

[0001234452-15-000208:mdna:60]
During the second quarter of fiscal 2015, the NDRC imposed a $975 million fine on the Company. The fine is not deductible for tax purposes. Given the significant unusual nature of the fine, it was accounted for discretely in the second quarter of fiscal 2015. Also, during the second quarter of fiscal 2015, we recorded a $61 million tax benefit as a result of a favorable tax audit settlement with the Internal Revenue Service related to Qualcomm Atheros, Inc.’s pre-acquisition 2010 and 2011 tax returns.

[0001234452-15-000208:mdna:61]
During the first quarter of fiscal 2015, the United States government reinstated the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. As a result of the reinstatement, we recorded a tax benefit of $101 million related to fiscal 2014 in the first quarter of fiscal 2015. Additionally, the estimated annual effective tax rate for fiscal 2015 reflects the United States federal research and development tax credit generated through December 31, 2014, the date on which the credit expired. The annual effective tax rate for fiscal 2014 reflected the tax benefit from the credit generated through December 31, 2013, the date on which the credit previously expired.

[0001234452-15-000208:mdna:62]
[same as prior period, unchanged from 0001234452-15-000134:mdna:59]

[0001234452-15-000208:mdna:63]
The following should be read in conjunction with the third quarter and first nine months financial results of fiscal 2015 for each reportable segment. See “Notes to Condensed Consolidated Financial Statements, Note 7 - Segment Information.”

[0001234452-15-000208:mdna:64]
| (in millions) | QCT |  | QTL |  | QSI |
| Three Months Ended June 28, 2015 |  |  |  |  |  |
| Revenues | $ | 3,853 |  |  | $ | 1,931 |  |  | $ | — |  |
| EBT (1) | 289 |  |  | 1,654 |  |  | (49 | ) |
| EBT as a % of revenues | 8 | % |  | 86 | % |  |  |
| Three Months Ended June 29, 2014 |  |  |  |  |  |
| Revenues | $ | 4,957 |  |  | $ | 1,803 |  |  | $ | — |  |
| EBT (1) | 1,116 |  |  | 1,550 |  |  | (1 | ) |
| EBT as a % of revenues | 23 | % |  | 86 | % |  |  |
| Nine Months Ended June 28, 2015 |  |  |  |  |  |
| Revenues | $ | 13,529 |  |  | $ | 6,162 |  |  | $ | — |  |
| EBT (1) | 2,185 |  |  | 5,395 |  |  | (82 | ) |
| EBT as a % of revenues | 16 | % |  | 88 | % |  |  |  |
| Nine Months Ended June 29, 2014 |  |  |  |  |  |
| Revenues | $ | 13,816 |  |  | $ | 5,774 |  |  | $ | — |  |
| EBT (1) | 2,762 |  |  | 5,054 |  |  | (36 | ) |
| EBT as a % of revenues | 20 | % |  | 88 | % |  |  |  |

[0001234452-15-000208:mdna:65]
[same as prior period, unchanged from 0001234452-15-000134:mdna:62]

[0001234452-15-000208:mdna:66]
QCT Segment. QCT results of operations in the third quarter of fiscal 2015 were negatively impacted by the effects of a shift in share among our customers within the premium tier, which reduced our sales of integrated Snapdragon processors and skewed our product mix towards lower-margin modem chipsets in this tier, a decline in share at a large customer and the competitive environment in China. The decreases in QCT revenues in the third quarter and the first nine months of fiscal 2015 of $1.10 billion and $287 million, respectively, were primarily due to decreases in equipment and services revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying Radio Frequency (RF) and Power Management (PM) integrated circuits, were $3.80 billion and $4.89 billion in the third quarter of fiscal 2015 and 2014, respectively, and $13.36 billion and $13.65 billion in the first nine months of fiscal 2015 and 2014, respectively. The decreases in equipment and services revenues in the third quarter and the first nine months of fiscal 2015 resulted primarily from net decreases of $1.10 billion and $2.29 billion, respectively, from lower-priced product mix and lower average selling prices. The decrease for the first nine months of fiscal 2015 was partially offset by an increase of $1.89 billion related to higher MSM and accompanying RF and PM unit shipments. Approximately 225 million MSM integrated circuits were sold during the third quarter of both fiscal 2015 and 2014, and approximately 728 million and 625 million MSM integrated circuits were sold during the first nine months of fiscal 2015 and 2014, respectively.

[0001234452-15-000208:mdna:67]
QCT EBT as a percentage of revenues in the third quarter and the first nine months of fiscal 2015 decreased primarily due to decreases in gross margin percentage and the related impact of lower revenues relative to operating expenses. The decreases in QCT gross margin percentage in the third quarter and the first nine months of fiscal 2015 primarily resulted from lower average selling prices and lower-margin product mix, partially offset by lower average unit costs. The gross margin percentage in the first nine months of fiscal 2015 was also impacted by an increase in excess inventory charges of $158 million.

[0001234452-15-000208:mdna:68]
QCT inventories decreased by 15% in the third quarter of fiscal 2015 from $1.86 billion to $1.58 billion, primarily due to decreases in work-in-process and finished goods inventories related to lower units on hand to align with near term demand and lower average unit costs.

[0001234452-15-000208:mdna:69]
QTL Segment. The increases in QTL revenues in the third quarter and the first nine months of fiscal 2015 of $128 million and $388 million, respectively, were primarily due to increases in sales of CDMA-based products, including multimode products that also implement OFDMA, reported by licensees and increased audit recoveries, partially offset by decreases in revenues per reported unit. QTL revenues and EBT for the third quarter and the first nine months of fiscal 2015 continued to be impacted negatively by units that we believe are not being reported by certain licensees and sales of certain unlicensed products in China. We expect it will take some time for those certain licensees to fully comply with the reporting requirements of their license agreements and for unlicensed companies that had delayed execution of new licenses pending resolution of the NDRC investigation to execute new licenses. QTL revenues and EBT for the first nine months of fiscal 2015 were also impacted negatively by fluctuations in foreign currency exchange rates.

[0001234452-15-000208:mdna:70]
QSI Segment. The decreases in QSI EBT in the third quarter and the first nine months of fiscal 2015 were primarily due to increases in impairment losses on our strategic investments.

[0001234452-15-000208:mdna:71]
[same as prior period, unchanged from 0001234452-15-000134:mdna:70]

[0001234452-15-000208:mdna:72]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. Cash, cash equivalents and marketable securities were $35.2 billion at June 28, 2015, an increase of $3.2 billion from September 28, 2014. This increase included $9.9 billion in proceeds from the issuance of notes, partially offset by $9.0 billion in payments to repurchase shares of our common stock, including the $5.0 billion accelerated share repurchase agreements (ASR Agreements). Total cash provided by operating activities decreased to $3.8 billion during the first nine months of fiscal 2015, compared to $7.3 billion during the first nine months of fiscal 2014 primarily due to a reduction in net income of $1.9 billion and prepayment of $950 million to secure long-term capacity commitments at a supplier of our integrated circuit products.

[0001234452-15-000208:mdna:73]
We classify certain of our marketable securities as short-term based on their nature and our plan to make them available, if needed, for use in our current operations. While we do not anticipate using our non-current marketable securities in operations in the foreseeable future, the securities could be liquidated within a short period of time if required. Our cash, cash equivalents and marketable securities at June 28, 2015 consisted of $8.0 billion held by United States-based entities and $27.2 billion held by foreign entities. Most of our cash, cash equivalents and marketable securities held by foreign entities are indefinitely reinvested and would be subject to material tax effects if repatriated.

[0001234452-15-000208:mdna:74]
[same as prior period, unchanged from 0001234452-15-000134:mdna:85]

[0001234452-15-000208:mdna:75]
However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate the funds.

[0001234452-15-000208:mdna:76]
Accounts receivable decreased 5% during the third quarter of fiscal 2015. Days sales outstanding, on a consolidated basis, were 30 days at June 28, 2015, compared to 27 days at March 29, 2015. The decrease in accounts receivable was primarily due to the net effects of decreased revenues related to integrated circuits, partially offset by the timing of payments from certain of our licensees. The increase in days sales outstanding was primarily due to the net effects of the timing of cash payments from certain of our licensees combined with a decrease in licensing revenues.

[0001234452-15-000208:mdna:77]
We believe our current cash, cash equivalents and marketable securities and our expected cash flow generated from operations and expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements also include:

[0001234452-15-000208:mdna:78]
| • | In connection with our Strategic Realignment Plan, we expect to incur approximately $350 million to $450 million in restructuring and restructuring-related charges, the majority of which will result in cash payments. |

[0001234452-15-000208:mdna:79]
| • | Our research and development expenditures were $4.1 billion during the first nine months of fiscal 2015 and $5.5 billion in fiscal 2014, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications, primarily in the wireless industry. |

[0001234452-15-000208:mdna:80]
| • | Our purchase obligations for the remainder of fiscal 2015 and for fiscal 2016, some of which relate to research and development activities and capital expenditures, totaled $2.2 billion and $1.2 billion, respectively, at June 28, 2015. |

[0001234452-15-000208:mdna:81]
| • | Cash outflows for capital expenditures were $815 million during the first nine months of fiscal 2015 and $1.2 billion in fiscal 2014. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-15-000208:mdna:82]
| • | In October 2014, we announced that we had reached agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.4 billion based upon an exchange rate of USD: GBP 1.5634). We expect to use existing cash resources to fund the acquisition. The acquisition has received approval from CSR’s shareholders, and every required regulatory agency has either provided formal written approval or declined to exercise jurisdiction, except for the Ministry of Commerce in China. The completion of the acquisition remains subject to the satisfaction of additional conditions. Subject to the satisfaction of these conditions, the acquisition is expected to close by the end of the summer of 2015. |

[0001234452-15-000208:mdna:83]
[same as prior period, unchanged from 0001234452-15-000134:mdna:83]

[0001234452-15-000208:mdna:84]
In connection with the pending acquisition of CSR, we agreed to set aside certain cash, cash equivalents and marketable securities to be held for purposes of satisfying payment of the consideration to effect the acquisition. At June 28, 2015, the fair value of the marketable securities that were set aside was $3.8 billion. Additionally, $47 million of cash equivalents, which were recorded as other current assets, were set aside. If the combined fair values falls below approximately £1.9 billion (approximately $2.9 billion using an exchange rate of USD: GBP 1.5634), we may be required to set aside additional securities. Additionally, if certain conditions are met, such as a reduction in the liquidity of any of the securities that are set aside, we may be required to liquidate the securities and transfer the cash to a third party until the acquisition closes.

[0001234452-15-000208:mdna:85]
Debt. In February 2015, we entered into a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. At June 28, 2015, no amounts were outstanding under the Revolving Credit Facility.

[0001234452-15-000208:mdna:86]
In March 2015, we began an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At June 28, 2015, we had $1.0 billion of commercial paper outstanding with weighted-average net interest rates of 0.14% and weighted-average remaining days to maturity of 51 days.

[0001234452-15-000208:mdna:87]
31

[0001234452-15-000208:mdna:88]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, with maturity dates starting in 2018 through 2045 and effective interest rates between 0.61% and 4.74%. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Net proceeds from the issuance of the notes of $9.9 billion were used to fund the ASR Agreements and are used for other general corporate purposes. We may issue additional debt in the future. The amount and timing of additional borrowings will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001234452-15-000208:mdna:89]
Additional information regarding our outstanding debt at June 28, 2015 is provided in the notes to our condensed consolidated financial statements. See “Notes to Condensed Consolidated Financial Statements, Note 5 — Debt.”

[0001234452-15-000208:mdna:90]
Capital Return Program. On March 9, 2015, we announced that we had been authorized to repurchase up to $15 billion of our common stock. We intend to return a minimum of 75% of our free cash flow to stockholders through stock repurchases and dividends over the foreseeable future, where free cash flow is defined as net cash provided by operating activities less capital expenditures. Additionally, we intend to repurchase $10 billion of stock from March 2015 through March 2016. To meet this goal, we expect to use existing cash and marketable securities (which include the proceeds from the recent debt offering) held by, and cash flow generated from, United States-based entities. We periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders.

[0001234452-15-000208:mdna:91]
We paid cash dividends totaling $757 million, or $0.48 per share, on June 24, 2015. On July 7, 2015, we announced a cash dividend of $0.48 per share on our common stock, payable on September 23, 2015 to stockholders of record as of the close of business on September 2, 2015. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-15-000208:mdna:92]
In May 2015, we entered into two accelerated share repurchase agreements (ASR Agreements) to repurchase an aggregate of $5.0 billion of our common stock. During the third quarter of fiscal 2015, 57.7 million shares were delivered to us under the ASR Agreements, constituting the initial delivery of shares under the ASR Agreements, and were retired. Pursuant to the terms of the ASR Agreements, the final number of shares and the average purchase price of the shares will be determined at the end of the applicable purchase periods based on the volume-weighted average stock price of our common stock during the terms of the transactions, which is expected to occur in or before November 2015. During the first nine months of fiscal 2015, we repurchased and retired an additional 56.7 million shares of our common stock for $4.0 billion, before commissions. At June 28, 2015, $9.1 billion remained authorized for repurchase under our stock repurchase program. Since June 28, 2015, we repurchased and retired 8.0 million shares of common stock for $510 million.

[0001234452-15-000208:mdna:93]
[same as prior period, unchanged from 0001234452-15-000134:mdna:86]

[0001234452-15-000208:mdna:94]
[same as prior period, unchanged from 0001234452-15-000134:mdna:87]

[0001234452-15-000208:mdna:95]
Additional information regarding our financial commitments at June 28, 2015 is provided in the notes to our condensed consolidated financial statements. See “Notes to Condensed Consolidated Financial Statements, Note 3 — Income Taxes,” “Note 5 — Debt” and “Note 6 — Commitments and Contingencies.”

[0001234452-15-000208:mdna:96]
[same as prior period, unchanged from 0001234452-15-000134:mdna:89]

[0001234452-15-000208:mdna:97]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for us starting in the first quarter of fiscal 2019. The FASB will also permit entities to adopt one year earlier if they choose (i.e., the original effective date). The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. We do not intend to adopt the standard early and are in the process of determining the adoption method as well as the effects the adoption will have on our consolidated financial statements.

[0001234452-15-000208:mdna:98]
[same as prior period, unchanged from 0001234452-15-000134:mdna:91]

[0001234452-15-000208:mdna:99]
[same as prior period, unchanged from 0001234452-15-000134:mdna:92]

[0001234452-15-000208:mdna:100]
[same as prior period, unchanged from 0001234452-15-000134:mdna:93]

[0001234452-15-000208:mdna:101]
[same as prior period, unchanged from 0001234452-15-000134:mdna:94]

[0001234452-15-000208:mdna:102]
[same as prior period, unchanged from 0001234452-15-000134:mdna:95]

[0001234452-15-000208:mdna:103]
[same as prior period, unchanged from 0001234452-15-000134:mdna:96]

[0001234452-15-000208:mdna:104]
[same as prior period, unchanged from 0001234452-15-000134:mdna:97]

[0001234452-15-000208:mdna:105]
[same as prior period, unchanged from 0001234452-15-000134:mdna:98]

[0001234452-15-000208:mdna:106]
[same as prior period, unchanged from 0001234452-15-000134:mdna:99]

[0001234452-15-000208:mdna:107]
[same as prior period, unchanged from 0001234452-15-000134:mdna:100]

[0001234452-15-000208:mdna:108]
[same as prior period, unchanged from 0001234452-15-000134:mdna:101]

[0001234452-15-000208:mdna:109]
[same as prior period, unchanged from 0001234452-15-000134:mdna:102]

[0001234452-15-000208:mdna:110]
[same as prior period, unchanged from 0001234452-15-000134:mdna:103]

[0001234452-15-000208:mdna:111]
[same as prior period, unchanged from 0001234452-15-000134:mdna:104]

[0001234452-15-000208:mdna:112]
[same as prior period, unchanged from 0001234452-15-000134:mdna:105]

[0001234452-15-000208:mdna:113]
| • | differentiate our integrated circuit products with innovative technologies across multiple products and features (e.g., modem, radio frequency front end, central, graphics and/or other processors, camera and connectivity) and with smaller geometry process technologies that drive performance; |

[0001234452-15-000208:mdna:114]
[same as prior period, unchanged from 0001234452-15-000134:mdna:107]

[0001234452-15-000208:mdna:115]
[same as prior period, unchanged from 0001234452-15-000134:mdna:108]

[0001234452-15-000208:mdna:116]
[same as prior period, unchanged from 0001234452-15-000134:mdna:109]

[0001234452-15-000208:mdna:117]
[same as prior period, unchanged from 0001234452-15-000134:mdna:110]

[0001234452-15-000208:mdna:118]
[same as prior period, unchanged from 0001234452-15-000134:mdna:111]

[0001234452-15-000208:mdna:119]
[same as prior period, unchanged from 0001234452-15-000134:mdna:112]

[0001234452-15-000208:mdna:120]
[same as prior period, unchanged from 0001234452-15-000134:mdna:114]

[0001234452-15-000208:mdna:121]
[same as prior period, unchanged from 0001234452-15-000134:mdna:115]

[0001234452-15-000208:mdna:122]
34

[0001234452-15-000208:mdna:123]
[same as prior period, unchanged from 0001234452-15-000134:mdna:116]

[0001234452-15-000208:mdna:124]
| • | create stand-alone value and/or contribute to the success of our existing businesses through acquisitions and other investments (and/or by developing customer, licensee and/or vendor relationships) in new industry segments and/or disruptive technologies, products and/or services (such as the connected home and the Internet of Things, automotive products, networking, mobile computing, mobile health, machine learning, including robotics and wireless charging, among others); and/or |

[0001234452-15-000208:mdna:125]
[same as prior period, unchanged from 0001234452-15-000134:mdna:118]

[0001234452-15-000208:mdna:126]
[same as prior period, unchanged from 0001234452-15-000134:mdna:119]

[0001234452-15-000208:mdna:127]
Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM, Wi-Fi) as well as companies that design integrated circuits based on CDMA, OFDMA or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom, Ericsson, HiSilicon Technologies, Intel, Lantiq, Marvell Technology, Maxim Integrated Products, MediaTek, Nvidia, Realtek Semiconductor, Samsung Electronics, Spreadtrum Communications (which is controlled by Tsinghua Unigroup), Texas Instruments and VIA Telecom. Some of these current and potential competitors have advantages over us that include, among others: lower cost structures; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; motivation by our customers in certain circumstances to utilize their own internally-developed integrated circuit products or to find alternate suppliers or choose alternative technologies; foreign government support of other technologies or competitors; more extensive relationships with local distribution companies and original equipment manufacturers in emerging geographic regions (such as China); and/or a more established presence in certain device markets.

[0001234452-15-000208:mdna:128]
[same as prior period, unchanged from 0001234452-15-000134:mdna:121]

[0001234452-15-000208:mdna:129]
[same as prior period, unchanged from 0001234452-15-000134:mdna:122]

[0001234452-15-000208:mdna:130]
Our QCT segment derives a significant portion of revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience an increasing concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. In addition, certain of our largest integrated circuit customers develop their own integrated circuit products, which they may

[0001234452-15-000208:mdna:131]
[same as prior period, unchanged from 0001234452-15-000134:mdna:136]

[0001234452-15-000208:mdna:132]
choose to utilize in their devices rather than our integrated circuit products (and/or sell their integrated circuit products to third parties in competition with us). The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or cancelation of significant purchases from any of these customers would reduce our revenues and could harm our ability to achieve or sustain expected operating results, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Further, concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have little or no control, and the timing of such introductions may cause our operating results to fluctuate. Accordingly, if current industry dynamics and concentrations continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases and the timing and size of any such future purchases by these significant customers.

[0001234452-15-000208:mdna:133]
Further, companies that develop HLOS for devices, including leading technology companies, now sell their own devices. If we fail to effectively partner or continue partnering with these companies, or with their partners or customers, they may decide not to purchase (either directly or through their contract manufacturers), or to reduce or discontinue their purchases of, our integrated circuit products.

[0001234452-15-000208:mdna:134]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products and/or intellectual property or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001234452-15-000208:mdna:135]
Although we have more than 275 CDMA-based licensees, our QTL segment derives a significant portion of licensing revenues from a limited number of licensees. In the event that one or more of our significant licensees fail to meet their reporting and/or payment requirements or we are unable to renew one or more of such license agreements, our revenues, operating results and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have little or no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our major licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues.

[0001234452-15-000208:mdna:136]
[same as prior period, unchanged from 0001234452-15-000134:mdna:127]

[0001234452-15-000208:mdna:137]
Although we own a very strong portfolio of issued and pending patents related to GSM, GPRS, EDGE, OFDM, OFDMA, WLAN, MIMO and other technologies, our patent portfolio licensing program in these areas is less established and might not be as successful in generating licensing revenues as our CDMA licensing program. Many wireless operators are investigating, have selected or have deployed OFDMA-based LTE as their next-generation 4G technology in existing (or future if not yet deployed) wireless spectrum bands as complementary to their existing CDMA-based networks. While 3G/4G multimode products are generally covered by our existing 3G licensing agreements, products that implement 4G but do not also implement 3G are generally not covered by these agreements. Although we believe that our patented technology is essential and useful to implementation of the LTE industry standards and have granted royalty-bearing licenses to more than 140 companies (including Alcatel-Lucent, Huawei, LG, Microsoft, Samsung, Sony Mobile and ZTE) that have realized that they need a license under our patents to make and sell products implementing 4G standards but not implementing 3G standards, it may be difficult to agree on material terms and/or conditions of new license agreements that are acceptable to us with companies that are currently unlicensed, particularly in China. Further, the royalty rates for single mode 4G products are generally lower than our royalty rates for 3G and 3G/4G multimode products, and therefore, we might not achieve the same licensing revenues on such LTE products as on 3G and 3G/4G multimode products. In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the connected home or the Internet of Things. We also seek to diversify and broaden our technology licensing programs to new industry segments in which we can utilize our technology leadership, such as wireless charging and other technologies. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties that are equivalent to those that we receive for 3G and 3G/4G multimode products used in

[0001234452-15-000208:mdna:138]
[same as prior period, unchanged from 0001234452-15-000134:mdna:143]

[0001234452-15-000208:mdna:139]
cellular communications. Although we believe that our patented technology is essential and useful to the commercialization of such services, the royalties we receive may be lower than those we receive from our current licensing program.

[0001234452-15-000208:mdna:140]
[same as prior period, unchanged from 0001234452-15-000134:mdna:130]

[0001234452-15-000208:mdna:141]
The licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date and, in a small number of agreements, royalties are payable on those patents for a specified time period. As a result, there are agreements with some licensees where later patents are not licensed by or to us and/or royalties are not owed to us under such license agreements after the specified time period. In order to license or to obtain a license to such later patents, or to receive royalties after the specified time period, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to modify those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in renewing a license agreement prior to its expiration, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001234452-15-000208:mdna:142]
[same as prior period, unchanged from 0001234452-15-000134:mdna:132]

[0001234452-15-000208:mdna:143]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, or some form of unfair competition; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the imposition of some form of compulsory licensing and/or to weaken a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies in attempts to shift their royalty obligation to their suppliers. In addition, particularly in China, certain licensees have disputed or underreported royalties owed to us under their license agreements with us, and certain companies have yet to enter into or delayed entering into license agreements with us for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future.

[0001234452-15-000208:mdna:144]
We are currently subject to various litigation and governmental investigations and/or proceedings, some of which may arise out of the strategies described above. Certain legal matters are described more fully in the notes to our condensed consolidated financial statements. See “Notes to Condensed Consolidated Financial Statements, Note 6 - Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or modify our business practices.

[0001234452-15-000208:mdna:145]
[same as prior period, unchanged from 0001234452-15-000134:mdna:135]

[0001234452-15-000208:mdna:146]
Further, some companies or entities have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the

[0001234452-15-000208:mdna:147]
selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions not be an available remedy for infringement of standard-essential patents and/or have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by severely limiting the base upon which the royalty percentage may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (and/or other companies’) alleged failure to abide by these policies.

[0001234452-15-000208:mdna:148]
[same as prior period, unchanged from 0001234452-15-000134:mdna:138]

[0001234452-15-000208:mdna:149]
[same as prior period, unchanged from 0001234452-15-000134:mdna:139]

[0001234452-15-000208:mdna:150]
[same as prior period, unchanged from 0001234452-15-000134:mdna:140]

[0001234452-15-000208:mdna:151]
[same as prior period, unchanged from 0001234452-15-000134:mdna:141]

[0001234452-15-000208:mdna:152]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property rights and/or contracts, including collecting royalties for use of our patent portfolio in particular foreign jurisdictions due to, among others: policies of foreign governments; challenges to our licensing practices under such jurisdictions’ competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and/or challenges pending before foreign competition agencies to the pricing and integration of additional features and functionality into our chipset products. Although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Particularly in China, certain licensees have disputed or underreported royalties owed to us under their license agreements with us, and certain companies have yet to enter into or delayed

[0001234452-15-000208:mdna:153]
[same as prior period, unchanged from 0001234452-15-000134:mdna:159]

[0001234452-15-000208:mdna:154]
entering into license agreements for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future.

[0001234452-15-000208:mdna:155]
We may need to litigate in the United States or elsewhere in the world to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable and/or we could incur substantial unexpected operating costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our operating results. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues in the period prior to conclusion.

[0001234452-15-000208:mdna:156]
[same as prior period, unchanged from 0001234452-15-000134:mdna:146]

[0001234452-15-000208:mdna:157]
[same as prior period, unchanged from 0001234452-15-000134:mdna:147]

[0001234452-15-000208:mdna:158]
We are currently subject to various governmental investigations and/or proceedings, and certain matters are described more fully in the notes to our condensed consolidated financial statements. See “Notes to Condensed Consolidated Financial Statements, Note 6 — Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices.

[0001234452-15-000208:mdna:159]
[same as prior period, unchanged from 0001234452-15-000134:mdna:149]

[0001234452-15-000208:mdna:160]
[same as prior period, unchanged from 0001234452-15-000134:mdna:150]

[0001234452-15-000208:mdna:161]
[same as prior period, unchanged from 0001234452-15-000134:mdna:151]

[0001234452-15-000208:mdna:162]
[same as prior period, unchanged from 0001234452-15-000134:mdna:152]

[0001234452-15-000208:mdna:163]
[same as prior period, unchanged from 0001234452-15-000134:mdna:153]

[0001234452-15-000208:mdna:164]
Our industry is subject to rapid technological change, evolving industry standards and frequent new product introductions, and we must make substantial research, development and other investments, such as acquisitions, in new

[0001234452-15-000208:mdna:165]
products, services and technologies to compete successfully. Technological innovations generally require significant research and development efforts before they are commercially viable. Our future growth depends, in part, upon our ability to utilize our technical and business expertise to succeed in adjacent industry segments. Accordingly, we intend to continue to make substantial investments in developing new products, services and technologies that we believe can create stand-alone value and/or contribute to the success of our existing businesses. However, it is possible that these initiatives will not be successful and/or will not result in meaningful revenues or generate operating income that meets expectations. While we continue to focus our development efforts primarily in support of 3G CDMA- and 4G OFDMA-based technologies, we innovate across a broad spectrum of opportunities to deploy new business models and enter into new industry segments by leveraging our existing technical and business expertise and/or through acquisitions. Our recent investment initiatives relate to, among others, small cell technology and addressing the challenge of meeting the increased demand for data; products for the connected home and the Internet of Things; automotive; networking; mobile computing; very high speed connectivity; data centers; mobile health; wireless charging; and machine learning, including robotics.

[0001234452-15-000208:mdna:166]
[same as prior period, unchanged from 0001234452-15-000134:mdna:155]

[0001234452-15-000208:mdna:167]
If we are unsuccessful in executing our Strategic Realignment Plan, our business and results of operations may be adversely affected.

[0001234452-15-000208:mdna:168]
On July 22, 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders. As part of this, among other actions, we are implementing a cost reduction plan to reduce our operating expenses from fiscal 2015 levels of $7.3 billion (adjusted for variable compensation) by approximately $1.1 billion through a series of targeted reductions across our businesses, particularly in our semiconductor business, QCT. We also plan to reduce annual share-based compensation grants in fiscal 2016 by approximately $300 million. We expect these cost initiatives to be fully implemented by the end of fiscal 2016. In connection with this plan, we expect to incur approximately $350 million to $450 million in restructuring and restructuring-related charges.

[0001234452-15-000208:mdna:169]
We cannot provide assurance that our Strategic Realignment Plan will be successful, that anticipated cost savings will be realized, that our operations, business and financial results will improve and/or that these efforts will not disrupt our operations (beyond what is intended). Our ability to achieve the anticipated cost savings and other benefits within the expected time frames is subject to many estimates and assumptions which are subject to significant economic, competitive and other uncertainties, some of which are beyond our control. Further, we may experience delays in the anticipated timing of these efforts and/or higher than expected or unanticipated costs in implementing them. Moreover, changes in the size, alignment or organization of our workforce could adversely affect employee morale and retention, relations with customers and business partners, our ability to develop and deliver products and services as anticipated and/or impair our ability to realize our current or future business and financial objectives. If we do not succeed in these efforts, if these efforts are more costly or time-consuming than expected, if our estimates and assumptions are not correct, if we experience delays or if other unforeseen events occur, our business and results of operations may be adversely affected.

[0001234452-15-000208:mdna:170]
[same as prior period, unchanged from 0001234452-15-000134:mdna:156]

[0001234452-15-000208:mdna:171]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe on another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products through a licensed supplier, we could be prohibited from making and selling such products or providing such services. In any potential

[0001234452-15-000208:mdna:172]
dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our operating results.

[0001234452-15-000208:mdna:173]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages, royalty payments and/or an injunction on the sale of certain of our integrated circuit products (and on the sale of our customers’ devices using such products). A negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our share of worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001234452-15-000208:mdna:174]
[same as prior period, unchanged from 0001234452-15-000134:mdna:161]

[0001234452-15-000208:mdna:175]
[same as prior period, unchanged from 0001234452-15-000134:mdna:162]

[0001234452-15-000208:mdna:176]
[same as prior period, unchanged from 0001234452-15-000134:mdna:163]

[0001234452-15-000208:mdna:177]
Achieving the anticipated benefits of business acquisitions depends in part upon our ability to integrate the acquired businesses in an efficient and effective manner. The integration of companies that have previously operated independently may result in significant challenges, including, among others: retaining key employees; successfully integrating new employees, business systems and technology; retaining customers and suppliers of the acquired business; consolidating research and development and/or supply operations; minimizing the diversion of management’s attention from ongoing business matters; and consolidating corporate and administrative infrastructures. We may not derive any commercial value from acquired technologies or products or from future technologies or products based on the acquired technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, or we may become subject to litigation. Additionally, we may not be successful in expanding into geographic regions and/or categories of products served by or adjacent to an acquired business or in addressing potential new opportunities that may arise out of the combination. In part due to our inexperience with technologies and/or products of and/or geographic regions served by acquired businesses, we may underestimate the costs and/or overestimate the benefits,

[0001234452-15-000208:mdna:178]
41

[0001234452-15-000208:mdna:179]
including product and other synergies and growth opportunities that we expect to realize, and we may not achieve them. If we do not achieve the anticipated benefits of business acquisitions, our results of operations may be adversely affected, and we may not enhance stockholder value by engaging in these transactions.

[0001234452-15-000208:mdna:180]
[same as prior period, unchanged from 0001234452-15-000134:mdna:165]

[0001234452-15-000208:mdna:181]
[same as prior period, unchanged from 0001234452-15-000134:mdna:166]

[0001234452-15-000208:mdna:182]
[same as prior period, unchanged from 0001234452-15-000134:mdna:167]

[0001234452-15-000208:mdna:183]
[same as prior period, unchanged from 0001234452-15-000134:mdna:168]

[0001234452-15-000208:mdna:184]
[same as prior period, unchanged from 0001234452-15-000134:mdna:169]

[0001234452-15-000208:mdna:185]
[same as prior period, unchanged from 0001234452-15-000134:mdna:170]

[0001234452-15-000208:mdna:186]
[same as prior period, unchanged from 0001234452-15-000134:mdna:171]

[0001234452-15-000208:mdna:187]
[same as prior period, unchanged from 0001234452-15-000134:mdna:172]

[0001234452-15-000208:mdna:188]
[same as prior period, unchanged from 0001234452-15-000134:mdna:173]

[0001234452-15-000208:mdna:189]
[same as prior period, unchanged from 0001234452-15-000134:mdna:174]

[0001234452-15-000208:mdna:190]
[same as prior period, unchanged from 0001234452-15-000134:mdna:175]

[0001234452-15-000208:mdna:191]
Our stock price and earnings have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and/or earnings include those identified throughout this “Risk Factors” section, volatility of the stock market in general and technology-based companies in particular, announcements

[0001234452-15-000208:mdna:192]
concerning us, our suppliers, our competitors or our customers and variations between our actual results or guidance and expectations of securities analysts, among others. Further, increased volatility in the financial markets and/or overall economic conditions may reduce the amounts that we realize in the future on our cash equivalents and/or marketable securities and may reduce our earnings as a result of any impairment charges that we record to reduce recorded values of marketable securities to their fair values.

[0001234452-15-000208:mdna:193]
In the past, securities class action litigation often has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we may be the target of securities litigation in the future. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources.

[0001234452-15-000208:mdna:194]
[same as prior period, unchanged from 0001234452-15-000134:mdna:178]

[0001234452-15-000208:mdna:195]
[same as prior period, unchanged from 0001234452-15-000134:mdna:179]

[0001234452-15-000208:mdna:196]
[same as prior period, unchanged from 0001234452-15-000134:mdna:180]

[0001234452-15-000208:mdna:197]
[same as prior period, unchanged from 0001234452-15-000134:mdna:181]

[0001234452-15-000208:mdna:198]
[same as prior period, unchanged from 0001234452-15-000134:mdna:182]

[0001234452-15-000208:mdna:199]
[same as prior period, unchanged from 0001234452-15-000134:mdna:183]

[0001234452-15-000208:mdna:200]
[same as prior period, unchanged from 0001234452-15-000134:mdna:184]

[0001234452-15-000208:mdna:201]
[same as prior period, unchanged from 0001234452-15-000134:mdna:185]

[0001234452-15-000208:mdna:202]
Our future success depends largely upon the continued service of our executive officers and other key management and technical personnel and on our ability to continue to identify, attract, retain and motivate them, particularly in an environment of cost reductions, including equity compensation and headcount. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. The market for employees in our industry is extremely competitive. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001234452-15-000208:mdna:203]
[same as prior period, unchanged from 0001234452-15-000134:mdna:187]

[0001234452-15-000208:mdna:204]
[same as prior period, unchanged from 0001234452-15-000134:mdna:188]

[0001234452-15-000208:mdna:205]
[same as prior period, unchanged from 0001234452-15-000134:mdna:189]

[0001234452-15-000208:mdna:206]
[same as prior period, unchanged from 0001234452-15-000134:mdna:190]

[0001234452-15-000208:mdna:207]
[same as prior period, unchanged from 0001234452-15-000134:mdna:191]

[0001234452-15-000208:mdna:208]
[same as prior period, unchanged from 0001234452-15-000134:mdna:192]

[0001234452-15-000208:mdna:209]
[same as prior period, unchanged from 0001234452-15-000134:mdna:193]

[0001234452-15-000208:mdna:210]
[same as prior period, unchanged from 0001234452-15-000134:mdna:194]

[0001234452-15-000208:mdna:211]
[same as prior period, unchanged from 0001234452-15-000134:mdna:195]

[0001234452-15-000208:mdna:212]
[same as prior period, unchanged from 0001234452-15-000134:mdna:196]

[0001234452-15-000208:mdna:213]
[same as prior period, unchanged from 0001234452-15-000134:mdna:197]

[0001234452-15-000208:mdna:214]
[same as prior period, unchanged from 0001234452-15-000134:mdna:198]

[0001234452-15-000208:mdna:215]
44

[0001234452-15-000208:mdna:216]
[same as prior period, unchanged from 0001234452-15-000134:mdna:199]

[0001234452-15-000208:mdna:217]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-United States headquarters is located. Significant judgment is required in determining our provision for income taxes. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related litigation could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision and results of operations in the period or periods in which that determination is made could be negatively affected.

[0001234452-15-000208:mdna:218]
[same as prior period, unchanged from 0001234452-15-000134:mdna:201]

[0001234452-15-000208:mdna:219]
[same as prior period, unchanged from 0001234452-15-000134:mdna:202]
