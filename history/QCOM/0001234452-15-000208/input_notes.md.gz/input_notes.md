# QCOM notes — 0001234452-15-000208


## qcom:CompositionOfCertainFinancialStatementCaptionsTextBlock

[0001234452-15-000208:notes:1]
[same as prior period, unchanged from 0001234452-15-000134:notes:1]

[0001234452-15-000208:notes:2]
| Inventories (in millions) |  |  |  |
|  | June 28, 2015 |  | September 28, 2014 |
| Raw materials | $ | 1 |  |  | $ | 1 |  |
| Work-in-process | 755 |  |  | 656 |  |
| Finished goods | 827 |  |  | 801 |  |
|  | $ | 1,583 |  |  | $ | 1,458 |  |

[0001234452-15-000208:notes:3]
| Other Current Liabilities (in millions) |  |  |  |
|  | June 28, 2015 |  | September 28, 2014 |
| Customer incentives and other customer-related liabilities | $ | 1,843 |  |  | $ | 1,777 |  |
| Other | 451 |  |  | 466 |  |
|  | $ | 2,294 |  |  | $ | 2,243 |  |

[0001234452-15-000208:notes:4]
Other Costs and Expenses

[0001234452-15-000208:notes:5]
On February 9, 2015, the Company announced that it had reached a resolution with the China National Development and Reform Commission (NDRC) regarding its investigation of the Company relating to China’s Anti-Monopoly Law (AML) and the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business. The NDRC issued an Administrative Sanction Decision finding that the Company had violated the AML, and the Company agreed to implement a rectification plan that modifies certain of its business practices in China. In addition, the NDRC imposed a fine on the Company of 6.088 billion Chinese Yuan Renminbi (approximately $975 million), which the Company has paid. The Company recorded the amount of the fine in the second quarter of fiscal 2015 in other expenses. Other expenses in the nine months ended June 28, 2015 also included $255 million and $11 million in impairment charges on goodwill and intangible assets, respectively, related to our content and push-to-talk services and display businesses.

[0001234452-15-000208:notes:6]
Other expenses in the first nine months of fiscal 2014 were comprised of $607 million in certain property, plant and equipment and goodwill impairment charges related to one of our display businesses and a $16 million goodwill impairment charge related to our former QRS division, partially offset by the reversal of the $173 million accrual recorded in fiscal 2013 related to the ParkerVision verdict (Note 6).

[0001234452-15-000208:notes:7]
| Investment Income, Net (in millions) |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | June 28, 2015 |  | June 29, 2014 |
| Interest and dividend income | $ | 128 |  |  | $ | 139 |  |  | $ | 400 |  |  | $ | 460 |  |
| Interest expense | (32 | ) |  | — |  |  | (34 | ) |  | (4 | ) |
| Net realized gains on marketable securities | 117 |  |  | 290 |  |  | 381 |  |  | 660 |  |
| Net realized gains on other investments | 5 |  |  | 8 |  |  | 18 |  |  | 25 |  |
| Impairment losses on marketable securities | (42 | ) |  | (8 | ) |  | (131 | ) |  | (149 | ) |
| Impairment losses on other investments | (13 | ) |  | (3 | ) |  | (30 | ) |  | (21 | ) |
| Net gains (losses) on derivative instruments | 10 |  |  | (6 | ) |  | 16 |  |  | (1 | ) |
| Equity in net losses of investees | (10 | ) |  | (2 | ) |  | (23 | ) |  | (7 | ) |
| Net gains on deconsolidation of subsidiaries | — |  |  | 4 |  |  | 3 |  |  | 5 |  |
|  | $ | 163 |  |  | $ | 422 |  |  | $ | 600 |  |  | $ | 968 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001234452-15-000208:notes:8]
Note 8 — Acquisitions

[0001234452-15-000208:notes:9]
In October 2014, the Company announced that it had reached agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.4 billion based upon an exchange rate of USD: GBP 1.5634). CSR is an innovator in the development of multifunction semiconductor platforms and technologies for the automotive, consumer and voice and music categories. The acquisition complements the Company’s current offerings by adding products, channels and customers in the growth categories of the Internet of Everything and automotive infotainment, accelerating the Company’s presence and path to leadership. The acquisition has received approval of CSR’s shareholders, and every required regulatory agency has either provided formal written approval or declined to exercise jurisdiction, except for the Ministry of Commerce in China. The completion of the acquisition remains subject to satisfaction of additional conditions. Subject to the satisfaction of these conditions, the acquisition is expected to close by the end of the summer of 2015. In connection with the pending acquisition, the Company agreed to set aside certain cash, cash equivalents and marketable securities (Note 11).


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001234452-15-000208:notes:10]
Note 6 — Commitments and Contingencies

[0001234452-15-000208:notes:11]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit heard the appeal on May 8, 2015 and will issue a decision sometime in the coming months. On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision now alleges that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. The Company was served with the complaint in this second action on August 28, 2014 and answered on November 17, 2014. The judge’s schedule sets the claim construction hearing for August 12, 2015, the close of discovery for January 2016 and the trial for August 2016.

[0001234452-15-000208:notes:12]
Nvidia Corporation v. QUALCOMM Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd., and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chipset products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District of Delaware complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. On April 2, 2015, the Administrative Law Judge in the ITC investigation issued a claim construction order construing seven claim terms from five of the seven asserted patents. The evidentiary hearing for the investigation was held from June 22 to June 26, 2015. Nvidia withdrew the ITC complaint with respect to four of the patents, but is moving forward with infringement allegations with respect to three of the patents. The Initial Determination of the Administrative Law Judge is due October 9, 2015, and the target date for completion of the investigation by the ITC is set for February 10, 2016. The district court case was stayed on October 23, 2014 pending completion of the ITC investigation including appeals.

[0001234452-15-000208:notes:13]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. The Commission is investigating “alleged practices in the form of predatory pricing on certain UMTS standard-compliant chipsets used to deliver cellular mobile broadband access.” The initiation of proceedings merely means that the Commission will deal with the case as a matter of priority. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that none of the business practices under investigation are in breach of the EU competition rules and will continue to cooperate with the Commission.

[0001234452-15-000208:notes:14]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments during fiscal 2015 with respect to this matter.

[0001234452-15-000208:notes:15]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 27 different dates, with the next hearing scheduled for August 4, 2015.

[0001234452-15-000208:notes:16]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). As discussed below, FCPA compliance is also the focus of the SEC investigation. The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee has completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.

[0001234452-15-000208:notes:17]
As previously disclosed, the Company discovered, and as a part of its cooperation with these investigations informed the SEC and the DOJ of, instances in which special hiring consideration, gifts or other benefits (collectively, benefits) were provided to several individuals associated with Chinese state-owned companies or agencies. Based on the facts currently known, the Company believes the aggregate monetary value of the benefits in question to be less than $250,000, excluding employment compensation.

[0001234452-15-000208:notes:18]
On March 13, 2014, the Company received a Wells Notice from the SEC’s Los Angeles Regional Office indicating that the staff has made a preliminary determination to recommend that the SEC file an enforcement action against the Company for violations of the anti-bribery, books and records and internal control provisions of the FCPA. The bribery allegations relate to benefits offered or provided to individuals associated with Chinese state-owned companies or agencies. The Wells Notice indicated that the recommendation could involve a civil injunctive action and could seek remedies that include disgorgement of profits, the retention of an independent compliance monitor to review the Company’s FCPA policies and procedures, an injunction, civil monetary penalties and prejudgment interest.

[0001234452-15-000208:notes:19]
A Wells Notice is not a formal allegation or finding by the SEC of wrongdoing or violation of law. Rather, the purpose of a Wells Notice is to give the recipient an opportunity to make a “Wells submission” setting forth reasons why the proposed enforcement action should not be filed and/or bringing additional facts to the SEC’s attention before any decision is made by the SEC as to whether to commence a proceeding. On April 4, 2014 and May 29, 2014, the Company made Wells submissions to the staff of the Los Angeles Regional Office explaining why the Company believes it has not violated the FCPA and therefore enforcement action is not warranted.

[0001234452-15-000208:notes:20]
The Company is continuing to cooperate with the SEC and the DOJ, but is unable to predict the outcome of their investigations or any actions that the SEC or DOJ may decide to file.

[0001234452-15-000208:notes:21]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act. The FTC has notified the Company that it is investigating conduct related to standard essential patents and pricing and contracting practices with respect to baseband processors and related products. If a violation of Section 5 is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company continues to cooperate with the FTC as it conducts its investigation.

[0001234452-15-000208:notes:22]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. The Commission is investigating “alleged payments, rebates and/or other consideration granted by Qualcomm Incorporated or any of its affiliates and/or subsidiaries (Qualcomm) to smartphone and/or tablet manufacturers which are conditional upon the exclusive or quasi-exclusive use or purchase of Qualcomm products, in particular baseband chipsets, by the respective manufacturer(s).” The initiation of proceedings merely means that the Commission will deal with the case as a matter of priority. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that none of the business practices under investigation are in breach of the EU competition rules and will continue to cooperate with the Commission.

[0001234452-15-000208:notes:23]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it is conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA).  The Company understands that this investigation concerns primarily its licensing business. If a violation of the MRFTA is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine or requiring modifications to the Company’s licensing practices. Given that this investigation is in its early stages, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. The Company continues to cooperate with the KFTC as it conducts its investigation.

[0001234452-15-000208:notes:24]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at June 28, 2015 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001234452-15-000208:notes:25]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through June 28, 2015, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

[0001234452-15-000208:notes:26]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at June 28, 2015 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001234452-15-000208:notes:27]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at June 28, 2015 for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 were $2.2 billion, $1.2 billion, $921 million, $791 million and $721 million, respectively, and $175 million thereafter. Of these amounts, for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019, commitments to purchase integrated circuit product inventories comprised $1.8 billion, $1.0 billion, $771 million, $703 million and $651 million, respectively, and $152 million thereafter. Integrated circuit product inventory obligations represent purchase commitments for wafers, die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

[0001234452-15-000208:notes:28]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 16 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 are $23 million, $84 million, $64 million, $33 million and $21 million, respectively, and $16 million thereafter.

[0001234452-15-000208:notes:29]
Other Commitments. The Company is committed to fund certain strategic investments up to $197 million. Of this amount, $105 million will be funded in fiscal 2015. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.


## us-gaap:DebtDisclosureTextBlock

[0001234452-15-000208:notes:30]
Note 5 — Debt

[0001234452-15-000208:notes:31]
Revolving Credit Facility. In February 2015, the Company entered into a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. Proceeds from the Revolving Credit Facility will be used for general corporate purposes. Loans under the Revolving Credit Facility bear interest, at the option of the Company, at either LIBOR (determined in accordance with the Revolving Credit Facility) plus a margin of 0.7% per annum or the Base Rate (determined in accordance with the Revolving Credit Facility), plus an initial margin of 0% per annum. The Revolving Credit Facility has a facility fee, which initially accrues at a rate of 0.05% per annum. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At June 28, 2015, the Company was in compliance with the covenants, and the Company had not borrowed any funds under the Revolving Credit Facility.

[0001234452-15-000208:notes:32]
Commercial Paper Program. In March 2015, the Company began an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At June 28, 2015, the Company had $1.0 billion of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 0.14%, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 51 days. The carrying value of the outstanding commercial paper approximated its estimated fair value at June 28, 2015.

[0001234452-15-000208:notes:33]
Long-term Debt. In May 2015, the Company issued an aggregate principal amount of $10.0 billion of unsecured floating- and fixed-rate notes (the notes) with varying maturities. The proceeds from the notes of $9.9 billion, net of underwriting discounts and offering expenses, were used to fund the ASR Agreements (Note 4) and are also being used for other general corporate purposes. The following table provides a summary of the Company’s long-term debt as of June 28, 2015 (dollar amounts in millions):

[0001234452-15-000208:notes:34]
|  |  | PrincipalAmount |  | EffectiveInterest Rate |
| Floating-rate notes due May 18, 2018 |  | $ | 250 |  |  | 0.61% |
| Floating-rate notes due May 20, 2020 |  | 250 |  |  | 0.88% |
| Fixed-rate 1.40% notes due May 18, 2018 |  | 1,250 |  |  | 0.68% |
| Fixed-rate 2.25% notes due May 20, 2020 |  | 1,750 |  |  | 1.78% |
| Fixed-rate 3.00% notes due May 20, 2022 |  | 2,000 |  |  | 2.28% |
| Fixed-rate 3.45% notes due May 20, 2025 |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 |  | 1,500 |  |  | 4.71% |
| Total principal |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments |  | (22 | ) |  |  |
| Total long-term debt |  | $ | 9,913 |  |  |  |

[0001234452-15-000208:notes:35]
The interest rate on the floating rate notes due in 2018 and the floating rate notes due in 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At June 28, 2015, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $9.8 billion.

[0001234452-15-000208:notes:36]
The Company has entered, and may in the future enter, into interest rate swaps to manage interest rate risk on certain notes. Such swaps allow the Company to effectively convert fixed-rate payments into floating-rate payments. These transactions are designated as fair value hedges, and the gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. In the third quarter of fiscal 2015, the Company entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings as interest expense in the current period.

[0001234452-15-000208:notes:37]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and, if applicable, adjustments related to hedging. The Company recognized $30 million of interest expense on its long-term debt during the three and nine months ended June 28, 2015. The Company did not have any long-term debt outstanding in fiscal 2014.

[0001234452-15-000208:notes:38]
No principal payments are due on the Company’s notes prior to fiscal 2018. At June 28, 2015, future principal payments were $1.5 billion in fiscal 2018 and $8.5 billion after fiscal 2019; no principal payments were due in fiscal 2019.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001234452-15-000208:notes:39]
Note 9 — Discontinued Operations

[0001234452-15-000208:notes:40]
[same as prior period, unchanged from 0001234452-15-000134:notes:33]


## us-gaap:DividendsDeclaredTableTextBlock

[0001234452-15-000208:notes:41]
During the nine months ended June 28, 2015 and June 29, 2014, dividends charged to retained earnings were as follows (in millions, except per share data):

[0001234452-15-000208:notes:42]
|  | 2015 |  | 2014 |
|  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.42 |  |  | $ | 710 |  |  | $ | 0.35 |  |  | $ | 599 |  |
| Second quarter | 0.42 |  |  | 702 |  |  | 0.35 |  |  | 599 |  |
| Third quarter | 0.48 |  |  | 771 |  |  | 0.42 |  |  | 718 |  |
|  | $ | 1.32 |  |  | $ | 2,183 |  |  | $ | 1.12 |  |  | $ | 1,916 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001234452-15-000208:notes:43]
Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 28, 2015 were 20,749,000 and 22,447,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 29, 2014 were 30,642,000 and 31,985,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 16,711,000 and 6,067,000 during the three and nine months ended June 28, 2015, respectively, which were primarily attributable to the ASR Agreements (Note 4), and 7,000 and 278,000 during the three and nine months ended June 29, 2014, respectively


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001234452-15-000208:notes:44]
[same as prior period, unchanged from 0001234452-15-000134:notes:37]

[0001234452-15-000208:notes:45]
|  | Nine Months Ended June 28, 2015 |  | Nine Months Ended June 29, 2014 |
|  | Auction RateSecurities |  | Mortgage- and Asset-BackedSecurities |  | Auction RateSecurities |  | Mortgage- and Asset-BackedSecurities |
| Beginning balance of Level 3 | $ | 83 |  |  | $ | 186 |  |  | $ | 83 |  |  | $ | 239 |  |
| Total realized and unrealized gains or losses: |  |  |  |  |  |  |  |
| Included in investment income, net | — |  |  | 3 |  |  | — |  |  | 10 |  |
| Included in other comprehensive income | — |  |  | (4 | ) |  | — |  |  | (4 | ) |
| Purchases | — |  |  | 62 |  |  | — |  |  | 86 |  |
| Sales | — |  |  | (46 | ) |  | — |  |  | (124 | ) |
| Settlements | (37 | ) |  | (20 | ) |  | — |  |  | (28 | ) |
| Transfers out of Level 3 | — |  |  | — |  |  | — |  |  | (2 | ) |
| Ending balance of Level 3 | $ | 46 |  |  | $ | 181 |  |  | $ | 83 |  |  | $ | 177 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001234452-15-000208:notes:46]
Note 10 — Fair Value Measurements

[0001234452-15-000208:notes:47]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at June 28, 2015 (in millions):

[0001234452-15-000208:notes:48]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 5,207 |  |  | $ | 4,465 |  |  | $ | — |  |  | $ | 9,672 |  |
| Marketable securities (a) |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 44 |  |  | 1,137 |  |  | — |  |  | 1,181 |  |
| Corporate bonds and notes | — |  |  | 16,272 |  |  | — |  |  | 16,272 |  |
| Mortgage- and asset-backed securities | — |  |  | 1,584 |  |  | 181 |  |  | 1,765 |  |
| Auction rate securities | — |  |  | — |  |  | 46 |  |  | 46 |  |
| Common and preferred stock | 753 |  |  | 683 |  |  | — |  |  | 1,436 |  |
| Equity funds | 496 |  |  | — |  |  | — |  |  | 496 |  |
| Debt funds | — |  |  | 4,042 |  |  | — |  |  | 4,042 |  |
| Total marketable securities | 1,293 |  |  | 23,718 |  |  | 227 |  |  | 25,238 |  |
| Derivative instruments | 2 |  |  | 7 |  |  | — |  |  | 9 |  |
| Other investments (a) | 356 |  |  | — |  |  | — |  |  | 356 |  |
| Total assets measured at fair value | $ | 6,858 |  |  | $ | 28,190 |  |  | $ | 227 |  |  | $ | 35,275 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |
| Other liabilities | 310 |  |  | — |  |  | — |  |  | 310 |  |
| Total liabilities measured at fair value | $ | 310 |  |  | $ | 23 |  |  | $ | — |  |  | $ | 333 |  |

[0001234452-15-000208:notes:49]
(a) Included amounts that are restricted (Note 11).

[0001234452-15-000208:notes:50]
Activity between Levels of the Fair Value Hierarchy. There were no significant transfers between Level 1 and Level 2 during the nine months ended June 28, 2015 and June 29, 2014. When a determination is made to classify an asset or liability within Level 3, the determination is based upon the significance of the unobservable inputs to the overall fair value measurement. The following table includes the activity for marketable securities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-15-000208:notes:51]
The Company recognizes transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. There were no transfers in or out of Level 3 during the nine months ended June 28, 2015. Transfers out of Level 3 during the nine months ended June 29, 2014 primarily consisted of debt securities with significant upgrades in credit ratings.

[0001234452-15-000208:notes:52]
Nonrecurring Fair Value Measurements. The Company measures certain assets at fair value on a nonrecurring basis. These assets include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During the nine months ended June 28, 2015 and June 29, 2014, the Company updated the business plans and related internal forecasts related to certain of the Company’s businesses, resulting in impairment charges to write down certain property, plant and equipment, intangible assets and goodwill (Note 2). The Company determined the fair values using cost, income and market approaches. The estimation of fair value and cash flows used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During the nine months ended June 28, 2015 and June 29, 2014, the Company did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001234452-15-000208:notes:53]
Note 3 — Income Taxes

[0001234452-15-000208:notes:54]
The Company estimates its annual effective income tax rate for continuing operations to be approximately 19% for fiscal 2015, which is greater than its 14% effective income tax rate for fiscal 2014. Tax benefits from foreign income taxed at rates lower than rates in the United States are expected to be approximately 19% in fiscal 2015, compared to 20% in fiscal 2014.

[0001234452-15-000208:notes:55]
The effective tax rate of 15% for the third quarter of fiscal 2015 was less than the estimated annual effective tax rate of 19% primarily resulting from an increase in the allocation of expenses to the Company’s United States operations.

[0001234452-15-000208:notes:56]
During the second quarter of fiscal 2015, the NDRC imposed a $975 million fine on the Company (Note 2). The fine is not deductible for tax purposes. Given the significant unusual nature of the fine, it was accounted for discretely in the second quarter of fiscal 2015. Also, during the second quarter of fiscal 2015, the Company recorded a $61 million tax benefit as a result of a favorable tax audit settlement with the Internal Revenue Service related to Qualcomm Atheros, Inc.’s pre-acquisition 2010 and 2011 tax returns.

[0001234452-15-000208:notes:57]
[same as prior period, unchanged from 0001234452-15-000134:notes:49]


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001234452-15-000208:notes:58]
At June 28, 2015, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001234452-15-000208:notes:59]
| Years to Maturity |  |  |  |  |
| Less Than One Year |  | One to Five Years |  | Five to Ten Years |  | Greater Than Ten Years |  | No Single Maturity Date |  | Total |
| $ | 3,750 |  |  | $ | 11,156 |  |  | $ | 1,005 |  |  | $ | 641 |  |  | $ | 4,812 |  |  | $ | 21,364 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001234452-15-000208:notes:60]
Note 11 — Marketable Securities

[0001234452-15-000208:notes:61]
Marketable securities were comprised as follows (in millions):

[0001234452-15-000208:notes:62]
|  | Current |  | Noncurrent |
|  | June 28, 2015 |  | September 28, 2014 |  | June 28, 2015 |  | September 28, 2014 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 329 |  |  | $ | 320 |  |  | $ | 6 |  |  | $ | 38 |  |
| Corporate bonds and notes | 187 |  |  | 191 |  |  | 379 |  |  | 367 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 252 |  |  | 237 |  |
| Total trading | 516 |  |  | 511 |  |  | 637 |  |  | 642 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 138 |  |  | 805 |  |  | 708 |  |  | 392 |  |
| Corporate bonds and notes | 8,628 |  |  | 6,274 |  |  | 7,078 |  |  | 7,649 |  |
| Mortgage- and asset-backed securities | 1,297 |  |  | 1,063 |  |  | 216 |  |  | 195 |  |
| Auction rate securities | — |  |  | — |  |  | 46 |  |  | 83 |  |
| Common and preferred stock | 550 |  |  | 192 |  |  | 886 |  |  | 1,605 |  |
| Equity funds | — |  |  | — |  |  | 496 |  |  | 541 |  |
| Debt funds | 215 |  |  | 813 |  |  | 3,038 |  |  | 2,560 |  |
| Total available-for-sale | 10,828 |  |  | 9,147 |  |  | 12,468 |  |  | 13,025 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 789 |  |  | 790 |  |
| Total marketable securities | $ | 11,344 |  |  | $ | 9,658 |  |  | $ | 13,894 |  |  | $ | 14,457 |  |

[0001234452-15-000208:notes:63]
In connection with the pending acquisition of CSR (Note 8), the Company agreed to set aside certain cash, cash equivalents and marketable securities to be held for purposes of satisfying payment of the consideration to effect the acquisition, which is expected to close by the end of the summer of 2015. At June 28, 2015, the fair values of the marketable securities that were set aside were $2.9 billion of corporate bonds and notes, $790 million of mortgage- and asset-backed securities and $79 million in U.S. Treasury securities and government-related securities. Additionally, $47 million in cash equivalents, which were recorded as other current assets, were set aside. If the combined fair values fall below approximately £1.9 billion (approximately $2.9 billion using an exchange rate of USD: GBP 1.5634), the Company may be required to set aside additional amounts. Additionally, if certain conditions are met, such as a reduction in the liquidity of any of the securities that are set aside, the Company may be required to liquidate the securities and transfer the cash to a third party until the acquisition closes.

[0001234452-15-000208:notes:64]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At June 28, 2015, the Company had an effective ownership interest in the debt fund of 25%. Changes in fair value associated with this investment are recognized in net investment income. During the three and nine months ended June 28, 2015, the changes in fair value associated with this investment were negligible. During the three and nine months ended June 29, 2014, net increases in fair value associated with this investment were $12 million and $30 million, respectively.

[0001234452-15-000208:notes:65]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains recognized on debt securities classified as trading held at June 28, 2015 were negligible for both the three and nine months ended June 28, 2015. Net gains recognized on debt securities classified as trading held at June 29, 2014 were negligible for both the three and nine months ended June 29, 2014.

[0001234452-15-000208:notes:66]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities, auction rate securities and corporate bonds and notes.

[0001234452-15-000208:notes:67]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001234452-15-000208:notes:68]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| June 28, 2015 | $ | 126 |  |  | $ | (10 | ) |  | $ | 116 |  |
| June 29, 2014 | 267 |  |  | (8 | ) |  | 259 |  |
| For the nine months ended |  |  |  |  |  |
| June 28, 2015 | $ | 434 |  |  | $ | (48 | ) |  | $ | 386 |  |
| June 29, 2014 | 610 |  |  | (16 | ) |  | 594 |  |

[0001234452-15-000208:notes:69]
Available-for-sale securities were comprised as follows (in millions):

[0001234452-15-000208:notes:70]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| June 28, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,543 |  |  | $ | 391 |  |  | $ | (2 | ) |  | $ | 1,932 |  |
| Debt securities (including debt funds) | 21,203 |  |  | 253 |  |  | (92 | ) |  | 21,364 |  |
|  | $ | 22,746 |  |  | $ | 644 |  |  | $ | (94 | ) |  | $ | 23,296 |  |
| September 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,769 |  |  | $ | 575 |  |  | $ | (6 | ) |  | $ | 2,338 |  |
| Debt securities (including debt funds) | 19,582 |  |  | 312 |  |  | (60 | ) |  | 19,834 |  |
|  | $ | 21,351 |  |  | $ | 887 |  |  | $ | (66 | ) |  | $ | 22,172 |  |

[0001234452-15-000208:notes:71]
The following table shows the gross unrealized losses and fair values of the Company’s investments in individual securities that are classified as available-for-sale and have been in a continuous unrealized loss position deemed to be temporary for less than 12 months and for more than 12 months, aggregated by investment category (in millions):

[0001234452-15-000208:notes:72]
|  | June 28, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 313 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 7,413 |  |  | (59 | ) |  | 142 |  |  | (9 | ) |
| Mortgage- and asset-backed securities | 874 |  |  | (2 | ) |  | 16 |  |  | — |  |
| Auction rate securities | — |  |  | — |  |  | 46 |  |  | (1 | ) |
| Common and preferred stock | 155 |  |  | (2 | ) |  | 18 |  |  | — |  |
| Debt funds | 934 |  |  | (18 | ) |  | 47 |  |  | (1 | ) |
|  | $ | 9,689 |  |  | $ | (83 | ) |  | $ | 269 |  |  | $ | (11 | ) |

[0001234452-15-000208:notes:73]
|  | September 28, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 279 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,924 |  |  | (31 | ) |  | 104 |  |  | (4 | ) |
| Mortgage- and asset-backed securities | 484 |  |  | (1 | ) |  | 52 |  |  | (1 | ) |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Common and preferred stock | 86 |  |  | (3 | ) |  | 52 |  |  | (3 | ) |
| Debt funds | 133 |  |  | (1 | ) |  | 384 |  |  | (19 | ) |
|  | $ | 5,906 |  |  | $ | (38 | ) |  | $ | 675 |  |  | $ | (28 | ) |

[0001234452-15-000208:notes:74]
At June 28, 2015, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

[0001234452-15-000208:notes:75]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company were negligible at June 28, 2015 and June 29, 2014, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001234452-15-000208:notes:76]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for the Company starting in the first quarter of fiscal 2019. The FASB will also permit entities to adopt one year earlier if they choose (i.e., the original effective date). The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the standard early and is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001234452-15-000208:notes:77]
[same as prior period, unchanged from 0001234452-15-000134:notes:72]

[0001234452-15-000208:notes:78]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 28, 2014. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 28, 2015 and June 29, 2014 included 13 weeks and 39 weeks, respectively.

[0001234452-15-000208:notes:79]
[same as prior period, unchanged from 0001234452-15-000134:notes:74]

[0001234452-15-000208:notes:80]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 28, 2015 were 20,749,000 and 22,447,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 29, 2014 were 30,642,000 and 31,985,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 16,711,000 and 6,067,000 during the three and nine months ended June 28, 2015, respectively, which were primarily attributable to the ASR Agreements (Note 4), and 7,000 and 278,000 during the three and nine months ended June 29, 2014, respectively.

[0001234452-15-000208:notes:81]
[same as prior period, unchanged from 0001234452-15-000134:notes:76]

[0001234452-15-000208:notes:82]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | June 28, 2015 |  | June 29, 2014 |
| Cost of equipment and services revenues | $ | 10 |  |  | $ | 12 |  |  | $ | 33 |  |  | $ | 37 |  |
| Research and development | 176 |  |  | 174 |  |  | 508 |  |  | 510 |  |
| Selling, general and administrative | 85 |  |  | 88 |  |  | 252 |  |  | 259 |  |
| Share-based compensation expense before income taxes | 271 |  |  | 274 |  |  | 793 |  |  | 806 |  |
| Related income tax benefit | (58 | ) |  | (42 | ) |  | (145 | ) |  | (151 | ) |
|  | $ | 213 |  |  | $ | 232 |  |  | $ | 648 |  |  | $ | 655 |  |

[0001234452-15-000208:notes:83]
The Company recorded $173 million and $177 million in share-based compensation expense during the nine months ended June 28, 2015 and June 29, 2014, respectively, related to share-based awards granted during those periods. At June 28, 2015, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.5 billion, which is expected to be recognized over a weighted-average period of 2.0 years. During the nine months ended June 28, 2015 and June 29, 2014, net share-based awards granted, after forfeitures and cancelations, represented 0.8% of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.9% of outstanding shares as of the end of each fiscal period.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001234452-15-000208:notes:84]
[same as prior period, unchanged from 0001234452-15-000134:notes:79]

[0001234452-15-000208:notes:85]
|  | June 28, 2015 |  | September 28, 2014 |
| QCT | $ | 2,977 |  |  | $ | 3,639 |  |
| QTL | 522 |  |  | 161 |  |
| QSI | 697 |  |  | 484 |  |
| Reconciling items | 48,099 |  |  | 44,290 |  |
| Total consolidated assets | $ | 52,295 |  |  | $ | 48,574 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001234452-15-000208:notes:86]
[same as prior period, unchanged from 0001234452-15-000134:notes:83]

[0001234452-15-000208:notes:87]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | June 28, 2015 |  | June 29, 2014 |
| Cost of equipment and services revenues | $ | 55 |  |  | $ | 62 |  |  | $ | 184 |  |  | $ | 186 |  |
| Research and development expenses | 3 |  |  | 3 |  |  | 11 |  |  | 26 |  |
| Selling, general and administrative expenses | 20 |  |  | 6 |  |  | 45 |  |  | 19 |  |

[0001234452-15-000208:notes:88]
[same as prior period, unchanged from 0001234452-15-000134:notes:81]

[0001234452-15-000208:notes:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 28, 2015 |  | June 29, 2014 |  | June 28, 2015 |  | June 29, 2014 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 49 |  |  | $ | 47 |  |  | $ | 138 |  |  | $ | 208 |  |
| Intersegment eliminations | (1 | ) |  | (1 | ) |  | (4 | ) |  | (3 | ) |
|  | $ | 48 |  |  | $ | 46 |  |  | $ | 134 |  |  | $ | 205 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of equipment and services revenues | $ | (65 | ) |  | $ | (74 | ) |  | $ | (217 | ) |  | $ | (223 | ) |
| Unallocated research and development expenses | (188 | ) |  | (220 | ) |  | (624 | ) |  | (653 | ) |
| Unallocated selling, general and administrative expenses | (93 | ) |  | (107 | ) |  | (342 | ) |  | (318 | ) |
| Unallocated other (expense) income | (142 | ) |  | 184 |  |  | (1,221 | ) |  | 173 |  |
| Unallocated investment income, net | 193 |  |  | 413 |  |  | 655 |  |  | 985 |  |
| Nonreportable segments | (201 | ) |  | (364 | ) |  | (512 | ) |  | (1,218 | ) |
| Intersegment eliminations | — |  |  | — |  |  | (1 | ) |  | — |  |
|  | $ | (496 | ) |  | $ | (168 | ) |  | $ | (2,262 | ) |  | $ | (1,254 | ) |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001234452-15-000208:notes:90]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity during the nine months ended June 28, 2015 were as follows (in millions):

[0001234452-15-000208:notes:91]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Total Accumulated Other Comprehensive Income |
| Balance at September 28, 2014 | $ | (113 | ) |  | $ | 24 |  |  | $ | 723 |  |  | $ | — |  |  | $ | 634 |  |
| Other comprehensive (loss) income before reclassifications | (25 | ) |  | (12 | ) |  | 14 |  |  | 58 |  |  | 35 |  |
| Reclassifications from accumulated other comprehensive income | — |  |  | 6 |  |  | (172 | ) |  | — |  |  | (166 | ) |
| Other comprehensive (loss) income | (25 | ) |  | (6 | ) |  | (158 | ) |  | 58 |  |  | (131 | ) |
| Balance at June 28, 2015 | $ | (138 | ) |  | $ | 18 |  |  | $ | 565 |  |  | $ | 58 |  |  | $ | 503 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001234452-15-000208:notes:92]
[same as prior period, unchanged from 0001234452-15-000134:notes:87]

[0001234452-15-000208:notes:93]
|  | QCT |  | QTL |  | QSI |  | ReconcilingItems |  | Total |
| For the three months ended |  |  |  |  |  |  |  |  |  |
| June 28, 2015 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 3,853 |  |  | $ | 1,931 |  |  | $ | — |  |  | $ | 48 |  |  | $ | 5,832 |  |
| EBT | 289 |  |  | 1,654 |  |  | (49 | ) |  | (496 | ) |  | 1,398 |  |
| June 29, 2014 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 4,957 |  |  | $ | 1,803 |  |  | $ | — |  |  | $ | 46 |  |  | $ | 6,806 |  |
| EBT | 1,116 |  |  | 1,550 |  |  | (1 | ) |  | (168 | ) |  | 2,497 |  |
| For the nine months ended |  |  |  |  |  |  |  |  |  |
| June 28, 2015 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 13,529 |  |  | $ | 6,162 |  |  | $ | — |  |  | $ | 134 |  |  | $ | 19,825 |  |
| EBT | 2,185 |  |  | 5,395 |  |  | (82 | ) |  | (2,262 | ) |  | 5,236 |  |
| June 29, 2014 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 13,816 |  |  | $ | 5,774 |  |  | $ | — |  |  | $ | 205 |  |  | $ | 19,795 |  |
| EBT | 2,762 |  |  | 5,054 |  |  | (36 | ) |  | (1,254 | ) |  | 6,526 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001234452-15-000208:notes:94]
Changes in stockholders’ equity for the nine months ended June 28, 2015 were as follows (in millions):

[0001234452-15-000208:notes:95]
|  | Qualcomm Stockholders’ Equity |  | Noncontrolling Interests |  | Total Stockholders’ Equity |
| Balance at September 28, 2014 | $ | 39,169 |  |  | $ | (3 | ) |  | $ | 39,166 |  |
| Net income (loss) | 4,209 |  |  | (2 | ) |  | 4,207 |  |
| Other comprehensive loss | (131 | ) |  | — |  |  | (131 | ) |
| Common stock issued under employee benefit plans and related tax benefits | 657 |  |  | — |  |  | 657 |  |
| Share-based compensation | 834 |  |  | — |  |  | 834 |  |
| Tax withholdings related to vesting of share-based payments | (336 | ) |  | — |  |  | (336 | ) |
| Dividends | (2,183 | ) |  | — |  |  | (2,183 | ) |
| Stock repurchases | (9,016 | ) |  | — |  |  | (9,016 | ) |
| Other | (1 | ) |  | (1 | ) |  | (2 | ) |
| Balance at June 28, 2015 | $ | 33,202 |  |  | $ | (6 | ) |  | $ | 33,196 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001234452-15-000208:notes:96]
Note 7 — Segment Information

[0001234452-15-000208:notes:97]
The Company is organized on the basis of products and services. The Company conducts business primarily through two reportable segments: QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing), and its QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. The Company also has nonreportable segments, including its small cells, data center and other wireless technology and service initiatives.

[0001234452-15-000208:notes:98]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT) from continuing operations. Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization and impairment of certain intangible assets and certain other acquisition-related charges, and beginning in the first quarter of fiscal 2015, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. The table below presents revenues and EBT for reportable segments (in millions):

[0001234452-15-000208:notes:99]
[same as prior period, unchanged from 0001234452-15-000134:notes:94]

[0001234452-15-000208:notes:100]
Unallocated other expense for the nine months ended June 28, 2015 included a $975 million charge related to the resolution reached with the NDRC and charges of $235 million and $11 million for impairment of goodwill and intangible assets, respectively, related to three of the Company’s nonreportable segments (Note 2). Nonreportable segments EBT for the nine months ended June 29, 2014 included $607 million in impairment charges related to property, plant and equipment and goodwill (Note 2).

[0001234452-15-000208:notes:101]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets include certain marketable securities, notes receivable, wireless spectrum, other investments and all assets of consolidated subsidiaries included in QSI. Total segment assets differ from total assets on a consolidated basis as a result of unallocated assets primarily comprised of certain cash, cash equivalents, marketable securities, property, plant and equipment, deferred tax assets, goodwill, other intangible assets and assets of nonreportable segments. Segment assets and reconciling items were as follows (in millions):


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001234452-15-000208:notes:102]
Note 4 — Stockholders’ Equity

[0001234452-15-000208:notes:103]
In the third quarter of fiscal 2015, the Company entered into U.S. Treasury rate locks in anticipation of its debt offering (Note 5), which were designated as cash flow hedges. This resulted in the deferral of gains of $56 million in accumulated other comprehensive income, which will be recognized over the 10- and 30-year lives of the underlying notes associated with the U.S. Treasury rate locks. Reclassifications from accumulated other comprehensive income related to available-for-sale securities and foreign currency translation adjustments of $48 million and $166 million for the three and nine months ended June 28, 2015, respectively, and $163 million and $287 million for the three and nine months ended June 29, 2014, respectively, were recorded in investment income, net (Note 2). Reclassifications from accumulated other comprehensive income related to derivative instruments of $7 million and $20 million for the three and nine months ended June 29, 2014, respectively, were recorded in revenues, cost of equipment and services revenues, research and development expenses and selling, general and administrative expenses.

[0001234452-15-000208:notes:104]
Stock Repurchase Program. On March 9, 2015, the Company announced a stock repurchase program authorizing it to repurchase up to $15 billion of the Company’s common stock. The stock repurchase program has no expiration date.

[0001234452-15-000208:notes:105]
In May 2015, the Company entered into two accelerated share repurchase agreements (ASR Agreements) with two financial institutions under which the Company paid an aggregate of $5.0 billion upfront to the financial institutions and received from them an initial delivery of 57,737,000 shares of the Company’s common stock, which were retired and recorded as a $4.0 billion reduction to stockholders’ equity. The final number of shares to be repurchased will be based on the volume-weighted average stock price of the Company’s common stock during the terms of the transactions, less a discount and subject to adjustments pursuant to the terms and conditions of the ASR Agreements, and will also be retired upon delivery to the Company and recorded as a reduction to stockholders’ equity. This is evaluated as an unsettled forward contract indexed to the Company’s own stock, with $1.0 billion classified within stockholders’ equity. At settlement, under certain circumstances, one or both of the financial institutions may be required to deliver additional shares of common stock to the Company, or under certain circumstances, the Company may be required to deliver shares of common stock or to make a cash payment to one or both of the financial institutions, with the method of settlement at the Company’s election. The final settlement of the transactions under the ASR Agreements is scheduled to occur in November 2015 but may occur earlier in certain circumstances.

[0001234452-15-000208:notes:106]
During the nine months ended June 28, 2015 and June 29, 2014, the Company repurchased and retired an additional 56,652,000 and 44,609,000 shares of common stock, respectively, for $4.0 billion and $3.4 billion, respectively, before commissions. To reflect share repurchases in the condensed consolidated balance sheet, the Company (i) reduces common stock for the par value of the shares, (ii) reduces paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) records the residual amount to retained earnings. At June 28, 2015, $9.1 billion remained authorized for repurchase under the Company’s stock repurchase program. Since June 28, 2015, the Company repurchased and retired 8,018,000 shares of common stock for $510 million.

[0001234452-15-000208:notes:107]
Dividends. On July 7, 2015, the Company announced a cash dividend of $0.48 per share on the Company’s common stock, payable on September 23, 2015 to stockholders of record as of the close of business on September 2, 2015. During the nine months ended June 28, 2015 and June 29, 2014, dividends charged to retained earnings were as follows (in millions, except per share data):


## us-gaap:SubsequentEventsTextBlock

[0001234452-15-000208:notes:108]
Note 12 - Subsequent Event

[0001234452-15-000208:notes:109]
On July 22, 2015, the Company announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as the Company works to create sustainable long-term value for stockholders. As part of this, among other actions, the Company is implementing a cost reduction plan to reduce annual costs from fiscal 2015 levels of $7.3 billion (adjusted for variable compensation) by approximately $1.1 billion through a series of targeted reductions across the Company’s businesses, particularly in QCT. The Company also plans to reduce annual share-based compensation grants by approximately $300 million. The Company expects these cost initiatives to be fully implemented by the end of fiscal 2016. In connection with this plan, the Company expects to incur approximately $350 million to $450 million in restructuring and restructuring-related charges, of which approximately $100 million to $200 million are expected to be incurred in the fourth quarter of fiscal 2015. Restructuring and restructuring-related charges include an estimate of severance costs, lease termination costs, acceleration of depreciation, consultancy fees and other costs.
