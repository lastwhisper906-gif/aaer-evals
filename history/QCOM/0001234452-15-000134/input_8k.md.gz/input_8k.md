# QCOM 8-K — 0001234452-15-000132 filed 2015-04-22

## item codes, every 8-K on or before 2015-04-22

- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2015-04-22

- none on or before 2015-04-22

## item 2.02 — earnings release, exhibit 99.1

[0001234452-15-000132:8k_2_02:1]
EX-99.1
2
qcom32915erex991.htm
EXHIBIT 99.1

[0001234452-15-000132:8k_2_02:2]
QCOM 3.29.15 ER EX 99.1

[0001234452-15-000132:8k_2_02:3]
Exhibit 99.1

[0001234452-15-000132:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-15-000132:8k_2_02:5]
Qualcomm Contact:

[0001234452-15-000132:8k_2_02:6]
Warren Kneeshaw

[0001234452-15-000132:8k_2_02:7]
Vice President, Investor Relations

[0001234452-15-000132:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-15-000132:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-15-000132:8k_2_02:10]
Qualcomm Announces Second Quarter Fiscal 2015 Results

[0001234452-15-000132:8k_2_02:11]
Revenues $6.9 billion

[0001234452-15-000132:8k_2_02:12]
GAAP EPS $0.63, Non-GAAP EPS $1.40

[0001234452-15-000132:8k_2_02:13]
- Record Quarterly Licensing Revenues and Earnings -

[0001234452-15-000132:8k_2_02:14]
SAN DIEGO - April 22, 2015 - Qualcomm Incorporated (Nasdaq:  QCOM), a leading developer and innovator of advanced wireless technologies, products and services, today announced results for the second quarter of fiscal 2015 ended March 29, 2015.

[0001234452-15-000132:8k_2_02:15]
“We are pleased with our second quarter results, with record licensing revenues and earnings driven by all-time high 3G/4G device shipments reported by our licensees.  We continue to see robust global demand for 3G/4G devices, including in China where our licensing business is now better positioned to participate in the rapidly accelerating adoption of our 3G/4G technology,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “While we remain confident in the significant growth opportunities ahead, we are reducing our QCT outlook for fiscal 2015, primarily due to the increased impact of customer share shifts within the premium tier and a decline in our share at a large customer.  In addition to our ongoing expense management initiatives, we have initiated a comprehensive review of our cost structure to identify opportunities to improve operating margins while at the same time extending our technology and product leadership positions.”

[0001234452-15-000132:8k_2_02:16]
Second Quarter Results (GAAP)*

[0001234452-15-000132:8k_2_02:17]
|  | Q2 Fiscal 2015 |  | Q2 Fiscal 2014 |  | Year-Over-Year Change |  | Q1 Fiscal 2015 |  | Sequential Change |
| Revenues 1 | $6.9B |  | $6.4B |  | +8% |  | $7.1B |  | (3%) |
| Operating income 1 | $1.3B |  | $2.0B |  | (33%) |  | $2.1B |  | (35%) |
| Net income 2 | $1.1B |  | $2.0B |  | (46%) |  | $2.0B |  | (47%) |
| Diluted earnings per share 2 | $0.63 |  | $1.14 |  | (45%) |  | $1.17 |  | (46%) |
| Operating cash flow | ($0.7B) |  | $1.8B |  | N/M |  | $2.4B |  | N/M |

[0001234452-15-000132:8k_2_02:18]
_________________________

[0001234452-15-000132:8k_2_02:19]
1 Throughout this news release, revenues, operating expenses, operating income, earnings before tax (EBT) and effective tax rates are from continuing operations (i.e., before adjustments for noncontrolling interests and discontinued operations), unless otherwise stated.

[0001234452-15-000132:8k_2_02:20]
2 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests and discontinued operations), unless otherwise stated.

[0001234452-15-000132:8k_2_02:21]
Non-GAAP Second Quarter Results

[0001234452-15-000132:8k_2_02:22]
|  | Q2 Fiscal 2015 |  | Q2 Fiscal 2014 |  | Year-Over-Year Change |  | Q1 Fiscal 2015 |  | Sequential Change |
| Revenues | $6.9B |  | $6.4B |  | +8% |  | $7.1B |  | (3%) |
| Operating income | $2.7B |  | $2.3B |  | +16% |  | $2.5B |  | +7% |
| Net income | $2.3B |  | $2.3B |  | +4% |  | $2.3B |  | +3% |
| Diluted earnings per share | $1.40 |  | $1.31 |  | +7% |  | $1.34 |  | +4% |

[0001234452-15-000132:8k_2_02:23]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Beginning in the first quarter of fiscal 2015, we changed our methodology for reporting Non-GAAP results to exclude third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages.  Detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-15-000132:8k_2_02:24]
* The following should be considered in regards to the year-over-year and sequential comparisons:  The second quarter of fiscal 2015 GAAP results included a $975 million charge, or $0.58 per share, related to the resolution reached with the China National Development and Reform Commission (NDRC) regarding its investigation of us under China’s Anti-Monopoly Law.  Operating cash flow also was impacted by the prepayment of $950 million to secure long-term capacity commitments at a supplier of our integrated circuit products.

[0001234452-15-000132:8k_2_02:25]
Second Quarter Key Business Metrics

[0001234452-15-000132:8k_2_02:26]
|  | Q2 Fiscal 2015 |  | Q2 Fiscal 2014 |  | Year-Over-Year Change (1) |  | Q1 Fiscal 2015 |  | Sequential Change (1) |
| MSMTM chip shipments | 233M |  | 188M |  | +24% |  | 270M |  | (14%) |
| Total reported device sales (2) | $75.8B |  | $66.5B |  | +14% |  | $56.4B |  | +34% |
| Est. reported 3G/4G device shipments (approx.) (2) | 384M - 388M |  | 295M - 299M |  | +30% |  | 284M - 288M |  | +35% |
| Est. reported 3G/4G average selling price (approx.) (2) | $193 - $199 |  | $221 - $227 |  | (13%) |  | $194 - $200 |  | (1%) |

[0001234452-15-000132:8k_2_02:27]
| (1) | The midpoints of the estimated ranges are identified for comparison purposes only and do not indicate a higher degree of confidence in the midpoints. |

[0001234452-15-000132:8k_2_02:28]
| (2) | The second quarter of fiscal 2014 and 2015 are based on sales by our licensees in the December quarter as reported to us in the March quarter, and the first quarter of fiscal 2015 is based on sales by our licensees in the September quarter as reported to us in the December quarter. |

[0001234452-15-000132:8k_2_02:29]
Cash and Marketable Securities

[0001234452-15-000132:8k_2_02:30]
Our cash, cash equivalents and marketable securities totaled $29.6 billion at the end of the second quarter of fiscal 2015, compared to $32.1 billion a year ago and $31.6 billion at the end of the first quarter of fiscal 2015.

[0001234452-15-000132:8k_2_02:31]
Return of Capital to Stockholders

[0001234452-15-000132:8k_2_02:32]
During the second quarter of fiscal 2015, we returned $2.6 billion to stockholders, including $1.9 billion through repurchases of 27.8 million shares of common stock and $689 million, or $0.42 per share, of cash dividends paid.  On March 9, 2015, we announced a new $15 billion stock repurchase program, including our intention to repurchase $10 billion of common stock within 12 months, in addition to our current commitment to return a minimum of 75% of free cash flow to stockholders through stock repurchases and dividends.  Since March 29, 2015, we repurchased and retired 5.1 million shares of common stock for $345 million.  On April 8, 2015, we announced a cash dividend of $0.48 per share payable on June 24, 2015 to stockholders of record as of the close of business on June 3, 2015, which represents a 14 percent increase over our prior quarterly dividend.

[0001234452-15-000132:8k_2_02:33]
Effective Income Tax Rates

[0001234452-15-000132:8k_2_02:34]
Our fiscal 2015 annual effective income tax rates are estimated to be approximately 21 percent for GAAP and approximately 19 percent for Non-GAAP, both of which include the United States federal research and development (R&D) tax credit generated through December 31, 2014, the date on which the credit expired.  The effective income tax rates for the second quarter of fiscal 2015 were 32 percent for GAAP and 20 percent for Non-GAAP.  Our estimated annual tax rate for GAAP increased from our prior estimate primarily as a result of the $975 million fine related to the resolution with the NDRC during the second quarter of fiscal 2015.  The fine is not deductible for tax purposes and was accounted for discretely.

[0001234452-15-000132:8k_2_02:35]
During the second quarter of fiscal 2015, we recorded a $61 million tax benefit as a result of an agreement reached with the Internal Revenue Service related to Atheros’ pre-acquisition tax returns, which was excluded from Non-GAAP results.

[0001234452-15-000132:8k_2_02:36]
Business Outlook

[0001234452-15-000132:8k_2_02:37]
we face, and our most recent annual and quarterly reports on file with the Securities and Exchange Commission (SEC) provide a more complete description of risks.

[0001234452-15-000132:8k_2_02:38]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment and certain derivative gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001234452-15-000132:8k_2_02:39]
We are reducing our outlook for our semiconductor business, QCT, for the second half of fiscal 2015 primarily due to:

[0001234452-15-000132:8k_2_02:40]
| • | The increased impact of customer share shifts within the premium tier, which will reduce our sales of our integrated SnapdragonTM processors and skew our product mix towards modem chipsets in this tier; and |

[0001234452-15-000132:8k_2_02:41]
| • | A decline in our share at a large customer. |

[0001234452-15-000132:8k_2_02:42]
In the second quarter of fiscal 2015, we reached a resolution with the NDRC regarding its investigation and agreed to implement a rectification plan that modifies certain of our business practices in China.  However, we continue to believe that certain licensees in China are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes 3G/4G units that we believe are not being reported by certain licensees).  Additionally, we expect it will take some time for licensees to decide whether to accept the new China terms or retain the terms of their existing agreements and for unlicensed companies that had delayed execution of new licenses pending resolution of the investigation to execute new licenses.  We believe that the conclusion of the NDRC investigation will accelerate the resolution of these issues, although the outcome and timing of any resolutions are uncertain.  Please refer to our Quarterly Report on Form 10-Q for the second quarter ended March 29, 2015 filed with the SEC for our most recent disclosures regarding the NDRC resolution.  Our current outlook for our licensing business, QTL, also reflects the following:

[0001234452-15-000132:8k_2_02:43]
| • | We estimate global 3G/4G device shipments were approximately 1.37 billion for calendar year 2014. However, due to the issues described above, we do not believe that all of the global 3G/4G device shipments for calendar year 2014 were reported to us within the time periods required by our license agreements. Accordingly, we currently estimate approximately 1.174 billion to 1.190 |

[0001234452-15-000132:8k_2_02:44]
billion calendar year 2014 3G/4G device shipments were actually reported to us through the first calendar quarter of 2015.

[0001234452-15-000132:8k_2_02:45]
| • | We expect global 3G/4G device shipments to be approximately 1.52 billion to 1.6 billion for calendar year 2015. At this time, we are not providing a forecast for calendar year 2015 reported 3G/4G device shipments. |

[0001234452-15-000132:8k_2_02:46]
| • | In the following table, we do provide guidance for estimated third fiscal quarter and fiscal 2015 3G/4G total reported device sales. That guidance includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-15-000132:8k_2_02:47]
Our outlook for fiscal 2015 includes an estimate of the benefit related to stock repurchases that we plan to complete over the remainder of fiscal 2015.

[0001234452-15-000132:8k_2_02:48]
We have not included any estimates related to the proposed acquisition of CSR plc in our fiscal 2015 outlook.  The acquisition is expected to close by the end of the summer of 2015.  We expect the acquisition to be accretive to Non-GAAP earnings per share in fiscal 2016, the first full year of combined operations.

[0001234452-15-000132:8k_2_02:49]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-15-000132:8k_2_02:50]
Qualcomm’s Business Outlook Summary

[0001234452-15-000132:8k_2_02:51]
| THIRD FISCAL QUARTER |
|  |  | Q3 FY14 Results | Current Guidance Q3 FY15 Estimates |
|  | Revenues | $6.8B | $5.4B - $6.2B |  |
|  | Year-over-year change |  | decrease 9% - 21% |  |
|  | Non-GAAP diluted earnings per share (EPS) |  | $1.44 |  | $0.85 - $1.00 |  |
|  | Year-over-year change |  | decrease 31% - 41% |  |
|  | Diluted EPS attributable to QSI |  | $0.00 |  |  | ($0.01 | ) |
|  | Diluted EPS attributable to share-based compensation |  | ($0.14 | ) |  | ($0.14 | ) |
|  | Diluted EPS attributable to other items |  | $0.00 |  |  | ($0.03 | ) |
|  | GAAP diluted EPS |  | $1.31 |  | $0.67 - $0.82 |  |
|  | Year-over-year change |  | decrease 37% - 49% |  |
|  | Metrics |  |  |
|  | MSM chip shipments | 225M |  | 210M - 230M |  |
|  | Year-over-year change |  | decrease 7% - increase 2% |  |
|  | Total reported device sales* (1) | approx. $58.1B |  | approx. $61.0B - $67.0B (3) |  |
|  | Year-over-year change |  | increase 5% - 15% |  |
|  | *Est. sales in March quarter, reported in June quarter |  |  |

[0001234452-15-000132:8k_2_02:52]
| FISCAL YEAR |
|  |  | FY 2014 Results | Prior Guidance FY 2015 Estimates (2) | Current Guidance FY 2015 Estimates (2) |
|  | Revenues |  | $26.5 | B | $26.3B - $28.0B |  | $25.0B - $27.0B |  |
|  | Year-over-year change |  | decrease 1% - increase 6% |  | decrease 6% - increase 2% |  |
|  | Non-GAAP diluted EPS |  | $5.27 |  | $4.85 - $5.05 |  | $4.60 - $5.00 |  |
|  | Year-over-year change |  | decrease 4% - 8% |  | decrease 5% - 13% |  |
|  | Diluted EPS attributable to QSI |  | $0.01 |  |  | ($0.02 | ) |  | ($0.04 | ) |
|  | Diluted EPS attributable to share-based compensation |  | ($0.50 | ) |  | ($0.54 | ) |  | ($0.54 | ) |
|  | Diluted EPS attributable to other items |  | ($0.13 | ) |  | ($0.73 | ) |  | ($0.74 | ) |
|  | GAAP diluted EPS |  | $4.65 |  | $3.56 - $3.76 |  | $3.28 - $3.68 |  |
|  | Year-over-year change |  | decrease 19% - 23% |  | decrease 21% - 29% |  |
|  | Metrics |  |  |  |
|  | Total reported device sales* (1) | approx. $243.6B |  | approx. $245.0B - $270.0B (3) |  | approx. $255.0B - $275.0B (3) |  |
|  | Year-over-year change |  | increase 1% - 11% |  | increase 5% - 13% |  |
|  | *Est. sales in Sept. to June quarters, reported in Dec. to Sept. quarters |  |  |  |

[0001234452-15-000132:8k_2_02:53]
| CALENDAR YEAR Reported 3G/4G Device Estimates (1) |
|  |  | Prior Guidance Calendar 2014 Estimates | Current GuidanceCalendar 2014Estimates |
|  | Est. reported 3G/4G device shipments |  |  |
|  | March quarter | approx. 250M - 254M | approx. 250M - 254M |
|  | June quarter | approx. 256M - 260M | approx. 256M - 260M |
|  | September quarter | approx. 284M - 288M | approx. 284M - 288M |
|  | December quarter | not provided | approx. 384M - 388M |
|  | Est. calendar year range (approx.) | 1,135M - 1,175M (4) | 1,174M - 1,190M (4) |

[0001234452-15-000132:8k_2_02:54]
| (1) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). The reported quarterly estimated ranges of average selling prices (ASPs) and unit shipments are determined based on the information as reported to us by our licensees during the relevant period and our own estimates of the selling prices and unit shipments for licensees that do not provide such information. Not all licensees report sales, selling prices and/or unit shipments the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales, estimated unit shipments and estimated ASPs for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-15-000132:8k_2_02:55]
| (2) | Our prior guidance for fiscal 2015 included an estimate of the benefit related to stock repurchases that we planned to complete over the remainder of fiscal 2015 under our previous stock repurchase program. Our current guidance for fiscal 2015 includes an estimate of the benefit related to stock repurchases that we plan to complete over the remainder of fiscal 2015 under our new $15 billion stock repurchase program, including our intention to repurchase $10 billion of common stock within 12 months, in addition to our current commitment to return a minimum of 75% of free cash flow to stockholders through repurchases and dividends. |

[0001234452-15-000132:8k_2_02:56]
| (3) | Our guidance range for the third quarter of fiscal 2015 and fiscal 2015 total reported device sales reflects estimated 3G/4G total reported device sales that we currently expect to be reported to us, which includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-15-000132:8k_2_02:57]
| (4) | We estimate global 3G/4G device shipments were approximately 1.37 billion for calendar year 2014. However, we do not believe that all of the global 3G/4G device shipments for calendar year 2014 were reported to us within the time periods required by our license agreements. Accordingly, we currently estimate approximately 1.174 billion to 1.190 billion calendar year 2014 3G/4G device shipments were actually reported to us through the first calendar quarter of 2015. |

[0001234452-15-000132:8k_2_02:58]
Sums may not equal totals due to rounding.

[0001234452-15-000132:8k_2_02:59]
Results of Business Segments

[0001234452-15-000132:8k_2_02:60]
The following table reconciles our Non-GAAP results to our GAAP results ($ in millions, except per share data):

[0001234452-15-000132:8k_2_02:61]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (a) | Non-GAAP | QSI | Share-Based Compensation | Other Items (b) (c) |  | GAAP |
| Q2 - FISCAL 2015 |  |  |  |  |  |
| Revenues | $4,434 | $2,414 | $46 | $6,894 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $6,894 |  |
| Change from prior year | 5 | % | 17 | % | (13 | %) | 8 | % |  |  |  |  |  |  | 8 | % |  |
| Change from prior quarter | (15 | %) | 33 | % | 12 | % | (3 | %) |  |  |  |  |  |  | (3 | %) |  |
| Cost of equipment and services revenues |  |  |  | $2,554 |  |  | $— |  |  | $11 | $63 |  | $2,628 |  |
| Research and development |  |  |  | 1,186 |  | 1 |  | 158 | 30 |  | 1,375 |  |
| Selling, general and administrative |  |  |  | 447 |  | 3 |  | 80 | 15 |  | 545 |  |
| Other expenses |  |  |  | — |  |  | — |  |  | — |  | 1,010 |  | 1,010 |  |
| Operating income (loss) |  |  |  | $2,707 |  | ($4) |  | ($249) | ($1,118) |  | $1,336 |  |
| Change from prior year |  |  |  | 16 | % |  | 33 | % |  | 1 | % | N/M |  |  | (33 | %) |  |
| Change from prior quarter |  |  |  | 7 | % |  | 43 | % |  | 9 | % | N/M |  |  | (35 | %) |  |
| Investment income, net |  |  |  | $231 | (d) | ($28) | (e) |  | $— |  |  | $— |  |  | $203 |  |
| EBT | $750 | $2,162 | $26 | $2,938 |  | ($32) |  | ($249) | ($1,118) |  | $1,539 |  |
| Change from prior year | 1 | % | 18 | % | (67 | %) | 11 | % |  | 18 | % |  | 1 | % | N/M |  |  | (32 | %) |  |
| Change from prior quarter | (35 | %) | 37 | % | (24 | %) | 6 | % |  | N/M |  |  | 9 | % | N/M |  |  | (33 | %) |  |
| EBT as % of revenues | 17 | % | 90 | % | 57 | % | 43 | % |  |  |  |  |  |  | 22 | % |  |
| Net income (loss) |  |  |  | $2,339 |  | ($27) |  | ($206) | ($1,053) |  | $1,053 |  |
| Change from prior year |  |  |  | 4 | % |  | (59 | %) |  | (4 | %) | N/M |  |  | (46 | %) |  |
| Change from prior quarter |  |  |  | 3 | % |  | N/M |  |  | 10 | % | N/M |  |  | (47 | %) |  |
| Diluted EPS |  |  |  | $1.40 |  | ($0.02) |  | ($0.12) | ($0.63) |  | $0.63 |  |
| Change from prior year |  |  |  | 7 | % |  | N/M |  |  | (9 | %) | N/M |  |  | (45 | %) |  |
| Change from prior quarter |  |  |  | 4 | % |  | N/M |  |  | 14 | % | N/M |  |  | (46 | %) |  |
| Diluted shares used |  |  |  | 1,667 |  | 1,667 |  | 1,667 | 1,667 |  | 1,667 |  |
| Q1 - FISCAL 2015 |  |  |  |  |  |
| Revenues | $5,242 | $1,816 | $41 | $7,099 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $7,099 |  |
| Operating income (loss) |  |  |  | 2,531 |  | (7) |  | (273) | (187) |  | 2,064 |  |
| EBT | $1,146 | $1,579 | $34 | 2,759 |  | (1) |  | (273) | (187) |  | 2,298 |  |
| Net income (loss) |  |  |  | 2,263 |  | — |  |  | (229) | (62) |  | 1,972 |  |
| Diluted EPS |  |  |  | $1.34 |  | $0.00 |  | ($0.14) | ($0.04) |  | $1.17 |  |
| Diluted shares used |  |  |  | 1,686 |  | 1,686 |  | 1,686 | 1,686 |  | 1,686 |  |
| Q2 - FISCAL 2014 |  |  |  |  |  |
| Revenues | $4,243 | $2,071 | $53 | $6,367 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $6,367 |  |
| Operating income (loss) |  |  |  | 2,337 |  | (6) |  | (251) | (90) |  | 1,990 |  |
| EBT | $740 | $1,834 | $78 | 2,652 |  | (39) |  | (251) | (90) |  | 2,272 |  |
| Net income (loss) |  |  |  | 2,255 |  | (17) |  | (198) | (81) |  | 1,959 |  |
| Diluted EPS |  |  |  | $1.31 |  | ($0.01) |  | ($0.11) | ($0.05) |  | $1.14 |  |
| Diluted shares used |  |  |  | 1,719 |  | 1,719 |  | 1,719 | 1,719 |  | 1,719 |  |
| Q3 - FISCAL 2014 |  |  |  |  |  |
| Revenues | $4,957 | $1,803 | $46 | $6,806 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $6,806 |  |
| Operating income (loss) |  |  |  | 2,425 |  | (5) |  | (274) | (71) |  | 2,075 |  |
| EBT | $1,116 | $1,550 | $177 | 2,843 |  | (1) |  | (274) | (71) |  | 2,497 |  |
| Net income (loss) |  |  |  | 2,470 |  | — |  |  | (232) | — |  |  | 2,238 |  |
| Diluted EPS |  |  |  | $1.44 |  | $0.00 |  | ($0.14) | $0.00 |  | $1.31 |  |
| Diluted shares used |  |  |  | 1,714 |  | 1,714 |  | 1,714 | 1,714 |  | 1,714 |  |

[0001234452-15-000132:8k_2_02:62]
| (a) | Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations. Non-GAAP reconciling items related to earnings before taxes consisted primarily of certain research and development expenses, selling, general and administrative expenses, other expenses or income and certain investment income that are not allocated to the segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit. |

[0001234452-15-000132:8k_2_02:63]
| (b) | Beginning in the first quarter of fiscal 2015, we changed our methodology for reporting Non-GAAP results to exclude third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. In the second quarter of fiscal 2015, other items excluded from Non-GAAP EBT included $975 million related to the resolution reached with the NDRC, $79 million of acquisition-related items, impairment charges of $35 million and $27 million related to goodwill and in-process research and development, respectively, and $2 million of severance costs related to a restructuring. |

[0001234452-15-000132:8k_2_02:64]
| (c) | In the second quarter of fiscal 2015, the tax benefit in the “Other Items” column included a $61 million tax benefit as a result of an agreement reached with the Internal Revenue Service related to Atheros’ pre-acquisition tax returns, a $10 million tax benefit for the tax effect of other items in EBT and a $3 million tax benefit for the tax effect of acquisition-related items, partially offset by a $9 million tax expense to reconcile the tax provisions for each column to the total GAAP tax provision for the quarter. At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. In interim quarters of prior fiscal years, this difference was allocated to the tax provisions (benefits) among the columns. See the “Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates” herein. |

[0001234452-15-000132:8k_2_02:65]
| (d) | Included $138 million in interest and dividend income, $106 million in net realized gains on investments and $1 million in other net investment income, partially offset by $14 million in other-than-temporary losses on investments. |

[0001234452-15-000132:8k_2_02:66]
| (e) | Included $27 million in other-than-temporary losses on investments and $1 million in other net investment expense. |

[0001234452-15-000132:8k_2_02:67]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (a) | Non-GAAP | QSI | Share-Based Compensation | Other Items (f) (g) |  | GAAP |
| 6 MONTHS - FISCAL 2015 |  |  |  |  |  |
| Revenues | $9,676 | $4,230 | $87 | $13,993 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $13,993 |  |
| Change from prior year | 9 | % | 7 | % | (45 | %) | 8 | % |  |  |  |  |  |  | 8 | % |  |
| Cost of equipment and services revenues |  |  |  | $5,524 |  |  | $— |  |  | $23 | $129 |  | $5,676 |  |
| Research and development |  |  |  | 2,356 |  | 2 |  | 333 | 35 |  | 2,726 |  |
| Selling, general and administrative |  |  |  | 875 |  | 9 |  | 166 | 62 |  | 1,112 |  |
| Other expenses |  |  |  | — |  |  | — |  |  | — |  | 1,079 |  | 1,079 |  |
| Operating income (loss) |  |  |  | $5,238 |  | ($11) |  | ($522) | ($1,305) |  | $3,400 |  |
| Change from prior year |  |  |  | 25 | % |  | (10 | %) |  | 2 | % | N/M |  |  | (2 | %) |  |
| Investment income, net |  |  |  | $459 | (h) | ($22) | (i) |  | $— |  |  | $— |  |  | $437 |  |
| EBT | $1,896 | $3,741 | $60 | $5,697 |  | ($33) |  | ($522) | ($1,305) |  | $3,837 |  |
| Change from prior year | 15 | % | 7 | % | N/M |  | 20 | % |  | 6 | % |  | 2 | % | N/M |  |  | (5 | %) |  |
| EBT as % of revenues | 20 | % | 88 | % | 69 | % | 41 | % |  |  |  |  |  |  | 27 | % |  |
| Net income (loss) |  |  |  | $4,603 |  |  | ($27 | ) |  | ($436) | ($1,115) |  | $3,025 |  |
| Change from prior year |  |  |  | 4 | % |  | N/M |  |  | (3 | %) | N/M |  |  | (21 | %) |  |
| Diluted EPS |  |  |  | $2.75 |  | ($0.02) |  | ($0.26) | ($0.67) |  | $1.80 |  |
| Change from prior year |  |  |  | 7 | % |  | N/M |  |  | (4 | %) | N/M |  |  | (19 | %) |  |
| Diluted shares used |  |  |  | 1,677 |  | 1,677 |  | 1,677 | 1,677 |  | 1,677 |  |
| 6 MONTHS - FISCAL 2014 |  |  |  |  |  |
| Revenues | $8,859 | $3,971 | $159 | $12,989 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $12,989 |  |
| Operating income (loss) |  |  |  | 4,185 |  | (10) |  | (532) | (160) |  | 3,483 |  |
| EBT | $1,646 | $3,504 | ($394) | 4,756 |  | (35) |  | (532) | (160) |  | 4,029 |  |
| Discontinued operations, net of tax |  |  |  | 430 |  | — |  |  | — |  | — |  |  | 430 |  |
| Net income (loss) |  |  |  | 4,418 |  | (13) |  | (423) | (147) |  | 3,835 |  |
| Diluted EPS |  |  |  | $2.57 |  | ($0.01) |  | ($0.25) | ($0.09) |  | $2.23 |  |
| Diluted shares used |  |  |  | 1,721 |  | 1,721 |  | 1,721 | 1,721 |  | 1,721 |  |
| 12 MONTHS - FISCAL 2014 |  |  |  |  |  |
| Revenues | $18,665 | $7,569 | $253 | $26,487 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $26,487 |  |
| Operating income (loss) |  |  |  | 8,933 |  | (18) |  | (1,059) | (306) |  | 7,550 |  |
| EBT | $3,807 | $6,590 | ($247) | 10,150 |  | (7) |  | (1,059) | (306) |  | 8,778 |  |
| Discontinued operations, net of tax |  |  |  | 430 |  | — |  |  | — |  | — |  |  | 430 |  |
| Net income (loss) |  |  |  | 9,032 |  | 15 |  | (856) | (224) |  | 7,967 |  |
| Diluted EPS |  |  |  | $5.27 |  | $0.01 |  | ($0.50) | ($0.13) |  | $4.65 |  |
| Diluted shares used |  |  |  | 1,714 |  | 1,714 |  | 1,714 | 1,714 |  | 1,714 |  |

[0001234452-15-000132:8k_2_02:68]
| (f) | In the six months ended March 29, 2015, other items excluded from Non-GAAP EBT included $975 million related to the resolution reached with the NDRC, $162 million of acquisition-related items, $104 million related to goodwill impairment charges, $37 million of severance costs related to a restructuring and a $27 million impairment charge related to in-process research and development. |

[0001234452-15-000132:8k_2_02:69]
| (g) | In the six months ended March 29, 2015, the tax benefit in the “Other Items” column included a $101 million tax benefit related to fiscal 2014 as a result of the retroactive reinstatement of the federal R&D tax credit, a $61 million tax benefit as a result of an agreement reached with the Internal Revenue Service related to Atheros’ pre-acquisition tax returns, a $31 million tax benefit for the tax effect of other items in EBT and a $3 million tax benefit related to fiscal 2014 as a result of the retroactive reinstatement of other tax laws, partially offset by a $6 million tax expense to reconcile the tax provisions for each column to the total GAAP tax provision for the six months ended March 29, 2015. See the “Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates” herein. |

[0001234452-15-000132:8k_2_02:70]
| (h) | Included $270 million in interest and dividend income, $262 million in net realized gains on investments and $3 million in other net investment income, partially offset by $76 million in other-than-temporary losses on investments. |

[0001234452-15-000132:8k_2_02:71]
| (i) | Included $30 million in other-than-temporary losses on investments and $10 million in equity in losses of investees, partially offset by $15 million in net realized gains on investments and $3 million in other net investment income. |

[0001234452-15-000132:8k_2_02:72]
N/M - Not Meaningful

[0001234452-15-000132:8k_2_02:73]
Sums may not equal totals due to rounding.

[0001234452-15-000132:8k_2_02:74]
Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates

[0001234452-15-000132:8k_2_02:75]
(Unaudited)

[0001234452-15-000132:8k_2_02:76]
| Three Months Ended March 29, 2015 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Other Items |  |  | GAAP Results |  |
| Income (loss) from continuing operations before income taxes |  | $ | 2,938 |  |  |  | $ | (32 | ) |  |  | $ | (249 | ) |  |  | $ | (1,118 | ) |  |  | $ | 1,539 |  |  |
| Income tax (expense) benefit |  | (599 | ) |  |  | 4 |  |  |  | 43 |  |  |  | 65 |  |  |  | (487 | ) |  |
| Income (loss) from continuing operations |  | $ | 2,339 |  |  |  | $ | (28 | ) |  |  | $ | (206 | ) |  |  | $ | (1,053 | ) |  |  | $ | 1,052 |  |  |
| Tax rate |  | 20 | % |  |  | 13 | % |  |  | 17 | % |  |  | 6% |  |  |  | 32 | % |  |

[0001234452-15-000132:8k_2_02:77]
| Six Months Ended March 29, 2015 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Other Items |  |  | GAAP Results |  |
| Income (loss) from continuing operations before income taxes |  | $ | 5,697 |  |  |  | $ | (33 | ) |  |  | $ | (522 | ) |  |  | $ | (1,305 | ) |  |  | $ | 3,837 |  |  |
| Income tax (expense) benefit |  | (1,094 | ) |  |  | 4 |  |  |  | 86 |  |  |  | 190 |  |  |  | (814 | ) |  |
| Income (loss) from continuing operations |  | $ | 4,603 |  |  |  | $ | (29 | ) |  |  | $ | (436 | ) |  |  | $ | (1,115 | ) |  |  | $ | 3,023 |  |  |
| Tax rate |  | 19 | % |  |  | 12 | % |  |  | 16 | % |  |  | 15% |  |  |  | 21 | % |  |

[0001234452-15-000132:8k_2_02:78]
Conference Call

[0001234452-15-000132:8k_2_02:79]
Qualcomm’s second quarter fiscal 2015 earnings conference call will be broadcast live on April 22, 2015, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 18876512.

[0001234452-15-000132:8k_2_02:80]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-15-000132:8k_2_02:81]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for, or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-15-000132:8k_2_02:82]
The Company uses Non-GAAP financial information (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against each other and against competitors.  Non-GAAP measurements used by the Company include revenues, cost of equipment and services revenues, R&D expenses, SG&A expenses, other expenses, operating income, net investment income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  As a result, management compensation decisions and the review of executive compensation by the Compensation Committee of the Board of Directors focus primarily on Non-GAAP financial measures applicable to the Company and its business segments.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.

[0001234452-15-000132:8k_2_02:83]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items, tax items and other items.

[0001234452-15-000132:8k_2_02:84]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-15-000132:8k_2_02:85]
| • | Share-based compensation expense primarily relates to restricted stock units. Non-cash share-based compensation is excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses. |

[0001234452-15-000132:8k_2_02:86]
| • | Certain other items are excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core business, including: |

[0001234452-15-000132:8k_2_02:87]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items starting with acquisitions completed in the third quarter of fiscal 2011, as well as any tax effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property. Starting in the first quarter of fiscal 2015, the Company excludes third-party |

[0001234452-15-000132:8k_2_02:88]
acquisition and integration services costs.  Prior year amounts have not been reclassified to conform to the current presentation.

[0001234452-15-000132:8k_2_02:89]
| • | Starting in the first quarter of fiscal 2015, the Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and long-lived asset impairments and litigation settlements and/or damages. Prior year amounts have not been reclassified to conform to the current presentation. |

[0001234452-15-000132:8k_2_02:90]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. Also, the provision (benefit) to reconcile the tax provisions (benefits) for each column to the total GAAP tax provision for the quarter is excluded. At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. In interim quarters of prior fiscal years, this difference was allocated to the tax provisions (benefits) among the columns. |

[0001234452-15-000132:8k_2_02:91]
About Qualcomm

[0001234452-15-000132:8k_2_02:92]
Qualcomm Incorporated (Nasdaq:  QCOM) is a world leader in 3G, 4G and next-generation wireless technologies.  Qualcomm Incorporated includes Qualcomm’s licensing business, QTL, and the vast majority of its patent portfolio.  Qualcomm Technologies, Inc., a wholly-owned subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of Qualcomm’s engineering, research and development functions, and substantially all of its products and services businesses, including its semiconductor business, QCT.  For more than 25 years, Qualcomm ideas and inventions have driven the evolution of digital communications, linking people everywhere more closely to information, entertainment and each other.  For more information, visit www.qualcomm.com.

[0001234452-15-000132:8k_2_02:93]
Note Regarding Forward-Looking Statements

[0001234452-15-000132:8k_2_02:94]
In addition to the historical information contained herein, this news release contains forward-looking statements that are inherently subject to risks and uncertainties, including but not limited to statements regarding: robust global demand for 3G/4G devices around the world, including in China; our licensing business being better positioned to participate in the rapidly accelerating adoption of our 3G/4G technology in China; our confidence in the significant growth opportunities ahead; our reduced QCT outlook for fiscal 2015 primarily due to the increased impact of customer share shifts within the

[0001234452-15-000132:8k_2_02:95]
###

[0001234452-15-000132:8k_2_02:96]
Qualcomm, Snapdragon and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-15-000132:8k_2_02:97]
Qualcomm Incorporated

[0001234452-15-000132:8k_2_02:98]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001234452-15-000132:8k_2_02:99]
(In millions, except per share data)

[0001234452-15-000132:8k_2_02:100]
(Unaudited)

[0001234452-15-000132:8k_2_02:101]
|  | March 29, 2015 |  | September 28, 2014 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 5,492 |  |  | $ | 7,907 |  |
| Marketable securities | 10,063 |  |  | 9,658 |  |
| Accounts receivable, net | 2,058 |  |  | 2,412 |  |
| Inventories | 1,861 |  |  | 1,458 |  |
| Deferred tax assets | 533 |  |  | 577 |  |
| Other current assets | 733 |  |  | 401 |  |
| Total current assets | 20,740 |  |  | 22,413 |  |
| Marketable securities | 14,055 |  |  | 14,457 |  |
| Deferred tax assets | 1,049 |  |  | 1,174 |  |
| Property, plant and equipment, net | 2,523 |  |  | 2,487 |  |
| Goodwill | 4,388 |  |  | 4,488 |  |
| Other intangible assets, net | 2,482 |  |  | 2,580 |  |
| Other assets | 1,936 |  |  | 975 |  |
| Total assets | $ | 47,173 |  |  | $ | 48,574 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,683 |  |  | $ | 2,183 |  |
| Payroll and other benefits related liabilities | 744 |  |  | 802 |  |
| Unearned revenues | 778 |  |  | 785 |  |
| Short-term debt | 1,096 |  |  | — |  |
| Other current liabilities | 1,868 |  |  | 2,243 |  |
| Total current liabilities | 6,169 |  |  | 6,013 |  |
| Unearned revenues | 2,667 |  |  | 2,967 |  |
| Other liabilities | 503 |  |  | 428 |  |
| Total liabilities | 9,339 |  |  | 9,408 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,633 and 1,669 shares issued and outstanding, respectively | 4,956 |  |  | 7,736 |  |
| Retained earnings | 32,411 |  |  | 30,799 |  |
| Accumulated other comprehensive income | 472 |  |  | 634 |  |
| Total Qualcomm stockholders’ equity | 37,839 |  |  | 39,169 |  |
| Noncontrolling interests | (5 | ) |  | (3 | ) |
| Total stockholders’ equity | 37,834 |  |  | 39,166 |  |
| Total liabilities and stockholders’ equity | $ | 47,173 |  |  | $ | 48,574 |  |

[0001234452-15-000132:8k_2_02:102]
Qualcomm Incorporated

[0001234452-15-000132:8k_2_02:103]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-15-000132:8k_2_02:104]
(In millions, except per share data)

[0001234452-15-000132:8k_2_02:105]
(Unaudited)

[0001234452-15-000132:8k_2_02:106]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | March 29, 2015 |  | March 30, 2014 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 4,403 |  |  | $ | 4,229 |  |  | $ | 9,619 |  |  | $ | 8,881 |  |
| Licensing | 2,491 |  |  | 2,138 |  |  | 4,374 |  |  | 4,108 |  |
| Total revenues | 6,894 |  |  | 6,367 |  |  | 13,993 |  |  | 12,989 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of equipment and services revenues | 2,628 |  |  | 2,482 |  |  | 5,676 |  |  | 5,189 |  |
| Research and development | 1,375 |  |  | 1,356 |  |  | 2,726 |  |  | 2,683 |  |
| Selling, general and administrative | 545 |  |  | 539 |  |  | 1,112 |  |  | 1,162 |  |
| Other | 1,010 |  |  | — |  |  | 1,079 |  |  | 472 |  |
| Total costs and expenses | 5,558 |  |  | 4,377 |  |  | 10,593 |  |  | 9,506 |  |
| Operating income | 1,336 |  |  | 1,990 |  |  | 3,400 |  |  | 3,483 |  |
| Investment income, net | 203 |  |  | 282 |  |  | 437 |  |  | 546 |  |
| Income from continuing operations before income taxes | 1,539 |  |  | 2,272 |  |  | 3,837 |  |  | 4,029 |  |
| Income tax expense | (487 | ) |  | (314 | ) |  | (814 | ) |  | (626 | ) |
| Income from continuing operations | 1,052 |  |  | 1,958 |  |  | 3,023 |  |  | 3,403 |  |
| Discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | 430 |  |
| Net income | 1,052 |  |  | 1,958 |  |  | 3,023 |  |  | 3,833 |  |
| Net loss attributable to noncontrolling interests | 1 |  |  | 1 |  |  | 2 |  |  | 2 |  |
| Net income attributable to Qualcomm | $ | 1,053 |  |  | $ | 1,959 |  |  | $ | 3,025 |  |  | $ | 3,835 |  |
| Basic earnings per share attributable to Qualcomm: |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.64 |  |  | $ | 1.16 |  |  | $ | 1.83 |  |  | $ | 2.02 |  |
| Discontinued operations | — |  |  | — |  |  | — |  |  | 0.25 |  |
| Net income | $ | 0.64 |  |  | $ | 1.16 |  |  | $ | 1.83 |  |  | $ | 2.27 |  |
| Diluted earnings per share attributable to Qualcomm: |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.63 |  |  | $ | 1.14 |  |  | $ | 1.80 |  |  | $ | 1.98 |  |
| Discontinued operations | — |  |  | — |  |  | — |  |  | 0.25 |  |
| Net income | $ | 0.63 |  |  | $ | 1.14 |  |  | $ | 1.80 |  |  | $ | 2.23 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,645 |  |  | 1,688 |  |  | 1,653 |  |  | 1,688 |  |
| Diluted | 1,667 |  |  | 1,719 |  |  | 1,677 |  |  | 1,721 |  |
| Dividends per share announced | $ | 0.42 |  |  | $ | 0.35 |  |  | $ | 0.84 |  |  | $ | 0.70 |  |

[0001234452-15-000132:8k_2_02:107]
Qualcomm Incorporated

[0001234452-15-000132:8k_2_02:108]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-15-000132:8k_2_02:109]
(In millions)

[0001234452-15-000132:8k_2_02:110]
(Unaudited)

[0001234452-15-000132:8k_2_02:111]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | March 29, 2015 |  | March 30, 2014 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,052 |  |  | $ | 1,958 |  |  | $ | 3,023 |  |  | $ | 3,833 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 304 |  |  | 289 |  |  | 591 |  |  | 561 |  |
| Gain on sale of discontinued operations | — |  |  | — |  |  | — |  |  | (665 | ) |
| Long-lived asset and goodwill impairment charges | 63 |  |  | 19 |  |  | 138 |  |  | 479 |  |
| Income tax provision in excess of income tax payments | 80 |  |  | 10 |  |  | 73 |  |  | 268 |  |
| Non-cash portion of share-based compensation expense | 249 |  |  | 251 |  |  | 522 |  |  | 532 |  |
| Incremental tax benefits from share-based compensation | (30 | ) |  | (70 | ) |  | (78 | ) |  | (169 | ) |
| Net realized gains on marketable securities and other investments | (111 | ) |  | (243 | ) |  | (277 | ) |  | (388 | ) |
| Impairment losses on marketable securities and other investments | 41 |  |  | 123 |  |  | 106 |  |  | 159 |  |
| Other items, net | 1 |  |  | (23 | ) |  | (30 | ) |  | (20 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | 165 |  |  | (884 | ) |  | 338 |  |  | (96 | ) |
| Inventories | (100 | ) |  | (84 | ) |  | (403 | ) |  | 153 |  |
| Other assets | (998 | ) |  | 58 |  |  | (1,138 | ) |  | 127 |  |
| Trade accounts payable | (776 | ) |  | 183 |  |  | (508 | ) |  | 35 |  |
| Payroll, benefits and other liabilities | (425 | ) |  | 240 |  |  | (405 | ) |  | (102 | ) |
| Unearned revenues | (173 | ) |  | (13 | ) |  | (246 | ) |  | (112 | ) |
| Net cash (used) provided by operating activities | (658 | ) |  | 1,814 |  |  | 1,706 |  |  | 4,595 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (196 | ) |  | (587 | ) |  | (449 | ) |  | (797 | ) |
| Purchases of available-for-sale securities | (2,792 | ) |  | (5,772 | ) |  | (8,758 | ) |  | (7,827 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 4,053 |  |  | 3,516 |  |  | 8,631 |  |  | 5,684 |  |
| Purchases of trading securities | (393 | ) |  | (1,029 | ) |  | (695 | ) |  | (1,814 | ) |
| Proceeds from sales and maturities of trading securities | 414 |  |  | 1,020 |  |  | 710 |  |  | 1,793 |  |
| Proceeds from sale of discontinued operations, net of cash sold | — |  |  | — |  |  | — |  |  | 788 |  |
| Acquisitions and other investments, net of cash acquired | (80 | ) |  | (32 | ) |  | (178 | ) |  | (347 | ) |
| Other items, net | 40 |  |  | (19 | ) |  | 49 |  |  | 62 |  |
| Net cash provided (used) by investing activities | 1,046 |  |  | (2,903 | ) |  | (690 | ) |  | (2,458 | ) |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock | 301 |  |  | 512 |  |  | 417 |  |  | 953 |  |
| Repurchases and retirements of common stock | (1,947 | ) |  | (1,002 | ) |  | (3,611 | ) |  | (2,004 | ) |
| Dividends paid | (689 | ) |  | (589 | ) |  | (1,385 | ) |  | (1,179 | ) |
| Proceeds from short-term debt | 1,095 |  |  | — |  |  | 1,095 |  |  | — |  |
| Incremental tax benefits from share-based compensation | 30 |  |  | 70 |  |  | 78 |  |  | 169 |  |
| Change in obligations under securities lending | — |  |  | 142 |  |  | (2 | ) |  | 123 |  |
| Other items, net | (3 | ) |  | (1 | ) |  | (8 | ) |  | (3 | ) |
| Net cash used by financing activities | (1,213 | ) |  | (868 | ) |  | (3,416 | ) |  | (1,941 | ) |
| Changes in cash and cash equivalents held for sale | — |  |  | 4 |  |  | — |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents | (8 | ) |  | (2 | ) |  | (15 | ) |  | (1 | ) |
| Net (decrease) increase in cash and cash equivalents | (833 | ) |  | (1,955 | ) |  | (2,415 | ) |  | 195 |  |
| Cash and cash equivalents at beginning of period | 6,325 |  |  | 8,292 |  |  | 7,907 |  |  | 6,142 |  |
| Cash and cash equivalents at end of period | $ | 5,492 |  |  | $ | 6,337 |  |  | $ | 5,492 |  |  | $ | 6,337 |  |
