# QCOM MD&A — 0001234452-15-000134


## mdna

[0001234452-15-000134:mdna:1]
[same as prior period, unchanged from 0001234452-15-000024:mdna:1]

[0001234452-15-000134:mdna:2]
[same as prior period, unchanged from 0001234452-15-000024:mdna:2]

[0001234452-15-000134:mdna:3]
This Quarterly Report (including, but not limited to, this section regarding Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements, including, but not limited to, statements regarding our future business, financial condition, results of operations and prospects. Additionally, statements concerning other future matters, such as the development of new products, enhancements of technologies, industry or regional trends, consumer demand, sales or price levels, challenges to our business and/or business model, capital expenditures, investments in research and development, strategic investments and acquisitions and other statements regarding matters that are not historical, are forward-looking statements. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001234452-15-000134:mdna:4]
[same as prior period, unchanged from 0001234452-15-000024:mdna:4]

[0001234452-15-000134:mdna:5]
Revenues for the second quarter of fiscal 2015 were $6.9 billion, with net income attributable to Qualcomm of $1.1 billion, which primarily resulted from the following key items:

[0001234452-15-000134:mdna:6]
| • | We shipped approximately 233 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, an increase of approximately 24%, compared to approximately 188 million MSM integrated circuits in the year ago quarter. |

[0001234452-15-000134:mdna:7]
| • | Total reported device sales were approximately $75.8 billion, an increase of approximately 14%, compared to approximately $66.5 billion in the year ago quarter.(1) |

[0001234452-15-000134:mdna:8]
| • | On February 9, 2015, we announced that we had reached a resolution with the China National Development and Reform Commission (NDRC) regarding its investigation of us relating to China’s Anti-Monopoly Law (AML). The NDRC issued an Administrative Sanction Decision finding that we had violated the AML, and we agreed to implement a rectification plan that modifies certain of our business practices in China. In addition, the NDRC imposed a fine on us of 6.088 billion Chinese Yuan Renminbi (approximately $975 million), which was recorded in other expenses and was paid, primarily with cash held by foreign entities, in the second quarter of fiscal 2015. |

[0001234452-15-000134:mdna:9]
Against this backdrop, the following recent developments occurred during the second quarter of fiscal 2015 with respect to key elements of our business or our industry:

[0001234452-15-000134:mdna:10]
| • | Worldwide cellular connections grew sequentially by approximately 2% to reach approximately 7.2 billion.(2) |

[0001234452-15-000134:mdna:11]
| • | Worldwide 3G/4G connections (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) grew sequentially by approximately 5% to approximately 3.1 billion, which was approximately 43% of total cellular connections.(2) |

[0001234452-15-000134:mdna:12]
| (1) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). Not all licensees report |

[0001234452-15-000134:mdna:13]
[same as prior period, unchanged from 0001234452-15-000024:mdna:20]

[0001234452-15-000134:mdna:14]
sales the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales for a particular period may include prior period activity that was not reported by the licensee until such particular period.

[0001234452-15-000134:mdna:15]
| (2) | According to GSMA Intelligence estimates as of April 20, 2015 for the quarter ended March 31, 2015. |

[0001234452-15-000134:mdna:16]
[same as prior period, unchanged from 0001234452-15-000024:mdna:13]

[0001234452-15-000134:mdna:17]
[same as prior period, unchanged from 0001234452-15-000024:mdna:14]

[0001234452-15-000134:mdna:18]
[same as prior period, unchanged from 0001234452-15-000024:mdna:15]

[0001234452-15-000134:mdna:19]
QCT is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products and system software are sold to or licensed to manufacturers that use our products in wireless devices, particularly mobile phones, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards and infrastructure equipment, and in wired devices, particularly broadband gateway equipment, desktop computers and streaming media players. Our MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Qualcomm Snapdragon processors and LTE modems, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon processors provide advanced application and graphics processing capabilities. QCT’s system software enables the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits. QCT revenues comprised 64% and 67% of total consolidated revenues in the second quarter of fiscal 2015 and 2014, respectively, and 69% and 68% of total consolidated revenues for the first six months of fiscal 2015 and 2014, respectively.

[0001234452-15-000134:mdna:20]
[same as prior period, unchanged from 0001234452-15-000024:mdna:17]

[0001234452-15-000134:mdna:21]
QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD (including TD-SCDMA), GSM/GPRS/EDGE and/or OFDMA standards and their derivatives. QTL licensing revenues are comprised of license fees as well as royalties based on sales by licensees of products incorporating or using our intellectual property. License fees are fixed amounts paid in one or more installments. Royalties are generally based upon a percentage of the wholesale selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). QTL recognizes royalty revenues based on royalties reported by licensees during the quarter and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. QTL revenues comprised 35% and

[0001234452-15-000134:mdna:22]
33% of total consolidated revenues in the second quarter of fiscal 2015 and 2014, respectively, and 30% and 31% of total consolidated revenues for the first six months of fiscal 2015 and 2014, respectively. The vast majority of such revenues were generated through our licensees’ sales of CDMA2000- and WCDMA-based products, such as feature phones and smartphones.

[0001234452-15-000134:mdna:23]
QSI makes strategic investments that are focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications. Many of these strategic investments are in early-stage companies in a variety of industries, including, but not limited to, digital media, e-commerce, energy, healthcare and wearable devices. Investments primarily include non-marketable equity instruments, which generally are recorded using the cost method or the equity method, and convertible debt instruments, which are recorded at fair value. QSI also holds wireless spectrum, which at March 29, 2015, consisted of L-Band spectrum in the United Kingdom. As part of our strategic investment activities, we intend to pursue various exit strategies for each of our QSI investments in the foreseeable future.

[0001234452-15-000134:mdna:24]
Nonreportable segments include our QMT (Qualcomm MEMS Technologies), Pixtronix and Small Cells divisions and other wireless technology and service initiatives.

[0001234452-15-000134:mdna:25]
[same as prior period, unchanged from 0001234452-15-000024:mdna:23]

[0001234452-15-000134:mdna:26]
[same as prior period, unchanged from 0001234452-15-000024:mdna:24]

[0001234452-15-000134:mdna:27]
[same as prior period, unchanged from 0001234452-15-000024:mdna:25]

[0001234452-15-000134:mdna:28]
[same as prior period, unchanged from 0001234452-15-000024:mdna:26]

[0001234452-15-000134:mdna:29]
[same as prior period, unchanged from 0001234452-15-000024:mdna:27]

[0001234452-15-000134:mdna:30]
| • | China continues to present significant opportunities for us, particularly with the rollout of 3G/4G LTE multimode. We expect the rollout of 4G services in China will encourage competition and growth, bring the benefits of 3G/4G LTE multimode to consumers, encourage consumers to replace 2G (GSM) and 3G devices and enable new opportunities (e.g., machine-to-machine) for the industry. However, our success in China is in part dependent upon the rate of commercialization of products based on 4G LTE (an OFDMA-based standard) in China. |

[0001234452-15-000134:mdna:31]
| • | We reached a resolution with the NDRC regarding its investigation and agreed to implement a rectification plan that modifies certain of our business practices in China. The rectification plan provides, among other things, that for licenses of only our 3G and 4G essential Chinese patents for branded devices sold for use in China starting on January 1, 2015 (and reported to us in the third quarter of fiscal 2015), we will charge running royalties at royalty rates of 5% for 3G CDMA or WCDMA devices (including multimode 3G/4G devices) and 3.5% for 4G devices that do not implement CDMA or WCDMA (including 3-mode LTE-TDD devices), in each case using a royalty base of 65% of the net selling price. |

[0001234452-15-000134:mdna:32]
| • | Despite the resolution of the NDRC investigation, China continues to present significant challenges for us. We continue to believe that certain licensees in China are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes 3G/4G units that we believe are not being reported by certain licensees). Additionally, we expect it will take some time for licensees to decide whether to accept the new China terms or retain the terms of their existing agreements and for unlicensed companies that had delayed execution of new licenses pending resolution of the investigation to execute new licenses. We believe that the |

[0001234452-15-000134:mdna:33]
[same as prior period, unchanged from 0001234452-15-000024:mdna:41]

[0001234452-15-000134:mdna:34]
conclusion of the NDRC investigation will accelerate the resolution of these issues. However, litigation and/or other actions may be necessary to compel these licensees to report and pay the required royalties for such sales and unlicensed companies to execute new licenses.

[0001234452-15-000134:mdna:35]
| • | We anticipate that our results of operations for our semiconductor business, QCT, will be adversely impacted in the second half of fiscal 2015, and continuing into next fiscal year, by the effects of: an increased shift in share among our customers within the premium tier, which will reduce our sales of our integrated Snapdragon processors and skew our product mix towards more modem chipsets in this tier; a decline in share at a large customer; and the continuing competitive environment in China. Based on our current customer engagements and our future product roadmap, we do not believe these factors reflect a long-term change to QCT’s competitive positioning. |

[0001234452-15-000134:mdna:36]
| • | In addition to our ongoing expense management initiatives, we have initiated a comprehensive review of our cost structure to identify opportunities to improve operating margins while at the same time extending our technology and product leadership positions. |

[0001234452-15-000134:mdna:37]
| • | We continue to invest significant resources toward advancements in 3G, 3G/4G multimode and 4G LTE technologies, audio and video codecs, wireless baseband chips, our converged computing/communications (Snapdragon) chips, graphics, connectivity, multimedia products, software and services. We are also investing across a broad spectrum of opportunities that leverage our existing technical and business expertise to deploy new business models and enter into new industry segments, such as products designed for implementation of small cells and addressing the challenge of meeting the increased demand for data; products for the connected home and the Internet of Things; automotive; very high speed connectivity; new display technology; data centers; mobile health; wireless charging; and machine learning, including robotics. |

[0001234452-15-000134:mdna:38]
| • | In October 2014, we announced that we had reached agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.3 billion based upon an exchange rate of USD: GBP 1.4929). CSR is an innovator in the development of multifunction semiconductor platforms and technologies for the automotive, consumer and voice and music market categories. The acquisition complements our current offerings by adding products, channels and customers in the growth categories of the Internet of Everything and automotive infotainment, accelerating our presence and path to leadership. The acquisition has received approval of CSR’s shareholders, and every required regulatory agency has either provided approval or declined to exercise jurisdiction, except for the Ministry of Commerce in China. The completion of the acquisition remains subject to the satisfaction of additional conditions. Subject to the satisfaction of these conditions, the acquisition is expected to close by the end of the summer of 2015. |

[0001234452-15-000134:mdna:39]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless value chain and governments as to the benefits of our business model and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not welcome the success of our business model in enabling new, highly cost-effective competitors to their products. We expect that such companies and/or governments or regulators will continue to challenge our business model in various forums throughout the world.

[0001234452-15-000134:mdna:40]
[same as prior period, unchanged from 0001234452-15-000024:mdna:35]

[0001234452-15-000134:mdna:41]
[same as prior period, unchanged from 0001234452-15-000024:mdna:36]

[0001234452-15-000134:mdna:42]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | Change |  | March 29, 2015 |  | March 30, 2014 |  | Change |
| Equipment and services | $ | 4,403 |  |  | $ | 4,229 |  |  | $ | 174 |  |  | $ | 9,619 |  |  | $ | 8,881 |  |  | $ | 738 |  |
| Licensing | 2,491 |  |  | 2,138 |  |  | 353 |  |  | 4,374 |  |  | 4,108 |  |  | 266 |  |
|  | $ | 6,894 |  |  | $ | 6,367 |  |  | $ | 527 |  |  | $ | 13,993 |  |  | $ | 12,989 |  |  | $ | 1,004 |  |

[0001234452-15-000134:mdna:43]
The increases in equipment and services revenues in the second quarter and the first six months of fiscal 2015 were primarily due to increases in QCT revenues of $175 million and $798 million, respectively. The increase for the first six

[0001234452-15-000134:mdna:44]
months of fiscal 2015 was partially offset by a decrease of $59 million as a result of the sale of the North and Latin America operations of our Omnitracs division during fiscal 2014. The increases in licensing revenues in the second quarter and the first six months of fiscal 2015 were primarily due to increases in QTL revenues of $343 million and $259 million, respectively.

[0001234452-15-000134:mdna:45]
| Costs and Expenses (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | Change |  | March 29, 2015 |  | March 30, 2014 |  | Change |
| Cost of equipment and services (E&S) revenues | $ | 2,628 |  |  | $ | 2,482 |  |  | $ | 146 |  |  | $ | 5,676 |  |  | $ | 5,189 |  |  | $ | 487 |  |
| Cost as % of E&S revenues | 60 | % |  | 59 | % |  |  |  | 59 | % |  | 58 | % |  |  |

[0001234452-15-000134:mdna:46]
The decreases in margin percentage for the second quarter and the first six months of fiscal 2015 were driven primarily by decreases in QCT margin percentage. Our margin percentage may fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors.

[0001234452-15-000134:mdna:47]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | Change |  | March 29, 2015 |  | March 30, 2014 |  | Change |
| Research and development | $ | 1,375 |  |  | $ | 1,356 |  |  | $ | 19 |  |  | $ | 2,726 |  |  | $ | 2,683 |  |  | $ | 43 |  |
| % of revenues | 20 | % |  | 21 | % |  |  |  | 19 | % |  | 21 | % |  |  |
| Selling, general, and administrative | $ | 545 |  |  | $ | 539 |  |  | $ | 6 |  |  | $ | 1,112 |  |  | $ | 1,162 |  |  | $ | (50 | ) |
| % of revenues | 8 | % |  | 8 | % |  |  |  | 8 | % |  | 9 | % |  |  |
| Other | $ | 1,010 |  |  | $ | — |  |  | $ | 1,010 |  |  | $ | 1,079 |  |  | $ | 472 |  |  | $ | 607 |  |

[0001234452-15-000134:mdna:48]
The dollar increases in research and development expenses in the second quarter and the first six months of fiscal 2015 were primarily attributable to increases of $45 million and $85 million, respectively, in costs related to the development of CDMA-based 3G, OFDMA-based 4G LTE and other technologies for integrated circuit and related software products, including small cells and data center products, and to expand our intellectual property portfolio, partially offset by decreases of $20 million and $30 million, respectively, related to the development costs of display technologies.

[0001234452-15-000134:mdna:49]
The dollar decrease in selling, general and administrative expenses in the first six months of fiscal 2015 was primarily attributable to a $16 million gain related to the sale of certain assets of one of our display businesses, the effect of which is a decrease in selling, general and administrative expenses, and a decrease of $16 million in patent-related expenses.

[0001234452-15-000134:mdna:50]
Other expenses in the second quarter of fiscal 2015 were primarily attributable to a $975 million charge resulting from the resolution reached with the NDRC. Other expenses in the first six months of fiscal 2015 also included $104 million in goodwill impairment charges related to our push-to-talk services business and one of our display businesses. Other expenses in the first six months of fiscal 2014 were comprised of a $444 million impairment charge related to one of our display businesses, a $16 million goodwill impairment charge related to our former QRS division and a $12 million charge related to the ParkerVision verdict.

[0001234452-15-000134:mdna:51]
26

[0001234452-15-000134:mdna:52]
| Net Investment Income (in millions) |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | Change |  | March 29, 2015 |  | March 30, 2014 |  | Change |
| Interest and dividend income | $ | 138 |  |  | $ | 167 |  |  | $ | (29 | ) |  | $ | 272 |  |  | $ | 322 |  |  | $ | (50 | ) |
| Interest expense | (1 | ) |  | (3 | ) |  | 2 |  |  | (2 | ) |  | (5 | ) |  | 3 |  |
| Net realized gains on marketable securities | 108 |  |  | 243 |  |  | (135 | ) |  | 264 |  |  | 371 |  |  | (107 | ) |
| Net realized gains on other investments | 3 |  |  | — |  |  | 3 |  |  | 13 |  |  | 17 |  |  | (4 | ) |
| Impairment losses on marketable securities and other investments | (41 | ) |  | (123 | ) |  | 82 |  |  | (106 | ) |  | (159 | ) |  | 53 |  |
| Net gains on derivative instruments | 2 |  |  | — |  |  | 2 |  |  | 6 |  |  | 4 |  |  | 2 |  |
| Equity in net losses of investees | (9 | ) |  | (4 | ) |  | (5 | ) |  | (13 | ) |  | (5 | ) |  | (8 | ) |
| Net gains on deconsolidation of subsidiaries | 3 |  |  | 2 |  |  | 1 |  |  | 3 |  |  | 1 |  |  | 2 |  |
|  | $ | 203 |  |  | $ | 282 |  |  | $ | (79 | ) |  | $ | 437 |  |  | $ | 546 |  |  | $ | (109 | ) |

[0001234452-15-000134:mdna:53]
The decreases in interest and dividend income in the second quarter and the first six months of fiscal 2015 were primarily due to lower interest rates earned on lower cash, cash equivalents and marketable securities balances held. The decreases in net realized gains on marketable securities in the second quarter and the first six months of fiscal 2015 were primarily due to the decreased impact of portfolio rebalancing in the second quarter and the first six months of fiscal 2015. The decreases in impairment losses on marketable securities and other investments in the second quarter and the first six months of fiscal 2015 were primarily due to decreases in our recognition of unrealized losses on debt funds that are not expected to recover over a reasonable period of time.

[0001234452-15-000134:mdna:54]
| Income Tax Expense (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | Change |  | March 29, 2015 |  | March 30, 2014 |  | Change |
| Income tax expense | $ | 487 |  |  | $ | 314 |  |  | $ | 173 |  |  | $ | 814 |  |  | $ | 626 |  |  | $ | 188 |  |
| Effective tax rate | 32 | % |  | 14 | % |  | 18 | % |  | 21 | % |  | 16 | % |  | 5 | % |

[0001234452-15-000134:mdna:55]
The following table summarizes the primary factors that caused our effective tax rates for the second quarter and first six months of fiscal 2015 and 2014 to be less than the United States federal statutory rate:

[0001234452-15-000134:mdna:56]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | March 29, 2015 |  | March 30, 2014 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |  | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (22 | %) |  | (20 | %) |  | (18 | %) |  | (18 | %) |
| Benefits related to the research and development tax credit | (1 | %) |  | (1 | %) |  | (3 | %) |  | (1 | %) |
| Tax impact of NDRC fine | 22 | % |  | — |  |  | 9 | % |  | — |  |
| Tax audit impacts, net | (4 | %) |  | — |  |  | (2 | %) |  | — |  |
| Other | 2 | % |  | — |  |  | — |  |  | — |  |
| Effective tax rate | 32 | % |  | 14 | % |  | 21 | % |  | 16 | % |

[0001234452-15-000134:mdna:57]
The effective tax rate of 32% for the second quarter of fiscal 2015 was greater than the estimated annual effective tax rate of 21% primarily as a result of the NDRC fine, partially offset by the favorable tax audit settlement. The fine is not deductible for tax purposes and was accounted for discretely in the second quarter of fiscal 2015. We recorded a $61 million tax benefit during the second quarter of fiscal 2015 as a result of a favorable tax audit settlement with the Internal Revenue Service related to Qualcomm Atheros, Inc.’s pre-acquisition 2010 and 2011 tax returns.

[0001234452-15-000134:mdna:58]
During the first quarter of fiscal 2015, the United States government reinstated the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. As a result of the reinstatement, the Company recorded a tax benefit of $101 million related to fiscal 2014 in the first quarter of fiscal 2015. Additionally, the estimated annual effective tax rate for fiscal 2015 reflects the United States federal research and development tax credit generated through December 31, 2014, the date on which the credit expired. The annual effective tax rate for fiscal 2014 reflected the tax benefit from the credit generated through December 31, 2013, the date on which the credit previously expired.

[0001234452-15-000134:mdna:59]
[same as prior period, unchanged from 0001234452-15-000024:mdna:53]

[0001234452-15-000134:mdna:60]
The following should be read in conjunction with the second quarter and first six months financial results of fiscal 2015 for each reportable segment. See “Notes to Condensed Consolidated Financial Statements, Note 8 - Segment Information.”

[0001234452-15-000134:mdna:61]
| (in millions) | QCT |  | QTL |  | QSI |
| Three Months Ended March 29, 2015 |  |  |  |  |  |
| Revenues | $ | 4,434 |  |  | $ | 2,414 |  |  | $ | — |  |
| EBT (1) | 750 |  |  | 2,162 |  |  | (32 | ) |
| EBT as a % of revenues | 17 | % |  | 90 | % |  |  |
| Three Months Ended March 30, 2014 |  |  |  |  |  |
| Revenues | $ | 4,243 |  |  | $ | 2,071 |  |  | $ | — |  |
| EBT (1) | 740 |  |  | 1,834 |  |  | (39 | ) |
| EBT as a % of revenues | 17 | % |  | 89 | % |  |  |
| Six Months Ended March 29, 2015 |  |  |  |  |  |
| Revenues | $ | 9,676 |  |  | $ | 4,230 |  |  | $ | — |  |
| EBT (1) | 1,896 |  |  | 3,741 |  |  | (33 | ) |
| EBT as a % of revenues | 20 | % |  | 88 | % |  |  |  |
| Six Months Ended March 30, 2014 |  |  |  |  |  |
| Revenues | $ | 8,859 |  |  | $ | 3,971 |  |  | $ | — |  |
| EBT (1) | 1,646 |  |  | 3,504 |  |  | (35 | ) |
| EBT as a % of revenues | 19 | % |  | 88 | % |  |  |  |

[0001234452-15-000134:mdna:62]
[same as prior period, unchanged from 0001234452-15-000024:mdna:56]

[0001234452-15-000134:mdna:63]
QCT Segment. The increases in QCT revenues in the second quarter and the first six months of fiscal 2015 of $191 million and $817 million, respectively, were primarily due to increases in equipment and services revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying Radio Frequency (RF) and Power Management (PM) integrated circuits, were $4.37 billion and $4.19 billion in the second quarter of fiscal 2015 and 2014, respectively, and $9.56 billion and $8.76 billion in the first six months of fiscal 2015 and 2014, respectively. The increases in equipment and services revenues in the second quarter and the first six months of fiscal 2015 resulted primarily from increases of $843 million and $1.84 billion, respectively, related to higher MSM and accompanying RF and PM unit shipments, partially offset by net decreases of $727 million and $1.16 billion, respectively, resulting from lower-priced product mix and lower average selling prices. Approximately 233 million and 188 million MSM integrated circuits were sold during the second quarter of fiscal 2015 and 2014, respectively, and approximately 503 million and 400 million MSM integrated circuits were sold during the first six months of fiscal 2015 and 2014, respectively.

[0001234452-15-000134:mdna:64]
QCT EBT as a percentage of revenues in the first six months of fiscal 2015 increased primarily due to an increase of 9% in QCT revenues relative to an increase of 3% in research and development expenses, partially offset by a decrease in gross margin percentage. The decrease in QCT gross margin percentage in the first six months of fiscal 2015 primarily

[0001234452-15-000134:mdna:65]
[same as prior period, unchanged from 0001234452-15-000024:mdna:83]

[0001234452-15-000134:mdna:66]
resulted from lower average selling prices, lower-margin product mix and higher excess inventory charges, partially offset by lower average unit costs.

[0001234452-15-000134:mdna:67]
QCT inventories increased by 5% in the second quarter of fiscal 2015 from $1.76 billion to $1.86 billion, primarily due to an increase in work-in-process wafer inventories related to the timing of inventory receipts and stages of completion, partially offset by lower average unit costs.

[0001234452-15-000134:mdna:68]
QTL Segment. The increases in QTL revenues in the second quarter and the first six months of fiscal 2015 of $343 million and $259 million, respectively, were primarily due to increases in sales of CDMA-based products, including multimode products that also implement OFDMA, reported by licensees, partially offset by decreases in revenues per reported units. The increase in QTL EBT as a percentage of revenues in the second quarter of fiscal 2015 was primarily due to an increase of 17% in QTL revenues relative to an increase of 6% in costs and expenses. QTL revenues and EBT for the second quarter and the first six months of fiscal 2015 were impacted negatively by units that we believe are not being reported by certain licensees and sales of certain unlicensed products in China. We expect it will take some time for those certain licensees to fully comply with the reporting requirements of their license agreements and for unlicensed companies that had delayed execution of new licenses pending resolution of the NDRC investigation to execute new licenses. We believe that QTL revenues and EBT for the second quarter and the first six months of fiscal 2015 were also impacted negatively by fluctuations in foreign currency exchange rates. We expect this trend will continue into the second half of fiscal 2015.

[0001234452-15-000134:mdna:69]
QSI Segment. The improvements in QSI EBT in the second quarter and the first six months of fiscal 2015 were primarily due to decreases in impairment losses on our strategic investments.

[0001234452-15-000134:mdna:70]
[same as prior period, unchanged from 0001234452-15-000024:mdna:63]

[0001234452-15-000134:mdna:71]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash available from our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. Cash, cash equivalents and marketable securities were $29.6 billion at March 29, 2015, a decrease of $2.4 billion from September 28, 2014. While we do not anticipate using our non-current marketable securities in operations in the foreseeable future, the securities could be liquidated within a short period of time if required. Our cash, cash equivalents and marketable securities at March 29, 2015 consisted of $3.4 billion held by United States-based entities and $26.2 billion held by foreign entities. Most of our cash, cash equivalents and marketable securities held by foreign entities is indefinitely reinvested and would be subject to material tax effects if repatriated. However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate the funds. Total cash provided by operating activities decreased to $1.7 billion during the first six months of fiscal 2015, compared to $4.6 billion during the first six months of fiscal 2014 primarily due to payment of $975 million resulting from the fine imposed by the NDRC and the prepayment of $950 million to secure long-term capacity commitments at a supplier of our integrated circuit products.

[0001234452-15-000134:mdna:72]
Accounts receivable decreased 8% during the second quarter of fiscal 2015. Days sales outstanding, on a consolidated basis, were 27 days at March 29, 2015, compared to 28 days at December 28, 2014. The decrease in accounts receivable was primarily due to the effects of decreased revenues related to integrated circuits. The decrease in days sales outstanding was primarily due to the net effects of the timing of cash payments for licensing relative to the increase in licensing revenues.

[0001234452-15-000134:mdna:73]
In February 2015, we entered into a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. At March 29, 2015, no amounts were outstanding.

[0001234452-15-000134:mdna:74]
In March 2015, we began an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At March 29, 2015, we had $1.1 billion of commercial paper outstanding with weighted-average interest rates of 0.14%, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 58 days.

[0001234452-15-000134:mdna:75]
We paid cash dividends totaling $689 million, or $0.42 per share, on March 25, 2015. On April 8, 2015, we announced a cash dividend of $0.48 per share on our common stock, payable on June 24, 2015 to stockholders of record as of the close of business on June 3, 2015. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-15-000134:mdna:76]
During the first six months of fiscal 2015, we repurchased and retired 50,699,000 shares of our common stock for $3.6 billion, before commissions. On March 9, 2015, we announced that we had been authorized to repurchase up to $15

[0001234452-15-000134:mdna:77]
billion of our common stock. The $15 billion stock repurchase program replaced a $7.8 billion stock repurchase program announced on March 4, 2014, of which $2.1 billion remained authorized for repurchase. At March 29, 2015, approximately $14.5 billion remained authorized for repurchase under our new stock repurchase program. Since March 29, 2015, we repurchased and retired 5,061,000 shares of common stock for $345 million. We intend to return a minimum of 75% of our free cash flow to stockholders through stock repurchases and dividends over the foreseeable future, where free cash flow is defined as net cash provided by operating activities less capital expenditures. Additionally, we intend to repurchase $10 billion of stock within approximately 12 months. To meet this goal, we expect to use existing cash and marketable securities held by, and cash flow generated from, United States-based entities and to issue additional debt, including accessing the public debt markets in the third quarter of fiscal 2015. The amount and timing of additional borrowings will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors. We periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders.

[0001234452-15-000134:mdna:78]
Subject to the foregoing paragraph, we believe our current cash, cash equivalents and marketable securities and our expected cash flow generated from operations and expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements also include:

[0001234452-15-000134:mdna:79]
| • | Our research and development expenditures were $2.7 billion during the first six months of fiscal 2015 and $5.5 billion in fiscal 2014, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications, primarily in the wireless industry. |

[0001234452-15-000134:mdna:80]
| • | Cash outflows for capital expenditures were $449 million during the first six months of fiscal 2015 and $1.2 billion in fiscal 2014. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-15-000134:mdna:81]
| • | Our purchase obligations for the remainder of fiscal 2015 and for fiscal 2016, some of which relate to research and development activities and capital expenditures, totaled $3.2 billion and $1.2 billion, respectively, at March 29, 2015. |

[0001234452-15-000134:mdna:82]
| • | In October 2014, we announced that we had reached agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.3 billion based upon an exchange rate of USD: GBP 1.4929). We expect to use existing cash resources to fund the acquisition. The acquisition has received approval from CSR’s shareholders, and every required regulatory agency has either provided approval or declined to exercise jurisdiction, except for the Ministry of Commerce in China. The completion of the acquisition remains subject to the satisfaction of additional conditions. Subject to the satisfaction of these conditions, the acquisition is expected to close by the end of the summer of 2015. |

[0001234452-15-000134:mdna:83]
[same as prior period, unchanged from 0001234452-15-000024:mdna:74]

[0001234452-15-000134:mdna:84]
In connection with the pending acquisition of CSR, we agreed to set aside certain cash, cash equivalents and marketable securities to be held for purposes of satisfying payment of the consideration to effect the acquisition. At March 29, 2015, the fair value of the marketable securities that were set aside was $3.8 billion. Additionally, $24 million of cash equivalents, which were recorded as other current assets, were set aside. If the combined fair values falls below approximately £1.9 billion (approximately $2.8 billion using an exchange rate of 1.4929), we may be required to set aside additional securities. Additionally, if certain conditions are met, such as a reduction in the liquidity of any of the securities that are set aside, we may be required to liquidate the securities and transfer the cash to a third party until the acquisition closes.

[0001234452-15-000134:mdna:85]
30

[0001234452-15-000134:mdna:86]
[same as prior period, unchanged from 0001234452-15-000024:mdna:76]

[0001234452-15-000134:mdna:87]
[same as prior period, unchanged from 0001234452-15-000024:mdna:77]

[0001234452-15-000134:mdna:88]
Additional information regarding our financial commitments at March 29, 2015 is provided in the notes to our condensed consolidated financial statements. See “Notes to Condensed Consolidated Financial Statements, Note 4 — Income Taxes,” “Note 6 — Debt” and “Note 7 — Commitments and Contingencies.”

[0001234452-15-000134:mdna:89]
[same as prior period, unchanged from 0001234452-15-000024:mdna:79]

[0001234452-15-000134:mdna:90]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The ASU as currently issued will be effective for us starting in the first quarter of fiscal 2018. On April 1, 2015, the FASB voted to propose a one-year deferral to the effective date, but to permit entities to adopt one year earlier if they choose (i.e., the original effective date). The proposal will be subject to the FASB’s due process requirement, which includes a period for public comments. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. We are in the process of determining the adoption method as well as the effects the adoption will have on our consolidated financial statements.

[0001234452-15-000134:mdna:91]
[same as prior period, unchanged from 0001234452-15-000024:mdna:81]

[0001234452-15-000134:mdna:92]
[same as prior period, unchanged from 0001234452-15-000024:mdna:82]

[0001234452-15-000134:mdna:93]
[same as prior period, unchanged from 0001234452-15-000024:mdna:84]

[0001234452-15-000134:mdna:94]
[same as prior period, unchanged from 0001234452-15-000024:mdna:85]

[0001234452-15-000134:mdna:95]
[same as prior period, unchanged from 0001234452-15-000024:mdna:86]

[0001234452-15-000134:mdna:96]
[same as prior period, unchanged from 0001234452-15-000024:mdna:87]

[0001234452-15-000134:mdna:97]
[same as prior period, unchanged from 0001234452-15-000024:mdna:88]

[0001234452-15-000134:mdna:98]
[same as prior period, unchanged from 0001234452-15-000024:mdna:89]

[0001234452-15-000134:mdna:99]
[same as prior period, unchanged from 0001234452-15-000024:mdna:90]

[0001234452-15-000134:mdna:100]
[same as prior period, unchanged from 0001234452-15-000024:mdna:91]

[0001234452-15-000134:mdna:101]
[same as prior period, unchanged from 0001234452-15-000024:mdna:92]

[0001234452-15-000134:mdna:102]
[same as prior period, unchanged from 0001234452-15-000024:mdna:93]

[0001234452-15-000134:mdna:103]
[same as prior period, unchanged from 0001234452-15-000024:mdna:94]

[0001234452-15-000134:mdna:104]
[same as prior period, unchanged from 0001234452-15-000024:mdna:95]

[0001234452-15-000134:mdna:105]
[same as prior period, unchanged from 0001234452-15-000024:mdna:96]

[0001234452-15-000134:mdna:106]
[same as prior period, unchanged from 0001234452-15-000024:mdna:98]

[0001234452-15-000134:mdna:107]
[same as prior period, unchanged from 0001234452-15-000024:mdna:99]

[0001234452-15-000134:mdna:108]
[same as prior period, unchanged from 0001234452-15-000024:mdna:100]

[0001234452-15-000134:mdna:109]
[same as prior period, unchanged from 0001234452-15-000024:mdna:101]

[0001234452-15-000134:mdna:110]
[same as prior period, unchanged from 0001234452-15-000024:mdna:102]

[0001234452-15-000134:mdna:111]
[same as prior period, unchanged from 0001234452-15-000024:mdna:103]

[0001234452-15-000134:mdna:112]
[same as prior period, unchanged from 0001234452-15-000024:mdna:104]

[0001234452-15-000134:mdna:113]
32

[0001234452-15-000134:mdna:114]
[same as prior period, unchanged from 0001234452-15-000024:mdna:105]

[0001234452-15-000134:mdna:115]
[same as prior period, unchanged from 0001234452-15-000024:mdna:106]

[0001234452-15-000134:mdna:116]
[same as prior period, unchanged from 0001234452-15-000024:mdna:107]

[0001234452-15-000134:mdna:117]
| • | create stand-alone value and/or contribute to the success of our existing businesses through acquisitions and other investments (and/or by developing customer, licensee and/or vendor relationships) in new industry segments and/or disruptive technologies, products and/or services (such as the connected home and the Internet of Things, automotive products, new display technology, mobile health, machine learning, including robotics and wireless charging, among others); and/or |

[0001234452-15-000134:mdna:118]
[same as prior period, unchanged from 0001234452-15-000024:mdna:109]

[0001234452-15-000134:mdna:119]
Competition in any or all product tiers, customer concentration and/or growth in sales of mid- and low-tier products, particularly relative to premium-tier products, may reduce average selling prices for our chipset products and the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging geographic regions (e.g., China). Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0001234452-15-000134:mdna:120]
Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM, Wi-Fi) as well as companies that design integrated circuits based on CDMA, OFDMA or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom, Ericsson, HiSilicon Technologies, Intel, Lantiq, Marvell Technology, Maxim Integrated Products, MediaTek, Nvidia, Realtek Semiconductor, Samsung Electronics, Spreadtrum Communications (which is controlled by Tsinghua Unigroup), Texas Instruments and VIA Telecom. Some of these current and potential competitors have advantages over us that include, among others: lower cost structures; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; motivation by our customers in certain circumstances to find alternate suppliers or choose alternative technologies; foreign government support of other technologies or competitors; more extensive relationships with local distribution companies and original equipment manufacturers in emerging geographic regions (such as China); and/or a more established presence in certain device markets.

[0001234452-15-000134:mdna:121]
[same as prior period, unchanged from 0001234452-15-000024:mdna:113]

[0001234452-15-000134:mdna:122]
[same as prior period, unchanged from 0001234452-15-000024:mdna:114]

[0001234452-15-000134:mdna:123]
Our QCT segment derives a significant portion of revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience an increasing concentration of device share among a few companies, contributing to this trend. In addition, certain of our largest integrated circuit customers are part of conglomerates that include certain of our integrated circuit competitors. The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or cancelation of significant purchases from any of these customers would reduce our revenues and could harm our ability to achieve or sustain expected operating results, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Further, concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have little or no control, and the timing of such introductions may cause our operating results to fluctuate. Accordingly, if current industry dynamics and concentrations continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases and the timing and size of any such future purchases by these significant customers.

[0001234452-15-000134:mdna:124]
[same as prior period, unchanged from 0001234452-15-000024:mdna:116]

[0001234452-15-000134:mdna:125]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products and/or intellectual property or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001234452-15-000134:mdna:126]
Although we have more than 265 CDMA-based licensees, our QTL segment derives a significant portion of licensing revenues from a limited number of licensees. In the event that one or more of our significant licensees fail to meet their reporting and/or payment requirements or we are unable to renew one or more of such license agreements, our revenues, operating results and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have little or no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our major licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues.

[0001234452-15-000134:mdna:127]
[same as prior period, unchanged from 0001234452-15-000024:mdna:120]

[0001234452-15-000134:mdna:128]
Although we own a very strong portfolio of issued and pending patents related to GSM, GPRS, EDGE, OFDM, OFDMA, WLAN, MIMO and other technologies, our patent portfolio licensing program in these areas is less established and might not be as successful in generating licensing revenues as our CDMA licensing program. Many wireless operators are investigating, have selected or have deployed OFDMA-based LTE as their next-generation 4G technology in existing (or future if not yet deployed) wireless spectrum bands as complementary to their existing CDMA-based networks. While 3G/4G multimode products are generally covered by our existing 3G licensing agreements, products that implement 4G but do not also implement 3G are generally not covered by these agreements. Although we believe that our patented technology is essential and useful to implementation of the LTE industry standards and have granted royalty-bearing licenses to more than 125 companies (including Huawei, LG, Microsoft, Samsung, Sony Mobile and ZTE) that have realized that they need a license under our patents to make and sell products implementing 4G standards but not implementing 3G standards, it may be difficult to agree on material terms and/or conditions of new license agreements that are acceptable to us with companies that are currently unlicensed, particularly in China. Further, the royalty rates for single mode 4G products are generally lower than our royalty rates for 3G and 3G/4G multimode products, and therefore, we might not achieve the same licensing revenues on such LTE products as on 3G and 3G/4G multimode products. In addition, new connectivity and other services are emerging that rely on devices that may or may

[0001234452-15-000134:mdna:129]
not be used on traditional cellular networks, such as devices used in the connected home or the Internet of Things. We also seek to diversify and broaden our technology licensing programs to new industry segments in which we can leverage our technology leadership, such as wireless charging, display and other technologies. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties that are equivalent to those that we receive for 3G and 3G/4G multimode products used in cellular communications. Although we believe that our patented technology is essential and useful to the commercialization of such services, the royalties we receive may be lower than those we receive from our current licensing program.

[0001234452-15-000134:mdna:130]
[same as prior period, unchanged from 0001234452-15-000024:mdna:122]

[0001234452-15-000134:mdna:131]
The licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date and, in a small number of agreements, royalties are payable on those patents for a specified time period. As a result, there are agreements with some licensees where later patents are not licensed by or to us and/or royalties are not owed to us under such license agreements after the specified time period. In order to license or to obtain a license to such later patents, or to receive royalties after the specified time period, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to modify those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in renewing a license agreement prior to its expiration, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001234452-15-000134:mdna:132]
[same as prior period, unchanged from 0001234452-15-000024:mdna:124]

[0001234452-15-000134:mdna:133]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, or some form of unfair competition; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the imposition of some form of compulsory licensing and/or to weaken a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies in attempts to shift their royalty obligation to their suppliers. In addition, particularly in China, certain licensees have disputed or underreported royalties owed to us under their license agreements with us, and certain companies have yet to enter into or delayed entering into license agreements with us for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future.

[0001234452-15-000134:mdna:134]
We are currently subject to various litigation and governmental investigations and/or proceedings, some of which may arise out of the strategies described above. Certain legal matters are described more fully in the notes to our condensed consolidated financial statements. See “Notes to Condensed Consolidated Financial Statements, Note 7 - Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or modify our business practices.

[0001234452-15-000134:mdna:135]
[same as prior period, unchanged from 0001234452-15-000024:mdna:128]

[0001234452-15-000134:mdna:136]
[same as prior period, unchanged from 0001234452-15-000024:mdna:146]

[0001234452-15-000134:mdna:137]
[same as prior period, unchanged from 0001234452-15-000024:mdna:129]

[0001234452-15-000134:mdna:138]
[same as prior period, unchanged from 0001234452-15-000024:mdna:130]

[0001234452-15-000134:mdna:139]
[same as prior period, unchanged from 0001234452-15-000024:mdna:131]

[0001234452-15-000134:mdna:140]
[same as prior period, unchanged from 0001234452-15-000024:mdna:133]

[0001234452-15-000134:mdna:141]
[same as prior period, unchanged from 0001234452-15-000024:mdna:134]

[0001234452-15-000134:mdna:142]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property rights and/or contracts, including collecting royalties for use of our patent portfolio in particular foreign jurisdictions due to, among others: policies of foreign governments; challenges to our licensing practices under such jurisdictions’ competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and/or challenges pending before foreign competition agencies to the pricing and integration of additional features and functionality into our chipset products. Although our license

[0001234452-15-000134:mdna:143]
36

[0001234452-15-000134:mdna:144]
agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Particularly in China, certain licensees have disputed or underreported royalties owed to us under their license agreements with us, and certain companies have yet to enter into or delayed entering into license agreements for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future.

[0001234452-15-000134:mdna:145]
We may need to litigate in the United States or elsewhere in the world to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable and/or we could incur substantial unexpected operating costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our operating results. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues in the period prior to conclusion.

[0001234452-15-000134:mdna:146]
[same as prior period, unchanged from 0001234452-15-000024:mdna:137]

[0001234452-15-000134:mdna:147]
[same as prior period, unchanged from 0001234452-15-000024:mdna:138]

[0001234452-15-000134:mdna:148]
We are currently subject to various governmental investigations and/or proceedings, and certain matters are described more fully in the notes to our condensed consolidated financial statements. See “Notes to Condensed Consolidated Financial Statements, Note 7 - Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices.

[0001234452-15-000134:mdna:149]
[same as prior period, unchanged from 0001234452-15-000024:mdna:140]

[0001234452-15-000134:mdna:150]
[same as prior period, unchanged from 0001234452-15-000024:mdna:141]

[0001234452-15-000134:mdna:151]
Regulations in the United States require that we determine whether certain materials used in our products, referred to as conflict minerals, originated in the Democratic Republic of the Congo or an adjoining country, or were from recycled or scrap sources. The verification and reporting requirements, in addition to customer demands for conflict free sourcing, impose additional costs on us and on our suppliers, and may limit the sources or increase the prices of materials used in our products. Further, if we are unable to determine that our products are “conflict free,” we may face challenges with our customers that place us at a competitive disadvantage, and our reputation may be harmed.

[0001234452-15-000134:mdna:152]
Laws, regulations and standards relating to corporate governance, business conduct, public disclosure and health care are complex and changing and may create uncertainty regarding compliance. Laws, regulations and standards are subject to varying interpretations in many cases, and their application in practice may evolve over time. As a result, our efforts to comply may fail, particularly if there is ambiguity as to how they should be applied in practice. New laws, regulations and standards or evolving interpretations of legal requirements may cause us to incur higher costs as we revise current practices, policies and/or procedures and may divert management time and attention to compliance activities.

[0001234452-15-000134:mdna:153]
[same as prior period, unchanged from 0001234452-15-000024:mdna:143]

[0001234452-15-000134:mdna:154]
Our industry is subject to rapid technological change, evolving industry standards and frequent new product introductions, and we must make substantial research, development and other investments, such as acquisitions, in new products, services and technologies to compete successfully. Technological innovations generally require significant research and development efforts before they are commercially viable. We intend to continue to make substantial investments in developing new products, services and technologies that we believe can create stand-alone value and/or contribute to the success of our existing businesses. However, it is possible that these initiatives will not be successful and/or will not result in meaningful revenues or generate operating income that meets expectations. While we continue to focus our development efforts primarily in support of 3G CDMA- and 4G OFDMA-based technologies, we innovate across a broad spectrum of opportunities to deploy new business models and enter into new industry segments by leveraging our existing technical and business expertise and/or through acquisitions. Our recent investment initiatives relate to, among others, networking, mobile computing, small cell technology and addressing the challenge of meeting the increased demand for data; products for the connected home and the Internet of Things; automotive; very high speed connectivity; new display technology; data centers; mobile health; wireless charging; and machine learning, including robotics.

[0001234452-15-000134:mdna:155]
[same as prior period, unchanged from 0001234452-15-000024:mdna:145]

[0001234452-15-000134:mdna:156]
[same as prior period, unchanged from 0001234452-15-000024:mdna:147]

[0001234452-15-000134:mdna:157]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe on another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products through a licensed supplier, we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our operating results.

[0001234452-15-000134:mdna:158]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages, royalty payments and/or an injunction on the sale of certain of our integrated circuit products (and on the sale of our customers’ devices using such products). A negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could

[0001234452-15-000134:mdna:159]
38

[0001234452-15-000134:mdna:160]
harm our relationships with them and could result in a decline in our share of worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001234452-15-000134:mdna:161]
[same as prior period, unchanged from 0001234452-15-000024:mdna:150]

[0001234452-15-000134:mdna:162]
[same as prior period, unchanged from 0001234452-15-000024:mdna:151]

[0001234452-15-000134:mdna:163]
[same as prior period, unchanged from 0001234452-15-000024:mdna:152]

[0001234452-15-000134:mdna:164]
Achieving the anticipated benefits of business acquisitions depends in part upon our ability to integrate the acquired businesses in an efficient and effective manner. The integration of companies that have previously operated independently may result in significant challenges, including, among others: retaining key employees; successfully integrating new employees, business systems and technology; retaining customers and suppliers of the acquired business; consolidating research and development and/or supply operations; minimizing the diversion of management’s attention from ongoing business matters; and consolidating corporate and administrative infrastructures. We may not derive any commercial value from acquired technologies or products or from future technologies or products based on the acquired technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, or we may become subject to litigation. Additionally, we may not be successful in expanding into geographic regions and/or categories of products served by or adjacent to an acquired business or in addressing potential new opportunities that may arise out of the combination. In part due to our inexperience with technologies and/or products of and/or geographic regions served by acquired businesses, we may underestimate the costs and/or overestimate the benefits, including product and other synergies and growth opportunities that we expect to realize, and we may not achieve them. If we do not achieve the anticipated benefits of business acquisitions, our results of operations may be adversely affected, and we may not enhance stockholder value by engaging in these transactions.

[0001234452-15-000134:mdna:165]
[same as prior period, unchanged from 0001234452-15-000024:mdna:155]

[0001234452-15-000134:mdna:166]
[same as prior period, unchanged from 0001234452-15-000024:mdna:156]

[0001234452-15-000134:mdna:167]
[same as prior period, unchanged from 0001234452-15-000024:mdna:157]

[0001234452-15-000134:mdna:168]
[same as prior period, unchanged from 0001234452-15-000024:mdna:158]

[0001234452-15-000134:mdna:169]
[same as prior period, unchanged from 0001234452-15-000024:mdna:159]

[0001234452-15-000134:mdna:170]
[same as prior period, unchanged from 0001234452-15-000024:mdna:160]

[0001234452-15-000134:mdna:171]
[same as prior period, unchanged from 0001234452-15-000024:mdna:161]

[0001234452-15-000134:mdna:172]
While we have established alternate suppliers for certain technologies, we rely on sole- or limited-source suppliers for some products, subjecting us to significant risks, including: possible shortages of raw materials or manufacturing capacity; poor product performance; and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established alternate suppliers, these suppliers may require significant levels of support to bring complex technologies to production. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, any future consolidation of foundry suppliers could increase our vulnerability to sole- or limited-source arrangements. Our arrangements with our suppliers may obligate us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies, and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Our inability to meet customer demand due to sole- or limited-sourcing and/or the additional costs that we incur because of these or other supply constraints or because of the need to support alternate suppliers could negatively impact our business, our revenues and our results of operations.

[0001234452-15-000134:mdna:173]
[same as prior period, unchanged from 0001234452-15-000024:mdna:163]

[0001234452-15-000134:mdna:174]
[same as prior period, unchanged from 0001234452-15-000024:mdna:165]

[0001234452-15-000134:mdna:175]
[same as prior period, unchanged from 0001234452-15-000024:mdna:166]

[0001234452-15-000134:mdna:176]
Our stock price and earnings have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and/or earnings include those identified throughout this “Risk Factors” section, volatility of the stock market in general and technology-based companies in particular, announcements concerning us, our suppliers, our competitors or our customers and variations between our actual results or guidance and expectations of securities analysts, among others. Further, increased volatility in the financial markets and/or overall economic conditions may reduce the amounts that we realize in the future on our cash equivalents and/or marketable securities and may reduce our earnings as a result of any impairment charges that we record to reduce recorded values of marketable securities to their fair values.

[0001234452-15-000134:mdna:177]
In the past, securities class action litigation often has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we may be the target of securities litigation in the future. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources.

[0001234452-15-000134:mdna:178]
There are risks associated with our indebtedness.

[0001234452-15-000134:mdna:179]
Our outstanding indebtedness and any additional indebtedness we incur may have negative consequences, including, among others:

[0001234452-15-000134:mdna:180]
| • | requiring us to use cash to pay the principal of and interest on our indebtedness, thereby reducing the amount of cash flow available for other purposes; |

[0001234452-15-000134:mdna:181]
| • | limiting our ability to obtain additional financing for working capital, capital expenditures, acquisitions, stock repurchases, dividends or other general corporate and other purposes; |

[0001234452-15-000134:mdna:182]
| • | limiting our flexibility in planning for, or reacting to, changes in our business and our industry; and/or |

[0001234452-15-000134:mdna:183]
| • | increasing our vulnerability to interest rate fluctuations to the extent a portion of our debt has variable interest rates. |

[0001234452-15-000134:mdna:184]
Our ability to make payments of principal of and interest on our indebtedness depends upon our future performance, which is subject to general economic conditions, industry cycles and financial, business and other factors, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations in the future to service our debt, we may be required to, among other things: repatriate funds to the United States at substantial tax cost; refinance or restructure all or a portion of our indebtedness; reduce or delay planned capital or operating expenditures; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such financing, refinancing or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such financing and/or refinancing are higher than our current rates, interest expense related to such financing and/or refinancing would increase. If there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt in the future and/or the terms of the financing could be adversely affected.

[0001234452-15-000134:mdna:185]
[same as prior period, unchanged from 0001234452-15-000024:mdna:169]

[0001234452-15-000134:mdna:186]
[same as prior period, unchanged from 0001234452-15-000024:mdna:170]

[0001234452-15-000134:mdna:187]
[same as prior period, unchanged from 0001234452-15-000024:mdna:171]

[0001234452-15-000134:mdna:188]
[same as prior period, unchanged from 0001234452-15-000024:mdna:172]

[0001234452-15-000134:mdna:189]
[same as prior period, unchanged from 0001234452-15-000024:mdna:173]

[0001234452-15-000134:mdna:190]
[same as prior period, unchanged from 0001234452-15-000024:mdna:174]

[0001234452-15-000134:mdna:191]
[same as prior period, unchanged from 0001234452-15-000024:mdna:175]

[0001234452-15-000134:mdna:192]
[same as prior period, unchanged from 0001234452-15-000024:mdna:176]

[0001234452-15-000134:mdna:193]
[same as prior period, unchanged from 0001234452-15-000024:mdna:177]

[0001234452-15-000134:mdna:194]
[same as prior period, unchanged from 0001234452-15-000024:mdna:178]

[0001234452-15-000134:mdna:195]
[same as prior period, unchanged from 0001234452-15-000024:mdna:179]

[0001234452-15-000134:mdna:196]
[same as prior period, unchanged from 0001234452-15-000024:mdna:180]

[0001234452-15-000134:mdna:197]
[same as prior period, unchanged from 0001234452-15-000024:mdna:181]

[0001234452-15-000134:mdna:198]
[same as prior period, unchanged from 0001234452-15-000024:mdna:182]

[0001234452-15-000134:mdna:199]
[same as prior period, unchanged from 0001234452-15-000024:mdna:183]

[0001234452-15-000134:mdna:200]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-United States headquarters is located. Significant judgment is required in determining our provision for income taxes. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related litigation could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision and results of operations in the period or periods in which that determination is made could be negatively affected.

[0001234452-15-000134:mdna:201]
[same as prior period, unchanged from 0001234452-15-000024:mdna:185]

[0001234452-15-000134:mdna:202]
Tax rules may change in a manner that adversely affects our future reported financial results or the way we conduct our business. For example, we consider the operating earnings of certain non-United States subsidiaries to be indefinitely reinvested outside the United States based on our current needs for those earnings to be reinvested offshore as well as estimates that future domestic cash generated from operations and/or borrowings will be sufficient to meet future domestic cash needs for the foreseeable future. No provision has been made for United States federal, state or foreign taxes that may result from future remittances of the undistributed earnings of these foreign subsidiaries. Our future financial results and liquidity may be adversely affected if tax rules regarding unrepatriated earnings change, if domestic cash needs require us to repatriate foreign earnings, if the shares of these foreign subsidiaries were sold or otherwise transferred or if the United States international tax rules change as part of comprehensive tax reform or other tax legislation. If our effective tax rates were to increase, particularly in the United States or Singapore, our operating results, cash flows and/or financial condition could be adversely affected.
