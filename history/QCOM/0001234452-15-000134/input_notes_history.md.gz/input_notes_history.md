# QCOM note change history — 0001234452-15-000024 → 0001234452-15-000134


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-04-22):
[0001234452-15-000134:note_history:1]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of approximately $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit will hear the appeal on May 8, 2015 and issue a decision sometime thereafter. On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision now alleges that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. The Company was served with the complaint in this second action on August 28, 2014 and answered on November 17, 2014. The judge’s schedule sets the claim construction hearing for August 12, 2015, the close of discovery for January 2016 and the trial for August 2016.
  (was, 2015-01-28, similarity 0.8929):
[0001234452-15-000024:note_history:1]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of approximately $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The parties are currently submitting appeal briefs to the Court of Appeals for the Federal Circuit, which will schedule a hearing once briefing is completed. On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision now alleges that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. The Company was served with the complaint in this second action on August 28, 2014 and answered on November 17, 2014. The judge has not yet set a schedule, but the parties have jointly proposed a claim construction hearing date in September 2015, a date for the close of discovery in the first half of 2016 and a trial date in early 2017.

- changed (2015-04-22):
[0001234452-15-000134:note_history:2]
Nvidia Corporation v. Qualcomm Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd., and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chip products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District of Delaware complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. On April 2, 2015, the Administrative Law Judge in the ITC investigation issued a claim construction order construing seven claim terms from five of the seven asserted patents. The evidentiary hearing for the investigation is set for June 22 to June 26, 2015. The Initial Determination of the Administrative Law Judge is due October 9, 2015, and the target date for completion of the investigation by the ITC is set for February 10, 2016. The district court case was stayed on October 23, 2014 pending completion of the ITC investigation including appeals.
  (was, 2015-01-28, similarity 0.9468):
[0001234452-15-000024:note_history:2]
Nvidia Corporation v. Qualcomm Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd., and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chip products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District of Delaware complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. The evidentiary hearing for the investigation is set for June 22 to June 26, 2015. The Initial Determination of the Administrative Law Judge is due October 9, 2015, and the target date for completion of the investigation by the Commission is set for February 10, 2016. The district court case was stayed on October 23, 2014 pending completion of the ITC investigation including appeals.

- changed (2015-04-22):
[0001234452-15-000134:note_history:3]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chips and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments during fiscal 2015 with respect to this matter.
  (was, 2015-01-28, similarity 0.9887):
[0001234452-15-000024:note_history:3]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chips and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments with respect to this matter.

- changed (2015-04-22):
[0001234452-15-000134:note_history:4]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 26 different dates, with the next hearing scheduled for May 25, 2015.
  (was, 2015-01-28, similarity 0.9967):
[0001234452-15-000024:note_history:4]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 25 different dates, with the next hearing scheduled for February 25, 2015.

- changed (2015-04-22):
[0001234452-15-000134:note_history:5]
The Company is continuing to cooperate with the SEC and the DOJ, but is unable to predict the outcome of their investigations or any actions that the SEC or DOJ may decide to file.
  (was, 2015-01-28, similarity 0.9773):
[0001234452-15-000024:note_history:5]
The Company is continuing to cooperate with the SEC and the DOJ, but is unable to predict the outcome of their investigations or any action that the SEC may decide to file.

- added (2015-04-22):
[0001234452-15-000134:note_history:6]
China National Development and Reform Commission (NDRC) Investigation: In November 2013, the NDRC notified the Company that it had commenced an investigation of the Company relating to China’s Anti-Monopoly Law (AML). The investigation concerned primarily the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business. On February 9, 2015, the Company announced that it had reached a resolution with the NDRC regarding the investigation. The NDRC issued an Administrative Sanction Decision finding that the Company had violated the AML, and the Company agreed to implement a rectification plan that modifies certain of its business practices in China. The NDRC has reviewed that plan and stated that it satisfies their decision. The Company will not pursue further legal proceedings contesting the NDRC’s findings.

- added (2015-04-22):
[0001234452-15-000134:note_history:7]
The key terms of the rectification plan provide that the Company will offer licenses for devices under its current 3G and 4G essential Chinese patents separately from licenses to its other patents and will provide patent lists during the negotiation process. If the Company seeks a cross license from a Chinese licensee as part of such offer, it will negotiate with the licensee in good faith and provide fair consideration for such rights. For licenses of the Company’s 3G and 4G essential Chinese patents for branded devices sold for use in China starting on January 1, 2015, the Company will charge running royalties of 5% for 3G CDMA or WCDMA devices (including multimode 3G/4G devices) and 3.5% for 4G devices that do not implement CDMA or WCDMA (including 3-mode LTE-TDD devices), in each case using a royalty base of 65% of the net selling price of the device. Consistent with the plan, the Company has offered its existing licensees the revised terms for sales of devices for use in China. The plan also provides that the Company will not condition the sale of baseband chipsets on the chipset customer signing a license agreement with terms that the NDRC found to be unreasonable or on the chipset customer not challenging unreasonable terms in its license agreement. The rectification plan does not require the Company to sell chipsets to any entity that is not a patent licensee of the Company.

- added (2015-04-22):
[0001234452-15-000134:note_history:8]
In addition, the NDRC imposed a fine on the Company of 6.088 billion Chinese Yuan Renminbi (approximately $975 million), which the Company has paid. The Company recorded the amount of the fine in the second quarter of fiscal 2015 as a charge in other expenses.

- added (2015-04-22):
[0001234452-15-000134:note_history:9]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act. The FTC has notified the Company that it is investigating conduct related to standard essential patents and pricing and contracting practices with respect to baseband processors and related products. If a violation of Section 5 is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company continues to cooperate with the FTC as it conducts its investigation.

- changed (2015-04-22):
[0001234452-15-000134:note_history:10]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Article 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU) and Article 53 and/or 54 of the Agreement for the European Economic Area (EEA Agreement). The Company understands that the investigation concerns the sale and/or marketing of the Company’s baseband chipsets, including alleged conditions relating to the provision by the Company of rebates and/or other financial incentives. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. Given that this investigation is in its early stages, it is difficult to predict the outcome or what remedies, if any, may be imposed by the Commission. The Company continues to cooperate with the Commission as it conducts its investigation.
  (was, 2015-01-28, similarity 0.9935):
[0001234452-15-000024:note_history:10]
European Commission Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Article 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU) and Article 53 and/or 54 of the Agreement for the European Economic Area (EEA Agreement). The Company understands that the investigation concerns the sale and/or marketing of the Company’s baseband chipsets, including alleged conditions relating to the provision by the Company of rebates and/or other financial incentives. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. Given that this investigation is in its early stages, it is difficult to predict the outcome or what remedies, if any, may be imposed by the Commission. The Company continues to cooperate with the Commission as it conducts its investigation.

- changed (2015-04-22):
[0001234452-15-000134:note_history:11]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it is conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA).  The Company understands that this investigation concerns primarily its licensing business. If a violation of the MRFTA is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine or requiring modifications to the Company’s licensing practices. Given that this investigation is in its early stages, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. The Company continues to cooperate with the KFTC as it conducts its investigation.
  (was, 2015-01-28, similarity 0.8226):
[0001234452-15-000024:note_history:11]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act. The Company understands that the investigation concerns primarily the Company’s licensing business, including potential breach of FRAND commitments. If a violation of Section 5 is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s licensing practices. Given that this investigation is in its early stages, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company has responded to the FTC’s initial request for documents and continues to cooperate with the FTC as it conducts its investigation.

- added (2015-04-22):
[0001234452-15-000134:note_history:12]
With the exception of the NDRC matter, which has been resolved, the Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at March 29, 2015 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

- changed (2015-04-22):
[0001234452-15-000134:note_history:13]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through March 29, 2015, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.
  (was, 2015-01-28, similarity 0.9934):
[0001234452-15-000024:note_history:13]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through December 28, 2014, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

- changed (2015-04-22):
[0001234452-15-000134:note_history:14]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at March 29, 2015 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.
  (was, 2015-01-28, similarity 0.9929):
[0001234452-15-000024:note_history:14]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at December 28, 2014 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- changed (2015-04-22):
[0001234452-15-000134:note_history:15]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at March 29, 2015 for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 were approximately $3.2 billion, $1.2 billion, $941 million, $797 million and $733 million, respectively, and $208 million thereafter. Of these amounts, for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019, commitments to purchase integrated circuit product inventories comprised $2.5 billion, $994 million, $794 million, $715 million and $665 million, respectively, and $185 million thereafter. Integrated circuit product inventory obligations represent purchase commitments for wafers, die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.
  (was, 2015-01-28, similarity 0.9939):
[0001234452-15-000024:note_history:15]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at December 28, 2014 for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 were approximately $3.8 billion, $1.1 billion, $1.2 billion, $959 million and $892 million, respectively, and $242 million thereafter. Of these amounts, for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019, commitments to purchase integrated circuit product inventories comprised $3.3 billion, $986 million, $956 million, $919 million and $874 million, respectively, and $214 million thereafter. Integrated circuit product inventory obligations represent purchase commitments for wafers, die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

- changed (2015-04-22):
[0001234452-15-000134:note_history:16]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 20 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 are $45 million, $80 million, $61 million, $33 million and $21 million, respectively, and $21 million thereafter.
  (was, 2015-01-28, similarity 0.9947):
[0001234452-15-000024:note_history:16]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 25 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 are $69 million, $80 million, $61 million, $32 million, $21 million, respectively, and $27 million thereafter.

- removed (2015-04-22):
[0001234452-15-000024:note_history:17]
China National Development and Reform Commission (NDRC) Investigation: In November 2013, the NDRC notified the Company that it had commenced an investigation of the Company relating to the Chinese Anti-Monopoly Law (AML). The investigation concerns primarily the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business, including how royalties are calculated in the Company’s patent licenses, the value exchanged for cross-licenses to patents of the Company’s licensees, whether the Company will offer license agreements limited to patents essential to certain standards, whether royalties are sought for the Company’s expired patents, the Company’s policy of selling chipsets only to the Company’s patent licensees, the alleged refusal of the Company to grant patent licenses to chipset manufacturers, and certain other terms and conditions in the Company’s patent license and chipset sale agreements. A broad range of remedies with respect to business practices deemed to violate the AML is potentially available to the NDRC, including but not limited to issuing an order to cease conduct deemed illegal, confiscating gains deemed illegally obtained, imposing a fine in the range of 1% to 10% of the prior year’s revenues and requiring modifications to business practices. Given the limited precedent of enforcement actions and penalties under the AML, it is difficult to predict the outcome of this matter or what remedies may be imposed by the NDRC. The Company continues to cooperate with the NDRC as it conducts its investigation.

- removed (2015-04-22):
[0001234452-15-000024:note_history:18]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at December 28, 2014 for contingent losses associated with these matters based on its belief that, with the exception of the NDRC matter, losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. Regarding the NDRC matter, the Company believes that a loss is probable but that any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-04-22):
[0001234452-15-000134:note_history:19]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 28, 2014. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and six-month periods ended March 29, 2015 and March 30, 2014 included 13 weeks and 26 weeks, respectively.
  (was, 2015-01-28, similarity 0.9599):
[0001234452-15-000024:note_history:19]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 28, 2014. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month periods ended December 28, 2014 and December 29, 2013 included 13 weeks.

- changed (2015-04-22):
[0001234452-15-000134:note_history:20]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 29, 2015 were 21,588,000 and 23,295,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 30, 2014 were 30,989,000 and 32,656,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 18,000 and 744,000 during the three and six months ended March 29, 2015, respectively, and 12,000 and 413,000 during the three and six months ended March 30, 2014, respectively.
  (was, 2015-01-28, similarity 0.7478):
[0001234452-15-000024:note_history:20]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three months ended December 28, 2014 and December 29, 2013 were 25,003,000 and 34,322,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 1,470,000 and 814,000 during the three months ended December 28, 2014 and December 29, 2013, respectively.

- changed (2015-04-22):
[0001234452-15-000134:note_history:21]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | March 29, 2015 |  | March 30, 2014 |
| Cost of equipment and services revenues | $ | 11 |  |  | $ | 13 |  |  | $ | 23 |  |  | $ | 25 |  |
| Research and development | 158 |  |  | 163 |  |  | 333 |  |  | 336 |  |
| Selling, general and administrative | 80 |  |  | 75 |  |  | 166 |  |  | 171 |  |
| Share-based compensation expense before income taxes | 249 |  |  | 251 |  |  | 522 |  |  | 532 |  |
| Related income tax benefit | (43 | ) |  | (53 | ) |  | (86 | ) |  | (109 | ) |
|  | $ | 206 |  |  | $ | 198 |  |  | $ | 436 |  |  | $ | 423 |  |
  (was, 2015-01-28, similarity 0.7619):
[0001234452-15-000024:note_history:21]
|  | Three Months Ended |
|  | December 28, 2014 |  | December 29, 2013 |
| Cost of equipment and services revenues | $ | 12 |  |  | $ | 12 |  |
| Research and development | 174 |  |  | 173 |  |
| Selling, general and administrative | 87 |  |  | 96 |  |
| Share-based compensation expense before income taxes | 273 |  |  | 281 |  |
| Related income tax benefit | (44 | ) |  | (55 | ) |
|  | $ | 229 |  |  | $ | 226 |  |

- added (2015-04-22):
[0001234452-15-000134:note_history:22]
The Company recorded $81 million and $82 million in share-based compensation expense during the six months ended March 29, 2015 and March 30, 2014, respectively, related to share-based awards granted during those periods. At March 29, 2015, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.3 billion, which is expected to be recognized over a weighted-average period of 1.8 years. During the six months ended March 29, 2015 and March 30, 2014, net share-based awards granted, after forfeitures and cancelations, represented 0.4% of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.5% of outstanding shares as of the end of each fiscal period.

- changed (2015-04-22):
[0001234452-15-000134:note_history:23]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The ASU as currently issued will be effective for the Company starting in the first quarter of fiscal 2018. On April 1, 2015, the FASB voted to propose a one-year deferral to the effective date, but to permit entities to adopt one year earlier if they choose (i.e., the original effective date). The proposal will be subject to the FASB’s due process requirement, which includes a period for public comments. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. The Company is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.
  (was, 2015-01-28, similarity 0.853):
[0001234452-15-000024:note_history:23]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. This ASU will be effective for the Company starting in the first quarter of fiscal 2018. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the fiscal 2018 opening retained earnings balance. The Company is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.

- removed (2015-04-22):
[0001234452-15-000024:note_history:24]
The Company recorded $31 million in share-based compensation expense during each of the three months ended December 28, 2014 and December 29, 2013, related to share-based awards granted during those periods. At December 28, 2014, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.5 billion, which is expected to be recognized over a weighted-average period of 2.0 years. During the three months ended December 28, 2014 and December 29, 2013, net share-based awards granted, after forfeitures and cancelations, represented 0.4% of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.4% and 0.5%, respectively, of outstanding shares as of the end of each fiscal period.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2015-04-22):
[0001234452-15-000134:note_history:25]
Note 6 — Debt

- added (2015-04-22):
[0001234452-15-000134:note_history:26]
In February 2015, the Company entered into a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. Proceeds from the Revolving Credit Facility will be used for general corporate purposes. Loans under the Revolving Credit Facility bear interest, at the option of the Company, at either LIBOR (determined in accordance with the Revolving Credit Facility) plus a margin of 0.7% per annum or the Base Rate (determined in accordance with the Revolving Credit Facility), plus an initial margin of 0% per annum. The Revolving Credit Facility has a facility fee, which initially accrues at a rate of 0.05% per annum. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At March 29, 2015, the Company was in compliance with the financial covenant, and the Company had not borrowed any funds under the Revolving Credit Facility.

- added (2015-04-22):
[0001234452-15-000134:note_history:27]
In March 2015, the Company began an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At March 29, 2015, the Company had $1.1 billion of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 0.14%, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 58 days. The carrying value of the outstanding commercial paper approximated its estimated fair value at March 29, 2015.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-04-22):
[0001234452-15-000134:note_history:28]
|  | Current |  | Noncurrent |
|  | March 29, 2015 |  | September 28, 2014 |  | March 29, 2015 |  | September 28, 2014 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 338 |  |  | $ | 320 |  |  | $ | 23 |  |  | $ | 38 |  |
| Corporate bonds and notes | 177 |  |  | 191 |  |  | 345 |  |  | 367 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 240 |  |  | 237 |  |
| Total trading | 515 |  |  | 511 |  |  | 608 |  |  | 642 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 385 |  |  | 805 |  |  | 715 |  |  | 392 |  |
| Corporate bonds and notes | 7,250 |  |  | 6,274 |  |  | 7,668 |  |  | 7,649 |  |
| Mortgage- and asset-backed securities | 1,091 |  |  | 1,063 |  |  | 205 |  |  | 195 |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | 83 |  |
| Common and preferred stock | 572 |  |  | 192 |  |  | 819 |  |  | 1,605 |  |
| Equity funds | — |  |  | — |  |  | 646 |  |  | 541 |  |
| Debt funds | 250 |  |  | 813 |  |  | 2,559 |  |  | 2,560 |  |
| Total available-for-sale | 9,548 |  |  | 9,147 |  |  | 12,659 |  |  | 13,025 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 788 |  |  | 790 |  |
| Total marketable securities | $ | 10,063 |  |  | $ | 9,658 |  |  | $ | 14,055 |  |  | $ | 14,457 |  |
  (was, 2015-01-28, similarity 0.99):
[0001234452-15-000024:note_history:28]
|  | Current |  | Noncurrent |
|  | December 28, 2014 |  | September 28, 2014 |  | December 28, 2014 |  | September 28, 2014 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 314 |  |  | $ | 320 |  |  | $ | 30 |  |  | $ | 38 |  |
| Corporate bonds and notes | 195 |  |  | 191 |  |  | 367 |  |  | 367 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 224 |  |  | 237 |  |
| Total trading | 509 |  |  | 511 |  |  | 621 |  |  | 642 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 500 |  |  | 805 |  |  | 660 |  |  | 392 |  |
| Corporate bonds and notes | 7,612 |  |  | 6,274 |  |  | 7,420 |  |  | 7,649 |  |
| Mortgage- and asset-backed securities | 1,111 |  |  | 1,063 |  |  | 201 |  |  | 195 |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | 83 |  |
| Common and preferred stock | 1,008 |  |  | 192 |  |  | 805 |  |  | 1,605 |  |
| Equity funds | — |  |  | — |  |  | 763 |  |  | 541 |  |
| Debt funds | 723 |  |  | 813 |  |  | 2,514 |  |  | 2,560 |  |
| Total available-for-sale | 10,954 |  |  | 9,147 |  |  | 12,410 |  |  | 13,025 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 784 |  |  | 790 |  |
| Total marketable securities | $ | 11,463 |  |  | $ | 9,658 |  |  | $ | 13,815 |  |  | $ | 14,457 |  |

- changed (2015-04-22):
[0001234452-15-000134:note_history:29]
In connection with the pending acquisition of CSR (Note 9), the Company agreed to set aside certain cash, cash equivalents and marketable securities to be held for purposes of satisfying payment of the consideration to effect the acquisition, which is expected to close by the end of the summer of 2015. At March 29, 2015, the fair values of the marketable securities that were set aside were $2.9 billion of corporate bonds and notes, $717 million of mortgage- and asset-backed securities and $140 million in U.S. Treasury securities and government-related securities. Additionally, $24 million in cash equivalents, which were recorded as other current assets, were set aside. If the combined fair values fall below approximately £1.9 billion (approximately $2.8 billion using an exchange rate of 1.4929), the Company may be required to set aside additional amounts. Additionally, if certain conditions are met, such as a reduction in the liquidity of any of the securities that are set aside, the Company may be required to liquidate the securities and transfer the cash to a third party until the acquisition closes.
  (was, 2015-01-28, similarity 0.9941):
[0001234452-15-000024:note_history:29]
In connection with the pending acquisition of CSR (Note 8), the Company agreed to set aside certain cash, cash equivalents and marketable securities to be held for purposes of satisfying payment of the consideration to effect the acquisition, which is expected to close by the end of the summer of 2015. At December 28, 2014, the fair values of the marketable securities that were set aside were $2.8 billion of corporate bonds and notes, $777 million of mortgage- and asset-backed securities and $146 million in U.S. Treasury securities and government-related securities. Additionally, $38 million in cash equivalents, which were recorded as other current assets, were set aside. If the combined fair values fall below approximately £1.9 billion (approximately $2.8 billion using an exchange rate of 1.51571), the Company may be required to set aside additional amounts. Additionally, if certain conditions are met, such as a reduction in the liquidity of any of the securities that are set aside, the Company may be required to liquidate the securities and transfer the cash to a third party until the acquisition closes.

- changed (2015-04-22):
[0001234452-15-000134:note_history:30]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At March 29, 2015, the Company had an effective ownership interest in the debt fund of 27%. Changes in fair value associated with this investment are recognized in net investment income. During the three and six months ended March 29, 2015, the changes in fair value associated with this investment were negligible. During the three and six months ended March 30, 2014, net increases in fair value associated with this investment were $12 million and $18 million, respectively.
  (was, 2015-01-28, similarity 0.6737):
[0001234452-15-000024:note_history:30]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At December 28, 2014, the Company had an effective ownership interest in the debt fund of 26%. Changes in fair value associated with this investment are recognized in net investment income. During the three months ended December 28, 2014, the net decrease in fair value associated with this investment was $6 million. During the three months ended December 29, 2013, the net increase in fair value associated with this investment was $13 million.

- changed (2015-04-22):
[0001234452-15-000134:note_history:31]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains recognized on debt securities classified as trading held at March 29, 2015 were $14 million and negligible for the three and six months ended March 29, 2015, respectively. Net gains recognized on debt securities classified as trading held at March 30, 2014 were negligible for both the three and six months ended March 30, 2014.
  (was, 2015-01-28, similarity 0.6526):
[0001234452-15-000024:note_history:31]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net losses recognized on debt securities classified as trading held at December 28, 2014 and December 29, 2013 were $12 million for the three months ended December 28, 2014 and negligible for the three months ended December 29, 2013, respectively.

- changed (2015-04-22):
[0001234452-15-000134:note_history:32]
At March 29, 2015, the contractual maturities of available-for-sale debt securities were as follows (in millions):
  (was, 2015-01-28, similarity 0.9589):
[0001234452-15-000024:note_history:32]
At December 28, 2014, the contractual maturities of available-for-sale debt securities were as follows (in millions):

- added (2015-04-22):
[0001234452-15-000134:note_history:33]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| March 29, 2015 | $ | 128 |  |  | $ | (30 | ) |  | $ | 98 |  |
| March 30, 2014 | 227 |  |  | (5 | ) |  | 222 |  |
| For the six months ended |  |  |  |  |  |
| March 29, 2015 | $ | 308 |  |  | $ | (37 | ) |  | $ | 271 |  |
| March 30, 2014 | 343 |  |  | (8 | ) |  | 335 |  |

- added (2015-04-22):
[0001234452-15-000134:note_history:34]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| March 29, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,654 |  |  | $ | 383 |  |  | $ | — |  |  | $ | 2,037 |  |
| Debt securities (including debt funds) | 19,940 |  |  | 311 |  |  | (81 | ) |  | 20,170 |  |
|  | $ | 21,594 |  |  | $ | 694 |  |  | $ | (81 | ) |  | $ | 22,207 |  |
| September 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,769 |  |  | $ | 575 |  |  | $ | (6 | ) |  | $ | 2,338 |  |
| Debt securities (including debt funds) | 19,582 |  |  | 312 |  |  | (60 | ) |  | 19,834 |  |
|  | $ | 21,351 |  |  | $ | 887 |  |  | $ | (66 | ) |  | $ | 22,172 |  |

- changed (2015-04-22):
[0001234452-15-000134:note_history:35]
|  | March 29, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 395 |  |  | $ | (3 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,211 |  |  | (58 | ) |  | 201 |  |  | (10 | ) |
| Mortgage- and asset-backed securities | 535 |  |  | (1 | ) |  | 26 |  |  | — |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | (1 | ) |
| Common and preferred stock | 13 |  |  | — |  |  | 12 |  |  | — |  |
| Debt funds | 784 |  |  | (7 | ) |  | 38 |  |  | (1 | ) |
|  | $ | 5,938 |  |  | $ | (69 | ) |  | $ | 324 |  |  | $ | (12 | ) |
  (was, 2015-01-28, similarity 0.8213):
[0001234452-15-000024:note_history:35]
|  | December 28, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 669 |  |  | $ | (12 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 9,172 |  |  | (115 | ) |  | 77 |  |  | (7 | ) |
| Mortgage- and asset-backed securities | 747 |  |  | (2 | ) |  | 37 |  |  | — |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | (1 | ) |
| Common and preferred stock | 128 |  |  | (10 | ) |  | 23 |  |  | (1 | ) |
| Debt funds | 384 |  |  | (7 | ) |  | 5 |  |  | — |  |
| Equity funds | 388 |  |  | (11 | ) |  | — |  |  | — |  |
|  | $ | 11,488 |  |  | $ | (157 | ) |  | $ | 189 |  |  | $ | (9 | ) |

- changed (2015-04-22):
[0001234452-15-000134:note_history:36]
At March 29, 2015, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.
  (was, 2015-01-28, similarity 0.6684):
[0001234452-15-000024:note_history:36]
At December 28, 2014, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common and preferred stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

- changed (2015-04-22):
[0001234452-15-000134:note_history:37]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was negligible at March 29, 2015 and March 30, 2014.
  (was, 2015-01-28, similarity 0.7514):
[0001234452-15-000024:note_history:37]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was negligible for each of the three months ended December 28, 2014 and December 29, 2013.

- removed (2015-04-22):
[0001234452-15-000024:note_history:38]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| December 28, 2014 | $ | 180 |  |  | $ | (8 | ) |  | $ | 172 |  |
| December 29, 2013 | 116 |  |  | (3 | ) |  | 113 |  |

- removed (2015-04-22):
[0001234452-15-000024:note_history:39]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| December 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 2,133 |  |  | $ | 465 |  |  | $ | (22 | ) |  | $ | 2,576 |  |
| Debt securities (including debt funds) | 20,690 |  |  | 242 |  |  | (144 | ) |  | 20,788 |  |
|  | $ | 22,823 |  |  | $ | 707 |  |  | $ | (166 | ) |  | $ | 23,364 |  |
| September 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,769 |  |  | $ | 575 |  |  | $ | (6 | ) |  | $ | 2,338 |  |
| Debt securities (including debt funds) | 19,582 |  |  | 312 |  |  | (60 | ) |  | 19,834 |  |
|  | $ | 21,351 |  |  | $ | 887 |  |  | $ | (66 | ) |  | $ | 22,172 |  |
