# QCOM notes — 0001234452-15-000134


## qcom:CompositionOfCertainFinancialStatementCaptionsTextBlock

[0001234452-15-000134:notes:1]
[same as prior period, unchanged from 0001234452-15-000024:notes:94]

[0001234452-15-000134:notes:2]
| Accounts Receivable (in millions) |  |  |  |
|  | March 29, 2015 |  | September 28, 2014 |
| Trade, net of allowances for doubtful accounts of $5 and $5, respectively | $ | 2,040 |  |  | $ | 2,362 |  |
| Long-term contracts | 11 |  |  | 17 |  |
| Other | 7 |  |  | 33 |  |
|  | $ | 2,058 |  |  | $ | 2,412 |  |

[0001234452-15-000134:notes:3]
| Inventories (in millions) |  |  |  |
|  | March 29, 2015 |  | September 28, 2014 |
| Raw materials | $ | 1 |  |  | $ | 1 |  |
| Work-in-process | 903 |  |  | 656 |  |
| Finished goods | 957 |  |  | 801 |  |
|  | $ | 1,861 |  |  | $ | 1,458 |  |

[0001234452-15-000134:notes:4]
| Other Current Liabilities (in millions) |  |  |  |
|  | March 29, 2015 |  | September 28, 2014 |
| Customer incentives and other customer-related liabilities | $ | 1,452 |  |  | $ | 1,777 |  |
| Other | 416 |  |  | 466 |  |
|  | $ | 1,868 |  |  | $ | 2,243 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001234452-15-000134:notes:5]
Note 9 — Acquisitions

[0001234452-15-000134:notes:6]
In October 2014, the Company announced that it had reached agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.3 billion based upon an exchange rate of USD: GBP 1.4929). CSR is an innovator in the development of multifunction semiconductor platforms and technologies for the automotive, consumer and voice and music market categories. The acquisition complements the Company’s current offerings by adding products, channels and customers in the growth categories of the Internet of Everything and automotive infotainment, accelerating the Company’s presence and path to leadership. The acquisition has received approval of CSR’s shareholders, and every required regulatory agency has either provided approval or declined to exercise jurisdiction, except for the Ministry of Commerce in China. The completion of the acquisition remains subject to satisfaction of additional conditions. Subject to the satisfaction of these conditions, the acquisition is expected to close by the end of the summer of 2015. In connection with the pending acquisition, the Company agreed to set aside certain cash, cash equivalents and marketable securities (Note 12).


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001234452-15-000134:notes:7]
Note 7 — Commitments and Contingencies

[0001234452-15-000134:notes:8]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of approximately $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit will hear the appeal on May 8, 2015 and issue a decision sometime thereafter. On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision now alleges that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. The Company was served with the complaint in this second action on August 28, 2014 and answered on November 17, 2014. The judge’s schedule sets the claim construction hearing for August 12, 2015, the close of discovery for January 2016 and the trial for August 2016.

[0001234452-15-000134:notes:9]
Nvidia Corporation v. Qualcomm Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd., and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chip products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District of Delaware complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. On April 2, 2015, the Administrative Law Judge in the ITC investigation issued a claim construction order construing seven claim terms from five of the seven asserted patents. The evidentiary hearing for the investigation is set for June 22 to June 26, 2015. The Initial Determination of the Administrative Law Judge is due October 9, 2015, and the target date for completion of the investigation by the ITC is set for February 10, 2016. The district court case was stayed on October 23, 2014 pending completion of the ITC investigation including appeals.

[0001234452-15-000134:notes:10]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. The Company continues to cooperate with the Commission’s preliminary investigation.

[0001234452-15-000134:notes:11]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chips and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments during fiscal 2015 with respect to this matter.

[0001234452-15-000134:notes:12]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 26 different dates, with the next hearing scheduled for May 25, 2015.

[0001234452-15-000134:notes:13]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). As discussed below, FCPA compliance is also the focus of the SEC investigation. The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee has completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.

[0001234452-15-000134:notes:14]
As previously disclosed, the Company discovered, and as a part of its cooperation with these investigations informed the SEC and the DOJ of, instances in which special hiring consideration, gifts or other benefits (collectively, benefits) were provided to several individuals associated with Chinese state-owned companies or agencies. Based on the facts currently known, the Company believes the aggregate monetary value of the benefits in question to be less than $250,000, excluding employment compensation.

[0001234452-15-000134:notes:15]
On March 13, 2014, the Company received a Wells Notice from the SEC’s Los Angeles Regional Office indicating that the staff has made a preliminary determination to recommend that the SEC file an enforcement action against the Company for violations of the anti-bribery, books and records and internal control provisions of the FCPA. The bribery allegations relate to benefits offered or provided to individuals associated with Chinese state-owned companies or agencies. The Wells Notice indicated that the recommendation could involve a civil injunctive action and could seek remedies that include disgorgement of profits, the retention of an independent compliance monitor to review the Company’s FCPA policies and procedures, an injunction, civil monetary penalties and prejudgment interest.

[0001234452-15-000134:notes:16]
A Wells Notice is not a formal allegation or finding by the SEC of wrongdoing or violation of law. Rather, the purpose of a Wells Notice is to give the recipient an opportunity to make a “Wells submission” setting forth reasons why the proposed enforcement action should not be filed and/or bringing additional facts to the SEC’s attention before any decision is made by the SEC as to whether to commence a proceeding. On April 4, 2014 and May 29, 2014, the Company made Wells submissions to the staff of the Los Angeles Regional Office explaining why the Company believes it has not violated the FCPA and therefore enforcement action is not warranted.

[0001234452-15-000134:notes:17]
The Company is continuing to cooperate with the SEC and the DOJ, but is unable to predict the outcome of their investigations or any actions that the SEC or DOJ may decide to file.

[0001234452-15-000134:notes:18]
China National Development and Reform Commission (NDRC) Investigation: In November 2013, the NDRC notified the Company that it had commenced an investigation of the Company relating to China’s Anti-Monopoly Law (AML). The investigation concerned primarily the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business. On February 9, 2015, the Company announced that it had reached a resolution with the NDRC regarding the investigation. The NDRC issued an Administrative Sanction Decision finding that the Company had violated the AML, and the Company agreed to implement a rectification plan that modifies certain of its business practices in China. The NDRC has reviewed that plan and stated that it satisfies their decision. The Company will not pursue further legal proceedings contesting the NDRC’s findings.

[0001234452-15-000134:notes:19]
The key terms of the rectification plan provide that the Company will offer licenses for devices under its current 3G and 4G essential Chinese patents separately from licenses to its other patents and will provide patent lists during the negotiation process. If the Company seeks a cross license from a Chinese licensee as part of such offer, it will negotiate with the licensee in good faith and provide fair consideration for such rights. For licenses of the Company’s 3G and 4G essential Chinese patents for branded devices sold for use in China starting on January 1, 2015, the Company will charge running royalties of 5% for 3G CDMA or WCDMA devices (including multimode 3G/4G devices) and 3.5% for 4G devices that do not implement CDMA or WCDMA (including 3-mode LTE-TDD devices), in each case using a royalty base of 65% of the net selling price of the device. Consistent with the plan, the Company has offered its existing licensees the revised terms for sales of devices for use in China. The plan also provides that the Company will not condition the sale of baseband chipsets on the chipset customer signing a license agreement with terms that the NDRC found to be unreasonable or on the chipset customer not challenging unreasonable terms in its license agreement. The rectification plan does not require the Company to sell chipsets to any entity that is not a patent licensee of the Company.

[0001234452-15-000134:notes:20]
In addition, the NDRC imposed a fine on the Company of 6.088 billion Chinese Yuan Renminbi (approximately $975 million), which the Company has paid. The Company recorded the amount of the fine in the second quarter of fiscal 2015 as a charge in other expenses.

[0001234452-15-000134:notes:21]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act. The FTC has notified the Company that it is investigating conduct related to standard essential patents and pricing and contracting practices with respect to baseband processors and related products. If a violation of Section 5 is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company continues to cooperate with the FTC as it conducts its investigation.

[0001234452-15-000134:notes:22]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Article 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU) and Article 53 and/or 54 of the Agreement for the European Economic Area (EEA Agreement). The Company understands that the investigation concerns the sale and/or marketing of the Company’s baseband chipsets, including alleged conditions relating to the provision by the Company of rebates and/or other financial incentives. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. Given that this investigation is in its early stages, it is difficult to predict the outcome or what remedies, if any, may be imposed by the Commission. The Company continues to cooperate with the Commission as it conducts its investigation.

[0001234452-15-000134:notes:23]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it is conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA).  The Company understands that this investigation concerns primarily its licensing business. If a violation of the MRFTA is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine or requiring modifications to the Company’s licensing practices. Given that this investigation is in its early stages, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. The Company continues to cooperate with the KFTC as it conducts its investigation.

[0001234452-15-000134:notes:24]
With the exception of the NDRC matter, which has been resolved, the Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at March 29, 2015 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001234452-15-000134:notes:25]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through March 29, 2015, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

[0001234452-15-000134:notes:26]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at March 29, 2015 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001234452-15-000134:notes:27]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at March 29, 2015 for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 were approximately $3.2 billion, $1.2 billion, $941 million, $797 million and $733 million, respectively, and $208 million thereafter. Of these amounts, for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019, commitments to purchase integrated circuit product inventories comprised $2.5 billion, $994 million, $794 million, $715 million and $665 million, respectively, and $185 million thereafter. Integrated circuit product inventory obligations represent purchase commitments for wafers, die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

[0001234452-15-000134:notes:28]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 20 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments for the remainder of fiscal 2015 and for each of the subsequent four years from fiscal 2016 through 2019 are $45 million, $80 million, $61 million, $33 million and $21 million, respectively, and $21 million thereafter.


## us-gaap:DebtDisclosureTextBlock

[0001234452-15-000134:notes:29]
Note 6 — Debt

[0001234452-15-000134:notes:30]
In February 2015, the Company entered into a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. Proceeds from the Revolving Credit Facility will be used for general corporate purposes. Loans under the Revolving Credit Facility bear interest, at the option of the Company, at either LIBOR (determined in accordance with the Revolving Credit Facility) plus a margin of 0.7% per annum or the Base Rate (determined in accordance with the Revolving Credit Facility), plus an initial margin of 0% per annum. The Revolving Credit Facility has a facility fee, which initially accrues at a rate of 0.05% per annum. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At March 29, 2015, the Company was in compliance with the financial covenant, and the Company had not borrowed any funds under the Revolving Credit Facility.

[0001234452-15-000134:notes:31]
In March 2015, the Company began an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At March 29, 2015, the Company had $1.1 billion of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 0.14%, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 58 days. The carrying value of the outstanding commercial paper approximated its estimated fair value at March 29, 2015.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001234452-15-000134:notes:32]
Note 10 — Discontinued Operations

[0001234452-15-000134:notes:33]
[same as prior period, unchanged from 0001234452-15-000024:notes:23]


## us-gaap:DividendsDeclaredTableTextBlock

[0001234452-15-000134:notes:34]
During the six months ended March 29, 2015 and March 30, 2014, dividends charged to retained earnings were as follows (in millions, except per share data):

[0001234452-15-000134:notes:35]
|  | 2015 |  | 2014 |
|  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.42 |  |  | $ | 710 |  |  | $ | 0.35 |  |  | $ | 599 |  |
| Second quarter | 0.42 |  |  | 702 |  |  | 0.35 |  |  | 599 |  |
|  | $ | 0.84 |  |  | $ | 1,412 |  |  | $ | 0.70 |  |  | $ | 1,198 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001234452-15-000134:notes:36]
Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 29, 2015 were 21,588,000 and 23,295,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 30, 2014 were 30,989,000 and 32,656,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 18,000 and 744,000 during the three and six months ended March 29, 2015, respectively, and 12,000 and 413,000 during the three and six months ended March 30, 2014, respectively


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001234452-15-000134:notes:37]
[same as prior period, unchanged from 0001234452-15-000024:notes:25]

[0001234452-15-000134:notes:38]
|  | Six Months Ended March 29, 2015 |  | Six Months Ended March 30, 2014 |
|  | Auction RateSecurities |  | Mortgage- and Asset-BackedSecurities |  | Auction RateSecurities |  | Mortgage- and Asset-BackedSecurities |
| Beginning balance of Level 3 | $ | 83 |  |  | $ | 186 |  |  | $ | 83 |  |  | $ | 239 |  |
| Total realized and unrealized gains or losses: |  |  |  |  |  |  |  |
| Included in investment income, net | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Included in other comprehensive income | — |  |  | (4 | ) |  | — |  |  | 1 |  |
| Purchases | — |  |  | 50 |  |  | — |  |  | 49 |  |
| Sales | — |  |  | (41 | ) |  | — |  |  | (18 | ) |
| Settlements | (36 | ) |  | (13 | ) |  | — |  |  | (22 | ) |
| Transfers out of Level 3 | — |  |  | — |  |  | — |  |  | (2 | ) |
| Ending balance of Level 3 | $ | 47 |  |  | $ | 181 |  |  | $ | 83 |  |  | $ | 250 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001234452-15-000134:notes:39]
Note 11 — Fair Value Measurements

[0001234452-15-000134:notes:40]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at March 29, 2015 (in millions):

[0001234452-15-000134:notes:41]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 2,453 |  |  | $ | 2,751 |  |  | $ | — |  |  | $ | 5,204 |  |
| Marketable securities (a) |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 252 |  |  | 1,209 |  |  | — |  |  | 1,461 |  |
| Corporate bonds and notes | — |  |  | 15,440 |  |  | — |  |  | 15,440 |  |
| Mortgage- and asset-backed securities | — |  |  | 1,355 |  |  | 181 |  |  | 1,536 |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | 47 |  |
| Common and preferred stock | 676 |  |  | 715 |  |  | — |  |  | 1,391 |  |
| Equity funds | 646 |  |  | — |  |  | — |  |  | 646 |  |
| Debt funds | — |  |  | 3,597 |  |  | — |  |  | 3,597 |  |
| Total marketable securities | 1,574 |  |  | 22,316 |  |  | 228 |  |  | 24,118 |  |
| Derivative instruments | 1 |  |  | 6 |  |  | — |  |  | 7 |  |
| Other investments (a) | 318 |  |  | — |  |  | — |  |  | 318 |  |
| Total assets measured at fair value | $ | 4,346 |  |  | $ | 25,073 |  |  | $ | 228 |  |  | $ | 29,647 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | 2 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 6 |  |
| Other liabilities | 294 |  |  | — |  |  | — |  |  | 294 |  |
| Total liabilities measured at fair value | $ | 296 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 300 |  |

[0001234452-15-000134:notes:42]
(a) Included amounts that are restricted (Note 12).

[0001234452-15-000134:notes:43]
Activity between Levels of the Fair Value Hierarchy. There were no significant transfers between Level 1 and Level 2 during the six months ended March 29, 2015 or March 30, 2014. When a determination is made to classify an asset or liability within Level 3, the determination is based upon the significance of the unobservable inputs to the overall fair value measurement. The following table includes the activity for marketable securities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-15-000134:notes:44]
The Company recognizes transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. There were no transfers in or out of Level 3 during the six months ended March 29, 2015. Transfers out of Level 3 during the six months ended March 30, 2014 primarily consisted of debt securities with significant upgrades in credit ratings.

[0001234452-15-000134:notes:45]
Nonrecurring Fair Value Measurements. The Company measures certain assets at fair value on a nonrecurring basis. These assets include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During the six months ended March 29, 2015, the Company updated the business plans and related internal forecasts related to the Company’s push-to-talk services business and its display businesses, resulting in impairment charges of $104 million related to goodwill and $27 million related to in-process research and development (IPR&D). During the six months ended March 30, 2014, the Company recorded impairment charges of $444 million to write down certain property, plant and equipment related to one of the Company’s display businesses and $16 million related to goodwill in its former QRS division. The IPR&D impairment charge was recorded in research and development expenses, and the other impairment charges were recorded in other operating expenses. The Company determined the fair values using cost, income and market approaches. The estimation of fair value and cash flows used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During the six months ended March 29, 2015 and March 30, 2014, the Company did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001234452-15-000134:notes:46]
[same as prior period, unchanged from 0001234452-15-000024:notes:34]

[0001234452-15-000134:notes:47]
The Company estimates its annual effective income tax rate for continuing operations to be approximately 21% for fiscal 2015, which is greater than its 14% effective income tax rate for fiscal 2014. Tax benefits from foreign income taxed at rates lower than rates in the United States are expected to be approximately 17% in fiscal 2015, compared to 20% in fiscal 2014.

[0001234452-15-000134:notes:48]
During the second quarter of fiscal 2015, the China National Development and Reform Commission (NDRC) imposed a $975 million fine on the Company (Note 7). The fine is not deductible for tax purposes. Given the significant unusual nature of the fine, it was accounted for discretely in the second quarter of fiscal 2015.  Also, during the second quarter of fiscal 2015, the Company recorded a $61 million tax benefit as a result of a favorable tax audit settlement with the Internal Revenue Service related to Qualcomm Atheros, Inc.’s pre-acquisition 2010 and 2011 tax returns.

[0001234452-15-000134:notes:49]
During the first quarter of fiscal 2015, the United States government reinstated the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. As a result of the reinstatement, the Company recorded a tax benefit of $101 million related to fiscal 2014 in the first quarter of fiscal 2015. Additionally, the estimated annual effective tax rate for fiscal 2015 reflects the United States federal research and development tax credit generated through December 31, 2014, the date on which the credit expired. The annual effective tax rate for fiscal 2014 reflected the tax benefit from the credit generated through December 31, 2013, the date on which the credit previously expired.

[0001234452-15-000134:notes:50]
The effective tax rate of 32% for the second quarter of fiscal 2015 was greater than the estimated annual effective tax rate of 21% primarily as a result of the NDRC fine, partially offset by the favorable tax audit settlement.


## us-gaap:InterestAndOtherIncomeTextBlock

[0001234452-15-000134:notes:51]
[same as prior period, unchanged from 0001234452-15-000024:notes:37]

[0001234452-15-000134:notes:52]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | March 29, 2015 |  | March 30, 2014 |
| Interest and dividend income | $ | 138 |  |  | $ | 167 |  |  | $ | 272 |  |  | $ | 322 |  |
| Interest expense | (1 | ) |  | (3 | ) |  | (2 | ) |  | (5 | ) |
| Net realized gains on marketable securities | 108 |  |  | 243 |  |  | 264 |  |  | 371 |  |
| Net realized gains on other investments | 3 |  |  | — |  |  | 13 |  |  | 17 |  |
| Impairment losses on marketable securities | (27 | ) |  | (112 | ) |  | (89 | ) |  | (141 | ) |
| Impairment losses on other investments | (14 | ) |  | (11 | ) |  | (17 | ) |  | (18 | ) |
| Net gains on derivative instruments | 2 |  |  | — |  |  | 6 |  |  | 4 |  |
| Equity in net losses of investees | (9 | ) |  | (4 | ) |  | (13 | ) |  | (5 | ) |
| Net gains on deconsolidation of subsidiaries | 3 |  |  | 2 |  |  | 3 |  |  | 1 |  |
|  | $ | 203 |  |  | $ | 282 |  |  | $ | 437 |  |  | $ | 546 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001234452-15-000134:notes:53]
At March 29, 2015, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001234452-15-000134:notes:54]
| Years to Maturity |  |  |  |  |
| Less Than One Year |  | One to Five Years |  | Five to Ten Years |  | Greater Than Ten Years |  | No Single Maturity Date |  | Total |
| $ | 2,818 |  |  | $ | 11,245 |  |  | $ | 1,363 |  |  | $ | 592 |  |  | $ | 4,152 |  |  | $ | 20,170 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001234452-15-000134:notes:55]
Note 12 — Marketable Securities

[0001234452-15-000134:notes:56]
Marketable securities were comprised as follows (in millions):

[0001234452-15-000134:notes:57]
|  | Current |  | Noncurrent |
|  | March 29, 2015 |  | September 28, 2014 |  | March 29, 2015 |  | September 28, 2014 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 338 |  |  | $ | 320 |  |  | $ | 23 |  |  | $ | 38 |  |
| Corporate bonds and notes | 177 |  |  | 191 |  |  | 345 |  |  | 367 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 240 |  |  | 237 |  |
| Total trading | 515 |  |  | 511 |  |  | 608 |  |  | 642 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 385 |  |  | 805 |  |  | 715 |  |  | 392 |  |
| Corporate bonds and notes | 7,250 |  |  | 6,274 |  |  | 7,668 |  |  | 7,649 |  |
| Mortgage- and asset-backed securities | 1,091 |  |  | 1,063 |  |  | 205 |  |  | 195 |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | 83 |  |
| Common and preferred stock | 572 |  |  | 192 |  |  | 819 |  |  | 1,605 |  |
| Equity funds | — |  |  | — |  |  | 646 |  |  | 541 |  |
| Debt funds | 250 |  |  | 813 |  |  | 2,559 |  |  | 2,560 |  |
| Total available-for-sale | 9,548 |  |  | 9,147 |  |  | 12,659 |  |  | 13,025 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 788 |  |  | 790 |  |
| Total marketable securities | $ | 10,063 |  |  | $ | 9,658 |  |  | $ | 14,055 |  |  | $ | 14,457 |  |

[0001234452-15-000134:notes:58]
In connection with the pending acquisition of CSR (Note 9), the Company agreed to set aside certain cash, cash equivalents and marketable securities to be held for purposes of satisfying payment of the consideration to effect the acquisition, which is expected to close by the end of the summer of 2015. At March 29, 2015, the fair values of the marketable securities that were set aside were $2.9 billion of corporate bonds and notes, $717 million of mortgage- and asset-backed securities and $140 million in U.S. Treasury securities and government-related securities. Additionally, $24 million in cash equivalents, which were recorded as other current assets, were set aside. If the combined fair values fall below approximately £1.9 billion (approximately $2.8 billion using an exchange rate of 1.4929), the Company may be required to set aside additional amounts. Additionally, if certain conditions are met, such as a reduction in the liquidity of any of the securities that are set aside, the Company may be required to liquidate the securities and transfer the cash to a third party until the acquisition closes.

[0001234452-15-000134:notes:59]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At March 29, 2015, the Company had an effective ownership interest in the debt fund of 27%. Changes in fair value associated with this investment are recognized in net investment income. During the three and six months ended March 29, 2015, the changes in fair value associated with this investment were negligible. During the three and six months ended March 30, 2014, net increases in fair value associated with this investment were $12 million and $18 million, respectively.

[0001234452-15-000134:notes:60]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains recognized on debt securities classified as trading held at March 29, 2015 were $14 million and negligible for the three and six months ended March 29, 2015, respectively. Net gains recognized on debt securities classified as trading held at March 30, 2014 were negligible for both the three and six months ended March 30, 2014.

[0001234452-15-000134:notes:61]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities, auction rate securities and corporate bonds and notes.

[0001234452-15-000134:notes:62]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001234452-15-000134:notes:63]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| March 29, 2015 | $ | 128 |  |  | $ | (30 | ) |  | $ | 98 |  |
| March 30, 2014 | 227 |  |  | (5 | ) |  | 222 |  |
| For the six months ended |  |  |  |  |  |
| March 29, 2015 | $ | 308 |  |  | $ | (37 | ) |  | $ | 271 |  |
| March 30, 2014 | 343 |  |  | (8 | ) |  | 335 |  |

[0001234452-15-000134:notes:64]
Available-for-sale securities were comprised as follows (in millions):

[0001234452-15-000134:notes:65]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| March 29, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,654 |  |  | $ | 383 |  |  | $ | — |  |  | $ | 2,037 |  |
| Debt securities (including debt funds) | 19,940 |  |  | 311 |  |  | (81 | ) |  | 20,170 |  |
|  | $ | 21,594 |  |  | $ | 694 |  |  | $ | (81 | ) |  | $ | 22,207 |  |
| September 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,769 |  |  | $ | 575 |  |  | $ | (6 | ) |  | $ | 2,338 |  |
| Debt securities (including debt funds) | 19,582 |  |  | 312 |  |  | (60 | ) |  | 19,834 |  |
|  | $ | 21,351 |  |  | $ | 887 |  |  | $ | (66 | ) |  | $ | 22,172 |  |

[0001234452-15-000134:notes:66]
The following table shows the gross unrealized losses and fair values of the Company’s investments in individual securities that are classified as available-for-sale and have been in a continuous unrealized loss position deemed to be temporary for less than 12 months and for more than 12 months, aggregated by investment category (in millions):

[0001234452-15-000134:notes:67]
|  | March 29, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 395 |  |  | $ | (3 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,211 |  |  | (58 | ) |  | 201 |  |  | (10 | ) |
| Mortgage- and asset-backed securities | 535 |  |  | (1 | ) |  | 26 |  |  | — |  |
| Auction rate securities | — |  |  | — |  |  | 47 |  |  | (1 | ) |
| Common and preferred stock | 13 |  |  | — |  |  | 12 |  |  | — |  |
| Debt funds | 784 |  |  | (7 | ) |  | 38 |  |  | (1 | ) |
|  | $ | 5,938 |  |  | $ | (69 | ) |  | $ | 324 |  |  | $ | (12 | ) |

[0001234452-15-000134:notes:68]
|  | September 28, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 279 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,924 |  |  | (31 | ) |  | 104 |  |  | (4 | ) |
| Mortgage- and asset-backed securities | 484 |  |  | (1 | ) |  | 52 |  |  | (1 | ) |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Common and preferred stock | 86 |  |  | (3 | ) |  | 52 |  |  | (3 | ) |
| Debt funds | 133 |  |  | (1 | ) |  | 384 |  |  | (19 | ) |
|  | $ | 5,906 |  |  | $ | (38 | ) |  | $ | 675 |  |  | $ | (28 | ) |

[0001234452-15-000134:notes:69]
At March 29, 2015, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

[0001234452-15-000134:notes:70]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was negligible at March 29, 2015 and March 30, 2014.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001234452-15-000134:notes:71]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The ASU as currently issued will be effective for the Company starting in the first quarter of fiscal 2018. On April 1, 2015, the FASB voted to propose a one-year deferral to the effective date, but to permit entities to adopt one year earlier if they choose (i.e., the original effective date). The proposal will be subject to the FASB’s due process requirement, which includes a period for public comments. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. The Company is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001234452-15-000134:notes:72]
[same as prior period, unchanged from 0001234452-15-000024:notes:58]

[0001234452-15-000134:notes:73]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 28, 2014. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and six-month periods ended March 29, 2015 and March 30, 2014 included 13 weeks and 26 weeks, respectively.

[0001234452-15-000134:notes:74]
[same as prior period, unchanged from 0001234452-15-000024:notes:60]

[0001234452-15-000134:notes:75]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 29, 2015 were 21,588,000 and 23,295,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 30, 2014 were 30,989,000 and 32,656,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 18,000 and 744,000 during the three and six months ended March 29, 2015, respectively, and 12,000 and 413,000 during the three and six months ended March 30, 2014, respectively.

[0001234452-15-000134:notes:76]
[same as prior period, unchanged from 0001234452-15-000024:notes:62]

[0001234452-15-000134:notes:77]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | March 29, 2015 |  | March 30, 2014 |
| Cost of equipment and services revenues | $ | 11 |  |  | $ | 13 |  |  | $ | 23 |  |  | $ | 25 |  |
| Research and development | 158 |  |  | 163 |  |  | 333 |  |  | 336 |  |
| Selling, general and administrative | 80 |  |  | 75 |  |  | 166 |  |  | 171 |  |
| Share-based compensation expense before income taxes | 249 |  |  | 251 |  |  | 522 |  |  | 532 |  |
| Related income tax benefit | (43 | ) |  | (53 | ) |  | (86 | ) |  | (109 | ) |
|  | $ | 206 |  |  | $ | 198 |  |  | $ | 436 |  |  | $ | 423 |  |

[0001234452-15-000134:notes:78]
The Company recorded $81 million and $82 million in share-based compensation expense during the six months ended March 29, 2015 and March 30, 2014, respectively, related to share-based awards granted during those periods. At March 29, 2015, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.3 billion, which is expected to be recognized over a weighted-average period of 1.8 years. During the six months ended March 29, 2015 and March 30, 2014, net share-based awards granted, after forfeitures and cancelations, represented 0.4% of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.5% of outstanding shares as of the end of each fiscal period.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001234452-15-000134:notes:79]
[same as prior period, unchanged from 0001234452-15-000024:notes:66]

[0001234452-15-000134:notes:80]
|  | March 29, 2015 |  | September 28, 2014 |
| QCT | $ | 3,412 |  |  | $ | 3,639 |  |
| QTL | 475 |  |  | 161 |  |
| QSI | 614 |  |  | 484 |  |
| Reconciling items | 42,672 |  |  | 44,290 |  |
| Total consolidated assets | $ | 47,173 |  |  | $ | 48,574 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001234452-15-000134:notes:81]
Reconciling items in the previous table were as follows (in millions):

[0001234452-15-000134:notes:82]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | March 29, 2015 |  | March 30, 2014 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 47 |  |  | $ | 53 |  |  | $ | 90 |  |  | $ | 162 |  |
| Intersegment eliminations | (1 | ) |  | — |  |  | (3 | ) |  | (3 | ) |
|  | $ | 46 |  |  | $ | 53 |  |  | $ | 87 |  |  | $ | 159 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of equipment and services revenues | $ | (74 | ) |  | $ | (75 | ) |  | $ | (152 | ) |  | $ | (148 | ) |
| Unallocated research and development expenses | (226 | ) |  | (217 | ) |  | (437 | ) |  | (434 | ) |
| Unallocated selling, general and administrative expenses | (100 | ) |  | (85 | ) |  | (249 | ) |  | (210 | ) |
| Unallocated other expense | (1,010 | ) |  | — |  |  | (1,079 | ) |  | (12 | ) |
| Unallocated investment income, net | 232 |  |  | 314 |  |  | 462 |  |  | 571 |  |
| Nonreportable segments | (163 | ) |  | (200 | ) |  | (311 | ) |  | (853 | ) |
| Intersegment eliminations | — |  |  | — |  |  | (1 | ) |  | — |  |
|  | $ | (1,341 | ) |  | $ | (263 | ) |  | $ | (1,767 | ) |  | $ | (1,086 | ) |

[0001234452-15-000134:notes:83]
[same as prior period, unchanged from 0001234452-15-000024:notes:68]

[0001234452-15-000134:notes:84]
|  | Three Months Ended |  | Six Months Ended |
|  | March 29, 2015 |  | March 30, 2014 |  | March 29, 2015 |  | March 30, 2014 |
| Cost of equipment and services revenues | $ | 63 |  |  | $ | 62 |  |  | $ | 129 |  |  | $ | 123 |  |
| Research and development expenses | 3 |  |  | 22 |  |  | 8 |  |  | 23 |  |
| Selling, general and administrative expenses | 13 |  |  | 6 |  |  | 25 |  |  | 13 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001234452-15-000134:notes:85]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity during the six months ended March 29, 2015 were as follows (in millions):

[0001234452-15-000134:notes:86]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Total Accumulated Other Comprehensive Income |
| Balance at September 28, 2014 | $ | (113 | ) |  | $ | 24 |  |  | $ | 723 |  |  | $ | 634 |  |
| Other comprehensive loss before reclassifications | (31 | ) |  | (7 | ) |  | (6 | ) |  | (44 | ) |
| Reclassifications from accumulated other comprehensive income | — |  |  | 4 |  |  | (122 | ) |  | (118 | ) |
| Other comprehensive loss | (31 | ) |  | (3 | ) |  | (128 | ) |  | (162 | ) |
| Balance at March 29, 2015 | $ | (144 | ) |  | $ | 21 |  |  | $ | 595 |  |  | $ | 472 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001234452-15-000134:notes:87]
[same as prior period, unchanged from 0001234452-15-000024:notes:76]

[0001234452-15-000134:notes:88]
|  | QCT |  | QTL |  | QSI |  | ReconcilingItems |  | Total |
| For the three months ended |  |  |  |  |  |  |  |  |  |
| March 29, 2015 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 4,434 |  |  | $ | 2,414 |  |  | $ | — |  |  | $ | 46 |  |  | $ | 6,894 |  |
| EBT | 750 |  |  | 2,162 |  |  | (32 | ) |  | (1,341 | ) |  | 1,539 |  |
| March 30, 2014 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 4,243 |  |  | $ | 2,071 |  |  | $ | — |  |  | $ | 53 |  |  | $ | 6,367 |  |
| EBT | 740 |  |  | 1,834 |  |  | (39 | ) |  | (263 | ) |  | 2,272 |  |
| For the six months ended |  |  |  |  |  |  |  |  |  |
| March 29, 2015 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 9,676 |  |  | $ | 4,230 |  |  | $ | — |  |  | $ | 87 |  |  | $ | 13,993 |  |
| EBT | 1,896 |  |  | 3,741 |  |  | (33 | ) |  | (1,767 | ) |  | 3,837 |  |
| March 30, 2014 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 8,859 |  |  | $ | 3,971 |  |  | $ | — |  |  | $ | 159 |  |  | $ | 12,989 |  |
| EBT | 1,646 |  |  | 3,504 |  |  | (35 | ) |  | (1,086 | ) |  | 4,029 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001234452-15-000134:notes:89]
Changes in stockholders’ equity for the six months ended March 29, 2015 were as follows (in millions):

[0001234452-15-000134:notes:90]
|  | Qualcomm Stockholders’ Equity |  | Noncontrolling Interests |  | Total Stockholders’ Equity |
| Balance at September 28, 2014 | $ | 39,169 |  |  | $ | (3 | ) |  | $ | 39,166 |  |
| Net income (loss) | 3,025 |  |  | (2 | ) |  | 3,023 |  |
| Other comprehensive loss | (162 | ) |  | — |  |  | (162 | ) |
| Common stock issued under employee benefit plans and related tax benefits | 476 |  |  | — |  |  | 476 |  |
| Share-based compensation | 548 |  |  | — |  |  | 548 |  |
| Tax withholding related to vesting of restricted stock units | (193 | ) |  | — |  |  | (193 | ) |
| Dividends | (1,412 | ) |  | — |  |  | (1,412 | ) |
| Stock repurchases | (3,611 | ) |  | — |  |  | (3,611 | ) |
| Other | (1 | ) |  | — |  |  | (1 | ) |
| Balance at March 29, 2015 | $ | 37,839 |  |  | $ | (5 | ) |  | $ | 37,834 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001234452-15-000134:notes:91]
Note 8 — Segment Information

[0001234452-15-000134:notes:92]
The Company is organized on the basis of products and services. The Company conducts business primarily through two reportable segments: QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing), and its QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. The Company also has nonreportable segments, including its QMT (Qualcomm MEMS Technologies), Pixtronix and Small Cells divisions and other wireless technology and service initiatives.

[0001234452-15-000134:notes:93]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT) from continuing operations. Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization and impairment of certain intangible assets and certain other acquisition-related charges, and beginning in the first quarter of fiscal 2015, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. The table below presents revenues and EBT for reportable segments (in millions):

[0001234452-15-000134:notes:94]
[same as prior period, unchanged from 0001234452-15-000024:notes:87]

[0001234452-15-000134:notes:95]
Unallocated other expense for the six months ended March 29, 2015 included a $975 million charge related to the resolution reached with the NDRC (Note 7) and $104 million in goodwill impairment charges related to two of the Company’s nonreportable segments (Note 11). Nonreportable segments EBT for the six months ended March 30, 2014 included $444 million in impairment charges related to property, plant and equipment (Note 11).

[0001234452-15-000134:notes:96]
[same as prior period, unchanged from 0001234452-15-000024:notes:89]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001234452-15-000134:notes:97]
[same as prior period, unchanged from 0001234452-15-000024:notes:90]

[0001234452-15-000134:notes:98]
Reclassifications from accumulated other comprehensive income related to available-for-sale securities and foreign currency translation adjustment of $47 million and $118 million for the three and six months ended March 29, 2015, respectively, and $71 million and $124 million for the three and six months ended March 30, 2014, respectively, were recorded in investment income, net (Note 3). Reclassifications from accumulated other comprehensive income related to derivative instruments of $7 million and $13 million for the three and six months ended March 30, 2014, respectively, were recorded in revenues, cost of equipment and services revenues, research and development expenses and selling, general and administrative expenses.

[0001234452-15-000134:notes:99]
Stock Repurchase Program. On March 9, 2015, the Company announced a stock repurchase program authorizing it to repurchase up to $15 billion of the Company’s common stock. The stock repurchase program has no expiration date. The $15 billion stock repurchase program replaced a $7.8 billion stock repurchase program announced on March 4, 2014, of which $2.1 billion remained authorized for repurchase. During the six months ended March 29, 2015 and March 30, 2014, the Company repurchased and retired 50,699,000 and 27,586,000 shares of common stock, respectively, for $3.6 billion and $2.0 billion, respectively, before commissions. At March 29, 2015, approximately $14.5 billion remained authorized for repurchase under the Company’s stock repurchase program. Since March 29, 2015, the Company repurchased and retired 5,061,000 shares of common stock for $345 million.

[0001234452-15-000134:notes:100]
Dividends. On March 9, 2015, the Company announced a 14% increase in its quarterly cash dividend per share of common stock from $0.42 to $0.48, which is effective for dividends payable after March 25, 2015. On April 8, 2015, the Company announced a cash dividend of $0.48 per share on the Company’s common stock, payable on June 24, 2015 to stockholders of record as of the close of business on June 3, 2015. During the six months ended March 29, 2015 and March 30, 2014, dividends charged to retained earnings were as follows (in millions, except per share data):
