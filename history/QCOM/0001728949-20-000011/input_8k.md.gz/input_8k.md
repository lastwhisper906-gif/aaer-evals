# QCOM 8-K — 0001728949-20-000010 filed 2020-02-05

## item codes, every 8-K on or before 2020-02-05

- 2020-02-05 0001728949-20-000010 — 2.02, 9.01
- 2019-11-06 0001728949-19-000074 — 5.02
- 2019-11-06 0001728949-19-000071 — 2.02, 9.01
- 2019-08-28 0001728949-19-000058 — 5.02
- 2019-07-31 0001728949-19-000053 — 2.02, 9.01
- 2019-05-10 0001728949-19-000044 — 5.02
- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2020-02-05

- none on or before 2020-02-05

## item 2.02 — earnings release, exhibit 99.1

[0001728949-20-000010:8k_2_02:1]
EX-99.1
2
qcom122919erex991.htm
EXHIBIT 99.1

[0001728949-20-000010:8k_2_02:2]
Exhibit

[0001728949-20-000010:8k_2_02:3]
Exhibit 99.1

[0001728949-20-000010:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001728949-20-000010:8k_2_02:5]
Qualcomm Contact:

[0001728949-20-000010:8k_2_02:6]
Mauricio Lopez-Hodoyan

[0001728949-20-000010:8k_2_02:7]
Vice President, Investor Relations

[0001728949-20-000010:8k_2_02:8]
Phone: 1-858-658-4813

[0001728949-20-000010:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001728949-20-000010:8k_2_02:10]
Qualcomm Announces First Quarter Fiscal 2020 Results

[0001728949-20-000010:8k_2_02:11]
Revenues $5.1 billion

[0001728949-20-000010:8k_2_02:12]
GAAP EPS $0.80, Non-GAAP EPS $0.99

[0001728949-20-000010:8k_2_02:13]
SAN DIEGO - February 5, 2020 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal first quarter ended December 29, 2019.

[0001728949-20-000010:8k_2_02:14]
"Our strong fiscal first quarter financial performance reflects a significant inflection point for Qualcomm as we begin to realize the benefits from the ramp of 5G,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.

[0001728949-20-000010:8k_2_02:15]
First Quarter Results ¹

[0001728949-20-000010:8k_2_02:16]
|  | GAAP |  | Non-GAAP |
| (in millions, except per share data and percentages) | Q1 Fiscal 2020 |  | Q1 Fiscal 2019 |  | Change |  | Q1 Fiscal 2020 |  | Q1 Fiscal 2019 |  | Change |
| Revenues | $5,077 |  | $4,842 |  | +5% |  | $5,057 |  | $4,815 |  | +5% |
| Earnings before taxes (EBT) | $947 |  | $559 |  | +69% |  | $1,334 |  | $1,044 |  | +28% |
| Net income | $925 |  | $1,068 |  | (13%) |  | $1,151 |  | $1,464 |  | (21%) |
| Diluted earnings per share | $0.80 |  | $0.87 |  | (8%) |  | $0.99 |  | $1.20 |  | (18%) |

[0001728949-20-000010:8k_2_02:17]
1  Discussion regarding our use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results, as well as information that should be considered in regard to year-over-year comparisons, are included at the end of this news release.

[0001728949-20-000010:8k_2_02:18]
Segment Results

[0001728949-20-000010:8k_2_02:19]
|  | QCT |  | QTL |
| (in millions, except percentages) | Q1 Fiscal 2020 |  | Q1 Fiscal 2019 |  | Change |  | Q1 Fiscal 2020 |  | Q1 Fiscal 2019 |  | Change |
| Revenues | $3,618 |  | $3,739 |  | (3%) |  | $1,404 |  | $1,018 |  | +38% |
| EBT | $479 |  | $598 |  | (20%) |  | $1,017 |  | $590 |  | +72% |
| EBT as % of revenues | 13% |  | 16% |  | -3 points |  | 72% |  | 58% |  | +14 points |
| MSMTM chip shipments | 155 |  | 186 |  | (17%) |  |  |  |  |  |  |

[0001728949-20-000010:8k_2_02:20]
Return of Capital to Stockholders

[0001728949-20-000010:8k_2_02:21]
During the first quarter of fiscal 2020, we returned $1.5 billion to stockholders, including $710 million, or $0.62 per share, of cash dividends paid and $762 million through repurchases of 9.2 million shares of common stock.

[0001728949-20-000010:8k_2_02:22]
| Qualcomm Announces First Quarter Fiscal 2020 Results | Page 2 of 8 |

[0001728949-20-000010:8k_2_02:23]
Business Outlook

[0001728949-20-000010:8k_2_02:24]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.

[0001728949-20-000010:8k_2_02:25]
|  |  | Current Guidance Q2 FY20 Estimates (1)(2)(3) |  |
|  | Revenues | $4.9B - $5.7B |  |  |
|  | GAAP diluted EPS | $0.50 - $0.65 |  |  |
|  | Less diluted EPS attributable to QSI |  | $— |  |  |
|  | Less diluted EPS attributable to share-based compensation |  | ($0.23 | ) |  |
|  | Less diluted EPS attributable to other items (4) |  | ($0.07 | ) |  |
|  | Non-GAAP diluted EPS | $0.80 - $0.95 |  |  |
|  | Other Information |  |  |
|  | MSM chip shipments | 125M - 145M |  |  |
|  | QCT revenues | $3.9B - $4.5B |  |  |
|  | QTL revenues | $1.0B - $1.2B |  |  |

[0001728949-20-000010:8k_2_02:26]
| (1) | Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable. Further, due to their nature, certain income and expense items, such as certain investments, derivative and foreign currency transaction gains or losses, cannot be accurately forecast. Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook. |

[0001728949-20-000010:8k_2_02:27]
| (2) | Our guidance for revenues and EPS for the second quarter of fiscal 2020 excludes QTL revenues from Huawei and includes QTL revenues from two key Chinese licensees under license agreements that were extended and now expire on March 31, 2020. |

[0001728949-20-000010:8k_2_02:28]
| (3) | Our guidance for the second quarter of fiscal 2020 includes an estimate of the potential impact of the recent outbreak of a coronavirus; however, the actual impact may differ materially. |

[0001728949-20-000010:8k_2_02:29]
| (4) | Our guidance for EPS attributable to other items for the second quarter of fiscal 2020 is primarily attributable to acquisition-related items. |

[0001728949-20-000010:8k_2_02:30]
| Qualcomm Announces First Quarter Fiscal 2020 Results | Page 3 of 8 |

[0001728949-20-000010:8k_2_02:31]
Conference Call

[0001728949-20-000010:8k_2_02:32]
Qualcomm’s first quarter fiscal 2020 earnings conference call will be broadcast live on February 5, 2020, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to our financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at http://investor.qualcomm.com/ immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415.  Callers should use reservation number 13697473.

[0001728949-20-000010:8k_2_02:33]
About Qualcomm

[0001728949-20-000010:8k_2_02:34]
Qualcomm is the world’s leading wireless technology innovator and the driving force behind the development, launch and expansion of 5G.  When we connected the phone to the internet, the mobile revolution was born.  Today, our foundational technologies enable the mobile ecosystem and are found in every 3G, 4G and 5G smartphone.  We bring the benefits of mobile to new industries, including automotive, the internet of things and computing, and are leading the way to a world where everything and everyone can communicate and interact seamlessly.

[0001728949-20-000010:8k_2_02:35]
Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of our engineering, research and development functions, and substantially all of our products and services businesses, including our QCT semiconductor business.

[0001728949-20-000010:8k_2_02:36]
Note Regarding Forward-Looking Statements

[0001728949-20-000010:8k_2_02:37]
###

[0001728949-20-000010:8k_2_02:38]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-20-000010:8k_2_02:39]
MSM is a product of Qualcomm Technologies, Inc.

[0001728949-20-000010:8k_2_02:40]
| Qualcomm Announces First Quarter Fiscal 2020 Results | Page 4 of 8 |

[0001728949-20-000010:8k_2_02:41]
QUALCOMM Incorporated

[0001728949-20-000010:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001728949-20-000010:8k_2_02:43]
(In millions, except per share data)

[0001728949-20-000010:8k_2_02:44]
(Unaudited)

[0001728949-20-000010:8k_2_02:45]
|  | December 29, 2019 |  | September 29, 2019 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 11,109 |  |  | $ | 11,839 |  |
| Marketable securities | 314 |  |  | 421 |  |
| Accounts receivable, net | 2,737 |  |  | 2,471 |  |
| Inventories | 1,420 |  |  | 1,400 |  |
| Other current assets | 625 |  |  | 634 |  |
| Total current assets | 16,205 |  |  | 16,765 |  |
| Deferred tax assets | 1,254 |  |  | 1,196 |  |
| Property, plant and equipment, net | 3,171 |  |  | 3,081 |  |
| Goodwill | 6,297 |  |  | 6,282 |  |
| Other intangible assets, net | 2,045 |  |  | 2,172 |  |
| Other assets | 4,139 |  |  | 3,461 |  |
| Total assets | $ | 33,111 |  |  | $ | 32,957 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,718 |  |  | $ | 1,368 |  |
| Payroll and other benefits related liabilities | 939 |  |  | 1,048 |  |
| Unearned revenues | 511 |  |  | 565 |  |
| Short-term debt | 2,498 |  |  | 2,496 |  |
| Other current liabilities | 3,528 |  |  | 3,458 |  |
| Total current liabilities | 9,194 |  |  | 8,935 |  |
| Unearned revenues | 1,061 |  |  | 1,160 |  |
| Income taxes payable | 2,054 |  |  | 2,088 |  |
| Long-term debt | 13,437 |  |  | 13,437 |  |
| Other liabilities | 2,852 |  |  | 2,428 |  |
| Total liabilities | 28,598 |  |  | 28,048 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,143 and 1,145 shares issued and outstanding, respectively | — |  |  | 343 |  |
| Retained earnings | 4,376 |  |  | 4,466 |  |
| Accumulated other comprehensive income | 137 |  |  | 100 |  |
| Total stockholders’ equity | 4,513 |  |  | 4,909 |  |
| Total liabilities and stockholders’ equity | $ | 33,111 |  |  | $ | 32,957 |  |

[0001728949-20-000010:8k_2_02:46]
| Qualcomm Announces First Quarter Fiscal 2020 Results | Page 5 of 8 |

[0001728949-20-000010:8k_2_02:47]
QUALCOMM Incorporated

[0001728949-20-000010:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-20-000010:8k_2_02:49]
(In millions, except per share data)

[0001728949-20-000010:8k_2_02:50]
(Unaudited)

[0001728949-20-000010:8k_2_02:51]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |
| Revenues: |  |  |  |
| Equipment and services | $ | 3,534 |  |  | $ | 3,754 |  |
| Licensing | 1,543 |  |  | 1,088 |  |
| Total revenues | 5,077 |  |  | 4,842 |  |
| Costs and expenses: |  |  |  |
| Cost of revenues | 2,113 |  |  | 2,188 |  |
| Research and development | 1,406 |  |  | 1,269 |  |
| Selling, general and administrative | 528 |  |  | 526 |  |
| Other | — |  |  | 149 |  |
| Total costs and expenses | 4,047 |  |  | 4,132 |  |
| Operating income | 1,030 |  |  | 710 |  |
| Interest expense | (148 | ) |  | (156 | ) |
| Investment and other income, net | 65 |  |  | 5 |  |
| Income before income taxes | 947 |  |  | 559 |  |
| Income tax (expense) benefit | (22 | ) |  | 509 |  |
| Net income | $ | 925 |  |  | $ | 1,068 |  |
| Basic earnings per share | $ | 0.81 |  |  | $ | 0.88 |  |
| Diluted earnings per share | $ | 0.80 |  |  | $ | 0.87 |  |
| Shares used in per share calculations: |  |  |  |
| Basic | 1,144 |  |  | 1,213 |  |
| Diluted | 1,159 |  |  | 1,223 |  |

[0001728949-20-000010:8k_2_02:52]
| Qualcomm Announces First Quarter Fiscal 2020 Results | Page 6 of 8 |

[0001728949-20-000010:8k_2_02:53]
QUALCOMM Incorporated

[0001728949-20-000010:8k_2_02:54]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-20-000010:8k_2_02:55]
(In millions)

[0001728949-20-000010:8k_2_02:56]
(Unaudited)

[0001728949-20-000010:8k_2_02:57]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |
| Operating Activities: |  |  |  |
| Net income | $ | 925 |  |  | $ | 1,068 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization expense | 351 |  |  | 353 |  |
| Income tax provision less than income tax payments | (131 | ) |  | (663 | ) |
| Non-cash portion of share-based compensation expense | 294 |  |  | 230 |  |
| Net (gains) losses on marketable securities and other investments | (79 | ) |  | 37 |  |
| Indefinite and long-lived asset impairment charges | — |  |  | 150 |  |
| Impairment losses on other investments | 72 |  |  | 9 |  |
| Other items, net | (26 | ) |  | (34 | ) |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable, net | (262 | ) |  | 415 |  |
| Inventories | (17 | ) |  | (18 | ) |
| Other assets | (119 | ) |  | (148 | ) |
| Trade accounts payable | 396 |  |  | (403 | ) |
| Payroll, benefits and other liabilities | (171 | ) |  | (578 | ) |
| Unearned revenues | (115 | ) |  | (62 | ) |
| Net cash provided by operating activities | 1,118 |  |  | 356 |  |
| Investing Activities: |  |  |  |
| Capital expenditures | (296 | ) |  | (152 | ) |
| Proceeds from sales and maturities of debt and equity marketable securities | 129 |  |  | 35 |  |
| Acquisitions and other investments, net of cash acquired | (75 | ) |  | (56 | ) |
| Proceeds from other investments | 26 |  |  | 23 |  |
| Other items, net | 13 |  |  | (2 | ) |
| Net cash used by investing activities | (203 | ) |  | (152 | ) |
| Financing Activities: |  |  |  |
| Proceeds from short-term debt | 558 |  |  | 1,784 |  |
| Repayment of short-term debt | (558 | ) |  | (1,790 | ) |
| Proceeds from issuance of common stock | 23 |  |  | 28 |  |
| Repurchases and retirements of common stock | (762 | ) |  | (1,019 | ) |
| Dividends paid | (710 | ) |  | (750 | ) |
| Payments of tax withholdings related to vesting of share-based awards | (201 | ) |  | (139 | ) |
| Other items, net | (9 | ) |  | (1 | ) |
| Net cash used by financing activities | (1,659 | ) |  | (1,887 | ) |
| Changes in cash and cash equivalents held for sale | — |  |  | (25 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 14 |  |  | (3 | ) |
| Net decrease in total cash and cash equivalents | (730 | ) |  | (1,711 | ) |
| Total cash and cash equivalents at beginning of period | 11,839 |  |  | 11,777 |  |
| Total cash and cash equivalents at end of period | $ | 11,109 |  |  | $ | 10,066 |  |

[0001728949-20-000010:8k_2_02:58]
| Qualcomm Announces First Quarter Fiscal 2020 Results | Page 7 of 8 |

[0001728949-20-000010:8k_2_02:59]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-20-000010:8k_2_02:60]
The Non-GAAP financial measures presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, our Non-GAAP financial measures might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP financial measures are presented herein.

[0001728949-20-000010:8k_2_02:61]
We use Non-GAAP financial information: (i) to evaluate, assess and benchmark our operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of our ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by us include revenues, cost of revenues, research and development (R&D) expenses, selling, general and administrative (SG&A) expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  We are able to assess what we believe is a more meaningful and comparable set of financial performance measures for Qualcomm and its business segments by using Non-GAAP information.  In addition, the HR and Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  We present Non-GAAP financial information to provide greater transparency to investors with respect to our use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0001728949-20-000010:8k_2_02:62]
Non-GAAP information excludes our QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-20-000010:8k_2_02:63]
| • | QSI is excluded because we expect to exit our strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed as unrelated to our operational performance. |

[0001728949-20-000010:8k_2_02:64]
| • | Share-based compensation expense primarily relates to restricted stock units. We believe that excluding non-cash share-based compensation from the Non-GAAP financial information allows us and investors to make additional comparisons of the operating activities of our ongoing core businesses over time and with respect to other companies. |

[0001728949-20-000010:8k_2_02:65]
| • | Certain other items are excluded because we view such items as unrelated to the operating activities of our ongoing core businesses, as follows: |

[0001728949-20-000010:8k_2_02:66]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of these items, as well as any effects from restructuring the ownership of such acquired assets. Additionally, we exclude third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition. |

[0001728949-20-000010:8k_2_02:67]
| • | We exclude certain other items that we view as unrelated to our ongoing businesses, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. |

[0001728949-20-000010:8k_2_02:68]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of our ongoing Non-GAAP tax rate and after-tax earnings. |

[0001728949-20-000010:8k_2_02:69]
| Qualcomm Announces First Quarter Fiscal 2020 Results | Page 8 of 8 |

[0001728949-20-000010:8k_2_02:70]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-20-000010:8k_2_02:71]
The following tables reconcile our GAAP results to our Non-GAAP results (in millions, except per share data and percentages):

[0001728949-20-000010:8k_2_02:72]
|  | GAAP to Non-GAAP Reconciliation | Non-GAAP Supplemental Information |
| GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results | QCT | QTL (b) | Non-GAAP Reconciling Items (c) |
| Q1 FISCAL 2020 |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues | $5,077 |  | $20 |  |  | $— |  |  |  | $— |  |  | $5,057 |  | $3,618 |  | $1,404 |  | $35 |  |
| Operating income (loss) | 1,030 |  | 13 |  | (294) |  | (84) |  | 1,395 |  |  |  |  |  |  |  |
| EBT | 947 |  | (3) |  | (294) |  | (90) |  | 1,334 |  | 479 |  | 1,017 |  | (162) |  |
| EBT as % of revenues | 19 | % |  |  |  |  |  |  |  | 26 | % |  |  |  |  |  |  |  |
| Net income (loss) | 925 |  | (2) |  | (222) |  | (2) |  | 1,151 |  |  |  |  |  |  |  |
| Diluted EPS | $0.80 |  |  | $— |  |  | ($0.19) |  |  | $— |  |  | $0.99 |  |  |  |  |  |  |  |
| Diluted shares | 1,159 |  | 1,159 |  | 1,159 |  | 1,159 |  | 1,159 |  |  |  |  |  |  |  |
| Q1 FISCAL 2019 (d) |  |  |  |  |  |  |  |  |  |  |  |
| Revenues | $4,842 |  | $27 |  |  | $— |  |  |  | $— |  |  | $4,815 |  | $3,739 |  | $1,018 |  | $58 |  |
| Operating income (loss) | 710 |  | 13 |  | (230) |  | (260) |  | 1,187 |  |  |  |  |  |  |  |
| EBT | 559 |  | 8 |  | (230) |  | (263) |  | 1,044 |  | 598 |  | 590 |  | (144) |  |
| EBT as % of revenues | 12 | % |  |  |  |  |  |  |  | 22 | % |  |  |  |  |  |  |  |
| Net income (loss) | 1,068 |  | 7 |  | (182) |  | (221) |  | 1,464 |  |  |  |  |  |  |  |
| Diluted EPS | $0.87 |  | $0.01 |  | ($0.15) |  | ($0.18) |  | $1.20 |  |  |  |  |  |  |  |
| Diluted shares | 1,223 |  | 1,223 |  | 1,223 |  | 1,223 |  | 1,223 |  |  |  |  |  |  |  |

[0001728949-20-000010:8k_2_02:73]
| (a) | Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” section herein. Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001728949-20-000010:8k_2_02:74]
| (b) | QTL results for the first quarter of fiscal 2020 included royalties from Apple as a result of the settlement with Apple and its contract manufacturers in April 2019 and excluded royalties due on the sales of Huawei’s products. QTL results for the first quarter of fiscal 2019 excluded royalties due on sales of Apple or other products by Apple’s contract manufacturers and included $150 million of royalties resulting from an interim agreement with Huawei. |

[0001728949-20-000010:8k_2_02:75]
| (c) | Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations. Non-GAAP reconciling items related to EBT consisted primarily of certain R&D expenses, SG&A expenses, other expenses or income, interest expense and certain investment income that are not allocated to the segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit. |

[0001728949-20-000010:8k_2_02:76]
| (d) | The first quarter of fiscal 2019 GAAP and Non-GAAP results included $570 million tax benefit, or $0.47 per share, for GAAP and $552 million tax benefit, or $0.45 per share, for Non-GAAP relating to certain tax elections made in the first quarter of fiscal 2019. |

[0001728949-20-000010:8k_2_02:77]
Sums may not equal totals due to rounding.

[0001728949-20-000010:8k_2_02:78]
|  | Q1 FISCAL 2020 Supplemental Information and Reconciliations |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) | Non-GAAP Results |
|  | Cost of revenues |  | $2,113 |  |  | $4 |  |  | $8 |  |  | $82 |  |  | $2,019 |  |
|  | Research and development expenses |  | 1,406 |  |  | — |  |  |  | 209 |  |  | — |  |  |  | 1,197 |  |
|  | Selling, general and administrative expenses |  | 528 |  |  | 3 |  |  | 77 |  |  | 2 |  |  | 446 |  |
|  | Interest expense |  | 148 |  |  | — |  |  |  | — |  |  |  | 6 |  |  | 142 |  |
|  | Investment and other income (loss), net |  | 65 |  |  | (16) |  |  | — |  |  |  | — |  |  |  | 81 |  |
|  | Income tax expense (benefit) |  | 22 |  |  | (1) |  |  | (72) |  |  | (88) |  |  | 183 |  |

[0001728949-20-000010:8k_2_02:79]
| (a) | Other items excluded from Non-GAAP results included $87 million of acquisition-related charges and $6 million of interest expense related to the 2018 and 2019 European Commission fines, partially offset by a $3 million net gain from restructuring-related activities included in SG&A. |

[0001728949-20-000010:8k_2_02:80]
| (b) | At fiscal year end, the quarterly tax provision for each column equals the annual tax provision for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions may not equal the total GAAP tax provision, and this difference is included in the tax provision in the “Other Items” column. The tax benefit in the “Other Items” column included a $44 million tax benefit for release of a valuation allowance, a $43 million foreign currency gain related to a noncurrent receivable related to our refund claim of Korean withholding taxes paid in prior periods, a $12 million tax benefit for the tax effect of acquisition-related charges and a $2 million tax benefit from the combined effect of other items in EBT, partially offset by a $13 million charge related to a change in prior period tax rate of a foreign jurisdiction. |
