# QCOM notes — 0001728949-20-000011


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-20-000011:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for the fiscal year ended September 29, 2019. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 29, 2019 and December 30, 2018 included 13 weeks.

[0001728949-20-000011:notes:2]
[same as prior period, unchanged from 0001728949-19-000055:notes:2]

[0001728949-20-000011:notes:3]
Recently Adopted Accounting Guidance.

[0001728949-20-000011:notes:4]
Leases: In February 2016, the FASB issued new accounting guidance related to leases (ASC 842) that outlines a new comprehensive lease accounting model and requires expanded disclosures. Under the new accounting guidance, we are required to recognize right-of-use assets and corresponding lease liabilities on the consolidated balance sheet. We adopted ASC 842 in the first quarter of fiscal 2020 using the modified retrospective approach, with the cumulative effect of initial adoption recorded as an adjustment to our opening condensed consolidated balance sheet at September 30, 2019. We elected to not record leases with a term of 12 months or less on our consolidated balance sheet. In addition, we applied the package of practical expedients permitted under the transition guidance, which among other things, does not require reassessment of lease classification upon adoption. Prior period results have not been restated and continue to be reported in accordance with the accounting guidance in effect for those periods (ASC 840).

[0001728949-20-000011:notes:5]
Upon adoption, we recorded $449 million of operating lease assets in other assets and $500 million of corresponding lease liabilities ($127 million recorded in other current liabilities and $373 million recorded in other liabilities). The difference between the operating lease assets and liabilities of $51 million primarily related to deferred rent liabilities that existed as of the date of adoption. Finance leases were not material for all periods presented. Adoption of the new accounting guidance did not have a material impact on our condensed consolidated statements of operations or cash flows.

[0001728949-20-000011:notes:6]
[same as prior period, unchanged from 0001728949-19-000055:notes:28]

[0001728949-20-000011:notes:7]
Leases: As a result of the adoption of ASC 842, we revised our lease accounting policy beginning in fiscal 2020 as follows.

[0001728949-20-000011:notes:8]
Operating lease assets and liabilities are recognized for leases with lease terms greater than 12 months based on the present value of the future lease payments over the lease term at the commencement date. Operating leases are included in other assets, other current liabilities and other liabilities on our consolidated balance sheet. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise such option. We account for substantially all lease and related non-lease components together as a single lease component. Operating lease expense is recognized on a straight-line basis over the lease term.

[0001728949-20-000011:notes:9]
Recent Accounting Guidance Not Yet Adopted.

[0001728949-20-000011:notes:10]
Financial Assets: In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) will be estimated based on expected losses rather than the current incurred loss impairment model. The new accounting guidance also modifies the impairment model for available-for-sale debt securities. These changes will result in earlier recognition of credit losses, if any. The new accounting guidance generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. We will adopt the new accounting guidance in the first quarter of fiscal 2021, and the impact of this new 
accounting guidance will largely depend on the composition and credit quality of our investment portfolio, as well as economic conditions, at the time of adoption.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-20-000011:notes:11]
[same as prior period, unchanged from 0001728949-19-000055:notes:47]

[0001728949-20-000011:notes:12]
| Inventories (in millions) |  |  |  |
|  | December 29, 2019 |  | September 29, 2019 |
| Raw materials | $ | 75 |  |  | $ | 77 |  |
| Work-in-process | 725 |  |  | 667 |  |
| Finished goods | 620 |  |  | 656 |  |
|  | $ | 1,420 |  |  | $ | 1,400 |  |

[0001728949-20-000011:notes:13]
| Short-term debt (in millions) |  |  |  |
|  | December 29, 2019 |  | September 29, 2019 |
| Commercial paper | $ | 499 |  |  | $ | 499 |  |
| Current portion of long-term debt | 1,999 |  |  | 1,997 |  |
|  | $ | 2,498 |  |  | $ | 2,496 |  |

[0001728949-20-000011:notes:14]
Revolving Credit Facility. We have an Amended and Restated Revolving Credit Facility (Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion expire on February 18, 2020 and November 8, 2021, respectively. At December 29, 2019, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-20-000011:notes:15]
Revenues. We disaggregate our revenues by segment (Note 6) and type of products and services (as presented on our condensed consolidated statement of operations), as we believe this best depicts how the nature, amount, timing and uncertainty of our revenues and cash flows are affected by economic factors. Substantially all of QCT’s (Qualcomm CDMA Technologies) revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s (Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time.

[0001728949-20-000011:notes:16]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were $92 million and $72 million for the three months ended December 29, 2019 and December 30, 2018, respectively, and primarily related to QTL royalty revenues recognized related to devices sold in prior periods and certain customer incentives.

[0001728949-20-000011:notes:17]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In the three months ended December 29, 2019 and December 30, 2018, we recognized revenues of $178 million and $133 million, respectively, that were recorded as unearned revenues at September 29, 2019 and October 1, 2018, respectively.

[0001728949-20-000011:notes:18]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront. At December 29, 2019, we had $1.6 billion of remaining performance obligations, of which $372 million, $462 million, $449 million, $198 million and $50 million was expected to be recognized as revenues for the remainder of fiscal 2020 and each of the subsequent four years from fiscal 2021 through 2024, respectively, and $26 million thereafter.

[0001728949-20-000011:notes:19]
Other Income, Costs and Expenses. Other expenses in the three months ended December 30, 2018 consisted of $180 million, in restructuring and restructuring-related charges related to our Cost Plan that concluded in fiscal 2019, partially offset by a $31 million benefit related to a favorable legal settlement.

[0001728949-20-000011:notes:20]
| Investment and Other Income, Net (in millions) |  |  |  |
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |
| Interest and dividend income | $ | 69 |  |  | $ | 74 |  |
| Net gains (losses) on marketable securities | 31 |  |  | (72 | ) |
| Net gains on other investments | 48 |  |  | 35 |  |
| Impairment losses on other investments | (72 | ) |  | (9 | ) |
| Net gains (losses) on derivative investments | 2 |  |  | (8 | ) |
| Equity in net losses of investees | (10 | ) |  | (21 | ) |
| Net (losses) gains on foreign currency transactions | (3 | ) |  | 6 |  |
|  | $ | 65 |  |  | $ | 5 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-20-000011:notes:21]
Income Taxes
We estimate our annual effective income tax rate to be 11% for fiscal 2020, which is lower than the U.S. federal statutory rate since a significant portion of our income qualifies for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate and due to benefits from our research and development tax credit. The effective tax rate of 2% for the first quarter of fiscal 2020 was lower than the estimated annual effective tax rate of 11% due to $102 million of discrete net tax benefits recorded in the first quarter of fiscal 2020, primarily related to excess tax benefits associated with share-based awards that vested in the first fiscal quarter, valuation allowance release on capital loss carryforwards and foreign currency gains on a noncurrent receivable related to our refund claim of Korean withholding tax. The effective tax rate of 91% benefit for the first quarter of fiscal 2019 included a $570 million tax benefit due to establishing new U.S. net deferred tax assets from making certain check-the-box elections.

[0001728949-20-000011:notes:22]
The United States Treasury Department has issued proposed regulations on several provisions of the 2017 Tax Cuts and Jobs Act, including FDII and interest expense deduction limitations, which are expected to be finalized in the next several months. When finalized, these proposed regulations may adversely affect our provision for income taxes, results of operations and/or cash flows.

[0001728949-20-000011:notes:23]
Unrecognized tax benefits were $1.8 billion and $1.7 billion at December 29, 2019 and September 29, 2019, respectively, and primarily relates to our refund claim of Korean withholding tax. If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We expect that the total amount of unrecognized tax benefits at December 29, 2019 will increase in the next 12 months as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-20-000011:notes:24]
Capital Stock
Stock Repurchase Program. On July 26, 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock.

[0001728949-20-000011:notes:25]
In the three months ended December 29, 2019 and December 30, 2018, we repurchased and retired 9.2 million and 16.8 million shares for $762 million and $1.0 billion, respectively, before commissions. To reflect share repurchases in the consolidated balance sheet, we (i) reduce common stock for the par value of the shares, (ii) reduce paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) record the residual amount to retained earnings, if any. At December 29, 2019, $6.3 billion remained authorized for repurchase under our stock repurchase program. Since December 29, 2019, we repurchased and retired 2.9 million shares of common stock for $260 million.

[0001728949-20-000011:notes:26]
Dividends. On January 17, 2020, we announced a cash dividend of $0.62 per share on our common stock, payable on March 26, 2020 to stockholders of record as of the close of business on March 5, 2020.

[0001728949-20-000011:notes:27]
Earnings Per Common Share. Basic earnings per common share is computed by dividing net income by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of the weighted-average number of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans and shares subject to accelerated share repurchase agreements, if

[0001728949-20-000011:notes:28]
any, and the weighted-average number of common shares outstanding during the reporting period. The following table provides information about the diluted earnings per share calculation (in millions):

[0001728949-20-000011:notes:29]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |
| Dilutive common share equivalents included in diluted shares | 15.0 |  |  | 10.3 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 0.2 |  |  | 11.7 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-20-000011:notes:30]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0001728949-20-000011:notes:31]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, a securities class action complaint was filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers. On April 29, 2016, the plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, the plaintiffs filed a second amended complaint, alleging that we and certain of our current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding our business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint sought unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, we filed a motion to dismiss the second amended complaint. On October 20, 2017, the court entered an order granting in part our motion to dismiss, and on November 29, 2017, the court entered an order granting the remaining portions of our motion to dismiss. On December 28, 2017, the plaintiffs filed an appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). A hearing was held on July 11, 2019, and on July 23, 2019, the Ninth Circuit affirmed the District Court’s dismissal of the second amended complaint in its entirety. On August 29, 2019, the Ninth Circuit denied the plaintiffs’ request for en banc review. The plaintiffs did not file a petition for certiorari to request that the United States Supreme Court hear the matter prior to the November 27, 2019 deadline. Accordingly, the dismissal is final.

[0001728949-20-000011:notes:32]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss the complaint. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

[0001728949-20-000011:notes:33]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On January 22, 2019, the court appointed the lead plaintiff in the action. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

[0001728949-20-000011:notes:34]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. At December 29, 2019, twenty-two such cases remained outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging

[0001728949-20-000011:notes:35]
that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. The Ninth Circuit has not yet ruled on our appeal. We believe the plaintiffs’ claims are without merit.

[0001728949-20-000011:notes:36]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, eight consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the U.S. consumer class action complaint. The complaints seek unspecified damages. One of the complaints in the Supreme Court of British Columbia has since been discontinued by the plaintiffs. We have not yet answered the complaints. We expect the Ontario and British Columbia complaints will be consolidated into one proceeding in British Columbia with a class certification hearing no earlier than late 2020. Once the certification hearing is scheduled, we expect the court to set a timetable for the exchange of evidence and briefing. As to the complaint filed in Quebec, on April 15, 2019, the Quebec Superior Court held a class certification hearing, and on April 30, 2019, the court issued an order certifying a class. We are awaiting the court to set a timetable for pre-trial steps, including discovery, as well as the exchange of expert evidence. We do not expect the trial to occur before 2022. We believe the plaintiffs’ claims are without merit.

[0001728949-20-000011:notes:37]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0001728949-20-000011:notes:38]
We believe that our business practices do not violate the MRFTA. On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019 and, on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our

[0001728949-20-000011:notes:39]
favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC.

[0001728949-20-000011:notes:40]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision confirming their preliminary view that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

[0001728949-20-000011:notes:41]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 29, 2019, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $271 million and included in other current liabilities.

[0001728949-20-000011:notes:42]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the EU competition rules.

[0001728949-20-000011:notes:43]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 29, 2019, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.1 billion and included in other current liabilities.

[0001728949-20-000011:notes:44]
European Commission (EC) Investigation regarding Radio Frequency Front Ends (RFFE): On December 3, 2019, we received a Request for Information from the EC notifying us that it is investigating whether we engaged in anti-competitive behavior in the European Union (EU)/European Economic Area (EEA) by leveraging our market position in 5G baseband processors in the RFFE space. We are in the process of responding. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of our annual revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. We believe that our business practices do not violate the EU competition rules.

[0001728949-20-000011:notes:45]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of cellular modem chipsets on the purchaser first agreeing to a license to our cellular standard-essential patents, paying incentives to purchasers of cellular modem chipsets to induce them to accept certain license terms, refusing to license our cellular standard-essential patents to our competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint sought a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief. On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to

[0001728949-20-000011:notes:46]
rival sellers of cellular modem chipsets. On November 6, 2018, the court granted the FTC’s partial summary judgment motion. Trial was held January 4-29, 2019.

[0001728949-20-000011:notes:47]
On May 21, 2019, the court issued an Order setting forth its Findings of Fact and Conclusions of Law. The court concluded that we had monopoly power in the CDMA and premium-tier Long Term Evolution (LTE) cellular modem chip markets, and that we had used that power in these two markets to engage in anticompetitive acts, including (1) using threats of lack of access to cellular modem chip supply to coerce OEMs to accept license terms that include unreasonably high royalty rates; (2) refusing to license our cellular standard-essential patents to competitors selling cellular modem chips; and (3) entering into exclusive dealing arrangements with OEMs that foreclosed our rivals. The court further found that the royalties we charge OEMs are unreasonably high and reflect the use of our monopoly power over CDMA and premium-tier LTE cellular modem chips rather than just the value of our patents. The court concluded that our unreasonably high royalties constitute an anticompetitive surcharge on cellular modem chips sold by our competitors, which increases the effective price of our competitors’ cellular modem chips, reduces their margins and results in exclusivity. The court also found that our practice of not licensing competitors’ cellular modem chips violated our commitments to certain standard-development organizations and a duty under the antitrust laws to license competing cellular modem chip makers and helped us maintain our royalties at unreasonably high levels. Finally, the court found that incentive funds entered into with certain OEMs further harmed competing cellular modem chip makers’ ability to undermine our monopoly position, prevented rivals from entering the market and restricted the sales of those competitors that do enter. The court concluded that the combined effect of our conduct, together with our monopoly power, harmed the competitive process.

[0001728949-20-000011:notes:48]
The court imposed the following injunctive relief: (1) we must not condition the supply of cellular modem chips on a customer’s patent license status, and we must negotiate or renegotiate license terms with customers in good faith under conditions free from the threat of lack of access to or discriminatory provision of cellular modem chip supply or associated technical support or access to software; (2) we must make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers on fair, reasonable and non-discriminatory (FRAND) terms and submit, as necessary, to arbitral or judicial dispute resolution to determine such terms; (3) we may not enter into express or de facto exclusive dealing agreements for the supply of cellular modem chips; and (4) we may not interfere with the ability of any customer to communicate with a government agency about a potential law enforcement or regulatory matter. The court also ordered us to submit to compliance and monitoring procedures for a period of seven years and to report to the FTC on an annual basis regarding our compliance with the above remedies.

[0001728949-20-000011:notes:49]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On August 23, 2019, the Ninth Circuit granted our Motion. Thus, pending the resolution of the appeal in the Ninth Circuit or until further order of the Ninth Circuit, the portions of the court’s injunction requiring that we must (i) make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers and (ii) not condition the supply of cellular modem chips on a customer’s patent license status and must negotiate or renegotiate license terms with customers are stayed. On July 10, 2019, the Ninth Circuit granted our Motion to Expedite Appeal. Oral argument is scheduled for February 13, 2020.

[0001728949-20-000011:notes:50]
Contingent losses and other considerations: We will continue to vigorously defend ourself in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at December 29, 2019 for contingent losses associated with these matters based on our belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0001728949-20-000011:notes:51]
Indemnifications. We generally do not indemnify our customers, licensees and suppliers for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain agreements to defend and/or indemnify certain customers, licensees and suppliers against certain types of liability and/or damages arising from the infringement of third-party intellectual property rights. Our obligations under these agreements may be limited in

[0001728949-20-000011:notes:52]
terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us.

[0001728949-20-000011:notes:53]
Claims and reimbursements under indemnification arrangements have not been material to our consolidated financial statements. At December 29, 2019, accruals for contingent liabilities associated with these indemnification arrangements were negligible. We have not recorded accruals for certain claims under indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001728949-20-000011:notes:54]
Operating Leases. We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years. At December 29, 2019, other assets included $479 million of operating lease assets, with corresponding lease liabilities of $136 million recorded in other current liabilities and $393 million recorded in other liabilities.

[0001728949-20-000011:notes:55]
Operating lease expense for the three months ended December 29, 2019 and December 30, 2018 was $44 million and $37 million, respectively. Cash paid under our operating leases was $38 million for the three months ended December 29, 2019. As of December 29, 2019, the weighted-average remaining lease term and weighted-average discount rate for operating leases were 5.7 years and 4%, respectively.

[0001728949-20-000011:notes:56]
At December 29, 2019, future lease payments under our operating leases were as follows (in millions):

[0001728949-20-000011:notes:57]
|  | Operating Leases |
| Remainder of fiscal 2020 | $ | 115 |  |
| 2021 | 140 |  |
| 2022 | 107 |  |
| 2023 | 62 |  |
| 2024 | 43 |  |
| Thereafter | 140 |  |
| Total future lease payments | 607 |  |
| Imputed interest | (78 | ) |
| Total lease liability balance | $ | 529 |  |

[0001728949-20-000011:notes:58]
At September 29, 2019, future minimum lease payments under our noncancelable operating leases under ASC 840 were as follows (in millions):

[0001728949-20-000011:notes:59]
|  | Operating Leases |
| 2020 | $ | 138 |  |
| 2021 | 97 |  |
| 2022 | 66 |  |
| 2023 | 31 |  |
| 2024 | 18 |  |
| Thereafter | 35 |  |
| Total | $ | 385 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-20-000011:notes:60]
Segment Information
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices, wireless networks, devices used in the Internet of Things (IoT), broadband gateway equipment, consumer electronic devices and automotive

[0001728949-20-000011:notes:61]
telematics and infotainment systems. QTL grants licenses to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an equity method investee. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and other wireless technology and service initiatives.

[0001728949-20-000011:notes:62]
We evaluate the performance of our segments based on earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense; certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories and property, plant and equipment to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages.

[0001728949-20-000011:notes:63]
[same as prior period, unchanged from 0001728949-19-000055:notes:111]

[0001728949-20-000011:notes:64]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |
| Revenues |  |  |  |
| QCT | $ | 3,618 |  |  | $ | 3,739 |  |
| QTL | 1,404 |  |  | 1,018 |  |
| QSI | 20 |  |  | 27 |  |
| Reconciling items | 35 |  |  | 58 |  |
| Total | $ | 5,077 |  |  | $ | 4,842 |  |
| EBT |  |  |  |
| QCT | $ | 479 |  |  | $ | 598 |  |
| QTL | 1,017 |  |  | 590 |  |
| QSI | (3 | ) |  | 8 |  |
| Reconciling items | (546 | ) |  | (637 | ) |
| Total | $ | 947 |  |  | $ | 559 |  |

[0001728949-20-000011:notes:65]
|  | December 29, 2019 |  | September 29, 2019 |
| Assets |  |  |  |
| QCT | $ | 2,283 |  |  | $ | 2,307 |  |
| QTL | 1,844 |  |  | 1,541 |  |
| QSI | 1,582 |  |  | 1,708 |  |
| Reconciling items | 27,402 |  |  | 27,401 |  |
| Total | $ | 33,111 |  |  | $ | 32,957 |  |

[0001728949-20-000011:notes:66]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets include certain non-marketable equity instruments, accounts receivable and other investments. Total segment assets differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable and non-marketable securities, property, plant and equipment, deferred tax assets, goodwill, intangible assets, operating lease assets, noncurrent income taxes receivables and assets of nonreportable segments.

[0001728949-20-000011:notes:67]
QTL accounts receivable increased in the first quarter of fiscal 2020 from $1.54 billion to $1.84 billion, primarily due to an increase in licensing revenues. At December 29, 2019, 29% of total accounts receivable included estimated royalties from

[0001728949-20-000011:notes:68]
two key Chinese licensees, primarily from sales made in the last three fiscal quarters (including amounts that are not yet due) under license agreements that were extended and now expire on March 31, 2020. Certain of such amounts have been delayed while good faith negotiations continue to amend the existing license agreements or enter into new license agreements. The existing agreements are legally enforceable, the amounts outstanding are considered probable of being collected and we believe these licensees are committed to make payment. These licensees/customers continue to make timely payments on purchases of integrated circuit products.

[0001728949-20-000011:notes:69]
[same as prior period, unchanged from 0001728949-19-000055:notes:114]

[0001728949-20-000011:notes:70]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |
| Revenues |  |  |  |
| Nonreportable segments | $ | 35 |  |  | $ | 58 |  |
|  | $ | 35 |  |  | $ | 58 |  |
| EBT |  |  |  |
| Unallocated cost of revenues | $ | (90 | ) |  | $ | (114 | ) |
| Unallocated research and development expenses | (259 | ) |  | (147 | ) |
| Unallocated selling, general and administrative expenses | (117 | ) |  | (64 | ) |
| Unallocated other expenses (Note 2) | — |  |  | (149 | ) |
| Unallocated interest expense | (147 | ) |  | (153 | ) |
| Unallocated investment and other income, net | 82 |  |  | 20 |  |
| Nonreportable segments | (15 | ) |  | (30 | ) |
|  | $ | (546 | ) |  | $ | (637 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-20-000011:notes:71]
Fair Value Measurements
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at December 29, 2019 (in millions):

[0001728949-20-000011:notes:72]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 6,101 |  |  | $ | 3,658 |  |  | $ | — |  |  | $ | 9,759 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Auction rate securities | — |  |  | — |  |  | 35 |  |  | 35 |  |
| Equity securities | 315 |  |  | — |  |  | — |  |  | 315 |  |
| Total marketable securities | 315 |  |  | — |  |  | 35 |  |  | 350 |  |
| Derivative instruments | — |  |  | 24 |  |  | — |  |  | 24 |  |
| Other investments | 474 |  |  | — |  |  | 98 |  |  | 572 |  |
| Total assets measured at fair value | $ | 6,890 |  |  | $ | 3,682 |  |  | $ | 133 |  |  | $ | 10,705 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Other liabilities | 475 |  |  | — |  |  | 40 |  |  | 515 |  |
| Total liabilities measured at fair value | $ | 475 |  |  | $ | 2 |  |  | $ | 40 |  |  | $ | 517 |  |

[0001728949-20-000011:notes:73]
Activity within Level 3 of the Fair Value Hierarchy. Other investments and other liabilities included in Level 3 at December 29, 2019 were comprised of debt instruments issued by private companies and contingent consideration related to business combinations, respectively. Activity for marketable securities, other investments and other liabilities classified within Level 3 of the valuation hierarchy was insignificant during the three months ended December 29, 2019, which was primarily related to purchases of convertible debt instruments issued by private companies, and the three months ended December 30, 2018, which was primarily related to settlements of convertible debt instruments by private companies.

[0001728949-20-000011:notes:74]
Assets Measured and Recorded at Fair Value on a Nonrecurring Basis. We measure certain assets and liabilities at fair value on a nonrecurring basis. These assets and liabilities include equity method and non-marketable equity investments, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During the three months ended December 29, 2019, certain non-marketable securities were written down to their estimated fair values, which was recorded as a component of impairment losses on other investments in investment and other income, net (Note 2). During the three months ended December 30, 2018, goodwill related to a nonreportable segment that we agreed to sell was written down to its estimated fair value and recorded as a component of restructuring and restructuring-related charges within other expenses. The estimation of fair value required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During the three months ended December 29, 2019 and December 30, 2018, we did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis.

[0001728949-20-000011:notes:75]
Long-term Debt. At December 29, 2019 and September 29, 2019, the aggregate fair value of our remaining outstanding principal floating- and fixed-rate notes, based on Level 2 inputs, was approximately $16.6 billion and $16.5 billion, respectively.
