# QCOM note change history — 0001728949-19-000055 → 0001728949-20-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001728949-20-000011:note_history:1]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, a securities class action complaint was filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers. On April 29, 2016, the plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, the plaintiffs filed a second amended complaint, alleging that we and certain of our current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding our business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint sought unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, we filed a motion to dismiss the second amended complaint. On October 20, 2017, the court entered an order granting in part our motion to dismiss, and on November 29, 2017, the court entered an order granting the remaining portions of our motion to dismiss. On December 28, 2017, the plaintiffs filed an appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). A hearing was held on July 11, 2019, and on July 23, 2019, the Ninth Circuit affirmed the District Court’s dismissal of the second amended complaint in its entirety. On August 29, 2019, the Ninth Circuit denied the plaintiffs’ request for en banc review. The plaintiffs did not file a petition for certiorari to request that the United States Supreme Court hear the matter prior to the November 27, 2019 deadline. Accordingly, the dismissal is final.
  (was, 2019-07-31, similarity 0.8939):
[0001728949-19-000055:note_history:1]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, a securities class action complaint was filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers. On April 29, 2016, the plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, the plaintiffs filed a second amended complaint, alleging that we and certain of our current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding our business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint sought unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, we filed a motion to dismiss the second amended complaint. On October 20, 2017, the court entered an order granting in part our motion to dismiss, and on November 29, 2017, the court entered an order granting the remaining portions of our motion to dismiss. On December 28, 2017, the plaintiffs filed an appeal to the United States Court of Appeals for the Ninth Circuit. A hearing was held on July 11, 2019, and on July 23, 2019, the United States Court of Appeals for the Ninth Circuit affirmed the District Court’s dismissal of the second amended complaint in its entirety.

- changed (2020-02-05):
[0001728949-20-000011:note_history:2]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss the complaint. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.
  (was, 2019-07-31, similarity 0.8889):
[0001728949-19-000055:note_history:2]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss the complaint. Discovery has commenced and is scheduled to be completed by March 3, 2020. We believe the plaintiffs’ claims are without merit.

- changed (2020-02-05):
[0001728949-20-000011:note_history:3]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On January 22, 2019, the court appointed the lead plaintiff in the action. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.
  (was, 2019-07-31, similarity 0.6597):
[0001728949-19-000055:note_history:3]
In re Qualcomm/Broadcom Merger Securities Litigation (formerly Camp v. Qualcomm Incorporated et al): On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints allege, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints seek unspecified damages, interest, fees and costs. On January 22, 2019, the Court appointed the lead plaintiff in the action and designated that the case be captioned “In re Qualcomm/Broadcom Merger Securities Litigation.” On March 18, 2019, the plaintiffs filed a consolidated complaint. On May 10, 2019, we filed a motion to dismiss the consolidated complaint. A hearing on our motion to dismiss is scheduled for September 19, 2019. We believe the plaintiffs’ claims are without merit.

- changed (2020-02-05):
[0001728949-20-000011:note_history:4]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. At December 29, 2019, twenty-two such cases remained outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging
  (was, 2019-07-31, similarity 0.639):
[0001728949-19-000055:note_history:4]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Twenty-two such cases remain outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion,

- added (2020-02-05):
[0001728949-20-000011:note_history:5]
that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. The Ninth Circuit has not yet ruled on our appeal. We believe the plaintiffs’ claims are without merit.

- changed (2020-02-05):
[0001728949-20-000011:note_history:6]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, eight consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the U.S. consumer class action complaint. The complaints seek unspecified damages. One of the complaints in the Supreme Court of British Columbia has since been discontinued by the plaintiffs. We have not yet answered the complaints. We expect the Ontario and British Columbia complaints will be consolidated into one proceeding in British Columbia with a class certification hearing no earlier than late 2020. Once the certification hearing is scheduled, we expect the court to set a timetable for the exchange of evidence and briefing. As to the complaint filed in Quebec, on April 15, 2019, the Quebec Superior Court held a class certification hearing, and on April 30, 2019, the court issued an order certifying a class. We are awaiting the court to set a timetable for pre-trial steps, including discovery, as well as the exchange of expert evidence. We do not expect the trial to occur before 2022. We believe the plaintiffs’ claims are without merit.
  (was, 2019-07-31, similarity 0.7344):
[0001728949-19-000055:note_history:6]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, eight consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the U.S. consumer class action complaint. The complaints seek unspecified damages. One of the complaints in the Supreme Court of British Columbia has since been discontinued by the plaintiffs. We have not yet answered the complaints. On April 15, 2019, the Quebec Superior Court held a class certification hearing, and on April 30, 2019, the court issued an order certifying a class. We believe the plaintiffs’ claims are without merit.

- added (2020-02-05):
[0001728949-20-000011:note_history:7]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

- added (2020-02-05):
[0001728949-20-000011:note_history:8]
We believe that our business practices do not violate the MRFTA. On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019 and, on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our

- added (2020-02-05):
[0001728949-20-000011:note_history:9]
favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC.

- added (2020-02-05):
[0001728949-20-000011:note_history:10]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision confirming their preliminary view that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

- changed (2020-02-05):
[0001728949-20-000011:note_history:11]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 29, 2019, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $271 million and included in other current liabilities.
  (was, 2019-07-31, similarity 0.8663):
[0001728949-19-000055:note_history:11]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to such EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. As of October 1, 2018, we have designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At June 30, 2019, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.16 billion and included in other current liabilities.

- changed (2020-02-05):
[0001728949-20-000011:note_history:12]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the EU competition rules.
  (was, 2019-07-31, similarity 0.7738):
[0001728949-19-000055:note_history:12]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that, pursuant to an agreement with Apple Inc., since 2011, we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets. This conduct allegedly reduced Apple’s incentives to source baseband chipsets from our competitors and harmed competition and innovation for certain baseband chipsets. On January 24, 2018, the EC issued a decision finding that certain terms of that agreement violate EU competition law and imposed a fine of 997 million Euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the EU competition rules.

- added (2020-02-05):
[0001728949-20-000011:note_history:13]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 29, 2019, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.1 billion and included in other current liabilities.

- added (2020-02-05):
[0001728949-20-000011:note_history:14]
European Commission (EC) Investigation regarding Radio Frequency Front Ends (RFFE): On December 3, 2019, we received a Request for Information from the EC notifying us that it is investigating whether we engaged in anti-competitive behavior in the European Union (EU)/European Economic Area (EEA) by leveraging our market position in 5G baseband processors in the RFFE space. We are in the process of responding. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of our annual revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. We believe that our business practices do not violate the EU competition rules.

- changed (2020-02-05):
[0001728949-20-000011:note_history:15]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of cellular modem chipsets on the purchaser first agreeing to a license to our cellular standard-essential patents, paying incentives to purchasers of cellular modem chipsets to induce them to accept certain license terms, refusing to license our cellular standard-essential patents to our competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint sought a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief. On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to
  (was, 2019-07-31, similarity 0.875):
[0001728949-19-000055:note_history:15]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of cellular modem chipsets on the purchaser first agreeing to a license to our cellular standard-essential patents, paying incentives to purchasers of cellular modem chipsets to induce them to accept certain license terms, refusing to license our cellular standard-essential patents to our competitors, and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint sought a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief.

- added (2020-02-05):
[0001728949-20-000011:note_history:16]
rival sellers of cellular modem chipsets. On November 6, 2018, the court granted the FTC’s partial summary judgment motion. Trial was held January 4-29, 2019.

- added (2020-02-05):
[0001728949-20-000011:note_history:17]
On May 21, 2019, the court issued an Order setting forth its Findings of Fact and Conclusions of Law. The court concluded that we had monopoly power in the CDMA and premium-tier Long Term Evolution (LTE) cellular modem chip markets, and that we had used that power in these two markets to engage in anticompetitive acts, including (1) using threats of lack of access to cellular modem chip supply to coerce OEMs to accept license terms that include unreasonably high royalty rates; (2) refusing to license our cellular standard-essential patents to competitors selling cellular modem chips; and (3) entering into exclusive dealing arrangements with OEMs that foreclosed our rivals. The court further found that the royalties we charge OEMs are unreasonably high and reflect the use of our monopoly power over CDMA and premium-tier LTE cellular modem chips rather than just the value of our patents. The court concluded that our unreasonably high royalties constitute an anticompetitive surcharge on cellular modem chips sold by our competitors, which increases the effective price of our competitors’ cellular modem chips, reduces their margins and results in exclusivity. The court also found that our practice of not licensing competitors’ cellular modem chips violated our commitments to certain standard-development organizations and a duty under the antitrust laws to license competing cellular modem chip makers and helped us maintain our royalties at unreasonably high levels. Finally, the court found that incentive funds entered into with certain OEMs further harmed competing cellular modem chip makers’ ability to undermine our monopoly position, prevented rivals from entering the market and restricted the sales of those competitors that do enter. The court concluded that the combined effect of our conduct, together with our monopoly power, harmed the competitive process.

- added (2020-02-05):
[0001728949-20-000011:note_history:18]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On August 23, 2019, the Ninth Circuit granted our Motion. Thus, pending the resolution of the appeal in the Ninth Circuit or until further order of the Ninth Circuit, the portions of the court’s injunction requiring that we must (i) make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers and (ii) not condition the supply of cellular modem chips on a customer’s patent license status and must negotiate or renegotiate license terms with customers are stayed. On July 10, 2019, the Ninth Circuit granted our Motion to Expedite Appeal. Oral argument is scheduled for February 13, 2020.

- changed (2020-02-05):
[0001728949-20-000011:note_history:19]
Contingent losses and other considerations: We will continue to vigorously defend ourself in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at December 29, 2019 for contingent losses associated with these matters based on our belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.
  (was, 2019-07-31, similarity 0.9947):
[0001728949-19-000055:note_history:19]
Contingent losses and other considerations: We will continue to vigorously defend ourself in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at June 30, 2019 for contingent losses associated with these matters based on our belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- added (2020-02-05):
[0001728949-20-000011:note_history:20]
Indemnifications. We generally do not indemnify our customers, licensees and suppliers for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain agreements to defend and/or indemnify certain customers, licensees and suppliers against certain types of liability and/or damages arising from the infringement of third-party intellectual property rights. Our obligations under these agreements may be limited in

- added (2020-02-05):
[0001728949-20-000011:note_history:21]
terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us.

- added (2020-02-05):
[0001728949-20-000011:note_history:22]
Claims and reimbursements under indemnification arrangements have not been material to our consolidated financial statements. At December 29, 2019, accruals for contingent liabilities associated with these indemnification arrangements were negligible. We have not recorded accruals for certain claims under indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- added (2020-02-05):
[0001728949-20-000011:note_history:23]
Operating Leases. We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years. At December 29, 2019, other assets included $479 million of operating lease assets, with corresponding lease liabilities of $136 million recorded in other current liabilities and $393 million recorded in other liabilities.

- added (2020-02-05):
[0001728949-20-000011:note_history:24]
Operating lease expense for the three months ended December 29, 2019 and December 30, 2018 was $44 million and $37 million, respectively. Cash paid under our operating leases was $38 million for the three months ended December 29, 2019. As of December 29, 2019, the weighted-average remaining lease term and weighted-average discount rate for operating leases were 5.7 years and 4%, respectively.

- added (2020-02-05):
[0001728949-20-000011:note_history:25]
At December 29, 2019, future lease payments under our operating leases were as follows (in millions):

- added (2020-02-05):
[0001728949-20-000011:note_history:26]
|  | Operating Leases |
| Remainder of fiscal 2020 | $ | 115 |  |
| 2021 | 140 |  |
| 2022 | 107 |  |
| 2023 | 62 |  |
| 2024 | 43 |  |
| Thereafter | 140 |  |
| Total future lease payments | 607 |  |
| Imputed interest | (78 | ) |
| Total lease liability balance | $ | 529 |  |

- added (2020-02-05):
[0001728949-20-000011:note_history:27]
At September 29, 2019, future minimum lease payments under our noncancelable operating leases under ASC 840 were as follows (in millions):

- added (2020-02-05):
[0001728949-20-000011:note_history:28]
|  | Operating Leases |
| 2020 | $ | 138 |  |
| 2021 | 97 |  |
| 2022 | 66 |  |
| 2023 | 31 |  |
| 2024 | 18 |  |
| Thereafter | 35 |  |
| Total | $ | 385 |  |

- removed (2020-02-05):
[0001728949-19-000055:note_history:29]
Apple Inc. v. QUALCOMM Incorporated, QUALCOMM Incorporated v. Compal Electronics, Inc. et al. and QUALCOMM Incorporated v. Apple Inc.: On April 16, 2019, we entered into settlement agreements with Apple and its contract manufacturers to dismiss all outstanding litigation between the parties. These matters and related financial guarantees either have been, or are in the process of being, dismissed or canceled.

- removed (2020-02-05):
[0001728949-19-000055:note_history:30]
except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the Ninth Circuit Court of Appeals granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. We believe the plaintiffs’ claims are without merit.

- removed (2020-02-05):
[0001728949-19-000055:note_history:31]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that we violated Korean law by offering certain discounts and rebates for purchases of our CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents expired. The KFTC levied a fine of 273.2 billion Korean won (approximately $230 million), which we recorded as an expense in fiscal 2009 and paid in fiscal 2010. We appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, we filed an appeal with the Korea Supreme Court. On January 31, 2019, the Korea Supreme Court reversed in part the decision of the Seoul High Court and remanded the case for further proceedings consistent with its decision. In March 2019, the KFTC refunded $56 million (including interest) to us, representing a portion of the fine we previously paid to the KFTC. In the second quarter of fiscal 2019, we recorded a gain of $43 million in other income and interest income of $13 million in investment and other income, net. In light of the Korea Supreme Court’s reversal in part of the decision of the Seoul High Court and the refund we received from the KFTC, on May 8, 2019, we filed to withdraw the case from the Seoul High Court. On May 19, 2019, the KFTC filed its consent to our withdrawal, ending the case as of that date.

- removed (2020-02-05):
[0001728949-19-000055:note_history:32]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (iii) not demand unjustifiable conditions in our license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred to in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred to in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean Won (approximately $927 million), which we paid on March 30, 2017. We believe that our business practices do not violate the MRFTA, and on February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. On the same day, we filed an application with the Seoul High Court to stay the decision’s remedial order pending the Seoul High Court’s final judgment on our action to cancel the KFTC’s decision. On September 4, 2017, the Seoul High Court denied our application to stay the remedial order, and on November 27, 2017, the Korea Supreme Court dismissed our appeal of the Seoul High Court’s decision on the application to stay. Hearings on our action to cancel the KFTC’s decision are scheduled to be held before the Seoul High Court on August 12 and 14, 2019. Under the current procedural plan of the Seoul High Court, we believe these will be the final hearings before that court issues its decision.

- removed (2020-02-05):
[0001728949-19-000055:note_history:33]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, we were engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. On August 15, 2016, we submitted our response to the Statement of Objections. On July 19, 2018, the EC announced that it had issued a Supplementary Statement of Objections which focuses on certain elements of the “price-cost” test applied by the EC to assess the extent to which we sold certain baseband chipsets allegedly below cost. On October 22, 2018, we submitted our response to the Supplementary Statement of Objections. On January 10, 2019, the EC held a hearing regarding the Supplementary Statement of Objections and our response to it. On July 18, 2019, the EC issued a decision confirming their preliminary view that between 2009 and 2011 we engaged in predatory pricing with respect to two customers and imposed a fine of approximately 242 million Euros (approximately $275 million based on the exchange rate at June 30, 2019), which was recorded as a charge to other expenses in the third quarter of fiscal 2019. We intend to file an appeal of the EC’s decision with the General Court of the European Union. We intend to provide financial guarantees to satisfy the obligation in lieu of a cash payment during our appeal. We believe that our business practices do not violate the EU competition rules.

- removed (2020-02-05):
[0001728949-19-000055:note_history:34]
On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to rival sellers of cellular modem chipsets. On November 6, 2018, the court granted the FTC’s partial summary judgment motion. Trial was held January 4-29, 2019.

- removed (2020-02-05):
[0001728949-19-000055:note_history:35]
On May 21, 2019, the court issued an Order setting forth its Findings of Fact and Conclusions of Law. The court concluded that we had monopoly power in the CDMA and premium-tier LTE cellular modem chip markets, and that we had used that power in these two markets to engage in anticompetitive acts, including (1) using threats of lack of access to cellular modem chip supply to coerce OEMs to accept license terms that include unreasonably high royalty rates; (2) refusing to license our cellular standard-essential patents to competitors selling cellular modem chips; and (3) entering into exclusive

- removed (2020-02-05):
[0001728949-19-000055:note_history:36]
dealing arrangements with OEMs that foreclosed our rivals. The court further found that the royalties we charge OEMs are unreasonably high and reflect the use of our monopoly power over CDMA and premium-tier LTE cellular modem chips rather than just the value of our patents. The court concluded that our unreasonably high royalties constitute an anticompetitive surcharge on cellular modem chips sold by our competitors, which increases the effective price of our competitors’ cellular modem chips, reduces their margins and results in exclusivity. The court also found that our practice of not licensing competitors’ cellular modem chips violated our commitments to certain standard-development organizations and a duty under the antitrust laws to license competing cellular modem chip makers and helped us maintain our royalties at unreasonably high levels. Finally, the court found that incentive funds entered into with certain OEMs further harmed competing cellular modem chip makers’ ability to undermine our monopoly position, prevented rivals from entering the market and restricted the sales of those competitors that do enter. The court concluded that the combined effect of our conduct, together with our monopoly power, harmed the competitive process.

- removed (2020-02-05):
[0001728949-19-000055:note_history:37]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. Accordingly, on May 28, 2019, we filed a Motion to Stay Pending Appeal in the court, which was denied on July 3, 2019. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On July 10, 2019, the Ninth Circuit granted our Motion to Expedite Appeal, and we expect briefing to be completed before the end of the calendar year. The Partial Stay motion is pending.

- removed (2020-02-05):
[0001728949-19-000055:note_history:38]
Indemnifications. We generally do not indemnify our customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by us, or by intellectual property provided by us to chipset foundries and semiconductor assembly and test service providers. Our obligations under these agreements may be limited in terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us.

- removed (2020-02-05):
[0001728949-19-000055:note_history:39]
Through June 30, 2019, we have received a number of claims from our direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by our products. Reimbursements under indemnification arrangements have not been material to our consolidated financial statements. We have not recorded any accrual for contingent liabilities at June 30, 2019 associated with these indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- removed (2020-02-05):
[0001728949-19-000055:note_history:40]
Purchase Obligations and Operating Leases. We have agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe,

- removed (2020-02-05):
[0001728949-19-000055:note_history:41]
assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization. We lease certain of our land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 15 years and with provisions in certain leases for cost-of-living increases.

- removed (2020-02-05):
[0001728949-19-000055:note_history:42]
Obligations under our purchase agreements, which primarily relate to integrated circuit product inventory obligations, and future minimum lease payments under our operating leases at June 30, 2019 were as follows (in millions):

- removed (2020-02-05):
[0001728949-19-000055:note_history:43]
|  | Purchase Obligations |  | Operating Leases |
| Remainder of fiscal 2019 | $ | 2,249 |  |  | $ | 42 |  |
| 2020 | 890 |  |  | 123 |  |
| 2021 | 308 |  |  | 95 |  |
| 2022 | 111 |  |  | 66 |  |
| 2023 | 53 |  |  | 28 |  |
| Thereafter | 17 |  |  | 45 |  |
| Total | $ | 3,628 |  |  | $ | 399 |  |

- removed (2020-02-05):
[0001728949-19-000055:note_history:44]
Other Commitments. At June 30, 2019, we committed to fund certain strategic investments up to $194 million, of which $30 million is expected to be funded in the remainder of fiscal 2019. The remaining commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001728949-20-000011:note_history:45]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for the fiscal year ended September 29, 2019. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 29, 2019 and December 30, 2018 included 13 weeks.
  (was, 2019-07-31, similarity 0.9476):
[0001728949-19-000055:note_history:45]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for the fiscal year ended September 30, 2018. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 30, 2019 and June 24, 2018 included 13 weeks and 39 weeks, respectively.

- changed (2020-02-05):
[0001728949-20-000011:note_history:46]
Recently Adopted Accounting Guidance.
  (was, 2019-07-31, similarity 0.825):
[0001728949-19-000055:note_history:46]
Recently Adopted Accounting Pronouncements.

- added (2020-02-05):
[0001728949-20-000011:note_history:47]
Leases: In February 2016, the FASB issued new accounting guidance related to leases (ASC 842) that outlines a new comprehensive lease accounting model and requires expanded disclosures. Under the new accounting guidance, we are required to recognize right-of-use assets and corresponding lease liabilities on the consolidated balance sheet. We adopted ASC 842 in the first quarter of fiscal 2020 using the modified retrospective approach, with the cumulative effect of initial adoption recorded as an adjustment to our opening condensed consolidated balance sheet at September 30, 2019. We elected to not record leases with a term of 12 months or less on our consolidated balance sheet. In addition, we applied the package of practical expedients permitted under the transition guidance, which among other things, does not require reassessment of lease classification upon adoption. Prior period results have not been restated and continue to be reported in accordance with the accounting guidance in effect for those periods (ASC 840).

- added (2020-02-05):
[0001728949-20-000011:note_history:48]
Upon adoption, we recorded $449 million of operating lease assets in other assets and $500 million of corresponding lease liabilities ($127 million recorded in other current liabilities and $373 million recorded in other liabilities). The difference between the operating lease assets and liabilities of $51 million primarily related to deferred rent liabilities that existed as of the date of adoption. Finance leases were not material for all periods presented. Adoption of the new accounting guidance did not have a material impact on our condensed consolidated statements of operations or cash flows.

- changed (2020-02-05):
[0001728949-20-000011:note_history:49]
Leases: As a result of the adoption of ASC 842, we revised our lease accounting policy beginning in fiscal 2020 as follows.
  (was, 2019-07-31, similarity 0.848):
[0001728949-19-000055:note_history:49]
Revenue Recognition: As a result of the adoption of ASC 606, we revised our revenue recognition policy beginning in fiscal 2019 as follows.

- added (2020-02-05):
[0001728949-20-000011:note_history:50]
Operating lease assets and liabilities are recognized for leases with lease terms greater than 12 months based on the present value of the future lease payments over the lease term at the commencement date. Operating leases are included in other assets, other current liabilities and other liabilities on our consolidated balance sheet. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise such option. We account for substantially all lease and related non-lease components together as a single lease component. Operating lease expense is recognized on a straight-line basis over the lease term.

- changed (2020-02-05):
[0001728949-20-000011:note_history:51]
Recent Accounting Guidance Not Yet Adopted.
  (was, 2019-07-31, similarity 0.8478):
[0001728949-19-000055:note_history:51]
Recent Accounting Pronouncements Not Yet Adopted.

- added (2020-02-05):
[0001728949-20-000011:note_history:52]
Financial Assets: In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) will be estimated based on expected losses rather than the current incurred loss impairment model. The new accounting guidance also modifies the impairment model for available-for-sale debt securities. These changes will result in earlier recognition of credit losses, if any. The new accounting guidance generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. We will adopt the new accounting guidance in the first quarter of fiscal 2021, and the impact of this new 
accounting guidance will largely depend on the composition and credit quality of our investment portfolio, as well as economic conditions, at the time of adoption.

- removed (2020-02-05):
[0001728949-19-000055:note_history:53]
Revision of Prior Period Financial Statements. As previously disclosed, in connection with the preparation of our condensed consolidated financial statements for the three months ended December 30, 2018, we identified an immaterial error related to the recognition of certain royalty revenues of our QTL (Qualcomm Technology Licensing) segment in the quarterly and annual periods in fiscal 2018 and third and fourth quarters and annual period in fiscal 2017. In accordance with SAB No. 99, “Materiality,” and SAB No. 108, “Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements,” we evaluated the error and determined that the related impact was not material to our financial statements for any prior annual or interim period, but that correcting the cumulative impact of the error would be significant to our results of operations for the three months ended December 30, 2018. Accordingly, we have revised previously reported financial information for such immaterial error, as previously disclosed in our Quarterly Report on Form 10-Q for the first and second quarters of fiscal 2019. A summary of revisions to certain previously reported financial information presented herein for comparative purposes is included in Note 11. We will also correct previously reported financial information for such immaterial error in our future filings, as applicable.

- removed (2020-02-05):
[0001728949-19-000055:note_history:54]
Earnings (Loss) Per Common Share. Basic earnings (loss) per common share is computed by dividing net income (loss) by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans and shares subject to accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Due to the net loss for the nine months ended June 24, 2018, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share. The following table provides information about the diluted earnings (loss) per share calculation (in millions):

- removed (2020-02-05):
[0001728949-19-000055:note_history:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | June 30, 2019 |  | June 24, 2018 |
| Dilutive common share equivalents included in diluted shares | 13.9 |  |  | 9.0 |  |  | 9.3 |  |  | — |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 0.7 |  |  | 0.6 |  |  | 9.9 |  |  | 43.2 |  |

- removed (2020-02-05):
[0001728949-19-000055:note_history:56]
Share-Based Compensation. Total share-based compensation expense, related to all of our share-based awards, was comprised as follows (in millions):

- removed (2020-02-05):
[0001728949-19-000055:note_history:57]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, 2019 |  | June 24, 2018 |  | June 30, 2019 |  | June 24, 2018 |
| Cost of revenues | $ | 8 |  |  | $ | 9 |  |  | $ | 23 |  |  | $ | 30 |  |
| Research and development | 164 |  |  | 140 |  |  | 479 |  |  | 447 |  |
| Selling, general and administrative | 74 |  |  | 40 |  |  | 196 |  |  | 182 |  |
| Share-based compensation expense before income taxes | 246 |  |  | 189 |  |  | 698 |  |  | 659 |  |
| Related income tax benefit | (48 | ) |  | (34 | ) |  | (127 | ) |  | (111 | ) |
|  | $ | 198 |  |  | $ | 155 |  |  | $ | 571 |  |  | $ | 548 |  |

- removed (2020-02-05):
[0001728949-19-000055:note_history:58]
At June 30, 2019, total unrecognized compensation expense related to nonvested restricted stock units granted prior to that date was $1.2 billion, which is expected to be recognized over a weighted-average period of 2.1 years. At June 30, 2019, we had outstanding 26.9 million restricted stock units and 1.1 million stock options that contain only a service requirement.

- removed (2020-02-05):
[0001728949-19-000055:note_history:59]
Revenue Recognition: In May 2014, the Financial Accounting Standards Board (FASB) issued new accounting guidance related to revenue recognition (ASC 606), which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition accounting guidance and requires increased disclosures. The new accounting guidance defines a five-step approach that requires a company to recognize revenue as control of goods or services transfers to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. We adopted ASC 606 in the first quarter of fiscal 2019 using the modified retrospective transition method only to those contracts that were not completed as of October 1, 2018. We recognized the cumulative effect of initially applying the new revenue accounting guidance as an adjustment to opening retained earnings. Prior period results have not been restated and continue to be reported in accordance with the accounting guidance in effect for those periods (ASC 605). We have implemented new accounting policies, systems, processes and internal controls necessary to support the requirements of ASC 606.

- removed (2020-02-05):
[0001728949-19-000055:note_history:60]
Adoption of this new accounting guidance most significantly impacts the timing of sales-based royalty revenues, which are the vast majority of our QTL segment’s revenues. Prior to adoption, we recognized sales-based royalties as revenues in the period in which such royalties were reported by licensees, which was after the conclusion of the quarter in which the licensees’ sales occurred and when all other revenue recognition criteria had been met. Under the new accounting guidance, we estimate and recognize sales-based royalties in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such amounts, resulting in an acceleration of revenue recognition compared to the historical method under ASC 605. Since we do not invoice for sales-based royalties estimated and recognized in any given quarter until after the conclusion of that quarter (which is generally the following quarter when such royalties are reported by licensees), revenues recognized from sales-based royalties results in unbilled receivables (included in accounts receivable, net on the consolidated balance sheet). The adoption of ASC 606 did not otherwise have a material impact.

- removed (2020-02-05):
[0001728949-19-000055:note_history:61]
The new accounting guidance also impacts the timing of recognizing certain customer incentives, which are recorded as a reduction to revenues in the period that the related revenues are earned. Prior to adoption, we accounted for certain customer incentive arrangements, including volume-related and other pricing rebates or cost reimbursements for marketing and other activities involving certain of our products and technologies, in part based on the maximum potential liability. Under the new accounting guidance, we estimate the amount of all customer incentives.

- removed (2020-02-05):
[0001728949-19-000055:note_history:62]
The following table summarizes the cumulative effects of adopting the new revenue accounting guidance (substantially all of which related to the impact to QTL’s sales-based royalties) on our condensed consolidated balance sheet at October 1, 2018 (in millions):

- removed (2020-02-05):
[0001728949-19-000055:note_history:63]
|  | Balance as of September 30, 2018 |  | Adjustment |  | Opening Balance as of October 1, 2018 |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 2,904 |  |  | $ | 957 |  |  | $ | 3,861 |  |
| Other current assets | 699 |  |  | 1 |  |  | 700 |  |
| Deferred tax assets | 936 |  |  | (98 | ) |  | 838 |  |
| Other assets | 1,970 |  |  | 1 |  |  | 1,971 |  |
| Liabilities |  |  |  |  |  |
| Unearned revenues, current | $ | 500 |  |  | $ | 6 |  |  | $ | 506 |  |
| Other current liabilities | 6,978 |  |  | 125 |  |  | 7,103 |  |
| Unearned revenues | 1,620 |  |  | (110 | ) |  | 1,510 |  |
| Stockholders’ equity |  |  |  |  |  |
| Retained earnings | $ | 542 |  |  | $ | 840 |  |  | $ | 1,382 |  |

- removed (2020-02-05):
[0001728949-19-000055:note_history:64]
The following tables summarize the impacts of adopting the new revenue accounting guidance on our condensed consolidated balance sheet and statements of operations (in millions):

- removed (2020-02-05):
[0001728949-19-000055:note_history:65]
|  | As of June 30, 2019 |
| Balance Sheet | As ReportedASC 606 |  | Adjustment |  | ASC 605 |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 2,390 |  |  | $ | (1,070 | ) |  | $ | 1,320 |  |
| Other current assets | 682 |  |  | (32 | ) |  | 650 |  |
| Deferred tax assets | 1,172 |  |  | 106 |  |  | 1,278 |  |
| Other assets | 2,062 |  |  | (1 | ) |  | 2,061 |  |
| Liabilities |  |  |  |  |  |
| Unearned revenues, current | $ | 527 |  |  | $ | (41 | ) |  | $ | 486 |  |
| Other current liabilities | 4,725 |  |  | (31 | ) |  | 4,694 |  |
| Unearned revenues | 1,251 |  |  | 138 |  |  | 1,389 |  |
| Stockholders’ equity |  |  |  |  |  |
| Retained earnings | $ | 4,687 |  |  | $ | (1,063 | ) |  | $ | 3,624 |  |

- removed (2020-02-05):
[0001728949-19-000055:note_history:66]
|  | Three Months Ended June 30, 2019 |  | Nine Months Ended June 30, 2019 |
| Statements of Operations | As Reported ASC 606 |  | Adjustment |  | ASC 605 |  | As Reported ASC 606 |  | Adjustment |  | ASC 605 |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,531 |  |  | $ | (10 | ) |  | $ | 3,521 |  |  | $ | 11,037 |  |  | $ | (80 | ) |  | $ | 10,957 |  |
| Licensing | 6,104 |  |  | (239 | ) |  | 5,865 |  |  | 8,422 |  |  | (196 | ) |  | 8,226 |  |
| Investment and other income, net | 344 |  |  | (1 | ) |  | 343 |  |  | 377 |  |  | — |  |  | 377 |  |
| Income tax (expense) benefit | (3,352 | ) |  | 49 |  |  | (3,303 | ) |  | (2,987 | ) |  | 53 |  |  | (2,934 | ) |
| Net income | 2,149 |  |  | (201 | ) |  | 1,948 |  |  | 3,880 |  |  | (223 | ) |  | 3,657 |  |

- removed (2020-02-05):
[0001728949-19-000055:note_history:67]
Adoption of the new accounting guidance had no impact to net cash provided (used) by operating, financing or investing activities on our condensed consolidated statement of cash flows for the nine months ended June 30, 2019.

- removed (2020-02-05):
[0001728949-19-000055:note_history:68]
Financial Assets: In January 2016, the FASB issued new accounting guidance on classifying and measuring financial instruments, which requires that all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings in the statement of operations. Additionally, it changes the disclosure requirements for financial instruments. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the modified retrospective transition method for investments in marketable securities, which have readily determinable fair values, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings. Upon adoption, we reclassified $50 million of unrealized gains, net of the associated tax effects, related to our investments in marketable securities from accumulated other comprehensive income to opening retained earnings. We have applied the prospective transition method for investments in non-marketable securities, which are investments in privately held companies that do not have readily determinable fair values and will recognize, through earnings, any unrealized gains that have accumulated in the period in which there is an observable transaction, if any.

- removed (2020-02-05):
[0001728949-19-000055:note_history:69]
Hedge Instruments: In August 2017, the FASB issued new accounting guidance that expands and refines hedge accounting for both financial and non-financial risks, aligns the recognition and presentation of the effects of hedging instruments and hedged items in the financial statements, and includes targeted improvements related to the assessment of hedge effectiveness. The new accounting guidance also modifies disclosure requirements for hedging activities. We adopted the new accounting guidance in the first quarter of 2019 using the modified retrospective transition method and recorded a negligible adjustment to opening retained earnings. The new accounting guidance did not have a material impact on our condensed consolidated financial statements.

- removed (2020-02-05):
[0001728949-19-000055:note_history:70]
Statement of Cash Flows: In August 2016, the FASB issued new accounting guidance related to the classification of certain cash receipts and cash payments in the statement of cash flows. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the retrospective transition method for each period presented, which did not have a material impact on our condensed consolidated statements of cash flows.

- removed (2020-02-05):
[0001728949-19-000055:note_history:71]
In November 2016, the FASB issued new accounting guidance that requires companies to include restricted cash and cash equivalents as a component in total cash and cash equivalents on the statement of cash flows. As a result, the consolidated statement of cash flows no longer reflects transfers between cash and cash equivalents and restricted cash and cash equivalents. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the retrospective transition method, which results in certain amounts in fiscal 2018 being adjusted to conform to the new accounting guidance. This includes restricted cash and cash equivalents held during fiscal 2018 related to funds deposited as collateral for outstanding letters of credit in connection with a then proposed acquisition. Restricted cash and cash equivalents related to the outstanding letters of credit totaled $2.0 billion at the end of the fourth quarter of fiscal 2017 and third quarter of fiscal 2018. Additionally, amounts for the nine months ended June 24, 2018 have been adjusted for restricted cash and cash equivalents of $2.8 billion that was irrevocably deposited to redeem long-term debt in July 2018, resulting in a decrease in net cash used by financing activities by such amount, with a corresponding increase in total cash and cash equivalents presented on the condensed consolidated statement of cash flows.

- removed (2020-02-05):
[0001728949-19-000055:note_history:72]
Income Taxes: In October 2016, the FASB issued new accounting guidance that changes the accounting for the income tax effects of intra-entity transfers of assets other than inventory. Under the new accounting guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related

- removed (2020-02-05):
[0001728949-19-000055:note_history:73]
deferred tax benefit or expense, upon receipt of the asset. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings of $2.6 billion, primarily as the result of establishing a deferred tax asset on the basis difference of certain intellectual property distributed from one of our foreign subsidiaries to a subsidiary in the United States in fiscal 2018. During the third quarter of fiscal 2019, the United States Treasury Department issued new temporary regulations that resulted in a change to the deductibility of dividend income received by a U.S. stockholder from a foreign corporation. As a result of this change, pursuant to an agreement with the Internal Revenue Service, we will forgo the federal tax basis step-up in such distributed intellectual property. Therefore, the related deferred tax asset was written-off, resulting in a $2.5 billion charge to income tax expense in the third quarter of fiscal 2019 (Note 3). The ongoing impact of this accounting guidance will be dependent on the facts and circumstances of any transactions within its scope.

- removed (2020-02-05):
[0001728949-19-000055:note_history:74]
Leases: In February 2016, the FASB issued new accounting guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease accounting guidance. The new accounting guidance requires lessees to recognize right-of-use assets and corresponding lease liabilities on the balance sheet for leases with a lease term of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. We will adopt the new accounting guidance in the first quarter of fiscal 2020 using the modified retrospective approach as of the effective date, and we will elect certain practical expedients. We do not expect finance leases to be material at the time of adoption. We are in the process of determining the effects the adoption will have on our consolidated financial statements.

- removed (2020-02-05):
[0001728949-19-000055:note_history:75]
Financial Assets: In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost will be estimated based on expected losses rather than the current incurred loss impairment model. The new accounting guidance also modifies the impairment model for available-for-sale debt securities. The new accounting guidance generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. We will adopt the new accounting guidance in the first quarter of fiscal 2021, and the impact of this new accounting guidance will largely depend on the composition and credit quality of our investment portfolio, as well as economic conditions at the time of adoption.

- removed (2020-02-05):
[0001728949-19-000055:note_history:76]
We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We also generate revenues by performing software hosting, software development and other services and from other product sales. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of our performance obligations.

- removed (2020-02-05):
[0001728949-19-000055:note_history:77]
Revenues from sales of our products are recognized upon transfer of control to the customer, which is generally at the time of shipment. Revenues from providing services are typically recognized over time as our performance obligation is satisfied. Revenues from providing services were less than 5% of total revenues for all periods presented.

- removed (2020-02-05):
[0001728949-19-000055:note_history:78]
We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops, which in general, effectively provide for a maximum royalty amount per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such royalties. Our estimates of sales-based royalties are based largely on an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property. We estimate sales-based royalties taking into consideration the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products, and consider all information

- removed (2020-02-05):
[0001728949-19-000055:note_history:79]
(historical, current and forecasted) that is reasonably available to us. Our licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter, which is generally the following quarter. As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

- removed (2020-02-05):
[0001728949-19-000055:note_history:80]
License agreements that require payment of license fees contain a single performance obligation that represents ongoing access to a portfolio of intellectual property over the license term since such agreements provide the licensee the right to access a portfolio of intellectual property that exists at inception of the license agreement and to updates and new intellectual property that is added to the licensed portfolio during the term of the agreement that are highly interdependent or interrelated. Since we expect to expend efforts to develop and transfer updates to our licensed portfolio on an even basis, license fees are recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee.

- removed (2020-02-05):
[0001728949-19-000055:note_history:81]
We account for a contract with a customer/licensee when it is legally enforceable, the parties are committed to perform their respective obligations, the rights of the parties regarding the goods and/or services to be transferred are identified, payment terms are identified, the contract has commercial substance and collectability of substantially all of the consideration is probable.

- removed (2020-02-05):
[0001728949-19-000055:note_history:82]
From time to time, regulatory authorities investigate our business practices, particularly with respect to our licensing business, and institute proceedings against us. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. Additionally, from time to time, companies initiate various strategies in an attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property, which may include disputing, underreporting, underpaying, not reporting and/or not paying royalties owed to us under their license agreements with us, or reporting to us in a manner that is not in compliance with their contractual obligations. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in ASC 606, and to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur, both of which may require significant judgment. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us.

- removed (2020-02-05):
[0001728949-19-000055:note_history:83]
On May 21, 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief (Note 6). While we believe that our business practices do not violate either antitrust law or our FRAND (fair, reasonable and non-discriminatory) licensing commitments, significant evaluation and judgment were required in determining the impact of such ruling on the amount of licensing revenues estimated and recognized in the third quarter of fiscal 2019. This included, among other items: (i) evaluating whether our license agreements remain valid and enforceable, (ii) evaluating licensees’ conduct and whether they remain committed to perform their respective obligations and (iii) determining the expected impact, if any, to the current period of any license agreements that may be renegotiated and/or are newly entered into as a result of the ruling while the stay and appeal are pending. Based on this evaluation, the impact of the ruling was not material to QTL licensing revenues in the third quarter of fiscal 2019 based on facts and factors currently known by us. As new information becomes available, we may be required to make adjustments to revenues in subsequent periods to reflect changes in estimates and/or this matter could have a material adverse effect on our ability to recognize future licensing revenues.

- removed (2020-02-05):
[0001728949-19-000055:note_history:84]
We measure revenues (including our estimates of sales-based royalties) based on the amount of consideration we expect to receive in exchange for products or services. We record reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of our products and technologies, in the period that the related revenues are earned. The charges for such arrangements are recorded as a reduction to accounts receivable, net or as other current liabilities based on whether we have the intent and contractual right of offset. Certain of these charges are considered variable consideration and are included in the transaction price primarily based on estimating the most likely amount expected to be provided to the customer/licensee.

- removed (2020-02-05):
[0001728949-19-000055:note_history:85]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied performance obligations.

- removed (2020-02-05):
[0001728949-19-000055:note_history:86]
We disaggregate our revenues by segment (Note 7) and type of product and services (as presented on our consolidated statement of operations), as we believe this best depicts how the nature, amount, timing and uncertainty of our revenues and cash flows are affected by economic factors. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time.

- removed (2020-02-05):
[0001728949-19-000055:note_history:87]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were $4.8 billion and $4.1 billion for the three and nine months ended June 30, 2019, respectively, and primarily related to licensing revenues of $4.7 billion recognized in the third quarter of fiscal 2019 (a portion of which was attributable to the first and second quarters of fiscal 2019) resulting from the settlement with Apple and its contract manufacturers (Note 6), consisting of a payment from Apple and the release of certain of our obligations to pay Apple and the contract manufacturers customer-related liabilities.

- removed (2020-02-05):
[0001728949-19-000055:note_history:88]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In the nine months ended June 30, 2019, we recognized revenues of $371 million that were recorded as unearned revenues at October 1, 2018.

- removed (2020-02-05):
[0001728949-19-000055:note_history:89]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront. At June 30, 2019, we had $1.8 billion of remaining performance obligations, of which $129 million, $516 million, $436 million, $429 million and $195 million was expected to be recognized as revenues for the remainder of fiscal 2019 and each of the subsequent four years from fiscal 2020 through 2023, respectively, and $77 million thereafter.

- removed (2020-02-05):
[0001728949-19-000055:note_history:90]
Marketable Securities and Non-Marketable Securities: Prior to the adoption of the new accounting guidance in the first quarter of fiscal 2019, investments in marketable equity securities were generally classified as available-for-sale equity investments, with net unrealized gains or losses recorded as a component of accumulated other comprehensive income, net of income taxes. Beginning in fiscal 2019, all gains and losses on investments in marketable equity securities, realized and unrealized, are recognized in investment and other income, net.

- removed (2020-02-05):
[0001728949-19-000055:note_history:91]
Prior to the adoption of the new accounting guidance in the first quarter of fiscal 2019, investments in non-marketable equity securities were recorded at cost less impairment, if any, with any losses resulting from an impairment recognized in investment and other income, net. Beginning in fiscal 2019, investments in non-marketable equity securities are recorded at cost, less impairments (if any), adjusted for observable price changes in orderly transactions for identical or similar securities (if any). All gains and losses on investments in non-marketable equity securities, realized and unrealized, are recognized in investment and other income, net.

- removed (2020-02-05):
[0001728949-19-000055:note_history:92]
In addition, prior to adoption, we recorded impairment losses in earnings on investments in non-marketable equity securities when an impairment was considered other than temporary. Beginning in fiscal 2019, we record impairment losses in earnings when we believe an investment has experienced a decline in value.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2020-02-05):
[0001728949-19-000055:note_history:93]
Debt
Revolving Credit Facility. We have an Amended and Restated Revolving Credit Facility (Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. Proceeds from the Revolving Credit Facility, if drawn, are expected to be used for general corporate purposes. Loans under the Revolving Credit Facility will bear interest, at our option, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the Revolving Credit Facility) or the Base Rate (determined in accordance with the Revolving Credit Facility), in each case plus an applicable margin based on our long-term unsecured senior, non-credit enhanced debt ratings. The margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.805% and 0.00%, respectively. The Revolving Credit Facility has a facility fee, which accrues at a rate of 0.07% per annum. At June 30, 2019 and September 30, 2018, we had not borrowed any funds under the Revolving Credit Facility.

- removed (2020-02-05):
[0001728949-19-000055:note_history:94]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At June 30, 2019 and September 30, 2018, we had $998 million and $1.0 billion, respectively, of outstanding commercial paper included in short-term debt with a weighted-average interest rate of 2.57% and 2.35%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 28 days and 16 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at June 30, 2019 and September 30, 2018.

- removed (2020-02-05):
[0001728949-19-000055:note_history:95]
Long-term Debt. The following table provides a summary of our long-term debt (in millions, except percentages):

- removed (2020-02-05):
[0001728949-19-000055:note_history:96]
|  |  | June 30, 2019 |  | September 30, 2018 |
|  |  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | $ | 250 |  |  | 3.13% |  | $ | 250 |  |  | 2.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 2.84% |  | 1,750 |  |  | 3.13% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 3.16% |  | 2,000 |  |  | 3.73% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.73% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.72% |  | 1,500 |  |  | 4.72% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 3.38% |  | 500 |  |  | 3.14% |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | 1,500 |  |  | 2.70% |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | 1,500 |  |  | 3.01% |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.47% |  | 1,500 |  |  | 4.47% |
|  | Total principal | 15,500 |  |  |  |  | 15,500 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (77 | ) |  |  |  | (85 | ) |  |  |
|  | Hedge accounting fair value adjustments | 5 |  |  |  |  | (50 | ) |  |  |
|  | Total long-term debt | $ | 15,428 |  |  |  |  | $ | 15,365 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | 2,002 |  |  |  |  | $ | — |  |  |  |
|  | Long-term debt | 13,426 |  |  |  |  | 15,365 |  |  |  |
|  | Total | $ | 15,428 |  |  |  |  | $ | 15,365 |  |  |  |

- removed (2020-02-05):
[0001728949-19-000055:note_history:97]
At June 30, 2019 and September 30, 2018, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $16.1 billion and $15.1 billion, respectively.

- removed (2020-02-05):
[0001728949-19-000055:note_history:98]
We may redeem the outstanding fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. We may not redeem the outstanding floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of our other senior unsecured indebtedness and will effectively rank junior to all liabilities of our subsidiaries.

- removed (2020-02-05):
[0001728949-19-000055:note_history:99]
At June 30, 2019, we had outstanding interest rate swaps with an aggregate notional amount of $1.8 billion related to the May 2015 Notes, which effectively converted approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recorded as interest expense in the current period. We did not enter into interest rate swaps in connection with issuance of the May 2017 Notes.

- removed (2020-02-05):
[0001728949-19-000055:note_history:100]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to our commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $516 million and $594 million in the nine months ended June 30, 2019 and June 24, 2018, respectively.

- removed (2020-02-05):
[0001728949-19-000055:note_history:101]
Debt Covenants. The Revolving Credit Facility requires that we comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. We are not subject to any financial covenants under the notes nor any covenants that would prohibit us from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by us or our subsidiaries. At June 30, 2019 and September 30, 2018, we were in compliance with the applicable covenants under the Revolving Credit Facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2020-02-05):
[0001728949-19-000055:note_history:102]
Marketable Securities
Our marketable securities were comprised as follows (in millions):

- removed (2020-02-05):
[0001728949-19-000055:note_history:103]
|  | Current |  | Noncurrent (1) |
|  | June 30, 2019 |  | September 30, 2018 |  | June 30, 2019 |  | September 30, 2018 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 19 |  |  | $ | 144 |  |  | $ | — |  |  | $ | — |  |
| Auction rate securities | — |  |  | — |  |  | 35 |  |  | 35 |  |
| Total available-for-sale debt securities | 19 |  |  | 144 |  |  | 35 |  |  | 35 |  |
| Equity securities | 416 |  |  | 167 |  |  | 1 |  |  | — |  |
| Total marketable securities | $ | 435 |  |  | $ | 311 |  |  | $ | 36 |  |  | $ | 35 |  |

- removed (2020-02-05):
[0001728949-19-000055:note_history:104]
(1) Noncurrent marketable securities were included in other assets.

- removed (2020-02-05):
[0001728949-19-000055:note_history:105]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

- removed (2020-02-05):
[0001728949-19-000055:note_history:106]
|  | June 30, 2019 |
| Years to Maturity |  |
| Less than one year | $ | 19 |  |
| No single maturity date | 35 |  |
| Total | $ | 54 |  |

- removed (2020-02-05):
[0001728949-19-000055:note_history:107]
Debt securities with no single maturity date included auction rate securities.
During the three and nine months ended June 30, 2019, there were no realized gains or losses on sales of available-for-sale debt securities, and during the three months ended June 24, 2018, gross realized gains and losses were negligible. During the nine months ended June 24, 2018, gross realized gains and losses were $15 million and negligible, respectively. As of June 30, 2019 and September 30, 2018, unrealized gains and losses on available-for-sale debt securities were negligible. As of September 30, 2018, available-for-sale securities also included equity securities with a fair value of $167 million, including an unrealized gain of $63 million.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2020-02-05):
[0001728949-19-000055:note_history:108]
The following table provides a summary of our long-term debt (in millions, except percentages):

- removed (2020-02-05):
[0001728949-19-000055:note_history:109]
|  |  | June 30, 2019 |  | September 30, 2018 |
|  |  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | $ | 250 |  |  | 3.13% |  | $ | 250 |  |  | 2.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 2.84% |  | 1,750 |  |  | 3.13% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 3.16% |  | 2,000 |  |  | 3.73% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.73% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.72% |  | 1,500 |  |  | 4.72% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 3.38% |  | 500 |  |  | 3.14% |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | 1,500 |  |  | 2.70% |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | 1,500 |  |  | 3.01% |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.47% |  | 1,500 |  |  | 4.47% |
|  | Total principal | 15,500 |  |  |  |  | 15,500 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (77 | ) |  |  |  | (85 | ) |  |  |
|  | Hedge accounting fair value adjustments | 5 |  |  |  |  | (50 | ) |  |  |
|  | Total long-term debt | $ | 15,428 |  |  |  |  | $ | 15,365 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | 2,002 |  |  |  |  | $ | — |  |  |  |
|  | Long-term debt | 13,426 |  |  |  |  | 15,365 |  |  |  |
|  | Total | $ | 15,428 |  |  |  |  | $ | 15,365 |  |  |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-02-05):
[0001728949-20-000011:note_history:110]
| Short-term debt (in millions) |  |  |  |
|  | December 29, 2019 |  | September 29, 2019 |
| Commercial paper | $ | 499 |  |  | $ | 499 |  |
| Current portion of long-term debt | 1,999 |  |  | 1,997 |  |
|  | $ | 2,498 |  |  | $ | 2,496 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-02-05):
[0001728949-20-000011:note_history:111]
We disaggregate our revenues by segment (Note 6) and type of products and services (as presented on our condensed consolidated statement of operations), as we believe this best depicts how the nature, amount, timing and uncertainty of our revenues and cash flows are affected by economic factors. Substantially all of QCT’s (Qualcomm CDMA Technologies) revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s (Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time.

- removed (2020-02-05):
[0001728949-19-000055:note_history:112]
As a result of the adoption of ASC 606, we revised our revenue recognition policy beginning in fiscal 2019 as follows.
We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We also generate revenues by performing software hosting, software development and other services and from other product sales. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of our performance obligations.

- removed (2020-02-05):
[0001728949-19-000055:note_history:113]
Revenues from sales of our products are recognized upon transfer of control to the customer, which is generally at the time of shipment. Revenues from providing services are typically recognized over time as our performance obligation is satisfied. Revenues from providing services were less than 5% of total revenues for all periods presented.

- removed (2020-02-05):
[0001728949-19-000055:note_history:114]
We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops, which in general, effectively provide for a maximum royalty amount per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such royalties. Our estimates of sales-based royalties are based largely on an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property. We estimate sales-based royalties taking into consideration the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products, and consider all information

- removed (2020-02-05):
[0001728949-19-000055:note_history:115]
(historical, current and forecasted) that is reasonably available to us. Our licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter, which is generally the following quarter. As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

- removed (2020-02-05):
[0001728949-19-000055:note_history:116]
License agreements that require payment of license fees contain a single performance obligation that represents ongoing access to a portfolio of intellectual property over the license term since such agreements provide the licensee the right to access a portfolio of intellectual property that exists at inception of the license agreement and to updates and new intellectual property that is added to the licensed portfolio during the term of the agreement that are highly interdependent or interrelated. Since we expect to expend efforts to develop and transfer updates to our licensed portfolio on an even basis, license fees are recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee.

- removed (2020-02-05):
[0001728949-19-000055:note_history:117]
We account for a contract with a customer/licensee when it is legally enforceable, the parties are committed to perform their respective obligations, the rights of the parties regarding the goods and/or services to be transferred are identified, payment terms are identified, the contract has commercial substance and collectability of substantially all of the consideration is probable.

- removed (2020-02-05):
[0001728949-19-000055:note_history:118]
From time to time, regulatory authorities investigate our business practices, particularly with respect to our licensing business, and institute proceedings against us. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. Additionally, from time to time, companies initiate various strategies in an attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property, which may include disputing, underreporting, underpaying, not reporting and/or not paying royalties owed to us under their license agreements with us, or reporting to us in a manner that is not in compliance with their contractual obligations. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in ASC 606, and to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur, both of which may require significant judgment. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us.

- removed (2020-02-05):
[0001728949-19-000055:note_history:119]
On May 21, 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief (Note 6). While we believe that our business practices do not violate either antitrust law or our FRAND (fair, reasonable and non-discriminatory) licensing commitments, significant evaluation and judgment were required in determining the impact of such ruling on the amount of licensing revenues estimated and recognized in the third quarter of fiscal 2019. This included, among other items: (i) evaluating whether our license agreements remain valid and enforceable, (ii) evaluating licensees’ conduct and whether they remain committed to perform their respective obligations and (iii) determining the expected impact, if any, to the current period of any license agreements that may be renegotiated and/or are newly entered into as a result of the ruling while the stay and appeal are pending. Based on this evaluation, the impact of the ruling was not material to QTL licensing revenues in the third quarter of fiscal 2019 based on facts and factors currently known by us. As new information becomes available, we may be required to make adjustments to revenues in subsequent periods to reflect changes in estimates and/or this matter could have a material adverse effect on our ability to recognize future licensing revenues.

- removed (2020-02-05):
[0001728949-19-000055:note_history:120]
We measure revenues (including our estimates of sales-based royalties) based on the amount of consideration we expect to receive in exchange for products or services. We record reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of our products and technologies, in the period that the related revenues are earned. The charges for such arrangements are recorded as a reduction to accounts receivable, net or as other current liabilities based on whether we have the intent and contractual right of offset. Certain of these charges are considered variable consideration and are included in the transaction price primarily based on estimating the most likely amount expected to be provided to the customer/licensee.

- removed (2020-02-05):
[0001728949-19-000055:note_history:121]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied performance obligations. 
We disaggregate our revenues by segment (Note 7) and type of product and services (as presented on our consolidated statement of operations), as we believe this best depicts how the nature, amount, timing and uncertainty of our revenues and cash flows are affected by economic factors. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time.
