# QCOM MD&A — 0001728949-20-000011


## mdna

[0001728949-20-000011:mdna:1]
[same as prior period, unchanged from 0001728949-19-000055:mdna:1]

[0001728949-20-000011:mdna:2]
This information should be read in conjunction with the condensed consolidated financial statements and the notes thereto included in “Part I, Item 1” of this Quarterly Report and with “Management’s Discussion and Analysis of Financial Condition and Results of Operations” for the fiscal year ended September 29, 2019 contained in our 2019 Annual Report on Form 10-K.

[0001728949-20-000011:mdna:3]
This Quarterly Report (including, but not limited to, this section regarding Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements regarding our business, investments, financial condition, results of operations and prospects. Forward-looking statements include but are not limited to statements regarding industry, market, business, product, technology, commercial, competitive or consumer trends; our businesses, growth potential or strategies, or factors that may impact them; challenges to our licensing business, including by licensees, governments, governmental agencies or regulators, standards bodies or others; challenges to our QCT business; other legal or regulatory matters; competition; new or expanded product areas, adjacent industry segments or applications; costs or expenditures including research and development, selling, general and administrative, restructuring or restructuring-related charges, working capital or information technology systems; our financing, stock repurchase or dividend programs; strategic investments or acquisitions; adoption and application of future accounting guidance; tax law changes; our tax structure or strategies; or the potential business or financial statement impacts of any of the above, among others. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001728949-20-000011:mdna:4]
First Quarter Fiscal 2020 Overview

[0001728949-20-000011:mdna:5]
Revenues for the first quarter of fiscal 2020 were $5.1 billion, an increase of 5% compared to the year ago quarter, with net income of $925 million, a decrease of 13% compared to the year ago quarter. Highlights and other key developments from the first quarter of fiscal 2020 included:

[0001728949-20-000011:mdna:6]
| • | QTL revenues in the first quarter of fiscal 2020 benefited from the inclusion of royalties from Apple for sales made during the December 2019 quarter (as a result of the settlement with Apple and its contract manufacturers in April 2019), which reflected the impact of Apple’s fall device launches in advance of the holiday season. We did not record any revenues in the first quarter of fiscal 2020 for royalties due on the sales of Huawei’s products. |

[0001728949-20-000011:mdna:7]
| • | QCT revenues decreased by 3% in the first quarter of fiscal 2020 compared to the year ago quarter, primarily due to a decrease in Mobile Station Modem (MSM™) unit shipments. |

[0001728949-20-000011:mdna:8]
[same as prior period, unchanged from 0001728949-19-000055:mdna:17]

[0001728949-20-000011:mdna:9]
We develop and commercialize foundational technologies and products used in mobile devices and other wireless products. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents and other rights.

[0001728949-20-000011:mdna:10]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices (primarily smartphones), tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, broadband gateway equipment, data cards and infrastructure equipment, IoT devices and applications, other consumer electronics and automotive telematics and infotainment systems. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale and/or use of certain wireless products.

[0001728949-20-000011:mdna:11]
Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and other wireless technology and service initiatives.

[0001728949-20-000011:mdna:12]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering, research and development functions, are operated by QTI (Qualcomm Technologies, Inc.), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001728949-20-000011:mdna:13]
Seasonality. Many of our products and/or much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when the related royalties were recognized, which prior to fiscal 2019 was when licensees reported their sales and beginning in fiscal 2019 when the licensees’ sales occurred. Our historical trends were impacted by our prior dispute with Apple and its contract manufacturers, which was settled in April 2019. We expect to begin recording equipment revenues for new chipset models under our multi-year chipset agreement with Apple in the second half of fiscal 2020. These trends may or may not continue in the future. Further, the trends for QTL have been, and/or may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings, including the lawsuit filed against us by the FTC.

[0001728949-20-000011:mdna:14]
[same as prior period, unchanged from 0001728949-19-000055:mdna:25]

[0001728949-20-000011:mdna:15]
| Revenues (in millions) |
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |  | Change |
| Equipment and services | $ | 3,534 |  |  | $ | 3,754 |  |  | $ | (220 | ) |
| Licensing | 1,543 |  |  | 1,088 |  |  | 455 |  |
|  | $ | 5,077 |  |  | $ | 4,842 |  |  | $ | 235 |  |

[0001728949-20-000011:mdna:16]
First quarter 2020 vs. 2019

[0001728949-20-000011:mdna:17]
The increase in revenues in the first quarter of fiscal 2020 was primarily due to:

[0001728949-20-000011:mdna:18]
| + | $386 million in higher licensing revenues from our QTL segment |

[0001728949-20-000011:mdna:19]
| - | $194 million in lower equipment and services revenues from our QCT segment |

[0001728949-20-000011:mdna:20]
| Costs and Expenses (in millions, except percentages) |
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |  | Change |
| Cost of revenues | $ | 2,113 |  |  | $ | 2,188 |  |  | $ | (75 | ) |
| Gross margin | 58 | % |  | 55 | % |  |  |

[0001728949-20-000011:mdna:21]
First quarter 2020 vs. 2019

[0001728949-20-000011:mdna:22]
Gross margin percentage increased in the first quarter of fiscal 2020 primarily due to:

[0001728949-20-000011:mdna:23]
| + | increase in higher margin QTL licensing revenues as a proportion of total revenues |

[0001728949-20-000011:mdna:24]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |  | Change |
| Research and development | $ | 1,406 |  |  | $ | 1,269 |  |  | $ | 137 |  |
| % of revenues | 28 | % |  | 26 | % |  |  |

[0001728949-20-000011:mdna:25]
20

[0001728949-20-000011:mdna:26]
First quarter 2020 vs. 2019

[0001728949-20-000011:mdna:27]
The dollar increase in research and development expenses in the first quarter of fiscal 2020 was primarily due to:

[0001728949-20-000011:mdna:28]
| + | $93 million increase primarily driven by higher costs related to the development of wireless and integrated circuit technologies, including 5G technologies and RFFE technologies and related software products |

[0001728949-20-000011:mdna:29]
| + | $51 million increase in share-based compensation expense |

[0001728949-20-000011:mdna:30]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |  | Change |
| Selling, general and administrative | $ | 528 |  |  | $ | 526 |  |  | $ | 2 |  |
| % of revenues | 10 | % |  | 11 | % |  |  |

[0001728949-20-000011:mdna:31]
First quarter 2020 vs. 2019

[0001728949-20-000011:mdna:32]
Selling, general and administrative expenses remained approximately flat in the first quarter of fiscal 2020 primarily due to:

[0001728949-20-000011:mdna:33]
| + | $41 million in higher expenses driven by revaluation of our deferred compensation obligation on strong stock market performance (which resulted in a corresponding increase in net gains on marketable securities within investment and other income, net due to the revaluation of the related assets) |

[0001728949-20-000011:mdna:34]
| - | $60 million in lower litigation costs, primarily resulting from the settlement of our prior dispute with Apple and its contract manufacturers in April 2019 |

[0001728949-20-000011:mdna:35]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |  | Change |
| Other | $ | — |  |  | $ | 149 |  |  | $ | (149 | ) |

[0001728949-20-000011:mdna:36]
First quarter 2019

[0001728949-20-000011:mdna:37]
Other expenses in the first quarter of fiscal 2019 consisted of:

[0001728949-20-000011:mdna:38]
| + | $180 million in restructuring and restructuring-related charges related to our Cost Plan that concluded in fiscal 2019 |

[0001728949-20-000011:mdna:39]
-    $31 million benefit related to a favorable legal settlement

[0001728949-20-000011:mdna:40]
| Interest Expense and Investment and Other Income, Net (in millions) |
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |  | Change |
| Interest expense | $ | 148 |  |  | $ | 156 |  |  | $ | (8 | ) |
| Investment and other income, net |  |  |  |  |  |
| Interest and dividend income | $ | 69 |  |  | $ | 74 |  |  | $ | (5 | ) |
| Net gains (losses) on marketable securities | 31 |  |  | (72 | ) |  | 103 |  |
| Net gains on other investments | 48 |  |  | 35 |  |  | 13 |  |
| Impairment losses on other investments | (72 | ) |  | (9 | ) |  | (63 | ) |
| Net gains (losses) on derivative instruments | 2 |  |  | (8 | ) |  | 10 |  |
| Equity in net losses of investees | (10 | ) |  | (21 | ) |  | 11 |  |
| Net (losses) gains on foreign currency transactions | (3 | ) |  | 6 |  |  | (9 | ) |
|  | $ | 65 |  |  | $ | 5 |  |  | $ | 60 |  |

[0001728949-20-000011:mdna:41]
21

[0001728949-20-000011:mdna:42]
| Income Tax Expense (Benefit) (in millions, except percentages) |
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |  | Change |
| Income tax expense (benefit) | $ | 22 |  |  | $ | (509 | ) |  | $ | 531 |  |
| Effective tax rate | 2 | % |  | (91 | %) |  | 93 | % |

[0001728949-20-000011:mdna:43]
[same as prior period, unchanged from 0001728949-19-000055:mdna:85]

[0001728949-20-000011:mdna:44]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |
| Expected income tax provision at federal statutory tax rate | $ | 199 |  |  | $ | 117 |  |
| Excess tax benefit associated with share-based awards | (47 | ) |  | (1 | ) |
| Benefit from foreign-derived intangible income (FDII) deduction | (46 | ) |  | (41 | ) |
| Valuation allowance release on capital loss carryforwards | (44 | ) |  | — |  |
| Foreign currency gain related to foreign withholding tax receivable | (43 | ) |  | — |  |
| Benefit related to the research and development tax credit | (25 | ) |  | (24 | ) |
| Foreign income taxed at other than U.S. rates | 7 |  |  | 4 |  |
| Benefit from establishing new U.S. net deferred tax assets | — |  |  | (570 | ) |
| Other | 21 |  |  | 6 |  |
| Income tax expense (benefit) | $ | 22 |  |  | $ | (509 | ) |

[0001728949-20-000011:mdna:45]
We estimate our annual effective income tax rate to be 11% for fiscal 2020. The estimated annual effective tax rate for fiscal 2020 is lower than the U.S. federal statutory rate since a significant portion of our income qualifies for preferential treatment as FDII at a 13% effective tax rate and due to benefits from our research and development tax credit.

[0001728949-20-000011:mdna:46]
The United States Treasury Department has issued proposed regulations on several provisions of the 2017 Tax Cuts and Jobs Act (the Tax Legislation), including FDII and interest expense deduction limitations, which are expected to be finalized in the next several months. When finalized, these proposed regulations may adversely affect our provision for income taxes, results of operations and/or cash flows.

[0001728949-20-000011:mdna:47]
[same as prior period, unchanged from 0001728949-19-000055:mdna:94]

[0001728949-20-000011:mdna:48]
The following should be read in conjunction with the financial results for the first quarter of fiscal 2020 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0001728949-20-000011:mdna:49]
QCT Segment (in millions, except percentages)

[0001728949-20-000011:mdna:50]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |  | Change |
| Revenues |  |  |  |  |  |
| Equipment and services | $ | 3,484 |  |  | $ | 3,678 |  |  | $ | (194 | ) |
| Licensing | 134 |  |  | 61 |  |  | 73 |  |
| Total revenues | $ | 3,618 |  |  | $ | 3,739 |  |  | $ | (121 | ) |
| Earnings before taxes (EBT) | $ | 479 |  |  | $ | 598 |  |  | $ | (119 | ) |
| EBT as a % of revenues | 13 | % |  | 16 | % |  | (3 | %) |

[0001728949-20-000011:mdna:51]
Equipment and services revenues primarily relate to sales of MSM, Radio Frequency (RF), Power Management (PM) and wireless connectivity chipsets. MSM integrated circuits include our stand-alone Mobile Data Modems (MDMs) and Snapdragon platforms, including processors and modems. Approximately 155 million and 186 million MSM integrated circuits were sold in the first quarter of fiscal 2020 and 2019, respectively.

[0001728949-20-000011:mdna:52]
22

[0001728949-20-000011:mdna:53]
First quarter 2020 vs. 2019

[0001728949-20-000011:mdna:54]
The decrease in QCT equipment and services revenues in the first quarter of fiscal 2020 was primarily due to:

[0001728949-20-000011:mdna:55]
| - | $287 million in lower MSM and accompanying RF, PM and wireless connectivity chipset shipments, primarily driven by lower modem sales to Apple and a decrease in 4G premium tier shipments ahead of the ramp of 5G |

[0001728949-20-000011:mdna:56]
QCT EBT as a percentage of revenues decreased in the first quarter of fiscal 2020 primarily due to:

[0001728949-20-000011:mdna:57]
| - | lower QCT revenues |

[0001728949-20-000011:mdna:58]
QTL Segment (in millions, except percentages)

[0001728949-20-000011:mdna:59]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |  | Change |
| Licensing revenues | $ | 1,404 |  |  | $ | 1,018 |  |  | $ | 386 |  |
| EBT | $ | 1,017 |  |  | $ | 590 |  |  | $ | 427 |  |
| EBT as a % of revenues | 72 | % |  | 58 | % |  | 14 | % |

[0001728949-20-000011:mdna:60]
As a result of the settlement with Apple and its contract manufacturers in April 2019, QTL results for the first quarter of fiscal 2020 included royalties from Apple and its contract manufactures. Revenues in the first quarter of fiscal 2019 did not include royalties from sales of Apple or other products by Apple’s contract manufacturers.

[0001728949-20-000011:mdna:61]
QTL revenues in the first quarter of fiscal 2019 included $150 million of royalties from Huawei under a second interim agreement that concluded in the third quarter of fiscal 2019. This represented a minimum, non-refundable amount for royalties due and does not reflect the full amount of royalties due under the underlying license agreement, which expired on December 31, 2019. We have not reached a final amended or new agreement with Huawei, and we did not record any revenues in the first quarter of fiscal 2020 for royalties due on the sales of Huawei’s products.

[0001728949-20-000011:mdna:62]
First quarter 2020 vs. 2019

[0001728949-20-000011:mdna:63]
The increase in QTL licensing revenues in the first quarter of fiscal 2020 was primarily due to:

[0001728949-20-000011:mdna:64]
| + | $571 million increase in estimated sales of 3G/4G/5G-based products (including multimode products), primarily due to the new license agreement with Apple, which reflected the impact of Apple’s fall device launches in advance of the holiday season |

[0001728949-20-000011:mdna:65]
| - | $150 million in lower royalty revenues from Huawei due to the expiration of the interim agreement |

[0001728949-20-000011:mdna:66]
| - | $53 million in lower estimated revenues per unit, in part reflecting licensees entering into new 5G multimode license agreements with rights to our cellular standard-essential patents only (compared to previous licenses which also included rights to certain other non-cellular essential patents) and decreases in our per unit royalty caps |

[0001728949-20-000011:mdna:67]
QTL EBT as a percentage of revenues increased in the first quarter of fiscal 2020 primarily due to:

[0001728949-20-000011:mdna:68]
| + | higher QTL revenues |

[0001728949-20-000011:mdna:69]
| + | lower selling, general and administrative expenses, primarily from lower litigation costs |

[0001728949-20-000011:mdna:70]
QTL accounts receivable increased by 20% in the first quarter of fiscal 2020 from $1.54 billion to $1.84 billion, primarily due to an increase in licensing revenues. At December 29, 2019, 29% of total accounts receivable included estimated royalties from two key Chinese licensees, primarily from sales made in the last three fiscal quarters (including amounts that are not yet due) under license agreements that were extended and now expire on March 31, 2020. Certain of such amounts have been delayed while good faith negotiations continue to amend the existing license agreements or enter into new license agreements. The existing agreements are legally enforceable, the amounts outstanding are considered probable of being collected and we believe these licensees are committed to make payment. These licensees/customers continue to make timely payments on purchases of integrated circuit products.

[0001728949-20-000011:mdna:71]
QSI Segment (in millions)

[0001728949-20-000011:mdna:72]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |  | Change |
| Equipment and services revenues | $ | 20 |  |  | $ | 27 |  |  | $ | (7 | ) |
| (Loss) earnings before tax (EBT) | (3 | ) |  | 8 |  |  | (11 | ) |

[0001728949-20-000011:mdna:73]
First quarter 2020 vs. 2019

[0001728949-20-000011:mdna:74]
The decrease in QSI EBT in the first quarter of fiscal 2020 was primarily due to:

[0001728949-20-000011:mdna:75]
| - | $61 million increase in impairment losses on investments |

[0001728949-20-000011:mdna:76]
| + | $46 million increase in net gains on investments |

[0001728949-20-000011:mdna:77]
[same as prior period, unchanged from 0001728949-19-000055:mdna:157]

[0001728949-20-000011:mdna:78]
In the coming years, we expect consumer demand for 3G/4G multimode and 4G products and services to decline as new consumer demand for 3G/4G/5G multimode and 5G products and services ramps around the world. We expect growth in new device categories and industries, resulting from the expanding adoption of certain technologies that are already commonly used in smartphones by industry segments outside traditional cellular industries, such as automotive, computing, IoT and networking.

[0001728949-20-000011:mdna:79]
[same as prior period, unchanged from 0001728949-19-000055:mdna:159]

[0001728949-20-000011:mdna:80]
| • | In May 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief. We disagree with the court’s conclusions, interpretation of the facts and application of the law. Accordingly, we filed a motion to stay certain of the remedies with, and appealed the decision to, the Ninth Circuit Court of Appeals (Ninth Circuit). In July 2019, the Ninth Circuit granted our appeal, and oral argument is scheduled for February 13, 2020. In August 2019, the Ninth Circuit granted our partial motion to stay in its entirety. Regulatory authorities in certain jurisdictions are investigating and/or have investigated our business practices and instituted proceedings against us, and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. These activities have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs until the respective matters are resolved. See “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report, including the Risk Factors entitled “Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations” and “Efforts by some OEMs or their customers to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.” |

[0001728949-20-000011:mdna:81]
| • | We did not record any revenues in the first quarter of fiscal 2020 for royalties due on the sales of Huawei’s products, and our license agreement with Huawei expired on December 31, 2019. The agreement provides either party the right to initiate binding arbitration for a period of several months, the result of which will be a new license agreement effective January 1, 2020. To date, neither party has initiated arbitration. Huawei may not make any other payments or may not make full payments due under the prior or any new license agreement. This may result in significant legal costs and will negatively impact our future revenues, as well as our financial condition, results of operations and cash flows, until the dispute is resolved. |

[0001728949-20-000011:mdna:82]
24

[0001728949-20-000011:mdna:83]
| • | Our license agreements with two key Chinese licensees were extended and now expire on March 31, 2020. Such agreements provide either party the right to initiate binding arbitration for a period of several months, the result of which will be a new license agreement. Although good faith negotiations continue, we have not reached final new agreements with these licensees. Further delay in entering into new license agreements with these licensees could have a material adverse effect on our ability to recognize future licensing revenues from these licensees, as well as our financial condition, results of operations and cash flows. |

[0001728949-20-000011:mdna:84]
| • | We have not been the sole supplier of modems for iPhone products beginning with products that launched in September 2016, and Apple is not utilizing our modems for iPhone products that launched in September 2019. In the second half of fiscal 2020, we expect QCT to begin recording revenues under our multi-year chipset agreement with Apple announced in April 2019. |

[0001728949-20-000011:mdna:85]
[same as prior period, unchanged from 0001728949-19-000055:mdna:163]

[0001728949-20-000011:mdna:86]
| • | Increased concentration of device share among a few companies, particularly within the premium tier, resulting in significant supply chain leverage for those companies, and exacerbating the negative impact to our business and financial results to the extent those companies do not utilize our chipsets. For example, Huawei has taken, and may continue to take, share in China from other Chinese OEMs, negatively impacting QCT as we sell a limited number of chipsets to Huawei as compared to many of those other OEMs. In addition, the negative impact to our overall business of Huawei share gains at the expense of other Chinese OEMs may be further exacerbated if a new license agreement with Huawei is not signed in the near term and/or Huawei continues to not pay us royalties or does not make full payment due to us under the prior or any new license agreement; |

[0001728949-20-000011:mdna:87]
| • | Decisions by companies to utilize their own internally-developed integrated circuit products and/or sell such products to others, including by selling them together with certain of their other products; |

[0001728949-20-000011:mdna:88]
| • | Decisions by certain companies to utilize our competitors’ integrated circuit products in all or a portion of their devices; |

[0001728949-20-000011:mdna:89]
[same as prior period, unchanged from 0001728949-19-000055:mdna:168]

[0001728949-20-000011:mdna:90]
| • | Lengthened handset replacement cycles and consumer demand, which is increasingly driven by new product launches and/or innovation cycles; and |

[0001728949-20-000011:mdna:91]
| • | Continued growth of device share by Chinese OEMs in China and in regions outside of China. |

[0001728949-20-000011:mdna:92]
[same as prior period, unchanged from 0001728949-19-000055:mdna:172]

[0001728949-20-000011:mdna:93]
| • | The recent outbreak of a coronavirus that originated in China may negatively impact consumer demand and/or our ability, or the ability of our suppliers, to manufacture products, which would negatively impact our business and results of operations. |

[0001728949-20-000011:mdna:94]
| • | Commercial 5G network deployments and device launches have begun and will continue through calendar 2020 and beyond. We believe that 5G technologies will empower a new era of smartphones and connected devices. We also believe that 5G will drive transformation across industries beyond traditional cellular communications that will create new business models and new services. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing of 5G technologies, and to be a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long term. |

[0001728949-20-000011:mdna:95]
[same as prior period, unchanged from 0001728949-19-000055:mdna:176]

[0001728949-20-000011:mdna:96]
Further discussion of risks related to our business is provided in the section labeled “Risk Factors” included in this Quarterly Report.

[0001728949-20-000011:mdna:97]
[same as prior period, unchanged from 0001728949-19-000055:mdna:178]

[0001728949-20-000011:mdna:98]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following table presents selected financial information related to our liquidity as of December 29, 2019 and September 29, 2019 and for the first three months of fiscal 2020 and 2019 (in millions):

[0001728949-20-000011:mdna:99]
|  | December 29, 2019 |  | September 29, 2019 |  | $ Change |
| Cash, cash equivalents and marketable securities | $ | 11,458 |  |  | $ | 12,296 |  |  | $ | (838 | ) |
| Accounts receivable, net | 2,737 |  |  | 2,471 |  |  | 266 |  |
| Inventories | 1,420 |  |  | 1,400 |  |  | 20 |  |
| Short-term debt | 2,498 |  |  | 2,496 |  |  | 2 |  |
| Long-term debt | 13,437 |  |  | 13,437 |  |  | — |  |
| Noncurrent income taxes payable | 2,054 |  |  | 2,088 |  |  | (34 | ) |

[0001728949-20-000011:mdna:100]
|  | Three Months Ended |
|  | December 29, 2019 |  | December 30, 2018 |  | $ Change |
| Net cash provided by operating activities | $ | 1,118 |  |  | $ | 356 |  |  | $ | 762 |  |
| Net cash used by investing activities | (203 | ) |  | (152 | ) |  | (51 | ) |
| Net cash used by financing activities | (1,659 | ) |  | (1,887 | ) |  | 228 |  |

[0001728949-20-000011:mdna:101]
The net decrease in cash, cash equivalents and marketable securities was primarily due to $762 million in payments to repurchase shares of our common stock, $710 million in cash dividends paid, $296 million in capital expenditures and $201 million in payments of tax withholdings related to the vesting of share-based awards, partially offset by net cash provided by operating activities and proceeds from certain other investing activities.

[0001728949-20-000011:mdna:102]
Our days sales outstanding, on a consolidated basis, increased to 49 days at December 29, 2019, as compared to 47 days at September 29, 2019. The increase in days sales outstanding was primarily due to an increase in QTL licensing revenues and accounts receivable as a proportion of total revenues and total receivables, respectively. The increase in accounts receivable was primarily due to an increase in QTL licensing revenues.

[0001728949-20-000011:mdna:103]
Debt. At December 29, 2019, we had $15.5 billion of principal floating- and fixed-rate notes outstanding, $2.0 billion of which matures in May 2020. The remaining debt has maturity dates in 2022 through 2047.

[0001728949-20-000011:mdna:104]
Our Amended and Restated Revolving Credit Facility (Revolving Credit Facility) provides for unsecured revolving facility loans, swing line loans and letters of credit in the aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion expire on February 18, 2020 and November 8, 2021, respectively. At December 29, 2019, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-20-000011:mdna:105]
We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At December 29, 2019, we had $499 million of commercial paper outstanding.

[0001728949-20-000011:mdna:106]
We may issue additional debt in the future. The amount and timing of such additional borrowings will be subject to a number of factors, including acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors. Additional information regarding our outstanding debt is provided in “Notes to Consolidated Financial Statements, Note 6. Debt” in our 2019 Annual Report on Form 10-K.

[0001728949-20-000011:mdna:107]
Income Taxes. At December 29, 2019, we estimated remaining future payments of $2.3 billion for the one-time U.S. repatriation tax accrued in fiscal 2018 (Toll Charge), after application of certain tax credits, which is payable in installments over the next seven years. At December 29, 2019, other current liabilities included $209 million reflecting the installment paid in January 2020. We estimate the next installment due in January 2021 to be $176 million.

[0001728949-20-000011:mdna:108]
[same as prior period, unchanged from 0001728949-19-000055:mdna:193]

[0001728949-20-000011:mdna:109]
Capital Return Program. In fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. In the first quarter of fiscal 2020, we repurchased and retired 9.2 million shares of our

[0001728949-20-000011:mdna:110]
26

[0001728949-20-000011:mdna:111]
common stock for $762 million, before commissions. At December 29, 2019, $6.3 billion remained authorized for repurchase under the stock repurchase program. Since December 29, 2019, we repurchased and retired 2.9 million shares of common stock for $260 million. This stock repurchase program has no expiration date. We intend to continue to use our stock repurchase program as a means of returning capital to stockholders, subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders and may accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-20-000011:mdna:112]
In the first quarter of fiscal 2020, we paid cash dividends totaling $710 million, or $0.62 per share. On January 17, 2020, we announced a cash dividend of $0.62 per share on our common stock, payable on March 26, 2020 to stockholders of record as of the close of business on March 5, 2020. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-20-000011:mdna:113]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2019 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At December 29, 2019, there have been no material changes to our expected working and other capital requirements described in our 2019 Annual Report on Form 10-K. At December 29, 2019, $1.4 billion was accrued related to two fines imposed by the EC (based on the exchange rate at December 29, 2019, including related foreign currency gains and accrued interest). We have provided financial guarantees in lieu of cash payment to satisfy the obligations while we appeal the EC’s decisions.

[0001728949-20-000011:mdna:114]
Further, regulatory authorities in certain jurisdictions are investigating and/or have investigated our business practices and instituted proceedings against us, including the lawsuit filed against us by the FTC in which a ruling was issued in favor of the FTC in May 2019, and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees, have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0001728949-20-000011:mdna:115]
We believe our cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans.

[0001728949-20-000011:mdna:116]
[same as prior period, unchanged from 0001728949-19-000055:mdna:206]

[0001728949-20-000011:mdna:117]
[same as prior period, unchanged from 0001728949-19-000055:mdna:207]

[0001728949-20-000011:mdna:118]
Additional information regarding our financial commitments at December 29, 2019 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items,” “Note 3. Income Taxes” and “Note 5. Commitments and Contingencies.”

[0001728949-20-000011:mdna:119]
Recent Accounting Guidance

[0001728949-20-000011:mdna:120]
Information regarding recent accounting guidance and the impact of such guidance on our consolidated financial statements is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 1. Basis of Presentation and Significant Accounting Policies Update.”

[0001728949-20-000011:mdna:121]
[same as prior period, unchanged from 0001728949-19-000055:mdna:217]

[0001728949-20-000011:mdna:122]
You should consider each of the following factors in evaluating our business and our prospects. The risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also negatively impact our business and results of operations and require significant management time and attention. In that case, the trading price of our common stock could decline. You should also consider the other information set forth in this Quarterly Report in evaluating our business and our prospects, including but not limited to our financial statements and the related notes, and “Part I, Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” References to “and” and “or” should be read to include the other as well as “and/or,” as appropriate.

[0001728949-20-000011:mdna:123]
[same as prior period, unchanged from 0001728949-19-000055:mdna:219]

[0001728949-20-000011:mdna:124]
[same as prior period, unchanged from 0001728949-19-000055:mdna:220]

[0001728949-20-000011:mdna:125]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on operators of wireless networks and our customers and licensees to adopt and implement the latest generation of these technologies for use in their networks, devices and services. We also depend on our customers and licensees to develop devices and services based on these technologies with value-added features to drive consumer demand for new 3G/4G and 3G/4G/5G multimode devices, as well as 3G, 4G and 5G single-mode devices, and to establish the selling prices for such devices. Further, the timing of our shipment of products and completion of services is dependent on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries and applications beyond traditional cellular communications, such as automotive, computing, IoT (including the connected home, smart cities, wearables, voice and music and robotics) and networking, among others.

[0001728949-20-000011:mdna:126]
We have historically been successful during wireless technology transitions, including 3G and 4G. The latest generation of wireless technologies is 5G, which we expect will empower a new era of connected devices and will be utilized not only in handsets but also in new device types, industries and applications beyond traditional cellular communications, as described above (see also Part I, Item 1, “Business” in our most recent Annual Report on Form 10-K for further description of 5G). Commercial deployments of 5G networks and devices have begun and will continue through fiscal 2020 and beyond. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and technology licensing, and that we develop, commercialize and be a leading supplier of 5G integrated circuit products and services, in order to sustain and grow our business long-term.

[0001728949-20-000011:mdna:127]
27

[0001728949-20-000011:mdna:128]
[same as prior period, unchanged from 0001728949-19-000055:mdna:223]

[0001728949-20-000011:mdna:129]
[same as prior period, unchanged from 0001728949-19-000055:mdna:224]

[0001728949-20-000011:mdna:130]
| • | wireless operators delay next-generation network deployments, expansions or upgrades or delay moving customers to 3G/4G and 3G/4G/5G multimode devices, as well as 4G and 5G single-mode devices; |

[0001728949-20-000011:mdna:131]
| • | Long Term Evolution (LTE), an OFDMA-based wireless technology, is not more widely deployed or further commercial deployment is delayed; |

[0001728949-20-000011:mdna:132]
| • | government regulators delay making sufficient spectrum available for 4G and 5G wireless technologies, including unlicensed spectrum and shared spectrum technologies, thereby delaying or precluding the initial deployment or expanded deployment of these technologies; |

[0001728949-20-000011:mdna:133]
| • | wireless operators delay or do not drive improvements in 4G or 5G, or 3G/4G or 3G/4G/5G multimode network performance and capacity; |

[0001728949-20-000011:mdna:134]
| • | our customers’ and licensees’ revenues and sales of products, particularly premium-tier products, and services using these technologies, and average selling prices of such products, decline, do not grow or do not grow meaningfully due to, for example, the maturity of smartphone penetration in developed regions and China; |

[0001728949-20-000011:mdna:135]
| • | our intellectual property and technical leadership included in the continued 5G standardization effort is different than in 3G and 4G standards; |

[0001728949-20-000011:mdna:136]
| • | the continued standardization or commercial deployment of 5G technologies is delayed; |

[0001728949-20-000011:mdna:137]
[same as prior period, unchanged from 0001728949-19-000055:mdna:233]

[0001728949-20-000011:mdna:138]
| • | consumers’ rates of replacement of smartphones and other computing devices decline, do not grow or do not grow meaningfully. |

[0001728949-20-000011:mdna:139]
Our industry is subject to competition in an environment of rapid technological change. Our success depends in part on our ability to adapt to such change and compete effectively; and such change and competition could result in decreased demand for our products, services and technologies or declining average selling prices for our products or those of our customers or licensees.

[0001728949-20-000011:mdna:140]
Our products, services and technologies face significant competition. We expect competition to increase as our current competitors expand their product offerings or reduce the prices of their products as part of a strategy to maintain existing business and customers or attract new business and customers, as new opportunities develop, and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: OEM concentrations; vertical integration; growth in demand, consumption and competition in certain geographic regions; government intervention or support of national industries or competitors; evolving industry standards and business models; evolving methods of transmission of voice and data communications; increasing data traffic and densification of wireless networks; convergence and aggregation of connectivity technologies (including Wi-Fi and LTE) in both devices and access points; consolidation of wireless technologies and infrastructure at the network edge; networking and connectivity trends (including cloud services); use of licensed, shared and unlicensed spectrum; the evolving nature of computing (including demand for always on, always connected capabilities); the speed of technological change (including the transition to smaller geometry process technologies); value-added features that drive selling prices and consumer demand for new 3G/4G and 3G/4G/5G multimode devices, as well as 3G, 4G and 5G single-mode devices; turnkey, integrated products that incorporate hardware, software, user interface, applications and reference designs; scalability; and the ability of the system technology to meet customers’ immediate and future network requirements. We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, technological and public policy changes and relatively low barriers to entry in certain segments of the industry. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape.

[0001728949-20-000011:mdna:141]
[same as prior period, unchanged from 0001728949-19-000055:mdna:237]

[0001728949-20-000011:mdna:142]
| • | differentiate our integrated circuit products with innovative technologies across multiple products and features (e.g., modem, Radio Frequency front-end (RFFE), graphics and other processors, camera and connectivity) and with smaller geometry process technologies that drive both performance and lower power consumption; |

[0001728949-20-000011:mdna:143]
| • | develop and offer integrated circuit products at competitive cost and price points to effectively cover all geographic regions and all device tiers; |

[0001728949-20-000011:mdna:144]
| • | drive the adoption of our integrated circuit products into the most popular device models and across a broad spectrum of devices, such as smartphones, tablets, laptops and other computing devices, automobiles, wearables, voice and music and other connected devices and infrastructure products; |

[0001728949-20-000011:mdna:145]
28

[0001728949-20-000011:mdna:146]
| • | maintain or accelerate demand for our integrated circuit products at the premium device tier, while also driving the adoption of our 5G products into high, mid- and low-tier devices across all regions; |

[0001728949-20-000011:mdna:147]
| • | continue to be a leader in 4G and 5G technology evolution and continue to innovate and introduce 4G and 5G turnkey, integrated products and services that differentiate us from our competition; |

[0001728949-20-000011:mdna:148]
| • | remain a leader in 5G technology development, standardization, intellectual property creation and licensing, and develop, commercialize and be a leading supplier of 5G integrated circuit products and services; |

[0001728949-20-000011:mdna:149]
| • | increase or accelerate demand for our semiconductor component products, including RFFE, and our wireless connectivity products, including networking products for consumers, carriers and enterprise equipment and connected devices; |

[0001728949-20-000011:mdna:150]
| • | become a leading supplier of RFFE products, which are designed to address cellular RF band fragmentation while improving RF performance and assist OEMs in developing multiband, multimode mobile devices; |

[0001728949-20-000011:mdna:151]
| • | create standalone value and contribute to the success of our existing businesses through acquisitions, joint ventures and other transactions, and by developing customer, licensee, vendor, distributor and other channel relationships in new industry segments and with disruptive technologies, products and services, such as products for automotive, computing, IoT (including the connected home, smart cities, wearables, voice and music and robotics) and networking, among others; |

[0001728949-20-000011:mdna:152]
| • | identify potential acquisition targets that will grow or sustain our business or address strategic needs, reach agreement on terms acceptable to us, close the transactions and effectively integrate these new businesses, products and technologies; |

[0001728949-20-000011:mdna:153]
| • | be a leader serving OEMs, high level operating systems (HLOS) providers, operators, cloud providers and other industry participants as competitors, new industry entrants and other factors continue to affect the industry landscape; |

[0001728949-20-000011:mdna:154]
| • | be a preferred partner and sustain preferred relationships providing integrated circuit products that support multiple operating system and infrastructure platforms to industry participants that effectively commercialize new devices using these platforms; and |

[0001728949-20-000011:mdna:155]
| • | continue to develop brand recognition to effectively compete against better known companies in computing and other consumer driven segments and to deepen our presence in significant emerging regions and China. |

[0001728949-20-000011:mdna:156]
We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application, industry segment or standard product, including those that produce products for RFFE, automotive, computing, IoT and networking applications. Most of these competitors compete with us with respect to some, but not all, of our businesses. Companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom, Cirrus Logic, Cypress Semiconductor, HiSilicon, Intel, Marvell, Maxim, MediaTek, Microchip Technology, Murata, Nordic Semiconductor, Nvidia, NXP Semiconductors, Qorvo, Realtek Semiconductor, Renesas, Samsung, Sequans Communications, Skyworks and Spreadtrum Communications (which is controlled by Tsinghua Unigroup). Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to use our competitors’ integrated circuit products, to utilize their own internally-developed integrated circuit products or sell such products to others, or to choose alternative technologies; lower cost structures or a willingness and ability to accept lower prices or lower or negative margins for their products, particularly in China; foreign government support of other technologies, competitors or OEMs that sell devices that do not contain our chipsets; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and OEMs in certain geographic regions (such as China); more experience in adjacent industry segments outside traditional cellular industries (such as automotive, computing, IoT and networking); and a more established presence in certain regions.

[0001728949-20-000011:mdna:157]
In particular, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past utilized, and currently utilize, in certain of their devices and may in the future choose to utilize in certain (or all) of their devices, rather than our products (and they may sell their integrated circuit products to third parties, discretely or together with certain of their other products, in competition with us). Also, Apple, which has historically been one of our largest customers, has utilized products of one of our competitors in many of its devices rather than our products, and is solely utilizing one of our competitors’ products in its most recent smartphone launches. In April 2019, we entered into a new multi-year chipset supply agreement with Apple. We do not expect to begin recording revenues under this agreement until the second half of fiscal 2020. However, Apple may choose to use our competitors’ products or its own modem products in one or more of its future devices.

[0001728949-20-000011:mdna:158]
Further, certain of our competitors develop and sell multiple components (including integrated circuit products) for use in devices and sell those components together to OEMs. Our competitors’ sales of multiple components put us (and our discrete integrated circuit products) at a competitive disadvantage. Certain of our competitors also develop and sell infrastructure equipment for wireless networks and can optimize their integrated circuit products to perform on such networks to a degree that we are not able to, which again puts us at a competitive disadvantage.

[0001728949-20-000011:mdna:159]
Competition in any or all product tiers may result in the loss of business or customers, which would negatively impact our revenues, results of operations and cash flows. Such competition may also reduce average selling prices for our chipset products or the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging regions and China where competitors may have lower cost structures or may have a willingness and ability to accept lower prices or lower or negative margins on their products. Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0001728949-20-000011:mdna:160]
We derive a significant portion of our revenues from a small number of customers and licensees, which increasingly includes a small number of Chinese OEMs. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected.

[0001728949-20-000011:mdna:161]
Our QCT segment derives a significant portion of its revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. Chinese OEMs continue to grow their device share in China and are increasing their device share in regions outside of China, and we derive a significant and increasing portion of our revenues from a small number of these OEMs. In addition, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past utilized, and currently utilize, in certain of their devices and may in the future choose to utilize in certain (or all) of their devices, rather than our products (and they may sell their integrated circuit products to third parties, discretely or together with certain of their other products, in competition with us). Also, Apple, which has historically been one of our largest customers, has utilized products of one of our competitors in many of its devices rather than our products, and is solely utilizing one of our competitor’s products in its most recent smartphone launches. In April 2019, we entered into a new multi-year chipset supply agreement with Apple. We do not expect to begin recording revenues under this agreement until the second half of fiscal 2020. However, Apple may choose to use our competitors’ products or its own modem products in one or more of its future devices.

[0001728949-20-000011:mdna:162]
Similarly, certain of our Chinese OEM customers have developed and others may in the future develop their own integrated circuit products and use such integrated circuit products, or other integrated circuit products, in their devices rather than our integrated circuit products, whether due to pressure from the Chinese government as part of its broader economic policies, the OEMs’ concerns over losing access to our integrated circuit products as a result of U.S./Chinese trade tensions, or otherwise.

[0001728949-20-000011:mdna:163]
Further, political actions, including trade and/or national security protection policies, or other actions by governments, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our customers, or limit or prevent certain of our customers from transacting business with us.

[0001728949-20-000011:mdna:164]
Finally, we spend a significant amount of engineering and development time, funds and resources in understanding our key customers’ feedback and/or specifications and attempt to incorporate such input into our product launches and technologies. These efforts may not require or result in purchase commitments from such customers or we may have lower purchases from such customers than expected, and consequently, we may not achieve the anticipated revenues from these efforts, or these efforts may result in non-recoverable costs.

[0001728949-20-000011:mdna:165]
The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or the cancelation of significant purchases by any of these customers, whether due to the use of their own integrated circuit products or our competitors’ integrated circuit products, government restrictions or otherwise, would reduce our revenues and could harm our ability to achieve or sustain expected results of operations, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development. Further, the concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have no control, and the timing

[0001728949-20-000011:mdna:166]
and success of such introductions may cause our revenues and results of operations to fluctuate. Accordingly, if current industry dynamics continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases, and the timing and size of any such future purchases, by these significant customers.

[0001728949-20-000011:mdna:167]
Further, to the extent Apple purchases our modem products, it purchases our MDM products, which do not include our integrated application processor technology, and which have lower revenue and margin contributions than our combined modem and application processor products. To the extent Apple takes device share from our customers who purchase our integrated modem and application processor products, our revenues and margins may be negatively impacted.

[0001728949-20-000011:mdna:168]
Further, companies that develop HLOS for devices, including leading technology companies, sell their own devices. If we fail to effectively partner or continue partnering with these companies, or with their partners or customers, they may decide not to purchase (either directly or through their contract manufacturers), or to reduce or discontinue their purchases of, our integrated circuit products.

[0001728949-20-000011:mdna:169]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products or intellectual property, and rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001728949-20-000011:mdna:170]
Although we have more than 300 licensees, our QTL segment derives a significant portion of its revenues from a limited number of licensees, which increasingly includes a small number of Chinese OEMs. In the event that one or more of our significant licensees fail to meet their reporting and payment obligations, or we are unable to renew or modify one or more of such license agreements under similar terms, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in sales of our licensees’ products, or reductions in the average selling prices of wireless devices sold by our licensees without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues. Such adverse impact may be mitigated by the per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets, laptops and smartwatches.

[0001728949-20-000011:mdna:171]
We derive a significant portion of our revenues from the premium-tier device segment. If sales of premium-tier devices decrease, or sales of our premium-tier integrated circuit products decrease, our results of operations could be negatively affected.

[0001728949-20-000011:mdna:172]
We derive a significant portion of our revenues from the premium-tier device segment, and we expect this trend to continue in the foreseeable future. The industry has experienced, and we expect it will continue to experience, slowing growth in the premium-tier device segment due to, among other factors, lengthening replacement cycles in developed regions, where premium-tier smartphones are common; increasing consumer demand in emerging regions and China where premium-tier smartphones are less common and replacement cycles are on average longer than in developed regions and are continuing to lengthen; and a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and innovation cycles.

[0001728949-20-000011:mdna:173]
In addition, as discussed in the prior risk factor, our industry is experiencing concentration of device share at the premium tier among a few companies, which gives them significant leverage. Further, certain of those companies have in the past utilized, currently utilize and may in the future utilize their own internally-developed integrated circuit products or our competitors’ integrated circuit products rather than our products in all or a portion of their devices. These dynamics may result in reduced sales of or lower prices for our premium-tier integrated circuit products.

[0001728949-20-000011:mdna:174]
A reduction in sales of premium-tier devices, a reduction in sales of our premium-tier integrated circuit products (which have a higher revenue and margin contribution than our lower-tier integrated circuit products) or a shift in share away from OEMs that utilize our products, would reduce our revenues and margins and may harm our ability to achieve or sustain expected financial results. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0001728949-20-000011:mdna:175]
Efforts by some OEMs or their customers to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.

[0001728949-20-000011:mdna:176]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging

[0001728949-20-000011:mdna:177]
[same as prior period, unchanged from 0001728949-19-000055:mdna:22]

[0001728949-20-000011:mdna:178]
infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) various attempts by licensees to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated.

[0001728949-20-000011:mdna:179]
In addition, certain licensees have disputed, underreported, underpaid, not reported or not paid royalties owed to us under their license agreements or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or have delayed entering into or renewing license agreements with us for their use of our intellectual property. Further, certain licensees and companies are currently engaged in such behavior and they or others may engage in such behavior in the future. The fact that one or more licensees dispute, underreport, underpay, do not report or do not pay royalties owed to us may encourage other licensees to take similar actions or not renew their existing license agreements, and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Further, to the extent such licensees and companies increase their device share, the negative impact of their underreporting, underpayment, non-payment or non-reporting on our business, revenues, results of operations, financial condition and cash flows will be exacerbated.

[0001728949-20-000011:mdna:180]
We have been in the past and are currently subject to various litigation and governmental investigations and proceedings, including the lawsuit filed against us by the FTC. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See the Risk Factors below entitled “Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings” and “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations.”

[0001728949-20-000011:mdna:181]
In addition, in connection with our participation in SDOs, we, like other patent owners, generally have made contractual commitments to such organizations to license those of our patents that would necessarily be infringed by standard-compliant products as set forth in those commitments. Some manufacturers and users of standard-compliant products advance interpretations of these commitments that are adverse to our licensing business, including interpretations that would limit the amount of royalties that we could collect on the licensing of our standard-essential patent portfolio.

[0001728949-20-000011:mdna:182]
Further, some companies or entities have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions should not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by severely limiting the base upon which the royalty rate may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies. Some SDOs, courts and governmental agencies have adopted and may in the future adopt some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001728949-20-000011:mdna:183]
We expect that such proposals, interpretations and strategies will continue in the future, and if successful, our business model would be harmed, either by limiting or eliminating our ability to collect royalties (or by reducing the royalties we can collect) on all or a portion of our standard-essential patent portfolio, limiting our return on investment with respect to new technologies, limiting our ability to seek injunctions against infringers of our standard-essential patents, constraining our ability to make licensing commitments when submitting our technology for inclusion in future standards (which could make

[0001728949-20-000011:mdna:184]
32

[0001728949-20-000011:mdna:185]
our technology less likely to be included in such standards) or forcing us to work outside of SDOs or other industry groups to promote our new technologies, and our revenues, results of operations and cash flows could be negatively impacted. In addition, the legal and other costs associated with asserting or defending our positions have been and continue to be significant. We assume that such challenges, regardless of their merits, will continue into the foreseeable future and will require the investment of substantial management time and financial resources.

[0001728949-20-000011:mdna:186]
[same as prior period, unchanged from 0001728949-19-000055:mdna:280]

[0001728949-20-000011:mdna:187]
We have been in the past and are currently subject to various governmental investigations and proceedings, particularly with respect to our licensing business, including the lawsuit filed against us by the FTC. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Key allegations or findings in those matters include, among others, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high, that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions), that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets, that we have entered into exclusive agreements with chipset customers that foreclose competition, and that we violate antitrust laws, engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-20-000011:mdna:188]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any licensing or royalty revenues under such agreements. The renegotiation of license agreements could lead to arbitration or litigation to resolve the licensing terms (which could be less favorable to us than existing terms), each of which could take months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. Further, if our appeal in the FTC lawsuit is unsuccessful, it could have a material adverse effect on our business. Any such event could result in a materially negative impact on our financial condition, in which case we would have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies such as 5G. Further, depending on the breadth and severity of the circumstances above, we may have to reduce or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted. If these events occur, our financial outlook and stock price could decline, possibly significantly. Further, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region.

[0001728949-20-000011:mdna:189]
These challenges have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs until the respective matters are resolved.

[0001728949-20-000011:mdna:190]
Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations.

[0001728949-20-000011:mdna:191]
As described in the Risk Factor above entitled “Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings,” we have been in the past and are currently subject to various governmental investigations and proceedings, as well as private legal proceedings, challenging our patent licensing and chipset sales practices, including the lawsuit filed against us by the FTC. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We believe that one intent of these investigations and legal proceedings is to reduce the amount of royalties that licensees are

[0001728949-20-000011:mdna:192]
required to pay to us for their use of our intellectual property. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-20-000011:mdna:193]
We historically licensed our cellular standard-essential patents together with our other patents that may be useful to licensed products because licensees desired to obtain the commercial benefits of receiving such broad patent rights from us. However, we also licensed only our cellular standard-essential patents to licensees who requested such licenses. Since 2015, our standard practice in China is to offer licenses to our 3G and 4G (and now 5G) cellular standard-essential Chinese patents for devices sold for use in China separately from our other patents. In addition, we also offer licenses to only our cellular standard-essential patents (including 3G, 4G and 5G) for both single-mode and multimode devices on a worldwide basis, and since 2018, an increasing number of new and existing licensees have elected to enter into worldwide license agreements covering only our cellular standard-essential patents. Going forward, we anticipate that a significant portion of our licensing revenues will continue to be derived from licensees that have entered into license agreements covering only our cellular standard-essential patents. Our royalty rates for licenses to only our cellular standard-essential patents are lower than our royalty rates for licenses to substantially all of our patent portfolio. If more licensees choose a license to only our cellular standard-essential patents instead of a portfolio license than has historically been the case, our licensing revenues and earnings would be negatively impacted unless we were able to license our other patents at rates that offset all or a portion of any difference between the royalties previously received for licenses of substantially all of our patent portfolio as compared to licenses of only our cellular standard-essential patents or there was a sufficient increase in the overall volume of sales of devices upon which royalties are paid.

[0001728949-20-000011:mdna:194]
If we were required to grant patent licenses to chipset manufacturers (which could lead to implementing a more complex, multi-level licensing structure in which we license certain portions of our patent portfolio to chipset manufacturers and other portions to OEMs), we would incur additional transaction costs, which may be significant, and we could incur delays in recognizing revenues until license negotiations were completed. In addition, our licensing revenues and earnings would be negatively impacted if we were not able to obtain, in the aggregate, equivalent revenues under such a multi-level licensing structure.

[0001728949-20-000011:mdna:195]
[same as prior period, unchanged from 0001728949-19-000055:mdna:287]

[0001728949-20-000011:mdna:196]
If we were required to sell chipsets to OEMs that do not have a license to our patents, our licensing program could be negatively impacted by patent exhaustion claims raised by such unlicensed OEMs (i.e., claims that our sale of chipsets to such OEMs forecloses us from asserting any patents substantially embodied by the chipsets against such OEMs). Such sales would provide OEMs with a defense in the event we asserted our patents against them to obtain licensing revenue for those patents. This would have a material adverse effect on our licensing program and our results of operations, financial condition and cash flows.

[0001728949-20-000011:mdna:197]
To the extent that we were required to implement any of these new licensing and/or business practices, including by modifying or renegotiating our existing license agreements or pursuing other commercial arrangements, we would incur additional transaction costs, which may be significant, and we could incur delays in recognizing revenues until license negotiations were completed. The impact of any such changes to our licensing practices could vary widely and by jurisdiction, depending on the specific outcomes and the geographic scope of such outcomes. In addition, if we were required to make modifications to our licensing practices in one jurisdiction, licensees or governmental agencies in other jurisdictions may attempt to obtain similar outcomes for themselves or for such other jurisdictions, as applicable.

[0001728949-20-000011:mdna:198]
Finally, if our appeal in the FTC lawsuit is unsuccessful, it could have a material adverse effect on our business.

[0001728949-20-000011:mdna:199]
[same as prior period, unchanged from 0001728949-19-000055:mdna:291]

[0001728949-20-000011:mdna:200]
[same as prior period, unchanged from 0001728949-19-000055:mdna:292]

[0001728949-20-000011:mdna:201]
the future will prevent, the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as U.S. laws or where the enforcement of such laws may be lacking or ineffective. See the Risk Factor entitled “Our business and operations could suffer in the event of security breaches of our information technology systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0001728949-20-000011:mdna:202]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that the European Union (EU) will adopt a unitary patent system in the next few years that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-20-000011:mdna:203]
We have had, currently have, and may in the future have, difficulty in certain circumstances in protecting or enforcing our intellectual property rights and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies of foreign governments; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business and the pricing and integration of additional features and functionality into our chipset products. Certain licensees have disputed, underreported, underpaid, not reported or not paid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or have delayed entering into or renewing license agreements for their use of our intellectual property. Further, certain licensees and companies are currently engaged in such behavior and they or others may engage in such behavior in the future. The fact that one or more licensees dispute, underreport, underpay, do not report or do not pay royalties owed to us may encourage other licensees to take similar actions or not renew their existing license agreements, and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements. Similarly, we provide access to certain of our intellectual property and proprietary and confidential business information to our direct and indirect customers and licensees, who have in the past and may in the future wrongfully use such intellectual property and information or wrongfully disclose such intellectual property and information to third parties, including our competitors.

[0001728949-20-000011:mdna:204]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0001728949-20-000011:mdna:205]
Our growth increasingly depends on our ability to extend our technologies, products and services into new and expanded product areas, such as RFFE, and adjacent industry segments and applications outside of traditional cellular industries, such as automotive, computing, IoT and networking, among others. Our research, development and other investments in these new and expanded product areas, industry segments and applications, and related technologies, products and

[0001728949-20-000011:mdna:206]
[same as prior period, unchanged from 0001728949-19-000055:mdna:89]

[0001728949-20-000011:mdna:207]
services, as well as in our existing technologies, products and services and new technologies, such as 5G, may not generate operating income or contribute to future results of operations that meet our expectations.

[0001728949-20-000011:mdna:208]
Our industry is subject to rapid technological change, evolving industry standards and frequent new product introductions, and we must make substantial research, development and other investments, such as acquisitions, in new products, services and technologies to compete successfully. Technological innovations generally require significant research and development efforts before they are commercially viable. While we continue to invest significant resources toward advancements primarily in support of 4G- and 5G-based technologies, we also invest in new and expanded product areas, and adjacent industry segments and applications, by utilizing our existing technical and business expertise and through acquisitions.

[0001728949-20-000011:mdna:209]
In particular, our future growth significantly depends on new and expanded product areas, such as RFFE, and adjacent industry segments and applications outside of traditional cellular industries, such as automotive, computing, IoT (including the connected home, smart cities, wearables, voice and music and robotics) and networking, among others; our ability to develop leading and cost-effective technologies, products and services for new and expanded product areas, adjacent industry segments and applications; and third parties incorporating our technologies, products and services into devices used in these product areas, industry segments and applications. Accordingly, we intend to continue to make substantial investments in these new and expanded product areas and adjacent industry segments and applications, and in developing new products, services and technologies for these product areas, industry segments and applications.

[0001728949-20-000011:mdna:210]
Our growth also depends significantly on our ability to develop and patent 5G technologies, and to develop and commercialize products using 5G technologies.

[0001728949-20-000011:mdna:211]
However, our research, development and other investments in these new and expanded product areas and adjacent industry segments and applications, and corresponding technologies, products and services, as well as in our existing, technologies, products and services and new technologies, such as 5G, use of licensed, shared and unlicensed spectrum and convergence of cellular and Wi-Fi, may not succeed due to, among other reasons: we may not be issued patents on the technologies we develop; the technologies we develop may not be incorporated into relevant standards; new and expanded product areas and adjacent industry segments, applications and consumer demand may not develop or grow as anticipated; our strategies or the strategies of our customers, licensees or partners may not be successful; improvements in alternate technologies in ways that reduce the advantages we anticipate from our investments; competitors’ technologies, products or services being more cost effective, having more capabilities or fewer limitations or being brought to market faster than our new technologies, products and services; we may not be able to develop, or our competitors may have more established and/or stronger, customer, vendor, distributor or other channel relationships; and competitors having longer operating histories in industry segments that are new to us. We may also underestimate the costs of or overestimate the future revenues or margins that could result from these investments, and these investments may not, or may take many years to, generate material returns.

[0001728949-20-000011:mdna:212]
Further, the automotive industry is subject to long design-in time frames, long product life cycles and a high degree of regulatory and safety requirements, necessitating suppliers to the industry to comply with stringent qualification processes, very low defect rates and high reliability standards, all of which results in a significant barrier to entry and increased costs.

[0001728949-20-000011:mdna:213]
If our new technologies, products and services are not successful, or are not successful in the time frames we anticipate, we may incur significant costs and asset impairments, our business may not grow or grow meaningfully, our revenues and margins may be negatively impacted, and our reputation may be harmed.

[0001728949-20-000011:mdna:214]
The continued and future success of our licensing programs requires us to continue to evolve our patent portfolio, and our licensing programs may be impacted by the proliferation of devices in new industry segments such as automotive, computing, IoT and networking, as well as the need to renew or renegotiate license agreements that are expiring or to cover additional future patents.

[0001728949-20-000011:mdna:215]
We own a very strong portfolio of issued and pending patents related to 3G, 4G, 5G and other technologies. It is critical that we continue to evolve our patent portfolio, particularly in 5G. If we do not maintain a strong portfolio that is applicable to current and future standards, products and services, our future licensing revenues could be negatively impacted.

[0001728949-20-000011:mdna:216]
In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the automotive, computing, IoT and networking industry segments. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties at all or that are equivalent to those that we receive for products used in cellular communications. Although we believe that our patented technologies are essential and useful to the

[0001728949-20-000011:mdna:217]
commercialization of such services, any royalties we receive may be lower than those we receive from our current licensing program.

[0001728949-20-000011:mdna:218]
Further, the licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, all of our patent license agreements in China that were entered into in 2015 or thereafter, as well as our recent worldwide cellular standard-essential patent only agreements, are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of the specified term, and to receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. In particular, our license agreement with Huawei expired on December 31, 2019, and our license agreements with two key Chinese licensees were extended and now expire on March 31, 2020. Such agreements provide either party with the right to initiate binding arbitration for a period of several months, the result of which will be a new license agreement. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001728949-20-000011:mdna:219]
We depend on a limited number of third-party suppliers for the procurement, manufacture and testing of our products manufactured in a fabless production model. If we fail to execute supply strategies that provide technology leadership, supply assurance and reasonable margins, our business and results of operations may be harmed. We are also subject to order and shipment uncertainties that could negatively impact our results of operations.

[0001728949-20-000011:mdna:220]
Our QCT segment primarily utilizes a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Other than the facilities we own that manufacture certain of our RFFE modules and RF filter acoustic products, we rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Under the turnkey model, our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services such as wafer bump, probe, assembly and the majority of our final test requirements. The semiconductor manufacturing foundries that supply products to our QCT segment are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders.

[0001728949-20-000011:mdna:221]
The following could have an adverse effect on our ability to meet customer demand and negatively impact our revenues, business operations, profitability and cash flows:

[0001728949-20-000011:mdna:222]
[same as prior period, unchanged from 0001728949-19-000055:mdna:317]

[0001728949-20-000011:mdna:223]
| • | a failure by our suppliers to procure raw materials, or to provide or allocate adequate raw materials or manufacturing or test capacity, for our products; |

[0001728949-20-000011:mdna:224]
[same as prior period, unchanged from 0001728949-19-000055:mdna:319]

[0001728949-20-000011:mdna:225]
[same as prior period, unchanged from 0001728949-19-000055:mdna:320]

[0001728949-20-000011:mdna:226]
[same as prior period, unchanged from 0001728949-19-000055:mdna:321]

[0001728949-20-000011:mdna:227]
| • | additional expense or production delays as a result of qualifying a new supplier and commencing volume production or testing in the event of a loss of, or a decision to add or change, a supplier; |

[0001728949-20-000011:mdna:228]
| • | natural disasters or geopolitical conflicts impacting our suppliers; and |

[0001728949-20-000011:mdna:229]
| • | an outbreak of a virus in Asia, such as the recent coronavirus outbreak that originated in China, affecting the production capabilities of our suppliers, including as a result of quarantines or closure. |

[0001728949-20-000011:mdna:230]
[same as prior period, unchanged from 0001728949-19-000055:mdna:324]

[0001728949-20-000011:mdna:231]
37

[0001728949-20-000011:mdna:232]
[same as prior period, unchanged from 0001728949-19-000055:mdna:325]

[0001728949-20-000011:mdna:233]
Although we have long-term contracts with our suppliers, most of these contracts do not provide for long-term capacity commitments. To the extent we do not have firm commitments from our suppliers over a specific time period or for any specific quantity, our suppliers may allocate, and in the past have allocated, capacity to the production and testing of products for their other customers while reducing or limiting capacity to manufacture or test our products. Accordingly, capacity for our products may not be available when we need it or at reasonable prices. To the extent we do obtain long-term capacity commitments, we may incur additional costs related to those commitments or make non-refundable payments for capacity commitments that are not used.

[0001728949-20-000011:mdna:234]
Our suppliers or potential alternate suppliers may manufacture CDMA- or OFDMA-based integrated circuits, for themselves or for other companies, that compete with our products. Such suppliers have in the past and could again elect to allocate raw materials and manufacturing capacity to their own products or products of our competitors and reduce or limit deliveries to us to our detriment.

[0001728949-20-000011:mdna:235]
In addition, we may not receive reasonable pricing, manufacturing or delivery terms from our suppliers. We cannot guarantee that the actions of our suppliers will not cause disruptions in our operations that could harm our ability to meet our delivery obligations to our customers or increase our cost of sales. To the extent we are unable to obtain adequate supply, we may be obligated to make payment to our customers for such shortfalls.

[0001728949-20-000011:mdna:236]
Additionally, we place orders with our suppliers using our and our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates. As we move to smaller geometry process technologies, the manufacturing lead-time increases. As a result, the orders we place with our suppliers are generally only partially covered by commitments from our customers. If we, or our customers, overestimate demand that is not under a binding commitment from our customers, we may experience increased excess or obsolete inventory, which would negatively impact our results of operations.

[0001728949-20-000011:mdna:237]
There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model, environmental compliance and liability, issues related to climate change, exposure to natural disasters, timely supply of equipment and materials, and various manufacturing issues.

[0001728949-20-000011:mdna:238]
While our QCT segment has historically utilized a fabless production model, we now also own and operate various facilities that manufacture our RFFE modules and RF filter acoustic products. Manufacturing facilities are characterized by a higher portion of fixed costs relative to a fabless model. We may be faced with a decline in the utilization rates of our manufacturing facilities due to decreases in demand for our products, including in less favorable industry environments. During such periods, our manufacturing facilities could operate at lower capacity levels, while the fixed costs associated with such facilities continue to be incurred, resulting in lower gross profit.

[0001728949-20-000011:mdna:239]
We are subject to many environmental, health and safety laws and regulations in each jurisdiction in which we operate our manufacturing facilities, which govern, among other things, emissions of pollutants into the air; wastewater discharges; the use, storage, generation, handling and disposal of hazardous substances and other waste; the investigation and remediation of soil and ground water contamination; and the health and safety of our employees. Certain environmental laws impose strict, and in certain circumstances joint and several, liability on current or previous owners or operators of real property, or parties who arranged for hazardous substances to be sent to disposal or treatment facilities, for the cost of investigation, removal or remediation of hazardous substances. As a result, we may incur clean-up costs in connection with any such removal or remediation efforts, as well as other third-party claims in connection with contaminated sites. In addition, we could be held liable for consequences arising out of human exposure to hazardous substances or other

[0001728949-20-000011:mdna:240]
environmental damage. If we or companies we acquire have in the past failed or in the future fail to comply with any such laws and regulations, then we could incur liabilities, fines or prohibitions on the sale of products we manufacture, and our operations could be suspended. Such laws and regulations could also restrict our ability to modify or expand our facilities, could require us to acquire costly equipment, or could require other significant expenditures. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. While we have designed policies and procedures to ensure compliance with applicable laws, regulations and permits, we cannot make assurances that we, or our employees, contractors or agents, will at all times be in compliance with such laws, regulations and permits, or our related policies and procedures.

[0001728949-20-000011:mdna:241]
Climate change concerns and the potential resulting environmental impact may result in new environmental, health and safety laws and regulations that may affect us, our suppliers and/or our customers. Such laws or regulations could cause us to incur additional direct costs for compliance, as well as increased indirect costs resulting from our customers, suppliers or both incurring additional compliance costs that are passed on to us. These costs may adversely impact our operations and financial condition. In addition, climate change may pose physical risks to us or our suppliers, including increased extreme weather events that could result in supply delays or disruptions.

[0001728949-20-000011:mdna:242]
We have manufacturing facilities in Asia and Europe. If tsunamis, flooding, earthquakes, volcanic eruptions or other natural disasters, or geopolitical conflicts, were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, delay new production and shipments of inventory and result in costly repairs, replacements or other costs. In addition, natural disasters or geopolitical conflicts may result in disruptions in transportation, distribution channels and supply chains, and significant increases in the prices of raw materials. Further, an outbreak of a virus in Asia, such as the recent coronavirus outbreak that originated in China, could affect the production capabilities of our manufacturing facilities, including by resulting in quarantines and/or closures, which would result in disruptions to and potentially closures of our manufacturing operations.

[0001728949-20-000011:mdna:243]
Our manufacturing operations depend on securing raw materials and other supplies in adequate quality and quantity in a timely manner from multiple suppliers, and in some cases, we rely on a limited number of suppliers, particularly in Asia. Accordingly, there may be cases where supplies of raw materials and other products are interrupted by disaster, accident or some other event at a supplier, supply is suspended due to quality or other issues, or there is a shortage of supply due to a rapid increase in demand, among others, which could impact production and prevent us from supplying products to our customers. If the supply-demand balance is disrupted, it may considerably increase costs of manufacturing due to increased prices we pay for raw materials. From time to time, suppliers may extend lead times, limit the amounts supplied to us or increase prices due to capacity constraints or other factors. Additionally, supply and costs of raw materials may be negatively impacted by trade and/or national security protection policies, such as tariffs, or actions by governments that limit or prevent us from transacting business with certain companies or that limit or prevent certain companies from transacting business with us, or escalating trade tensions, particularly with countries in Asia. Further, it may be difficult or impossible to substitute one piece of equipment for another or replace one type of material with another. A failure by our suppliers to deliver our requirements could result in disruptions to our manufacturing operations.

[0001728949-20-000011:mdna:244]
[same as prior period, unchanged from 0001728949-19-000055:mdna:310]

[0001728949-20-000011:mdna:245]
Finally, we typically begin manufacturing our products using our or our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates and are generally not covered by purchase commitments. As a result, we incur inventory and manufacturing costs in advance of anticipated sales, which sales ultimately may not materialize or may be lower than expected. If we or our customers overestimate demand that is not under a binding commitment from our customers, we may experience higher inventory carrying and operating costs and/or increased excess or obsolete inventory, which would negatively impact our results of operations.

[0001728949-20-000011:mdna:246]
[same as prior period, unchanged from 0001728949-19-000055:mdna:332]

[0001728949-20-000011:mdna:247]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe another company’s intellectual property rights, we could be subject to an injunction or be

[0001728949-20-000011:mdna:248]
required to redesign our products or services, or to license such rights or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling such products or providing such services. Similarly, our suppliers could be found to infringe another company’s intellectual property rights, and such suppliers could then be enjoined from providing products or services to us.

[0001728949-20-000011:mdna:249]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products or services sold or provided by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-20-000011:mdna:250]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset or licensing revenues.

[0001728949-20-000011:mdna:251]
Certain legal matters, which may include certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0001728949-20-000011:mdna:252]
We may engage in strategic acquisitions and other transactions or make investments, or be unable to consummate planned strategic acquisitions, which could adversely affect our results of operations or fail to enhance stockholder value.

[0001728949-20-000011:mdna:253]
We engage in strategic acquisitions and other transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. From time to time, we acquire businesses and other assets, including patents, technology and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies, including those that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our products and technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications and new industry segments. Many of our strategic activities entail a high degree of risk and require the use of significant amounts of capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies, products or services. We may underestimate the costs or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our financial condition and results of operations, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001728949-20-000011:mdna:254]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such

[0001728949-20-000011:mdna:255]
integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, technology, products, processes, operations (including manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development and supply operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models (including manufacturing), geographic regions, industry segments or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0001728949-20-000011:mdna:256]
[same as prior period, unchanged from 0001728949-19-000055:mdna:341]

[0001728949-20-000011:mdna:257]
Many of our acquisitions and other strategic investments require approval by the United States and/or foreign government agencies. Certain agencies in the past have, and may in the future, deny the transaction or fail to approve in a timely manner, resulting in us not realizing the anticipated benefits of the transaction. Future acquisitions or other strategic investments may be more difficult, complex or expensive to the extent that our reputation for our ability to consummate acquisitions has been harmed. Further, if U.S./China trade relations remain strained, our ability to consummate any transaction that would require approval from the State Administration for Market Regulation (SAMR) in China may be severely impacted.

[0001728949-20-000011:mdna:258]
We are subject to various laws, regulations, policies and standards. Our business may suffer as a result of existing, new or amended laws, regulations, policies or standards, or our failure or inability to comply with laws, regulations, policies or standards.

[0001728949-20-000011:mdna:259]
Our business, products and services, and those of our customers and licensees, are subject to various laws and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies. Compliance with existing laws, regulations, policies and standards, the adoption of new laws, regulations, policies or standards, changes in the interpretation of existing laws, regulations, policies or standards, changes in the regulation of our activities by a government or standards body or rulings in court, regulatory, administrative or other proceedings relating to such laws, regulations, policies or standards, including, among others, those affecting licensing practices, competitive business practices, the use of our technology or products, protection of intellectual property, trade and trade protection including tariffs, cybersecurity, foreign currency, investments or loans, spectrum availability and license issuance, adoption of standards, the provision of device subsidies by wireless operators to their customers, taxation, export control, privacy and data protection, environmental protection, health and safety, labor and employment, human rights, corporate governance, public disclosure or business conduct, could have an adverse effect on our business and results of operations.

[0001728949-20-000011:mdna:260]
Government policies, particularly in China, that regulate the amount and timing of funds that may flow out of a country have impacted and may continue to impact the timing of our receipt of and/or ability to receive payments from our customers and licensees in such countries, which may negatively impact our cash flows.

[0001728949-20-000011:mdna:261]
Further, China has implemented, and other countries or regions may implement, cybersecurity laws that require that our overall information technology security environment meet certain standards and/or be certified. Such laws may be complex, ambiguous and subject to interpretation, which may create uncertainty regarding compliance. As a result, our efforts to comply with such laws may be expensive and may fail, which could adversely affect our business, results of operations and cash flows.

[0001728949-20-000011:mdna:262]
Delays in government approvals or other governmental activities that could result from, among others, a decrease in or a lack of funding for certain agencies or branches of the government, trade or national security protection policies, or political changes, could result in our incurring higher costs, could negatively impact our ability to timely consummate strategic transactions and could have other negative impacts on our business and the businesses of our customers and licensees.

[0001728949-20-000011:mdna:263]
[same as prior period, unchanged from 0001728949-19-000055:mdna:348]

[0001728949-20-000011:mdna:264]
National, state and local environmental laws and regulations affect our operations around the world. These laws may make it more expensive to manufacture and sell products, and our costs could increase if our vendors (e.g., suppliers, third-party manufacturers or utility companies) pass on their costs to us. The imposition of tariffs on raw materials or our products could also have a negative impact on our revenues and results of operations. We are also subject to laws and regulations impacting our manufacturing operations. See the Risk Factor entitled “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model, environmental compliance and liability, issues related to climate change, exposure to natural disasters, timely supply of equipment and materials, and various manufacturing issues.”

[0001728949-20-000011:mdna:265]
[same as prior period, unchanged from 0001728949-19-000055:mdna:350]

[0001728949-20-000011:mdna:266]
[same as prior period, unchanged from 0001728949-19-000055:mdna:351]

[0001728949-20-000011:mdna:267]
[same as prior period, unchanged from 0001728949-19-000055:mdna:352]

[0001728949-20-000011:mdna:268]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe we will continue to see, an increase in customers requesting that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of a product’s source code and may expose related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of the open source software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Furthermore, in the course of product development, we may make contributions to third party open source projects that could obligate our intellectual property to adverse licensing conditions. For example, to encourage the growth of a software ecosystem that is interoperable with our products, we may need to contribute certain implementations under the open source licensing terms that govern such projects, which may adversely impact certain of our associated intellectual property. Developing open source products, while adequately protecting the intellectual property rights upon which our licensing business depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property rights. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ adequate controls to protect our intellectual property rights, our contributions to and use of open source software presents risks that could have an adverse effect on these rights and on our business.

[0001728949-20-000011:mdna:269]
We operate in the highly cyclical semiconductor industry, which is subject to significant downturns that may adversely impact our business. Our stock price, earnings and the fair value of our investments are subject to substantial quarterly and annual fluctuations due to this dynamic and others, and to market downturns generally.

[0001728949-20-000011:mdna:270]
The semiconductor industry is highly cyclical and characterized by constant and rapid technological change, price erosion, evolving technical standards, frequent new product introductions, short product life cycles (for both semiconductors and for many of the products in which they are used) and fluctuations in product supply and demand. From time to time,

[0001728949-20-000011:mdna:271]
these factors, together with changes in general economic conditions, cause significant upturns and downturns in the semiconductor industry. Periods of downturns have been characterized by diminished demand for end-user products, high inventory levels, periods of inventory adjustment, underutilization of manufacturing capacity, changes in revenue mix and erosion of average selling prices. We expect our business to continue to be subject to cyclical downturns, even when overall economic conditions are relatively stable. If we cannot offset semiconductor industry or market downturns, our revenues may decline, and our financial condition and results of operations may be adversely impacted.

[0001728949-20-000011:mdna:272]
Our stock price and earnings have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and earnings include those identified above and throughout this Risk Factors section; volatility of the stock market in general and technology-based and semiconductor companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. Further, increased volatility in the financial markets and overall economic conditions may reduce the amounts that we realize in the future on our cash equivalents and marketable securities and may reduce our earnings as a result of any reductions in the fair values of marketable securities.

[0001728949-20-000011:mdna:273]
In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0001728949-20-000011:mdna:274]
[same as prior period, unchanged from 0001728949-19-000055:mdna:358]

[0001728949-20-000011:mdna:275]
[same as prior period, unchanged from 0001728949-19-000055:mdna:359]

[0001728949-20-000011:mdna:276]
[same as prior period, unchanged from 0001728949-19-000055:mdna:360]

[0001728949-20-000011:mdna:277]
| • | limiting our ability to obtain additional financing for working capital, capital expenditures, acquisitions, stock repurchases, dividends or general corporate or other purposes; |

[0001728949-20-000011:mdna:278]
| • | limiting our flexibility in planning for, or reacting to, changes in our business, our industry and the market; and |

[0001728949-20-000011:mdna:279]
[same as prior period, unchanged from 0001728949-19-000055:mdna:363]

[0001728949-20-000011:mdna:280]
Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to economic and political conditions, industry cycles and financial, business and other factors, including factors which negatively impact our cash flows, such as licensees withholding some or all of the royalty payments they owe to us or our paying fines or modifying our business practices in connection with regulatory investigations or litigation, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations in the future to service our debt, we may be required to, among other things: refinance or restructure all or a portion of our indebtedness; reduce or delay planned capital or operating expenditures; reduce or eliminate our dividend payments; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing or restructuring are higher than our current rates, interest expense related to such refinancing or restructuring would increase. If there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt in the future and the terms of such debt could be adversely affected.

[0001728949-20-000011:mdna:281]
Our current outstanding variable rate indebtedness uses LIBOR as a benchmark for establishing the interest rate. LIBOR is the subject of recent national, international and other regulatory guidance and proposals for reform. These reforms may cause LIBOR to disappear entirely after 2021 or to perform differently than in the past. We expect that reasonable alternatives to LIBOR will be created and implemented prior to the 2021 target date. Fallback provisions are being written into LIBOR-based contracts to attempt to reduce the risk of sudden and unpredictable increases in the cost of variable rate indebtedness. However, we cannot predict the consequences and timing of these developments.

[0001728949-20-000011:mdna:282]
We have implemented a stock repurchase program to repurchase up to $30 billion of our outstanding common stock. This stock repurchase program has significantly reduced and is expected to continue to reduce the amount of cash that we have available to fund our operations, including research and development, working capital, capital expenditures, acquisitions, investments, dividends and other corporate purposes; and increases our exposure to adverse economic, market, industry and competitive conditions and developments, and other changes in our business and our industry. In addition, this significant decrease in our cash reserves exacerbates the risks described above associated with our indebtedness.

[0001728949-20-000011:mdna:283]
Our business and operations could suffer in the event of security breaches of our information technology systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.

[0001728949-20-000011:mdna:284]
Third parties regularly attempt to gain unauthorized access to our information technology systems, and most of such attempts are increasingly more sophisticated. These attempts, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, and impersonating authorized users, among others. In addition, third party suppliers that we may rely on to store and/or process our confidential information may also be subject to similar attacks. Such attempts could result in the misappropriation, theft, misuse, disclosure or loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our information technology systems. These threats are constantly evolving, thereby increasing the difficulty of successfully defending against them or implementing adequate preventative measures. We seek to detect and investigate all security incidents and to prevent their recurrence, but attempts to gain unauthorized access to our information technology systems may be successful, and in some cases, we might be unaware of an incident or its magnitude and effects.

[0001728949-20-000011:mdna:285]
In addition, employees and former employees, in particular former employees who become employees of our competitors, customers, licensees or other third parties, including state actors, have in the past and may in the future misappropriate, use, publish or provide to our competitors, customers, licensees or other third parties, including state actors, our technology, intellectual property or other proprietary or confidential information. This risk is exacerbated as competitors for talent, particularly engineering talent, increasingly attempt to hire our employees. See the Risk Factor entitled “We may not be able to attract and retain qualified employees.” Similarly, we provide access to certain of our technology, intellectual property and other proprietary or confidential information to our direct and indirect customers and licensees and certain of our consultants, who have in the past and may in the future wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. We also provide access to certain of our technology, intellectual property and other proprietary or confidential information to certain of our joint venture partners, including those affiliated with state actors and including in foreign jurisdictions where ownership restrictions may require us to take a minority ownership interest in the joint venture. Such joint venture partners may wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors.

[0001728949-20-000011:mdna:286]
The misappropriation, theft, misuse, disclosure or loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, could harm our competitive position, reduce the value of our investment in research and development and other strategic initiatives, cause us to lose business, damage our reputation, subject us to legal or regulatory proceedings, cause us to incur other loss or liability and otherwise adversely affect our business. We expect to continue to devote significant resources to the security of our information technology systems, and our technology, intellectual property and proprietary and confidential information.

[0001728949-20-000011:mdna:287]
[same as prior period, unchanged from 0001728949-19-000055:mdna:372]

[0001728949-20-000011:mdna:288]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed. Our current examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts giving rise to a revision become known. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-20-000011:mdna:289]
The United States Treasury Department has issued proposed regulations on several provisions of the Tax Legislation, including FDII and interest expense deduction limitations, which are expected to be finalized in the next several months. When finalized, these proposed regulations may adversely affect our provision for income taxes, results of operations and/or cash flows.

[0001728949-20-000011:mdna:290]
We have tax incentives in Singapore provided that we meet specified employment and other criteria, and as a result of the expiration of these incentives, our Singapore tax rate is expected to increase in fiscal 2022 and again in fiscal 2027. If we

[0001728949-20-000011:mdna:291]
do not meet the criteria required to retain such incentives, our historical and future Singapore tax rate could increase prior to fiscal 2022 and/or fiscal 2027, and our results of operations and cash flows could be adversely affected.

[0001728949-20-000011:mdna:292]
Tax rules may change in a manner that adversely affects our future reported results of operations or the way we conduct our business. Further changes in the tax laws of foreign jurisdictions could arise as a result of the base erosion and profit shifting (BEPS) project that was undertaken by the Organization for Economic Co-operation and Development (OECD). The OECD, which represents a coalition of member countries, recommended changes to numerous long-standing tax principles related to transfer pricing. These changes, as adopted by countries, may increase tax uncertainty and may adversely affect our provision for income taxes, results of operations and cash flows. Partially to address BEPS, we moved certain intellectual property from Singapore to the United States. As a result, if tax rates were to increase in the United States, our results of operations, cash flows and financial condition could be adversely affected.

[0001728949-20-000011:mdna:293]
[same as prior period, unchanged from 0001728949-19-000055:mdna:377]

[0001728949-20-000011:mdna:294]
A decline in global, regional or local economic conditions, a slow-down in economic growth, political actions including trade and/or national security protection policies, such as tariffs, or actions by governments that limit or prevent us from transacting business with certain companies or that limit or prevent certain companies from transacting business with us, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could have adverse, wide-ranging effects on demand for our products and services and for the products and services of our customers or licensees, particularly equipment manufacturers or others in the wireless communications industry who buy their products, such as wireless operators. Similarly, an outbreak of a virus in Asia, such as the recent coronavirus outbreak that originated in China, could negatively affect the production capabilities of our manufacturing facilities and/or the manufacturing facilities of our customers, licensees and/or suppliers, including by resulting in quarantines and/or closures. Any such prolonged economic downturn, “trade war” or outbreak may result in a decrease in demand for our products and technologies; a decrease in demand for the products and services of our customers or licensees; the inability of our suppliers to deliver on their supply commitments to us, our inability to supply our products to our customers and/or the inability of our customers or licensees to supply their products to end users; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our licensees or customers; failures by counterparties; and/or negative effects on wireless device inventories. In addition, our customers’ ability to purchase or pay for our products and services and network operators’ ability to upgrade their wireless networks could be adversely affected by economic conditions, leading to a reduction, cancelation or delay of orders for our products and services.

[0001728949-20-000011:mdna:295]
[same as prior period, unchanged from 0001728949-19-000055:mdna:380]

[0001728949-20-000011:mdna:296]
Our future success depends largely upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. The market for employees in our industry is extremely competitive, and competitors for talent, particularly engineering talent, increasingly attempt to hire, and to varying degrees have been successful in hiring, our employees, including by establishing local offices near our headquarters in San Diego, California. A number of such competitors for talent are significantly larger than us and are able to offer compensation in excess of what we are able to offer. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001728949-20-000011:mdna:297]
[same as prior period, unchanged from 0001728949-19-000055:mdna:382]

[0001728949-20-000011:mdna:298]
[same as prior period, unchanged from 0001728949-19-000055:mdna:383]

[0001728949-20-000011:mdna:299]
[same as prior period, unchanged from 0001728949-19-000055:mdna:384]

[0001728949-20-000011:mdna:300]
[same as prior period, unchanged from 0001728949-19-000055:mdna:385]

[0001728949-20-000011:mdna:301]
[same as prior period, unchanged from 0001728949-19-000055:mdna:386]

[0001728949-20-000011:mdna:302]
| • | Our foreign suppliers may raise their prices if they are impacted by currency fluctuations, resulting in higher than expected costs, and lower margins and cash flows; |

[0001728949-20-000011:mdna:303]
[same as prior period, unchanged from 0001728949-19-000055:mdna:388]

[0001728949-20-000011:mdna:304]
[same as prior period, unchanged from 0001728949-19-000055:mdna:389]

[0001728949-20-000011:mdna:305]
Failures in our products, or in the products of our customers or licensees, including those resulting from security vulnerabilities, defects or errors, could harm our business.

[0001728949-20-000011:mdna:306]
Our products (including related software) are complex and may contain defects, errors or security vulnerabilities, or experience failures or unsatisfactory performance, due to any number of issues, including in materials, design, fabrication, packaging and/or use within a system. Further, because of the complexity of our products, defects or errors might only be detected when the products are in use. Development of products in new domains of technology, and the migration to integrated circuit technologies with smaller geometric feature sizes, is complex, adds risk to manufacturing yields and reliability, and increases the likelihood of product defects or errors. Risks associated with product defects, errors or security vulnerabilities are exacerbated by the fact that our customers typically integrate our products into consumer devices.

[0001728949-20-000011:mdna:307]
The use of devices containing our products to interact with untrusted systems or otherwise access untrusted content creates a risk of exposing the system hardware and software in those devices to malicious attacks. Security vulnerabilities in our products could expose our customers or end users to hackers or other unscrupulous third parties who develop and deploy viruses, worms and other malicious software programs that could attack our products or those of our customers. While we continue to focus on this issue and are taking measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and applications, and increasing the risk of security failures.

[0001728949-20-000011:mdna:308]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and to the end users of such devices. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products, repairing or replacing defective products, writing down defective inventory, or indemnification clauses in our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, losses on unfavorable purchase commitments, and a decrease in demand for connected devices and wireless services generally. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products generally and our premium-tier products in particular.

[0001728949-20-000011:mdna:309]
In addition, the occurrence of defects may give rise to product liability claims, particularly if defects in our products or the products into which they are integrated result in personal injury or death. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the efforts of our technical and management personnel and harm our business. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. Further, our business liability insurance may be inadequate, or future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as automobiles, including autonomous driver assistance programs; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and extended reality (XR) for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0001728949-20-000011:mdna:310]
[same as prior period, unchanged from 0001728949-19-000055:mdna:254]

[0001728949-20-000011:mdna:311]
Accordingly, defects, errors or security vulnerabilities in our products or services could have an adverse impact on us, on our customers and the end users of our customers’ products. If any of these risks materialize, there could be a material adverse effect on our business, financial condition and results of operations.
