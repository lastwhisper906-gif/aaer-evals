# QCOM 8-K — 0001728949-21-000021 filed 2021-02-03

## item codes, every 8-K on or before 2021-02-03

- 2021-02-03 0001728949-21-000021 — 2.02, 9.01
- 2021-01-13 0001728949-21-000009 — 1.01, 9.01
- 2021-01-08 0001728949-21-000004 — 5.02
- 2020-12-10 0001104659-20-134200 — 1.01, 1.02, 2.03, 9.01
- 2020-11-19 0001728949-20-000070 — 5.02
- 2020-11-04 0001728949-20-000066 — 2.02, 9.01
- 2020-08-18 0001104659-20-096322 — 1.01, 8.01, 9.01
- 2020-08-05 0001104659-20-090597 — 8.01, 9.01
- 2020-07-29 0001728949-20-000056 — 2.02, 9.01
- 2020-07-24 0001728949-20-000047 — 5.02
- 2020-05-11 0001104659-20-058923 — 1.01, 8.01, 9.01
- 2020-05-04 0001728949-20-000037 — 5.02
- 2020-04-29 0001728949-20-000030 — 2.02, 9.01
- 2020-03-13 0001728949-20-000015 — 5.07
- 2020-02-05 0001728949-20-000010 — 2.02, 9.01
- 2019-11-06 0001728949-19-000074 — 5.02
- 2019-11-06 0001728949-19-000071 — 2.02, 9.01
- 2019-08-28 0001728949-19-000058 — 5.02
- 2019-07-31 0001728949-19-000053 — 2.02, 9.01
- 2019-05-10 0001728949-19-000044 — 5.02
- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2021-02-03

- none on or before 2021-02-03

## item 2.02 — earnings release, exhibit 99.1

[0001728949-21-000021:8k_2_02:1]
EX-99.1
2
qcom122720erex991.htm
EX-99.1

[0001728949-21-000021:8k_2_02:2]
Document

[0001728949-21-000021:8k_2_02:3]
Exhibit 99.1

[0001728949-21-000021:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001728949-21-000021:8k_2_02:5]
Qualcomm Contact:

[0001728949-21-000021:8k_2_02:6]
Mauricio Lopez-Hodoyan

[0001728949-21-000021:8k_2_02:7]
Vice President, Investor Relations

[0001728949-21-000021:8k_2_02:8]
Phone: 1-858-658-4813 | e-mail: ir@qualcomm.com

[0001728949-21-000021:8k_2_02:9]
Qualcomm Announces First Quarter Fiscal 2021 Results

[0001728949-21-000021:8k_2_02:10]
GAAP: Revenues $8.2 billion; EPS $2.12

[0001728949-21-000021:8k_2_02:11]
Non-GAAP: Revenues $8.2 billion; EPS $2.17

[0001728949-21-000021:8k_2_02:12]
—Record Quarterly QCT Revenues and Earnings—

[0001728949-21-000021:8k_2_02:13]
SAN DIEGO - February 3, 2021 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal first quarter ended December 27, 2020.

[0001728949-21-000021:8k_2_02:14]
“We delivered an exceptional quarter, more than doubling earnings year-over-year due to strong 5G demand in handsets and growth in our RF front-end, automotive and IoT adjacencies, which drove record earnings in our chip business,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “We remain well positioned as the 5G ramp continues and we extend our core technology roadmap to adjacent industries.”

[0001728949-21-000021:8k_2_02:15]
First Quarter Results 1

[0001728949-21-000021:8k_2_02:16]
|  | GAAP |  | Non-GAAP |  |
| (in millions, except per share dataand percentages) | Q1 Fiscal 2021 |  | Q1 Fiscal 2020 |  | Change |  | Q1 Fiscal 2021 |  | Q1 Fiscal 2020 |  |  |  |  | Change |  |
| Revenues | $8,235 |  | $5,077 |  | +62% |  | $8,226 |  | $5,057 |  |  |  |  | +63% |  |
| Earnings before taxes (EBT) | $2,604 |  | $947 |  | +175% |  | $2,912 |  | $1,334 |  |  |  |  | +118% |  |
| Net income | $2,455 |  | $925 |  | +165% |  | $2,510 |  | $1,151 |  |  |  |  | +118% |  |
| Diluted earnings per share (EPS) | $2.12 |  | $0.80 |  | +165% |  | $2.17 |  | $0.99 |  |  |  |  | +119% |  |

[0001728949-21-000021:8k_2_02:17]
(1)  Discussion regarding our use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results are included at the end of this news release.

[0001728949-21-000021:8k_2_02:18]
Segment Results

[0001728949-21-000021:8k_2_02:19]
|  | QCT |  | QTL |
| (in millions, except percentages) | Q1 Fiscal 2021 |  | Q1 Fiscal 2020 |  | Change |  | Q1 Fiscal 2021 |  | Q1 Fiscal 2020 |  | Change |  |  |  |
| Revenues | $6,533 |  | $3,618 |  | +81% |  | $1,660 |  | $1,404 |  | +18% |  |  |  |
| EBT | $1,919 |  | $479 |  | N/M |  | $1,270 |  | $1,017 |  | +25% |  |  |  |
| EBT as % of revenues | 29% |  | 13% |  | +16 points |  | 77% |  | 72% |  | +5 points |  |  |  |

[0001728949-21-000021:8k_2_02:20]
N/M: Not meaningful

[0001728949-21-000021:8k_2_02:21]
| Qualcomm Announces First Quarter Fiscal 2021 Results | Page 2 of 8 |

[0001728949-21-000021:8k_2_02:22]
QCT Revenue Streams

[0001728949-21-000021:8k_2_02:23]
We disaggregate QCT revenues based on industry segment or application in which our products are sold (as presented below).

[0001728949-21-000021:8k_2_02:24]
| (in millions, except percentages) |  |  |  |  |  |  | Q1 Fiscal 2021 |  | Q1 Fiscal 2020 |  | Change |  |  |  |
| Handsets |  |  |  |  |  |  | $4,216 |  | $2,352 |  | +79% |  |  |  |
| RF front-end |  |  |  |  |  |  | 1,061 |  | 413 |  | +157% |  |  |  |
| Automotive |  |  |  |  |  |  | 212 |  | 147 |  | +44% |  |  |  |
| IoT |  |  |  |  |  |  | 1,044 |  | 706 |  | +48% |  |  |  |
| Total QCT revenues |  |  |  |  |  |  | $6,533 |  | $3,618 |  | +81% |  |  |  |

[0001728949-21-000021:8k_2_02:25]
Return of Capital to Stockholders

[0001728949-21-000021:8k_2_02:26]
During the first quarter of fiscal 2021, we returned $1.2 billion to stockholders, including $739 million, or $0.65 per share, of cash dividends paid and $444 million through repurchases of 3 million shares of common stock.

[0001728949-21-000021:8k_2_02:27]
Business Outlook

[0001728949-21-000021:8k_2_02:28]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.

[0001728949-21-000021:8k_2_02:29]
|  |  |  | Current Guidance Q2 FY21 Estimates1 |  |
|  | Revenues |  | $7.2B - $8.0B |  |
|  | Supplemental Revenue Information |  |  |  |
|  | QCT revenues |  | $6.0B - $6.5B |  |
|  | QTL revenues |  | $1.25B - $1.45B |  |
|  | GAAP diluted EPS |  | $1.17 - $1.37 |  |
|  | Less diluted EPS attributable to QSI |  | $— |  |  |
|  | Less diluted EPS attributable to share-based compensation |  | ($0.30) |  |  |
|  | Less diluted EPS attributable to other items2 |  | ($0.08) |  |  |
|  | Non-GAAP diluted EPS |  | $1.55 - $1.75 |  |

[0001728949-21-000021:8k_2_02:30]
(1)  Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as certain investments, derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain.  Our outlook includes the impact of any pending business combinations to the extent they are expected to close in the upcoming quarter.  Actual results may differ materially from the outlook.

[0001728949-21-000021:8k_2_02:31]
(2)  Our guidance for diluted EPS attributable to other items for the second quarter of fiscal 2021 is primarily attributable to acquisition-related items and an estimated tax expense that is unrelated to the fiscal year in which it is expected to be recorded.

[0001728949-21-000021:8k_2_02:32]
| Qualcomm Announces First Quarter Fiscal 2021 Results | Page 3 of 8 |

[0001728949-21-000021:8k_2_02:33]
Conference Call

[0001728949-21-000021:8k_2_02:34]
Qualcomm’s first quarter fiscal 2021 earnings conference call will be broadcast live on February 3, 2021, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to our financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at http://investor.qualcomm.com/ immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415.  Callers should use reservation number 13714808.

[0001728949-21-000021:8k_2_02:35]
About Qualcomm

[0001728949-21-000021:8k_2_02:36]
Qualcomm is the world’s leading wireless technology innovator and the driving force behind the development, launch and expansion of 5G.  When we connected the phone to the internet, the mobile revolution was born.  Today, our foundational technologies enable the mobile ecosystem and are found in every 3G, 4G and 5G smartphone.  We bring the benefits of mobile to new industries, including automotive, the internet of things and computing, and are leading the way to a world where everything and everyone can communicate and interact seamlessly.

[0001728949-21-000021:8k_2_02:37]
Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of our engineering, research and development functions and substantially all of our products and services businesses, including our QCT semiconductor business.

[0001728949-21-000021:8k_2_02:38]
Note Regarding Forward-Looking Statements

[0001728949-21-000021:8k_2_02:39]
###

[0001728949-21-000021:8k_2_02:40]
Qualcomm is a trademark or registered trademark of Qualcomm Incorporated. Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-21-000021:8k_2_02:41]
| Qualcomm Announces First Quarter Fiscal 2021 Results | Page 4 of 8 |

[0001728949-21-000021:8k_2_02:42]
QUALCOMM Incorporated

[0001728949-21-000021:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001728949-21-000021:8k_2_02:44]
(In millions, except par value amounts)

[0001728949-21-000021:8k_2_02:45]
(Unaudited)

[0001728949-21-000021:8k_2_02:46]
|  | December 27,2020 |  | September 27,2020 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 7,076 |  |  | $ | 6,707 |  |
| Marketable securities | 5,222 |  |  | 4,507 |  |
| Accounts receivable, net | 4,148 |  |  | 4,003 |  |
| Inventories | 2,552 |  |  | 2,598 |  |
| Other current assets | 794 |  |  | 704 |  |
| Total current assets | 19,792 |  |  | 18,519 |  |
| Deferred tax assets | 1,319 |  |  | 1,351 |  |
| Property, plant and equipment, net | 4,033 |  |  | 3,711 |  |
| Goodwill | 6,358 |  |  | 6,323 |  |
| Other intangible assets, net | 1,541 |  |  | 1,653 |  |
| Other assets | 4,436 |  |  | 4,037 |  |
| Total assets | $ | 37,479 |  |  | $ | 35,594 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 2,429 |  |  | $ | 2,248 |  |
| Payroll and other benefits related liabilities | 1,149 |  |  | 1,053 |  |
| Unearned revenues | 540 |  |  | 568 |  |
| Short-term debt | 500 |  |  | 500 |  |
| Other current liabilities | 4,605 |  |  | 4,303 |  |
| Total current liabilities | 9,223 |  |  | 8,672 |  |
| Unearned revenues | 644 |  |  | 761 |  |
| Income taxes payable | 1,855 |  |  | 1,872 |  |
| Long-term debt | 15,231 |  |  | 15,226 |  |
| Other liabilities | 3,146 |  |  | 2,986 |  |
| Total liabilities | 30,099 |  |  | 29,517 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,136 and 1,131 shares issued and outstanding, respectively | 113 |  |  | 586 |  |
| Retained earnings | 6,974 |  |  | 5,284 |  |
| Accumulated other comprehensive income | 293 |  |  | 207 |  |
| Total stockholders’ equity | 7,380 |  |  | 6,077 |  |
| Total liabilities and stockholders’ equity | $ | 37,479 |  |  | $ | 35,594 |  |

[0001728949-21-000021:8k_2_02:47]
| Qualcomm Announces First Quarter Fiscal 2021 Results | Page 5 of 8 |

[0001728949-21-000021:8k_2_02:48]
QUALCOMM Incorporated

[0001728949-21-000021:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-21-000021:8k_2_02:50]
(In millions, except per share data)

[0001728949-21-000021:8k_2_02:51]
(Unaudited)

[0001728949-21-000021:8k_2_02:52]
|  |  | Three Months Ended |  |  |
|  |  |  |  |  |  | December 27,2020 |  | December 29,2019 |  |  |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services |  |  |  |  |  | $ | 6,442 |  |  | $ | 3,534 |  |  |  |  |  |
| Licensing |  |  |  |  |  | 1,793 |  |  | 1,543 |  |  |  |  |  |
| Total revenues |  |  |  |  |  | 8,235 |  |  | 5,077 |  |  |  |  |  |
| Costs and expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  |  |  |  | 3,489 |  |  | 2,113 |  |  |  |  |  |
| Research and development |  |  |  |  |  | 1,653 |  |  | 1,406 |  |  |  |  |  |
| Selling, general and administrative |  |  |  |  |  | 567 |  |  | 528 |  |  |  |  |  |
| Total costs and expenses |  |  |  |  |  | 5,709 |  |  | 4,047 |  |  |  |  |  |
| Operating income |  |  |  |  |  | 2,526 |  |  | 1,030 |  |  |  |  |  |
| Interest expense |  |  |  |  |  | (141) |  |  | (148) |  |  |  |  |  |
| Investment and other income, net |  |  |  |  |  | 219 |  |  | 65 |  |  |  |  |  |
| Income before income taxes |  |  |  |  |  | 2,604 |  |  | 947 |  |  |  |  |  |
| Income tax expense |  |  |  |  |  | (149) |  |  | (22) |  |  |  |  |  |
| Net income |  |  |  |  |  | $ | 2,455 |  |  | $ | 925 |  |  |  |  |  |
| Basic earnings per share |  |  |  |  |  | $ | 2.16 |  |  | $ | 0.81 |  |  |  |  |  |
| Diluted earnings per share |  |  |  |  |  | $ | 2.12 |  |  | $ | 0.80 |  |  |  |  |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  | 1,134 |  |  | 1,144 |  |  |  |  |  |
| Diluted |  |  |  |  |  | 1,156 |  |  | 1,159 |  |  |  |  |  |

[0001728949-21-000021:8k_2_02:53]
| Qualcomm Announces First Quarter Fiscal 2021 Results | Page 6 of 8 |

[0001728949-21-000021:8k_2_02:54]
QUALCOMM Incorporated

[0001728949-21-000021:8k_2_02:55]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-21-000021:8k_2_02:56]
(In millions)

[0001728949-21-000021:8k_2_02:57]
(Unaudited)

[0001728949-21-000021:8k_2_02:58]
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  |  |  |  |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 2,455 |  |  | $ | 925 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization expense | 364 |  |  | 351 |  |  |  |  |  |
| Income tax provision in excess of (less than) income tax payments | 53 |  |  | (131) |  |  |  |  |  |
| Share-based compensation expense | 392 |  |  | 294 |  |  |  |  |  |
| Net gains on marketable securities and other investments | (195) |  |  | (79) |  |  |  |  |  |
| Impairment losses on other investments | 1 |  |  | 72 |  |  |  |  |  |
| Other items, net | (19) |  |  | (26) |  |  |  |  |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (141) |  |  | (262) |  |  |  |  |  |
| Inventories | 62 |  |  | (17) |  |  |  |  |  |
| Other assets | (97) |  |  | (119) |  |  |  |  |  |
| Trade accounts payable | 129 |  |  | 396 |  |  |  |  |  |
| Payroll, benefits and other liabilities | 278 |  |  | (171) |  |  |  |  |  |
| Unearned revenues | (107) |  |  | (115) |  |  |  |  |  |
| Net cash provided by operating activities | 3,175 |  |  | 1,118 |  |  |  |  |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (469) |  |  | (296) |  |  |  |  |  |
| Purchases of debt and equity marketable securities | (2,248) |  |  | (10) |  |  |  |  |  |
| Proceeds from sales and maturities of debt and equity marketable securities | 1,612 |  |  | 129 |  |  |  |  |  |
| Acquisitions and other investments, net of cash acquired | (138) |  |  | (75) |  |  |  |  |  |
| Other items, net | 41 |  |  | 49 |  |  |  |  |  |
| Net cash used by investing activities | (1,202) |  |  | (203) |  |  |  |  |  |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 819 |  |  | 558 |  |  |  |  |  |
| Repayment of short-term debt | (818) |  |  | (558) |  |  |  |  |  |
| Repurchases and retirements of common stock | (444) |  |  | (762) |  |  |  |  |  |
| Dividends paid | (739) |  |  | (710) |  |  |  |  |  |
| Payments of tax withholdings related to vesting of share-based awards | (449) |  |  | (203) |  |  |  |  |  |
| Other items, net | (14) |  |  | 16 |  |  |  |  |  |
| Net cash used by financing activities | (1,645) |  |  | (1,659) |  |  |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents | 41 |  |  | 14 |  |  |  |  |  |
| Net increase (decrease) in total cash and cash equivalents | 369 |  |  | (730) |  |  |  |  |  |
| Total cash and cash equivalents at beginning of period | 6,707 |  |  | 11,839 |  |  |  |  |  |
| Total cash and cash equivalents at end of period | $ | 7,076 |  |  | $ | 11,109 |  |  |  |  |  |

[0001728949-21-000021:8k_2_02:59]
| Qualcomm Announces First Quarter Fiscal 2021 Results | Page 7 of 8 |

[0001728949-21-000021:8k_2_02:60]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-21-000021:8k_2_02:61]
The Non-GAAP financial measures presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, our Non-GAAP financial measures might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP financial measures are presented herein.

[0001728949-21-000021:8k_2_02:62]
We use Non-GAAP financial information: (i) to evaluate, assess and benchmark our operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of our ongoing core operating businesses, including our QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by us include revenues, cost of revenues, research and development (R&D) expenses, selling, general and administrative (SG&A) expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  We are able to assess what we believe is a more meaningful and comparable set of financial performance measures by using Non-GAAP information.  In addition, the HR and Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  We present Non-GAAP financial information to provide greater transparency to investors with respect to our use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0001728949-21-000021:8k_2_02:63]
Non-GAAP information excludes our QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-21-000021:8k_2_02:64]
•QSI is excluded because we expect to exit our strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed as unrelated to our operational performance.

[0001728949-21-000021:8k_2_02:65]
•Share-based compensation expense primarily relates to restricted stock units.  We believe that excluding non-cash share-based compensation from the Non-GAAP financial information allows us and investors to make additional comparisons of the operating activities of our ongoing core businesses over time and with respect to other companies.

[0001728949-21-000021:8k_2_02:66]
•Certain other items are excluded because we view such items as unrelated to the operating activities of our ongoing core businesses, as follows:

[0001728949-21-000021:8k_2_02:67]
◦Acquisition-related items include amortization of acquisition-related intangible assets, substantially all of which relate to the amortization of technology-based intangible assets that is recorded in cost of revenues and will recur in future periods until the related intangible assets have been fully amortized.  We view acquisition-related intangible assets as items arising from pre-acquisition activities determined at the time of an acquisition.  Acquisition-related intangible assets contribute to revenue generation that has not been excluded from our Non-GAAP financial information.  Acquisition-related items also include recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of acquisition-related items, as well as any effects from restructuring the ownership of such acquired assets.  Additionally, we exclude third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition.

[0001728949-21-000021:8k_2_02:68]
◦We exclude certain other items that we view as unrelated to our ongoing businesses, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters.  Beginning in the second quarter of fiscal 2020, we exclude gains and losses driven by the revaluation of our deferred compensation plan liabilities recognized in operating expenses and the offsetting gains and losses on the related plan assets recognized in investment and other income.  Amounts prior to the second quarter of fiscal 2020, which were not material, continue to be included in Non-GAAP results.

[0001728949-21-000021:8k_2_02:69]
◦Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of our ongoing Non-GAAP tax rate and after-tax earnings.

[0001728949-21-000021:8k_2_02:70]
| Qualcomm Announces First Quarter Fiscal 2021 Results | Page 8 of 8 |

[0001728949-21-000021:8k_2_02:71]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-21-000021:8k_2_02:72]
| (in millions, except per share data and percentages) |  |  |  | GAAP to Non-GAAP Reconciliation | Non-GAAP Supplemental Information |
|  |  |  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1 | Non-GAAP Results | QCT | QTL | Non-GAAP Reconciling Items2 |
| Q1 Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $8,235 |  | $9 |  | $— |  |  | $— |  |  | $8,226 |  | $6,533 |  | $1,660 |  | $33 |  |
| Operating income (loss) |  |  |  | 2,526 |  | 6 |  | (393) |  | (118) |  | 3,031 |  |  |  |  |  |  |  |
| EBT |  |  |  | 2,604 |  | 158 |  | (393) |  | (73) |  | 2,912 |  | 1,919 |  | 1,270 |  | (277) |  |
| EBT as % of revenues |  |  |  | 32 | % |  |  |  |  |  |  |  | 35 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 2,455 |  | 150 |  | (231) |  | 26 |  | 2,510 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $2.12 |  | $0.13 |  | ($0.20) |  | $0.02 |  | $2.17 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,156 |  | 1,156 |  | 1,156 |  | 1,156 |  | 1,156 |  |  |  |  |  |  |  |
| Q1 Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $5,077 |  | $20 |  | $— |  |  | $— |  |  | $5,057 |  | $3,618 |  | $1,404 |  | $35 |  |
| Operating income (loss) |  |  |  | 1,030 |  | 13 |  | (294) |  | (84) |  | 1,395 |  |  |  |  |  |  |  |
| EBT |  |  |  | 947 |  | (3) |  | (294) |  | (90) |  | 1,334 |  | 479 |  | 1,017 |  | (162) |  |
| EBT as % of revenues |  |  |  | 19 | % |  |  |  |  |  |  |  | 26 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 925 |  | (2) |  | (222) |  | (2) |  | 1,151 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $0.80 |  | $— |  | ($0.19) |  | $— |  | $0.99 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,159 |  | 1,159 |  | 1,159 |  | 1,159 |  | 1,159 |  |  |  |  |  |  |  |

[0001728949-21-000021:8k_2_02:73]
(1)  Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” section herein.  Details of amounts included in the “Other Items” column for the prior period are included in the news release for that period.

[0001728949-21-000021:8k_2_02:74]
(2)   Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations.  Non-GAAP reconciling items related to EBT consisted primarily of certain R&D expenses, SG&A expenses, other expenses or income, interest expense and certain investment income that are not allocated to segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit.

[0001728949-21-000021:8k_2_02:75]
Sums may not equal totals due to rounding.

[0001728949-21-000021:8k_2_02:76]
|  | Q1 Fiscal 2021 Supplemental Information and Reconciliations |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |
|  | Cost of revenues |  | $3,489 |  |  | $— |  |  | $11 |  |  | $62 |  |  | $3,416 |  |
|  | Research and development expenses |  | 1,653 |  |  | — |  |  |  | 283 |  |  | 18 |  |  | 1,352 |  |
|  | Selling, general and administrative expenses |  | 567 |  |  | 3 |  |  | 99 |  |  | 38 |  |  | 427 |  |
|  | Interest expense |  | 141 |  |  | — |  |  |  | — |  |  |  | 9 |  |  | 132 |  |
|  | Investment and other income, net |  | 219 |  |  | 152 |  |  | — |  |  |  | 54 |  |  | 13 |  |
|  | Income tax expense (benefit) |  | 149 |  |  | 8 |  |  | (162) |  |  | (99) |  |  | 402 |  |

[0001728949-21-000021:8k_2_02:77]
(1)  Other items excluded from Non-GAAP results included $64 million of acquisition-related charges, $9 million of interest expense related to the 2018 and 2019 European Commission fines and $3 million of charges related to restructuring-related activities, partially offset by a $3 million gain related to a favorable legal settlement.  Other items excluded from Non-GAAP results also included $54 million of losses driven by the revaluation of our deferred compensation plan liabilities, which increased operating expenses, offset by corresponding $54 million of gains driven by the revaluation of the associated plan assets, which were included within investment and other income, net.

[0001728949-21-000021:8k_2_02:78]
(2)   At fiscal year end, the quarterly tax provision for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP.  In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column.  Tax benefit in the “Other Items” column included $78 million of foreign currency gains related to a noncurrent receivable resulting from our refund claim of Korean withholding taxes paid in prior periods, a $19 million tax benefit from the effects of the new U.S. Treasury regulations on prior periods, a $7 million tax benefit for the tax effect of acquisition-related charges and a $1 million tax benefit from the combined effect of other items in EBT, partially offset by a $6 million charge to reconcile the tax provision of each column to the total GAAP tax provision for the quarter.
