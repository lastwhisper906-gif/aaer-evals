# QCOM note change history — 0001728949-20-000057 → 0001728949-21-000022


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-02-03):
[0001728949-21-000022:note_history:1]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

- changed (2021-02-03):
[0001728949-21-000022:note_history:2]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our then current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to
  (was, 2020-07-29, similarity 0.7721):
[0001728949-20-000057:note_history:2]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by

- added (2021-02-03):
[0001728949-21-000022:note_history:3]
disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On January 22, 2019, the court appointed the lead plaintiff in the action. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint, and on March 10, 2020, the court granted our motion. On May 11, 2020, the plaintiffs filed a second amended complaint, and on October 8, 2020, the court granted our motion to dismiss the case with prejudice. On November 7, 2020, the plaintiffs filed a notice of appeal. No hearing date has been set. We believe the plaintiffs’ claims are without merit.

- changed (2021-02-03):
[0001728949-21-000022:note_history:4]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. The Ninth Circuit has not yet ruled on our appeal. We believe the plaintiffs’ claims are without merit.
  (was, 2020-07-29, similarity 0.9867):
[0001728949-20-000057:note_history:4]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Currently, twenty-two such cases remained outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. The Ninth Circuit has not yet ruled on our appeal. We believe the plaintiffs’ claims are without merit.

- added (2021-02-03):
[0001728949-21-000022:note_history:5]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court) and Israel (in the Haifa District Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek unspecified damages. We believe the plaintiffs’ claims are without merit.

- added (2021-02-03):
[0001728949-21-000022:note_history:6]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, then captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision has subsequently reduced the number of patents asserted to four, granted covenants not to sue on the other patents and dismissed the Samsung and HTC entities from the case. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. Trial is expected to begin no earlier than June 2021. We have previously prevailed on infringement claims asserted by ParkerVision in related lawsuits and have successfully invalidated a number of their patent claims in patent office proceedings. We believe that ParkerVision’s claims are without merit.

- added (2021-02-03):
[0001728949-21-000022:note_history:7]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an

- changed (2021-02-03):
[0001728949-21-000022:note_history:8]
independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.
  (was, 2020-07-29, similarity 0.7688):
[0001728949-20-000057:note_history:8]
violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

- changed (2021-02-03):
[0001728949-21-000022:note_history:9]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019 and, on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC. We believe that our business practices do not violate the MRFTA.
  (was, 2020-07-29, similarity 0.9366):
[0001728949-20-000057:note_history:9]
We believe that our business practices do not violate the MRFTA. On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019 and, on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC.

- changed (2021-02-03):
[0001728949-21-000022:note_history:10]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of their investigation, but we believe it concerns our business practices in connection with our sale of radio frequency front-end (RFFE) components. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.
  (was, 2020-07-29, similarity 0.9663):
[0001728949-20-000057:note_history:10]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of their investigation, but we believe it concerns our business practices in connection with our sale of radio frequency front end (RFFE) components. We are responding to several Requests for Information. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

- changed (2021-02-03):
[0001728949-21-000022:note_history:11]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 27, 2020, the liability, including related foreign currency losses and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $301 million and included in other current liabilities.
  (was, 2020-07-29, similarity 0.9881):
[0001728949-20-000057:note_history:11]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At June 28, 2020, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $275 million and included in other current liabilities.

- changed (2021-02-03):
[0001728949-21-000022:note_history:12]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. A
  (was, 2020-07-29, similarity 0.9296):
[0001728949-20-000057:note_history:12]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the EU competition rules.

- added (2021-02-03):
[0001728949-21-000022:note_history:13]
hearing before the court is scheduled for May 4-6, 2021. We believe that our business practices do not violate the EU competition rules.

- changed (2021-02-03):
[0001728949-21-000022:note_history:14]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 27, 2020, the liability, including related foreign currency losses and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.3 billion and included in other current liabilities.
  (was, 2020-07-29, similarity 0.9881):
[0001728949-20-000057:note_history:14]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At June 28, 2020, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.2 billion and included in other current liabilities.

- changed (2021-02-03):
[0001728949-21-000022:note_history:15]
The court imposed the following injunctive relief: (1) we must not condition the supply of cellular modem chips on a customer’s patent license status, and we must negotiate or renegotiate license terms with customers in good faith under conditions free from the threat of lack of access to or discriminatory provision of cellular modem chip supply or associated technical support or access to software; (2) we must make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers on fair, reasonable and non-discriminatory (FRAND) terms and submit, as necessary, to arbitral or judicial dispute resolution to determine such terms; (3) we may not enter into express or de facto exclusive dealing
  (was, 2020-07-29, similarity 0.7825):
[0001728949-20-000057:note_history:15]
The court imposed the following injunctive relief: (1) we must not condition the supply of cellular modem chips on a customer’s patent license status, and we must negotiate or renegotiate license terms with customers in good faith under conditions free from the threat of lack of access to or discriminatory provision of cellular modem chip supply or associated technical support or access to software; (2) we must make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers on fair, reasonable and non-discriminatory (FRAND) terms and submit, as necessary, to arbitral or judicial dispute resolution to determine such terms; (3) we may not enter into express or de facto exclusive dealing agreements for the supply of cellular modem chips; and (4) we may not interfere with the ability of any customer to communicate with a government agency about a potential law enforcement or regulatory matter. The court also ordered us to submit to compliance and monitoring procedures for a period of seven years and to report to the FTC on an annual basis regarding our compliance with the above remedies.

- added (2021-02-03):
[0001728949-21-000022:note_history:16]
agreements for the supply of cellular modem chips; and (4) we may not interfere with the ability of any customer to communicate with a government agency about a potential law enforcement or regulatory matter. The court also ordered us to submit to compliance and monitoring procedures for a period of seven years and to report to the FTC on an annual basis regarding our compliance with the above remedies.

- changed (2021-02-03):
[0001728949-21-000022:note_history:17]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On August 23, 2019, the Ninth Circuit granted our Motion for Partial Stay. On February 13, 2020, the Ninth Circuit heard oral argument.
  (was, 2020-07-29, similarity 0.6033):
[0001728949-20-000057:note_history:17]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On August 23, 2019, the Ninth Circuit granted our Motion for Partial Stay. Thus, pending the resolution of the appeal in the Ninth Circuit or until further order of the Ninth Circuit, the portions of the court’s injunction requiring that we must (i) make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers and (ii) not condition the supply of cellular modem chips on a customer’s patent license status and must negotiate or renegotiate license terms with customers are stayed. On July 10, 2019, the Ninth Circuit granted our Motion to Expedite Appeal. On February 13, 2020, the Ninth Circuit heard oral argument, but has not yet ruled on our appeal.

- added (2021-02-03):
[0001728949-21-000022:note_history:18]
On August 11, 2020, the Ninth Circuit issued its opinion, which reversed the district court’s judgment, vacated its injunction and vacated its partial grant of summary judgment. The Ninth Circuit stated that the district court erred in holding that we are under an antitrust duty to license rival chip manufacturers and noted that our practice of licensing our standard-essential patents exclusively at the OEM level does not violate the antitrust laws. The Ninth Circuit also held that the district court’s “anticompetitive surcharge” theory failed to state a cogent theory of anticompetitive harm and that our patent-licensing royalties and “no license, no chips” policy do not impose an anticompetitive surcharge on rivals’ modem chip sales and do not undermine competition in either the CDMA or premium LTE chip markets. While agreeing with the district court that our 2011 and 2013 agreements with Apple were structured like exclusive dealing contracts, the Ninth Circuit nonetheless held that neither agreement had the actual or practical effect of substantially foreclosing competition in the CDMA modem chip market, and because Apple terminated these agreements years ago, the district court had improperly issued an injunction. The Ninth Circuit noted that neither the Sherman Act nor any other law prohibits companies like us from (1) licensing their standard-essential patents independently from their chip sales and collecting royalties, and/or (2) limiting their chip customer base to licensed OEMs. On September 25, 2020, the FTC filed a Petition for Rehearing En Banc. On October 28, 2020, the Ninth Circuit denied the FTC’s petition.

- added (2021-02-03):
[0001728949-21-000022:note_history:19]
Contingent losses and other considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at December 27, 2020 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- removed (2021-02-03):
[0001728949-20-000057:note_history:20]
making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss the complaint. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

- removed (2021-02-03):
[0001728949-20-000057:note_history:21]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On January 22, 2019, the court appointed the lead plaintiff in the action. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint, and on March 10, 2020, the court granted our motion. On May 11, 2020, the plaintiffs filed a second amended complaint, and on June 25, 2020, we filed a motion to dismiss that complaint. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

- removed (2021-02-03):
[0001728949-20-000057:note_history:22]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, eight consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the U.S. consumer class action complaints. The complaints seek unspecified damages. One of the complaints in the Supreme Court of British Columbia has since been discontinued by the plaintiffs. We have not yet answered the complaints. We expect the Ontario and British Columbia complaints will be consolidated into one proceeding in British Columbia with a class certification hearing no earlier than late 2020. Once the certification hearing is scheduled, we expect the court to set a timetable for the exchange of evidence and briefing. As to the complaint filed in Quebec, on April 15, 2019, the Quebec Superior Court held a class certification hearing, and on April 30, 2019, the court issued an order certifying a class. We are awaiting the court to set a timetable for pre-trial steps, including discovery, as well as the exchange of expert evidence. We do not expect the trial to occur before 2022. We believe the plaintiffs’ claims are without merit.

- removed (2021-02-03):
[0001728949-20-000057:note_history:23]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts

- removed (2021-02-03):
[0001728949-20-000057:note_history:24]
Contingent losses and other considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at June 28, 2020 for contingent losses associated with these matters based on our belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- removed (2021-02-03):
[0001728949-20-000057:note_history:25]
Indemnifications. We generally do not indemnify our customers, licensees and suppliers for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain agreements to defend and/or indemnify certain customers, licensees and suppliers against certain types of liability and/or damages arising from the infringement of third-party intellectual property rights. Our obligations under these agreements may be limited in terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us.

- removed (2021-02-03):
[0001728949-20-000057:note_history:26]
Claims and reimbursements under indemnification arrangements have not been material to our consolidated financial statements. At June 28, 2020, accruals for contingent liabilities associated with these indemnification arrangements were negligible. We have not recorded accruals for certain claims under indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- removed (2021-02-03):
[0001728949-20-000057:note_history:27]
Operating Leases. We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years. At June 28, 2020, other assets included $458 million of operating lease assets, with corresponding lease liabilities of $128 million recorded in other current liabilities and $374 million recorded in other liabilities.

- removed (2021-02-03):
[0001728949-20-000057:note_history:28]
Operating lease expense for the three and nine months ended June 28, 2020 was $45 million and $132 million, respectively, and $38 million and $110 million for the three and nine months ended June 30, 2019, respectively. Cash paid under our operating leases was $114 million for the nine months ended June 28, 2020. As of June 28, 2020, the weighted-average remaining lease term and weighted-average discount rate for operating leases were 6.0 years and 4%, respectively.

- removed (2021-02-03):
[0001728949-20-000057:note_history:29]
At June 28, 2020, future lease payments under our operating leases were as follows (in millions):

- removed (2021-02-03):
[0001728949-20-000057:note_history:30]
|  |  |  | June 28,2020 |
| Remainder of fiscal 2020 |  |  | $ | 38 |  |
| 2021 |  |  | 132 |  |
| 2022 |  |  | 112 |  |
| 2023 |  |  | 68 |  |
| 2024 |  |  | 49 |  |
| Thereafter |  |  | 178 |  |
| Total future lease payments |  |  | 577 |  |
| Imputed interest |  |  | (75) |  |
| Total lease liability balance |  |  | $ | 502 |  |

- removed (2021-02-03):
[0001728949-20-000057:note_history:31]
At September 29, 2019, future minimum lease payments under our noncancelable operating leases under ASC 840 were as follows (in millions):

- removed (2021-02-03):
[0001728949-20-000057:note_history:32]
|  |  |  | September 29,2019 |
| 2020 |  |  | $ | 138 |  |
| 2021 |  |  | 97 |  |
| 2022 |  |  | 66 |  |
| 2023 |  |  | 31 |  |
| 2024 |  |  | 18 |  |
| Thereafter |  |  | 35 |  |
| Total |  |  | $ | 385 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-02-03):
[0001728949-21-000022:note_history:33]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 27, 2020. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 27, 2020 and December 29, 2019 included 13 weeks.
  (was, 2020-07-29, similarity 0.954):
[0001728949-20-000057:note_history:33]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 29, 2019. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and nine months ended June 28, 2020 and June 30, 2019 included 13 weeks and 39 weeks, respectively.

- added (2021-02-03):
[0001728949-21-000022:note_history:34]
Financial Assets: In June 2016, the Financial Accounting Standards Board (FASB) issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) are estimated based on expected losses rather than the previous incurred loss impairment model. The new accounting guidance also eliminated the concept of other-than-temporary impairment with credit losses related to available-for-sale debt securities recorded through an allowance for credit losses rather than as a reduction in the amortized cost basis of the securities. We adopted the new accounting guidance in the first quarter of fiscal 2021 under the modified retrospective transition method, except for certain available-for-sale debt securities where the prospective transition method was required, and as a result, prior period results have not been restated. The impact upon adoption was not material to our condensed consolidated financial statements. The future impact of such accounting guidance will largely depend on the future composition and credit quality of our investment portfolio and accounts receivable, as well as future economic conditions.

- changed (2021-02-03):
[0001728949-21-000022:note_history:35]
Marketable Securities: As a result of the adoption of the new accounting guidance described above, we revised our  accounting policy beginning in fiscal 2021 as follows.
  (was, 2020-07-29, similarity 0.773):
[0001728949-20-000057:note_history:35]
Leases: As a result of the adoption of ASC 842, we revised our lease accounting policy beginning in fiscal 2020 as follows.

- added (2021-02-03):
[0001728949-21-000022:note_history:36]
Marketable securities include marketable equity securities, available-for-sale debt securities and, from time-to-time, certain time deposits. We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value with all realized and unrealized gains and losses on investments in marketable equity securities and realized gains and losses on available-for-sale debt securities recognized in investment and other income, net. Debt securities are classified as available for sale or held to maturity at the time of purchase and reevaluated at each balance sheet date. The realized and unrealized gains and losses on marketable securities are determined using the specific identification method.

- added (2021-02-03):
[0001728949-21-000022:note_history:37]
If a debt security has an unrealized loss and we either intend to sell the security or it is more likely than not that we will be required to sell the security before its anticipated recovery, we record an impairment charge to investment and other income, net for the entire amount of the unrealized loss and adjust the amortized cost basis of the security. For the remaining debt securities, if an unrealized loss exists, we separate the impairment into the portion of the loss related to credit factors and the portion of the loss that is not related to credit factors. Unrealized gains or unrealized losses that are not related to credit factors on available-for-sale debt securities are recorded as a component of accumulated other comprehensive income, net of income taxes. Unrealized losses that are related to credit loss factors on available-for-sale debt securities and subsequent adjustments to the credit loss are recorded as an allowance for credit losses, which is included in investment and other income, net. In evaluating whether a credit loss exists, we consider a variety of factors, including the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; the security’s relative performance versus its peers, sector or asset class; the market and economy in general; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.

- removed (2021-02-03):
[0001728949-20-000057:note_history:38]
Leases: In February 2016, the FASB issued new accounting guidance related to leases (ASC 842) that outlines a new comprehensive lease accounting model and requires expanded disclosures. Under the new accounting guidance, we are required to recognize right-of-use assets and corresponding lease liabilities on the consolidated balance sheet. We adopted ASC 842 in the first quarter of fiscal 2020 using the modified retrospective approach, with the cumulative effect of initial adoption recorded as an adjustment to our opening condensed consolidated balance sheet at September 30, 2019. We elected to not record leases with a term of 12 months or less on our consolidated balance sheet. In addition, we applied the package of practical expedients permitted under the transition guidance, which among other things, does not require reassessment of lease classification upon adoption. Prior period results have not been restated and continue to be reported in accordance with the accounting guidance in effect for those periods (ASC 840).

- removed (2021-02-03):
[0001728949-20-000057:note_history:39]
Upon adoption, we recorded $449 million of operating lease assets in other assets and $500 million of corresponding lease liabilities ($127 million recorded in other current liabilities and $373 million recorded in other liabilities). The difference between the operating lease assets and liabilities of $51 million primarily related to deferred rent liabilities that existed as of the date of adoption. Finance leases were not material for all periods presented. Adoption of the new accounting guidance did not have a material impact on our condensed consolidated statements of operations or cash flows.

- removed (2021-02-03):
[0001728949-20-000057:note_history:40]
Operating lease assets and liabilities are recognized for leases with lease terms greater than 12 months based on the present value of the future lease payments over the lease term at the commencement date. Operating leases are included in other assets, other current liabilities and other liabilities on our consolidated balance sheet. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise such option. We account for substantially all lease and related non-lease components together as a single lease component. Operating lease expense is recognized on a straight-line basis over the lease term.

- removed (2021-02-03):
[0001728949-20-000057:note_history:41]
Recent Accounting Guidance Not Yet Adopted.

- removed (2021-02-03):
[0001728949-20-000057:note_history:42]
Financial Assets: In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) will be estimated based on expected losses rather than the current incurred loss impairment model. The new accounting guidance also eliminates the concept of other-than-temporary impairment and requires credit losses related to available-for-sale debt securities to be recorded through an allowance for credit losses rather than as a reduction in the amortized cost basis of the securities. These changes will result in earlier recognition of credit losses, if any. The new accounting guidance generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt 
securities for which an other-than-temporary impairment has been recorded. We will adopt the new accounting guidance in the first quarter of fiscal 2021, and the impact of this new accounting guidance will largely depend on the composition and credit quality of our investment portfolio and accounts receivable, as well as economic conditions, at the time of adoption. Based on facts and factors currently known by us, we do not expect the impact of adoption to be material to our consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2021-02-03):
[0001728949-20-000057:note_history:43]
Debt
Long-term Debt. In May 2020, we issued unsecured fixed-rate notes, consisting of $1.2 billion fixed-rate 2.15% notes and $800 million fixed-rate 3.25% notes (May 2020 Notes) that mature on May 20, 2030 and May 20, 2050, respectively. The proceeds from the May 2020 Notes, net of underwriting discounts and offering expenses, were used to repay the $250 million floating-rate and $1.75 billion fixed-rate notes that matured on May 20, 2020, which were classified as short-term debt at September 29, 2019. We are not subject to any financial covenants under the May 2020 Notes nor any covenants that would prohibit us from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by us or our subsidiaries. The May 2020 Notes are senior unsecured obligations and rank equally with our other senior debt from time to time outstanding. We may redeem the outstanding fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable note.

- removed (2021-02-03):
[0001728949-20-000057:note_history:44]
The following table provides a summary of our long-term debt:

- removed (2021-02-03):
[0001728949-20-000057:note_history:45]
|  | June 28, 2020 |  |  |  |  |  | September 29, 2019 |  |  |  |  |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2022 - 2045 |  | $ | 6,500 |  |  | 2.62% - 4.73% |  | 2020 - 2045 |  | $ | 8,500 |  |  | 2.64% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 7,000 |  |  | 1.55% - 4.46% |  | 2023 - 2047 |  | 7,000 |  |  | 2.70% - 4.47% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.31% - 3.30% |  |  |  | — |  |  |  |
| Total principal |  |  | 15,500 |  |  |  |  |  |  | 15,500 |  |  |  |
| Unamortized discount, including debt issuance costs |  |  | (91) |  |  |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 16 |  |  |  |  |  |  | 9 |  |  |  |
| Total long-term debt |  |  | $ | 15,425 |  |  |  |  |  |  | $ | 15,434 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | — |  |  |  |  |  |  | $ | 1,997 |  |  |  |
| Long-term debt |  |  | 15,425 |  |  |  |  |  |  | 13,437 |  |  |  |
| Total |  |  | $ | 15,425 |  |  |  |  |  |  | $ | 15,434 |  |  |  |

- removed (2021-02-03):
[0001728949-20-000057:note_history:46]
At September 29, 2019, we had outstanding interest rate swaps with an aggregate notional amount of $1.8 billion related to certain of our May 2015 Notes. During the second quarter of fiscal 2020, we terminated interest rate swaps related to our fixed-rate 3.00% notes due May 20, 2022 resulting in a deferred gain of $19 million, which is being amortized to interest expense over the remaining term of such notes. During the third quarter of fiscal 2020, the remaining interest rate swaps on our fixed-rate 2.25% notes due May 20, 2020 terminated upon maturity of the notes.

- removed (2021-02-03):
[0001728949-20-000057:note_history:47]
At June 28, 2020 and September 29, 2019, the aggregate fair value of our remaining outstanding principal floating- and fixed-rate notes, including the current portion of long-term debt, based on Level 2 inputs, was approximately $17.6 billion and $16.5 billion, respectively.

- removed (2021-02-03):
[0001728949-20-000057:note_history:48]
Commercial Paper Program. In the third quarter of fiscal 2020, we reduced the total amount available for issuance under our unsecured commercial paper program from $5.0 billion to $4.5 billion. At June 28, 2020 and September 29, 2019, we had $500 million and $499 million, respectively, of outstanding commercial paper recorded as short-term debt.

- removed (2021-02-03):
[0001728949-20-000057:note_history:49]
Revolving Credit Facility. We have an Amended and Restated Revolving Credit Facility (Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion which expires on November 8, 2021. At June 28, 2020, no amounts were outstanding under the Revolving Credit Facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-03):
[0001728949-21-000022:note_history:50]
Marketable Securities
We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Our marketable securities were comprised as follows (in millions):
  (was, 2020-07-29, similarity 0.9518):
[0001728949-20-000057:note_history:50]
We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Our marketable securities were comprised as follows (in millions):

- changed (2021-02-03):
[0001728949-21-000022:note_history:51]
|  | Current |  | Noncurrent (1) |
|  | December 27,2020 |  | September 27,2020 |  | December 27,2020 |  | September 27,2020 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 27 |  |  | $ | 10 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,675 |  |  | 4,049 |  |  | — |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 95 |  |  | 66 |  |  | 35 |  |  | 35 |  |
| Total available-for-sale debt securities | 4,797 |  |  | 4,125 |  |  | 35 |  |  | 35 |  |
| Equity securities | 425 |  |  | 352 |  |  | — |  |  | — |  |
| Time deposit (2) | — |  |  | 30 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 5,222 |  |  | $ | 4,507 |  |  | $ | 35 |  |  | $ | 35 |  |
  (was, 2020-07-29, similarity 0.9413):
[0001728949-20-000057:note_history:51]
|  | Current |  |  |  | Noncurrent (1) |  |  |
|  | June 28,2020 |  | September 29,2019 |  | June 28,2020 |  | September 29,2019 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 6 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,005 |  |  | 4 |  |  | — |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 84 |  |  | — |  |  | 34 |  |  | 35 |  |
| Total available-for-sale debt securities | 4,095 |  |  | 4 |  |  | 34 |  |  | 35 |  |
| Equity securities | 355 |  |  | 417 |  |  | — |  |  | 1 |  |
| Time deposit (2) | 30 |  |  | — |  |  | — |  |  | — |  |
| Total marketable securities | $ | 4,480 |  |  | $ | 421 |  |  | $ | 34 |  |  | $ | 36 |  |

- changed (2021-02-03):
[0001728949-21-000022:note_history:52]
(2) At September 27, 2020, marketable securities also included a time deposit with an original maturity of greater than 90 days.
  (was, 2020-07-29, similarity 0.9536):
[0001728949-20-000057:note_history:52]
(2) At June 28, 2020, marketable securities also included a time deposit with an original maturity of greater than 90 days.

- changed (2021-02-03):
[0001728949-21-000022:note_history:53]
|  | December 27,2020 |
| Years to Maturity |  |
| Less than one year | $ | 2,810 |  |
| One to five years | 1,892 |  |
| No single maturity date | 130 |  |
| Total | $ | 4,832 |  |
  (was, 2020-07-29, similarity 0.9673):
[0001728949-20-000057:note_history:53]
|  | June 28,2020 |
| Years to Maturity |  |
| Less than one year | $ | 2,730 |  |
| One to five years | 1,281 |  |
| No single maturity date | 118 |  |
| Total | $ | 4,129 |  |

- removed (2021-02-03):
[0001728949-20-000057:note_history:54]
Note 9. Marketable Securities


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2021-02-03):
[0001728949-20-000057:note_history:55]
The following table provides a summary of our long-term debt:

- removed (2021-02-03):
[0001728949-20-000057:note_history:56]
|  | June 28, 2020 |  |  |  |  |  | September 29, 2019 |  |  |  |  |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2022 - 2045 |  | $ | 6,500 |  |  | 2.62% - 4.73% |  | 2020 - 2045 |  | $ | 8,500 |  |  | 2.64% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 7,000 |  |  | 1.55% - 4.46% |  | 2023 - 2047 |  | 7,000 |  |  | 2.70% - 4.47% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.31% - 3.30% |  |  |  | — |  |  |  |
| Total principal |  |  | 15,500 |  |  |  |  |  |  | 15,500 |  |  |  |
| Unamortized discount, including debt issuance costs |  |  | (91) |  |  |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 16 |  |  |  |  |  |  | 9 |  |  |  |
| Total long-term debt |  |  | $ | 15,425 |  |  |  |  |  |  | $ | 15,434 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | — |  |  |  |  |  |  | $ | 1,997 |  |  |  |
| Long-term debt |  |  | 15,425 |  |  |  |  |  |  | 13,437 |  |  |  |
| Total |  |  | $ | 15,425 |  |  |  |  |  |  | $ | 15,434 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2021-02-03):
[0001728949-21-000022:note_history:57]
QCT revenue streams were as follows (in millions):

- added (2021-02-03):
[0001728949-21-000022:note_history:58]
|  |  |  |  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  | December 27,2020 |  | December 29,2019 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 4,216 |  |  | $ | 2,352 |  |
| RFFE (2) |  |  |  |  |  |  |  |  | 1,061 |  |  | 413 |  |
| Automotive (3) |  |  |  |  |  |  |  |  | 212 |  |  | 147 |  |
| IoT (4) |  |  |  |  |  |  |  |  | 1,044 |  |  | 706 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 6,533 |  |  | $ | 3,618 |  |

- added (2021-02-03):
[0001728949-21-000022:note_history:59]
(1) Includes revenues from products sold for use in mobile handsets, excluding RFFE (radio frequency front-end) components.

- added (2021-02-03):
[0001728949-21-000022:note_history:60]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in handsets).

- added (2021-02-03):
[0001728949-21-000022:note_history:61]
(3) Includes revenues from products sold for use in automobiles, including telematics, connectivity and digital cockpit.

- added (2021-02-03):
[0001728949-21-000022:note_history:62]
(4) Internet of things (IoT) revenues primarily include products sold for use in cellular and non-cellular connected devices within the following industry segments or applications: consumer, computing, industrial, fixed wireless broadband, voice and music and wireless networking.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-02-03):
[0001728949-21-000022:note_history:63]
We disaggregate our revenues by segment (Note 6) and type of products and services (as presented on our condensed consolidated statement of operations), and for our QCT segment by revenue stream, which is based on industry segment or application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry segment or application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets.

- removed (2021-02-03):
[0001728949-20-000057:note_history:64]
We disaggregate our revenues by segment (Note 7) and type of products and services (as presented on our condensed consolidated statement of operations), as we believe this best depicts how the nature, amount, timing and uncertainty of our revenues and cash flows are affected by economic factors. Substantially all of QCT’s (Qualcomm CDMA Technologies) revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s (Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-02-03):
[0001728949-21-000022:note_history:65]
Subsequent EventsIn January 2021, we announced that we entered into a definitive agreement to acquire NuVia, Inc. (NUVIA) for approximately $1.4 billion before working capital and other adjustments, a substantial portion of which will be paid in cash and the remaining amount of which relates to unvested NUVIA equity awards that will be assumed or replaced in connection with the acquisition and will be recognized as compensation expense over the related post-acquisition service vesting period. NUVIA has certain in-process technologies and is comprised of a CPU (central processing unit) and technology design team with expertise in high performance processors, SoC (system-on-chip) and power management for compute-intensive devices and applications. Upon completion of development, NUVIA’s technologies are expected to be integrated into certain QCT products. The acquisition has been approved by the requisite number of NUVIA’s stockholders and is subject to receipt of regulatory approval in the United States and other customary closing conditions. The acquisition is expected to close in the second quarter of fiscal 2021.

- removed (2021-02-03):
[0001728949-20-000057:note_history:66]
Note 10. Subsequent Events

- removed (2021-02-03):
[0001728949-20-000057:note_history:67]
In July 2020, we entered into a settlement agreement with Huawei to resolve our prior dispute related to our license agreement that expired on December 31, 2019. We also entered into a new long-term, global patent license agreement, including a cross license granting back rights to certain of Huawei’s patents, covering sales beginning January 1, 2020. Amounts due under the settlement agreement (which are incremental to the $1.2 billion previously paid under two interim agreements) are expected to be paid in installments within one year in accordance with an agreed upon payment schedule, with the first payment due in the fourth quarter of fiscal 2020. While we continue to assess the accounting impacts of the agreements, including consideration of the geopolitical environment, we currently expect to record revenues in the fourth quarter of fiscal 2020 resulting from such agreements, including certain amounts related to previously satisfied performance obligations. Such event is considered a nonrecognized subsequent event.
