# QCOM notes — 0001728949-21-000022


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-21-000022:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 27, 2020. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 27, 2020 and December 29, 2019 included 13 weeks.

[0001728949-21-000022:notes:2]
[same as prior period, unchanged from 0001728949-20-000057:notes:2]

[0001728949-21-000022:notes:3]
Recently Adopted Accounting Guidance.

[0001728949-21-000022:notes:4]
Financial Assets: In June 2016, the Financial Accounting Standards Board (FASB) issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) are estimated based on expected losses rather than the previous incurred loss impairment model. The new accounting guidance also eliminated the concept of other-than-temporary impairment with credit losses related to available-for-sale debt securities recorded through an allowance for credit losses rather than as a reduction in the amortized cost basis of the securities. We adopted the new accounting guidance in the first quarter of fiscal 2021 under the modified retrospective transition method, except for certain available-for-sale debt securities where the prospective transition method was required, and as a result, prior period results have not been restated. The impact upon adoption was not material to our condensed consolidated financial statements. The future impact of such accounting guidance will largely depend on the future composition and credit quality of our investment portfolio and accounts receivable, as well as future economic conditions.

[0001728949-21-000022:notes:5]
[same as prior period, unchanged from 0001728949-20-000057:notes:6]

[0001728949-21-000022:notes:6]
Marketable Securities: As a result of the adoption of the new accounting guidance described above, we revised our  accounting policy beginning in fiscal 2021 as follows.

[0001728949-21-000022:notes:7]
Marketable securities include marketable equity securities, available-for-sale debt securities and, from time-to-time, certain time deposits. We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value with all realized and unrealized gains and losses on investments in marketable equity securities and realized gains and losses on available-for-sale debt securities recognized in investment and other income, net. Debt securities are classified as available for sale or held to maturity at the time of purchase and reevaluated at each balance sheet date. The realized and unrealized gains and losses on marketable securities are determined using the specific identification method.

[0001728949-21-000022:notes:8]
If a debt security has an unrealized loss and we either intend to sell the security or it is more likely than not that we will be required to sell the security before its anticipated recovery, we record an impairment charge to investment and other income, net for the entire amount of the unrealized loss and adjust the amortized cost basis of the security. For the remaining debt securities, if an unrealized loss exists, we separate the impairment into the portion of the loss related to credit factors and the portion of the loss that is not related to credit factors. Unrealized gains or unrealized losses that are not related to credit factors on available-for-sale debt securities are recorded as a component of accumulated other comprehensive income, net of income taxes. Unrealized losses that are related to credit loss factors on available-for-sale debt securities and subsequent adjustments to the credit loss are recorded as an allowance for credit losses, which is included in investment and other income, net. In evaluating whether a credit loss exists, we consider a variety of factors, including the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; the security’s relative performance versus its peers, sector or asset class; the market and economy in general; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-21-000022:notes:9]
[same as prior period, unchanged from 0001728949-20-000057:notes:11]

[0001728949-21-000022:notes:10]
| Inventories (in millions) |  |  |  |
|  | December 27,2020 |  | September 27,2020 |
| Raw materials | $ | 138 |  |  | $ | 94 |  |
| Work-in-process | 1,192 |  |  | 1,155 |  |
| Finished goods | 1,222 |  |  | 1,349 |  |
|  | $ | 2,552 |  |  | $ | 2,598 |  |

[0001728949-21-000022:notes:11]
Revolving Credit Facility. On December 8, 2020, we entered into a Revolving Credit Facility replacing our prior Amended and Restated Revolving Credit Facility. There were no outstanding borrowings under the Amended and Restated Revolving Credit Facility at the time of termination. The Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At December 27, 2020, no amounts were outstanding under the Revolving Credit Facility. The Revolving Credit Facility requires that we comply with certain financial covenants, including that we maintain an interest coverage ratio, as defined in the agreement. At December 27, 2020, we were in compliance with the applicable covenants under the Revolving Credit Facility.

[0001728949-21-000022:notes:12]
Revenues. We disaggregate our revenues by segment (Note 6) and type of products and services (as presented on our condensed consolidated statement of operations), and for our QCT segment by revenue stream, which is based on industry segment or application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry segment or application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets. QCT revenue streams were as follows (in millions):

[0001728949-21-000022:notes:13]
|  |  |  |  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  | December 27,2020 |  | December 29,2019 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 4,216 |  |  | $ | 2,352 |  |
| RFFE (2) |  |  |  |  |  |  |  |  | 1,061 |  |  | 413 |  |
| Automotive (3) |  |  |  |  |  |  |  |  | 212 |  |  | 147 |  |
| IoT (4) |  |  |  |  |  |  |  |  | 1,044 |  |  | 706 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 6,533 |  |  | $ | 3,618 |  |

[0001728949-21-000022:notes:14]
(1) Includes revenues from products sold for use in mobile handsets, excluding RFFE (radio frequency front-end) components.

[0001728949-21-000022:notes:15]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in handsets).

[0001728949-21-000022:notes:16]
(3) Includes revenues from products sold for use in automobiles, including telematics, connectivity and digital cockpit.

[0001728949-21-000022:notes:17]
(4) Internet of things (IoT) revenues primarily include products sold for use in cellular and non-cellular connected devices within the following industry segments or applications: consumer, computing, industrial, fixed wireless broadband, voice and music and wireless networking.

[0001728949-21-000022:notes:18]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were $110 million and $92 million for the three months ended December 27, 2020 and December 29, 2019, respectively, and primarily related to QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, in part based on actual reporting of royalties by our licensees) and certain QCT customer incentives.

[0001728949-21-000022:notes:19]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In the three months ended December 27, 2020 and December 29, 2019, we recognized revenues of $185 million and $178 million, respectively, that were recorded as unearned revenues at September 27, 2020 and September 29, 2019, respectively.

[0001728949-21-000022:notes:20]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and

[0001728949-21-000022:notes:21]
(b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront. At December 27, 2020, we had $1.2 billion of remaining performance obligations, of which $403 million, $496 million, $238 million, $65 million and $26 million was expected to be recognized as revenues for the remainder of fiscal 2021 and each of the subsequent four years from fiscal 2022 through 2025, respectively, and no amounts thereafter.

[0001728949-21-000022:notes:22]
Concentrations. A significant portion of our revenues are concentrated with a small number of customers/licensees of our QCT and QTL segments. Revenues from three customers/licensees comprised 34%, 13% and 10% of total consolidated revenues in the first quarter fiscal 2021, as compared to 14%, 17% and 13% of total consolidated revenues in the first quarter of fiscal 2020. In the first quarter of fiscal 2020, one additional customer/licensee also comprised 12% of total consolidated revenues. The comparability of customer/licensee concentrations for the interim periods presented are impacted by the timing of customer/licensee device launches and/or innovation cycles and other seasonal trends, among other fluctuations in demand.

[0001728949-21-000022:notes:23]
Accounts receivable at December 27, 2020 and September 27, 2020 included $1.2 billion and $1.3 billion, respectively, excluding the impact of foreign withholding taxes, from Huawei related to the remaining amounts due under the previously disclosed settlement agreement to be paid in installments by the end of June 2021 and estimated royalties for sales made in the December 2020 and September 2020 quarters, respectively, under the global patent license agreement with Huawei. Subsequent to December 27, 2020, Huawei paid the second installment of $500 million (excluding the impact of foreign withholding taxes) under the settlement agreement in accordance with the agreed upon payment schedule.

[0001728949-21-000022:notes:24]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  |  |  |  |
| Interest and dividend income | $ | 21 |  |  | $ | 59 |  |  |  |  |  |
| Net gains on marketable securities | 118 |  |  | 11 |  |  |  |  |  |
| Net gains on other investments | 34 |  |  | 48 |  |  |  |  |  |
| Net gains on deferred compensation plan assets | 54 |  |  | 30 |  |  |  |  |  |
| Impairment losses on other investments | (1) |  |  | (72) |  |  |  |  |  |
| Net gains on derivative investments | 9 |  |  | 2 |  |  |  |  |  |
| Equity in net losses of investees | (2) |  |  | (10) |  |  |  |  |  |
| Net losses on foreign currency transactions | (14) |  |  | (3) |  |  |  |  |  |
|  | $ | 219 |  |  | $ | 65 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-21-000022:notes:25]
Income Taxes
As of the first quarter of fiscal 2021, we estimated our annual effective income tax rate to be 11% for fiscal 2021, which is lower than the U.S. federal statutory rate, primarily due to a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate and due to benefits from our federal research and development tax credit. The effective tax rate of 6% for the first quarter of fiscal 2021 was lower than the estimated annual effective tax rate of 11% primarily due to $212 million of discrete net tax benefits recorded in the first quarter of fiscal 2021, which principally related to excess tax benefits associated with share-based awards that vested in the first fiscal quarter, foreign currency gains on a noncurrent receivable related to our refund claim of Korean withholding tax and valuation allowance release on foreign tax credit carryforwards. The effective tax rate of 2% for the first quarter of fiscal 2020 included $102 million of discrete net tax benefits recorded in the first quarter of fiscal 2020, which principally related to excess tax benefits associated with share-based awards that vested in the first fiscal quarter of fiscal 2020, valuation allowance release on capital loss carryforwards and foreign currency gains on a noncurrent receivable related to our refund claim of Korean withholding tax.

[0001728949-21-000022:notes:26]
In the first quarter of fiscal 2021, the United States Treasury Department issued final regulations on the foreign tax credit, which generally are applicable beginning in fiscal 2021, with certain provisions retroactive to fiscal 2019. As a result of these regulations, our fiscal 2021 estimated annual effective tax rate increased by approximately 1%. The retroactive impact resulting from these new regulations, which was related to fiscal 2019 and fiscal 2020 and recorded discretely in the first quarter of fiscal 2021, was not significant.
Unrecognized tax benefits were $2.0 billion and $1.9 billion at December 27, 2020 and September 27, 2020, respectively, and primarily related to our refund claim of Korean withholding tax. If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We expect that the total amount of unrecognized tax benefits at December 27, 2020 will increase in the next 12 months as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-21-000022:notes:27]
Capital Stock
Stock Repurchase Program. On July 26, 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. The stock repurchase program has no expiration date. In the first quarter of fiscal 2021, we resumed stock repurchases under the stock repurchase program, which we had suspended in the third quarter of fiscal 2020 in light of the COVID-19 pandemic.

[0001728949-21-000022:notes:28]
In the three months ended December 27, 2020 and December 29, 2019, we repurchased and retired 3 million and 9 million shares, respectively, for $444 million and $762 million, respectively, before commissions. To reflect share repurchases in the consolidated balance sheet, we (i) reduce common stock for the par value of the shares, (ii) reduce paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) record the residual amount, if any, to retained earnings. At December 27, 2020, $4.2 billion remained authorized for repurchase under our stock repurchase program. Since December 27, 2020, we repurchased and retired 2 million shares of common stock for $311 million.

[0001728949-21-000022:notes:29]
Dividends. On January 20, 2021, we announced a cash dividend of $0.65 per share on our common stock, payable on March 25, 2021 to stockholders of record as of the close of business on March 4, 2021.

[0001728949-21-000022:notes:30]
Earnings Per Common Share. Basic earnings per common share is computed by dividing net income by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of the weighted-average number of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans and the weighted-average number of common shares outstanding during the reporting period. The following table provides information about the diluted earnings per share calculation (in millions):

[0001728949-21-000022:notes:31]
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  |  |  |  |
| Dilutive common share equivalents included in diluted shares | 22 |  |  | 15 |  |  |  |  |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | — |  |  | — |  |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-21-000022:notes:32]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0001728949-21-000022:notes:33]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000022:notes:34]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our then current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to

[0001728949-21-000022:notes:35]
disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On January 22, 2019, the court appointed the lead plaintiff in the action. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint, and on March 10, 2020, the court granted our motion. On May 11, 2020, the plaintiffs filed a second amended complaint, and on October 8, 2020, the court granted our motion to dismiss the case with prejudice. On November 7, 2020, the plaintiffs filed a notice of appeal. No hearing date has been set. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000022:notes:36]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. The Ninth Circuit has not yet ruled on our appeal. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000022:notes:37]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court) and Israel (in the Haifa District Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek unspecified damages. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000022:notes:38]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, then captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision has subsequently reduced the number of patents asserted to four, granted covenants not to sue on the other patents and dismissed the Samsung and HTC entities from the case. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. Trial is expected to begin no earlier than June 2021. We have previously prevailed on infringement claims asserted by ParkerVision in related lawsuits and have successfully invalidated a number of their patent claims in patent office proceedings. We believe that ParkerVision’s claims are without merit.

[0001728949-21-000022:notes:39]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an

[0001728949-21-000022:notes:40]
independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0001728949-21-000022:notes:41]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019 and, on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-21-000022:notes:42]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of their investigation, but we believe it concerns our business practices in connection with our sale of radio frequency front-end (RFFE) components. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-21-000022:notes:43]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision confirming their preliminary view that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

[0001728949-21-000022:notes:44]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 27, 2020, the liability, including related foreign currency losses and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $301 million and included in other current liabilities.

[0001728949-21-000022:notes:45]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. A

[0001728949-21-000022:notes:46]
hearing before the court is scheduled for May 4-6, 2021. We believe that our business practices do not violate the EU competition rules.

[0001728949-21-000022:notes:47]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 27, 2020, the liability, including related foreign currency losses and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.3 billion and included in other current liabilities.

[0001728949-21-000022:notes:48]
European Commission (EC) Investigation regarding Radio Frequency Front End (RFFE): On December 3, 2019, we received a Request for Information from the EC notifying us that it is investigating whether we engaged in anti-competitive behavior in the European Union (EU)/European Economic Area (EEA) by leveraging our market position in 5G baseband processors in the RFFE space. We have responded to the Request for Information. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of our annual revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. We believe that our business practices do not violate the EU competition rules.

[0001728949-21-000022:notes:49]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of cellular modem chipsets on the purchaser first agreeing to a license to our cellular standard-essential patents, paying incentives to purchasers of cellular modem chipsets to induce them to accept certain license terms, refusing to license our cellular standard-essential patents to our competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint sought a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief. On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to rival sellers of cellular modem chipsets. On November 6, 2018, the court granted the FTC’s partial summary judgment motion. Trial was held January 4-29, 2019.

[0001728949-21-000022:notes:50]
On May 21, 2019, the court issued an Order setting forth its Findings of Fact and Conclusions of Law. The court concluded that we had monopoly power in the CDMA and premium-tier Long Term Evolution (LTE) cellular modem chip markets, and that we had used that power in these two markets to engage in anticompetitive acts, including (1) using threats of lack of access to cellular modem chip supply to coerce OEMs to accept license terms that include unreasonably high royalty rates; (2) refusing to license our cellular standard-essential patents to competitors selling cellular modem chips; and (3) entering into exclusive dealing arrangements with OEMs that foreclosed our rivals. The court further found that the royalties we charge OEMs are unreasonably high and reflect the use of our monopoly power over CDMA and premium-tier LTE cellular modem chips rather than just the value of our patents. The court concluded that our unreasonably high royalties constitute an anticompetitive surcharge on cellular modem chips sold by our competitors, which increases the effective price of our competitors’ cellular modem chips, reduces their margins and results in exclusivity. The court also found that our practice of not licensing competitors’ cellular modem chips violated our commitments to certain standard-development organizations and a duty under the antitrust laws to license competing cellular modem chip makers and helped us maintain our royalties at unreasonably high levels. Finally, the court found that incentive funds entered into with certain OEMs further harmed competing cellular modem chip makers’ ability to undermine our monopoly position, prevented rivals from entering the market and restricted the sales of those competitors that do enter. The court concluded that the combined effect of our conduct, together with our monopoly power, harmed the competitive process.

[0001728949-21-000022:notes:51]
The court imposed the following injunctive relief: (1) we must not condition the supply of cellular modem chips on a customer’s patent license status, and we must negotiate or renegotiate license terms with customers in good faith under conditions free from the threat of lack of access to or discriminatory provision of cellular modem chip supply or associated technical support or access to software; (2) we must make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers on fair, reasonable and non-discriminatory (FRAND) terms and submit, as necessary, to arbitral or judicial dispute resolution to determine such terms; (3) we may not enter into express or de facto exclusive dealing

[0001728949-21-000022:notes:52]
agreements for the supply of cellular modem chips; and (4) we may not interfere with the ability of any customer to communicate with a government agency about a potential law enforcement or regulatory matter. The court also ordered us to submit to compliance and monitoring procedures for a period of seven years and to report to the FTC on an annual basis regarding our compliance with the above remedies.

[0001728949-21-000022:notes:53]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On August 23, 2019, the Ninth Circuit granted our Motion for Partial Stay. On February 13, 2020, the Ninth Circuit heard oral argument.

[0001728949-21-000022:notes:54]
On August 11, 2020, the Ninth Circuit issued its opinion, which reversed the district court’s judgment, vacated its injunction and vacated its partial grant of summary judgment. The Ninth Circuit stated that the district court erred in holding that we are under an antitrust duty to license rival chip manufacturers and noted that our practice of licensing our standard-essential patents exclusively at the OEM level does not violate the antitrust laws. The Ninth Circuit also held that the district court’s “anticompetitive surcharge” theory failed to state a cogent theory of anticompetitive harm and that our patent-licensing royalties and “no license, no chips” policy do not impose an anticompetitive surcharge on rivals’ modem chip sales and do not undermine competition in either the CDMA or premium LTE chip markets. While agreeing with the district court that our 2011 and 2013 agreements with Apple were structured like exclusive dealing contracts, the Ninth Circuit nonetheless held that neither agreement had the actual or practical effect of substantially foreclosing competition in the CDMA modem chip market, and because Apple terminated these agreements years ago, the district court had improperly issued an injunction. The Ninth Circuit noted that neither the Sherman Act nor any other law prohibits companies like us from (1) licensing their standard-essential patents independently from their chip sales and collecting royalties, and/or (2) limiting their chip customer base to licensed OEMs. On September 25, 2020, the FTC filed a Petition for Rehearing En Banc. On October 28, 2020, the Ninth Circuit denied the FTC’s petition.

[0001728949-21-000022:notes:55]
Contingent losses and other considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at December 27, 2020 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-21-000022:notes:56]
Segment InformationWe are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarity of business activities within our operating segments, such as the nature of products, the level of shared products, technology and other resources, production processes and customer base. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies for use in mobile devices, wireless networks, devices used in the internet of things (IoT), broadband gateway equipment, consumer electronic devices and automotive systems for telematics and infotainment. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an investee. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies), our cloud AI inference processing initiative and other technology and service initiatives.
Our CODM allocates resources to and evaluates the performance of our segments based on revenues and earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense, certain net investment income, certain share-based compensation, gains and losses on our deferred compensation plan liabilities and related assets and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories and property, plant and equipment to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and awards, settlements and/or damages arising from legal or regulatory matters.

[0001728949-21-000022:notes:57]
The table below presents revenues and EBT for reportable segments (in millions):

[0001728949-21-000022:notes:58]
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 6,533 |  |  | $ | 3,618 |  |  |  |  |  |
| QTL | 1,660 |  |  | 1,404 |  |  |  |  |  |
| QSI | 9 |  |  | 20 |  |  |  |  |  |
| Reconciling items | 33 |  |  | 35 |  |  |  |  |  |
| Total | $ | 8,235 |  |  | $ | 5,077 |  |  |  |  |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 1,919 |  |  | $ | 479 |  |  |  |  |  |
| QTL | 1,270 |  |  | 1,017 |  |  |  |  |  |
| QSI | 158 |  |  | (3) |  |  |  |  |  |
| Reconciling items | (743) |  |  | (546) |  |  |  |  |  |
| Total | $ | 2,604 |  |  | $ | 947 |  |  |  |  |  |

[0001728949-21-000022:notes:59]
[same as prior period, unchanged from 0001728949-20-000057:notes:78]

[0001728949-21-000022:notes:60]
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 33 |  |  | $ | 35 |  |  |  |  |  |
|  | $ | 33 |  |  | $ | 35 |  |  |  |  |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of revenues | $ | (74) |  |  | $ | (90) |  |  |  |  |  |
| Unallocated research and development expenses | (406) |  |  | (259) |  |  |  |  |  |
| Unallocated selling, general and administrative expenses | (178) |  |  | (117) |  |  |  |  |  |
| Unallocated interest expense | (142) |  |  | (147) |  |  |  |  |  |
| Unallocated investment and other income, net | 71 |  |  | 82 |  |  |  |  |  |
| Nonreportable segments | (14) |  |  | (15) |  |  |  |  |  |
|  | $ | (743) |  |  | $ | (546) |  |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-21-000022:notes:61]
Fair Value Measurements
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at December 27, 2020 (in millions):

[0001728949-21-000022:notes:62]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 1,970 |  |  | $ | 3,684 |  |  | $ | — |  |  | $ | 5,654 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 19 |  |  | 8 |  |  | — |  |  | 27 |  |
| Corporate bonds and notes | — |  |  | 4,675 |  |  | — |  |  | 4,675 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 95 |  |  | 35 |  |  | 130 |  |
| Equity securities | 425 |  |  | — |  |  | — |  |  | 425 |  |
| Total marketable securities | 444 |  |  | 4,778 |  |  | 35 |  |  | 5,257 |  |
| Derivative instruments | — |  |  | 60 |  |  | — |  |  | 60 |  |
| Other investments | 590 |  |  | — |  |  | 9 |  |  | 599 |  |
| Total assets measured at fair value | $ | 3,004 |  |  | $ | 8,522 |  |  | $ | 44 |  |  | $ | 11,570 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 19 |  |
| Other liabilities | 590 |  |  | — |  |  | — |  |  | 590 |  |
| Total liabilities measured at fair value | $ | 590 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 609 |  |

[0001728949-21-000022:notes:63]
Activity within Level 3 of the Fair Value Hierarchy. Other investments included in Level 3 at December 27, 2020 were comprised of non-marketable debt instruments. Activity for marketable securities and other investments classified within Level 3 was insignificant during the three months ended December 27, 2020 (primarily related to settlements of non-marketable debt instruments) and the three months ended December 29, 2019 (primarily related to purchases of non-marketable debt instruments). Activity for other liabilities classified within Level 3 was insignificant during the three months ended December 29, 2019.

[0001728949-21-000022:notes:64]
Assets Measured and Recorded at Fair Value on a Nonrecurring Basis. We measure certain assets and liabilities at fair value on a nonrecurring basis. These assets and liabilities include equity method and non-marketable equity investments, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During the three months ended December 27, 2020 and December 29, 2019, certain of our non-marketable equity investments were written down to their estimated fair values, which was recorded as a component of impairment losses on other investments in investment and other income, net (Note 2), and certain other non-marketable equity investments were remeasured to their estimated fair values based on observable price changes in orderly transactions for identical or similar securities, which is recorded as a component of net gains on other investments in investment and other income, net (Note 2). The estimation of fair value used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3.

[0001728949-21-000022:notes:65]
Long-term Debt. At December 27, 2020 and September 27, 2020, the aggregate fair value of our outstanding floating- and fixed-rate notes, based on Level 2 inputs, was approximately $17.7 billion and $17.5 billion, respectively.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-21-000022:notes:66]
Marketable Securities
We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Our marketable securities were comprised as follows (in millions):

[0001728949-21-000022:notes:67]
|  | Current |  | Noncurrent (1) |
|  | December 27,2020 |  | September 27,2020 |  | December 27,2020 |  | September 27,2020 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 27 |  |  | $ | 10 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,675 |  |  | 4,049 |  |  | — |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 95 |  |  | 66 |  |  | 35 |  |  | 35 |  |
| Total available-for-sale debt securities | 4,797 |  |  | 4,125 |  |  | 35 |  |  | 35 |  |
| Equity securities | 425 |  |  | 352 |  |  | — |  |  | — |  |
| Time deposit (2) | — |  |  | 30 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 5,222 |  |  | $ | 4,507 |  |  | $ | 35 |  |  | $ | 35 |  |

[0001728949-21-000022:notes:68]
(1) Noncurrent marketable securities were included in other assets.

[0001728949-21-000022:notes:69]
(2) At September 27, 2020, marketable securities also included a time deposit with an original maturity of greater than 90 days.

[0001728949-21-000022:notes:70]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001728949-21-000022:notes:71]
|  | December 27,2020 |
| Years to Maturity |  |
| Less than one year | $ | 2,810 |  |
| One to five years | 1,892 |  |
| No single maturity date | 130 |  |
| Total | $ | 4,832 |  |

[0001728949-21-000022:notes:72]
Debt securities with no single maturity date included mortgage- and asset-backed securities and auction rate securities.


## us-gaap:SubsequentEventsTextBlock

[0001728949-21-000022:notes:73]
Subsequent EventsIn January 2021, we announced that we entered into a definitive agreement to acquire NuVia, Inc. (NUVIA) for approximately $1.4 billion before working capital and other adjustments, a substantial portion of which will be paid in cash and the remaining amount of which relates to unvested NUVIA equity awards that will be assumed or replaced in connection with the acquisition and will be recognized as compensation expense over the related post-acquisition service vesting period. NUVIA has certain in-process technologies and is comprised of a CPU (central processing unit) and technology design team with expertise in high performance processors, SoC (system-on-chip) and power management for compute-intensive devices and applications. Upon completion of development, NUVIA’s technologies are expected to be integrated into certain QCT products. The acquisition has been approved by the requisite number of NUVIA’s stockholders and is subject to receipt of regulatory approval in the United States and other customary closing conditions. The acquisition is expected to close in the second quarter of fiscal 2021.
