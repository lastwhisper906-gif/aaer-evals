# QCOM MD&A — 0001728949-21-000022


## mdna

[0001728949-21-000022:mdna:1]
[same as prior period, unchanged from 0001728949-20-000057:mdna:1]

[0001728949-21-000022:mdna:2]
This information should be read in conjunction with the condensed consolidated financial statements and the notes thereto included in “Part I, Item 1” of this Quarterly Report and with “Management’s Discussion and Analysis of Financial Condition and Results of Operations” for the fiscal year ended September 27, 2020 contained in our 2020 Annual Report on Form 10-K.

[0001728949-21-000022:mdna:3]
This Quarterly Report (including but not limited to this section titled Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements regarding our business, investments, financial condition, results of operations, cash flows and prospects. Forward-looking statements also include but are not limited to statements regarding the coronavirus (COVID-19) pandemic and its potential future impact on: the global economy, economic uncertainty and consumer and business confidence; demand for devices that incorporate our products and intellectual property; our and the global wireless industry’s supply chains, transportation and distribution networks and workforces; 5G network deployments; and our business, revenues, results of operations, cash flows and financial condition; as well as statements regarding our planning assumptions, workforce practices, the duration and severity of the pandemic, and government and other actions to mitigate the spread of, and to treat, COVID-19. Forward-looking statements further include but are not limited to statements regarding industry, market, business, product, technology, commercial, competitive or consumer trends, including seasonality; the 5G transition; our businesses, growth potential or strategies, or factors that may impact them; challenges to our licensing business, including by licensees, governments, governmental agencies or regulators, standards bodies or others; challenges to our QCT business; other legal or regulatory matters; competition; new or expanded product areas, adjacent industry segments or applications; costs or expenditures including research and development, selling, general and administrative, restructuring or restructuring-related charges, working capital or information technology systems; our debt, financing, stock repurchase or dividend programs; our liquidity and capital resources; strategic investments or acquisitions, and the anticipated timing or benefits thereof; adoption and application of future accounting guidance; tax law changes; our tax structure or strategies; U.S./China trade or national security policies; and the potential business or financial statement impacts of any of the above, among others. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001728949-21-000022:mdna:4]
First Quarter Fiscal 2021 Overview and Other Recent Events

[0001728949-21-000022:mdna:5]
Revenues for the first quarter of fiscal 2021 were $8.2 billion, an increase of 62% compared to the year ago quarter, with net income of $2.5 billion, an increase of 165% compared to the year ago quarter. Highlights and other key developments from the first quarter of fiscal 2021 and other recent events included:

[0001728949-21-000022:mdna:6]
•QCT and QTL results were positively impacted by Apple’s fall device launches in advance of the holiday season.

[0001728949-21-000022:mdna:7]
•QCT revenues increased by 81% in the first quarter of fiscal 2021 compared to the year ago quarter, primarily due to an increase in demand for 5G products across handsets and RFFE, along with higher automotive and IoT revenues.

[0001728949-21-000022:mdna:8]
•QTL revenues increased by 18% in the first quarter of fiscal 2021 compared to the year ago quarter, primarily due an increase in estimated sales of 3G/4G/5G-based multimode products from our key licensees (in part due to the new license agreement with Huawei), partially offset by the negative impact of COVID-19 and lower demand in China for licensees’ products that incorporate our intellectual property.

[0001728949-21-000022:mdna:9]
22

[0001728949-21-000022:mdna:10]
•In January 2021, we announced that we entered into a definitive agreement to acquire NuVia, Inc. (NUVIA) for approximately $1.4 billion. NUVIA is comprised of a CPU (central processing unit) and technology design team with expertise in high performance processors, SoC (system-on-chip) and power management for compute-intensive devices and applications. Upon development, NUVIA’s technologies are expected to be integrated into certain QCT products. The acquisition is expected to close in the second quarter of fiscal 2021.

[0001728949-21-000022:mdna:11]
[same as prior period, unchanged from 0001728949-20-000057:mdna:11]

[0001728949-21-000022:mdna:12]
[same as prior period, unchanged from 0001728949-20-000057:mdna:12]

[0001728949-21-000022:mdna:13]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies), our cloud AI inference processing initiative and other technology and service initiatives.

[0001728949-21-000022:mdna:14]
[same as prior period, unchanged from 0001728949-20-000057:mdna:14]

[0001728949-21-000022:mdna:15]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when licensees’ sales occur. We expect QCT revenues to continue to be impacted by seasonal trends related to product launch timing for sales made to Apple under our multi-year chipset supply agreement. These trends may or may not continue in the future and have been impacted by the decline in consumer demand resulting from COVID-19. Further, the trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings.

[0001728949-21-000022:mdna:16]
[same as prior period, unchanged from 0001728949-20-000057:mdna:17]

[0001728949-21-000022:mdna:17]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  | Change |  |  |  |  |  |  |
| Equipment and services | $ | 6,442 |  |  | $ | 3,534 |  |  | $ | 2,908 |  |  |  |  |  |  |  |
| Licensing | 1,793 |  |  | 1,543 |  |  | 250 |  |  |  |  |  |  |  |
|  | $ | 8,235 |  |  | $ | 5,077 |  |  | $ | 3,158 |  |  |  |  |  |  |  |

[0001728949-21-000022:mdna:18]
First quarter 2021 vs. 2020

[0001728949-21-000022:mdna:19]
The increase in revenues in the first quarter of fiscal 2021 was primarily due to:

[0001728949-21-000022:mdna:20]
+    $2.9 billion in higher equipment and services revenues from our QCT segment

[0001728949-21-000022:mdna:21]
+    $256 million in higher licensing revenues from our QTL segment

[0001728949-21-000022:mdna:22]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  | Change |  |  |  |  |  |  |
| Cost of revenues | $ | 3,489 |  |  | $ | 2,113 |  |  | $ | 1,376 |  |  |  |  |  |  |  |
| Gross margin | 58 | % |  | 58 | % |  |  |  |  |  |  |  |  |

[0001728949-21-000022:mdna:23]
First quarter 2021 vs. 2020

[0001728949-21-000022:mdna:24]
Gross margin percentage remained flat in the first quarter of fiscal 2021 primarily due to:

[0001728949-21-000022:mdna:25]
-    decrease in higher margin QTL licensing revenues in proportion to QCT revenues

[0001728949-21-000022:mdna:26]
+    increase in QCT gross margin

[0001728949-21-000022:mdna:27]
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  | Change |  |  |  |  |  |  |
| Research and development | $ | 1,653 |  |  | $ | 1,406 |  |  | $ | 247 |  |  |  |  |  |  |  |
| % of revenues | 20 | % |  | 28 | % |  |  |  |  |  |  |  |  |

[0001728949-21-000022:mdna:28]
First quarter 2021 vs. 2020

[0001728949-21-000022:mdna:29]
The increase in research and development expenses in the first quarter of fiscal 2021 was primarily due to:

[0001728949-21-000022:mdna:30]
+    $170 million increase driven by higher costs related to the development of wireless and integrated circuit technologies, including 5G and application processor technologies

[0001728949-21-000022:mdna:31]
+    $74 million increase in share-based compensation expense

[0001728949-21-000022:mdna:32]
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  | Change |  |  |  |  |  |  |
| Selling, general and administrative | $ | 567 |  |  | $ | 528 |  |  | $ | 39 |  |  |  |  |  |  |  |
| % of revenues | 7 | % |  | 10 | % |  |  |  |  |  |  |  |  |

[0001728949-21-000022:mdna:33]
First quarter 2021 vs. 2020

[0001728949-21-000022:mdna:34]
The increase in selling, general and administrative expenses in the first quarter of fiscal 2021 was primarily due to:

[0001728949-21-000022:mdna:35]
+    $22 million increase in share-based compensation expense

[0001728949-21-000022:mdna:36]
+    $20 million in higher expenses driven by revaluation of our deferred compensation obligation on strong stock market performance (which resulted in a corresponding increase in net gains on deferred compensation plan assets within investment and other income, net due to the revaluation of the related assets)

[0001728949-21-000022:mdna:37]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  | Change |  |  |  |  |  |  |
| Interest expense | $ | 141 |  |  | $ | 148 |  |  | $ | (7) |  |  |  |  |  |  |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 21 |  |  | $ | 59 |  |  | $ | (38) |  |  |  |  |  |  |  |
| Net gains on marketable securities | 118 |  |  | 11 |  |  | 107 |  |  |  |  |  |  |  |
| Net gains on other investments | 34 |  |  | 48 |  |  | (14) |  |  |  |  |  |  |  |
| Net gains on deferred compensation plan assets | 54 |  |  | 30 |  |  | 24 |  |  |  |  |  |  |  |
| Impairment losses on other investments | (1) |  |  | (72) |  |  | 71 |  |  |  |  |  |  |  |
| Net gains on derivative instruments | 9 |  |  | 2 |  |  | 7 |  |  |  |  |  |  |  |
| Equity in net losses of investees | (2) |  |  | (10) |  |  | 8 |  |  |  |  |  |  |  |
| Net losses on foreign currency transactions | (14) |  |  | (3) |  |  | (11) |  |  |  |  |  |  |  |
|  | $ | 219 |  |  | $ | 65 |  |  | $ | 154 |  |  |  |  |  |  |  |

[0001728949-21-000022:mdna:38]
24

[0001728949-21-000022:mdna:39]
[same as prior period, unchanged from 0001728949-20-000057:mdna:72]

[0001728949-21-000022:mdna:40]
[same as prior period, unchanged from 0001728949-20-000057:mdna:73]

[0001728949-21-000022:mdna:41]
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  |  |  |  |
| Expected income tax provision at federal statutory tax rate | $ | 547 |  |  | $ | 199 |  |  |  |  |  |
| Excess tax benefit associated with share-based awards | (163) |  |  | (47) |  |  |  |  |  |
| Foreign currency gain related to foreign withholding tax receivable | (79) |  |  | (43) |  |  |  |  |  |
| Benefit from foreign-derived intangible income (FDII) deduction | (75) |  |  | (46) |  |  |  |  |  |
| Benefit related to the research and development tax credit | (59) |  |  | (25) |  |  |  |  |  |
| Benefit from releasing valuation allowance on capital losses | (8) |  |  | (44) |  |  |  |  |  |
| Other | (14) |  |  | 28 |  |  |  |  |  |
| Income tax expense | $ | 149 |  |  | $ | 22 |  |  |  |  |  |
| Effective tax rate | 6 | % |  | 2 | % |  |  |  |  |

[0001728949-21-000022:mdna:42]
As of the first quarter of fiscal 2021, we estimated our annual effective income tax rate to be 11% for fiscal 2021, which is lower than the U.S. federal statutory rate, primarily due to a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate and due to benefits from our federal research and development tax credit.

[0001728949-21-000022:mdna:43]
In the first quarter of fiscal 2021, the United States Treasury Department issued final regulations on the foreign tax credit, which generally are applicable beginning in fiscal 2021, with certain provisions retroactive to fiscal 2019. As a result of these regulations, our fiscal 2021 estimated annual effective tax rate increased by approximately 1%. The retroactive impact resulting from these new regulations, which was related to fiscal 2019 and fiscal 2020 and recorded discretely in the first quarter of fiscal 2021, was not significant.

[0001728949-21-000022:mdna:44]
25

[0001728949-21-000022:mdna:45]
[same as prior period, unchanged from 0001728949-20-000057:mdna:79]

[0001728949-21-000022:mdna:46]
The following should be read in conjunction with our financial results for the first quarter of fiscal 2021 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0001728949-21-000022:mdna:47]
[same as prior period, unchanged from 0001728949-20-000057:mdna:81]

[0001728949-21-000022:mdna:48]
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  | Change |  |  |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets (1) | $ | 4,216 |  |  | $ | 2,352 |  |  | $ | 1,864 |  |  |  |  |  |  |  |
| RFFE (2) | 1,061 |  |  | 413 |  |  | 648 |  |  |  |  |  |  |  |
| Automotive (3) | 212 |  |  | 147 |  |  | 65 |  |  |  |  |  |  |  |
| IoT (4) | 1,044 |  |  | 706 |  |  | 338 |  |  |  |  |  |  |  |
| Total revenues | $ | 6,533 |  |  | $ | 3,618 |  |  | $ | 2,915 |  |  |  |  |  |  |  |
| EBT (5) | $ | 1,919 |  |  | $ | 479 |  |  | $ | 1,440 |  |  |  |  |  |  |  |
| EBT as a % of revenues | 29 | % |  | 13 | % |  | 16 | % |  |  |  |  |  |  |

[0001728949-21-000022:mdna:49]
(1) Includes revenues from products sold for use in mobile handsets, excluding RFFE (radio frequency front-end) components.

[0001728949-21-000022:mdna:50]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in handsets).

[0001728949-21-000022:mdna:51]
(3) Includes revenues from products sold for use in automobiles, including telematics, connectivity and digital cockpit.

[0001728949-21-000022:mdna:52]
(4) Internet of things (IoT) revenues primarily include products sold for use in cellular and non-cellular connected devices within the following industry segments or applications: consumer, computing, industrial, fixed wireless broadband, voice and music and wireless networking.

[0001728949-21-000022:mdna:53]
(5) Earnings (loss) before taxes.

[0001728949-21-000022:mdna:54]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $6.4 billion and $3.5 billion in the first quarter of fiscal 2021 and fiscal 2020, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our stand-alone Mobile Data Modems, Snapdragon platforms (which include processors and modems), radio frequency, power management and wireless connectivity integrated chipsets.

[0001728949-21-000022:mdna:55]
First quarter 2021 vs. 2020

[0001728949-21-000022:mdna:56]
The increase in QCT revenues in the first quarter of fiscal 2021 was primarily due to:

[0001728949-21-000022:mdna:57]
+    higher handsets revenues, primarily driven by $926 million in higher revenues per chipset and $899 million in higher chipset shipments, both of which are primarily due to an increase in demand for 5G products, a substantial portion of which is attributable to higher sales to Apple

[0001728949-21-000022:mdna:58]
+    higher RFFE revenues, primarily driven by an increase in demand for 5G products from Apple and other major OEMs

[0001728949-21-000022:mdna:59]
+    higher automotive revenues, primarily driven by an increase in demand for telematics products

[0001728949-21-000022:mdna:60]
+    higher IoT revenues, primarily driven by an increase in demand for connected devices due to the continued work and learn from home environment

[0001728949-21-000022:mdna:61]
QCT EBT as a percentage of revenues increased in the first quarter of fiscal 2021 primarily due to:

[0001728949-21-000022:mdna:62]
+    higher revenues

[0001728949-21-000022:mdna:63]
+    higher gross margin percentage, primarily driven by favorable mix from an increase in demand for 5G products

[0001728949-21-000022:mdna:64]
-    higher operating expenses, primarily driven by higher research and development costs

[0001728949-21-000022:mdna:65]
[same as prior period, unchanged from 0001728949-20-000057:mdna:101]

[0001728949-21-000022:mdna:66]
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  | Change |  |  |  |  |  |  |
| Licensing revenues | $ | 1,660 |  |  | $ | 1,404 |  |  | $ | 256 |  |  |  |  |  |  |  |
| EBT | 1,270 |  |  | 1,017 |  |  | 253 |  |  |  |  |  |  |  |
| EBT as a % of revenues | 77 | % |  | 72 | % |  | 5 | % |  |  |  |  |  |  |

[0001728949-21-000022:mdna:67]
As a result of the global patent license agreement entered into with Huawei in July 2020, QTL results for the first quarter of fiscal 2021 included revenues for royalties due on sales made by Huawei in the December 2020 quarter. We did not record any revenues in the first quarter of fiscal 2020 for royalties due on the sales of Huawei’s consumer wireless products.

[0001728949-21-000022:mdna:68]
First quarter 2021 vs. 2020

[0001728949-21-000022:mdna:69]
The increase in QTL licensing revenues in the first quarter of fiscal 2021 was primarily due to an increase in estimated sales of 3G/4G/5G-based multimode products from our key licensees (in part due to the new license agreement with Huawei), partially offset by the negative impact of COVID-19 and lower demand in China for licensees’ products that incorporate our intellectual property.

[0001728949-21-000022:mdna:70]
QTL EBT as a percentage of revenues increased in the first quarter of fiscal 2021 primarily due to higher revenues.

[0001728949-21-000022:mdna:71]
[same as prior period, unchanged from 0001728949-20-000057:mdna:122]

[0001728949-21-000022:mdna:72]
|  | Three Months Ended |  |  |
|  | December 27,2020 |  | December 29,2019 |  | Change |  |  |  |  |  |  |
| Equipment and services revenues | $ | 9 |  |  | $ | 20 |  |  | $ | (11) |  |  |  |  |  |  |  |
| EBT | 158 |  |  | (3) |  |  | 161 |  |  |  |  |  |  |  |

[0001728949-21-000022:mdna:73]
First quarter 2021 vs. 2020

[0001728949-21-000022:mdna:74]
The increase in QSI EBT in the first quarter of fiscal 2021 was primarily due to:

[0001728949-21-000022:mdna:75]
+     $88 million increase in net gains on investments, primarily driven by unrealized gains on marketable equity investments

[0001728949-21-000022:mdna:76]
+    $71 million decrease in impairment losses on non-marketable equity investments

[0001728949-21-000022:mdna:77]
[same as prior period, unchanged from 0001728949-20-000057:mdna:133]

[0001728949-21-000022:mdna:78]
In the coming years, we expect new consumer demand for 3G/4G/5G multimode and 5G products and services to ramp around the world as we transition from 3G/4G multimode and 4G products and services. We believe that 5G will drive growth and transformation in emerging device categories and industries that will create new business models and new services, resulting from the expanding adoption of certain technologies that are already commonly used in smartphones by industry segments or applications beyond mobile, such as automotive and IoT. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing of 5G technologies, and to be a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long-term.

[0001728949-21-000022:mdna:79]
As we look forward to the next several months and beyond, our business may be impacted by the following key items:

[0001728949-21-000022:mdna:80]
•The COVID-19 pandemic has resulted in significant economic uncertainty and has led to a global recession. While the pandemic has had a negative impact on consumer demand for some devices that incorporate our products and intellectual property, as compared to economic conditions and consumer demand prior to the pandemic, we currently do not expect a significant impact on our results of operations in the future. We have not experienced, and we currently do not anticipate a material adverse impact on our ability, or our suppliers’ ability, to manufacture and test our products or on our ability to provide our products to our customers due to the pandemic. Workforce changes that we implemented in fiscal 2020 are expected to remain in effect in the near term. The degree to which the COVID-19 pandemic impacts our business, financial condition and results of operations will depend on future developments, which are highly uncertain. See “Risk Factors” in this Quarterly Report, specifically the Risk Factor titled “The coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and may continue to impact us in the future.”

[0001728949-21-000022:mdna:81]
•In May 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the district court issued an Order ruling against us and imposing certain injunctive relief. On August 11, 2020, on appeal, the Ninth Circuit reversed the district court’s judgment, vacated its injunction and vacated its partial grant of summary

[0001728949-21-000022:mdna:82]
judgment. On September 25, 2020, the FTC filed a Petition for Rehearing En Banc. On October 28, 2020, the Ninth Circuit denied the FTC’s petition. Regulatory authorities in certain other jurisdictions are investigating and/or have investigated our business practices and instituted proceedings against us, and they or other regulatory authorities may do so in the future. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report, including the Risk Factors titled “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations” and “Our business may suffer as a result of adverse rulings in government investigations or proceedings.”

[0001728949-21-000022:mdna:83]
•We expect QCT revenues to continue to be favorably impacted compared to the prior year as we make shipments to support Apple’s iPhone products, as well as reflect increased demand for connected devices resulting from the continued work and learn from home environment.

[0001728949-21-000022:mdna:84]
•We have seen and expect to continue to see increased demand from certain Chinese OEMs as they position to gain device share, particularly in China. Since it will take time for us to adapt our supply chain process, and due to the limited supply capacity across the semiconductor industry, primarily at the leading node, we do not expect to realize the full benefit from this increased demand from OEMs.

[0001728949-21-000022:mdna:85]
•We expect commercial 5G network deployments and device launches will continue through calendar 2021 and beyond.

[0001728949-21-000022:mdna:86]
•We expect our research and development costs will increase, primarily due to increased investment towards advancements in 5G and application processor technologies and certain other long-term initiatives, as well as an increase in share-based compensation expense.

[0001728949-21-000022:mdna:87]
•We expect continued intense competition, particularly in China, as our competitors expand their product offerings and/or reduce the prices of their products as part of a strategy to attract new and/or retain existing customers.

[0001728949-21-000022:mdna:88]
•Current U.S./China trade relations and/or national security protection policies may negatively impact our business, growth prospects and results of operations. See “Risk Factors” in this Quarterly Report, including the Risk Factor titled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0001728949-21-000022:mdna:89]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless value chain and governments as to the benefits of our licensing program and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technologies and not welcome the success of our licensing program in enabling new, highly cost-effective competitors to their products. Accordingly, such companies, and/or governments or regulators, may continue to challenge our business model in various forums throughout the world.

[0001728949-21-000022:mdna:90]
[same as prior period, unchanged from 0001728949-20-000057:mdna:154]

[0001728949-21-000022:mdna:91]
[same as prior period, unchanged from 0001728949-20-000057:mdna:155]

[0001728949-21-000022:mdna:92]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at December 27, 2020 and September 27, 2020 and for the first three months of fiscal 2021 and 2020 (in millions):

[0001728949-21-000022:mdna:93]
|  | December 27,2020 |  | September 27,2020 |  | Change |  |  |
| Cash, cash equivalents and marketable securities | $ | 12,333 |  |  | $ | 11,249 |  |  | $ | 1,084 |  |  |  |
| Accounts receivable, net | 4,148 |  |  | 4,003 |  |  | 145 |  |  |  |
| Inventories | 2,552 |  |  | 2,598 |  |  | (46) |  |  |  |
| Short-term debt | 500 |  |  | 500 |  |  | — |  |  |  |
| Long-term debt | 15,231 |  |  | 15,226 |  |  | 5 |  |  |  |
| Noncurrent income taxes payable | 1,855 |  |  | 1,872 |  |  | (17) |  |  |  |

[0001728949-21-000022:mdna:94]
28

[0001728949-21-000022:mdna:95]
|  | Three Months Ended |
|  | December 27,2020 |  | December 29,2019 |  | Change |  |  |
| Net cash provided by operating activities | $ | 3,175 |  |  | $ | 1,118 |  |  | $ | 2,057 |  |  |  |
| Net cash used by investing activities | (1,202) |  |  | (203) |  |  | (999) |  |  |  |
| Net cash used by financing activities | (1,645) |  |  | (1,659) |  |  | 14 |  |  |  |

[0001728949-21-000022:mdna:96]
The net increase in cash, cash equivalents and marketable securities was primarily due to net cash provided by operating activities, partially offset by $739 million in cash dividends paid, $469 million in capital expenditures, $449 million in payments of tax withholdings related to the vesting of share-based awards and $444 million in payments to repurchase shares of our common stock.

[0001728949-21-000022:mdna:97]
The increase in accounts receivable was primarily due to an increase in QCT revenues, partially offset by timing of QCT integrated circuit shipments during the quarter. Accounts receivable from Huawei related to the remaining amounts due under the previously disclosed settlement agreement remained unchanged during the first three months of fiscal 2021 as Huawei paid the second installment of $500 million (excluding the impact of foreign withholding taxes) subsequent to December 27, 2020 in accordance with the agreed upon payment schedule.

[0001728949-21-000022:mdna:98]
Debt. At December 27, 2020, we had $15.5 billion of principal floating- and fixed-rate notes outstanding. Our remaining debt has maturity dates in 2022 through 2050.

[0001728949-21-000022:mdna:99]
We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At December 27, 2020, we had $500 million of commercial paper outstanding.

[0001728949-21-000022:mdna:100]
On December 8, 2020, we entered into a Revolving Credit Facility replacing our prior Amended and Restated Revolving Credit Facility. There were no outstanding borrowings under the Amended and Restated Revolving Credit Facility at the time of termination. The Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At December 27, 2020, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-21-000022:mdna:101]
We may issue new debt in the future. COVID-19 has led to disruption and volatility in the global capital markets, which may adversely impact the cost of and access to capital. The amount and timing of additional borrowings, if any, will depend on a number of factors, including but not limited to maturities of our existing debt, acquisitions and strategic investments, favorable and/or acceptable interest rates and changes in corporate income tax law. Additional information regarding our outstanding debt is provided in “Notes to Consolidated Financial Statements, Note 6. Debt” in our 2020 Annual Report on Form 10-K.

[0001728949-21-000022:mdna:102]
Income Taxes. At December 27, 2020, we estimated remaining future payments of $2.0 billion for the one-time U.S. repatriation tax accrued in fiscal 2018 (Toll Charge), after application of certain tax credits, which is payable in installments over the next six years. At December 27, 2020, other current liabilities included $177 million, reflecting the installment paid in January 2021. We estimate the next installment due in January 2022 to be $189 million. Additional information regarding our income taxes is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes.”

[0001728949-21-000022:mdna:103]
Capital Return Program. In fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. The stock repurchase program has no expiration date. In the first quarter of fiscal 2021, we resumed stock repurchases under the stock repurchase program, which we had suspended in the third quarter of fiscal 2020 in light of the COVID-19 pandemic, and we repurchased and retired 3 million shares of our common stock for $444 million, before commissions. At December 27, 2020, $4.2 billion remained authorized for repurchase under the stock repurchase program. Since December 27, 2020, we repurchased and retired 2 million shares of common stock for $311 million. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-21-000022:mdna:104]
In the first quarter of fiscal 2021, we paid cash dividends totaling $739 million, or $0.65 per share. On January 20, 2021, we announced a cash dividend of $0.65 per share on our common stock, payable on March 25, 2021 to stockholders of record as of the close of business on March 4, 2021. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability, which may be impacted by COVID-19, and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-21-000022:mdna:105]
[same as prior period, unchanged from 0001728949-20-000057:mdna:137]

[0001728949-21-000022:mdna:106]
Acquisitions. In January 2021, we announced that we entered into a definitive agreement to acquire NUVIA for approximately $1.4 billion before working capital and other adjustments, a substantial portion of which will be paid in cash and the remaining amount of which relates to unvested NUVIA equity awards that will be assumed or replaced in connection with the acquisition and will be recognized as compensation expense over the related post-acquisition service vesting period. The acquisition has been approved by the requisite number of NUVIA’s stockholders and is subject to receipt of regulatory approval in the United States and other customary closing conditions. We expect to use existing cash resources to fund the acquisition, which is expected to close in the second quarter of fiscal 2021.

[0001728949-21-000022:mdna:107]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2020 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At December 27, 2020, other than changes disclosed in the “Notes to Condensed Consolidated Financial Statements” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no material changes to our expected working and other capital requirements or contractual obligations described in our 2020 Annual Report on Form 10-K.

[0001728949-21-000022:mdna:108]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees, have pursued, and others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0001728949-21-000022:mdna:109]
We believe, based on our current business plan and the facts and factors known by us, our cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months and thereafter for the foreseeable future. See “Risk Factors” in this Quarterly Report, including the Risk Factor titled “The coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and may continue to impact us in the future.”

[0001728949-21-000022:mdna:110]
[same as prior period, unchanged from 0001728949-20-000057:mdna:176]

[0001728949-21-000022:mdna:111]
Information regarding recent accounting guidance and the impact of such guidance on our condensed consolidated financial statements is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 1. Basis of Presentation and Significant Accounting Policies Update.”

[0001728949-21-000022:mdna:112]
[same as prior period, unchanged from 0001728949-20-000057:mdna:179]

[0001728949-21-000022:mdna:113]
You should consider each of the following factors in evaluating our business and our prospects. However, the risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also negatively impact our business, results of operations, cash flows and financial condition, and require significant management time and attention. In that case, the trading price of our common stock could decline. In addition to the risks and uncertainties set forth in the Risk Factor below titled “The coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and may continue to impact us in the future,” many of the risks and uncertainties set forth in the other Risk Factors below are exacerbated by the COVID-19 pandemic, government and business responses thereto and any further resulting decline in the global business and economic environment, and may be impacted by the extent and speed of the global economic recovery. You should also consider the other information set forth in this Quarterly Report in evaluating our business and our prospects, including but not limited to our financial statements and the related notes, and “Part I, Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” References to “and,” “or” and “and/or” should be read to include the others, as appropriate.

[0001728949-21-000022:mdna:114]
RISKS RELATED TO THE CORONAVIRUS (COVID-19) PANDEMIC

[0001728949-21-000022:mdna:115]
The coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and may continue to impact us in the future.

[0001728949-21-000022:mdna:116]
The rapid, global spread of COVID-19 and the fear it has created has resulted in significant economic uncertainty, significant declines in business and consumer confidence and global demand in the wireless industry (among others), a global economic slowdown, and has led to a global recession. Specifically, the decline in demand for smartphones and other consumer devices sold by our customers or licensees has resulted in decreased demand for our integrated circuit products (which are incorporated into such devices) and a decrease in the royalties we earn on the licensing of our intellectual property

[0001728949-21-000022:mdna:117]
[same as prior period, unchanged from 0001728949-20-000057:mdna:144]

[0001728949-21-000022:mdna:118]
(which is dependent upon the number of such devices sold that utilize our intellectual property). However, we currently do not expect a significant impact on our results of operations in the future.

[0001728949-21-000022:mdna:119]
Further, while to date we have not seen a significant impact on our manufacturing facilities or our supply chain, the ability of our suppliers to deliver on their commitments to us, or our ability to ship our products to our customers, may be negatively impacted by the pandemic and/or government responses thereto, such as travel bans and restrictions, quarantines, shelter-in-place and social distancing orders, declarations of states of emergency and shutdowns.

[0001728949-21-000022:mdna:120]
Although the spread of COVID-19 has caused us to modify our workforce practices, such as having the vast majority of our employees working from home, we have not experienced a significant negative impact to our business or results of operations. However, we could be negatively affected in the future if, among others, a significant number of our employees, or employees who perform critical functions, become ill and/or are quarantined as the result of exposure to COVID-19, or if government policies restrict the ability of those employees to perform their critical functions.

[0001728949-21-000022:mdna:121]
The COVID-19 pandemic could also impact our business, results of operations and financial condition through delayed, reduced or cancelled customer orders; the inability of our customers or licensees to purchase or pay for our products or technologies; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our customers or licensees; or failures by other counterparties. Additionally, state or federal governments may in the future increase corporate tax rates, increase employer payroll tax obligations and/or otherwise change tax laws to pay for stimulus and other actions that may be taken as a result of COVID-19.

[0001728949-21-000022:mdna:122]
The degree to which the COVID-19 pandemic impacts our future business, results of operations and financial condition will depend on future developments, which are uncertain, including but not limited to the duration, spread and severity of the pandemic, government responses and other actions to mitigate the spread of and to treat COVID-19, and when and to what extent normal business, economic and social activity and conditions resume. We are similarly unable to predict the extent to which the pandemic impacts our customers, licensees, suppliers and other partners and their financial conditions, but adverse effects on these parties could also adversely affect us. Finally, the COVID-19 pandemic makes it challenging for management to estimate the future performance of our business.

[0001728949-21-000022:mdna:123]
RISKS RELATED TO INDUSTRY DYNAMICS AND COMPETITION

[0001728949-21-000022:mdna:124]
Our revenues depend on our customers’ and licensees’ sales of products and services based on CDMA, OFDMA and other communications technologies, including 5G, and customer demand for our products based on these technologies.

[0001728949-21-000022:mdna:125]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on our customers and licensees to develop devices and services based on these technologies with value-added features to drive consumer demand for new 3G/4G and 3G/4G/5G multimode devices, as well as 3G and 4G single-mode devices, and to establish the selling prices for such devices. Further, the timing of our shipment of our products is dependent on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries and applications beyond mobile, such as automotive and IoT, among others.

[0001728949-21-000022:mdna:126]
We have historically been successful during wireless technology transitions, including 3G, 4G and now 5G. Commercial deployments of 5G networks and devices have begun and will continue. However, the timing and scale of such deployments, in certain regions, have been and may in the future be delayed due to the COVID-19 pandemic.

[0001728949-21-000022:mdna:127]
We believe it is critical that we remain a leader in 5G technology development, standardization, intellectual property creation and technology licensing, and that we develop, commercialize and be a leading supplier of 5G integrated circuit products, in order to sustain and grow our business long-term.

[0001728949-21-000022:mdna:128]
Our revenues and growth in revenues could be negatively impacted, our business may be harmed and our substantial investments in these technologies may not provide us an adequate return if: our customers’ and licensees’ revenues and sales of products, particularly premium-tier products, and services using these technologies, and average selling prices of such products, decline due to, for example, the maturity of smartphone penetration in developed regions and China; our intellectual property and technical leadership included in the continued 5G standardization effort is less than in 3G and 4G standards; we are unable to drive the adoption of our products into networks and devices, including devices beyond mobile; or consumers’ rates of replacement of smartphones and other computing devices decline.

[0001728949-21-000022:mdna:129]
Our industry is subject to intense competition in an environment of rapid technological change. Our success depends in part on our ability to adapt to such change and compete effectively; and such change and competition could result in decreased demand for our products and technologies or declining average selling prices for our products or those of our customers or licensees.

[0001728949-21-000022:mdna:130]
Our products and technologies face significant competition. We expect competition to increase as our current competitors expand their product offerings, improve their products or reduce the prices of their products as part of a strategy to maintain existing business and customers or attract new business and customers, as new opportunities develop, and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: OEM concentrations; vertical integration; competition in certain geographic regions; government intervention or support of national industries or competitors; the ability to maintain product differentiation as the result of evolving industry standards and speed of technological change (including the transition to smaller geometry process technologies and the demand for always on, always connected capabilities); and value-added features that drive selling prices and consumer demand for new 3G/4G and 3G/4G/5G multimode devices, as well as 3G and 4G single-mode devices.

[0001728949-21-000022:mdna:131]
We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, and technological and public policy changes. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape. For example, if any key supplier of technologies and intellectual property to the semiconductor industry was sold to one of our competitors, it could negatively affect our ability to procure or license such technologies and intellectual property in the future, which could have wide-ranging impacts on our business and operations.

[0001728949-21-000022:mdna:132]
[same as prior period, unchanged from 0001728949-20-000057:mdna:212]

[0001728949-21-000022:mdna:133]
•differentiate our integrated circuit products with innovative technologies across multiple products and features (e.g., modem, radio frequency front-end (RFFE), including mmWave, graphics and other processors, camera and connectivity) and with smaller geometry process technologies that drive both performance and lower power consumption;

[0001728949-21-000022:mdna:134]
[same as prior period, unchanged from 0001728949-20-000057:mdna:214]

[0001728949-21-000022:mdna:135]
•continue to be a leader in mobile, and drive the adoption of our technologies and integrated circuit products, including RFFE, into the most popular device models and across a broad spectrum of devices in mobile, such as smartphones, tablets, laptops and other mobile computing devices;

[0001728949-21-000022:mdna:136]
•increase or accelerate adoption of our technologies and products in industry segments or applications outside of mobile, including automotive and IoT;

[0001728949-21-000022:mdna:137]
•maintain or accelerate demand for our integrated circuit products at the premium device tier, while also driving the adoption of our products into high, mid- and low-tier devices across all regions;

[0001728949-21-000022:mdna:138]
•remain a leader in 5G (and 4G) technology development, standardization, intellectual property creation and licensing, and develop, commercialize and remain a leading supplier of 5G (and 4G) integrated circuit products, including RFFE products;

[0001728949-21-000022:mdna:139]
•create standalone value and contribute to the success of our existing businesses through acquisitions, joint ventures and other transactions, and by developing customer, licensee, vendor, distributor and other channel relationships in new industry segments or applications and with disruptive technologies and products;

[0001728949-21-000022:mdna:140]
[same as prior period, unchanged from 0001728949-20-000057:mdna:222]

[0001728949-21-000022:mdna:141]
•provide leading products and technologies to OEMs, high level operating systems (HLOS) providers, operators, cloud providers and other industry participants as competitors, new industry entrants and other factors continue to affect the industry landscape;

[0001728949-21-000022:mdna:142]
[same as prior period, unchanged from 0001728949-20-000057:mdna:224]

[0001728949-21-000022:mdna:143]
[same as prior period, unchanged from 0001728949-20-000057:mdna:225]

[0001728949-21-000022:mdna:144]
We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application, industry segment or standard product, including those that produce products for mobile, automotive and IoT, among others. Most of these competitors compete with us with respect to some, but not all, of our businesses. Companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom, HiSilicon, MediaTek, Nvidia, NXP Semiconductors, Qorvo, Samsung, Skyworks, Texas Instruments and UNISOC (formally known as Spreadtrum Communications). Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to use our competitors’ integrated circuit products, to utilize their own internally-developed integrated circuit products, or sell such products to others, or to utilize alternative technologies; lower cost structures or a willingness and ability to accept lower prices or lower margins for their products, particularly in China; foreign government support of other technologies, competitors or OEMs that sell devices that do not contain our integrated circuit products; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and OEMs in certain geographic regions (such as China); more experience in adjacent industry segments or applications beyond mobile (such as automotive and IoT); and a more established presence in certain regions.

[0001728949-21-000022:mdna:145]
In addition, certain of our largest integrated circuit customers have in the past utilized, currently utilize and may in the future utilize our competitors’ integrated circuit products in some (or all) of their devices, rather than our products. Further, certain of those customers have developed, are developing or may develop their own integrated circuit products (effectively making them competitors), which they have in the past utilized, currently utilize and may in the future utilize in some (or all) of their devices, rather than our products. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).” Further, political actions, including trade and/or national security protection policies, or other actions by governments, particularly the U.S. and Chinese governments, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our customers or suppliers, limit, prevent or discourage certain of our customers or suppliers from transacting business with us, or make it more expensive to do so. This could advantage our competitors by enabling them with increased sales, economies of scale, operating income and/or cash flows and/or enable critical technology transfer, allowing them to increase their investments in technology development, research and development and commercialization of products. See also the Risk Factor titled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.” Further, certain of our competitors develop and sell multiple components (including integrated circuit products) for use in devices and sell those components together to OEMs. Our competitors’ sales of multiple components put us (and our discrete integrated circuit products) at a competitive disadvantage. Certain of our competitors also develop and sell infrastructure equipment for wireless networks and can optimize their integrated circuit products to perform on such networks to a degree that we are not able to, which again puts us at a competitive disadvantage.

[0001728949-21-000022:mdna:146]
Competition in any or all product tiers may result in the loss of business or customers, which would negatively impact our business, revenues, results of operations, cash flows and financial condition. Such competition may also reduce average selling prices for our chipset products or the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging regions and China where competitors may have lower cost structures or may have a willingness and ability to accept lower prices or lower margins on their products. Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0001728949-21-000022:mdna:147]
RISKS RELATED TO OUR OPERATING BUSINESSES

[0001728949-21-000022:mdna:148]
We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected.

[0001728949-21-000022:mdna:149]
We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. Chinese OEMs continue to grow their device share in China and are increasing their device share in

[0001728949-21-000022:mdna:150]
regions outside of China, and we derive a significant portion of our revenues from a small number of these OEMs as well. See also “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Concentrations.”

[0001728949-21-000022:mdna:151]
In addition, a number of our largest integrated circuit customers have developed, are developing or may develop their own integrated circuit products, or may choose our competitors’ integrated circuit products, which they have in the past utilized, currently utilize and may in the future utilize in some (or all) of their devices, rather than our products, which could significantly reduce the revenues we derive from these customers. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0001728949-21-000022:mdna:152]
Further, political actions, including trade and/or national security protection policies, or other actions by governments, particularly the U.S. and Chinese governments, have in the past and could in the future limit or prevent us from transacting business with some of our largest customers, limit, prevent or discourage those customers from transacting business with us, or make it more expensive to do so, any of which could also significantly reduce the revenues we derive from these customers. See also the Risk Factor titled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0001728949-21-000022:mdna:153]
[same as prior period, unchanged from 0001728949-20-000057:mdna:239]

[0001728949-21-000022:mdna:154]
The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or the cancelation of significant purchases by any of these customers, whether due to the use of their own integrated circuit products or our competitors’ integrated circuit products, government restrictions, the COVID-19 pandemic or otherwise, would reduce our revenues and could harm our ability to achieve or sustain expected results of operations, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0001728949-21-000022:mdna:155]
Further, the concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have no control, and the timing and success of such introductions may cause our revenues and results of operations to fluctuate.

[0001728949-21-000022:mdna:156]
Apple purchases our MDM (or thin modem) products, which do not include our integrated application processor technology, and which have lower revenue and margin contributions than our combined modem and application processor products. Further, to the extent Apple takes device share from our customers who purchase our integrated modem and application processor products, our revenues and margins may be negatively impacted.

[0001728949-21-000022:mdna:157]
Our industry has also experienced, and we expect it will continue to experience, slowing growth in the premium-tier device segment due to, among other factors, lengthening replacement cycles in developed regions, where premium-tier smartphones are common; increasing consumer demand in emerging regions where premium-tier smartphones are less common and replacement cycles are on average longer than in developed regions and are continuing to lengthen; and a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and innovation cycles.

[0001728949-21-000022:mdna:158]
A reduction in sales of premium-tier devices, a reduction in sales of our premium-tier integrated circuit products (which have a higher revenue and margin contribution than our lower-tier integrated circuit products), or a shift in share away from OEMs that utilize our premium-tier products, would reduce our revenues and margins and may harm our ability to achieve or sustain expected financial results. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0001728949-21-000022:mdna:159]
Although we have more than 300 licensees, we derive a significant portion of our licensing revenues from a limited number of licensees, which includes a number of Chinese OEMs. In the event that one or more of our significant licensees fail to meet their reporting and payment obligations, or we are unable to renew or modify one or more of their license agreements under similar terms as their existing agreements, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability

[0001728949-21-000022:mdna:160]
34

[0001728949-21-000022:mdna:161]
of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We do not have control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in sales of our licensees’ products, or reductions in the average selling prices of wireless devices sold by our licensees without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues. Such adverse impact may be mitigated by our per unit royalty caps that apply to certain categories of our licensees’ complete wireless devices, namely smartphones, tablets, laptops and smartwatches.

[0001728949-21-000022:mdna:162]
Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).

[0001728949-21-000022:mdna:163]
Certain of our largest integrated circuit customers (for example, Samsung) develop their own integrated circuit products, which they have in the past utilized, and currently utilize, in certain of their devices and may in the future utilize in some (or all) of their devices, rather than our products (and they have and may continue to sell their integrated circuit products to third parties, discretely or together with certain of their other products, in competition with us).

[0001728949-21-000022:mdna:164]
Apple has utilized modem products of one of our competitors in some of its devices rather than our products, and solely utilized one of our competitors’ products in several of its prior device launches. In April 2019, we entered into a new multi-year chipset supply agreement with Apple and began shipping modems under this agreement in the third quarter of fiscal 2020. In December 2019, Apple acquired Intel’s modem assets and is developing its own modem products using these assets. Accordingly, Apple is expected to use its own modem products, rather than our products, in some (or all) of its future devices.

[0001728949-21-000022:mdna:165]
Similarly, we derive a significant portion of our revenues from Chinese OEMs. Certain of our customers in China have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products in their devices rather than our integrated circuit products, including due to pressure from or policies of the Chinese government (whose Made in China 2025 campaign targets 70% semiconductor self-sufficiency by 2025), concerns over losing access to our integrated circuit products as a result of actual, threatened or potential U.S. or Chinese government actions or policies, including trade protection or national security policies, or other reasons.

[0001728949-21-000022:mdna:166]
If some or all of our largest customers and/or the largest smartphone OEMs utilize their own integrated circuit/modem products in some (or all) of their devices rather than our products, our business, revenues, results of operations, cash flows and financial position could be materially adversely impacted. See also the Risk Factor titled “We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected.”

[0001728949-21-000022:mdna:167]
A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.

[0001728949-21-000022:mdna:168]
We derive a significant portion of our revenues from Chinese OEMs, and from non-Chinese OEMs that utilize our integrated circuit products in their devices and sell those devices into China, which has the largest number of smartphone users in the world. We also source certain critical integrated circuit products from suppliers in China.

[0001728949-21-000022:mdna:169]
Due to various factors, including pressure, encouragement or incentives from, or policies of, the Chinese government (including its Made in China 2025 campaign), concerns over losing access to our integrated circuit products as a result of actual, threatened or potential U.S. or Chinese government actions or policies, including trade protection or national security policies, or other reasons, some of our Chinese integrated circuit customers have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products in their devices, or use our competitors’ integrated circuit products in their devices, rather than our products.

[0001728949-21-000022:mdna:170]
Political actions, including trade protection and national security policies of the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our Chinese customers or suppliers, limit, prevent or discourage certain of our Chinese customers or suppliers from transacting business with us, or make it more expensive to do so. Given our revenue concentration in China, if, due to actual, threatened or potential U.S. or Chinese government actions or policies, we were further limited in, or prohibited from, selling our integrated circuit products to Chinese OEMs; if our non-Chinese OEM customers were limited in, or prohibited from, selling devices into China that incorporate our integrated circuit products; if Chinese OEMs develop and use their own integrated circuit products or use our competitors’ integrated circuit products in some (or all) of their devices rather than our integrated circuit products; if Chinese tariffs on our integrated circuit products or on devices which incorporate our integrated circuit products made purchasing such products or devices more expensive to Chinese OEMs or Chinese consumers; or if our Chinese licensees delay or cease making payments of license fees they owe

[0001728949-21-000022:mdna:171]
us, our business, revenues, results of operations, cash flows and financial position could be materially harmed. Similarly, if, due to U.S. or Chinese government actions or policies, we were limited in or prohibited from obtaining critical integrated circuit products from our suppliers in China, our business, revenues, results of operations, cash flows and financial position could be materially harmed.

[0001728949-21-000022:mdna:172]
Finally, government policies in China that regulate the amount and timing of funds that may flow out of the country have impacted and may continue to impact the timing of our receipt of, and/or ability to receive, payments from our customers and licensees in China, which may negatively impact our cash flows.

[0001728949-21-000022:mdna:173]
RISKS SPECIFIC TO OUR LICENSING BUSINESS

[0001728949-21-000022:mdna:174]
Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.

[0001728949-21-000022:mdna:175]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, alleging that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) attempts by licensees to shift their royalty obligation to their suppliers in order to lower the wholesale (i.e., licensee’s) selling price on which the royalty is calculated.

[0001728949-21-000022:mdna:176]
In addition, certain licensees have disputed, underreported, underpaid, not reported or not paid royalties owed to us under their license agreements or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or have delayed entering into or renewing license agreements with us for their use of our intellectual property, and they or others may engage in such behavior in the future. The fact that one or more licensees dispute, underreport, underpay, do not report or do not pay royalties owed to us may encourage other licensees to take similar actions or not renew their existing license agreements, and may encourage other licensees or unlicensed companies to delay entering into, or to not enter into, new license agreements. Further, to the extent such licensees and companies increase their device share, the negative impact of their underreporting, underpayment, non-payment or non-reporting on our business, revenues, results of operations, cash flows and financial condition will be exacerbated.

[0001728949-21-000022:mdna:177]
We have been in the past and are currently subject to various litigation and governmental investigations and proceedings. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. See also the Risk Factors below titled “Our business may suffer as a result of adverse rulings in government investigations or proceedings” and “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations.”

[0001728949-21-000022:mdna:178]
[same as prior period, unchanged from 0001728949-20-000057:mdna:255]

[0001728949-21-000022:mdna:179]
Further, some third parties have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any

[0001728949-21-000022:mdna:180]
product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions should not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by severely limiting the base upon which the royalty rate may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies.

[0001728949-21-000022:mdna:181]
Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party. Further, SDOs in certain countries may attempt to modify widely accepted standards and claim the resulting standard as their own.

[0001728949-21-000022:mdna:182]
We expect that such proposals, interpretations and strategies will continue in the future, and if successful, our business model would be harmed, either by limiting or eliminating our ability to collect royalties (or by reducing the royalties we can collect) on all or a portion of our standard-essential patent portfolio, limiting our return on investment with respect to new technologies, limiting our ability to seek injunctions against infringers of our standard-essential patents, constraining our ability to make licensing commitments when submitting our technologies for inclusion in future standards (which could make our technologies less likely to be included in such standards) or forcing us to work outside of SDOs or other industry groups to promote our new technologies, and our revenues, results of operations and cash flows could be negatively impacted. In addition, the legal and other costs associated with asserting or defending our positions have been and continue to be significant. We expect that such challenges, regardless of their merits, will continue into the foreseeable future and will require the investment of substantial management time and financial resources.

[0001728949-21-000022:mdna:183]
Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations.

[0001728949-21-000022:mdna:184]
As described in the Risk Factor “Our business may suffer as a result of adverse rulings in government investigations or proceedings” below, we have been in the past and are currently subject to various governmental investigations and proceedings, as well as private legal proceedings, challenging our patent licensing and chipset sales practices. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We believe that one intent of certain of these investigations and legal proceedings has been to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-21-000022:mdna:185]
[same as prior period, unchanged from 0001728949-20-000057:mdna:269]

[0001728949-21-000022:mdna:186]
If we were required to grant patent licenses to chipset manufacturers (which could lead to implementing a more complex, multi-level licensing structure in which we license certain portions of our patent portfolio to chipset manufacturers and other portions to OEMs), we would incur additional transaction costs, which may be significant, and we could incur delays in recognizing revenues until license negotiations were completed. In addition, our licensing revenues and earnings would be negatively impacted if we were not able to obtain, in the aggregate, equivalent revenues under such a multi-level licensing structure.

[0001728949-21-000022:mdna:187]
If we were required to sell chipsets to OEMs that do not have a license to our patents, our licensing program could be negatively impacted by patent exhaustion claims raised by such unlicensed OEMs (i.e., claims that our sale of chipsets to such OEMs forecloses us from asserting any patents substantially embodied by the chipsets against such OEMs). Such sales would provide OEMs with a defense in the event we asserted our patents against them to obtain licensing revenue for those patents. This could have a material adverse effect on our licensing program and our results of operations, cash flows and financial condition.

[0001728949-21-000022:mdna:188]
To the extent that we were required to implement any of these new licensing and/or business practices, including by modifying or renegotiating our existing license agreements or pursuing other commercial arrangements, we would incur additional transaction costs, which may be significant, we could incur delays in recognizing revenues until license negotiations were completed, and our business, revenues, results of operations, cash flows and financial condition could be harmed. The impact of any such changes to our licensing practices could vary widely and by jurisdiction, depending on the

[0001728949-21-000022:mdna:189]
specific outcomes and the geographic scope of such outcomes. In addition, if we were required to make modifications to our licensing practices in one jurisdiction, licensees or governmental agencies in other jurisdictions may attempt to obtain similar outcomes for themselves or for such other jurisdictions, as applicable.

[0001728949-21-000022:mdna:190]
The continued and future success of our licensing programs requires us to continue to evolve our patent portfolio and to renew or renegotiate license agreements that are expiring or to cover additional future patents.

[0001728949-21-000022:mdna:191]
[same as prior period, unchanged from 0001728949-20-000057:mdna:289]

[0001728949-21-000022:mdna:192]
Further, the licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, our patent license agreements in effect that constitute a significant portion of our licensing revenues are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of the specified term, and to receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms and may impact the financial or other terms of license agreements not subject to the litigation or arbitration. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001728949-21-000022:mdna:193]
RISKS RELATED TO REGULATORY AND LEGAL CHALLENGES

[0001728949-21-000022:mdna:194]
Our business may suffer as a result of adverse rulings in government investigations or proceedings.

[0001728949-21-000022:mdna:195]
We have been in the past and are currently subject to various governmental investigations and proceedings. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Key allegations or findings in those matters include, among others, that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers; that our royalty rates are too high; that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions); that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets; that we have entered into exclusive agreements with chipset customers that foreclose competition; that we leverage our position in baseband chipsets in the RFFE space; and that we violate antitrust laws, engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-21-000022:mdna:196]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any licensing or royalty revenues under such agreements. The renegotiation of license agreements could result in terms which are less favorable to us than existing terms, or lead to arbitration or litigation to resolve the licensing terms, which could also be less favorable to us than existing terms, and each of which could take months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. The occurrence of any of the above could have a material adverse effect on our business, revenues, results

[0001728949-21-000022:mdna:197]
of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies such as 5G. Further, depending on the breadth and severity of the circumstances above, we may have to reduce, suspend or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region.

[0001728949-21-000022:mdna:198]
These challenges have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in significant legal costs until the respective matters are resolved.

[0001728949-21-000022:mdna:199]
RISKS RELATED TO SUPPLY AND MANUFACTURING

[0001728949-21-000022:mdna:200]
We depend on a limited number of third-party suppliers for the procurement, manufacture and testing of our products manufactured in a fabless production model. If we fail to execute supply strategies that provide supply assurance, technology leadership and reasonable margins, our business and results of operations may be harmed. We are also subject to order and shipment uncertainties that could negatively impact our results of operations.

[0001728949-21-000022:mdna:201]
We primarily utilize a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Other than the facilities we own that manufacture certain of our RFFE modules and RF filter products, we rely on third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. There are a limited number of such third-party suppliers, and even fewer who are capable of manufacturing at the leading process technology nodes. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Under the turnkey model, our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services such as wafer bump, probe, assembly and the majority of our final test requirements. The semiconductor manufacturing foundries that supply our products are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders.

[0001728949-21-000022:mdna:202]
[same as prior period, unchanged from 0001728949-20-000057:mdna:295]

[0001728949-21-000022:mdna:203]
[same as prior period, unchanged from 0001728949-20-000057:mdna:296]

[0001728949-21-000022:mdna:204]
•a failure by our suppliers to procure raw materials or allocate adequate raw materials for our products;

[0001728949-21-000022:mdna:205]
•an inability to procure or utilize raw materials, components or products from our suppliers due to government prohibitions or restrictions on transactions with certain countries and/or companies, and alternative suppliers, raw material sources or raw materials are not available or not available in acceptable time frames or upon acceptable terms;

[0001728949-21-000022:mdna:206]
•a failure by our suppliers to allocate adequate manufacturing or test capacity for our products;

[0001728949-21-000022:mdna:207]
[same as prior period, unchanged from 0001728949-20-000057:mdna:298]

[0001728949-21-000022:mdna:208]
•our suppliers’ inability to develop or maintain, or a delay in developing or building out manufacturing capacity for leading process technologies, including transitions to smaller geometry process technologies;

[0001728949-21-000022:mdna:209]
[same as prior period, unchanged from 0001728949-20-000057:mdna:300]

[0001728949-21-000022:mdna:210]
[same as prior period, unchanged from 0001728949-20-000057:mdna:301]

[0001728949-21-000022:mdna:211]
•natural disasters or geopolitical conflicts impacting our suppliers;

[0001728949-21-000022:mdna:212]
•health crises, including epidemics or pandemics, such as the COVID-19 pandemic, and government and business responses thereto, which impact our suppliers, including as a result of quarantines or closure; and

[0001728949-21-000022:mdna:213]
•trade or national security protection policies, particularly U.S. or Chinese government policies, that limit or prevent us from transacting business with suppliers of critical integrated circuit products, or that limit or prevent such

[0001728949-21-000022:mdna:214]
39

[0001728949-21-000022:mdna:215]
suppliers from transacting business with us or from procuring materials, machinery or technology necessary to manufacture goods for us.

[0001728949-21-000022:mdna:216]
While we have established alternate suppliers for certain technologies, there are a limited number of such suppliers, and even fewer who are capable of operating at the leading process technology nodes or who are willing to operate at older process technology nodes. We rely on sole- or limited-source suppliers for certain products, which may exacerbate the risks identified above, and subject us to other significant risks, including: poor product performance and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established alternate suppliers, these suppliers may require significant amounts of time and levels of support to bring such technologies to production, both of which may increase for complex or leading process technologies. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, the elimination or limitation of a foundry supplier’s ability to manufacture components or products for us due to trade or national security protection policies could increase our vulnerability to sole- or limited-source arrangements and limit or prevent us from procuring critical components or products from those suppliers. Future consolidation of foundry suppliers could also increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions, increase our manufacturing costs and limit the amount of capacity available to us. Our arrangements with our suppliers may obligate us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies (which adds risk to manufacturing yields and reliability), and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Any of the above could negatively impact our business, results of operations and cash flows.

[0001728949-21-000022:mdna:217]
Although we have long-term contracts with our suppliers, most of these contracts do not provide for long-term capacity commitments. To the extent we do not have firm commitments from our suppliers over a specific time period or for any specific quantity, our suppliers may allocate, and in the past have allocated, capacity to the production and testing of products for their other customers while reducing or limiting capacity to manufacture or test our products, and such capacity may be limited based on our suppliers’ ability and willingness to invest in the capital required to manufacture in the leading process technologies. Accordingly, capacity for our products may not be available when we need it or at reasonable prices. To the extent we do obtain long-term capacity commitments, we may incur additional costs related to those commitments or make non-refundable payments for capacity commitments that are not used.

[0001728949-21-000022:mdna:218]
[same as prior period, unchanged from 0001728949-20-000057:mdna:309]

[0001728949-21-000022:mdna:219]
[same as prior period, unchanged from 0001728949-20-000057:mdna:310]

[0001728949-21-000022:mdna:220]
Additionally, we place orders with our suppliers using our and our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates. As we move to smaller geometry process technologies, the manufacturing lead-time increases. As a result, the orders we place with our suppliers are generally only partially covered by commitments from our customers. If we, or our customers, overestimate demand, or if demand is impacted by factors outside of our or our customers’ control, such as the COVID-19 pandemic, that is not under a binding commitment from our customers, we may experience increased excess or obsolete inventory, which would negatively impact our results of operations.

[0001728949-21-000022:mdna:221]
There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model, environmental compliance and liability, impacts related to climate change, exposure to natural disasters, timely supply of equipment and materials, and various manufacturing issues.

[0001728949-21-000022:mdna:222]
We own and operate various facilities that manufacture certain of our RFFE modules and RF filter products. Manufacturing facilities are characterized by a higher portion of fixed costs relative to a fabless model. We may be faced with a decline in the utilization rates of our manufacturing facilities due to decreases in demand for our products, including in less favorable industry environments, or due to our failure to win and/or retain designs with OEMs. During such periods, our

[0001728949-21-000022:mdna:223]
manufacturing facilities could operate at lower capacity levels, while the fixed costs associated with such facilities would continue to be incurred, resulting in lower gross profit.

[0001728949-21-000022:mdna:224]
We are subject to many environmental, health and safety laws and regulations in each jurisdiction in which we operate our manufacturing facilities, which govern, among other things, emissions of pollutants into the air; wastewater discharges; the use, storage, generation, handling and disposal of hazardous substances and other waste; the investigation and remediation of soil and ground water contamination; and the health and safety of our employees. Certain environmental laws impose strict, and in certain circumstances joint and several, liability on current or previous owners or operators of real property, or parties who arranged for hazardous substances to be sent to disposal or treatment facilities, for the cost of investigation, removal or remediation of hazardous substances. As a result, we may incur clean-up costs in connection with any such removal or remediation efforts, as well as other third-party claims in connection with contaminated sites. In addition, we could be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage. If we, or companies or facilities we acquire or have acquired, in the past failed or in the future fail to comply with any such laws and regulations, then we could incur liabilities, fines or prohibitions on the sale of products we manufacture, and our operations could be suspended. Such laws and regulations could also restrict our ability to modify or expand our facilities, could require us to acquire costly equipment, or could require other significant expenditures. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. While we have policies and procedures designed to ensure compliance with applicable laws, regulations and permits, we cannot make assurances that we, or our employees, contractors or agents, will at all times be in compliance with such laws, regulations and permits, or our related policies and procedures.

[0001728949-21-000022:mdna:225]
Climate change concerns and the potential resulting environmental impact may result in new environmental, health and safety laws and regulations that may affect us, our suppliers and our customers. Such laws or regulations could cause us to incur additional direct costs for compliance, as well as increased indirect costs resulting from our customers, suppliers or both incurring additional compliance costs that are passed on to us. These costs may adversely impact our results of operations and financial condition. In addition, climate change may pose physical risks to our manufacturing facilities or our suppliers’ facilities, including increased extreme weather events that could result in supply delays or disruptions.

[0001728949-21-000022:mdna:226]
We have manufacturing facilities in Asia and Europe. If tsunamis, flooding, earthquakes, volcanic eruptions or other natural disasters, effects of climate change or geopolitical conflicts, were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, delay production and shipments of inventory and result in costly repairs, replacements or other costs. In addition, natural disasters, effects of climate change or geopolitical conflicts may result in disruptions in transportation, distribution channels and supply chains, and significant increases in the prices of raw materials. Further, health crises, including epidemics or pandemics, such as the COVID-19 pandemic, and government and business responses thereto, could affect our manufacturing facilities, including by resulting in quarantines and/or closures, which would result in disruptions to and potential closures of our manufacturing operations.

[0001728949-21-000022:mdna:227]
Our manufacturing operations depend on securing raw materials and other supplies in adequate quality and quantity in a timely manner from multiple suppliers, and in some cases, we rely on a limited number of suppliers, including in some cases sole suppliers, particularly in Asia. There may be cases where supplies of raw materials and other products are interrupted by disaster, accident or some other event at a supplier; supply is suspended due to quality or other issues; there is a shortage of supply due to a rapid increase in demand; and/or we or our suppliers are prohibited from utilizing certain raw materials, or products or components that incorporate such raw materials, due to government restrictions related to the countries from which such raw materials originate, and acceptable alternative suppliers, raw materials or raw materials sources are not available or not available in acceptable time frames or upon acceptable terms, among others, which could impact production and prevent us from supplying our products to our customers. If the supply-demand balance is disrupted, it may considerably increase costs of manufacturing due to increased prices we pay for raw materials. From time to time, suppliers may extend lead times, limit amounts supplied to us or increase prices due to capacity constraints or other factors. Additionally, supply and costs of raw materials may be negatively impacted by trade and/or national security protection policies, such as tariffs, or actions by governments that limit or prevent us from transacting business with certain countries or companies or that limit or prevent certain companies from transacting business with us, or trade tensions, particularly with countries in Asia. Further, it may be difficult or impossible to substitute one piece of equipment for another or replace one type of material with another. A failure by our suppliers to deliver our requirements could result in disruptions to our manufacturing operations.

[0001728949-21-000022:mdna:228]
Our manufacturing processes are highly complex, require advanced and costly equipment and must be continuously modified to improve yields and performance. Difficulties in the production process can reduce yields or interrupt production, and as a result, we may not be able to deliver our products or do so in a timely, cost-effective or competitive manner. Further, to remain competitive and meet customer demand, we may be required to improve our facilities and process technologies and

[0001728949-21-000022:mdna:229]
41

[0001728949-21-000022:mdna:230]
carry out extensive research and development, each of which may require investment of significant amounts of capital and may have a material adverse effect on our results of operations, cash flows and financial condition.

[0001728949-21-000022:mdna:231]
Finally, we typically begin manufacturing our products using our or our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates and are generally not covered by purchase commitments. As a result, we incur inventory and manufacturing costs in advance of anticipated sales, which sales ultimately may not materialize or may be lower than expected. If we or our customers overestimate demand, or if demand is impacted by factors outside of our or our customers’ control such as the COVID-19 pandemic or trade or national security protection policies, that is not under a binding commitment from our customers, we may experience higher inventory carrying and operating costs and/or increased excess or obsolete inventory, which would negatively impact our results of operations.

[0001728949-21-000022:mdna:232]
RISKS RELATED TO NEW AND ADJACENT INITIATIVES

[0001728949-21-000022:mdna:233]
Our growth depends in part on our ability to extend our technologies and products into new and expanded product areas, and adjacent industry segments or applications beyond mobile. Our research, development and other investments in these new and expanded product areas, industry segments or applications, and related technologies and products, as well as in our existing technologies and products, and new technologies, may not generate operating income or contribute to future results of operations that meet our expectations.

[0001728949-21-000022:mdna:234]
While we continue to invest significant resources toward advancements primarily in support of 4G- and 5G-based technologies, we also invest in new and expanded product areas, and adjacent industry segments or applications, by utilizing our existing technical and business expertise and through acquisitions.

[0001728949-21-000022:mdna:235]
In particular, our future growth depends in part on new and expanded product areas, such as RFFE, and adjacent industry segments or applications beyond mobile, such as automotive and IoT; our ability to develop leading and cost-effective technologies and products for new and expanded product areas, adjacent industry segments or applications; and third parties incorporating our technologies and products into devices used in these product areas, industry segments or applications. Accordingly, we intend to continue to make substantial investments in these new and expanded product areas and adjacent industry segments or applications, and in developing new products and technologies for these product areas, industry segments or applications. Our growth also depends significantly on our ability to develop and patent 5G technologies, and to develop and commercialize products using 5G technologies.

[0001728949-21-000022:mdna:236]
However, our research, development and other investments in these new and expanded product areas and adjacent industry segments or applications, and corresponding technologies and products, as well as in our existing, technologies and products and new technologies, such as 5G, use of licensed, shared and unlicensed spectrum and convergence of cellular and Wi-Fi, may not succeed because, among other reasons: we may not be issued patents on the technologies we develop; the technologies we develop may not be incorporated into relevant standards; new and expanded product areas, adjacent industry segments or applications, and consumer demand therein, may not develop or grow as anticipated; our strategies or the strategies of our customers, licensees or partners may not be successful; alternate technologies may be better or may reduce the advantages we anticipate from our investments; competitors’ technologies or products may be more cost effective, have more capabilities or fewer limitations or are brought to market faster than our new technologies or products; we may not be able to develop, or our competitors may have more established and/or stronger, customer, vendor, distributor or other channel relationships; and competitors may have longer operating histories in industry segments or applications that are new to us. We may also underestimate the costs of or overestimate the future revenues or margins that could result from these investments, and these investments may not, or may take many years to, generate material returns.

[0001728949-21-000022:mdna:237]
Further, the automotive industry is subject to long design-in time frames, long product life cycles and a high degree of regulatory and safety requirements, necessitating suppliers to the industry to comply with stringent qualification processes, very low defect rates and high reliability standards, all of which results in significant barriers to entry and increased costs.

[0001728949-21-000022:mdna:238]
If our new technologies and products are not successful, or are not successful in the time frames we anticipate, we may incur significant costs and asset impairments, our business and revenues may not grow or grow as anticipated, our revenues and margins may be negatively impacted, our stock price may decline and our reputation may be harmed.

[0001728949-21-000022:mdna:239]
[same as prior period, unchanged from 0001728949-20-000057:mdna:329]

[0001728949-21-000022:mdna:240]
We engage in strategic acquisitions and other transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. From time to time, we acquire businesses and other assets, including patents, technology and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies, including those that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our products

[0001728949-21-000022:mdna:241]
and technologies and supporting the design and introduction of new products (or enhancing existing products) for mobile, and for new industry segments or applications beyond mobile. Many of our strategic activities entail a high degree of risk and require the use of significant amounts of capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies or products. We may underestimate the costs or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we have in the past and may record impairment charges in the future related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our results of operations and financial condition, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001728949-21-000022:mdna:242]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models, geographic regions, industry segments or applications served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0001728949-21-000022:mdna:243]
[same as prior period, unchanged from 0001728949-20-000057:mdna:332]

[0001728949-21-000022:mdna:244]
Many of our acquisitions and other strategic investments require approval by the United States and foreign government agencies. Certain agencies in the past have, and may in the future, deny the transaction or fail to approve in a timely manner, resulting in us not realizing the anticipated benefits of the proposed transaction. Future acquisitions or other strategic investments may be more difficult, complex or expensive to the extent that our reputation for our ability to consummate acquisitions has been harmed. Further, if U.S./China relations remain strained, our ability to consummate any transaction that would require approval from the relevant regulatory agency(ies) in China may be severely impacted.

[0001728949-21-000022:mdna:245]
RISKS RELATED TO CYBERSECURITY OR MISAPPROPRIATION OF OUR CRITICAL INFORMATION

[0001728949-21-000022:mdna:246]
[same as prior period, unchanged from 0001728949-20-000057:mdna:361]

[0001728949-21-000022:mdna:247]
Third parties regularly attempt to gain unauthorized access to our information technology systems, and many such attempts are increasingly more sophisticated. The perception that the COVID-19 pandemic has made companies’ information technology systems more vulnerable has increased the already significant volume of such attempts. These attempts, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, and impersonating authorized users, among others. We may also be subject to ransom-style cyber-attacks, which could impact our information technology systems and cause widespread disruption to our business, including our manufacturing operations, and expose our confidential or propriety information. In addition, third parties that we may rely on to store and/or process our confidential information may also be subject to similar threats. Such threats could result in the misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our information technology systems. These threats are constantly evolving, increasing the difficulty of successfully defending against them or implementing adequate preventative measures. We seek to detect and investigate all security incidents and to prevent their recurrence, but attempts to gain unauthorized access to our information technology systems or other attacks have in the past, in certain instances and to certain degrees, been successful (but have not caused significant harm), and may in the future be successful, and in some cases, we might be unaware of an incident or its magnitude and effects.

[0001728949-21-000022:mdna:248]
In addition, employees and former employees, in particular former employees who become employees of our competitors, customers, licensees or other third parties, including state actors, have in the past and may in the future misappropriate, use, publish or provide to our competitors, customers, licensees or other third parties, including state actors, our technology, intellectual property or other proprietary or confidential information. This risk is exacerbated as competitors for talent, particularly engineering talent, increasingly attempt to hire our employees. See also the Risk Factor titled “We may not be able to attract and retain qualified employees.” Similarly, we provide access to certain of our technology, intellectual property and other proprietary or confidential information to our direct and indirect customers and licensees and certain of our consultants, who have in the past and may in the future wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. We also provide access to certain of our technology, intellectual property and other proprietary or confidential information to certain of our joint venture partners, including those affiliated with state actors and including in foreign jurisdictions where ownership restrictions may require us to take a minority ownership interest in the joint venture. Such joint venture partners may wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors.

[0001728949-21-000022:mdna:249]
The misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, could harm our competitive position, reduce the value of our investment in research and development and other strategic initiatives, cause us to lose business, damage our reputation, subject us to legal or regulatory proceedings, cause us to incur other loss or liability and otherwise adversely affect our business. We expect to continue to devote significant resources to the security of our information technology systems, and our technology, intellectual property and proprietary and confidential information.

[0001728949-21-000022:mdna:250]
Further, China has implemented, and other countries or regions may implement, cybersecurity laws that require our overall information technology security environment to meet certain standards and/or be certified. Such laws may be complex, ambiguous and subject to interpretation, which may create uncertainty regarding compliance. As a result, our efforts to comply with such laws may be expensive and may fail, which could adversely affect our business, results of operations and cash flows.

[0001728949-21-000022:mdna:251]
RISKS RELATED TO INTELLECTUAL PROPERTY

[0001728949-21-000022:mdna:252]
The enforcement and protection of our intellectual property may be expensive, could fail to prevent misappropriation or unauthorized use of our intellectual property, could result in the loss of our ability to enforce one or more patents, and could be adversely affected by changes in patent laws, by laws in certain foreign jurisdictions that may not effectively protect our intellectual property and by ineffective enforcement of laws in such jurisdictions.

[0001728949-21-000022:mdna:253]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our intellectual property, including our patent portfolio. Policing unauthorized use of our products, technologies and intellectual property is difficult and time consuming. The steps we have taken have not always prevented, and we cannot be certain the steps we will take in the future will prevent, the misappropriation or unauthorized use of our products, technologies or intellectual property, particularly in foreign countries where the laws may not protect our rights as fully or as readily as U.S. laws or where the enforcement of such laws may be lacking or ineffective. See also the Risk Factor titled “Our business and operations could suffer in the event of security breaches of our information technology systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0001728949-21-000022:mdna:254]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-21-000022:mdna:255]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies or political actions of governments,

[0001728949-21-000022:mdna:256]
including trade protection and national security policies; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business and the pricing and integration of additional features and functionality into our chipset products. See also the Risk Factors titled “Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business” and “Our business may suffer as a result of adverse rulings in government investigations or proceedings.”

[0001728949-21-000022:mdna:257]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0001728949-21-000022:mdna:258]
Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements. Similarly, we provide access to certain of our intellectual property and proprietary and confidential business information to our direct and indirect customers and licensees, who have in the past and may in the future wrongfully use such intellectual property and information or wrongfully disclose such intellectual property and information to third parties, including our competitors. See also the Risk Factor titled “Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.”

[0001728949-21-000022:mdna:259]
[same as prior period, unchanged from 0001728949-20-000057:mdna:322]

[0001728949-21-000022:mdna:260]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property claims against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products were found to infringe another company’s intellectual property, we could be subject to an injunction or be required to redesign our products, or to license such intellectual property or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products, license such intellectual property used in our products or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling our products. Similarly, our suppliers could be found to infringe another company’s intellectual property, and such suppliers could then be enjoined from providing products or services to us.

[0001728949-21-000022:mdna:261]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products sold by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result

[0001728949-21-000022:mdna:262]
[same as prior period, unchanged from 0001728949-20-000057:mdna:292]

[0001728949-21-000022:mdna:263]
in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-21-000022:mdna:264]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset or licensing revenues.

[0001728949-21-000022:mdna:265]
Certain legal matters, which may include certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0001728949-21-000022:mdna:266]
[same as prior period, unchanged from 0001728949-20-000057:mdna:344]

[0001728949-21-000022:mdna:267]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe that we will continue to see, an increase in customers requesting that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of our products’ source code and may expose our related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of that software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Furthermore, in the course of product development, we may make contributions to third-party open source projects that could obligate our intellectual property to adverse licensing conditions. For example, to encourage the growth of a software ecosystem that is interoperable with our products, we may need to contribute certain implementations under the open source licensing terms that govern such projects, which may adversely impact our associated intellectual property. Developing open source products, while adequately protecting the intellectual property upon which our licensing program depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental and third-party scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ adequate controls to protect our intellectual property, our contributions to and use of open source software presents risks that could have an adverse effect on these and on our business.

[0001728949-21-000022:mdna:268]
RISKS RELATED TO HUMAN CAPITAL MANAGEMENT

[0001728949-21-000022:mdna:269]
[same as prior period, unchanged from 0001728949-20-000057:mdna:378]

[0001728949-21-000022:mdna:270]
Our future success depends upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. The market for employees in our industry is extremely competitive, and competitors for talent, particularly engineering talent, increasingly attempt to hire, and to varying degrees have been successful in hiring, our employees, including by establishing local offices near our headquarters in San Diego, California. A number of such competitors for talent are significantly larger than us and are able to offer compensation in excess of what we are able to offer. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001728949-21-000022:mdna:271]
RISKS RELATED TO PRODUCT DEFECTS OR SECURITY VULNERABILITIES

[0001728949-21-000022:mdna:272]
[same as prior period, unchanged from 0001728949-20-000057:mdna:388]

[0001728949-21-000022:mdna:273]
Our products (including related software) are complex and may contain defects, errors or security vulnerabilities, or experience failures or unsatisfactory performance, due to any number of issues, including issues in materials, design, fabrication, packaging and/or use within a system. Further, because of the complexity of our products, defects or errors might only be detected when the products are in use. Development of products in new domains of technology, such as the transition to 5G, and the migration to integrated circuit technologies with smaller geometric feature sizes, increases complexity and adds risk to manufacturing yields and reliability, and increases the likelihood of product defects or errors. Risks associated with product defects, errors or security vulnerabilities are exacerbated by the fact that our customers typically integrate our products into consumer and other devices.

[0001728949-21-000022:mdna:274]
The use of devices containing our products to interact with untrusted systems or otherwise access untrusted content creates a risk of exposing the system hardware and software in those devices to malicious attacks. Security vulnerabilities in our products could expose our customers or end users to hackers or other unscrupulous third parties who develop and deploy viruses, worms and other malicious software programs that could attack our products or those of our customers. While we continue to focus on this issue and take measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and applications, and increasing the risk of security failures.

[0001728949-21-000022:mdna:275]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and to the end users of such devices. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products, repairing or replacing defective products, writing down defective inventory, or the indemnification clauses in our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, and losses on unfavorable purchase commitments. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products.

[0001728949-21-000022:mdna:276]
In addition, the occurrence of defects may give rise to product liability claims, particularly if defects in our products or the products into which they are integrated result in personal injury or death, and could result in significant costs, expenses and losses. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the efforts of our technical and management personnel and harm our business, even if we are successful. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. Further, our business liability insurance may be inadequate, or future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as automobiles, including autonomous driver assistance programs; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and extended reality (XR) for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0001728949-21-000022:mdna:277]
Accordingly, defects, errors or security vulnerabilities in our products could have an adverse impact on us, on our customers and the end users of our customers’ products. If any of these risks materialize, there could be a material adverse effect on our business, results of operations and financial condition.

[0001728949-21-000022:mdna:278]
GENERAL RISK FACTORS

[0001728949-21-000022:mdna:279]
We operate in the highly cyclical semiconductor industry, which is subject to significant downturns. We are also susceptible to declines in global, regional and local economic conditions generally. Our stock price and financial results are subject to substantial quarterly and annual fluctuations due to these dynamics, among others.

[0001728949-21-000022:mdna:280]
The semiconductor industry is highly cyclical, volatile, subject to downturns and characterized by constant and rapid technological change, price erosion, evolving technical standards, frequent new product introductions, short product life cycles and fluctuations in product supply and demand. Periods of downturns have been characterized by diminished demand for end-user products, high inventory levels, excess or obsolete inventory adjustments, underutilization of manufacturing capacity, changes in revenue mix and erosion of average selling prices. We expect our business to continue to be subject to

[0001728949-21-000022:mdna:281]
such cyclical downturns. Consequently, our revenues may decline, and our results of operations and financial condition may be adversely impacted.

[0001728949-21-000022:mdna:282]
A decline in global, regional or local economic conditions or a slow-down in economic growth, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could have adverse, wide-ranging effects on our business and financial results, including a decrease in demand for our products and technologies; a decrease in demand for the products and services of our customers or licensees; the inability of our suppliers to deliver on their supply commitments to us, our inability to supply our products to our customers and/or the inability of our customers or licensees to supply their products to end users; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our customers or licensees; failures by counterparties; and/or negative effects on wireless device inventories. In addition, our customers’ and licensees’ ability to purchase or pay for our products and intellectual property and network operators’ ability to upgrade their wireless networks could be adversely affected, potentially leading to a reduction, cancellation or delay of orders for our products.

[0001728949-21-000022:mdna:283]
Our stock price and financial results have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and our financial results include those identified above and throughout this Risk Factors section; volatility of the stock market in general and technology and semiconductor companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0001728949-21-000022:mdna:284]
Our business may suffer due to the impact of, or our failure to comply with, the various existing, new or amended laws, regulations, policies or standards to which we are subject.

[0001728949-21-000022:mdna:285]
Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). Compliance with, or changes in the interpretation of, existing Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, including, among others, Regulations affecting patent licensing practices; antitrust, competition and competitive business practices; the flow of funds out of certain countries (e.g., China); cybersecurity; import and export regulations such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; protection of intellectual property; trade and trade protection including tariffs; foreign policy and national security; environmental protection, health and safety; supply chain, responsible sourcing, including the use of conflict minerals, and human rights; spectrum availability and license issuance; adoption of standards; taxation; privacy and data protection; labor, employment and human capital; corporate governance; public disclosure; or business conduct, could have an adverse effect on our business and results of operations. See also the Risk Factors titled “Our business may suffer as a result of adverse rulings in government investigations or proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model, environmental compliance and liability, issues related to climate change, exposure to natural disasters, timely supply of equipment and materials, and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

[0001728949-21-000022:mdna:286]
Regulations are complex and changing (which may create uncertainty regarding compliance), are subject to varying interpretations, and their application in practice may evolve over time. As a result, our efforts to comply with Regulations may fail, particularly if there is ambiguity as to how they should be applied in practice. Failure to comply with any Regulation may adversely affect our business, results of operations and cash flows. New Regulations or evolving interpretations thereof, may cause us to incur higher costs as we revise current practices, policies or procedures and may divert management time and attention to compliance activities.

[0001728949-21-000022:mdna:287]
There are risks associated with our debt.

[0001728949-21-000022:mdna:288]
Our outstanding debt and any additional debt we incur may have negative consequences on our business, including, among others: requiring us to use cash to pay the principal of and interest on our debt, thereby reducing the amount of cash

[0001728949-21-000022:mdna:289]
[same as prior period, unchanged from 0001728949-20-000057:mdna:326]

[0001728949-21-000022:mdna:290]
available for other purposes; limiting our ability to obtain additional financing for working capital, capital expenditures, acquisitions, stock repurchases, dividends, general corporate or other purposes; and limiting our flexibility in planning for, or reacting to, changes in our business, industries or the market. Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to economic and political conditions, industry cycles and financial, business and other factors, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations to service our debt, we may be required to, among other things: refinance or restructure all or a portion of our debt; reduce or delay planned capital or operating expenditures; reduce, suspend or eliminate our dividend payments and/or our stock repurchase program; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing or restructuring are higher than our current rates, interest expense related to such refinancing or restructuring would increase. Further, if there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt in the future and the terms of such debt could be adversely affected.

[0001728949-21-000022:mdna:291]
Tax liabilities could adversely affect our results of operations.

[0001728949-21-000022:mdna:292]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed, as well as countries where we own intellectual property. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-21-000022:mdna:293]
Tax rules may change in a manner that adversely affects our future reported results of operations or the way we conduct our business. In response to the 2017 Tax Cuts and Jobs Act and to better align our profits with our activities, we implemented certain restructuring in fiscal 2018 and 2019. After our restructuring, most of our income is taxable in the United States with a significant portion qualifying for preferential treatment as FDII (foreign-derived intangible income). Beginning in fiscal 2027, the effective tax rate for FDII increases from 13% to 16%. Further, if U.S. tax rates increase or the FDII deduction is eliminated or reduced, our provision for income taxes, results of operations and cash flows would be adversely affected. Also, if our customers move manufacturing operations to the United States, our FDII deduction may be reduced.

[0001728949-21-000022:mdna:294]
We have tax incentives in Singapore that require we meet specified employment and other criteria. Although our profit in Singapore has declined as a result of our 2018 restructuring, failure to meet these incentive requirements near the end of March 2021 and March 2022 could result in a retroactive Singapore tax increase for 2017 and 2018.

[0001728949-21-000022:mdna:295]
[same as prior period, unchanged from 0001728949-20-000057:mdna:372]
