# QCOM 8-K — 0001728949-19-000011 filed 2019-01-30

## item codes, every 8-K on or before 2019-01-30

- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2019-01-30

- none on or before 2019-01-30

## item 2.02 — earnings release, exhibit 99.1

[0001728949-19-000011:8k_2_02:1]
EX-99.1
2
qcom123018erex991.htm
EXHIBIT 99.1

[0001728949-19-000011:8k_2_02:2]
Exhibit

[0001728949-19-000011:8k_2_02:3]
Exhibit 99.1

[0001728949-19-000011:8k_2_02:4]
Exhibit 99.1

[0001728949-19-000011:8k_2_02:5]
FOR IMMEDIATE RELEASE

[0001728949-19-000011:8k_2_02:6]
Qualcomm Contact:

[0001728949-19-000011:8k_2_02:7]
Mauricio Lopez-Hodoyan

[0001728949-19-000011:8k_2_02:8]
Vice President, Investor Relations

[0001728949-19-000011:8k_2_02:9]
Phone: 1-858-658-4813

[0001728949-19-000011:8k_2_02:10]
e-mail: ir@qualcomm.com

[0001728949-19-000011:8k_2_02:11]
Qualcomm Announces First Quarter Fiscal 2019 Results

[0001728949-19-000011:8k_2_02:12]
GAAP Revenues $4.8 billion

[0001728949-19-000011:8k_2_02:13]
GAAP EPS $0.87, Non-GAAP EPS $1.20

[0001728949-19-000011:8k_2_02:14]
SAN DIEGO - January 30, 2019 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal first quarter ended December 30, 2018.

[0001728949-19-000011:8k_2_02:15]
“Our fiscal first quarter results reflected continued strength in our semiconductor business, driven by strong product leadership and operating expense management,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “We continue to execute on our strategic objectives, including driving the global transition to 5G, protecting the established value of our technology and inventions and expanding into new industries and product categories.”

[0001728949-19-000011:8k_2_02:16]
First Quarter Results (GAAP)*

[0001728949-19-000011:8k_2_02:17]
|  | Q1 Fiscal 2019 |  | Q1 Fiscal 2018 3 |  | Year-Over-Year Change |  | Q4 Fiscal 2018 3 |  | Sequential Change |
| Revenues | $4.8B |  | $6.0B |  | (20%) |  | $5.8B |  | (16%) |
| Operating income (loss) | $0.7B |  | $0.0B |  | N/M |  | ($0.7B) |  | N/M |
| Net income (loss) 1 | $1.1B |  | ($6.0B) |  | N/M |  | ($0.5B) |  | N/M |
| Diluted earnings (loss) per share 1 | $0.87 |  | ($4.05) |  | N/M |  | ($0.36) |  | N/M |
| Operating cash flow 2 | $0.4B |  | $1.8B |  | (80%) |  | ($0.4B) |  | N/M |

[0001728949-19-000011:8k_2_02:18]
1 Throughout this news release, percentage changes are calculated based on the dollar amounts as disclosed in millions.

[0001728949-19-000011:8k_2_02:19]
2 In the first quarter of fiscal 2019, we adopted new accounting guidance that changed the classification and presentation of certain cash receipts and cash payments and that requires companies to include changes in restricted cash and cash equivalents in the statement of cash flows.  As a result, prior period cash flow amounts presented herein have been adjusted to conform to the current year presentation.

[0001728949-19-000011:8k_2_02:20]
3 In connection with the preparation of our condensed consolidated financial statements for the three months ended December 30, 2018, we identified an immaterial error related to the recognition of certain royalty revenues of our QTL (Qualcomm Technology Licensing) segment in the quarterly and annual periods in fiscal 2018 and third and fourth quarters and annual period in fiscal 2017.  We have corrected this error in our GAAP and Non-GAAP results for all prior periods presented herein.  See “Notes to Condensed Consolidated Financial Statements, Note 1. Basis of Presentation and Significant Accounting Policies Update” and “Note 11. Revision of Prior Period Financial Statements” included in our Quarterly Report on Form 10-Q for the fiscal quarter ended December 30, 2018 filed with the SEC.

[0001728949-19-000011:8k_2_02:21]
N/M - Not Meaningful

[0001728949-19-000011:8k_2_02:22]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 2 of 14 |

[0001728949-19-000011:8k_2_02:23]
First Quarter Results (Non-GAAP)*

[0001728949-19-000011:8k_2_02:24]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding the Company’s use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001728949-19-000011:8k_2_02:25]
|  | Q1 Fiscal 2019 |  | Q1 Fiscal 2018 |  | Year-Over-Year Change |  | Q4 Fiscal 2018 |  | Sequential Change |
| Revenues | $4.8B |  | $6.0B |  | (20%) |  | $5.8B |  | (17%) |
| Operating income | $1.2B |  | $1.6B |  | (26%) |  | $1.3B |  | (5%) |
| Net income | $1.5B |  | $1.4B |  | +2% |  | $1.3B |  | +16% |
| Diluted earnings per share | $1.20 |  | $0.96 |  | +25% |  | $0.89 |  | +35% |

[0001728949-19-000011:8k_2_02:26]
* Beginning in the third quarter of fiscal 2017, GAAP and Non-GAAP results have been negatively impacted by our dispute with Apple and its contract manufacturers (who are our licensees).  QTL revenues in the first quarter of fiscal 2019 and in fiscal 2018 do not include royalties due on sales of Apple or other products by Apple’s contract manufacturers.  We expect the actions taken by these companies will continue until this dispute is resolved.  QTL revenues in the first quarter of fiscal 2019 included $150 million of royalties due under an interim agreement with Huawei (who was previously disclosed as the other licensee in dispute).  QTL revenues in the fourth quarter of fiscal 2018 included $100 million received under a prior interim agreement with Huawei.  These amounts represented partial payments for royalties due by Huawei while negotiations continue, and they do not reflect the full amount of royalties due under the underlying license agreement.  We did not record any revenues in the first quarter of fiscal 2018 for royalties due on the sales of Huawei’s products.  If we do not reach a final agreement with Huawei prior to the conclusion of the interim agreement, Huawei may not make any other payments or may not make full payments under the existing license agreement.

[0001728949-19-000011:8k_2_02:27]
The following should be considered in regard to the sequential and year-over-year comparisons:

[0001728949-19-000011:8k_2_02:28]
| • | The first quarter of fiscal 2019 GAAP results included: |

[0001728949-19-000011:8k_2_02:29]
| ◦ | $180 million of restructuring and restructuring-related charges, or ($0.13) per share, related to our Cost Plan that was announced in the second quarter of fiscal 2018. |

[0001728949-19-000011:8k_2_02:30]
| • | The first quarter of fiscal 2019 GAAP and Non-GAAP results included: |

[0001728949-19-000011:8k_2_02:31]
| ◦ | $570 million tax benefit, or $0.47 per share, for GAAP and $552 million tax benefit, or $0.45 per share, for Non-GAAP relating to certain tax elections made in the first quarter of fiscal 2019. |

[0001728949-19-000011:8k_2_02:32]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 3 of 14 |

[0001728949-19-000011:8k_2_02:33]
| ◦ | $150 million of revenues, or $0.11 per share, resulting from an interim agreement with Huawei while negotiations continue. |

[0001728949-19-000011:8k_2_02:34]
| • | The first quarter of fiscal 2018 GAAP results included: |

[0001728949-19-000011:8k_2_02:35]
| ◦ | $6.0 billion charge, or ($4.03) per share, related to the enactment of the Tax Cuts and Jobs Act (the Tax Legislation) in the United States. |

[0001728949-19-000011:8k_2_02:36]
| ◦ | $1.2 billion charge, or ($0.76) per share, for the fine imposed by the European Commission (EC). |

[0001728949-19-000011:8k_2_02:37]
| • | The fourth quarter of fiscal 2018 GAAP results included: |

[0001728949-19-000011:8k_2_02:38]
| ◦ | $2.0 billion charge, or ($1.41) per share, related to a termination fee paid to NXP Semiconductors N.V. (NXP) resulting from the termination of the purchase agreement. |

[0001728949-19-000011:8k_2_02:39]
| ◦ | $676 million gain, or $0.48 per share, related to the settlement of the Taiwan Fair Trade Commission (TFTC) investigation. |

[0001728949-19-000011:8k_2_02:40]
| ◦ | $265 million of restructuring and restructuring-related charges, or ($0.14) per share, related to our Cost Plan. |

[0001728949-19-000011:8k_2_02:41]
| • | The fourth quarter of fiscal 2018 GAAP and Non-GAAP results included: |

[0001728949-19-000011:8k_2_02:42]
| ◦ | $100 million of revenues, or $0.05 per share, resulting from an interim agreement with Huawei while negotiations continue. |

[0001728949-19-000011:8k_2_02:43]
Segment Results

[0001728949-19-000011:8k_2_02:44]
First Quarter Fiscal 2019

[0001728949-19-000011:8k_2_02:45]
| (in millions, except percentages) | Q1 Fiscal 2019 |  | Q1 Fiscal 2018 |  | Year-Over-Year Change |  | Q4 Fiscal 2018 |  | Sequential Change |
| QCT |  |  |  |  |  |  |  |  |  |
| Revenues | $3,739 |  | $4,651 |  | (20%) |  | $4,647 |  | (20%) |
| EBT 1 | $598 |  | $955 |  | (37%) |  | $796 |  | (25%) |
| EBT as % of revenues | 16% |  | 21% |  | (5%) |  | 17% |  | (1%) |
| MSMTM chip shipments | 186 |  | 237 |  | (22%) |  | 232 |  | (20%) |
| QTL |  |  |  |  |  |  |  |  |  |
| Revenues | $1,018 |  | $1,266 |  | (20%) |  | $1,113 |  | (9%) |
| EBT 1 | $590 |  | $854 |  | (31%) |  | $714 |  | (17%) |
| EBT as % of revenues | 58% |  | 67% |  | (9%) |  | 64% |  | (6%) |

[0001728949-19-000011:8k_2_02:46]
1 Earnings (loss) before taxes

[0001728949-19-000011:8k_2_02:47]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 4 of 14 |

[0001728949-19-000011:8k_2_02:48]
We adopted accounting guidance (ASC 606) in the first quarter of fiscal 2019, which requires us to estimate and recognize QTL royalty revenues in the period in which the licensees’ sales occur, resulting in an acceleration of royalty revenues by one quarter.  As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues will be required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

[0001728949-19-000011:8k_2_02:49]
Return of Capital to Stockholders

[0001728949-19-000011:8k_2_02:50]
In the fourth quarter of fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock.  As of December 30, 2018, we have executed on $22.2 billion of share repurchases, primarily comprised of three Accelerated Stock Repurchase Agreements (ASRs) under which we paid $16 billion and a tender offer under which we paid $5.1 billion.  The ASRs are scheduled to terminate in early September 2019.  At December 30, 2018, $7.8 billion remained authorized for repurchase under our stock repurchase program.

[0001728949-19-000011:8k_2_02:51]
During the first quarter of fiscal 2019, we returned $1.8 billion to stockholders, including $750 million, or $0.62 per share, of cash dividends paid and $1.0 billion through repurchases of 17 million shares of common stock.  On January 14, 2019, we announced a quarterly cash dividend of $0.62 per share, payable on March 28, 2019 to stockholders of record at the close of business on March 7, 2019.

[0001728949-19-000011:8k_2_02:52]
Cash and Marketable Securities

[0001728949-19-000011:8k_2_02:53]
Our cash, cash equivalents and marketable securities totaled $10.4 billion at the end of the first quarter of fiscal 2019, compared to $39.9 billion a year ago and $12.1 billion at the end of the fourth quarter of fiscal 2018.  Stock repurchases and repayment of long-term debt significantly reduced our cash, cash equivalents and marketable securities balance at the end of the first quarter of fiscal 2019, compared to a year ago.

[0001728949-19-000011:8k_2_02:54]
Effective Income Tax Rates

[0001728949-19-000011:8k_2_02:55]
Our fiscal 2019 annual effective income tax rates are estimated to be 7% benefit for GAAP and 0% for Non-GAAP.  The effective income tax rates for the first quarter of fiscal 2019 were 91% benefit for GAAP and 40% benefit for Non-GAAP.  As a result of the Tax Legislation, in the first quarter of fiscal 2019, several of our foreign subsidiaries made tax elections to be treated as U.S. branches for federal income tax purposes effective beginning in fiscal 2018 and fiscal 2019.  These elections resulted in a GAAP and Non-

[0001728949-19-000011:8k_2_02:56]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 5 of 14 |

[0001728949-19-000011:8k_2_02:57]
GAAP income tax benefit of $570 million and $552 million, respectively, which was recorded discretely in the first quarter of fiscal 2019.

[0001728949-19-000011:8k_2_02:58]
Certain provisions of the Tax Legislation became effective for us in fiscal 2019, including new taxes due on certain foreign income, such as GILTI (global intangible low-taxed income), BEAT (base-erosion and anti-abuse tax) and FDII (foreign-derived intangible income).  In response to the Tax Legislation, we implemented certain tax restructuring in fiscal 2018 and 2019.  As a result, substantially all of our income is in the U.S. and qualifies for the preferential FDII tax rate, and the impact of GILTI and BEAT are negligible.

[0001728949-19-000011:8k_2_02:59]
Business Outlook

[0001728949-19-000011:8k_2_02:60]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as certain investment, certain derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001728949-19-000011:8k_2_02:61]
Our financial guidance for the second quarter of fiscal 2019 excludes QTL revenues for royalties due on sales of Apple and other products by Apple’s contract manufacturers, as we expect the actions taken by these companies will continue until the respective disputes are resolved.  Our financial guidance for the second quarter of fiscal 2019 includes $150 million of QTL revenues from Huawei.  This represents a minimum, non-refundable amount for royalties due by Huawei while negotiations continue. This payment does not reflect the full amount of royalties due under the underlying license agreement.

[0001728949-19-000011:8k_2_02:62]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 6 of 14 |

[0001728949-19-000011:8k_2_02:63]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001728949-19-000011:8k_2_02:64]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001728949-19-000011:8k_2_02:65]
|  |  | Q2 FY18Results (1) | Current Guidance Q2 FY19 Estimates (2)(3) |  |
|  | Revenues | $5.2B | $4.4B - $5.2B |  |  |
|  | Year-over-year change |  | decrease 0% - 16% |  |  |
|  | GAAP diluted earnings (loss) per share (EPS) | $0.22 | $0.40 - $0.50 |  |  |
|  | Year-over-year change |  | increase 82% - 127% |  |  |
|  | Less diluted EPS attributable to QSI | $0.02 |  | ($0.01 | ) |  |
|  | Less diluted EPS attributable to share-based compensation | ($0.13) |  | ($0.16 | ) |  |
|  | Less diluted EPS attributable to other items | ($0.44) |  | ($0.08 | ) |  |
|  | Non-GAAP diluted EPS | $0.78 | $0.65 - $0.75 |  |  |
|  | Year-over-year change |  | decrease 4% - 17% |  |  |
|  | Other Information |  |  |  |
|  | MSM chip shipments | 187 | M | 150M - 170M |  |  |
|  | Year-over-year change |  | decrease 9% - 20% |  |  |
|  | QTL revenues | $1.2B | $1.0B - $1.1B |  |  |
|  | Year-over-year change |  | decrease 10% - 18% |  |  |

[0001728949-19-000011:8k_2_02:66]
| (1) | The second quarter of fiscal 2018 results excluded QTL revenues for royalties due on sales of Apple and other products by Apple’s contract manufacturers, as well as sales of products by Huawei. |

[0001728949-19-000011:8k_2_02:67]
| (2) | Our financial guidance for the second quarter of fiscal 2019 excludes QTL revenues for royalties due on sales of Apple and other products by Apple’s contract manufacturers, as we expect the actions taken by these companies will continue until the respective disputes are resolved. Our financial guidance for the second quarter of fiscal 2019 includes $150 million of QTL revenues from Huawei under an interim agreement while negotiations continue. |

[0001728949-19-000011:8k_2_02:68]
| (3) | Our guidance for diluted EPS attributable to other items for the second quarter of fiscal 2019 is primarily attributable to acquisition-related items and restructuring and restructuring-related items. |

[0001728949-19-000011:8k_2_02:69]
N/M - Not Meaningful

[0001728949-19-000011:8k_2_02:70]
Sums may not equal total due to rounding.

[0001728949-19-000011:8k_2_02:71]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 7 of 14 |

[0001728949-19-000011:8k_2_02:72]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-19-000011:8k_2_02:73]
The following tables reconcile our GAAP results to our Non-GAAP results (in millions, except per share data):

[0001728949-19-000011:8k_2_02:74]
|  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) | Non-GAAP Results |
| Q1 FISCAL 2019 |  |  |  |  |  |  |  |
| Revenues | $4,842 |  | $27 |  |  | $— |  |  |  | $— |  |  | $4,815 |  |
| Operating income (loss) | 710 |  | 13 |  | (230) |  | (260) |  | 1,187 |  |
| EBT | 559 |  | 8 |  | (230) |  | (263) |  | 1,044 |  |
| EBT as % of revenues | 12 | % |  |  |  |  |  |  |  | 22 | % |  |
| Net income (loss) | 1,068 |  | 7 |  | (182) |  | (221) |  | 1,464 |  |
| Diluted EPS | $0.87 |  | $0.01 |  | ($0.15) |  | ($0.18) |  | $1.20 |  |
| Diluted shares | 1,223 |  | 1,223 |  | 1,223 |  | 1,223 |  | 1,223 |  |
| Q4 FISCAL 2018 |  |  |  |  |  |  |  |
| Revenues | $5,778 |  | $20 |  |  | $— |  |  | ($50) |  | $5,808 |  |
| Operating (loss) income | (679) |  | 2 |  | (224) |  | (1,712) |  | 1,255 |  |
| EBT | (800) |  | (20) |  | (224) |  | (1,800) |  | 1,244 |  |
| EBT as % of revenues | N/M |  |  |  |  |  |  |  |  | 21 | % |  |
| Net (loss) income | (513) |  | (11) |  | (195) |  | (1,567) |  | 1,260 |  |
| Diluted EPS | ($0.36) |  | ($0.01) |  | ($0.14) |  | ($1.10) |  | $0.89 |  |
| Diluted shares | 1,417 |  | 1,429 |  | 1,429 |  | 1,429 |  | 1,429 |  |
| Q1 FISCAL 2018 |  |  |  |  |  |  |  |
| Revenues | $6,035 |  | $30 |  |  | $— |  |  |  | $— |  |  | $6,005 |  |
| Operating (loss) income | (4) |  | 9 |  | (248) |  | (1,367) |  | 1,602 |  |
| EBT | (60) |  | 11 |  | (248) |  | (1,373) |  | 1,550 |  |
| EBT as % of revenues | N/M |  |  |  |  |  |  |  |  | 26 | % |  |
| Net (loss) income | (5,983) |  | 8 |  | (199) |  | (7,230) |  | 1,438 |  |
| Diluted EPS | ($4.05) |  | $0.01 |  | ($0.13) |  | ($4.89) |  | $0.96 |  |
| Diluted shares | 1,477 |  | 1,491 |  | 1,491 |  | 1,491 |  | 1,491 |  |

[0001728949-19-000011:8k_2_02:75]
| (a) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” herein for further details. |

[0001728949-19-000011:8k_2_02:76]
| (b) | Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” sections herein. Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001728949-19-000011:8k_2_02:77]
Sums may not equal totals due to rounding.

[0001728949-19-000011:8k_2_02:78]
Supplemental Information and Reconciliations

[0001728949-19-000011:8k_2_02:79]
(Unaudited)

[0001728949-19-000011:8k_2_02:80]
|  | Q1 FISCAL 2019 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results |
|  | Cost of revenues |  | $2,188 |  |  | $11 |  |  | $8 |  |  | $103 |  |  | $2,066 |  |
|  | Research and development (R&D) expenses |  | 1,269 |  |  | — |  |  |  | 157 |  |  | 1 |  |  | 1,111 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 526 |  |  | 3 |  |  | 65 |  |  | 7 |  |  | 451 |  |
|  | Other expenses |  | 149 |  |  | — |  |  |  | — |  |  |  | 149 |  |  | — |  |  |
|  | Interest expense |  | 156 |  |  | — |  |  |  | — |  |  |  | 6 |  |  | 150 |  |
|  | Investment and other income (loss), net |  | 5 |  |  | (5) |  |  | — |  |  |  | 3 |  |  | 7 | (b) |

[0001728949-19-000011:8k_2_02:81]
| (a) | Other items excluded from Non-GAAP results included $180 million of restructuring and restructuring-related charges related to our Cost Plan, $111 million of acquisition-related charges and $6 million of interest expense related to the EC fine, partially offset by a $31 million benefit related to a favorable legal settlement and $3 million of foreign currency transaction gains related to the EC fine, net of associated losses on derivative instruments. |

[0001728949-19-000011:8k_2_02:82]
| (b) | Included $69 million in interest and dividend income, partially offset by $49 million in net losses on marketable securities, $8 million in equity in net losses of investees, $3 million of net losses on derivative instruments and $2 million in net foreign currency losses. |

[0001728949-19-000011:8k_2_02:83]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 8 of 14 |

[0001728949-19-000011:8k_2_02:84]
Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates

[0001728949-19-000011:8k_2_02:85]
(Unaudited)

[0001728949-19-000011:8k_2_02:86]
| ($ in millions) |  | GAAP Results |  |  | Less QSI | Less Share-Based Compensation | Less Other Items (b) (c) |  | Non-GAAP Results |  |
| Q1 FISCAL 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 559 |  |  |  | $ | 8 |  |  |  | $ | (230 | ) |  |  | $ | (263 | ) |  |  | $ | 1,044 |  |  |
| Income tax benefit (expense) |  | 509 |  |  |  | (1 | ) |  |  | 48 |  |  |  | 42 |  |  |  | 420 |  |  |
| Net income (loss) |  | $ | 1,068 |  |  |  | $ | 7 |  |  |  | $ | (182 | ) |  |  | $ | (221 | ) |  |  | $ | 1,464 |  |  |
| Tax rate |  | (91 | %) |  |  | 1 | % | (a) |  |  |  | (25 | %) | (a) |  |  | (27 | %) | (a) |  |  |  | (40 | %) |  |
| FISCAL 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Estimated annual tax rate |  | (7 | %) |  |  | 0 | % | (a) |  |  |  | (4 | %) | (a) |  |  |  | (3 | %) | (a) |  |  |  | — | % |  |

[0001728949-19-000011:8k_2_02:87]
| (a) | The incremental effect of our adjustments to the Non-GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001728949-19-000011:8k_2_02:88]
| (b) | In the first quarter of fiscal 2019, the tax benefit in the “Other Items” column included a $19 million benefit for the tax effect of acquisition-related items in EBT, a $12 million benefit for the combined effect of other items in EBT and a $11 million benefit to reconcile the tax provision for each column to the total GAAP tax provision for the quarter. |

[0001728949-19-000011:8k_2_02:89]
| (c) | In fiscal 2019, the estimated annual effective tax rate for the “Other Items” column included a $69 million benefit for the tax effect of acquisition-related items in EBT and a $12 million benefit for the combined effect of other items in EBT. |

[0001728949-19-000011:8k_2_02:90]
Conference Call

[0001728949-19-000011:8k_2_02:91]
Qualcomm’s fiscal first quarter 2019 earnings conference call will be broadcast live on January 30, 2019, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415.  Callers should use reservation number 13686071.

[0001728949-19-000011:8k_2_02:92]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-19-000011:8k_2_02:93]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results used herein are presented herein.

[0001728949-19-000011:8k_2_02:94]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 9 of 14 |

[0001728949-19-000011:8k_2_02:95]
The Company uses Non-GAAP financial information: (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income (loss) and diluted earnings (loss) per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating the Company’s business and assessing trends and future expectations.

[0001728949-19-000011:8k_2_02:96]
Non-GAAP information used by management excludes its QSI segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-19-000011:8k_2_02:97]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001728949-19-000011:8k_2_02:98]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001728949-19-000011:8k_2_02:99]
| • | Certain other items are excluded because management views such items as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001728949-19-000011:8k_2_02:100]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of these items, as well as any effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes third-party acquisition and integration services costs and |

[0001728949-19-000011:8k_2_02:101]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 10 of 14 |

[0001728949-19-000011:8k_2_02:102]
costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition.

[0001728949-19-000011:8k_2_02:103]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing businesses, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. |

[0001728949-19-000011:8k_2_02:104]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. In fiscal 2018, the Company excluded the full impact of the estimated one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries, including the portion that relates to earnings and profits of U.S.-owned foreign subsidiaries generated in the first quarter of fiscal 2018. |

[0001728949-19-000011:8k_2_02:105]
About Qualcomm

[0001728949-19-000011:8k_2_02:106]
Qualcomm invents breakthrough technologies that transform how the world connects, computes and communicates.  When we connected the phone to the Internet, the mobile revolution was born.  Today, our inventions are the foundation for life-changing products, experiences, and industries.  As we lead the world to 5G, we envision this next big change in cellular technology spurring a new era of intelligent, connected devices and enabling new opportunities in connected cars, remote delivery of health care services, and the IoT - including smart cities, smart homes, and wearables.  Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, all of our engineering, research and development functions, and all of our products and services businesses, including, our QCT semiconductor business.  For more information, visit www.qualcomm.com.

[0001728949-19-000011:8k_2_02:107]
Note Regarding Forward-Looking Statements

[0001728949-19-000011:8k_2_02:108]
In addition to the historical information contained herein, this news release contains forward-looking statements that are inherently subject to risks and uncertainties, including but not limited to statements regarding: executing on our strategic objectives, including driving the global transition to 5G, protecting the established value of our technology and inventions and expanding into new industries and product categories; our stock repurchase program, and the size and timing of the completion thereof; our expectation that Apple and its contract manufacturers, who did not fully pay royalties owed to us in fiscal 2018 or to date in fiscal 2019, will continue such actions until their respective disputes are resolved, and the financial impact thereof; the possibility that Huawei may not make any other payments or may not make full payments under the underlying license agreement if we do not reach a final agreement, and the financial impact thereof; the Tax Legislation and our adoption of new revenue recognition accounting

[0001728949-19-000011:8k_2_02:109]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 11 of 14 |

[0001728949-19-000011:8k_2_02:110]
###

[0001728949-19-000011:8k_2_02:111]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries. Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-19-000011:8k_2_02:112]
MSM is a product of Qualcomm Technologies, Inc.

[0001728949-19-000011:8k_2_02:113]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 12 of 14 |

[0001728949-19-000011:8k_2_02:114]
Qualcomm Incorporated

[0001728949-19-000011:8k_2_02:115]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001728949-19-000011:8k_2_02:116]
(In millions, except per share data)

[0001728949-19-000011:8k_2_02:117]
(Unaudited)

[0001728949-19-000011:8k_2_02:118]
|  | December 30, 2018 |  | September 30, 2018 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 10,066 |  |  | $ | 11,777 |  |
| Marketable securities | 249 |  |  | 311 |  |
| Accounts receivable, net | 3,426 |  |  | 2,904 |  |
| Inventories | 1,698 |  |  | 1,693 |  |
| Other current assets | 855 |  |  | 699 |  |
| Total current assets | 16,294 |  |  | 17,384 |  |
| Deferred tax assets | 3,923 |  |  | 936 |  |
| Property, plant and equipment, net | 2,932 |  |  | 2,975 |  |
| Goodwill | 6,295 |  |  | 6,498 |  |
| Other intangible assets, net | 2,746 |  |  | 2,955 |  |
| Other assets | 2,056 |  |  | 1,970 |  |
| Total assets | $ | 34,246 |  |  | $ | 32,718 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,422 |  |  | $ | 1,825 |  |
| Payroll and other benefits related liabilities | 821 |  |  | 1,081 |  |
| Unearned revenues | 484 |  |  | 500 |  |
| Short-term debt | 998 |  |  | 1,005 |  |
| Other current liabilities | 6,831 |  |  | 6,978 |  |
| Total current liabilities | 10,556 |  |  | 11,389 |  |
| Unearned revenues | 1,420 |  |  | 1,620 |  |
| Income taxes payable | 2,174 |  |  | 2,312 |  |
| Long-term debt | 15,388 |  |  | 15,365 |  |
| Other liabilities | 1,091 |  |  | 1,225 |  |
| Total liabilities | 30,629 |  |  | 31,911 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,210 and 1,219 shares issued and outstanding, respectively | — |  |  | — |  |
| Retained earnings | 3,415 |  |  | 542 |  |
| Accumulated other comprehensive income | 202 |  |  | 265 |  |
| Total stockholders’ equity | 3,617 |  |  | 807 |  |
| Total liabilities and stockholders’ equity | $ | 34,246 |  |  | $ | 32,718 |  |

[0001728949-19-000011:8k_2_02:119]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 13 of 14 |

[0001728949-19-000011:8k_2_02:120]
Qualcomm Incorporated

[0001728949-19-000011:8k_2_02:121]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-19-000011:8k_2_02:122]
(In millions, except per share data)

[0001728949-19-000011:8k_2_02:123]
(Unaudited)

[0001728949-19-000011:8k_2_02:124]
|  | Three Months Ended |
|  | December 30, 2018 |  | December 24, 2017 |
| Revenues: |  |  |  |
| Equipment and services | $ | 3,754 |  |  | $ | 4,704 |  |
| Licensing | 1,088 |  |  | 1,331 |  |
| Total revenues | 4,842 |  |  | 6,035 |  |
| Costs and expenses: |  |  |  |
| Cost of revenues | 2,188 |  |  | 2,663 |  |
| Research and development | 1,269 |  |  | 1,420 |  |
| Selling, general and administrative | 526 |  |  | 773 |  |
| Other | 149 |  |  | 1,183 |  |
| Total costs and expenses | 4,132 |  |  | 6,039 |  |
| Operating income (loss) | 710 |  |  | (4 | ) |
| Interest expense | (156 | ) |  | (170 | ) |
| Investment and other income, net | 5 |  |  | 114 |  |
| Income (loss) before income taxes | 559 |  |  | (60 | ) |
| Income tax benefit (expense) | 509 |  |  | (5,923 | ) |
| Net income (loss) | $ | 1,068 |  |  | $ | (5,983 | ) |
| Basic earnings (loss) per share | $ | 0.88 |  |  | $ | (4.05 | ) |
| Diluted earnings (loss) per share | $ | 0.87 |  |  | $ | (4.05 | ) |
| Shares used in per share calculations: |  |  |  |
| Basic | 1,213 |  |  | 1,477 |  |
| Diluted | 1,223 |  |  | 1,477 |  |

[0001728949-19-000011:8k_2_02:125]
| Qualcomm Announces First Quarter Fiscal 2019 Results | Page 14 of 14 |

[0001728949-19-000011:8k_2_02:126]
Qualcomm Incorporated

[0001728949-19-000011:8k_2_02:127]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-19-000011:8k_2_02:128]
(In millions)

[0001728949-19-000011:8k_2_02:129]
(Unaudited)

[0001728949-19-000011:8k_2_02:130]
|  | Three Months Ended |
|  | December 30, 2018 |  | December 24, 2017 |
| Operating Activities: |  |  |  |
| Net income (loss) | $ | 1,068 |  |  | $ | (5,983 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization expense | 353 |  |  | 363 |  |
| Income tax provision (less than) in excess of income tax payments | (663 | ) |  | 5,694 |  |
| Non-cash portion of share-based compensation expense | 230 |  |  | 248 |  |
| Net losses (gains) on marketable securities and other investments | 37 |  |  | (23 | ) |
| Indefinite and long-lived asset impairment charges | 150 |  |  | — |  |
| Impairment losses on marketable securities and other investments | 9 |  |  | 9 |  |
| Other items, net | (36 | ) |  | (25 | ) |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable, net | 415 |  |  | 581 |  |
| Inventories | (18 | ) |  | 162 |  |
| Other assets | (148 | ) |  | (62 | ) |
| Trade accounts payable | (403 | ) |  | (248 | ) |
| Payroll, benefits and other liabilities | (576 | ) |  | 1,121 |  |
| Unearned revenues | (62 | ) |  | (75 | ) |
| Net cash provided by operating activities | 356 |  |  | 1,762 |  |
| Investing Activities: |  |  |  |
| Capital expenditures | (152 | ) |  | (226 | ) |
| Purchases of debt and equity marketable securities | — |  |  | (5,627 | ) |
| Proceeds from sales and maturities of debt and equity marketable securities | 35 |  |  | 2,704 |  |
| Acquisitions and other investments, net of cash acquired | (56 | ) |  | (122 | ) |
| Proceeds from other investments | 23 |  |  | 10 |  |
| Other items, net | (2 | ) |  | — |  |
| Net cash used by investing activities | (152 | ) |  | (3,261 | ) |
| Financing Activities: |  |  |  |
| Proceeds from short-term debt | 1,784 |  |  | 2,116 |  |
| Repayment of short-term debt | (1,790 | ) |  | (1,149 | ) |
| Proceeds from issuance of common stock | 28 |  |  | 134 |  |
| Repurchases and retirements of common stock | (1,019 | ) |  | (225 | ) |
| Dividends paid | (750 | ) |  | (844 | ) |
| Payments of tax withholdings related to vesting of share-based awards | (139 | ) |  | (192 | ) |
| Other items, net | (1 | ) |  | (5 | ) |
| Net cash used by financing activities | (1,887 | ) |  | (165 | ) |
| Changes in cash and cash equivalents held for sale | (25 | ) |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents | (3 | ) |  | (3 | ) |
| Net decrease in cash, cash equivalents, restricted cash and restricted cash equivalents | (1,711 | ) |  | (1,667 | ) |
| Cash, cash equivalents, restricted cash and restricted cash equivalents at beginning of period | 11,777 |  |  | 37,029 |  |
| Cash, cash equivalents, restricted cash and restricted cash equivalents at end of period | $ | 10,066 |  |  | $ | 35,362 |  |
| Reconciliation to the condensed consolidated balance sheets |  |  |  |
| Cash and cash equivalents | $ | 10,066 |  |  | $ | 33,362 |  |
| Restricted cash and restricted cash equivalents included in other assets | — |  |  | 2,000 |  |
| Total cash, cash equivalents, restricted cash and restricted cash equivalents at end of period | $ | 10,066 |  |  | $ | 35,362 |  |
