# QCOM note change history — 0001728949-18-000075 → 0001728949-19-000012


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-01-30):
[0001728949-19-000012:note_history:1]
Apple Inc. (Apple) v. QUALCOMM Incorporated: On January 20, 2017, Apple filed a complaint against us in the United States District Court for the Southern District of California seeking declarations with respect to several of our patents and alleging that we breached certain agreements and violated federal antitrust and California state unfair competition laws. In its initial complaint, Apple sought declaratory judgments of non-infringement by Apple of nine of our patents, or in the alternative, a declaration of royalties Apple must pay for the patents. Apple further sought a declaration that our sale of baseband processor chipsets exhausts our patent rights for patents embodied in those chipsets. Separately, Apple sought to enjoin us from seeking excessive royalties from Apple and to disgorge royalties paid by Apple’s contract manufacturers that the court finds were not fair, reasonable and non-discriminatory (FRAND). Apple also claimed that our refusal to make certain payments to Apple under a Business Cooperation and Patent Agreement (Cooperation Agreement) constituted a breach of contract in violation of California law and sought damages in the amount of the unpaid payments, alleged to be approximately $1 billion. In addition, Apple claimed that we have refused to deal with competitors in contravention of our agreements with applicable standard setting organizations, have used our market position to impose contractual obligations on Apple that prevented Apple from challenging our licensing practices, have tied the purchase of our CDMA-enabled and “premium” LTE-enabled chipsets to licensing certain of our patents and have required Apple to purchase baseband processor chipsets exclusively from us as a condition of our payment to Apple of certain rebates, in violation of Section 2 of the Sherman Act and the California Unfair Competition Law. Apple sought injunctive relief with respect to these claims and a judgment awarding its expenses, costs and attorneys’ fees.

- changed (2019-01-30):
[0001728949-19-000012:note_history:2]
On April 10, 2017, we filed our Answer and Counterclaims (amended on May 24, 2017) in response to Apple’s complaint denying Apple’s claims and asserting claims against Apple. The counterclaims against Apple include tortious interference with our long-standing Subscriber Unit License Agreements (SULAs) with third-party contract manufacturers of Apple devices, causing those contract manufacturers to withhold certain royalty payments owed to us and violate their audit obligations; breach of contract and the implied covenant of good faith and fair dealing relating to the Cooperation Agreement; unjust enrichment and declaratory relief relating to the Cooperation Agreement; breach of contract based on Apple’s failure to pay amounts owed to us under a Statement of Work relating to a high-speed feature of our baseband processor chipsets; breach of the parties’ software agreement; and violation of California Unfair Competition Law based on Apple’s threatening us to prevent us from promoting the superior performance of our own baseband processor chipsets. We also seek declaratory judgments that we have satisfied our FRAND commitments with respect to Apple, and that our SULAs with the contract manufacturers do not violate either competition law or our FRAND commitments. On June 19, 2017, Apple filed a Partial Motion to Dismiss our counterclaim for violation of the California Unfair Competition Law. The court granted that motion on November 8, 2017. On June 20, 2017, Apple filed an Answer and Affirmative Defenses to the rest of our counterclaims, and also filed an Amended Complaint reiterating all of the original claims and adding claims for declaratory judgments of invalidity of the nine patents that are subject to declaratory judgment claims in the original complaint, adding new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for nine more patents. Apple also added claims for declaratory judgments that certain of our agreements are unenforceable. On July 21, 2017, we filed an Answer to Apple’s Amended Complaint as well as a motion to dismiss the new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for the nine additional patents. The court granted our motion on November 8, 2017.
  (was, 2018-07-25, similarity 0.6703):
[0001728949-18-000075:note_history:2]
On April 10, 2017, the Company filed its Answer and Counterclaims (amended on May 24, 2017) in response to Apple’s complaint denying Apple’s claims and asserting claims against Apple. The counterclaims against Apple include tortious interference with the Company’s long-standing Subscriber Unit License Agreements (SULAs) with third-party contract manufacturers of Apple devices, causing those contract manufacturers to withhold certain royalty payments owed to the Company and violate their audit obligations; breach of contract and the implied covenant of good faith and fair dealing relating to the parties’ Cooperation Agreement; unjust enrichment and declaratory relief relating to the Cooperation Agreement; breach of contract based on Apple’s failure to pay amounts owed to the Company under a Statement of Work relating to a high-speed feature of the Company’s chipsets; breach of the parties’ software agreement; and violation of California Unfair Competition Law based on Apple’s threatening the Company to prevent it from promoting the superior performance of the Company’s own chipsets. The Company also seeks declaratory judgments that the Company has satisfied its FRAND commitments with respect to Apple, and that the Company’s SULAs with the contract manufacturers do not violate either competition law or the Company’s FRAND commitments. On June 19, 2017, Apple filed a Partial Motion to Dismiss the Company’s counterclaim for violation of the California Unfair Competition Law. The court granted that motion on November 8, 2017. On June 20, 2017, Apple filed an Answer and Affirmative Defenses to the rest of the Company’s counterclaims, and also filed an Amended Complaint reiterating all of the original claims and adding claims for declaratory judgments of invalidity of the nine patents that are subject to declaratory judgment claims in the original complaint, adding new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for nine more patents. Apple also added claims for declaratory judgments that certain of the Company’s agreements are unenforceable. On July 21, 2017, the Company filed an Answer to Apple’s Amended Complaint as well as a motion to dismiss the new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for the nine additional patents. The court granted the Company’s motion on November 8, 2017.

- changed (2019-01-30):
[0001728949-19-000012:note_history:3]
On May 17, 2017, we filed a complaint (captioned QUALCOMM Incorporated v. Compal Electronics, Inc. et al.) in the United States District Court for the Southern District of California against certain of Apple’s contract manufacturers, Compal Electronics, Inc. (Compal), FIH Mobile, Ltd., Hon Hai Precision Industry Co., Ltd. (together with FIH Mobile, Ltd., Foxconn), Pegatron Corporation (Pegatron) and Wistron Corporation (Wistron), asserting claims for injunctive relief, specific performance, declaratory relief and damages stemming from the defendants’ breach of contracts by ceasing the payment of royalties for iPhones and other devices which they manufacture for Apple. On July 17, 2017, Compal, Foxconn, Pegatron and Wistron each filed third-party complaints for contractual indemnity against Apple seeking to join Apple as a party to the action. On July 18, 2017, Apple filed an answer to these third-party complaints acknowledging its indemnity agreements and consenting to be joined. On that same day, the defendants filed an Answer and Counterclaims to the complaint, asserting defenses and counterclaims similar to allegations previously made by Apple in the Apple Inc. v. QUALCOMM Incorporated case discussed above. In addition, the defendants asserted certain new claims, including claims under Section 1 of the Sherman Act and California’s Cartwright Act. The defendants seek damages, declaratory relief, injunctive relief, restitution of certain royalties and other relief. Also, on July 18, 2017, Apple filed a motion to consolidate this action with the Apple Inc. v. QUALCOMM Incorporated case. On September 13, 2017, the court granted Apple’s consolidation motion. Fact discovery is closed in these cases.
  (was, 2018-07-25, similarity 0.9618):
[0001728949-18-000075:note_history:3]
On May 17, 2017, the Company filed a complaint (captioned QUALCOMM Incorporated v. Compal Electronics, Inc. et al.) in the United States District Court for the Southern District of California against Compal Electronics, Inc. (Compal), FIH Mobile, Ltd., Hon Hai Precision Industry Co., Ltd. (together with FIH Mobile, Ltd., Foxconn), Pegatron Corporation (Pegatron) and Wistron Corporation (Wistron) asserting claims for injunctive relief, specific performance, declaratory relief and damages stemming from the defendants’ breach of contracts by ceasing the payment of royalties for iPhones and other devices which they manufacture for Apple. On July 17, 2017, Compal, Foxconn, Pegatron and Wistron each filed third-party complaints for contractual indemnity against Apple seeking to join Apple as a party to the action. On July 18, 2017, Apple filed an answer to these third-party complaints acknowledging its indemnity agreements and consenting to be joined. On July 18, 2017, the defendants filed an Answer and Counterclaims to the complaint, asserting defenses and counterclaims similar to allegations previously made by Apple in the Apple Inc. v. QUALCOMM Incorporated case discussed above. In addition, the defendants asserted certain new claims, including claims under Section 1 of the Sherman Act and California’s Cartwright Act. The defendants seek damages, declaratory relief, injunctive relief, restitution of certain royalties and other relief. On July 18, 2017, Apple filed a motion to consolidate this action with the Apple Inc. v. QUALCOMM Incorporated case. On September 13, 2017, the court granted Apple’s consolidation motion.

- added (2019-01-30):
[0001728949-19-000012:note_history:4]
On August 31, 2018, Apple filed a motion for judgment on the pleadings that the court lacks subject matter jurisdiction over our counterclaim that our license offers to Apple have not violated our obligation to license standard-essential patents on FRAND terms. The same day, Apple filed motions for partial summary judgment on the following issues: that part of our claim for Apple’s alleged tortious interference with its contract manufacturers’ agreements is barred by the statute of limitations; that our claim for damages under the Cooperation Agreement is unfounded; and that certain of our patent rights are exhausted by the sale of our baseband processor chipsets. On November 8, 2018, the court ruled on Apple’s motion regarding its alleged tortious interference, holding that Apple is not liable for tortious interference that occurred prior to January 20, 2015, but may be held liable for subsequent tortious interference. On December 18, 2018, the court denied Apple’s motion regarding patent exhaustion as moot in light of the dismissal of the claims at issue discussed below. The court heard oral arguments on Apple’s remaining two motions on January 25, 2019.

- added (2019-01-30):
[0001728949-19-000012:note_history:5]
On September 14, 2018, we filed a motion to dismiss Apple’s declaratory judgment claims relating to the nine specific patents identified in its original complaint on the basis that we granted Apple and its contract manufacturers a covenant-not-to-sue on those patents. The judge granted our motion on November 20, 2018, which disposed of a total of 56 claims pled by Apple and its contract manufacturers, including non-infringement, validity, damages and patent exhaustion for each of the nine patents.

- added (2019-01-30):
[0001728949-19-000012:note_history:6]
Trial is scheduled to begin on April 15, 2019.

- added (2019-01-30):
[0001728949-19-000012:note_history:7]
On January 23, 2017, an Apple subsidiary in China filed two complaints against us in the Beijing Intellectual Property Court. On March 31, 2017, the court granted an application by Apple Inc. to join the actions as a plaintiff, and Apple amended the complaints. One of the complaints alleges a violation of China’s Anti-Monopoly Law (AML complaint); the other complaint requests a determination of the terms of a patent license between us and Apple (FRAND complaint). The AML complaint alleges that (i) we have abused our dominant position in communication standard-essential patents licensing markets and certain global baseband processor chipset markets by charging and offering royalty terms that were excessively high; (ii) we refused to license certain implementers of standardized technologies, including Apple and baseband processor chipset manufacturers; (iii) we forced Apple to use only our products and services; and (iv) we bundled licenses to standard-essential patents with licenses to non-standard-essential patents and imposed other unreasonable or discriminatory trading terms on Apple in violation of the AML. The AML complaint seeks a decree that we cease the alleged abuse of dominance, as well as damages in the amount of 1 billion Chinese renminbi (approximately $146 million based on the exchange rate on December 30, 2018). The FRAND complaint makes allegations similar to the AML complaint and further alleges that we refused to offer licensing terms for our cellular standard-essential patents consistent with our FRAND licensing commitments and failed to provide to Apple certain information about our patents. The FRAND complaint seeks (i) a declaration that the license terms offered to Apple by us for our mobile communication standard-essential patents are not compliant with FRAND; (ii) an order that we cease our actions that allegedly violate our FRAND obligations, including pricing on unfair, unreasonable and excessive terms, refusing to deal, imposing unreasonable trade conditions and failing to provide information on our patents; and (iii) a determination of FRAND-compliant license terms for our Chinese standard-essential patents. Apple also seeks its expenses in each of the cases.

- added (2019-01-30):
[0001728949-19-000012:note_history:8]
On August 3, 2017, we received three additional complaints filed by an Apple subsidiary in China and Apple Inc. against us in the Beijing Intellectual Property Court. The complaints seek declaratory judgments of non-infringement of three of our patents. We filed jurisdictional and other objections to the complaints, which the court denied on May 31, 2018. On July 5, 2018, we appealed the denial of our objections to the Beijing High People’s Court.

- changed (2019-01-30):
[0001728949-19-000012:note_history:9]
On November 30, 2017, Apple and certain of its Chinese subsidiaries filed three patent infringement complaints against us in the Beijing Intellectual Property Court. Apple seeks damages and costs. We have filed jurisdictional objections to the complaints.
  (was, 2018-07-25, similarity 0.932):
[0001728949-18-000075:note_history:9]
On November 30, 2017, Apple and certain of its Chinese subsidiaries filed three patent infringement complaints against the Company in the Beijing Intellectual Property Court. Apple seeks damages and costs. The Company has filed jurisdictional objections to the complaints.

- changed (2019-01-30):
[0001728949-19-000012:note_history:10]
On February 16, 2017, Apple and one of its Japanese subsidiaries filed four complaints against us in the Tokyo District Court. In three of the complaints, Apple seeks declaratory judgment of non-infringement by Apple of three of our patents. Apple further seeks a declaration that our patent rights with respect to those three patents are exhausted by our SULAs with the contract manufacturers of Apple’s devices as well as our sale of baseband processor chipsets. Apple also seeks an award of fees. On January 30, 2018, April 27, 2018 and July 13, 2018, the court dismissed each of Apple’s three declaratory judgment complaints, finding that Apple lacked standing based on the facts it alleged in those complaints. Apple has appealed all three decisions. On December 12, 2018, the Intellectual Property High Court dismissed the first of Apple’s appeals. The other two appeals are still pending. The court has yet to rule on whether Apple has standing in the remaining complaint. On May 15, 2017, we learned of the fourth complaint. In that complaint, Apple and one of its Japanese subsidiaries seek damages of 100 million Japanese yen (approximately $1 million based on the exchange rate on December 30, 2018) from us, based on allegations that we violated the Japanese Antimonopoly Act and the Japanese Civil Code. In particular, the fourth complaint alleges that (i) we hold a monopoly position in the market for baseband processor chipsets that implement certain cellular standards; (ii) we collect double royalties through our license agreements and the sale of baseband processor chipsets; (iii) we refused to grant Apple a license on FRAND terms and forced Apple to execute a rebate agreement under unreasonable conditions; (iv) we refused to grant Apple a direct license; and (v) we demanded a license fee based on the market value of the total device. We have filed jurisdictional and other objections to this complaint.
  (was, 2018-07-25, similarity 0.8311):
[0001728949-18-000075:note_history:10]
On February 16, 2017, Apple and one of its Japanese subsidiaries filed four complaints against the Company in the Tokyo District Court. In three of the complaints, Apple seeks declaratory judgment of non-infringement by Apple of three of the Company’s patents. Apple further seeks a declaration that the Company’s patent rights with respect to those three patents are exhausted by the Company’s SULAs with the contract manufacturers of Apple’s devices as well as the Company’s sale of baseband chipsets. Apple also seeks an award of fees. On January 30, 2018, April 27, 2018 and July 13, 2018, the court dismissed each of the three declaratory judgment complaints, finding that Apple lacked standing based on the facts it alleged in those complaints. The court has yet to rule on whether Apple has standing in the remaining complaint. On May 15, 2017, the Company learned of the fourth complaint. In that complaint, Apple and one of its Japanese subsidiaries seek damages of 100 million Japanese Yen (approximately $1 million based on the exchange rate on June 24, 2018) from the Company, based on allegations that the Company violated the Japanese Antimonopoly Act and the Japanese Civil Code. In particular, the fourth complaint alleges that (i) the Company holds a monopoly position in the market for baseband processor chipsets that implement certain cellular standards; (ii) the Company collects double royalties through its license agreements and the sale of chipsets; (iii) the Company refused to grant Apple a license on FRAND terms and forced Apple to execute a rebate agreement under unreasonable conditions; (iv) the Company refused to grant Apple a direct license; and (v) the Company demanded a license fee based on the market value of the total device. The Company has filed jurisdictional and other objections to this complaint.

- added (2019-01-30):
[0001728949-19-000012:note_history:11]
On March 2, 2017, we learned that Apple and certain of its European subsidiaries issued a Claim Form against us in the UK High Court of Justice, Chancery Division, Patents Court on January 23, 2017. Apple subsequently filed an Amended Claim Form and Particulars of Claim. Both the Amended Claim Form and the Particulars of Claim allege several European competition law claims, including our refusal to license competing chipmakers, failure to offer Apple a direct license to our standard-essential patents on FRAND terms, demanding excessive royalties for our standard-essential patents, and demanding excessive license fees for the use of our standard-essential patents in connection with baseband processor chipsets purchased from us. Apple also seeks declarations that we are obliged to offer a direct patent license to Apple in respect of standard-essential patents actually practiced on FRAND terms and that using our baseband processor chipsets does not infringe any of our patents because we exhausted our patent rights. Finally, Apple seeks declarations that five of our European (UK) patents are invalid and not essential, and an order that each of those patents be revoked.

- added (2019-01-30):
[0001728949-19-000012:note_history:12]
On April 18, 2017, Apple and one of its Taiwanese subsidiaries filed a complaint against us in the Taiwan Intellectual Property Court alleging that we have abused a dominant market position in licensing wireless standard-essential patents and selling baseband processor chipsets, including improper pricing, refusal to deal, exclusive dealing, tying, imposing unreasonable trade terms and discriminatory treatment. The complaint seeks rulings that we not use the sales price of the terminal device as the royalty base for standard-essential patents; not leverage our cellular standard-essential patents to obtain licenses of our non-standard-essential patents or demand cross-licenses without proper compensation; not refuse, reduce, delay or take any other action to limit the supply of our baseband processor chipsets to non-licensees; that we must license our standard-essential patents on FRAND terms; and that we shall not, based on standard-essential patents, seek injunctions. The complaint also seeks damages of 10 million Taiwan dollars (less than $1 million based on the exchange rate on December 30, 2018), among other relief.

- changed (2019-01-30):
[0001728949-19-000012:note_history:13]
We believe Apple’s and its contract manufacturers’ claims in the above matters are without merit.
  (was, 2018-07-25, similarity 0.6927):
[0001728949-18-000075:note_history:13]
The Company believes Apple’s counterclaims and invalidation requests in the above matters are without merit.

- added (2019-01-30):
[0001728949-19-000012:note_history:14]
QUALCOMM Incorporated v. Apple Inc.: On July 6, 2017, we filed a complaint against Apple in the United States District Court for the Southern District of California asserting claims for damages and injunctive relief for infringement of six of our patents directed to a variety of features found in iPhone models. On July 7, 2017, we filed a complaint against Apple in the United States International Trade Commission (ITC) requesting that the ITC institute an investigation pursuant to Section 337 of the Tariff Act of 1930 based on Apple’s infringement of the same six patents. We are seeking a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor chipset. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple filed an Answer and Counterclaims in the District Court case on September 26, 2017. On November 29, 2017, Apple filed a First Amended Answer and Counterclaims asserting that our Snapdragon processors infringe eight Apple patents. On August 8, 2017, the ITC issued a notice of institution of an investigation. On August 25, 2017, we withdrew allegations as to one patent in both the ITC investigation and the district court case. On April 25, 2018, we withdrew allegations as to two additional patents in the ITC investigation, but not the District Court case, in order to satisfy certain briefing limitations and to narrow the issues for hearing. The ITC investigation evidentiary hearing by the Administrative Law Judge (ALJ) was held June 18-26, 2018. The ALJ’s Initial Determination on the merits was issued on September 28, 2018. The ALJ found that we had established a violation of Section 337 by Apple due to the infringement of one of the three asserted patents. However, the ALJ recommended against an exclusion order on the grounds of public interest. On October 15, 2018, the parties each filed petitions for review of portions of the ALJ’s decision by the full ITC. On December 12, 2018, the ITC announced that it will review the ALJ’s determination of violation on one patent and requested public comments on the potential impact on the public interest if an exclusion order is issued. The ITC denied review of the ALJ’s findings of no violation as to the other two patents. The target date for final determination by the ITC is February 19, 2019, but we expect that the target date will be moved due to the federal government shutdown. On March 2, 2018, the District Court granted our motion to sever, for separate trial, Apple’s counterclaims for patent infringement against us. Trial on four of our asserted patents is scheduled to begin on March 4, 2019. Apple has challenged the validity of four of our patents asserted in the first ITC action and corresponding District Court case via Inter Partes Review (IPR) petitions with the United States Patent and Trademark Office (USPTO) Patent Trial and Appeal Board (PTAB). The PTAB has instituted trials on three of those patents. With respect to Apple’s patent claims against us, trial is scheduled to begin on July 15, 2019. We challenged the validity of all of Apple’s asserted patents with the PTAB. Those petitions are pending.

- changed (2019-01-30):
[0001728949-19-000012:note_history:15]
On November 1, 2017, we filed a complaint against Apple in San Diego Superior Court for breach of the Master Software Agreement between the companies. The complaint recounts instances when Apple failed to protect our software as required by the agreement and failed to provide sufficient information to which we are entitled under the agreement in order to understand whether other breaches have occurred. The complaint seeks specific performance of Apple’s obligations to cooperate with an audit of its handling of our software, damages and injunctive relief. Apple filed its answer to the complaint on December 19, 2017. On September 24, 2018, we filed a motion seeking to amend our complaint to add causes of action for additional contract breaches and misappropriation of trade secrets. On October 26, 2018, the court granted our motion. We filed an amended complaint on October 31, 2018 and further amended the complaint on November 15, 2018. Apple has filed a demurrer objecting to the sufficiency of the second amended complaint which is scheduled for hearing on February 8, 2019. No trial date is currently scheduled.
  (was, 2018-07-25, similarity 0.6783):
[0001728949-18-000075:note_history:15]
On November 1, 2017, the Company filed a complaint against Apple in San Diego Superior Court for breach of the Master Software Agreement between the companies. The complaint recounts instances when Apple failed to protect the Company’s software as required by the agreement and failed to provide sufficient information to which the Company is entitled under the agreement in order to understand whether other breaches have occurred. The complaint seeks specific performance of Apple’s obligations to cooperate with an audit of its handling of the Company’s software, damages and injunctive relief. Apple filed its Answer to the Complaint on December 29, 2017. Trial is scheduled to begin on April 26, 2019.

- added (2019-01-30):
[0001728949-19-000012:note_history:16]
On November 29, 2017, we filed three additional complaints against Apple in the United States District Court for the Southern District of California alleging infringement of a total of 16 of our patents. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. The complaints seek damages and injunctive relief. On January 22, 2018, Apple filed answers and counterclaims in each of these cases seeking declaratory judgments that the asserted patents are invalid and/or not infringed. For the case relating to the November 30, 2017 ITC investigation described below, fact discovery is scheduled to close on March 13, 2019, and trial is scheduled to begin on October 21, 2019. Apple has filed IPR petitions with the PTAB challenging the validity of four of our patents asserted in the November 30, 2017 ITC action and corresponding District Court action. The PTAB has granted the petition as to one of those patents. For the cases not related to the ITC investigation, Apple has challenged all of the asserted patents in IPR proceedings filed in the PTAB. No decisions have yet been issued by the PTAB. In total, Apple has filed 50 IPRs. The PTAB has initiated proceedings in 13 of the IPRs to date. As a result of the IPR proceedings, on August 29, 2018, the court stayed those two cases pending the outcome of the IPR proceedings.

- changed (2019-01-30):
[0001728949-19-000012:note_history:17]
On November 30, 2017, we filed a complaint in the ITC accusing certain Apple products of infringing five of our patents. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. We seek a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor chipset. On January 2, 2018, the ITC instituted an investigation. The evidentiary hearing by the Administrative Law Judge (ALJ) took place from September 17-24, 2018 and included three of our patents. The ALJ’s Initial Determination on the merits was due on January 22, 2019 but did not occur due to the federal government shutdown. The target date for final determination by the ITC is currently May 22, 2019. We expect new dates will be set following the shutdown.
  (was, 2018-07-25, similarity 0.7548):
[0001728949-18-000075:note_history:17]
On November 30, 2017, the Company filed a complaint in the ITC accusing certain Apple products of infringing five of the Company’s patents. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. The Company seeks a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor. On January 2, 2018, the ITC instituted an investigation. The ITC investigation is scheduled for evidentiary hearing by the Administrative Law Judge (ALJ) from September 17-24, 2018. The ALJ’s Initial Determination on the merits is due on January 22, 2019, and the target date for final determination by the ITC is set for May 22, 2019.

- added (2019-01-30):
[0001728949-19-000012:note_history:18]
On July 17, 2017, we filed complaints against Apple and certain of its subsidiaries in the Federal Republic of Germany, asserting infringement of one of our patents in the Mannheim District Court and infringement of another patent in the Munich District Court. On October 2, 2017, we filed claim extensions in these actions against Apple and certain of its subsidiaries, asserting infringement of two additional patents in the Mannheim District Court and infringement of five additional patents in the Munich District Court. On May 28, 2018, we filed additional claim extensions in these actions against Apple and certain of its subsidiaries, asserting infringement of three additional patents in the Mannheim District Court and infringement of one additional patent in the Munich District Court. The complaints seek remedies including, among other relief, declaratory relief confirming liability on the merits for damages and injunctive relief. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple and/or its subsidiaries and, in some cases, also Intel have challenged the validity of the asserted patents in opposition proceedings before the European Patent Office or nullity actions before the Federal Patent Court. On October 11, 2018, the Munich District Court issued a judgment declaring one of the patents asserted on October 2, 2017 as not infringed. We have appealed that judgment. On December 20, 2018, the Munich District Court issued judgments declaring one of the patents asserted on July 17, 2017 as infringed and issued an injunction against the infringing Apple products, which would be effective following the posting of financial guarantees. On January 3, 2019, Qualcomm served the requisite financial guarantees to enforce the injunction in the amount of 1.3 billion Euro (approximately $1.5 billion based on the exchange rate at December 30, 2018). Apple and its subsidiaries appealed the judgments and requested a preliminary stay of enforcement pending the appeals. On January 15, 2019, the Mannheim District Court issued a judgment declaring one of the patents asserted on October 2, 2017 as not infringed. All other patents remain pending. Dates for the pronouncements of judgment and hearings are scheduled for various dates through September 2019.

- added (2019-01-30):
[0001728949-19-000012:note_history:19]
On September 29, 2017, we filed three complaints against Apple and certain of its subsidiaries in the Beijing (China) Intellectual Property Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On May 10, 2018 and June 21, 2018, Apple filed invalidation requests with the Chinese Patent Review Board (PRB) for the three asserted patents. The PRB has not ruled on the invalidation requests.

- added (2019-01-30):
[0001728949-19-000012:note_history:20]
On November 13, 2017, we filed three complaints against certain of Apple’s subsidiaries in the Beijing (China) High People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief, damages and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On December 19, 2017, Apple’s subsidiaries filed invalidation requests with the PRB for the three asserted patents. PRB hearings regarding the validity of the patents were held in April and May 2018. The PRB issued rulings upholding the validity of all three patents. On May 22, 2018, Apple’s subsidiaries filed a second invalidation request with the PRB for one of the three asserted patents. The PRB held a hearing regarding this request on October 19, 2018. On November 30, 2018 and December 5, 2018, Apple appealed all three validity rulings from the PRB to the Beijing IP Court.

- added (2019-01-30):
[0001728949-19-000012:note_history:21]
On November 15, 2017, we filed three complaints against certain of Apple’s subsidiaries in the Fuzhou (China) Intermediate People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple’s subsidiaries filed invalidation requests with the PRB on December 8, 2017 for one of the patents and December 11, 2017 for the other two patents. PRB hearings regarding the validity of the patents were held in April and May 2018. The PRB issued orders upholding the validity of two of the patents subject to Apple’s invalidity challenges. The PRB ruled that the third patent was invalid. We subsequently withdrew the infringement action in Fuzhou with respect to the third patent. Infringement hearings were held from August through October 30, 2018. On November 30, 2018, the court granted our motions for preliminary injunctions with respect to two of the patents and enjoined Apple’s subsidiaries from importing, selling and offering to sell the iPhone 6S through X.

- changed (2019-01-30):
[0001728949-19-000012:note_history:22]
On January 12, 2018, we filed three additional complaints against Apple and certain of its subsidiaries in the Fuzhou (China) Intermediate People’s Court, asserting infringement of three additional patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.
  (was, 2018-07-25, similarity 0.9748):
[0001728949-18-000075:note_history:22]
On January 12, 2018, the Company filed three additional complaints against Apple and certain of its subsidiaries in the Fuzhou (China) Intermediate People’s Court, asserting infringement of three additional Company patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

- added (2019-01-30):
[0001728949-19-000012:note_history:23]
Also, on January 12, 2018, we filed three complaints against certain of Apple’s subsidiaries in the Jiangsu (China) High People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief, damages and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On February 5, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents were held in June 2018. The PRB issued orders upholding the validity of one of the patents and partially upholding the validity of another patent. The PRB has not ruled on the invalidation request for the final patent.

- added (2019-01-30):
[0001728949-19-000012:note_history:24]
On February 2, 2018, we filed three complaints against certain of Apple’s subsidiaries in the Qingdao (China) Intermediate People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On February 26, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents were held in June 2018. The PRB issued orders upholding the validity of two of the patents and invalidating the third patent. We subsequently withdrew the infringement action in Qingdao with respect to the third patent.

- added (2019-01-30):
[0001728949-19-000012:note_history:25]
Also, on February 2, 2018, we filed three complaints against certain of Apple’s subsidiaries in the Guangzhou (China) Intermediate People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On March 14, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents began in July 2018. The PRB issued orders upholding the validity of two of the patents. The PRB has not ruled on the invalidation request for the final patent. Infringement hearings for all three of the patents were held in October through December 2018.

- changed (2019-01-30):
[0001728949-19-000012:note_history:26]
On June 14, 2018, we filed three complaints against certain of Apple’s subsidiaries in the Guangdong (China) High People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On August 13, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. The PRB has held hearings regarding all three of the patents.
  (was, 2018-07-25, similarity 0.8166):
[0001728949-18-000075:note_history:26]
On June 14, 2018, the Company filed three complaints against certain of Apple’s subsidiaries in the Guangdong (China) High People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

- changed (2019-01-30):
[0001728949-19-000012:note_history:27]
We believe Apple’s counterclaims and invalidation requests in the above matters are without merit.
  (was, 2018-07-25, similarity 0.6466):
[0001728949-18-000075:note_history:27]
The Company believes Apple’s (as well as Compal’s, Foxconn’s, Pegatron’s and Wistron’s) claims in the above matters are without merit.

- added (2019-01-30):
[0001728949-19-000012:note_history:28]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, a securities class action complaint was filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers. On April 29, 2016, the plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, the plaintiffs filed a second amended complaint, alleging that we and certain of our current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding our business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint sought unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, we filed a motion to dismiss the second amended complaint. On October 20, 2017, the court entered an order granting in part our motion to dismiss, and on November 29, 2017, the court entered an order granting the remaining portions of our motion to dismiss. On December 28, 2017, the plaintiffs filed an appeal to the United States Court of Appeals for the Ninth Circuit. No hearing date has been set. We believe the plaintiffs’ claims are without merit.

- added (2019-01-30):
[0001728949-19-000012:note_history:29]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. The court has not yet ruled on our motion to dismiss. We believe the plaintiffs’ claims are without merit.

- added (2019-01-30):
[0001728949-19-000012:note_history:30]
In re Qualcomm/Broadcom Merger Securities Litigation (formerly Camp v. Qualcomm Incorporated et al): On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints allege, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints seek unspecified damages, interest, fees and costs. On January 22, 2019, the Court appointed the lead plaintiff in the action and designated that the case be captioned “In re Qualcomm/Broadcom Merger Securities Litigation.” Upon the filing of a consolidated complaint in the action, we anticipate filing a motion to dismiss the complaint, as we believe the plaintiffs’ claims are without merit.

- added (2019-01-30):
[0001728949-19-000012:note_history:31]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Twenty-two such cases remain outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the Ninth Circuit Court of Appeals granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. We believe the plaintiffs’ claims are without merit.

- changed (2019-01-30):
[0001728949-19-000012:note_history:32]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, six consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia, and the Quebec Superior Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the FTC and U.S. consumer class action complaints. The complaints seek unspecified damages. We have not yet answered the complaints.
  (was, 2018-07-25, similarity 0.951):
[0001728949-18-000075:note_history:32]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, six consumer class action complaints have been filed against the Company in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia, and the Quebec Superior Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the FTC and U.S. consumer class action complaints. The complaints seek unspecified damages. The Company has not yet answered the complaints.

- added (2019-01-30):
[0001728949-19-000012:note_history:33]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that our business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that our Japanese licensees were forced to cross-license patents to us on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against our other licensees who made a similar commitment in their license agreements with us. The cease and desist order seeks to require us to modify our existing license agreements with Japanese companies to eliminate these provisions while preserving the license of our patents to those companies. We disagree with the conclusions that we forced our Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. We invoked our right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted our motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 37 different dates. No further hearings are currently scheduled. Fines or other monetary remedies are not available in this matter.

- added (2019-01-30):
[0001728949-19-000012:note_history:34]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that we violated Korean law by offering certain discounts and rebates for purchases of our CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents expired. The KFTC levied a fine, which we paid and recorded as an expense in fiscal 2010. We appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, we filed an appeal with the Korea Supreme Court. We understand that the Korea Supreme Court intends to issue a decision in this matter on January 30, 2019.

- added (2019-01-30):
[0001728949-19-000012:note_history:35]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (iii) not demand unjustifiable conditions in our license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred to in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred to in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean Won (approximately $927 million), which we paid on March 30, 2017. We believe that our business practices do not violate the MRFTA, and on February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. On the same day, we filed an application with the Seoul High Court to stay the decision’s remedial order pending the Seoul High Court’s final judgment on our action to cancel the KFTC’s decision. On September 4, 2017, the Seoul High Court denied our application to stay the remedial order, and on November 27, 2017, the Korea Supreme Court dismissed our appeal of the Seoul High Court’s decision on the application to stay. The Seoul High Court has not ruled on our action to cancel the KFTC’s decision.

- added (2019-01-30):
[0001728949-19-000012:note_history:36]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, we were engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On August 15, 2016, we submitted our response to the Statement of Objections. On July 19, 2018, the EC announced that it had issued a Supplementary Statement of Objections which focuses on certain elements of the “price-cost” test applied by the EC to assess the extent to which we sold certain baseband chipsets allegedly below cost. On October 22, 2018, we submitted our response to the Supplementary Statement of Objections. On January 10, 2019, the EC held a hearing regarding the Supplementary Statement of Objections and our response to it. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of our revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. We believe that our business practices do not violate the European Union (EU) competition rules.

- added (2019-01-30):
[0001728949-19-000012:note_history:37]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that, pursuant to an agreement with Apple Inc., since 2011, we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets. This conduct allegedly reduced Apple’s incentives to source baseband chipsets from our competitors and harmed competition and innovation for certain baseband chipsets. On January 24, 2018, the EC issued a decision finding that certain terms of that agreement violate EU competition law and imposed a fine of 997 million Euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not ruled on our appeal. We believe that our business practices do not violate the EU competition rules.

- added (2019-01-30):
[0001728949-19-000012:note_history:38]
We recorded a charge of $1.2 billion to other expenses related to the EC fine in the first quarter of fiscal 2018. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. As of October 1, 2018, we have designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 30, 2018, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.2 billion and included in other current liabilities.

- added (2019-01-30):
[0001728949-19-000012:note_history:39]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of cellular modem chipsets on the purchaser first agreeing to a license to our cellular standard-essential patents, paying incentives to purchasers of cellular modem chipsets to induce them to accept certain license terms, refusing to license our cellular standard-essential patents to our competitors, and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint seeks a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief. A fine is not an available remedy in this matter, and we do not believe that other monetary remedies are likely. On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to rival sellers of cellular modem chipsets. On October 15, 2018, we and the FTC submitted a Joint Administrative Motion asking the District Court to defer ruling on the FTC’s partial summary judgment motion in order to facilitate the parties’ ongoing discussions concerning settlement of this litigation, which the District Court denied on the same day. On November 6, 2018, the District Court granted the FTC’s partial summary judgment motion. On November 29, 2018, we and the FTC filed a Joint Pretrial Statement in which the FTC seeks a declaration and adjudication that our conduct violates the FTCA and seeks permanent injunctive and other equitable relief, including an order that would at least (i) require us to: negotiate or renegotiate license terms with licensees in good faith under conditions free from the threat of lack of access to or discriminatory provision of cellular modem chipset supply or associated technical, software or other support; submit to arbitral or judicial dispute resolution to determine reasonable royalties and other license terms should a licensee choose to pursue such a resolution; make exhaustive standard-essential patent licenses available to cellular modem chipset suppliers on FRAND terms and submit to arbitral or judicial dispute resolution to determine such terms; and adhere to certain compliance and monitoring procedures; and (ii) prohibit us from: conditioning the supply of cellular modem chipsets on a customer’s patent-license status; discriminating or retaliating against cellular modem chipset customers or cellular modem chipset suppliers because of a customer’s license status or a dispute over license terms; making payments or providing other value contingent on a customer’s agreement to license terms; entering into exclusive-dealing agreements for the supply of cellular modem chipsets; or interfering with the ability of customers to communicate with a government agency about a potential law enforcement or regulatory matter. Trial was held January 4-29, 2019. The FTC alleged at trial that we have monopoly power in the markets for both CDMA and premium-tier LTE cellular modem chipsets and have acted anticompetitively in violation of either Section 1 or Section 2 of the Sherman Act, or Section 5 of the FTCA to maintain our monopoly power in one or both of these alleged markets by employing four business practices. These practices include (i) our longstanding practice of requiring a license to our cellular standard-essential patents for a particular cellular standard before selling cellular modem chipsets that are used in cellular devices that implement such cellular standards; (ii) providing incentive payments to certain licensees to agree to our preferred license terms; (iii) not exhaustively licensing our cellular standard-essential patents to companies that make, use or sell cellular modem chipsets; and (iv) entering into a now-expired contract that conditioned certain payments to Apple on its not launching a new device that used a non-Qualcomm brand cellular modem chipset. In asserting that we have acted anticompetitively, the FTC asserts that our historical royalty rates are too high to be reasonable, and that amounts over a reasonable rate act as a surcharge on CDMA or premium-tier LTE cellular modem chipset transactions taking place between OEMs and our competitors, and this surcharge weakens our competitors by raising the price OEMs must pay for such CDMA or premium-tier LTE cellular modem chipsets. We believe the FTC’s claims in this case are without merit.

- added (2019-01-30):
[0001728949-19-000012:note_history:40]
Contingent losses and other considerations: We will continue to vigorously defend ourself in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fine, we have not recorded any accrual at December 30, 2018 for contingent losses associated with these matters based on our belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. For example, if some or all of our license agreements are declared invalid or unenforceable and we are required to renegotiate these license agreements, or if as part of a settlement we agree to renegotiate certain of our license agreements, we may not receive, or may not be able to recognize, any licensing or royalty revenues on the impacted license agreements unless and until we enter into new license agreements. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- added (2019-01-30):
[0001728949-19-000012:note_history:41]
Indemnifications. We generally do not indemnify our customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by us, or by intellectual property provided by us to chipset foundries and semiconductor assembly and test service providers. Our obligations under these agreements may be limited in terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us.

- added (2019-01-30):
[0001728949-19-000012:note_history:42]
Through December 30, 2018, we have received a number of claims from our direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by our products. Reimbursements under indemnification arrangements have not been material to our consolidated financial statements. We have not recorded any accrual for contingent liabilities at December 30, 2018 associated with these indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- added (2019-01-30):
[0001728949-19-000012:note_history:43]
Purchase Obligations and Operating Leases. We have agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization. We lease certain of our land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases.

- changed (2019-01-30):
[0001728949-19-000012:note_history:44]
Obligations under our purchase agreements, which primarily relate to integrated circuit product inventory obligations and future minimum lease payments under our operating leases, at December 30, 2018 were as follows (in millions):
  (was, 2018-07-25, similarity 0.7253):
[0001728949-18-000075:note_history:44]
Obligations under these purchase agreements and future minimum lease payments under these operating leases at June 24, 2018 were as follows (in millions):

- added (2019-01-30):
[0001728949-19-000012:note_history:45]
|  | Purchase Obligations |  | Operating Leases |
| Remainder of fiscal 2019 | $ | 3,748 |  |  | $ | 91 |  |
| 2020 | 499 |  |  | 106 |  |
| 2021 | 251 |  |  | 83 |  |
| 2022 | 45 |  |  | 51 |  |
| 2023 | 9 |  |  | 30 |  |
| Thereafter | 4 |  |  | 43 |  |
| Total | $ | 4,556 |  |  | $ | 404 |  |

- changed (2019-01-30):
[0001728949-19-000012:note_history:46]
Other Commitments. At December 30, 2018, we committed to fund certain strategic investments up to $282 million, of which $31 million and $66 million was expected to be funded in fiscal 2020 and fiscal 2021, respectively. The remaining commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all.
  (was, 2018-07-25, similarity 0.9206):
[0001728949-18-000075:note_history:46]
Other Commitments. At June 24, 2018, the Company was committed to fund certain strategic investments up to $544 million, of which $218 million, $37 million and $74 million was expected to be funded in the remainder of fiscal 2018, fiscal 2019 and fiscal 2021, respectively. The remaining commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all.

- changed (2019-01-30):
[0001728949-19-000012:note_history:47]
In March 2018, our RF360 Holdings joint venture entered into an agreement for a build-to-suit construction project with a third-party lessor for the development of a manufacturing facility located in Singapore. The agreement includes a long-term lease commitment with a noncancelable 10-year term commencing upon completion of the construction project. At December 30, 2018, the minimum lease commitment under the agreement based on the noncancelable term was $87 million.
  (was, 2018-07-25, similarity 0.7927):
[0001728949-18-000075:note_history:47]
In March 2018, the Company’s RF360 Holdings joint venture entered into an agreement for a build-to-suit construction project with a third-party lessor for the development of a manufacturing facility located in Singapore. The agreement includes a long-term lease commitment with a noncancelable 10-year term commencing upon completion of the construction project. At June 24, 2018, the minimum lease commitment under the agreement based on the noncancelable term was approximately $87 million.

- removed (2019-01-30):
[0001728949-18-000075:note_history:48]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe certain ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 ParkerVision patents and seeks damages and injunctive and other relief. On December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against the Company and other parties with the United States International Trade Commission (ITC) described below. Subsequently, ParkerVision announced that it had reached a settlement with Samsung which dismissed the Samsung entities from the District Court case. The Company had previously filed Inter-Partes Review petitions with the United States Patent and Trademark Office (USPTO) to invalidate all asserted claims of several of the remaining patents. On March 7, 2017, the USPTO decided in the Company’s favor with respect to all asserted claims of one such patent. After the ITC action described below was closed, and upon agreement among the parties, on May 24, 2017, the District Court further stayed the District Court case pending ParkerVision’s appeal of the USPTO’s invalidation decisions. A hearing on ParkerVision’s appeal before the United States Court of Appeals for the Federal Circuit is scheduled for August 7, 2018.

- removed (2019-01-30):
[0001728949-18-000075:note_history:49]
On December 14, 2015, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. were also named defendants. The complaint asserts that certain of the Company’s products infringe four additional ParkerVision patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. On February 12, 2016, the District Court case was stayed pending completion of the ITC investigation. Subsequently, ParkerVision announced that it had reached a settlement with Samsung which dismissed the Samsung entities from the ITC investigation and related District Court case. On February 2, 2017, the ITC granted ParkerVision’s motion to drop all but one patent and one accused product from the ITC investigation. On March 12, 2017, one day before the ITC hearing was scheduled to begin, ParkerVision moved to withdraw its ITC complaint in its entirety. The Company and the other defendants did not oppose the withdrawal of the complaint. On April 28, 2017, the ITC formally closed the investigation. On May 4, 2017, ParkerVision filed a motion to reopen the related District Court Case, and on May 26, 2017, the District Court granted the motion. On March 16, 2018, the parties agreed to dismiss three of ParkerVision’s patents from the case without prejudice, leaving only one patent at issue. A claim construction hearing is scheduled for August 31, 2018. No trial date has been set.

- removed (2019-01-30):
[0001728949-18-000075:note_history:50]
Apple Inc. (Apple) v. QUALCOMM Incorporated: On January 20, 2017, Apple filed a complaint against the Company in the United States District Court for the Southern District of California seeking declarations with respect to several of the Company’s patents and alleging that the Company breached certain agreements and violated federal antitrust and California state unfair competition laws. In its initial complaint, Apple sought declaratory judgments of non-infringement by Apple of nine of the Company’s patents, or in the alternative, a declaration of royalties Apple must pay for the patents. Apple further sought a declaration that the Company’s sale of baseband chipsets exhausts the Company’s patent rights for patents embodied in those chipsets. Separately, Apple sought to enjoin the Company from seeking excessive royalties from Apple and to disgorge royalties paid by Apple’s contract manufacturers that the court finds were not fair, reasonable and non-discriminatory (FRAND). Apple also claimed that the Company’s refusal to make certain payments to Apple under a Business Cooperation and Patent Agreement (Cooperation Agreement) constitutes a breach of contract in violation of California law and sought damages in the amount of the unpaid payments, alleged to be approximately $1 billion. In addition, Apple claimed that the Company has refused to deal with competitors in contravention of the Company’s agreements with applicable standard setting organizations, has used its market position to impose contractual obligations on Apple that prevented Apple from challenging the Company’s licensing practices, has tied the purchase of the Company’s CDMA-enabled and “premium” LTE-enabled chipsets to licensing certain of the Company’s patents and has required Apple to purchase baseband chipsets exclusively from the Company as a condition of the Company’s payment to Apple of certain rebates, in violation of Section 2 of the Sherman Act and the California Unfair Competition Law. Apple sought injunctive relief with respect to these claims and a judgment awarding its expenses, costs and attorneys’ fees.

- removed (2019-01-30):
[0001728949-18-000075:note_history:51]
Fact discovery is substantially closed in these cases. A final pretrial conference is scheduled for November 30, 2018. The trials have not been scheduled.

- removed (2019-01-30):
[0001728949-18-000075:note_history:52]
On January 23, 2017, an Apple subsidiary in China filed two complaints against the Company in the Beijing Intellectual Property Court. On March 31, 2017, the court granted an application by Apple Inc. to join the actions as a plaintiff, and Apple amended the complaints. One of the complaints alleges a violation of China’s Anti-Monopoly Law (AML complaint); the other complaint requests a determination of the terms of a patent license between the Company and Apple (FRAND complaint). The AML complaint alleges that (i) the Company has abused its dominant position in communication standard-essential patents licensing markets and certain global baseband chipset markets by charging and offering royalty terms that were excessively high; (ii) the Company refused to license certain implementers of standardized technologies, including Apple and baseband chipset manufacturers; (iii) the Company forced Apple to use only the Company’s products and services; and (iv) the Company bundled licenses to standard-essential patents with licenses to non-standard-essential patents and imposed other unreasonable or discriminatory trading terms on Apple in violation of the AML. The AML complaint seeks a decree that the Company cease the alleged abuse of dominance, as well as damages in the amount of 1 billion Chinese Renminbi (approximately $154 million based on the exchange rate on June 24, 2018). The FRAND complaint makes allegations similar to the AML complaint and further alleges that the Company refused to offer licensing terms for the Company’s cellular standard-essential patents consistent with the Company’s FRAND licensing commitments and failed to provide to Apple certain information about the Company’s patents. The FRAND complaint seeks (i) a declaration that the license terms offered to Apple by the Company for its mobile communication standard essential patents are not compliant with FRAND; (ii) an order that the Company cease its actions that allegedly violate the Company’s FRAND obligations, including pricing on unfair, unreasonable and excessive terms, refusing to deal, imposing unreasonable trade conditions and failing to provide information on the Company’s patents; and (iii) a determination of FRAND-compliant license terms for the Company’s Chinese standard-essential patents. Apple also seeks its expenses in each of the cases. On August 3, 2017, the Company received three additional complaints filed by an Apple subsidiary and Apple Inc. against the Company in the Beijing Intellectual Property Court. The complaints seek declaratory judgments of non-infringement of three Qualcomm patents. The Company filed jurisdictional and other objections to the complaints, which the court denied on May 31, 2018. On July 5, 2018, the Company appealed the denial of its objections to the Beijing High People’s Court.

- removed (2019-01-30):
[0001728949-18-000075:note_history:53]
On March 2, 2017, the Company learned that Apple and certain of its European subsidiaries issued a Claim Form against the Company in the UK High Court of Justice, Chancery Division, Patents Court on January 23, 2017. Apple subsequently filed an Amended Claim Form and Particulars of Claim. Both the Amended Claim Form and the Particulars of Claim allege several European competition law claims, including refusal to license competing chipmakers, failure to offer Apple a direct license to the Company’s standard-essential patents on FRAND terms, demanding excessive royalties for the Company’s standard-essential patents, and demanding excessive license fees for the use of the Company’s standard-essential patents in connection with chipsets purchased from the Company. Apple also seeks declarations that the Company is obliged to offer a direct patent license to Apple in respect of standard-essential patents actually practiced on fair, reasonable and non-discriminatory terms and that using the Company’s chipsets does not infringe any of the Company’s patents because the Company exhausted its patent rights. Finally, Apple seeks declarations that five of the Company’s European (UK) patents are invalid and not essential, and an order that each of those patents be revoked.

- removed (2019-01-30):
[0001728949-18-000075:note_history:54]
On April 18, 2017, Apple and one of its Taiwanese subsidiaries filed a complaint against the Company in the Taiwan Intellectual Property Court alleging that the Company has abused a dominant market position in licensing wireless standard-essential patents and selling baseband chipsets, including improper pricing, refusal to deal, exclusive dealing, tying, imposing unreasonable trade terms and discriminatory treatment. The complaint seeks rulings that the Company not use the sales price of the terminal device as the royalty base for standard-essential patents; not leverage its cellular standard-essential patents to obtain licenses of its non-standard-essential patents or demand cross-licenses without proper compensation; not refuse, reduce, delay or take any other action to limit the supply of its baseband chipsets to non-licensees; that the Company must license its standard-essential patents on FRAND terms; and that the Company shall not, based on standard-essential patents, seek injunctions. The complaint also seeks damages of 10 million Taiwan Dollars (less than $1 million based on the exchange rate on June 24, 2018), among other relief.

- removed (2019-01-30):
[0001728949-18-000075:note_history:55]
QUALCOMM Incorporated v. Apple Inc.: On July 6, 2017, the Company filed a complaint against Apple in the United States District Court for the Southern District of California asserting claims for damages and injunctive relief for infringement of six of the Company’s patents directed to a variety of features found in iPhone models. On July 7, 2017, the Company filed a complaint against Apple in the United States International Trade Commission (ITC) requesting that the ITC institute an investigation pursuant to Section 337 of the Tariff Act of 1930 based on Apple’s infringement of the same six patents. The Company is seeking a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple filed an Answer and Counterclaims in the District Court case on September 26, 2017. On November 29, 2017, Apple filed a First Amended Answer and Counterclaims asserting that the Company’s Snapdragon processors infringe eight Apple patents. On August 8, 2017, the ITC issued a notice of institution of an investigation. On August 25, 2017, the Company withdrew allegations as to one patent in both the ITC investigation and the District Court case. On April 25, 2018, the Company withdrew allegations as to two additional patents in the ITC investigation, but not the district court case, in order to satisfy certain briefing limitations and to narrow the issues for hearing. The ITC investigation evidentiary hearing by the Administrative Law Judge (ALJ) was held June 18-26, 2018. The ALJ’s Initial Determination on the merits is due on September 14, 2018, and the target date for final determination by the ITC is set for January 14, 2019. A case management conference in the district court case was held on January 26, 2018. On March 2, 2018, the court granted the Company’s motion to sever, for separate trial, Apple’s counterclaims for patent infringement against the Company. With respect to the Company’s patent claims against Apple, fact discovery closed on June 11, 2018, and a claim construction hearing is set for July 31, 2018. Trial is scheduled to begin on March 4, 2019. With respect to Apple’s patent claims against the Company, fact discovery is scheduled to close on December 3, 2018. A claim construction hearing is scheduled for September 5, 2018, and trial is scheduled to begin on July 15, 2019. On June 28, 2018, Intel filed petitions with the USPTO Patent Trial and Appeal Board (PTAB) challenging the validity of one of the patents asserted in the July 7, 2017 ITC investigation and corresponding District Court case. On June 29, 2018 and July 6, 2018, Intel filed petitions with the USPTO PTAB challenging the validity of another patent asserted in the July 7, 2017 ITC investigation and corresponding District Court case. On July 3, 2018, Intel filed petitions with the USPTO PTAB challenging the validity of two additional patents asserted in the July 7, 2017 ITC investigation and corresponding District Court case.

- removed (2019-01-30):
[0001728949-18-000075:note_history:56]
On November 29, 2017, the Company filed three additional complaints against Apple in the United States District Court for the Southern District of California alleging infringement of a total of 16 of the Company’s patents. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. The complaints seek damages and injunctive relief. On January 22, 2018, Apple filed Answers and Counterclaims in each of these cases seeking declaratory judgments that the asserted patents are invalid and/or not infringed. Case management conferences were held on February 7, 2018 and March 1, 2018. Tutorials and presentation of claim construction arguments for two of the cases are scheduled for September 12-13, 2018 and October 10 - 11, 2018, respectively. For the case relating to the November 30, 2017 ITC investigation described below, a mandatory settlement conference is scheduled for October 19, 2018, fact discovery is scheduled to close on March 13, 2019, and trial is scheduled to begin on October 21, 2019. On June 18, 2018, Apple filed a petition with the USPTO PTAB challenging the validity of one patent asserted in the November 30, 2017 ITC investigation and the corresponding District Court case. On June 29, 2018, Apple filed petitions with the USPTO PTAB challenging the validity of another patent asserted in the November 30, 2017 ITC investigation and the corresponding District Court case. No trial date has been set for the other two cases.

- removed (2019-01-30):
[0001728949-18-000075:note_history:57]
On July 17, 2017, the Company filed complaints against Apple and certain of its subsidiaries in the Federal Republic of Germany, asserting infringement of one of the Company’s patents in the Mannheim District Court and infringement of another patent in the Munich District Court. On October 2, 2017, the Company filed claim extensions in these actions against Apple and certain of its subsidiaries, asserting infringement of two additional patents in the Mannheim District Court and infringement of five additional patents in the Munich District Court. On May 28, 2018, the Company filed additional claim extensions in these actions against Apple and certain of its subsidiaries, asserting infringement of three additional patents in the Mannheim District Court and infringement of one additional patent in the Munich District Court. The complaints seek remedies including, among other relief, declaratory relief confirming liability on the merits for damages and injunctive relief. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Hearings are scheduled for various dates through March 2019.

- removed (2019-01-30):
[0001728949-18-000075:note_history:58]
On September 29, 2017, the Company filed three complaints against Apple and certain of its subsidiaries in the Beijing (China) Intellectual Property Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On May 10, 2018 and June 21, 2018, Apple filed invalidation requests with the PRB for the three asserted patents. The PRB has not set hearing dates for these proceedings.

- removed (2019-01-30):
[0001728949-18-000075:note_history:59]
On November 13, 2017, the Company filed three complaints against certain of Apple’s subsidiaries in the Beijing (China) High People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief, damages and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On December 19, 2017, Apple’s subsidiaries filed invalidation requests with the Chinese Patent Review Board (PRB) for each of the three asserted patents. PRB hearings regarding the validity of the patents were held in April and May 2018. On May 22, 2018, Apple’s subsidiaries filed a second invalidation request with the PRB for one of the three asserted patents. The PRB has not ruled on the invalidation requests.

- removed (2019-01-30):
[0001728949-18-000075:note_history:60]
On November 15, 2017, the Company filed three complaints against certain of Apple’s subsidiaries in the Fuzhou (China) Intermediate People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple’s subsidiaries filed invalidation requests with the PRB on December 8, 2017 for one of the patents and December 11, 2017 for the other two patents. PRB hearings regarding the validity of the patents were held in April and May 2018. On July 13, 2018, the PRB issued an order upholding the validity of one of the patents subject to Apple’s invalidity challenges. The PRB has not ruled on the invalidation requests with respect to the other two patents.

- removed (2019-01-30):
[0001728949-18-000075:note_history:61]
Also on January 12, 2018, the Company filed three complaints against certain of Apple’s subsidiaries in the Jiangsu (China) High People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief, damages and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On February 5, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents were held in June 2018. The PRB has not ruled on the invalidation requests.

- removed (2019-01-30):
[0001728949-18-000075:note_history:62]
On February 2, 2018, the Company filed three complaints against certain of Apple’s subsidiaries in the Qingdao (China) Intermediate People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On February 26, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents were held in June 2018. The PRB has not ruled on the invalidation requests.

- removed (2019-01-30):
[0001728949-18-000075:note_history:63]
Also on February 2, 2018, the Company filed three complaints against certain of Apple’s subsidiaries in the Guangzhou (China) Intermediate People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On March 14, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents began in July 2018. The PRB has not ruled on the invalidation requests.

- removed (2019-01-30):
[0001728949-18-000075:note_history:64]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, plaintiffs filed a securities class action complaint against the Company and certain of its current and former officers in the United States District Court for the Southern District of California. On April 29, 2016, plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, plaintiffs filed a second amended complaint, alleging that the Company and certain of its current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding the Company’s business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint sought unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, the Company filed a motion to dismiss the second amended complaint. On October 20, 2017, the court entered an order granting in part the Company’s motion to dismiss, and on November 29, 2017, the court entered an order granting the remaining portions of the Company’s motion to dismiss. On December 28, 2017, the plaintiffs filed an appeal to the United States Court of Appeals for the Ninth Circuit. No hearing date has been set. The Company believes the plaintiffs’ claims are without merit.

- removed (2019-01-30):
[0001728949-18-000075:note_history:65]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of the Company in the United States District Court for the Southern District of California against the Company and certain of its current and former officers and directors. The complaints alleged, among other things, that the defendants violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that the Company is or was engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, the defendants filed a motion to dismiss the consolidated amended complaint. The court has not yet ruled on the motion. The Company believes the plaintiffs’ claims are without merit.

- removed (2019-01-30):
[0001728949-18-000075:note_history:66]
Camp v. Qualcomm Incorporated et al: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of the Company in the United States District Court for the Southern District of California against the Company and two of its current officers. The two complaints allege, among other things, that the defendants violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by failing to disclose that the Company had made a filing with the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints seek unspecified damages, interest, fees and costs. Upon the appointment of lead plaintiff in the action and the filing of a First Amended Complaint, the Company anticipates filing a motion to dismiss the complaint, as it believes the plaintiffs’ claims are without merit.

- removed (2019-01-30):
[0001728949-18-000075:note_history:67]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against the Company in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Twenty-two such cases remain outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that the Company violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to its competitors, conditioning the supply of certain of its baseband chipsets on the purchaser first agreeing to license the Company’s entire patent portfolio, entering into exclusive deals with companies including Apple Inc., and charging unreasonably high royalties that do not comply with the Company’s commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that the Company be enjoined from further unlawful conduct. On August 11, 2017, the Company filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied the Company’s motion to dismiss the consolidated amended complaint, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and a hearing on that motion is scheduled for September 27, 2018. The case is currently in the discovery stage, with discovery scheduled to close on December 28, 2018. Trial is scheduled to begin on January 19, 2019. The Company believes the plaintiffs’ claims are without merit.

- removed (2019-01-30):
[0001728949-18-000075:note_history:68]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 37 different dates. No further hearings are currently scheduled. Fines or other monetary remedies are not available in this matter.

- removed (2019-01-30):
[0001728949-18-000075:note_history:69]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments since then with respect to this matter.

- removed (2019-01-30):
[0001728949-18-000075:note_history:70]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it was conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that the Company violated provisions of the MRFTA. On January 22, 2017, the Company received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with the Company; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders the Company to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chips; (iii) not demand unjustifiable conditions in the Company’s license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on the Company and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between the Company and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred to in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred to in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of approximately 1.03 trillion Korean Won (approximately $927 million), which was paid on March 30, 2017. The Company believes that its business practices do not violate the MRFTA, and on February 21, 2017 filed an action in the Seoul High Court to cancel the KFTC’s decision. On the same day, the Company filed an application with the Seoul High Court to stay the decision’s remedial order pending the Seoul High Court’s final judgment on the Company’s action to cancel the KFTC’s decision. On September 4, 2017, the Seoul High Court denied the Company’s application to stay the remedial order, and on November 27, 2017, the Korea Supreme Court dismissed the Company’s appeal of the Seoul High Court’s decision on the application to stay. The Seoul High Court has not ruled on the Company’s action to cancel the KFTC’s decision.

- removed (2019-01-30):
[0001728949-18-000075:note_history:71]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided the Company with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the EC to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company provided additional documents and information as requested by the EC. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On August 15, 2016, the Company submitted its response to the Statement of Objections. On July 19, 2018, the EC announced that it had issued a Supplementary Statement of Objections which focuses on certain elements of the "price-cost" test applied by the EC to assess the extent to which the Company sold certain baseband chipsets allegedly below cost. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of the Company’s revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. The Company believes that its business practices do not violate the European Union (EU) competition rules.

- removed (2019-01-30):
[0001728949-18-000075:note_history:72]
European Commission (EC) Investigation: On October 15, 2014, the EC notified the Company that it was conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that, pursuant to an agreement with a customer, since 2011 the Company paid significant amounts to that customer on condition that it exclusively use the Company’s baseband chipsets in its smartphones and tablets. This conduct allegedly reduced the customer’s incentives to source chipsets from the Company’s competitors and harmed competition and innovation for certain baseband chipsets. On January 24, 2018, the EC issued a decision finding that certain terms of that agreement violate EU competition law and imposed a fine of approximately 997 million Euros. On April 6, 2018, the Company filed an appeal of the EC’s decision with the General Court of the European Union. The court has not ruled on the Company’s appeal. The Company believes that its business practices do not violate the EU competition rules.

- removed (2019-01-30):
[0001728949-18-000075:note_history:73]
The Company recorded a charge of $1.18 billion to other expenses related to the EC fine in the first quarter of fiscal 2018. The Company provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while the Company appeals the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum until it is paid or annulled. At June 24, 2018, the liability, including related foreign currency gains and accrued interest (which were recorded in investment and other income, net), was $1.17 billion and included in other current liabilities.

- removed (2019-01-30):
[0001728949-18-000075:note_history:74]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against the Company in the United States District Court for the Northern District of California alleging that the Company engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of baseband processors on the purchaser first agreeing to a license to the Company’s standard-essential patents, paying incentives to purchasers of baseband processors to induce them to accept certain license terms, refusing to license its standard-essential patents to the Company’s competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint seeks a permanent injunction against the Company’s alleged violations of the FTCA and other unspecified ancillary equitable relief. A fine is not an available remedy in this matter, and the Company does not believe that other monetary remedies are likely. On April 19, 2017, the court set a trial date for January 4, 2019. The Company believes the FTC’s claims are without merit.

- removed (2019-01-30):
[0001728949-18-000075:note_history:75]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified the Company that it was conducting an investigation into whether the Company’s patent licensing practices violate the Taiwan Fair Trade Act (TFTA). On October 11, 2017, the TFTC announced that it had reached a decision in the investigation, finding that the Company violated the TFTA. On October 23, 2017, the Company received TFTC’s formal written decision, which found that the following conducts violate the TFTA: (i) refusing to license and demanding restrictive covenants from chip competitors; (ii) refusing to supply baseband processors to companies that do not have an executed license; and (iii) providing a royalty discount to Apple in exchange for its exclusive use of the Company’s chipsets. The TFTC’s decision was based on a four-three vote, and included three written dissents. The TFTC’s decision orders the Company to: (1) cease the following conduct within 60 days of the day after receipt of the decision: (a) applying the clauses in an agreement entered into with a competing chip supplier requesting it to provide sensitive sales information such as chip prices, customers, sales volumes, product types and serial numbers; (b) applying clauses in component supply agreements entered into with handset manufacturers relating to the refusal to sell chips to unlicensed manufacturers; and (c) applying discount clauses in the exclusive agreement entered into with a relevant enterprise; (2) notify competing chip companies and handset manufacturers in writing within 30 days after receipt of the decision that those companies may request to amend or enter into patent license agreements and other relevant agreements within 60 days of the day following the day such notices are received, and upon receipt of such requests, the Company shall commence negotiation in good faith; (3) submit status reports to the TFTC on any such negotiations every six months beginning from the day after receipt of the decision, as well as to submit a report to the TFTC within 30 days after amendments to any license agreements or newly signed license agreements are executed. The TFTC’s decision also imposed a fine of 23.4 billion Taiwan Dollars. The Company believes that its business practices do not violate the TFTA, and on November 10, 2017, the Company filed an Application for Stay of Enforcement (Stay Application) of the TFTC’s decision in the Taiwan Intellectual Property Court (IPC). On December 22, 2017, the Company filed an Administrative Litigation Complaint in the IPC to revoke the TFTC’s decision. On May 24, 2018, the Company withdrew its Stay Application. The IPC has not yet ruled on the Company’s Administrative Litigation Complaint to revoke the TFTC’s decision.

- removed (2019-01-30):
[0001728949-18-000075:note_history:76]
The Company recorded a charge of $778 million to other expenses related to the TFTC fine in the fourth quarter of fiscal 2017. The fine will be paid in monthly installments through December 2022. At June 24, 2018, the remaining liability, including related foreign currency gains (which were recorded in investment and other income, net), was approximately $708 million, of which $554 million was included in other noncurrent liabilities.

- removed (2019-01-30):
[0001728949-18-000075:note_history:77]
Contingent losses: The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain, and the Company faces difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Investigations by antitrust and trade regulation agencies are not conducted in a consistent manner across jurisdictions. Further, each country and agency has different sets of laws, rules and regulations, both substantive and procedural, as well as different legal principles, theories and potential remedies, and some agencies may seek to use the investigation to advance domestic policy goals. Depending on the jurisdiction, these investigations can involve non-transparent procedures under which the Company may not receive access to evidence relied upon by the enforcement agency or that may be exculpatory, and may not be informed of the specific legal theories or evidence considered or relied upon by the agency. Unlike in civil litigation in the United States, in foreign proceedings, the Company may not be entitled to discovery or depositions, allowed to cross-examine witnesses or confront its accusers. As a result, the Company may not be aware of, and may not be entitled to know, all allegations against it, or the information or documents provided to, or discovered or prepared by, the agency. Accordingly, the Company may have little or no idea what an agency’s intent is with respect to liability, penalties or the timing of a decision. In many cases the agencies are given significant discretion, and any available precedent may have limited, if any, predictive value in their jurisdictions, much less in other jurisdictions. Accordingly, the Company cannot predict the outcome of these matters.

- removed (2019-01-30):
[0001728949-18-000075:note_history:78]
Other than with respect to the TFTC and EC fines, the Company has not recorded any accrual at June 24, 2018 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

- removed (2019-01-30):
[0001728949-18-000075:note_history:79]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company, or by intellectual property provided by the Company to chipset foundries and semiconductor assembly and test service providers. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company.

- removed (2019-01-30):
[0001728949-18-000075:note_history:80]
Through June 24, 2018, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at June 24, 2018 associated with these indemnification arrangements based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- removed (2019-01-30):
[0001728949-18-000075:note_history:81]
Purchase Obligations and Operating Leases. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

- removed (2019-01-30):
[0001728949-18-000075:note_history:82]
The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases.

- removed (2019-01-30):
[0001728949-18-000075:note_history:83]
|  | Integrated Circuit Purchase Obligations |  | Other Purchase Obligations |  | Operating Leases |
| Remainder of fiscal 2018 | $ | 2,153 |  |  | $ | 665 |  |  | $ | 30 |  |
| 2019 | 1,357 |  |  | 391 |  |  | 114 |  |
| 2020 | 316 |  |  | 179 |  |  | 84 |  |
| 2021 | 60 |  |  | 67 |  |  | 63 |  |
| 2022 | 23 |  |  | 13 |  |  | 42 |  |
| Thereafter | — |  |  | 5 |  |  | 53 |  |
| Total | $ | 3,909 |  |  | $ | 1,320 |  |  | $ | 386 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-01-30):
[0001728949-19-000012:note_history:84]
Basis of Presentation and Significant Accounting Policies Update

- changed (2019-01-30):
[0001728949-19-000012:note_history:85]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for the fiscal year ended September 30, 2018. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month periods ended December 30, 2018 and December 24, 2017 included 13 weeks.
  (was, 2018-07-25, similarity 0.7895):
[0001728949-18-000075:note_history:85]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 24, 2017. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 24, 2018 and June 25, 2017 included 13 weeks and 39 weeks, respectively.

- changed (2019-01-30):
[0001728949-19-000012:note_history:86]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in our condensed consolidated financial statements and the accompanying notes. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.
  (was, 2018-07-25, similarity 0.85):
[0001728949-18-000075:note_history:86]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in the Company’s condensed consolidated financial statements and the accompanying notes. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

- added (2019-01-30):
[0001728949-19-000012:note_history:87]
Revision of Prior Period Financial Statements. In connection with the preparation of our condensed consolidated financial statements for the three months ended December 30, 2018, we identified an immaterial error related to the recognition of certain royalty revenues of our QTL (Qualcomm Technology Licensing) segment in the quarterly and annual periods in fiscal 2018 and third and fourth quarters and annual period in fiscal 2017. In accordance with SAB No. 99, “Materiality,” and SAB No. 108, “Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements,” we evaluated the error and determined that the related impact was not material to our financial statements for any prior annual or interim period, but that correcting the cumulative impact of the error would be significant to our results of operations for the three months ended December 30, 2018. Accordingly, we have revised our consolidated balance sheets at September 30, 2018 and September 24, 2017 and condensed (if applicable) consolidated statements of operations, comprehensive income (loss) and cash flows for the years ended September 30, 2018 and September 24, 2017, and the three months periods ended September 30, 2018, June 24, 2018, March 25, 2018, December 24, 2017, September 24, 2017 and June 25, 2017, including the related notes presented herein, as applicable. A summary of revisions to our previously reported financial statements is presented in Note 11. We will also correct previously reported financial information for such immaterial error in our future filings, as applicable.

- changed (2019-01-30):
[0001728949-19-000012:note_history:88]
Earnings (Loss) Per Common Share. Basic earnings (loss) per common share is computed by dividing net income (loss) by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans and shares subject to accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Due to the net loss for the three months ended December 24, 2017, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share. The following table provides information about the diluted earnings (loss) per share calculation (in millions):
  (was, 2018-07-25, similarity 0.8982):
[0001728949-18-000075:note_history:88]
Earnings (Loss) Per Common Share. Basic earnings (loss) per common share is computed by dividing net income (loss) attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans, if any, and the weighted-average number of common shares outstanding during the reporting period. Due to the net loss for the nine months ended June 24, 2018, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share. The following table provides information about the diluted earnings per share calculation (in millions):

- added (2019-01-30):
[0001728949-19-000012:note_history:89]
|  | Three Months Ended |
|  | December 30, 2018 |  | December 24, 2017 |
| Dilutive common share equivalents included in diluted shares | 10.3 |  |  | — |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 11.7 |  |  | 46.0 |  |

- changed (2019-01-30):
[0001728949-19-000012:note_history:90]
Share-Based Compensation. Total share-based compensation expense, related to all of our share-based awards, was comprised as follows (in millions):
  (was, 2018-07-25, similarity 0.9539):
[0001728949-18-000075:note_history:90]
Share-Based Compensation. Total share-based compensation expense, related to all of the Company’s share-based awards, was comprised as follows (in millions):

- changed (2019-01-30):
[0001728949-19-000012:note_history:91]
|  | Three Months Ended |
|  | December 30, 2018 |  | December 24, 2017 |
| Cost of revenues | $ | 8 |  |  | $ | 10 |  |
| Research and development | 157 |  |  | 156 |  |
| Selling, general and administrative | 65 |  |  | 82 |  |
| Share-based compensation expense before income taxes | 230 |  |  | 248 |  |
| Related income tax benefit | (48 | ) |  | (49 | ) |
|  | $ | 182 |  |  | $ | 199 |  |
  (was, 2018-07-25, similarity 0.6768):
[0001728949-18-000075:note_history:91]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | June 24, 2018 |  | June 25, 2017 |
| Cost of revenues | $ | 9 |  |  | $ | 10 |  |  | $ | 30 |  |  | $ | 30 |  |
| Research and development | 140 |  |  | 147 |  |  | 447 |  |  | 455 |  |
| Selling, general and administrative | 40 |  |  | 70 |  |  | 182 |  |  | 227 |  |
| Share-based compensation expense before income taxes | 189 |  |  | 227 |  |  | 659 |  |  | 712 |  |
| Related income tax benefit | (34 | ) |  | (28 | ) |  | (111 | ) |  | (113 | ) |
|  | $ | 155 |  |  | $ | 199 |  |  | $ | 548 |  |  | $ | 599 |  |

- added (2019-01-30):
[0001728949-19-000012:note_history:92]
At December 30, 2018, total unrecognized compensation expense related to nonvested restricted stock units granted prior to that date was $1.5 billion, which is expected to be recognized over a weighted-average period of 2.3 years. At December 30, 2018, we had outstanding 29.4 million restricted stock units that contain only a service requirement and 3.9 million stock options.

- changed (2019-01-30):
[0001728949-19-000012:note_history:93]
Recently Adopted Accounting Pronouncements.
  (was, 2018-07-25, similarity 0.8684):
[0001728949-18-000075:note_history:93]
Recent Accounting Pronouncements.

- added (2019-01-30):
[0001728949-19-000012:note_history:94]
Revenue Recognition: In May 2014, the Financial Accounting Standards Board (FASB) issued new accounting guidance related to revenue recognition (ASC 606), which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition accounting guidance. The new accounting guidance defines a five-step approach that requires a company to recognize revenue as control of goods or services transfers to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. We adopted ASC 606 in the first quarter of fiscal 2019 using the modified retrospective transition method only to those contracts that were not completed as of October 1, 2018. We recognized the cumulative effect of initially applying the new revenue accounting guidance as an adjustment to opening retained earnings. Prior period results have not been restated and continue to be reported in accordance with the accounting guidance in effect for those periods (ASC 605). We have implemented new accounting policies, systems, processes and internal controls necessary to support the requirements of ASC 606.

- added (2019-01-30):
[0001728949-19-000012:note_history:95]
Adoption of this new accounting guidance most significantly impacts the timing of sales-based royalty revenues, which are the vast majority of our QTL segment’s revenues. Previously, we recognized sales-based royalties as revenues in the period in which such royalties were reported by licensees, which was after the conclusion of the quarter in which the licensees’ sales occurred and when all other revenue recognition criteria had been met. Under the new accounting guidance, we estimate and recognize sales-based royalties in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such amounts, resulting in an acceleration of revenue recognition compared to the historical method. Since we do not invoice for sales-based royalties recognized in any given quarter until after the conclusion of that quarter (which is generally the following quarter when such royalties are reported by licensees), revenues recognized from sales-based royalties results in unbilled receivables (included in accounts receivable, net on the condensed consolidated balance sheet). The adoption of ASC 606 did not otherwise have a material impact.

- added (2019-01-30):
[0001728949-19-000012:note_history:96]
The new accounting guidance also impacts the timing of recognizing certain customer incentives, which are recorded as a reduction to revenues in the period that the related revenues are earned. We previously accounted for certain customer incentive arrangements, including volume-related and other pricing rebates or cost reimbursements for marketing and other activities involving certain of our products and technologies, in part based on the maximum potential liability. Under the new accounting guidance, we estimate the amount of all customer incentives.

- added (2019-01-30):
[0001728949-19-000012:note_history:97]
The following table summarizes the cumulative effects of adopting the new revenue accounting guidance (substantially all of which related to the impact to QTL’s sales-based royalties) on our condensed consolidated balance sheet at October 1, 2018 (in millions):

- added (2019-01-30):
[0001728949-19-000012:note_history:98]
|  | Balance as of September 30, 2018 |  | Adjustment |  | Opening Balance as of October 1, 2018 |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 2,904 |  |  | $ | 957 |  |  | $ | 3,861 |  |
| Other current assets | 699 |  |  | 1 |  |  | 700 |  |
| Deferred tax assets | 936 |  |  | (98 | ) |  | 838 |  |
| Other assets | 1,970 |  |  | 1 |  |  | 1,971 |  |
| Liabilities |  |  |  |  |  |
| Unearned revenues, current | $ | 500 |  |  | $ | 6 |  |  | $ | 506 |  |
| Other current liabilities | 6,978 |  |  | 125 |  |  | 7,103 |  |
| Unearned revenues | 1,620 |  |  | (110 | ) |  | 1,510 |  |
| Stockholders’ equity |  |  |  |  |  |
| Retained earnings | $ | 542 |  |  | $ | 840 |  |  | $ | 1,382 |  |

- added (2019-01-30):
[0001728949-19-000012:note_history:99]
The following tables summarize the impacts of adopting the new revenue accounting guidance on our condensed consolidated balance sheet and statement of operations (in millions):

- added (2019-01-30):
[0001728949-19-000012:note_history:100]
|  | As of December 30, 2018 |
| Balance Sheet | As ReportedASC 606 |  | Adjustment |  | ASC 605 |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 3,426 |  |  | $ | (845 | ) |  | $ | 2,581 |  |
| Other current assets | 855 |  |  | 23 |  |  | 878 |  |
| Deferred tax assets | 3,923 |  |  | 56 |  |  | 3,979 |  |
| Other assets | 2,056 |  |  | 1 |  |  | 2,057 |  |
| Liabilities |  |  |  |  |  |
| Unearned revenues, current | $ | 484 |  |  | 4 |  |  | $ | 488 |  |
| Other current liabilities | 6,831 |  |  | (271 | ) |  | 6,560 |  |
| Unearned revenues | 1,420 |  |  | 309 |  |  | 1,729 |  |
| Stockholders’ equity |  |  |  |  |  |
| Retained earnings | $ | 3,415 |  |  | $ | (807 | ) |  | $ | 2,608 |  |

- added (2019-01-30):
[0001728949-19-000012:note_history:101]
|  | Three Months Ended December 30, 2018 |
| Statement of Operations | As Reported ASC 606 |  | Adjustment |  | ASC 605 |
| Revenues |  |  |  |  |  |
| Equipment and services | $ | 3,754 |  |  | $ | (15 | ) |  | $ | 3,739 |  |
| Licensing | 1,088 |  |  | 51 |  |  | 1,139 |  |
| Investment and other income, net | 5 |  |  | 2 |  |  | 7 |  |
| Income tax benefit | 509 |  |  | (5 | ) |  | 504 |  |
| Net income | 1,068 |  |  | 33 |  |  | 1,101 |  |

- added (2019-01-30):
[0001728949-19-000012:note_history:102]
Adoption of the new accounting guidance had no impact to net cash provided (used) by operating, financing or investing activities on our condensed consolidated statement of cash flows in the first quarter of fiscal 2019.

- added (2019-01-30):
[0001728949-19-000012:note_history:103]
Financial Assets: In January 2016, the FASB issued new accounting guidance on classifying and measuring financial instruments, which requires that all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings in the statement of operations. Additionally, it changes the disclosure requirements for financial instruments. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the modified retrospective transition method for investments in marketable securities, which have readily determinable fair values, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings. Upon adoption, we reclassified $50 million of unrealized gains, net of the associated tax effects, related to our investments in marketable securities from accumulated other comprehensive income to opening retained earnings. We have applied the prospective transition method for investments in non-marketable securities, which are investments in privately held companies that do not have readily determinable fair values and will recognize any unrealized gains that have accumulated in the period in which there is an observable transaction, if any.

- changed (2019-01-30):
[0001728949-19-000012:note_history:104]
Hedge Instruments: In August 2017, the FASB issued new accounting guidance that expands and refines hedge accounting for both financial and non-financial risks, aligns the recognition and presentation of the effects of hedging instruments and hedged items in the financial statements, and includes targeted improvements related to the assessment of hedge effectiveness. The new accounting guidance also modifies disclosure requirements for hedging activities. We adopted the new accounting guidance in the first quarter of 2019 using the modified retrospective transition method and recorded a negligible adjustment to opening retained earnings. The new accounting guidance did not have a material impact on our condensed consolidated financial statements.
  (was, 2018-07-25, similarity 0.616):
[0001728949-18-000075:note_history:104]
Hedge Instruments: In August 2017, the FASB issued new guidance that expands and refines hedge accounting for both financial and non-financial risks, aligns the recognition and presentation of the effects of hedging instruments and hedged items in the financial statements, and includes targeted improvements related to the assessment of hedge effectiveness. The new guidance also modifies disclosure requirements for hedging activities. The Company plans to adopt the new guidance in the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption, and does not expect the effects of the adoption to have a material impact on its consolidated financial statements.

- added (2019-01-30):
[0001728949-19-000012:note_history:105]
Statement of Cash Flows: In August 2016, the FASB issued new accounting guidance related to the classification of certain cash receipts and cash payments in the statement of cash flows. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the retrospective transition method for each period presented, which did not have a material impact on our condensed consolidated statements of cash flows.

- added (2019-01-30):
[0001728949-19-000012:note_history:106]
In November 2016, the FASB issued new accounting guidance that requires companies to include changes in restricted cash and cash equivalents in the statement of cash flows. As a result, the statement of cash flows no longer reflects transfers between cash and cash equivalents and restricted cash and cash equivalents. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the retrospective transition method, which will result in certain amounts in fiscal 2018 being adjusted to conform to the new accounting guidance. During fiscal 2018, we had restricted cash and cash equivalents related to funds deposited as collateral for outstanding letters of credit in connection with a then proposed acquisition. Restricted cash and cash equivalents related to the outstanding letters of credit totaled $2.0 billion at the end of the fourth quarter of fiscal 2017 and first quarter of fiscal 2018. There was no impact of this change on the activity presented within the statement of cash flows for the three months ended December 24, 2017.

- changed (2019-01-30):
[0001728949-19-000012:note_history:107]
Income Taxes. In October 2016, the FASB issued new accounting guidance that changes the accounting for the income tax effects of intra-entity transfers of assets other than inventory. Under the new accounting guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings of $2.6 billion, primarily as the result of establishing a deferred tax asset on the basis difference of certain intellectual property distributed from one of our foreign subsidiaries to a subsidiary in the United States in fiscal 2018 (Note 3). The ongoing impact of this accounting guidance will be dependent on the facts and circumstances of any transactions within its scope.
  (was, 2018-07-25, similarity 0.6709):
[0001728949-18-000075:note_history:107]
In October 2016, the FASB issued new guidance that changes the accounting for income tax effects of intra-entity transfers of assets other than inventory. Under the new guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. The Company will adopt the new guidance in the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption, and is in the process of determining the effects the adoption will have on its consolidated financial statements.

- added (2019-01-30):
[0001728949-19-000012:note_history:108]
Recent Accounting Pronouncements Not Yet Adopted.

- added (2019-01-30):
[0001728949-19-000012:note_history:109]
Leases: In February 2016, the FASB issued new accounting guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease accounting guidance. The new accounting guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. We will adopt the new accounting guidance in the first quarter of fiscal 2020 and expect to use the modified retrospective approach and to elect certain practical expedients, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption. We are in the process of determining the effects the adoption will have on our consolidated financial statements.

- added (2019-01-30):
[0001728949-19-000012:note_history:110]
Financial Assets. In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The new accounting guidance also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The new accounting guidance will be effective for us starting in the first quarter of fiscal 2021 and generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. Early adoption is permitted starting in the first quarter of fiscal 2020. We are in the process of determining the effects the adoption will have on our consolidated financial statements and whether to adopt the new accounting guidance early.

- added (2019-01-30):
[0001728949-19-000012:note_history:111]
Accounting Policy Update.

- added (2019-01-30):
[0001728949-19-000012:note_history:112]
Revenue Recognition. As a result of the adoption of ASC 606, we revised our revenue recognition policy beginning in fiscal 2019 as follows.

- added (2019-01-30):
[0001728949-19-000012:note_history:113]
We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We also generate revenues by performing software hosting, software development and other services and from other product sales. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of our performance obligations.

- added (2019-01-30):
[0001728949-19-000012:note_history:114]
Revenues from sales of our products are recognized upon transfer of control to the customer, which is generally at the time of shipment. Revenues from providing services are typically recognized over time as the performance obligation is satisfied. Revenues from providing services were less than 5% of total revenues for all periods presented.

- added (2019-01-30):
[0001728949-19-000012:note_history:115]
We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops, which in general, effectively provide for a maximum royalty amount per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such royalties. Our estimates of sales-based royalties are based largely on an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property. We estimate sales-based royalties taking into consideration the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products, and considers all information (historical, current and forecasted) that is reasonably available to us. Our licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter, which is generally the following quarter. As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues will be required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

- added (2019-01-30):
[0001728949-19-000012:note_history:116]
License agreements that require payment of license fees contain a single performance obligation that represent ongoing access to a portfolio of intellectual property over the license term since such agreements provide the licensee the right to access a portfolio of intellectual property that exists at inception of the license agreement and to updates and new intellectual property that is added to the licensed portfolio during the term of the agreement that are highly interdependent or interrelated. Since we expect to expend efforts to develop and transfer updates to our licensed portfolio on an even basis, license fees are recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee.

- added (2019-01-30):
[0001728949-19-000012:note_history:117]
We account for a contract when it is legally enforceable, the parties are committed to perform their respective obligations, the rights of the parties regarding the goods and/or services to be transferred are identified, payment terms are identified, the contract has commercial substance and collectability of substantially all of the consideration is probable.

- added (2019-01-30):
[0001728949-19-000012:note_history:118]
From time to time, companies initiate various strategies to attempt to renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. Certain licensees have disputed, underreported, underpaid, not reported and/or not paid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and such licensees may continue to do so in the future. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in ASC 606, and to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us.

- added (2019-01-30):
[0001728949-19-000012:note_history:119]
We measure revenues based on the amount of consideration we expect to receive in exchange for products or services. We record reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of our products and technologies, in the period that the related revenues are earned. The charges for such arrangements are recorded as a reduction to accounts receivable, net or as other current liabilities based on whether we have the contractual right of offset. Certain of these charges are considered variable consideration and are included in the transaction price based on estimating the most likely amount expected to be provided to the customer/licensee.

- added (2019-01-30):
[0001728949-19-000012:note_history:120]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including certain unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied performance obligations.

- added (2019-01-30):
[0001728949-19-000012:note_history:121]
We disaggregate our revenues by segment (Note 7) and type of product and services (as presented in our statement of operations), as we believe this best depicts how the nature, amount, timing and uncertainty of our revenues and cash flows are affected by economic factors. Substantially all of QCT’s revenues consist of equipment revenues, which are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time.

- added (2019-01-30):
[0001728949-19-000012:note_history:122]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were $72 million in the first quarter of fiscal 2019 and primarily relate to QTL royalty revenues recognized related to devices sold in prior periods and certain customer incentives.

- added (2019-01-30):
[0001728949-19-000012:note_history:123]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In the first quarter of fiscal 2019, we recognized revenues of $133 million that were included within the unearned revenues balance at October 1, 2018.

- added (2019-01-30):
[0001728949-19-000012:note_history:124]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront. At December 30, 2018, we had $2.0 billion of remaining performance obligations, of which $411 million, $450 million, $415 million, $409 million and $193 million was expected to be recognized as revenues for the remainder of fiscal 2019 and each of the subsequent four years from fiscal 2020 through 2023, respectively, and $77 million thereafter.

- added (2019-01-30):
[0001728949-19-000012:note_history:125]
Marketable Securities and Non-Marketable Securities. Prior to the adoption of the new accounting guidance in the first quarter of fiscal 2019, investments in marketable equity securities were generally classified as available-for-sale equity investments, with net unrealized gains or losses recorded as a component of accumulated other comprehensive income, net of income taxes. Beginning in fiscal 2019, all gains and losses on investments in marketable equity securities, realized and unrealized, are recognized in investment and other income, net.

- added (2019-01-30):
[0001728949-19-000012:note_history:126]
Prior to the adoption of the new accounting guidance in the first quarter of fiscal 2019, investments in non-marketable equity securities were recorded at cost less impairment, if any, with any losses resulting from an impairment recognized in investment and other income, net. Beginning in fiscal 2019, investments in non-marketable equity securities are recorded at cost, less impairments, adjusted for observable price changes in orderly transactions for identical or similar securities. All gains and losses on investments in non-marketable equity securities, realized and unrealized, are recognized in investment and other income, net.

- removed (2019-01-30):
[0001728949-18-000075:note_history:127]
Basis of Presentation

- removed (2019-01-30):
[0001728949-18-000075:note_history:128]
During the third quarter of fiscal 2018, the Company eliminated the one-month reporting lag previously used to consolidate its RF360 Holdings joint venture to provide contemporaneous reporting within its consolidated financial statements. The effect of this change is not material to the consolidated financial statements, and therefore, the impact of eliminating the one-month reporting lag has been included in the Company’s results of operations for the three months and nine months ended June 24, 2018.

- removed (2019-01-30):
[0001728949-18-000075:note_history:129]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | June 24, 2018 |  | June 25, 2017 |
| Dilutive common share equivalents included in diluted shares | 9.0 |  |  | 12.2 |  |  | — |  |  | 13.5 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 0.6 |  |  | 0.6 |  |  | 43.2 |  |  | 3.8 |  |

- removed (2019-01-30):
[0001728949-18-000075:note_history:130]
At June 24, 2018, total unrecognized compensation expense related to nonvested restricted stock units granted prior to that date was $1.1 billion, which is expected to be recognized over a weighted-average period of 1.9 years. At June 24, 2018, the Company had 23.8 million restricted stock units outstanding and 6.5 million stock options outstanding.

- removed (2019-01-30):
[0001728949-18-000075:note_history:131]
Share-based Awards: In March 2016, the Financial Accounting Standards Board (FASB) issued new guidance that changed the accounting for share-based awards, including income taxes, classification of awards and classification in the statement of cash flows. The Company adopted the new guidance in the first quarter of fiscal 2018. In accordance with the new guidance, excess tax benefits or deficiencies associated with share-based awards are recognized through earnings when the awards vest or settle, rather than in stockholders’ equity. In the nine months ended June 24, 2018, net excess tax benefits associated with share-based awards of $15 million were recognized in the Company’s income tax provision. In addition, cash flows related to excess tax benefits are presented as an operating activity and cash payments made on an employee’s behalf for withheld shares are presented as financing activities, with the prior periods adjusted accordingly. As a result of these changes, amounts for the nine months ended June 25, 2017 have been adjusted as follows: net cash provided by operating activities increased by $301 million with a corresponding offset to net cash used in financing activities. The new guidance also impacts the Company’s earnings per share calculation as the estimate of dilutive common share equivalents under the treasury stock method no longer assumes that the estimated tax benefits realized when an award is settled are used to repurchase shares. There was no impact of this change on the Company’s calculation of earnings per share as a result of the net loss for the nine months ended June 24, 2018. The Company elected to continue its practice of estimating forfeitures expected to occur in determining the amount of compensation cost to be recognized each period.

- removed (2019-01-30):
[0001728949-18-000075:note_history:132]
Revenue Recognition: In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue as control of goods or services transfers to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The Company will adopt the new guidance in the first quarter of fiscal 2019 using the modified retrospective approach, with the cumulative effect of applying the new guidance recognized as an adjustment to the opening retained earnings balance. The Company is finalizing its identification of changes to policy, processes, systems and controls, as well as its assessment of data availability and presentation necessary to meet the additional disclosure requirements of the guidance in the notes to the consolidated financial statements.

- removed (2019-01-30):
[0001728949-18-000075:note_history:133]
The Company currently expects the adoption of this new guidance to most significantly impact its licensing business (Qualcomm Technology Licensing, or QTL). Specifically, the Company expects a change in the timing of revenues recognized from sales-based royalties, which are the vast majority of QTL’s revenues. The Company currently recognizes sales-based royalties as revenues in the period in which such royalties are reported by licensees, which is after the conclusion of the quarter in which the licensees’ sales occur and when all other revenue recognition criteria are met. Under the new guidance, the Company will be required to estimate and recognize sales-based royalties in the period in which the associated sales occur, resulting in an acceleration of revenue recognition compared to the current method. As a result of recognizing royalty revenues based on estimates, adjustments to revenues will be required in subsequent periods based on the actual amounts reported by licensees. Upon adoption of the new guidance, licenses to use portions of the Company’s intellectual property portfolio will be considered one performance obligation, and license fees will be recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee, which is similar to the recognition of license revenues under the current guidance. The Company currently accounts for customer incentive arrangements in its licensing and semiconductor businesses, including volume-related and other pricing rebates or cost reimbursements for marketing and other activities involving certain of the Company’s products and technologies, in part based on the maximum potential liability. Under the new guidance, the Company will estimate the amount of all customer incentives. The Company does not otherwise expect the adoption of the new guidance to have a material impact on its businesses.

- removed (2019-01-30):
[0001728949-18-000075:note_history:134]
Financial Assets: In January 2016, the FASB issued new guidance on classifying and measuring financial instruments, which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk be recognized separately in other comprehensive income. Additionally, it changes the disclosure requirements for financial instruments. For equity investments that do not have readily determinable fair values, the Company expects to use the measurement alternative, which is defined as cost, less impairments, adjusted by observable price changes in orderly transactions for identical or similar investments. The Company anticipates the adoption of the new guidance will increase the volatility of the Company’s investment and other income, net due to recording the changes in fair value of equity investments through earnings. The Company will adopt the new guidance in the first quarter of fiscal 2019 using the modified retrospective transition method for equity investments that have readily determinable fair values, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption, and the prospective transition method for equity investments that do not have readily determinable fair values. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements.

- removed (2019-01-30):
[0001728949-18-000075:note_history:135]
In June 2016, the FASB issued new guidance that changes the accounting for recognizing impairments of financial assets. Under the new guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The new guidance also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The new guidance will be effective for the Company starting in the first quarter of fiscal 2021 and generally requires the modified retrospective transition method, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. Early adoption is permitted starting in the first quarter of fiscal 2020. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements and whether to adopt the new guidance early.

- removed (2019-01-30):
[0001728949-18-000075:note_history:136]
Leases: In February 2016, the FASB issued new guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease guidance. The new guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. The Company will adopt the new guidance in the first quarter of fiscal 2020 and expects to use the modified retrospective approach, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements and whether to apply any of the optional practical expedients.

- removed (2019-01-30):
[0001728949-18-000075:note_history:137]
Other: In August 2016, the FASB issued new guidance related to the classification of certain cash receipts and cash payments on the statement of cash flows. The Company will adopt the new guidance in the first quarter of fiscal 2019 using the retrospective transition method for each period presented, and does not expect the effects of the adoption to have a material impact on its consolidated statements of cash flows.

- removed (2019-01-30):
[0001728949-18-000075:note_history:138]
In November 2016, the FASB issued new guidance related to the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. The Company will adopt the new guidance in the first quarter of fiscal 2019 using the retrospective transition method for each period presented. At June 24, 2018, the Company had restricted cash and cash equivalents of $2.0 billion related to funds deposited as collateral for outstanding letters of credit in connection with the NXP Purchase Agreement (Note 8), and $2.8 billion related to irrevocably deposited cash to redeem notes in July 2018 (Note 5). Otherwise, the Company does not expect the effects of the retrospective adoption to have a material impact on its consolidated statements of cash flows.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-01-30):
[0001728949-19-000012:note_history:139]
Revolving Credit Facility. We have an Amended and Restated Revolving Credit Facility (2016 Amended and Restated Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. Proceeds from the Amended and Restated Revolving Credit Facility are expected to be used for general corporate purposes. Loans under the 2016 Amended and Restated Revolving Credit Facility will bear interest, at our option, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the 2016 Amended and Restated Revolving Credit Facility) or the Base Rate (determined in accordance with the 2016 Amended and Restated Revolving Credit Facility), in each case plus an applicable margin based on our long-term unsecured senior, non-credit enhanced debt ratings. The margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.805% and 0.00% per annum, respectively. The 2016 Amended and Restated Revolving Credit Facility has a facility fee, which accrues at a rate of 0.07% per annum. At December 30, 2018 and September 30, 2018, we had not borrowed any funds under the 2016 Amended and Restated Revolving Credit Facility.

- added (2019-01-30):
[0001728949-19-000012:note_history:140]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At December 30, 2018 and September 30, 2018, we had $1.0 billion of outstanding commercial paper included in short-term debt with a weighted-average interest rate of 2.55% and 2.35%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 26 days and 16 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at December 30, 2018 and September 30, 2018.

- changed (2019-01-30):
[0001728949-19-000012:note_history:141]
Long-term Debt. The following table provides a summary of our long-term debt (in millions, except percentages):
  (was, 2018-07-25, similarity 0.8611):
[0001728949-18-000075:note_history:141]
The following table provides a summary of the Company’s long-term debt (in millions, except percentages):

- added (2019-01-30):
[0001728949-19-000012:note_history:142]
|  |  | December 30, 2018 |  | September 30, 2018 |
|  |  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | $ | 250 |  |  | 3.25% |  | $ | 250 |  |  | 2.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 3.18% |  | 1,750 |  |  | 3.13% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 3.66% |  | 2,000 |  |  | 3.73% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.73% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.72% |  | 1,500 |  |  | 4.72% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 3.32% |  | 500 |  |  | 3.14% |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | 1,500 |  |  | 2.70% |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | 1,500 |  |  | 3.01% |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.47% |  | 1,500 |  |  | 4.47% |
|  | Total principal | 15,500 |  |  |  |  | 15,500 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (82 | ) |  |  |  | (85 | ) |  |  |
|  | Hedge accounting fair value adjustments | (30 | ) |  |  |  | (50 | ) |  |  |
|  | Total long-term debt | $ | 15,388 |  |  |  |  | $ | 15,365 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | — |  |  |  |  | $ | — |  |  |  |
|  | Long-term debt | 15,388 |  |  |  |  | 15,365 |  |  |  |
|  | Total | $ | 15,388 |  |  |  |  | $ | 15,365 |  |  |  |

- changed (2019-01-30):
[0001728949-19-000012:note_history:143]
At December 30, 2018 and September 30, 2018, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $14.8 billion and $15.1 billion, respectively.
  (was, 2018-07-25, similarity 0.9675):
[0001728949-18-000075:note_history:143]
At June 24, 2018 and September 24, 2017, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $18.9 billion and $21.5 billion, respectively.

- added (2019-01-30):
[0001728949-19-000012:note_history:144]
We may redeem the outstanding fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. We may not redeem the outstanding floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of our other senior unsecured indebtedness and will effectively rank junior to all liabilities of our subsidiaries.

- changed (2019-01-30):
[0001728949-19-000012:note_history:145]
At December 30, 2018, we had outstanding interest rate swaps with an aggregate notional amount of $1.8 billion related to the May 2015 Notes, which effectively converted approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recorded as interest expense in the current period. We did not enter into similar interest rate swaps in connection with issuance of the May 2017 Notes.
  (was, 2018-07-25, similarity 0.8315):
[0001728949-18-000075:note_history:145]
At June 24, 2018, the Company had outstanding interest rate swaps with an aggregate notional amount of $1.8 billion related to the May 2015 Notes, which effectively converted approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recorded in earnings in interest expense in the current period. The Company did not enter into similar interest rate swaps in connection with issuance of the May 2017 Notes or May 2018 Notes.

- changed (2019-01-30):
[0001728949-19-000012:note_history:146]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to our commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $234 million and $257 million in the three months ended December 30, 2018 and December 24, 2017, respectively.
  (was, 2018-07-25, similarity 0.9294):
[0001728949-18-000075:note_history:146]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $594 million and $289 million in the nine months ended June 24, 2018 and June 25, 2017, respectively.

- changed (2019-01-30):
[0001728949-19-000012:note_history:147]
Debt Covenants. The 2016 Amended and Restated Revolving Credit Facility, requires that we comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. We are not subject to any financial covenants under the notes nor any covenants that would prohibit us from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by us or our subsidiaries. At December 30, 2018 and September 30, 2018, we were in compliance with the applicable covenants under the 2016 Amended and Restated Revolving Credit Facility.
  (was, 2018-07-25, similarity 0.7517):
[0001728949-18-000075:note_history:147]
Debt Covenants. The 2016 Amended and Restated Revolving Credit Facility, the 2016 Term Loan Facility, the 2018 Revolving Credit Facility and the 2018 Term Loan Facility require that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At June 24, 2018 and September 24, 2017, the Company was in compliance with the applicable covenants under each facility outstanding at such time.

- removed (2019-01-30):
[0001728949-18-000075:note_history:148]
Revolving Credit Facility. The Company has an Amended and Restated Revolving Credit Facility (2016 Amended and Restated Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. Proceeds from the 2016 Amended and Restated Revolving Credit Facility, if drawn, are expected to be used for general corporate purposes. At June 24, 2018 and September 24, 2017, the Company had not borrowed any funds under the 2016 Amended and Restated Revolving Credit Facility.

- removed (2019-01-30):
[0001728949-18-000075:note_history:149]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At June 24, 2018 and September 24, 2017, the Company had $3.2 billion and $999 million, respectively, of outstanding commercial paper included in short-term debt with a weighted-average interest rate of 2.34% and 1.19%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 46 days and 45 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at June 24, 2018 and September 24, 2017.

- removed (2019-01-30):
[0001728949-18-000075:note_history:150]
NXP-Related Credit and Term Loan Facilities. If the Company has not received regulatory approval from SAMR or other material developments have not occurred, the Company expects to terminate the NXP Acquisition after July 25, 2018 at 11:59 p.m. New York time (Note 8). As a result, the following credit agreements are expected to remain undrawn and terminate in accordance with their terms.

- removed (2019-01-30):
[0001728949-18-000075:note_history:151]
The Company is party to a credit agreement, as amended, that provides for senior unsecured delayed-draw revolving facility loans in an aggregate amount of $3.0 billion (as amended, the 2018 Revolving Credit Facility). Proceeds from the 2018 Revolving Credit Facility, if drawn, will be used in part to finance the NXP Acquisition and for general corporate purposes. Commitments under the 2018 Revolving Credit Facility expire on the first to occur of (i) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP, (ii) if the closing date under the 2018 Revolving Credit Facility has not occurred, the date that is five business days following July 25, 2018 and (iii) the termination of the commitments in accordance with the provisions of the 2018 Revolving Credit Facility providing for voluntary and mandatory commitment reductions. In the event the NXP Acquisition is terminated, these commitments will expire. Loans under the 2018 Revolving Credit Facility, if drawn, will mature on December 31, 2018 and will bear interest, at the option of the Company, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the 2018 Revolving Credit Facility) or the Base Rate (determined in accordance with the 2018 Revolving Credit Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate based on Qualcomm’s debt ratings as of June 24, 2018 will be 0.75% and 0.00% per annum, respectively. The 2018 Revolving Credit Facility has a ticking fee, which is based on Qualcomm’s debt ratings and initially accrues at a rate of 0.05% per annum commencing on March 6, 2018. At June 24, 2018, the Company had not borrowed any funds under the 2018 Revolving Credit Facility.

- removed (2019-01-30):
[0001728949-18-000075:note_history:152]
The Company is party to a credit agreement, as amended, that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion (as amended, the 2016 Term Loan Facility). Proceeds from the 2016 Term Loan Facility, if drawn, will be used to finance the NXP Acquisition. Commitments under the 2016 Term Loan Facility expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the 2016 Term Loan Facility, (ii) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP and (iii) the date that is five business days following July 25, 2018. In the event the NXP Acquisition is terminated, these commitments will expire. At June 24, 2018 and September 24, 2017, the Company had not borrowed any funds under the 2016 Term Loan Facility.

- removed (2019-01-30):
[0001728949-18-000075:note_history:153]
The Company is party to a credit agreement, as amended, that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $7.0 billion (as amended, the 2018 Term Loan Facility). Proceeds from the 2018 Term Loan Facility, if drawn, will be used in part to finance the NXP Acquisition and for general corporate purposes. Commitments under the 2018 Term Loan Facility expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the 2018 Term Loan Facility, (ii) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP, (iii) the date that is five business days following July 25, 2018 and (iv) the termination of the commitments in accordance with the provisions of the 2018 Term Loan Facility providing for voluntary and mandatory commitment reductions. In the event the NXP Acquisition is terminated, these commitments will expire. Loans under the 2018 Term Loan Facility, if drawn, will mature on December 31, 2018 and will bear interest, at the option of the Company, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the 2018 Term Loan Facility) or the Base Rate (determined in accordance with the 2018 Term Loan Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate based on Qualcomm’s debt ratings as of June 24, 2018 will be 0.875% and 0.00% per annum, respectively. The 2018 Term Loan Facility has a ticking fee, which is based on Qualcomm’s debt ratings and initially accrues at a rate of 0.05% per annum commencing on March 6, 2018. At June 24, 2018, the Company had not borrowed any funds under the 2018 Term Loan Facility.

- removed (2019-01-30):
[0001728949-18-000075:note_history:154]
Long-term Debt. In May 2018, the Company initiated private offerings to exchange the Company’s floating-rate notes due 2019, floating-rate notes due 2020, fixed-rate 1.85% notes due 2019 and fixed-rate 2.10% notes due 2020 (collectively, the Old Notes) issued in May 2017 that were subject to special mandatory redemption provisions. The Company offered certain eligible holders of the Old Notes the option to exchange Old Notes for (i) new notes that have the same principal amount and terms of the Old Notes, except for a new special mandatory redemption date of November 1, 2018 and maturity dates that are one day after the applicable maturity dates for the applicable series of Old Notes and (ii) a cash fee of 0.25% of the principal amount of the Old Notes. For holders not eligible to participate in the exchanges, the Company offered to repurchase the Old Notes pursuant to cash tender offers for 100.25% of the principal amount of the Old Notes. The offers to exchange and offers to repurchase the Company’s 2.10% fixed-rate notes due 2020 were not accepted because the amount of such notes validly tendered and not withdrawn in the applicable exchange offer was not sufficient to meet the minimum tender condition. On May 31, 2018, the Company exchanged $122 million of Old Notes for new notes and repurchased $71 million of Old Notes in the aggregate pursuant to the offers to exchange and the offers to repurchase. Also on May 31, 2018, the Company called for full redemption of all of its then-outstanding 1.85% fixed-rate notes due 2019 and 2.10% fixed-rate notes due 2020 pursuant to the optional redemption provision in the fixed-rate notes, and irrevocably deposited cash of $2.8 billion with the trustee of the notes, which represented an amount sufficient to satisfy and discharge such fixed-rate notes in full. On June 8, 2018, the Company called for full redemption all of its then-outstanding floating-rate notes due 2019 and floating-rate notes due 2020 pursuant to the special mandatory redemption provisions in the floating-rate notes. On July 2, 2018, $2.6 billion was paid to the holders of the fixed-rate notes in full redemption of such notes out of the $2.8 billion in cash previously deposited with the trustee, with the excess amount then refunded to the Company. On July 6, 2018, $1.2 billion was paid to the holders of the floating-rate notes in full redemption of such notes. At June 24, 2018, the $2.8 billion of irrevocably deposited cash was included in other current assets and the Old Notes redeemed in July 2018 were included in short-term debt.

- removed (2019-01-30):
[0001728949-18-000075:note_history:155]
|  |  | June 24, 2018 |  | September 24, 2017 |
|  |  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.27% notes due May 18, 2018 | $ | — |  |  |  |  | $ | 250 |  |  | 1.65% |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | 250 |  |  | 2.94% |  | 250 |  |  | 1.92% |
|  | Fixed-rate 1.40% notes due May 18, 2018 | — |  |  |  |  | 1,250 |  |  | 1.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 3.08% |  | 1,750 |  |  | 2.20% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 3.66% |  | 2,000 |  |  | 2.65% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.36% notes due May 20, 2019 | 695 |  |  | 3.88% |  | 750 |  |  | 1.80% |
|  | Floating-rate three-month LIBOR plus 0.45% notes due May 20, 2020 | 485 |  |  | 4.54% |  | 500 |  |  | 1.86% |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 3.16% |  | 500 |  |  | 2.11% |
|  | Fixed-rate 1.85% notes due May 20, 2019 | 1,127 |  |  | 3.55% |  | 1,250 |  |  | 2.00% |
|  | Fixed-rate 2.10% notes due May 20, 2020 | 1,500 |  |  | 4.09% |  | 1,500 |  |  | 2.19% |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | 1,500 |  |  | 2.70% |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | 1,500 |  |  | 3.01% |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.74% |  | 1,500 |  |  | 4.47% |
| May 2018 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.36% notes due May 21, 2019 | 52 |  |  | 3.08% |  | — |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.45% notes due May 21, 2020 | 14 |  |  | 3.00% |  | — |  |  |  |
|  | Fixed-rate 1.85% notes due May 21, 2019 | 56 |  |  | 2.28% |  | — |  |  |  |
| Total principal | 19,429 |  |  |  |  | 21,000 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (90 | ) |  |  |  | (106 | ) |  |  |
|  | Hedge accounting fair value adjustments | (48 | ) |  |  |  | — |  |  |  |
|  | Total | $ | 19,291 |  |  |  |  | $ | 20,894 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | 3,913 |  |  |  |  | $ | 1,496 |  |  |  |
|  | Long-term debt | 15,378 |  |  |  |  | 19,398 |  |  |  |
|  | Total | $ | 19,291 |  |  |  |  | $ | 20,894 |  |  |  |

- removed (2019-01-30):
[0001728949-18-000075:note_history:156]
The Company’s floating-rate notes due 2019, floating-rate notes due 2020 and 1.85% fixed-rate notes due 2019 issued in May 2018 for an aggregate principal amount of $122 million are subject to a special mandatory redemption at a price equal to 101% of the aggregate principal amount, plus accrued and unpaid interest to, but excluding, the date of such mandatory redemption (the May 2018 Notes). The redemption is required on the first to occur of (i) the termination of the NXP purchase agreement or (ii) November 1, 2018, if the NXP transaction has not closed as of such date. In the event the NXP Acquisition is terminated, the May 2018 Notes will be redeemed in accordance with their terms. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the other floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of the Company’s other senior unsecured indebtedness and will effectively rank junior to all liabilities of the Company’s subsidiaries.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-01-30):
[0001728949-19-000012:note_history:157]
Our marketable securities were comprised as follows (in millions):
  (was, 2018-07-25, similarity 0.9688):
[0001728949-18-000075:note_history:157]
Marketable securities were comprised as follows (in millions):

- added (2019-01-30):
[0001728949-19-000012:note_history:158]
|  | Current |  | Noncurrent (1) |
|  | December 30, 2018 |  | September 30, 2018 |  | December 30, 2018 |  | September 30, 2018 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 108 |  |  | $ | 144 |  |  | $ | — |  |  | $ | — |  |
| Auction rate securities | — |  |  | — |  |  | 35 |  |  | 35 |  |
| Total available-for-sale debt securities | 108 |  |  | 144 |  |  | 35 |  |  | 35 |  |
| Equity securities | 141 |  |  | 167 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 249 |  |  | $ | 311 |  |  | $ | 35 |  |  | $ | 35 |  |

- added (2019-01-30):
[0001728949-19-000012:note_history:159]
(1) Noncurrent marketable securities were included in other assets.

- changed (2019-01-30):
[0001728949-19-000012:note_history:160]
|  | December 30, 2018 |
| Years to Maturity |  |
| Less than one year | $ | 108 |  |
| No single maturity date | 35 |  |
| Total | $ | 143 |  |
  (was, 2018-07-25, similarity 0.6006):
[0001728949-18-000075:note_history:160]
|  | June 24, 2018 |
| Years to Maturity |  |
| Less than one year | $ | 194 |  |
| One to five years | 19 |  |
| Five to ten years | — |  |
| Greater than ten years | — |  |
| No single maturity date | 35 |  |
| Total | $ | 248 |  |

- changed (2019-01-30):
[0001728949-19-000012:note_history:161]
Debt securities with no single maturity date included auction rate securities.
  (was, 2018-07-25, similarity 0.7879):
[0001728949-18-000075:note_history:161]
Debt securities with no single maturity date included mortgage- and asset-backed securities and auction rate securities.

- added (2019-01-30):
[0001728949-19-000012:note_history:162]
During the three months ended December 30, 2018, there were no realized gains or losses on sales of available-for-sale debt securities, and during the three months ended December 24, 2017, gross realized gains were negligible.

- added (2019-01-30):
[0001728949-19-000012:note_history:163]
As of December 30, 2018 and September 30, 2018, unrealized gains and losses on available for sale debt securities were negligible. As of September 30, 2018, available-for-sale securities also included equity securities with a fair value of $167 million, including an unrealized gain of $63 million.

- removed (2019-01-30):
[0001728949-18-000075:note_history:164]
|  | Current |  | Noncurrent |
|  | June 24, 2018 |  | September 24, 2017 |  | June 24, 2018 |  | September 24, 2017 |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 959 |  |
| Corporate bonds and notes | 213 |  |  | 2,014 |  |  | — |  |  | 271 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 93 |  |  | 35 |  |  | 40 |  |
| Equity and preferred securities and equity funds | 34 |  |  | 36 |  |  | — |  |  | — |  |
| Debt funds | — |  |  | 109 |  |  | — |  |  | — |  |
| Total available-for-sale | 247 |  |  | 2,275 |  |  | 35 |  |  | 1,270 |  |
| Time deposits | 44 |  |  | 4 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 291 |  |  | $ | 2,279 |  |  | $ | 35 |  |  | $ | 1,270 |  |

- removed (2019-01-30):
[0001728949-18-000075:note_history:165]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

- removed (2019-01-30):
[0001728949-18-000075:note_history:166]
|  | For the three months ended |  | For the nine months ended |
|  | June 24, 2018 |  | June 25, 2017 |  | June 24, 2018 |  | June 25, 2017 |
| Gross realized gains | $ | 3 |  |  | $ | 119 |  |  | $ | 16 |  |  | $ | 422 |  |
| Gross realized losses | (6 | ) |  | (8 | ) |  | (6 | ) |  | (116 | ) |
| Net realized gains | $ | (3 | ) |  | $ | 111 |  |  | $ | 10 |  |  | $ | 306 |  |

- removed (2019-01-30):
[0001728949-18-000075:note_history:167]
Available-for-sale securities were comprised as follows (in millions):

- removed (2019-01-30):
[0001728949-18-000075:note_history:168]
|  | June 24, 2018 |  | September 24, 2017 |
| Equity securities |  |  |  |
| Cost | $ | 8 |  |  | $ | 8 |  |
| Unrealized gains | 26 |  |  | 28 |  |
| Fair value | 34 |  |  | 36 |  |
| Debt securities (including debt funds) |  |  |  |
| Cost | 247 |  |  | 3,497 |  |
| Unrealized gains | 1 |  |  | 13 |  |
| Unrealized losses | — |  |  | (1 | ) |
| Fair value | 248 |  |  | 3,509 |  |
|  | $ | 282 |  |  | $ | 3,545 |  |

- removed (2019-01-30):
[0001728949-18-000075:note_history:169]
In connection with the proposed NXP transaction (Note 8), the Company divested a substantial portion of its marketable securities portfolio in order to finance, in part, that transaction. Marketable securities that were expected to be used to finance the NXP transaction were fully liquidated and classified as cash and cash equivalents at June 24, 2018. Given the Company’s intention to sell certain marketable securities, the Company recorded other-than-temporary impairment losses in fiscal 2017 for certain marketable securities, and no additional losses were recorded in the nine months ended June 24, 2018.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-01-30):
[0001728949-19-000012:note_history:170]
The following table provides a summary of our long-term debt (in millions, except percentages):
  (was, 2018-07-25, similarity 0.93):
[0001728949-18-000075:note_history:170]
The following table provides a summary of the Company’s long-term debt (in millions, except percentages):

- added (2019-01-30):
[0001728949-19-000012:note_history:171]
|  |  | December 30, 2018 |  | September 30, 2018 |
|  |  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | $ | 250 |  |  | 3.25% |  | $ | 250 |  |  | 2.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 3.18% |  | 1,750 |  |  | 3.13% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 3.66% |  | 2,000 |  |  | 3.73% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.73% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.72% |  | 1,500 |  |  | 4.72% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 3.32% |  | 500 |  |  | 3.14% |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | 1,500 |  |  | 2.70% |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | 1,500 |  |  | 3.01% |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.47% |  | 1,500 |  |  | 4.47% |
|  | Total principal | 15,500 |  |  |  |  | 15,500 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (82 | ) |  |  |  | (85 | ) |  |  |
|  | Hedge accounting fair value adjustments | (30 | ) |  |  |  | (50 | ) |  |  |
|  | Total long-term debt | $ | 15,388 |  |  |  |  | $ | 15,365 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | — |  |  |  |  | $ | — |  |  |  |
|  | Long-term debt | 15,388 |  |  |  |  | 15,365 |  |  |  |
|  | Total | $ | 15,388 |  |  |  |  | $ | 15,365 |  |  |  |

- removed (2019-01-30):
[0001728949-18-000075:note_history:172]
|  |  | June 24, 2018 |  | September 24, 2017 |
|  |  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.27% notes due May 18, 2018 | $ | — |  |  |  |  | $ | 250 |  |  | 1.65% |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | 250 |  |  | 2.94% |  | 250 |  |  | 1.92% |
|  | Fixed-rate 1.40% notes due May 18, 2018 | — |  |  |  |  | 1,250 |  |  | 1.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 3.08% |  | 1,750 |  |  | 2.20% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 3.66% |  | 2,000 |  |  | 2.65% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.36% notes due May 20, 2019 | 695 |  |  | 3.88% |  | 750 |  |  | 1.80% |
|  | Floating-rate three-month LIBOR plus 0.45% notes due May 20, 2020 | 485 |  |  | 4.54% |  | 500 |  |  | 1.86% |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 3.16% |  | 500 |  |  | 2.11% |
|  | Fixed-rate 1.85% notes due May 20, 2019 | 1,127 |  |  | 3.55% |  | 1,250 |  |  | 2.00% |
|  | Fixed-rate 2.10% notes due May 20, 2020 | 1,500 |  |  | 4.09% |  | 1,500 |  |  | 2.19% |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | 1,500 |  |  | 2.70% |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | 1,500 |  |  | 3.01% |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.74% |  | 1,500 |  |  | 4.47% |
| May 2018 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.36% notes due May 21, 2019 | 52 |  |  | 3.08% |  | — |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.45% notes due May 21, 2020 | 14 |  |  | 3.00% |  | — |  |  |  |
|  | Fixed-rate 1.85% notes due May 21, 2019 | 56 |  |  | 2.28% |  | — |  |  |  |
| Total principal | 19,429 |  |  |  |  | 21,000 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (90 | ) |  |  |  | (106 | ) |  |  |
|  | Hedge accounting fair value adjustments | (48 | ) |  |  |  | — |  |  |  |
|  | Total | $ | 19,291 |  |  |  |  | $ | 20,894 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | 3,913 |  |  |  |  | $ | 1,496 |  |  |  |
|  | Long-term debt | 15,378 |  |  |  |  | 19,398 |  |  |  |
|  | Total | $ | 19,291 |  |  |  |  | $ | 20,894 |  |  |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-01-30):
[0001728949-19-000012:note_history:173]
As a result of the adoption of ASC 606, we revised our revenue recognition policy beginning in fiscal 2019 as follows.

- added (2019-01-30):
[0001728949-19-000012:note_history:174]
We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We also generate revenues by performing software hosting, software development and other services and from other product sales. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of our performance obligations.

- added (2019-01-30):
[0001728949-19-000012:note_history:175]
Revenues from sales of our products are recognized upon transfer of control to the customer, which is generally at the time of shipment. Revenues from providing services are typically recognized over time as the performance obligation is satisfied. Revenues from providing services were less than 5% of total revenues for all periods presented.

- added (2019-01-30):
[0001728949-19-000012:note_history:176]
We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops, which in general, effectively provide for a maximum royalty amount per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such royalties. Our estimates of sales-based royalties are based largely on an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property. We estimate sales-based royalties taking into consideration the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products, and considers all information (historical, current and forecasted) that is reasonably available to us. Our licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter, which is generally the following quarter. As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues will be required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

- added (2019-01-30):
[0001728949-19-000012:note_history:177]
License agreements that require payment of license fees contain a single performance obligation that represent ongoing access to a portfolio of intellectual property over the license term since such agreements provide the licensee the right to access a portfolio of intellectual property that exists at inception of the license agreement and to updates and new intellectual property that is added to the licensed portfolio during the term of the agreement that are highly interdependent or interrelated. Since we expect to expend efforts to develop and transfer updates to our licensed portfolio on an even basis, license fees are recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee.

- added (2019-01-30):
[0001728949-19-000012:note_history:178]
We account for a contract when it is legally enforceable, the parties are committed to perform their respective obligations, the rights of the parties regarding the goods and/or services to be transferred are identified, payment terms are identified, the contract has commercial substance and collectability of substantially all of the consideration is probable.

- added (2019-01-30):
[0001728949-19-000012:note_history:179]
From time to time, companies initiate various strategies to attempt to renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. Certain licensees have disputed, underreported, underpaid, not reported and/or not paid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and such licensees may continue to do so in the future. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in ASC 606, and to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us.

- added (2019-01-30):
[0001728949-19-000012:note_history:180]
We measure revenues based on the amount of consideration we expect to receive in exchange for products or services. We record reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of our products and technologies, in the period that the related revenues are earned. The charges for such arrangements are recorded as a reduction to accounts receivable, net or as other current liabilities based on whether we have the contractual right of offset. Certain of these charges are considered variable consideration and are included in the transaction price based on estimating the most likely amount expected to be provided to the customer/licensee.

- added (2019-01-30):
[0001728949-19-000012:note_history:181]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including certain unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied performance obligations.

- added (2019-01-30):
[0001728949-19-000012:note_history:182]
We disaggregate our revenues by segment (Note 7) and type of product and services (as presented in our statement of operations), as we believe this best depicts how the nature, amount, timing and uncertainty of our revenues and cash flows are affected by economic factors. Substantially all of QCT’s revenues consist of equipment revenues, which are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time.
