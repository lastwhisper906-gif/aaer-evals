# QCOM notes — 0001728949-19-000012


## qcom:EquityMethodandNonmarketableEquityInvestmentsTableTextBlock

[0001728949-19-000012:notes:1]
The carrying values of our equity method and non-marketable equity investments are recorded in other noncurrent assets and were as follows (in millions):

[0001728949-19-000012:notes:2]
|  | December 30, 2018 |  | September 30, 2018 |
| Equity method investments | $ | 386 |  |  | $ | 402 |  |
| Non-marketable equity investments | 708 |  |  | 650 |  |
|  | $ | 1,094 |  |  | $ | 1,052 |  |


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001728949-19-000012:notes:3]
Revision of Prior Period Financial Statements

[0001728949-19-000012:notes:4]
We revised certain prior period financial statements for an immaterial error related to the recognition of certain royalty revenues of our QTL segment in the quarterly and annual periods in fiscal 2018 and third and fourth quarters and annual period in fiscal 2017 (Note 1). A summary of revisions to our previously reported financial statements is presented below (in millions, except per share data).

[0001728949-19-000012:notes:5]
Revised Consolidated Balance Sheets.

[0001728949-19-000012:notes:6]
|  | As of September 30, 2018 |  | As of September 24, 2017 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Deferred tax assets (non-current) | $ | 904 |  |  | $ | 32 |  |  | $ | 936 |  |  | $ | 2,900 |  |  | $ | 12 |  |  | $ | 2,912 |  |
| Total assets | 32,686 |  |  | 32 |  |  | 32,718 |  |  | 65,486 |  |  | 12 |  |  | 65,498 |  |
| Other current liabilities | 6,825 |  |  | 153 |  |  | 6,978 |  |  | 4,756 |  |  | 33 |  |  | 4,789 |  |
| Total current liabilities | 11,236 |  |  | 153 |  |  | 11,389 |  |  | 10,907 |  |  | 33 |  |  | 10,940 |  |
| Total liabilities | 31,758 |  |  | 153 |  |  | 31,911 |  |  | 34,740 |  |  | 33 |  |  | 34,773 |  |
| Retained earnings | 663 |  |  | (121 | ) |  | 542 |  |  | 30,088 |  |  | (21 | ) |  | 30,067 |  |
| Total stockholders’ equity | 928 |  |  | (121 | ) |  | 807 |  |  | 30,746 |  |  | (21 | ) |  | 30,725 |  |
| Total liabilities and stockholders’ equity | 32,686 |  |  | 32 |  |  | 32,718 |  |  | 65,486 |  |  | 12 |  |  | 65,498 |  |

[0001728949-19-000012:notes:7]
Revised Consolidated Statements of Operations.

[0001728949-19-000012:notes:8]
|  | Year Ended |
|  | September 30, 2018 |  | September 24, 2017 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Licensing revenues | $ | 5,332 |  |  | $ | (121 | ) |  | $ | 5,211 |  |  | $ | 5,644 |  |  | $ | (33 | ) |  | $ | 5,611 |  |
| Total revenues | 22,732 |  |  | (121 | ) |  | 22,611 |  |  | 22,291 |  |  | (33 | ) |  | 22,258 |  |
| Operating income | 742 |  |  | (121 | ) |  | 621 |  |  | 2,614 |  |  | (33 | ) |  | 2,581 |  |
| Income before income taxes | 513 |  |  | (121 | ) |  | 392 |  |  | 3,020 |  |  | (33 | ) |  | 2,987 |  |
| Income tax expense | (5,377 | ) |  | 21 |  |  | (5,356 | ) |  | (555 | ) |  | 12 |  |  | (543 | ) |
| Net (loss) income | (4,864 | ) |  | (100 | ) |  | (4,964 | ) |  | 2,465 |  |  | (21 | ) |  | 2,444 |  |
| Net (loss) income attributable to Qualcomm | (4,864 | ) |  | (100 | ) |  | (4,964 | ) |  | 2,466 |  |  | (21 | ) |  | 2,445 |  |
| Basic (loss) earnings per share | (3.32 | ) |  | (0.07 | ) |  | (3.39 | ) |  | 1.67 |  |  | (0.01 | ) |  | 1.66 |  |
| Diluted (loss) earnings per share | (3.32 | ) |  | (0.07 | ) |  | (3.39 | ) |  | 1.65 |  |  | (0.01 | ) |  | 1.64 |  |

[0001728949-19-000012:notes:9]
|  | Three Months Ended September 30, 2018 |  | Three Months Ended June 24, 2018 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Licensing revenues | $ | 1,153 |  |  | $ | (25 | ) |  | $ | 1,128 |  |  | $ | 1,489 |  |  | $ | (22 | ) |  | $ | 1,467 |  |
| Total revenues | 5,803 |  |  | (25 | ) |  | 5,778 |  |  | 5,599 |  |  | (22 | ) |  | 5,577 |  |
| Operating (loss) income | (654 | ) |  | (25 | ) |  | (679 | ) |  | 925 |  |  | (22 | ) |  | 903 |  |
| (Loss) income before income taxes | (775 | ) |  | (25 | ) |  | (800 | ) |  | 956 |  |  | (22 | ) |  | 934 |  |
| Income tax benefit | 282 |  |  | 5 |  |  | 287 |  |  | 263 |  |  | 5 |  |  | 268 |  |
| Net (loss) income | (493 | ) |  | (20 | ) |  | (513 | ) |  | 1,219 |  |  | (17 | ) |  | 1,202 |  |
| Basic (loss) earnings per share | (0.35 | ) |  | (0.01 | ) |  | (0.36 | ) |  | 0.82 |  |  | (0.01 | ) |  | 0.81 |  |
| Diluted (loss) earnings per share | (0.35 | ) |  | (0.01 | ) |  | (0.36 | ) |  | 0.82 |  |  | (0.01 | ) |  | 0.81 |  |

[0001728949-19-000012:notes:10]
|  | Three Months Ended March 25, 2018 |  | Three Months Ended December 24, 2017 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Licensing revenues | $ | 1,325 |  |  | $ | (41 | ) |  | $ | 1,284 |  |  | $ | 1,364 |  |  | $ | (33 | ) |  | $ | 1,331 |  |
| Total revenues | 5,261 |  |  | (41 | ) |  | 5,220 |  |  | 6,068 |  |  | (33 | ) |  | 6,035 |  |
| Operating income (loss) | 441 |  |  | (41 | ) |  | 400 |  |  | 29 |  |  | (33 | ) |  | (4 | ) |
| Income (loss) before income taxes | 358 |  |  | (41 | ) |  | 317 |  |  | (27 | ) |  | (33 | ) |  | (60 | ) |
| Income tax benefit (expense) | 5 |  |  | 8 |  |  | 13 |  |  | (5,926 | ) |  | 3 |  |  | (5,923 | ) |
| Net income (loss) | 363 |  |  | (33 | ) |  | 330 |  |  | (5,953 | ) |  | (30 | ) |  | (5,983 | ) |
| Basic earnings (loss) per share | 0.25 |  |  | (0.03 | ) |  | 0.22 |  |  | (4.03 | ) |  | (0.02 | ) |  | (4.05 | ) |
| Diluted earnings (loss) per share | 0.24 |  |  | (0.02 | ) |  | 0.22 |  |  | (4.03 | ) |  | (0.02 | ) |  | (4.05 | ) |

[0001728949-19-000012:notes:11]
|  | Three Months Ended September 24, 2017 |  | Three Months Ended June 25, 2017 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Licensing revenues | $ | 1,207 |  |  | $ | (17 | ) |  | $ | 1,190 |  |  | $ | 1,250 |  |  | $ | (15 | ) |  | $ | 1,235 |  |
| Total revenues | 5,905 |  |  | (17 | ) |  | 5,888 |  |  | 5,371 |  |  | (15 | ) |  | 5,356 |  |
| Operating income | 333 |  |  | (17 | ) |  | 316 |  |  | 773 |  |  | (15 | ) |  | 758 |  |
| Income before income taxes | 434 |  |  | (17 | ) |  | 417 |  |  | 858 |  |  | (15 | ) |  | 843 |  |
| Income tax (expense) benefit | (266 | ) |  | 6 |  |  | (260 | ) |  | 7 |  |  | 5 |  |  | 12 |  |
| Net income | 168 |  |  | (11 | ) |  | 157 |  |  | 865 |  |  | (10 | ) |  | 855 |  |
| Net income attributable to Qualcomm | 168 |  |  | (11 | ) |  | 157 |  |  | 866 |  |  | (10 | ) |  | 856 |  |
| Basic earnings per share | 0.11 |  |  | — |  |  | 0.11 |  |  | 0.59 |  |  | (0.01 | ) |  | 0.58 |  |
| Diluted earnings per share | 0.11 |  |  | — |  |  | 0.11 |  |  | 0.58 |  |  | (0.01 | ) |  | 0.57 |  |

[0001728949-19-000012:notes:12]
Amounts, other than per share amounts, are rounded to millions each quarter. Therefore, the sum of the quarterly amounts may not equal the annual amounts reported.

[0001728949-19-000012:notes:13]
Revised Consolidated Statements of Comprehensive Income (Loss).

[0001728949-19-000012:notes:14]
|  | Year Ended |
|  | September 30, 2018 |  | September 24, 2017 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Net (loss) income | $ | (4,864 | ) |  | $ | (100 | ) |  | $ | (4,964 | ) |  | $ | 2,465 |  |  | $ | (21 | ) |  | $ | 2,444 |  |
| Total comprehensive (loss) income | (4,983 | ) |  | (100 | ) |  | (5,083 | ) |  | 2,421 |  |  | (21 | ) |  | 2,400 |  |
| Comprehensive (loss) income attributable to Qualcomm | (4,983 | ) |  | (100 | ) |  | (5,083 | ) |  | 2,422 |  |  | (21 | ) |  | 2,401 |  |

[0001728949-19-000012:notes:15]
|  | Three Months Ended June 24, 2018 |  | Three Months Ended March 25, 2018 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Net income | $ | 1,219 |  |  | $ | (17 | ) |  | $ | 1,202 |  |  | $ | 363 |  |  | $ | (33 | ) |  | $ | 330 |  |
| Total comprehensive income | 997 |  |  | (17 | ) |  | 980 |  |  | 523 |  |  | (33 | ) |  | 490 |  |

[0001728949-19-000012:notes:16]
|  | Three Months Ended December 24, 2017 |  | Three Months Ended June 25, 2017 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Net (loss) income | $ | (5,953 | ) |  | $ | (30 | ) |  | $ | (5,983 | ) |  | $ | 865 |  |  | $ | (10 | ) |  | $ | 855 |  |
| Total comprehensive (loss) income | (5,951 | ) |  | (30 | ) |  | (5,981 | ) |  | 925 |  |  | (10 | ) |  | 915 |  |
| Comprehensive (loss) income attributable to Qualcomm | (5,951 | ) |  | (30 | ) |  | (5,981 | ) |  | 926 |  |  | (10 | ) |  | 916 |  |

[0001728949-19-000012:notes:17]
Revised Consolidated Statements of Cash Flows.

[0001728949-19-000012:notes:18]
We revised our condensed consolidated statements of cash flows for the years ended September 30, 2018 and September 24, 2017 and the three months ended December 24, 2017 for this correction, which had no impact to net cash provided by operating activities in each such period.

[0001728949-19-000012:notes:19]
|  | Year Ended |
|  | September 30, 2018 |  | September 24, 2017 |
|  | As reported |  | Adjustment |  | As revised |  | As reported |  | Adjustment |  | As revised |
| Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net (loss) income | $ | (4,864 | ) |  | $ | (100 | ) |  | $ | (4,964 | ) |  | $ | 2,465 |  |  | $ | (21 | ) |  | $ | 2,444 |  |
| Income tax provision in excess of (less than) income tax payments | 4,502 |  |  | (21 | ) |  | 4,481 |  |  | (400 | ) |  | (12 | ) |  | (412 | ) |
| Payroll, benefits and other liabilities | 687 |  |  | 121 |  |  | 808 |  |  | 2,103 |  |  | 33 |  |  | 2,136 |  |
| Net cash provided by operating activities | 3,895 |  |  | — |  |  | 3,895 |  |  | 5,001 |  |  | — |  |  | 5,001 |  |

[0001728949-19-000012:notes:20]
|  | Three Months Ended December 24, 2017 |
|  | As reported |  | Reclassification adjustment (1) |  | Revision adjustment |  | As revised |
| Operating Activities: |  |  |  |  |  |  |  |
| Net loss | $ | (5,953 | ) |  | $ | — |  |  | $ | (30 | ) |  | $ | (5,983 | ) |
| Income tax provision in excess of (less than) income tax payments | 5,697 |  |  | — |  |  | (3 | ) |  | 5,694 |  |
| Other items, net | 57 |  |  | (82 | ) |  | — |  |  | (25 | ) |
| Other assets | (56 | ) |  | (6 | ) |  | — |  |  | (62 | ) |
| Payroll, benefits and other liabilities | 1,000 |  |  | 88 |  |  | 33 |  |  | 1,121 |  |
| Net cash provided by operating activities | 1,762 |  |  | — |  |  | — |  |  | 1,762 |  |

[0001728949-19-000012:notes:21]
(1) Certain previously reported amounts have been reclassified to conform to the current year presentation.

[0001728949-19-000012:notes:22]
Revised Segment Information.

[0001728949-19-000012:notes:23]
QTL segment results were revised for this correction (Note 7), which resulted in a decrease in QTL revenues and EBT (earnings before income taxes) of $33 million for the three months ended December 24, 2017. In addition, QTL revenues and EBT were also impacted for each of the other applicable prior periods by the same amount as consolidated revenues for the respective period.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-19-000012:notes:24]
[same as prior period, unchanged from 0001728949-18-000075:notes:1]

[0001728949-19-000012:notes:25]
| Accounts Receivable (in millions) |  |  |  |
|  | December 30, 2018 |  | September 30, 2018 |
| Trade, net of allowances for doubtful accounts of $47 and $56, respectively | $ | 2,330 |  |  | $ | 2,667 |  |
| Unbilled receivables | 1,072 |  |  | 201 |  |
| Other | 24 |  |  | 36 |  |
|  | $ | 3,426 |  |  | $ | 2,904 |  |

[0001728949-19-000012:notes:26]
The increase in unbilled receivables was primarily due to the adoption of ASC 606 (Note 1). Accounts receivable at December 30, 2018 and September 30, 2018 included approximately $960 million related to the short payment in the second quarter of fiscal 2017 of royalties reported by and deemed collectible from Apple’s contract manufacturers. This same amount was recorded in customer-related liabilities (in other current liabilities) for Apple, since we do not have the contractual right to offset these amounts.

[0001728949-19-000012:notes:27]
| Inventories (in millions) |  |  |  |
|  | December 30, 2018 |  | September 30, 2018 |
| Raw materials | $ | 79 |  |  | $ | 72 |  |
| Work-in-process | 763 |  |  | 715 |  |
| Finished goods | 856 |  |  | 906 |  |
|  | $ | 1,698 |  |  | $ | 1,693 |  |

[0001728949-19-000012:notes:28]
Equity Method and Non-marketable Equity Investments. The carrying values of our equity method and non-marketable equity investments are recorded in other noncurrent assets and were as follows (in millions):

[0001728949-19-000012:notes:29]
| Other Current Liabilities (in millions) |  |  |  |
|  | December 30, 2018 |  | September 30, 2018 |
| Customer incentives and other customer-related liabilities | $ | 3,494 |  |  | $ | 3,500 |  |
| Accrual for EC fine (Note 6) | 1,155 |  |  | 1,167 |  |
| Income taxes payable | 484 |  |  | 453 |  |
| RF360 Holdings put and call option | 1,141 |  |  | 1,137 |  |
| Other | 557 |  |  | 721 |  |
|  | $ | 6,831 |  |  | $ | 6,978 |  |

[0001728949-19-000012:notes:30]
Other Income, Costs and Expenses. Other expenses in the three months ended December 30, 2018 included $180 million in restructuring and restructuring-related charges related to our Cost Plan (Note 8), partially offset by a $31 million benefit related to a favorable legal settlement.

[0001728949-19-000012:notes:31]
Other expenses in the three months ended December 24, 2017 consisted of a $1.2 billion charge related to the European Commission (EC) fine (Note 6).

[0001728949-19-000012:notes:32]
| Investment and Other Income, Net (in millions) |  |  |  |
|  | Three Months Ended |
|  | December 30, 2018 |  | December 24, 2017 |
| Interest and dividend income | $ | 74 |  |  | $ | 126 |  |
| Net (losses) gains on marketable securities | (72 | ) |  | 10 |  |
| Net gains on other investments | 35 |  |  | 13 |  |
| Impairment losses on marketable securities and other investments | (9 | ) |  | (9 | ) |
| Net losses on derivative investments | (8 | ) |  | (1 | ) |
| Equity in net losses of investees | (21 | ) |  | (21 | ) |
| Net gains (losses) on foreign currency transactions | 6 |  |  | (4 | ) |
|  | $ | 5 |  |  | $ | 114 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-19-000012:notes:33]
Commitments and Contingencies

[0001728949-19-000012:notes:34]
Legal and Regulatory Proceedings.

[0001728949-19-000012:notes:35]
Apple Inc. (Apple) v. QUALCOMM Incorporated: On January 20, 2017, Apple filed a complaint against us in the United States District Court for the Southern District of California seeking declarations with respect to several of our patents and alleging that we breached certain agreements and violated federal antitrust and California state unfair competition laws. In its initial complaint, Apple sought declaratory judgments of non-infringement by Apple of nine of our patents, or in the alternative, a declaration of royalties Apple must pay for the patents. Apple further sought a declaration that our sale of baseband processor chipsets exhausts our patent rights for patents embodied in those chipsets. Separately, Apple sought to enjoin us from seeking excessive royalties from Apple and to disgorge royalties paid by Apple’s contract manufacturers that the court finds were not fair, reasonable and non-discriminatory (FRAND). Apple also claimed that our refusal to make certain payments to Apple under a Business Cooperation and Patent Agreement (Cooperation Agreement) constituted a breach of contract in violation of California law and sought damages in the amount of the unpaid payments, alleged to be approximately $1 billion. In addition, Apple claimed that we have refused to deal with competitors in contravention of our agreements with applicable standard setting organizations, have used our market position to impose contractual obligations on Apple that prevented Apple from challenging our licensing practices, have tied the purchase of our CDMA-enabled and “premium” LTE-enabled chipsets to licensing certain of our patents and have required Apple to purchase baseband processor chipsets exclusively from us as a condition of our payment to Apple of certain rebates, in violation of Section 2 of the Sherman Act and the California Unfair Competition Law. Apple sought injunctive relief with respect to these claims and a judgment awarding its expenses, costs and attorneys’ fees.

[0001728949-19-000012:notes:36]
On April 10, 2017, we filed our Answer and Counterclaims (amended on May 24, 2017) in response to Apple’s complaint denying Apple’s claims and asserting claims against Apple. The counterclaims against Apple include tortious interference with our long-standing Subscriber Unit License Agreements (SULAs) with third-party contract manufacturers of Apple devices, causing those contract manufacturers to withhold certain royalty payments owed to us and violate their audit obligations; breach of contract and the implied covenant of good faith and fair dealing relating to the Cooperation Agreement; unjust enrichment and declaratory relief relating to the Cooperation Agreement; breach of contract based on Apple’s failure to pay amounts owed to us under a Statement of Work relating to a high-speed feature of our baseband processor chipsets; breach of the parties’ software agreement; and violation of California Unfair Competition Law based on Apple’s threatening us to prevent us from promoting the superior performance of our own baseband processor chipsets. We also seek declaratory judgments that we have satisfied our FRAND commitments with respect to Apple, and that our SULAs with the contract manufacturers do not violate either competition law or our FRAND commitments. On June 19, 2017, Apple filed a Partial Motion to Dismiss our counterclaim for violation of the California Unfair Competition Law. The court granted that motion on November 8, 2017. On June 20, 2017, Apple filed an Answer and Affirmative Defenses to the rest of our counterclaims, and also filed an Amended Complaint reiterating all of the original claims and adding claims for declaratory judgments of invalidity of the nine patents that are subject to declaratory judgment claims in the original complaint, adding new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for nine more patents. Apple also added claims for declaratory judgments that certain of our agreements are unenforceable. On July 21, 2017, we filed an Answer to Apple’s Amended Complaint as well as a motion to dismiss the new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for the nine additional patents. The court granted our motion on November 8, 2017.

[0001728949-19-000012:notes:37]
On May 17, 2017, we filed a complaint (captioned QUALCOMM Incorporated v. Compal Electronics, Inc. et al.) in the United States District Court for the Southern District of California against certain of Apple’s contract manufacturers, Compal Electronics, Inc. (Compal), FIH Mobile, Ltd., Hon Hai Precision Industry Co., Ltd. (together with FIH Mobile, Ltd., Foxconn), Pegatron Corporation (Pegatron) and Wistron Corporation (Wistron), asserting claims for injunctive relief, specific performance, declaratory relief and damages stemming from the defendants’ breach of contracts by ceasing the payment of royalties for iPhones and other devices which they manufacture for Apple. On July 17, 2017, Compal, Foxconn, Pegatron and Wistron each filed third-party complaints for contractual indemnity against Apple seeking to join Apple as a party to the action. On July 18, 2017, Apple filed an answer to these third-party complaints acknowledging its indemnity agreements and consenting to be joined. On that same day, the defendants filed an Answer and Counterclaims to the complaint, asserting defenses and counterclaims similar to allegations previously made by Apple in the Apple Inc. v. QUALCOMM Incorporated case discussed above. In addition, the defendants asserted certain new claims, including claims under Section 1 of the Sherman Act and California’s Cartwright Act. The defendants seek damages, declaratory relief, injunctive relief, restitution of certain royalties and other relief. Also, on July 18, 2017, Apple filed a motion to consolidate this action with the Apple Inc. v. QUALCOMM Incorporated case. On September 13, 2017, the court granted Apple’s consolidation motion. Fact discovery is closed in these cases.

[0001728949-19-000012:notes:38]
On August 31, 2018, Apple filed a motion for judgment on the pleadings that the court lacks subject matter jurisdiction over our counterclaim that our license offers to Apple have not violated our obligation to license standard-essential patents on FRAND terms. The same day, Apple filed motions for partial summary judgment on the following issues: that part of our claim for Apple’s alleged tortious interference with its contract manufacturers’ agreements is barred by the statute of limitations; that our claim for damages under the Cooperation Agreement is unfounded; and that certain of our patent rights are exhausted by the sale of our baseband processor chipsets. On November 8, 2018, the court ruled on Apple’s motion regarding its alleged tortious interference, holding that Apple is not liable for tortious interference that occurred prior to January 20, 2015, but may be held liable for subsequent tortious interference. On December 18, 2018, the court denied Apple’s motion regarding patent exhaustion as moot in light of the dismissal of the claims at issue discussed below. The court heard oral arguments on Apple’s remaining two motions on January 25, 2019.

[0001728949-19-000012:notes:39]
On September 14, 2018, we filed a motion to dismiss Apple’s declaratory judgment claims relating to the nine specific patents identified in its original complaint on the basis that we granted Apple and its contract manufacturers a covenant-not-to-sue on those patents. The judge granted our motion on November 20, 2018, which disposed of a total of 56 claims pled by Apple and its contract manufacturers, including non-infringement, validity, damages and patent exhaustion for each of the nine patents.

[0001728949-19-000012:notes:40]
Trial is scheduled to begin on April 15, 2019.

[0001728949-19-000012:notes:41]
On January 23, 2017, an Apple subsidiary in China filed two complaints against us in the Beijing Intellectual Property Court. On March 31, 2017, the court granted an application by Apple Inc. to join the actions as a plaintiff, and Apple amended the complaints. One of the complaints alleges a violation of China’s Anti-Monopoly Law (AML complaint); the other complaint requests a determination of the terms of a patent license between us and Apple (FRAND complaint). The AML complaint alleges that (i) we have abused our dominant position in communication standard-essential patents licensing markets and certain global baseband processor chipset markets by charging and offering royalty terms that were excessively high; (ii) we refused to license certain implementers of standardized technologies, including Apple and baseband processor chipset manufacturers; (iii) we forced Apple to use only our products and services; and (iv) we bundled licenses to standard-essential patents with licenses to non-standard-essential patents and imposed other unreasonable or discriminatory trading terms on Apple in violation of the AML. The AML complaint seeks a decree that we cease the alleged abuse of dominance, as well as damages in the amount of 1 billion Chinese renminbi (approximately $146 million based on the exchange rate on December 30, 2018). The FRAND complaint makes allegations similar to the AML complaint and further alleges that we refused to offer licensing terms for our cellular standard-essential patents consistent with our FRAND licensing commitments and failed to provide to Apple certain information about our patents. The FRAND complaint seeks (i) a declaration that the license terms offered to Apple by us for our mobile communication standard-essential patents are not compliant with FRAND; (ii) an order that we cease our actions that allegedly violate our FRAND obligations, including pricing on unfair, unreasonable and excessive terms, refusing to deal, imposing unreasonable trade conditions and failing to provide information on our patents; and (iii) a determination of FRAND-compliant license terms for our Chinese standard-essential patents. Apple also seeks its expenses in each of the cases.

[0001728949-19-000012:notes:42]
On August 3, 2017, we received three additional complaints filed by an Apple subsidiary in China and Apple Inc. against us in the Beijing Intellectual Property Court. The complaints seek declaratory judgments of non-infringement of three of our patents. We filed jurisdictional and other objections to the complaints, which the court denied on May 31, 2018. On July 5, 2018, we appealed the denial of our objections to the Beijing High People’s Court.

[0001728949-19-000012:notes:43]
On November 30, 2017, Apple and certain of its Chinese subsidiaries filed three patent infringement complaints against us in the Beijing Intellectual Property Court. Apple seeks damages and costs. We have filed jurisdictional objections to the complaints.

[0001728949-19-000012:notes:44]
On February 16, 2017, Apple and one of its Japanese subsidiaries filed four complaints against us in the Tokyo District Court. In three of the complaints, Apple seeks declaratory judgment of non-infringement by Apple of three of our patents. Apple further seeks a declaration that our patent rights with respect to those three patents are exhausted by our SULAs with the contract manufacturers of Apple’s devices as well as our sale of baseband processor chipsets. Apple also seeks an award of fees. On January 30, 2018, April 27, 2018 and July 13, 2018, the court dismissed each of Apple’s three declaratory judgment complaints, finding that Apple lacked standing based on the facts it alleged in those complaints. Apple has appealed all three decisions. On December 12, 2018, the Intellectual Property High Court dismissed the first of Apple’s appeals. The other two appeals are still pending. The court has yet to rule on whether Apple has standing in the remaining complaint. On May 15, 2017, we learned of the fourth complaint. In that complaint, Apple and one of its Japanese subsidiaries seek damages of 100 million Japanese yen (approximately $1 million based on the exchange rate on December 30, 2018) from us, based on allegations that we violated the Japanese Antimonopoly Act and the Japanese Civil Code. In particular, the fourth complaint alleges that (i) we hold a monopoly position in the market for baseband processor chipsets that implement certain cellular standards; (ii) we collect double royalties through our license agreements and the sale of baseband processor chipsets; (iii) we refused to grant Apple a license on FRAND terms and forced Apple to execute a rebate agreement under unreasonable conditions; (iv) we refused to grant Apple a direct license; and (v) we demanded a license fee based on the market value of the total device. We have filed jurisdictional and other objections to this complaint.

[0001728949-19-000012:notes:45]
On March 2, 2017, we learned that Apple and certain of its European subsidiaries issued a Claim Form against us in the UK High Court of Justice, Chancery Division, Patents Court on January 23, 2017. Apple subsequently filed an Amended Claim Form and Particulars of Claim. Both the Amended Claim Form and the Particulars of Claim allege several European competition law claims, including our refusal to license competing chipmakers, failure to offer Apple a direct license to our standard-essential patents on FRAND terms, demanding excessive royalties for our standard-essential patents, and demanding excessive license fees for the use of our standard-essential patents in connection with baseband processor chipsets purchased from us. Apple also seeks declarations that we are obliged to offer a direct patent license to Apple in respect of standard-essential patents actually practiced on FRAND terms and that using our baseband processor chipsets does not infringe any of our patents because we exhausted our patent rights. Finally, Apple seeks declarations that five of our European (UK) patents are invalid and not essential, and an order that each of those patents be revoked.

[0001728949-19-000012:notes:46]
On April 18, 2017, Apple and one of its Taiwanese subsidiaries filed a complaint against us in the Taiwan Intellectual Property Court alleging that we have abused a dominant market position in licensing wireless standard-essential patents and selling baseband processor chipsets, including improper pricing, refusal to deal, exclusive dealing, tying, imposing unreasonable trade terms and discriminatory treatment. The complaint seeks rulings that we not use the sales price of the terminal device as the royalty base for standard-essential patents; not leverage our cellular standard-essential patents to obtain licenses of our non-standard-essential patents or demand cross-licenses without proper compensation; not refuse, reduce, delay or take any other action to limit the supply of our baseband processor chipsets to non-licensees; that we must license our standard-essential patents on FRAND terms; and that we shall not, based on standard-essential patents, seek injunctions. The complaint also seeks damages of 10 million Taiwan dollars (less than $1 million based on the exchange rate on December 30, 2018), among other relief.

[0001728949-19-000012:notes:47]
We believe Apple’s and its contract manufacturers’ claims in the above matters are without merit.

[0001728949-19-000012:notes:48]
QUALCOMM Incorporated v. Apple Inc.: On July 6, 2017, we filed a complaint against Apple in the United States District Court for the Southern District of California asserting claims for damages and injunctive relief for infringement of six of our patents directed to a variety of features found in iPhone models. On July 7, 2017, we filed a complaint against Apple in the United States International Trade Commission (ITC) requesting that the ITC institute an investigation pursuant to Section 337 of the Tariff Act of 1930 based on Apple’s infringement of the same six patents. We are seeking a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor chipset. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple filed an Answer and Counterclaims in the District Court case on September 26, 2017. On November 29, 2017, Apple filed a First Amended Answer and Counterclaims asserting that our Snapdragon processors infringe eight Apple patents. On August 8, 2017, the ITC issued a notice of institution of an investigation. On August 25, 2017, we withdrew allegations as to one patent in both the ITC investigation and the district court case. On April 25, 2018, we withdrew allegations as to two additional patents in the ITC investigation, but not the District Court case, in order to satisfy certain briefing limitations and to narrow the issues for hearing. The ITC investigation evidentiary hearing by the Administrative Law Judge (ALJ) was held June 18-26, 2018. The ALJ’s Initial Determination on the merits was issued on September 28, 2018. The ALJ found that we had established a violation of Section 337 by Apple due to the infringement of one of the three asserted patents. However, the ALJ recommended against an exclusion order on the grounds of public interest. On October 15, 2018, the parties each filed petitions for review of portions of the ALJ’s decision by the full ITC. On December 12, 2018, the ITC announced that it will review the ALJ’s determination of violation on one patent and requested public comments on the potential impact on the public interest if an exclusion order is issued. The ITC denied review of the ALJ’s findings of no violation as to the other two patents. The target date for final determination by the ITC is February 19, 2019, but we expect that the target date will be moved due to the federal government shutdown. On March 2, 2018, the District Court granted our motion to sever, for separate trial, Apple’s counterclaims for patent infringement against us. Trial on four of our asserted patents is scheduled to begin on March 4, 2019. Apple has challenged the validity of four of our patents asserted in the first ITC action and corresponding District Court case via Inter Partes Review (IPR) petitions with the United States Patent and Trademark Office (USPTO) Patent Trial and Appeal Board (PTAB). The PTAB has instituted trials on three of those patents. With respect to Apple’s patent claims against us, trial is scheduled to begin on July 15, 2019. We challenged the validity of all of Apple’s asserted patents with the PTAB. Those petitions are pending.

[0001728949-19-000012:notes:49]
On November 1, 2017, we filed a complaint against Apple in San Diego Superior Court for breach of the Master Software Agreement between the companies. The complaint recounts instances when Apple failed to protect our software as required by the agreement and failed to provide sufficient information to which we are entitled under the agreement in order to understand whether other breaches have occurred. The complaint seeks specific performance of Apple’s obligations to cooperate with an audit of its handling of our software, damages and injunctive relief. Apple filed its answer to the complaint on December 19, 2017. On September 24, 2018, we filed a motion seeking to amend our complaint to add causes of action for additional contract breaches and misappropriation of trade secrets. On October 26, 2018, the court granted our motion. We filed an amended complaint on October 31, 2018 and further amended the complaint on November 15, 2018. Apple has filed a demurrer objecting to the sufficiency of the second amended complaint which is scheduled for hearing on February 8, 2019. No trial date is currently scheduled.

[0001728949-19-000012:notes:50]
On November 29, 2017, we filed three additional complaints against Apple in the United States District Court for the Southern District of California alleging infringement of a total of 16 of our patents. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. The complaints seek damages and injunctive relief. On January 22, 2018, Apple filed answers and counterclaims in each of these cases seeking declaratory judgments that the asserted patents are invalid and/or not infringed. For the case relating to the November 30, 2017 ITC investigation described below, fact discovery is scheduled to close on March 13, 2019, and trial is scheduled to begin on October 21, 2019. Apple has filed IPR petitions with the PTAB challenging the validity of four of our patents asserted in the November 30, 2017 ITC action and corresponding District Court action. The PTAB has granted the petition as to one of those patents. For the cases not related to the ITC investigation, Apple has challenged all of the asserted patents in IPR proceedings filed in the PTAB. No decisions have yet been issued by the PTAB. In total, Apple has filed 50 IPRs. The PTAB has initiated proceedings in 13 of the IPRs to date. As a result of the IPR proceedings, on August 29, 2018, the court stayed those two cases pending the outcome of the IPR proceedings.

[0001728949-19-000012:notes:51]
On November 30, 2017, we filed a complaint in the ITC accusing certain Apple products of infringing five of our patents. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. We seek a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor chipset. On January 2, 2018, the ITC instituted an investigation. The evidentiary hearing by the Administrative Law Judge (ALJ) took place from September 17-24, 2018 and included three of our patents. The ALJ’s Initial Determination on the merits was due on January 22, 2019 but did not occur due to the federal government shutdown. The target date for final determination by the ITC is currently May 22, 2019. We expect new dates will be set following the shutdown.

[0001728949-19-000012:notes:52]
On July 17, 2017, we filed complaints against Apple and certain of its subsidiaries in the Federal Republic of Germany, asserting infringement of one of our patents in the Mannheim District Court and infringement of another patent in the Munich District Court. On October 2, 2017, we filed claim extensions in these actions against Apple and certain of its subsidiaries, asserting infringement of two additional patents in the Mannheim District Court and infringement of five additional patents in the Munich District Court. On May 28, 2018, we filed additional claim extensions in these actions against Apple and certain of its subsidiaries, asserting infringement of three additional patents in the Mannheim District Court and infringement of one additional patent in the Munich District Court. The complaints seek remedies including, among other relief, declaratory relief confirming liability on the merits for damages and injunctive relief. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple and/or its subsidiaries and, in some cases, also Intel have challenged the validity of the asserted patents in opposition proceedings before the European Patent Office or nullity actions before the Federal Patent Court. On October 11, 2018, the Munich District Court issued a judgment declaring one of the patents asserted on October 2, 2017 as not infringed. We have appealed that judgment. On December 20, 2018, the Munich District Court issued judgments declaring one of the patents asserted on July 17, 2017 as infringed and issued an injunction against the infringing Apple products, which would be effective following the posting of financial guarantees. On January 3, 2019, Qualcomm served the requisite financial guarantees to enforce the injunction in the amount of 1.3 billion Euro (approximately $1.5 billion based on the exchange rate at December 30, 2018). Apple and its subsidiaries appealed the judgments and requested a preliminary stay of enforcement pending the appeals. On January 15, 2019, the Mannheim District Court issued a judgment declaring one of the patents asserted on October 2, 2017 as not infringed. All other patents remain pending. Dates for the pronouncements of judgment and hearings are scheduled for various dates through September 2019.

[0001728949-19-000012:notes:53]
On September 29, 2017, we filed three complaints against Apple and certain of its subsidiaries in the Beijing (China) Intellectual Property Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On May 10, 2018 and June 21, 2018, Apple filed invalidation requests with the Chinese Patent Review Board (PRB) for the three asserted patents. The PRB has not ruled on the invalidation requests.

[0001728949-19-000012:notes:54]
On November 13, 2017, we filed three complaints against certain of Apple’s subsidiaries in the Beijing (China) High People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief, damages and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On December 19, 2017, Apple’s subsidiaries filed invalidation requests with the PRB for the three asserted patents. PRB hearings regarding the validity of the patents were held in April and May 2018. The PRB issued rulings upholding the validity of all three patents. On May 22, 2018, Apple’s subsidiaries filed a second invalidation request with the PRB for one of the three asserted patents. The PRB held a hearing regarding this request on October 19, 2018. On November 30, 2018 and December 5, 2018, Apple appealed all three validity rulings from the PRB to the Beijing IP Court.

[0001728949-19-000012:notes:55]
On November 15, 2017, we filed three complaints against certain of Apple’s subsidiaries in the Fuzhou (China) Intermediate People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple’s subsidiaries filed invalidation requests with the PRB on December 8, 2017 for one of the patents and December 11, 2017 for the other two patents. PRB hearings regarding the validity of the patents were held in April and May 2018. The PRB issued orders upholding the validity of two of the patents subject to Apple’s invalidity challenges. The PRB ruled that the third patent was invalid. We subsequently withdrew the infringement action in Fuzhou with respect to the third patent. Infringement hearings were held from August through October 30, 2018. On November 30, 2018, the court granted our motions for preliminary injunctions with respect to two of the patents and enjoined Apple’s subsidiaries from importing, selling and offering to sell the iPhone 6S through X.

[0001728949-19-000012:notes:56]
On January 12, 2018, we filed three additional complaints against Apple and certain of its subsidiaries in the Fuzhou (China) Intermediate People’s Court, asserting infringement of three additional patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

[0001728949-19-000012:notes:57]
Also, on January 12, 2018, we filed three complaints against certain of Apple’s subsidiaries in the Jiangsu (China) High People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief, damages and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On February 5, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents were held in June 2018. The PRB issued orders upholding the validity of one of the patents and partially upholding the validity of another patent. The PRB has not ruled on the invalidation request for the final patent.

[0001728949-19-000012:notes:58]
On February 2, 2018, we filed three complaints against certain of Apple’s subsidiaries in the Qingdao (China) Intermediate People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On February 26, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents were held in June 2018. The PRB issued orders upholding the validity of two of the patents and invalidating the third patent. We subsequently withdrew the infringement action in Qingdao with respect to the third patent.

[0001728949-19-000012:notes:59]
Also, on February 2, 2018, we filed three complaints against certain of Apple’s subsidiaries in the Guangzhou (China) Intermediate People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On March 14, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents began in July 2018. The PRB issued orders upholding the validity of two of the patents. The PRB has not ruled on the invalidation request for the final patent. Infringement hearings for all three of the patents were held in October through December 2018.

[0001728949-19-000012:notes:60]
On June 14, 2018, we filed three complaints against certain of Apple’s subsidiaries in the Guangdong (China) High People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On August 13, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. The PRB has held hearings regarding all three of the patents.

[0001728949-19-000012:notes:61]
We believe Apple’s counterclaims and invalidation requests in the above matters are without merit.

[0001728949-19-000012:notes:62]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, a securities class action complaint was filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers. On April 29, 2016, the plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, the plaintiffs filed a second amended complaint, alleging that we and certain of our current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding our business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint sought unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, we filed a motion to dismiss the second amended complaint. On October 20, 2017, the court entered an order granting in part our motion to dismiss, and on November 29, 2017, the court entered an order granting the remaining portions of our motion to dismiss. On December 28, 2017, the plaintiffs filed an appeal to the United States Court of Appeals for the Ninth Circuit. No hearing date has been set. We believe the plaintiffs’ claims are without merit.

[0001728949-19-000012:notes:63]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. The court has not yet ruled on our motion to dismiss. We believe the plaintiffs’ claims are without merit.

[0001728949-19-000012:notes:64]
In re Qualcomm/Broadcom Merger Securities Litigation (formerly Camp v. Qualcomm Incorporated et al): On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints allege, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints seek unspecified damages, interest, fees and costs. On January 22, 2019, the Court appointed the lead plaintiff in the action and designated that the case be captioned “In re Qualcomm/Broadcom Merger Securities Litigation.” Upon the filing of a consolidated complaint in the action, we anticipate filing a motion to dismiss the complaint, as we believe the plaintiffs’ claims are without merit.

[0001728949-19-000012:notes:65]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Twenty-two such cases remain outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the Ninth Circuit Court of Appeals granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. We believe the plaintiffs’ claims are without merit.

[0001728949-19-000012:notes:66]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, six consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia, and the Quebec Superior Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the FTC and U.S. consumer class action complaints. The complaints seek unspecified damages. We have not yet answered the complaints.

[0001728949-19-000012:notes:67]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that our business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that our Japanese licensees were forced to cross-license patents to us on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against our other licensees who made a similar commitment in their license agreements with us. The cease and desist order seeks to require us to modify our existing license agreements with Japanese companies to eliminate these provisions while preserving the license of our patents to those companies. We disagree with the conclusions that we forced our Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. We invoked our right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted our motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 37 different dates. No further hearings are currently scheduled. Fines or other monetary remedies are not available in this matter.

[0001728949-19-000012:notes:68]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that we violated Korean law by offering certain discounts and rebates for purchases of our CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents expired. The KFTC levied a fine, which we paid and recorded as an expense in fiscal 2010. We appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, we filed an appeal with the Korea Supreme Court. We understand that the Korea Supreme Court intends to issue a decision in this matter on January 30, 2019.

[0001728949-19-000012:notes:69]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (iii) not demand unjustifiable conditions in our license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred to in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred to in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean Won (approximately $927 million), which we paid on March 30, 2017. We believe that our business practices do not violate the MRFTA, and on February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. On the same day, we filed an application with the Seoul High Court to stay the decision’s remedial order pending the Seoul High Court’s final judgment on our action to cancel the KFTC’s decision. On September 4, 2017, the Seoul High Court denied our application to stay the remedial order, and on November 27, 2017, the Korea Supreme Court dismissed our appeal of the Seoul High Court’s decision on the application to stay. The Seoul High Court has not ruled on our action to cancel the KFTC’s decision.

[0001728949-19-000012:notes:70]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, we were engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On August 15, 2016, we submitted our response to the Statement of Objections. On July 19, 2018, the EC announced that it had issued a Supplementary Statement of Objections which focuses on certain elements of the “price-cost” test applied by the EC to assess the extent to which we sold certain baseband chipsets allegedly below cost. On October 22, 2018, we submitted our response to the Supplementary Statement of Objections. On January 10, 2019, the EC held a hearing regarding the Supplementary Statement of Objections and our response to it. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of our revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. We believe that our business practices do not violate the European Union (EU) competition rules.

[0001728949-19-000012:notes:71]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that, pursuant to an agreement with Apple Inc., since 2011, we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets. This conduct allegedly reduced Apple’s incentives to source baseband chipsets from our competitors and harmed competition and innovation for certain baseband chipsets. On January 24, 2018, the EC issued a decision finding that certain terms of that agreement violate EU competition law and imposed a fine of 997 million Euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not ruled on our appeal. We believe that our business practices do not violate the EU competition rules.

[0001728949-19-000012:notes:72]
We recorded a charge of $1.2 billion to other expenses related to the EC fine in the first quarter of fiscal 2018. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. As of October 1, 2018, we have designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 30, 2018, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.2 billion and included in other current liabilities.

[0001728949-19-000012:notes:73]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of cellular modem chipsets on the purchaser first agreeing to a license to our cellular standard-essential patents, paying incentives to purchasers of cellular modem chipsets to induce them to accept certain license terms, refusing to license our cellular standard-essential patents to our competitors, and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint seeks a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief. A fine is not an available remedy in this matter, and we do not believe that other monetary remedies are likely. On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to rival sellers of cellular modem chipsets. On October 15, 2018, we and the FTC submitted a Joint Administrative Motion asking the District Court to defer ruling on the FTC’s partial summary judgment motion in order to facilitate the parties’ ongoing discussions concerning settlement of this litigation, which the District Court denied on the same day. On November 6, 2018, the District Court granted the FTC’s partial summary judgment motion. On November 29, 2018, we and the FTC filed a Joint Pretrial Statement in which the FTC seeks a declaration and adjudication that our conduct violates the FTCA and seeks permanent injunctive and other equitable relief, including an order that would at least (i) require us to: negotiate or renegotiate license terms with licensees in good faith under conditions free from the threat of lack of access to or discriminatory provision of cellular modem chipset supply or associated technical, software or other support; submit to arbitral or judicial dispute resolution to determine reasonable royalties and other license terms should a licensee choose to pursue such a resolution; make exhaustive standard-essential patent licenses available to cellular modem chipset suppliers on FRAND terms and submit to arbitral or judicial dispute resolution to determine such terms; and adhere to certain compliance and monitoring procedures; and (ii) prohibit us from: conditioning the supply of cellular modem chipsets on a customer’s patent-license status; discriminating or retaliating against cellular modem chipset customers or cellular modem chipset suppliers because of a customer’s license status or a dispute over license terms; making payments or providing other value contingent on a customer’s agreement to license terms; entering into exclusive-dealing agreements for the supply of cellular modem chipsets; or interfering with the ability of customers to communicate with a government agency about a potential law enforcement or regulatory matter. Trial was held January 4-29, 2019. The FTC alleged at trial that we have monopoly power in the markets for both CDMA and premium-tier LTE cellular modem chipsets and have acted anticompetitively in violation of either Section 1 or Section 2 of the Sherman Act, or Section 5 of the FTCA to maintain our monopoly power in one or both of these alleged markets by employing four business practices. These practices include (i) our longstanding practice of requiring a license to our cellular standard-essential patents for a particular cellular standard before selling cellular modem chipsets that are used in cellular devices that implement such cellular standards; (ii) providing incentive payments to certain licensees to agree to our preferred license terms; (iii) not exhaustively licensing our cellular standard-essential patents to companies that make, use or sell cellular modem chipsets; and (iv) entering into a now-expired contract that conditioned certain payments to Apple on its not launching a new device that used a non-Qualcomm brand cellular modem chipset. In asserting that we have acted anticompetitively, the FTC asserts that our historical royalty rates are too high to be reasonable, and that amounts over a reasonable rate act as a surcharge on CDMA or premium-tier LTE cellular modem chipset transactions taking place between OEMs and our competitors, and this surcharge weakens our competitors by raising the price OEMs must pay for such CDMA or premium-tier LTE cellular modem chipsets. We believe the FTC’s claims in this case are without merit.

[0001728949-19-000012:notes:74]
Contingent losses and other considerations: We will continue to vigorously defend ourself in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fine, we have not recorded any accrual at December 30, 2018 for contingent losses associated with these matters based on our belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. For example, if some or all of our license agreements are declared invalid or unenforceable and we are required to renegotiate these license agreements, or if as part of a settlement we agree to renegotiate certain of our license agreements, we may not receive, or may not be able to recognize, any licensing or royalty revenues on the impacted license agreements unless and until we enter into new license agreements. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0001728949-19-000012:notes:75]
Indemnifications. We generally do not indemnify our customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by us, or by intellectual property provided by us to chipset foundries and semiconductor assembly and test service providers. Our obligations under these agreements may be limited in terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us.

[0001728949-19-000012:notes:76]
Through December 30, 2018, we have received a number of claims from our direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by our products. Reimbursements under indemnification arrangements have not been material to our consolidated financial statements. We have not recorded any accrual for contingent liabilities at December 30, 2018 associated with these indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001728949-19-000012:notes:77]
Purchase Obligations and Operating Leases. We have agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization. We lease certain of our land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases.

[0001728949-19-000012:notes:78]
Obligations under our purchase agreements, which primarily relate to integrated circuit product inventory obligations and future minimum lease payments under our operating leases, at December 30, 2018 were as follows (in millions):

[0001728949-19-000012:notes:79]
|  | Purchase Obligations |  | Operating Leases |
| Remainder of fiscal 2019 | $ | 3,748 |  |  | $ | 91 |  |
| 2020 | 499 |  |  | 106 |  |
| 2021 | 251 |  |  | 83 |  |
| 2022 | 45 |  |  | 51 |  |
| 2023 | 9 |  |  | 30 |  |
| Thereafter | 4 |  |  | 43 |  |
| Total | $ | 4,556 |  |  | $ | 404 |  |

[0001728949-19-000012:notes:80]
Other Commitments. At December 30, 2018, we committed to fund certain strategic investments up to $282 million, of which $31 million and $66 million was expected to be funded in fiscal 2020 and fiscal 2021, respectively. The remaining commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all.

[0001728949-19-000012:notes:81]
In March 2018, our RF360 Holdings joint venture entered into an agreement for a build-to-suit construction project with a third-party lessor for the development of a manufacturing facility located in Singapore. The agreement includes a long-term lease commitment with a noncancelable 10-year term commencing upon completion of the construction project. At December 30, 2018, the minimum lease commitment under the agreement based on the noncancelable term was $87 million.


## us-gaap:DebtDisclosureTextBlock

[0001728949-19-000012:notes:82]
Debt

[0001728949-19-000012:notes:83]
Revolving Credit Facility. We have an Amended and Restated Revolving Credit Facility (2016 Amended and Restated Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. Proceeds from the Amended and Restated Revolving Credit Facility are expected to be used for general corporate purposes. Loans under the 2016 Amended and Restated Revolving Credit Facility will bear interest, at our option, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the 2016 Amended and Restated Revolving Credit Facility) or the Base Rate (determined in accordance with the 2016 Amended and Restated Revolving Credit Facility), in each case plus an applicable margin based on our long-term unsecured senior, non-credit enhanced debt ratings. The margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.805% and 0.00% per annum, respectively. The 2016 Amended and Restated Revolving Credit Facility has a facility fee, which accrues at a rate of 0.07% per annum. At December 30, 2018 and September 30, 2018, we had not borrowed any funds under the 2016 Amended and Restated Revolving Credit Facility.

[0001728949-19-000012:notes:84]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At December 30, 2018 and September 30, 2018, we had $1.0 billion of outstanding commercial paper included in short-term debt with a weighted-average interest rate of 2.55% and 2.35%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 26 days and 16 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at December 30, 2018 and September 30, 2018.

[0001728949-19-000012:notes:85]
Long-term Debt. The following table provides a summary of our long-term debt (in millions, except percentages):

[0001728949-19-000012:notes:86]
|  |  | December 30, 2018 |  | September 30, 2018 |
|  |  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | $ | 250 |  |  | 3.25% |  | $ | 250 |  |  | 2.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 3.18% |  | 1,750 |  |  | 3.13% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 3.66% |  | 2,000 |  |  | 3.73% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.73% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.72% |  | 1,500 |  |  | 4.72% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 3.32% |  | 500 |  |  | 3.14% |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | 1,500 |  |  | 2.70% |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | 1,500 |  |  | 3.01% |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.47% |  | 1,500 |  |  | 4.47% |
|  | Total principal | 15,500 |  |  |  |  | 15,500 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (82 | ) |  |  |  | (85 | ) |  |  |
|  | Hedge accounting fair value adjustments | (30 | ) |  |  |  | (50 | ) |  |  |
|  | Total long-term debt | $ | 15,388 |  |  |  |  | $ | 15,365 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | — |  |  |  |  | $ | — |  |  |  |
|  | Long-term debt | 15,388 |  |  |  |  | 15,365 |  |  |  |
|  | Total | $ | 15,388 |  |  |  |  | $ | 15,365 |  |  |  |

[0001728949-19-000012:notes:87]
At December 30, 2018 and September 30, 2018, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $14.8 billion and $15.1 billion, respectively.

[0001728949-19-000012:notes:88]
We may redeem the outstanding fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. We may not redeem the outstanding floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of our other senior unsecured indebtedness and will effectively rank junior to all liabilities of our subsidiaries.

[0001728949-19-000012:notes:89]
At December 30, 2018, we had outstanding interest rate swaps with an aggregate notional amount of $1.8 billion related to the May 2015 Notes, which effectively converted approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recorded as interest expense in the current period. We did not enter into similar interest rate swaps in connection with issuance of the May 2017 Notes.

[0001728949-19-000012:notes:90]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to our commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $234 million and $257 million in the three months ended December 30, 2018 and December 24, 2017, respectively.

[0001728949-19-000012:notes:91]
Debt Covenants. The 2016 Amended and Restated Revolving Credit Facility, requires that we comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. We are not subject to any financial covenants under the notes nor any covenants that would prohibit us from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by us or our subsidiaries. At December 30, 2018 and September 30, 2018, we were in compliance with the applicable covenants under the 2016 Amended and Restated Revolving Credit Facility.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001728949-19-000012:notes:92]
Basic earnings (loss) per common share is computed by dividing net income (loss) by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans and shares subject to accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Due to the net loss for the three months ended December 24, 2017, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share.


## us-gaap:EquitySecuritiesWithoutReadilyDeterminableFairValuePolicyTextBlock

[0001728949-19-000012:notes:93]
Prior to the adoption of the new accounting guidance in the first quarter of fiscal 2019, investments in non-marketable equity securities were recorded at cost less impairment, if any, with any losses resulting from an impairment recognized in investment and other income, net. Beginning in fiscal 2019, investments in non-marketable equity securities are recorded at cost, less impairments, adjusted for observable price changes in orderly transactions for identical or similar securities. All gains and losses on investments in non-marketable equity securities, realized and unrealized, are recognized in investment and other income, net.


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-19-000012:notes:94]
[same as prior period, unchanged from 0001728949-18-000075:notes:84]

[0001728949-19-000012:notes:95]
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at December 30, 2018 (in millions):

[0001728949-19-000012:notes:96]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 5,336 |  |  | $ | 2,992 |  |  | $ | — |  |  | $ | 8,328 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 108 |  |  | — |  |  | 108 |  |
| Auction rate securities | — |  |  | — |  |  | 35 |  |  | 35 |  |
| Equity securities | 141 |  |  | — |  |  | — |  |  | 141 |  |
| Total marketable securities | 141 |  |  | 108 |  |  | 35 |  |  | 284 |  |
| Derivative instruments | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Other investments | 364 |  |  | — |  |  | 6 |  |  | 370 |  |
| Total assets measured at fair value | $ | 5,841 |  |  | $ | 3,106 |  |  | $ | 41 |  |  | $ | 8,988 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 33 |  |  | $ | — |  |  | $ | 33 |  |
| Other liabilities | 364 |  |  | — |  |  | 85 |  |  | 449 |  |
| Total liabilities measured at fair value | $ | 364 |  |  | $ | 33 |  |  | $ | 85 |  |  | $ | 482 |  |

[0001728949-19-000012:notes:97]
Activity between Levels of the Fair Value Hierarchy. There were no transfers of marketable securities into or out of Level 3 during the three months ended December 30, 2018 and December 24, 2017. Other investments and other liabilities included in Level 3 at December 30, 2018 were comprised of convertible debt instruments issued by private companies and contingent consideration related to business combinations, respectively. There were no transfers of convertible debt instruments or contingent consideration amounts into or out of Level 3 during the three months ended December 30, 2018 and December 24, 2017.

[0001728949-19-000012:notes:98]
Assets Measured and Recorded at Fair Value on a Nonrecurring Basis. We measure certain assets and liabilities at fair value on a nonrecurring basis. These assets and liabilities include equity method investments when they are deemed to be other-than-temporarily impaired, non-marketable equity securities if there is an observable price adjustment or impairment, assets acquired, and liabilities assumed in an acquisition or nonmonetary exchange and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. If an observable price adjustment or impairment is recognized on our non-marketable equity securities during the period, we classify these fair value measurements as Level 3 based on the nature of the inputs. During the first quarter of fiscal 2019, goodwill related to a nonreportable segment that we agreed to sell was written down to its estimated fair value (Note 8). The estimation of fair value required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During the three months ended December 30, 2018 and December 24, 2017, we did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-19-000012:notes:99]
[same as prior period, unchanged from 0001728949-18-000075:notes:88]

[0001728949-19-000012:notes:100]
The 2017 Tax Cuts and Jobs Act (the Tax Legislation) significantly revised the United States corporate income tax by, among other things, lowering the corporate income tax rate to 21% and imposing a one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge). The Tax Legislation fundamentally changed the taxation of multinational entities, including a shift from a system of worldwide taxation with deferral to a hybrid territorial system, featuring a participation exemption regime with current taxation of certain foreign income, a minimum tax on low-taxed foreign earnings, and new measures to deter base erosion and promote U.S. production. As a fiscal-year taxpayer, certain provisions of the Tax Legislation became effective starting at the beginning of fiscal 2019, including new taxes due on certain foreign income, such as GILTI (global intangible low-taxed income), BEAT (base-erosion and anti-abuse tax) and FDII (foreign-derived intangible income). In response to the Tax Legislation, we implemented certain tax restructuring in fiscal 2018 and 2019. As a result, substantially all of our income is in the U.S. and qualifies for preferential treatment as FDII, and the impact of GILTI and BEAT are negligible. Accordingly, our estimated annual effective tax rate for fiscal 2019 reflects the effects of these components of the Tax Legislation. Our annual effective tax rate for fiscal 2018 reflected a blended federal statutory rate of approximately 25%.

[0001728949-19-000012:notes:101]
Pursuant to the Securities and Exchange Commission Staff Accounting Bulletin No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act (SAB 118), we have finalized the accounting for the income tax effects of the Tax Legislation, including the effects of the Toll Charge.

[0001728949-19-000012:notes:102]
As a result of the Tax Legislation, in fiscal 2019, several of our foreign subsidiaries made tax elections (commonly referred to as “check-the-box” elections) to be treated as U.S. branches for federal income tax purposes effective beginning in fiscal 2018 and 2019. We believe that by these foreign subsidiaries being treated as U.S. branches for federal income taxes, rather than controlled foreign corporations, we will significantly reduce the risk of being subject to GILTI and BEAT taxes. As a result of making these check-the-box elections in the first quarter of fiscal 2019, we recorded a tax benefit of $570 million due to establishing new U.S. net deferred tax assets resulting from the difference between the GAAP basis and the U.S. federal tax carryover basis of the existing assets and liabilities of those foreign subsidiaries, primarily related to customer incentive liabilities that have not been deducted for tax purposes. Additionally, during fiscal 2018, one of our foreign subsidiaries distributed certain intellectual property to a U.S. subsidiary resulting in a difference between the GAAP basis and the U.S. federal tax basis of the distributed intellectual property. Upon adoption of new accounting guidance in the first quarter of fiscal 2019, we recorded through retained earnings a deferred tax asset of approximately $2.6 billion, primarily related to the distributed intellectual property, with an adjustment to opening retained earnings (Note 1).

[0001728949-19-000012:notes:103]
We estimate our annual effective income tax rate to be approximately 7% benefit for fiscal 2019, which includes the impact of the tax benefit of $570 million due to establishing new U.S. net deferred tax assets from making certain check-the-box elections. The estimated annual effective tax rate for fiscal 2019 also reflects benefits from its FDII deduction and research and development tax credits. The annual effective tax rate for fiscal 2018 was impacted by the combined effect of the Toll Charge, the remeasurement of deferred tax assets and liabilities and our decision to no longer indefinitely reinvest certain foreign earnings, all of which resulted from the Tax Legislation. The annual effective tax rate for fiscal 2018 was also impacted by the termination fee paid to NXP Semiconductors N.V. (NXP), the EC fine, settlement with the Taiwan Fair Trade Commission (TFTC), allocation of expenses to our U.S. operations and new Singapore tax incentives.

[0001728949-19-000012:notes:104]
The effective tax rate of 91% benefit for the first quarter of fiscal 2019 was lower than the estimated annual effective tax rate of 7% benefit primarily due to the tax benefit of $570 million, which was recorded discretely in the first quarter.

[0001728949-19-000012:notes:105]
Unrecognized tax benefits were $223 million and $217 million at December 30, 2018 and September 30, 2018, respectively. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at December 30, 2018 may increase or decrease in the next 12 months.

[0001728949-19-000012:notes:106]
The United States Treasury Department has issued proposed regulations on several provisions of the Tax Legislation, including foreign tax credits, GILTI, BEAT and interest expense deduction limitations, which are expected to be finalized in the next several months. When finalized, these proposed regulations may adversely affect our provision for income taxes, results of operations and/or cash flow.

[0001728949-19-000012:notes:107]
We are subject to income taxes in the United States and numerous foreign jurisdictions and are currently under examination by various tax authorities worldwide, most notably in countries where we earn a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2000. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of December 30, 2018, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001728949-19-000012:notes:108]
[same as prior period, unchanged from 0001728949-18-000075:notes:100]

[0001728949-19-000012:notes:109]
|  | December 30, 2018 |
| Years to Maturity |  |
| Less than one year | $ | 108 |  |
| No single maturity date | 35 |  |
| Total | $ | 143 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-19-000012:notes:110]
Marketable Securities

[0001728949-19-000012:notes:111]
Our marketable securities were comprised as follows (in millions):

[0001728949-19-000012:notes:112]
|  | Current |  | Noncurrent (1) |
|  | December 30, 2018 |  | September 30, 2018 |  | December 30, 2018 |  | September 30, 2018 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 108 |  |  | $ | 144 |  |  | $ | — |  |  | $ | — |  |
| Auction rate securities | — |  |  | — |  |  | 35 |  |  | 35 |  |
| Total available-for-sale debt securities | 108 |  |  | 144 |  |  | 35 |  |  | 35 |  |
| Equity securities | 141 |  |  | 167 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 249 |  |  | $ | 311 |  |  | $ | 35 |  |  | $ | 35 |  |

[0001728949-19-000012:notes:113]
(1) Noncurrent marketable securities were included in other assets.

[0001728949-19-000012:notes:114]
Debt securities with no single maturity date included auction rate securities.

[0001728949-19-000012:notes:115]
During the three months ended December 30, 2018, there were no realized gains or losses on sales of available-for-sale debt securities, and during the three months ended December 24, 2017, gross realized gains were negligible.

[0001728949-19-000012:notes:116]
As of December 30, 2018 and September 30, 2018, unrealized gains and losses on available for sale debt securities were negligible. As of September 30, 2018, available-for-sale securities also included equity securities with a fair value of $167 million, including an unrealized gain of $63 million.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001728949-19-000012:notes:117]
In May 2014, the Financial Accounting Standards Board (FASB) issued new accounting guidance related to revenue recognition (ASC 606), which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition accounting guidance. The new accounting guidance defines a five-step approach that requires a company to recognize revenue as control of goods or services transfers to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. We adopted ASC 606 in the first quarter of fiscal 2019 using the modified retrospective transition method only to those contracts that were not completed as of October 1, 2018. We recognized the cumulative effect of initially applying the new revenue accounting guidance as an adjustment to opening retained earnings. Prior period results have not been restated and continue to be reported in accordance with the accounting guidance in effect for those periods (ASC 605). We have implemented new accounting policies, systems, processes and internal controls necessary to support the requirements of ASC 606.

[0001728949-19-000012:notes:118]
Adoption of this new accounting guidance most significantly impacts the timing of sales-based royalty revenues, which are the vast majority of our QTL segment’s revenues. Previously, we recognized sales-based royalties as revenues in the period in which such royalties were reported by licensees, which was after the conclusion of the quarter in which the licensees’ sales occurred and when all other revenue recognition criteria had been met. Under the new accounting guidance, we estimate and recognize sales-based royalties in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such amounts, resulting in an acceleration of revenue recognition compared to the historical method. Since we do not invoice for sales-based royalties recognized in any given quarter until after the conclusion of that quarter (which is generally the following quarter when such royalties are reported by licensees), revenues recognized from sales-based royalties results in unbilled receivables (included in accounts receivable, net on the condensed consolidated balance sheet). The adoption of ASC 606 did not otherwise have a material impact.

[0001728949-19-000012:notes:119]
The new accounting guidance also impacts the timing of recognizing certain customer incentives, which are recorded as a reduction to revenues in the period that the related revenues are earned. We previously accounted for certain customer incentive arrangements, including volume-related and other pricing rebates or cost reimbursements for marketing and other activities involving certain of our products and technologies, in part based on the maximum potential liability. Under the new accounting guidance, we estimate the amount of all customer incentives.

[0001728949-19-000012:notes:120]
The following table summarizes the cumulative effects of adopting the new revenue accounting guidance (substantially all of which related to the impact to QTL’s sales-based royalties) on our condensed consolidated balance sheet at October 1, 2018 (in millions):

[0001728949-19-000012:notes:121]
|  | Balance as of September 30, 2018 |  | Adjustment |  | Opening Balance as of October 1, 2018 |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 2,904 |  |  | $ | 957 |  |  | $ | 3,861 |  |
| Other current assets | 699 |  |  | 1 |  |  | 700 |  |
| Deferred tax assets | 936 |  |  | (98 | ) |  | 838 |  |
| Other assets | 1,970 |  |  | 1 |  |  | 1,971 |  |
| Liabilities |  |  |  |  |  |
| Unearned revenues, current | $ | 500 |  |  | $ | 6 |  |  | $ | 506 |  |
| Other current liabilities | 6,978 |  |  | 125 |  |  | 7,103 |  |
| Unearned revenues | 1,620 |  |  | (110 | ) |  | 1,510 |  |
| Stockholders’ equity |  |  |  |  |  |
| Retained earnings | $ | 542 |  |  | $ | 840 |  |  | $ | 1,382 |  |

[0001728949-19-000012:notes:122]
The following tables summarize the impacts of adopting the new revenue accounting guidance on our condensed consolidated balance sheet and statement of operations (in millions):

[0001728949-19-000012:notes:123]
|  | As of December 30, 2018 |
| Balance Sheet | As ReportedASC 606 |  | Adjustment |  | ASC 605 |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 3,426 |  |  | $ | (845 | ) |  | $ | 2,581 |  |
| Other current assets | 855 |  |  | 23 |  |  | 878 |  |
| Deferred tax assets | 3,923 |  |  | 56 |  |  | 3,979 |  |
| Other assets | 2,056 |  |  | 1 |  |  | 2,057 |  |
| Liabilities |  |  |  |  |  |
| Unearned revenues, current | $ | 484 |  |  | 4 |  |  | $ | 488 |  |
| Other current liabilities | 6,831 |  |  | (271 | ) |  | 6,560 |  |
| Unearned revenues | 1,420 |  |  | 309 |  |  | 1,729 |  |
| Stockholders’ equity |  |  |  |  |  |
| Retained earnings | $ | 3,415 |  |  | $ | (807 | ) |  | $ | 2,608 |  |

[0001728949-19-000012:notes:124]
|  | Three Months Ended December 30, 2018 |
| Statement of Operations | As Reported ASC 606 |  | Adjustment |  | ASC 605 |
| Revenues |  |  |  |  |  |
| Equipment and services | $ | 3,754 |  |  | $ | (15 | ) |  | $ | 3,739 |  |
| Licensing | 1,088 |  |  | 51 |  |  | 1,139 |  |
| Investment and other income, net | 5 |  |  | 2 |  |  | 7 |  |
| Income tax benefit | 509 |  |  | (5 | ) |  | 504 |  |
| Net income | 1,068 |  |  | 33 |  |  | 1,101 |  |

[0001728949-19-000012:notes:125]
Adoption of the new accounting guidance had no impact to net cash provided (used) by operating, financing or investing activities on our condensed consolidated statement of cash flows in the first quarter of fiscal 2019.

[0001728949-19-000012:notes:126]
Financial Assets: In January 2016, the FASB issued new accounting guidance on classifying and measuring financial instruments, which requires that all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings in the statement of operations. Additionally, it changes the disclosure requirements for financial instruments. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the modified retrospective transition method for investments in marketable securities, which have readily determinable fair values, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings. Upon adoption, we reclassified $50 million of unrealized gains, net of the associated tax effects, related to our investments in marketable securities from accumulated other comprehensive income to opening retained earnings. We have applied the prospective transition method for investments in non-marketable securities, which are investments in privately held companies that do not have readily determinable fair values and will recognize any unrealized gains that have accumulated in the period in which there is an observable transaction, if any.

[0001728949-19-000012:notes:127]
Hedge Instruments: In August 2017, the FASB issued new accounting guidance that expands and refines hedge accounting for both financial and non-financial risks, aligns the recognition and presentation of the effects of hedging instruments and hedged items in the financial statements, and includes targeted improvements related to the assessment of hedge effectiveness. The new accounting guidance also modifies disclosure requirements for hedging activities. We adopted the new accounting guidance in the first quarter of 2019 using the modified retrospective transition method and recorded a negligible adjustment to opening retained earnings. The new accounting guidance did not have a material impact on our condensed consolidated financial statements.

[0001728949-19-000012:notes:128]
Statement of Cash Flows: In August 2016, the FASB issued new accounting guidance related to the classification of certain cash receipts and cash payments in the statement of cash flows. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the retrospective transition method for each period presented, which did not have a material impact on our condensed consolidated statements of cash flows.

[0001728949-19-000012:notes:129]
In November 2016, the FASB issued new accounting guidance that requires companies to include changes in restricted cash and cash equivalents in the statement of cash flows. As a result, the statement of cash flows no longer reflects transfers between cash and cash equivalents and restricted cash and cash equivalents. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the retrospective transition method, which will result in certain amounts in fiscal 2018 being adjusted to conform to the new accounting guidance. During fiscal 2018, we had restricted cash and cash equivalents related to funds deposited as collateral for outstanding letters of credit in connection with a then proposed acquisition. Restricted cash and cash equivalents related to the outstanding letters of credit totaled $2.0 billion at the end of the fourth quarter of fiscal 2017 and first quarter of fiscal 2018. There was no impact of this change on the activity presented within the statement of cash flows for the three months ended December 24, 2017.

[0001728949-19-000012:notes:130]
Income Taxes. In October 2016, the FASB issued new accounting guidance that changes the accounting for the income tax effects of intra-entity transfers of assets other than inventory. Under the new accounting guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings of $2.6 billion, primarily as the result of establishing a deferred tax asset on the basis difference of certain intellectual property distributed from one of our foreign subsidiaries to a subsidiary in the United States in fiscal 2018 (Note 3). The ongoing impact of this accounting guidance will be dependent on the facts and circumstances of any transactions within its scope.

[0001728949-19-000012:notes:131]
Recent Accounting Pronouncements Not Yet Adopted.

[0001728949-19-000012:notes:132]
Leases: In February 2016, the FASB issued new accounting guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease accounting guidance. The new accounting guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. We will adopt the new accounting guidance in the first quarter of fiscal 2020 and expect to use the modified retrospective approach and to elect certain practical expedients, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption. We are in the process of determining the effects the adoption will have on our consolidated financial statements.

[0001728949-19-000012:notes:133]
Financial Assets. In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The new accounting guidance also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The new accounting guidance will be effective for us starting in the first quarter of fiscal 2021 and generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. Early adoption is permitted starting in the first quarter of fiscal 2020. We are in the process of determining the effects the adoption will have on our consolidated financial statements and whether to adopt the new accounting guidance early.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-19-000012:notes:134]
Basis of Presentation and Significant Accounting Policies Update

[0001728949-19-000012:notes:135]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for the fiscal year ended September 30, 2018. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month periods ended December 30, 2018 and December 24, 2017 included 13 weeks.

[0001728949-19-000012:notes:136]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in our condensed consolidated financial statements and the accompanying notes. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

[0001728949-19-000012:notes:137]
Revision of Prior Period Financial Statements. In connection with the preparation of our condensed consolidated financial statements for the three months ended December 30, 2018, we identified an immaterial error related to the recognition of certain royalty revenues of our QTL (Qualcomm Technology Licensing) segment in the quarterly and annual periods in fiscal 2018 and third and fourth quarters and annual period in fiscal 2017. In accordance with SAB No. 99, “Materiality,” and SAB No. 108, “Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements,” we evaluated the error and determined that the related impact was not material to our financial statements for any prior annual or interim period, but that correcting the cumulative impact of the error would be significant to our results of operations for the three months ended December 30, 2018. Accordingly, we have revised our consolidated balance sheets at September 30, 2018 and September 24, 2017 and condensed (if applicable) consolidated statements of operations, comprehensive income (loss) and cash flows for the years ended September 30, 2018 and September 24, 2017, and the three months periods ended September 30, 2018, June 24, 2018, March 25, 2018, December 24, 2017, September 24, 2017 and June 25, 2017, including the related notes presented herein, as applicable. A summary of revisions to our previously reported financial statements is presented in Note 11. We will also correct previously reported financial information for such immaterial error in our future filings, as applicable.

[0001728949-19-000012:notes:138]
Earnings (Loss) Per Common Share. Basic earnings (loss) per common share is computed by dividing net income (loss) by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans and shares subject to accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Due to the net loss for the three months ended December 24, 2017, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share. The following table provides information about the diluted earnings (loss) per share calculation (in millions):

[0001728949-19-000012:notes:139]
|  | Three Months Ended |
|  | December 30, 2018 |  | December 24, 2017 |
| Dilutive common share equivalents included in diluted shares | 10.3 |  |  | — |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 11.7 |  |  | 46.0 |  |

[0001728949-19-000012:notes:140]
Share-Based Compensation. Total share-based compensation expense, related to all of our share-based awards, was comprised as follows (in millions):

[0001728949-19-000012:notes:141]
|  | Three Months Ended |
|  | December 30, 2018 |  | December 24, 2017 |
| Cost of revenues | $ | 8 |  |  | $ | 10 |  |
| Research and development | 157 |  |  | 156 |  |
| Selling, general and administrative | 65 |  |  | 82 |  |
| Share-based compensation expense before income taxes | 230 |  |  | 248 |  |
| Related income tax benefit | (48 | ) |  | (49 | ) |
|  | $ | 182 |  |  | $ | 199 |  |

[0001728949-19-000012:notes:142]
At December 30, 2018, total unrecognized compensation expense related to nonvested restricted stock units granted prior to that date was $1.5 billion, which is expected to be recognized over a weighted-average period of 2.3 years. At December 30, 2018, we had outstanding 29.4 million restricted stock units that contain only a service requirement and 3.9 million stock options.

[0001728949-19-000012:notes:143]
Recently Adopted Accounting Pronouncements.

[0001728949-19-000012:notes:144]
Revenue Recognition: In May 2014, the Financial Accounting Standards Board (FASB) issued new accounting guidance related to revenue recognition (ASC 606), which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition accounting guidance. The new accounting guidance defines a five-step approach that requires a company to recognize revenue as control of goods or services transfers to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. We adopted ASC 606 in the first quarter of fiscal 2019 using the modified retrospective transition method only to those contracts that were not completed as of October 1, 2018. We recognized the cumulative effect of initially applying the new revenue accounting guidance as an adjustment to opening retained earnings. Prior period results have not been restated and continue to be reported in accordance with the accounting guidance in effect for those periods (ASC 605). We have implemented new accounting policies, systems, processes and internal controls necessary to support the requirements of ASC 606.

[0001728949-19-000012:notes:145]
Accounting Policy Update.

[0001728949-19-000012:notes:146]
Revenue Recognition. As a result of the adoption of ASC 606, we revised our revenue recognition policy beginning in fiscal 2019 as follows.

[0001728949-19-000012:notes:147]
We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We also generate revenues by performing software hosting, software development and other services and from other product sales. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of our performance obligations.

[0001728949-19-000012:notes:148]
Revenues from sales of our products are recognized upon transfer of control to the customer, which is generally at the time of shipment. Revenues from providing services are typically recognized over time as the performance obligation is satisfied. Revenues from providing services were less than 5% of total revenues for all periods presented.

[0001728949-19-000012:notes:149]
We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops, which in general, effectively provide for a maximum royalty amount per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, subject to certain constraints on our ability to estimate such royalties. Our estimates of sales-based royalties are based largely on an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property. We estimate sales-based royalties taking into consideration the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products, and considers all information (historical, current and forecasted) that is reasonably available to us. Our licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter, which is generally the following quarter. As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues will be required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

[0001728949-19-000012:notes:150]
License agreements that require payment of license fees contain a single performance obligation that represent ongoing access to a portfolio of intellectual property over the license term since such agreements provide the licensee the right to access a portfolio of intellectual property that exists at inception of the license agreement and to updates and new intellectual property that is added to the licensed portfolio during the term of the agreement that are highly interdependent or interrelated. Since we expect to expend efforts to develop and transfer updates to our licensed portfolio on an even basis, license fees are recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee.

[0001728949-19-000012:notes:151]
We account for a contract when it is legally enforceable, the parties are committed to perform their respective obligations, the rights of the parties regarding the goods and/or services to be transferred are identified, payment terms are identified, the contract has commercial substance and collectability of substantially all of the consideration is probable.

[0001728949-19-000012:notes:152]
From time to time, companies initiate various strategies to attempt to renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. Certain licensees have disputed, underreported, underpaid, not reported and/or not paid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and such licensees may continue to do so in the future. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in ASC 606, and to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us.

[0001728949-19-000012:notes:153]
We measure revenues based on the amount of consideration we expect to receive in exchange for products or services. We record reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of our products and technologies, in the period that the related revenues are earned. The charges for such arrangements are recorded as a reduction to accounts receivable, net or as other current liabilities based on whether we have the contractual right of offset. Certain of these charges are considered variable consideration and are included in the transaction price based on estimating the most likely amount expected to be provided to the customer/licensee.

[0001728949-19-000012:notes:154]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including certain unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied performance obligations.

[0001728949-19-000012:notes:155]
We disaggregate our revenues by segment (Note 7) and type of product and services (as presented in our statement of operations), as we believe this best depicts how the nature, amount, timing and uncertainty of our revenues and cash flows are affected by economic factors. Substantially all of QCT’s revenues consist of equipment revenues, which are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time.

[0001728949-19-000012:notes:156]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were $72 million in the first quarter of fiscal 2019 and primarily relate to QTL royalty revenues recognized related to devices sold in prior periods and certain customer incentives.

[0001728949-19-000012:notes:157]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In the first quarter of fiscal 2019, we recognized revenues of $133 million that were included within the unearned revenues balance at October 1, 2018.

[0001728949-19-000012:notes:158]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront. At December 30, 2018, we had $2.0 billion of remaining performance obligations, of which $411 million, $450 million, $415 million, $409 million and $193 million was expected to be recognized as revenues for the remainder of fiscal 2019 and each of the subsequent four years from fiscal 2020 through 2023, respectively, and $77 million thereafter.

[0001728949-19-000012:notes:159]
Marketable Securities and Non-Marketable Securities. Prior to the adoption of the new accounting guidance in the first quarter of fiscal 2019, investments in marketable equity securities were generally classified as available-for-sale equity investments, with net unrealized gains or losses recorded as a component of accumulated other comprehensive income, net of income taxes. Beginning in fiscal 2019, all gains and losses on investments in marketable equity securities, realized and unrealized, are recognized in investment and other income, net.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001728949-19-000012:notes:160]
[same as prior period, unchanged from 0001728949-18-000075:notes:132]

[0001728949-19-000012:notes:161]
|  | Three Months Ended |
|  | December 30, 2018 |  | December 24, 2017 |
| Revenues |  |  |  |
| Nonreportable segments | $ | 58 |  |  | $ | 88 |  |
|  | $ | 58 |  |  | $ | 88 |  |
| EBT |  |  |  |
| Unallocated cost of revenues | $ | (114 | ) |  | $ | (117 | ) |
| Unallocated research and development expenses | (147 | ) |  | (280 | ) |
| Unallocated selling, general and administrative expenses | (64 | ) |  | (161 | ) |
| Unallocated other expenses (Note 2) | (149 | ) |  | (1,183 | ) |
| Unallocated interest expense | (153 | ) |  | (170 | ) |
| Unallocated investment and other income, net | 20 |  |  | 124 |  |
| Nonreportable segments | (30 | ) |  | (93 | ) |
|  | $ | (637 | ) |  | $ | (1,880 | ) |

[0001728949-19-000012:notes:162]
[same as prior period, unchanged from 0001728949-18-000075:notes:130]

[0001728949-19-000012:notes:163]
|  | Three Months Ended |
|  | December 30, 2018 |  | December 24, 2017 |
| Cost of revenues | $ | 103 |  |  | $ | 106 |  |
| Research and development expenses | 1 |  |  | 2 |  |
| Selling, general and administrative expenses | 7 |  |  | 76 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001728949-19-000012:notes:164]
Cost Plan

[0001728949-19-000012:notes:165]
In the second quarter of fiscal 2018, we announced a Cost Plan designed to align our cost structure to our long-term margin targets. As part of this plan, we have initiated a series of targeted actions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. We expect these cost reductions to be fully captured in fiscal 2019, excluding litigation costs that are in excess of the baseline spend.

[0001728949-19-000012:notes:166]
During the three months ended December 30, 2018, we recorded restructuring and restructuring-related charges of $180 million in other expenses, which consisted of restructuring charges of $29 million, primarily related to severance and consulting costs, and restructuring-related charges of $151 million, primarily related to asset impairment charges resulting from the planned sale of a nonreportable segment. In connection with this plan, we expect to incur additional restructuring and restructuring-related charges of up to $50 million, which primarily consist of severance and consulting costs, the vast majority of which are expected to be settled in cash. Since inception of the Cost Plan, we have incurred a total of $867 million in net restructuring and restructuring-related charges.

[0001728949-19-000012:notes:167]
The restructuring accrual, a portion of which was included in payroll and other benefits related liabilities with the remainder included in other current liabilities, is expected to be substantially paid within the next 12 months. Changes in the restructuring accrual for the first quarter of fiscal 2019 were as follows (in millions):

[0001728949-19-000012:notes:168]
|  | Severance Costs |  | OtherCosts |  | Total |
| Beginning balance of restructuring accrual | $ | 61 |  |  | $ | 22 |  |  | $ | 83 |  |
| Costs | 21 |  |  | 11 |  |  | 32 |  |
| Cash payments | (25 | ) |  | (14 | ) |  | (39 | ) |
| Adjustments | (1 | ) |  | (2 | ) |  | (3 | ) |
| Ending balance of restructuring accrual | $ | 56 |  |  | $ | 17 |  |  | $ | 73 |  |

[0001728949-19-000012:notes:169]
In the first quarter of fiscal 2019, we entered into a definitive agreement under which we agreed to sell a nonreportable segment. As a result, assets (recorded as other current assets and other noncurrent assets) and liabilities (recorded as other current liabilities and other noncurrent liabilities) of $129 million and $40 million, respectively, were classified as held for sale at December 30, 2018.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001728949-19-000012:notes:170]
Changes in the components of accumulated other comprehensive income, net of income taxes, in stockholders’ equity in the three months ended December 30, 2018 were as follows (in millions):

[0001728949-19-000012:notes:171]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized (Loss) Gain on Derivative Instruments |  | Other Gains |  | Total Accumulated Other Comprehensive Income |
| Balance at September 30, 2018 | $ | 11 |  |  | $ | 23 |  |  | $ | 243 |  |  | $ | (13 | ) |  | $ | 1 |  |  | $ | 265 |  |
| Other comprehensive (loss) income before reclassifications | (24 | ) |  | — |  |  | (5 | ) |  | 16 |  |  | — |  |  | (13 | ) |
| Reclassifications from accumulated other comprehensive income | 3 |  |  | — |  |  | (51 | ) |  | (2 | ) |  | — |  |  | (50 | ) |
| Other comprehensive (loss) income | (21 | ) |  | — |  |  | (56 | ) |  | 14 |  |  | — |  |  | (63 | ) |
| Balance at December 30, 2018 | $ | (10 | ) |  | $ | 23 |  |  | $ | 187 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 202 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001728949-19-000012:notes:172]
[same as prior period, unchanged from 0001728949-18-000075:notes:141]

[0001728949-19-000012:notes:173]
|  | Three Months Ended |
|  | December 30, 2018 |  | December 24, 2017 |
| Revenues |  |  |  |
| QCT | $ | 3,739 |  |  | $ | 4,651 |  |
| QTL | 1,018 |  |  | 1,266 |  |
| QSI | 27 |  |  | 30 |  |
| Reconciling items | 58 |  |  | 88 |  |
| Total | $ | 4,842 |  |  | $ | 6,035 |  |
| EBT |  |  |  |
| QCT | $ | 598 |  |  | $ | 955 |  |
| QTL | 590 |  |  | 854 |  |
| QSI | 8 |  |  | 11 |  |
| Reconciling items | (637 | ) |  | (1,880 | ) |
| Total | $ | 559 |  |  | $ | (60 | ) |

[0001728949-19-000012:notes:174]
|  | December 30, 2018 |  | September 30, 2018 |
| Assets |  |  |  |
| QCT | $ | 2,684 |  |  | $ | 3,041 |  |
| QTL | 2,405 |  |  | 1,472 |  |
| QSI | 1,296 |  |  | 1,279 |  |
| Reconciling items | 27,861 |  |  | 26,926 |  |
| Total | $ | 34,246 |  |  | $ | 32,718 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001728949-19-000012:notes:175]
Changes in stockholders’ equity in the three months ended December 30, 2018 were as follows (in millions):

[0001728949-19-000012:notes:176]
|  | Total Stockholders’ Equity |
| Balance at September 30, 2018 | $ | 807 |  |
| Cumulative effect of accounting changes (Note 1) | 3,403 |  |
| Net income | 1,068 |  |
| Other comprehensive loss | (12 | ) |
| Common stock issued under employee benefit plans and related tax benefits | 27 |  |
| Share-based compensation | 249 |  |
| Tax withholdings related to vesting of share-based payments | (139 | ) |
| Dividends | (767 | ) |
| Stock repurchases | (1,019 | ) |
| Balance at December 30, 2018 | $ | 3,617 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-19-000012:notes:177]
[same as prior period, unchanged from 0001728949-18-000075:notes:146]

[0001728949-19-000012:notes:178]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices, wireless networks, devices used in the Internet of Things (IoT), broadband gateway equipment, consumer electronic devices and automotive telematics and infotainment systems. QTL grants licenses to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an equity method investee. We also have nonreportable segments, including our cyber security solutions, mobile health and other wireless technology and service initiatives.

[0001728949-19-000012:notes:179]
We evaluate the performance of our segments based on earnings (loss) before income taxes (EBT). In fiscal 2018, all of the costs related to pre-commercial research and development of 5G technologies, of which $100 million was recorded in the first quarter of fiscal 2018, were included in unallocated corporate research and development expenses. Beginning in the first quarter of fiscal 2019, all research and development costs associated with 5G technologies are included in segment results. Additionally, beginning in the first quarter of fiscal 2019, certain research and development costs associated with early research and development that have historically been included in our QCT segment are allocated to our QTL segment. The net effect of these changes negatively impacted QTL’s EBT by $122 million and did not have a significant impact on QCT EBT in the first quarter of fiscal 2019.

[0001728949-19-000012:notes:180]
During the first quarter of fiscal 2019, we combined our Small Cells business, which sells products designed for the implementation of small cells to address the challenge of meeting the increased demand for mobile data, into our QCT segment. Revenues and operating results related to the Small Cells business were included in nonreportable segments through the end of fiscal 2018. Prior period segment information has not been adjusted to conform to the new segment presentation as such adjustments are insignificant.

[0001728949-19-000012:notes:181]
Unallocated other expenses in the three months ended December 30, 2018 were comprised of the charges related to our Cost Plan, partially offset by a benefit related to a favorable legal settlement (Note 2). Unallocated other expenses in the three months ended December 24, 2017 were comprised of the EC fine (Note 6).


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-19-000012:notes:182]
[same as prior period, unchanged from 0001728949-18-000075:notes:150]

[0001728949-19-000012:notes:183]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in stockholders’ equity in the three months ended December 30, 2018 were as follows (in millions):

[0001728949-19-000012:notes:184]
Reclassifications from accumulated other comprehensive income included adjustments of $51 million to the opening retained earnings balance as a result of the adoption of new accounting guidance in the first quarter of fiscal 2019 related to financial instruments and hedge instruments (Note 1). Reclassifications from accumulated other comprehensive income (excluding adjustments to opening retained earnings) related to available-for-sale securities were negligible in the three months ended December 30, 2018 and December 24, 2017 and were recorded in investment and other income, net (Note 2).

[0001728949-19-000012:notes:185]
Stock Repurchase Program. On July 26, 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. The stock repurchase program has no expiration date.

[0001728949-19-000012:notes:186]
In September 2018, we entered into three accelerated share repurchase agreements (ASR Agreements) with three financial institutions under which we paid an aggregate of $16.0 billion upfront and received an initial delivery of 178.4 million shares of our common stock, which were retired. The final number of shares to be repurchased will be based on the volume-weighted average stock price of our common stock during the terms of the transactions, less a discount and subject to adjustments pursuant to the terms and conditions of the ASR Agreements, and will also be retired upon delivery to us. The ASR Agreements are scheduled to terminate in early September 2019 but may terminate earlier in certain circumstances. At settlement, one or more of the financial institutions may be required to deliver additional shares of common stock to us, or under certain circumstances, we may be required to deliver shares of common stock or make a cash payment to one or more of the financial institutions, with the method of settlement at our election.

[0001728949-19-000012:notes:187]
In the three months ended December 30, 2018 and December 24, 2017, we repurchased and retired 16.8 million and 3.7 million shares for $1.0 billion and $225 million, respectively, before commissions. To reflect share repurchases in the consolidated balance sheet, we (i) reduce common stock for the par value of the shares, (ii) reduce paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) record the residual amount to retained earnings. At December 30, 2018, $7.8 billion remained authorized for repurchase under our stock repurchase program.

[0001728949-19-000012:notes:188]
Dividends. Cash dividends announced in the three months ended December 30, 2018 and December 24, 2017 were $0.62 and $0.57 per share, respectively. Dividends charged to retained earnings in the three months ended December 30, 2018 and December 24, 2017 were $767 million and $862 million, respectively. On January 14, 2019, we announced a cash dividend of $0.62 per share on our common stock, payable on March 28, 2019 to stockholders of record as of the close of business on March 7, 2019.
