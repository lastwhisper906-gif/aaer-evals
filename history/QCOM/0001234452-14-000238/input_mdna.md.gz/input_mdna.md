# QCOM MD&A — 0001234452-14-000238


## mdna

[0001234452-14-000238:mdna:1]
[same as prior period, unchanged from 0001234452-14-000154:mdna:1]

[0001234452-14-000238:mdna:2]
[same as prior period, unchanged from 0001234452-14-000154:mdna:2]

[0001234452-14-000238:mdna:3]
[same as prior period, unchanged from 0001234452-14-000154:mdna:3]

[0001234452-14-000238:mdna:4]
[same as prior period, unchanged from 0001234452-14-000154:mdna:4]

[0001234452-14-000238:mdna:5]
[same as prior period, unchanged from 0001234452-14-000154:mdna:5]

[0001234452-14-000238:mdna:6]
Revenues for the third quarter of fiscal 2014 were $6.8 billion, with net income attributable to Qualcomm of $2.2 billion, which primarily resulted from the following key items:

[0001234452-14-000238:mdna:7]
| • | We shipped approximately 225 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, an increase of approximately 31%, compared to approximately 172 million MSM integrated circuits in the year ago quarter. |

[0001234452-14-000238:mdna:8]
| • | Total reported device sales were approximately $58.1 billion, an increase of approximately 3%, compared to approximately $56.5 billion in the year ago quarter.(1) |

[0001234452-14-000238:mdna:9]
Against this backdrop, the following recent developments occurred during the third quarter of fiscal 2014 with respect to key elements of our business or our industry:

[0001234452-14-000238:mdna:10]
[same as prior period, unchanged from 0001234452-14-000154:mdna:10]

[0001234452-14-000238:mdna:11]
| • | Worldwide 3G/4G connections (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) grew sequentially by approximately 5% to approximately 2.7 billion, which was approximately 39% of total cellular connections.(2) |

[0001234452-14-000238:mdna:12]
| (1) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). Not all licensees report sales the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-14-000238:mdna:13]
| (2) | According to GSMA Intelligence estimates as of July 21, 2014, for the quarter ended June 30, 2014 (estimates excluded Wireless Local Loop). |

[0001234452-14-000238:mdna:14]
[same as prior period, unchanged from 0001234452-14-000154:mdna:22]

[0001234452-14-000238:mdna:15]
[same as prior period, unchanged from 0001234452-14-000154:mdna:15]

[0001234452-14-000238:mdna:16]
[same as prior period, unchanged from 0001234452-14-000154:mdna:16]

[0001234452-14-000238:mdna:17]
[same as prior period, unchanged from 0001234452-14-000154:mdna:17]

[0001234452-14-000238:mdna:18]
QCT (Qualcomm CDMA Technologies) is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products and system software are sold to or licensed to manufacturers that use our products in wireless devices, particularly mobile phones, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards and infrastructure equipment, and in wired devices, particularly broadband gateway equipment, desktop computers and streaming media players. The MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Qualcomm Snapdragon processor devices, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon processors provide advanced application and graphics processing capabilities. QCT’s system software enables the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits. QCT revenues comprised 73% and 68% of total consolidated revenues in the third quarter of fiscal 2014 and 2013, respectively, and 70% and 67% of total consolidated revenues for the first nine months of fiscal 2014 and 2013, respectively.

[0001234452-14-000238:mdna:19]
[same as prior period, unchanged from 0001234452-14-000154:mdna:19]

[0001234452-14-000238:mdna:20]
QTL (Qualcomm Technology Licensing) grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD (including TD-SCDMA), GSM/GPRS/EDGE and/or OFDMA standards and their derivatives. QTL licensing revenues are comprised of license fees as well as royalties based on sales by licensees of products incorporating or using our intellectual property. License fees are fixed amounts paid in one or more installments. Royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (e.g., certain shipping costs, packing costs, VAT, etc.). QTL recognizes royalty revenues based on royalties reported by licensees during the quarter and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. QTL revenues comprised 26% and 30% of total consolidated revenues in the third quarter of fiscal 2014 and 2013, respectively, and 29% and 31% of total consolidated revenues for the first nine months of fiscal 2014 and 2013, respectively. The vast majority of such revenues were generated through our licensees’ sales of CDMA2000- and WCDMA-based products, including multimode products that also implement OFDMA, such as feature phones and smartphones.

[0001234452-14-000238:mdna:21]
QSI (Qualcomm Strategic Initiatives) makes strategic investments that we believe may open new or expand opportunities for our technologies, support the design and introduction of new products and services for voice and data

[0001234452-14-000238:mdna:22]
communications or possess unique capabilities or technology. Many of these strategic investments are in early-stage companies. QSI also holds wireless spectrum. As part of our strategic investment activities, we intend to pursue various exit strategies from each of our QSI investments at some point in the future.

[0001234452-14-000238:mdna:23]
[same as prior period, unchanged from 0001234452-14-000154:mdna:24]

[0001234452-14-000238:mdna:24]
Nonreportable segments include our QIS (Qualcomm Internet Services), QGOV (Qualcomm Government Technologies) and QMT (Qualcomm MEMS Technologies) divisions and other display, wireless technology and service initiatives. Nonreportable segments develop and offer products and services that include, but are not limited to: software products and content enablement services to wireless operators; development, other services and related products to U.S. government agencies and their contractors; low power consumption, high optical performance flat display modules; products designed for implementation of small cells; medical device connectivity and related data management; augmented reality; and device-to-device communication.

[0001234452-14-000238:mdna:25]
During the first quarter of fiscal 2014, as a result of discussions with potential buyers and consideration of alternative uses for the separate asset groups that comprise one of the QMT division’s manufacturing facilities in Taiwan, we decreased our estimates of expected cash flows from those assets and recorded an impairment charge of $444 million in other expenses. We concluded that a triggering event had not occurred in the first quarter of fiscal 2014 that would have required impairment testing for the remaining QMT assets, including goodwill, as QMT’s licensing business plan did not utilize this manufacturing facility. During the third quarter of fiscal 2014, we updated QMT’s licensing business plan and related internal forecasts to reflect a decrease in expected cash flows. The updated business plan reflects an acceleration of our plans to transition from QMT’s current generation technology to the licensing of QMT’s next generation IMOD display technology and to focus on wearable devices. QMT will continue to make and sell current generation products for a period of time in support of certain existing customer requirements. As a result, we tested the QMT division’s long-lived assets and goodwill and recorded total impairment charges of $164 million in other expenses in the third quarter of fiscal 2014.

[0001234452-14-000238:mdna:26]
[same as prior period, unchanged from 0001234452-14-000154:mdna:26]

[0001234452-14-000238:mdna:27]
Discontinued Operations. On November 25, 2013, we completed our sale of the North and Latin America operations of our Omnitracs division to a U.S.-based private equity firm for cash consideration of $788 million (net of cash sold). As a result, we recorded a gain in discontinued operations of $665 million ($430 million net of income tax expense) during the nine months ended June 29, 2014. The revenues and operating results of the North and Latin America operations of our Omnitracs division, which comprised substantially all of our Omnitracs division, were not presented as discontinued operations in any fiscal period because they were immaterial.

[0001234452-14-000238:mdna:28]
[same as prior period, unchanged from 0001234452-14-000154:mdna:28]

[0001234452-14-000238:mdna:29]
The deployment of 3G networks has enabled increased voice capacity and higher data rates than prior generation networks, thereby supporting more minutes of use and a wide range of mobile broadband data applications for handsets, 3G connected computing devices and other consumer electronics. According to the Global mobile Suppliers Association (GSA), as of July 2014, to complement their existing 3G networks, 300 wireless operators have deployed and more than 200 additional wireless operators are planning to deploy OFDMA-based technology, often called 4G, in new wireless spectrum to gain additional capacity for data services. As a result, we expect continued growth in the coming years in consumer demand for 3G, 3G/4G multimode and 4G products and services around the world.

[0001234452-14-000238:mdna:30]
[same as prior period, unchanged from 0001234452-14-000154:mdna:30]

[0001234452-14-000238:mdna:31]
[same as prior period, unchanged from 0001234452-14-000154:mdna:31]

[0001234452-14-000238:mdna:32]
[same as prior period, unchanged from 0001234452-14-000154:mdna:32]

[0001234452-14-000238:mdna:33]
25

[0001234452-14-000238:mdna:34]
| • | China continues to present significant opportunities for us, particularly with the rollout of 4G LTE. We expect the launch of 4G services in China will encourage competition and growth, bring the benefits of 4G LTE to consumers, encourage consumers to replace 2G (GSM) devices and enable new opportunities (e.g., machine-to-machine) for the industry. |

[0001234452-14-000238:mdna:35]
| • | China also presents significant challenges, as our business practices continue to be the subject of an investigation by the China National Development and Reform Commission (NDRC). We also believe that certain licensees in China currently are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes certain licensees underreporting a portion of their 3G/4G device sales and a dispute with a licensee) and that unlicensed companies may seek to delay execution of new licenses while the NDRC investigation is ongoing. Litigation and/or other actions may be necessary to compel these licensees to report such sales and pay the required royalties for such sales and unlicensed companies to execute new licenses. Further, our success in China is in part dependent upon the rate of commercialization of 4G LTE products in China. |

[0001234452-14-000238:mdna:36]
[same as prior period, unchanged from 0001234452-14-000154:mdna:34]

[0001234452-14-000238:mdna:37]
| • | We continue to invest significant resources toward advancements in 3G, 3G/4G and 4G LTE (an OFDMA-based standard) technologies, audio and video codecs, wireless baseband chips, our converged computing/communications (Snapdragon) chips, graphics, connectivity, multimedia products, software and services. We are also investing across a broad spectrum of opportunities that leverage our existing technical and business expertise to deploy new business models and enter into new industry segments, such as new display technologies; products designed for implementation of small cells and the 1000x data challenge; wireless charging; very high speed connectivity; automotive; mobile health; wearable technology; and products for the connected home, the digital 6th sense and the Internet of Everything. |

[0001234452-14-000238:mdna:38]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants and governments in the wireless value chain as to the benefits of our business model and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not welcome the success of our business model in enabling new, highly cost-effective competitors to their products. We expect that such companies and/or governments or regulators will continue to challenge our business model in various forums throughout the world.

[0001234452-14-000238:mdna:39]
[same as prior period, unchanged from 0001234452-14-000154:mdna:38]

[0001234452-14-000238:mdna:40]
[same as prior period, unchanged from 0001234452-14-000154:mdna:39]

[0001234452-14-000238:mdna:41]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | Change |  | June 29, 2014 |  | June 30, 2013 |  | Change |
| Equipment and services | $ | 4,922 |  |  | $ | 4,286 |  |  | $ | 636 |  |  | $ | 13,803 |  |  | $ | 12,474 |  |  | $ | 1,329 |  |
| Licensing | 1,884 |  |  | 1,957 |  |  | (73 | ) |  | 5,992 |  |  | 5,911 |  |  | 81 |  |
|  | $ | 6,806 |  |  | $ | 6,243 |  |  | $ | 563 |  |  | $ | 19,795 |  |  | $ | 18,385 |  |  | $ | 1,410 |  |

[0001234452-14-000238:mdna:42]
The increases in equipment and services revenues in the third quarter and the first nine months of fiscal 2014 were primarily due to increases in QCT revenues of $732 million and $1.55 billion, respectively, partially offset by decreases of $89 million and $218 million as a result of the sale of our Omnitracs division during fiscal 2014. The decrease in licensing revenues in the third quarter of fiscal 2014 was primarily due to a decrease in QTL revenues of $64 million. The increase in licensing revenues in the first nine months of fiscal 2014 was primarily due to an increase in QTL revenues of $94 million.

[0001234452-14-000238:mdna:43]
[same as prior period, unchanged from 0001234452-14-000154:mdna:52]

[0001234452-14-000238:mdna:44]
| Costs and Expenses (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | Change |  | June 29, 2014 |  | June 30, 2013 |  | Change |
| Cost of equipment and services (E&S) revenues | $ | 2,740 |  |  | $ | 2,497 |  |  | $ | 243 |  |  | $ | 7,929 |  |  | $ | 7,106 |  |  | $ | 823 |  |
| Cost as % of E&S revenues | 56 | % |  | 58 | % |  |  |  | 57 | % |  | 57 | % |  |  |

[0001234452-14-000238:mdna:45]
The increase in margin percentage in the third quarter of fiscal 2014 was primarily attributable to an increase in QCT margin percentage. Margin percentage remained flat in the first nine months of fiscal 2014. Our margin percentage may fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors.

[0001234452-14-000238:mdna:46]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | Change |  | June 29, 2014 |  | June 30, 2013 |  | Change |
| Research and development | $ | 1,429 |  |  | $ | 1,298 |  |  | $ | 131 |  |  | $ | 4,113 |  |  | $ | 3,618 |  |  | $ | 495 |  |
| % of revenues | 21 | % |  | 21 | % |  |  |  | 21 | % |  | 20 | % |  |  |
| Selling, general, and administrative | $ | 582 |  |  | $ | 613 |  |  | $ | (31 | ) |  | $ | 1,745 |  |  | $ | 1,861 |  |  | $ | (116 | ) |
| % of revenues | 9 | % |  | 10 | % |  |  |  | 9 | % |  | 10 | % |  |  |
| Other | $ | (20 | ) |  | $ | 158 |  |  | $ | (178 | ) |  | $ | 450 |  |  | $ | 158 |  |  | $ | 292 |  |

[0001234452-14-000238:mdna:47]
The dollar increases in research and development expenses in the third quarter and the first nine months of fiscal 2014 were primarily attributable to increases of $106 million and $389 million, respectively, in costs related to the development of CDMA-based 3G, OFDMA-based 4G LTE and other technologies for integrated circuit and related software products and to expand our intellectual property portfolio and increases of $8 million and $31 million, respectively, in share-based compensation.

[0001234452-14-000238:mdna:48]
The dollar decrease in selling, general and administrative expenses in the third quarter of fiscal 2014 was primarily attributable to a decrease of $25 million in selling and marketing expenses. The dollar decrease in selling, general and administrative expenses in the first nine months of fiscal 2014 was primarily attributable to decreases of $47 million in costs related to litigation and other legal matters, $38 million in share-based compensation expenses and $22 million in selling and marketing expenses.

[0001234452-14-000238:mdna:49]
Other income in the third quarter of fiscal 2014 was comprised of $184 million resulting from the reversal of accruals due to the district court ruling that overturned the ParkerVision verdict during the third quarter of fiscal 2014, partially offset by goodwill and long-lived asset impairment charges of $164 million related to our QMT division. Other expenses in the first nine months of fiscal 2014 were comprised of $607 million in long-lived asset and goodwill impairment charges related to our QMT division and a $16 million goodwill impairment charge related to our former QRS (Qualcomm Retail Solutions) division, partially offset by the reversal of the $173 million accrual recorded in fiscal 2013 related to the ParkerVision verdict.

[0001234452-14-000238:mdna:50]
Other expenses for the third quarter and the first nine months of fiscal 2013 included a $158 million impairment charge related to one of our QMT division’s manufacturing facilities in Taiwan.

[0001234452-14-000238:mdna:51]
| Net Investment Income (in millions) |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | Change |  | June 29, 2014 |  | June 30, 2013 |  | Change |
| Interest and dividend income | $ | 139 |  |  | $ | 182 |  |  | $ | (43 | ) |  | $ | 460 |  |  | $ | 529 |  |  | $ | (69 | ) |
| Interest expense | — |  |  | (7 | ) |  | 7 |  |  | (4 | ) |  | (22 | ) |  | 18 |  |
| Net realized gains on marketable securities | 290 |  |  | 21 |  |  | 269 |  |  | 660 |  |  | 189 |  |  | 471 |  |
| Net realized gains on other investments | 8 |  |  | 39 |  |  | (31 | ) |  | 25 |  |  | 50 |  |  | (25 | ) |
| Net impairment losses on marketable securities and other investments | (11 | ) |  | (27 | ) |  | 16 |  |  | (170 | ) |  | (49 | ) |  | (121 | ) |
| Net (losses) gains on derivative instruments | (6 | ) |  | 5 |  |  | (11 | ) |  | (1 | ) |  | 17 |  |  | (18 | ) |
| Equity in net losses of investees | (2 | ) |  | (1 | ) |  | (1 | ) |  | (7 | ) |  | (5 | ) |  | (2 | ) |
| Net gains on deconsolidation of subsidiaries | 4 |  |  | 21 |  |  | (17 | ) |  | 5 |  |  | 21 |  |  | (16 | ) |
|  | $ | 422 |  |  | $ | 233 |  |  | $ | 189 |  |  | $ | 968 |  |  | $ | 730 |  |  | $ | 238 |  |

[0001234452-14-000238:mdna:52]
The decreases in interest and dividend income in the third quarter and the first nine months of fiscal 2014 were primarily due to lower interest rates earned on cash and marketable securities, compared to the same periods in fiscal 2013. The increases in net realized gains on marketable securities in the third quarter and the first nine months of fiscal 2014 were primarily due to the increased impact of portfolio rebalancing in the third quarter of fiscal 2014, compared to the third quarter of fiscal 2013. The increases in net impairment losses on marketable securities and other investments in the first nine months of fiscal 2014 were primarily due to an increase in our recognition of unrealized losses on marketable debt securities that we intended to sell or that we more likely than not would sell before recovery.

[0001234452-14-000238:mdna:53]
| Income Tax Expense (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | Change |  | June 29, 2014 |  | June 30, 2013 |  | Change |
| Income tax expense | $ | 260 |  |  | $ | 332 |  |  | $ | (72 | ) |  | $ | 886 |  |  | $ | 1,028 |  |  | $ | (142 | ) |
| Effective tax rate | 10 | % |  | 17 | % |  | (7 | %) |  | 14 | % |  | 16 | % |  | (2 | %) |

[0001234452-14-000238:mdna:54]
The following table summarizes the primary factors that caused our effective tax rates for the third quarter and the first nine months of fiscal 2014 and 2013 to be less than the United States federal statutory rate:

[0001234452-14-000238:mdna:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | June 29, 2014 |  | June 30, 2013 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |  | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (23 | %) |  | (17 | %) |  | (21 | %) |  | (17 | %) |
| Benefits related to the research and development tax credit | (1 | %) |  | (2 | %) |  | (1 | %) |  | (3 | %) |
| Other | (1 | %) |  | 1 | % |  | 1 | % |  | 1 | % |
| Effective tax rate | 10 | % |  | 17 | % |  | 14 | % |  | 16 | % |

[0001234452-14-000238:mdna:56]
The effective tax rate of 10% for the third quarter of fiscal 2014 was lower than the estimated annual effective tax rate of 14% primarily as a result of an agreement reached with the Internal Revenue Service on components of our fiscal 2013 tax return, which resulted in the recognition of a tax benefit of $66 million during the third quarter of fiscal 2014, and changes in estimates related to foreign income taxed at rates lower than rates in the United States. The effective tax rates for the third quarter and the first nine months of fiscal 2014 were lower than the effective tax rates for the same periods in fiscal 2013 primarily as a result of increases in foreign income taxed at rates lower than rates in the United States, partially offset by decreases in the United States federal research and development tax credit. The estimated

[0001234452-14-000238:mdna:57]
28

[0001234452-14-000238:mdna:58]
annual effective tax rate for fiscal 2014 reflects the United States federal research and development tax credit generated through December 31, 2013, the date on which the credit expired.

[0001234452-14-000238:mdna:59]
[same as prior period, unchanged from 0001234452-14-000154:mdna:57]

[0001234452-14-000238:mdna:60]
The following should be read in conjunction with the third quarter and first nine months financial results of fiscal 2014 for each reportable segment. See “Notes to Condensed Consolidated Financial Statements, Note 7 - Segment Information.”

[0001234452-14-000238:mdna:61]
| (in millions) | QCT |  | QTL |  | QSI |
| Three Months Ended June 29, 2014 |  |  |  |  |  |
| Revenues | $ | 4,957 |  |  | $ | 1,803 |  |  | $ | — |  |
| EBT (1) | 1,116 |  |  | 1,550 |  |  | (1 | ) |
| EBT as a % of revenues | 23 | % |  | 86 | % |  |  |
| Three Months Ended June 30, 2013 |  |  |  |  |  |
| Revenues | $ | 4,222 |  |  | $ | 1,867 |  |  | $ | — |  |
| EBT | 738 |  |  | 1,633 |  |  | 51 |  |
| EBT as a % of revenues | 17 | % |  | 87 | % |  |  |
| Nine Months Ended June 29, 2014 |  |  |  |  |  |
| Revenues | $ | 13,816 |  |  | $ | 5,774 |  |  | $ | — |  |
| EBT | 2,762 |  |  | 5,054 |  |  | (36 | ) |
| EBT as a % of revenues | 20 | % |  | 88 | % |  |  |
| Nine Months Ended June 30, 2013 |  |  |  |  |  |
| Revenues | $ | 12,258 |  |  | $ | 5,680 |  |  | $ | — |  |
| EBT | 2,487 |  |  | 4,968 |  |  | 66 |  |
| EBT as a % of revenues | 20 | % |  | 87 | % |  |  |

[0001234452-14-000238:mdna:62]
[same as prior period, unchanged from 0001234452-14-000154:mdna:60]

[0001234452-14-000238:mdna:63]
QCT Segment. The increases in QCT revenues in the third quarter and the first nine months of fiscal 2014 of $735 million and $1.56 billion, respectively, were primarily due to increases in equipment and services revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying RF and PM integrated circuits, were $4.89 billion and $4.16 billion in the third quarter of fiscal 2014 and 2013, respectively, and $13.65 billion and $12.09 billion in the first nine months of fiscal 2014 and 2013, respectively. The increases in equipment and services revenues in the third quarter and the first nine months of fiscal 2014 resulted primarily from increases of $935 million and $1.80 billion, respectively, related to higher MSM and accompanying RF and PM unit shipments and $32 million and $179 million, respectively, related to sales of connectivity products, partially offset by net decreases of $287 million and $521 million, respectively, resulting from lower average selling prices and favorable product mix. Approximately 225 million and 172 million MSM integrated circuits were sold during the third quarter of fiscal 2014 and 2013, respectively, and approximately 625 million and 526 million MSM integrated circuits were sold during the first nine months of fiscal 2014 and 2013, respectively.

[0001234452-14-000238:mdna:64]
QCT EBT as a percentage of revenues in the third quarter of fiscal 2014 increased due to an increase of 17% in QCT revenues relative to a combined increase of 5% in research and development expenses and selling, general and administrative expenses, as well as an increase in gross margin percentage. The increase in QCT gross margin percentage in the third quarter of fiscal 2014 resulted from lower average unit costs, partially offset by lower average selling prices and unfavorable product mix. QCT EBT as a percentage of revenues in the first nine months of fiscal 2014 remained flat as compared to the same period in fiscal 2013. During the first nine months of fiscal 2014, QCT revenues increased 13% relative to a combined increase of 8% in research and development expenses and selling, general and administrative expenses, whereas gross margin percentage decreased as a result of lower average selling prices and unfavorable product mix, partially offset by lower average unit costs.

[0001234452-14-000238:mdna:65]
QCT inventories increased by 4% in the third quarter of fiscal 2014 from $1.14 billion to $1.18 billion.

[0001234452-14-000238:mdna:66]
QTL Segment. The decrease in QTL revenues in the third quarter of fiscal 2014 of $64 million was primarily due to a decrease in revenues per unit, partially offset by an increase in sales of CDMA-based products, including multimode products that also implement OFDMA, by licensees. The decrease in QTL EBT as a percentage of revenues in the third

[0001234452-14-000238:mdna:67]
quarter of fiscal 2014 was attributable to a decrease of 3% in revenues relative to an increase of 8% in costs and expenses. The increase in QTL revenues in the first nine months of fiscal 2014 of $94 million was primarily due to an increase in sales of CDMA-based products, including multimode products that also implement OFDMA, by licensees, partially offset by a decrease in revenues per unit. The increase in QTL EBT as a percentage of revenues in the first nine months of fiscal 2014 was attributable to an increase of 2% in revenues relative to an increase of 1% in costs and expenses. QTL revenues and EBT for the third quarter and the first nine months of fiscal 2014 were impacted by units that we believe are being underreported by certain licensees, a dispute with a licensee and sales of certain unlicensed products in China.

[0001234452-14-000238:mdna:68]
QSI Segment. The decrease in QSI EBT in the third quarter of fiscal 2014 of $52 million was primarily due to a decrease of $34 million in net realized gains on investments and the effect of the $22 million gain on the deconsolidation of the BWA subsidiaries in India that was recorded in the third quarter of fiscal 2013. The decrease in QSI EBT in the first nine months of fiscal 2014 of $102 million was primarily due to a decrease of $57 million in net realized gains on investments, an increase of $34 million in impairment losses on investments and the effect of the $22 million gain on deconsolidation.

[0001234452-14-000238:mdna:69]
[same as prior period, unchanged from 0001234452-14-000154:mdna:66]

[0001234452-14-000238:mdna:70]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. Cash, cash equivalents and marketable securities were $32.7 billion at June 29, 2014, an increase of $3.3 billion from September 29, 2013. This increase included $1.1 billion in proceeds from the issuance of common stock under our equity compensation plans and $788 million in net proceeds from the sale of the North and Latin America operations of our Omnitracs division. Our cash, cash equivalents and marketable securities at June 29, 2014 consisted of $6.9 billion held by United States-based entities and $25.8 billion held by foreign entities. Of our cash, cash equivalents and marketable securities at June 29, 2014, $25.5 billion is indefinitely reinvested offshore and would be subject to material tax effects if repatriated. Due to tax considerations, we derive liquidity for operations primarily from domestic cash flow and investments held domestically. Total cash provided by operating activities increased to $7.3 billion during the first nine months of fiscal 2014, compared to $6.3 billion during the first nine months of fiscal 2013.

[0001234452-14-000238:mdna:71]
Accounts receivable decreased 6% during the third quarter of fiscal 2014. Days sales outstanding, on a consolidated basis, were 27 days at June 29, 2014, compared to 31 days at March 30, 2014. The decreases in accounts receivable and the related days sales outstanding were primarily due to the timing of integrated circuit shipments.

[0001234452-14-000238:mdna:72]
During the first nine months of fiscal 2014, we repurchased and retired 44,609,000 shares of our common stock for $3.4 billion, before commissions. On March 4, 2014, the Company announced that it had been authorized to repurchase up to $7.8 billion of the Company’s common stock. At June 29, 2014, approximately $6.5 billion remained available for repurchase under our stock repurchase program, and we currently expect to complete a minimum of $1 billion of stock repurchases during the fourth quarter of fiscal 2014. We continue to evaluate repurchases as a means of returning capital to stockholders, subject to our periodic determinations that repurchases are in the best interests of our stockholders.

[0001234452-14-000238:mdna:73]
We paid cash dividends totaling $706 million, or $0.42 per share, on June 25, 2014. On July 18, 2014, we announced a cash dividend of $0.42 per share on our common stock, payable on September 24, 2014 to stockholders of record as of the close of business on September 3, 2014. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-14-000238:mdna:74]
During the first quarter of fiscal 2014, we announced our intention of returning 75% of our free cash flow to stockholders through stock repurchases and dividends over the foreseeable future, where free cash flow is defined as net cash provided by operating activities less capital expenditures. To meet this goal, we expect to use existing cash and marketable securities held by, and cash flow generated from, United States-based entities, and we anticipate that we will supplement this by borrowing additional funds within the next two years. The requirement for and timing of such borrowing is subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001234452-14-000238:mdna:75]
[same as prior period, unchanged from 0001234452-14-000154:mdna:72]

[0001234452-14-000238:mdna:76]
| • | Our research and development expenditures were $4.1 billion during the first nine months of fiscal 2014 and $5.0 billion in fiscal 2013, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications, primarily in the wireless industry. |

[0001234452-14-000238:mdna:77]
| • | Cash outflows for capital expenditures were $955 million during the first nine months of fiscal 2014 and $1.0 billion in fiscal 2013. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-14-000238:mdna:78]
| • | Our purchase obligations for the remainder of fiscal 2014 and for fiscal 2015, some of which relate to research and development activities and capital expenditures, totaled $3.0 billion and $387 million, respectively, at June 29, 2014. |

[0001234452-14-000238:mdna:79]
| • | We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly, to open new opportunities for our technologies, obtain development resources, grow our patent portfolio or pursue new businesses. |

[0001234452-14-000238:mdna:80]
[same as prior period, unchanged from 0001234452-14-000154:mdna:77]

[0001234452-14-000238:mdna:81]
[same as prior period, unchanged from 0001234452-14-000154:mdna:78]

[0001234452-14-000238:mdna:82]
Additional information regarding our financial commitments at June 29, 2014 is provided in the notes to our condensed consolidated financial statements. See “Notes to Condensed Consolidated Financial Statements, Note 4 — Income Taxes” and “Note 6 — Commitments and Contingencies.”

[0001234452-14-000238:mdna:83]
Recent Accounting Pronouncements

[0001234452-14-000238:mdna:84]
In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers.” ASU 2014-09 outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. ASU 2014-09 will be effective for us starting in the first quarter of fiscal 2018. ASU 2014-09 allows for two methods of adoption: (a) “full retrospective” adoption, meaning the standard is applied to all periods presented, or (b) “modified retrospective” adoption, meaning the cumulative effect of applying ASU 2014-09 is recognized as an adjustment to the fiscal 2018 opening retained earnings balance. We are in the process of determining the adoption method as well as the effects the adoption of ASU 2014-09 will have on our consolidated financial statements.

[0001234452-14-000238:mdna:85]
[same as prior period, unchanged from 0001234452-14-000154:mdna:80]

[0001234452-14-000238:mdna:86]
[same as prior period, unchanged from 0001234452-14-000154:mdna:81]

[0001234452-14-000238:mdna:87]
[same as prior period, unchanged from 0001234452-14-000154:mdna:82]

[0001234452-14-000238:mdna:88]
[same as prior period, unchanged from 0001234452-14-000154:mdna:83]

[0001234452-14-000238:mdna:89]
[same as prior period, unchanged from 0001234452-14-000154:mdna:84]

[0001234452-14-000238:mdna:90]
[same as prior period, unchanged from 0001234452-14-000154:mdna:85]

[0001234452-14-000238:mdna:91]
[same as prior period, unchanged from 0001234452-14-000154:mdna:86]

[0001234452-14-000238:mdna:92]
[same as prior period, unchanged from 0001234452-14-000154:mdna:87]

[0001234452-14-000238:mdna:93]
[same as prior period, unchanged from 0001234452-14-000154:mdna:88]

[0001234452-14-000238:mdna:94]
[same as prior period, unchanged from 0001234452-14-000154:mdna:89]

[0001234452-14-000238:mdna:95]
[same as prior period, unchanged from 0001234452-14-000154:mdna:90]

[0001234452-14-000238:mdna:96]
[same as prior period, unchanged from 0001234452-14-000154:mdna:91]

[0001234452-14-000238:mdna:97]
[same as prior period, unchanged from 0001234452-14-000154:mdna:92]

[0001234452-14-000238:mdna:98]
[same as prior period, unchanged from 0001234452-14-000154:mdna:93]

[0001234452-14-000238:mdna:99]
[same as prior period, unchanged from 0001234452-14-000154:mdna:94]

[0001234452-14-000238:mdna:100]
[same as prior period, unchanged from 0001234452-14-000154:mdna:95]

[0001234452-14-000238:mdna:101]
[same as prior period, unchanged from 0001234452-14-000154:mdna:96]

[0001234452-14-000238:mdna:102]
[same as prior period, unchanged from 0001234452-14-000154:mdna:97]

[0001234452-14-000238:mdna:103]
[same as prior period, unchanged from 0001234452-14-000154:mdna:98]

[0001234452-14-000238:mdna:104]
[same as prior period, unchanged from 0001234452-14-000154:mdna:100]

[0001234452-14-000238:mdna:105]
[same as prior period, unchanged from 0001234452-14-000154:mdna:101]

[0001234452-14-000238:mdna:106]
[same as prior period, unchanged from 0001234452-14-000154:mdna:102]

[0001234452-14-000238:mdna:107]
32

[0001234452-14-000238:mdna:108]
[same as prior period, unchanged from 0001234452-14-000154:mdna:103]

[0001234452-14-000238:mdna:109]
[same as prior period, unchanged from 0001234452-14-000154:mdna:104]

[0001234452-14-000238:mdna:110]
| • | create stand-alone value and/or contribute to the success of our existing businesses through investments in new industry segments and/or disruptive technologies, including new display technologies, wireless charging, mobile health, automotive, the connected home and the Internet of Everything, among others. |

[0001234452-14-000238:mdna:111]
[same as prior period, unchanged from 0001234452-14-000154:mdna:106]

[0001234452-14-000238:mdna:112]
[same as prior period, unchanged from 0001234452-14-000154:mdna:107]

[0001234452-14-000238:mdna:113]
[same as prior period, unchanged from 0001234452-14-000154:mdna:108]

[0001234452-14-000238:mdna:114]
[same as prior period, unchanged from 0001234452-14-000154:mdna:109]

[0001234452-14-000238:mdna:115]
Our QCT segment derives a significant portion of revenues from a small number of customers, and we may be unable to further diversify our customer base. In addition, our industry is experiencing and may continue to experience an increasing concentration of device share among a few companies, and this trend may result in an increasing portion of our revenues being derived from a small number of customers. The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or cancelation of significant purchases from any of these customers would reduce our revenues and could harm our ability to achieve or sustain expected operating results, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Further, concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of

[0001234452-14-000238:mdna:116]
our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have little or no control, and the timing of such introductions may cause our operating results to fluctuate. Accordingly, if current industry dynamics and concentrations continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases and the timing and size of any such future purchases by these significant customers.

[0001234452-14-000238:mdna:117]
[same as prior period, unchanged from 0001234452-14-000154:mdna:111]

[0001234452-14-000238:mdna:118]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business.

[0001234452-14-000238:mdna:119]
Although we have more than 260 CDMA-based licensees, our QTL segment derives a significant portion of licensing revenues from a limited number of licensees. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have little or no control over the product development or sales efforts of our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our major licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our revenues.

[0001234452-14-000238:mdna:120]
[same as prior period, unchanged from 0001234452-14-000154:mdna:114]

[0001234452-14-000238:mdna:121]
Although we own a very strong portfolio of issued and pending patents related to GSM, GPRS, EDGE, OFDM, OFDMA, WLAN, MIMO and other technologies, our patent portfolio licensing program in these areas is less established and might not be as successful in generating licensing revenues as our CDMA licensing program. Many wireless operators are investigating, have selected or have deployed OFDMA-based LTE as their next-generation 4G technology for deployment in existing or future wireless spectrum bands as complementary to their existing CDMA-based networks. While 3G/4G multimode products are generally covered by existing 3G licensing agreements, products that implement 4G and do not implement 3G are generally not covered by existing 3G licensing agreements. Although we believe that our patented technology is essential and useful to implementation of the LTE industry standards and have granted royalty-bearing licenses to more than 110 companies (including LG, Nokia, Samsung, Sony Mobile and ZTE) that have realized that they need a license under our patents to make and sell products implementing 4G standards but not implementing 3G standards, the royalty rates for single mode 4G products are generally lower than our royalty rates for 3G and 3G/4G multimode products, and therefore, we might not achieve the same licensing revenues on such LTE products as on 3G or 3G/4G multimode products. In addition, new connectivity services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the connected home or the Internet of Everything. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties that are equivalent to those that we receive for 3G products used in cellular communications. Although we believe that our patented technology is essential and useful to the commercialization of such services, the royalties we receive may be lower than those we receive from our current licensing program.

[0001234452-14-000238:mdna:122]
[same as prior period, unchanged from 0001234452-14-000154:mdna:117]

[0001234452-14-000238:mdna:123]
The licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date and, in a small number of agreements, royalties are payable on those patents for a specified time period. As a result, there are agreements with some licensees where later patents are not licensed by or to us and/or royalties are not owed to us under such license agreements after the specified time period. In order to license or to obtain a license to such later patents, or to receive royalties after the specified time period, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to

[0001234452-14-000238:mdna:124]
modify those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001234452-14-000238:mdna:125]
[same as prior period, unchanged from 0001234452-14-000154:mdna:119]

[0001234452-14-000238:mdna:126]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, or some form of unfair competition; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; and (v) lobbying governmental regulators and elected officials for the purpose of seeking the imposition of some form of compulsory licensing and/or to weaken a patent holder’s ability to enforce its rights or obtain a fair return for such rights.

[0001234452-14-000238:mdna:127]
[same as prior period, unchanged from 0001234452-14-000154:mdna:121]

[0001234452-14-000238:mdna:128]
[same as prior period, unchanged from 0001234452-14-000154:mdna:122]

[0001234452-14-000238:mdna:129]
[same as prior period, unchanged from 0001234452-14-000154:mdna:123]

[0001234452-14-000238:mdna:130]
We expect that such proposals, interpretations and strategies will continue in the future, and if successful, our business model would be harmed, either by limiting or eliminating our ability to collect royalties on all or a portion of our patent portfolio, limiting our return on investment with respect to new technologies, limiting our ability to seek injunctions against infringers of our standard-essential patents, constraining our ability to make licensing commitments when submitting our technology for inclusion in future standards (which could make our technology less likely to be included in such standards) or forcing us to work outside of SDOs or other industry groups to promote our new technologies, and our results of operations could be negatively impacted. In addition, the legal and other costs associated with asserting or defending our positions have been and continue to be significant. We assume that such challenges, regardless of their merits, will continue into the foreseeable future and may require the investment of substantial management time and financial resources.

[0001234452-14-000238:mdna:131]
The enforcement and protection of our intellectual property rights may be expensive, could fail to prevent misappropriation or unauthorized use of our proprietary intellectual property rights, could result in the loss of our ability to enforce one or more patents, or could be adversely affected by changes in patent laws, by laws in certain

[0001234452-14-000238:mdna:132]
[same as prior period, unchanged from 0001234452-14-000154:mdna:140]

[0001234452-14-000238:mdna:133]
foreign jurisdictions that may not effectively protect our intellectual property rights or by ineffective enforcement of laws in such jurisdictions.

[0001234452-14-000238:mdna:134]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements and other methods, to protect our proprietary information, technologies and processes, including our patent portfolio. Policing unauthorized use of our products, technologies and proprietary information is difficult and time consuming. We cannot be certain that the steps we have taken, or may take in the future, will prevent the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as United States laws or where the enforcement of such laws may be lacking or ineffective. Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes. We expect that in the next few years the European Union will adopt a unitary patent system that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technology. We may have difficulty in certain circumstances in protecting or enforcing our intellectual property rights and/or contracts, including collecting royalties for use of our patent portfolio in particular foreign jurisdictions due to, among others: policies of foreign governments; challenges to our licensing practices under such jurisdictions’ competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and/or challenges pending before foreign competition agencies to the pricing and integration of additional features and functionality into our chipset products.

[0001234452-14-000238:mdna:135]
We may need to litigate in the United States or elsewhere in the world to enforce our intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation, we could lose our ability to enforce one or more patents or incur substantial unexpected operating costs. Any action we take to enforce our intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our operating results.

[0001234452-14-000238:mdna:136]
[same as prior period, unchanged from 0001234452-14-000154:mdna:130]

[0001234452-14-000238:mdna:137]
Our industry is subject to rapid technological change, and we must make substantial research, development and other investments in new products, services and technologies to compete successfully. Technological innovations generally require significant research and development efforts before they are commercially viable. We intend to continue to make substantial investments in developing new products, services and technologies that we believe can create stand-alone value and/or contribute to the success of our existing businesses. However, it is possible that these initiatives will not be successful and/or will not result in meaningful revenues or generate operating income that meets expectations. While we continue to focus our development efforts primarily in support of 3G CDMA- and 4G OFDMA-based technologies, we innovate across a broad spectrum of opportunities that leverage our existing technical and business expertise to deploy new business models and enter into new industry segments. Our recent investment initiatives relate to, among others, new display technologies, wireless charging technology, small cell technology and the 1000x data challenge, very high speed connectivity, automotive, mobile health, wearable technology and products for the connected home, the digital 6th sense and the Internet of Everything.

[0001234452-14-000238:mdna:138]
[same as prior period, unchanged from 0001234452-14-000154:mdna:133]

[0001234452-14-000238:mdna:139]
[same as prior period, unchanged from 0001234452-14-000154:mdna:134]

[0001234452-14-000238:mdna:140]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products were found to infringe on another company’s intellectual property rights, we could be subject to an injunction or required to redesign our products, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products, license such intellectual property rights used in our products or otherwise distribute our products through a licensed supplier, we could be prohibited from making and selling such products. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect upon our operating results.

[0001234452-14-000238:mdna:141]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the U.S. International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes includes everything from royalty payment to an injunction on the sale of certain of our integrated circuit products (and on the sale of our customers’ devices using such products). Any imposition of royalty payments might make purchases of our products less economical for our customers and could have an adverse effect upon our operating results. A negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our share of worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001234452-14-000238:mdna:142]
[same as prior period, unchanged from 0001234452-14-000154:mdna:137]

[0001234452-14-000238:mdna:143]
[same as prior period, unchanged from 0001234452-14-000154:mdna:138]

[0001234452-14-000238:mdna:144]
Our QCT segment purchases wafers, die and fully-assembled and tested integrated circuits from third-party semiconductor manufacturing foundries. We also contract with third-party suppliers for assembly, test and other services related to the manufacture of our products. A reduction, interruption, delay or limitation in our product supply sources, a failure by our suppliers to procure raw materials or to provide or allocate adequate manufacturing or test capacity for our products or their inability to react to shifts in product demand or an increase in raw material or component prices could have an adverse effect on our ability to meet customer demands, our business and/or our profitability. The loss of a supplier or the inability of a supplier to meet performance or quality specifications or delivery schedules could harm our ability to meet our delivery obligations to our customers and/or negatively impact our revenues, business operations and ability to compete for future business. In the event of a loss of or a decision to change a supplier, qualifying a new supplier and commencing volume production or testing could cause us to incur additional expense and production delays, resulting in possible decrease in margins or loss of customers.

[0001234452-14-000238:mdna:145]
While we have established alternate suppliers for certain technologies that we consider critical, we rely on sole- or limited-source suppliers for some products, subjecting us to significant risks, including: possible shortages of raw materials or manufacturing capacity; poor product performance; and reduced control over delivery schedules,

[0001234452-14-000238:mdna:146]
37

[0001234452-14-000238:mdna:147]
manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established alternate suppliers, these suppliers may require significant levels of support to bring complex technologies to production. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, any future consolidation of foundry suppliers could increase our vulnerability to sole- or limited-source arrangements. Our arrangements with our suppliers may oblige us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies, and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, and could increase our costs (resulting in a possible decrease in margins), as well as subject us to the risk of excess inventories. Our inability to meet customer demand due to sole- or limited-sourcing and/or the additional costs that we incur because of these or other supply constraints or because of the need to support alternate suppliers could negatively impact our business, our revenues and our results of operations.

[0001234452-14-000238:mdna:148]
[same as prior period, unchanged from 0001234452-14-000154:mdna:143]

[0001234452-14-000238:mdna:149]
[same as prior period, unchanged from 0001234452-14-000154:mdna:144]

[0001234452-14-000238:mdna:150]
[same as prior period, unchanged from 0001234452-14-000154:mdna:145]

[0001234452-14-000238:mdna:151]
[same as prior period, unchanged from 0001234452-14-000154:mdna:146]

[0001234452-14-000238:mdna:152]
[same as prior period, unchanged from 0001234452-14-000154:mdna:147]

[0001234452-14-000238:mdna:153]
[same as prior period, unchanged from 0001234452-14-000154:mdna:148]

[0001234452-14-000238:mdna:154]
[same as prior period, unchanged from 0001234452-14-000154:mdna:149]

[0001234452-14-000238:mdna:155]
[same as prior period, unchanged from 0001234452-14-000154:mdna:150]

[0001234452-14-000238:mdna:156]
[same as prior period, unchanged from 0001234452-14-000154:mdna:151]

[0001234452-14-000238:mdna:157]
| • | proprietary rights, product or patent litigation taken or threatened against us or against our customers or licensees; |

[0001234452-14-000238:mdna:158]
[same as prior period, unchanged from 0001234452-14-000154:mdna:154]

[0001234452-14-000238:mdna:159]
[same as prior period, unchanged from 0001234452-14-000154:mdna:155]

[0001234452-14-000238:mdna:160]
[same as prior period, unchanged from 0001234452-14-000154:mdna:156]

[0001234452-14-000238:mdna:161]
[same as prior period, unchanged from 0001234452-14-000154:mdna:157]

[0001234452-14-000238:mdna:162]
[same as prior period, unchanged from 0001234452-14-000154:mdna:158]

[0001234452-14-000238:mdna:163]
[same as prior period, unchanged from 0001234452-14-000154:mdna:159]

[0001234452-14-000238:mdna:164]
In the past, securities class action litigation often has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we may be the target of securities litigation in the future. Securities litigation could result in substantial uninsured costs and divert management’s attention and resources.

[0001234452-14-000238:mdna:165]
[same as prior period, unchanged from 0001234452-14-000154:mdna:161]

[0001234452-14-000238:mdna:166]
Our business, products and services, and those of our customers and licensees, are subject to various laws and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies. The adoption of new laws, regulations or policies, changes in the interpretation of existing laws, regulations or policies, changes in the regulation of our activities by a government or standards body and/or adverse rulings in court, regulatory, administrative or other proceedings relating to such laws, regulations or policies, including, among others, those affecting the use of our technology or products, competitive business practices, licensing practices, protection of intellectual property, trade, foreign investments or loans, spectrum availability and license issuance, adoption of standards, the provision of device subsidies by wireless operators to their customers, taxation, environmental protection or employment, could have an adverse effect on our business. We are currently subject to various governmental investigations and/or proceedings, which are described more fully in the notes to our condensed consolidated financial statements. See “Notes to Condensed Consolidated Financial Statements, Note 6 - Commitments and Contingencies.”

[0001234452-14-000238:mdna:167]
[same as prior period, unchanged from 0001234452-14-000154:mdna:163]

[0001234452-14-000238:mdna:168]
[same as prior period, unchanged from 0001234452-14-000154:mdna:164]

[0001234452-14-000238:mdna:169]
[same as prior period, unchanged from 0001234452-14-000154:mdna:165]

[0001234452-14-000238:mdna:170]
[same as prior period, unchanged from 0001234452-14-000154:mdna:166]

[0001234452-14-000238:mdna:171]
[same as prior period, unchanged from 0001234452-14-000154:mdna:167]

[0001234452-14-000238:mdna:172]
We engage in acquisitions and strategic transactions and make strategic investments with the goal of maximizing stockholder value. We acquire businesses and other assets, including wireless spectrum, patents and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies that may be private and early-stage. Our strategic activities are generally focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services for voice and data communications. Many of our acquisitions or strategic investments entail a high degree of risk, and investments may not become liquid for several years after the date of the investment, if at all. Our acquisitions or strategic investments may not generate financial returns or result in increased adoption or continued use of our

[0001234452-14-000238:mdna:173]
39

[0001234452-14-000238:mdna:174]
technologies. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our acquisitions or strategic investments. Any losses or impairment charges that we incur related to strategic investments or other transactions will have a negative impact on our financial results, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001234452-14-000238:mdna:175]
Achieving the anticipated benefits of business acquisitions depends in part upon our ability to integrate the acquired businesses in an efficient and effective manner. The integration of companies that have previously operated independently may result in significant challenges, including, among others: retaining key employees; successfully integrating new employees, business systems and technology; retaining customers and suppliers of the acquired business; minimizing the diversion of management’s attention from ongoing business matters; coordinating geographically separate organizations; consolidating research and development operations; and consolidating corporate and administrative infrastructures. We may not derive any commercial value from acquired technology, products or intellectual property or from future technologies or products based on the acquired technology and/or intellectual property, and we may be subject to liabilities that are not covered by indemnification protection we may obtain or we may become subject to litigation. Additionally, we may not be successful in expanding into geographic regions and/or categories of products served by or adjacent to an acquired business or in addressing potential new opportunities that may arise out of the combination. In part due to our inexperience with products of and/or geographic regions served by acquired businesses, we may underestimate the costs and/or overestimate the benefits, including product and other synergies and growth opportunities that we expect to realize, and we may not achieve them. If we do not achieve the anticipated benefits of business acquisitions, our results of operations may be adversely affected, and we may not enhance stockholder value by engaging in these transactions.

[0001234452-14-000238:mdna:176]
[same as prior period, unchanged from 0001234452-14-000154:mdna:170]

[0001234452-14-000238:mdna:177]
[same as prior period, unchanged from 0001234452-14-000154:mdna:171]

[0001234452-14-000238:mdna:178]
[same as prior period, unchanged from 0001234452-14-000154:mdna:172]

[0001234452-14-000238:mdna:179]
[same as prior period, unchanged from 0001234452-14-000154:mdna:173]

[0001234452-14-000238:mdna:180]
[same as prior period, unchanged from 0001234452-14-000154:mdna:174]

[0001234452-14-000238:mdna:181]
[same as prior period, unchanged from 0001234452-14-000154:mdna:175]

[0001234452-14-000238:mdna:182]
[same as prior period, unchanged from 0001234452-14-000154:mdna:176]

[0001234452-14-000238:mdna:183]
[same as prior period, unchanged from 0001234452-14-000154:mdna:177]

[0001234452-14-000238:mdna:184]
40

[0001234452-14-000238:mdna:185]
[same as prior period, unchanged from 0001234452-14-000154:mdna:178]

[0001234452-14-000238:mdna:186]
[same as prior period, unchanged from 0001234452-14-000154:mdna:179]

[0001234452-14-000238:mdna:187]
[same as prior period, unchanged from 0001234452-14-000154:mdna:180]

[0001234452-14-000238:mdna:188]
[same as prior period, unchanged from 0001234452-14-000154:mdna:181]

[0001234452-14-000238:mdna:189]
[same as prior period, unchanged from 0001234452-14-000154:mdna:182]

[0001234452-14-000238:mdna:190]
[same as prior period, unchanged from 0001234452-14-000154:mdna:183]

[0001234452-14-000238:mdna:191]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related litigation could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision and results of operations in the period or periods in which that determination is made could be negatively affected.

[0001234452-14-000238:mdna:192]
[same as prior period, unchanged from 0001234452-14-000154:mdna:185]

[0001234452-14-000238:mdna:193]
Tax rules may change in a manner that adversely affects our future reported financial results or the way we conduct our business. For example, we consider the operating earnings of certain non-United States subsidiaries to be indefinitely invested outside the United States based on our current needs for those earnings to be reinvested offshore as well as estimates that future domestic cash generated from operations and/or borrowings will be sufficient to meet future domestic cash needs for the foreseeable future. No provision has been made for United States federal and state or foreign taxes that may result from future remittances of the undistributed earnings of these foreign subsidiaries. Our future financial results and liquidity may be adversely affected if tax rules regarding unrepatriated earnings change, if domestic cash needs require us to repatriate foreign earnings, or if the United States international tax rules change as part of comprehensive tax reform or other tax legislation.

[0001234452-14-000238:mdna:194]
[same as prior period, unchanged from 0001234452-14-000154:mdna:188]

[0001234452-14-000238:mdna:195]
Concerns over the effects of radio frequency emissions continue. Interest groups have requested that the Federal Communications Commission investigate claims that wireless communications technologies pose health concerns and cause interference with, among other things, airbags, hearing aids and medical devices, and there continues to be litigation in the industry with respect to these issues. Legislation that may be adopted in response to these concerns or adverse news or findings about safety risks could reduce demand for our products and those of our licensees and customers in the United States as well as in foreign countries.

[0001234452-14-000238:mdna:196]
[same as prior period, unchanged from 0001234452-14-000154:mdna:190]

[0001234452-14-000238:mdna:197]
[same as prior period, unchanged from 0001234452-14-000154:mdna:191]
