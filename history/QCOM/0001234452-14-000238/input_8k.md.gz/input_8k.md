# QCOM 8-K — 0001234452-14-000236 filed 2014-07-23

## item codes, every 8-K on or before 2014-07-23

- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2014-07-23

- none on or before 2014-07-23

## item 2.02 — earnings release, exhibit 99.1

[0001234452-14-000236:8k_2_02:1]
EX-99.1
2
qcom062914erex991.htm
EX 99.1

[0001234452-14-000236:8k_2_02:2]
QCOM 06.29.14 ER EX 99.1

[0001234452-14-000236:8k_2_02:3]
Exhibit 99.1

[0001234452-14-000236:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-14-000236:8k_2_02:5]
Qualcomm Contact:

[0001234452-14-000236:8k_2_02:6]
Warren Kneeshaw

[0001234452-14-000236:8k_2_02:7]
Vice President, Investor Relations

[0001234452-14-000236:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-14-000236:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-14-000236:8k_2_02:10]
Qualcomm Announces Record Third Quarter Fiscal 2014 Results

[0001234452-14-000236:8k_2_02:11]
Revenues $6.8 billion

[0001234452-14-000236:8k_2_02:12]
GAAP EPS $1.31, Non-GAAP EPS $1.44

[0001234452-14-000236:8k_2_02:13]
- Raising Fiscal 2014 EPS Guidance -

[0001234452-14-000236:8k_2_02:14]
SAN DIEGO - July 23, 2014 - Qualcomm Incorporated (Nasdaq:  QCOM), a leading developer and innovator of advanced wireless technologies, products and services, today announced results for the third quarter of fiscal 2014 ended June 29, 2014.

[0001234452-14-000236:8k_2_02:15]
“We are pleased to report another record quarter with revenues, earnings per share and chip shipments reaching all-time highs, driven by broad-based demand for our industry-leading 3G/4G chipset solutions,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “Looking forward, although we have lowered our near-term financial outlook for the licensing business, we are pleased to be raising our fiscal year earnings per share guidance on better than expected performance in our semiconductor business.”

[0001234452-14-000236:8k_2_02:16]
Third Quarter Results (GAAP)*

[0001234452-14-000236:8k_2_02:17]
| • | Revenues: 1 $6.81 billion, up 9 percent year-over-year (y-o-y) and 7 percent sequentially. |

[0001234452-14-000236:8k_2_02:18]
| • | Operating income: 1 $2.08 billion, up 24 percent y-o-y and 4 percent sequentially. |

[0001234452-14-000236:8k_2_02:19]
| • | Net income: 2 $2.24 billion, up 42 percent y-o-y and 14 percent sequentially. |

[0001234452-14-000236:8k_2_02:20]
| • | Diluted earnings per share: 2 $1.31, up 46 percent y-o-y and 15 percent sequentially. |

[0001234452-14-000236:8k_2_02:21]
| • | Effective tax rate: 1 10 percent. |

[0001234452-14-000236:8k_2_02:22]
| • | Operating cash flow: $2.67 billion, up 29 percent y-o-y; 39 percent of revenues. |

[0001234452-14-000236:8k_2_02:23]
| • | Return of capital to stockholders: $2.06 billion, including $1.35 billion through repurchases of 17.0 million shares of common stock and $706 million, or $0.42 per share, of cash dividends paid. |

[0001234452-14-000236:8k_2_02:24]
__________________________

[0001234452-14-000236:8k_2_02:25]
1 Throughout this news release, revenues, operating expenses, operating income, earnings before tax (EBT) and effective tax rates are from continuing operations (i.e., before adjustments for noncontrolling interests and discontinued operations), unless otherwise stated.

[0001234452-14-000236:8k_2_02:26]
2 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests and discontinued operations), unless otherwise stated.

[0001234452-14-000236:8k_2_02:27]
Non-GAAP Third Quarter Results*

[0001234452-14-000236:8k_2_02:28]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items and tax items.

[0001234452-14-000236:8k_2_02:29]
| • | Revenues: $6.81 billion, up 9 percent y-o-y and 7 percent sequentially. |

[0001234452-14-000236:8k_2_02:30]
| • | Operating income: $2.43 billion, up 19 percent y-o-y and 4 percent sequentially. |

[0001234452-14-000236:8k_2_02:31]
| • | Net income: $2.47 billion, up 35 percent y-o-y and 10 percent sequentially. |

[0001234452-14-000236:8k_2_02:32]
| • | Diluted earnings per share: $1.44, up 40 percent y-o-y and 10 percent sequentially. |

[0001234452-14-000236:8k_2_02:33]
| • | Effective tax rate: 13 percent. |

[0001234452-14-000236:8k_2_02:34]
Detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-14-000236:8k_2_02:35]
* The following should be considered in regards to the year-over-year and sequential comparisons:

[0001234452-14-000236:8k_2_02:36]
| • | The third quarter of fiscal 2014 results included: |

[0001234452-14-000236:8k_2_02:37]
| ◦ | $208 million of income, or $0.12 per share, of which $184 million was recorded in other income, due to the reversal of accruals related to our litigation with ParkerVision; and |

[0001234452-14-000236:8k_2_02:38]
| ◦ | $164 million of charges, or $0.08 per share, that resulted from an impairment on goodwill and long-lived assets related to our QMT (Qualcomm MEMS Technologies) division. |

[0001234452-14-000236:8k_2_02:39]
| • | The third quarter of fiscal 2013 results included: |

[0001234452-14-000236:8k_2_02:40]
| ◦ | $158 million charge, or $0.06 per share, that resulted from an impairment on long-lived assets related to our QMT division. |

[0001234452-14-000236:8k_2_02:41]
Third Quarter Key Business Metrics

[0001234452-14-000236:8k_2_02:42]
| • | MSMTM chip shipments: 225 million units, up 31 percent y-o-y and 20 percent sequentially. |

[0001234452-14-000236:8k_2_02:43]
| • | March quarter total reported device sales: approximately $58.1 billion, up 3 percent y-o-y and down 13 percent sequentially. |

[0001234452-14-000236:8k_2_02:44]
| ◦ | March quarter estimated 3G/4G device shipments: approximately 250 to 254 million units, at an estimated average selling price of approximately $228 to $234 per unit. |

[0001234452-14-000236:8k_2_02:45]
Cash and Marketable Securities

[0001234452-14-000236:8k_2_02:46]
Our cash, cash equivalents and marketable securities totaled $32.7 billion at the end of the third quarter of fiscal 2014, compared to $30.4 billion a year ago and $32.1 billion at the end of the second quarter of fiscal 2014.  On July 18, 2014, we announced a cash dividend of $0.42 per share payable on September 24, 2014 to stockholders of record as of the close of business on September 3, 2014.

[0001234452-14-000236:8k_2_02:47]
Research and Development

[0001234452-14-000236:8k_2_02:48]
| ($ in millions) | Non-GAAP |  | QSI |  | Share-Based Compensation |  | Acquisition-Related Items |  | GAAP |
| Third quarter fiscal 2014 | $ | 1,251 |  |  | $ | 1 |  |  | $ | 174 |  |  | $ | 3 |  |  | $ | 1,429 |  |
| As % of revenues | 18 | % |  |  |  |  |  |  |  | 21 | % |
| Third quarter fiscal 2013 | $ | 1,130 |  |  | $ | 1 |  |  | $ | 166 |  |  | $ | 1 |  |  | $ | 1,298 |  |
| As % of revenues | 18 | % |  |  |  |  |  |  |  | 21 | % |
| Year-over-year change ($) | 11 | % |  | N/M |  |  | 5 | % |  | N/M |  |  | 10 | % |

[0001234452-14-000236:8k_2_02:49]
N/M - Not Meaningful

[0001234452-14-000236:8k_2_02:50]
Non-GAAP research and development (R&D) expenses increased 11 percent y-o-y primarily due to an increase in costs to develop CDMA-based 3G, OFDMA-based 4G LTE and other technologies for integrated circuit and related software products and to expand our intellectual property portfolio.

[0001234452-14-000236:8k_2_02:51]
Selling, General and Administrative

[0001234452-14-000236:8k_2_02:52]
| ($ in millions) | Non-GAAP |  | QSI |  | Share-Based Compensation |  | Acquisition-Related Items |  | GAAP |
| Third quarter fiscal 2014 | $ | 484 |  |  | $ | 4 |  |  | $ | 88 |  |  | $ | 6 |  |  | $ | 582 |  |
| As % of revenues | 7 | % |  |  |  |  |  |  |  | 9 | % |
| Third quarter fiscal 2013 | $ | 505 |  |  | $ | 6 |  |  | $ | 96 |  |  | $ | 6 |  |  | $ | 613 |  |
| As % of revenues | 8 | % |  |  |  |  |  |  |  | 10 | % |
| Year-over-year change ($) | (4 | %) |  | (33 | %) |  | (8 | %) |  | N/M |  |  | (5 | %) |

[0001234452-14-000236:8k_2_02:53]
N/M - Not Meaningful

[0001234452-14-000236:8k_2_02:54]
Non-GAAP selling, general and administrative (SG&A) expenses decreased 4 percent y-o-y primarily due to a decrease in selling and marketing expenses.

[0001234452-14-000236:8k_2_02:55]
Effective Income Tax Rates

[0001234452-14-000236:8k_2_02:56]
Our fiscal 2014 annual effective income tax rates are estimated to be 14 percent for GAAP and 15 percent for Non-GAAP, both of which include the United States federal R&D tax credit generated through December 31, 2013, the date on which the credit expired.  During the third quarter of fiscal 2014, we recorded a $66 million tax benefit as a result of an agreement reached with the Internal Revenue Service related to transfer pricing on our fiscal 2013 tax return, which was excluded from Non-GAAP results.

[0001234452-14-000236:8k_2_02:57]
Business Outlook

[0001234452-14-000236:8k_2_02:58]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment and certain derivative gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001234452-14-000236:8k_2_02:59]
During the fourth quarter of fiscal 2014, we expect to complete a minimum of $1 billion in stock repurchases under our current stock repurchase program.  Our outlook for fiscal 2014 diluted earnings per share includes an estimate of the benefit related to stock repurchases.

[0001234452-14-000236:8k_2_02:60]
China continues to present significant opportunities for us, particularly with the rollout of 4G LTE, but also presents significant challenges, as our business practices continue to be the subject of an investigation by the China National Development and Reform Commission (NDRC).  Please refer to our Quarterly Report on Form 10-Q for the third quarter ended June 29, 2014 filed with the SEC for our most recent disclosures regarding the NDRC investigation.

[0001234452-14-000236:8k_2_02:61]
We also believe that certain licensees in China currently are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes certain licensees underreporting a portion of their 3G/4G device sales and a dispute with a licensee) and that unlicensed companies may seek to delay execution of new licenses while the NDRC investigation is ongoing.  We expect calendar year 2014 3G/4G device shipments to be approximately 1.3 billion globally.  However, our estimate of calendar year 2014 3G/4G device shipments that we currently expect to be reported to us is approximately 1.04 billion to 1.13 billion, which is adjusted for units that we believe may not be reported to us, are in dispute or are currently unlicensed.  We are taking steps to address these issues, although the timing of any resolution is uncertain.

[0001234452-14-000236:8k_2_02:62]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-14-000236:8k_2_02:63]
Qualcomm’s Business Outlook Summary

[0001234452-14-000236:8k_2_02:64]
| FOURTH FISCAL QUARTER |
|  |  | Q4 FY13 Results | Current Guidance Q4 FY14 Estimates |
|  | Revenues |  | $6.48 | B | $6.5B - $7.4B |  |
|  | Year-over-year change |  | even - increase 14% |  |
|  | Non-GAAP diluted earnings per share (EPS) |  | $1.05 |  | $1.20 - $1.35 |  |
|  | Year-over-year change |  | increase 14% - 29% |  |
|  | Diluted EPS attributable to QSI |  | ($0.01 | ) | $0.00 |
|  | Diluted EPS attributable to share-based compensation |  | ($0.13 | ) |  | ($0.13 | ) |
|  | Diluted EPS attributable to acquisition-related items |  | ($0.04 | ) |  | ($0.04 | ) |
|  | GAAP diluted EPS |  | $0.86 |  | $1.03 - $1.18 |  |
|  | Year-over-year change |  | increase 20% - 37% |  |
|  | Metrics |  |  |
|  | MSM chip shipments | 190M |  | 230M - 245M |  |
|  | Year-over-year change |  | increase 21% - 29% |  |
|  | Total reported device sales (1) | approx. $60.2B* |  | approx. $53.0B - $59.0B* |  |
|  | Year-over-year change |  | decrease 2% - 12% |  |
|  | *Est. sales in June quarter, reported in September quarter |  |  |

[0001234452-14-000236:8k_2_02:65]
| FISCAL YEAR |
|  |  | FY 2013 Results | Prior Guidance FY 2014 Estimates (2) | Current Guidance FY 2014 Estimates |
|  | Revenues |  | $24.87 | B | $26.0B - $27.5B |  | $26.3B - $27.2B |  |
|  | Year-over-year change |  | increase 5% - 11% |  | increase 6% - 9% |  |
|  | Non-GAAP diluted EPS |  | $4.51 |  | $5.05 - $5.25 |  | $5.21 - $5.36 |  |
|  | Year-over-year change |  | increase 12% - 16% |  | increase 16% - 19% |  |
|  | Diluted EPS attributable to QSI |  | $0.02 |  |  | ($0.01 | ) |  | ($0.01 | ) |
|  | Diluted EPS attributable to share-based compensation |  | ($0.51 | ) |  | ($0.51 | ) |  | ($0.51 | ) |
|  | Diluted EPS attributable to acquisition-related items |  | ($0.16 | ) |  | ($0.16 | ) |  | ($0.16 | ) |
|  | Diluted EPS attributable to tax items |  | $0.04 |  | N/A |  |  | $0.04 |  |
|  | GAAP diluted EPS |  | $3.91 |  | $4.37 - $4.57 |  | $4.57 - $4.72 |  |
|  | Year-over-year change |  | increase 12% - 17% |  | increase 17% - 21% |  |
|  | Metrics |  |  |  |
|  | Est. fiscal year* 3G/4G device average selling price range (1) | approx. $223 - $229 |  | approx. $218 - $228 |  | approx. $222 - $228 |  |
|  | *Shipments in Sept. to June quarters, reported in Dec. to Sept. quarters |  |  |  |

[0001234452-14-000236:8k_2_02:66]
| CALENDAR YEAR Device Estimates (1) |
|  |  | Calendar 2013Estimates | Prior GuidanceCalendar 2014Estimates | Current GuidanceCalendar 2014Estimates |
|  | Est. 3G/4G device shipments |  |  |  |
|  | March quarter | approx. 244M - 248M | not provided | approx. 250M - 254M |
|  | June quarter | approx. 260M - 264M | not provided | not provided |
|  | September quarter | approx. 276M - 280M | not provided | not provided |
|  | December quarter | approx. 295M - 299M | not provided | not provided |
|  | Est. calendar year range (approx.) | 1,075M - 1,091M | 1,220M - 1,300M | 1,040M - 1,130M (3) |

[0001234452-14-000236:8k_2_02:67]
| (1) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). The reported quarterly estimated ranges of average selling prices (ASPs) and unit shipments are determined based on the information as reported to us by our licensees during the relevant period and our own estimates of the selling prices and unit shipments for licensees that do not provide such information. Not all licensees report sales, selling prices and/or unit shipments the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales, estimated unit shipments and estimated ASPs for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-14-000236:8k_2_02:68]
| (2) | Our prior guidance for fiscal 2014 GAAP diluted EPS excluded a $66 million tax benefit that we recorded in the third quarter of fiscal 2014 as a result of an agreement reached with the Internal Revenue Service, which was excluded from our Non-GAAP results. |

[0001234452-14-000236:8k_2_02:69]
| (3) | We expect calendar year 2014 3G/4G device shipments to be approximately 1.3 billion globally. However, our estimate of calendar year 2014 3G/4G device shipments that we currently expect to be reported to us is approximately 1.04 billion to 1.13 billion, which is adjusted for units that we believe may not be reported to us, are in dispute or are currently unlicensed. We are taking steps to address these issues, although the timing of any resolution is uncertain. |

[0001234452-14-000236:8k_2_02:70]
N/A - Not Applicable

[0001234452-14-000236:8k_2_02:71]
Sums may not equal totals due to rounding.

[0001234452-14-000236:8k_2_02:72]
Results of Business Segments

[0001234452-14-000236:8k_2_02:73]
The following table reconciles our Non-GAAP results to our GAAP results ($ in millions, except per share data):

[0001234452-14-000236:8k_2_02:74]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (1) (2) | Non-GAAP (3) | QSI (3) | Share-Based Compensation (3) | Acquisition-Related Items (3) | Tax Items | GAAP |
| Q3 - FISCAL 2014 |  |
| Revenues | $4,957 | $1,803 | $46 | $6,806 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $6,806 |  |
| Change from prior year | 17 | % | (3 | %) | (70 | %) | 9 | % |  |  |  |  |  |  | 9 | % |  |
| Change from prior quarter | 17 | % | (13 | %) | (13 | %) | 7 | % |  |  |  |  |  |  | 7 | % |  |
| Operating income (loss) |  |  |  | $2,425 |  | ($5) | ($274) | ($71) |  | $— |  |  | $2,075 |  |
| Change from prior year |  |  |  | 19 | % |  | 29 | % | 2 | % | — | % |  |  | 24 | % |  |
| Change from prior quarter |  |  |  | 4 | % |  | 17 | % | (9 | %) | 21 | % |  |  |  | 4 | % |  |
| EBT | $1,116 | $1,550 | $177 | $2,843 |  | ($1) | ($274) | ($71) |  | $— |  |  | $2,497 |  |
| Change from prior year | 51 | % | (5 | %) | N/M |  | 29 | % |  | N/M |  | 2 | % | — | % |  |  |  | 31 | % |  |
| Change from prior quarter | 51 | % | (15 | %) | N/M |  | 7 | % |  | 97 | % | (9 | %) | 21 | % |  |  |  | 10 | % |  |
| EBT as % of revenues | 23 | % | 86 | % | N/M |  | 42 | % |  |  |  |  |  |  | 37 | % |  |
| Net income (loss) |  |  |  | $2,470 |  |  | $— |  | ($232) | ($66) | $66 |  | $2,238 |  |
| Change from prior year |  |  |  | 35 | % |  | N/M |  | (5 | %) | (3 | %) | N/M |  |  | 42 | % |  |
| Change from prior quarter |  |  |  | 10 | % |  | N/M |  | (17 | %) | 19 | % | N/M |  |  | 14 | % |  |
| Diluted EPS |  |  |  | $1.44 |  | $0.00 | ($0.14) | ($0.04) | $0.04 |  | $1.31 |  |
| Change from prior year |  |  |  | 40 | % |  | N/M |  | (8 | %) | — | % | N/M |  |  | 46 | % |  |
| Change from prior quarter |  |  |  | 10 | % |  | N/M |  | (27 | %) | 20 | % | N/M |  |  | 15 | % |  |
| Diluted shares used |  |  |  | 1,714 |  | 1,714 | 1,714 | 1,714 | 1,714 |  | 1,714 |  |
| Q2 - FISCAL 2014 |  |
| Revenues | $4,243 | $2,071 | $53 | $6,367 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $6,367 |  |
| Operating income (loss) |  |  |  | 2,337 |  | (6) | (251) | (90) | — |  |  | 1,990 |  |
| EBT | $740 | $1,834 | $78 | 2,652 |  | (39) | (251) | (90) | — |  |  | 2,272 |  |
| Net income (loss) |  |  |  | 2,255 |  | (17) | (198) | (81) | — |  |  | 1,959 |  |
| Diluted EPS |  |  |  | $1.31 |  | ($0.01) | ($0.11) | ($0.05) |  | $— |  |  | $1.14 |  |
| Diluted shares used |  |  |  | 1,719 |  | 1,719 | 1,719 | 1,719 | 1,719 |  | 1,719 |  |
| Q3 - FISCAL 2013 |  |
| Revenues | $4,222 | $1,867 | $154 | $6,243 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $6,243 |  |
| Operating income (loss) |  |  |  | 2,035 |  | (7) | (280) | (71) | — |  |  | 1,677 |  |
| EBT | $738 | $1,633 | ($161) | 2,210 |  | 51 | (280) | (71) | — |  |  | 1,910 |  |
| Net income (loss) |  |  |  | 1,823 |  | 43 | (222) | (64) | — |  |  | 1,580 |  |
| Diluted EPS |  |  |  | $1.03 |  | $0.02 | ($0.13) | ($0.04) |  | $— |  |  | $0.90 |  |
| Diluted shares used |  |  |  | 1,765 |  | 1,765 | 1,765 | 1,765 | 1,765 |  | 1,765 |  |
| Q4 - FISCAL 2013 |  |
| Revenues | $4,457 | $1,874 | $149 | $6,480 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $6,480 |  |
| Operating income (loss) |  |  |  | 1,940 |  | (11) | (274) | (67) | — |  |  | 1,588 |  |
| EBT | $702 | $1,622 | ($151) | 2,173 |  | (11) | (274) | (67) | — |  |  | 1,821 |  |
| Net income (loss) |  |  |  | 1,818 |  | (24) | (226) | (67) | — |  |  | 1,501 |  |
| Diluted EPS |  |  |  | $1.05 |  | ($0.01) | ($0.13) | ($0.04) |  | $— |  |  | $0.86 |  |
| Diluted shares used |  |  |  | 1,738 |  | 1,738 | 1,738 | 1,738 | 1,738 |  | 1,738 |  |

[0001234452-14-000236:8k_2_02:75]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (1) (2) | Non-GAAP (3) | QSI (3) | Share-Based Compensation (3) | Acquisition-Related Items (3) | Tax Items | GAAP |
| 9 MONTHS - FISCAL 2014 |  |
| Revenues | $13,816 | $5,774 | $205 | $19,795 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $19,795 |  |
| Change from prior year | 13 | % | 2 | % | (54 | %) | 8 | % |  |  |  |  |  |  | 8 | % |  |
| Operating income (loss) |  |  |  | $6,611 |  | ($16) | ($806) | ($231) |  | $— |  |  | $5,558 |  |
| Change from prior year |  |  |  | (2 | %) |  | 20 | % | 3 | % | (3 | %) |  |  | (1 | %) |  |
| EBT | $2,762 | $5,054 | ($217) | $7,599 |  | ($36) | ($806) | ($231) |  | $— |  |  | $6,526 |  |
| Change from prior year | 11 | % | 2 | % | N/M |  | 3 | % |  | N/M |  | 3 | % | (3 | %) |  |  | 2 | % |  |
| EBT as % of revenues | 20 | % | 88 | % | N/M |  | 38 | % |  |  |  |  |  |  | 33 | % |  |
| Discontinued operations, net of tax (4) |  |  |  | $430 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $430 |  |
| Net income (loss) |  |  |  | $6,888 |  | ($13) | ($655) | ($213) | $66 |  | $6,073 |  |
| Change from prior year |  |  |  | 13 | % |  | N/M |  | 1 | % | — | % | 3 | % |  | 13 | % |  |
| Diluted EPS |  |  |  | $4.01 |  | ($0.01) | ($0.38) | ($0.12) | $0.04 |  | $3.53 |  |
| Change from prior year |  |  |  | 16 | % |  | N/M |  | — | % | — | % | — | % |  | 16 | % |  |
| Diluted shares used |  |  |  | 1,718 |  | 1,718 | 1,718 | 1,718 | 1,718 |  | 1,718 |  |
| 9 MONTHS - FISCAL 2013 |  |
| Revenues | $12,258 | $5,680 | $447 | $18,385 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $18,385 |  |
| Operating income (loss) |  |  |  | 6,716 |  | (20) | (829) | (225) | — |  |  | 5,642 |  |
| EBT | $2,487 | $4,968 | ($95) | 7,360 |  | 66 | (829) | (225) | — |  |  | 6,372 |  |
| Net income (loss) |  |  |  | 6,094 |  | 67 | (661) | (212) | 64 |  | 5,352 |  |
| Diluted EPS |  |  |  | $3.46 |  | $0.04 | ($0.38) | ($0.12) | $0.04 |  | $3.04 |  |
| Diluted shares used |  |  |  | 1,760 |  | 1,760 | 1,760 | 1,760 | 1,760 |  | 1,760 |  |
| 12 MONTHS - FISCAL 2013 |  |
| Revenues | $16,715 | $7,554 | $597 | $24,866 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $24,866 |  |
| Operating income (loss) |  |  |  | 8,657 |  | (31) | (1,103) | (293) | — |  |  | 7,230 |  |
| EBT | $3,189 | $6,590 | ($245) | 9,534 |  | 56 | (1,103) | (293) | — |  |  | 8,194 |  |
| Net income (loss) |  |  |  | 7,911 |  | 43 | (886) | (279) | 64 |  | 6,853 |  |
| Diluted EPS |  |  |  | $4.51 |  | $0.02 | ($0.51) | ($0.16) | $0.04 |  | $3.91 |  |
| Diluted shares used |  |  |  | 1,754 |  | 1,754 | 1,754 | 1,754 | 1,754 |  | 1,754 |  |

[0001234452-14-000236:8k_2_02:76]
| (1) | Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations. Non-GAAP reconciling items related to earnings before taxes consisted primarily of certain research and development expenses, selling, general and administrative expenses, other expenses or income and certain investment income that are not allocated to the segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit. |

[0001234452-14-000236:8k_2_02:77]
| (2) | During the first quarter of fiscal 2014, as a result of the reassessment of management reporting, the former Qualcomm Wireless & Internet (QWI) segment was eliminated. Revenues and operating results for the divisions that comprised the QWI segment are included in Non-GAAP reconciling items. Prior period information has been adjusted to conform to the current presentation. |

[0001234452-14-000236:8k_2_02:78]
| (3) | At fiscal year end, the sum of the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is allocated to tax provisions (benefits) among the columns. |

[0001234452-14-000236:8k_2_02:79]
| (4) | During the first quarter of fiscal 2014, a gain of $665 million was recorded associated with the sale of substantially all of the operations of our Omnitracs division. |

[0001234452-14-000236:8k_2_02:80]
N/M - Not Meaningful

[0001234452-14-000236:8k_2_02:81]
N/A - Not Applicable

[0001234452-14-000236:8k_2_02:82]
Sums may not equal totals due to rounding.

[0001234452-14-000236:8k_2_02:83]
Conference Call

[0001234452-14-000236:8k_2_02:84]
Qualcomm’s third quarter fiscal 2014 earnings conference call will be broadcast live on July 23, 2014, beginning at 2:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 63935250.

[0001234452-14-000236:8k_2_02:85]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-14-000236:8k_2_02:86]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for, or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-14-000236:8k_2_02:87]
The Company uses Non-GAAP financial information (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against each other and against competitors.  Non-GAAP measurements used by the Company include revenues, cost of equipment and services revenues, R&D expenses, SG&A expenses, operating income, net investment income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  As a result, management compensation decisions and the review of executive compensation by the Compensation Committee of the Board of Directors focus primarily on Non-GAAP financial measures applicable to the Company and its business segments.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.

[0001234452-14-000236:8k_2_02:88]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items and tax items.

[0001234452-14-000236:8k_2_02:89]
| • | QSI is excluded because the Company expects to exit its strategic investments at various times, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-14-000236:8k_2_02:90]
| • | Share-based compensation expense primarily relates to restricted stock units. Non-cash share-based compensation is excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses. |

[0001234452-14-000236:8k_2_02:91]
| • | Acquisition-related items include amortization and impairment of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items starting with acquisitions completed in the third quarter of fiscal 2011, as well as any tax effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property. These acquisition-related items are excluded and are not allocated to the Company’s segments because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses. In addition, these charges are impacted by the size and timing of acquisitions, potentially obscuring period-to-period comparisons of the Company’s operating businesses. |

[0001234452-14-000236:8k_2_02:92]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. |

[0001234452-14-000236:8k_2_02:93]
About Qualcomm

[0001234452-14-000236:8k_2_02:94]
Qualcomm Incorporated (Nasdaq:  QCOM) is a world leader in 3G, 4G and next-generation wireless technologies.  Qualcomm Incorporated includes Qualcomm’s licensing business, QTL, and the vast majority of its patent portfolio.  Qualcomm Technologies, Inc., a wholly-owned subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of Qualcomm’s engineering, research and development functions, and substantially all of its products and services businesses, including its semiconductor business, QCT.  For more than 25 years, Qualcomm ideas and inventions have driven the evolution of digital communications, linking people everywhere more closely to information, entertainment and each other.  For more information, visit www.qualcomm.com.

[0001234452-14-000236:8k_2_02:95]
Note Regarding Forward-Looking Statements

[0001234452-14-000236:8k_2_02:96]
###

[0001234452-14-000236:8k_2_02:97]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-14-000236:8k_2_02:98]
Supplemental Information

[0001234452-14-000236:8k_2_02:99]
(Unaudited)

[0001234452-14-000236:8k_2_02:100]
|  | Three Months Ended June 29, 2014 |  |
|  |  | Non-GAAP Results | QSI | Share-Based Compensation | Acquisition-Related Items | Tax Items (a) | GAAP Results |
| ($ in millions, except per share data) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Cost of equipment and services revenues |  | $ | 2,666 |  |  |  | $ | — |  |  |  | $ | 12 |  |  |  | $ | 62 |  |  |  | $ | — |  |  |  | $ | 2,740 |  |  |
|  | R&D expenses |  | 1,251 |  |  |  | 1 |  |  |  | 174 |  |  |  | 3 |  |  |  | — |  |  |  | 1,429 |  |  |
|  | SG&A expenses |  | 484 |  |  |  | 4 |  |  |  | 88 |  |  |  | 6 |  |  |  | — |  |  |  | 582 |  |  |
|  | Other income, net |  | 20 |  | (b) |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20 |  |  |
|  | Operating income (loss) |  | 2,425 |  |  |  | (5 | ) |  |  | (274 | ) |  |  | (71 | ) |  |  | — |  |  |  | 2,075 |  |  |
|  | Investment income, net |  | $ | 418 |  | (c) |  | $ | 4 |  | (d) |  | $ | — |  |  |  | $ | — |  |  |  | $ | — |  |  |  | $ | 422 |  |  |
|  | Tax rate |  | 13 | % |  |  | — | % |  |  | 15 | % |  |  | 7 | % |  |  | N/A |  |  |  | 10 | % |  |
|  | Net income (loss) |  | $ | 2,470 |  |  |  | $ | — |  |  |  | $ | (232 | ) |  |  | $ | (66 | ) |  |  | $ | 66 |  |  |  | $ | 2,238 |  |  |
|  | Diluted EPS |  | $ | 1.44 |  |  |  | $ | 0.00 |  |  |  | $ | (0.14 | ) |  |  | $ | (0.04 | ) |  |  | $ | 0.04 |  |  |  | $ | 1.31 |  |  |

[0001234452-14-000236:8k_2_02:101]
| (a) | Included a $66 million tax benefit related to an agreement reached with the Internal Revenue Service related to transfer pricing on our fiscal 2013 tax return. |

[0001234452-14-000236:8k_2_02:102]
| (b) | Included $184 million of other income from the reversal of accruals related to our litigation with ParkerVision, partially offset by $164 million of impairment charges on goodwill and long-lived assets related to our QMT division. |

[0001234452-14-000236:8k_2_02:103]
| (c) | Included $288 million in net realized gains on investments, $139 million in interest and dividend income and $4 million in gains on deconsolidation of subsidiaries, partially offset by $8 million in other-than-temporary losses on investments and $5 million in net losses on derivatives. |

[0001234452-14-000236:8k_2_02:104]
| (d) | Included $10 million in net realized gains on investments, partially offset by $3 million in other-than-temporary losses on investments, $2 million in equity in losses of investees and $1 million in net losses on derivatives. |

[0001234452-14-000236:8k_2_02:105]
|  | Nine Months Ended June 29, 2014 |  |
|  |  | Non-GAAP Results | QSI | Share-Based Compensation | Acquisition-Related Items | Tax Items (a) | GAAP Results |
| ($ in millions, except per share data) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Cost of equipment and services revenues |  | $ | 7,706 |  |  |  | $ | — |  |  |  | $ | 37 |  |  |  | $ | 186 |  |  |  | $ | — |  |  |  | $ | 7,929 |  |  |
|  | R&D expenses |  | 3,573 |  |  |  | 4 |  |  |  | 510 |  |  |  | 26 |  |  |  | — |  |  |  | 4,113 |  |  |
|  | SG&A expenses |  | 1,455 |  |  |  | 12 |  |  |  | 259 |  |  |  | 19 |  |  |  | — |  |  |  | 1,745 |  |  |
|  | Other expenses, net |  | 450 |  | (e) |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 450 |  |  |
|  | Operating income (loss) |  | 6,611 |  |  |  | (16 | ) |  |  | (806 | ) |  |  | (231 | ) |  |  | — |  |  |  | 5,558 |  |  |
|  | Investment income, net |  | $ | 988 |  | (f) |  | $ | (20 | ) | (g) |  | $ | — |  |  |  | $ | — |  |  |  | $ | — |  |  |  | $ | 968 |  |  |
|  | Tax rate |  | 15 | % |  |  | 56 | % |  |  | 19 | % |  |  | 8 | % |  |  | N/A |  |  |  | 14 | % |  |
|  | Net income (loss) |  | $ | 6,888 |  |  |  | $ | (13 | ) |  |  | $ | (655 | ) |  |  | $ | (213 | ) |  |  | $ | 66 |  |  |  | $ | 6,073 |  |  |
|  | Diluted EPS |  | $ | 4.01 |  |  |  | $ | (0.01 | ) |  |  | $ | (0.38 | ) |  |  | $ | (0.12 | ) |  |  | $ | 0.04 |  |  |  | $ | 3.53 |  |  |

[0001234452-14-000236:8k_2_02:106]
| (e) | Included $607 million of impairment charges on long-lived assets and goodwill related to our QMT division and a $16 million goodwill impairment charge related to our former QRS (Qualcomm Retail Solutions) division, partially offset by the reversal of the $173 million accrual recorded in fiscal 2013 related to our litigation with ParkerVision. |

[0001234452-14-000236:8k_2_02:107]
| (f) | Included $650 million in net realized gains on investments, $459 million in interest and dividend income, $5 million in gains on deconsolidation of subsidiaries and $1 million in net gains on derivatives, partially offset by $124 million in other-than-temporary losses on investments and $3 million in interest expense. |

[0001234452-14-000236:8k_2_02:108]
| (g) | Included $46 million in other-than-temporary losses on investments, $7 million in equity in losses of investees, $2 million in net losses on derivatives and $1 million in interest expense, partially offset by $35 million in net realized gains on investments and $1 million in interest and dividend income. |

[0001234452-14-000236:8k_2_02:109]
N/A - Not Applicable

[0001234452-14-000236:8k_2_02:110]
Sums may not equal totals due to rounding.

[0001234452-14-000236:8k_2_02:111]
Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates (a)

[0001234452-14-000236:8k_2_02:112]
(Unaudited)

[0001234452-14-000236:8k_2_02:113]
| Three Months Ended June 29, 2014 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Acquisition-Related Items |  |  | Tax Items (b) |  |  | GAAP Results |  |
| Income (loss) from continuing operations before income taxes |  | $ | 2,843 |  |  |  | $ | (1 | ) |  |  | $ | (274 | ) |  |  | $ | (71 | ) |  |  | $ | — |  |  |  | $ | 2,497 |  |  |
| Income tax (expense) benefit |  | (373 | ) |  |  | — |  |  |  | 42 |  |  |  | 5 |  |  |  | 66 |  |  |  | (260 | ) |  |
| Income (loss) from continuing operations |  | $ | 2,470 |  |  |  | $ | (1 | ) |  |  | $ | (232 | ) |  |  | $ | (66 | ) |  |  | $ | 66 |  |  |  | $ | 2,237 |  |  |
| Tax rate |  | 13 | % |  |  | — | % |  |  | 15 | % |  |  | 7 | % |  |  | N/A |  |  |  | 10 | % |  |

[0001234452-14-000236:8k_2_02:114]
| Nine Months Ended June 29, 2014 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Acquisition-Related Items |  |  | Tax Items (b) |  |  | GAAP Results |  |
| Income (loss) from continuing operations before income taxes |  | $ | 7,599 |  |  |  | $ | (36 | ) |  |  | $ | (806 | ) |  |  | $ | (231 | ) |  |  | $ | — |  |  |  | $ | 6,526 |  |  |
| Income tax (expense) benefit |  | (1,141 | ) |  |  | 20 |  |  |  | 151 |  |  |  | 18 |  |  |  | 66 |  |  |  | (886 | ) |  |
| Income (loss) from continuing operations |  | $ | 6,458 |  |  |  | $ | (16 | ) |  |  | $ | (655 | ) |  |  | $ | (213 | ) |  |  | $ | 66 |  |  |  | $ | 5,640 |  |  |
| Tax rate |  | 15 | % |  |  | 56 | % |  |  | 19 | % |  |  | 8 | % |  |  | N/A |  |  |  | 14 | % |  |

[0001234452-14-000236:8k_2_02:115]
| (a) | At fiscal year end, the sum of the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is allocated to tax provisions (benefits) among the columns. |

[0001234452-14-000236:8k_2_02:116]
| (b) | During the third quarter of fiscal 2014, we recorded a $66 million tax benefit as a result of an agreement reached with the Internal Revenue Service related to transfer pricing on our fiscal 2013 tax return. |

[0001234452-14-000236:8k_2_02:117]
N/A - Not Applicable

[0001234452-14-000236:8k_2_02:118]
Qualcomm Incorporated

[0001234452-14-000236:8k_2_02:119]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001234452-14-000236:8k_2_02:120]
(In millions, except per share data)

[0001234452-14-000236:8k_2_02:121]
(Unaudited)

[0001234452-14-000236:8k_2_02:122]
|  | June 29, 2014 |  | September 29, 2013 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 7,944 |  |  | $ | 6,142 |  |
| Marketable securities | 10,209 |  |  | 8,824 |  |
| Accounts receivable, net | 2,084 |  |  | 2,142 |  |
| Inventories | 1,185 |  |  | 1,302 |  |
| Deferred tax assets | 451 |  |  | 573 |  |
| Other current assets | 535 |  |  | 572 |  |
| Total current assets | 22,408 |  |  | 19,555 |  |
| Marketable securities | 14,563 |  |  | 14,440 |  |
| Deferred tax assets | 1,195 |  |  | 1,059 |  |
| Property, plant and equipment, net | 2,555 |  |  | 2,995 |  |
| Goodwill | 4,183 |  |  | 3,976 |  |
| Other intangible assets, net | 2,608 |  |  | 2,553 |  |
| Other assets | 843 |  |  | 938 |  |
| Total assets | $ | 48,355 |  |  | $ | 45,516 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,900 |  |  | $ | 1,554 |  |
| Payroll and other benefits related liabilities | 740 |  |  | 839 |  |
| Unearned revenues | 705 |  |  | 501 |  |
| Other current liabilities | 2,676 |  |  | 2,319 |  |
| Total current liabilities | 6,021 |  |  | 5,213 |  |
| Unearned revenues | 3,168 |  |  | 3,666 |  |
| Other liabilities | 379 |  |  | 550 |  |
| Total liabilities | 9,568 |  |  | 9,429 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,678 and 1,685 shares issued and outstanding, respectively | 8,346 |  |  | 9,874 |  |
| Retained earnings | 29,618 |  |  | 25,461 |  |
| Accumulated other comprehensive income | 825 |  |  | 753 |  |
| Total Qualcomm stockholders’ equity | 38,789 |  |  | 36,088 |  |
| Noncontrolling interests | (2 | ) |  | (1 | ) |
| Total stockholders’ equity | 38,787 |  |  | 36,087 |  |
| Total liabilities and stockholders’ equity | $ | 48,355 |  |  | $ | 45,516 |  |

[0001234452-14-000236:8k_2_02:123]
Qualcomm Incorporated

[0001234452-14-000236:8k_2_02:124]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-14-000236:8k_2_02:125]
(In millions, except per share data)

[0001234452-14-000236:8k_2_02:126]
(Unaudited)

[0001234452-14-000236:8k_2_02:127]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | June 29, 2014 |  | June 30, 2013 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 4,922 |  |  | $ | 4,286 |  |  | $ | 13,803 |  |  | $ | 12,474 |  |
| Licensing | 1,884 |  |  | 1,957 |  |  | 5,992 |  |  | 5,911 |  |
| Total revenues | 6,806 |  |  | 6,243 |  |  | 19,795 |  |  | 18,385 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of equipment and services revenues | 2,740 |  |  | 2,497 |  |  | 7,929 |  |  | 7,106 |  |
| Research and development | 1,429 |  |  | 1,298 |  |  | 4,113 |  |  | 3,618 |  |
| Selling, general and administrative | 582 |  |  | 613 |  |  | 1,745 |  |  | 1,861 |  |
| Other | (20 | ) |  | 158 |  |  | 450 |  |  | 158 |  |
| Total costs and expenses | 4,731 |  |  | 4,566 |  |  | 14,237 |  |  | 12,743 |  |
| Operating income | 2,075 |  |  | 1,677 |  |  | 5,558 |  |  | 5,642 |  |
| Investment income, net | 422 |  |  | 233 |  |  | 968 |  |  | 730 |  |
| Income from continuing operations before income taxes | 2,497 |  |  | 1,910 |  |  | 6,526 |  |  | 6,372 |  |
| Income tax expense | (260 | ) |  | (332 | ) |  | (886 | ) |  | (1,028 | ) |
| Income from continuing operations | 2,237 |  |  | 1,578 |  |  | 5,640 |  |  | 5,344 |  |
| Discontinued operations, net of income taxes | — |  |  | — |  |  | 430 |  |  | — |  |
| Net income | 2,237 |  |  | 1,578 |  |  | 6,070 |  |  | 5,344 |  |
| Net loss attributable to noncontrolling interests | 1 |  |  | 2 |  |  | 3 |  |  | 8 |  |
| Net income attributable to Qualcomm | $ | 2,238 |  |  | $ | 1,580 |  |  | $ | 6,073 |  |  | $ | 5,352 |  |
| Basic earnings per share attributable to Qualcomm: |  |  |  |  |  |  |  |
| Continuing operations | $ | 1.33 |  |  | $ | 0.91 |  |  | $ | 3.35 |  |  | $ | 3.11 |  |
| Discontinued operations | — |  |  | — |  |  | 0.25 |  |  | — |  |
| Net income | $ | 1.33 |  |  | $ | 0.91 |  |  | $ | 3.60 |  |  | $ | 3.11 |  |
| Diluted earnings per share attributable to Qualcomm: |  |  |  |  |  |  |  |
| Continuing operations | $ | 1.31 |  |  | $ | 0.90 |  |  | $ | 3.28 |  |  | $ | 3.04 |  |
| Discontinued operations | — |  |  | — |  |  | 0.25 |  |  | — |  |
| Net income | $ | 1.31 |  |  | $ | 0.90 |  |  | $ | 3.53 |  |  | $ | 3.04 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,683 |  |  | 1,727 |  |  | 1,686 |  |  | 1,720 |  |
| Diluted | 1,714 |  |  | 1,765 |  |  | 1,718 |  |  | 1,760 |  |
| Dividends per share announced | $ | 0.42 |  |  | $ | 0.35 |  |  | $ | 1.12 |  |  | $ | 0.85 |  |

[0001234452-14-000236:8k_2_02:128]
Qualcomm Incorporated

[0001234452-14-000236:8k_2_02:129]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-14-000236:8k_2_02:130]
(In millions)

[0001234452-14-000236:8k_2_02:131]
(Unaudited)

[0001234452-14-000236:8k_2_02:132]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | June 29, 2014 |  | June 30, 2013 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 2,237 |  |  | $ | 1,578 |  |  | $ | 6,070 |  |  | $ | 5,344 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 292 |  |  | 255 |  |  | 853 |  |  | 744 |  |
| Gain on sale of discontinued operations | — |  |  | — |  |  | (665 | ) |  | — |  |
| Revenues related to non-monetary exchanges | (31 | ) |  | (31 | ) |  | (93 | ) |  | (93 | ) |
| Long-lived asset and goodwill impairment charges | 164 |  |  | 163 |  |  | 642 |  |  | 191 |  |
| Income tax provision (less than) in excess of income tax payments | (24 | ) |  | 59 |  |  | 244 |  |  | 220 |  |
| Non-cash portion of share-based compensation expense | 274 |  |  | 281 |  |  | 806 |  |  | 831 |  |
| Incremental tax benefits from share-based compensation | (70 | ) |  | (75 | ) |  | (239 | ) |  | (178 | ) |
| Net realized gains on marketable securities and other investments | (298 | ) |  | (60 | ) |  | (685 | ) |  | (239 | ) |
| Impairment losses on marketable securities and other investments | 11 |  |  | 27 |  |  | 170 |  |  | 49 |  |
| Other items, net | 46 |  |  | 5 |  |  | 88 |  |  | 34 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | 139 |  |  | (21 | ) |  | 43 |  |  | (445 | ) |
| Inventories | (37 | ) |  | (245 | ) |  | 116 |  |  | (699 | ) |
| Other assets | 9 |  |  | 90 |  |  | 136 |  |  | (111 | ) |
| Trade accounts payable | 286 |  |  | 221 |  |  | 321 |  |  | 598 |  |
| Payroll, benefits and other liabilities | (235 | ) |  | (151 | ) |  | (337 | ) |  | 52 |  |
| Unearned revenues | (90 | ) |  | (19 | ) |  | (202 | ) |  | (30 | ) |
| Net cash provided by operating activities | 2,673 |  |  | 2,077 |  |  | 7,268 |  |  | 6,268 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (158 | ) |  | (314 | ) |  | (955 | ) |  | (808 | ) |
| Purchases of available-for-sale securities | (2,488 | ) |  | (4,663 | ) |  | (10,315 | ) |  | (12,112 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 4,060 |  |  | 2,805 |  |  | 9,744 |  |  | 7,337 |  |
| Purchases of trading securities | (1,054 | ) |  | (862 | ) |  | (2,868 | ) |  | (2,658 | ) |
| Proceeds from sales and maturities of trading securities | 826 |  |  | 767 |  |  | 2,619 |  |  | 2,365 |  |
| Purchases of other marketable securities | (220 | ) |  | — |  |  | (220 | ) |  | — |  |
| Proceeds from sale of discontinued operations, net of cash sold | — |  |  | — |  |  | 788 |  |  | — |  |
| Acquisitions and other investments, net of cash acquired | (100 | ) |  | (47 | ) |  | (447 | ) |  | (179 | ) |
| Other items, net | 40 |  |  | (2 | ) |  | 102 |  |  | 68 |  |
| Net cash provided (used) by investing activities | 906 |  |  | (2,316 | ) |  | (1,552 | ) |  | (5,987 | ) |
| Financing Activities: |  |  |  |  |  |  |  |
| Borrowing under loans and debentures | — |  |  | 534 |  |  | — |  |  | 534 |  |
| Repayment of loans and debentures | — |  |  | (492 | ) |  | — |  |  | (492 | ) |
| Proceeds from issuance of common stock | 194 |  |  | 217 |  |  | 1,147 |  |  | 964 |  |
| Incremental tax benefits from share-based compensation | 70 |  |  | 75 |  |  | 239 |  |  | 178 |  |
| Repurchases and retirements of common stock | (1,350 | ) |  | (1,039 | ) |  | (3,354 | ) |  | (1,289 | ) |
| Dividends paid | (706 | ) |  | (604 | ) |  | (1,884 | ) |  | (1,463 | ) |
| Other items, net | (184 | ) |  | 37 |  |  | (65 | ) |  | 35 |  |
| Net cash used by financing activities | (1,976 | ) |  | (1,272 | ) |  | (3,917 | ) |  | (1,533 | ) |
| Changes in cash and cash equivalents held for sale | — |  |  | (46 | ) |  | — |  |  | (15 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 4 |  |  | (3 | ) |  | 3 |  |  | (7 | ) |
| Net increase (decrease) in cash and cash equivalents | 1,607 |  |  | (1,560 | ) |  | 1,802 |  |  | (1,274 | ) |
| Cash and cash equivalents at beginning of period | 6,337 |  |  | 4,093 |  |  | 6,142 |  |  | 3,807 |  |
| Cash and cash equivalents at end of period | $ | 7,944 |  |  | $ | 2,533 |  |  | $ | 7,944 |  |  | $ | 2,533 |  |
