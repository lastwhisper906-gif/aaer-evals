# QCOM notes — 0001234452-14-000238


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001234452-14-000238:notes:1]
Note 6 — Commitments and Contingencies

[0001234452-14-000238:notes:2]
Legal Proceedings. Tessera, Inc. v. QUALCOMM Incorporated: On April 17, 2007, Tessera filed a patent infringement lawsuit in the United States District Court for the Eastern District of Texas and a complaint with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company and other companies, alleging infringement of two patents. The district court action was stayed pending resolution of the ITC proceeding, including all appeals. On January 18, 2012, pursuant to the parties’ stipulation, the District Court for the Eastern District of Texas lifted the stay and ordered that the case be moved to the United States District Court for the Northern District of California. On March 27, 2014, Tessera and the Company reached an agreement that the lawsuit against the Company would be dismissed with prejudice, and the parties will engage in discussions to explore potential technical collaborations. The court dismissed the lawsuit on April 1, 2014 based on the parties’ stipulation.

[0001234452-14-000238:notes:3]
ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. The trial began on October 7, 2013. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of approximately $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. On June 25, 2014, ParkerVision filed a notice of appeal with the court. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company has reversed all recorded amounts related to the damages verdict. On May 1, 2014, ParkerVision filed another complaint, captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation and HTC America, Inc., also in the United States District Court for the Middle District of Florida, alleging that certain of the Company’s products infringe seven additional ParkerVision patents. The complaint seeks damages and injunctive and other relief. The Company has not been served with the complaint in this action.

[0001234452-14-000238:notes:4]
Icera Complaint to the European Commission: On June 7, 2010, the European Commission (the Commission) notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. The Company continues to cooperate fully with the Commission’s preliminary investigation.

[0001234452-14-000238:notes:5]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chips and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid in the second quarter of fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court.

[0001234452-14-000238:notes:6]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 23 different dates, with additional hearing dates yet to be scheduled.

[0001234452-14-000238:notes:7]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee has completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.

[0001234452-14-000238:notes:8]
As previously disclosed, the Company discovered, and as a part of its cooperation with these investigations informed the SEC and the DOJ of, instances in which special hiring consideration, gifts or other benefits (collectively, benefits) were provided to several individuals associated with Chinese state-owned companies or agencies. Based on the facts currently known, the Company believes the aggregate monetary value of the benefits in question to be less than $250,000, excluding employment compensation.

[0001234452-14-000238:notes:9]
On March 13, 2014, the Company received a Wells Notice from the SEC’s Los Angeles Regional Office indicating that the staff has made a preliminary determination to recommend that the SEC file an enforcement action against the Company for violations of the anti-bribery, books and records and internal control provisions of the FCPA. The bribery allegations relate to benefits offered or provided to individuals associated with Chinese state-owned companies or agencies. The Wells Notice indicated that the recommendation could involve a civil injunctive action and could seek remedies that include disgorgement of profits, the retention of an independent compliance monitor to review the Company’s FCPA policies and procedures, an injunction, civil monetary penalties and prejudgment interest.

[0001234452-14-000238:notes:10]
A Wells Notice is not a formal allegation or finding by the SEC of wrongdoing or violation of law. Rather, the purpose of a Wells Notice is to give the recipient an opportunity to make a “Wells submission” setting forth reasons why the proposed enforcement action should not be filed and/or bringing additional facts to the SEC’s attention before any decision is made by the SEC as to whether to commence a proceeding. On April 4, 2014 and May 29, 2014, the Company made Wells submissions to the staff of the Los Angeles Regional Office explaining why the Company believes it has not violated the FCPA and therefore enforcement action is not warranted.

[0001234452-14-000238:notes:11]
The Company is continuing to cooperate with the SEC and the DOJ, but is unable to predict the outcome of their investigations or any action that the SEC may decide to file.

[0001234452-14-000238:notes:12]
China National Development and Reform Commission (NDRC) Investigation: In November 2013, the NDRC notified the Company that it had commenced an investigation of the Company relating to the Chinese Anti-Monopoly Law (AML). The Company understands that the investigation concerns primarily the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business, including how royalties are calculated in the Company’s patent licenses, the value exchanged for cross-licenses to patents of the Company’s licensees, whether the Company will offer license agreements limited to patents essential to certain standards, whether royalties are sought for the Company’s expired patents, the Company’s policy of selling chipsets only to the Company’s patent licensees, the alleged refusal of the Company to grant patent licenses to chipset manufacturers, and certain other terms and conditions in the Company’s patent license and chipset sale agreements. A broad range of remedies with respect to business practices deemed to violate the AML is potentially available to the NDRC, including but not limited to issuing an order to cease conduct deemed illegal, confiscating gains deemed illegally obtained, imposing a fine in the range of 1% to 10% of the prior year’s revenues and requiring modifications to business practices. Given the limited precedent of enforcement actions and penalties under the AML, it is difficult to predict the outcome of this matter or what remedies may be imposed by the NDRC. The Company continues to cooperate with the NDRC as it conducts its investigation.

[0001234452-14-000238:notes:13]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at June 29, 2014 for contingent losses associated with these matters based on its belief that, with the exception of the NDRC matter, losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. Regarding the NDRC matter, the Company believes that a loss is probable but that any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001234452-14-000238:notes:14]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through June 29, 2014, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

[0001234452-14-000238:notes:15]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at June 29, 2014 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001234452-14-000238:notes:16]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations, which generally have a remaining term of less than one year, under these agreements at June 29, 2014 for the remainder of fiscal 2014 and for each of the subsequent four years from fiscal 2015 through fiscal 2018 were approximately $3.0 billion, $387 million, $64 million, $19 million and $17 million, respectively, and $40 million thereafter. Of these amounts, for the remainder of fiscal 2014 and for fiscal 2015, commitments to purchase integrated circuit product inventories comprised $2.6 billion and $228 million, respectively. Integrated circuit product inventory obligations represent purchase commitments for wafers, die and assembly and test services. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase orders is generally allowed but requires payment of costs incurred through the date of cancelation.

[0001234452-14-000238:notes:17]
Leases. The future minimum lease payments for all capital leases and operating leases at June 29, 2014 by fiscal year were as follows (in millions):

[0001234452-14-000238:notes:18]
|  | CapitalLeases |  | OperatingLeases |  | Total |
| Remainder of fiscal 2014 | $ | — |  |  | $ | 25 |  |  | $ | 25 |  |
| 2015 | 1 |  |  | 93 |  |  | 94 |  |
| 2016 | 1 |  |  | 79 |  |  | 80 |  |
| 2017 | 1 |  |  | 58 |  |  | 59 |  |
| 2018 | 1 |  |  | 31 |  |  | 32 |  |
| Thereafter | 18 |  |  | 50 |  |  | 68 |  |
| Total minimum lease payments | 22 |  |  | $ | 336 |  |  | $ | 358 |  |
| Deduct: Amounts representing interest | 10 |  |  |  |  |  |
| Present value of minimum lease payments | 12 |  |  |  |  |  |
| Deduct: Current portion of capital lease obligations | 1 |  |  |  |  |  |
| Long-term portion of capital lease obligations | $ | 11 |  |  |  |  |  |

[0001234452-14-000238:notes:19]
The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 25 years and with provisions in certain leases for cost-of-living increases. The Company leases certain property under capital lease agreements primarily related to site leases that have an initial term of five years with renewal options of up to five additional renewal periods. Capital lease obligations are included in other liabilities.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001234452-14-000238:notes:20]
[same as prior period, unchanged from 0001234452-14-000154:notes:20]

[0001234452-14-000238:notes:21]
On November 25, 2013, the Company completed its sale of the North and Latin America operations of its Omnitracs division to a U.S.-based private equity firm for cash consideration of $788 million (net of cash sold). As a result, the Company recorded a gain in discontinued operations of $665 million ($430 million net of income tax expense) during the nine months ended June 29, 2014. Total assets and total liabilities were reduced by $150 million and $45 million, respectively. The revenues and operating results of the North and Latin America operations of the Omnitracs division, which comprised substantially all of the Omnitracs division, were not presented as discontinued operations in any fiscal period because they were immaterial. The related assets (included in other current assets and other noncurrent assets) and liabilities (included in other current liabilities and other noncurrent liabilities) of $139 million and $43 million, respectively, were classified as held for sale at September 29, 2013.


## us-gaap:DividendsDeclaredTableTextBlock

[0001234452-14-000238:notes:22]
During the nine months ended June 29, 2014 and June 30, 2013, dividends charged to retained earnings were as follows (in millions, except per share data):

[0001234452-14-000238:notes:23]
|  | 2014 |  | 2013 |
|  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.35 |  |  | $ | 599 |  |  | $ | 0.25 |  |  | $ | 435 |  |
| Second quarter | 0.35 |  |  | 599 |  |  | 0.25 |  |  | 439 |  |
| Third quarter | 0.42 |  |  | 718 |  |  | 0.35 |  |  | 615 |  |
|  | $ | 1.12 |  |  | $ | 1,916 |  |  | $ | 0.85 |  |  | $ | 1,489 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001234452-14-000238:notes:24]
Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 29, 2014 were 30,642,000 and 31,985,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 30, 2013 were 37,927,000 and 40,132,000, respectively.

[0001234452-14-000238:notes:25]
Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 7,000 and 278,000 during the three and nine months ended June 29, 2014, respectively, and 720,000 and 589,000 during the three and nine months ended June 30, 2013


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001234452-14-000238:notes:26]
[same as prior period, unchanged from 0001234452-14-000154:notes:26]

[0001234452-14-000238:notes:27]
|  | Nine Months Ended June 29, 2014 |  | Nine Months Ended June 30, 2013 |
|  | Auction RateSecurities |  | Mortgage- and Asset-BackedSecurities |  | Auction RateSecurities |  | Mortgage- and Asset-BackedSecurities |
| Beginning balance of Level 3 | $ | 83 |  |  | $ | 239 |  |  | $ | 118 |  |  | $ | 203 |  |
| Total realized and unrealized gains or losses: |  |  |  |  |  |  |  |
| Included in investment income, net | — |  |  | 10 |  |  | — |  |  | 4 |  |
| Included in other comprehensive income | — |  |  | (4 | ) |  | 1 |  |  | (2 | ) |
| Purchases | — |  |  | 86 |  |  | — |  |  | 157 |  |
| Sales | — |  |  | (124 | ) |  | — |  |  | (10 | ) |
| Settlements | — |  |  | (28 | ) |  | (36 | ) |  | (66 | ) |
| Transfers (out of) into Level 3 | — |  |  | (2 | ) |  | — |  |  | 18 |  |
| Ending balance of Level 3 | $ | 83 |  |  | $ | 177 |  |  | $ | 83 |  |  | $ | 304 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001234452-14-000238:notes:28]
[same as prior period, unchanged from 0001234452-14-000154:notes:28]

[0001234452-14-000238:notes:29]
[same as prior period, unchanged from 0001234452-14-000154:notes:29]

[0001234452-14-000238:notes:30]
[same as prior period, unchanged from 0001234452-14-000154:notes:30]

[0001234452-14-000238:notes:31]
[same as prior period, unchanged from 0001234452-14-000154:notes:31]

[0001234452-14-000238:notes:32]
[same as prior period, unchanged from 0001234452-14-000154:notes:32]

[0001234452-14-000238:notes:33]
[same as prior period, unchanged from 0001234452-14-000154:notes:33]

[0001234452-14-000238:notes:34]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at June 29, 2014 (in millions):

[0001234452-14-000238:notes:35]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 2,933 |  |  | $ | 4,235 |  |  | $ | — |  |  | $ | 7,168 |  |
| Marketable securities |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 729 |  |  | 897 |  |  | — |  |  | 1,626 |  |
| Corporate bonds and notes | — |  |  | 14,815 |  |  | — |  |  | 14,815 |  |
| Mortgage- and asset-backed securities | — |  |  | 1,098 |  |  | 177 |  |  | 1,275 |  |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | 83 |  |
| Common and preferred stock | 1,264 |  |  | 742 |  |  | — |  |  | 2,006 |  |
| Equity funds | 681 |  |  | — |  |  | — |  |  | 681 |  |
| Debt funds | 817 |  |  | 3,469 |  |  | — |  |  | 4,286 |  |
| Total marketable securities | 3,491 |  |  | 21,021 |  |  | 260 |  |  | 24,772 |  |
| Derivative instruments | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Other investments | 281 |  |  | — |  |  | — |  |  | 281 |  |
| Total assets measured at fair value | $ | 6,705 |  |  | $ | 25,270 |  |  | $ | 260 |  |  | $ | 32,235 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | 1 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 5 |  |
| Other liabilities | 280 |  |  | — |  |  | — |  |  | 280 |  |
| Total liabilities measured at fair value | $ | 281 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 285 |  |

[0001234452-14-000238:notes:36]
[same as prior period, unchanged from 0001234452-14-000154:notes:36]

[0001234452-14-000238:notes:37]
[same as prior period, unchanged from 0001234452-14-000154:notes:37]

[0001234452-14-000238:notes:38]
[same as prior period, unchanged from 0001234452-14-000154:notes:38]

[0001234452-14-000238:notes:39]
[same as prior period, unchanged from 0001234452-14-000154:notes:39]

[0001234452-14-000238:notes:40]
[same as prior period, unchanged from 0001234452-14-000154:notes:40]

[0001234452-14-000238:notes:41]
[same as prior period, unchanged from 0001234452-14-000154:notes:41]

[0001234452-14-000238:notes:42]
[same as prior period, unchanged from 0001234452-14-000154:notes:42]

[0001234452-14-000238:notes:43]
[same as prior period, unchanged from 0001234452-14-000154:notes:43]

[0001234452-14-000238:notes:44]
Activity between Levels of the Fair Value Hierarchy. There were no significant transfers between Level 1 and Level 2 during the nine months ended June 29, 2014 or June 30, 2013. When a determination is made to classify an asset or liability within Level 3, the determination is based upon the significance of the unobservable inputs to the overall fair value measurement. The following table includes the activity for marketable securities and other liabilities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-14-000238:notes:45]
The Company recognizes transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. Transfers out of Level 3 during the nine months ended June 29, 2014 primarily consisted of debt securities with significant upgrades in credit ratings. Transfers into Level 3 during the nine months ended June 30, 2013 primarily consisted of debt securities with significant inputs that became unobservable as a result of an increased likelihood of a shortfall in contractual cash flows or significant downgrades in credit ratings.

[0001234452-14-000238:notes:46]
Nonrecurring Fair Value Measurements. The Company measures certain assets at fair value on a nonrecurring basis. These assets include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During the nine months ended June 29, 2014, certain long-lived assets and goodwill related to the Company’s QMT division were written down to their estimated fair values resulting in impairment charges of $507 million on long-lived assets and $100 million on goodwill (Note 2). At June 29, 2014, the carrying values of the QMT division’s property, plant and equipment and goodwill were $162 million and $35 million, respectively. The Company determined the fair values primarily using cost, income and market approaches. The estimation of fair values and cash flows used in these fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During the nine months ended June 29, 2014 and June 30, 2013, the Company did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001234452-14-000238:notes:47]
[same as prior period, unchanged from 0001234452-14-000154:notes:47]

[0001234452-14-000238:notes:48]
The Company estimates its annual effective income tax rate for continuing operations to be approximately 14% for fiscal 2014, which is less than the 16% effective income tax rate for fiscal 2013. Tax benefits from foreign income taxed at rates lower than rates in the United States are expected to be approximately 20% in fiscal 2014, compared to 17% in fiscal 2013. The estimated annual effective tax rate for fiscal 2014 reflects the United States federal research and development tax credit generated through December 31, 2013, the date on which the credit expired. The annual effective tax rate for fiscal 2013 included a tax benefit of $64 million related to fiscal 2012 due to the retroactive extension of the United States federal research and development tax credit in fiscal 2013.

[0001234452-14-000238:notes:49]
The Company had unrecognized tax benefits of $85 million and $221 million at June 29, 2014 and September 29, 2013, respectively. The total amount of unrecognized tax benefits decreased due to an agreement reached with the Internal Revenue Service on components of the Company’s fiscal 2013 tax return. As a result, the Company recorded a tax benefit of $66 million in the third quarter of fiscal 2014. Additionally, the Company believes that several other audits will be resolved within the next 12 months, further decreasing the unrecognized tax benefits, which will reduce the effective tax rate to the extent tax benefits are sustained or in the settlement of the liability with the tax authorities to the extent not sustained.


## us-gaap:InterestAndOtherIncomeTextBlock

[0001234452-14-000238:notes:50]
[same as prior period, unchanged from 0001234452-14-000154:notes:50]

[0001234452-14-000238:notes:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | June 29, 2014 |  | June 30, 2013 |
| Interest and dividend income | $ | 139 |  |  | $ | 182 |  |  | $ | 460 |  |  | $ | 529 |  |
| Interest expense | — |  |  | (7 | ) |  | (4 | ) |  | (22 | ) |
| Net realized gains on marketable securities | 290 |  |  | 21 |  |  | 660 |  |  | 189 |  |
| Net realized gains on other investments | 8 |  |  | 39 |  |  | 25 |  |  | 50 |  |
| Impairment losses on marketable securities | (8 | ) |  | (22 | ) |  | (149 | ) |  | (37 | ) |
| Impairment losses on other investments | (3 | ) |  | (5 | ) |  | (21 | ) |  | (12 | ) |
| Net (losses) gains on derivative instruments | (6 | ) |  | 5 |  |  | (1 | ) |  | 17 |  |
| Equity in net losses of investees | (2 | ) |  | (1 | ) |  | (7 | ) |  | (5 | ) |
| Net gains on deconsolidation of subsidiaries | 4 |  |  | 21 |  |  | 5 |  |  | 21 |  |
|  | $ | 422 |  |  | $ | 233 |  |  | $ | 968 |  |  | $ | 730 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001234452-14-000238:notes:52]
At June 29, 2014, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001234452-14-000238:notes:53]
| Years to Maturity |  |  |  |  |
| Less Than One Year |  | One to Five Years |  | Five to Ten Years |  | Greater Than Ten Years |  | No Single Maturity Date |  | Total |
| $ | 2,993 |  |  | $ | 10,255 |  |  | $ | 1,594 |  |  | $ | 660 |  |  | $ | 4,642 |  |  | $ | 20,144 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001234452-14-000238:notes:54]
Note 10 — Marketable Securities

[0001234452-14-000238:notes:55]
Marketable securities were comprised as follows (in millions):

[0001234452-14-000238:notes:56]
|  | Current |  | Noncurrent |
|  | June 29, 2014 |  | September 29, 2013 |  | June 29, 2014 |  | September 29, 2013 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 317 |  |  | $ | 241 |  |  | $ | 47 |  |  | $ | 49 |  |
| Corporate bonds and notes | 195 |  |  | 269 |  |  | 380 |  |  | 256 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 215 |  |  | 104 |  |
| Total trading | 512 |  |  | 510 |  |  | 642 |  |  | 409 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 872 |  |  | 721 |  |  | 390 |  |  | 71 |  |
| Corporate bonds and notes | 6,553 |  |  | 4,533 |  |  | 7,687 |  |  | 6,812 |  |
| Mortgage- and asset-backed securities | 860 |  |  | 745 |  |  | 200 |  |  | 328 |  |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | 83 |  |
| Common and preferred stock | 342 |  |  | 8 |  |  | 1,664 |  |  | 2,351 |  |
| Equity funds | 160 |  |  | — |  |  | 521 |  |  | 960 |  |
| Debt funds | 910 |  |  | 2,307 |  |  | 2,589 |  |  | 2,889 |  |
| Total available-for-sale | 9,697 |  |  | 8,314 |  |  | 13,134 |  |  | 13,494 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 787 |  |  | 537 |  |
| Total marketable securities | $ | 10,209 |  |  | $ | 8,824 |  |  | $ | 14,563 |  |  | $ | 14,440 |  |

[0001234452-14-000238:notes:57]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At June 29, 2014, the Company had an effective ownership interest in the debt fund of 27%. Changes in fair value associated with this investment are recognized in net investment income. During the three and nine months ended June 29, 2014, net increases in fair value associated with this investment were $12 million and $30 million, respectively. During the three months ended June 30, 2013, the net decrease in fair value associated with this investment was $4 million. During the nine months ended June 30, 2013, the net increase in fair value associated with this investment was $14 million.

[0001234452-14-000238:notes:58]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains recognized on debt securities classified as trading held at June 29, 2014 were $7 million and $8 million for the three and nine months ended June 29, 2014, respectively. Net losses recognized on debt securities classified as trading held at June 30, 2013 were $21 million and $36 million for the three and nine months ended June 30, 2013, respectively.

[0001234452-14-000238:notes:59]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities and auction rate securities.

[0001234452-14-000238:notes:60]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001234452-14-000238:notes:61]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| June 29, 2014 | $ | 267 |  |  | $ | (8 | ) |  | $ | 259 |  |
| June 30, 2013 | 52 |  |  | (5 | ) |  | 47 |  |
| For the nine months ended |  |  |  |  |  |
| June 29, 2014 | $ | 610 |  |  | $ | (16 | ) |  | $ | 594 |  |
| June 30, 2013 | 204 |  |  | (14 | ) |  | 190 |  |

[0001234452-14-000238:notes:62]
Available-for-sale securities were comprised as follows (in millions):

[0001234452-14-000238:notes:63]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| June 29, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 2,000 |  |  | $ | 692 |  |  | $ | (5 | ) |  | $ | 2,687 |  |
| Debt securities (including debt funds) | 19,741 |  |  | 423 |  |  | (20 | ) |  | 20,144 |  |
|  | $ | 21,741 |  |  | $ | 1,115 |  |  | $ | (25 | ) |  | $ | 22,831 |  |
| September 29, 2013 |  |  |  |  |  |  |  |
| Equity securities | $ | 2,570 |  |  | $ | 793 |  |  | $ | (44 | ) |  | $ | 3,319 |  |
| Debt securities (including debt funds) | 18,255 |  |  | 396 |  |  | (162 | ) |  | 18,489 |  |
|  | $ | 20,825 |  |  | $ | 1,189 |  |  | $ | (206 | ) |  | $ | 21,808 |  |

[0001234452-14-000238:notes:64]
The following table shows the gross unrealized losses and fair values of the Company’s investments in individual securities that are classified as available-for-sale and have been in a continuous unrealized loss position deemed to be temporary for less than 12 months and for more than 12 months, aggregated by investment category (in millions):

[0001234452-14-000238:notes:65]
|  | June 29, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| Corporate bonds and notes | $ | 2,033 |  |  | $ | (5 | ) |  | $ | 96 |  |  | $ | (2 | ) |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Debt funds | 50 |  |  | (1 | ) |  | 394 |  |  | (11 | ) |
| Equity funds | 30 |  |  | — |  |  | 115 |  |  | (5 | ) |
|  | $ | 2,113 |  |  | $ | (6 | ) |  | $ | 688 |  |  | $ | (19 | ) |

[0001234452-14-000238:notes:66]
|  | September 29, 2013 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 42 |  |  | $ | (1 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 2,084 |  |  | (31 | ) |  | 24 |  |  | (1 | ) |
| Mortgage- and asset-backed securities | 367 |  |  | (5 | ) |  | 24 |  |  | — |  |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Common and preferred stock | 291 |  |  | (41 | ) |  | — |  |  | — |  |
| Debt funds | 2,776 |  |  | (123 | ) |  | 4 |  |  | — |  |
| Equity funds | 82 |  |  | (3 | ) |  | — |  |  | — |  |
|  | $ | 5,642 |  |  | $ | (204 | ) |  | $ | 135 |  |  | $ | (2 | ) |

[0001234452-14-000238:notes:67]
At June 29, 2014, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common and preferred stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

[0001234452-14-000238:notes:68]
The following table shows the activity for the credit loss portion of other-than-temporary impairments on debt securities held by the Company (in millions):

[0001234452-14-000238:notes:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | June 29, 2014 |  | June 30, 2013 |
| Beginning balance of credit losses | $ | 8 |  |  | $ | 8 |  |  | $ | 4 |  |  | $ | 31 |  |
| Reduction in credit losses related to securities the Company intends to sell | — |  |  | — |  |  | — |  |  | (6 | ) |
| Credit losses recognized on securities not previously impaired | — |  |  | — |  |  | 5 |  |  | 1 |  |
| Additional credit losses recognized on securities previously impaired | — |  |  | — |  |  | — |  |  | 1 |  |
| Reductions in credit losses related to securities sold | (3 | ) |  | (3 | ) |  | (4 | ) |  | (21 | ) |
| Accretion of credit losses due to an increase in cash flows expected to be collected | — |  |  | — |  |  | — |  |  | (1 | ) |
| Ending balance of credit losses | $ | 5 |  |  | $ | 5 |  |  | $ | 5 |  |  | $ | 5 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001234452-14-000238:notes:70]
[same as prior period, unchanged from 0001234452-14-000154:notes:70]

[0001234452-14-000238:notes:71]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim data includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 29, 2013. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 29, 2014 and June 30, 2013 included 13 weeks and 39 weeks, respectively.

[0001234452-14-000238:notes:72]
[same as prior period, unchanged from 0001234452-14-000154:notes:72]

[0001234452-14-000238:notes:73]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 29, 2014 were 30,642,000 and 31,985,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 30, 2013 were 37,927,000 and 40,132,000, respectively.

[0001234452-14-000238:notes:74]
Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 7,000 and 278,000 during the three and nine months ended June 29, 2014, respectively, and 720,000 and 589,000 during the three and nine months ended June 30, 2013, respectively.

[0001234452-14-000238:notes:75]
[same as prior period, unchanged from 0001234452-14-000154:notes:75]

[0001234452-14-000238:notes:76]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | June 29, 2014 |  | June 30, 2013 |
| Cost of equipment and services revenues | $ | 12 |  |  | $ | 18 |  |  | $ | 37 |  |  | $ | 55 |  |
| Research and development | 174 |  |  | 166 |  |  | 510 |  |  | 479 |  |
| Selling, general and administrative | 88 |  |  | 96 |  |  | 259 |  |  | 297 |  |
| Share-based compensation expense before income taxes | 274 |  |  | 280 |  |  | 806 |  |  | 831 |  |
| Related income tax benefit | (42 | ) |  | (58 | ) |  | (151 | ) |  | (169 | ) |
|  | $ | 232 |  |  | $ | 222 |  |  | $ | 655 |  |  | $ | 662 |  |

[0001234452-14-000238:notes:77]
The Company recorded $177 million and $152 million in share-based compensation expense during the nine months ended June 29, 2014 and June 30, 2013, respectively, related to share-based awards granted during those periods.

[0001234452-14-000238:notes:78]
At June 29, 2014, total unrecognized compensation costs related to non-vested restricted stock units granted prior to that date were $1.5 billion, which are expected to be recognized over a weighted-average period of 2.0 years. During the nine months ended June 29, 2014 and June 30, 2013, net share-based awards granted, after forfeitures and cancelations, represented 0.8% and 0.7%, respectively, of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.9% and 0.8%, respectively, of outstanding shares as of the end of each fiscal period.

[0001234452-14-000238:notes:79]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers.” ASU 2014-09 outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. ASU 2014-09 will be effective for the Company starting in the first quarter of fiscal 2018. ASU 2014-09 allows for two methods of adoption: (a) “full retrospective” adoption, meaning the standard is applied to all periods presented, or (b) “modified retrospective” adoption, meaning the cumulative effect of applying ASU 2014-09 is recognized as an adjustment to the fiscal 2018 opening retained earnings balance. The Company is in the process of determining the adoption method as well as the effects the adoption of ASU 2014-09 will have on its consolidated financial statements.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001234452-14-000238:notes:80]
| Other Current Liabilities (in millions) |  |  |  |
|  | June 29, 2014 |  | September 29, 2013 |
| Customer incentives and other customer-related liabilities | $ | 2,111 |  |  | $ | 1,706 |  |
| Other | 565 |  |  | 613 |  |
|  | $ | 2,676 |  |  | $ | 2,319 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001234452-14-000238:notes:81]
| Property, Plant and Equipment (in millions) |  |  |  |
|  | June 29, 2014 |  | September 29, 2013 |
| Land | $ | 220 |  |  | $ | 212 |  |
| Buildings and improvements | 1,587 |  |  | 1,733 |  |
| Computer equipment and software | 1,534 |  |  | 1,425 |  |
| Machinery and equipment | 2,200 |  |  | 2,013 |  |
| Furniture and office equipment | 88 |  |  | 87 |  |
| Leasehold improvements | 245 |  |  | 218 |  |
| Construction in progress | 196 |  |  | 480 |  |
|  | 6,070 |  |  | 6,168 |  |
| Less accumulated depreciation and amortization | (3,515 | ) |  | (3,173 | ) |
|  | $ | 2,555 |  |  | $ | 2,995 |  |


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001234452-14-000238:notes:82]
[same as prior period, unchanged from 0001234452-14-000154:notes:81]

[0001234452-14-000238:notes:83]
|  | June 29, 2014 |  | September 29, 2013* |
| QCT | $ | 3,046 |  |  | $ | 3,305 |  |
| QTL | 158 |  |  | 28 |  |
| QSI | 517 |  |  | 511 |  |
| Reconciling items | 44,634 |  |  | 41,672 |  |
| Total consolidated assets | $ | 48,355 |  |  | $ | 45,516 |  |

[0001234452-14-000238:notes:84]
[same as prior period, unchanged from 0001234452-14-000154:notes:83]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001234452-14-000238:notes:85]
[same as prior period, unchanged from 0001234452-14-000154:notes:84]

[0001234452-14-000238:notes:86]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013* |  | June 29, 2014 |  | June 30, 2013* |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 47 |  |  | $ | 156 |  |  | $ | 208 |  |  | $ | 451 |  |
| Intersegment eliminations | (1 | ) |  | (2 | ) |  | (3 | ) |  | (4 | ) |
|  | $ | 46 |  |  | $ | 154 |  |  | $ | 205 |  |  | $ | 447 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of equipment and services revenues | $ | (74 | ) |  | $ | (82 | ) |  | $ | (223 | ) |  | $ | (258 | ) |
| Unallocated research and development expenses | (220 | ) |  | (201 | ) |  | (653 | ) |  | (591 | ) |
| Unallocated selling, general and administrative expenses | (107 | ) |  | (112 | ) |  | (318 | ) |  | (376 | ) |
| Unallocated other income, net | 184 |  |  | — |  |  | 173 |  |  | — |  |
| Unallocated investment income, net | 413 |  |  | 176 |  |  | 985 |  |  | 644 |  |
| Nonreportable segments | (364 | ) |  | (293 | ) |  | (1,218 | ) |  | (568 | ) |
|  | $ | (168 | ) |  | $ | (512 | ) |  | $ | (1,254 | ) |  | $ | (1,149 | ) |

[0001234452-14-000238:notes:87]
Nonreportable segments EBT for the three and nine months ended June 29, 2014 included a total of $164 million and $607 million, respectively, in impairment charges related to the Company’s QMT division (Note 2).

[0001234452-14-000238:notes:88]
[same as prior period, unchanged from 0001234452-14-000154:notes:87]

[0001234452-14-000238:notes:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | June 29, 2014 |  | June 30, 2013 |
| Cost of equipment and services revenues | $ | 62 |  |  | $ | 64 |  |  | $ | 186 |  |  | $ | 203 |  |
| Research and development expenses | 3 |  |  | 1 |  |  | 26 |  |  | 2 |  |
| Selling, general and administrative expenses | 6 |  |  | 6 |  |  | 19 |  |  | 20 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001234452-14-000238:notes:90]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity during the nine months ended June 29, 2014 were as follows (in millions):

[0001234452-14-000238:notes:91]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Total Accumulated Other Comprehensive Income |
| Balance at September 29, 2013 | $ | (115 | ) |  | $ | 25 |  |  | $ | 825 |  |  | $ | 18 |  |  | $ | 753 |  |
| Other comprehensive income before reclassifications | 14 |  |  | 1 |  |  | 356 |  |  | 8 |  |  | 379 |  |
| Reclassifications from accumulated other comprehensive income | 1 |  | (a) | (1 | ) | (a) | (287 | ) | (a) | (20 | ) | (b) | (307 | ) |
| Other comprehensive income (loss) | 15 |  |  | — |  |  | 69 |  |  | (12 | ) |  | 72 |  |
| Balance at June 29, 2014 | $ | (100 | ) |  | $ | 25 |  |  | $ | 894 |  |  | $ | 6 |  |  | $ | 825 |  |

[0001234452-14-000238:notes:92]
| (a) | Reclassifications from accumulated other comprehensive income of $163 million and $287 million for the three and nine months ended June 29, 2014, respectively, were recorded in investment income, net (Note 3). |

[0001234452-14-000238:notes:93]
| (b) | Reclassifications from accumulated other comprehensive income of $7 million and $20 million for the three and nine months ended June 29, 2014, respectively, were recorded in revenues, cost of equipment and services revenues, research and development expenses and selling, general and administrative expenses. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001234452-14-000238:notes:94]
| Inventories (in millions) |  |  |  |
|  | June 29, 2014 |  | September 29, 2013 |
| Raw materials | $ | 2 |  |  | $ | 2 |  |
| Work-in-process | 480 |  |  | 631 |  |
| Finished goods | 703 |  |  | 669 |  |
|  | $ | 1,185 |  |  | $ | 1,302 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001234452-14-000238:notes:95]
[same as prior period, unchanged from 0001234452-14-000154:notes:94]

[0001234452-14-000238:notes:96]
|  | QCT |  | QTL |  | QSI |  | ReconcilingItems |  | Total |
| For the three months ended: |  |  |  |  |  |  |  |  |  |
| June 29, 2014 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 4,957 |  |  | $ | 1,803 |  |  | $ | — |  |  | $ | 46 |  |  | $ | 6,806 |  |
| EBT | 1,116 |  |  | 1,550 |  |  | (1 | ) |  | (168 | ) |  | 2,497 |  |
| June 30, 2013* |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 4,222 |  |  | $ | 1,867 |  |  | $ | — |  |  | $ | 154 |  |  | $ | 6,243 |  |
| EBT | 738 |  |  | 1,633 |  |  | 51 |  |  | (512 | ) |  | 1,910 |  |
| For the nine months ended: |  |  |  |  |  |  |  |  |  |
| June 29, 2014 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 13,816 |  |  | $ | 5,774 |  |  | $ | — |  |  | $ | 205 |  |  | $ | 19,795 |  |
| EBT | 2,762 |  |  | 5,054 |  |  | (36 | ) |  | (1,254 | ) |  | 6,526 |  |
| June 30, 2013* |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 12,258 |  |  | $ | 5,680 |  |  | $ | — |  |  | $ | 447 |  |  | $ | 18,385 |  |
| EBT | 2,487 |  |  | 4,968 |  |  | 66 |  |  | (1,149 | ) |  | 6,372 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001234452-14-000238:notes:97]
Changes in stockholders’ equity for the nine months ended June 29, 2014 were as follows (in millions):

[0001234452-14-000238:notes:98]
|  | Qualcomm Stockholders’ Equity |  | Noncontrolling Interests |  | Total Stockholders’ Equity |
| Balance at September 29, 2013 | $ | 36,088 |  |  | $ | (1 | ) |  | $ | 36,087 |  |
| Net income (loss) (1) | 6,073 |  |  | (3 | ) |  | 6,070 |  |
| Other comprehensive income | 72 |  |  | — |  |  | 72 |  |
| Common stock issued under employee benefit plans and related tax benefits, net of shares withheld for taxes | 987 |  |  | — |  |  | 987 |  |
| Share-based compensation | 838 |  |  | — |  |  | 838 |  |
| Dividends | (1,916 | ) |  | — |  |  | (1,916 | ) |
| Stock repurchases | (3,354 | ) |  | — |  |  | (3,354 | ) |
| Other | 1 |  |  | 2 |  |  | 3 |  |
| Balance at June 29, 2014 | $ | 38,789 |  |  | $ | (2 | ) |  | $ | 38,787 |  |

[0001234452-14-000238:notes:99]
[same as prior period, unchanged from 0001234452-14-000154:notes:98]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001234452-14-000238:notes:100]
[same as prior period, unchanged from 0001234452-14-000154:notes:99]

[0001234452-14-000238:notes:101]
[same as prior period, unchanged from 0001234452-14-000154:notes:100]

[0001234452-14-000238:notes:102]
[same as prior period, unchanged from 0001234452-14-000154:notes:101]

[0001234452-14-000238:notes:103]
[same as prior period, unchanged from 0001234452-14-000154:notes:102]

[0001234452-14-000238:notes:104]
[same as prior period, unchanged from 0001234452-14-000154:notes:103]

[0001234452-14-000238:notes:105]
During the first quarter of fiscal 2014, the Company reassessed its management reporting as a result of the sale of the North and Latin America operations of its Omnitracs division (Note 8), which comprised substantially all of the Omnitracs division, among other reasons. The Omnitracs division was previously aggregated with three other divisions into the Qualcomm Wireless & Internet (QWI) reportable segment. Starting in fiscal 2014, the QWI segment was eliminated, and revenues and operating results for the divisions that comprised the QWI reportable segment are included in nonreportable segments as components of reconciling items. Prior period segment information has been adjusted to conform to the new segment presentation.

[0001234452-14-000238:notes:106]
Nonreportable segments include the Company’s QIS (Qualcomm Internet Services), QGOV (Qualcomm Government Technologies) and QMT (Qualcomm MEMS Technologies) divisions and other display, wireless technology and service initiatives. Nonreportable segments develop and offer products and services that include, but are not limited to: software products and content enablement services to wireless operators; development, other services and related products to U.S. government agencies and their contractors; low power consumption, high optical performance flat display modules; products designed for implementation of small cells; medical device connectivity and related data management; augmented reality; and device-to-device communication.

[0001234452-14-000238:notes:107]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT) from continuing operations. Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization and impairment of certain intangible assets and certain other acquisition-related charges. The table below presents revenues and EBT for reportable segments (in millions):

[0001234452-14-000238:notes:108]
QCT revenues for both of the three and nine months ended June 29, 2014 and June 30, 2013 included $1 million and $3 million of intersegment revenues, respectively. All other revenues for reportable segments were from external customers for all periods presented.

[0001234452-14-000238:notes:109]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets include marketable securities, notes receivable, wireless spectrum, other investments and all assets of consolidated subsidiaries included in QSI. Reconciling items for total consolidated assets included $299 million and $892 million at June 29, 2014 and September 29, 2013, respectively, of goodwill and other assets related to the Company’s QMT division. The decrease in QMT assets was primarily a result of impairments of goodwill and certain property, plant and equipment recorded in the nine months ended June 29, 2014 (Note 2). Total segment assets also differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable securities, property, plant and equipment, deferred tax assets, goodwill, other intangible assets and assets of nonreportable segments. Segment assets and reconciling items were as follows (in millions):


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001234452-14-000238:notes:110]
[same as prior period, unchanged from 0001234452-14-000154:notes:109]

[0001234452-14-000238:notes:111]
Stock Repurchase Program. During the nine months ended June 29, 2014 and June 30, 2013, the Company repurchased and retired 44,609,000 and 21,009,000 shares, respectively, of the Company’s common stock for $3.4 billion and $1.3 billion, respectively, before commissions. On March 4, 2014, the Company announced that it had been authorized to repurchase up to $7.8 billion of the Company’s common stock. The stock repurchase program has no expiration date. At June 29, 2014, approximately $6.5 billion remained available for repurchase.

[0001234452-14-000238:notes:112]
Dividends. On July 18, 2014, the Company announced a cash dividend of $0.42 per share on the Company’s common stock, payable on September 24, 2014 to stockholders of record as of the close of business on September 3, 2014. During the nine months ended June 29, 2014 and June 30, 2013, dividends charged to retained earnings were as follows (in millions, except per share data):


## qcom:CompositionOfCertainFinancialStatementCaptionsTextBlock

[0001234452-14-000238:notes:113]
[same as prior period, unchanged from 0001234452-14-000154:notes:112]

[0001234452-14-000238:notes:114]
During the first quarter of fiscal 2014, as a result of discussions with potential buyers and consideration of alternative uses for the separate asset groups that comprise one of the QMT division’s manufacturing facilities in Taiwan, the Company decreased its estimates of expected cash flows from those assets and recorded an impairment charge of $444 million in other expenses. The Company concluded that a triggering event had not occurred in the first quarter of fiscal 2014 that would have required impairment testing for its remaining QMT assets, including goodwill, as QMT’s licensing business plan did not utilize this manufacturing facility. During the third quarter of fiscal 2014, the Company updated QMT’s licensing business plan and related internal forecasts to reflect a decrease in expected cash flows. The updated business plan reflects an acceleration of the Company’s plans to transition from QMT’s current generation technology to the licensing of its next generation IMOD display technology and to focus on wearable devices. QMT will continue to make and sell current generation products for a period of time in support of certain existing customer requirements. As a result of this triggering event, the Company assessed the recoverability of the QMT division’s long-lived assets, performed a goodwill impairment test of the QMT reporting unit and recorded impairment charges of $64 million on long-lived assets and $100 million on goodwill in other expenses in the third quarter of fiscal 2014. At June 29, 2014, the carrying values of the QMT division’s goodwill and property, plant and equipment were $35 million and $162 million, respectively, including $44 million in property, plant and equipment that was classified as held for sale and included in other assets.
