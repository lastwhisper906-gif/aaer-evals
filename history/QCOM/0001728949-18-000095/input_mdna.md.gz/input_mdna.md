# QCOM MD&A — 0001728949-18-000095


## mdna

[0001728949-18-000095:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001728949-18-000095:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes included in “Part II, Item 8. Financial Statements and Supplementary Data” of this Annual Report.

[0001728949-18-000095:mdna:3]
Fiscal 2018 Overview

[0001728949-18-000095:mdna:4]
Revenues were $22.7 billion, an increase of 2% from fiscal 2017, with net loss attributable to Qualcomm of $4.9 billion, compared to net income of $2.5 billion in fiscal 2017. Highlights and other events from fiscal 2018 included:

[0001728949-18-000095:mdna:5]
| • | The transition of wireless networks and devices to 3G/4G (CDMA-single mode, OFDMA-single mode and CDMA/OFDMA multi-mode) continued around the world. 3G/4G connections increased to approximately 5.5 billion, up 17% year-over-year, and represent approximately 69% of total mobile connections at the end of fiscal 2018, up from 60% at the end of fiscal 2017.(1) |

[0001728949-18-000095:mdna:6]
| • | We continue to invest significant resources toward advancements primarily in support of 4G- and 5G-based technologies as well as other technologies to extend the demand for our products and generate new or expanded licensing opportunities, including within adjacent industry segments outside traditional cellular industries, such as automotive, the Internet of Things (IoT) and networking. |

[0001728949-18-000095:mdna:7]
| • | QCT results in fiscal 2018 were positively impacted by results from our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017, and higher demand from OEMs in China, partially offset by lower modem sales to Apple. |

[0001728949-18-000095:mdna:8]
| • | QTL results were negatively impacted by our continued dispute with Apple and its contract manufacturers (who are Qualcomm licensees). We did not record any revenues in fiscal 2018 for royalties due on sales of Apple’s products. QTL revenues in fiscal 2018 included $600 million paid under an interim agreement with the other licensee in dispute (which dispute was previously disclosed). This represents a partial payment for royalties due after the second quarter of fiscal 2017 by that other licensee while negotiations continue. This payment does not reflect the full amount of royalties due under the underlying license agreement. |

[0001728949-18-000095:mdna:9]
| • | In the first quarter of fiscal 2018, tax reform legislation known as the Tax Cuts and Jobs Act (the Tax Legislation) was enacted in the United States. As a result of such enactment, net loss for fiscal 2018 included an estimated $5.7 billion charge to income tax expense, comprised of a one-time tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge) of $5.2 billion and a charge of $438 million resulting from the remeasurement of deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate tax rate Further, our federal statutory income tax rate for fiscal 2018 reflected a blended rate of approximately 25%. |

[0001728949-18-000095:mdna:10]
| • | In January 2018, the European Commission (EC) issued a decision finding that certain terms of an agreement with Apple violate European Union competition law and imposed a fine of 997 million Euros ($1.2 billion), which was recorded as a charge to other expenses in the first quarter of fiscal 2018. We provided financial guarantees to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. |

[0001728949-18-000095:mdna:11]
| • | In the second quarter of fiscal 2018, we announced a Cost Plan designed to align our cost structure to our long-term margin targets, under which we continue to execute on a series of targeted actions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. We expect these cost reductions to be fully captured in fiscal 2019. We recorded restructuring and restructuring-related charges of $687 million in fiscal 2018 related to our Cost Plan. |

[0001728949-18-000095:mdna:12]
| • | In the fourth quarter of fiscal 2018, we reached a settlement with the Taiwan Fair Trade Commission (TFTC) resolving the TFTC’s investigation alleging that we violated the Taiwan Fair Trade Act. As a result of the settlement, the parties agreed that the amounts we paid towards the previously imposed fine will be retained by the TFTC, and no other amounts will be due. As a result, in the fourth quarter of fiscal 2018 we reversed the remaining $676 million accrual that was initially recorded in fiscal 2017 as a benefit to other expense. |

[0001728949-18-000095:mdna:13]
| • | In the fourth quarter of fiscal 2018, we terminated the definitive agreement under which we proposed to acquire NXP Semiconductors N.V. (NXP). In accordance with the terms of the purchase agreement, we paid NXP a termination fee of $2.0 billion, which was recorded as a charge to other expense in the fourth quarter of fiscal 2018. |

[0001728949-18-000095:mdna:14]
41

[0001728949-18-000095:mdna:15]
| • | In the fourth quarter of fiscal 2018, following the termination of our agreement to acquire NXP, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock, the large majority of which we expect to complete by the end of fiscal 2019. In August 2018, we completed a tender offer and paid an aggregate of $5.1 billion to repurchase 76.2 million shares of our common stock. In September 2018, we entered into three accelerated share repurchase agreements to repurchase an aggregate of $16.0 billion of our common stock resulting in an initial delivery to us of 178.4 million shares of our common stock. |

[0001728949-18-000095:mdna:16]
| (1) | According to GSMA Intelligence estimates as of November 5, 2018 (estimates excluded Wireless Local Loop). |

[0001728949-18-000095:mdna:17]
Our Business and Operating Segments

[0001728949-18-000095:mdna:18]
We develop and commercialize foundational technologies and products used in mobile devices and other wireless products, including network equipment, broadband gateway equipment and consumer electronics devices. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents, software and other rights.

[0001728949-18-000095:mdna:19]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices, wireless networks, devices used in IoT, broadband gateway equipment, consumer electronic devices and automotive telematics and infotainment systems. QTL grants licenses to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including our cyber security solutions (formerly Qualcomm Government Technologies or QGOV), mobile health, small cells and other wireless technology and service initiatives.

[0001728949-18-000095:mdna:20]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering, research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001728949-18-000095:mdna:21]
Further information regarding our business and operating segments is provided in “Part I, Item 1. Business” of this Annual Report.

[0001728949-18-000095:mdna:22]
Seasonality. Many of our products and/or much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has tended historically to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons. Similarly, because QTL has historically recognized royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made in the fourth calendar quarter. These trends may or may not continue in the future, in part depending on the amount of QCT revenues from modem sales for iPhone products and QTL royalties on sales of Apple’s products, both of which have been significant drivers of our historical seasonality. Further, starting in the first quarter of fiscal 2019, seasonal trends for QTL will be impacted by the adoption of the new guidance related to revenue recognition pursuant to which we will be required to estimate and recognize sales-based royalties in the period in which the associated sales occur, resulting in an acceleration of revenue recognition by one quarter compared to the current method.

[0001728949-18-000095:mdna:23]
We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 4G networks by wireless operators and the timing of launches of flagship wireless devices and consumer demand for wireless devices that incorporate our products and/or intellectual property. The seasonal trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees.

[0001728949-18-000095:mdna:24]
Results of Operations

[0001728949-18-000095:mdna:25]
| Revenues (in millions) |  |  |  |  |  |
|  | 2018 |  | 2017 |  | 2016 |  | 2018 vs. 2017 Change |  | 2017 vs. 2016 Change |
| Equipment and services | $ | 17,400 |  |  | $ | 16,647 |  |  | $ | 15,467 |  |  | $ | 753 |  |  | $ | 1,180 |  |
| Licensing | 5,332 |  |  | 5,644 |  |  | 8,087 |  |  | (312 | ) |  | (2,443 | ) |
|  | $ | 22,732 |  |  | $ | 22,291 |  |  | $ | 23,554 |  |  | $ | 441 |  |  | $ | (1,263 | ) |

[0001728949-18-000095:mdna:26]
2018 vs. 2017

[0001728949-18-000095:mdna:27]
The increase in revenues in fiscal 2018 was primarily due to:

[0001728949-18-000095:mdna:28]
| + | $962 million reduction to licensing revenues recorded in fiscal 2017 related to the BlackBerry arbitration |

[0001728949-18-000095:mdna:29]
| + | $745 million in higher equipment and services revenues from our QCT segment |

[0001728949-18-000095:mdna:30]
| - | $1.3 billion in lower licensing revenues from our QTL segment |

[0001728949-18-000095:mdna:31]
| - | $100 million reduction to licensing revenues recorded in fiscal 2018 related to a portion of a business arrangement that resolved a legal dispute |

[0001728949-18-000095:mdna:32]
2017 vs. 2016

[0001728949-18-000095:mdna:33]
The increase in revenues in fiscal 2017 was primarily due to:

[0001728949-18-000095:mdna:34]
| + | $1.1 billion in higher equipment and services revenues from our QCT segment |

[0001728949-18-000095:mdna:35]
| + | $66 million in higher equipment and services revenues from our QSI segment |

[0001728949-18-000095:mdna:36]
| - | $1.2 billion in lower licensing revenues from our QTL segment |

[0001728949-18-000095:mdna:37]
| - | $962 million reduction to licensing revenues recorded in fiscal 2017 related to the BlackBerry arbitration |

[0001728949-18-000095:mdna:38]
| - | $103 million in lower licensing revenues of one of our nonreportable segments |

[0001728949-18-000095:mdna:39]
Revenue Concentrations

[0001728949-18-000095:mdna:40]
In fiscal 2018, revenues from Samsung Electronics, Xiaomi Corporation and suppliers to Apple Inc. each comprised more than 10% of consolidated revenues. In fiscal 2018 and 2017, combined revenues from GuangDong OPPO Mobile Telecommunications Corp. Ltd. and vivo Communication Technology Co., Ltd., and their respective affiliates, also comprised more than 10% of consolidated revenues. In fiscal 2017 and 2016, revenues from Samsung Electronics and suppliers to Apple Inc. each comprised more than 10% of consolidated revenues. QCT and QTL segment revenues related to the products of these customers/licensees comprised 52%, 58% and 54% of total consolidated revenues in fiscal 2018, 2017 and 2016, respectively.

[0001728949-18-000095:mdna:41]
Revenues from customers in China (including Hong Kong) and South Korea comprised 67% and 14%, respectively, of total consolidated revenues for fiscal 2018, compared to 65% and 16%, respectively, for fiscal 2017, and 57% and 17%, respectively, for fiscal 2016. We report revenues from external customers by country based on the location to which our products or services are delivered, which for QCT is generally the country in which our customers manufacture their products, or for licensing revenues, the invoiced addresses of our licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues could include revenues related to shipments of integrated circuits for a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States.

[0001728949-18-000095:mdna:42]
| Costs and Expenses (in millions) |  |  |  |  |  |
|  | 2018 |  | 2017 |  | 2016 |  | 2018 vs. 2017 Change |  | 2017 vs. 2016 Change |
| Cost of revenues | $ | 10,244 |  |  | $ | 9,792 |  |  | $ | 9,749 |  |  | $ | 452 |  |  | $ | 43 |  |
| Gross margin | 55 | % |  | 56 | % |  | 59 | % |  |  |  |  |

[0001728949-18-000095:mdna:43]
2018 vs. 2017

[0001728949-18-000095:mdna:44]
The decrease in margin percentage in fiscal 2018 was primarily due to:

[0001728949-18-000095:mdna:45]
| - | decrease in higher margin QTL licensing revenues as a proportion of total revenues |

[0001728949-18-000095:mdna:46]
| - | reduction to licensing revenues recorded in fiscal 2018 related to a portion of a business arrangement that resolved a legal dispute |

[0001728949-18-000095:mdna:47]
| + | reduction to licensing revenues recorded in fiscal 2017 related to the BlackBerry arbitration |

[0001728949-18-000095:mdna:48]
2017 vs. 2016

[0001728949-18-000095:mdna:49]
The decrease in margin percentage in fiscal 2017 was primarily due to:

[0001728949-18-000095:mdna:50]
| - | decrease in higher margin QTL licensing revenues as a proportion of total revenues |

[0001728949-18-000095:mdna:51]
| - | reduction to licensing revenues recorded in fiscal 2017 related to the BlackBerry arbitration |

[0001728949-18-000095:mdna:52]
| + | increase in QCT margin |

[0001728949-18-000095:mdna:53]
Our margin percentage may continue to fluctuate in future periods depending on the mix of segment results as well as products sold, competitive pricing, new product introduction costs and other factors, including disputes and/or resolutions with licensees.

[0001728949-18-000095:mdna:54]
43

[0001728949-18-000095:mdna:55]
|  | 2018 |  | 2017 |  | 2016 |  | 2018 vs. 2017 Change |  | 2017 vs. 2016 Change |
| Research and development | $ | 5,625 |  |  | $ | 5,485 |  |  | $ | 5,151 |  |  | $ | 140 |  |  | $ | 334 |  |
| % of revenues | 25 | % |  | 25 | % |  | 22 | % |  |  |  |  |

[0001728949-18-000095:mdna:56]
2018 vs. 2017

[0001728949-18-000095:mdna:57]
The dollar increase in research and development expenses in fiscal 2018 was primarily due to:

[0001728949-18-000095:mdna:58]
| + | $168 million, net of cost decreases driven by actions initiated under our Cost Plan, in higher costs related to the development of wireless and integrated circuit technologies, including 5G technologies and RFFE technologies from our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017, and related software products |

[0001728949-18-000095:mdna:59]
| - | $30 million impairment charge on certain intangible assets recorded in fiscal 2017 |

[0001728949-18-000095:mdna:60]
2017 vs. 2016

[0001728949-18-000095:mdna:61]
The dollar increase in research and development expenses in fiscal 2017 was primarily due to:

[0001728949-18-000095:mdna:62]
| + | $372 million, net of cost decreases driven by actions initiated under our 2015 Strategic Realignment Plan, in higher costs related to the development of integrated circuit technologies, including 5G technologies and RFFE technologies from our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017, and related software products |

[0001728949-18-000095:mdna:63]
In fiscal 2018, all of the costs ($474 million) related to pre-commercial research and development of 5G technologies were included in unallocated corporate research and development expenses. Beginning in the first quarter of fiscal 2019, all research and development costs associated with 5G technologies will be included in segment results. Additionally, beginning in the first quarter of fiscal 2019, certain research and development costs associated with early research and development that have historically been included in our QCT segment will be allocated to our QTL segment. The net effect of these changes is expected to negatively impact QTL’s EBT in fiscal 2019 by approximately $500 million and to not have a significant impact on QCT EBT in fiscal 2019.

[0001728949-18-000095:mdna:64]
|  | 2018 |  | 2017 |  | 2016 |  | 2018 vs. 2017 Change |  | 2017 vs. 2016 Change |
| Selling, general and administrative | $ | 2,986 |  |  | $ | 2,658 |  |  | $ | 2,385 |  |  | $ | 328 |  |  | $ | 273 |  |
| % of revenues | 13 | % |  | 12 | % |  | 10 | % |  |  |  |  |

[0001728949-18-000095:mdna:65]
2018 vs. 2017

[0001728949-18-000095:mdna:66]
The dollar increase in selling, general and administrative expenses in fiscal 2018 was primarily due to:

[0001728949-18-000095:mdna:67]
| + | $325 million in higher litigation costs, with total litigation costs of $554 million and $229 million in fiscal 2018 and fiscal 2017, respectively |

[0001728949-18-000095:mdna:68]
| + | $45 million in bad debt expense recorded in fiscal 2018 |

[0001728949-18-000095:mdna:69]
| + | $42 million in higher professional fees and costs related to other legal matters, which was primarily driven by Broadcom’s withdrawn takeover proposal, partially offset by lower third-party acquisition and integration services fees |

[0001728949-18-000095:mdna:70]
| - | $40 million in lower amortization, primarily from our RF360 Holdings joint venture |

[0001728949-18-000095:mdna:71]
| - | $37 million in lower share-based compensation expense, primarily due to actions initiated under our Cost Plan |

[0001728949-18-000095:mdna:72]
2017 vs. 2016

[0001728949-18-000095:mdna:73]
The dollar increase in selling, general and administrative expenses in fiscal 2017 was primarily due to:

[0001728949-18-000095:mdna:74]
| + | $136 million in higher professional services fees, primarily related to third-party acquisition and integration services resulting from the proposed acquisition of NXP |

[0001728949-18-000095:mdna:75]
| + | $70 million in higher costs related to litigation and other legal matters |

[0001728949-18-000095:mdna:76]
| + | $33 million in higher employee-related expenses, primarily related to our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017 |

[0001728949-18-000095:mdna:77]
|  | 2018 |  | 2017 |  | 2016 |  | 2018 vs. 2017 Change |  | 2017 vs. 2016 Change |
| Other | $ | 3,135 |  |  | $ | 1,742 |  |  | $ | (226 | ) |  | $ | 1,393 |  |  | $ | 1,968 |  |

[0001728949-18-000095:mdna:78]
2018

[0001728949-18-000095:mdna:79]
Other expenses in fiscal 2018 consisted of:

[0001728949-18-000095:mdna:80]
+    $2.0 billion charge related to the NXP termination fee

[0001728949-18-000095:mdna:81]
+    $1.2 billion charge related to the EC fine

[0001728949-18-000095:mdna:82]
+    $629 million in restructuring and restructuring-related charges related to our Cost Plan

[0001728949-18-000095:mdna:83]
-    $676 million benefit related to the settlement of the TFTC investigation

[0001728949-18-000095:mdna:84]
2017

[0001728949-18-000095:mdna:85]
Other expenses in fiscal 2017 consisted of:

[0001728949-18-000095:mdna:86]
| + | $927 million charge related to the Korea Fair Trade Commission (KFTC) fine, including related foreign currency losses |

[0001728949-18-000095:mdna:87]
+    $778 million charge related to the TFTC fine

[0001728949-18-000095:mdna:88]
+    $37 million in restructuring and restructuring-related charges related to our 2015 Strategic Realignment Plan

[0001728949-18-000095:mdna:89]
2016

[0001728949-18-000095:mdna:90]
Other income in fiscal 2016 consisted of:

[0001728949-18-000095:mdna:91]
+    $380 million gain on the sale of wireless spectrum

[0001728949-18-000095:mdna:92]
+    $48 million gain on the sale of our business that provided augmented reality applications

[0001728949-18-000095:mdna:93]
-    $202 million in restructuring and restructuring-related charges related to our 2015 Strategic Realignment Plan

[0001728949-18-000095:mdna:94]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | 2018 |  | 2017 |  | 2016 |  | 2018 vs. 2017 Change |  | 2017 vs. 2016 Change |
| Interest expense | $ | 768 |  |  | $ | 494 |  |  | $ | 297 |  |  | $ | 274 |  |  | $ | 197 |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 625 |  |  | $ | 619 |  |  | $ | 611 |  |  | $ | 6 |  |  | $ | 8 |  |
| Net realized gains on marketable securities | 41 |  |  | 456 |  |  | 239 |  |  | (415 | ) |  | 217 |  |
| Net realized gains on other investments | 83 |  |  | 74 |  |  | 49 |  |  | 9 |  |  | 25 |  |
| Impairment losses on marketable securities and other investments | (75 | ) |  | (177 | ) |  | (172 | ) |  | 102 |  |  | (5 | ) |
| Equity in net losses of investees | (145 | ) |  | (74 | ) |  | (84 | ) |  | (71 | ) |  | 10 |  |
| Net gains (losses) on foreign currency transactions | 37 |  |  | (30 | ) |  | — |  |  | 67 |  |  | (30 | ) |
| Net (losses) gains on derivative instruments | (27 | ) |  | 32 |  |  | (8 | ) |  | (59 | ) |  | 40 |  |
|  | $ | 539 |  |  | $ | 900 |  |  | $ | 635 |  |  | $ | (361 | ) |  | $ | 265 |  |

[0001728949-18-000095:mdna:95]
The increases in interest expense in fiscal 2018 and 2017 were primarily due to the issuance of an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes in May 2017 (May 2017 Notes), of which $4.0 billion were repaid between May and August 2018, and fees related to the Bridge and Term Loan Facilities entered into during the first quarter of fiscal 2017, which terminated in July 2018. In the first quarter of fiscal 2017, we began divesting a substantial portion of our marketable securities portfolio in order to finance, in part, the then proposed acquisition of NXP. As a result, we recorded net realized gains and impairment losses on such marketable securities that we sold and expected to sell before their anticipated recovery, respectively, in fiscal 2017. The net gains on foreign currency transactions in fiscal 2018, which were partially offset by losses on derivative instruments, were primarily attributable to currency exchange rate movements on amounts accrued for the EC and TFTC fines, as well as the impact of currency exchange rate movements on certain monetary assets and liabilities of our RF360 Holdings joint venture.

[0001728949-18-000095:mdna:96]
| Income Tax Expense (in millions) |  |  |  |  |  |
|  | 2018 |  | 2017 |  | 2016 |  | 2018 vs. 2017 Change |  | 2017 vs. 2016 Change |
| Income tax expense | $ | 5,377 |  |  | $ | 555 |  |  | $ | 1,131 |  |  | $ | 4,822 |  |  | $ | (576 | ) |
| Effective tax rate | N/M |  |  | 18 | % |  | 17 | % |  |  |  |  |  |  |

[0001728949-18-000095:mdna:97]
N/M - Not meaningful

[0001728949-18-000095:mdna:98]
45

[0001728949-18-000095:mdna:99]
The following table summarizes the primary factors that caused our annual tax provision to differ from the expected income tax provision at the United States federal statutory rate (in millions):

[0001728949-18-000095:mdna:100]
|  | 2018 |  | 2017 |  | 2016 |
| Expected income tax provision at federal statutory tax rate | $ | 127 |  |  | $ | 1,057 |  |  | $ | 2,392 |  |
| State income tax provision, net of federal benefit | 2 |  |  | 8 |  |  | 19 |  |
| Toll Charge from U.S. tax reform | 5,236 |  |  | — |  |  | — |  |
| Benefits from foreign income taxed at other than U.S. rates | (834 | ) |  | (963 | ) |  | (1,068 | ) |
| Valuation allowance on deferred tax asset related to NXP termination fee | 494 |  |  | — |  |  | — |  |
| Remeasurement of deferred taxes due to changes in statutory rate due to U.S. tax reform | 438 |  |  | — |  |  | — |  |
| Benefits related to research and development tax credits | (136 | ) |  | (81 | ) |  | (143 | ) |
| Nondeductible charges and reversals related to the EC, KFTC and TFTC investigations | (119 | ) |  | 363 |  |  | — |  |
| Taxes on undistributed foreign earnings | 87 |  |  | — |  |  | — |  |
| Impact of changes in tax reserves and audit settlements for prior year tax positions | — |  |  | 111 |  |  | — |  |
| Worthless stock deduction of domestic subsidiary | — |  |  | — |  |  | (101 | ) |
| Other | 82 |  |  | 60 |  |  | 32 |  |
| Income tax expense | $ | 5,377 |  |  | $ | 555 |  |  | $ | 1,131 |  |

[0001728949-18-000095:mdna:101]
The Tax Cuts and Jobs Act (the Tax Legislation) in the United States enacted on December 22, 2017 significantly revised the United States corporate income tax by, among other things, lowering the corporate income tax rate to 21% effective January 1, 2018, implementing a modified territorial tax system and imposing a one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge). As a fiscal-year taxpayer, certain provisions of the Tax Legislation impacted us in fiscal 2018, including the change in the corporate income tax rate and the Toll Charge, while other provisions will be effective starting at the beginning of fiscal 2019, including the implementation of a modified territorial tax system. Accordingly, our federal statutory income tax rate for fiscal 2018 reflected a blended rate of approximately 25%.

[0001728949-18-000095:mdna:102]
As a result of the Tax Legislation, we recorded a charge of $5.7 billion to income tax expense in fiscal 2018, comprised of $5.2 billion related to the estimated Toll Charge and $438 million resulting from the remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate, which included a  $135 million tax benefit in fiscal 2018 related to the remeasurement of a U.S. deferred tax liability that was established as a result of a change in one of our positions due to Tax Legislation.

[0001728949-18-000095:mdna:103]
Income tax expense for fiscal 2018 was further negatively impacted by the charge recorded in the fourth quarter of fiscal 2018 related to the termination fee paid to NXP, which did not result in a tax benefit after the consideration of realizability of such loss. Fiscal 2018 and 2017 income tax expense was also impacted by the EC, KFTC and TFTC fines, and settlement with the TFTC, which are not deductible for tax purposes and portions of which were attributable to foreign jurisdictions and to the United States. These impacts were partially offset in fiscal 2018 and 2017 by lower U.S. revenues primarily related to decreased royalty revenues from Apple’s contract manufacturers and, for fiscal 2017, the BlackBerry arbitration.

[0001728949-18-000095:mdna:104]
Income tax expense for fiscal 2017 also reflected the increase in our Singapore tax rate as a result of the expiration of certain of our tax incentives in March 2017, which was substantially offset by tax benefits resulting from the increase in our Singapore tax rate that will be in effect when certain deferred tax assets are scheduled to reverse. During the third quarter of fiscal 2018, we entered into a new tax incentive agreement in Singapore that results in a reduced tax rate from March 2017 through March 2022, provided that we meet specified employment and investment criteria in Singapore. Our Singapore tax rate will increase in March 2022 as a result of expiration of these incentives and again in March 2027 upon the expiration of tax incentives under a prior agreement. As a result of this new tax incentive, our income tax expense for fiscal 2018 was reduced by approximately $130 million.

[0001728949-18-000095:mdna:105]
Unrecognized tax benefits were $217 million and $372 million at September 30, 2018 and September 24, 2017, respectively. The decrease in unrecognized tax benefits in fiscal 2018 was primarily due to an agreement with the IRS related to tax positions on the classification of income in our fiscal 2016 federal income tax return. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at September 30, 2018 may increase or decrease in the next 12 months.

[0001728949-18-000095:mdna:106]
46

[0001728949-18-000095:mdna:107]
As a result of the Tax Legislation, in fiscal 2019, several of our foreign subsidiaries will make tax elections to be treated as U.S. branches for federal income tax purposes (commonly referred to as “check-the-box” elections) effective beginning in fiscal 2018 and 2019. We believe that, by these foreign subsidiaries being treated as U.S. branches for federal income taxes, rather than controlled foreign corporations, we will significantly reduce the risk of being subject to GILTI (global intangible low-taxed income) and BEAT (base-erosion anti-abuse tax) taxes, both of which are effective for us starting in fiscal 2019. As a result of making these check-the-box elections in the first quarter of fiscal 2019, we expect to record an estimated tax benefit of $525 million to $575 million due to establishing new U.S. net deferred tax assets resulting from the difference between the GAAP basis and the U.S. federal tax carryover basis of the existing assets and liabilities of those foreign subsidiaries, primarily related to customer incentive liabilities that have not been deducted for tax purposes.

[0001728949-18-000095:mdna:108]
We are subject to income taxes in the United States and numerous foreign jurisdictions and are currently under examination by various tax authorities worldwide, most notably in countries where we earn a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of September 30, 2018, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0001728949-18-000095:mdna:109]
Segment Results

[0001728949-18-000095:mdna:110]
The following should be read in conjunction with the fiscal 2018, 2017 and 2016 results of operations for each reportable segment included in this Annual Report in “Notes to Consolidated Financial Statements, Note 8. Segment Information.”

[0001728949-18-000095:mdna:111]
QCT Segment

[0001728949-18-000095:mdna:112]
| (in millions) | 2018 |  | 2017 |  | 2016 |  | 2018 vs. 2017 Change |  | 2017 vs. 2016 Change |
| Revenues |  |  |  |  |  |  |  |  |  |
| Equipment and services | $ | 17,060 |  |  | $ | 16,315 |  |  | $ | 15,183 |  |  | $ | 745 |  |  | $ | 1,132 |  |
| Licensing | 222 |  |  | 164 |  |  | 226 |  |  | 58 |  |  | (62 | ) |
| Total revenues | $ | 17,282 |  |  | $ | 16,479 |  |  | $ | 15,409 |  |  | $ | 803 |  |  | $ | 1,070 |  |
| EBT (1) | $ | 2,966 |  |  | $ | 2,747 |  |  | $ | 1,812 |  |  | $ | 219 |  |  | $ | 935 |  |
| EBT as a % of revenues | 17 | % |  | 17 | % |  | 12 | % |  | — |  |  | 5 | % |

[0001728949-18-000095:mdna:113]
| (1) | Earnings (loss) before taxes. |

[0001728949-18-000095:mdna:114]
Equipment and services revenues mostly relate to sales of Mobile Station Modem (MSM) and accompanying Radio Frequency (RF), Power Management (PM) and wireless connectivity integrated circuits. Approximately 855 million, 804 million and 842 million MSM integrated circuits were sold during fiscal 2018, 2017 and 2016, respectively.

[0001728949-18-000095:mdna:115]
2018 vs. 2017

[0001728949-18-000095:mdna:116]
The increase in QCT equipment and services revenues in fiscal 2018 was primarily due to:

[0001728949-18-000095:mdna:117]
| + | $825 million in higher RFFE product revenues primarily related to revenues from our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017, and reflected the impact of eliminating a one-month reporting lag in fiscal 2018 |

[0001728949-18-000095:mdna:118]
| + | $737 million in higher MSM and accompanying unit shipments primarily due to by higher demand from OEMs in China, partially offset by a decline in share at Apple |

[0001728949-18-000095:mdna:119]
| - | $719 million decrease due to lower average selling prices and unfavorable product mix |

[0001728949-18-000095:mdna:120]
| - | $83 million in lower connectivity product revenues |

[0001728949-18-000095:mdna:121]
QCT EBT as a percentage of revenues remained flat in fiscal 2018 primarily due to an unchanged gross margin percentage, driven by the net effect of lower average selling prices and lower-margin product mix, offset by lower average unit costs.

[0001728949-18-000095:mdna:122]
QCT accounts receivable decreased by 25% in fiscal 2018 from $1.81 billion to $1.36 billion, primarily due to the timing of integrated circuit shipments. QCT inventories decreased by 17% in fiscal 2018 from $2.02 billion to $1.68 billion primarily due to a decrease in the overall quantity of units on hand.

[0001728949-18-000095:mdna:123]
47

[0001728949-18-000095:mdna:124]
2017 vs. 2016

[0001728949-18-000095:mdna:125]
The increase in QCT equipment and services revenues in fiscal 2017 was primarily due to:

[0001728949-18-000095:mdna:126]
| + | $676 million in higher RFFE revenues, primarily related to revenues from our RF360 Holdings joint venture |

[0001728949-18-000095:mdna:127]
| + | $492 million increase due to higher shipments of connectivity products primarily related to adjacent industry segments outside of traditional cellular industries |

[0001728949-18-000095:mdna:128]
| + | $469 million increase due to the net impact of higher-priced product mix and lower average selling prices |

[0001728949-18-000095:mdna:129]
| - | $553 million decrease primarily due to lower MSM and accompanying RF and PM unit shipments driven primarily by a decline in share at Apple, partially offset by higher demand from OEMs in China |

[0001728949-18-000095:mdna:130]
QCT EBT as a percentage of revenues increased in fiscal 2017 primarily due to:

[0001728949-18-000095:mdna:131]
| + | increase in gross margin percentage primarily driven by higher-margin product mix and lower average unit costs, partially offset by lower average selling prices and higher excess inventory charges |

[0001728949-18-000095:mdna:132]
| - | a combined increase of 1% in research and development and selling, general and administrative expenses primarily related to our RF360 Holdings joint venture |

[0001728949-18-000095:mdna:133]
QTL Segment

[0001728949-18-000095:mdna:134]
| (in millions) | 2018 |  | 2017 |  | 2016 |  | 2018 vs. 2017 Change |  | 2017 vs. 2016 Change |
| Licensing revenues | $ | 5,163 |  |  | $ | 6,445 |  |  | $ | 7,664 |  |  | $ | (1,282 | ) |  | $ | (1,219 | ) |
| EBT | $ | 3,525 |  |  | $ | 5,175 |  |  | $ | 6,528 |  |  | $ | (1,650 | ) |  | $ | (1,353 | ) |
| EBT as a % of revenues | 68 | % |  | 80 | % |  | 85 | % |  | (12 | %) |  | (5 | %) |

[0001728949-18-000095:mdna:135]
QTL results in fiscal 2018 and fiscal 2017 were negatively impacted by our continued dispute with Apple and its contract manufacturers (who are our licensees). We did not record any revenues in fiscal 2018 or the third or fourth quarter of fiscal 2017 for royalties due on sales of Apple’s products. QTL revenues in fiscal 2018 included $600 million paid under an interim agreement with the other licensee in dispute. This represents a partial payment for royalties due after the second quarter of fiscal 2017 by that other licensee while negotiations continue, and it does not reflect the full amount of royalties due under the underlying license agreement. We did not record any revenues in the third or fourth quarter of fiscal 2017 for royalties due on the sales of the other licensee’s products, and the other licensee underpaid royalties due in the second quarter of fiscal 2017, which negatively impacted QTL revenues by an estimated amount in excess of $150 million. Royalty revenues related to the products of Apple’s contract manufacturers and the other licensee in dispute were approximately $1.7 billion in fiscal 2017. Revenues related to the products of Apple’s contract manufacturers and the other licensee in dispute comprised a total of approximately $1.35 billion in the third and fourth quarters of fiscal 2016.

[0001728949-18-000095:mdna:136]
2018 vs. 2017

[0001728949-18-000095:mdna:137]
Excluding the impact of the aforementioned continued dispute with Apple and its contract manufacturers, as well as the dispute with the other licensee, QTL licensing revenues in fiscal 2018 further decreased primarily due to:

[0001728949-18-000095:mdna:138]
| - | $177 million in lower royalty revenues recognized related to devices sold in prior periods from certain other licensees |

[0001728949-18-000095:mdna:139]
QTL EBT as a percentage of revenue decreased in fiscal 2018 primarily due to:

[0001728949-18-000095:mdna:140]
| - | higher selling, general and administrative expenses resulting primarily from higher litigation costs |

[0001728949-18-000095:mdna:141]
| - | lower QTL revenues |

[0001728949-18-000095:mdna:142]
QTL accounts receivable decreased by 15% in fiscal 2018 from $1.74 billion to $1.47 billion, primarily due to the timing of the collection of payments from certain of our licensees.

[0001728949-18-000095:mdna:143]
2017 vs. 2016

[0001728949-18-000095:mdna:144]
Excluding the impact of the aforementioned continued dispute with Apple and its contract manufacturers, as well as the with the other licensee, QTL licensing revenues in fiscal 2017 increased primarily due to:

[0001728949-18-000095:mdna:145]
| + | higher royalty revenues recognized related to devices sold in prior periods |

[0001728949-18-000095:mdna:146]
| + | higher revenues per unit |

[0001728949-18-000095:mdna:147]
| - | recognition of revenues in fiscal 2016 relating to the termination of an infrastructure license agreement resulting from the merger of two licensees |

[0001728949-18-000095:mdna:148]
| - | lower recognition of unearned license fees |

[0001728949-18-000095:mdna:149]
QTL EBT as a percentage of revenue decreased in fiscal 2017 primarily due to the decrease in QTL revenues.

[0001728949-18-000095:mdna:150]
QSI Segment

[0001728949-18-000095:mdna:151]
| (in millions) | 2018 |  | 2017 |  | 2016 |  | 2018 vs. 2017 Change |  | 2017 vs. 2016 Change |
| Equipment and services revenues | $ | 100 |  |  | $ | 113 |  |  | $ | 47 |  |  | $ | (13 | ) |  | $ | 66 |  |
| EBT | $ | 24 |  |  | $ | 65 |  |  | $ | 386 |  |  | $ | (41 | ) |  | $ | (321 | ) |

[0001728949-18-000095:mdna:152]
2018 vs. 2017

[0001728949-18-000095:mdna:153]
The decrease in QSI EBT in fiscal 2018 was primarily due to:

[0001728949-18-000095:mdna:154]
| - | $14 million decrease in net gains on investments |

[0001728949-18-000095:mdna:155]
| - | $14 million increase in our share of losses in equity method investments |

[0001728949-18-000095:mdna:156]
| - | $13 million decrease resulting from lower revenues from certain development contracts with one of our equity method investees |

[0001728949-18-000095:mdna:157]
2017 vs. 2016

[0001728949-18-000095:mdna:158]
The decrease in QSI EBT in fiscal 2017 was primarily due to:

[0001728949-18-000095:mdna:159]
| - | $380 million gain recorded in fiscal 2016 from the sale of wireless spectrum |

[0001728949-18-000095:mdna:160]
| + | $41 million increase resulting from higher revenues and costs associated with certain development contracts with one of our equity method investees |

[0001728949-18-000095:mdna:161]
Looking Forward

[0001728949-18-000095:mdna:162]
In the coming years, we expect continued growth in consumer demand for 3G/4G multi-mode and 4G products and services and new consumer demand for 5G products and services around the world, driven primarily by smartphones. We also expect growth in new device categories and industries, driven by the expanding adoption of certain technologies that are already commonly used in smartphones by industry segments outside traditional cellular industries, such as automotive, IoT and networking.

[0001728949-18-000095:mdna:163]
As we look forward to the next several months and beyond, we expect our business to be impacted by the following key items:

[0001728949-18-000095:mdna:164]
| • | In the second quarter of fiscal 2018, we announced a cost plan designed to align our cost structure to our long-term margin targets. As part of this plan, we continue to execute on a series of targeted actions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. We expect these cost reductions to be fully captured in fiscal 2019. In connection with this plan, we expect to incur additional restructuring and restructuring-related charges of up to $100 million, and we incurred $687 million in restructuring and restructuring-related charges in fiscal 2018. |

[0001728949-18-000095:mdna:165]
| • | Regulatory authorities in certain jurisdictions continue to investigate our business practices, and other regulatory authorities may do so in the future. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business with remedies that include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Additionally, certain of our direct and indirect customers and licensees, including Apple, have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have in the past had a material adverse effect on our business and could in the future have a material adverse effect on our business including, among others, monetary damages, the loss of our ability to enforce one or more of our patents, and/or portions of our license agreements could be determined to be invalid or unenforceable. These activities have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs until the respective matters are resolved. See “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies” and “Risk Factors” included in this Annual Report. |

[0001728949-18-000095:mdna:166]
| • | We are currently in dispute with Apple surrounding what we believe is an attempt by Apple to reduce the amount of royalties that its contract manufacturers (who are our licensees) are required to pay to us for use of our intellectual property. In fiscal 2018, such contract manufacturers did not fully report, and did not pay, royalties due on sales of Apple products. We have taken action against Apple’s contract manufacturers to compel them to pay the required royalties, and against Apple, as described more fully in this Annual Report in “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies.” We did not record any revenues in fiscal 2018 or in the third and fourth quarters of fiscal 2017 for royalties due on sales of Apple’s products, and as a result, QTL revenues and EBT were negatively impacted by these continued disputes. We expect these companies will continue to take such actions in the future, resulting in increased legal costs and negatively impacting our future revenues, as well as our financial condition, results of operations and cash flows until the respective disputes are resolved. In the third |

[0001728949-18-000095:mdna:167]
49

[0001728949-18-000095:mdna:168]
quarter of fiscal 2018, we entered into an interim agreement with the other licensee in dispute in which that licensee agreed to pay $700 million as partial payment for royalties due after the second quarter of fiscal 2017. That licensee paid $600 million in fiscal 2018 as a partial payment while negotiations continue. This payment does not reflect the full amount of royalties due under the underlying license agreement. If we do not reach a final agreement with that other licensee, it may not make any other payments or may not make full payments under the underlying license agreement, which may result in increased legal costs, due to exercising the dispute resolution provision in the license agreement, and will negatively impact our future revenues, as well as our financial condition, results of operations and cash flows until the dispute is resolved.

[0001728949-18-000095:mdna:169]
| • | To position QTL for stability on a long-term basis, we have announced that our cellular standard-essential patent only licensing terms, including 3G, 4G and 5G through Release 15 for both single mode and multi-mode devices worldwide, will remain at the same rate, consistent with our licensing program established in China for 3G and 4G devices. A number of our licensees have entered into cellular standard-essential patent only agreements on a worldwide basis, and we expect more of our licensees may enter into such cellular standard-essential patent only agreements in the future. In addition, in fiscal 2018, we have reduced the per unit royalty cap on smartphones, which is the base on which our royalties are calculated. While we expect these developments to enhance stability for the long term, they will negatively impact QTL royalty revenues. |

[0001728949-18-000095:mdna:170]
| • | We expect our business, particularly QCT, to continue to be impacted by industry dynamics, including: |

[0001728949-18-000095:mdna:171]
| • | Concentration of device share among a few companies within the premium tier, resulting in significant supply chain leverage for those companies, and exacerbating the negative impact to our business and financial results if any of those companies do not utilize our chipsets; |

[0001728949-18-000095:mdna:172]
| • | Decisions by companies to utilize their own internally-developed integrated circuit products and/or sell such products to others, including by bundling with other products, increasing competition; |

[0001728949-18-000095:mdna:173]
| • | Decisions by certain companies to utilize our competitors’ integrated circuit products in all or a portion of their devices. For example, we have not been the sole supplier of modems for iPhone products beginning with products that launched in September 2016, as Apple utilizes modems from one or more of our competitors in a portion of such devices. Apple is solely using one or more of our competitors’ modems, rather than our modems, in its 2018 iPhone release and may take similar actions in the future. Accordingly, QCT revenues from modem sales for iPhones have declined in fiscal 2018, are expected to further decline in fiscal 2019 and may fluctuate in the future, in part depending on the extent of Apple’s utilization of competitors’ modems and the mix of the various versions of its products that are sold. Overall, QCT revenues, as well as profitability, may similarly decline unless offset by sales of integrated circuit products to other customers, including those outside of traditional cellular industries, such as the IoT, automotive and networking. Apple’s sourcing of integrated circuit products does not impact our licensing revenues since our licensing revenues from Apple products are not dependent upon whether such products include our chipsets; |

[0001728949-18-000095:mdna:174]
| • | Intense competition, particularly in China, as our competitors expand their product offerings and/or reduce the prices of their products as part of a strategy to attract new and/or retain existing customers; |

[0001728949-18-000095:mdna:175]
| • | Continued growth of device share by Chinese OEMs in China and in regions outside of China; |

[0001728949-18-000095:mdna:176]
| • | Lengthening replacement cycles in developed regions, where the smartphone industry is mature, premium-tier smartphones are common and consumer demand is increasingly driven by new product launches and/or innovation cycles; |

[0001728949-18-000095:mdna:177]
| • | Lengthening replacement cycles in emerging regions as smartphone penetration increases; and |

[0001728949-18-000095:mdna:178]
| • | Increasing consumer demand for 3G/4G smartphone products in emerging regions driven by availability of lower-tier 3G/4G devices. |

[0001728949-18-000095:mdna:179]
| • | Current U.S./China trade relations may negatively impact our business, growth prospects and results of operations. |

[0001728949-18-000095:mdna:180]
| • | We expect the ongoing rollout of 4G services in emerging regions will encourage competition and growth, bringing the benefits of 3G/4G LTE multi-mode to consumers. |

[0001728949-18-000095:mdna:181]
| • | We continue to invest significant resources to develop our wireless baseband chips, and our converged computing/communications (Snapdragon) chipsets, which incorporate technologies in the following areas, among others: advancements in 4G and 5G, OFDM-based Wi-Fi, RFFE, connectivity, power management, graphics, audio and |

[0001728949-18-000095:mdna:182]
50

[0001728949-18-000095:mdna:183]
video codecs, multimedia, artificial intelligence (AI) and virtual/augmented reality, and all of which contribute to the expansion of our intellectual property portfolio. We are also investing in targeted opportunities that leverage our existing technical and business expertise to deploy new business models and enter and/or expand into new industry segments and applications, such as products for automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), networking, computing and AI, such as machine learning, among others.

[0001728949-18-000095:mdna:184]
| • | We expect initial commercial 5G network deployments and device launches to begin in calendar 2019. We believe that 5G technologies will empower a new era of smartphones and connected devices. We also believe that 5G will drive transformation across industries beyond traditional cellular communications that will create new business models and new services. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing of 5G technologies, and to be a leading developer and supplier of 5G integrated circuit products and services in order to sustain and grow our business long term. |

[0001728949-18-000095:mdna:185]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless value chain and governments as to the benefits of our licensing program and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not welcome the success of our licensing program in enabling new, highly cost-effective competitors to their products. We expect that such companies, and/or governments or regulators, will continue to challenge our business model in various forums throughout the world.

[0001728949-18-000095:mdna:186]
Further discussion of risks related to our business is presented in “Part I, Item 1A. Risk Factors” included in this Annual Report.

[0001728949-18-000095:mdna:187]
Liquidity and Capital Resources

[0001728949-18-000095:mdna:188]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. The following table presents selected financial information related to our liquidity as of and for the years ended September 30, 2018 and September 24, 2017 (in millions):

[0001728949-18-000095:mdna:189]
|  | 2018 |  | 2017 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 12,123 |  |  | $ | 38,578 |  |  | $ | (26,455 | ) |  | (69 | %) |
| Accounts receivable, net | 2,904 |  |  | 3,632 |  |  | (728 | ) |  | (20 | %) |
| Inventories | 1,693 |  |  | 2,035 |  |  | (342 | ) |  | (17 | %) |
| Short-term debt | 1,005 |  |  | 2,495 |  |  | (1,490 | ) |  | (60 | %) |
| Long-term debt | 15,365 |  |  | 19,398 |  |  | (4,033 | ) |  | (21 | %) |
| Net cash provided by operating activities | 3,895 |  |  | 5,001 |  |  | (1,106 | ) |  | (22 | %) |
| Net cash provided by investing activities | 4,381 |  |  | 18,463 |  |  | (14,082 | ) |  | (76 | %) |
| Net cash (used) provided by financing activities | (31,487 | ) |  | 5,571 |  |  | (37,058 | ) |  | N/M |  |

[0001728949-18-000095:mdna:190]
N/M = Not meaningful

[0001728949-18-000095:mdna:191]
The net decrease in cash, cash equivalents and marketable securities was primarily due to $22.6 billion in payments to repurchase shares of our common stock, $5.5 billion in repayment of long-term debt, $3.5 billion in cash dividends paid and $784 million in capital expenditures, partially offset by net cash provided by operating activities and the release of the restriction on $2.0 billion of deposits used to collateralize the letters of credit related to our proposed acquisition of NXP upon termination of the letters of credit. Net cash provided by operating activities decreased primarily due to the $2.0 billion termination fee paid to NXP and the continued actions taken by Apple and its contract manufacturers who did not report or pay royalties due in fiscal 2018, partially offset by the effect of the $940 million payment in connection with the BlackBerry arbitration in fiscal 2017 and the $927 million payment of the fine related to the KFTC investigation in fiscal 2017.

[0001728949-18-000095:mdna:192]
Our days sales outstanding, on a consolidated basis, decreased to 49 days at September 30, 2018 compared to 56 days at September 24, 2017. The decrease in accounts receivable and the related days sales outstanding were primarily due to the timing of integrated circuit shipments and the collection of receivables from certain licensees. The decrease in inventories was primarily due to a decrease in the overall quantity of units on hand.

[0001728949-18-000095:mdna:193]
Debt. Our 2016 Amended and Restated Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in the aggregate amount of $5.0 billion, of which $530 million and $4.47 billion will expire

[0001728949-18-000095:mdna:194]
in February 2020 and November 2021, respectively. At September 30, 2018, no amounts were outstanding under the revolving credit facility.

[0001728949-18-000095:mdna:195]
We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At September 30, 2018, we had $1.0 billion of commercial paper outstanding with weighted-average net interest rates of 2.35% and weighted-average remaining days to maturity of 16 days.

[0001728949-18-000095:mdna:196]
In July 2018, as a result of our termination of the NXP acquisition, the 2018 Revolving Credit Facility, 2016 Term Loan Facility and 2018 Term Loan Facility that were established primarily to fund the proposed acquisition of NXP were terminated in accordance with their terms. We had not borrowed any funds under these facilities. In addition, upon our payment of the NXP termination fee, the four letters of credit for which we had deposited aggregate funds of $2.0 billion as collateral for the potential termination fee payable to NXP were terminated, and we were no longer restricted from using the funds.

[0001728949-18-000095:mdna:197]
In May 2017, we issued an aggregate principal amount of $11.0 billion in nine tranches of unsecured floating- and fixed-rate notes, with maturity dates starting in 2019 through 2047. Effective interest rates were between 2.70% and 4.47% at September 30, 2018. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001728949-18-000095:mdna:198]
In May 2018, we initiated private offerings to exchange and repurchase certain of our notes issued in May 2017 that were subject to special mandatory redemption provisions that required redemption on the first to occur of (i) the termination of the NXP purchase agreement or (ii) June 1, 2018 if the NXP transaction had not closed as of such date. We exchanged $122 million of notes and repurchased $71 million of notes in the aggregate. In July 2018, we repurchased $3.8 billion of notes subject to the special mandatory redemption provisions that were not exchanged in the May 2018 private offerings. In August 2018, subsequent to the termination of the NXP purchase agreement, we repurchased the $122 million of new notes issued in May 2018.

[0001728949-18-000095:mdna:199]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, of which $8.5 billion remains outstanding with maturity dates in 2020 through 2045. Effective interest rates were between 2.93% and 4.73% at September 30, 2018. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001728949-18-000095:mdna:200]
We may issue additional debt in the future. The amount and timing of such additional debt will be subject to a number of factors, including the cash flow generated by our operations, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001728949-18-000095:mdna:201]
Additional information regarding our outstanding debt at September 30, 2018 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 6. Debt.”

[0001728949-18-000095:mdna:202]
Income Taxes. The Tax Legislation, which was signed into law during the first quarter of fiscal 2018, resulted in an estimated $5.2 billion charge related to the Toll Charge. We currently estimate that we will pay $2.5 billion for the Toll Charge after application of certain tax credits, which is payable in installments over eight years (8% in each of the first five years, 15% in year six, 20% in year seven and 25% in year eight) beginning on January 15, 2019. This amount may be reduced by excess tax benefits generated in fiscal 2019.

[0001728949-18-000095:mdna:203]
We have historically asserted our intention to indefinitely reinvest the operating earnings of certain non-U.S. subsidiaries outside the United States based on our plans for use and/or investment outside of the United States and our belief that our sources of cash and liquidity in the United States would be sufficient to meet future domestic cash needs. The Tax Legislation eliminated certain material tax effects on the repatriation of cash to the United States. Future repatriation of cash and other property held by our foreign subsidiaries will generally not be subject to U.S. federal income tax. As a result, we reevaluated our historic assertion, and as of September 30, 2018, we no longer consider substantially all of our foreign earnings to be indefinitely reinvested in our foreign subsidiaries.

[0001728949-18-000095:mdna:204]
Additional information regarding our income taxes is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 3. Income Taxes.”

[0001728949-18-000095:mdna:205]
Capital Return Program. The following table summarizes stock repurchases, before commissions, and dividends paid during fiscal 2018, 2017 and 2016 (in millions, except per-share amounts):

[0001728949-18-000095:mdna:206]
|  |  | Stock Repurchase Program |  | Dividends |  | Total |
|  |  | Shares |  | Average Price Paid Per Share (1) |  | Amount |  | Per Share |  | Amount |  | Amount |
| 2018 |  | 278.8 |  |  | $ | 65.41 |  |  | $ | 22,569 |  |  | $ | 2.38 |  |  | $ | 3,466 |  |  | $ | 26,035 |  |
| 2017 |  | 22.8 |  |  | 58.87 |  |  | 1,342 |  |  | 2.20 |  |  | 3,252 |  |  | 4,594 |  |
| 2016 |  | 73.8 |  |  | 53.16 |  |  | 3,922 |  |  | 2.02 |  |  | 2,990 |  |  | 6,912 |  |

[0001728949-18-000095:mdna:207]
| (1) | Average Price Paid Per Share in fiscal 2018 excludes the impact of the three accelerated share repurchase agreements executed in September 2018 as the final number of shares and average purchase price will be determined at the end of the applicable purchase periods. |

[0001728949-18-000095:mdna:208]
In the fourth quarter of fiscal 2018, following the termination of the agreement to acquire NXP, we announced a stock repurchase program authorizing us to repurchase up to $30.0 billion of our common stock, the large majority of which we expect to complete by the end of fiscal 2019. This replaced the existing $10.0 billion stock repurchase authorization announced on May 9, 2018. In August 2018, we completed a “modified Dutch auction” tender offer and paid an aggregate of $5.1 billion, excluding fees and related expenses, to repurchase 76.2 million shares of our common stock. In September 2018, we entered into three accelerated share repurchase agreements (ASR Agreements) to repurchase an aggregate of $16.0 billion of our common stock. During the fourth quarter of fiscal 2018, 178.4 million shares were initially delivered to us under the ASR Agreements and were retired. Pursuant to the terms of the ASR Agreements, the final number of shares and the average purchase price will be determined at the end of the applicable purchase periods, which are scheduled to occur in August 2019 but may occur earlier in certain circumstances. At September 30, 2018, $8.9 billion remained authorized for repurchase under our stock repurchase program. Since September 30, 2018, we repurchased and retired 8.5 million shares of common stock for $542 million.

[0001728949-18-000095:mdna:209]
Our stock repurchase program has significantly reduced and will continue to reduce the amount of cash that we have available to fund our operations including research and development, working capital, capital expenditures, acquisitions, investments, dividends and other corporate purposes; and increases our exposure to adverse economic, market, industry and competitive conditions and developments, and other changes in our business and our industry. This stock repurchase program has no expiration date. However, we periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders and may accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-18-000095:mdna:210]
On October 23, 2018, we announced a cash dividend of $0.62 per share on our common stock, payable on December 20, 2018 to stockholders of record as of the close of business on December 6, 2018. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-18-000095:mdna:211]
Additional Capital Requirements. We believe our cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements, in addition to the above matters, also include the items described below.

[0001728949-18-000095:mdna:212]
| • | We expect the majority of the charges incurred in connection with our Cost Plan will result in cash payments. Our restructuring accrual was $83 million at September 30, 2018, and we expect to incur additional restructuring and restructuring-related charges of up to $100 million. |

[0001728949-18-000095:mdna:213]
| • | Our purchase obligations at September 30, 2018, some of which relate to research and development activities and capital expenditures, totaled $3.7 billion and $630 million for fiscal 2019 and 2020, respectively, and $210 million thereafter. |

[0001728949-18-000095:mdna:214]
| • | Our research and development expenditures were $5.6 billion in fiscal 2018 and $5.5 billion in fiscal 2017, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications. |

[0001728949-18-000095:mdna:215]
| • | Cash outflows for capital expenditures were $784 million in fiscal 2018 and $690 million in fiscal 2017. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001728949-18-000095:mdna:216]
53

[0001728949-18-000095:mdna:217]
| • | The EC imposed a fine on us, of which $1.2 billion was accrued at September 30, 2018 (based on the exchange rate at September 30, 2018, including related foreign currency gains and accrued interest). In the third quarter of 2018, we provided financial guarantees in lieu of cash payment to satisfy the obligation while we appeal the EU’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. |

[0001728949-18-000095:mdna:218]
| • | In August 2019, we have the option to acquire (and the minority owner has the option to sell) the minority ownership interest in the RF360 Holdings joint venture for $1.15 billion. The accreted value of such amount was included in other current liabilities at September 30, 2018. |

[0001728949-18-000095:mdna:219]
| • | We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly, to open new opportunities for our technologies, obtain development resources, grow our patent portfolio or pursue new businesses. |

[0001728949-18-000095:mdna:220]
Contractual Obligations/Off-Balance Sheet Arrangements

[0001728949-18-000095:mdna:221]
We have no significant contractual obligations not fully recorded on our consolidated balance sheets or fully disclosed in the notes to our consolidated financial statements. We have no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001728949-18-000095:mdna:222]
The following table summarizes the payments due by fiscal period for our outstanding contractual obligations at September 30, 2018 (in millions):

[0001728949-18-000095:mdna:223]
|  | Total |  | 2019 |  | 2020-2021 |  | 2022-2023 |  | Beyond2023 |  | NoExpirationDate |
| Purchase obligations (1) | $ | 4,513 |  |  | $ | 3,673 |  |  | $ | 794 |  |  | $ | 45 |  |  | $ | 1 |  |  | $ | — |  |
| Operating lease obligations | 413 |  |  | 117 |  |  | 169 |  |  | 84 |  |  | 43 |  |  | — |  |
| Capital lease obligations (2) | 31 |  |  | 14 |  |  | 16 |  |  | 1 |  |  | — |  |  | — |  |
| Equity funding and financing commitments (3) | 316 |  |  | 35 |  |  | 75 |  |  | 8 |  |  | — |  |  | 198 |  |
| Long-term debt (4) | 15,500 |  |  | — |  |  | 2,000 |  |  | 4,000 |  |  | 9,500 |  |  | — |  |
| Other long-term liabilities (5)(6) | 3,318 |  |  | 337 |  |  | 560 |  |  | 225 |  |  | 1,708 |  |  | 488 |  |
| Total contractual obligations | $ | 24,091 |  |  | $ | 4,176 |  |  | $ | 3,614 |  |  | $ | 4,363 |  |  | $ | 11,252 |  |  | $ | 686 |  |

[0001728949-18-000095:mdna:224]
| (1) | Total purchase obligations included commitments to purchase integrated circuit product inventories of $2.6 billion, $322 million, $62 million and $24 million for each of the four years from fiscal 2019 through 2022, respectively; there were no such purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization. |

[0001728949-18-000095:mdna:225]
| (2) | Amounts represent future minimum lease payments including interest payments. Capital lease obligations were included in other current liabilities and other noncurrent liabilities in the consolidated balance sheet at September 30, 2018. The future lease payments related to our RF360 Holdings joint venture manufacturing facility under construction (Note 7) have not been presented in the table above as the lease term will commence upon completion of the construction project. |

[0001728949-18-000095:mdna:226]
| (3) | Certain of these commitments do not have fixed funding dates and are subject to certain conditions and have, therefore, been presented as having no expiration date. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all. |

[0001728949-18-000095:mdna:227]
| (4) | The amounts noted herein represent contractual payments of principal only. |

[0001728949-18-000095:mdna:228]
| (5) | Certain long-term liabilities reflected on our balance sheet, such as unearned revenues, are not presented in this table because they do not require cash settlement in the future. Other long-term liabilities as presented in this table include the related current portions, as applicable. |

[0001728949-18-000095:mdna:229]
| (6) | Our consolidated balance sheet at September 30, 2018 included $123 million in other noncurrent liabilities for uncertain tax positions, some of which may result in cash payment. The future payments related to uncertain tax positions recorded as other noncurrent liabilities have not been presented in the table above due to the uncertainty of the amounts and timing of cash settlement with the taxing authorities. |

[0001728949-18-000095:mdna:230]
Additional information regarding our financial commitments at September 30, 2018 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 3. Income Taxes,” “Note 6. Debt” and “Note 7. Commitments and Contingencies.”

[0001728949-18-000095:mdna:231]
Critical Accounting Estimates

[0001728949-18-000095:mdna:232]
The preparation of our consolidated financial statements in accordance with accounting principles generally accepted in the United States requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and disclosure of contingent assets and liabilities. We base our estimates on historical and anticipated results and trends and on various other assumptions that we believe are reasonable under the circumstances, including assumptions as to future events. By their nature, estimates are subject to an inherent degree of uncertainty. Although we believe that our estimates and the assumptions supporting our assessments are reasonable, actual results that differ from our estimates could be material to our consolidated financial statements. A summary of our significant accounting policies is included in this Annual Report in “Notes to Consolidated Financial Statements, Note 1. Significant Accounting Policies.” We consider the following accounting estimates to be critical in the preparation of our consolidated financial statements.

[0001728949-18-000095:mdna:233]
Impairment of Other Investments. We hold investments in non-marketable equity instruments in privately held companies that are accounted for using either the cost or the equity method. Many of these investments are in early-stage companies, which are inherently risky because the markets for the technologies or products of these companies are uncertain and may never develop. We monitor our investments for events or circumstances that could indicate the investments are impaired, such as a deterioration in the investee’s financial condition and business forecasts and lower valuations in recently completed or proposed financings, and we record impairment losses in earnings when we believe an investment has experienced a decline in value that is other than temporary.

[0001728949-18-000095:mdna:234]
Valuation of Inventories. Inventories are valued at the lower of cost and net realizable value using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers, among other things. This valuation also requires us to make judgments and assumptions based on information currently available about market conditions, including competition, product pricing, product life cycle and development plans. As we move to smaller geometry process technologies, the manufacturing lead-time increases, resulting in an increased reliance on our own forecasts of customer demand, rather than our customers’ forecasts. If we overestimate demand for our products, the amount of our loss will be impacted by our contractual ability to reduce inventory purchases from our suppliers. Our assumptions of future product demand are inherently uncertain, and changes in our estimates and assumptions may cause us to realize material write-downs in the future.

[0001728949-18-000095:mdna:235]
Valuation of Goodwill and Other Indefinite-Lived and Long-Lived Assets. Our business combinations typically result in the recording of goodwill, other intangible assets and/or property, plant and equipment, and the recorded values of those assets may become impaired in the future. We also acquire intangible assets and property, plant and equipment in other types of transactions. The determination of the recorded value of intangible assets acquired in a business combination requires management to make estimates and assumptions that affect our consolidated financial statements. For intangible assets acquired in a non-monetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value. An estimate of fair value can be affected by many assumptions that require significant judgment. For example, the income approach generally requires us to use assumptions to estimate future cash flows including those related to total addressable market, pricing and share forecasts, competition, technology obsolescence, future tax rates and discount rates. Our estimate of the fair value of certain assets may differ materially from that determined by others who use different assumptions or utilize different business models and from the future cash flows actually realized.

[0001728949-18-000095:mdna:236]
Goodwill and other indefinite-lived intangible assets are tested annually for impairment and in interim periods if events or changes in circumstances indicate that the assets may be impaired. Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Our judgments regarding the existence of impairment indicators and future cash flows related to goodwill and other indefinite-lived intangible assets and long-lived assets may be based on operational performance of our businesses, market conditions, expected selling price and/or other factors. Although there are inherent uncertainties in this assessment process, the estimates and assumptions we use, including estimates of future cash flows and discount rates, are consistent with our internal planning, when appropriate. If these estimates or their related assumptions change in the future, we may be required to record an impairment charge on a portion or all of our goodwill, other indefinite-lived intangible assets and/or long-lived assets. Furthermore, we cannot predict the occurrence of future impairment-triggering events nor the impact such events might have on our reported asset values. Future events could cause us to conclude that impairment indicators exist, and that goodwill or other intangible assets

[0001728949-18-000095:mdna:237]
55

[0001728949-18-000095:mdna:238]
associated with our acquired businesses are impaired. Any resulting impairment loss could have an adverse impact on our financial condition and results of operations. During fiscal 2018, 2017 and 2016, we recorded $273 million, $76 million and $107 million, respectively, in impairment charges for goodwill, other indefinite-lived intangible assets and long-lived assets. The estimated fair values of our QCT and QTL reporting units were substantially in excess of their respective carrying values at September 30, 2018.

[0001728949-18-000095:mdna:239]
Legal and Regulatory Proceedings. We are currently involved in certain legal and regulatory proceedings, and we intend to continue to vigorously defend ourselves. Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Investigations by antitrust and trade regulation agencies are not conducted in a consistent manner across jurisdictions. Further, each country and agency has different sets of laws, rules and regulations, both substantive and procedural, as well as different legal principles, theories and potential remedies, and some agencies may seek to use the investigation to advance domestic policy goals. Depending on the jurisdiction, these investigations can involve non-transparent procedures under which we may not receive access to evidence relied upon by the enforcement agency or that may be exculpatory and may not be informed of the specific legal theories or evidence considered or relied upon by the agency. Unlike in civil litigation in the United States, in foreign proceedings, we may not be entitled to discovery or depositions, allowed to cross-examine witnesses or confront our accusers. As a result, we may not be aware of, and may not be entitled to know, all allegations against us, or the information or documents provided to, or discovered or prepared by, the agency. Accordingly, we may have little or no idea what an agency’s intent is with respect to liability, penalties or the timing of a decision. In many cases the agencies are given significant discretion, and any available precedent may have limited, if any, predictive value in their jurisdictions, much less in other jurisdictions. Accordingly, we cannot predict the outcome of these matters. However, the unfavorable resolution of one or more of these proceedings could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. A broad range of remedies with respect to our business practices that are deemed to violate applicable laws are potentially available. These remedies may include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or to modify our business practices. If there is at least a reasonable possibility that a material loss may have been incurred associated with a loss contingency, we disclose such fact, and if reasonably estimable, we provide an estimate of the possible loss or range of possible loss. We record our best estimate of a loss related to pending legal or regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, we record the minimum estimated liability. As additional information becomes available, we assess the potential liability, including the probability of loss related to pending legal or regulatory proceedings, and revise our estimates and update our disclosures accordingly. Significant judgment is required in both the determination of probability and the determination as to whether a loss is reasonably estimable. Revisions in our estimates of the potential liability could materially impact our results of operations.

[0001728949-18-000095:mdna:240]
Income Taxes. We are subject to income taxes in the United States and numerous foreign jurisdictions, and the assessment of our income tax positions involves dealing with uncertainties in the application of complex tax laws and regulations in various taxing jurisdictions. In addition, the application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws and regulations themselves are subject to change as a result of changes in fiscal policy, changes in legislation, the evolution of regulations and court rulings. Significant judgments and estimates are required in determining our provision for income taxes, including those related to tax incentives, intercompany research and development cost-sharing arrangements, transfer pricing and tax credits. While we believe we have appropriate support for the positions taken or plan to take on our tax returns, we regularly assess the potential outcomes of examinations by taxing authorities in determining the adequacy of our provision for income taxes. Therefore, the actual liability for U.S. or foreign taxes may be materially different from our estimates, which could result in the need to record additional tax liabilities or potentially reverse previously recorded tax liabilities. We are participating in the Internal Revenue Service (IRS) Compliance Assurance Process program whereby we endeavor to agree with the IRS on the treatment of all issues prior to filing our federal return. A benefit of participation in this program is that post-filing adjustments by the IRS are less likely to occur.

[0001728949-18-000095:mdna:241]
On December 22, 2017, tax reform legislation known as the Tax Cuts and Jobs Act (the Tax Legislation) was enacted in the U.S. The Tax Legislation significantly revises the U.S. corporate income tax by, among other things, lowering the corporate income tax rate to 21%, implementing a modified territorial tax system and imposing a one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge). As a fiscal-year taxpayer, we were impacted by certain provisions of the Tax Legislation in fiscal 2018, including the change in the corporate income tax rate and the Toll Charge, while other provisions will be effective starting at the beginning of fiscal 2019, including the implementation of a modified territorial tax system. Accounting for the income tax effects of the Tax Legislation requires significant judgments and estimates in the interpretation and calculations of the provisions of the Tax Legislation.

[0001728949-18-000095:mdna:242]
56

[0001728949-18-000095:mdna:243]
Given the amount and complexity of the changes in tax law resulting from the Tax Legislation, we have not finalized the accounting for the income tax effects of the Tax Legislation related to the Toll Charge. We have made reasonable estimates of the effects and recorded provisional amounts in our consolidated financial statements. The impact of the Tax Legislation related to the Toll Charge may differ from this estimate during the remainder of the one-year measurement period due to, among other things, further refinement of our calculations, changes in interpretations and assumptions we have made, guidance that may be issued and actions we may take as a result of the Tax Legislation. We are in the process of analyzing the effects of new taxes due on certain foreign income, such as GILTI (global intangible low-taxed income), BEAT (base-erosion anti-abuse tax) and FDII (foreign-derived intangible income), and limitations on interest expense deductions (if certain conditions apply), all of which are effective starting in fiscal 2019, as well as other provisions of the Tax Legislation.

[0001728949-18-000095:mdna:244]
Our QCT segment’s non-U.S. headquarters is located in Singapore. During the third quarter of fiscal 2018, we entered into a new tax incentive agreement in Singapore that results in a reduced tax rate from March 2017 through March 2022, provided that we meet specified employment and investment criteria in Singapore. Our Singapore tax rate will increase in March 2022 as a result of expiration of these incentives and again in March 2027 upon the expiration of tax incentives under a prior agreement. As a result of this new tax incentive, our income tax expense for fiscal 2018 was reduced by approximately $130 million. Our failure to meet these criteria could adversely impact our provision for income taxes.

[0001728949-18-000095:mdna:245]
Recent Accounting Pronouncements

[0001728949-18-000095:mdna:246]
Information regarding recent accounting pronouncements and the impact of those pronouncements, if any, on our consolidated financial statements is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 1. Significant Accounting Policies.”
