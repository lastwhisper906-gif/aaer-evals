# QCOM notes — 0001728949-18-000095


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001728949-18-000095:notes:1]
SCHEDULE II

[0001728949-18-000095:notes:2]
QUALCOMM INCORPORATED

[0001728949-18-000095:notes:3]
VALUATION AND QUALIFYING ACCOUNTS

[0001728949-18-000095:notes:4]
(In millions)

[0001728949-18-000095:notes:5]
|  | Balance atBeginning ofPeriod |  | Charged(Credited) toCosts andExpenses |  | Balance atEnd ofPeriod |
| Year ended September 30, 2018 |  |  |  |  |  |
| Allowances: |  |  |  |  |  |
| — trade receivables | $ | 11 |  |  | $ | 45 |  |  | $ | 56 |  |
| Valuation allowance on deferred tax assets | 863 |  |  | 666 |  |  | 1,529 |  |
|  | $ | 874 |  |  | $ | 711 |  |  | $ | 1,585 |  |
| Year ended September 24, 2017 |  |  |  |  |  |
| Allowances: |  |  |  |  |  |
| — trade receivables | $ | 1 |  |  | $ | 10 |  |  | $ | 11 |  |
| Valuation allowance on deferred tax assets | 754 |  |  | 109 |  |  | 863 |  |
|  | $ | 755 |  |  | $ | 119 |  |  | $ | 874 |  |
| Year ended September 25, 2016 |  |  |  |  |  |
| Allowances: |  |  |  |  |  |
| — trade receivables | $ | 6 |  |  | $ | (5 | ) |  | $ | 1 |  |
| Valuation allowance on deferred tax assets | 635 |  |  | 119 |  |  | 754 |  |
|  | $ | 641 |  |  | $ | 114 |  |  | $ | 755 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-18-000095:notes:6]
Composition of Certain Financial Statement Items

[0001728949-18-000095:notes:7]
| Accounts Receivable (in millions) |  |  |  |
|  | September 30, 2018 |  | September 24, 2017 |
| Trade, net of allowances for doubtful accounts of $56 and $11, respectively | $ | 2,848 |  |  | $ | 3,576 |  |
| Long-term contracts | 20 |  |  | 40 |  |
| Other | 36 |  |  | 16 |  |
|  | $ | 2,904 |  |  | $ | 3,632 |  |

[0001728949-18-000095:notes:8]
Accounts receivable at the end of both fiscal 2018 and fiscal 2017 included approximately $960 million related to the short payment in the second quarter of fiscal 2017 of royalties reported by and deemed collectible from Apple’s contract manufacturers. This same amount was recorded in customer-related liabilities (in other current liabilities) for Apple, since we do not have the contractual right to offset these amounts.

[0001728949-18-000095:notes:9]
| Inventories (in millions) |  |  |  |
|  | September 30, 2018 |  | September 24, 2017 |
| Raw materials | $ | 72 |  |  | $ | 103 |  |
| Work-in-process | 715 |  |  | 799 |  |
| Finished goods | 906 |  |  | 1,133 |  |
|  | $ | 1,693 |  |  | $ | 2,035 |  |

[0001728949-18-000095:notes:10]
| Property, Plant and Equipment (in millions) | September 30, 2018 |  | September 24, 2017 |
| Land | $ | 186 |  |  | $ | 195 |  |
| Buildings and improvements | 1,575 |  |  | 1,595 |  |
| Computer equipment and software | 1,419 |  |  | 1,609 |  |
| Machinery and equipment | 3,792 |  |  | 3,528 |  |
| Furniture and office equipment | 85 |  |  | 109 |  |
| Leasehold improvements | 325 |  |  | 310 |  |
| Construction in progress | 79 |  |  | 73 |  |
|  | 7,461 |  |  | 7,419 |  |
| Less accumulated depreciation and amortization | (4,486 | ) |  | (4,203 | ) |
|  | $ | 2,975 |  |  | $ | 3,216 |  |

[0001728949-18-000095:notes:11]
Depreciation and amortization expense related to property, plant and equipment for fiscal 2018, 2017 and 2016 was $776 million, $684 million and $624 million, respectively. The gross book values of property under capital leases included in buildings and improvements were negligible at September 30, 2018 and September 24, 2017.

[0001728949-18-000095:notes:12]
Goodwill and Other Intangible Assets. We allocate goodwill to our reporting units for annual impairment testing purposes. The following table presents the goodwill allocated to our reportable and nonreportable segments, as described in Note 8, as well as the changes in the carrying amounts of goodwill during fiscal 2018 and 2017 (in millions):

[0001728949-18-000095:notes:13]
|  | QCT |  | QTL |  | Nonreportable Segments |  | Total |
| Balance at September 25, 2016 | $ | 4,674 |  |  | $ | 718 |  |  | $ | 287 |  |  | $ | 5,679 |  |
| Acquisitions | 841 |  |  | 23 |  |  | 11 |  |  | 875 |  |
| Other (1) | 66 |  |  | — |  |  | 3 |  |  | 69 |  |
| Balance at September 24, 2017 (2) | 5,581 |  |  | 741 |  |  | 301 |  |  | 6,623 |  |
| Acquisitions | — |  |  | — |  |  | — |  |  | — |  |
| Impairments | — |  |  | (22 | ) |  | (107 | ) |  | (129 | ) |
| Other (1) | 6 |  |  | (1 | ) |  | (1 | ) |  | 4 |  |
| Balance at September 30, 2018 (2) | $ | 5,587 |  |  | $ | 718 |  |  | $ | 193 |  |  | $ | 6,498 |  |

[0001728949-18-000095:notes:14]
| (1) | Includes changes in goodwill amounts resulting from foreign currency translation, purchase accounting adjustments. |

[0001728949-18-000095:notes:15]
| (2) | Cumulative goodwill impairments were $666 million and $537 million at September 30, 2018 and September 24, 2017, respectively. |

[0001728949-18-000095:notes:16]
The components of other intangible assets, net were as follows (in millions):

[0001728949-18-000095:notes:17]
|  | September 30, 2018 |  | September 24, 2017 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |
| Wireless spectrum | $ | 1 |  |  | $ | — |  |  | 20 |  | $ | 1 |  |  | $ | — |  |  | 20 |
| Marketing-related | 51 |  |  | (39 | ) |  | 5 |  | 77 |  |  | (52 | ) |  | 4 |
| Technology-based | 6,334 |  |  | (3,461 | ) |  | 10 |  | 6,413 |  |  | (2,818 | ) |  | 10 |
| Customer-related | 97 |  |  | (28 | ) |  | 10 |  | 149 |  |  | (33 | ) |  | 9 |
|  | $ | 6,483 |  |  | $ | (3,528 | ) |  | 10 |  | $ | 6,640 |  |  | $ | (2,903 | ) |  | 10 |

[0001728949-18-000095:notes:18]
All of these intangible assets are subject to amortization, other than acquired in-process research and development with carrying values of $74 million at September 24, 2017. At September 30, 2018, all acquired in-process research and development projects were completed and are being amortized over their useful lives. Amortization expense related to these intangible assets was $785 million, $777 million and $804 million for fiscal 2018, 2017 and 2016, respectively. Amortization expense related to these intangible assets is expected to be $733 million, $630 million, $517 million, $418 million and $285 million for each of the five years from fiscal 2019 through 2023, respectively, and $372 million thereafter.

[0001728949-18-000095:notes:19]
| Other Current Liabilities (in millions) |  |  |  |
|  | September 30, 2018 |  | September 24, 2017 |
| Customer incentives and other customer-related liabilities | $ | 3,347 |  |  | $ | 2,804 |  |
| Accrual for EC fine (Note 7) | 1,167 |  |  | — |  |
| Income taxes payable | 453 |  |  | 312 |  |
| Accrual for TFTC fine (Note 7) | — |  |  | 778 |  |
| RF360 Holdings Put and Call Option (Note 9) | 1,137 |  |  | — |  |
| Other | 721 |  |  | 862 |  |
|  | $ | 6,825 |  |  | $ | 4,756 |  |

[0001728949-18-000095:notes:20]
Customer incentives and other customer-related liabilities substantially consist of amounts payable to customers for incentive and other arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of our products and technologies. The corresponding charges for such arrangements were recorded as a reduction to revenues.

[0001728949-18-000095:notes:21]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity during fiscal 2018 were as follows (in millions):

[0001728949-18-000095:notes:22]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Other Gains |  | Total Accumulated Other Comprehensive Income |
| Balance at September 24, 2017 | $ | 147 |  |  | $ | 23 |  |  | $ | 218 |  |  | $ | (8 | ) |  | $ | 4 |  |  | $ | 384 |  |
| Other comprehensive (loss) income before reclassifications | (136 | ) |  | — |  |  | 29 |  |  | (17 | ) |  | (3 | ) |  | (127 | ) |
| Reclassifications from accumulated other comprehensive income | — |  |  | — |  |  | (4 | ) |  | 12 |  |  | — |  |  | 8 |  |
| Other comprehensive (loss) income | (136 | ) |  | — |  |  | 25 |  |  | (5 | ) |  | (3 | ) |  | (119 | ) |
| Balance at September 30, 2018 | $ | 11 |  |  | $ | 23 |  |  | $ | 243 |  |  | $ | (13 | ) |  | $ | 1 |  |  | $ | 265 |  |

[0001728949-18-000095:notes:23]
Reclassifications from accumulated other comprehensive income related to net gains on available-for-sale securities were negligible, $201 million and $83 million during fiscal 2018, 2017 and 2016, respectively, and were recorded in investment and other income, net (Note 2). Reclassifications from accumulated other comprehensive income related to foreign currency translation losses of $21 million during fiscal 2016 were recorded in selling, general and administrative expenses and other operating expenses. Reclassifications from accumulated other comprehensive income related to foreign currency translation adjustments during fiscal 2018 and 2017 were negligible. Reclassifications from accumulated other comprehensive income related to derivative instruments of $12 million, $10 million and negligible for fiscal 2018, 2017 and 2016, respectively, were recorded in revenues, cost of revenues, research and development expenses and selling, general and administrative expenses.

[0001728949-18-000095:notes:24]
Other Income, Costs and Expenses. Other expenses in fiscal 2018 consisted of a $2.0 billion charge related to the termination of our purchase agreement to acquire NXP (Note 9), a $1.2 billion charge related to the European Commission (EC) fine (Note 7), $629 million in restructuring and restructuring-related charges related to our Cost Plan (Note 10) and a $676 million benefit related to the settlement of the Taiwan Fair Trade Commission (TFTC) investigation (Note 7).

[0001728949-18-000095:notes:25]
Other expenses for fiscal 2017 consisted of a $927 million charge related to the Korea Fair Trade Commission (KFTC) fine (Note 7), including related foreign currency losses, a $778 million charge related to the TFTC fine (Note 7) and $37 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan (Note 10).

[0001728949-18-000095:notes:26]
Other income for fiscal 2016 included a gain of $380 million on the sale of wireless spectrum in the United Kingdom that was held by the QSI (Qualcomm Strategic Initiatives) segment in the first quarter of fiscal 2016 for $232 million in cash and $275 million in deferred payments due in 2020 to 2023, which were recorded at their present values in other noncurrent assets. Other income for fiscal 2016 also included $202 million in restructuring and restructuring-related charges, which were partially offset by a $48 million gain on the sale of our business that provided augmented reality applications, all of which related to our Strategic Realignment Plan.

[0001728949-18-000095:notes:27]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |
|  | 2018 |  | 2017 |  | 2016 |
| Interest and dividend income | $ | 625 |  |  | $ | 619 |  |  | $ | 611 |  |
| Net realized gains on marketable securities | 41 |  |  | 456 |  |  | 239 |  |
| Net realized gains on other investments | 83 |  |  | 74 |  |  | 49 |  |
| Impairment losses on marketable securities | (6 | ) |  | (131 | ) |  | (112 | ) |
| Impairment losses on other investments | (69 | ) |  | (46 | ) |  | (60 | ) |
| Net (losses) gains on derivative instruments | (27 | ) |  | 32 |  |  | (8 | ) |
| Equity in net losses of investees | (145 | ) |  | (74 | ) |  | (84 | ) |
| Net gains (losses) on foreign currency transactions | 37 |  |  | (30 | ) |  | — |  |
|  | $ | 539 |  |  | $ | 900 |  |  | $ | 635 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001728949-18-000095:notes:28]
The unaudited pro forma results presented below include adjustments for the step-up of inventories to fair value, amortization and depreciation of identified intangible assets and property, plant and equipment, adjustments for certain acquisition-related charges, interest expense related to the Put and Call Option and related tax effects (in millions):

[0001728949-18-000095:notes:29]
|  | (Unaudited) |
|  | 2017 |  | 2016 |
| Pro forma revenues | $ | 22,806 |  |  | $ | 24,731 |  |
| Pro forma net income attributable to Qualcomm | 2,614 |  |  | 5,791 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001728949-18-000095:notes:30]
Acquisitions

[0001728949-18-000095:notes:31]
Terminated. On October 27, 2016, we announced a definitive agreement (as amended on February 20, 2018 and April 19, 2018, the Purchase Agreement) under which Qualcomm River Holdings, B.V. (Qualcomm River Holdings), an indirect, wholly owned subsidiary of QUALCOMM Incorporated, proposed to acquire NXP Semiconductors N.V. (NXP). Pursuant to the Purchase Agreement, Qualcomm River Holdings commenced a tender offer to acquire all of the issued and outstanding common shares of NXP. On July 26, 2018, we terminated the Purchase Agreement, and we paid NXP a termination fee of $2.0 billion in cash in accordance with the terms of the Purchase Agreement.

[0001728949-18-000095:notes:32]
Completed. On February 3, 2017, we completed the formation of a joint venture with TDK Corporation (TDK), under the name RF360 Holdings, to enable delivery of radio frequency front-end (RFFE) modules and radio frequency (RF) filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others. The joint venture is owned 51% by Qualcomm Global Trading Pte. Ltd. (Qualcomm Global Trading), a Singapore corporation and wholly-owned subsidiary of ours, and 49% by EPCOS AG (EPCOS), a German wholly-owned subsidiary of TDK. RF360 Holdings is a Singapore corporation with research and development and manufacturing and/or sales locations in the United States, Europe and Asia and its headquarters in Munich, Germany. Certain intellectual property, patents and filter and module design and manufacturing assets were carved out of existing TDK businesses and are owned by the joint venture, and certain assets were acquired directly by our affiliates. Qualcomm Global Trading has the option to acquire (and EPCOS has an option to sell) EPCOS’s interest in the joint venture for $1.15 billion (Settlement Amount) in August 2019 (the Put and Call Option).

[0001728949-18-000095:notes:33]
EPCOS is entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the Closing Date, which is a substitute for and in lieu of the right of EPCOS to receive any profit sharing, distributions, dividends or other payments of any kind or nature. Such contingent consideration was recorded as a liability at fair value at close based on significant inputs that were not observable, with future changes in fair value recorded in earnings. Such fair value adjustments resulted in a $23 million gain and a negligible gain in fiscal 2018 and fiscal 2017, respectively.

[0001728949-18-000095:notes:34]
RF360 Holdings is a variable interest entity, and its results of operations and statement of financial position are included in our consolidated financial statements as the governance structure of RF360 Holdings provides us with the power to direct the activities of the joint venture that most significantly impact its economic performance, such as operating decisions related to research and development, manufacturing and sales and marketing of its products. Since the Put and Call Option is considered a financing of our purchase of EPCOS’s interest in RF360 Holdings, noncontrolling interest is not recorded in our consolidated financial statements. Therefore, the Put and Call Option was recorded as a liability at fair value at close and was included in other current liabilities at September 30, 2018 and other noncurrent liabilities at September 24, 2017. The liability is being accreted to the Settlement Amount, with the offset recorded as interest expense. The carrying value of the Put and Call Option approximated its estimated fair value at September 30, 2018.

[0001728949-18-000095:notes:35]
The total purchase price consisted of the following (in millions):

[0001728949-18-000095:notes:36]
| Cash paid to TDK at close | $ | 1,463 |  |
| Fair value of Put and Call Option | 1,112 |  |
| Fair value of contingent consideration and other deferred payments | 496 |  |
| Total purchase price | $ | 3,071 |  |

[0001728949-18-000095:notes:37]
The allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0001728949-18-000095:notes:38]
| Cash and cash equivalents | $ | 306 |  |
| Accounts receivable | 303 |  |
| Inventories | 260 |  |
| Intangible assets subject to amortization: |  |
| Technology-based intangible assets | 738 |  |
| Customer-related intangible assets | 87 |  |
| Marketing-related intangible assets | 8 |  |
| In-process research and development (IPR&D) | 75 |  |
| Property, plant and equipment | 821 |  |
| Goodwill | 843 |  |
| Other assets | 31 |  |
| Total assets | 3,472 |  |
| Liabilities | (401 | ) |
|  | $ | 3,071 |  |

[0001728949-18-000095:notes:39]
We recognized $843 million in goodwill related to this transaction, of which $366 million is expected to be deductible for tax purposes. The goodwill recognized was allocated to the QCT segment for annual impairment testing purposes. The goodwill is primarily attributable to the assembled workforce and synergies expected to arise after the acquisition. Each category of intangible assets acquired are being amortized on a straight-line basis over the weighted-average useful lives of seven years for technology-based intangible assets, nine years for customer-related intangible assets and one year for marketing-related intangible assets. At September 30, 2018, all IPR&D projects had been completed and are being amortized over their weighted-average useful lives of six years. The estimated fair values of the intangible assets and the property, plant and equipment acquired were determined using the income approach and cost approach, respectively, both of which were based on significant inputs that were not observable.

[0001728949-18-000095:notes:40]
The following table presents the unaudited pro forma results for fiscal 2017 and fiscal 2016. The unaudited pro forma financial information combines the results of operations of Qualcomm and RF360 Holdings as though the companies had been combined as of the beginning of fiscal 2016. The pro forma information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at such time. The unaudited pro forma results presented below include adjustments for the step-up of inventories to fair value, amortization and depreciation of identified intangible assets and property, plant and equipment, adjustments for certain acquisition-related charges, interest expense related to the Put and Call Option and related tax effects (in millions):

[0001728949-18-000095:notes:41]
During fiscal 2017, we acquired three other businesses for total cash consideration of $35 million, net of cash acquired, and up to a total of $94 million in certain contingent payments, which were recorded as a liability at fair value. We recognized $47 million in goodwill related to these transactions, of which $12 million is expected to be deductible for tax purposes. Goodwill of $23 million, $12 million and $11 million was assigned to our QTL, QCT and nonreportable segments, respectively.

[0001728949-18-000095:notes:42]
During fiscal 2016, we acquired four businesses for total cash consideration of $392 million, net of cash acquired. Technology-based intangible assets of $257 million were recognized with a weighted-average useful life of four years. We recognized $172 million in goodwill related to these transactions, all of which was assigned to our QCT segment and of which $24 million is expected to be deductible for tax purposes.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001728949-18-000095:notes:43]
Cash Equivalents. We consider all highly liquid investments with original maturities of 90 days or less to be cash equivalents. Cash equivalents are comprised of money market funds, certificates of deposit, commercial paper, corporate bonds and notes, certain bank time and demand deposits and government agencies’ securities. The carrying amounts approximate fair value due to the short maturities of these instruments.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-18-000095:notes:44]
Commitments and Contingencies

[0001728949-18-000095:notes:45]
Legal and Regulatory Proceedings.

[0001728949-18-000095:notes:46]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringe certain ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that we infringe 11 ParkerVision patents and seeks damages and injunctive and other relief. On December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted us and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against us and other parties with the United States International Trade Commission (ITC) described below. Subsequently, ParkerVision announced that it had reached a settlement with Samsung which dismissed the Samsung entities from the District Court case. We had previously filed Inter Partes Review petitions with the United States Patent and Trademark Office (USPTO) to invalidate all asserted claims of several of the remaining patents. On March 7, 2017, the USPTO decided in our favor with respect to all asserted claims of one such patent. After the ITC action described below was closed, and upon agreement among the parties, on May 24, 2017, the District Court further stayed the District Court case pending ParkerVision’s appeal of the USPTO’s invalidation decisions. A hearing on ParkerVision’s appeal before the United States Court of Appeals for the Federal Circuit was held on August 7, 2018. On September 13, 2018, the Court of Appeals reaffirmed the USPTO’s decisions. The case has been further stayed by motion of the parties while ParkerVision decides whether to bring a further appeal.

[0001728949-18-000095:notes:47]
On December 14, 2015, ParkerVision filed another complaint against us in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. were also named defendants. The complaint asserts that certain of our products infringe four additional ParkerVision patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two of our transceivers or one Samsung transceiver and a cease and desist order preventing us and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, we served our answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. On February 12, 2016, the District Court case was stayed pending completion of the ITC investigation. Subsequently, ParkerVision announced that it had reached a settlement with Samsung which dismissed the Samsung entities from the ITC investigation and related District Court case. On February 2, 2017, the ITC granted ParkerVision’s motion to drop all but one patent and one accused product from the ITC investigation. On March 12, 2017, one day before the ITC hearing was scheduled to begin, ParkerVision moved to withdraw its ITC complaint in its entirety. We and the other defendants did not oppose the withdrawal of the complaint. On April 28, 2017, the ITC formally closed the investigation. On May 4, 2017, ParkerVision filed a motion to reopen the related District Court Case, and on May 26, 2017, the District Court granted the motion. On March 16, 2018, the parties agreed to dismiss three of ParkerVision’s patents from the case without prejudice, leaving only one patent at issue. A claim construction hearing was held on August 31, 2018. The District Court has not issued on order on that hearing. No trial date has been set.

[0001728949-18-000095:notes:48]
Apple Inc. (Apple) v. QUALCOMM Incorporated: On January 20, 2017, Apple filed a complaint against us in the United States District Court for the Southern District of California seeking declarations with respect to several of our patents and alleging that we breached certain agreements and violated federal antitrust and California state unfair competition laws. In its initial complaint, Apple sought declaratory judgments of non-infringement by Apple of nine of our patents, or in the alternative, a declaration of royalties Apple must pay for the patents. Apple further sought a declaration that our sale of baseband processor chipsets exhausts our patent rights for patents embodied in those chipsets. Separately, Apple sought to enjoin us from seeking excessive royalties from Apple and to disgorge royalties paid by Apple’s contract manufacturers that the court finds were not fair, reasonable and non-discriminatory (FRAND). Apple also claimed that our refusal to make certain payments to Apple under a Business Cooperation and Patent Agreement (Cooperation Agreement) constituted a breach of contract in violation of California law and sought damages in the amount of the unpaid payments, alleged to be approximately $1 billion. In addition, Apple claimed that we have refused to deal with competitors in contravention of our agreements with applicable standard setting organizations, have used our market position to impose contractual obligations on Apple that prevented Apple from challenging our licensing practices, have tied the purchase of our CDMA-enabled and “premium” LTE-enabled chipsets to licensing certain of our patents and have required Apple to purchase baseband processor chipsets exclusively from us as a condition of our payment to Apple of certain rebates, in violation of Section 2 of the Sherman Act and the California Unfair Competition Law. Apple sought injunctive relief with respect to these claims and a judgment awarding its expenses, costs and attorneys’ fees.

[0001728949-18-000095:notes:49]
On April 10, 2017, we filed our Answer and Counterclaims (amended on May 24, 2017) in response to Apple’s complaint denying Apple’s claims and asserting claims against Apple. The counterclaims against Apple include tortious interference with our long-standing Subscriber Unit License Agreements (SULAs) with third-party contract manufacturers of Apple devices, causing those contract manufacturers to withhold certain royalty payments owed to us and violate their audit obligations; breach of contract and the implied covenant of good faith and fair dealing relating to the Cooperation Agreement; unjust enrichment and declaratory relief relating to the Cooperation Agreement; breach of contract based on Apple’s failure to pay amounts owed to us under a Statement of Work relating to a high-speed feature of our baseband processor chipsets; breach of the parties’ software agreement; and violation of California Unfair Competition Law based on Apple’s threatening us to prevent us from promoting the superior performance of our own baseband processor chipsets. We also seek declaratory judgments that we have satisfied our FRAND commitments with respect to Apple, and that our SULAs with the contract manufacturers do not violate either competition law or our FRAND commitments. On June 19, 2017, Apple filed a Partial Motion to Dismiss our counterclaim for violation of the California Unfair Competition Law. The court granted that motion on November 8, 2017. On June 20, 2017, Apple filed an Answer and Affirmative Defenses to the rest of our counterclaims, and also filed an Amended Complaint reiterating all of the original claims and adding claims for declaratory judgments of invalidity of the nine patents that are subject to declaratory judgment claims in the original complaint, adding new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for nine more patents. Apple also added claims for declaratory judgments that certain of our agreements are unenforceable. On July 21, 2017, we filed an Answer to Apple’s Amended Complaint as well as a motion to dismiss the new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for the nine additional patents. The court granted our motion on November 8, 2017.

[0001728949-18-000095:notes:50]
On May 17, 2017, we filed a complaint (captioned QUALCOMM Incorporated v. Compal Electronics, Inc. et al.) in the United States District Court for the Southern District of California against certain of Apple’s contract manufacturers, Compal Electronics, Inc. (Compal), FIH Mobile, Ltd., Hon Hai Precision Industry Co., Ltd. (together with FIH Mobile, Ltd., Foxconn), Pegatron Corporation (Pegatron) and Wistron Corporation (Wistron), asserting claims for injunctive relief, specific performance, declaratory relief and damages stemming from the defendants’ breach of contracts by ceasing the payment of royalties for iPhones and other devices which they manufacture for Apple. On July 17, 2017, Compal, Foxconn, Pegatron and Wistron each filed third-party complaints for contractual indemnity against Apple seeking to join Apple as a party to the action. On July 18, 2017, Apple filed an answer to these third-party complaints acknowledging its indemnity agreements and consenting to be joined. On July 18, 2017, the defendants filed an Answer and Counterclaims to the complaint, asserting defenses and counterclaims similar to allegations previously made by Apple in the Apple Inc. v. QUALCOMM Incorporated case discussed above. In addition, the defendants asserted certain new claims, including claims under Section 1 of the Sherman Act and California’s Cartwright Act. The defendants seek damages, declaratory relief, injunctive relief, restitution of certain royalties and other relief. On July 18, 2017, Apple filed a motion to consolidate this action with the Apple Inc. v. QUALCOMM Incorporated case. On September 13, 2017, the court granted Apple’s consolidation motion. Fact discovery is closed in these cases.

[0001728949-18-000095:notes:51]
On August 31, 2018, Apple filed a motion for judgment on the pleadings that the court lacks subject matter jurisdiction over our counterclaim that our license offers to Apple have not violated our obligation to license standard-essential patents on FRAND terms. The same day, Apple also filed motions for partial summary judgment on the following issues: that part of our claim for Apple’s alleged tortious interference with its contract manufacturers’ agreements is barred by the statute of limitations; that our claim for damages under the Cooperation Agreement is unfounded; and that certain of our patent rights are exhausted by the sale of our baseband processor chipsets. The foregoing motions are scheduled for hearing on November 9, 2018.

[0001728949-18-000095:notes:52]
On September 14, 2018, we filed a motion to dismiss Apple’s declaratory judgment claims relating to the nine specific patents identified in its original complaint on the basis that we granted Apple and its contract manufacturers a covenant-not-to-sue on those patents. If granted, this motion would dispose of a total of 56 claims pled by Apple and its contract manufacturers, including non-infringement, validity, damages and patent exhaustion for each of the nine patents (which would render Apple’s motion for partial summary judgment on the issue as moot). The hearing on our motion to dismiss was held on October 26, 2018. A final pretrial conference is scheduled for November 30, 2018. The trials have not been scheduled.

[0001728949-18-000095:notes:53]
On January 23, 2017, an Apple subsidiary in China filed two complaints against us in the Beijing Intellectual Property Court. On March 31, 2017, the court granted an application by Apple Inc. to join the actions as a plaintiff, and Apple amended the complaints. One of the complaints alleges a violation of China’s Anti-Monopoly Law (AML complaint); the other complaint requests a determination of the terms of a patent license between us and Apple (FRAND complaint). The AML complaint alleges that (i) we have abused our dominant position in communication standard-essential patents licensing markets and certain global baseband processor chipset markets by charging and offering royalty terms that were excessively high; (ii) we refused to license certain implementers of standardized technologies, including Apple and baseband processor chipset manufacturers; (iii) we forced Apple to use only our products and services; and (iv) we bundled licenses to standard-essential patents with licenses to non-standard-essential patents and imposed other unreasonable or discriminatory trading terms on Apple in violation of the AML. The AML complaint seeks a decree that we cease the alleged abuse of dominance, as well as damages in the amount of 1 billion Chinese renminbi (approximately $145 million based on the exchange rate on September 30, 2018). The FRAND complaint makes allegations similar to the AML complaint and further alleges that we refused to offer licensing terms for our cellular standard-essential patents consistent with our FRAND licensing commitments and failed to provide to Apple certain information about our patents. The FRAND complaint seeks (i) a declaration that the license terms offered to Apple by us for our mobile communication standard-essential patents are not compliant with FRAND; (ii) an order that we cease our actions that allegedly violate our FRAND obligations, including pricing on unfair, unreasonable and excessive terms, refusing to deal, imposing unreasonable trade conditions and failing to provide information on our patents; and (iii) a determination of FRAND-compliant license terms for our Chinese standard-essential patents. Apple also seeks its expenses in each of the cases.

[0001728949-18-000095:notes:54]
On August 3, 2017, we received three additional complaints filed by an Apple subsidiary and Apple Inc. against us in the Beijing Intellectual Property Court. The complaints seek declaratory judgments of non-infringement of three of our patents. We filed jurisdictional and other objections to the complaints, which the court denied on May 31, 2018. On July 5, 2018, we appealed the denial of our objections to the Beijing High People’s Court.

[0001728949-18-000095:notes:55]
On November 30, 2017, Apple and certain of its Chinese subsidiaries filed three patent infringement complaints against us in the Beijing Intellectual Property Court. Apple seeks damages and costs. We have filed jurisdictional objections to the complaints.

[0001728949-18-000095:notes:56]
On February 16, 2017, Apple and one of its Japanese subsidiaries filed four complaints against us in the Tokyo District Court. In three of the complaints, Apple seeks declaratory judgment of non-infringement by Apple of three of our patents. Apple further seeks a declaration that our patent rights with respect to those three patents are exhausted by our SULAs with the contract manufacturers of Apple’s devices as well as our sale of baseband processor chipsets. Apple also seeks an award of fees. On January 30, 2018, April 27, 2018 and July 13, 2018, the court dismissed each of Apple’s three declaratory judgment complaints, finding that Apple lacked standing based on the facts it alleged in those complaints. The court has yet to rule on whether Apple has standing in the remaining complaint. On May 15, 2017, we learned of the fourth complaint. In that complaint, Apple and one of its Japanese subsidiaries seek damages of 100 million Japanese yen (approximately $1 million based on the exchange rate on September 30, 2018) from us, based on allegations that we violated the Japanese Antimonopoly Act and the Japanese Civil Code. In particular, the fourth complaint alleges that (i) we hold a monopoly position in the market for baseband processor chipsets that implement certain cellular standards; (ii) we collect double royalties through our license agreements and the sale of baseband processor chipsets; (iii) we refused to grant Apple a license on FRAND terms and forced Apple to execute a rebate agreement under unreasonable conditions; (iv) we refused to grant Apple a direct license; and (v) we demanded a license fee based on the market value of the total device. We have filed jurisdictional and other objections to this complaint.

[0001728949-18-000095:notes:57]
On March 2, 2017, we learned that Apple and certain of its European subsidiaries issued a Claim Form against us in the UK High Court of Justice, Chancery Division, Patents Court on January 23, 2017. Apple subsequently filed an Amended Claim Form and Particulars of Claim. Both the Amended Claim Form and the Particulars of Claim allege several European competition law claims, including our refusal to license competing chipmakers, failure to offer Apple a direct license to our standard-essential patents on FRAND terms, demanding excessive royalties for our standard-essential patents, and demanding excessive license fees for the use of our standard-essential patents in connection with baseband processor chipsets purchased from us. Apple also seeks declarations that we are obliged to offer a direct patent license to Apple in respect of standard-essential patents actually practiced on FRAND terms and that using our baseband processor chipsets does not infringe any of our patents because we exhausted our patent rights. Finally, Apple seeks declarations that five of our European (UK) patents are invalid and not essential, and an order that each of those patents be revoked.

[0001728949-18-000095:notes:58]
On April 18, 2017, Apple and one of its Taiwanese subsidiaries filed a complaint against us in the Taiwan Intellectual Property Court alleging that we have abused a dominant market position in licensing wireless standard-essential patents and selling baseband processor chipsets, including improper pricing, refusal to deal, exclusive dealing, tying, imposing unreasonable trade terms and discriminatory treatment. The complaint seeks rulings that we not use the sales price of the terminal device as the royalty base for standard-essential patents; not leverage our cellular standard-essential patents to obtain licenses of our non-standard-essential patents or demand cross-licenses without proper compensation; not refuse, reduce, delay or take any other action to limit the supply of our baseband processor chipsets to non-licensees; that we must license our standard-essential patents on FRAND terms; and that we shall not, based on standard-essential patents, seek injunctions. The complaint also seeks damages of 10 million Taiwan dollars (less than $1 million based on the exchange rate on September 30, 2018), among other relief.

[0001728949-18-000095:notes:59]
We believe Apple’s and its contract manufacturers’ claims in the above matters are without merit.

[0001728949-18-000095:notes:60]
QUALCOMM Incorporated v. Apple Inc.: On July 6, 2017, we filed a complaint against Apple in the United States District Court for the Southern District of California asserting claims for damages and injunctive relief for infringement of six of our patents directed to a variety of features found in iPhone models. On July 7, 2017, we filed a complaint against Apple in the United States International Trade Commission (ITC) requesting that the ITC institute an investigation pursuant to Section 337 of the Tariff Act of 1930 based on Apple’s infringement of the same six patents. We are seeking a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor chipset. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple filed an Answer and Counterclaims in the District Court case on September 26, 2017. On November 29, 2017, Apple filed a First Amended Answer and Counterclaims asserting that our Snapdragon processors infringe eight Apple patents. On August 8, 2017, the ITC issued a notice of institution of an investigation. On August 25, 2017, we withdrew allegations as to one patent in both the ITC investigation and the district court case. On April 25, 2018, we withdrew allegations as to two additional patents in the ITC investigation, but not the District Court case, in order to satisfy certain briefing limitations and to narrow the issues for hearing. The ITC investigation evidentiary hearing by the Administrative Law Judge (ALJ) was held June 18-26, 2018. The ALJ’s Initial Determination on the merits was issued on September 28, 2018. The ALJ found that we had established a violation of Section 337 by Apple due to the infringement of one of the three asserted patents. However, the ALJ recommended against an exclusion order on the grounds of public interest. On October 15, 2018, the parties each filed petitions for review of portions of the ALJ’s decision by the full ITC. The ITC is expected to announce the scope of its review by November 29, 2018. The target date for final determination by the ITC is set for January 28, 2019. On March 2, 2018, the District Court granted our motion to sever, for separate trial, Apple’s counterclaims for patent infringement against us. Trial is scheduled to begin on March 4, 2019. With respect to Apple’s patent claims against us, fact discovery is scheduled to close on December 3, 2018, and trial is scheduled to begin on July 15, 2019. All of the asserted patents have been challenged in Inter Partes Review (IPR) petitions filed by Apple, and/or in some cases by Intel, in the USPTO. No decisions have yet been issued by the USPTO.

[0001728949-18-000095:notes:61]
On November 1, 2017, we filed a complaint against Apple in San Diego Superior Court for breach of the Master Software Agreement between the companies. The complaint recounts instances when Apple failed to protect our software as required by the agreement and failed to provide sufficient information to which we are entitled under the agreement in order to understand whether other breaches have occurred. The complaint seeks specific performance of Apple’s obligations to cooperate with an audit of its handling of our software, damages and injunctive relief. Apple filed its answer to the complaint on December 29, 2017. On September 24, 2018, we filed a motion seeking to amend our complaint to add causes of action for additional contract breaches and misappropriation of trade secrets. On October 26, 2018, the court granted our motion. We filed an amended complaint on October 31, 2018. No trial date is currently set.

[0001728949-18-000095:notes:62]
On November 29, 2017, we filed three additional complaints against Apple in the United States District Court for the Southern District of California alleging infringement of a total of 16 of our patents. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. The complaints seek damages and injunctive relief. On January 22, 2018, Apple filed answers and counterclaims in each of these cases seeking declaratory judgments that the asserted patents are invalid and/or not infringed. Case management conferences were held on February 7, 2018 and March 1, 2018. For the case relating to the November 30, 2017 ITC investigation described below, fact discovery is scheduled to close on March 13, 2019, and trial is scheduled to begin on October 21, 2019. On June 18, 2018, Apple filed a petition with the USPTO Patent Trial and Appeal Board (PTAB) challenging the validity of one patent asserted in the November 30, 2017 ITC investigation and the corresponding District Court case. On June 29, 2018, Apple filed petitions with the USPTO PTAB challenging the validity of another patent asserted in the November 30, 2017 ITC investigation and the corresponding District Court case. For the cases not related to the ITC investigation, all of the asserted patents have been challenged in IPR proceedings filed by Apple in the USPTO. No decisions have yet been issued by the USPTO. As a result of the IPR proceedings, on August 29, 2018, the court stayed those two cases pending the outcome of the IPR proceedings.

[0001728949-18-000095:notes:63]
On November 30, 2017, we filed a complaint in the ITC accusing certain Apple products of infringing five of our patents. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. We seek a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor chipset. On January 2, 2018, the ITC instituted an investigation. The evidentiary hearing by the Administrative Law Judge (ALJ) took place from September 17-24, 2018 and included three of our patents. The ALJ’s Initial Determination on the merits is due on January 22, 2019, and the target date for final determination by the ITC is set for May 22, 2019.

[0001728949-18-000095:notes:64]
On July 17, 2017, we filed complaints against Apple and certain of its subsidiaries in the Federal Republic of Germany, asserting infringement of one of our patents in the Mannheim District Court and infringement of another patent in the Munich District Court. On October 2, 2017, we filed claim extensions in these actions against Apple and certain of its subsidiaries, asserting infringement of two additional patents in the Mannheim District Court and infringement of five additional patents in the Munich District Court. On May 28, 2018, we filed additional claim extensions in these actions against Apple and certain of its subsidiaries, asserting infringement of three additional patents in the Mannheim District Court and infringement of one additional patent in the Munich District Court. The complaints seek remedies including, among other relief, declaratory relief confirming liability on the merits for damages and injunctive relief. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On October 11, 2018, the Munich District Court issued a judgment declaring one of the patents asserted on October 2, 2017 as not infringed. All other patents remain pending. Hearings are scheduled for various dates through September 2019.

[0001728949-18-000095:notes:65]
On September 29, 2017, we filed three complaints against Apple and certain of its subsidiaries in the Beijing (China) Intellectual Property Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On May 10, 2018 and June 21, 2018, Apple filed invalidation requests with the Chinese Patent Review Board (PRB) for the three asserted patents. The PRB has not ruled on the invalidation requests.

[0001728949-18-000095:notes:66]
On November 13, 2017, we filed three complaints against certain of Apple’s subsidiaries in the Beijing (China) High People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief, damages and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On December 19, 2017, Apple’s subsidiaries filed invalidation requests with the PRB for the three asserted patents. PRB hearings regarding the validity of the patents were held in April and May 2018. The PRB issued rulings upholding the validity of all three patents. On May 22, 2018, Apple’s subsidiaries filed a second invalidation request with the PRB for one of the three asserted patents. The PRB held a hearing regarding this request on October 19, 2018.

[0001728949-18-000095:notes:67]
On November 15, 2017, we filed three complaints against certain of Apple’s subsidiaries in the Fuzhou (China) Intermediate People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Infringement hearings were held in August and September 2018. Subsequent hearings are scheduled for October 29-30, 2018. Apple’s subsidiaries filed invalidation requests with the PRB on December 8, 2017 for one of the patents and December 11, 2017 for the other two patents. PRB hearings regarding the validity of the patents were held in April and May 2018. The PRB issued orders upholding the validity of two of the patents subject to Apple’s invalidity challenges. The PRB has not ruled on the invalidation request with respect to the other patent.

[0001728949-18-000095:notes:68]
On January 12, 2018, we filed three additional complaints against Apple and certain of its subsidiaries in the Fuzhou (China) Intermediate People’s Court, asserting infringement of three additional patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

[0001728949-18-000095:notes:69]
Also on January 12, 2018, we filed three complaints against certain of Apple’s subsidiaries in the Jiangsu (China) High People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief, damages and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On February 5, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents were held in June 2018. The PRB issued orders upholding the validity of one of the patents and partially upholding the validity of another patent. The PRB has not ruled on the invalidation request for the final patent.

[0001728949-18-000095:notes:70]
On February 2, 2018, we filed three complaints against certain of Apple’s subsidiaries in the Qingdao (China) Intermediate People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On February 26, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents were held in June 2018. The PRB issued orders upholding the validity of one of the patents and invalidating another patent. The PRB has not ruled on the invalidation request for the final patent.

[0001728949-18-000095:notes:71]
Also on February 2, 2018, we filed three complaints against certain of Apple’s subsidiaries in the Guangzhou (China) Intermediate People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On March 14, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents began in July 2018. The PRB issued orders upholding the validity of two of the patents. The PRB has not ruled on the invalidation request for the final patent. An infringement hearing for one of the patents was held on October 18, 2018.

[0001728949-18-000095:notes:72]
On June 14, 2018, we filed three complaints against certain of Apple’s subsidiaries in the Guangdong (China) High People’s Court, asserting infringement of three of our patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On August 13, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. The PRB has not yet set hearing dates.

[0001728949-18-000095:notes:73]
We believe Apple’s counterclaims and invalidation requests in the above matters are without merit.

[0001728949-18-000095:notes:74]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, a securities class action complaint was filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers. On April 29, 2016, the plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, the plaintiffs filed a second amended complaint, alleging that we and certain of our current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding our business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint sought unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, we filed a motion to dismiss the second amended complaint. On October 20, 2017, the court entered an order granting in part our motion to dismiss, and on November 29, 2017, the court entered an order granting the remaining portions of our motion to dismiss. On December 28, 2017, the plaintiffs filed an appeal to the United States Court of Appeals for the Ninth Circuit. No hearing date has been set. We believe the plaintiffs’ claims are without merit.

[0001728949-18-000095:notes:75]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. The court has not yet ruled on our motion to dismiss. We believe the plaintiffs’ claims are without merit.

[0001728949-18-000095:notes:76]
Camp v. Qualcomm Incorporated et al: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints allege, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints seek unspecified damages, interest, fees and costs. Upon the appointment of lead plaintiff in the action and the filing of a First Amended Complaint, we anticipate filing a motion to dismiss the complaint, as we believe the plaintiffs’ claims are without merit.

[0001728949-18-000095:notes:77]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Twenty-two such cases remain outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. The case is currently in the discovery stage, with discovery scheduled to close on December 28, 2018. Trial is scheduled to begin on June 24, 2019. We believe the plaintiffs’ claims are without merit.

[0001728949-18-000095:notes:78]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, six consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia, and the Quebec Superior Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the FTC and U.S. consumer class action complaints. The complaints seek unspecified damages. We have not yet answered the complaints.

[0001728949-18-000095:notes:79]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that our business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that our Japanese licensees were forced to cross-license patents to us on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against our other licensees who made a similar commitment in their license agreements with us. The cease and desist order seeks to require us to modify our existing license agreements with Japanese companies to eliminate these provisions while preserving the license of our patents to those companies. We disagree with the conclusions that we forced our Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. We invoked our right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted our motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 37 different dates. No further hearings are currently scheduled. Fines or other monetary remedies are not available in this matter.

[0001728949-18-000095:notes:80]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that we violated Korean law by offering certain discounts and rebates for purchases of our CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents expired. The KFTC levied a fine, which we paid and recorded as an expense in fiscal 2010. We appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, we filed an appeal with the Korea Supreme Court. There have been no material developments since then with respect to this matter.

[0001728949-18-000095:notes:81]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (iii) not demand unjustifiable conditions in our license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred to in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred to in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean Won (approximately $927 million), which we paid on March 30, 2017. We believe that our business practices do not violate the MRFTA, and on February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. On the same day, we filed an application with the Seoul High Court to stay the decision’s remedial order pending the Seoul High Court’s final judgment on our action to cancel the KFTC’s decision. On September 4, 2017, the Seoul High Court denied our application to stay the remedial order, and on November 27, 2017, the Korea Supreme Court dismissed our appeal of the Seoul High Court’s decision on the application to stay. The Seoul High Court has not ruled on our action to cancel the KFTC’s decision.

[0001728949-18-000095:notes:82]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. We were asked by the EC to submit a preliminary response to the portions of the complaint disclosed to us, and we submitted our response in July 2010. Subsequently, we provided additional documents and information as requested by the EC. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, we were engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On August 15, 2016, we submitted our response to the Statement of Objections. On July 19, 2018, the EC announced that it had issued a Supplementary Statement of Objections which focuses on certain elements of the “price-cost” test applied by the EC to assess the extent to which we sold certain baseband chipsets allegedly below cost. On October 22, 2018, we submitted our response to the Supplementary Statement of Objections. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of our revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. We believe that our business practices do not violate the European Union (EU) competition rules.

[0001728949-18-000095:notes:83]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that, pursuant to an agreement with Apple Inc., since 2011, we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets. This conduct allegedly reduced Apple’s incentives to source baseband chipsets from our competitors and harmed competition and innovation for certain baseband chipsets. On January 24, 2018, the EC issued a decision finding that certain terms of that agreement violate EU competition law and imposed a fine of 997 million Euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not ruled on our appeal. We believe that our business practices do not violate the EU competition rules.

[0001728949-18-000095:notes:84]
We recorded a charge of $1.18 billion to other expenses related to the EC fine in the first quarter of fiscal 2018. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. At September 30, 2018, the liability, including related foreign currency gains and accrued interest (which were recorded in investment and other income, net), was $1.17 billion and included in other current liabilities.

[0001728949-18-000095:notes:85]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of baseband processors on the purchaser first agreeing to a license to our standard-essential patents, paying incentives to purchasers of baseband processors to induce them to accept certain license terms, refusing to license our standard-essential patents to our competitors, and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint seeks a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief. A fine is not an available remedy in this matter, and we do not believe that other monetary remedies are likely. On April 19, 2017, the court set a trial date for January 4, 2019. Fact and expert discovery are now closed. On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to rival sellers of modem chipsets. On September 25, 2018, we filed our opposition to this motion, and on October 4, 2018, the FTC filed its reply. On October 15, 2018, we and the FTC submitted a Joint Administrative Motion asking the District Court to defer ruling on the FTC’s partial summary judgment motion in order to facilitate the parties’ ongoing discussions concerning settlement of this litigation, which the District Court denied on the same day. On November 6, 2018, the District Court granted the FTC’s partial summary judgment motion. We believe the FTC’s claims in this case are without merit.

[0001728949-18-000095:notes:86]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified us that it was conducting an investigation into whether our patent licensing practices violate the Taiwan Fair Trade Act (TFTA). On October 11, 2017, the TFTC announced that it had reached a decision in the investigation, finding that we violated the TFTA. On October 23, 2017, we received TFTC’s formal written decision, which found that the following conducts violate the TFTA: (i) refusing to license and demanding restrictive covenants from chipset competitors; (ii) refusing to supply baseband processors to companies that do not have an executed license; and (iii) providing a royalty discount to Apple in exchange for its exclusive use of our chipsets. The TFTC’s decision was based on a four-three vote and included three written dissents. The TFTC’s decision orders us to: (1) cease the following conduct within 60 days of the day after receipt of the decision: (a) applying the clauses in an agreement entered into with a competing chipset supplier requesting it to provide sensitive sales information such as chipset prices, customers, sales volumes, product types and serial numbers; (b) applying clauses in component supply agreements entered into with handset manufacturers relating to the refusal to sell chipsets to unlicensed manufacturers; and (c) applying discount clauses in the exclusive agreement entered into with a relevant enterprise; (2) notify competing chipset companies and handset manufacturers in writing within 30 days after receipt of the decision that those companies may request to amend or enter into patent license agreements and other relevant agreements within 60 days of the day following the day such notices are received, and upon receipt of such requests, we shall commence negotiation in good faith; (3) submit status reports to the TFTC on any such negotiations every six months beginning from the day after receipt of the decision, as well as to submit a report to the TFTC within 30 days after amendments to any license agreements or newly signed license agreements are executed (collectively, the TFTC Remedies). The TFTC’s decision also imposed a fine of 23.4 billion Taiwan Dollars. On December 22, 2017, we filed an Administrative Litigation Complaint in the Taiwan Intellectual Property Court (IPC) to revoke the TFTC’s decision.

[0001728949-18-000095:notes:87]
On August 9, 2018, we announced that we had reached a settlement with the TFTC, which resolved the TFTC’s investigation of us and our litigation challenging the TFTC’s decision. By the terms of the Settlement Transcript executed under the supervision of the IPC, the entire TFTC decision is deemed revoked ab initio, including all TFTC Remedies and the fine, and the Settlement Transcript replaced the TFTC decision in its entirety. As part of the resolution, we agreed to certain process-related commitments confirming principles of mutual good-faith and fairness in the negotiation of agreements with handset licensees regarding our cellular standard-essential patents. The resolution does not require component-level licensing. In addition, we will undertake certain commercial initiatives over the next 5 years for the benefit of the mobile and semiconductor ecosystem (including small- and medium-sized enterprises and consumers), including 5G collaborations, new market expansion, start-up and university collaborations, and the development of a center for operations and manufacturing engineering located in Taiwan. Under the terms of the Settlement Transcript, the resolution of the IPC litigation and the TFTC’s decision shall not constitute or be construed as any evidence of wrongdoing or an admission of liability or wrongdoing. In addition, the terms of the Settlement Transcript fully and finally resolve all concerns expressed by the TFTC with respect to the investigation of our chipset and licensing businesses. Our litigation challenging the TFTC’s decision filed in the IPC is now closed. On August 8, 2018, the IPC denied certain petitions by various companies to intervene into the IPC case. On August 24, 2018, MediaTek filed an Appeal of this decision with the IPC, claiming that its petition to intervene was wrongfully denied. On October 10, 2018, we filed our opposition to MediaTek’s appeal. The TFTC has also filed an opposition to MediaTek’s appeal. The IPC has not set a hearing date for MediaTek’s appeal. We believe that MediaTek’s appeal is without merit.

[0001728949-18-000095:notes:88]
In the fourth quarter of fiscal 2017, we recorded a charge of $778 million to other expenses related to the TFTC fine. The fine was to be paid in monthly installments through December 2022, and prior to the settlement, we paid seven installments totaling $93 million. As a result of the settlement, the parties agreed that the amounts we paid towards the fine through the date of the settlement will be retained by the TFTC, and no other amounts will be due. As a result, we reversed the remaining $676 million accrual to other expenses in the fourth quarter of fiscal 2018.

[0001728949-18-000095:notes:89]
Contingent losses: We will continue to vigorously defend ourself in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fine, we have not recorded any accrual at September 30, 2018 for contingent losses associated with these matters based on our belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0001728949-18-000095:notes:90]
Indemnifications. We generally do not indemnify our customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by us, or by intellectual property provided by us to chipset foundries and semiconductor assembly and test service providers. Our obligations under these agreements may be limited in terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us.

[0001728949-18-000095:notes:91]
Through September 30, 2018, we have received a number of claims from our direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by our products. Reimbursements under indemnification arrangements have not been material to our consolidated financial statements. We have not recorded any accrual for contingent liabilities at September 30, 2018 associated with these indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001728949-18-000095:notes:92]
Purchase Obligations and Operating Leases. We have agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

[0001728949-18-000095:notes:93]
We lease certain of our land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Rental expense for fiscal 2018, 2017 and 2016 was $160 million, $129 million and $116 million, respectively.

[0001728949-18-000095:notes:94]
Obligations under our purchase agreements and future minimum lease payments under our operating leases at September 30, 2018 were as follows (in millions):

[0001728949-18-000095:notes:95]
|  | Integrated Circuit Purchase Obligations |  | Other Purchase Obligations |  | Operating Leases |
| 2019 | $ | 2,647 |  |  | $ | 1,026 |  |  | $ | 117 |  |
| 2020 | 322 |  |  | 308 |  |  | 95 |  |
| 2021 | 62 |  |  | 102 |  |  | 74 |  |
| 2022 | 24 |  |  | 16 |  |  | 53 |  |
| 2023 | — |  |  | 5 |  |  | 31 |  |
| Thereafter | — |  |  | 1 |  |  | 43 |  |
| Total | $ | 3,055 |  |  | $ | 1,458 |  |  | $ | 413 |  |

[0001728949-18-000095:notes:96]
Other Commitments. At September 30, 2018, we have committed to fund certain strategic investments up to $316 million, of which $35 million, $5 million, $70 million, $4 million and $4 million is expected to be funded in each of the five years from fiscal 2019 through fiscal 2023, respectively. The remaining commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all.

[0001728949-18-000095:notes:97]
In March 2018, our RF360 Holdings joint venture entered into an agreement for a build-to-suit construction project with a third-party lessor for the development of a manufacturing facility located in Singapore. The agreement includes a long-term lease commitment with a noncancelable 10-year term commencing upon completion of the construction project. At September 30, 2018, the minimum lease commitment under the agreement based on the noncancelable term was $87 million.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001728949-18-000095:notes:98]
Employee Benefit Plans

[0001728949-18-000095:notes:99]
Employee Savings and Retirement Plan. We have a 401(k) plan that allows eligible employees to contribute up to 85% of their eligible compensation, subject to annual limits. We match a portion of the employee contributions and may, at our discretion, make additional contributions based upon earnings. Our contribution expense was $78 million, $76 million and $74 million in fiscal 2018, 2017 and 2016, respectively.

[0001728949-18-000095:notes:100]
Equity Compensation Plans. On March 8, 2016, our stockholders approved the Qualcomm Incorporated 2016 Long-Term Incentive Plan (the 2016 Plan), which replaced the Qualcomm Incorporated 2006 Long-Term Incentive Plan (the Prior Plan). Effective on and after that date, no new awards will be granted under the Prior Plan, although all outstanding awards under the Prior Plan will remain outstanding according to their terms and the terms of the Prior Plan. The 2016 Plan provides for the grant of incentive and nonstatutory stock options, stock appreciation rights, restricted stock, unrestricted stock, restricted stock units, performance units, performance shares, deferred compensation awards and other stock-based awards. The share reserve under the 2016 Plan is equal to 90.0 million shares, plus approximately 20.1 million shares that were available for future grant under the Prior Plan on March 8, 2016, for a total of approximately 110.1 million shares initially available for grant under the 2016 Plan. This share reserve is automatically increased as provided in the 2016 Plan by the number of shares subject to stock options that were granted under the Prior Plan and outstanding as of March 8, 2016, which after that date expire or for any reason are forfeited, canceled or terminated, and by two times the number of shares subject to any awards other than stock options that were granted under the Prior Plan and outstanding as of March 8, 2016, which after that date expire, are forfeited, canceled or terminated, fail to vest, are not earned due to any performance goal that is not met, are otherwise reacquired without having become vested, or are paid in cash, exchanged by a participant or withheld by us to satisfy any tax withholding or tax payment obligations related to such award. The Board of Directors may amend or terminate the 2016 Plan at any time. Certain amendments, including an increase in the share reserve, require stockholder approval. At September 30, 2018, approximately 79.3 million shares were available for future grant under the 2016 Plan.

[0001728949-18-000095:notes:101]
RSUs are share awards that entitle the holder to receive shares of our common stock upon vesting. The RSUs generally include dividend-equivalent rights and vest over periods of three years from the date of grant. A summary of RSU transactions that contain only service requirements to vest for all equity compensation plans follows:

[0001728949-18-000095:notes:102]
|  | Number of Shares |  | Weighted-AverageGrant Date FairValue |  | Aggregate IntrinsicValue |
|  | (In thousands) |  |  |  | (In billions) |
| RSUs outstanding at September 24, 2017 | 24,704 |  |  | $ | 62.46 |  |  |  |
| RSUs granted | 16,297 |  |  | 62.61 |  |  |  |
| RSUs canceled/forfeited | (4,195 | ) |  | 61.74 |  |  |  |
| RSUs vested | (13,709 | ) |  | 63.43 |  |  |  |
| RSUs outstanding at September 30, 2018 | 23,097 |  |  | $ | 62.12 |  |  | $ | 1.7 |  |

[0001728949-18-000095:notes:103]
At September 30, 2018, total unrecognized compensation expense related to such non-vested RSUs granted prior to that date was $889 million, which is expected to be recognized over a weighted-average period of 1.7 years. The total vest-date fair value of such RSUs that vested during fiscal 2018, 2017 and 2016 was $940 million, $820 million and $685 million, respectively. The total shares withheld to satisfy statutory tax withholding requirements related to all share-based awards were approximately 4.4 million, 4.2 million and 4.3 million in fiscal 2018, 2017 and 2016, respectively, and were based on the value of the awards on their vesting dates as determined by our closing stock price.

[0001728949-18-000095:notes:104]
The Board of Directors may grant stock options to employees, directors and consultants to purchase shares of our common stock at an exercise price not less than the fair market value of the stock at the date of grant. Stock options vest over periods not exceeding five years and are exercisable for up to ten years from the grant date. A summary of stock option transactions that contain only service requirements to vest for all equity compensation plans follows:

[0001728949-18-000095:notes:105]
|  | Number of Shares |  | Weighted- AverageExercisePrice |  | Average RemainingContractual Term |  | Aggregate IntrinsicValue |
|  | (In thousands) |  |  |  | (Years) |  | (In millions) |
| Stock options outstanding at September 24, 2017 | 12,385 |  |  | $ | 40.99 |  |  |  |  |  |
| Stock options canceled/forfeited/expired | (59 | ) |  | 41.78 |  |  |  |  |  |
| Stock options exercised | (7,739 | ) |  | 41.03 |  |  |  |  |  |
| Stock options outstanding at September 30, 2018 | 4,587 |  |  | 40.92 |  |  | 0.8 |  | $ | 143 |  |
| Exercisable at September 30, 2018 | 4,587 |  |  | $ | 40.92 |  |  | 0.8 |  | $ | 143 |  |

[0001728949-18-000095:notes:106]
The total intrinsic value of stock options exercised during fiscal 2018, 2017 and 2016 was $156 million, $118 million and $147 million, respectively, and the amount of cash received from the exercise of stock options was $317 million, $236 million and $436 million, respectively. Upon option exercise, we issue new shares of stock.

[0001728949-18-000095:notes:107]
The total tax benefits realized, including the excess tax benefits, related to share-based awards during fiscal 2018, 2017 and 2016 were $254 million, $301 million and $253 million, respectively.

[0001728949-18-000095:notes:108]
Employee Stock Purchase Plan. We have an employee stock purchase plan for eligible employees to purchase shares of common stock at 85% of the lower of the fair market value on the first or the last day of each offering period, which is generally six months. Employees may authorize us to withhold up to 15% of their compensation during any offering period, subject to certain limitations. The employee stock purchase plan includes a non-423(b) plan. On March 23, 2018, our stockholders approved an amendment to the Amended and Restated QUALCOMM Incorporated 2001 Employee Stock Purchase Plan to increase the share reserve by 30.0 million shares. The shares authorized under the plan were approximately 101.7 million at September 30, 2018. The shares reserved for future issuance were approximately 38.9 million at September 30, 2018. During fiscal 2018, 2017 and 2016, approximately 5.8 million, 5.7 million and 6.0 million shares, respectively, were issued under the plan at an average price of $49.41, $45.29 and $38.89 per share, respectively. At September 30, 2018, total unrecognized compensation expense related to non-vested purchase rights granted prior to that date was $24 million. We recorded cash received from the exercise of purchase rights of $286 million, $260 million and $232 million during fiscal 2018, 2017 and 2016, respectively.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001728949-18-000095:notes:109]
Concentrations. Revenues in fiscal 2018 and 2017 were negatively impacted by our continued dispute with Apple Inc. and Hon Hai Precision Industry Co., Ltd./Foxconn, its affiliates and other suppliers to Apple. We did not record any revenues in fiscal 2018 or the third or fourth quarter of fiscal 2017 for royalties due on sales of Apple’s products.

[0001728949-18-000095:notes:110]
A significant portion of our revenues are concentrated with a small number of customers/licensees of our QCT and QTL segments. Revenues from three customers/licensees comprised 16%, 11% and 11% of total consolidated revenues in fiscal 2018. Revenues from two customers/licensees comprised 17% and 18% in fiscal 2017 and 16% and 24% in fiscal 2016. Excluding the unpaid royalty receivables due from suppliers to Apple (Note 2), aggregate accounts receivable from three customers/licensees comprised 37% and 28% of accounts receivable at September 30, 2018 and September 24, 2017, respectively.

[0001728949-18-000095:notes:111]
We rely on sole- or limited-source suppliers for some products, particularly products in the QCT segment, subjecting us to possible shortages of raw materials or manufacturing capacity. While we have established alternate suppliers for certain technologies that we consider critical, the loss of a supplier or the inability of a supplier to meet performance or quality specifications or delivery schedules could harm our ability to meet our delivery obligations and/or negatively impact our revenues, business operations and ability to compete for future business.


## us-gaap:ConsolidationPolicyTextBlock

[0001728949-18-000095:notes:112]
Principles of Consolidation. Our consolidated financial statements include the assets, liabilities and operating results of majority-owned subsidiaries, including our joint venture RF360 Holdings Singapore Pte. Ltd (RF360 Holdings) (Note 9). During the third quarter of fiscal 2018, we eliminated the one-month reporting lag previously used to consolidate our RF360 Holdings joint venture to provide contemporaneous reporting within our consolidated financial statements. The effect of this change was not material to the consolidated financial statements, and therefore, the impact of eliminating the one-month reporting lag has been included in our results of operations for fiscal 2018.

[0001728949-18-000095:notes:113]
In addition, we consolidated our investment in an immaterial less than majority-owned variable interest entity as we were the primary beneficiary until the end of fiscal 2017. The ownership of the other interest holders of consolidated subsidiaries and the immaterial less than majority-owned variable interest entity is presented separately in the consolidated balance sheets and statements of operations. All significant intercompany accounts and transactions have been eliminated.


## us-gaap:DebtDisclosureTextBlock

[0001728949-18-000095:notes:114]
Debt

[0001728949-18-000095:notes:115]
Revolving Credit Facility. We have an Amended and Restated Revolving Credit Facility (2016 Amended and Restated Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. Proceeds from the Amended and Restated Revolving Credit Facility are expected to be used for general corporate purposes. Loans under the 2016 Amended and Restated Revolving Credit Facility will bear interest, at our option, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the 2016 Amended and Restated Revolving Credit Facility) or the Base Rate (determined in accordance with the 2016 Amended and Restated Revolving Credit Facility), in each case plus an applicable margin based on our long-term unsecured senior, non-credit enhanced debt ratings. The margins over the reserve-adjusted Eurocurrency Rate and the Base Rate will be 0.805% and 0.00% per annum, respectively. The 2016 Amended and Restated Revolving Credit Facility has a facility fee, which accrues at a rate of 0.07% per annum. At September 30, 2018 and September 24, 2017, we had not borrowed any funds under the 2016 Amended and Restated Revolving Credit Facility.

[0001728949-18-000095:notes:116]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At September 30, 2018 and September 24, 2017, we had $1.0 billion and $999 million, respectively, of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 2.35% and 1.19%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 16 days and 45 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at September 30, 2018 and September 24, 2017.

[0001728949-18-000095:notes:117]
NXP-Related Credit and Term Loan Facilities. In July 2018, we terminated our agreement to acquire NXP (Note 9). As a result, the credit agreements that were established primarily to finance the NXP acquisition were terminated in accordance with their terms in the fourth quarter of fiscal 2018. The credit agreements terminated had provided for (a) senior unsecured delayed-draw revolving facility loans in an aggregate amount of $3.0 billion (as amended, the 2018 Revolving Credit Facility), (b) senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion (as amended, the 2016 Term Loan Facility) and (c) senior unsecured delayed-draw term facility loans in an aggregate amount of $7.0 billion (as amended, the 2018 Term Loan Facility). We had not borrowed any funds under the 2018 Revolving Credit Facility, 2016 Term Loan Facility or 2018 Term Loan Facility.

[0001728949-18-000095:notes:118]
Long-term Debt. In May 2015, we issued an aggregate principal amount of $10.0 billion of unsecured floating- and fixed-rate notes (May 2015 Notes) with varying maturities. The proceeds from the May 2015 Notes of $9.9 billion, net of underwriting discounts and offering expenses, were used to fund stock repurchases and also for other general corporate purposes. In May 2017, we issued an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes (May 2017 Notes) with varying maturities. The proceeds from the May 2017 Notes of $10.95 billion, net of underwriting discounts and offering expenses, were intended to be used to finance, in part, our proposed acquisition of NXP and other related transactions and for general corporate purposes. Our floating-rate notes due 2019, floating-rate notes due 2020, fixed-rate 1.85% notes due 2019 and fixed-rate 2.10% notes due 2020 (collectively, the Old SMR Notes) issued in May 2017 for an aggregate principal amount of $4.0 billion were subject to special mandatory redemption provisions that required redemption on the first to occur of (i) the termination of the NXP purchase agreement or (ii) June 1, 2018 if the NXP transaction had not closed as of such date. In May 2018, we completed private offerings to exchange $122 million of the Old SMR Notes for new notes (the New SMR Notes) that had the same principal amount and terms, except for a new special mandatory redemption date of November 1, 2018 and maturity dates that were one day after the applicable maturity dates for the applicable series of Old SMR Notes. Also, in May 2018, we repurchased $71 million of Old SMR Notes that were not eligible for exchange in the May 2018 private offerings. In July 2018, we repurchased $3.8 billion of Old SMR Notes that were not exchanged in the May 2018 private offerings. In August 2018, subsequent to the termination of the NXP acquisition, we repurchased the $122 million of New SMR Notes issued in May 2018.

[0001728949-18-000095:notes:119]
The following table provides a summary of our long-term debt (in millions except percentages):

[0001728949-18-000095:notes:120]
|  |  | September 30, 2018 |  | September 24, 2017 |
|  |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.27% notes due May 18, 2018 | $ | — |  |  |  |  | $ | 250 |  |  | 1.65% |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | 250 |  |  | 2.93% |  | 250 |  |  | 1.92% |
|  | Fixed-rate 1.40% notes due May 18, 2018 | — |  |  |  |  | 1,250 |  |  | 1.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 3.13% |  | 1,750 |  |  | 2.20% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 3.73% |  | 2,000 |  |  | 2.65% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.74% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.72% |  | 1,500 |  |  | 4.71% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.36% notes due May 20, 2019 | — |  |  |  |  | 750 |  |  | 1.80% |
|  | Floating-rate three-month LIBOR plus 0.45% notes due May 20, 2020 | — |  |  |  |  | 500 |  |  | 1.86% |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 3.14% |  | 500 |  |  | 2.11% |
|  | Fixed-rate 1.85% notes due May 20, 2019 | — |  |  |  |  | 1,250 |  |  | 2.00% |
|  | Fixed-rate 2.10% notes due May 20, 2020 | — |  |  |  |  | 1,500 |  |  | 2.19% |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | 1,500 |  |  | 2.70% |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | 1,500 |  |  | 3.01% |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.47% |  | 1,500 |  |  | 4.47% |
|  | Total principal | 15,500 |  |  |  |  | 21,000 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (85 | ) |  |  |  | (106 | ) |  |  |
|  | Hedge accounting fair value adjustments | (50 | ) |  |  |  | — |  |  |  |
|  | Total long-term debt | $ | 15,365 |  |  |  |  | $ | 20,894 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | — |  |  |  |  | $ | 1,496 |  |  |  |
|  | Long-term debt | 15,365 |  |  |  |  | 19,398 |  |  |  |
|  | Total | $ | 15,365 |  |  |  |  | $ | 20,894 |  |  |  |

[0001728949-18-000095:notes:121]
At September 30, 2018, future principal payments were $2.0 billion in fiscal 2020, $2.0 billion in fiscal 2022, $2.0 billion in fiscal 2023 and $9.5 billion after fiscal 2023; no principal payments are due in fiscal 2019 or 2021. At September 30, 2018 and September 24, 2017, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $15.1 billion and $21.5 billion, respectively.

[0001728949-18-000095:notes:122]
We may redeem the outstanding fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. We may not redeem the outstanding floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of our other senior unsecured indebtedness and will effectively rank junior to all liabilities of our subsidiaries.

[0001728949-18-000095:notes:123]
At September 30, 2018, we had outstanding interest rate swaps with an aggregate notional amount of $1.8 billion, related to the May 2015 Notes, which effectively converted approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recorded in earnings in interest expense in the current period. We did not enter into similar interest rate swaps in connection with issuance of the May 2017 Notes.

[0001728949-18-000095:notes:124]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to our commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $662 million, $313 million and $282 million during fiscal 2018, 2017 and 2016, respectively.

[0001728949-18-000095:notes:125]
Debt Covenants. The 2016 Amended and Restated Revolving Credit Facility requires, and the 2016 Term Loan Facility, the 2018 Revolving Credit Facility and the 2018 Term Loan Facility required, that we comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. We are not subject to any financial covenants under the notes nor any covenants that would prohibit us from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by us or our subsidiaries. At September 30, 2018 and September 24, 2017, we were in compliance with the applicable covenants under each facility outstanding at such time.


## us-gaap:DerivativesPolicyTextBlock

[0001728949-18-000095:notes:126]
Derivatives. Our primary objectives for holding derivative instruments are to manage interest rate risk on our long-term debt and to manage foreign exchange risk for certain foreign currency revenues, operating expenses, receivables and payables. Derivative instruments are recorded at fair value and included in other current or noncurrent assets or other current or noncurrent liabilities based on their maturity dates. Counterparties to our derivative instruments are all major banking institutions.

[0001728949-18-000095:notes:127]
Interest Rate Swaps: We manage our exposure to certain interest rate risks related to our long-term debt through the use of interest rate swaps. Such swaps allow us to effectively convert fixed-rate payments into floating-rate payments based on LIBOR. These transactions are designated as fair value hedges, and the gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate debt attributable to the hedged risks, are recognized in earnings as interest expense in the current period. The interest settlement payments associated with the interest rate swap agreements are classified as cash flows from operating activities in the consolidated statements of cash flows.

[0001728949-18-000095:notes:128]
At September 30, 2018 and September 24, 2017, the aggregate fair value of our interest rate swaps related to our long-term debt issued in May 2015 was $50 million and negligible, respectively. The fair values of the swaps were recorded in other noncurrent liabilities at September 30, 2018 and in noncurrent assets, other current liabilities and other noncurrent liabilities at September 24, 2017. At September 30, 2018, the swaps had an aggregate notional amount of $1.8 billion, which effectively converted approximately 43% and 50% of the fixed-rate debt due in 2020 and 2022, respectively, into floating-rate debt, with maturities matching our fixed-rate debt due in 2020 and 2022. At September 24, 2017, the swaps had an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate debt due in 2018 and approximately 43% and 50% of the fixed-rate debt due in 2020 and 2022, respectively, into floating-rate debt, with maturities matching our fixed-rate debt due in 2018, 2020 and 2022.

[0001728949-18-000095:notes:129]
Foreign Currency Hedges: We manage our exposure to foreign exchange market risks, when deemed appropriate, through the use of derivative instruments, including foreign currency forward and option contracts with financial counterparties, that may or may not be designated as hedging instruments. These derivative instruments have maturity dates of less than twelve months. Gains and losses arising from the effective portion of such contracts that are designated as cash flow hedging instruments are recorded as a component of accumulated other comprehensive income as gains and losses on derivative instruments, net of income taxes. The hedging gains and losses in accumulated other comprehensive income are subsequently reclassified to revenues or costs and expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect our earnings. Gains and losses arising from the ineffective portion of such contracts, if any, are recorded in investment and other income, net as gains and losses on derivative instruments. The cash flows associated with derivative instruments designated as cash flow hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The cash flows associated with the ineffective portion of such derivative instruments, if any, are classified as cash flows from investing activities in the consolidated statements of cash flows. The fair values of our foreign currency forward and option contracts used to hedge foreign currency risk designated as cash flow hedges recorded in total assets and in total liabilities were negligible and $19 million, respectively, at September 30, 2018 and $10 million and $22 million, respectively at September 24, 2017.

[0001728949-18-000095:notes:130]
For foreign currency forward and option contracts not designated as hedging instruments, the changes in fair value are recorded in investment and other income, net in the period of change. The cash flows associated with derivative instruments not designated as hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The fair values of our foreign currency forward and option contracts not designated as hedging instruments were negligible at September 30, 2018 and September 24, 2017, respectively.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0001728949-18-000095:notes:131]
A summary of stock option transactions that contain only service requirements to vest for all equity compensation plans follows:

[0001728949-18-000095:notes:132]
A summary of RSU transactions that contain only service requirements to vest for all equity compensation plans follows:


## us-gaap:DividendsDeclaredTableTextBlock

[0001728949-18-000095:notes:133]
Dividends charged to retained earnings in fiscal 2018, 2017 and 2016 were as follows (in millions, except per share data):

[0001728949-18-000095:notes:134]
|  | 2018 |  | 2017 |  | 2016 |
|  | Per Share |  | Total |  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.57 |  |  | $ | 862 |  |  | $ | 0.53 |  |  | $ | 801 |  |  | $ | 0.48 |  |  | $ | 730 |  |
| Second quarter | 0.57 |  |  | 857 |  |  | 0.53 |  |  | 798 |  |  | 0.48 |  |  | 726 |  |
| Third quarter | 0.62 |  |  | 921 |  |  | 0.57 |  |  | 858 |  |  | 0.53 |  |  | 794 |  |
| Fourth quarter | 0.62 |  |  | 877 |  |  | 0.57 |  |  | 857 |  |  | 0.53 |  |  | 796 |  |
|  | $ | 2.38 |  |  | $ | 3,517 |  |  | $ | 2.20 |  |  | $ | 3,314 |  |  | $ | 2.02 |  |  | $ | 3,046 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001728949-18-000095:notes:135]
Earnings (Loss) Per Common Share. Basic earnings (loss) per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans and shares subject to accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Due to the net loss in fiscal 2018, all of the common share equivalents issuable under share-based compensation plans and accelerated share repurchase agreements entered into in fiscal 2018 had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share. The following table provides information about the diluted earnings per share calculation (in millions):

[0001728949-18-000095:notes:136]
|  | 2018 |  | 2017 |  | 2016 |
| Dilutive common share equivalents included in diluted shares | — |  |  | 13.0 |  |  | 13.9 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 51.2 |  |  | 3.0 |  |  | 2.4 |  |


## us-gaap:EquityMethodInvestmentsTextBlock

[0001728949-18-000095:notes:137]
The carrying values of our non-marketable equity investments are recorded in other noncurrent assets and were as follows (in millions):

[0001728949-18-000095:notes:138]
|  | September 30, 2018 |  | September 24, 2017 |
| Equity method investments | $ | 402 |  |  | $ | 379 |  |
| Cost method investments | 650 |  |  | 603 |  |
|  | $ | 1,052 |  |  | $ | 982 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001728949-18-000095:notes:139]
The following table includes the activity for marketable securities, other investments and other liabilities classified within Level 3 of the valuation hierarchy (in millions):

[0001728949-18-000095:notes:140]
|  | 2018 |  | 2017 |
|  | Marketable Securities |  | Other Investments |  | Other Liabilities |  | Marketable Securities |  | Other Investments |  | Other Liabilities |
| Beginning balance of Level 3 | $ | 40 |  |  | $ | 125 |  |  | $ | 196 |  |  | $ | 43 |  |  | $ | 37 |  |  | $ | — |  |
| Total realized and unrealized gains or losses: |  |  |  |  |  |  |  |  |  |  |  |
| Included in selling, general and administrative and other expenses | — |  |  | — |  |  | (64 | ) |  | — |  |  | — |  |  | (7 | ) |
| Included in investment and other income, net | — |  |  | 6 |  |  | — |  |  | — |  |  | 3 |  |  | — |  |
| Included in other comprehensive (loss) income | — |  |  | 7 |  |  | — |  |  | — |  |  | 8 |  |  | — |  |
| Issuances | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 203 |  |
| Purchases | — |  |  | 7 |  |  | — |  |  | — |  |  | 111 |  |  | — |  |
| Sales | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlements | (5 | ) |  | (129 | ) |  | (46 | ) |  | (3 | ) |  | (34 | ) |  | — |  |
| Transfers into Level 3 | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Transfers out of Level 3 | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Ending balance of Level 3 | $ | 35 |  |  | $ | 16 |  |  | $ | 86 |  |  | $ | 40 |  |  | $ | 125 |  |  | $ | 196 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-18-000095:notes:141]
Fair Value Measurements

[0001728949-18-000095:notes:142]
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at September 30, 2018 (in millions):

[0001728949-18-000095:notes:143]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 7,147 |  |  | $ | 2,867 |  |  | $ | — |  |  | $ | 10,014 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 144 |  |  | — |  |  | 144 |  |
| Auction rate securities | — |  |  | — |  |  | 35 |  |  | 35 |  |
| Equity and preferred securities | 167 |  |  | — |  |  | — |  |  | 167 |  |
| Total marketable securities | 167 |  |  | 144 |  |  | 35 |  |  | 346 |  |
| Derivative instruments | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Other investments | 380 |  |  | — |  |  | 16 |  |  | 396 |  |
| Total assets measured at fair value | $ | 7,694 |  |  | $ | 3,014 |  |  | $ | 51 |  |  | $ | 10,759 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 71 |  |  | $ | — |  |  | $ | 71 |  |
| Other liabilities | 380 |  |  | — |  |  | 86 |  |  | 466 |  |
| Total liabilities measured at fair value | $ | 380 |  |  | $ | 71 |  |  | $ | 86 |  |  | $ | 537 |  |

[0001728949-18-000095:notes:144]
Activity within Level 3 of the Fair Value Hierarchy. The following table includes the activity for marketable securities, other investments and other liabilities classified within Level 3 of the valuation hierarchy (in millions):

[0001728949-18-000095:notes:145]
We recognize transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. Other investments and other liabilities included in Level 3 at September 30, 2018 and September 24, 2017 were comprised of convertible debt instruments issued by private companies and contingent consideration related to business combinations, respectively.

[0001728949-18-000095:notes:146]
Nonrecurring Fair Value Measurements. We measure certain assets and liabilities at fair value on a nonrecurring basis. These assets and liabilities include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During fiscal 2018, we updated the business plans and related internal forecasts related to certain of our businesses, resulting in impairment charges to write down certain property, plant and equipment, intangible assets and goodwill (Note 10). We determined the fair values using cost, market and income approaches. The estimation of fair value and cash flows used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During fiscal 2018, 2017 and 2016, we did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001728949-18-000095:notes:147]
Fair Value Measurements. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants as of the measurement date. Applicable accounting guidance provides an established hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Observable inputs are inputs that market participants would use in valuing the asset or liability and are developed based on market data obtained from sources independent of us. Unobservable inputs are inputs that reflect our assumptions about the factors that market participants would use in valuing the asset or liability. There are three levels of inputs that may be used to measure fair value:

[0001728949-18-000095:notes:148]
| • | Level 1 includes financial instruments for which quoted market prices for identical instruments are available in active markets. |

[0001728949-18-000095:notes:149]
| • | Level 2 includes financial instruments for which there are inputs other than quoted prices included within Level 1 that are observable for the instrument. |

[0001728949-18-000095:notes:150]
| • | Level 3 includes financial instruments for which fair value is derived from valuation techniques in which one or more significant inputs are unobservable, including our own assumptions. |

[0001728949-18-000095:notes:151]
Assets and liabilities are classified based on the lowest level of input that is significant to the fair value measurement. We review the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy.

[0001728949-18-000095:notes:152]
Cash Equivalents and Marketable Securities: With the exception of auction rate securities, we obtain pricing information from quoted market prices, pricing vendors or quotes from brokers/dealers. We conduct reviews of our primary pricing vendors to determine whether the inputs used in the vendor’s pricing processes are deemed to be observable. The fair value for interest-bearing securities includes accrued interest.

[0001728949-18-000095:notes:153]
The fair value of U.S. Treasury securities and government-related securities, corporate bonds and notes and common and preferred stock is generally determined using standard observable inputs, including reported trades, quoted market prices, matrix pricing, benchmark yields, broker/dealer quotes, issuer spreads, two-sided markets and/or benchmark securities.

[0001728949-18-000095:notes:154]
The fair value of debt and equity funds is reported at published net asset values. We assess the daily frequency and size of transactions at published net asset values and/or the funds’ underlying holdings to determine whether fair value is based on observable or unobservable inputs.

[0001728949-18-000095:notes:155]
The fair value of auction rate securities is estimated using a discounted cash flow model that incorporates transaction details, such as contractual terms, maturity and timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery, the future state of the auction rate market and credit valuation adjustments of market participants. Though most of the securities we hold are pools of student loans guaranteed by the United States government, prepayment speeds and illiquidity discounts are considered significant unobservable inputs. These additional inputs are generally unobservable, and therefore, auction rate securities are included in Level 3.

[0001728949-18-000095:notes:156]
Derivative Instruments: Derivative instruments that are traded on an exchange are valued using quoted market prices and are included in Level 1. Derivative instruments that are not traded on an exchange are valued using conventional calculations/models that are primarily based on observable inputs, such as foreign currency exchange rates, volatilities and interest rates, and therefore, such derivative instruments are included in Level 2.

[0001728949-18-000095:notes:157]
Other Investments and Other Liabilities: Other investments and other liabilities included in Level 1 are comprised of our deferred compensation plan liability and related assets, which consist of mutual funds classified as trading securities, and are included in other assets. Other investments and other liabilities included in Level 3 are comprised of convertible debt instruments issued by private companies and contingent consideration related to business combinations, respectively. The fair value of convertible debt instruments is estimated based on the estimated timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery. The fair value of contingent consideration related to business combinations is estimated using either a real options approach or discounted cash flow model, both of which include inputs, such as projected financial information, market volatility, discount rates and timing of contractual payments. The inputs we use to estimate the fair values of the convertible debt instruments and contingent consideration are generally unobservable, and therefore, they are included in Level 3.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001728949-18-000095:notes:158]
Foreign Currency. Certain foreign subsidiaries use a local currency as the functional currency. Resulting translation gains or losses are recognized as a component of accumulated other comprehensive income. Transaction gains or losses related to balances denominated in a currency other than the functional currency are recognized in the consolidated statements of operations.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001728949-18-000095:notes:159]
Goodwill and Other Intangible Assets. Goodwill represents the excess of purchase price over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Acquired intangible assets other than goodwill are amortized over their useful lives unless the lives are determined to be indefinite. For intangible assets purchased in a business combination, the estimated fair values of the assets received are used to establish their recorded values. For intangible assets acquired in a non-monetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001728949-18-000095:notes:160]
Impairment of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. Goodwill and other indefinite-lived intangible assets are tested annually for impairment in the fourth fiscal quarter and in interim periods if events or changes in circumstances indicate that the assets may be impaired. If a qualitative assessment is used and we determine that the fair value of a reporting unit or indefinite-lived intangible asset is more likely than not (i.e., a likelihood of more than 50%) less than its carrying amount, a quantitative impairment test will be performed. Pursuant to the new guidance adopted in the fourth quarter of fiscal 2018, if goodwill is quantitatively assessed for impairment and a reporting unit’s carrying value exceeds its fair value, the difference is recorded as an impairment. Other indefinite-lived intangible assets are quantitatively assessed for impairment, if necessary, by comparing their estimated fair values to their carrying values. If the carrying value exceeds the fair value, the difference is recorded as an impairment.

[0001728949-18-000095:notes:161]
Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by comparing the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Long-lived assets to be disposed of by sale are reported at the lower of their carrying amounts or their estimated fair values less costs to sell and are not depreciated.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-18-000095:notes:162]
Income Taxes

[0001728949-18-000095:notes:163]
The components of the income tax provision were as follows (in millions):

[0001728949-18-000095:notes:164]
|  | 2018 |  | 2017 |  | 2016 |
| Current provision (benefit): |  |  |  |  |  |
| Federal | $ | 2,559 |  |  | $ | 72 |  |  | $ | 4 |  |
| State | (1 | ) |  | 3 |  |  | 4 |  |
| Foreign | 777 |  |  | 1,256 |  |  | 1,411 |  |
|  | 3,335 |  |  | 1,331 |  |  | 1,419 |  |
| Deferred provision (benefit): |  |  |  |  |  |
| Federal | 1,867 |  |  | (586 | ) |  | (184 | ) |
| State | 1 |  |  | 4 |  |  | 6 |  |
| Foreign | 174 |  |  | (194 | ) |  | (110 | ) |
|  | 2,042 |  |  | (776 | ) |  | (288 | ) |
|  | $ | 5,377 |  |  | $ | 555 |  |  | $ | 1,131 |  |

[0001728949-18-000095:notes:165]
The foreign component of the income tax provision consisted primarily of foreign withholding taxes on royalty revenues included in U.S. earnings.

[0001728949-18-000095:notes:166]
The components of income before income taxes by U.S. and foreign jurisdictions were as follows (in millions):

[0001728949-18-000095:notes:167]
|  | 2018 |  | 2017 |  | 2016 |
| United States | $ | (1,713 | ) |  | $ | (762 | ) |  | $ | 3,032 |  |
| Foreign | 2,226 |  |  | 3,782 |  |  | 3,801 |  |
|  | $ | 513 |  |  | $ | 3,020 |  |  | $ | 6,833 |  |

[0001728949-18-000095:notes:168]
The foreign component of income before income taxes in foreign jurisdictions consisted primarily of income earned in Singapore.

[0001728949-18-000095:notes:169]
The following is a reconciliation of the expected statutory federal income tax provision to our actual income tax provision (in millions):

[0001728949-18-000095:notes:170]
|  | 2018 |  | 2017 |  | 2016 |
| Expected income tax provision at federal statutory tax rate | $ | 127 |  |  | $ | 1,057 |  |  | $ | 2,392 |  |
| State income tax provision, net of federal benefit | 2 |  |  | 8 |  |  | 19 |  |
| Toll Charge from U.S. tax reform | 5,236 |  |  | — |  |  | — |  |
| Benefits from foreign income taxed at other than U.S. rates | (834 | ) |  | (963 | ) |  | (1,068 | ) |
| Valuation allowance on deferred tax assets related to NXP termination fee (Note 9) | 494 |  |  | — |  |  | — |  |
| Remeasurement of deferred taxes due to changes in statutory rate due to U.S. tax reform | 438 |  |  | — |  |  | — |  |
| Benefits related to research and development tax credits | (136 | ) |  | (81 | ) |  | (143 | ) |
| Nondeductible charges and reversals related to the EC, KFTC and TFTC investigations | (119 | ) |  | 363 |  |  | — |  |
| Taxes on undistributed foreign earnings | 87 |  |  | — |  |  | — |  |
| Impact of changes in tax reserves and audit settlements for prior year tax positions | — |  |  | 111 |  |  | — |  |
| Worthless stock deduction of domestic subsidiary | — |  |  | — |  |  | (101 | ) |
| Other | 82 |  |  | 60 |  |  | 32 |  |
|  | $ | 5,377 |  |  | $ | 555 |  |  | $ | 1,131 |  |

[0001728949-18-000095:notes:171]
On December 22, 2017, tax reform legislation known as the Tax Cuts and Jobs Act (the Tax Legislation) was enacted in the United States. The Tax Legislation significantly revises the United States corporate income tax by, among other things, lowering the corporate income tax rate to 21%, implementing a modified territorial tax system and imposing a one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge). As a fiscal-year taxpayer, certain provisions of the Tax Legislation impacted us in fiscal 2018, including the change in the corporate income tax rate and the Toll Charge, while other provisions will be effective starting at the beginning of fiscal 2019, including the implementation of a modified territorial tax system. The United States federal income tax rate reduction was effective as of January 1, 2018. Accordingly, our federal statutory income tax rate for fiscal 2018 reflected a blended rate of approximately 25%.

[0001728949-18-000095:notes:172]
Pursuant to the Securities and Exchange Commission Staff Accounting Bulletin No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act, we have not finalized the accounting for the income tax effects of the Tax Legislation related to the Toll Charge. Further, we are in the process of analyzing the effects of new taxes due on certain foreign income, such as GILTI (global intangible low-taxed income), BEAT (base-erosion anti-abuse tax) and FDII (foreign-derived intangible income), and limitations on interest expense deductions (if certain conditions apply), all of which are effective starting in fiscal 2019, as well as other provisions of the Tax Legislation. We have elected to account for GILTI as period costs, if and when incurred. As a result of recognizing the impact of the Tax Legislation in income tax expense, certain tax effects, which were nominal, were stranded in accumulated other comprehensive income, and we will not reclassify such amounts to retained earnings. The impact of the Tax Legislation related to the Toll Charge may differ from this estimate during the remainder of the one-year measurement period due to, among other things, further refinement of our calculations, changes in interpretations and assumptions we have made, guidance that may be issued and actions we may take as a result of the Tax Legislation.

[0001728949-18-000095:notes:173]
As a result of the Tax Legislation, we recorded a charge of $5.7 billion to income tax expense in fiscal 2018, comprised of $5.2 billion related to the estimated Toll Charge and $438 million resulting from the remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate, which included a $135 million tax benefit recorded in fiscal 2018 related to the remeasurement of a U.S. deferred tax liability that was established as a result of a change in one of our tax positions due to Tax Legislation.

[0001728949-18-000095:notes:174]
The Toll Charge is based on our post-1986 earnings and profits of U.S.-owned foreign subsidiaries through December 31, 2017 for which we had previously deferred U.S. income taxes. We have not yet finalized our calculation of the total post-1986 foreign earnings and profits for the respective foreign subsidiaries. Further, the Toll Charge is based in part on the amount of those earnings held in cash and other specific assets. In addition, we remeasured our deferred tax assets and liabilities that existed at the end of fiscal 2017 based on the income tax rate at which they are expected to reverse, which primarily assumes the reduced income tax rate of 21% applicable in fiscal 2019, resulting in a reduction to noncurrent net deferred tax assets of $438 million in fiscal 2018.

[0001728949-18-000095:notes:175]
We have historically asserted our intention to indefinitely reinvest the operating earnings of certain non-U.S. subsidiaries outside the United States based on our plans for use and/or investment outside of the United States and our belief that our sources of cash and liquidity in the United States would be sufficient to meet future domestic cash needs. The Tax Legislation eliminated certain material tax effects on the repatriation of cash to the United States. Future repatriation of cash and other property held by our foreign subsidiaries will generally not be subject to U.S. federal income tax. As a result, we reevaluated our historic assertion, and as of September 30, 2018, we no longer consider substantially all of our foreign earnings to be indefinitely reinvested in our foreign subsidiaries. As a result of our change in assertion, during fiscal 2018, we recorded a charge of $87 million to income tax expense related to outside basis differences that are no longer permanently reinvested. We have not recorded a deferred tax liability of approximately $31 million related to foreign withholding taxes on approximately $137 million of undistributed earnings of certain subsidiaries that we continue to consider to be indefinitely reinvested outside the United States. Should we decide to no longer indefinitely reinvest such earnings outside the United States, we would have to adjust the income tax provision in the period management makes such determination.

[0001728949-18-000095:notes:176]
As a result of the Toll Charge imposed by the Tax Legislation, we expect to fully utilize all of our unused federal tax credits that existed at the end of fiscal 2017 of $1.3 billion. We will elect to pay the Toll Charge, interest free, over a period of eight years, with payments beginning on January 15, 2019. We did not discount the amount of the Toll Charge. At September 30, 2018, we estimated that we will pay $2.5 billion for the Toll Charge, which was net of tax credit carryforwards and tax credits generated through fiscal 2018. This amount may be further reduced by excess tax credits generated in fiscal 2019. At September 30, 2018, $201 million, which represents the first installment that is due on January 15, 2019, was included in other current liabilities, with the remaining liability included in noncurrent income taxes payable.

[0001728949-18-000095:notes:177]
As a result of the Tax Legislation, in fiscal 2019, several of our foreign subsidiaries will make tax elections to be treated as U.S. branches for federal income tax purposes (commonly referred to as “check-the-box” elections) effective beginning in fiscal 2018 and 2019. We believe that, by these foreign subsidiaries being treated as U.S. branches for federal income taxes, rather than controlled foreign corporations, we will significantly reduce the risk of being subject to GILTI and BEAT taxes, both of which are effective for us starting in fiscal 2019. As a result of making these check-the-box elections in the first quarter of fiscal 2019, we expect to record an estimated tax benefit of $525 million to $575 million due to establishing new U.S. net deferred tax assets resulting from the difference between the GAAP basis and the U.S. federal tax carryover basis of the existing assets and liabilities of those foreign subsidiaries, primarily related to customer incentive liabilities that have not been deducted for tax purposes. Additionally, during fiscal 2018, one of our foreign subsidiaries distributed certain intellectual property to a U.S. subsidiary resulting in a difference between the GAAP basis and the U.S. federal tax basis of the distributed intellectual property. Upon adoption of the new guidance in the first quarter fiscal 2019 that changes the accounting for income tax effects of such intra-entity transfers of assets (Note 1), we expect to record an estimated deferred tax asset of approximately $2.5 billion.

[0001728949-18-000095:notes:178]
Income tax expense for fiscal 2018 was further negatively impacted by the charge recorded in the fourth quarter of fiscal 2018 related to the termination fee paid to NXP, which did not result in a tax benefit after the consideration of realizability of such loss. Fiscal 2018 and 2017 income tax expense was also impacted by the EC, KFTC and TFTC fines, and settlement with the TFTC, which are not deductible for tax purposes and portions of which were attributable to foreign jurisdictions and to the United States. These impacts were partially offset in fiscal 2018 and 2017 by lower U.S. revenues primarily related to decreased royalty revenues from Apple’s contract manufacturers and, for fiscal 2017, the BlackBerry arbitration.

[0001728949-18-000095:notes:179]
Income tax expense for fiscal 2017 also reflected the increase in our Singapore tax rate as a result of the expiration of certain of our tax incentives in March 2017, which was substantially offset by tax benefits resulting from the increase in our Singapore tax rate that will be in effect when certain deferred tax assets are scheduled to reverse. During the third quarter of fiscal 2018, we entered into a new tax incentive agreement in Singapore that results in a reduced tax rate from March 2017 through March 2022, provided that we meet specified employment and investment criteria in Singapore. Our Singapore tax rate will increase in March 2022 as a result of expiration of these incentives and again in March 2027 upon the expiration of tax incentives under a prior agreement. As a result of this new tax incentive, our income tax expense for fiscal 2018 was reduced by approximately $130 million. Without these tax incentives, our income tax expense would have been higher and impacted earnings (loss) per share attributable to Qualcomm as follows (in millions, except per share amounts):

[0001728949-18-000095:notes:180]
|  | 2018 |  | 2017 |  | 2016 |
| Additional income tax expense | $ | 652 |  |  | $ | 493 |  |  | $ | 487 |  |
| Reduction to diluted earnings (loss) per share | 0.45 |  |  | 0.33 |  |  | 0.32 |  |

[0001728949-18-000095:notes:181]
We had deferred tax assets and deferred tax liabilities as follows (in millions):

[0001728949-18-000095:notes:182]
|  | September 30, 2018 |  | September 24, 2017 |
| Unused tax credits | $ | 1,044 |  |  | $ | 1,798 |  |
| Unused net operating losses | 696 |  |  | 208 |  |
| Unearned revenues | 446 |  |  | 886 |  |
| Accrued liabilities and reserves | 396 |  |  | 888 |  |
| Unrealized losses on other investments and marketable securities | 126 |  |  | 151 |  |
| Share-based compensation | 97 |  |  | 241 |  |
| Other | 26 |  |  | 21 |  |
| Total gross deferred tax assets | 2,831 |  |  | 4,193 |  |
| Valuation allowance | (1,529 | ) |  | (863 | ) |
| Total net deferred tax assets | 1,302 |  |  | 3,330 |  |
| Intangible assets | (322 | ) |  | (535 | ) |
| Accrued revenues | (202 | ) |  | — |  |
| Accrued withholding taxes | (90 | ) |  | — |  |
| Unrealized gains on other investments and marketable securities | (26 | ) |  | (33 | ) |
| Other | (49 | ) |  | (95 | ) |
| Total deferred tax liabilities | (689 | ) |  | (663 | ) |
| Net deferred tax assets | $ | 613 |  |  | $ | 2,667 |  |
| Reported as: |  |  |  |
| Non-current deferred tax assets | $ | 904 |  |  | $ | 2,900 |  |
| Non-current deferred tax liabilities (1) | (291 | ) |  | (233 | ) |
|  | $ | 613 |  |  | $ | 2,667 |  |

[0001728949-18-000095:notes:183]
| (1) | Non-current deferred tax liabilities were included in other liabilities in the consolidated balance sheets. |

[0001728949-18-000095:notes:184]
At September 30, 2018, we had unused federal net operating loss carryforwards of $213 million expiring from 2021 through 2035, unused state net operating loss carryforwards of $949 million expiring from 2019 through 2038 and unused foreign net operating loss carryforwards of $2.3 billion, of which $2.0 billion expire in 2027. At September 30, 2018, we had unused state tax credits of $892 million, of which substantially all may be carried forward indefinitely, unused federal tax credits of $126 million expiring from 2026 through 2028 and unused tax credits of $26 million in foreign jurisdictions expiring from 2033 through 2038. We do not expect our federal net operating loss carryforwards to expire unused.

[0001728949-18-000095:notes:185]
At September 30, 2018, we have provided a valuation allowance on certain state tax credits, foreign deferred tax assets and state net operating losses of $879 million, $604 million and $46 million, respectively. The valuation allowances reflect the uncertainties surrounding our ability to generate sufficient future taxable income in certain foreign and state tax jurisdictions to utilize our net operating losses and our ability to generate sufficient capital gains to utilize all capital losses. We believe, more likely than not, that we will have sufficient taxable income after deductions related to share-based awards to utilize our remaining deferred tax assets.

[0001728949-18-000095:notes:186]
A summary of the changes in the amount of unrecognized tax benefits for fiscal 2018, 2017 and 2016 follows (in millions):

[0001728949-18-000095:notes:187]
|  | 2018 |  | 2017 |  | 2016 |
| Beginning balance of unrecognized tax benefits | $ | 372 |  |  | $ | 271 |  |  | $ | 40 |  |
| Additions based on prior year tax positions | 7 |  |  | 92 |  |  | 20 |  |
| Reductions for prior year tax positions and lapse in statute of limitations | (11 | ) |  | (11 | ) |  | (6 | ) |
| Additions for current year tax positions | 18 |  |  | 23 |  |  | 218 |  |
| Settlements with taxing authorities | (169 | ) |  | (3 | ) |  | (1 | ) |
| Ending balance of unrecognized tax benefits | $ | 217 |  |  | $ | 372 |  |  | $ | 271 |  |

[0001728949-18-000095:notes:188]
We believe that it is reasonably possible that certain unrecognized tax benefits recorded at September 30, 2018 may result in a cash payment in fiscal 2019. Unrecognized tax benefits at September 30, 2018 included $92 million for tax positions that, if recognized, would impact the effective tax rate. The unrecognized tax benefits differ from the amount that would affect our effective tax rate primarily because the unrecognized tax benefits were included on a gross basis and did not reflect secondary impacts such as the federal deduction for state taxes, adjustments to deferred tax assets and the valuation allowance that might be required if our tax positions are sustained. The decrease in unrecognized tax benefits in fiscal 2018 was primarily due to an agreement reached with the IRS related to tax positions on the classification of income in our fiscal 2016 federal income tax return. The increase in unrecognized tax benefits in fiscal 2017 was primarily due to tax positions related to transfer pricing. We believe that it is reasonably possible that the total amount of unrecognized tax benefits at September 30, 2018 may increase or decrease in fiscal 2019.

[0001728949-18-000095:notes:189]
We file income tax returns in the United States federal jurisdiction and various state and foreign jurisdictions. We are currently a participant in the IRS Compliance Assurance Process, whereby we and the IRS endeavor to agree on the treatment of all tax issues prior to the tax return being filed. We are no longer subject to U.S. federal income tax examinations for years prior to fiscal 2015. We are subject to examination by the California Franchise Tax Board for fiscal years after 2014. We are also subject to examination in other taxing jurisdictions in the United States and numerous foreign jurisdictions, most notably in countries where we earn a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2000. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of September 30, 2018, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0001728949-18-000095:notes:190]
Cash amounts paid for income taxes, net of refunds received, were $877 million, $1.0 billion and $1.3 billion for fiscal 2018, 2017 and 2016, respectively.


## us-gaap:IncomeTaxPolicyTextBlock

[0001728949-18-000095:notes:191]
Income Taxes. The asset and liability approach is used to recognize deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax bases of assets and liabilities. Tax law and rate changes are reflected in income in the period such changes are enacted. We record a valuation allowance to reduce deferred tax assets to the amount that is more likely than not to be realized. We include interest and penalties related to income taxes, including unrecognized tax benefits, within income tax expense. We classify all deferred tax assets and liabilities as noncurrent in the consolidated balance sheets.

[0001728949-18-000095:notes:192]
Our income tax returns are based on calculations and assumptions that are subject to examination by the Internal Revenue Service and other tax authorities. In addition, the calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. While we believe we have appropriate support for the positions taken on our tax returns, we regularly assess the potential outcomes of examinations by tax authorities in determining the adequacy of our provision for income taxes. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts that give rise to a revision become known.

[0001728949-18-000095:notes:193]
Beginning in fiscal 2018, we recognize excess tax benefits and shortfall tax detriments associated with share-based awards in the consolidated statements of operations, as a component of income tax expense, when realized. Prior to fiscal 2018, we recognized such excess tax benefits and shortfall tax detriments directly to stockholders’ equity when realized since, in the case of shortfall tax detriments, we had a sufficient APIC windfall pool. An excess tax benefit occurs when the actual tax benefit realized by us upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that we had recorded. A shortfall tax detriment occurs when the actual tax benefit realized by us upon an employee’s disposition of a share-based award is less than the deferred tax asset, if any, associated with the award that we have recorded.


## us-gaap:InventoryPolicyTextBlock

[0001728949-18-000095:notes:194]
Inventories. Inventories are valued at the lower of cost and net realizable value using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers and our own forecast of customer demand, among other things.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001728949-18-000095:notes:195]
At September 30, 2018, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001728949-18-000095:notes:196]
|  | September 30, 2018 |
| Years to Maturity: |  |
| Less than one year | $ | 140 |  |
| One to five years | 4 |  |
| No single maturity date | 35 |  |
| Total | $ | 179 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-18-000095:notes:197]
Marketable Securities

[0001728949-18-000095:notes:198]
Marketable securities were comprised as follows (in millions):

[0001728949-18-000095:notes:199]
|  | Current |  | Noncurrent |
|  | September 30, 2018 |  | September 24, 2017 |  | September 30, 2018 |  | September 24, 2017 |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 959 |  |
| Corporate bonds and notes | 144 |  |  | 2,014 |  |  | — |  |  | 271 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 93 |  |  | 35 |  |  | 40 |  |
| Equity and preferred securities and equity funds | 167 |  |  | 36 |  |  | — |  |  | — |  |
| Debt funds | — |  |  | 109 |  |  | — |  |  | — |  |
| Total available-for-sale | 311 |  |  | 2,275 |  |  | 35 |  |  | 1,270 |  |
| Time deposits | — |  |  | 4 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 311 |  |  | $ | 2,279 |  |  | $ | 35 |  |  | $ | 1,270 |  |

[0001728949-18-000095:notes:200]
Debt securities with no single maturity date included auction rate securities.

[0001728949-18-000095:notes:201]
We recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001728949-18-000095:notes:202]
|  | 2018 |  | 2017 |  | 2016 |
| Gross realized gains | $ | 27 |  |  | $ | 553 |  |  | $ | 277 |  |
| Gross realized losses | (6 | ) |  | (127 | ) |  | (37 | ) |
| Net realized gains | $ | 21 |  |  | $ | 426 |  |  | $ | 240 |  |

[0001728949-18-000095:notes:203]
Available-for-sale securities were comprised as follows (in millions):

[0001728949-18-000095:notes:204]
|  | September 30, 2018 |  | September 24, 2017 |
| Equity securities |  |  |  |
| Cost | $ | 104 |  |  | $ | 8 |  |
| Unrealized gains | 63 |  |  | 28 |  |
| Fair value | 167 |  |  | 36 |  |
| Debt securities (including debt funds) |  |  |  |
| Cost | 179 |  |  | 3,497 |  |
| Unrealized gains | — |  |  | 13 |  |
| Unrealized losses | — |  |  | (1 | ) |
| Fair value | 179 |  |  | 3,509 |  |
|  | $ | 346 |  |  | $ | 3,545 |  |

[0001728949-18-000095:notes:205]
In connection with the proposed NXP transaction (Note 9), we divested a substantial portion of our marketable securities portfolio in order to finance, in part, that transaction. Given our intention to sell certain marketable securities, we recorded other-than-temporary impairment losses in fiscal 2017 for certain marketable securities, and no additional losses were recorded in fiscal 2018. Marketable securities that were expected to be used to finance the NXP transaction were fully liquidated, a portion of which were used to fund the stock repurchase program (Note 4) with the remaining classified as cash and cash equivalents at September 30, 2018.


## us-gaap:LegalCostsPolicyTextBlock

[0001728949-18-000095:notes:206]
Our legal costs associated with defending ourself are recorded to expense as incurred.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001728949-18-000095:notes:207]
Recent Accounting Pronouncements.

[0001728949-18-000095:notes:208]
Share-based Awards: In March 2016, the Financial Accounting Standards Board (FASB) issued new guidance that changed the accounting for share-based awards, including income taxes, classification of awards and classification in the statement of cash flows. We adopted the new guidance in the first quarter of fiscal 2018. In accordance with the new guidance, excess tax benefits or deficiencies associated with share-based awards are recognized through earnings when the awards vest or settle, rather than in stockholders’ equity. In fiscal 2018, net excess tax benefits associated with share-based awards of $22 million were recognized in income tax expense. In addition, cash flows related to excess tax benefits are presented as an operating activity and cash payments made on an employee’s behalf for withheld shares are presented as financing activities, with the prior periods adjusted accordingly. As a result of these changes, amounts for fiscal 2017 and fiscal 2016 have been adjusted as follows: net cash provided by operating activities increased by $308 million and $232 million, respectively, with a corresponding offset to net cash used in financing activities. The new guidance also impacts our earnings per share calculation as the estimate of dilutive common share equivalents under the treasury stock method no longer assumes that the estimated tax benefits realized when an award is settled are used to repurchase shares. There was no impact of this change on our calculation of earnings per share as a result of the net loss for fiscal 2018. We elected to continue our practice of estimating forfeitures expected to occur in determining the amount of compensation cost to be recognized each period.

[0001728949-18-000095:notes:209]
Revenue Recognition: In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue as control of goods or services transfers to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. We will adopt the new guidance in the first quarter of fiscal 2019 using the modified retrospective approach, with the cumulative effect of applying the new guidance recognized as an adjustment to the opening retained earnings balance. We currently estimate such adjustment will result in an increase of approximately $800 million to $1.0 billion to the opening retained earnings balance for fiscal 2019, primarily related to the impacts described below, net of the associated tax effects. We have finalized our identification of changes to policy, processes and systems, as well as our assessment of data availability, and we are in the process of finalizing changes to our controls and presentation necessary to meet the additional disclosure requirements of the guidance in the notes to the consolidated financial statements.

[0001728949-18-000095:notes:210]
We currently expect the adoption of this new guidance to most significantly impact our licensing business (Qualcomm Technology Licensing, or QTL). Specifically, we expect a change in the timing of revenues recognized from sales-based royalties, which are the vast majority of QTL’s revenues. We currently recognize sales-based royalties as revenues in the period in which such royalties are reported by licensees, which is after the conclusion of the quarter in which the licensees’ sales occur and when all other revenue recognition criteria are met. Under the new guidance, we will be required to estimate and recognize sales-based royalties in the period in which the associated sales occur, resulting in an acceleration of revenue recognition compared to the current method. As a result of recognizing royalty revenues based on estimates, adjustments to revenues will be required in subsequent periods based on the actual amounts reported by licensees. Upon adoption of the new guidance, licenses to use portions of our intellectual property portfolio will be considered one performance obligation, and license fees will be recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee, which is similar to the recognition of license revenues under the current guidance. We have historically accounted for customer incentive arrangements in our licensing and semiconductor businesses, including volume-related and other pricing rebates or cost reimbursements for marketing and other activities involving certain of our products and technologies, in part based on the maximum potential liability. Under the new guidance, we will estimate the amount of all customer incentives. We do not otherwise expect the adoption of the new guidance to have a material impact on our businesses.

[0001728949-18-000095:notes:211]
Financial Assets: In January 2016, the FASB issued new guidance on classifying and measuring financial instruments, which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk be recognized separately in other comprehensive income. Additionally, it changes the disclosure requirements for financial instruments. For equity investments that do not have readily determinable fair values, we expect to use the measurement alternative, which is defined as cost, less impairments, adjusted by observable price changes in orderly transactions for identical or similar investments. We anticipate the adoption of the new guidance will increase the volatility of our investment and other income, net due to recording the changes in fair value of equity investments through earnings. We will adopt the new guidance in the first quarter of fiscal 2019 using the modified retrospective transition method for equity investments that have readily determinable fair values, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption, and the prospective transition method for equity investments that do not have readily determinable fair values. Upon adoption, the unrealized gains on our marketable securities of $63 million at September 30, 2018 will be recognized as an adjustment to opening retained earnings.

[0001728949-18-000095:notes:212]
In June 2016, the FASB issued new guidance that changes the accounting for recognizing impairments of financial assets. Under the new guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The new guidance also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The new guidance will be effective for us starting in the first quarter of fiscal 2021 and generally requires the modified retrospective transition method, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. Early adoption is permitted starting in the first quarter of fiscal 2020. We are in the process of determining the effects the adoption will have on our consolidated financial statements and whether to adopt the new guidance early.

[0001728949-18-000095:notes:213]
Leases: In February 2016, the FASB issued new guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease guidance. The new guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. We will adopt the new guidance in the first quarter of fiscal 2020 and expect to use the modified retrospective approach and to elect certain practical expedients, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption. We are in the process of determining the effects the adoption will have on our consolidated financial statements.

[0001728949-18-000095:notes:214]
Hedge Instruments: In August 2017, the FASB issued new guidance that expands and refines hedge accounting for both financial and non-financial risks, aligns the recognition and presentation of the effects of hedging instruments and hedged items in the financial statements, and includes targeted improvements related to the assessment of hedge effectiveness. The new guidance also modifies disclosure requirements for hedging activities. We will adopt the new guidance as of the beginning of the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings, which is expected to be negligible. We do not expect the effects of the adoption to have a material impact on our consolidated financial statements.

[0001728949-18-000095:notes:215]
Other: In August 2016, the FASB issued new guidance related to the classification of certain cash receipts and cash payments on the statement of cash flows. We will adopt the new guidance in the first quarter of fiscal 2019 using the retrospective transition method for each period presented and do not expect the effects of the adoption to have a material impact on our consolidated statements of cash flows.

[0001728949-18-000095:notes:216]
In October 2016, the FASB issued new guidance that changes the accounting for income tax effects of intra-entity transfers of assets other than inventory. Under the new guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. We will adopt the new guidance in the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption. We estimate the increase to the opening retained earnings to be approximately $2.5 billion, primarily as the result of establishing a deferred tax asset on the basis difference of certain intellectual property distributed from one of our foreign subsidiaries to a subsidiary in the United States in fiscal 2018 (Note 3).

[0001728949-18-000095:notes:217]
In November 2016, the FASB issued new guidance related to the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. We will adopt the new guidance in the first quarter of fiscal 2019 using the retrospective transition method for each period presented, which will result in certain amounts in fiscal 2017 and 2018 to be adjusted to conform to the new guidance upon adoption in the first quarter of fiscal 2019. During fiscal 2017 and 2018, we had restricted cash and cash equivalents related to funds deposited as collateral for outstanding letters of credit in connection with the NXP Purchase Agreement (Note 9). Restricted cash and cash equivalents related to the outstanding letters of credit totaled $700 million at the end of each of the first, second and third quarters of fiscal 2017 and $2.0 billion at the end of each of the fourth quarter of fiscal 2017 and the first, second and third quarters of fiscal 2018. There was no restricted cash at the end of the fourth quarter of fiscal 2018. Additionally, at the end of the third quarter of fiscal 2018, we had restricted cash and cash equivalents of $2.8 billion related to irrevocably deposited cash to redeem notes in July 2018. Otherwise, we do not expect the effects of the retrospective adoption to have a material impact on our consolidated statements of cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-18-000095:notes:218]
Note 1. Significant Accounting Policies

[0001728949-18-000095:notes:219]
We develop, design, manufacture, have manufactured on our behalf and market digital communications products, which principally consist of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices, wireless networks, devices used in the Internet of Things (IoT), broadband gateway equipment, consumer electronic devices and automotive telematics and infotainment systems. We also grant licenses to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products and receive ongoing royalties based on sales by licensees of wireless products incorporating our patented technologies and may also receive fixed license fees (payable in one or more installments).

[0001728949-18-000095:notes:220]
Financial Statement Preparation. The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in our consolidated financial statements and the accompanying notes. Examples of our significant accounting estimates that may involve a higher degree of judgment and complexity than others include: the determination of other-than-temporary impairments of other investments; the valuation of inventories; the valuation and assessment of the recoverability of goodwill and other indefinite-lived and long-lived assets; the recognition, measurement and disclosure of loss contingencies related to legal and regulatory proceedings; and the calculation of tax liabilities, including the recognition and measurement of uncertain tax positions. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

[0001728949-18-000095:notes:221]
Fiscal Year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. The fiscal year ended September 30, 2018, included 53 weeks. The fiscal years ended September 24, 2017 and September 25, 2016 included 52 weeks.

[0001728949-18-000095:notes:222]
Marketable Securities. Marketable securities include available-for-sale securities and certain time deposits for which classification is determined at the time of purchase and reevaluated at each balance sheet date. We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value. The net unrealized gains or losses on available-for-sale securities are recorded as a component of accumulated other comprehensive income, net of income taxes. The realized gains and losses on marketable securities are determined using the specific identification method.

[0001728949-18-000095:notes:223]
At each balance sheet date, we assess available-for-sale securities in an unrealized loss position to determine whether the unrealized loss is other than temporary. We consider factors including: the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; how long the market value of the security has been less than its cost basis; the security’s relative performance versus its peers, sector or asset class; expected market volatility; the market and economy in general; analyst recommendations and price targets; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.

[0001728949-18-000095:notes:224]
If a debt security’s market value is below amortized cost and we either intend to sell the security or it is more likely than not that we will be required to sell the security before its anticipated recovery, we record an other-than-temporary impairment charge to investment and other income, net for the entire amount of the impairment. For the remaining debt securities, if an other-than-temporary impairment exists, we separate the other-than-temporary impairment into the portion of the loss related to credit factors, or the credit loss portion, which is recorded as a charge to investment and other income, net, and the portion of the loss that is not related to credit factors, or the noncredit loss portion, which is recorded as a component of other accumulated comprehensive income, net of income taxes.

[0001728949-18-000095:notes:225]
For equity securities, we consider the loss relative to the expected volatility and the likelihood of recovery over a reasonable period of time. If events and circumstances indicate that a decline in the value of an equity security has occurred and is other than temporary, we record a charge to investment and other income, net for the difference between fair value and cost at the balance sheet date. Additionally, if we either have the intent to sell the equity security or do not have both the intent and the ability to hold the equity security until its anticipated recovery, we record a charge to investment and other income, net for the difference between fair value and cost at the balance sheet date.

[0001728949-18-000095:notes:226]
Equity and Cost Method Investments. We generally account for non-marketable equity investments either under the equity or the cost method. Equity investments for which we have significant influence, but not control over the investee and are not the primary beneficiary of the investee’s activities are accounted for under the equity method. Other non-marketable equity investments are accounted for under the cost method. Our share of gains and losses in equity method investments are recorded in investment and other income, net. We monitor non-marketable equity investments for events or circumstances that could indicate the investments are impaired, such as a deterioration in the investee’s financial condition and business forecasts and lower valuations in recently completed or proposed financings, and record a charge to investment and other income, net for the difference between the estimated fair value and the carrying value.

[0001728949-18-000095:notes:227]
Transactions with equity method investees are considered related party transactions. Revenues from certain licensing and services contracts were $100 million with one of our equity method investees in fiscal 2018, and $165 million and $196 million with two of our equity method investees in fiscal 2017 and 2016, respectively. We eliminate unrealized profit or loss related to such transactions in relation to our ownership interest in the investee, which is recorded as a component of equity in net losses in investees in investment and other income, net. No accounts receivable were due from these equity method investees at September 30, 2018. Aggregate accounts receivable from these equity method investees were $29 million at September 24, 2017.

[0001728949-18-000095:notes:228]
Gross Notional Amounts: The gross notional amounts of our interest rate and foreign currency derivatives by instrument type were as follows (in millions):

[0001728949-18-000095:notes:229]
|  | September 30, 2018 |  | September 24, 2017 |
| Forwards | $ | 682 |  |  | $ | 163 |  |
| Options | 1,375 |  |  | 2,333 |  |
| Swaps | 1,750 |  |  | 3,000 |  |
|  | $ | 3,807 |  |  | $ | 5,496 |  |

[0001728949-18-000095:notes:230]
The gross notional amounts by currency were as follows (in millions):

[0001728949-18-000095:notes:231]
|  | September 30, 2018 |  | September 24, 2017 |
| Chinese renminbi | $ | 650 |  |  | $ | 1,460 |  |
| Euro | 938 |  |  | 146 |  |
| Indian rupee | 336 |  |  | 772 |  |
| Japanese yen | 17 |  |  | 68 |  |
| Korean won | — |  |  | 50 |  |
| United States dollar | 1,866 |  |  | 3,000 |  |
|  | $ | 3,807 |  |  | $ | 5,496 |  |

[0001728949-18-000095:notes:232]
Allowances for Doubtful Accounts. We maintain allowances for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. We consider the following factors when determining if collection of required payments is reasonably assured: customer credit-worthiness; past transaction history with the customer; current economic industry and/or geographic trends; changes in customer payment terms; and bank credit-worthiness for letters of credit. If we have no previous experience with the customer, we may request financial information, including financial statements or other documents, to determine that the customer has the means of making payment. We may also obtain reports from various credit organizations to determine that the customer has a history of paying its creditors. If these factors do not indicate collection is reasonably assured, revenue is deferred as a reduction to accounts receivable until collection becomes reasonably assured, which is generally upon receipt of cash. If the financial condition of our customers was to deteriorate, adversely affecting their ability to make payments, additional allowances would be required.

[0001728949-18-000095:notes:233]
Property, Plant and Equipment. Property, plant and equipment are recorded at cost and depreciated or amortized using the straight-line method over their estimated useful lives. Upon the retirement or disposition of property, plant and equipment, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded, when appropriate. Buildings on owned land are depreciated over 30 years, and building improvements are depreciated over their useful lives ranging from 7 to 15 years. Leasehold improvements are amortized over the shorter of their estimated useful lives, not to exceed 15 years, or the remaining term of the related lease. Other property, plant and equipment have useful lives ranging from 2 to 25 years. Leased property meeting certain capital lease criteria is capitalized, and the net present value of the related lease payments is recorded as a liability. Amortization of assets under capital leases is recorded using the straight-line method over the shorter of the estimated useful lives or the lease terms. Maintenance, repairs and minor renewals or betterments are charged to expense as incurred.

[0001728949-18-000095:notes:234]
Revenue Recognition. We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property and also generate revenues through sales of products that connect medical devices and by performing software hosting, software development and other services. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of our deliverables and obligations. Unearned revenues consist primarily of license fees for intellectual property with continuing performance obligations.

[0001728949-18-000095:notes:235]
Revenues from sales of our products are recognized at the time of shipment, or when title and risk of loss pass to the customer and all other criteria for revenue recognition are met, if later. Revenues from providing services are recognized when earned. Revenues from providing services were less than 10% of total revenues for all periods presented.

[0001728949-18-000095:notes:236]
We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. License fees are recognized over the estimated period of benefit of the license to the licensee, typically 5 to 15 years. Royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops, which in general, effectively provide for a maximum royalty amount per device. We earn royalties on such licensed products sold worldwide by our licensees at the time that the licensees’ sales occur. Our licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter, which is generally the following quarter. We recognize royalty revenues based on royalties reported by licensees during the quarter and when all other revenue recognition criteria are met.

[0001728949-18-000095:notes:237]
We record reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates as well as cost reimbursements for marketing and other activities involving certain of our products and technologies. The charges for such arrangements are recorded as a reduction to accounts receivable or as other current liabilities based on whether we have the contractual right of offset. We recognize the liability based on the estimated amount of the incentive, or if not reasonably estimated, the maximum potential liability, at the later of the date at which we record the related revenues or the date at which we offer the incentive or, if payment is contingent, when the contingency is resolved. We reverse accruals for unclaimed incentive amounts to revenues when the unclaimed amounts are no longer subject to payment.

[0001728949-18-000095:notes:238]
Shipping and Handling Costs. Costs incurred for shipping and handling are included in cost of revenues. Amounts billed to a customer for shipping and handling are reported as revenues.

[0001728949-18-000095:notes:239]
Share-Based Compensation. Share-based compensation expense for equity-classified awards, principally related to restricted stock units (RSUs), is measured at the grant date, or at the acquisition date for awards assumed in business combinations, based on the estimated fair value of the award and is recognized over the employee’s requisite service period. Share-based compensation expense is adjusted to exclude amounts related to share-based awards that are expected to be forfeited.

[0001728949-18-000095:notes:240]
The fair values of RSUs are estimated based on the fair market values of the underlying stock on the dates of grant or dates the RSUs are assumed. If RSUs do not have the right to participate in dividends, the fair values are discounted by the dividend yield. The weighted-average estimated fair values of employee RSUs that contain only service requirements to vest granted during fiscal 2018, 2017 and 2016 were $62.61, $66.54 and $53.56 per share, respectively. Upon vesting, we issue new shares of common stock. For the majority of RSUs, shares are issued on the vesting dates net of the amount of shares needed to satisfy statutory tax withholding requirements to be paid by us on behalf of the employees. As a result, the actual number of shares issued will be fewer than the number of RSUs outstanding. The annual pre-vest forfeiture rate for RSUs was estimated to be approximately 6%, 5% and 4% in fiscal 2018, 2017 and 2016, respectively.

[0001728949-18-000095:notes:241]
Total share-based compensation expense, related to all of our share-based awards, was comprised as follows (in millions):

[0001728949-18-000095:notes:242]
|  | 2018 |  | 2017 |  | 2016 |
| Cost of revenues | $ | 38 |  |  | $ | 38 |  |  | $ | 40 |  |
| Research and development | 594 |  |  | 588 |  |  | 614 |  |
| Selling, general and administrative | 251 |  |  | 288 |  |  | 289 |  |
| Share-based compensation expense before income taxes | 883 |  |  | 914 |  |  | 943 |  |
| Related income tax benefit | (140 | ) |  | (161 | ) |  | (190 | ) |
|  | $ | 743 |  |  | $ | 753 |  |  | $ | 753 |  |

[0001728949-18-000095:notes:243]
Legal and Regulatory Proceedings. We are currently involved in certain legal and regulatory proceedings. Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Investigations by antitrust and trade regulation agencies are not conducted in a consistent manner across jurisdictions. Further, each country and agency has different sets of laws, rules and regulations, both substantive and procedural, as well as different legal principles, theories and potential remedies, and some agencies may seek to use the investigation to advance domestic policy goals. Depending on the jurisdiction, these investigations can involve non-transparent procedures under which we may not receive access to evidence relied upon by the enforcement agency or that may be exculpatory and may not be informed of the specific legal theories or evidence considered or relied upon by the agency. Unlike in civil litigation in the United States, in foreign proceedings, we may not be entitled to discovery or depositions, allowed to cross-examine witnesses or confront our accusers. As a result, we may not be aware of, and may not be entitled to know, all allegations against us, or the information or documents provided to, or discovered or prepared by, the agency. Accordingly, we may have little or no idea what an agency’s intent is with respect to liability, penalties or the timing of a decision. In many cases the agencies are given significant discretion, and any available precedent may have limited, if any, predictive value in their jurisdictions, much less in other jurisdictions. Accordingly, we cannot predict the outcome of these matters.

[0001728949-18-000095:notes:244]
If there is at least a reasonable possibility that a material loss may have been incurred associated with pending legal and regulatory proceedings, we disclose such fact, and if reasonably estimable, we provide an estimate of the possible loss or range of possible loss. We record our best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, we record the minimum estimated liability. As additional information becomes available, we assess the potential liability related to pending legal and regulatory proceedings and revise our estimates and update our disclosures accordingly. Our legal costs associated with defending ourself are recorded to expense as incurred.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001728949-18-000095:notes:245]
Summarized Quarterly Data (Unaudited)

[0001728949-18-000095:notes:246]
The following financial information reflects all normal recurring adjustments that are, in the opinion of management, necessary for a fair statement of the results of the interim periods.

[0001728949-18-000095:notes:247]
The table below presents quarterly data for fiscal 2018 and 2017 (in millions, except per share data):

[0001728949-18-000095:notes:248]
|  | 1st Quarter |  | 2nd Quarter |  | 3rd Quarter |  | 4th Quarter |
| 2018 (1) |  |  |  |  |  |  |  |
| Revenues | $ | 6,068 |  |  | $ | 5,261 |  |  | $ | 5,599 |  |  | $ | 5,803 |  |
| Operating income (loss) (2) | 29 |  |  | 441 |  |  | 925 |  |  | (654 | ) |
| Net (loss) income (2) | (5,953 | ) |  | 363 |  |  | 1,219 |  |  | (493 | ) |
| Basic (loss) earnings per share (3): | $ | (4.03 | ) |  | $ | 0.25 |  |  | $ | 0.82 |  |  | $ | (0.35 | ) |
| Diluted (loss) earnings per share (3): | (4.03 | ) |  | 0.24 |  |  | 0.82 |  |  | (0.35 | ) |
| 2017 (1) |  |  |  |  |  |  |  |
| Revenues | $ | 5,999 |  |  | $ | 5,016 |  |  | $ | 5,371 |  |  | $ | 5,905 |  |
| Operating income | 778 |  |  | 729 |  |  | 773 |  |  | 333 |  |
| Net income | 681 |  |  | 749 |  |  | 865 |  |  | 168 |  |
| Net income attributable to Qualcomm | 682 |  |  | 749 |  |  | 866 |  |  | 168 |  |
| Basic earnings per share attributable to Qualcomm (3): | $ | 0.46 |  |  | $ | 0.51 |  |  | $ | 0.59 |  |  | $ | 0.11 |  |
| Diluted earnings per share attributable to Qualcomm (3): | 0.46 |  |  | 0.50 |  |  | 0.58 |  |  | 0.11 |  |

[0001728949-18-000095:notes:249]
| (1) | Amounts, other than per share amounts, are rounded to millions each quarter. Therefore, the sum of the quarterly amounts may not equal the annual amounts reported. |

[0001728949-18-000095:notes:250]
| (2) | Operating loss and net loss in the fourth quarter of fiscal 2018 were negatively impacted by a $2.0 billion charge related to the NXP termination fee. Net loss in the first quarter of fiscal 2018 was negatively impacted by a $5.9 billion provisional charge to income tax expense due to the effects of the Tax Legislation. Additionally, operating income and net loss in the first quarter of fiscal 2018 were negatively impacted by a $1.2 billion charge related to the EC fine. |

[0001728949-18-000095:notes:251]
| (3) | (Loss) earnings per share and earnings per share attributable to Qualcomm are computed independently for each quarter and the full year based upon respective average shares outstanding. Therefore, the sum of the quarterly (loss) earnings per share amounts may not equal the annual amounts reported. |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001728949-18-000095:notes:252]
Unallocated acquisition-related expenses were comprised as follows (in millions):

[0001728949-18-000095:notes:253]
|  | 2018 |  | 2017 |  | 2016 |
| Cost of revenues | $ | 449 |  |  | $ | 437 |  |  | $ | 434 |  |
| Research and development expenses | 6 |  |  | 20 |  |  | 10 |  |
| Selling, general and administrative expenses | 327 |  |  | 272 |  |  | 99 |  |

[0001728949-18-000095:notes:254]
Reconciling items for revenues and EBT in a previous table were as follows (in millions):

[0001728949-18-000095:notes:255]
|  | 2018 |  | 2017 |  | 2016 |
| Revenues |  |  |  |  |  |
| Nonreportable segments | $ | 287 |  |  | $ | 311 |  |  | $ | 438 |  |
| Reduction to revenues related to BlackBerry arbitration decision | — |  |  | (962 | ) |  | — |  |
| Other unallocated reductions to revenues | (100 | ) |  | (95 | ) |  | — |  |
| Intersegment eliminations | — |  |  | — |  |  | (4 | ) |
|  | $ | 187 |  |  | $ | (746 | ) |  | $ | 434 |  |
| EBT |  |  |  |  |  |
| Reduction to revenues related to BlackBerry arbitration decision | $ | — |  |  | $ | (962 | ) |  | $ | — |  |
| Other unallocated reductions to revenues | (100 | ) |  | (95 | ) |  | — |  |
| Unallocated cost of revenues | (486 | ) |  | (517 | ) |  | (495 | ) |
| Unallocated research and development expenses | (1,154 | ) |  | (1,056 | ) |  | (799 | ) |
| Unallocated selling, general and administrative expenses | (576 | ) |  | (647 | ) |  | (478 | ) |
| Unallocated other expenses (Note 2) | (3,135 | ) |  | (1,742 | ) |  | (154 | ) |
| Unallocated interest expense | (761 | ) |  | (488 | ) |  | (292 | ) |
| Unallocated investment and other income, net | 566 |  |  | 913 |  |  | 667 |  |
| Nonreportable segments | (356 | ) |  | (373 | ) |  | (342 | ) |
|  | $ | (6,002 | ) |  | $ | (4,967 | ) |  | $ | (1,893 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001728949-18-000095:notes:256]
Restructuring Plans

[0001728949-18-000095:notes:257]
Cost Plan. In the second quarter of fiscal 2018, we announced a Cost Plan designed to align our cost structure to our long-term margin targets. As part of this plan, we have initiated a series of targeted actions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. We expect these cost reductions to be fully captured in fiscal 2019.

[0001728949-18-000095:notes:258]
During fiscal 2018, we recorded restructuring and restructuring-related charges of $629 million in other expenses and charges of $58 million in investment and other income, net (Note 2), which consisted of restructuring charges of $353 million, primarily related to severance costs, and restructuring-related charges of $334 million, primarily related to asset impairment charges (and which was net of a $41 million gain resulting from fair value adjustments of certain contingent consideration related to a business combination). In connection with this plan, we expect to incur additional restructuring and restructuring-related charges of up to $100 million, which primarily consist of severance and consulting costs, and the vast majority of which are expected to be settled in cash.

[0001728949-18-000095:notes:259]
The restructuring accrual, a portion of which was included in payroll and other benefits related liabilities with the remainder included in other current liabilities, is expected to be substantially paid within the next 12 months. Changes in the restructuring accrual for fiscal 2018 were as follows (in millions):

[0001728949-18-000095:notes:260]
|  | Severance Costs |  | OtherCosts |  | Total |
| Beginning balance of restructuring accrual | $ | — |  |  | $ | — |  |  | $ | — |  |
| Costs | 317 |  |  | 43 |  |  | 360 |  |
| Cash payments | (251 | ) |  | (19 | ) |  | (270 | ) |
| Adjustments | (5 | ) |  | (2 | ) |  | (7 | ) |
| Ending balance of restructuring accrual | $ | 61 |  |  | $ | 22 |  |  | $ | 83 |  |

[0001728949-18-000095:notes:261]
Strategic Realignment Plan. In the fourth quarter of fiscal 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we worked to create sustainable long-term value for stockholders. As part of this, among other actions, we implemented a cost reduction plan, which included a series of targeted reductions across our businesses, particularly in QCT, and a reduction to our annual share-based compensation grants. Restructuring activities were initiated in the fourth quarter of fiscal 2015, and the cost reduction initiatives were achieved by the end of fiscal 2016 and other activities under the plan were completed by the end of fiscal 2017. During fiscal 2017 and 2016, we recorded restructuring and restructuring-related charges of $37 million and $202 million (which was partially offset by a $48 million gain on the sale of our business that provided augmented reality applications), respectively.


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001728949-18-000095:notes:262]
Revenues by country were as follows (in millions):

[0001728949-18-000095:notes:263]
|  | 2018 |  | 2017 |  | 2016 |
| China (including Hong Kong) | $ | 15,149 |  |  | $ | 14,579 |  |  | $ | 13,503 |  |
| South Korea | 3,175 |  |  | 3,538 |  |  | 3,918 |  |
| United States | 603 |  |  | 513 |  |  | 386 |  |
| Other foreign | 3,805 |  |  | 3,661 |  |  | 5,747 |  |
|  | $ | 22,732 |  |  | $ | 22,291 |  |  | $ | 23,554 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001728949-18-000095:notes:264]
The table below presents revenues, EBT and total assets for reportable segments (in millions):

[0001728949-18-000095:notes:265]
|  | 2018 |  | 2017 |  | 2016 |
| Revenues |  |  |  |  |  |
| QCT | $ | 17,282 |  |  | $ | 16,479 |  |  | $ | 15,409 |  |
| QTL | 5,163 |  |  | 6,445 |  |  | 7,664 |  |
| QSI | 100 |  |  | 113 |  |  | 47 |  |
| Reconciling items | 187 |  |  | (746 | ) |  | 434 |  |
| Total | $ | 22,732 |  |  | $ | 22,291 |  |  | $ | 23,554 |  |
| EBT |  |  |  |  |  |
| QCT | $ | 2,966 |  |  | $ | 2,747 |  |  | $ | 1,812 |  |
| QTL | 3,525 |  |  | 5,175 |  |  | 6,528 |  |
| QSI | 24 |  |  | 65 |  |  | 386 |  |
| Reconciling items | (6,002 | ) |  | (4,967 | ) |  | (1,893 | ) |
| Total | $ | 513 |  |  | $ | 3,020 |  |  | $ | 6,833 |  |
| Assets |  |  |  |  |  |
| QCT | $ | 3,041 |  |  | $ | 3,830 |  |  | $ | 2,995 |  |
| QTL | 1,472 |  |  | 1,735 |  |  | 644 |  |
| QSI | 1,279 |  |  | 1,037 |  |  | 910 |  |
| Reconciling items | 26,894 |  |  | 58,884 |  |  | 47,810 |  |
| Total | $ | 32,686 |  |  | $ | 65,486 |  |  | $ | 52,359 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-18-000095:notes:266]
Segment Information

[0001728949-18-000095:notes:267]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices, wireless networks, devices used in the Internet of Things (IoT), broadband gateway equipment, consumer electronic devices and automotive telematics and infotainment systems. QTL grants licenses to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an equity method investee. We also have nonreportable segments, including our cyber security solutions (formerly Qualcomm Government Technologies or QGOV), mobile health, small cells and other wireless technology and service initiatives.

[0001728949-18-000095:notes:268]
We evaluate the performance of our segments based on earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense; certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages. Additionally, starting with acquisitions in the second quarter of fiscal 2017, unallocated charges include recognition of the depreciation related to the step-up of property, plant and equipment to fair value. Such charges related to acquisitions that were completed prior to the second quarter of fiscal 2017 continue to be allocated to the respective segment, and such amounts are not material.

[0001728949-18-000095:notes:269]
In fiscal 2018, all of the costs ($474 million) related to pre-commercial research and development of 5G (fifth generation) technologies were included in unallocated corporate research and development expenses, whereas similar costs related to the research and development of other technologies, including 3G (third generation) and 4G (fourth generation) technologies, were recorded in the QCT and QTL segments. Beginning in the first quarter of fiscal 2019, all research and development costs associated with 5G technologies will be included in QCT and QTL segment results. Additionally, beginning in the first quarter of fiscal 2019, certain research and development costs associated with early research and development that have historically been included in our QCT segment will be allocated to our QTL segment. The net effect of these changes is expected to negatively impact QTL’s EBT in fiscal 2019 by approximately $500 million and to not have a significant impact on QCT EBT in fiscal 2019.

[0001728949-18-000095:notes:270]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets include certain non-marketable equity instruments and other investments and a receivable from the sale of wireless spectrum in fiscal 2016 (Note 2). QSI assets at September 30, 2018, September 24, 2017 and September 25, 2016 included $283 million, $254 million and $162 million, respectively, related to investments in equity method investees. The decrease in fiscal 2018 QCT segment assets resulted from a decrease in accounts receivable related to the timing of integrated circuit shipments and to a decrease in inventory due to a reduction in the overall quantity of units on hand. The decrease in fiscal 2018 QTL segment assets was due to a decrease in accounts receivable resulting from the collection of receivables from certain licensees. The increase in fiscal 2017 QCT segment assets resulted primarily from our RF360 Holdings joint venture in the second quarter of fiscal 2017 (Note 9). The increase in fiscal 2017 QTL segment assets was due to an increase in accounts receivable. Total segment assets differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable securities, property, plant and equipment, deferred tax assets, intangible assets and assets of nonreportable segments. The net book values of long-lived tangible assets located outside of the United States were $1.4 billion at September 30, 2018 and September 24, 2017, and $404 million at September 25, 2016. The increase in fiscal 2017 was primarily from our RF360 Holdings joint venture, which has substantially all of its operations outside the United States. The net book values of long-lived tangible assets located in the United States were $1.6 billion, $1.8 billion and $1.9 billion at September 30, 2018, September 24, 2017 and September 25, 2016, respectively.

[0001728949-18-000095:notes:271]
We report revenues from external customers by country based on the location to which our products or services are delivered, which for QCT is generally the country in which our customers manufacture their products, and for licensing revenues, the invoiced addresses of our licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues could include revenues related to shipments of integrated circuits for a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States. Revenues by country were as follows (in millions):

[0001728949-18-000095:notes:272]
Other unallocated revenues in fiscal 2018 and 2017 were comprised of reductions to licensing revenues related to the portions of business arrangements that resolved legal disputes and were not allocated to a reportable segment in our management reports because they were not considered in evaluating segment results. In May 2017, in connection with the arbitration decision, we entered into a Joint Stipulation Regarding Final Award Agreement with BlackBerry Limited (BlackBerry) agreeing that we would pay BlackBerry $940 million to cover the award amount, pre-judgment interest and attorneys’ fees. This amount, which was paid in the third quarter of fiscal 2017, also reflected $22 million that was owed to us by BlackBerry, which was recorded as revenues in the QTL segment. The remaining amount was recorded as an adjustment to revenues related to the arbitration decision and was not allocated to QTL. Unallocated other expenses in fiscal 2018 were comprised of charges related to the termination of our purchase agreement to acquire NXP (Note 9), the EC fine (Note 7), and our Cost Plan (Note 10), partially offset by a benefit related to the settlement of the TFTC investigation (Note 7). Unallocated other expenses in fiscal 2017 were comprised of charges related to the fines imposed by the KFTC and the TFTC, which was settled in fiscal 2018 (Note 7), as well as restructuring and restructuring-related charges related to our Strategic Realignment Plan, which was substantially implemented in fiscal 2016 (Note 10). Unallocated other expenses for fiscal 2016 were comprised of net restructuring and restructuring-related charges related to our Strategic Realignment Plan.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001728949-18-000095:notes:273]
In fiscal 2018, all of the costs ($474 million) related to pre-commercial research and development of 5G (fifth generation) technologies were included in unallocated corporate research and development expenses, whereas similar costs related to the research and development of other technologies, including 3G (third generation) and 4G (fourth generation) technologies, were recorded in the QCT and QTL segments. Beginning in the first quarter of fiscal 2019, all research and development costs associated with 5G technologies will be included in QCT and QTL segment results.

[0001728949-18-000095:notes:274]
We report revenues from external customers by country based on the location to which our products or services are delivered, which for QCT is generally the country in which our customers manufacture their products, and for licensing revenues, the invoiced addresses of our licensees.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-18-000095:notes:275]
Capital Stock

[0001728949-18-000095:notes:276]
Stock Repurchase Program. On July 26, 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. The stock repurchase program has no expiration date. The $30 billion stock repurchase program replaced a $10 billion stock repurchase program announced on May 9, 2018, of which $9.0 billion remained authorized for repurchase. In August 2018, we completed a “modified Dutch auction” tender offer and paid an aggregate of $5.1 billion, excluding fees and related expenses, to repurchase 76.2 million shares of our common stock, which were retired, at a price of $67.50 per share.

[0001728949-18-000095:notes:277]
In September 2018, we entered into three accelerated share repurchase agreements (ASR Agreements) with three financial institutions under which we paid an aggregate of $16.0 billion upfront to the financial institutions and received from them an initial delivery of 178.4 million shares of our common stock, which were retired, and recorded as a $12.8 billion reduction to stockholders’ equity. The final number of shares to be repurchased will be based on the volume-weighted average stock price of our common stock during the terms of the transactions, less a discount and subject to adjustments pursuant to the terms and conditions of the ASR Agreements, and will also be retired upon delivery to us and recorded as a reduction to stockholders’ equity. This is evaluated as an unsettled forward contract indexed to our own stock, with $3.2 billion classified within stockholders’ equity. The transactions are scheduled to terminate in August 2019 but may terminate earlier in certain circumstances. At settlement, under certain circumstances, one or more of the financial institutions may be required to deliver additional shares of common stock to us, or under certain circumstances, we may be required to deliver shares of common stock or to make a cash payment to one or more of the financial institutions, with the method of settlement at our election.

[0001728949-18-000095:notes:278]
During fiscal 2018, 2017 and 2016, we repurchased and retired an additional 24.2 million, 22.8 million and 73.8 million shares of common stock, respectively, for $1.4 billion, $1.3 billion and $3.9 billion, respectively, before commissions. To reflect share repurchases in the consolidated balance sheet, we (i) reduce common stock for the par value of the shares, (ii) reduce paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) record the residual amount to retained earnings. At September 30, 2018, $8.9 billion remained authorized for repurchase under our stock repurchase program. Since September 30, 2018, we repurchased and retired 8.5 million shares of common stock for $542 million.

[0001728949-18-000095:notes:279]
Dividends. On October 23, 2018, we announced a cash dividend of $0.62 per share on our common stock, payable on December 20, 2018 to stockholders of record as of the close of business on December 6, 2018. Dividends charged to retained earnings in fiscal 2018, 2017 and 2016 were as follows (in millions, except per share data):
