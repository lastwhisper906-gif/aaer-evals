# QCOM 8-K — 0001728949-18-000093 filed 2018-11-07

## item codes, every 8-K on or before 2018-11-07

- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2018-11-07

- none on or before 2018-11-07

## item 2.02 — earnings release, exhibit 99.1

[0001728949-18-000093:8k_2_02:1]
EX-99.1
2
qcom093018erex991.htm
EXHIBIT 99.1

[0001728949-18-000093:8k_2_02:2]
Exhibit

[0001728949-18-000093:8k_2_02:3]
Exhibit 99.1

[0001728949-18-000093:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001728949-18-000093:8k_2_02:5]
Qualcomm Contact:

[0001728949-18-000093:8k_2_02:6]
John Sinnott

[0001728949-18-000093:8k_2_02:7]
Vice President, Investor Relations

[0001728949-18-000093:8k_2_02:8]
Phone: 1-858-658-4813

[0001728949-18-000093:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001728949-18-000093:8k_2_02:10]
Qualcomm Announces Fourth Quarter and Fiscal 2018 Results

[0001728949-18-000093:8k_2_02:11]
Fiscal 2018 Revenues $22.7 billion

[0001728949-18-000093:8k_2_02:12]
GAAP Loss per Share $3.32

[0001728949-18-000093:8k_2_02:13]
Non-GAAP Earnings per Share $3.69

[0001728949-18-000093:8k_2_02:14]
SAN DIEGO - November 7, 2018 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal fourth quarter and year ended September 30, 2018.

[0001728949-18-000093:8k_2_02:15]
“We delivered a strong quarter, with Non-GAAP earnings per share above the high end of our prior expectations, on greater than expected chipset demand in QCT and lower operating expenses,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “We are executing well on our strategic objectives, including driving the commercialization of 5G globally in 2019 and returning significant capital to our stockholders.”

[0001728949-18-000093:8k_2_02:16]
GAAP Results*

[0001728949-18-000093:8k_2_02:17]
Fourth Quarter Fiscal 2018

[0001728949-18-000093:8k_2_02:18]
|  | Q4 Fiscal 2018 |  | Q4 Fiscal 2017 |  | Year-Over-Year Change |  | Q3 Fiscal 2018 |  | Sequential Change |
| Revenues | $5.8B |  | $5.9B |  | (2%) |  | $5.6B |  | +4% |
| Operating (loss) income | ($0.7B) |  | $0.3B |  | N/M |  | $0.9B |  | N/M |
| Net (loss) income 1 | ($0.5B) |  | $0.2B |  | N/M |  | $1.2B |  | N/M |
| Diluted (loss) earnings per share 1 | ($0.35) |  | $0.11 |  | N/M |  | $0.82 |  | N/M |
| Operating cash flow 2 | ($0.4B) |  | $2.4B |  | N/M |  | $2.1B |  | N/M |

[0001728949-18-000093:8k_2_02:19]
1 Throughout this news release, net income and diluted (loss) earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests), unless otherwise stated, and percentage changes are calculated based on the dollar amounts as disclosed in millions.

[0001728949-18-000093:8k_2_02:20]
2 In the first quarter of fiscal 2018, we adopted new accounting guidance that changed the presentation of certain cash flows related to share-based awards in the statements of cash flows.  As a result, prior period cash flow amounts presented in this news release have been adjusted to conform to the current year presentation as follows: net cash provided by operating activities for the fiscal fourth quarter and year ended September 24, 2017 increased by $7 million and $308 million, respectively, with corresponding offsets to net cash (used) provided by financing activities.

[0001728949-18-000093:8k_2_02:21]
N/M - Not Meaningful

[0001728949-18-000093:8k_2_02:22]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 2 of 17 |

[0001728949-18-000093:8k_2_02:23]
Fiscal 2018

[0001728949-18-000093:8k_2_02:24]
|  | Fiscal 2018 |  | Fiscal2017 |  | Year-Over-Year Change |
| Revenues | $22.7B |  | $22.3B |  | +2% |
| Operating income | $0.7B |  | $2.6B |  | (72%) |
| Net (loss) income | ($4.9B) |  | $2.5B |  | N/M |
| Diluted (loss) earnings per share | ($3.32) |  | $1.65 |  | N/M |
| Operating cash flow | $3.9B |  | $5.0B |  | (22%) |

[0001728949-18-000093:8k_2_02:25]
Non-GAAP Results*

[0001728949-18-000093:8k_2_02:26]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding the Company’s use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001728949-18-000093:8k_2_02:27]
Fourth Quarter Fiscal 2018

[0001728949-18-000093:8k_2_02:28]
|  | Q4 Fiscal 2018 |  | Q4 Fiscal 2017 |  | Year-Over-Year Change |  | Q3 Fiscal 2018 |  | Sequential Change |
| Revenues | $5.8B |  | $6.0B |  | (2%) |  | $5.6B |  | +4% |
| Operating income | $1.3B |  | $1.6B |  | (19%) |  | $1.4B |  | (10%) |
| Net income | $1.3B |  | $1.4B |  | (7%) |  | $1.5B |  | (15%) |
| Diluted earnings per share | $0.90 |  | $0.92 |  | (2%) |  | $1.01 |  | (11%) |

[0001728949-18-000093:8k_2_02:29]
Fiscal 2018

[0001728949-18-000093:8k_2_02:30]
|  | Fiscal 2018 |  | Fiscal2017 |  | Year-Over-Year Change |
| Revenues | $22.7B |  | $23.2B |  | (2%) |
| Operating income | $5.6B |  | $7.1B |  | (21%) |
| Net income | $5.4B |  | $6.4B |  | (15%) |
| Diluted earnings per share | $3.69 |  | $4.28 |  | (14%) |

[0001728949-18-000093:8k_2_02:31]
* Beginning in the third quarter of fiscal 2017, GAAP and Non-GAAP results have been negatively impacted by our dispute with Apple and its contract manufacturers (who are our licensees).  We did not record any QTL revenues in fiscal 2018 or the third or fourth quarters of fiscal 2017 for royalties due on sales of Apple’s products.  We expect the actions taken by these companies will continue until these disputes are resolved.  QTL revenues in the fourth fiscal quarter and fiscal 2018 included $100 million and

[0001728949-18-000093:8k_2_02:32]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 3 of 17 |

[0001728949-18-000093:8k_2_02:33]
$600 million, respectively, received under an interim agreement with the other licensee in dispute (which dispute was previously disclosed).  This represents a partial payment for royalties due after the second quarter of fiscal 2017 by that other licensee while negotiations continue.  This payment does not reflect the full amount of royalties due under the underlying license agreement.  We did not record any revenues from the third quarter of fiscal 2017 through the second quarter of fiscal 2018 for royalties due on the sales of the other licensee’s products.  If we do not reach a final agreement with the other licensee, it may not make any other payments or may not make full payments under the existing license agreement.  Royalty revenues related to the products of Apple’s contract manufacturers and the other licensee in dispute were approximately $1.7 billion in fiscal 2017.

[0001728949-18-000093:8k_2_02:34]
The following should be considered in regard to the sequential and year-over-year comparisons:

[0001728949-18-000093:8k_2_02:35]
| • | Fiscal 2018 GAAP results included: |

[0001728949-18-000093:8k_2_02:36]
| ◦ | $6.0 billion charge, or ($4.03) per share, related to the enactment of the Tax Cuts and Jobs Act (the Tax Legislation) in the United States in the first quarter of fiscal 2018. |

[0001728949-18-000093:8k_2_02:37]
| ◦ | $2.0 billion charge, or ($1.41) per share, related to a termination fee paid to NXP Semiconductors N.V. (NXP) in the fourth quarter of fiscal 2018 resulting from the termination of the purchase agreement. |

[0001728949-18-000093:8k_2_02:38]
| ◦ | $1.2 billion charge, or ($0.76) per share, for the fine imposed by the European Commission (EC) in the first quarter of fiscal 2018. We provided financial guarantees to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. |

[0001728949-18-000093:8k_2_02:39]
| ◦ | $687 million of restructuring and restructuring-related charges, or ($0.37) per share, related to our Cost Plan that was announced in the second quarter of fiscal 2018. |

[0001728949-18-000093:8k_2_02:40]
| ◦ | $676 million gain, or $0.48 per share, related to the settlement of the Taiwan Fair Trade Commission (TFTC) investigation in the fourth quarter of fiscal 2018. |

[0001728949-18-000093:8k_2_02:41]
| • | Fiscal 2018 GAAP and Non-GAAP results included: |

[0001728949-18-000093:8k_2_02:42]
| ◦ | $600 million of revenues, or $0.31 per share for GAAP and $0.30 per share for Non-GAAP (based on diluted shares of 1,463 million and 1,475 million, respectively), resulting from an interim agreement with the other licensee in dispute for royalties due after the second quarter of fiscal 2017, while negotiations continue. |

[0001728949-18-000093:8k_2_02:43]
| • | Fiscal 2017 GAAP results included: |

[0001728949-18-000093:8k_2_02:44]
| ◦ | $868 million charge, or ($0.49) per share, for the fine imposed by the Korea Fair Trade Commission (KFTC) in the first quarter of fiscal 2017 (additional impact of $59 million of related foreign exchange losses, resulting in a total charge of $927 million in fiscal 2017). |

[0001728949-18-000093:8k_2_02:45]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 4 of 17 |

[0001728949-18-000093:8k_2_02:46]
| ◦ | $974 million reduction to revenues, or ($0.48) per share, related to the BlackBerry arbitration decision in the second quarter of fiscal 2017 (subsequent downward adjustment of $34 million to reflect the final award amount, resulting in a total reduction to revenues of $940 million in fiscal 2017). |

[0001728949-18-000093:8k_2_02:47]
| ◦ | $778 million charge, or ($0.52) per share, for the fine imposed by the TFTC, which was accrued in the fourth quarter of fiscal 2017. |

[0001728949-18-000093:8k_2_02:48]
Segment Results

[0001728949-18-000093:8k_2_02:49]
Fourth Quarter Fiscal 2018

[0001728949-18-000093:8k_2_02:50]
| (in millions, except percentages) | Q4 Fiscal 2018 |  | Q4 Fiscal 2017 |  | Year-Over-Year Change |  | Q3 Fiscal 2018 |  | Sequential Change |
| QCT |  |  |  |  |  |  |  |  |  |
| Revenues | $4,647 |  | $4,650 |  | —% |  | $4,087 |  | +14% |
| EBT 1 | $796 |  | $973 |  | (18%) |  | $607 |  | +31% |
| EBT as % of revenues | 17% |  | 21% |  | (4%) |  | 15% |  | +2% |
| MSMTM chip shipments | 232 |  | 220 |  | +5% |  | 199 |  | +17% |
| QTL |  |  |  |  |  |  |  |  |  |
| Revenues | $1,138 |  | $1,213 |  | (6%) |  | $1,465 |  | (22%) |
| EBT | $739 |  | $829 |  | (11%) |  | $1,049 |  | (30%) |
| EBT as % of revenues | 65% |  | 68% |  | (3%) |  | 72% |  | (7%) |

[0001728949-18-000093:8k_2_02:51]
1 Earnings (loss) before taxes

[0001728949-18-000093:8k_2_02:52]
Fiscal 2018

[0001728949-18-000093:8k_2_02:53]
| (in millions, except percentages) | Fiscal 2018 |  | Fiscal 2017 |  | Year-Over-Year Change |
| QCT |  |  |  |  |  |
| Revenues | $17,282 |  | $16,479 |  | +5% |
| EBT | $2,966 |  | $2,747 |  | +8% |
| EBT as % of revenues | 17% |  | 17% |  | —% |
| MSMTM chip shipments | 855 |  | 804 |  | +6% |
| QTL |  |  |  |  |  |
| Revenues | $5,163 |  | $6,445 |  | (20%) |
| EBT | $3,525 |  | $5,175 |  | (32%) |
| EBT as % of revenues | 68% |  | 80% |  | (12%) |

[0001728949-18-000093:8k_2_02:54]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 5 of 17 |

[0001728949-18-000093:8k_2_02:55]
Return of Capital to Stockholders

[0001728949-18-000093:8k_2_02:56]
In the fourth quarter of fiscal 2018, following the termination of our agreement to acquire NXP, we announced a stock repurchase program authorizing us to repurchase up to $30.0 billion of our common stock, the large majority of which we expect to complete by the end of fiscal 2019.  The following table summarizes stock repurchases, before commissions, and dividends paid during the fourth quarter and fiscal 2018 (in millions, except per-share amounts):

[0001728949-18-000093:8k_2_02:57]
|  | Stock Repurchases |  | Dividends |  | Total |
|  | Shares (1) |  | Amount |  | Per Share |  | Amount |  | Amount |
| Q4 fiscal 2018 | 254.6 |  | $21,144 |  | $0.62 |  | $866 |  | $22,010 |
| Fiscal 2018 | 278.8 |  | $22,569 |  | $2.38 |  | $3,466 |  | $26,035 |

[0001728949-18-000093:8k_2_02:58]
| (1) | The fourth quarter and fiscal 2018 shares repurchased included an initial delivery of 178.4 million shares delivered and retired in September 2018 upon the initiation of three accelerated share repurchase (ASR) agreements and 76.2 million shares repurchased in August 2018 upon the completion of a tender offer. |

[0001728949-18-000093:8k_2_02:59]
At September 30, 2018, $8.9 billion remained authorized for repurchase under our stock repurchase program.  Since September 30, 2018, we repurchased and retired 8.5 million shares of common stock for $542 million.  On October 23, 2018, we announced a cash dividend of $0.62 per share payable on December 20, 2018 to stockholders of record as of the close of business on December 6, 2018.

[0001728949-18-000093:8k_2_02:60]
Cash and Marketable Securities

[0001728949-18-000093:8k_2_02:61]
Our cash, cash equivalents and marketable securities totaled $12.1 billion at the end of the fourth quarter of fiscal 2018, compared to $38.6 billion a year ago and $35.9 billion at the end of the third quarter of fiscal 2018.  Stock repurchases and repayment of long-term debt significantly reduced our cash, cash equivalents and marketable securities balance at the end of the fourth quarter of fiscal 2018.

[0001728949-18-000093:8k_2_02:62]
Effective Income Tax Rates

[0001728949-18-000093:8k_2_02:63]
Our fiscal 2018 annual effective income tax rates were 1,048% provision for GAAP and 1% provision for Non-GAAP.  The fiscal 2018 GAAP effective tax rate included the impact of the Tax Legislation, the EC fine and the TFTC settlement, which are not deductible for tax purposes, and the NXP termination fee, which did not result in a tax benefit after the consideration of realizability of such charge.  The effective income tax rates for the fourth quarter of fiscal 2018 were 36% benefit for GAAP and 1% benefit for Non-GAAP.  Our GAAP effective income tax rate for fourth quarter of fiscal 2018 was different than our prior guidance of 10% benefit as a result of the impact of the NXP termination fee, which was not included in our guidance estimate for the fourth quarter of fiscal 2018.

[0001728949-18-000093:8k_2_02:64]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 6 of 17 |

[0001728949-18-000093:8k_2_02:65]
As a result of the Tax Legislation, we recorded a charge of $5.7 billion to income tax expense in fiscal 2018, primarily comprised of $5.2 billion related to the estimated Toll Charge and $438 million resulting from the remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate.  The cash amount we estimate will be paid for the Toll Charge, net of tax credit carryforwards and tax credits generated through fiscal 2018, is $2.5 billion and is payable in installments over eight years beginning on January 15, 2019.

[0001728949-18-000093:8k_2_02:66]
First Quarter Fiscal 2019

[0001728949-18-000093:8k_2_02:67]
As a result of the Tax Legislation, in fiscal 2019, several of our foreign subsidiaries will make tax elections to be treated as U.S. branches for federal income tax purposes effective beginning in fiscal 2018 and fiscal 2019.  These elections will result in an estimated income tax benefit of $525 million to $575 million, which will be recorded discretely in the first quarter of fiscal 2019.  Our first quarter of fiscal 2019 GAAP and Non-GAAP outlook includes the estimated impact of these elections.

[0001728949-18-000093:8k_2_02:68]
Business Outlook

[0001728949-18-000093:8k_2_02:69]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment, certain derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001728949-18-000093:8k_2_02:70]
We will adopt new revenue recognition guidance in the first quarter of fiscal 2019, which requires us to estimate and recognize QTL royalties in the period in which the associated sales occur, resulting in an acceleration of royalty revenues by one quarter.  As a result of estimation, adjustments will be recorded in subsequent quarters based on the actual amounts of royalties reported by licensees.

[0001728949-18-000093:8k_2_02:71]
Our financial guidance for the first quarter of fiscal 2019 excludes QTL revenues for royalties due on sales of Apple products by Apple’s contract manufacturers as well as sales of products by the other licensee in

[0001728949-18-000093:8k_2_02:72]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 7 of 17 |

[0001728949-18-000093:8k_2_02:73]
dispute, as we expect the actions taken by these companies will continue until the respective disputes are resolved.  Our financial guidance for the first quarter of fiscal 2019 does not include the final $100 million payment received under the interim agreement by the other licensee that was collected in the first quarter of fiscal 2019 since such amount will be recognized as an adjustment to our opening retained earnings balance upon adoption of the new revenue recognition guidance.

[0001728949-18-000093:8k_2_02:74]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 8 of 17 |

[0001728949-18-000093:8k_2_02:75]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001728949-18-000093:8k_2_02:76]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001728949-18-000093:8k_2_02:77]
|  |  | Q1 FY18Results (1) | Current Guidance Q1 FY19 Estimates (2)(3)(4) |  |
|  | Revenues | $6.1B | $4.5B - $5.3B |  |  |
|  | Year-over-year change |  | decrease 13% - 26% |  |  |
|  | GAAP diluted earnings (loss) per share (EPS) | ($4.03) | $0.78 - $0.88 |  |  |
|  | Year-over-year change |  | N/M |  |  |
|  | Less diluted EPS attributable to QSI | $0.01 |  | ($0.02 | ) |  |
|  | Less diluted EPS attributable to share-based compensation | ($0.13) |  | ($0.16 | ) |  |
|  | Less diluted EPS attributable to other items | ($4.89) |  | ($0.09 | ) |  |
|  | Non-GAAP diluted EPS | $0.98 | $1.05 - $1.15 |  |  |
|  | Year-over-year change |  | increase 7% - 17% |  |  |
|  | Other Information |  |  |  |
|  | MSM chip shipments | 237 | M | 175M - 195M |  |  |
|  | Year-over-year change |  | decrease 18% - 26% |  |  |
|  | QTL revenues | $1.3B | $1.0B - $1.1B |  |  |
|  | Year-over-year change |  | decrease 15% - 23% |  |  |

[0001728949-18-000093:8k_2_02:78]
| (1) | The first quarter of fiscal 2018 results excluded QTL revenues for royalties due on sales of Apple’s products by Apple’s contract manufacturers, as well as sales of products by the other licensee in dispute. Diluted EPS attributable to other items for the first quarter of fiscal 2018 was primarily attributable to a $6.0 billion charge resulting from the Tax Legislation, a $1.2 billion charge related to the fine imposed by the EC and acquisition-related items. |

[0001728949-18-000093:8k_2_02:79]
| (2) | Our financial guidance for the first quarter of fiscal 2019 excludes QTL revenues for royalties due on sales of Apple’s products by Apple’s contract manufacturers, as well as sales of products by the other licensee in dispute, as we expect the actions taken by these licensees will continue until the respective disputes are resolved. |

[0001728949-18-000093:8k_2_02:80]
| (3) | Our guidance for diluted EPS attributable to other items for the first quarter of fiscal 2019 is primarily attributable to acquisition-related items and restructuring and restructuring-related items. |

[0001728949-18-000093:8k_2_02:81]
| (4) | As a result of the Tax Legislation, we made certain tax elections in the first quarter of fiscal 2019, which will result in an estimated income tax benefit of $525 million to $575 million, which is included in our first quarter of fiscal 2019 guidance for GAAP and Non-GAAP diluted EPS. |

[0001728949-18-000093:8k_2_02:82]
N/M - Not Meaningful

[0001728949-18-000093:8k_2_02:83]
Sums may not equal total due to rounding.

[0001728949-18-000093:8k_2_02:84]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 9 of 17 |

[0001728949-18-000093:8k_2_02:85]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-18-000093:8k_2_02:86]
The following tables reconcile our GAAP results to our Non-GAAP results ($ and shares in millions, except per share data):

[0001728949-18-000093:8k_2_02:87]
|  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) | Non-GAAP Results |
| Q4 FISCAL 2018 |  |  |  |  |  |  |  |
| Revenues | $5,803 |  | $20 |  |  | $— |  |  | ($50) | (c) | $5,833 |  |
| Operating (loss) income | (654) |  | 2 |  | (224) |  | (1,712) |  | 1,280 |  |
| EBT | (775) |  | (20) |  | (224) |  | (1,800) |  | 1,269 |  |
| EBT as % of revenues | N/M |  |  |  |  |  |  |  |  | 22 | % |  |
| Net (loss) income | (493) |  | (11) |  | (195) |  | (1,567) |  | 1,280 |  |
| Diluted EPS (d) | ($0.35) |  | ($0.01) |  | ($0.14) |  | ($1.10) |  | $0.90 |  |
| Diluted shares (d) | 1,417 |  | 1,429 |  | 1,429 |  | 1,429 |  | 1,429 |  |
| Q3 FISCAL 2018 |  |  |  |  |  |  |  |
| Revenues | $5,599 |  | $20 |  |  | $— |  |  | ($50) |  | $5,629 |  |
| Operating income (loss) | 925 |  | 2 |  | (189) |  | (312) |  | 1,424 |  |
| EBT | 956 |  | (7) |  | (189) |  | (264) |  | 1,416 |  |
| EBT as % of revenues | 17 | % |  |  |  |  |  |  |  | 25 | % |  |
| Net income (loss) | 1,219 |  | (5) |  | (155) |  | (129) |  | 1,508 |  |
| Diluted EPS | $0.82 |  | $0.00 |  | ($0.10) |  | ($0.09) |  | $1.01 |  |
| Diluted shares | 1,487 |  | 1,487 |  | 1,487 |  | 1,487 |  | 1,487 |  |
| Q4 FISCAL 2017 |  |  |  |  |  |  |  |
| Revenues | $5,905 |  | $43 |  |  | $— |  |  | ($95) |  | $5,957 |  |
| Operating income (loss) | 333 |  | 22 |  | (204) |  | (1,063) |  | 1,578 |  |
| EBT | 434 |  | 28 |  | (204) |  | (1,065) |  | 1,675 |  |
| EBT as % of revenues | 7 | % |  |  |  |  |  |  |  | 28 | % |  |
| Net income (loss) | 168 |  | 25 |  | (153) |  | (1,079) |  | 1,375 |  |
| Diluted EPS | $0.11 |  | $0.02 |  | ($0.10) |  | ($0.73) |  | $0.92 |  |
| Diluted shares | 1,488 |  | 1,488 |  | 1,488 |  | 1,488 |  | 1,488 |  |
| FISCAL 2018 |  |  |  |  |  |  |  |  |  |  |
| Revenues | $22,732 |  | $100 |  |  | $— |  |  | ($100) | (c) | $22,732 |  |
| Operating income (loss) | 742 |  | 23 |  | (883) |  | (4,018) |  | 5,620 |  |
| EBT | 513 |  | 24 |  | (883) |  | (4,132) |  | 5,504 |  |
| EBT as % of revenues | 2 | % |  |  |  |  |  |  |  | 24 | % |  |
| Net (loss) income | (4,864) |  | 22 |  | (743) |  | (9,586) |  | 5,443 |  |
| Diluted EPS (d) | ($3.32) |  | $0.01 |  | ($0.50) |  | ($6.53) |  | $3.69 |  |
| Diluted shares (d) | 1,463 |  | 1,475 |  | 1,475 |  | 1,475 |  | 1,475 |  |
| FISCAL 2017 |  |  |  |  |  |  |  |  |  |  |
| Revenues | $22,291 |  | $113 |  |  | $— |  |  | ($1,057) |  | $23,235 |  |
| Operating income (loss) | 2,614 |  | 38 |  | (914) |  | (3,604) |  | 7,094 |  |
| EBT | 3,020 |  | 65 |  | (914) |  | (3,641) |  | 7,510 |  |
| EBT as % of revenues | 14 | % |  |  |  |  |  |  |  | 32 | % |  |
| Net income (loss) | 2,466 |  | 46 |  | (753) |  | (3,213) |  | 6,386 |  |
| Diluted EPS | $1.65 |  | $0.03 |  | ($0.51) |  | ($2.16) |  | $4.28 |  |
| Diluted shares | 1,490 |  | 1,490 |  | 1,490 |  | 1,490 |  | 1,490 |  |

[0001728949-18-000093:8k_2_02:88]
| (a) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” herein for further details. |

[0001728949-18-000093:8k_2_02:89]
| (b) | Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” sections herein. Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001728949-18-000093:8k_2_02:90]
| (c) | In the fourth quarter and fiscal 2018, other items excluded from Non-GAAP revenues consisted of reductions to licensing revenues related to a portion of a business arrangement that resolved a legal dispute. |

[0001728949-18-000093:8k_2_02:91]
| (d) | As a result of the net loss in our GAAP results in the fourth quarter and fiscal 2018, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of GAAP diluted loss per share. The diluted EPS impacts of a $5.7 billion charge resulting from the Tax Legislation recorded in fiscal 2018 was calculated using the GAAP diluted shares. Amounts in all other columns included the common share equivalents issuable under share-based compensation plans in the calculation of diluted earnings per share because the Company reported Non-GAAP net income. |

[0001728949-18-000093:8k_2_02:92]
Sums may not equal totals due to rounding.

[0001728949-18-000093:8k_2_02:93]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 10 of 17 |

[0001728949-18-000093:8k_2_02:94]
Supplemental Information and Reconciliations

[0001728949-18-000093:8k_2_02:95]
(Unaudited)

[0001728949-18-000093:8k_2_02:96]
|  | Q4 FISCAL 2018 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results |
|  | Cost of revenues |  | $2,850 |  |  | $15 |  |  | $8 |  |  | $114 |  |  | $2,713 |  |
|  | Research and development (R&D) expenses |  | 1,388 |  |  | — |  |  |  | 146 |  |  | 1 |  |  | 1,241 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 689 |  |  | 3 |  |  | 70 |  |  | 17 |  |  | 599 |  |
|  | Other expenses |  | 1,530 |  |  | — |  |  |  | — |  |  |  | 1,530 |  |  | — |  |  |
|  | Interest expense |  | 207 |  |  | — |  |  |  | — |  |  |  | 36 |  |  | 171 |  |
|  | Investment and other income (loss), net |  | 86 |  |  | (22) |  |  | — |  |  |  | (52) |  |  | 160 | (b) |

[0001728949-18-000093:8k_2_02:97]
| (a) | Other items excluded from Non-GAAP results included a $2.0 billion charge related to the NXP termination fee, $265 million of restructuring and restructuring-related charges related to our Cost Plan, $162 million of acquisition-related charges and $6 million of interest expense related to the EC fine, partially offset by a $676 million gain related to the TFTC settlement and $7 million of foreign currency transaction gains related to the EC and TFTC fines, net of associated losses on derivative instruments. |

[0001728949-18-000093:8k_2_02:98]
| (b) | Included $155 million in interest and dividend income, $10 million in net foreign currency gains and $8 million in net realized gains on investments, partially offset by $12 million in equity in net losses of investees and $1 million of net losses on derivative instruments. |

[0001728949-18-000093:8k_2_02:99]
|  | FISCAL 2018 |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (c) | Non-GAAP Results |
|  | Cost of revenues |  | $10,244 |  |  | $65 |  |  | $38 |  |  | $449 |  |  | $9,692 |  |
|  | Research and development (R&D) expenses |  | 5,625 |  |  | — |  |  |  | 594 |  |  | 7 |  |  | 5,024 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 2,986 |  |  | 12 |  |  | 251 |  |  | 327 |  |  | 2,396 |  |
|  | Other expenses |  | 3,135 |  |  | — |  |  |  | — |  |  |  | 3,135 |  |  | — |  |  |
|  | Interest expense |  | 768 |  |  | — |  |  |  | — |  |  |  | 64 |  |  | 704 |  |
|  | Investment and other income (loss), net |  | 539 |  |  | 1 |  |  | — |  |  |  | (50) |  |  | 588 | (d) |

[0001728949-18-000093:8k_2_02:100]
| (c) | Other items excluded from Non-GAAP results included a $2.0 billion charge related to a termination fee paid to NXP, a $1.2 billion charge related to the fine imposed by the EC, $836 million of acquisition-related charges, $687 million of restructuring and restructuring-related charges related to our Cost Plan and $10 million of interest expense related to the EC fine, partially offset by a $676 million gain related to the TFTC settlement and $8 million of foreign currency transaction gains related to the EC and TFTC fines, net of associated losses on derivative instruments. |

[0001728949-18-000093:8k_2_02:101]
| (d) | Included $602 million in interest and dividend income, $31 million in net realized gains on investments and $4 million in net foreign currency gains, partially offset by $49 million in equity in net losses of investees. |

[0001728949-18-000093:8k_2_02:102]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 11 of 17 |

[0001728949-18-000093:8k_2_02:103]
Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates

[0001728949-18-000093:8k_2_02:104]
(Unaudited)

[0001728949-18-000093:8k_2_02:105]
| ($ in millions) |  | GAAP Results |  |  | Less QSI | Less Share-Based Compensation | Less Other Items (b) (c) |  | Non-GAAP Results |  |
| Q4 FISCAL 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Loss) income before income taxes |  | $ | (775 | ) |  |  | $ | (20 | ) |  |  | $ | (224 | ) |  |  | $ | (1,800 | ) |  |  | $ | 1,269 |  |  |
| Income tax benefit |  | 282 |  |  |  | 9 |  |  |  | 29 |  |  |  | 233 |  |  |  | 11 |  |  |
| Net (loss) income |  | $ | (493 | ) |  |  | $ | (11 | ) |  |  | $ | (195 | ) |  |  | $ | (1,567 | ) |  |  | $ | 1,280 |  |  |
| Tax rate |  | 36 | % |  |  | 0 | % | (a) |  |  |  | 4 | % | (a) |  |  | 33 | % | (a) |  |  |  | (1 | %) |  |
| FISCAL 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 513 |  |  |  | $ | 24 |  |  |  | $ | (883 | ) |  |  | $ | (4,132 | ) |  |  | $ | 5,504 |  |  |
| Income tax (expense) benefit |  | (5,377 | ) |  |  | (2 | ) |  |  | 140 |  |  |  | (5,454 | ) |  |  | (61 | ) |  |
| Net (loss) income |  | $ | (4,864 | ) |  |  | $ | 22 |  |  |  | $ | (743 | ) |  |  | $ | (9,586 | ) |  |  | $ | 5,443 |  |  |
| Tax rate |  | 1,048 | % |  |  | 0 | % | (a) |  |  |  | (7 | %) | (a) |  |  |  | 1,054 | % | (a) |  |  |  | 1 | % |  |

[0001728949-18-000093:8k_2_02:106]
| (a) | The incremental effect of our adjustments to the Non-GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001728949-18-000093:8k_2_02:107]
| (b) | In the fourth quarter of fiscal 2018, the tax benefit in the “Other Items” column included a benefit of $80 million for the combined effect of other items in EBT, a $66 million benefit to reconcile the tax provision for each column to the total GAAP tax provision for the quarter, a $64 million net benefit related to the refinement of estimates related to the combined effect of the Toll Charge, the remeasurement of deferred tax assets and liabilities and our decision to no longer indefinitely reinvest certain foreign earnings, all of which relate to the Tax Legislation, and a $37 million tax benefit for the tax effect of acquisition-related items in EBT, partially offset by tax expense of $14 million related to the revaluation of deferred tax assets that existed at the end of fiscal 2017 due to a new tax incentive agreement in Singapore. |

[0001728949-18-000093:8k_2_02:108]
| (c) | In fiscal 2018, the estimated annual effective tax rate for the “Other Items” column included a $5.8 billion charge related to the combined effect of the Toll Charge, the remeasurement of deferred tax assets and liabilities and our decision to no longer indefinitely reinvest certain foreign earnings, all of which relate to the Tax Legislation, and an $8 million increase in unrecognized tax benefits, partially offset by tax benefits of $147 million for the tax effect of acquisition-related items in EBT, $165 million for the combined effect of other items in EBT and $2 million from a new tax incentive agreement in Singapore. |

[0001728949-18-000093:8k_2_02:109]
Conference Call

[0001728949-18-000093:8k_2_02:110]
Qualcomm’s fiscal fourth quarter 2018 earnings conference call will be broadcast live on November 7, 2018, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415.  Callers should use reservation number 13684055.

[0001728949-18-000093:8k_2_02:111]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-18-000093:8k_2_02:112]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-

[0001728949-18-000093:8k_2_02:113]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 12 of 17 |

[0001728949-18-000093:8k_2_02:114]
GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results used herein are presented herein.

[0001728949-18-000093:8k_2_02:115]
The Company uses Non-GAAP financial information: (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income (loss) and diluted earnings (loss) per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating the Company’s business and assessing trends and future expectations.

[0001728949-18-000093:8k_2_02:116]
Non-GAAP information used by management excludes its QSI segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-18-000093:8k_2_02:117]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001728949-18-000093:8k_2_02:118]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001728949-18-000093:8k_2_02:119]
| • | Certain other items are excluded because management views such items as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001728949-18-000093:8k_2_02:120]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 13 of 17 |

[0001728949-18-000093:8k_2_02:121]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items, as well as any effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property, third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition. Starting with acquisitions in the second quarter of fiscal 2017, the Company excludes recognition of the step-up of property, plant and equipment from the net book value based on the original cost basis to fair value. Such charges related to acquisitions that were completed prior to the second quarter of fiscal 2017 continue to be allocated to the segments, and such amounts are not material. |

[0001728949-18-000093:8k_2_02:122]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. |

[0001728949-18-000093:8k_2_02:123]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. In fiscal 2018, the Company excluded the full impact of the Toll Charge, including the portion that relates to earnings and profits of U.S.-owned foreign subsidiaries generated in the first quarter of fiscal 2018. |

[0001728949-18-000093:8k_2_02:124]
About Qualcomm

[0001728949-18-000093:8k_2_02:125]
Qualcomm invents breakthrough technologies that transform how the world connects and communicates.  When we connected the phone to the Internet, the mobile revolution was born.  Today, our inventions are the foundation for life-changing products, experiences, and industries.  As we lead the world to 5G, we envision this next big change in cellular technology spurring a new era of intelligent, connected devices and enabling new opportunities in connected cars, remote delivery of health care services, and the IoT - including smart cities, smart homes, and wearables.  Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, all of our engineering, research and development functions, and all of our products and services businesses, including, our QCT semiconductor business.  For more information, visit www.qualcomm.com.

[0001728949-18-000093:8k_2_02:126]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 14 of 17 |

[0001728949-18-000093:8k_2_02:127]
Note Regarding Forward-Looking Statements

[0001728949-18-000093:8k_2_02:128]
###

[0001728949-18-000093:8k_2_02:129]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries. Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-18-000093:8k_2_02:130]
MSM is a product of Qualcomm Technologies, Inc.

[0001728949-18-000093:8k_2_02:131]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 15 of 17 |

[0001728949-18-000093:8k_2_02:132]
Qualcomm Incorporated

[0001728949-18-000093:8k_2_02:133]
CONSOLIDATED BALANCE SHEETS

[0001728949-18-000093:8k_2_02:134]
(In millions, except per share data)

[0001728949-18-000093:8k_2_02:135]
(Unaudited)

[0001728949-18-000093:8k_2_02:136]
|  | September 30, 2018 |  | September 24, 2017 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 11,777 |  |  | $ | 35,029 |  |
| Marketable securities | 311 |  |  | 2,279 |  |
| Accounts receivable, net | 2,904 |  |  | 3,632 |  |
| Inventories | 1,693 |  |  | 2,035 |  |
| Other current assets | 699 |  |  | 618 |  |
| Total current assets | 17,384 |  |  | 43,593 |  |
| Marketable securities | 35 |  |  | 1,270 |  |
| Deferred tax assets | 904 |  |  | 2,900 |  |
| Property, plant and equipment, net | 2,975 |  |  | 3,216 |  |
| Goodwill | 6,498 |  |  | 6,623 |  |
| Other intangible assets, net | 2,955 |  |  | 3,737 |  |
| Other assets | 1,935 |  |  | 4,147 |  |
| Total assets | $ | 32,686 |  |  | $ | 65,486 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,825 |  |  | $ | 1,971 |  |
| Payroll and other benefits related liabilities | 1,081 |  |  | 1,183 |  |
| Unearned revenues | 500 |  |  | 502 |  |
| Short-term debt | 1,005 |  |  | 2,495 |  |
| Other current liabilities | 6,825 |  |  | 4,756 |  |
| Total current liabilities | 11,236 |  |  | 10,907 |  |
| Unearned revenues | 1,620 |  |  | 2,003 |  |
| Income taxes payable | 2,312 |  |  | — |  |
| Long-term debt | 15,365 |  |  | 19,398 |  |
| Other liabilities | 1,225 |  |  | 2,432 |  |
| Total liabilities | 31,758 |  |  | 34,740 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,219 and 1,474 shares issued and outstanding, respectively | — |  |  | 274 |  |
| Retained earnings | 663 |  |  | 30,088 |  |
| Accumulated other comprehensive income | 265 |  |  | 384 |  |
| Total stockholders’ equity | 928 |  |  | 30,746 |  |
| Total liabilities and stockholders’ equity | $ | 32,686 |  |  | $ | 65,486 |  |

[0001728949-18-000093:8k_2_02:137]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 16 of 17 |

[0001728949-18-000093:8k_2_02:138]
Qualcomm Incorporated

[0001728949-18-000093:8k_2_02:139]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-18-000093:8k_2_02:140]
(In millions, except per share data)

[0001728949-18-000093:8k_2_02:141]
(Unaudited)

[0001728949-18-000093:8k_2_02:142]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 30, 2018 |  | September 24, 2017 |  | September 30, 2018 |  | September 24, 2017 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 4,650 |  |  | $ | 4,698 |  |  | $ | 17,400 |  |  | $ | 16,647 |  |
| Licensing | 1,153 |  |  | 1,207 |  |  | 5,332 |  |  | 5,644 |  |
| Total revenues | 5,803 |  |  | 5,905 |  |  | 22,732 |  |  | 22,291 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of revenues | 2,850 |  |  | 2,653 |  |  | 10,244 |  |  | 9,792 |  |
| Research and development | 1,388 |  |  | 1,397 |  |  | 5,625 |  |  | 5,485 |  |
| Selling, general and administrative | 689 |  |  | 742 |  |  | 2,986 |  |  | 2,658 |  |
| Other | 1,530 |  |  | 780 |  |  | 3,135 |  |  | 1,742 |  |
| Total costs and expenses | 6,457 |  |  | 5,572 |  |  | 21,990 |  |  | 19,677 |  |
| Operating (loss) income | (654 | ) |  | 333 |  |  | 742 |  |  | 2,614 |  |
| Interest expense | (207 | ) |  | (164 | ) |  | (768 | ) |  | (494 | ) |
| Investment and other income, net | 86 |  |  | 265 |  |  | 539 |  |  | 900 |  |
| Income (loss) before income taxes | (775 | ) |  | 434 |  |  | 513 |  |  | 3,020 |  |
| Income tax benefit (expense) | 282 |  |  | (266 | ) |  | (5,377 | ) |  | (555 | ) |
| Net (loss) income | (493 | ) |  | 168 |  |  | (4,864 | ) |  | 2,465 |  |
| Net loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 1 |  |
| Net (loss) income attributable to Qualcomm | $ | (493 | ) |  | $ | 168 |  |  | $ | (4,864 | ) |  | $ | 2,466 |  |
| Basic (loss) earnings per share attributable to Qualcomm | $ | (0.35 | ) |  | $ | 0.11 |  |  | $ | (3.32 | ) |  | $ | 1.67 |  |
| Diluted (loss) earnings per share attributable to Qualcomm | $ | (0.35 | ) |  | $ | 0.11 |  |  | $ | (3.32 | ) |  | $ | 1.65 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,417 |  |  | 1,476 |  |  | 1,463 |  |  | 1,477 |  |
| Diluted | 1,417 |  |  | 1,488 |  |  | 1,463 |  |  | 1,490 |  |

[0001728949-18-000093:8k_2_02:143]
| Qualcomm Announces Fourth Quarter and Fiscal 2018 Results | Page 17 of 17 |

[0001728949-18-000093:8k_2_02:144]
Qualcomm Incorporated

[0001728949-18-000093:8k_2_02:145]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-18-000093:8k_2_02:146]
(In millions)

[0001728949-18-000093:8k_2_02:147]
(Unaudited)

[0001728949-18-000093:8k_2_02:148]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 30, 2018 |  | September 24, 2017 |  | September 30, 2018 |  | September 24, 2017 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net (loss) income | $ | (493 | ) |  | $ | 168 |  |  | $ | (4,864 | ) |  | $ | 2,465 |  |
| Adjustments to reconcile net (loss) income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 396 |  |  | 397 |  |  | 1,561 |  |  | 1,461 |  |
| Income tax provision (less than) in excess of income tax payments | (471 | ) |  | 67 |  |  | 4,502 |  |  | (400 | ) |
| Non-cash portion of share-based compensation expense | 224 |  |  | 204 |  |  | 883 |  |  | 914 |  |
| Net realized gains on marketable securities and other investments | (24 | ) |  | (156 | ) |  | (124 | ) |  | (530 | ) |
| Indefinite and long-lived asset impairment charges | 177 |  |  | — |  |  | 273 |  |  | 76 |  |
| Impairment losses on marketable securities and other investments | 35 |  |  | 15 |  |  | 75 |  |  | 177 |  |
| Other items, net | 105 |  |  | 131 |  |  | 129 |  |  | 146 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | 264 |  |  | (83 | ) |  | 734 |  |  | (1,104 | ) |
| Inventories | 92 |  |  | (18 | ) |  | 337 |  |  | (200 | ) |
| Other assets | (60 | ) |  | 58 |  |  | 30 |  |  | 169 |  |
| Trade accounts payable | 202 |  |  | 498 |  |  | (94 | ) |  | (45 | ) |
| Payroll, benefits and other liabilities | (827 | ) |  | 1,225 |  |  | 687 |  |  | 2,103 |  |
| Unearned revenues | (56 | ) |  | (82 | ) |  | (234 | ) |  | (231 | ) |
| Net cash (used) provided by operating activities | (436 | ) |  | 2,424 |  |  | 3,895 |  |  | 5,001 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (159 | ) |  | (262 | ) |  | (784 | ) |  | (690 | ) |
| Purchases of available-for-sale marketable securities | (101 | ) |  | (3,553 | ) |  | (5,936 | ) |  | (19,062 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 83 |  |  | 22,072 |  |  | 9,188 |  |  | 41,715 |  |
| Purchases of other marketable securities | — |  |  | (5 | ) |  | (49 | ) |  | (710 | ) |
| Proceeds from sales and maturities of other marketable securities | 50 |  |  | 706 |  |  | 50 |  |  | 706 |  |
| Release (deposits) of investments designated as collateral | 2,000 |  |  | — |  |  | 2,000 |  |  | (2,000 | ) |
| Acquisitions and other investments, net of cash acquired | (134 | ) |  | (143 | ) |  | (326 | ) |  | (1,544 | ) |
| Proceeds from other investments | 15 |  |  | 5 |  |  | 222 |  |  | 23 |  |
| Other items, net | 12 |  |  | (15 | ) |  | 16 |  |  | 25 |  |
| Net cash provided by investing activities | 1,766 |  |  | 18,805 |  |  | 4,381 |  |  | 18,463 |  |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 1,746 |  |  | 1,710 |  |  | 11,131 |  |  | 8,558 |  |
| Repayment of short-term debt | (3,929 | ) |  | (1,711 | ) |  | (11,127 | ) |  | (9,309 | ) |
| Proceeds from long-term debt | — |  |  | — |  |  | — |  |  | 10,953 |  |
| Repayment of long-term debt | (3,929 | ) |  | — |  |  | (5,500 | ) |  | — |  |
| Release of deposit to redeem long-term debt | 2,831 |  |  | — |  |  | — |  |  | — |  |
| Proceeds from issuance of common stock | 216 |  |  | 166 |  |  | 603 |  |  | 497 |  |
| Repurchases and retirements of common stock | (21,155 | ) |  | (315 | ) |  | (22,580 | ) |  | (1,342 | ) |
| Dividends paid | (866 | ) |  | (841 | ) |  | (3,466 | ) |  | (3,252 | ) |
| Payments of tax withholdings related to vesting of share-based awards | (7 | ) |  | (5 | ) |  | (280 | ) |  | (268 | ) |
| Payment of purchase consideration related to RF360 joint venture | — |  |  | (115 | ) |  | (157 | ) |  | (115 | ) |
| Other items, net | (57 | ) |  | (18 | ) |  | (111 | ) |  | (151 | ) |
| Net cash (used) provided by financing activities | (25,150 | ) |  | (1,129 | ) |  | (31,487 | ) |  | 5,571 |  |
| Effect of exchange rate changes on cash and cash equivalents | (22 | ) |  | 20 |  |  | (41 | ) |  | 48 |  |
| Net (decrease) increase in cash and cash equivalents | (23,842 | ) |  | 20,120 |  |  | (23,252 | ) |  | 29,083 |  |
| Cash and cash equivalents at beginning of period | 35,619 |  |  | 14,909 |  |  | 35,029 |  |  | 5,946 |  |
| Cash and cash equivalents at end of period | $ | 11,777 |  |  | $ | 35,029 |  |  | $ | 11,777 |  |  | $ | 35,029 |  |
