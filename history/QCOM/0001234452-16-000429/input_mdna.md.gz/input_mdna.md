# QCOM MD&A — 0001234452-16-000429


## mdna

[0001234452-16-000429:mdna:1]
[same as prior period, unchanged from 0001234452-16-000352:mdna:1]

[0001234452-16-000429:mdna:2]
[same as prior period, unchanged from 0001234452-16-000352:mdna:2]

[0001234452-16-000429:mdna:3]
This Quarterly Report (including, but not limited to, this section regarding Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements, including, but not limited to, statements regarding industry trends and dynamics; challenges and opportunities related to our semiconductor and licensing businesses, particularly in China; our Strategic Realignment Plan; our joint venture with TDK Corporation; and our future business, investments, financial condition, results of operations and prospects. Additionally, statements concerning other future matters, such as the development of new products, enhancements of technologies, industry or regional trends, consumer demand, sales or price levels, challenges to our business and/or business model, capital expenditures, investments in research and development, strategic investments and acquisitions and other statements regarding matters that are not historical, are forward-looking statements. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001234452-16-000429:mdna:4]
[same as prior period, unchanged from 0001234452-16-000352:mdna:4]

[0001234452-16-000429:mdna:5]
Revenues for the second quarter of fiscal 2016 were $5.6 billion, a decrease of 19% compared to the year ago quarter, with net income attributable to Qualcomm of $1.2 billion, an increase of 11% compared to the year ago quarter.

[0001234452-16-000429:mdna:6]
| • | We shipped approximately 189 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, a decrease of 19%, compared to approximately 233 million MSM integrated circuits in the year ago quarter. The decline in MSM shipments contributed in part to a 25% decrease in QCT’s revenues as compared to the year ago quarter. QCT continued to be negatively impacted by the effects of a shift in share among our customers within the premium tier, a decline in demand for thin modem products, a decline in share at a large customer and the competitive environment in China. |

[0001234452-16-000429:mdna:7]
| • | Total reported device sales were approximately $70.1 billion, a decrease of approximately 8%, compared to approximately $75.8 billion in the year ago quarter.(1) QTL’s revenues decreased by 12% compared to the year ago quarter primarily as a result of a decrease in reported sales of CDMA-based products (including multimode products that also implement OFDMA), which was impacted by the effect of underreported royalties by licensees, and the deferral of revenue due to the arbitration with LG Electronics, Inc. (LGE), among other factors. |

[0001234452-16-000429:mdna:8]
Against this backdrop, the following recent developments occurred during the second quarter of fiscal 2016 with respect to key elements of our industry:

[0001234452-16-000429:mdna:9]
| • | Worldwide cellular connections grew sequentially by approximately 1% to reach approximately 7.4 billion.(2) |

[0001234452-16-000429:mdna:10]
| • | Worldwide 3G/4G connections (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) grew sequentially by approximately 4% to approximately 3.7 billion, which was approximately 50% of total cellular connections.(2) |

[0001234452-16-000429:mdna:11]
[same as prior period, unchanged from 0001234452-16-000352:mdna:12]

[0001234452-16-000429:mdna:12]
[same as prior period, unchanged from 0001234452-16-000352:mdna:13]

[0001234452-16-000429:mdna:13]
| (2) | According to GSMA Intelligence estimates as of April 18, 2016 for the quarter ended March 31, 2016. |

[0001234452-16-000429:mdna:14]
[same as prior period, unchanged from 0001234452-16-000352:mdna:15]

[0001234452-16-000429:mdna:15]
[same as prior period, unchanged from 0001234452-16-000352:mdna:16]

[0001234452-16-000429:mdna:16]
[same as prior period, unchanged from 0001234452-16-000352:mdna:17]

[0001234452-16-000429:mdna:17]
QCT is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products are sold and its system software is licensed to manufacturers that use our products in wireless devices, particularly mobile phones, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards, infrastructure equipment, headsets, sound systems and automobiles and in wired devices, particularly broadband gateway equipment, desktop computers and streaming media players. Our MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Qualcomm Snapdragon processors and LTE modems, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon processors provide advanced application and graphics processing capabilities. QCT’s system software enables the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits. QCT revenues comprised 60% and 64% of total consolidated revenues in the second quarter of fiscal 2016 and 2015, respectively, and 66% and 69% of total consolidated revenues for the first six months of fiscal 2016 and 2015, respectively.

[0001234452-16-000429:mdna:18]
[same as prior period, unchanged from 0001234452-16-000352:mdna:19]

[0001234452-16-000429:mdna:19]
QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD and/or LTE standards and their derivatives. QTL licensing revenues include license fees and royalties based on sales by licensees of products incorporating or using our intellectual property. License fees are fixed amounts paid in one or more installments. Royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). QTL recognizes royalty revenues based on royalties reported by licensees and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. QTL revenues comprised 38% and 35% of total consolidated revenues in the second quarter of fiscal 2016 and 2015, respectively, and 33% and 30% of total consolidated revenues for the first six months of fiscal 2016 and 2015, respectively. The vast majority of such revenues were generated through our licensees’ sales of CDMA-based products (including multimode products that also implement OFDMA), such as feature phones and smartphones.

[0001234452-16-000429:mdna:20]
QSI makes strategic investments that are focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications. Many of these strategic investments are in early-stage companies in a variety of industries, including, but not limited to, digital media, e-commerce, healthcare and wearable devices. Investments primarily include non-marketable equity instruments, which generally are recorded using the cost method or the equity method, and convertible debt instruments, which are recorded at fair value. QSI also held wireless spectrum, which was sold in October 2015 for a gain of approximately $380 million. In addition, QSI segment results include revenues and related costs associated with development contracts with one of our equity method investees. As part of our strategic investment activities, we intend to pursue various exit strategies for each of our QSI investments in the foreseeable future.

[0001234452-16-000429:mdna:21]
[same as prior period, unchanged from 0001234452-16-000352:mdna:23]

[0001234452-16-000429:mdna:22]
[same as prior period, unchanged from 0001234452-16-000352:mdna:24]

[0001234452-16-000429:mdna:23]
[same as prior period, unchanged from 0001234452-16-000352:mdna:25]

[0001234452-16-000429:mdna:24]
[same as prior period, unchanged from 0001234452-16-000352:mdna:26]

[0001234452-16-000429:mdna:25]
| • | China continues to present significant opportunities for us, particularly with the rollout of 3G/4G LTE multimode. We expect the ongoing rollout of 4G services in China will encourage competition and growth, bring the benefits of 3G/4G LTE multimode to consumers, encourage consumers to replace 2G (GSM) and 3G devices and enable new opportunities beyond mobile applications (e.g., machine-to-machine). |

[0001234452-16-000429:mdna:26]
| • | We expect that the increased availability of low-tier 3G/4G smartphone products will help enable further expansion of 3G and 3G/4G multimode in emerging regions. |

[0001234452-16-000429:mdna:27]
[same as prior period, unchanged from 0001234452-16-000352:mdna:29]

[0001234452-16-000429:mdna:28]
| • | Despite the resolution of the NDRC investigation, China continues to present significant challenges for us. We continue to believe that certain licensees are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes 3G/4G units that we believe are not being reported by certain licensees), and certain companies, including unlicensed companies, are delaying execution of new license agreements. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing. We believe that the conclusion of new agreements with these licensees will result in improved reporting by these licensees, including with respect to sales of three-mode devices (i.e., devices that implement GSM, TD-SCDMA and LTE-TDD) sold in China. However, litigation and/or other actions may be necessary to compel licensees to report and pay the required royalties for sales they have not previously reported and to compel unlicensed companies to execute new licenses. |

[0001234452-16-000429:mdna:29]
| • | Regulatory authorities in other jurisdictions continue to investigate our business practices as well. |

[0001234452-16-000429:mdna:30]
| • | In April 2016, we entered into agreements with LG Electronics, Inc. pursuant to which LG Electronics agreed to dismiss the arbitration that it had commenced in the first quarter of fiscal 2016 over certain terms of its license agreement. As a result of the settlement, commencing with the third quarter of fiscal 2016, we will no longer defer |

[0001234452-16-000429:mdna:31]
27

[0001234452-16-000429:mdna:32]
royalty revenues reported by LG Electronics and will record greater than $200 million of revenues that were previously deferred.

[0001234452-16-000429:mdna:33]
| • | Our business, particularly our semiconductor business, QCT, continues to be impacted by current industry dynamics, including: concentration of device share among companies within the premium tier, which will continue to negatively impact sales of our integrated Snapdragon processors and skew our product mix towards lower-margin modem chipsets in this tier; and intense competition, particularly in China. In addition, we expect QCT will be impacted by second sourcing decisions made by our large customers, which are included in our planning assumptions. |

[0001234452-16-000429:mdna:34]
[same as prior period, unchanged from 0001234452-16-000352:mdna:34]

[0001234452-16-000429:mdna:35]
[same as prior period, unchanged from 0001234452-16-000352:mdna:35]

[0001234452-16-000429:mdna:36]
| • | In the fourth quarter of fiscal 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders. As part of this Strategic Realignment Plan, among other actions, we are implementing a cost reduction plan and plan to reduce our annual costs from fiscal 2015 levels (adjusted for variable compensation) of $7.3 billion (as announced on July 22, 2015) by approximately $1.1 billion through a series of targeted reductions across Qualcomm’s businesses, particularly in QCT. We are also planning to reduce annual share-based compensation grants by approximately $300 million. We expect these cost reduction initiatives to be substantially implemented by the end of fiscal 2016. Restructuring activities were initiated in the fourth quarter of fiscal 2015, and a total of $271 million in net restructuring and restructuring-related charges were incurred through the second quarter of fiscal 2016. We expect to incur additional restructuring and restructuring-related charges of approximately $25 million to $125 million. |

[0001234452-16-000429:mdna:37]
| • | In January 2016, we announced that we had reached an agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd., to enable delivery of radio frequency front-end (RFFE) modules and RF filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others. The joint venture will initially be owned 51% by us and 49% by TDK. Certain intellectual property, patents and filter and module design and manufacturing assets will be carved out of existing TDK businesses and be acquired by the joint venture, with certain assets acquired by us. The purchase price of our interest in the joint venture and the assets to be transferred to us is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, we have the option to acquire (and TDK has an option to sell) TDK’s interest in the joint venture for $1.15 billion 30 months after the closing date. TDK will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date, which is a substitute for and in lieu of any right of TDK to receive any profit sharing, distributions, dividends or other payments of any kind or nature. The transaction is subject to receipt of regulatory approvals and other closing conditions and is expected to close by early calendar 2017. |

[0001234452-16-000429:mdna:38]
[same as prior period, unchanged from 0001234452-16-000352:mdna:38]

[0001234452-16-000429:mdna:39]
[same as prior period, unchanged from 0001234452-16-000352:mdna:39]

[0001234452-16-000429:mdna:40]
[same as prior period, unchanged from 0001234452-16-000352:mdna:40]

[0001234452-16-000429:mdna:41]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | Change |  | March 27, 2016 |  | March 29, 2015 |  | Change |
| Equipment and services | $ | 3,349 |  |  | $ | 4,403 |  |  | $ | (1,054 | ) |  | $ | 7,436 |  |  | $ | 9,619 |  |  | $ | (2,183 | ) |
| Licensing | 2,202 |  |  | 2,491 |  |  | (289 | ) |  | 3,890 |  |  | 4,374 |  |  | (484 | ) |
|  | $ | 5,551 |  |  | $ | 6,894 |  |  | $ | (1,343 | ) |  | $ | 11,326 |  |  | $ | 13,993 |  |  | $ | (2,667 | ) |

[0001234452-16-000429:mdna:42]
The decreases in equipment and services revenues in the second quarter and first six months of fiscal 2016 were primarily due to decreases in QCT revenues of $1.09 billion and $2.25 billion, respectively. The decreases in licensing revenues in the second quarter and first six months of fiscal 2016 were primarily due to decreases in QTL revenues of $279 million and $488 million, respectively.

[0001234452-16-000429:mdna:43]
| Costs and Expenses (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | Change |  | March 27, 2016 |  | March 29, 2015 |  | Change |
| Cost of equipment and services (E&S) revenues | $ | 2,141 |  |  | $ | 2,628 |  |  | $ | (487 | ) |  | $ | 4,675 |  |  | $ | 5,676 |  |  | $ | (1,001 | ) |
| Cost as % of E&S revenues | 64 | % |  | 60 | % |  |  |  | 63 | % |  | 59 | % |  |  |

[0001234452-16-000429:mdna:44]
The decreases in margin percentage in the second quarter and first six months of fiscal 2016 were driven primarily by the effect of $43 million and $117 million, respectively, in additional charges related to the amortization of intangible assets and recognition of the step-up of inventories to fair value primarily related to the acquisition of CSR plc in the fourth quarter of fiscal 2015, and decreases in QCT margin percentage. Our margin percentage may fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors.

[0001234452-16-000429:mdna:45]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | Change |  | March 27, 2016 |  | March 29, 2015 |  | Change |
| Research and development | $ | 1,301 |  |  | $ | 1,375 |  |  | $ | (74 | ) |  | $ | 2,653 |  |  | $ | 2,726 |  |  | $ | (73 | ) |
| % of revenues | 23 | % |  | 20 | % |  |  |  | 23 | % |  | 19 | % |  |  |
| Selling, general, and administrative | $ | 619 |  |  | $ | 545 |  |  | $ | 74 |  |  | $ | 1,198 |  |  | $ | 1,128 |  |  | $ | 70 |  |
| % of revenues | 11 | % |  | 8 | % |  |  |  | 11 | % |  | 8 | % |  |  |
| Other | $ | 75 |  |  | $ | 1,010 |  |  | $ | (935 | ) |  | $ | (299 | ) |  | $ | 1,063 |  |  | $ | (1,362 | ) |

[0001234452-16-000429:mdna:46]
The dollar decreases in research and development expenses in the second quarter and first six months of fiscal 2016  were primarily attributable to decreases of $33 million and $35 million, respectively, in costs related to the development of CDMA-based 3G, OFDMA-based 4G LTE and other technologies for integrated circuit and related software products and to expand our intellectual property portfolio and decreases of $44 million and $60 million, respectively, in development costs and the effect of an impairment charge recorded in the second quarter of fiscal 2015 related to our display businesses. The dollar decrease in research and development expenses in the first six months of fiscal 2016 was partially offset by an increase of $28 million in costs related to the development of our data center products.

[0001234452-16-000429:mdna:47]
The dollar increases in selling, general and administrative expenses in the second quarter and first six months of fiscal 2016 were primarily attributable to increases of $35 million and $36 million, respectively, in litigation and other legal matters and $13 million and $17 million, respectively, in depreciation and amortization expense. The dollar increase in selling, general and administrative expenses in the first six months of fiscal 2016 was also attributable to an increase of $21 million in selling and marketing expenses, partially offset by a decrease of $18 million in share-based compensation expenses.

[0001234452-16-000429:mdna:48]
Other expenses in the second quarter of fiscal 2016 were attributable to $75 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan. Other income in the first six months of fiscal 2016 was primarily attributable to a $380 million gain on the sale of wireless spectrum and also included $129 million in restructuring and

[0001234452-16-000429:mdna:49]
29

[0001234452-16-000429:mdna:50]
restructuring-related charges, partially offset by a $48 million gain on the sale of our business that provided augmented reality applications, both of which related to our Strategic Realignment Plan.

[0001234452-16-000429:mdna:51]
Other expenses in the second quarter of fiscal 2015 were primarily attributable to a $975 million charge resulting from the resolution reached with the NDRC. Other expenses in the first six months of fiscal 2015 also included $104 million in goodwill impairment charges related to our push-to-talk services business and one of our display businesses, partially offset by a $16 million gain on the sale of certain property, plant and equipment.

[0001234452-16-000429:mdna:52]
| Interest Expense and Net Investment Income (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | Change |  | March 27, 2016 |  | March 29, 2015 |  | Change |
| Interest expense | $ | 72 |  |  | $ | 1 |  |  | $ | 71 |  |  | $ | 145 |  |  | $ | 2 |  |  | $ | 143 |  |
| Investment income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 158 |  |  | $ | 138 |  |  | $ | 20 |  |  | $ | 295 |  |  | $ | 272 |  |  | $ | 23 |  |
| Net realized gains on marketable securities | 1 |  |  | 108 |  |  | (107 | ) |  | 43 |  |  | 264 |  |  | (221 | ) |
| Net realized gains on other investments | 23 |  |  | 3 |  |  | 20 |  |  | 30 |  |  | 13 |  |  | 17 |  |
| Impairment losses on marketable securities and other investments | (43 | ) |  | (41 | ) |  | (2 | ) |  | (106 | ) |  | (106 | ) |  | — |  |
| Equity in net losses of investees | (11 | ) |  | (9 | ) |  | (2 | ) |  | (31 | ) |  | (13 | ) |  | (18 | ) |
| Other | (1 | ) |  | 5 |  |  | (6 | ) |  | (5 | ) |  | 9 |  |  | (14 | ) |
|  | $ | 127 |  |  | $ | 204 |  |  | $ | (77 | ) |  | $ | 226 |  |  | $ | 439 |  |  | $ | (213 | ) |

[0001234452-16-000429:mdna:53]
The increase in interest expense in the second quarter and first six months of fiscal 2016 was primarily due to the issuance of an aggregate principal amount of $10.0 billion in floating- and fixed-rate notes in May 2015.

[0001234452-16-000429:mdna:54]
| Income Tax Expense (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | Change |  | March 27, 2016 |  | March 29, 2015 |  | Change |
| Income tax expense | $ | 306 |  |  | $ | 487 |  |  | $ | (181 | ) |  | $ | 520 |  |  | $ | 814 |  |  | $ | (294 | ) |
| Effective tax rate | 21 | % |  | 32 | % |  | (11 | %) |  | 16 | % |  | 21 | % |  | (5 | %) |

[0001234452-16-000429:mdna:55]
The following table summarizes the primary factors that caused our effective tax rates for the second quarter and first six months of fiscal 2016 and 2015 to be less than the United States federal statutory rate:

[0001234452-16-000429:mdna:56]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | March 27, 2016 |  | March 29, 2015 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |  | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (14 | %) |  | (2 | %) |  | (16 | %) |  | (10 | %) |
| Benefits related to the research and development tax credit | (1 | %) |  | (1 | %) |  | (4 | %) |  | (3 | %) |
| Tax audit impacts, net | — |  |  | (4 | %) |  | — |  |  | (2 | %) |
| Other | 1 | % |  | 4 | % |  | 1 | % |  | 1 | % |
| Effective tax rate | 21 | % |  | 32 | % |  | 16 | % |  | 21 | % |

[0001234452-16-000429:mdna:57]
[same as prior period, unchanged from 0001234452-16-000352:mdna:68]

[0001234452-16-000429:mdna:58]
The effective tax rate of 21% for the second quarter of fiscal 2016 was greater than the estimated annual effective tax rate of 18% primarily due to changes in our estimates made in the second quarter of fiscal 2016 related to foreign earnings taxed at rates that are less than the United States federal tax rate. Additionally, the estimated annual effective tax rate for fiscal 2016 reflects the benefit of the retroactive reinstatement of the United States federal research and development credit recorded discretely during the first quarter of fiscal 2016. The annual effective tax rate of 19% for fiscal 2015 reflected the NDRC fine of $975 million, which was not deductible for tax purposes and was substantially attributable to a foreign jurisdiction, and a $61 million tax benefit as a result of a favorable tax audit settlement with the Internal Revenue Service, both of which were accounted for discretely in the second quarter of fiscal 2015. During the first quarter of fiscal 2015, the United States government reinstated the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. As a result of the reinstatement, the annual effective tax rate for fiscal 2015 also reflected a tax benefit of $101 million in the first quarter of fiscal 2015 related to fiscal 2014. Unrecognized tax benefits were $154 million and $40 million at March 27, 2016 and September 27, 2015, respectively. Certain of our existing tax positions are expected to continue to generate an increase in unrecognized tax benefits through fiscal 2016.

[0001234452-16-000429:mdna:59]
[same as prior period, unchanged from 0001234452-16-000352:mdna:57]

[0001234452-16-000429:mdna:60]
The following should be read in conjunction with the financial results for the second quarter and first six months of fiscal 2016 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 8. Segment Information.”

[0001234452-16-000429:mdna:61]
| (in millions) | QCT |  | QTL |  | QSI |
| Three Months Ended March 27, 2016 |  |  |  |  |  |
| Revenues | $ | 3,337 |  |  | $ | 2,135 |  |  | $ | 12 |  |
| EBT (1) | 170 |  |  | 1,857 |  |  | 46 |  |
| EBT as a % of revenues | 5 | % |  | 87 | % |  |  |  |
| Three Months Ended March 29, 2015 |  |  |  |  |  |
| Revenues | $ | 4,434 |  |  | $ | 2,414 |  |  | $ | — |  |
| EBT (1) | 750 |  |  | 2,162 |  |  | (32 | ) |
| EBT as a % of revenues | 17 | % |  | 90 | % |  |  |
| Six Months Ended March 27, 2016 |  |  |  |  |  |
| Revenues | $ | 7,433 |  |  | $ | 3,742 |  |  | $ | 21 |  |
| EBT (1) | 760 |  |  | 3,195 |  |  | 405 |  |
| EBT as a % of revenues | 10 | % |  | 85 | % |  |  |
| Six Months Ended March 29, 2015 |  |  |  |  |  |
| Revenues | $ | 9,676 |  |  | $ | 4,230 |  |  | $ | — |  |
| EBT (1) | 1,896 |  |  | 3,741 |  |  | (33 | ) |
| EBT as a % of revenues | 20 | % |  | 88 | % |  |  |

[0001234452-16-000429:mdna:62]
[same as prior period, unchanged from 0001234452-16-000352:mdna:60]

[0001234452-16-000429:mdna:63]
QCT Segment. QCT results of operations in the second quarter and first six months of fiscal 2016 continued to be negatively impacted by the effects of a shift in share among our customers within the premium tier, which reduced our sales of integrated Snapdragon processors and skewed our product mix towards lower-margin modem chipsets in this tier, a decline in demand for our thin modem products, a decline in share at a large customer and the competitive environment in China. The decreases in QCT revenues in the second quarter and first six months of fiscal 2016 of $1.10 billion and $2.24 billion, respectively, were primarily due to decreases in equipment and services revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying Radio Frequency (RF) and Power Management (PM) integrated circuits, were $3.28 billion and $4.37 billion in the second quarter of fiscal 2016 and 2015, respectively and $7.30 billion and $9.56 billion in the first six months of fiscal 2016 and 2015, respectively. The decreases in equipment and services revenues in the second quarter and first six months of fiscal 2016 resulted primarily from decreases of $689 million and $1.15 billion, respectively, related to lower MSM and accompanying RF and PM unit shipments and $473 million and $1.32 billion, respectively, from lower average selling prices and lower-priced product mix, partially offset by net increases of $81 million and $233 million, respectively, in revenues related to other products. Approximately 189 million and 233 million MSM integrated circuits were

[0001234452-16-000429:mdna:64]
31

[0001234452-16-000429:mdna:65]
sold during the second quarter of fiscal 2016 and 2015, respectively, and approximately 430 million and 503 million MSM integrated circuits were sold during the first six months of fiscal 2016 and 2015, respectively.

[0001234452-16-000429:mdna:66]
QCT EBT as a percentage of revenues in the second quarter and first six months of fiscal 2016 decreased primarily due to the impact of lower revenues relative to operating expenses and decreases in gross margin percentage. The decreases in QCT gross margin percentage primarily resulted from lower average selling prices and lower-margin product mix, partially offset by lower average unit costs and lower excess inventory charges.

[0001234452-16-000429:mdna:67]
QTL Segment. The decreases in QTL revenues in the second quarter and first six months of fiscal 2016 of $279 million and $488 million, respectively, were primarily attributable to a decrease in reported sales of CDMA-based products (including multimode products that also implement OFDMA), which was impacted by the effect of underreported royalties by licensees, the deferral of revenue due to the arbitration with LG Electronics, Inc. (LGE) and decreases in revenues per reported unit and recognition of unearned license fees, partially offset by $266 million in licensing revenues recorded in the second quarter of fiscal 2016 due to the termination of an infrastructure license agreement resulting from the merger of two licensees. QTL revenues and EBT for the second quarter and first six months of fiscal 2016 were impacted negatively by units that we believe are not being reported by certain licensees and sales of certain unlicensed products.

[0001234452-16-000429:mdna:68]
In April 2016, we entered into agreements with LGE pursuant to which LGE agreed to dismiss the arbitration. As a result of the settlement, commencing with the third quarter of fiscal 2016, we will no longer defer royalty revenues reported by LGE and will record greater than $200 million of revenues that were previously deferred. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing, and litigation may become necessary if negotiations fail to resolve the relevant issues.

[0001234452-16-000429:mdna:69]
QSI Segment. The increase in QSI EBT in the second quarter of fiscal 2016 was primarily due to a $46 million increase in net realized gains on investments and a $24 million decrease in impairment losses on investments. The increase in QSI EBT in the first six months of fiscal 2016 was primarily due to a $380 million gain on the sale of wireless spectrum and a $54 million increase in net realized gains on investments, partially offset by a $17 million increase in equity in losses of investees.

[0001234452-16-000429:mdna:70]
[same as prior period, unchanged from 0001234452-16-000352:mdna:65]

[0001234452-16-000429:mdna:71]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. The following tables present selected financial information related to our liquidity as of March 27, 2016 and September 27, 2015 and for the first six months of fiscal 2016 and 2015 (in millions):

[0001234452-16-000429:mdna:72]
|  | March 27, 2016 |  | September 27, 2015 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 29,984 |  |  | $ | 30,947 |  |  | $ | (963 | ) |  | (3 | %) |
| Accounts receivable, net | 1,738 |  |  | 1,964 |  |  | (226 | ) |  | (12 | %) |
| Inventories | 1,427 |  |  | 1,492 |  |  | (65 | ) |  | (4 | %) |
| Short-term debt | 1,949 |  |  | 1,000 |  |  | 949 |  |  | 95 | % |
| Long-term debt | 9,993 |  |  | 9,969 |  |  | 24 |  |  | — | % |

[0001234452-16-000429:mdna:73]
|  | Six Months Ended |  |  |  |  |
|  | March 27, 2016 |  | March 29, 2015 |  | $ Change |  | % Change |
| Net cash provided by operating activities | $ | 3,476 |  |  | $ | 1,706 |  |  | $ | 1,770 |  |  | 104 | % |
| Net cash used by investing activities | (1,435 | ) |  | (690 | ) |  | (745 | ) |  | 108 | % |
| Net cash used by financing activities | (3,822 | ) |  | (3,416 | ) |  | (406 | ) |  | 12 | % |

[0001234452-16-000429:mdna:74]
The net decrease in cash, cash equivalents and marketable securities was primarily the result of $3.6 billion in payments to repurchase shares of our common stock and $1.4 billion in cash dividends paid, partially offset by net cash provided by operating activities and net proceeds from short-term debt. Total cash provided by operating activities increased primarily due to changes in working capital, which was impacted by a prepayment of $950 million in the six months ended March 29, 2015 to secure long-term capacity commitments at a supplier of our integrated circuit products, partially offset by a reduction in net income of $363 million. Our days sales outstanding, on a consolidated basis, decreased to 28 days at March 27, 2016 compared to 33 days at September 27, 2015. The decrease in accounts receivable was primarily due to the collection of

[0001234452-16-000429:mdna:75]
32

[0001234452-16-000429:mdna:76]
payments from certain of our licensees and the timing of integrated circuit shipments. The decrease in days sales outstanding was primarily due to the collection of payments from certain of our licensees and an increase in licensing revenues from the termination of an infrastructure license agreement resulting from the merger of two licensees. The decrease in inventories was primarily due to a decrease in QCT finished goods related to lower units on hand to align with near-term demand and recognition of the step-up in the fair value of the acquired inventories from the CSR acquisition.

[0001234452-16-000429:mdna:77]
We classify certain of our marketable securities as short-term based on their nature and our plan to make them available, if needed, for use in our current operations. While we do not anticipate using our non-current marketable securities in operations in the foreseeable future, the securities could be liquidated within a short period of time if required. Our cash, cash equivalents and marketable securities at March 27, 2016 consisted of $2.9 billion held by United States-based entities and $27.1 billion held by foreign entities. Most of our cash, cash equivalents and marketable securities held by foreign entities are indefinitely reinvested and would be subject to material tax effects if repatriated. However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate funds held by foreign entities.

[0001234452-16-000429:mdna:78]
[same as prior period, unchanged from 0001234452-16-000352:mdna:72]

[0001234452-16-000429:mdna:79]
| • | We expect the majority of the charges incurred in connection with our Strategic Realignment Plan will result in cash payment. Our restructuring accrual was $51 million at March 27, 2016, and we expect to incur additional restructuring and restructuring-related charges of approximately $25 million to $125 million in fiscal 2016 and 2017. |

[0001234452-16-000429:mdna:80]
| • | Our purchase obligations at March 27, 2016, some of which relate to research and development activities and capital expenditures, totaled $3.1 billion and $1.0 billion for fiscal 2016 and 2017, respectively, and $1.8 billion thereafter. |

[0001234452-16-000429:mdna:81]
| • | Our research and development expenditures were $2.7 billion during the first six months of fiscal 2016 and $5.5 billion in fiscal 2015, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications, primarily in the wireless industry. |

[0001234452-16-000429:mdna:82]
| • | Cash outflows for capital expenditures were $253 million during the first six months of fiscal 2016 and $994 million in fiscal 2015. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-16-000429:mdna:83]
| • | In January 2016, we announced that we had reached agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd. The joint venture will initially be owned 51% by us and 49% by TDK. The purchase price due upon close of the transaction is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, we have the option to acquire (and TDK has an option to sell) TDK’s interest in the joint venture for $1.15 billion 30 months after the closing date. We expect to use existing cash resources to fund the acquisition. TDK will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date. The transaction is subject to regulatory approvals and other closing conditions and is expected to close by early calendar 2017. |

[0001234452-16-000429:mdna:84]
[same as prior period, unchanged from 0001234452-16-000352:mdna:78]

[0001234452-16-000429:mdna:85]
Debt. We have a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. At March 27, 2016, no amounts were outstanding under the Revolving Credit Facility.

[0001234452-16-000429:mdna:86]
We have an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At March 27, 2016, we had $1.9 billion of commercial paper outstanding with weighted-average net interest rates of 0.49% and weighted-average remaining days to maturity of 33 days.

[0001234452-16-000429:mdna:87]
We have issued unsecured floating- and fixed-rate notes in an aggregate principal amount of $10.0 billion, with maturity dates in 2018 through 2045 and effective interest rates between 0.75% and 4.74%. Interest is payable in arrears quarterly for

[0001234452-16-000429:mdna:88]
33

[0001234452-16-000429:mdna:89]
the floating-rate notes and semi-annually for the fixed-rate notes. We may issue additional debt in the future. The amount and timing of additional borrowings will be subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001234452-16-000429:mdna:90]
Additional information regarding our outstanding debt at March 27, 2016 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Debt.”

[0001234452-16-000429:mdna:91]
Capital Return Program. During the first six months of fiscal 2016, we repurchased and retired 68,335,000 shares of our common stock for $3.6 billion, before commissions. We intend to return a minimum of 75% of our free cash flow to stockholders through stock repurchases and dividends over the foreseeable future, where free cash flow is defined as net cash provided by operating activities less capital expenditures. On March 9, 2015, we announced that we had been authorized to repurchase up to $15 billion of our common stock. Additionally, we announced our intention to repurchase $10 billion of stock from March 2015 through March 2016, which we completed during the first quarter of fiscal 2016. At March 27, 2016, $3.3 billion remained authorized for repurchase under our stock repurchase program. To meet our goal, we expect to use existing cash and marketable securities held by, and cash flow generated from, United States-based entities and borrowings. We periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders.

[0001234452-16-000429:mdna:92]
During the first six months of fiscal 2016, we paid cash dividends totaling $1.4 billion, or $0.96 per share. On April 8, 2016, we announced a cash dividend of $0.53 per share on our common stock, payable on June 22, 2016 to stockholders of record as of the close of business on June 1, 2016. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-16-000429:mdna:93]
[same as prior period, unchanged from 0001234452-16-000352:mdna:85]

[0001234452-16-000429:mdna:94]
[same as prior period, unchanged from 0001234452-16-000352:mdna:86]

[0001234452-16-000429:mdna:95]
Additional information regarding our financial commitments at March 27, 2016 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes,” “Note 6. Debt” and “Note 7. Commitments and Contingencies.”

[0001234452-16-000429:mdna:96]
[same as prior period, unchanged from 0001234452-16-000352:mdna:88]

[0001234452-16-000429:mdna:97]
Information regarding recent accounting pronouncements and the impact of those pronouncements, if any, on our consolidated financial statements is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 1. Basis of Presentation.”

[0001234452-16-000429:mdna:98]
[same as prior period, unchanged from 0001234452-16-000352:mdna:93]

[0001234452-16-000429:mdna:99]
[same as prior period, unchanged from 0001234452-16-000352:mdna:94]

[0001234452-16-000429:mdna:100]
[same as prior period, unchanged from 0001234452-16-000352:mdna:95]

[0001234452-16-000429:mdna:101]
[same as prior period, unchanged from 0001234452-16-000352:mdna:96]

[0001234452-16-000429:mdna:102]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on our customers, our licensees and operators of wireless networks to use these technologies in their adoption of our products and services into their devices and networks and on the timing of their deployments of new products and services. We also depend on our customers and licensees to develop products and services with value-added features to drive consumer demand for new 3G, 3G/4G multimode and 4G devices, as well as the selling prices for such devices. Further, our rate of revenue growth depends on third parties incorporating our technology, products and/or services into new device types used in industries beyond traditional cellular communications, such as

[0001234452-16-000429:mdna:103]
automotive, connected home and wearable uses. Our revenues and/or growth in revenues could be negatively impacted, our business may be harmed and our substantial investments in these technologies may not provide us an adequate return, if:

[0001234452-16-000429:mdna:104]
[same as prior period, unchanged from 0001234452-16-000352:mdna:98]

[0001234452-16-000429:mdna:105]
[same as prior period, unchanged from 0001234452-16-000352:mdna:99]

[0001234452-16-000429:mdna:106]
[same as prior period, unchanged from 0001234452-16-000352:mdna:100]

[0001234452-16-000429:mdna:107]
[same as prior period, unchanged from 0001234452-16-000352:mdna:101]

[0001234452-16-000429:mdna:108]
[same as prior period, unchanged from 0001234452-16-000352:mdna:102]

[0001234452-16-000429:mdna:109]
[same as prior period, unchanged from 0001234452-16-000352:mdna:103]

[0001234452-16-000429:mdna:110]
[same as prior period, unchanged from 0001234452-16-000352:mdna:104]

[0001234452-16-000429:mdna:111]
[same as prior period, unchanged from 0001234452-16-000352:mdna:105]

[0001234452-16-000429:mdna:112]
[same as prior period, unchanged from 0001234452-16-000352:mdna:106]

[0001234452-16-000429:mdna:113]
[same as prior period, unchanged from 0001234452-16-000352:mdna:107]

[0001234452-16-000429:mdna:114]
[same as prior period, unchanged from 0001234452-16-000352:mdna:108]

[0001234452-16-000429:mdna:115]
[same as prior period, unchanged from 0001234452-16-000352:mdna:109]

[0001234452-16-000429:mdna:116]
[same as prior period, unchanged from 0001234452-16-000352:mdna:110]

[0001234452-16-000429:mdna:117]
[same as prior period, unchanged from 0001234452-16-000352:mdna:126]

[0001234452-16-000429:mdna:118]
[same as prior period, unchanged from 0001234452-16-000352:mdna:111]

[0001234452-16-000429:mdna:119]
[same as prior period, unchanged from 0001234452-16-000352:mdna:112]

[0001234452-16-000429:mdna:120]
[same as prior period, unchanged from 0001234452-16-000352:mdna:113]

[0001234452-16-000429:mdna:121]
[same as prior period, unchanged from 0001234452-16-000352:mdna:114]

[0001234452-16-000429:mdna:122]
[same as prior period, unchanged from 0001234452-16-000352:mdna:115]

[0001234452-16-000429:mdna:123]
[same as prior period, unchanged from 0001234452-16-000352:mdna:116]

[0001234452-16-000429:mdna:124]
[same as prior period, unchanged from 0001234452-16-000352:mdna:117]

[0001234452-16-000429:mdna:125]
[same as prior period, unchanged from 0001234452-16-000352:mdna:119]

[0001234452-16-000429:mdna:126]
[same as prior period, unchanged from 0001234452-16-000352:mdna:120]

[0001234452-16-000429:mdna:127]
[same as prior period, unchanged from 0001234452-16-000352:mdna:121]

[0001234452-16-000429:mdna:128]
Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM) as well as companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Airoha Technology Corp., Broadcom Limited, Ericsson, HiSilicon Technologies, Intel, Leadcore Technology Co., Ltd., Marvell Technology, Maxim Integrated Products, MediaTek, Microchip Technology Inc., Nvidia, Qorvo Inc., Realtek Semiconductor, Samsung Electronics, Skyworks Solutions Inc. and Spreadtrum Communications (which is controlled by Tsinghua Unigroup). Some of these current and potential competitors may have advantages over us that include, among others: lower cost structures; motivation by our customers in certain circumstances to utilize their own internally-developed integrated circuit products or to find alternate suppliers or choose alternative technologies; foreign government support of other technologies or competitors; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and original equipment manufacturers in emerging geographic regions (such as China); and/or a more established presence in certain regions.

[0001234452-16-000429:mdna:129]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe we will continue to see, an increase in customers requesting that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of a product’s source

[0001234452-16-000429:mdna:130]
code and may expose related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of the open source software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers, or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Developing open source products, while adequately protecting the intellectual property rights upon which our licensing business depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ adequate controls to protect our intellectual property rights, our use of open source software presents risks that could have an adverse effect on these rights and on our business.

[0001234452-16-000429:mdna:131]
[same as prior period, unchanged from 0001234452-16-000352:mdna:124]

[0001234452-16-000429:mdna:132]
Our QCT segment derives a significant portion of revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience an increasing concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. In addition, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past chosen, and may in the future choose, to utilize in their devices rather than our integrated circuit products (and/or sell their integrated circuit products to third parties in competition with us). The loss of any one of our significant customers, a reduction in the purchases of our products by such customers (due to the use of their own integrated circuit products or otherwise) or cancellation of significant purchases from any of these customers would reduce our revenues and could harm our ability to achieve or sustain expected operating results, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Further, concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have little or no control, and the timing of such introductions may cause our operating results to fluctuate. Accordingly, if current industry dynamics and concentrations continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases and the timing and size of any such future purchases by these significant customers.

[0001234452-16-000429:mdna:133]
[same as prior period, unchanged from 0001234452-16-000352:mdna:128]

[0001234452-16-000429:mdna:134]
[same as prior period, unchanged from 0001234452-16-000352:mdna:129]

[0001234452-16-000429:mdna:135]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products and/or intellectual property or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001234452-16-000429:mdna:136]
Although we have more than 310 CDMA-based licensees, our QTL segment derives a significant portion of licensing revenues from a limited number of licensees. In the event that one or more of our significant licensees fail to meet their reporting and/or payment requirements or we are unable to renew or modify one or more of such license agreements, our revenues, operating results and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have little or no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our major licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues.

[0001234452-16-000429:mdna:137]
[same as prior period, unchanged from 0001234452-16-000352:mdna:132]

[0001234452-16-000429:mdna:138]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, or some form of unfair competition; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the imposition of some form of compulsory licensing and/or to weaken a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies to attempt to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated. In addition, certain licensees have disputed or underreported royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into license agreements with us for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future. Further, to the extent such licensees and/or companies increase their device share, the negative impact of their underreporting and/or non-reporting on our business and operating results will be exacerbated.

[0001234452-16-000429:mdna:139]
We are currently subject to various litigation and governmental investigations and/or proceedings, some of which may arise out of the strategies described above. Certain legal matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region.

[0001234452-16-000429:mdna:140]
[same as prior period, unchanged from 0001234452-16-000352:mdna:135]

[0001234452-16-000429:mdna:141]
[same as prior period, unchanged from 0001234452-16-000352:mdna:136]

[0001234452-16-000429:mdna:142]
Some SDOs, courts and governmental agencies have adopted and may in the future adopt some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001234452-16-000429:mdna:143]
We expect that such proposals, interpretations and strategies will continue in the future, and if successful, our business model would be harmed, either by limiting or eliminating our ability to collect royalties (or by reducing the royalties we can collect) on all or a portion of our patent portfolio, limiting our return on investment with respect to new technologies, limiting our ability to seek injunctions against infringers of our standard-essential patents, constraining our ability to make licensing commitments when submitting our technology for inclusion in future standards (which could make our technology less likely to be included in such standards) or forcing us to work outside of SDOs or other industry groups to promote our new technologies, and our results of operations could be negatively impacted. In addition, the legal and other costs associated with

[0001234452-16-000429:mdna:144]
asserting or defending our positions have been and continue to be significant. We assume that such challenges, regardless of their merits, will continue into the foreseeable future and may require the investment of substantial management time and financial resources.

[0001234452-16-000429:mdna:145]
[same as prior period, unchanged from 0001234452-16-000352:mdna:139]

[0001234452-16-000429:mdna:146]
[same as prior period, unchanged from 0001234452-16-000352:mdna:140]

[0001234452-16-000429:mdna:147]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property rights and/or contracts, including collecting royalties for use of our patent portfolio in particular foreign jurisdictions due to, among others: policies of foreign governments; challenges to our licensing practices under such jurisdictions’ competition laws; adoption of mandatory licensing provisions by foreign jurisdictions (either with controlled/regulated royalties or royalty free); failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and/or challenges pending before foreign competition agencies to the pricing and integration of additional features and functionality into our chipset products. Certain licensees have disputed or underreported royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into license agreements for their use of our intellectual property, and such licensees and/or companies may continue to do so in the future. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements.

[0001234452-16-000429:mdna:148]
We may need to litigate to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements and/or initiating litigation) and/or we could incur substantial unexpected operating costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our operating results. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues in the period prior to conclusion.

[0001234452-16-000429:mdna:149]
[same as prior period, unchanged from 0001234452-16-000352:mdna:144]

[0001234452-16-000429:mdna:150]
Although we own a very strong portfolio of issued and pending patents related to GSM, GPRS, EDGE, OFDM, OFDMA, WLAN, MIMO and other technologies, our patent portfolio licensing program in these areas is less established and

[0001234452-16-000429:mdna:151]
might not be as successful in generating licensing revenues as our CDMA licensing program has been. Many wireless operators are investigating, have selected or have deployed OFDMA-based LTE as their next-generation 4G technology in existing (or future if not yet deployed) wireless spectrum bands as complementary to their existing CDMA-based networks. While 3G/4G multimode products are generally covered by our existing 3G licensing agreements, products that implement 4G but do not also implement 3G are generally not covered by these agreements. Although we believe that our patented technology is essential and useful to implementation of the LTE industry standards and have granted royalty-bearing licenses to more than 180 companies (including Huawei, Lenovo, LG, Microsoft, Samsung, Sony Mobile and ZTE) that have realized that they need a license to our patents to make and sell products implementing 4G standards but not implementing 3G standards, it may be difficult to agree on material terms and/or conditions of new license agreements that are acceptable to us with companies that are currently unlicensed, particularly in China. Further, the royalty rates for single mode 4G products are generally lower than our royalty rates for 3G and 3G/4G multimode products have been, and therefore, we might not achieve the same licensing revenues on such LTE products as on 3G and 3G/4G multimode products. In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the connected home or the Internet of Things. We also seek to diversify and broaden our technology licensing programs to new industry segments in which we can utilize our technology leadership, such as wireless charging and other technologies. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties that are equivalent to those that we receive for 3G and 3G/4G multimode products used in cellular communications. Although we believe that our patented technology is essential and useful to the commercialization of such services, the royalties we receive may be lower than those we receive from our current licensing program.

[0001234452-16-000429:mdna:152]
[same as prior period, unchanged from 0001234452-16-000352:mdna:146]

[0001234452-16-000429:mdna:153]
The licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date and, in a small number of agreements, royalties are payable on those patents for a specified time period. As a result, there are agreements with some licensees where later patents are not licensed by or to us and/or royalties are not owed to us under such license agreements after the specified time period. Additionally, certain license agreements are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of a specified term, or to receive royalties after the specified time period, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to modify those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in renewing a license agreement prior to its expiration, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001234452-16-000429:mdna:154]
[same as prior period, unchanged from 0001234452-16-000352:mdna:150]

[0001234452-16-000429:mdna:155]
[same as prior period, unchanged from 0001234452-16-000352:mdna:151]

[0001234452-16-000429:mdna:156]
We are currently subject to various governmental investigations and/or proceedings, and certain matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region.

[0001234452-16-000429:mdna:157]
[same as prior period, unchanged from 0001234452-16-000352:mdna:170]

[0001234452-16-000429:mdna:158]
[same as prior period, unchanged from 0001234452-16-000352:mdna:153]

[0001234452-16-000429:mdna:159]
[same as prior period, unchanged from 0001234452-16-000352:mdna:154]

[0001234452-16-000429:mdna:160]
[same as prior period, unchanged from 0001234452-16-000352:mdna:155]

[0001234452-16-000429:mdna:161]
[same as prior period, unchanged from 0001234452-16-000352:mdna:156]

[0001234452-16-000429:mdna:162]
[same as prior period, unchanged from 0001234452-16-000352:mdna:157]

[0001234452-16-000429:mdna:163]
Our industry is subject to rapid technological change, evolving industry standards and frequent new product introductions, and we must make substantial research, development and other investments, such as acquisitions, in new products, services and technologies to compete successfully. Technological innovations generally require significant research and development efforts before they are commercially viable. Our future growth significantly depends on third parties incorporating our technology, products and/or services into new device types used in industries beyond traditional cellular communications, such as automotive, connected home and wearable uses. Accordingly, we intend to continue to make substantial investments in developing new products, services and technologies that we believe can create stand-alone value and/or contribute to the success of our existing businesses. However, it is possible that these initiatives will not be successful and/or will not result in meaningful revenues or generate operating income that meets expectations. As a result, we may develop products that fail to meet our customers’ needs and/or develop products that may become obsolete and be replaced by competitors’ products offering more compelling features, technologies or costs.

[0001234452-16-000429:mdna:164]
[same as prior period, unchanged from 0001234452-16-000352:mdna:160]

[0001234452-16-000429:mdna:165]
[same as prior period, unchanged from 0001234452-16-000352:mdna:161]

[0001234452-16-000429:mdna:166]
[same as prior period, unchanged from 0001234452-16-000352:mdna:162]

[0001234452-16-000429:mdna:167]
[same as prior period, unchanged from 0001234452-16-000352:mdna:163]

[0001234452-16-000429:mdna:168]
[same as prior period, unchanged from 0001234452-16-000352:mdna:164]

[0001234452-16-000429:mdna:169]
[same as prior period, unchanged from 0001234452-16-000352:mdna:165]

[0001234452-16-000429:mdna:170]
[same as prior period, unchanged from 0001234452-16-000352:mdna:166]

[0001234452-16-000429:mdna:171]
[same as prior period, unchanged from 0001234452-16-000352:mdna:167]

[0001234452-16-000429:mdna:172]
[same as prior period, unchanged from 0001234452-16-000352:mdna:168]

[0001234452-16-000429:mdna:173]
While we have established alternate suppliers for certain technologies, we rely on sole- or limited-source suppliers for certain products, subjecting us to significant risks, including: possible shortages of raw materials or manufacturing capacity; poor product performance; and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have established alternate suppliers, these suppliers may require significant levels of support to bring complex technologies to production. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, any future consolidation of foundry suppliers could increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions and/or increase our manufacturing costs. Our arrangements with our suppliers may obligate us to incur costs to manufacture and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies, and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Our inability to meet customer demand due to sole- or limited-sourcing and/or the additional costs that we incur because of these or other supply constraints or because of the need to support alternate suppliers could negatively impact our business, our revenues and our results of operations.

[0001234452-16-000429:mdna:174]
[same as prior period, unchanged from 0001234452-16-000352:mdna:172]

[0001234452-16-000429:mdna:175]
[same as prior period, unchanged from 0001234452-16-000352:mdna:173]

[0001234452-16-000429:mdna:176]
[same as prior period, unchanged from 0001234452-16-000352:mdna:174]

[0001234452-16-000429:mdna:177]
42

[0001234452-16-000429:mdna:178]
[same as prior period, unchanged from 0001234452-16-000352:mdna:175]

[0001234452-16-000429:mdna:179]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe on another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products through a licensed supplier, we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our operating results.

[0001234452-16-000429:mdna:180]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages, royalty payments and/or an injunction on the sale of certain of our integrated circuit products (and/or on the sale of our customers’ devices using such products). A negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001234452-16-000429:mdna:181]
A number of other companies have claimed to own patents applicable to products implementing various CDMA-based standards, TDMA-based standards, such as GSM and OFDMA-based standards. In addition, existing standards continue to evolve, and new standards, including those applicable to new industry segments, continue to be developed. If future standards diminish, or fail to include, a base level of interoperability, our business may be harmed, and our investments in these new segments may not succeed.

[0001234452-16-000429:mdna:182]
[same as prior period, unchanged from 0001234452-16-000352:mdna:180]

[0001234452-16-000429:mdna:183]
[same as prior period, unchanged from 0001234452-16-000352:mdna:181]

[0001234452-16-000429:mdna:184]
[same as prior period, unchanged from 0001234452-16-000352:mdna:201]

[0001234452-16-000429:mdna:185]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner. Such integration involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, business systems, technology and products; retaining customers and suppliers of the businesses; consolidating research and development and/or supply operations; minimizing the diversion of management’s attention from ongoing business matters; and consolidating corporate and administrative infrastructures. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, or we may become subject to litigation. Additionally, we may not be successful in expanding into geographic regions and/or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of the combination.

[0001234452-16-000429:mdna:186]
[same as prior period, unchanged from 0001234452-16-000352:mdna:183]

[0001234452-16-000429:mdna:187]
In the fourth quarter of fiscal 2015, we announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as we work to create sustainable long-term value for stockholders. As part of this Strategic Realignment Plan, among other actions, we are implementing a cost reduction plan, which includes a series of targeted reductions across our businesses, particularly in our semiconductor business, QCT, and a reduction to our annual share-based compensation grants in fiscal 2016. We expect these cost reduction initiatives to be substantially implemented by the end of fiscal 2016. Additional information regarding our Strategic Realignment Plan is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 10. Strategic Realignment Plan.”

[0001234452-16-000429:mdna:188]
[same as prior period, unchanged from 0001234452-16-000352:mdna:185]

[0001234452-16-000429:mdna:189]
[same as prior period, unchanged from 0001234452-16-000352:mdna:186]

[0001234452-16-000429:mdna:190]
[same as prior period, unchanged from 0001234452-16-000352:mdna:187]

[0001234452-16-000429:mdna:191]
In the past, securities class action litigation often has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we may be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources.

[0001234452-16-000429:mdna:192]
[same as prior period, unchanged from 0001234452-16-000352:mdna:189]

[0001234452-16-000429:mdna:193]
[same as prior period, unchanged from 0001234452-16-000352:mdna:190]

[0001234452-16-000429:mdna:194]
| • | requiring us to use cash to pay the principal of and interest on our indebtedness, thereby reducing the amount of cash available for other purposes; |

[0001234452-16-000429:mdna:195]
[same as prior period, unchanged from 0001234452-16-000352:mdna:192]

[0001234452-16-000429:mdna:196]
[same as prior period, unchanged from 0001234452-16-000352:mdna:193]

[0001234452-16-000429:mdna:197]
[same as prior period, unchanged from 0001234452-16-000352:mdna:194]

[0001234452-16-000429:mdna:198]
Our ability to make payments of principal of and interest on our indebtedness depends upon our future performance, which is subject to general economic conditions, industry cycles and financial, business and other factors, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations in the future to service our debt, we may be required to, among other things: repatriate funds to the United States at substantial tax cost; refinance or restructure all or a portion of our indebtedness; reduce or delay planned capital or operating expenditures; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing and/or restructuring are higher than our current rates, interest expense related to such refinancing and/or restructuring would increase. If there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt in the future and/or the terms of such debt could be adversely affected.

[0001234452-16-000429:mdna:199]
[same as prior period, unchanged from 0001234452-16-000352:mdna:196]

[0001234452-16-000429:mdna:200]
Our future success depends largely upon the continued service of our executive officers and other key management and technical personnel and on our ability to continue to identify, attract, retain and motivate them, particularly in an environment of cost reductions, including equity compensation and headcount reductions. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. The market for employees in our industry is extremely competitive. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001234452-16-000429:mdna:201]
Currency fluctuations could negatively affect future product sales or royalty revenues, harm our ability to collect receivables or increase the U.S. dollar cost of our products.

[0001234452-16-000429:mdna:202]
[same as prior period, unchanged from 0001234452-16-000352:mdna:199]

[0001234452-16-000429:mdna:203]
[same as prior period, unchanged from 0001234452-16-000352:mdna:200]

[0001234452-16-000429:mdna:204]
[same as prior period, unchanged from 0001234452-16-000352:mdna:202]

[0001234452-16-000429:mdna:205]
[same as prior period, unchanged from 0001234452-16-000352:mdna:203]

[0001234452-16-000429:mdna:206]
[same as prior period, unchanged from 0001234452-16-000352:mdna:204]

[0001234452-16-000429:mdna:207]
[same as prior period, unchanged from 0001234452-16-000352:mdna:205]

[0001234452-16-000429:mdna:208]
[same as prior period, unchanged from 0001234452-16-000352:mdna:206]

[0001234452-16-000429:mdna:209]
[same as prior period, unchanged from 0001234452-16-000352:mdna:207]

[0001234452-16-000429:mdna:210]
[same as prior period, unchanged from 0001234452-16-000352:mdna:208]

[0001234452-16-000429:mdna:211]
[same as prior period, unchanged from 0001234452-16-000352:mdna:209]

[0001234452-16-000429:mdna:212]
[same as prior period, unchanged from 0001234452-16-000352:mdna:210]

[0001234452-16-000429:mdna:213]
[same as prior period, unchanged from 0001234452-16-000352:mdna:211]

[0001234452-16-000429:mdna:214]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-United States headquarters is located. Significant judgment is required in determining our provision for income taxes. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related litigation could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision and results of operations in the period or periods in which that determination is made could be negatively affected.

[0001234452-16-000429:mdna:215]
[same as prior period, unchanged from 0001234452-16-000352:mdna:214]

[0001234452-16-000429:mdna:216]
[same as prior period, unchanged from 0001234452-16-000352:mdna:215]
