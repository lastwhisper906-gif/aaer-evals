# QCOM note change history — 0001234452-16-000352 → 0001234452-16-000429


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2016-04-20):
[0001234452-16-000429:note_history:1]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims were invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict and denied ParkerVision’s motions for injunctive relief and ongoing royalties as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit heard the appeal on May 8, 2015 and issued a decision on July 31, 2015. The decision affirmed the District Court’s finding of non-infringement and granted in part the Company’s cross-appeal, holding 10 of the 11 asserted claims invalid. A subsequent Petition for Rehearing by ParkerVision was denied on October 2, 2015. On February 29, 2016, ParkerVision filed a petition for certiorari with the United States Supreme Court asking for review of the Federal Circuit’s decision. On March 28, 2016, the United States Supreme Court denied ParkerVision’s petition. No further appeals are available to ParkerVision in this matter.

- changed (2016-04-20):
[0001234452-16-000429:note_history:2]
On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the complaint, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. On September 25, 2015, ParkerVision filed a motion with the court to sever some claims against the Company and all other defendants into a separate lawsuit. In addition, on December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against the Company and other parties with the United States International Trade Commission (ITC) described below.
  (was, 2016-01-27, similarity 0.8163):
[0001234452-16-000352:note_history:2]
On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. On September 25, 2015, ParkerVision filed a motion with the court to sever some claims against the Company and all other defendants into a separate lawsuit. In addition, on December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. The close of discovery is scheduled for April 2016, and the trial is scheduled for November 2016. A claim construction ruling and a ruling on ParkerVision’s severance motion are still pending.

- changed (2016-04-20):
[0001234452-16-000429:note_history:3]
On December 14, 2015, ParkerVision filed a third complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. are also named defendants. The complaint asserts four additional patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. The ITC scheduled a hearing to begin on August 24, 2016. The ITC’s target date for completion of the investigation is April 21, 2017. The District Court case was stayed on February 12, 2016 pending completion of the ITC investigation.
  (was, 2016-01-27, similarity 0.8833):
[0001234452-16-000352:note_history:3]
On December 14, 2015, ParkerVision filed a third complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. are also named defendants. The complaint asserts four additional patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. The ITC has not yet determined a target date for concluding its investigation.

- changed (2016-04-20):
[0001234452-16-000429:note_history:4]
Nvidia Corporation v. QUALCOMM Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd. and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chipset products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District Court complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. Nvidia later narrowed the ITC case to three asserted patents. On October 9, 2015, the Administrative Law Judge in the ITC case issued an Initial Determination finding no violation of Section 337 because none of the three patents were both valid and infringed. On October 26, 2015, Nvidia filed a petition requesting the ITC to review the Initial Determination as to two of the asserted patents, but is no longer pursuing infringement allegations with respect to the third patent. On December 14, 2015, the ITC issued its decision not to review the Initial Determination of the Administrative Law Judge. This made final the determination that the Company did not violate Section 337. Therefore, neither an exclusion order nor a cease and desist order were issued. On February 17, 2016, Nvidia filed a notice of appeal of the ITC’s determination to the United States Court of Appeals for the Federal Circuit. The District Court case was stayed on October 23, 2014 pending completion of the ITC investigation, including appeals.
  (was, 2016-01-27, similarity 0.9106):
[0001234452-16-000352:note_history:4]
Nvidia Corporation v. QUALCOMM Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd. and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chipset products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District Court complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. Nvidia later narrowed the case to three asserted patents. On October 9, 2015, the Administrative Law Judge issued an Initial Determination finding no violation of Section 337 because none of the three patents were both valid and infringed. On October 22, 2015, the Administrative Law Judge issued a recommendation that, if the ITC were to find any violation of Section 337 in the investigation, the ITC should issue a limited exclusion order directed at Samsung’s accused products and a cease and desist order against Samsung but not the Company. On October 26, 2015, Nvidia filed a petition requesting the ITC to review the Initial Determination as to two of the asserted patents, but is no longer pursuing infringement allegations with respect to the third patent. On December 14, 2015, the ITC issued its decision not to review the Initial Determination of the Administrative Law Judge. This made final the determination that the Company did not violate Section 337. Therefore, neither an exclusion order nor a cease and desist order were issued. Nvidia has until February 12, 2016 to file a notice of appeal of the ITC’s determination. The District Court case was stayed on October 23, 2014 pending completion of the ITC investigation, including appeals.

- added (2016-04-20):
[0001234452-16-000429:note_history:5]
LG Electronics, Inc. (LGE) Arbitration: In December 2015, LGE filed an arbitration demand with the International Chamber of Commerce (ICC) alleging that it overpaid royalties on certain CDMA (including WCDMA) subscriber units based on the alleged effect of specific provisions in its license agreement, and that the Company breached its license agreement with LGE, as well as certain implied covenants. The arbitration demand sought determination and return of the overpayment and determination of the ongoing royalties owed by LGE. On April 16, 2016, the parties entered into agreements pursuant to which the parties agreed to settle the disputes raised by LGE in its arbitration demand, and LGE agreed to dismiss the arbitration with prejudice and release all claims brought in the arbitration against the Company. Although the Company believed LGE’s claims were without merit, it deferred the recognition of revenue related to CDMA subscriber unit royalties reported and paid by LGE in the first and second quarters of fiscal 2016 because, among other reasons, the matter was submitted to arbitration for resolution. As a result of the settlement, commencing with the third quarter of fiscal 2016, the Company will no longer defer royalty revenues reported by LGE and will record greater than $200 million of revenues that were previously deferred.

- added (2016-04-20):
[0001234452-16-000429:note_history:6]
Blackberry Limited (Blackberry) Arbitration: On April 20, 2016, the Company and Blackberry entered into an agreement to arbitrate Blackberry’s allegation that it overpaid royalties on certain past sales of subscriber units based on the alleged effect of specific provisions in its license agreement. The arbitration will be conducted under the rules of the Judicial Arbitration and Mediation Services in San Diego, California. Blackberry seeks the return of the alleged overpayment. The Company believes Blackberry’s claims are without merit.

- changed (2016-04-20):
[0001234452-16-000429:note_history:7]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 32 different dates, with the next hearing scheduled for July 20, 2016.
  (was, 2016-01-27, similarity 0.9971):
[0001234452-16-000352:note_history:7]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 31 different dates, with the next hearing scheduled for February 25, 2016.

- changed (2016-04-20):
[0001234452-16-000429:note_history:8]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company provided additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.
  (was, 2016-01-27, similarity 0.9911):
[0001234452-16-000352:note_history:8]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

- changed (2016-04-20):
[0001234452-16-000429:note_history:9]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). As discussed below, FCPA compliance was also the focus of the SEC investigation. The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.
  (was, 2016-01-27, similarity 0.9979):
[0001234452-16-000352:note_history:9]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). As discussed below, FCPA compliance is also the focus of the SEC investigation. The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee has completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.

- added (2016-04-20):
[0001234452-16-000429:note_history:10]
On November 19, 2015, the DOJ notified the Company that it was terminating its investigation and would not pursue charges in this matter. On March 1, 2016, the Company entered into an administrative settlement with the SEC pursuant to which the Company paid a $7.5 million penalty and entered into a two-year period of self-monitoring and self-reporting with respect to FCPA compliance. The Company neither admits nor denies the findings in the SEC’s order and does not expect any further enforcement action against the Company or its current or former employees relating to this investigation.

- changed (2016-04-20):
[0001234452-16-000429:note_history:11]
The Company will continue to vigorously defend itself in the foregoing matters that remain outstanding. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at March 27, 2016 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.
  (was, 2016-01-27, similarity 0.9675):
[0001234452-16-000352:note_history:11]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. Other than a nominal amount, the Company has not recorded any accrual at December 27, 2015 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

- changed (2016-04-20):
[0001234452-16-000429:note_history:12]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through March 27, 2016, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.
  (was, 2016-01-27, similarity 0.9934):
[0001234452-16-000352:note_history:12]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through December 27, 2015, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

- changed (2016-04-20):
[0001234452-16-000429:note_history:13]
Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at March 27, 2016 associated with these indemnification arrangements, other than nominal amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.
  (was, 2016-01-27, similarity 0.9859):
[0001234452-16-000352:note_history:13]
Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at December 27, 2015 associated with these indemnification arrangements, other than nominal amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- added (2016-04-20):
[0001234452-16-000429:note_history:14]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at March 27, 2016 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $3.1 billion, $1.0 billion, $778 million, $736 million and $221 million, respectively, and $34 million thereafter. Of these amounts, for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020, commitments to purchase integrated circuit product inventories comprised $2.6 billion, $822 million, $704 million, $687 million and $175 million, respectively, and there were no purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancellation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancellation, and in some cases, incremental fees related to capacity underutilization.

- changed (2016-04-20):
[0001234452-16-000429:note_history:15]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments at March 27, 2016 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $51 million, $43 million, $26 million, $20 million and $19 million, respectively, and $24 million thereafter.
  (was, 2016-01-27, similarity 0.8699):
[0001234452-16-000352:note_history:15]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancellable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments at December 27, 2015 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $75 million, $78 million, $45 million, $30 million and $20 million, respectively, and $27 million thereafter.

- changed (2016-04-20):
[0001234452-16-000429:note_history:16]
Other Commitments. At March 27, 2016, the Company was committed to fund certain strategic investments up to $310 million. Of this amount, $86 million is expected to be funded in the remainder of fiscal 2016. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.
  (was, 2016-01-27, similarity 0.9831):
[0001234452-16-000352:note_history:16]
Other Commitments. At December 27, 2015, the Company was committed to fund certain strategic investments up to $431 million. Of this amount, $197 million is expected to be funded in the remainder of fiscal 2016. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.

- removed (2016-04-20):
[0001234452-16-000352:note_history:17]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict and denied ParkerVision’s motions for injunctive relief and ongoing royalties as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit heard the appeal on May 8, 2015 and issued a decision on July 31, 2015. The decision affirmed the District Court’s finding of non-infringement and granted in part the Company’s cross-appeal, holding 10 of the 11 asserted claims invalid. A subsequent Petition for Rehearing by ParkerVision was denied on October 2, 2015. On December 16, 2015, ParkerVision was granted an extension of the deadline to file a petition requesting that the United States Supreme Court hear ParkerVision’s appeal of the Federal Circuit decision. The petition is now due on January 29, 2016.

- removed (2016-04-20):
[0001234452-16-000352:note_history:18]
LG Electronics, Inc. (LGE) Arbitration: In December 2015, LGE filed an arbitration demand with the International Chamber of Commerce alleging that it overpaid royalties on certain CDMA (including WCDMA) subscriber units based on the alleged effect of specific provisions in its license agreement, and that the Company breached its license agreement with LGE, as well as certain implied covenants. The arbitration demand seeks determination and return of the overpayment and determination of the ongoing royalties owed by LGE. The Company intends to respond to the arbitration demand, denying the allegations and requesting judgment in its favor on all claims. Although the Company believes LGE’s claims are without merit, it has deferred the recognition of revenue related to CDMA subscriber unit royalties reported and paid by LGE in the first quarter of fiscal 2016 because, among other reasons, the matter has been submitted to arbitration for resolution.

- removed (2016-04-20):
[0001234452-16-000352:note_history:19]
On March 13, 2014, the Company received a Wells Notice from the SEC’s Los Angeles Regional Office indicating that the staff has made a preliminary determination to recommend that the SEC file an enforcement action against the Company for violations of the anti-bribery, books and records and internal control provisions of the FCPA. The bribery allegations relate to benefits offered or provided to individuals associated with Chinese state-owned companies or agencies. The Wells Notice indicated that the recommendation could involve a civil injunctive action and could seek remedies that include disgorgement of profits, the retention of an independent compliance monitor to review the Company’s FCPA policies and procedures, an injunction, civil monetary penalties and prejudgment interest.

- removed (2016-04-20):
[0001234452-16-000352:note_history:20]
A Wells Notice is not a formal allegation or finding by the SEC of wrongdoing or violation of law. Rather, the purpose of a Wells Notice is to give the recipient an opportunity to make a “Wells submission” setting forth reasons why the proposed enforcement action should not be filed and/or bringing additional facts to the SEC’s attention before any decision is made by the SEC as to whether to commence a proceeding. On April 4, 2014 and May 29, 2014, the Company made Wells submissions to the staff of the Los Angeles Regional Office explaining why the Company believes it has not violated the FCPA and therefore enforcement action is not warranted.

- removed (2016-04-20):
[0001234452-16-000352:note_history:21]
On November 19, 2015, the DOJ notified the Company that it was terminating its investigation and would not pursue charges in this matter. The DOJ’s decision is independent of the SEC’s investigation, with which we continue to cooperate.

- removed (2016-04-20):
[0001234452-16-000352:note_history:22]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at December 27, 2015 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $3.2 billion, $891 million, $739 million, $718 million and $196 million, respectively, and $14 million thereafter. Of these amounts, for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020, commitments to purchase integrated circuit product inventories comprised $2.6 billion, $742 million, $698 million, $699 million and $177 million, respectively, and there were no purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancellation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancellation, and in some cases, incremental fees related to capacity underutilization.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-04-20):
[0001234452-16-000429:note_history:23]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 27, 2015. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and six-month periods ended March 27, 2016 and March 29, 2015 included 13 weeks and 26 weeks, respectively.
  (was, 2016-01-27, similarity 0.9599):
[0001234452-16-000352:note_history:23]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 27, 2015. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month periods ended December 27, 2015 and December 28, 2014 included 13 weeks.

- changed (2016-04-20):
[0001234452-16-000429:note_history:24]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the sum of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 27, 2016 were 10,734,000 and 12,582,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 29, 2015 were 21,588,000 and 23,295,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 6,899,000 and 4,036,000 during the three and six months ended March 27, 2016, respectively, and 18,000 and 744,000 during the three and six months ended March 29, 2015, respectively.
  (was, 2016-01-27, similarity 0.7499):
[0001234452-16-000352:note_history:24]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three months ended December 27, 2015 and December 28, 2014 were 14,430,000 and 25,003,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 1,172,000 and 1,470,000 during the three months ended December 27, 2015 and December 28, 2014, respectively.

- changed (2016-04-20):
[0001234452-16-000429:note_history:25]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | March 27, 2016 |  | March 29, 2015 |
| Cost of equipment and services revenues | $ | 10 |  |  | $ | 11 |  |  | $ | 20 |  |  | $ | 23 |  |
| Research and development | 161 |  |  | 158 |  |  | 326 |  |  | 333 |  |
| Selling, general and administrative | 76 |  |  | 80 |  |  | 148 |  |  | 166 |  |
| Share-based compensation expense before income taxes | 247 |  |  | 249 |  |  | 494 |  |  | 522 |  |
| Related income tax benefit | (27 | ) |  | (43 | ) |  | (87 | ) |  | (86 | ) |
|  | $ | 220 |  |  | $ | 206 |  |  | $ | 407 |  |  | $ | 436 |  |
  (was, 2016-01-27, similarity 0.7619):
[0001234452-16-000352:note_history:25]
|  | Three Months Ended |
|  | December 27, 2015 |  | December 28, 2014 |
| Cost of equipment and services revenues | $ | 10 |  |  | $ | 12 |  |
| Research and development | 165 |  |  | 174 |  |
| Selling, general and administrative | 72 |  |  | 87 |  |
| Share-based compensation expense before income taxes | 247 |  |  | 273 |  |
| Related income tax benefit | (60 | ) |  | (44 | ) |
|  | $ | 187 |  |  | $ | 229 |  |

- added (2016-04-20):
[0001234452-16-000429:note_history:26]
The Company recorded $96 million and $81 million in share-based compensation expense during the six months ended March 27, 2016 and March 29, 2015, respectively, related to share-based awards granted during those periods. At March 27, 2016, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.4 billion, which is expected to be recognized over a weighted-average period of 2.0 years. During the six months ended March 27, 2016 and March 29, 2015, net share-based awards granted, after forfeitures and cancellations, represented 0.7% and 0.4%, respectively, of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.9% and 0.5%, respectively, of outstanding shares as of the end of each fiscal period.

- added (2016-04-20):
[0001234452-16-000429:note_history:27]
Recent Accounting Pronouncements. In November 2015, the Financial Accounting Standards Board (FASB) issued new guidance related to accounting for income taxes, which requires all deferred tax assets and liabilities to be classified as noncurrent on the balance sheet. The Company early adopted the new guidance prospectively in the second quarter of fiscal 2016. Prior period amounts have not been adjusted.

- changed (2016-04-20):
[0001234452-16-000429:note_history:28]
In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Adoption one year early is permitted. Two methods of adoption are permitted: (a) full retrospective adoption, meaning the standard is applied to all periods presented or (b) modified retrospective adoption, meaning the cumulative effect of applying the new guidance is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the new guidance early and is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.
  (was, 2016-01-27, similarity 0.7239):
[0001234452-16-000352:note_history:28]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The new standard will be effective for the Company starting in the first quarter of fiscal 2019. The FASB will permit entities to adopt one year earlier if they choose (i.e., the original effective date). The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the standard early and is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.

- changed (2016-04-20):
[0001234452-16-000429:note_history:29]
In January 2016, the FASB issued new guidance on classifying and measuring financial instruments, which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk be recognized separately in other comprehensive income. Additionally, it changes the disclosure requirements for financial instruments. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Early adoption is permitted for certain provisions. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt certain provisions early.
  (was, 2016-01-27, similarity 0.8835):
[0001234452-16-000352:note_history:29]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments-Overall: Recognition and Measurement of Financial Assets and Financial Liabilities,” which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk will be recognized separately in other comprehensive income. Additionally, the ASU changes the disclosure requirements for financial instruments. The new standard will be effective for the Company starting in the first quarter of fiscal 2019. Early adoption is permitted for certain provisions. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt certain provisions early.

- added (2016-04-20):
[0001234452-16-000429:note_history:30]
In February 2016, the FASB issued new guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease guidance. The new guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. The new guidance must be adopted using the modified retrospective approach and will be effective for the Company starting in the first quarter of fiscal 2020. Early adoption is permitted. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.

- added (2016-04-20):
[0001234452-16-000429:note_history:31]
In March 2016, the FASB issued new guidance that changes the accounting for share-based payments. Under the new guidance, excess tax benefits associated with share-based payment awards will be recognized in the income statement when the awards vest or settle, rather than in stockholders’ equity. In addition, it will increase the number of shares an employer can withhold to cover income taxes on share-based payment awards and still qualify for the exemption to liability classification. The new guidance will be effective for the Company starting in the first quarter of fiscal 2018. Early adoption is permitted in any annual or interim period. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.

- removed (2016-04-20):
[0001234452-16-000352:note_history:32]
The Company recorded $31 million in share-based compensation expense during each of the three months ended December 27, 2015 and December 28, 2014 related to share-based awards granted during those periods. At December 27, 2015, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.6 billion, which is expected to be recognized over a weighted-average period of 2.2 years. During the three months ended December 27, 2015 and December 28, 2014, net share-based awards granted, after forfeitures and cancellations, represented 0.7% and 0.4%, respectively, of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.9% and 0.4%, respectively, of outstanding shares as of the end of each fiscal period.

- removed (2016-04-20):
[0001234452-16-000352:note_history:33]
In November 2015, the FASB issued ASU No. 2015-17, “Balance Sheet Classification of Deferred Taxes,” which requires all deferred tax assets and liabilities to be classified as noncurrent on the balance sheet. The new accounting guidance is effective for annual reporting periods beginning after December 15, 2016 and interim periods therein. Early adoption is permitted as of the beginning of interim or annual reporting periods. The Company plans to adopt the standard prospectively in the second quarter of fiscal 2016.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-04-20):
[0001234452-16-000429:note_history:34]
Revolving Credit Facility. The Company has a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At March 27, 2016 and September 27, 2015, the Company was in compliance with the covenants, and the Company had not borrowed any funds under the Revolving Credit Facility.
  (was, 2016-01-27, similarity 0.9914):
[0001234452-16-000352:note_history:34]
Revolving Credit Facility. The Company has a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At December 27, 2015 and September 27, 2015, the Company was in compliance with the covenants, and the Company had not borrowed any funds under the Revolving Credit Facility.

- changed (2016-04-20):
[0001234452-16-000429:note_history:35]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At March 27, 2016 and September 27, 2015, the Company had $1.9 billion and $1.0 billion, respectively, of outstanding commercial paper recorded as short-term debt with weighted-average interest rates of 0.49% and 0.19%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 33 days and 38 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at March 27, 2016 and September 27, 2015.
  (was, 2016-01-27, similarity 0.929):
[0001234452-16-000352:note_history:35]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At December 27, 2015 and September 27, 2015, the Company had $1.0 billion of outstanding commercial paper recorded as short-term debt with weighted-average interest rates of 0.25% and 0.19%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 30 days and 38 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at December 27, 2015 and September 27, 2015.

- changed (2016-04-20):
[0001234452-16-000429:note_history:36]
|  | March 27, 2016 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.95% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.23% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.75% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.67% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.06% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (60 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 53 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 9,993 |  |  |  |  | $ | 9,969 |  |  |  |
  (was, 2016-01-27, similarity 0.9925):
[0001234452-16-000352:note_history:36]
|  | December 27, 2015 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.70% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 0.98% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.71% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.71% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.14% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (62 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 12 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 9,950 |  |  |  |  | $ | 9,969 |  |  |  |

- changed (2016-04-20):
[0001234452-16-000429:note_history:37]
The interest rate on the floating rate notes due in 2018 and 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At March 27, 2016 and September 27, 2015, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $10.1 billion and $9.6 billion, respectively.
  (was, 2016-01-27, similarity 0.9791):
[0001234452-16-000352:note_history:37]
The interest rate on the floating rate notes due in 2018 and 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At December 27, 2015 and September 27, 2015, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $9.6 billion.

- changed (2016-04-20):
[0001234452-16-000429:note_history:38]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $137 million during the six months ended March 27, 2016. Cash interest paid related to the Company’s commercial paper program was negligible in the six months ended March 29, 2015. No long-term debt was outstanding in the six months ended March 29, 2015.
  (was, 2016-01-27, similarity 0.7132):
[0001234452-16-000352:note_history:38]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $128 million during the three months ended December 27, 2015. No commercial paper or long-term debt was outstanding in the three months ended December 28, 2014.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-04-20):
[0001234452-16-000429:note_history:39]
|  | Current |  | Noncurrent |
|  | March 27, 2016 |  | September 27, 2015 |  | March 27, 2016 |  | September 27, 2015 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | — |  |  | $ | — |  |  | $ | 23 |  |  | $ | 12 |  |
| Corporate bonds and notes | — |  |  | — |  |  | — |  |  | 364 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | — |  |  | — |  |  | 242 |  |
| Total trading | — |  |  | — |  |  | 23 |  |  | 618 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 238 |  |  | 156 |  |  | 861 |  |  | 691 |  |
| Corporate bonds and notes | 8,770 |  |  | 7,926 |  |  | 7,926 |  |  | 7,112 |  |
| Mortgage- and asset-backed and auction rate securities | 1,505 |  |  | 1,302 |  |  | 461 |  |  | 263 |  |
| Equity and preferred securities and equity funds | 114 |  |  | 377 |  |  | 1,377 |  |  | 1,253 |  |
| Debt funds | — |  |  | — |  |  | 2,934 |  |  | 2,909 |  |
| Total available-for-sale | 10,627 |  |  | 9,761 |  |  | 13,559 |  |  | 12,228 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | — |  |  | 780 |  |
| Total marketable securities | $ | 10,627 |  |  | $ | 9,761 |  |  | $ | 13,582 |  |  | $ | 13,626 |  |
  (was, 2016-01-27, similarity 0.9867):
[0001234452-16-000352:note_history:39]
|  | Current |  | Noncurrent |
|  | December 27, 2015 |  | September 27, 2015 |  | December 27, 2015 |  | September 27, 2015 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | — |  |  | $ | — |  |  | $ | 61 |  |  | $ | 12 |  |
| Corporate bonds and notes | — |  |  | — |  |  | 300 |  |  | 364 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | — |  |  | 279 |  |  | 242 |  |
| Total trading | — |  |  | — |  |  | 640 |  |  | 618 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 160 |  |  | 156 |  |  | 782 |  |  | 691 |  |
| Corporate bonds and notes | 7,942 |  |  | 7,926 |  |  | 7,568 |  |  | 7,112 |  |
| Mortgage- and asset-backed and auction rate securities | 1,339 |  |  | 1,302 |  |  | 299 |  |  | 263 |  |
| Equity and preferred securities and equity funds | 174 |  |  | 377 |  |  | 1,321 |  |  | 1,253 |  |
| Debt funds | — |  |  | — |  |  | 2,870 |  |  | 2,909 |  |
| Total available-for-sale | 9,615 |  |  | 9,761 |  |  | 12,840 |  |  | 12,228 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 583 |  |  | 780 |  |
| Total marketable securities | $ | 9,615 |  |  | $ | 9,761 |  |  | $ | 14,063 |  |  | $ | 13,626 |  |

- added (2016-04-20):
[0001234452-16-000429:note_history:40]
In the second quarter of fiscal 2016, the Company exited an investment in a debt fund for which the Company elected the fair value option. The investment would have otherwise been recorded using the equity method. Changes in fair value associated with this investment were recognized in net investment income. During the three and six months ended March 27, 2016 and March 29, 2015, the changes in fair value associated with this investment were negligible.

- changed (2016-04-20):
[0001234452-16-000429:note_history:41]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains or net losses recognized on debt securities classified as trading held at March 27, 2016 and March 29, 2015 were negligible during the three and six months ended March 27, 2016 and March 29, 2015, respectively.
  (was, 2016-01-27, similarity 0.774):
[0001234452-16-000352:note_history:41]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net losses recognized on debt securities classified as trading held at December 27, 2015 and December 28, 2014 were negligible and $12 million during the three months ended December 27, 2015 and December 28, 2014, respectively.

- changed (2016-04-20):
[0001234452-16-000429:note_history:42]
At March 27, 2016, the contractual maturities of available-for-sale debt securities were as follows (in millions):
  (was, 2016-01-27, similarity 0.9589):
[0001234452-16-000352:note_history:42]
At December 27, 2015, the contractual maturities of available-for-sale debt securities were as follows (in millions):

- added (2016-04-20):
[0001234452-16-000429:note_history:43]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| March 27, 2016 | $ | 34 |  |  | $ | (11 | ) |  | $ | 23 |  |
| March 29, 2015 | 128 |  |  | (30 | ) |  | 98 |  |
| For the six months ended |  |  |  |  |  |
| March 27, 2016 | $ | 84 |  |  | $ | (22 | ) |  | $ | 62 |  |
| March 29, 2015 | 308 |  |  | (37 | ) |  | 271 |  |

- added (2016-04-20):
[0001234452-16-000429:note_history:44]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| March 27, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,283 |  |  | $ | 242 |  |  | $ | (34 | ) |  | $ | 1,491 |  |
| Debt securities (including debt funds) | 22,824 |  |  | 196 |  |  | (325 | ) |  | 22,695 |  |
|  | $ | 24,107 |  |  | $ | 438 |  |  | $ | (359 | ) |  | $ | 24,186 |  |
| September 27, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,394 |  |  | $ | 264 |  |  | $ | (28 | ) |  | $ | 1,630 |  |
| Debt securities (including debt funds) | 20,459 |  |  | 185 |  |  | (285 | ) |  | 20,359 |  |
|  | $ | 21,853 |  |  | $ | 449 |  |  | $ | (313 | ) |  | $ | 21,989 |  |

- changed (2016-04-20):
[0001234452-16-000429:note_history:45]
|  | March 27, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 468 |  |  | $ | (3 | ) |  | $ | 39 |  |  | $ | (1 | ) |
| Corporate bonds and notes | 7,498 |  |  | (117 | ) |  | 1,065 |  |  | (93 | ) |
| Mortgage- and asset-backed and auction rate securities | 1,122 |  |  | (9 | ) |  | 171 |  |  | (2 | ) |
| Equity and preferred securities and equity funds | 358 |  |  | (34 | ) |  | 4 |  |  | — |  |
| Debt funds | 1,953 |  |  | (95 | ) |  | 79 |  |  | (5 | ) |
|  | $ | 11,399 |  |  | $ | (258 | ) |  | $ | 1,358 |  |  | $ | (101 | ) |
  (was, 2016-01-27, similarity 0.991):
[0001234452-16-000352:note_history:45]
|  | December 27, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 808 |  |  | $ | (12 | ) |  | $ | 20 |  |  | $ | (2 | ) |
| Corporate bonds and notes | 10,466 |  |  | (132 | ) |  | 956 |  |  | (108 | ) |
| Mortgage- and asset-backed and auction rate securities | 1,220 |  |  | (7 | ) |  | 164 |  |  | (1 | ) |
| Equity and preferred securities and equity funds | 360 |  |  | (22 | ) |  | 2 |  |  | — |  |
| Debt funds | 1,923 |  |  | (138 | ) |  | 79 |  |  | (6 | ) |
|  | $ | 14,777 |  |  | $ | (311 | ) |  | $ | 1,221 |  |  | $ | (117 | ) |

- changed (2016-04-20):
[0001234452-16-000429:note_history:46]
At March 27, 2016, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company did not have the intent to sell, nor was it more likely than not that the Company will be required to sell, such securities before recovery or maturity.
  (was, 2016-01-27, similarity 0.9064):
[0001234452-16-000352:note_history:46]
At December 27, 2015, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

- changed (2016-04-20):
[0001234452-16-000429:note_history:47]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was $52 million and negligible at March 27, 2016 and March 29, 2015, respectively.
  (was, 2016-01-27, similarity 0.9536):
[0001234452-16-000352:note_history:47]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was $22 million and negligible at December 27, 2015 and December 28, 2014, respectively.

- removed (2016-04-20):
[0001234452-16-000352:note_history:48]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At December 27, 2015, the Company had an effective ownership interest in the debt fund of 22%. Changes in fair value associated with this investment are recognized in net investment income. During the three months ended December 27, 2015 and December 28, 2014, the changes in fair value associated with this investment were negligible.

- removed (2016-04-20):
[0001234452-16-000352:note_history:49]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| December 27, 2015 | $ | 50 |  |  | $ | (12 | ) |  | $ | 38 |  |
| December 28, 2014 | 180 |  |  | (8 | ) |  | 172 |  |

- removed (2016-04-20):
[0001234452-16-000352:note_history:50]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| December 27, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,266 |  |  | $ | 251 |  |  | $ | (22 | ) |  | $ | 1,495 |  |
| Debt securities (including debt funds) | 21,234 |  |  | 132 |  |  | (406 | ) |  | 20,960 |  |
|  | $ | 22,500 |  |  | $ | 383 |  |  | $ | (428 | ) |  | $ | 22,455 |  |
| September 27, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,394 |  |  | $ | 264 |  |  | $ | (28 | ) |  | $ | 1,630 |  |
| Debt securities (including debt funds) | 20,459 |  |  | 185 |  |  | (285 | ) |  | 20,359 |  |
|  | $ | 21,853 |  |  | $ | 449 |  |  | $ | (313 | ) |  | $ | 21,989 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-04-20):
[0001234452-16-000429:note_history:51]
|  | March 27, 2016 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.95% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.23% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.75% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.67% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.06% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (60 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 53 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 9,993 |  |  |  |  | $ | 9,969 |  |  |  |
  (was, 2016-01-27, similarity 0.9925):
[0001234452-16-000352:note_history:51]
|  | December 27, 2015 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.70% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 0.98% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.71% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.71% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.14% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (62 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 12 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 9,950 |  |  |  |  | $ | 9,969 |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2016-04-20):
[0001234452-16-000352:note_history:52]
Note 12. Subsequent Event

- removed (2016-04-20):
[0001234452-16-000352:note_history:53]
In January 2016, the Company announced that it had reached agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd., to enable delivery of radio frequency front-end (RFFE) modules and RF filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others. The joint venture will initially be owned 51% by the Company and 49% by TDK. Certain intellectual property, patents and filter and module design and manufacturing assets will be carved out of existing TDK businesses and be acquired by the joint venture, with certain assets acquired by the Company. The purchase price of the Company’s interest in the joint venture and the assets to be transferred to the Company is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, the Company has the option to acquire (and TDK has an option to sell) TDK’s interest in the joint venture for $1.15 billion 30 months after the closing date. TDK will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date, which is a substitute for and in lieu of any right of TDK to receive any profit sharing, distributions, dividends or other payments of any kind or nature. The transaction is subject to receipt of regulatory approvals and other closing conditions and is expected to close by early 2017.
