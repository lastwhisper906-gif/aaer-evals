# QCOM 8-K — 0001234452-16-000427 filed 2016-04-20

## item codes, every 8-K on or before 2016-04-20

- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2016-04-20

- none on or before 2016-04-20

## item 2.02 — earnings release, exhibit 99.1

[0001234452-16-000427:8k_2_02:1]
EX-99.1
2
qcom32716erex991.htm
EXHIBIT 99.1

[0001234452-16-000427:8k_2_02:2]
Exhibit

[0001234452-16-000427:8k_2_02:3]
Exhibit 99.1

[0001234452-16-000427:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-16-000427:8k_2_02:5]
Qualcomm Contact:

[0001234452-16-000427:8k_2_02:6]
Warren Kneeshaw

[0001234452-16-000427:8k_2_02:7]
Vice President, Investor Relations

[0001234452-16-000427:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-16-000427:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-16-000427:8k_2_02:10]
Qualcomm Announces Second Quarter Fiscal 2016 Results

[0001234452-16-000427:8k_2_02:11]
Revenues $5.6 billion

[0001234452-16-000427:8k_2_02:12]
GAAP EPS $0.78, Non-GAAP EPS $1.04

[0001234452-16-000427:8k_2_02:13]
-Non-GAAP EPS Above Prior Guidance Range-

[0001234452-16-000427:8k_2_02:14]
SAN DIEGO - April 20, 2016 - Qualcomm Incorporated (NASDAQ: QCOM), a leading developer and innovator of advanced wireless technologies, products and services, today announced results for its fiscal second quarter ended March 27, 2016.

[0001234452-16-000427:8k_2_02:15]
“Our fiscal second quarter results were driven by stronger than expected performance across our chipset and licensing businesses,” said Steve Mollenkopf, CEO of Qualcomm Incorporated. “We are pleased with our continued progress in the licensing business, including the recent conclusion of new license agreements in China and the resolution of our dispute with LG Electronics.  We are continuing to build momentum into the second half of our fiscal 2016 with traction for our Snapdragon processors in the premium and high tiers and strong execution of our strategic realignment plan.”

[0001234452-16-000427:8k_2_02:16]
Second Quarter Results (GAAP)*

[0001234452-16-000427:8k_2_02:17]
|  | Q2 Fiscal 2016 |  | Q2 Fiscal 2015 |  | Year-Over-Year Change |  | Q1 Fiscal 2016 |  | Sequential Change |
| Revenues 1 | $5.6B |  | $6.9B |  | (19%) |  | $5.8B |  | (4%) |
| Operating income 1 | $1.4B |  | $1.3B |  | +6% |  | $1.7B |  | (16%) |
| Net income 2 | $1.2B |  | $1.1B |  | +11% |  | $1.5B |  | (22%) |
| Diluted earnings per share 2 | $0.78 |  | $0.63 |  | +24% |  | $0.99 |  | (21%) |
| Operating cash flow | $0.7B |  | ($0.7B) |  | N/M |  | $2.7B |  | (73%) |

[0001234452-16-000427:8k_2_02:18]
1 Throughout this news release, revenues, operating expenses, operating income, earnings before tax (EBT) and effective tax rates are from continuing operations (i.e., before adjustments for noncontrolling interests), unless otherwise stated.

[0001234452-16-000427:8k_2_02:19]
2 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests), unless otherwise stated.

[0001234452-16-000427:8k_2_02:20]
Non-GAAP Second Quarter Results*

[0001234452-16-000427:8k_2_02:21]
|  | Q2 Fiscal 2016 |  | Q2 Fiscal 2015 |  | Year-Over-Year Change |  | Q1 Fiscal 2016 |  | Sequential Change |
| Revenues | $5.5B |  | $6.9B |  | (20%) |  | $5.8B |  | (4%) |
| Operating income | $1.9B |  | $2.7B |  | (30%) |  | $1.7B |  | +8% |
| Net income | $1.6B |  | $2.3B |  | (34%) |  | $1.5B |  | +6% |
| Diluted earnings per share | $1.04 |  | $1.40 |  | (26%) |  | $0.97 |  | +7% |

[0001234452-16-000427:8k_2_02:22]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion and detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-16-000427:8k_2_02:23]
* The following should be considered in regards to the year-over-year and sequential comparisons:

[0001234452-16-000427:8k_2_02:24]
| • | The second quarter of fiscal 2016 GAAP and Non-GAAP results included: |

[0001234452-16-000427:8k_2_02:25]
| ◦ | $266 million of revenues, or $0.13 per share, due to the termination of an infrastructure license agreement resulting from the merger of two licensees. |

[0001234452-16-000427:8k_2_02:26]
| • | The first quarter of fiscal 2016 GAAP results included: |

[0001234452-16-000427:8k_2_02:27]
| ◦ | $380 million gain, or $0.20 per share, related to the sale of our wireless spectrum in the United Kingdom. |

[0001234452-16-000427:8k_2_02:28]
| • | The second quarter of fiscal 2015 GAAP results included: |

[0001234452-16-000427:8k_2_02:29]
| ◦ | $975 million charge, or $0.58 per share, related to the resolution reached with the China National Development and Reform Commission (NDRC) regarding its investigation of us under China’s Anti-Monopoly Law; and |

[0001234452-16-000427:8k_2_02:30]
| ◦ | Operating cash flow also was impacted by the prepayment of $950 million to secure long-term capacity commitments at a supplier of our integrated circuit products. |

[0001234452-16-000427:8k_2_02:31]
Second Quarter Key Business Metrics

[0001234452-16-000427:8k_2_02:32]
|  | Q2 Fiscal 2016 |  | Q2 Fiscal 2015 |  | Year-Over-Year Change (1) |  | Q1 Fiscal 2016 |  | Sequential Change (1) |
| MSMTM chip shipments | 189M |  | 233M |  | (19%) |  | 242M |  | (22%) |
| Total reported device sales (2) | $70.1B |  | $75.8B |  | (8%) |  | $60.6B |  | +16% |
| Est. reported 3G/4G device shipments (approx.) (2) | 335M - 339M |  | 384M - 388M |  | (13%) |  | 307M - 311M |  | +9% |
| Est. reported 3G/4G average selling price (approx.) (2) | $205 - $211 |  | $193 - $199 |  | +6% |  | $193 - $199 |  | +6% |

[0001234452-16-000427:8k_2_02:33]
| (1) | The year-over-year and sequential changes for estimated reported 3G/4G device shipments and average selling prices are calculated at the midpoints. The midpoints of the estimated ranges are used for comparison purposes only and do not indicate a higher degree of confidence in the midpoints. |

[0001234452-16-000427:8k_2_02:34]
| (2) | The second quarter of fiscal 2015 and 2016 are based on sales by our licensees in the December quarter as reported to us in the March quarter, and the first quarter of fiscal 2016 is based on sales by our licensees in the September quarter as reported to us in the December quarter. |

[0001234452-16-000427:8k_2_02:35]
Cash and Marketable Securities

[0001234452-16-000427:8k_2_02:36]
Our cash, cash equivalents and marketable securities totaled $30.0 billion at the end of the second quarter of fiscal 2016, compared to $29.6 billion a year ago and $30.6 billion at the end of the first quarter of fiscal 2016.

[0001234452-16-000427:8k_2_02:37]
Return of Capital to Stockholders

[0001234452-16-000427:8k_2_02:38]
The following table summarizes stock repurchases and dividends paid during the second quarter of fiscal 2016 (in millions, except per share amounts):

[0001234452-16-000427:8k_2_02:39]
|  | Stock Repurchases |  | Dividends |  | Total |
|  | Shares |  | Amount |  | Per Share |  | Amount |  | Amount |
| Q2 fiscal 2016 | 31.7 |  | $1,547 |  | $0.48 |  | $710 |  | $2,257 |

[0001234452-16-000427:8k_2_02:40]
On April 8, 2016, we announced a cash dividend of $0.53 per share payable on June 22, 2016 to stockholders of record as of the close of business on June 1, 2016, which represents a 10 percent increase over our prior quarterly dividend.

[0001234452-16-000427:8k_2_02:41]
Effective Income Tax Rates

[0001234452-16-000427:8k_2_02:42]
Our fiscal 2016 annual effective income tax rates are estimated to be approximately 18 percent for both GAAP and Non-GAAP.  The effective income tax rates for the second quarter of fiscal 2016 were 21 percent for GAAP and 18 percent for Non-GAAP.  The effective tax rate for GAAP of 21% for the second quarter of fiscal 2016 was greater than the estimated annual effective tax rate of 18% primarily due to changes in our estimates related to foreign earnings taxed at rates that are less than the United States federal tax rate and the benefit of the retroactive reinstatement of the United States federal research and development credit recorded discretely during the first quarter of fiscal 2016.

[0001234452-16-000427:8k_2_02:43]
Business Outlook

[0001234452-16-000427:8k_2_02:44]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment and certain derivative gains or losses, cannot be accurately

[0001234452-16-000427:8k_2_02:45]
forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.  Our outlook includes an estimate of the benefit related to stock repurchases that we plan to complete.

[0001234452-16-000427:8k_2_02:46]
We have not included any estimates related to the proposed joint venture with TDK Corporation in our fiscal 2016 outlook.  The joint venture is expected to close by early calendar 2017.  We expect the joint venture to be accretive to Non-GAAP earnings per share in the 12 months following the transaction close.

[0001234452-16-000427:8k_2_02:47]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-16-000427:8k_2_02:48]
Qualcomm’s Business Outlook Summary

[0001234452-16-000427:8k_2_02:49]
|  |  | Q3 FY15 Results | Current Guidance Q3 FY16 Estimates |
|  | Revenues |  | $5.8 | B | $5.2B - $6.0B |  |
|  | Year-over-year change |  | decrease 11% - increase 3% |  |
|  | Non-GAAP diluted earnings per share (EPS) |  | $0.99 |  | $0.90 - $1.00 |  |
|  | Year-over-year change |  | decrease 9% - increase 1% |  |
|  | Diluted EPS attributable to QSI |  | ($0.02 | ) |  | $0.01 |  |
|  | Diluted EPS attributable to share-based compensation |  | ($0.13 | ) |  | ($0.14 | ) |
|  | Diluted EPS attributable to other items (1) |  | ($0.12 | ) |  | ($0.09 | ) |
|  | GAAP diluted EPS |  | $0.73 |  | $0.68 - $0.78 |  |
|  | Year-over-year change |  | decrease 7% - increase 7% |  |
|  | Metrics |  |  |
|  | MSM chip shipments | 225 | M | 175M - 195M |  |
|  | Year-over-year change |  | decrease 13% - 22% |  |
|  | Total reported device sales* (2) | approx. $60.4B | approx. $52.0B - $60.0B (3) |  |
|  | Year-over-year change |  | decrease 1% - 14% |  |
|  | *Est. sales in March quarter, reported in June quarter |  |  |

[0001234452-16-000427:8k_2_02:50]
| (1) | Our guidance for diluted EPS attributable to other items for the third quarter of fiscal 2016 includes a loss per share of $0.08 for acquisition-related items. |

[0001234452-16-000427:8k_2_02:51]
| (2) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). The reported quarterly estimated ranges of average selling prices (ASPs) and unit shipments are determined based on the information as reported to us by our licensees during the relevant period and our own estimates of the selling prices and unit shipments for licensees that do not provide such information. Not all licensees report sales, selling prices and/or unit shipments the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales, estimated unit shipments and estimated ASPs for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-16-000427:8k_2_02:52]
| (3) | Our guidance range for the third quarter of fiscal 2016 total reported device sales reflects estimated 3G/4G total reported device sales that we currently expect to be reported to us, which includes an estimate of some prior period activity (i.e., devices shipped in prior periods) that may be reported to us. |

[0001234452-16-000427:8k_2_02:53]
Sums may not equal totals due to rounding.

[0001234452-16-000427:8k_2_02:54]
Results of Business Segments

[0001234452-16-000427:8k_2_02:55]
The following table reconciles our Non-GAAP results to our GAAP results ($ in millions, except per share data):

[0001234452-16-000427:8k_2_02:56]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (a) | Non-GAAP | QSI | Share-Based Compensation | Other Items (b) (c) (d) |  | GAAP |
| Q2 - FISCAL 2016 |  |  |  |  |  |
| Revenues | $3,337 | $2,135 | $67 | $5,539 |  | $12 |  |  | $— |  |  | $— |  |  | $5,551 |  |
| Change from prior year | (25 | %) | (12 | %) | 46 | % | (20 | %) |  | N/M |  |  |  |  |  | (19 | %) |  |
| Change from prior quarter | (19 | %) | 33 | % | 6 | % | (4 | %) |  | 33 | % |  |  |  |  | (4 | %) |  |
| Cost of equipment and services revenues |  |  |  | $2,017 |  | $9 |  | $10 | $105 |  | $2,141 |  |
| Research and development |  |  |  | 1,138 |  | — |  |  | 161 | 2 |  | 1,301 |  |
| Selling, general and administrative |  |  |  | 499 |  | — |  |  | 76 | 44 |  | 619 |  |
| Other expenses |  |  |  | — |  |  | — |  |  | — |  | 75 |  | 75 |  |
| Operating income (loss) |  |  |  | $1,885 |  | $3 |  | ($247) | ($226) |  | $1,415 |  |
| Change from prior year |  |  |  | (30 | %) |  | N/M |  |  | 1 | % | 80 | % |  | 6 | % |  |
| Change from prior quarter |  |  |  | 8 | % |  | N/M |  |  | — | % | (25 | %) |  | (16 | %) |  |
| Interest expense |  |  |  | ($72) |  |  | $— |  |  |  | $— |  |  | $— |  |  | ($72) |  |
| Investment income, net |  |  |  | 84 | (e) | 43 | (f) | — |  | — |  |  | 127 |  |
| EBT | $170 | $1,857 | ($130) | $1,897 |  | $46 |  | ($247) | ($226) |  | $1,470 |  |
| Change from prior year | (77 | %) | (14 | %) | N/M |  | (35 | %) |  | N/M |  |  | 1 | % | 80 | % |  | (4 | %) |  |
| Change from prior quarter | (71 | %) | 39 | % | 13 | % | 7 | % |  | (87 | %) |  | — | % | (25 | %) |  | (14 | %) |  |
| EBT as % of revenues | 5 | % | 87 | % | N/M |  | 34 | % |  |  |  |  |  |  | 26 | % |  |
| Net income (loss) |  |  |  | $1,552 |  | $30 |  | ($220) | ($198) |  | $1,164 |  |
| Change from prior year |  |  |  | (34 | %) |  | N/M |  |  | (7 | %) | 81 | % |  | 11 | % |  |
| Change from prior quarter |  |  |  | 6 | % |  | (87 | %) |  | (18 | %) | N/M |  |  | (22 | %) |  |
| Diluted EPS |  |  |  | $1.04 |  | $0.02 |  | ($0.15) | ($0.13) |  | $0.78 |  |
| Change from prior year |  |  |  | (26 | %) |  | N/M |  |  | (25 | %) | 79 | % |  | 24 | % |  |
| Change from prior quarter |  |  |  | 7 | % |  | (87 | %) |  | (25 | %) | N/M |  |  | (21 | %) |  |
| Diluted shares |  |  |  | 1,498 |  | 1,498 |  | 1,498 | 1,498 |  | 1,498 |  |
| Q1 - FISCAL 2016 |  |  |  |  |  |
| Revenues | $4,096 | $1,607 | $63 | $5,766 |  | $9 |  |  | $— |  |  | $— |  |  | $5,775 |  |
| Operating income (loss) |  |  |  | 1,741 |  | 372 |  | (247) | (181) |  | 1,685 |  |
| EBT | $590 | $1,339 | ($150) | 1,779 |  | 359 |  | (247) | (181) |  | 1,710 |  |
| Net income (loss) |  |  |  | 1,469 |  | 234 |  | (187) | (18) |  | 1,498 |  |
| Diluted EPS |  |  |  | $0.97 |  | $0.15 |  | ($0.12) | ($0.01) |  | $0.99 |  |
| Diluted shares |  |  |  | 1,517 |  | 1,517 |  | 1,517 | 1,517 |  | 1,517 |  |
| Q2 - FISCAL 2015 |  |  |  |  |  |
| Revenues | $4,434 | $2,414 | $46 | $6,894 |  |  | $— |  |  |  | $— |  |  | $— |  |  | $6,894 |  |
| Operating income (loss) |  |  |  | 2,707 |  | (4) |  | (249) | (1,118) |  | 1,336 |  |
| EBT | $750 | $2,162 | $26 | 2,938 |  | (32) |  | (249) | (1,118) |  | 1,539 |  |
| Net income (loss) |  |  |  | 2,339 |  | (27) |  | (206) | (1,053) |  | 1,053 |  |
| Diluted EPS |  |  |  | $1.40 |  | ($0.02) |  | ($0.12) | ($0.63) |  | $0.63 |  |
| Diluted shares |  |  |  | 1,667 |  | 1,667 |  | 1,667 | 1,667 |  | 1,667 |  |

[0001234452-16-000427:8k_2_02:57]
| (a) | Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations. Non-GAAP reconciling items related to earnings before taxes consisted primarily of certain research and development expenses, selling, general and administrative expenses, other expenses or income, interest expense and certain investment income that are not allocated to the segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit. |

[0001234452-16-000427:8k_2_02:58]
| (b) | In the second quarter of fiscal 2016, other items excluded from Non-GAAP EBT included $135 million of acquisition-related charges, $75 million of restructuring and restructuring-related charges related to our Strategic Realignment Plan, $12 million in asset impairment charges and $4 million of other severance costs. |

[0001234452-16-000427:8k_2_02:59]
| (c) | In the second quarter of fiscal 2016, the tax benefit in the “Other Items” column included a $24 million tax benefit for the tax effect of other items and a $15 million tax benefit for the tax effect of acquisition-related items in EBT, partially offset by a $11 million tax expense to reconcile the tax provision for each column to the total GAAP tax provision for the quarter. At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates” herein. |

[0001234452-16-000427:8k_2_02:60]
| (d) | Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001234452-16-000427:8k_2_02:61]
| (e) | Included $154 million in interest and dividend income, partially offset by $41 million in other-than-temporary losses on investments, $26 million in net realized losses on investments and $3 million in other net investment expense. |

[0001234452-16-000427:8k_2_02:62]
| (f) | Included $50 million in net realized gains on investments and $1 million in other net investment income, partially offset by $8 million in equity in losses of investees. |

[0001234452-16-000427:8k_2_02:63]
Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates

[0001234452-16-000427:8k_2_02:64]
(Unaudited)

[0001234452-16-000427:8k_2_02:65]
| Three Months Ended March 27, 2016 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Other Items |  |  | GAAP Results |  |
| Income (loss) before income taxes |  | $ | 1,897 |  |  |  | $ | 46 |  |  |  | $ | (247 | ) |  |  | $ | (226 | ) |  |  | $ | 1,470 |  |  |
| Income tax (expense) benefit |  | (345 | ) |  |  | (16 | ) |  |  | 27 |  |  |  | 28 |  |  |  | (306 | ) |  |
| Net income (loss) (1) |  | $ | 1,552 |  |  |  | $ | 30 |  |  |  | $ | (220 | ) |  |  | $ | (198 | ) |  |  | $ | 1,164 |  |  |
| Tax rate |  | 18 | % |  |  | 35 | % |  |  | 11 | % |  |  | 12 | % |  |  | 21 | % |  |

[0001234452-16-000427:8k_2_02:66]
| (1) | Before adjustments for noncontrolling interests. |

[0001234452-16-000427:8k_2_02:67]
Conference Call

[0001234452-16-000427:8k_2_02:68]
Qualcomm’s fiscal second quarter 2016 earnings conference call will be broadcast live on April 20, 2016, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 82473415.

[0001234452-16-000427:8k_2_02:69]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-16-000427:8k_2_02:70]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-16-000427:8k_2_02:71]
The Company uses the Non-GAAP financial information:  (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of equipment and services revenues, R&D expenses, SG&A expenses,

[0001234452-16-000427:8k_2_02:72]
other income or expenses, operating income, interest expense, net investment income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial information also is used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0001234452-16-000427:8k_2_02:73]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items, tax items and other items.

[0001234452-16-000427:8k_2_02:74]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-16-000427:8k_2_02:75]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001234452-16-000427:8k_2_02:76]
| • | Certain other items are excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001234452-16-000427:8k_2_02:77]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items starting with acquisitions completed in the third quarter of fiscal 2011, as well as any tax effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property and third-party acquisition and integration services costs. |

[0001234452-16-000427:8k_2_02:78]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and litigation settlements and/or damages. |

[0001234452-16-000427:8k_2_02:79]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. |

[0001234452-16-000427:8k_2_02:80]
About Qualcomm

[0001234452-16-000427:8k_2_02:81]
Qualcomm Incorporated (NASDAQ: QCOM) is a world leader in 3G, 4G and next-generation wireless technologies.  Qualcomm Incorporated includes Qualcomm’s licensing business, QTL, and the vast majority of its patent portfolio.  Qualcomm Technologies, Inc., a wholly-owned subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of Qualcomm’s engineering, research and development functions, and substantially all of its products and services businesses, including its semiconductor business, QCT.  For more than 30 years, Qualcomm ideas and inventions have driven the evolution of digital communications, linking people everywhere more closely to information, entertainment and each other.  For more information, visit www.qualcomm.com.

[0001234452-16-000427:8k_2_02:82]
Note Regarding Forward-Looking Statements

[0001234452-16-000427:8k_2_02:83]
###

[0001234452-16-000427:8k_2_02:84]
Qualcomm, Snapdragon and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-16-000427:8k_2_02:85]
Qualcomm Snapdragon processors are products of Qualcomm Technologies, Inc.

[0001234452-16-000427:8k_2_02:86]
Qualcomm Incorporated

[0001234452-16-000427:8k_2_02:87]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001234452-16-000427:8k_2_02:88]
(In millions, except per share data)

[0001234452-16-000427:8k_2_02:89]
(Unaudited)

[0001234452-16-000427:8k_2_02:90]
|  | March 27, 2016 |  | September 27, 2015 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 5,775 |  |  | $ | 7,560 |  |
| Marketable securities | 10,627 |  |  | 9,761 |  |
| Accounts receivable, net | 1,738 |  |  | 1,964 |  |
| Inventories | 1,427 |  |  | 1,492 |  |
| Deferred tax assets | — |  |  | 635 |  |
| Other current assets | 590 |  |  | 687 |  |
| Total current assets | 20,157 |  |  | 22,099 |  |
| Marketable securities | 13,582 |  |  | 13,626 |  |
| Deferred tax assets | 2,203 |  |  | 1,453 |  |
| Property, plant and equipment, net | 2,391 |  |  | 2,534 |  |
| Goodwill | 5,657 |  |  | 5,479 |  |
| Other intangible assets, net | 3,896 |  |  | 3,742 |  |
| Other assets | 2,174 |  |  | 1,863 |  |
| Total assets | $ | 50,060 |  |  | $ | 50,796 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,452 |  |  | $ | 1,300 |  |
| Payroll and other benefits related liabilities | 785 |  |  | 861 |  |
| Unearned revenues | 791 |  |  | 583 |  |
| Short-term debt | 1,949 |  |  | 1,000 |  |
| Other current liabilities | 2,049 |  |  | 2,356 |  |
| Total current liabilities | 7,026 |  |  | 6,100 |  |
| Unearned revenues | 2,526 |  |  | 2,496 |  |
| Long-term debt | 9,993 |  |  | 9,969 |  |
| Other liabilities | 878 |  |  | 817 |  |
| Total liabilities | 20,423 |  |  | 19,382 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,467 and 1,524 shares issued and outstanding, respectively | — |  |  | — |  |
| Retained earnings | 29,485 |  |  | 31,226 |  |
| Accumulated other comprehensive income | 160 |  |  | 195 |  |
| Total Qualcomm stockholders’ equity | 29,645 |  |  | 31,421 |  |
| Noncontrolling interests | (8 | ) |  | (7 | ) |
| Total stockholders’ equity | 29,637 |  |  | 31,414 |  |
| Total liabilities and stockholders’ equity | $ | 50,060 |  |  | $ | 50,796 |  |

[0001234452-16-000427:8k_2_02:91]
Qualcomm Incorporated

[0001234452-16-000427:8k_2_02:92]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-16-000427:8k_2_02:93]
(In millions, except per share data)

[0001234452-16-000427:8k_2_02:94]
(Unaudited)

[0001234452-16-000427:8k_2_02:95]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | March 27, 2016 |  | March 29, 2015 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 3,349 |  |  | $ | 4,403 |  |  | $ | 7,436 |  |  | $ | 9,619 |  |
| Licensing | 2,202 |  |  | 2,491 |  |  | 3,890 |  |  | 4,374 |  |
| Total revenues | 5,551 |  |  | 6,894 |  |  | 11,326 |  |  | 13,993 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of equipment and services revenues | 2,141 |  |  | 2,628 |  |  | 4,675 |  |  | 5,676 |  |
| Research and development | 1,301 |  |  | 1,375 |  |  | 2,653 |  |  | 2,726 |  |
| Selling, general and administrative | 619 |  |  | 545 |  |  | 1,198 |  |  | 1,128 |  |
| Other | 75 |  |  | 1,010 |  |  | (299 | ) |  | 1,063 |  |
| Total costs and expenses | 4,136 |  |  | 5,558 |  |  | 8,227 |  |  | 10,593 |  |
| Operating income | 1,415 |  |  | 1,336 |  |  | 3,099 |  |  | 3,400 |  |
| Interest expense | (72 | ) |  | (1 | ) |  | (145 | ) |  | (2 | ) |
| Investment income, net | 127 |  |  | 204 |  |  | 226 |  |  | 439 |  |
| Income before income taxes | 1,470 |  |  | 1,539 |  |  | 3,180 |  |  | 3,837 |  |
| Income tax expense | (306 | ) |  | (487 | ) |  | (520 | ) |  | (814 | ) |
| Net income | 1,164 |  |  | 1,052 |  |  | 2,660 |  |  | 3,023 |  |
| Net loss attributable to noncontrolling interests | — |  |  | 1 |  |  | 2 |  |  | 2 |  |
| Net income attributable to Qualcomm | $ | 1,164 |  |  | $ | 1,053 |  |  | $ | 2,662 |  |  | $ | 3,025 |  |
| Basic earnings per share attributable to Qualcomm | $ | 0.78 |  |  | $ | 0.64 |  |  | $ | 1.78 |  |  | $ | 1.83 |  |
| Diluted earnings per share attributable to Qualcomm | $ | 0.78 |  |  | $ | 0.63 |  |  | $ | 1.77 |  |  | $ | 1.80 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,487 |  |  | 1,645 |  |  | 1,495 |  |  | 1,653 |  |
| Diluted | 1,498 |  |  | 1,667 |  |  | 1,507 |  |  | 1,677 |  |
| Dividends per share announced | $ | 0.48 |  |  | $ | 0.42 |  |  | $ | 0.96 |  |  | $ | 0.84 |  |

[0001234452-16-000427:8k_2_02:96]
Qualcomm Incorporated

[0001234452-16-000427:8k_2_02:97]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-16-000427:8k_2_02:98]
(In millions)

[0001234452-16-000427:8k_2_02:99]
(Unaudited)

[0001234452-16-000427:8k_2_02:100]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | March 27, 2016 |  | March 29, 2015 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,164 |  |  | $ | 1,052 |  |  | $ | 2,660 |  |  | $ | 3,023 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 372 |  |  | 304 |  |  | 736 |  |  | 591 |  |
| Indefinite and long-lived asset impairment charges | 45 |  |  | 63 |  |  | 47 |  |  | 138 |  |
| Income tax provision (less than) in excess of income tax payments | (86 | ) |  | 80 |  |  | (189 | ) |  | 73 |  |
| Gain on sale of wireless spectrum | — |  |  | — |  |  | (380 | ) |  | — |  |
| Non-cash portion of share-based compensation expense | 247 |  |  | 249 |  |  | 494 |  |  | 522 |  |
| Incremental tax benefits from share-based compensation | — |  |  | (30 | ) |  | (2 | ) |  | (78 | ) |
| Net realized gains on marketable securities and other investments | (24 | ) |  | (111 | ) |  | (73 | ) |  | (277 | ) |
| Impairment losses on marketable securities and other investments | 43 |  |  | 41 |  |  | 106 |  |  | 106 |  |
| Other items, net | 60 |  |  | 1 |  |  | 47 |  |  | (30 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (392 | ) |  | 165 |  |  | 254 |  |  | 338 |  |
| Inventories | (212 | ) |  | (100 | ) |  | 79 |  |  | (403 | ) |
| Other assets | 55 |  |  | (998 | ) |  | 121 |  |  | (1,138 | ) |
| Trade accounts payable | 87 |  |  | (776 | ) |  | 137 |  |  | (508 | ) |
| Payroll, benefits and other liabilities | (708 | ) |  | (425 | ) |  | (610 | ) |  | (405 | ) |
| Unearned revenues | 86 |  |  | (173 | ) |  | 49 |  |  | (246 | ) |
| Net cash provided (used) by operating activities | 737 |  |  | (658 | ) |  | 3,476 |  |  | 1,706 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (125 | ) |  | (196 | ) |  | (253 | ) |  | (449 | ) |
| Purchases of available-for-sale securities | (4,038 | ) |  | (2,792 | ) |  | (7,775 | ) |  | (8,758 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 2,693 |  |  | 4,053 |  |  | 5,806 |  |  | 8,631 |  |
| Purchases of trading securities | (28 | ) |  | (393 | ) |  | (177 | ) |  | (695 | ) |
| Proceeds from sales and maturities of trading securities | 635 |  |  | 414 |  |  | 756 |  |  | 710 |  |
| Proceeds from sales of other marketable securities | 250 |  |  | — |  |  | 450 |  |  | — |  |
| Acquisitions and other investments, net of cash acquired | (173 | ) |  | (80 | ) |  | (623 | ) |  | (191 | ) |
| Proceeds from sale of wireless spectrum | — |  |  | — |  |  | 232 |  |  | — |  |
| Other items, net | 67 |  |  | 40 |  |  | 149 |  |  | 62 |  |
| Net cash (used) provided by investing activities | (719 | ) |  | 1,046 |  |  | (1,435 | ) |  | (690 | ) |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 3,239 |  |  | 1,095 |  |  | 4,328 |  |  | 1,095 |  |
| Repayment of short-term debt | (2,290 | ) |  | (1 | ) |  | (3,380 | ) |  | (1 | ) |
| Proceeds from issuance of common stock | 172 |  |  | 301 |  |  | 271 |  |  | 417 |  |
| Repurchases and retirements of common stock | (1,548 | ) |  | (1,947 | ) |  | (3,598 | ) |  | (3,611 | ) |
| Dividends paid | (710 | ) |  | (689 | ) |  | (1,427 | ) |  | (1,385 | ) |
| Incremental tax benefits from share-based compensation | — |  |  | 30 |  |  | 2 |  |  | 78 |  |
| Other items, net | (20 | ) |  | (2 | ) |  | (18 | ) |  | (9 | ) |
| Net cash used by financing activities | (1,157 | ) |  | (1,213 | ) |  | (3,822 | ) |  | (3,416 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 1 |  |  | (8 | ) |  | (4 | ) |  | (15 | ) |
| Net decrease in cash and cash equivalents | (1,138 | ) |  | (833 | ) |  | (1,785 | ) |  | (2,415 | ) |
| Cash and cash equivalents at beginning of period | 6,913 |  |  | 6,325 |  |  | 7,560 |  |  | 7,907 |  |
| Cash and cash equivalents at end of period | $ | 5,775 |  |  | $ | 5,492 |  |  | $ | 5,775 |  |  | $ | 5,492 |  |
