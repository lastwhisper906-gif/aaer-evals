# QCOM notes — 0001234452-16-000429


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001234452-16-000429:notes:1]
[same as prior period, unchanged from 0001234452-16-000352:notes:1]

[0001234452-16-000429:notes:2]
| Accounts Receivable (in millions) |  |  |  |
|  | March 27, 2016 |  | September 27, 2015 |
| Trade, net of allowances for doubtful accounts of $1 and $6, respectively | $ | 1,697 |  |  | $ | 1,941 |  |
| Long-term contracts | 16 |  |  | 11 |  |
| Other | 25 |  |  | 12 |  |
|  | $ | 1,738 |  |  | $ | 1,964 |  |

[0001234452-16-000429:notes:3]
The decrease in accounts receivable was primarily due to the collection of payments from certain of the Company’s licensees and the timing of integrated circuit shipments.

[0001234452-16-000429:notes:4]
| Inventories (in millions) |  |  |  |
|  | March 27, 2016 |  | September 27, 2015 |
| Raw materials | $ | 5 |  |  | $ | 1 |  |
| Work-in-process | 573 |  |  | 550 |  |
| Finished goods | 849 |  |  | 941 |  |
|  | $ | 1,427 |  |  | $ | 1,492 |  |

[0001234452-16-000429:notes:5]
| Other Current Liabilities (in millions) |  |  |  |
|  | March 27, 2016 |  | September 27, 2015 |
| Customer incentives and other customer-related liabilities | $ | 1,561 |  |  | $ | 1,894 |  |
| Other | 488 |  |  | 462 |  |
|  | $ | 2,049 |  |  | $ | 2,356 |  |

[0001234452-16-000429:notes:6]
Other Income, Costs and Expenses. Other expenses in the three months ended March 27, 2016 consisted of restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan (Note 10). Other income in the six months ended March 27, 2016 included a gain of $380 million on the sale of wireless spectrum in the United Kingdom in the first quarter of fiscal 2016 for $232 million in cash and $275 million in deferred payments due in 2020 to 2023, which were recorded at their present values in other assets. Other income in the six months ended March 27, 2016 also included $129 million in restructuring and restructuring-related charges, which were partially offset by a $48 million gain on the sale of the Company’s business that provided augmented reality applications, both of which related to the Company’s Strategic Realignment Plan.

[0001234452-16-000429:notes:7]
Other expenses in the three and six months ended March 29, 2015 included a $975 million charge resulting from the resolution reached with the China National Development and Reform Commission (NDRC) in the second quarter of fiscal 2015 regarding the NDRC’s investigation of the Company relating to China’s Anti-Monopoly Law. Other expenses in the six months ended March 29, 2015 also included $104 million in goodwill impairment charges related to the Company’s push-to-talk services and display businesses, which were partially offset by a $16 million gain on the sale of certain property, plant and equipment.

[0001234452-16-000429:notes:8]
| Investment Income, Net (in millions) |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | March 27, 2016 |  | March 29, 2015 |
| Interest and dividend income | $ | 158 |  |  | $ | 138 |  |  | $ | 295 |  |  | $ | 272 |  |
| Net realized gains on marketable securities | 1 |  |  | 108 |  |  | 43 |  |  | 264 |  |
| Net realized gains on other investments | 23 |  |  | 3 |  |  | 30 |  |  | 13 |  |
| Impairment losses on marketable securities | (41 | ) |  | (27 | ) |  | (90 | ) |  | (89 | ) |
| Impairment losses on other investments | (2 | ) |  | (14 | ) |  | (16 | ) |  | (17 | ) |
| Equity in net losses of investees | (11 | ) |  | (9 | ) |  | (31 | ) |  | (13 | ) |
| Other | (1 | ) |  | 5 |  |  | (5 | ) |  | 9 |  |
|  | $ | 127 |  |  | $ | 204 |  |  | $ | 226 |  |  | $ | 439 |  |

[0001234452-16-000429:notes:9]
Net impairment losses on marketable securities related to the noncredit portion of losses on debt securities recognized in other comprehensive income (loss) were $13 million and $36 million in the three and six months ended March 27, 2016, respectively, and were negligible in the three and six months ended March 29, 2015.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001234452-16-000429:notes:10]
Note 9. Acquisitions

[0001234452-16-000429:notes:11]
During the six months ended March 27, 2016, the Company acquired three businesses for total cash consideration of $382 million, net of cash acquired. Technology-based intangible assets recognized in the amount of $248 million are being amortized on a straight-line basis over a weighted-average useful life of five years. The Company recognized $170 million in goodwill related to these transactions, all of which was assigned to the Company’s QCT segment and of which $23 million is expected to be deductible for tax purposes.

[0001234452-16-000429:notes:12]
In January 2016, the Company announced that it had reached agreement with TDK Corporation to form a joint venture, under the name RF360 Holdings Singapore Pte. Ltd., to enable delivery of radio frequency front-end (RFFE) modules and RF filters into fully integrated products for mobile devices and Internet of Things (IoT) applications, among others. The joint venture will initially be owned 51% by the Company and 49% by TDK. Certain intellectual property, patents and filter and module design and manufacturing assets will be carved out of existing TDK businesses and be acquired by the joint venture, with certain assets acquired by the Company. The purchase price of the Company’s interest in the joint venture and the assets to be transferred to the Company is $1.2 billion, to be adjusted for working capital, outstanding indebtedness and certain capital expenditures, among other things. Additionally, the Company has the option to acquire (and TDK has an option to sell) TDK’s interest in the joint venture for $1.15 billion 30 months after the closing date. TDK will be entitled to up to a total of $200 million in payments based on sales of RF filter functions over the three-year period after the closing date, which is a substitute for and in lieu of any right of TDK to receive any profit sharing, distributions, dividends or other payments of any kind or nature. The transaction is subject to receipt of regulatory approvals and other closing conditions and is expected to close by early calendar 2017.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001234452-16-000429:notes:13]
Note 7. Commitments and Contingencies

[0001234452-16-000429:notes:14]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims were invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict and denied ParkerVision’s motions for injunctive relief and ongoing royalties as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. The Court of Appeals for the Federal Circuit heard the appeal on May 8, 2015 and issued a decision on July 31, 2015. The decision affirmed the District Court’s finding of non-infringement and granted in part the Company’s cross-appeal, holding 10 of the 11 asserted claims invalid. A subsequent Petition for Rehearing by ParkerVision was denied on October 2, 2015. On February 29, 2016, ParkerVision filed a petition for certiorari with the United States Supreme Court asking for review of the Federal Circuit’s decision. On March 28, 2016, the United States Supreme Court denied ParkerVision’s petition. No further appeals are available to ParkerVision in this matter.

[0001234452-16-000429:notes:15]
On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the complaint, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. On September 25, 2015, ParkerVision filed a motion with the court to sever some claims against the Company and all other defendants into a separate lawsuit. In addition, on December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against the Company and other parties with the United States International Trade Commission (ITC) described below.

[0001234452-16-000429:notes:16]
On December 14, 2015, ParkerVision filed a third complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. are also named defendants. The complaint asserts four additional patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. The ITC scheduled a hearing to begin on August 24, 2016. The ITC’s target date for completion of the investigation is April 21, 2017. The District Court case was stayed on February 12, 2016 pending completion of the ITC investigation.

[0001234452-16-000429:notes:17]
Nvidia Corporation v. QUALCOMM Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd. and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of certain consumer electronics and display device products, including some that incorporate the Company’s chipset products, that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District Court complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. Nvidia later narrowed the ITC case to three asserted patents. On October 9, 2015, the Administrative Law Judge in the ITC case issued an Initial Determination finding no violation of Section 337 because none of the three patents were both valid and infringed. On October 26, 2015, Nvidia filed a petition requesting the ITC to review the Initial Determination as to two of the asserted patents, but is no longer pursuing infringement allegations with respect to the third patent. On December 14, 2015, the ITC issued its decision not to review the Initial Determination of the Administrative Law Judge. This made final the determination that the Company did not violate Section 337. Therefore, neither an exclusion order nor a cease and desist order were issued. On February 17, 2016, Nvidia filed a notice of appeal of the ITC’s determination to the United States Court of Appeals for the Federal Circuit. The District Court case was stayed on October 23, 2014 pending completion of the ITC investigation, including appeals.

[0001234452-16-000429:notes:18]
LG Electronics, Inc. (LGE) Arbitration: In December 2015, LGE filed an arbitration demand with the International Chamber of Commerce (ICC) alleging that it overpaid royalties on certain CDMA (including WCDMA) subscriber units based on the alleged effect of specific provisions in its license agreement, and that the Company breached its license agreement with LGE, as well as certain implied covenants. The arbitration demand sought determination and return of the overpayment and determination of the ongoing royalties owed by LGE. On April 16, 2016, the parties entered into agreements pursuant to which the parties agreed to settle the disputes raised by LGE in its arbitration demand, and LGE agreed to dismiss the arbitration with prejudice and release all claims brought in the arbitration against the Company. Although the Company believed LGE’s claims were without merit, it deferred the recognition of revenue related to CDMA subscriber unit royalties reported and paid by LGE in the first and second quarters of fiscal 2016 because, among other reasons, the matter was submitted to arbitration for resolution. As a result of the settlement, commencing with the third quarter of fiscal 2016, the Company will no longer defer royalty revenues reported by LGE and will record greater than $200 million of revenues that were previously deferred.

[0001234452-16-000429:notes:19]
Blackberry Limited (Blackberry) Arbitration: On April 20, 2016, the Company and Blackberry entered into an agreement to arbitrate Blackberry’s allegation that it overpaid royalties on certain past sales of subscriber units based on the alleged effect of specific provisions in its license agreement. The arbitration will be conducted under the rules of the Judicial Arbitration and Mediation Services in San Diego, California. Blackberry seeks the return of the alleged overpayment. The Company believes Blackberry’s claims are without merit.

[0001234452-16-000429:notes:20]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 32 different dates, with the next hearing scheduled for July 20, 2016.

[0001234452-16-000429:notes:21]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments during fiscal 2016 with respect to this matter.

[0001234452-16-000429:notes:22]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it is conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On November 13, 2015, the Company received a case Examiner’s Report (ER) prepared by the KFTC’s investigative staff. The ER alleges, among other things, that the Company is in violation of Korean competition law by licensing its patents exhaustively only to device manufacturers and requiring that its chipset customers be licensed to the Company’s intellectual property. The ER also alleges that the Company obtains certain terms, including royalty terms, that are unfair or unreasonable in its license agreements through negotiations that do not conform to Korean competition law. The ER proposes remedies including modifications to certain business practices and monetary penalties. It remains difficult to predict the outcome of this matter. The Company believes that its business practices do not violate the MRFTA. The Company continues to cooperate with the KFTC as it conducts its investigation.

[0001234452-16-000429:notes:23]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company provided additional documents and information as requested by the Commission. On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

[0001234452-16-000429:notes:24]
European Commission (Commission) Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the Commission announced that it had initiated formal proceedings in this matter. On December 8, 2015, the Commission announced that it had issued a Statement of Objections expressing its preliminary view that since 2011 the Company has paid significant amounts to a customer on condition that it exclusively use the Company’s baseband chipsets in its smartphones and tablets. This conduct has allegedly reduced the customer’s incentives to source chipsets from the Company’s competitors and harmed competition and innovation for certain baseband chipsets. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the Commission. The Company believes that its business practices do not violate the EU competition rules.

[0001234452-16-000429:notes:25]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). As discussed below, FCPA compliance was also the focus of the SEC investigation. The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.

[0001234452-16-000429:notes:26]
As previously disclosed, the Company discovered, and as a part of its cooperation with these investigations informed the SEC and the DOJ of, instances in which special hiring consideration, gifts or other benefits (collectively, benefits) were provided to several individuals associated with Chinese state-owned companies or agencies. Based on the facts currently known, the Company believes the aggregate monetary value of the benefits in question to be less than $250,000, excluding employment compensation.

[0001234452-16-000429:notes:27]
On November 19, 2015, the DOJ notified the Company that it was terminating its investigation and would not pursue charges in this matter. On March 1, 2016, the Company entered into an administrative settlement with the SEC pursuant to which the Company paid a $7.5 million penalty and entered into a two-year period of self-monitoring and self-reporting with respect to FCPA compliance. The Company neither admits nor denies the findings in the SEC’s order and does not expect any further enforcement action against the Company or its current or former employees relating to this investigation.

[0001234452-16-000429:notes:28]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act (FTCA). The FTC has notified the Company that it is investigating conduct related to standard essential patents and pricing and contracting practices with respect to baseband processors and related products. If a violation of Section 5 is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company believes that its business practices do not violate the FTCA. The Company continues to cooperate with the FTC as it conducts its investigation.

[0001234452-16-000429:notes:29]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified the Company that it is conducting an investigation into whether the Company’s patent licensing arrangements violate the Taiwan Fair Trade Act (TFTA). If a violation is found, a broad range of remedies is potentially available to the TFTC, including imposing a fine or requiring modifications to the Company’s business practices. At this stage of the investigation, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the TFTC. The Company believes that its business practices do not violate the TFTA. The Company continues to cooperate with the TFTC as it conducts its investigation.

[0001234452-16-000429:notes:30]
The Company will continue to vigorously defend itself in the foregoing matters that remain outstanding. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at March 27, 2016 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001234452-16-000429:notes:31]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through March 27, 2016, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

[0001234452-16-000429:notes:32]
Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at March 27, 2016 associated with these indemnification arrangements, other than nominal amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001234452-16-000429:notes:33]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations under these agreements at March 27, 2016 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $3.1 billion, $1.0 billion, $778 million, $736 million and $221 million, respectively, and $34 million thereafter. Of these amounts, for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020, commitments to purchase integrated circuit product inventories comprised $2.6 billion, $822 million, $704 million, $687 million and $175 million, respectively, and there were no purchase commitments thereafter. Integrated circuit product inventory obligations represent purchase commitments for semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancellation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancellation, and in some cases, incremental fees related to capacity underutilization.

[0001234452-16-000429:notes:34]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases. Future minimum lease payments at March 27, 2016 for the remainder of fiscal 2016 and for each of the subsequent four years from fiscal 2017 through 2020 were $51 million, $43 million, $26 million, $20 million and $19 million, respectively, and $24 million thereafter.

[0001234452-16-000429:notes:35]
Other Commitments. At March 27, 2016, the Company was committed to fund certain strategic investments up to $310 million. Of this amount, $86 million is expected to be funded in the remainder of fiscal 2016. The remaining commitments represent the maximum amounts that do not have fixed funding dates and/or are subject to certain conditions. Actual funding may be in lesser amounts or not at all.


## us-gaap:DebtDisclosureTextBlock

[0001234452-16-000429:notes:36]
Note 6. Debt

[0001234452-16-000429:notes:37]
Revolving Credit Facility. The Company has a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.0 billion, expiring in February 2020. The Revolving Credit Facility requires that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in the Revolving Credit Facility, of not less than three to one at the end of each fiscal quarter. At March 27, 2016 and September 27, 2015, the Company was in compliance with the covenants, and the Company had not borrowed any funds under the Revolving Credit Facility.

[0001234452-16-000429:notes:38]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $4.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At March 27, 2016 and September 27, 2015, the Company had $1.9 billion and $1.0 billion, respectively, of outstanding commercial paper recorded as short-term debt with weighted-average interest rates of 0.49% and 0.19%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 33 days and 38 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at March 27, 2016 and September 27, 2015.

[0001234452-16-000429:notes:39]
Long-term Debt. The following table provides a summary of the Company’s long-term debt (dollar amounts in millions):

[0001234452-16-000429:notes:40]
|  | March 27, 2016 |  | September 27, 2015 |
|  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| Floating-rate notes due May 18, 2018 | $ | 250 |  |  | 0.95% |  | $ | 250 |  |  | 0.66% |
| Floating-rate notes due May 20, 2020 | 250 |  |  | 1.23% |  | 250 |  |  | 0.94% |
| Fixed-rate 1.40% notes due May 18, 2018 | 1,250 |  |  | 0.75% |  | 1,250 |  |  | 0.43% |
| Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 1.67% |  | 1,750 |  |  | 1.62% |
| Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 2.06% |  | 2,000 |  |  | 2.08% |
| Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
| Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
| Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| Total principal | 10,000 |  |  |  |  | 10,000 |  |  |  |
| Unamortized discount, including debt issuance costs | (60 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments | 53 |  |  |  |  | 32 |  |  |  |
| Total long-term debt | $ | 9,993 |  |  |  |  | $ | 9,969 |  |  |  |

[0001234452-16-000429:notes:41]
The interest rate on the floating rate notes due in 2018 and 2020 for a particular interest period will be a per annum rate equal to three-month LIBOR as determined on the interest determination date plus 0.27% and 0.55%, respectively. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the floating-rate notes prior to maturity. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At March 27, 2016 and September 27, 2015, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $10.1 billion and $9.6 billion, respectively.

[0001234452-16-000429:notes:42]
The Company has entered into interest rate swaps with an aggregate notional amount of $3.0 billion, which effectively converted all of the fixed-rate notes due in 2018 and approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings as interest expense in the current period.

[0001234452-16-000429:notes:43]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $137 million during the six months ended March 27, 2016. Cash interest paid related to the Company’s commercial paper program was negligible in the six months ended March 29, 2015. No long-term debt was outstanding in the six months ended March 29, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001234452-16-000429:notes:44]
Note 5. Employee Benefit Plans

[0001234452-16-000429:notes:45]
Equity Compensation Plans. On March 8, 2016, the Company’s stockholders approved the Qualcomm Incorporated 2016 Long-Term Incentive Plan (the 2016 Plan), which replaced the Qualcomm Incorporated 2006 Long-Term Incentive Plan (the Prior Plan). Effective on and after that date, no new awards will be granted under the Prior Plan, although all outstanding awards under the Prior Plan will remain outstanding according to their terms and the terms of the Prior Plan. The 2016 Plan provides for the grant of incentive and nonstatutory stock options, stock appreciation rights, restricted stock, unrestricted stock, restricted stock units, performance units, performance shares, deferred compensation awards and other stock-based awards. The share reserve under the 2016 Plan is equal to 90,000,000 shares, plus approximately 20,120,000 shares that were available for future grant under the Prior Plan on March 8, 2016, for a total of approximately 110,120,000 shares available for grant under the 2016 Plan on that date. This share reserve is automatically increased as provided in the 2016 Plan by the number of shares subject to stock options granted under the Prior Plan and outstanding as of March 8, 2016, which after that date expire or for any reason are forfeited, canceled or terminated, and by two times the number of shares subject to any awards other than stock options granted under the Prior Plan and outstanding as of March 8, 2016, which after that date expire, are forfeited, canceled or terminated, fail to vest, are not earned due to any performance goal that is not met, are otherwise reacquired without having become vested, or are paid in cash, exchanged by a participant or withheld by the Company to satisfy any tax withholding or tax payment obligations related to such award. The Board of Directors of the Company may amend or terminate the 2016 Plan at any time. Certain amendments, including an increase in the share reserve, require stockholder approval.


## us-gaap:DividendsDeclaredTableTextBlock

[0001234452-16-000429:notes:46]
During the six months ended March 27, 2016 and March 29, 2015, dividends charged to retained earnings were as follows (in millions, except per share data):

[0001234452-16-000429:notes:47]
|  | 2016 |  | 2015 |
|  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.48 |  |  | $ | 730 |  |  | $ | 0.42 |  |  | $ | 710 |  |
| Second quarter | 0.48 |  |  | 726 |  |  | 0.42 |  |  | 702 |  |
|  | $ | 0.96 |  |  | $ | 1,456 |  |  | $ | 0.84 |  |  | $ | 1,412 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001234452-16-000429:notes:48]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the sum of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options and/or accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 27, 2016 were 10,734,000 and 12,582,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 29, 2015 were 21,588,000 and 23,295,000, respectively. Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 6,899,000 and 4,036,000 during the three and six months ended March 27, 2016, respectively, and 18,000 and 744,000 during the three and six months ended March 29, 2015, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001234452-16-000429:notes:49]
[same as prior period, unchanged from 0001234452-16-000352:notes:44]

[0001234452-16-000429:notes:50]
|  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |
| Beginning balance of Level 3 | $ | 224 |  |  | $ | 269 |  |
| Total realized and unrealized gains or losses: |  |  |  |
| Included in investment income, net | (3 | ) |  | 3 |  |
| Included in other comprehensive income (loss) | (2 | ) |  | (4 | ) |
| Purchases | 2 |  |  | 50 |  |
| Sales | (101 | ) |  | (41 | ) |
| Settlements | (40 | ) |  | (49 | ) |
| Transfers out of Level 3 | (15 | ) |  | — |  |
| Ending balance of Level 3 | $ | 65 |  |  | $ | 228 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001234452-16-000429:notes:51]
Note 11. Fair Value Measurements

[0001234452-16-000429:notes:52]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at March 27, 2016 (in millions):

[0001234452-16-000429:notes:53]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 2,860 |  |  | $ | 1,884 |  |  | $ | — |  |  | $ | 4,744 |  |
| Marketable securities |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 103 |  |  | 1,019 |  |  | — |  |  | 1,122 |  |
| Corporate bonds and notes | — |  |  | 16,696 |  |  | — |  |  | 16,696 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 1,901 |  |  | 65 |  |  | 1,966 |  |
| Equity and preferred securities and equity funds | 1,088 |  |  | 403 |  |  | — |  |  | 1,491 |  |
| Debt funds | — |  |  | 2,934 |  |  | — |  |  | 2,934 |  |
| Total marketable securities | 1,191 |  |  | 22,953 |  |  | 65 |  |  | 24,209 |  |
| Derivative instruments | — |  |  | 60 |  |  | — |  |  | 60 |  |
| Other investments | 289 |  |  | — |  |  | — |  |  | 289 |  |
| Total assets measured at fair value | $ | 4,340 |  |  | $ | 24,897 |  |  | $ | 65 |  |  | $ | 29,302 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |
| Other liabilities | 288 |  |  | — |  |  | — |  |  | 288 |  |
| Total liabilities measured at fair value | $ | 288 |  |  | $ | 7 |  |  | $ | — |  |  | $ | 295 |  |

[0001234452-16-000429:notes:54]
Activity between Levels of the Fair Value Hierarchy. There were no significant transfers between Level 1 and Level 2 during the six months ended March 27, 2016 and March 29, 2015. When a determination is made to classify an asset or liability within Level 3, the determination is based upon the significance of the unobservable inputs to the overall fair value measurement. The following table includes the activity for mortgage- and asset-backed and auction rate securities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-16-000429:notes:55]
The Company recognizes transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. Transfers out of Level 3 during the six months ended March 27, 2016 primarily consisted of debt securities with significant upgrades in credit ratings or for which there were observable inputs. There were no transfers into or out of Level 3 during the six months ended March 29, 2015.

[0001234452-16-000429:notes:56]
Nonrecurring Fair Value Measurements. The Company measures certain assets at fair value on a nonrecurring basis. These assets include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During the six months ended March 29, 2015, the Company updated the business plans and related internal forecasts related to certain of the Company’s businesses, resulting in impairment charges to write down goodwill (Note 2). The Company determined the fair values using an income approach. The estimation of fair value and cash flows used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During the six months ended March 27, 2016 and March 29, 2015, the Company did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001234452-16-000429:notes:57]
[same as prior period, unchanged from 0001234452-16-000352:notes:52]

[0001234452-16-000429:notes:58]
The Company estimates its annual effective income tax rate to be approximately 18% for fiscal 2016, which is less than its 19% effective income tax rate for fiscal 2015. Tax benefits from foreign income taxed at rates lower than rates in the United States are expected to be approximately 15% in fiscal 2016, compared to 14% in fiscal 2015. During the first quarter of fiscal 2016, the United States government permanently reinstated the federal research and development tax credit retroactively to January 1, 2015. As a result of the reinstatement, the Company recorded a tax benefit of $79 million in the first quarter of fiscal 2016 related to fiscal 2015. The annual effective tax rate for fiscal 2015 reflected the fine imposed by the NDRC of $975 million (Note 2), which was not deductible for tax purposes and was substantially attributable to a foreign jurisdiction, and a $61 million tax benefit as a result of a favorable tax audit settlement with the Internal Revenue Service, both of which were accounted for discretely in the second quarter of fiscal 2015. During the first quarter of fiscal 2015, the United States government reinstated the federal research and development tax credit retroactively to January 1, 2014 through December 31, 2014. As a result of the reinstatement, the annual effective tax rate for fiscal 2015 also reflected a tax benefit of $101 million recorded in the first quarter of fiscal 2015 related to fiscal 2014.

[0001234452-16-000429:notes:59]
The effective tax rate of 21% for the second quarter of fiscal 2016 was greater than the estimated annual effective tax rate of 18% primarily due to changes in the Company’s estimates made in the second quarter of fiscal 2016 related to foreign earnings taxed at rates that are less than the United States federal tax rate. Additionally, the estimated annual effective tax rate for fiscal 2016 reflects the benefit of the retroactive reinstatement of the United States federal research and development credit recorded discretely during the first quarter of fiscal 2016.

[0001234452-16-000429:notes:60]
Unrecognized tax benefits were $154 million and $40 million at March 27, 2016 and September 27, 2015, respectively. Certain of the Company’s existing tax positions are expected to continue to generate an increase in unrecognized tax benefits through fiscal 2016.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001234452-16-000429:notes:61]
At March 27, 2016, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001234452-16-000429:notes:62]
| Years to Maturity |  |  |  |  |
| Less Than One Year |  | One to Five Years |  | Five to Ten Years |  | Greater Than Ten Years |  | No Single Maturity Date |  | Total |
| $ | 3,616 |  |  | $ | 11,239 |  |  | $ | 2,187 |  |  | $ | 753 |  |  | $ | 4,900 |  |  | $ | 22,695 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001234452-16-000429:notes:63]
Note 12. Marketable Securities

[0001234452-16-000429:notes:64]
Marketable securities were comprised as follows (in millions):

[0001234452-16-000429:notes:65]
|  | Current |  | Noncurrent |
|  | March 27, 2016 |  | September 27, 2015 |  | March 27, 2016 |  | September 27, 2015 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | — |  |  | $ | — |  |  | $ | 23 |  |  | $ | 12 |  |
| Corporate bonds and notes | — |  |  | — |  |  | — |  |  | 364 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | — |  |  | — |  |  | 242 |  |
| Total trading | — |  |  | — |  |  | 23 |  |  | 618 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 238 |  |  | 156 |  |  | 861 |  |  | 691 |  |
| Corporate bonds and notes | 8,770 |  |  | 7,926 |  |  | 7,926 |  |  | 7,112 |  |
| Mortgage- and asset-backed and auction rate securities | 1,505 |  |  | 1,302 |  |  | 461 |  |  | 263 |  |
| Equity and preferred securities and equity funds | 114 |  |  | 377 |  |  | 1,377 |  |  | 1,253 |  |
| Debt funds | — |  |  | — |  |  | 2,934 |  |  | 2,909 |  |
| Total available-for-sale | 10,627 |  |  | 9,761 |  |  | 13,559 |  |  | 12,228 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | — |  |  | 780 |  |
| Total marketable securities | $ | 10,627 |  |  | $ | 9,761 |  |  | $ | 13,582 |  |  | $ | 13,626 |  |

[0001234452-16-000429:notes:66]
In the second quarter of fiscal 2016, the Company exited an investment in a debt fund for which the Company elected the fair value option. The investment would have otherwise been recorded using the equity method. Changes in fair value associated with this investment were recognized in net investment income. During the three and six months ended March 27, 2016 and March 29, 2015, the changes in fair value associated with this investment were negligible.

[0001234452-16-000429:notes:67]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains or net losses recognized on debt securities classified as trading held at March 27, 2016 and March 29, 2015 were negligible during the three and six months ended March 27, 2016 and March 29, 2015, respectively.

[0001234452-16-000429:notes:68]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities and auction rate securities.

[0001234452-16-000429:notes:69]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001234452-16-000429:notes:70]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| March 27, 2016 | $ | 34 |  |  | $ | (11 | ) |  | $ | 23 |  |
| March 29, 2015 | 128 |  |  | (30 | ) |  | 98 |  |
| For the six months ended |  |  |  |  |  |
| March 27, 2016 | $ | 84 |  |  | $ | (22 | ) |  | $ | 62 |  |
| March 29, 2015 | 308 |  |  | (37 | ) |  | 271 |  |

[0001234452-16-000429:notes:71]
Available-for-sale securities were comprised as follows (in millions):

[0001234452-16-000429:notes:72]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| March 27, 2016 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,283 |  |  | $ | 242 |  |  | $ | (34 | ) |  | $ | 1,491 |  |
| Debt securities (including debt funds) | 22,824 |  |  | 196 |  |  | (325 | ) |  | 22,695 |  |
|  | $ | 24,107 |  |  | $ | 438 |  |  | $ | (359 | ) |  | $ | 24,186 |  |
| September 27, 2015 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,394 |  |  | $ | 264 |  |  | $ | (28 | ) |  | $ | 1,630 |  |
| Debt securities (including debt funds) | 20,459 |  |  | 185 |  |  | (285 | ) |  | 20,359 |  |
|  | $ | 21,853 |  |  | $ | 449 |  |  | $ | (313 | ) |  | $ | 21,989 |  |

[0001234452-16-000429:notes:73]
The following table shows the gross unrealized losses and fair values of the Company’s investments in individual securities that are classified as available-for-sale and have been in a continuous unrealized loss position deemed to be temporary for less than 12 months and for more than 12 months, aggregated by investment category (in millions):

[0001234452-16-000429:notes:74]
|  | March 27, 2016 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 468 |  |  | $ | (3 | ) |  | $ | 39 |  |  | $ | (1 | ) |
| Corporate bonds and notes | 7,498 |  |  | (117 | ) |  | 1,065 |  |  | (93 | ) |
| Mortgage- and asset-backed and auction rate securities | 1,122 |  |  | (9 | ) |  | 171 |  |  | (2 | ) |
| Equity and preferred securities and equity funds | 358 |  |  | (34 | ) |  | 4 |  |  | — |  |
| Debt funds | 1,953 |  |  | (95 | ) |  | 79 |  |  | (5 | ) |
|  | $ | 11,399 |  |  | $ | (258 | ) |  | $ | 1,358 |  |  | $ | (101 | ) |

[0001234452-16-000429:notes:75]
|  | September 27, 2015 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 304 |  |  | $ | (4 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 7,656 |  |  | (93 | ) |  | 368 |  |  | (62 | ) |
| Mortgage- and asset-backed and auction rate securities | 862 |  |  | (3 | ) |  | 108 |  |  | (1 | ) |
| Equity and preferred securities and equity funds | 392 |  |  | (28 | ) |  | 17 |  |  | — |  |
| Debt funds | 1,792 |  |  | (117 | ) |  | 124 |  |  | (5 | ) |
|  | $ | 11,006 |  |  | $ | (245 | ) |  | $ | 617 |  |  | $ | (68 | ) |

[0001234452-16-000429:notes:76]
At March 27, 2016, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities and preferred stock with unrealized losses, the Company did not have the intent to sell, nor was it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

[0001234452-16-000429:notes:77]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company was $52 million and negligible at March 27, 2016 and March 29, 2015, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001234452-16-000429:notes:78]
Recent Accounting Pronouncements. In November 2015, the Financial Accounting Standards Board (FASB) issued new guidance related to accounting for income taxes, which requires all deferred tax assets and liabilities to be classified as noncurrent on the balance sheet. The Company early adopted the new guidance prospectively in the second quarter of fiscal 2016. Prior period amounts have not been adjusted.

[0001234452-16-000429:notes:79]
In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Adoption one year early is permitted. Two methods of adoption are permitted: (a) full retrospective adoption, meaning the standard is applied to all periods presented or (b) modified retrospective adoption, meaning the cumulative effect of applying the new guidance is recognized as an adjustment to the opening retained earnings balance. The Company does not intend to adopt the new guidance early and is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.

[0001234452-16-000429:notes:80]
In January 2016, the FASB issued new guidance on classifying and measuring financial instruments, which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk be recognized separately in other comprehensive income. Additionally, it changes the disclosure requirements for financial instruments. The new guidance will be effective for the Company starting in the first quarter of fiscal 2019. Early adoption is permitted for certain provisions. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt certain provisions early.

[0001234452-16-000429:notes:81]
In February 2016, the FASB issued new guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease guidance. The new guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. The new guidance must be adopted using the modified retrospective approach and will be effective for the Company starting in the first quarter of fiscal 2020. Early adoption is permitted. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.

[0001234452-16-000429:notes:82]
In March 2016, the FASB issued new guidance that changes the accounting for share-based payments. Under the new guidance, excess tax benefits associated with share-based payment awards will be recognized in the income statement when the awards vest or settle, rather than in stockholders’ equity. In addition, it will increase the number of shares an employer can withhold to cover income taxes on share-based payment awards and still qualify for the exemption to liability classification. The new guidance will be effective for the Company starting in the first quarter of fiscal 2018. Early adoption is permitted in any annual or interim period. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements as well as whether to adopt the new guidance early.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001234452-16-000429:notes:83]
[same as prior period, unchanged from 0001234452-16-000352:notes:75]

[0001234452-16-000429:notes:84]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 27, 2015. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and six-month periods ended March 27, 2016 and March 29, 2015 included 13 weeks and 26 weeks, respectively.

[0001234452-16-000429:notes:85]
[same as prior period, unchanged from 0001234452-16-000352:notes:77]

[0001234452-16-000429:notes:86]
[same as prior period, unchanged from 0001234452-16-000352:notes:78]

[0001234452-16-000429:notes:87]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | March 27, 2016 |  | March 29, 2015 |
| Cost of equipment and services revenues | $ | 10 |  |  | $ | 11 |  |  | $ | 20 |  |  | $ | 23 |  |
| Research and development | 161 |  |  | 158 |  |  | 326 |  |  | 333 |  |
| Selling, general and administrative | 76 |  |  | 80 |  |  | 148 |  |  | 166 |  |
| Share-based compensation expense before income taxes | 247 |  |  | 249 |  |  | 494 |  |  | 522 |  |
| Related income tax benefit | (27 | ) |  | (43 | ) |  | (87 | ) |  | (86 | ) |
|  | $ | 220 |  |  | $ | 206 |  |  | $ | 407 |  |  | $ | 436 |  |

[0001234452-16-000429:notes:88]
The Company recorded $96 million and $81 million in share-based compensation expense during the six months ended March 27, 2016 and March 29, 2015, respectively, related to share-based awards granted during those periods. At March 27, 2016, total unrecognized compensation expense related to non-vested restricted stock units granted prior to that date was $1.4 billion, which is expected to be recognized over a weighted-average period of 2.0 years. During the six months ended March 27, 2016 and March 29, 2015, net share-based awards granted, after forfeitures and cancellations, represented 0.7% and 0.4%, respectively, of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.9% and 0.5%, respectively, of outstanding shares as of the end of each fiscal period.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001234452-16-000429:notes:89]
[same as prior period, unchanged from 0001234452-16-000352:notes:81]

[0001234452-16-000429:notes:90]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | March 27, 2016 |  | March 29, 2015 |
| Cost of equipment and services revenues | $ | 105 |  |  | $ | 63 |  |  | $ | 246 |  |  | $ | 129 |  |
| Research and development expenses | 2 |  |  | 3 |  |  | 5 |  |  | 8 |  |
| Selling, general and administrative expenses | 28 |  |  | 13 |  |  | 57 |  |  | 25 |  |

[0001234452-16-000429:notes:91]
[same as prior period, unchanged from 0001234452-16-000352:notes:83]

[0001234452-16-000429:notes:92]
|  | Three Months Ended |  | Six Months Ended |
|  | March 27, 2016 |  | March 29, 2015 |  | March 27, 2016 |  | March 29, 2015 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 68 |  |  | $ | 47 |  |  | $ | 132 |  |  | $ | 90 |  |
| Intersegment eliminations | (1 | ) |  | (1 | ) |  | (2 | ) |  | (3 | ) |
|  | $ | 67 |  |  | $ | 46 |  |  | $ | 130 |  |  | $ | 87 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of equipment and services revenues | $ | (115 | ) |  | $ | (74 | ) |  | $ | (266 | ) |  | $ | (152 | ) |
| Unallocated research and development expenses | (186 | ) |  | (226 | ) |  | (402 | ) |  | (437 | ) |
| Unallocated selling, general and administrative expenses | (125 | ) |  | (100 | ) |  | (252 | ) |  | (249 | ) |
| Unallocated other expense, net | (75 | ) |  | (1,010 | ) |  | (81 | ) |  | (1,079 | ) |
| Unallocated interest expense | (71 | ) |  | (1 | ) |  | (143 | ) |  | (1 | ) |
| Unallocated investment income, net | 89 |  |  | 233 |  |  | 203 |  |  | 463 |  |
| Nonreportable segments | (117 | ) |  | (163 | ) |  | (239 | ) |  | (311 | ) |
| Intersegment eliminations | (3 | ) |  | — |  |  | — |  |  | (1 | ) |
|  | $ | (603 | ) |  | $ | (1,341 | ) |  | $ | (1,180 | ) |  | $ | (1,767 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001234452-16-000429:notes:93]
Note 10. Strategic Realignment Plan

[0001234452-16-000429:notes:94]
On July 22, 2015, the Company announced a Strategic Realignment Plan designed to improve execution, enhance financial performance and drive profitable growth as the Company works to create sustainable long-term value for stockholders. As part of this, among other actions, the Company is implementing a cost reduction plan, which includes a series of targeted reductions across the Company’s businesses, particularly in QCT, and a reduction to its annual share-based compensation grants. The Company expects these cost reduction initiatives to be substantially implemented by the end of fiscal 2016. During the six months ended March 27, 2016, the Company recorded restructuring charges of $89 million, including consulting costs of $48 million and severance costs of $37 million, restructuring-related charges of $40 million, which primarily consisted of asset impairments, and a $48 million gain on the sale of the Company’s business that provided augmented reality applications, since such sale was executed in connection with the Strategic Realignment Plan, all of which were included in other income (Note 2) in reconciling items (Note 8). Restructuring activities were initiated in the fourth quarter of fiscal 2015, and a total of $271 million in net restructuring and restructuring-related charges were incurred through the second quarter of fiscal 2016. In connection with this plan, the Company expects to incur additional restructuring and restructuring-related charges of approximately $25 million to $125 million, which primarily consist of severance and consulting costs. The remaining costs are expected to be incurred in fiscal 2016 and fiscal 2017, and the majority are expected to be settled in cash.

[0001234452-16-000429:notes:95]
The restructuring accrual, a portion of which is included in payroll and other benefits related liabilities with the remainder included in other current liabilities, is expected to be substantially paid within the next 12 months. Changes in the restructuring accrual during the six months ended March 27, 2016 were as follows (in millions):

[0001234452-16-000429:notes:96]
|  | Severance Costs |  | OtherCosts |  | Total |
| Beginning balance of restructuring accrual | $ | 122 |  |  | $ | 31 |  |  | $ | 153 |  |
| Additional costs | 44 |  |  | 53 |  |  | 97 |  |
| Cash payments | (124 | ) |  | (67 | ) |  | (191 | ) |
| Adjustments | (7 | ) |  | (1 | ) |  | (8 | ) |
| Ending balance of restructuring accrual | $ | 35 |  |  | $ | 16 |  |  | $ | 51 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001234452-16-000429:notes:97]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in Qualcomm stockholders’ equity during the six months ended March 27, 2016 were as follows (in millions):

[0001234452-16-000429:notes:98]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Total Accumulated Other Comprehensive Income |
| Balance at September 27, 2015 | $ | (160 | ) |  | $ | 4 |  |  | $ | 297 |  |  | $ | 54 |  |  | $ | 195 |  |
| Other comprehensive loss before reclassifications | (11 | ) |  | (8 | ) |  | (41 | ) |  | — |  |  | (60 | ) |
| Reclassifications from accumulated other comprehensive income | 6 |  |  | (5 | ) |  | 23 |  |  | 1 |  |  | 25 |  |
| Other comprehensive (loss) income | (5 | ) |  | (13 | ) |  | (18 | ) |  | 1 |  |  | (35 | ) |
| Balance at March 27, 2016 | $ | (165 | ) |  | $ | (9 | ) |  | $ | 279 |  |  | $ | 55 |  |  | $ | 160 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001234452-16-000429:notes:99]
[same as prior period, unchanged from 0001234452-16-000352:notes:91]

[0001234452-16-000429:notes:100]
|  | QCT |  | QTL |  | QSI |  | ReconcilingItems |  | Total |
| For the three months ended |  |  |  |  |  |  |  |  |  |
| March 27, 2016 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 3,337 |  |  | $ | 2,135 |  |  | $ | 12 |  |  | $ | 67 |  |  | $ | 5,551 |  |
| EBT | 170 |  |  | 1,857 |  |  | 46 |  |  | (603 | ) |  | 1,470 |  |
| March 29, 2015 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 4,434 |  |  | $ | 2,414 |  |  | $ | — |  |  | $ | 46 |  |  | $ | 6,894 |  |
| EBT | 750 |  |  | 2,162 |  |  | (32 | ) |  | (1,341 | ) |  | 1,539 |  |
| For the six months ended |  |  |  |  |  |  |  |  |  |
| March 27, 2016 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 7,433 |  |  | $ | 3,742 |  |  | $ | 21 |  |  | $ | 130 |  |  | $ | 11,326 |  |
| EBT | 760 |  |  | 3,195 |  |  | 405 |  |  | (1,180 | ) |  | 3,180 |  |
| March 29, 2015 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 9,676 |  |  | $ | 4,230 |  |  | $ | — |  |  | $ | 87 |  |  | $ | 13,993 |  |
| EBT | 1,896 |  |  | 3,741 |  |  | (33 | ) |  | (1,767 | ) |  | 3,837 |  |
| Total assets |  |  |  |  |  |  |  |  |  |
| March 27, 2016 | $ | 2,821 |  |  | $ | 268 |  |  | $ | 934 |  |  | $ | 46,037 |  |  | $ | 50,060 |  |
| September 27, 2015 | 2,923 |  |  | 438 |  |  | 812 |  |  | 46,623 |  |  | $ | 50,796 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001234452-16-000429:notes:101]
Changes in stockholders’ equity for the six months ended March 27, 2016 were as follows (in millions):

[0001234452-16-000429:notes:102]
|  | Qualcomm Stockholders’ Equity |  | Noncontrolling Interests |  | Total Stockholders’ Equity |
| Balance at September 27, 2015 | $ | 31,421 |  |  | $ | (7 | ) |  | $ | 31,414 |  |
| Net income (loss) | 2,662 |  |  | (2 | ) |  | 2,660 |  |
| Other comprehensive loss | (35 | ) |  | — |  |  | (35 | ) |
| Common stock issued under employee benefit plans and related tax benefits | 238 |  |  | — |  |  | 238 |  |
| Share-based compensation | 520 |  |  | — |  |  | 520 |  |
| Tax withholdings related to vesting of share-based payments | (107 | ) |  | — |  |  | (107 | ) |
| Dividends | (1,456 | ) |  | — |  |  | (1,456 | ) |
| Stock repurchases | (3,598 | ) |  | — |  |  | (3,598 | ) |
| Other | — |  |  | 1 |  |  | 1 |  |
| Balance at March 27, 2016 | $ | 29,645 |  |  | $ | (8 | ) |  | $ | 29,637 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001234452-16-000429:notes:103]
Note 8. Segment Information

[0001234452-16-000429:notes:104]
[same as prior period, unchanged from 0001234452-16-000352:notes:96]

[0001234452-16-000429:notes:105]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT) from continuing operations. Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense; certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include amortization and impairment of certain intangible assets, recognition of the step-up of inventories to fair value and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and litigation settlements and/or damages.

[0001234452-16-000429:notes:106]
[same as prior period, unchanged from 0001234452-16-000352:notes:98]

[0001234452-16-000429:notes:107]
Unallocated other expense for the six months ended March 27, 2016 was comprised of net restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan (Note 10). Unallocated other expense for the six months ended March 29, 2015 was comprised of a charge related to the resolution reached with the NDRC and goodwill impairment charges related to two of the Company’s nonreportable segments (Note 2).


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001234452-16-000429:notes:108]
[same as prior period, unchanged from 0001234452-16-000352:notes:100]

[0001234452-16-000429:notes:109]
Reclassifications from accumulated other comprehensive income related to available-for-sale securities of $11 million and $18 million for the three and six months ended March 27, 2016, respectively, and $47 million and $118 million for the three and six months ended March 29, 2015, respectively, were recorded in investment income, net (Note 2).

[0001234452-16-000429:notes:110]
Stock Repurchase Program. On March 9, 2015, the Company announced a stock repurchase program authorizing it to repurchase up to $15 billion of the Company’s common stock. The stock repurchase program has no expiration date. During the six months ended March 27, 2016 and March 29, 2015, the Company repurchased and retired 68,335,000 and 50,699,000 shares of common stock, respectively, for $3.6 billion in each period, before commissions. At March 27, 2016, $3.3 billion remained authorized for repurchase under the Company’s stock repurchase program.

[0001234452-16-000429:notes:111]
Dividends. On March 8, 2016, the Company announced a 10% increase in its quarterly cash dividend per share of common stock from $0.48 to $0.53, which is effective for dividends payable after March 23, 2016. On April 8, 2016, the Company announced a cash dividend of $0.53 per share on the Company’s common stock, payable on June 22, 2016 to stockholders of record as of the close of business on June 1, 2016. During the six months ended March 27, 2016 and March 29, 2015, dividends charged to retained earnings were as follows (in millions, except per share data):
