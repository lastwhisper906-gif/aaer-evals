# QCOM note change history — 0000804328-23-000006 → 0000804328-23-000023


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2023-05-03):
[0000804328-23-000023:note_history:1]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions, and on July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On May 23, 2022, the plaintiffs filed a motion for class certification, and a hearing on the motion was held on October 19, 2022. On March 20, 2023, the court issued an order granting in part and denying in part the plaintiffs’ motion for class certification. The order denied class certification on the basis of alleged misrepresentations relating to our chip-level licensing practices, but certified a class on the basis of alleged misrepresentations relating to the separate operations of QCT and QTL. No trial date has been set.

- added (2023-05-03):
[0000804328-23-000023:note_history:2]
On April 3, 2023, we filed a petition with the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) seeking permission to appeal the district court’s class certification order. We believe the plaintiffs’ claims are without merit.

- added (2023-05-03):
[0000804328-23-000023:note_history:3]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On July 5, 2018, the plaintiffs filed a motion for class certification, and on September 27, 2018, the court granted that motion. We appealed the district court’s class certification order to the Ninth Circuit. On September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class, and remanded the case to the district court. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. On August 1, 2022, we filed a motion to dismiss the amended complaint, and on November 15, 2022, the court held a hearing on our motion. On January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. The order preserved the plaintiffs’ claims related to exclusive dealing under California antitrust and unfair competition laws and dismissed the remainder of the plaintiffs’ claims, which were related to our licensing practices. On April 7, 2023, we filed a motion for summary judgment on the plaintiffs’ remaining claims. A hearing on our motion is scheduled for July 20, 2023. We believe the plaintiffs’ claims are without merit.

- changed (2023-05-03):
[0000804328-23-000023:note_history:4]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.
  (was, 2023-02-02, similarity 0.8513):
[0000804328-23-000006:note_history:4]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in

- added (2023-05-03):
[0000804328-23-000023:note_history:5]
On September 30, 2022, we filed our Answer and Counterclaim in response to ARM’s complaint denying ARM’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and ARM and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia), server System-on-Chip (SoC) and

- changed (2023-05-03):
[0000804328-23-000023:note_history:6]
compute SoC are fully licensed under our existing Architecture License Agreement and Technology License Agreement with ARM (the ARM-Qualcomm Agreements). We further seek an order enjoining ARM from making any claim that our products are not licensed under the ARM-Qualcomm Agreements, are not ARM-compliant or that we are prohibited from using ARM’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements ARM is making in the marketplace concerning our rights under the ARM-Qualcomm Agreements are false, and that ARM has no right to prevent us from shipping our products, which are validly licensed. Trial is scheduled to begin on September 23, 2024.
  (was, 2023-02-02, similarity 0.7653):
[0000804328-23-000006:note_history:6]
On September 30, 2022, we filed our Answer and Counterclaim in response to ARM’s complaint denying ARM’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and ARM and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia), server System-on-Chip (SoC) and compute SoC are fully licensed under our existing Architecture License Agreement and Technology License Agreement with ARM (the ARM-Qualcomm Agreements). We further seek an order enjoining ARM from making any claim that our products are not licensed under the ARM-Qualcomm Agreements, are not ARM-compliant or that we are prohibited from using ARM’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements ARM is making in the marketplace concerning our rights under the ARM-Qualcomm Agreements are false, and that ARM has no right to prevent us from shipping our products, which are validly licensed. Trial is scheduled to begin on September 23, 2024.

- changed (2023-05-03):
[0000804328-23-000023:note_history:7]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.
  (was, 2023-02-02, similarity 0.9743):
[0000804328-23-000006:note_history:7]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises.

- changed (2023-05-03):
[0000804328-23-000023:note_history:8]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019, and on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. On April 12, 2023, the Korea Supreme Court delivered its judgment, which dismissed all appeals by both Qualcomm and the KFTC, affirming the judgment of the Seoul High Court. The Korea Supreme Court judgment concludes the appeal process.
  (was, 2023-02-02, similarity 0.8237):
[0000804328-23-000006:note_history:8]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019, and on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC. We believe that our business practices do not violate the MRFTA.

- added (2023-05-03):
[0000804328-23-000023:note_history:9]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC did not provide a formal notice on the scope of its investigation, but we believe it concerned our business practices in connection with our sale of RFFE components. On April 18, 2023, the KFTC informed us that it had closed its investigation without finding any violation.

- changed (2023-05-03):
[0000804328-23-000023:note_history:10]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision finding that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. From March 13, 2023 to March 15, 2023, the court held a hearing on our appeal. The court has not yet issued a ruling. We believe that our business practices do not violate the European Union (EU) competition rules.
  (was, 2023-02-02, similarity 0.8056):
[0000804328-23-000006:note_history:10]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision finding that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. A hearing on our appeal is scheduled for March 13-15, 2023. We believe that our business practices do not violate the European Union (EU) competition rules.

- added (2023-05-03):
[0000804328-23-000023:note_history:11]
Contingent Losses and Other Considerations: We will continue to vigorously defend ourselves in the pending matters described above. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. Other than with respect to the EC fine related to the Icera Complaint to the European Commission, we have not recorded any accrual at March 26, 2023 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- removed (2023-05-03):
[0000804328-23-000006:note_history:12]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions. On July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint, and on March 18, 2019, the court denied our motion. On January 15, 2020, we filed a motion for judgment on the pleadings, which the court denied on February 3, 2022. On May 23, 2022, the plaintiffs filed a motion for class certification, and a hearing on the motion was held on October 19, 2022. The court has not yet ruled on the motion. We believe the plaintiffs’ claims are without merit.

- removed (2023-05-03):
[0000804328-23-000006:note_history:13]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On July 5, 2018, the plaintiffs filed a motion for class certification, and on September 27, 2018, the court granted that motion. We appealed the district court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit), and on September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class. The Ninth Circuit remanded the case to the district court and instructed the court to consider the effect of United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated (which the Ninth Circuit decided in favor of Qualcomm in August 2020) on this case. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. On August 1, 2022, we filed a motion to dismiss the amended complaint, and on November 15, 2022, the court held a hearing on our motion. On January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. The order preserved the plaintiffs’ claims related to exclusive dealing under California antitrust and unfair competition laws and dismissed the remainder of the plaintiffs’ claims, which were related to our licensing practices. We believe the plaintiffs’ claims are without merit.

- removed (2023-05-03):
[0000804328-23-000006:note_history:14]
these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

- removed (2023-05-03):
[0000804328-23-000006:note_history:15]
The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

- removed (2023-05-03):
[0000804328-23-000006:note_history:16]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of its investigation, but we believe it concerns our business practices in connection with our sale of RFFE components. We continue to cooperate with the KFTC as it conducts its investigation. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

- removed (2023-05-03):
[0000804328-23-000006:note_history:17]
Contingent Losses and Other Considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. Other than with respect to the EC fine related to the Icera Complaint to the European Commission, we have not recorded any accrual at December 25, 2022 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000804328-23-000023:note_history:18]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 25, 2022. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 26, 2023 and March 27, 2022 included 13 weeks and 26 weeks, respectively.
  (was, 2023-02-02, similarity 0.9616):
[0000804328-23-000006:note_history:18]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 25, 2022. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 25, 2022 and December 26, 2021 included 13 weeks.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000804328-23-000023:note_history:19]
At March 26, 2023, the aggregate fair value of our outstanding floating- and fixed-rate notes, based on Level 2 inputs, was approximately $15.1 billion.
  (was, 2023-02-02, similarity 0.9689):
[0000804328-23-000006:note_history:19]
At December 25, 2022, the aggregate fair value of our outstanding floating- and fixed-rate notes, based on Level 2 inputs, was approximately $16.1 billion.

- changed (2023-05-03):
[0000804328-23-000023:note_history:20]
Interest Rate Swaps. At September 25, 2022, we had outstanding forward-starting interest rate swaps with an aggregate notional amount, denominated in U.S. dollars, of $1.6 billion. During the first quarter of fiscal 2023, in connection with the issuance of the November 2022 Notes, we terminated these swaps, and the related gains of $334 million, included within accumulated comprehensive income, are being recorded as a reduction to interest expense over the hedged portions of the related debt.
  (was, 2023-02-02, similarity 0.9453):
[0000804328-23-000006:note_history:20]
Interest Rate Swaps. At September 25, 2022, we had outstanding forward-starting interest rate swaps with an aggregate notional amount, denominated in U.S. dollars, of $1.6 billion. During the first quarter of fiscal 2023, in connection with the issuance of the November 2022 Notes, we terminated these swaps, and the related gains of $334 million are being reclassified from accumulated comprehensive income to being recorded as a reduction to interest expense over the hedged portions of the related debt.

- changed (2023-05-03):
[0000804328-23-000023:note_history:21]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. At March 26, 2023 and September 25, 2022, we had $499 million of outstanding commercial paper recorded as short-term debt.
  (was, 2023-02-02, similarity 0.9208):
[0000804328-23-000006:note_history:21]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. At December 25, 2022 and September 25, 2022, we had no amounts and $499 million, respectively, of outstanding commercial paper recorded as short-term debt.

- removed (2023-05-03):
[0000804328-23-000006:note_history:22]
The following table provides a summary of our long-term debt:

- removed (2023-05-03):
[0000804328-23-000006:note_history:23]
|  | December 25, 2022 |  | September 25, 2022 |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |  | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 5,860 |  |  | 2.66% - 5.17% |  | 2023 - 2047 |  | 5,860 |  |  | 2.68% - 4.46% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.95% - 3.30% |  | 2030 - 2050 |  | 2,000 |  |  | 2.97% - 3.30% |
| August 2020 Notes | 2028 - 2032 |  | 2,207 |  |  | 2.48% - 3.53% |  | 2028 - 2032 |  | 2,207 |  |  | 2.50% - 3.52% |
| May 2022 Notes | 2032 - 2052 |  | 1,500 |  |  | 3.14% - 4.26% |  | 2032 - 2052 |  | 1,500 |  |  | 3.13% - 4.26% |
| November 2022 Notes | 2033 - 2053 |  | 1,900 |  |  | 3.44% - 4.99% |  |  |  | — |  |  |  |
| Total principal |  |  | 17,332 |  |  |  |  |  |  | 15,432 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (258) |  |  |  |  |  |  | (241) |  |  |  |
| Hedge accounting fair value adjustments |  | (197) |  |  |  |  |  |  | (208) |  |  |  |
| Total long-term debt |  |  | $ | 16,877 |  |  |  |  |  |  | $ | 14,983 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 1,446 |  |  |  |  |  |  | $ | 1,446 |  |  |  |
| Long-term debt |  |  | 15,431 |  |  |  |  |  |  | 13,537 |  |  |  |
| Total |  |  | $ | 16,877 |  |  |  |  |  |  | $ | 14,983 |  |  |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-05-03):
[0000804328-23-000006:note_history:24]
Marketable Securities
Our marketable securities were all classified as current and were comprised as follows (in millions):

- removed (2023-05-03):
[0000804328-23-000006:note_history:25]
|  | December 25,2022 |  | September 25,2022 |  |  |  |  |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 3,185 |  |  | $ | 3,330 |  |  |  |  |  |
| Mortgage- and asset-backed securities | 90 |  |  | 99 |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 16 |  |  | 16 |  |  |  |  |  |
| Total available-for-sale debt securities | 3,291 |  |  | 3,445 |  |  |  |  |  |
| Equity securities | 139 |  |  | 164 |  |  |  |  |  |
| Total marketable securities | $ | 3,430 |  |  | $ | 3,609 |  |  |  |  |  |

- removed (2023-05-03):
[0000804328-23-000006:note_history:26]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

- removed (2023-05-03):
[0000804328-23-000006:note_history:27]
|  | December 25,2022 |
| Years to Maturity |  |
| Less than one year | $ | 1,260 |  |
| One to five years | 1,941 |  |
| No single maturity date | 90 |  |
| Total | $ | 3,291 |  |

- removed (2023-05-03):
[0000804328-23-000006:note_history:28]
Debt securities with no single maturity date included mortgage- and asset-backed securities.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-05-03):
[0000804328-23-000006:note_history:29]
The following table provides a summary of our long-term debt:

- removed (2023-05-03):
[0000804328-23-000006:note_history:30]
|  | December 25, 2022 |  | September 25, 2022 |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |  | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 5,860 |  |  | 2.66% - 5.17% |  | 2023 - 2047 |  | 5,860 |  |  | 2.68% - 4.46% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.95% - 3.30% |  | 2030 - 2050 |  | 2,000 |  |  | 2.97% - 3.30% |
| August 2020 Notes | 2028 - 2032 |  | 2,207 |  |  | 2.48% - 3.53% |  | 2028 - 2032 |  | 2,207 |  |  | 2.50% - 3.52% |
| May 2022 Notes | 2032 - 2052 |  | 1,500 |  |  | 3.14% - 4.26% |  | 2032 - 2052 |  | 1,500 |  |  | 3.13% - 4.26% |
| November 2022 Notes | 2033 - 2053 |  | 1,900 |  |  | 3.44% - 4.99% |  |  |  | — |  |  |  |
| Total principal |  |  | 17,332 |  |  |  |  |  |  | 15,432 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (258) |  |  |  |  |  |  | (241) |  |  |  |
| Hedge accounting fair value adjustments |  | (197) |  |  |  |  |  |  | (208) |  |  |  |
| Total long-term debt |  |  | $ | 16,877 |  |  |  |  |  |  | $ | 14,983 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 1,446 |  |  |  |  |  |  | $ | 1,446 |  |  |  |
| Long-term debt |  |  | 15,431 |  |  |  |  |  |  | 13,537 |  |  |  |
| Total |  |  | $ | 16,877 |  |  |  |  |  |  | $ | 14,983 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000804328-23-000023:note_history:31]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  | March 26,2023 |  | March 27,2022 |  | March 26,2023 |  | March 27,2022 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,105 |  |  | $ | 7,349 |  |  | $ | 11,860 |  |  | $ | 14,338 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 447 |  |  | 371 |  |  | 903 |  |  | 659 |  |
| IoT (3) |  |  |  |  |  |  |  |  | 1,390 |  |  | 1,828 |  |  | 3,071 |  |  | 3,398 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 7,942 |  |  | $ | 9,548 |  |  | $ | 15,834 |  |  | $ | 18,395 |  |
  (was, 2023-02-02, similarity 0.7571):
[0000804328-23-000006:note_history:31]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | December 25,2022 |  | December 26,2021 |  |  |  |  |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 5,754 |  |  | $ | 6,989 |  |  |  |  |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 456 |  |  | 288 |  |  |  |  |  |
| IoT (3) |  |  |  |  |  |  |  |  | 1,682 |  |  | 1,570 |  |  |  |  |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 7,892 |  |  | $ | 8,847 |  |  |  |  |  |
