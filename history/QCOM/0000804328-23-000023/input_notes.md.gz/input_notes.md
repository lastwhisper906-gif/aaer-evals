# QCOM notes — 0000804328-23-000023


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000804328-23-000023:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 25, 2022. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 26, 2023 and March 27, 2022 included 13 weeks and 26 weeks, respectively.

[0000804328-23-000023:notes:2]
[same as prior period, unchanged from 0000804328-23-000006:notes:2]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-23-000023:notes:3]
[same as prior period, unchanged from 0000804328-23-000006:notes:3]

[0000804328-23-000023:notes:4]
| Inventories (in millions) |  |  |  |
|  | March 26,2023 |  | September 25,2022 |
| Raw materials | $ | 219 |  |  | $ | 221 |  |
| Work-in-process | 4,248 |  |  | 3,329 |  |
| Finished goods | 2,391 |  |  | 2,791 |  |
|  | $ | 6,858 |  |  | $ | 6,341 |  |

[0000804328-23-000023:notes:5]
[same as prior period, unchanged from 0000804328-23-000006:notes:5]

[0000804328-23-000023:notes:6]
[same as prior period, unchanged from 0000804328-23-000006:notes:6]

[0000804328-23-000023:notes:7]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  | March 26,2023 |  | March 27,2022 |  | March 26,2023 |  | March 27,2022 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,105 |  |  | $ | 7,349 |  |  | $ | 11,860 |  |  | $ | 14,338 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 447 |  |  | 371 |  |  | 903 |  |  | 659 |  |
| IoT (3) |  |  |  |  |  |  |  |  | 1,390 |  |  | 1,828 |  |  | 3,071 |  |  | 3,398 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 7,942 |  |  | $ | 9,548 |  |  | $ | 15,834 |  |  | $ | 18,395 |  |

[0000804328-23-000023:notes:8]
[same as prior period, unchanged from 0000804328-23-000006:notes:8]

[0000804328-23-000023:notes:9]
[same as prior period, unchanged from 0000804328-23-000006:notes:9]

[0000804328-23-000023:notes:10]
[same as prior period, unchanged from 0000804328-23-000006:notes:10]

[0000804328-23-000023:notes:11]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods generally include certain QCT sales-based royalty revenues related to system software, certain amounts related to QCT customer incentives  and QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due) and were as follows (in millions):

[0000804328-23-000023:notes:12]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | March 26,2023 |  | March 27,2022 |
| Revenues recognized from previously satisfied performance obligations | $ | 170 |  |  | $ | 185 |  |  | $ | 337 |  |  | $ | 367 |  |

[0000804328-23-000023:notes:13]
Unearned revenues (which are considered contract liabilities) consist primarily of certain customer contracts for which QCT received fees upfront and QTL license fees for intellectual property with continuing performance obligations. In the six months ended March 26, 2023 and March 27, 2022, we recognized revenues of $241 million and $340 million, respectively, that were recorded as unearned revenues at September 25, 2022 and September 26, 2021, respectively.

[0000804328-23-000023:notes:14]
Remaining performance obligations, which are primarily included in unearned revenues (as presented on our condensed consolidated balance sheet), represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements.

[0000804328-23-000023:notes:15]
[same as prior period, unchanged from 0000804328-23-000006:notes:17]

[0000804328-23-000023:notes:16]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | March 26,2023 |  | March 27,2022 |
| Customer/licensee (x) | 27 | % |  | 19 | % |  | 31 | % |  | 22 | % |
| Customer/licensee (y) | 25 |  |  | 19 |  |  | 19 |  |  | 19 |  |
| Customer/licensee (z) | * |  | 10 |  |  | * |  | * |

[0000804328-23-000023:notes:17]
*Less than 10%

[0000804328-23-000023:notes:18]
Other Expenses. Other expenses in the three and six months ended March 26, 2023 consisted of $208 million and $288 million, respectively, in restructuring and restructuring-related charges, substantially all of which related to severance costs, resulting from certain cost reduction initiatives committed to in fiscal 2023. We expect these actions to be substantially completed (including payments of the related severance) by the end of fiscal 2023. We may incur additional restructuring and restructuring-related charges, as the actual amount of costs may differ from our current expectations and estimates, and as we further evaluate our operating expenses.

[0000804328-23-000023:notes:19]
| Investment and Other (Expense) Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | March 26,2023 |  | March 27,2022 |
| Interest and dividend income | $ | 59 |  |  | $ | 20 |  |  | $ | 114 |  |  | $ | 37 |  |
| Net gains (losses) on marketable securities | 9 |  |  | (240) |  |  | 20 |  |  | (223) |  |
| Net (losses) gains on other investments | — |  |  | (21) |  |  | — |  |  | 73 |  |
| Net gains (losses) on deferred compensation plan assets | 21 |  |  | (43) |  |  | 47 |  |  | (30) |  |
| Impairment losses on other investments | (87) |  |  | (20) |  |  | (101) |  |  | (21) |  |
| Other | (18) |  |  | 6 |  |  | (20) |  |  | 6 |  |
|  | $ | (16) |  |  | $ | (298) |  |  | $ | 60 |  |  | $ | (158) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-23-000023:notes:20]
Income Taxes
We estimate our annual effective income tax rate to be 8% for fiscal 2023, which is lower than the U.S. federal statutory rate, primarily due to (i) a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, which includes certain benefits discussed below from the new requirement to capitalize research and development expenditures for federal income tax purposes, (ii) benefits from our federal research and development tax credit and (iii) benefits related to foreign currency gains on a noncurrent receivable related to our refund claim of Korean withholding tax. Our effective tax rate of 10% for the second quarter of fiscal 2023 was higher than our estimated annual effective tax rate of 8% primarily due to foreign currency gains realized in the first quarter of fiscal 2023 on a noncurrent receivable related to our refund claim of Korean withholding tax.

[0000804328-23-000023:notes:21]
Beginning in fiscal 2023, for federal income tax purposes, we are required to capitalize and amortize domestic research and development expenditures over five years and foreign research and development expenditures over fifteen years (such expenditures were previously deducted as incurred). Our cash flows from operations will be adversely affected due to significantly higher cash tax payments. However, since the resulting deferred tax asset is established at the statutory rate of 21% (rather than the effective tax rate of 13% to 16% after considering the FDII deduction), capitalization favorably affects our provision for income taxes and results of operations. The adverse cash flow impact and favorable tax provision impact will diminish in future years as capitalized research and development expenditures continue to amortize.
Income taxes payable (recorded in other current liabilities) were $1.3 billion and $634 million at March 26, 2023 and September 25, 2022, respectively. This increase was primarily due to the recent announcement (IR-2023-33) by the Internal Revenue Service (IRS), which postponed our remaining current year U.S. federal income tax-payment deadlines until October 2023.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-23-000023:notes:22]
Capital Stock
Stock Repurchase Program. On October 12, 2021, we announced a $10.0 billion stock repurchase program. The stock repurchase program has no expiration date. At March 26, 2023, $5.9 billion remained authorized for repurchase under our stock repurchase program.

[0000804328-23-000023:notes:23]
Shares Outstanding. Shares of common stock outstanding at March 26, 2023 were as follows (in millions):

[0000804328-23-000023:notes:24]
| Balance at September 25, 2022 | 1,121 |  |
| Issued | 11 |  |
| Repurchased | (18) |  |
| Balance at March 26, 2023 | 1,114 |  |

[0000804328-23-000023:notes:25]
Dividends. On March 8, 2023, we announced a 7% increase in our quarterly dividend per share of common stock from $0.75 to $0.80, which is effective for dividends payable after March 23, 2023. On April 12, 2023, we announced a cash dividend of $0.80 per share on our common stock, payable on June 22, 2023 to stockholders of record as of the close of business on June 1, 2023.

[0000804328-23-000023:notes:26]
[same as prior period, unchanged from 0000804328-23-000006:notes:27]

[0000804328-23-000023:notes:27]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | March 26,2023 |  | March 27,2022 |
| Dilutive common share equivalents included in diluted shares | 7 |  |  | 16 |  |  | 8 |  |  | 17 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 5 |  |  | — |  |  | 5 |  |  | — |  |


## us-gaap:DebtDisclosureTextBlock

[0000804328-23-000023:notes:28]
Debt
Long-term Debt. In November 2022, we issued unsecured fixed-rate notes, consisting of $700 million of fixed-rate 5.40% notes and $1.2 billion of fixed-rate 6.00% notes (collectively, November 2022 Notes) that mature on May 20, 2033 and May 20, 2053, respectively. The net proceeds from the November 2022 Notes were used to repay $946 million of fixed-rate notes and $500 million of floating-rate notes that matured in January 2023 and the excess will be used for general corporate purposes.

[0000804328-23-000023:notes:29]
At March 26, 2023, the aggregate fair value of our outstanding floating- and fixed-rate notes, based on Level 2 inputs, was approximately $15.1 billion.

[0000804328-23-000023:notes:30]
Interest Rate Swaps. At September 25, 2022, we had outstanding forward-starting interest rate swaps with an aggregate notional amount, denominated in U.S. dollars, of $1.6 billion. During the first quarter of fiscal 2023, in connection with the issuance of the November 2022 Notes, we terminated these swaps, and the related gains of $334 million, included within accumulated comprehensive income, are being recorded as a reduction to interest expense over the hedged portions of the related debt.

[0000804328-23-000023:notes:31]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. At March 26, 2023 and September 25, 2022, we had $499 million of outstanding commercial paper recorded as short-term debt.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-23-000023:notes:32]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0000804328-23-000023:notes:33]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions, and on July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On May 23, 2022, the plaintiffs filed a motion for class certification, and a hearing on the motion was held on October 19, 2022. On March 20, 2023, the court issued an order granting in part and denying in part the plaintiffs’ motion for class certification. The order denied class certification on the basis of alleged misrepresentations relating to our chip-level licensing practices, but certified a class on the basis of alleged misrepresentations relating to the separate operations of QCT and QTL. No trial date has been set.

[0000804328-23-000023:notes:34]
On April 3, 2023, we filed a petition with the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) seeking permission to appeal the district court’s class certification order. We believe the plaintiffs’ claims are without merit.

[0000804328-23-000023:notes:35]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On July 5, 2018, the plaintiffs filed a motion for class certification, and on September 27, 2018, the court granted that motion. We appealed the district court’s class certification order to the Ninth Circuit. On September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class, and remanded the case to the district court. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. On August 1, 2022, we filed a motion to dismiss the amended complaint, and on November 15, 2022, the court held a hearing on our motion. On January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. The order preserved the plaintiffs’ claims related to exclusive dealing under California antitrust and unfair competition laws and dismissed the remainder of the plaintiffs’ claims, which were related to our licensing practices. On April 7, 2023, we filed a motion for summary judgment on the plaintiffs’ remaining claims. A hearing on our motion is scheduled for July 20, 2023. We believe the plaintiffs’ claims are without merit.

[0000804328-23-000023:notes:36]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

[0000804328-23-000023:notes:37]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit. We believe that ParkerVision’s claims are without merit.

[0000804328-23-000023:notes:38]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (ARM) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with ARM (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. The complaint seeks specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology. ARM also contends that we violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of ARM’s trademarks and seeks associated injunctive and declaratory relief. ARM further seeks exemplary or punitive damages, costs, expenses and reasonable attorney’s fees, and equitable relief addressing any infringement occurring after entry of judgment. We believe ARM’s claims are without merit.

[0000804328-23-000023:notes:39]
On September 30, 2022, we filed our Answer and Counterclaim in response to ARM’s complaint denying ARM’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and ARM and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia), server System-on-Chip (SoC) and

[0000804328-23-000023:notes:40]
compute SoC are fully licensed under our existing Architecture License Agreement and Technology License Agreement with ARM (the ARM-Qualcomm Agreements). We further seek an order enjoining ARM from making any claim that our products are not licensed under the ARM-Qualcomm Agreements, are not ARM-compliant or that we are prohibited from using ARM’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements ARM is making in the marketplace concerning our rights under the ARM-Qualcomm Agreements are false, and that ARM has no right to prevent us from shipping our products, which are validly licensed. Trial is scheduled to begin on September 23, 2024.

[0000804328-23-000023:notes:41]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0000804328-23-000023:notes:42]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019, and on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. On April 12, 2023, the Korea Supreme Court delivered its judgment, which dismissed all appeals by both Qualcomm and the KFTC, affirming the judgment of the Seoul High Court. The Korea Supreme Court judgment concludes the appeal process.

[0000804328-23-000023:notes:43]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC did not provide a formal notice on the scope of its investigation, but we believe it concerned our business practices in connection with our sale of RFFE components. On April 18, 2023, the KFTC informed us that it had closed its investigation without finding any violation.

[0000804328-23-000023:notes:44]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision finding that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. From March 13, 2023 to March 15, 2023, the court held a hearing on our appeal. The court has not yet issued a ruling. We believe that our business practices do not violate the European Union (EU) competition rules.

[0000804328-23-000023:notes:45]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to the EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding and included in other current liabilities.

[0000804328-23-000023:notes:46]
Contingent Losses and Other Considerations: We will continue to vigorously defend ourselves in the pending matters described above. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. Other than with respect to the EC fine related to the Icera Complaint to the European Commission, we have not recorded any accrual at March 26, 2023 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-23-000023:notes:47]
Segment Information
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies, including RFFE, for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices; industrial devices; and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our cloud AI inference processing initiative.

[0000804328-23-000023:notes:48]
[same as prior period, unchanged from 0000804328-23-000006:notes:52]

[0000804328-23-000023:notes:49]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | March 26,2023 |  | March 27,2022 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 7,942 |  |  | $ | 9,548 |  |  | $ | 15,834 |  |  | $ | 18,395 |  |
| QTL | 1,290 |  |  | 1,580 |  |  | 2,814 |  |  | 3,398 |  |
| QSI | 7 |  |  | 6 |  |  | 13 |  |  | 14 |  |
| Reconciling items | 36 |  |  | 30 |  |  | 77 |  |  | 61 |  |
| Total | $ | 9,275 |  |  | $ | 11,164 |  |  | $ | 18,738 |  |  | $ | 21,868 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 2,107 |  |  | $ | 3,340 |  |  | $ | 4,291 |  |  | $ | 6,455 |  |
| QTL | 871 |  |  | 1,154 |  |  | 1,988 |  |  | 2,560 |  |
| QSI | (53) |  |  | (269) |  |  | (61) |  |  | (147) |  |
| Reconciling items | (1,030) |  |  | (802) |  |  | (1,952) |  |  | (1,579) |  |
| Total | $ | 1,895 |  |  | $ | 3,423 |  |  | $ | 4,266 |  |  | $ | 7,289 |  |

[0000804328-23-000023:notes:50]
[same as prior period, unchanged from 0000804328-23-000006:notes:54]

[0000804328-23-000023:notes:51]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | March 26,2023 |  | March 27,2022 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 36 |  |  | $ | 30 |  |  | $ | 77 |  |  | $ | 61 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of revenues | $ | (47) |  |  | $ | (53) |  |  | $ | (112) |  |  | $ | (106) |  |
| Unallocated research and development expenses | (494) |  |  | (433) |  |  | (1,018) |  |  | (886) |  |
| Unallocated selling, general and administrative expenses | (126) |  |  | (138) |  |  | (292) |  |  | (292) |  |
| Unallocated other expenses (Note 2) | (208) |  |  | — |  |  | (288) |  |  | — |  |
| Unallocated interest expense | (178) |  |  | (137) |  |  | (348) |  |  | (275) |  |
| Unallocated investment and other income (expense), net | 36 |  |  | (34) |  |  | 123 |  |  | (11) |  |
| Nonreportable segments | (13) |  |  | (7) |  |  | (17) |  |  | (9) |  |
|  | $ | (1,030) |  |  | $ | (802) |  |  | $ | (1,952) |  |  | $ | (1,579) |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000804328-23-000023:notes:52]
[same as prior period, unchanged from 0000804328-23-000006:notes:56]

[0000804328-23-000023:notes:53]
At March 26, 2023, we had agreed to provide certain funding of approximately $300 million to the Non-Arriver businesses while SSW Partners sells these businesses, of which approximately $50 million of funding remained available to the Non-Arriver businesses. Such amounts, along with cash retained in the Non-Arriver businesses, are expected to be used to fund working and other near-term capital needs, as well as certain costs incurred in connection with the close of the acquisition.

[0000804328-23-000023:notes:54]
Although we do not own or operate the Non-Arriver businesses, we are the primary beneficiary, within the meaning of the Financial Accounting Standards Board (FASB) accounting guidance related to consolidation (ASC 810), of these businesses under the variable interest model. Factors considered in reaching this conclusion included, among others: (i) our involvement in the design of and our funding of substantially all of the total cash consideration payable in the transaction and (ii) our obligations to absorb losses and rights to receive returns from the Non-Arriver businesses.

[0000804328-23-000023:notes:55]
In December 2022, Magna entered into a definitive agreement to acquire the Active Safety business from SSW Partners for approximately $1.5 billion in cash, subject to working capital and other purchase price adjustments. The sale is subject to certain regulatory approvals and other customary closing conditions. We expect that SSW Partners will complete the sale of both Non-Arriver businesses within fiscal 2023, subject to any required regulatory approvals and other closing conditions being met. Accordingly, the assets and liabilities of the Non-Arriver businesses (the majority of which relate to the Active Safety business) are consolidated and presented as held for sale on our condensed consolidated balance sheet, and the operating results are presented as discontinued operations.

[0000804328-23-000023:notes:56]
[same as prior period, unchanged from 0000804328-23-000006:notes:60]

[0000804328-23-000023:notes:57]
The allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0000804328-23-000023:notes:58]
| Cash | $ | 30 |  |
| Current held for sale assets, net of costs to sell (1) | 626 |  |
| Completed technology-based intangible assets | 349 |  |
| In-process research and development (IPR&D) | 298 |  |
| Goodwill | 2,793 |  |
| Noncurrent held for sale assets (1) | 1,186 |  |
| Other assets | 326 |  |
| Total assets | 5,608 |  |
| Current held for sale liabilities (1) | (677) |  |
| Convertible senior notes | (352) |  |
| Noncurrent held for sale liabilities (1) | (128) |  |
| Other liabilities | (200) |  |
| Total liabilities | (1,357) |  |
| Net assets acquired | $ | 4,251 |  |

[0000804328-23-000023:notes:59]
(1) Held for sale assets and liabilities relate to the Non-Arriver businesses and were measured at fair value less costs to sell (including SSW Partners’ estimated return with respect to the sale proceeds of the Non-Arriver businesses), which was estimated using a market approach based on significant inputs that were not observable. The Non-Arriver businesses’ assets are not available to be used to settle our obligations, and the Non-Arriver businesses’ creditors do not have recourse to us. SSW Partners owns and operates the Non-Arriver businesses, and its funding of the purchase price for Veoneer was recorded as a component of held for sale liabilities. The underlying classes of assets and liabilities held for sale have not been presented because such amounts are not material.

[0000804328-23-000023:notes:60]
Goodwill related to this transaction was allocated to our QCT segment, $471 million of which is expected to be deductible for tax purposes. Goodwill is primarily attributable to assembled workforce and certain synergies expected to arise after the acquisition. Completed technology-based intangible assets will be amortized on a straight-line basis over the weighted-average useful life of nine years. IPR&D relates to a single project that is expected to be completed in fiscal 2025. Upon completion, we expect the IPR&D to be amortized over its useful life of seven years. We valued the completed technology and IPR&D using an income approach based on significant unobservable inputs.

[0000804328-23-000023:notes:61]
The Non-Arriver businesses are presented as discontinued operations on a one quarter reporting lag. Pro forma results of operations have not been presented because the effects of this acquisition were not material to our consolidated results of operations. The cash flows used by the Non-Arriver businesses are reflected as discontinued operations and are classified as operating, investing and financing activities in the consolidated statements of cash flows.


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-23-000023:notes:62]
Fair Value Measurements and Marketable Securities
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at March 26, 2023 (in millions):

[0000804328-23-000023:notes:63]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 1,779 |  |  | $ | 367 |  |  | $ | — |  |  | $ | 2,146 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 2,943 |  |  | — |  |  | 2,943 |  |
| Equity securities | 145 |  |  | — |  |  | — |  |  | 145 |  |
| Mortgage- and asset-backed securities | — |  |  | 84 |  |  | — |  |  | 84 |  |
| U.S. Treasury securities and government-related securities | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total marketable securities | 145 |  |  | 3,043 |  |  | — |  |  | 3,188 |  |
| Derivative instruments | — |  |  | 37 |  |  | — |  |  | 37 |  |
| Other investments | 731 |  |  | — |  |  | 20 |  |  | 751 |  |
| Total assets measured at fair value | $ | 2,655 |  |  | $ | 3,447 |  |  | $ | 20 |  |  | $ | 6,122 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 210 |  |  | $ | — |  |  | $ | 210 |  |
| Other liabilities | 730 |  |  | — |  |  | — |  |  | 730 |  |
| Total liabilities measured at fair value | $ | 730 |  |  | $ | 210 |  |  | $ | — |  |  | $ | 940 |  |

[0000804328-23-000023:notes:64]
At March 26, 2023 and September 25, 2022, our marketable securities were all classified as current and were primarily comprised of available-for-sale debt securities (substantially all of which were corporate bonds and notes).

[0000804328-23-000023:notes:65]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0000804328-23-000023:notes:66]
|  | March 26,2023 |
| Years to Maturity |  |
| Less than one year | $ | 1,463 |  |
| One to five years | 1,496 |  |
| No single maturity date | 84 |  |
| Total | $ | 3,043 |  |

[0000804328-23-000023:notes:67]
Debt securities with no single maturity date included mortgage- and asset-backed securities.
