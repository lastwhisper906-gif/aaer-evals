# QCOM MD&A — 0000804328-23-000023


## mdna

[0000804328-23-000023:mdna:1]
[same as prior period, unchanged from 0000804328-23-000006:mdna:1]

[0000804328-23-000023:mdna:2]
[same as prior period, unchanged from 0000804328-23-000006:mdna:2]

[0000804328-23-000023:mdna:3]
[same as prior period, unchanged from 0000804328-23-000006:mdna:3]

[0000804328-23-000023:mdna:4]
Second Quarter Fiscal 2023 Overview

[0000804328-23-000023:mdna:5]
Revenues for the second quarter of fiscal 2023 were $9.3 billion, a decrease of 17% compared to the year ago quarter, with net income of $1.7 billion, a decrease of 42% compared to the year ago quarter. Key items from the second quarter of fiscal 2023 included:

[0000804328-23-000023:mdna:6]
•QCT and QTL revenues were negatively impacted by the weakness in the macroeconomic environment (which negatively impacted consumer demand for smartphones and other devices that incorporate our products and technologies) and our customers drawing down on their inventory (which is at elevated levels given the rapid deceleration in consumer demand and the easing of supply constraints that occurred during the second half of calendar 2022).

[0000804328-23-000023:mdna:7]
•QCT revenues decreased by 17% in the second quarter of fiscal 2023 compared to the year ago quarter due to lower handset and IoT revenues, partially offset by higher automotive revenues.

[0000804328-23-000023:mdna:8]
•QTL revenues decreased by 18% in the second quarter of fiscal 2023 compared to the year ago quarter.

[0000804328-23-000023:mdna:9]
[same as prior period, unchanged from 0000804328-23-000006:mdna:9]

[0000804328-23-000023:mdna:10]
[same as prior period, unchanged from 0000804328-23-000006:mdna:10]

[0000804328-23-000023:mdna:11]
[same as prior period, unchanged from 0000804328-23-000006:mdna:11]

[0000804328-23-000023:mdna:12]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Substantially all of our

[0000804328-23-000023:mdna:13]
21

[0000804328-23-000023:mdna:14]
products and services businesses, including QCT, and substantially all of our engineering and research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0000804328-23-000023:mdna:15]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when licensees’ sales occur. These trends may or may not continue in the future.

[0000804328-23-000023:mdna:16]
[same as prior period, unchanged from 0000804328-23-000006:mdna:16]

[0000804328-23-000023:mdna:17]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | Change |  | March 26,2023 |  | March 27,2022 |  | Change |
| Equipment and services | $ | 7,846 |  |  | $ | 9,417 |  |  | $ | (1,571) |  |  | $ | 15,630 |  |  | $ | 18,098 |  |  | $ | (2,468) |  |
| Licensing | 1,429 |  |  | 1,747 |  |  | (318) |  |  | 3,108 |  |  | 3,770 |  |  | (662) |  |
|  | $ | 9,275 |  |  | $ | 11,164 |  |  | $ | (1,889) |  |  | $ | 18,738 |  |  | $ | 21,868 |  |  | $ | (3,130) |  |

[0000804328-23-000023:mdna:18]
Second quarter 2023 vs. 2022

[0000804328-23-000023:mdna:19]
The decrease in revenues in the second quarter of fiscal 2023 was primarily due to:

[0000804328-23-000023:mdna:20]
-    $1.6 billion in lower equipment and services revenues from our QCT segment

[0000804328-23-000023:mdna:21]
-    $290 million in lower licensing revenues from our QTL segment

[0000804328-23-000023:mdna:22]
First six months 2023 vs. 2022

[0000804328-23-000023:mdna:23]
The decrease in revenues in the first six months of fiscal 2023 was primarily due to:

[0000804328-23-000023:mdna:24]
-    $2.5 billion in lower equipment and services revenues from our QCT segment

[0000804328-23-000023:mdna:25]
-    $584 million in lower licensing revenues from our QTL segment

[0000804328-23-000023:mdna:26]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | Change |  | March 26,2023 |  | March 27,2022 |  | Change |
| Cost of revenues | $ | 4,153 |  |  | $ | 4,648 |  |  | $ | (495) |  |  | $ | 8,197 |  |  | $ | 8,951 |  |  | $ | (754) |  |
| Gross margin | 55 | % |  | 58 | % |  |  |  | 56 | % |  | 59 | % |  |  |

[0000804328-23-000023:mdna:27]
Second quarter and first six months 2023 vs. 2022

[0000804328-23-000023:mdna:28]
Gross margin percentage decreased in the second quarter and first six months of fiscal 2023 primarily due to a decrease in QCT gross margin.

[0000804328-23-000023:mdna:29]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | Change |  | March 26,2023 |  | March 27,2022 |  | Change |
| Research and development | $ | 2,210 |  |  | $ | 2,034 |  |  | $ | 176 |  |  | $ | 4,461 |  |  | $ | 3,963 |  |  | $ | 498 |  |
| % of revenues | 24 | % |  | 18 | % |  |  |  | 24 | % |  | 18 | % |  |  |

[0000804328-23-000023:mdna:30]
Second quarter 2023 vs. 2022

[0000804328-23-000023:mdna:31]
The increase in research and development expenses in the second quarter of fiscal 2023 was primarily due to:

[0000804328-23-000023:mdna:32]
+    $106 million increase in share-based compensation expense

[0000804328-23-000023:mdna:33]
+    $33 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), primarily driven by an increase in employee-related expenses (which included lower employee cash incentive program costs)

[0000804328-23-000023:mdna:34]
First six months 2023 vs. 2022

[0000804328-23-000023:mdna:35]
The increase in research and development expenses in the first six months of fiscal 2023 was primarily due to:

[0000804328-23-000023:mdna:36]
+    $237 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), primarily driven by an increase in employee-related expenses (which included lower employee cash incentive program costs)

[0000804328-23-000023:mdna:37]
+    $216 million increase in share-based compensation expense

[0000804328-23-000023:mdna:38]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | Change |  | March 26,2023 |  | March 27,2022 |  | Change |
| Selling, general and administrative | $ | 614 |  |  | $ | 624 |  |  | $ | (10) |  |  | $ | 1,238 |  |  | $ | 1,232 |  |  | $ | 6 |  |
| % of revenues | 7 | % |  | 6 | % |  |  |  | 7 | % |  | 6 | % |  |  |

[0000804328-23-000023:mdna:39]
Second quarter and first six months 2023 vs. 2022

[0000804328-23-000023:mdna:40]
Selling, general and administrative expenses in the second quarter and first six months of fiscal 2023 remained largely flat.

[0000804328-23-000023:mdna:41]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | Change |  | March 26,2023 |  | March 27,2022 |  | Change |
| Other expense | $ | 208 |  |  | $ | — |  |  | $ | 208 |  |  | $ | 288 |  |  | $ | — |  |  | $ | 288 |  |

[0000804328-23-000023:mdna:42]
Second quarter and first six months 2023 vs. 2022

[0000804328-23-000023:mdna:43]
Other expense in the second quarter and first six months of fiscal 2023 consisted of restructuring and restructuring-related charges, substantially all of which related to severance costs, resulting from certain cost reduction initiatives committed to in fiscal 2023. Additional information regarding our restructuring charges is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Other Expenses.”

[0000804328-23-000023:mdna:44]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | Change |  | March 26,2023 |  | March 27,2022 |  | Change |
| Interest expense | $ | 179 |  |  | $ | 137 |  |  | $ | 42 |  |  | $ | 348 |  |  | $ | 275 |  |  | $ | 73 |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 59 |  |  | $ | 20 |  |  | $ | 39 |  |  | $ | 114 |  |  | $ | 37 |  |  | $ | 77 |  |
| Net gains (losses) on marketable securities | 9 |  |  | (240) |  |  | 249 |  |  | 20 |  |  | (223) |  |  | 243 |  |
| Net (losses) gains on other investments | — |  |  | (21) |  |  | 21 |  |  | — |  |  | 73 |  |  | (73) |  |
| Net gains (losses) on deferred compensation plan assets | 21 |  |  | (43) |  |  | 64 |  |  | 47 |  |  | (30) |  |  | 77 |  |
| Impairment losses on other investments | (87) |  |  | (20) |  |  | (67) |  |  | (101) |  |  | (21) |  |  | (80) |  |
| Other | (18) |  |  | 6 |  |  | (24) |  |  | (20) |  |  | 6 |  |  | (26) |  |
|  | $ | (16) |  |  | $ | (298) |  |  | $ | 282 |  |  | $ | 60 |  |  | $ | (158) |  |  | $ | 218 |  |

[0000804328-23-000023:mdna:45]
Net losses on marketable securities for the three and six months ended March 27, 2022 was primarily driven by the change in fair value of certain of our QSI marketable equity investments in early or growth stage companies.

[0000804328-23-000023:mdna:46]
[same as prior period, unchanged from 0000804328-23-000006:mdna:38]

[0000804328-23-000023:mdna:47]
[same as prior period, unchanged from 0000804328-23-000006:mdna:39]

[0000804328-23-000023:mdna:48]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | March 26,2023 |  | March 27,2022 |
| Expected income tax provision at federal statutory tax rate | $ | 398 |  |  | $ | 719 |  |  | $ | 896 |  |  | $ | 1,531 |  |
| Benefit from foreign-derived intangible income (FDII) deduction related to capitalizing research and development expenditures | (140) |  |  | — |  |  | (252) |  |  | — |  |
| Benefit from FDII deduction, excluding the impact of capitalizing research and development expenditures | (88) |  |  | (203) |  |  | (209) |  |  | (344) |  |
| Benefit related to the research and development tax credit | (68) |  |  | (46) |  |  | (122) |  |  | (104) |  |
| Foreign currency losses (gains) related to foreign withholding tax receivable | 17 |  |  | 36 |  |  | (113) |  |  | 48 |  |
| Shortfall (excess) tax benefit associated with share-based awards | 2 |  |  | (27) |  |  | (21) |  |  | (215) |  |
| Other | 72 |  |  | 10 |  |  | 112 |  |  | 40 |  |
| Income tax expense | $ | 193 |  |  | $ | 489 |  |  | $ | 291 |  |  | $ | 956 |  |
| Effective tax rate | 10 | % |  | 14 | % |  | 7 | % |  | 13 | % |

[0000804328-23-000023:mdna:49]
We estimate our annual effective income tax rate to be 8% for fiscal 2023, which is lower than the U.S. federal statutory rate. Additional information regarding our annual effective income tax rate and income tax expense (including discussion related to the impact of the new requirement to capitalize research and development expenditures for federal income tax purposes) is provided in this Quarterly Report in “Notes to Condensed Consolidated Statements, Note. 3 Income Taxes.”

[0000804328-23-000023:mdna:50]
| Discontinued Operations (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | Change |  | March 26,2023 |  | March 27,2022 |  | Change |
| Discontinued operations, net of income taxes | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |  | $ | (36) |  |  | $ | — |  |  | $ | (36) |  |

[0000804328-23-000023:mdna:51]
[same as prior period, unchanged from 0000804328-23-000006:mdna:37]

[0000804328-23-000023:mdna:52]
Discontinued operations in the second quarter and first six months of fiscal 2023 related to net income (losses) from the Non-Arriver businesses. Information regarding the Non-Arriver businesses is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 8. Acquisitions.”

[0000804328-23-000023:mdna:53]
[same as prior period, unchanged from 0000804328-23-000006:mdna:45]

[0000804328-23-000023:mdna:54]
The following should be read in conjunction with our financial results for the second quarter of fiscal 2023 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0000804328-23-000023:mdna:55]
[same as prior period, unchanged from 0000804328-23-000006:mdna:47]

[0000804328-23-000023:mdna:56]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | Change |  | March 26,2023 |  | March 27,2022 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets | $ | 6,105 |  |  | $ | 7,349 |  |  | $ | (1,244) |  |  | $ | 11,860 |  |  | $ | 14,338 |  |  | $ | (2,478) |  |
| Automotive | 447 |  |  | 371 |  |  | 76 |  |  | 903 |  |  | 659 |  |  | 244 |  |
| IoT (internet of things) | 1,390 |  |  | 1,828 |  |  | (438) |  |  | 3,071 |  |  | 3,398 |  |  | (327) |  |
| Total revenues (1) | $ | 7,942 |  |  | $ | 9,548 |  |  | $ | (1,606) |  |  | $ | 15,834 |  |  | $ | 18,395 |  |  | $ | (2,561) |  |
| EBT (2) | $ | 2,107 |  |  | $ | 3,340 |  |  | $ | (1,233) |  |  | $ | 4,291 |  |  | $ | 6,455 |  |  | $ | (2,164) |  |
| EBT as a % of revenues | 27 | % |  | 35 | % |  | -8 points |  | 27 | % |  | 35 | % |  | -8 points |

[0000804328-23-000023:mdna:57]
(1) Beginning in the first quarter of fiscal 2023, QCT RFFE (radio frequency front-end) revenues, which were previously presented as a separate revenue stream, are now included within our Handset, Automotive and internet of things (IoT) revenue streams, as applicable, based on the industry and application in which the related RFFE products are sold. Prior period information has been recast to reflect this change. Descriptions of our three QCT revenue streams can be found in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Item.”

[0000804328-23-000023:mdna:58]
(2) Earnings (loss) before income taxes.

[0000804328-23-000023:mdna:59]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $7.8 billion and $9.4 billion in the second quarter of fiscal 2023 and 2022, respectively and $15.5 billion and $18.0 billion in the first six months of fiscal 2023 and 2022, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets as well as sales of 4G, 5G sub 6 and 5G millimeter wave RFFE products.

[0000804328-23-000023:mdna:60]
Second quarter 2023 vs. 2022

[0000804328-23-000023:mdna:61]
The decrease in QCT revenues in the second quarter of fiscal 2023 was primarily due to:

[0000804328-23-000023:mdna:62]
-    lower handsets revenues, primarily driven by $1.5 billion in lower chipset shipments to certain major OEMs (primarily driven by the negative effects of the macroeconomic environment weakness and customers drawing down on their elevated inventory levels), partially offset by $498 million in higher revenues per chipset primarily driven by increases in average selling prices

[0000804328-23-000023:mdna:63]
-    lower IoT revenues, primarily driven by a decrease in demand across consumer, edge networking and industrial products (primarily driven by the negative effects of the macroeconomic environment weakness and customers drawing down on their elevated inventory levels)

[0000804328-23-000023:mdna:64]
[same as prior period, unchanged from 0000804328-23-000006:mdna:58]

[0000804328-23-000023:mdna:65]
QCT EBT as a percentage of revenues decreased in the second quarter of fiscal 2023 primarily due to:

[0000804328-23-000023:mdna:66]
[same as prior period, unchanged from 0000804328-23-000006:mdna:61]

[0000804328-23-000023:mdna:67]
-    lower gross margin percentage, primarily driven by increased product costs and unfavorable mix, partially offset by increases in average selling prices

[0000804328-23-000023:mdna:68]
[same as prior period, unchanged from 0000804328-23-000006:mdna:63]

[0000804328-23-000023:mdna:69]
First six months 2023 vs. 2022

[0000804328-23-000023:mdna:70]
The decrease in QCT revenues in the first six months of fiscal 2023 was primarily due to:

[0000804328-23-000023:mdna:71]
-    lower handsets revenues, primarily driven by $3.1 billion in lower chipset shipments to certain major OEMs (primarily driven by the negative effects of the macroeconomic environment weakness and customers drawing down on their elevated inventory levels), partially offset by $845 million in higher revenues per chipset primarily driven by increases in average selling prices

[0000804328-23-000023:mdna:72]
-    lower IoT revenues, primarily driven by a decrease in demand across consumer and edge networking products (primarily driven by the negative effects of the macroeconomic environment weakness and customers drawing down on their elevated inventory levels)

[0000804328-23-000023:mdna:73]
+    higher automotive revenues, primarily driven by an increase in demand for digital cockpit products

[0000804328-23-000023:mdna:74]
QCT EBT as a percentage of revenues decreased in the first six months of fiscal 2023 primarily due to:

[0000804328-23-000023:mdna:75]
-    lower revenues

[0000804328-23-000023:mdna:76]
-    lower gross margin percentage, primarily driven by increased product costs and unfavorable mix, partially offset by increases in average selling prices

[0000804328-23-000023:mdna:77]
-    higher operating expenses, primarily driven by higher research and development expenses

[0000804328-23-000023:mdna:78]
[same as prior period, unchanged from 0000804328-23-000006:mdna:65]

[0000804328-23-000023:mdna:79]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | Change |  | March 26,2023 |  | March 27,2022 |  | Change |
| Licensing revenues | $ | 1,290 |  |  | $ | 1,580 |  |  | $ | (290) |  |  | $ | 2,814 |  |  | $ | 3,398 |  |  | $ | (584) |  |
| EBT | 871 |  |  | 1,154 |  |  | (283) |  |  | 1,988 |  |  | 2,560 |  |  | (572) |  |
| EBT as a % of revenues | 68 | % |  | 73 | % |  | -5 points |  | 71 | % |  | 75 | % |  | -4 points |

[0000804328-23-000023:mdna:80]
Second quarter 2023 vs. 2022

[0000804328-23-000023:mdna:81]
The decrease in QTL licensing revenues in the second quarter of fiscal 2023 was primarily due to:

[0000804328-23-000023:mdna:82]
-    $192 million decrease in volume of estimated sales of 3G/4G/5G-based multimode products, primarily driven by the macroeconomic environment weakness

[0000804328-23-000023:mdna:83]
-    $68 million decrease in revenues from the ending of the recognition of certain upfront license fee consideration in the first quarter of fiscal 2023 from our long-term license agreement with Nokia

[0000804328-23-000023:mdna:84]
QTL EBT as a percentage of revenues decreased in the second quarter of fiscal 2023 primarily due to lower revenues.

[0000804328-23-000023:mdna:85]
First six months 2023 vs. 2022

[0000804328-23-000023:mdna:86]
The decrease in QTL licensing revenues in the first six months of fiscal 2023 was primarily due to:

[0000804328-23-000023:mdna:87]
-    $506 million decrease in volume of estimated sales of 3G/4G/5G-based multimode products, primarily driven by the macroeconomic environment weakness

[0000804328-23-000023:mdna:88]
-    $68 million decrease in revenues from the ending of the recognition of certain upfront license fee consideration in the first quarter of fiscal 2023 from our long-term license agreement with Nokia

[0000804328-23-000023:mdna:89]
QTL EBT as a percentage of revenues decreased in the first six months of fiscal 2023 primarily due to lower revenues.

[0000804328-23-000023:mdna:90]
[same as prior period, unchanged from 0000804328-23-000006:mdna:70]

[0000804328-23-000023:mdna:91]
|  | Three Months Ended |  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | Change |  | March 26,2023 |  | March 27,2022 |  | Change |
| Equipment and services revenues | $ | 7 |  |  | $ | 6 |  |  | $ | 1 |  |  | $ | 13 |  |  | $ | 14 |  |  | $ | (1) |  |
| Loss before income taxes | (53) |  |  | (269) |  |  | 216 |  |  | (61) |  |  | (147) |  |  | 86 |  |

[0000804328-23-000023:mdna:92]
Second quarter and first six months of 2023 vs. 2022

[0000804328-23-000023:mdna:93]
QSI loss before income taxes in the second quarter and first six months of fiscal 2023 was primarily driven by impairment losses on certain equity investments.

[0000804328-23-000023:mdna:94]
QSI loss before income taxes in the second quarter and first six months of fiscal 2022 was primarily driven by losses on marketable securities resulting from the change in fair value of certain of our marketable equity investments in early or growth stage companies.

[0000804328-23-000023:mdna:95]
[same as prior period, unchanged from 0000804328-23-000006:mdna:74]

[0000804328-23-000023:mdna:96]
In the coming years, we expect consumer demand for 3G/4G/5G multimode and 5G products and services to continue to ramp around the world as we continue to transition from 3G/4G multimode and 4G products and services. We believe that 5G combined with high-performance, low-power processing and on-device intelligence will continue to drive adoption of certain technologies that are already commonly used in smartphones by industries and applications beyond mobile handsets, such as automotive and IoT. We believe it is important that we remain a leader in 5G technology development, standardization,

[0000804328-23-000023:mdna:97]
intellectual property creation and licensing, and a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long-term.

[0000804328-23-000023:mdna:98]
[same as prior period, unchanged from 0000804328-23-000006:mdna:76]

[0000804328-23-000023:mdna:99]
•We expect the current macroeconomic environment challenges to continue (which will negatively impact demand for smartphones and other devices that incorporate our products and technologies) and that our customers will continue to draw down on their inventory (which is at elevated levels given the rapid deceleration in demand and the easing of supply constraints that occurred during the second half of calendar 2022), and that both of these dynamics will continue to have a negative impact on our revenues, results of operations and cash flows compared to the prior year, and will impact our historical QCT seasonal trends. These dynamics have also contributed to our elevated inventory levels and contribute to the inherent uncertainties in estimating future customer demand, which may increase excess or obsolete inventory or reserve charges if we overestimate such demand, negatively impacting our results of operations and cash flows.

[0000804328-23-000023:mdna:100]
•We expect to continue to see price increases from certain of our key semiconductor wafer suppliers compared to the prior year.

[0000804328-23-000023:mdna:101]
[same as prior period, unchanged from 0000804328-23-000006:mdna:79]

[0000804328-23-000023:mdna:102]
[same as prior period, unchanged from 0000804328-23-000006:mdna:80]

[0000804328-23-000023:mdna:103]
[same as prior period, unchanged from 0000804328-23-000006:mdna:81]

[0000804328-23-000023:mdna:104]
[same as prior period, unchanged from 0000804328-23-000006:mdna:83]

[0000804328-23-000023:mdna:105]
[same as prior period, unchanged from 0000804328-23-000006:mdna:84]

[0000804328-23-000023:mdna:106]
[same as prior period, unchanged from 0000804328-23-000006:mdna:85]

[0000804328-23-000023:mdna:107]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at March 26, 2023 and September 25, 2022 and for the first six months of fiscal 2023 and 2022 (in millions):

[0000804328-23-000023:mdna:108]
|  | March 26,2023 |  | September 25,2022 |  | Change |  |  |
| Cash and cash equivalents (1) | $ | 3,488 |  |  | $ | 2,773 |  |  | $ | 715 |  |  |  |
| Marketable securities | 3,188 |  |  | 3,609 |  |  | (421) |  |  |  |
| Cash, cash equivalents and marketable securities | $ | 6,676 |  |  | $ | 6,382 |  |  | $ | 294 |  |  |  |

[0000804328-23-000023:mdna:109]
(1) Excludes $294 million and $326 million of cash and cash equivalents classified as held for sale (included in other current assets) at March 26, 2023 and September 25, 2022, respectively.

[0000804328-23-000023:mdna:110]
|  | Six Months Ended |
|  | March 26,2023 |  | March 27,2022 |  | Change |  |  |
| Net cash provided by operating activities | $ | 4,552 |  |  | $ | 4,755 |  |  | $ | (203) |  |  |  |
| Net cash used by investing activities | (357) |  |  | (638) |  |  | 281 |  |  |  |
| Net cash used by financing activities | (3,558) |  |  | (4,044) |  |  | 486 |  |  |  |

[0000804328-23-000023:mdna:111]
Cash, cash equivalents and marketable securities. The net increase in cash, cash equivalents and marketable securities was primarily due to net cash provided by operating activities and the issuance of $1.9 billion of unsecured fixed-rate notes (additional information regarding our issuance of debt is provided in this Quarterly Report in “Notes to Condensed

[0000804328-23-000023:mdna:112]
27

[0000804328-23-000023:mdna:113]
Consolidated Financial Statements, Note 5. Debt”) and $232 million in proceeds from the issuance of common stock (primarily under our Employee Stock Purchase Plan), partially offset by $2.2 billion in payments to repurchase 18 million shares of our common stock, $1.7 billion in cash dividends paid, $1.4 billion repayments of notes that matured in January 2023, $851 million in capital expenditures and $332 million in payments of tax withholdings related to the vesting of share-based awards.

[0000804328-23-000023:mdna:114]
Net changes in our operating assets and liabilities negatively impacted our operating cash flows primarily due to lower operating liabilities and higher inventory resulting primarily from lower customer demand and the impact of timing of related payments. We expect to continue to see elevated inventory levels in the near term. These negative impacts were partially offset by a decrease in accounts receivable primarily as a result of lower revenues and a decrease in other assets primarily driven by utilization of prior advanced supply agreement payments and certain settlement payments received associated with our forward starting interest rate swaps.

[0000804328-23-000023:mdna:115]
Capital Return Program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time.

[0000804328-23-000023:mdna:116]
On March 8, 2023, we announced a 7% increase in our quarterly dividend per share of common stock from $0.75 to $0.80, which is effective for dividends payable after March 23, 2023. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors. Additional information regarding our capital returns is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 4. Capital Stock.”

[0000804328-23-000023:mdna:117]
Debt. During the second quarter of fiscal 2023, we amended our Revolving Credit Facility, which provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.3 billion (compared to $4.5 billion prior to the amendment), which expires on December 8, 2025. At March 26, 2023, no amounts were outstanding under the Revolving Credit Facility.

[0000804328-23-000023:mdna:118]
Income Taxes. Beginning in fiscal 2023, for federal income tax purposes, we are required to capitalize and amortize domestic research and development expenditures over five years and foreign research and development expenditures over fifteen years (such expenditures were previously deducted as incurred). Our cash flows from operations will be adversely affected due to significantly higher cash tax payments. We estimate the additional cash tax impact related to fiscal 2023 to be approximately $1.1 billion. Due to the recent announcement by the IRS, our remaining current year U.S. federal income tax-payment deadlines have been postponed until October 2023. Additional information regarding our income taxes is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes.”

[0000804328-23-000023:mdna:119]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2022 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At March 26, 2023, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements”, “Looking Forward” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2022 Annual Report on Form 10-K.

[0000804328-23-000023:mdna:120]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0000804328-23-000023:mdna:121]
[same as prior period, unchanged from 0000804328-23-000006:mdna:102]

[0000804328-23-000023:mdna:122]
[same as prior period, unchanged from 0000804328-23-000006:mdna:103]

[0000804328-23-000023:mdna:123]
You should consider each of the following factors in evaluating our business and our prospects, any of which could negatively impact our business, results of operations, cash flows and financial condition, and require significant management time and attention. Further, the risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also negatively impact our business,

[0000804328-23-000023:mdna:124]
results of operations, cash flows and financial condition, and require significant management time and attention. In such cases, the trading price of our common stock could decline. You should also consider the other information set forth in this Quarterly Report in evaluating our business and our prospects, including but not limited to our financial statements and the related notes, and “Part I, Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” References to “and,” “or” and “and/or” should be read to include the others, as appropriate.

[0000804328-23-000023:mdna:125]
[same as prior period, unchanged from 0000804328-23-000006:mdna:105]

[0000804328-23-000023:mdna:126]
[same as prior period, unchanged from 0000804328-23-000006:mdna:106]

[0000804328-23-000023:mdna:127]
We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. Certain Chinese OEMs continue to grow their device share in China and are increasing their device share in regions outside of China, and we derive a significant portion of our revenues from a small number of these OEMs as well. See also “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Concentrations.”

[0000804328-23-000023:mdna:128]
[same as prior period, unchanged from 0000804328-23-000006:mdna:109]

[0000804328-23-000023:mdna:129]
[same as prior period, unchanged from 0000804328-23-000006:mdna:110]

[0000804328-23-000023:mdna:130]
[same as prior period, unchanged from 0000804328-23-000006:mdna:111]

[0000804328-23-000023:mdna:131]
[same as prior period, unchanged from 0000804328-23-000006:mdna:112]

[0000804328-23-000023:mdna:132]
[same as prior period, unchanged from 0000804328-23-000006:mdna:113]

[0000804328-23-000023:mdna:133]
[same as prior period, unchanged from 0000804328-23-000006:mdna:114]

[0000804328-23-000023:mdna:134]
Our industry has also experienced slowing growth in the premium-tier device segment due to, among other factors, a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and innovation

[0000804328-23-000023:mdna:135]
cycles. A reduction in sales of premium-tier devices, a reduction in sales of our premium-tier integrated circuit products (which have a higher revenue and margin contribution than our lower-tier integrated circuit products), or a shift in share away from OEMs that utilize our premium-tier products, would reduce our revenues and margins and may harm our ability to achieve or sustain expected financial results. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0000804328-23-000023:mdna:136]
[same as prior period, unchanged from 0000804328-23-000006:mdna:116]

[0000804328-23-000023:mdna:137]
Although we have more than 300 licensees, we derive a significant portion of our licensing revenues from a limited number of licensees, which includes a number of Chinese OEMs. In the event that one or more of our significant licensees fail to meet their reporting and payment obligations, or we are unable to renew or modify one or more of their license agreements under similar terms as their existing agreements, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We do not have control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in sales of our licensees’ products, or reductions in the average selling prices of such products without a sufficient increase in the volumes sold, would generally have an adverse effect on our licensing revenues.

[0000804328-23-000023:mdna:138]
[same as prior period, unchanged from 0000804328-23-000006:mdna:119]

[0000804328-23-000023:mdna:139]
[same as prior period, unchanged from 0000804328-23-000006:mdna:120]

[0000804328-23-000023:mdna:140]
[same as prior period, unchanged from 0000804328-23-000006:mdna:121]

[0000804328-23-000023:mdna:141]
[same as prior period, unchanged from 0000804328-23-000006:mdna:122]

[0000804328-23-000023:mdna:142]
[same as prior period, unchanged from 0000804328-23-000006:mdna:123]

[0000804328-23-000023:mdna:143]
[same as prior period, unchanged from 0000804328-23-000006:mdna:124]

[0000804328-23-000023:mdna:144]
[same as prior period, unchanged from 0000804328-23-000006:mdna:125]

[0000804328-23-000023:mdna:145]
[same as prior period, unchanged from 0000804328-23-000006:mdna:126]

[0000804328-23-000023:mdna:146]
Due to various factors, including pressure, encouragement or incentives from, or policies of, the Chinese government (including its Made in China 2025 campaign), concerns over losing access to our integrated circuit products as a result of actual, threatened or potential U.S. or Chinese government actions or policies, including trade protection or national security

[0000804328-23-000023:mdna:147]
policies, or other reasons, some of our Chinese integrated circuit customers have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products in their devices, or use our competitors’ integrated circuit products in their devices, rather than our products, which could materially harm our business, revenues, results of operations, cash flows and financial position. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0000804328-23-000023:mdna:148]
Political actions, including trade protection and national security policies of the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our Chinese customers or suppliers, limit, prevent or discourage certain of our Chinese customers or suppliers from transacting business with us, or make it more expensive to do so. Given our revenue concentration in China, if, due to actual, threatened or potential U.S. or Chinese government actions or policies: we were further limited in, or prohibited from, selling our integrated circuit products to Chinese OEMs; our non-Chinese OEM customers were limited in, or prohibited from, selling devices that incorporate our integrated circuit products into China; Chinese OEMs develop and use their own integrated circuit products or use our competitors’ integrated circuit products in some or all of their devices rather than our integrated circuit products; Chinese tariffs on our integrated circuit products or on devices which incorporate our integrated circuit products made purchasing such products or devices more expensive to Chinese OEMs or Chinese consumers; or our Chinese licensees delay or cease making payments of license fees they owe us, our business, revenues, results of operations, cash flows and financial position could be materially harmed. For example, we currently sell 4G and other integrated circuit products, including WiFi products (but excluding 5G products), to Huawei under export licenses from the U.S. Department of Commerce. Recent news reports have indicated that the Department of Commerce is considering not granting any new licenses for sales to Huawei and potentially revoking existing licenses. If we are unable to sell products to Huawei, either due to the inability to obtain new export licenses upon the expiration of our current licenses, or because our current licenses are revoked, our revenues, results of operations and cash flows would be negatively affected. Similarly, if, due to U.S. or Chinese government actions or policies, we were limited in or prohibited from obtaining critical integrated circuit products from our suppliers in China, our business, revenues, results of operations, cash flows and financial position could be materially harmed. See also the Risk Factor titled “We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected.”

[0000804328-23-000023:mdna:149]
[same as prior period, unchanged from 0000804328-23-000006:mdna:131]

[0000804328-23-000023:mdna:150]
[same as prior period, unchanged from 0000804328-23-000006:mdna:132]

[0000804328-23-000023:mdna:151]
[same as prior period, unchanged from 0000804328-23-000006:mdna:133]

[0000804328-23-000023:mdna:152]
[same as prior period, unchanged from 0000804328-23-000006:mdna:134]

[0000804328-23-000023:mdna:153]
[same as prior period, unchanged from 0000804328-23-000006:mdna:135]

[0000804328-23-000023:mdna:154]
However, our research, development and other investments in these new and expanded product areas, industries and applications, and corresponding technologies and products, as well as in our existing technologies and products and new technologies in mobile handsets, may not succeed because, among other reasons: we may not be issued patents on the technologies we develop; the technologies we develop may not be incorporated into relevant standards; new and expanded

[0000804328-23-000023:mdna:155]
product areas, industries and applications beyond mobile handsets, and consumer demand therein, may not develop or grow as anticipated; we may be unable to attract or retain employees with the necessary skills in such new and expanded product areas, industries and applications; our strategies or the strategies of our customers, licensees or partners may not be successful; alternate technologies or products may be better or may reduce the advantages we anticipate from our investments; competitors’ technologies or products may be more cost effective, have more capabilities or fewer limitations or be brought to market faster than our new technologies or products; we may not be able to develop, or our competitors may have more established and/or stronger, customer, vendor, distributor or other channel relationships; and competitors may have longer operating histories in industries and applications that are new to us. We may also underestimate the costs of, or overestimate the future revenues or margins that could result from, these investments, and these investments may not, or may take many years to, generate material returns.

[0000804328-23-000023:mdna:156]
[same as prior period, unchanged from 0000804328-23-000006:mdna:137]

[0000804328-23-000023:mdna:157]
[same as prior period, unchanged from 0000804328-23-000006:mdna:138]

[0000804328-23-000023:mdna:158]
[same as prior period, unchanged from 0000804328-23-000006:mdna:139]

[0000804328-23-000023:mdna:159]
[same as prior period, unchanged from 0000804328-23-000006:mdna:140]

[0000804328-23-000023:mdna:160]
[same as prior period, unchanged from 0000804328-23-000006:mdna:141]

[0000804328-23-000023:mdna:161]
[same as prior period, unchanged from 0000804328-23-000006:mdna:142]

[0000804328-23-000023:mdna:162]
Achieving the anticipated benefits of business acquisitions depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these

[0000804328-23-000023:mdna:163]
technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models, geographic regions, industries and applications served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0000804328-23-000023:mdna:164]
[same as prior period, unchanged from 0000804328-23-000006:mdna:144]

[0000804328-23-000023:mdna:165]
[same as prior period, unchanged from 0000804328-23-000006:mdna:145]

[0000804328-23-000023:mdna:166]
[same as prior period, unchanged from 0000804328-23-000006:mdna:146]

[0000804328-23-000023:mdna:167]
[same as prior period, unchanged from 0000804328-23-000006:mdna:147]

[0000804328-23-000023:mdna:168]
[same as prior period, unchanged from 0000804328-23-000006:mdna:148]

[0000804328-23-000023:mdna:169]
[same as prior period, unchanged from 0000804328-23-000006:mdna:149]

[0000804328-23-000023:mdna:170]
[same as prior period, unchanged from 0000804328-23-000006:mdna:150]

[0000804328-23-000023:mdna:171]
[same as prior period, unchanged from 0000804328-23-000006:mdna:151]

[0000804328-23-000023:mdna:172]
[same as prior period, unchanged from 0000804328-23-000006:mdna:152]

[0000804328-23-000023:mdna:173]
[same as prior period, unchanged from 0000804328-23-000006:mdna:153]

[0000804328-23-000023:mdna:174]
[same as prior period, unchanged from 0000804328-23-000006:mdna:154]

[0000804328-23-000023:mdna:175]
[same as prior period, unchanged from 0000804328-23-000006:mdna:155]

[0000804328-23-000023:mdna:176]
[same as prior period, unchanged from 0000804328-23-000006:mdna:156]

[0000804328-23-000023:mdna:177]
[same as prior period, unchanged from 0000804328-23-000006:mdna:157]

[0000804328-23-000023:mdna:178]
[same as prior period, unchanged from 0000804328-23-000006:mdna:158]

[0000804328-23-000023:mdna:179]
[same as prior period, unchanged from 0000804328-23-000006:mdna:159]

[0000804328-23-000023:mdna:180]
[same as prior period, unchanged from 0000804328-23-000006:mdna:160]

[0000804328-23-000023:mdna:181]
[same as prior period, unchanged from 0000804328-23-000006:mdna:161]

[0000804328-23-000023:mdna:182]
We rely on sole- or limited-source suppliers for certain products, which may exacerbate the risks identified above, and subject us to other significant risks, including poor product performance and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. While we have established and may in the future establish alternate suppliers for certain products, these suppliers may require significant amounts of time and levels of support to bring such products to production, both of which may increase for complex or leading process technologies. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, the elimination or limitation of a foundry supplier’s ability to manufacture components or products for us due to trade or national security protection policies could increase our vulnerability to sole- or limited-source arrangements and limit or prevent us from procuring critical components or products from those suppliers. Future consolidation of foundry suppliers could also increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions, increase our manufacturing costs and limit the amount of capacity available to us. Our arrangements with our suppliers may obligate us to incur costs to manufacture, assemble and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies (which adds risk to manufacturing yields and reliability), and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Any of the above could negatively impact our business, results of operations and cash flows.

[0000804328-23-000023:mdna:183]
[same as prior period, unchanged from 0000804328-23-000006:mdna:164]

[0000804328-23-000023:mdna:184]
[same as prior period, unchanged from 0000804328-23-000006:mdna:165]

[0000804328-23-000023:mdna:185]
[same as prior period, unchanged from 0000804328-23-000006:mdna:166]

[0000804328-23-000023:mdna:186]
[same as prior period, unchanged from 0000804328-23-000006:mdna:167]

[0000804328-23-000023:mdna:187]
See also the Risk Factor below titled “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises, geopolitical conflicts and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues” as similar risks, as well as additional risks, may be applicable to our third-party suppliers’ manufacturing facilities, which could result in disruptions to our business or additional costs to us, and negatively impact our results of operations.

[0000804328-23-000023:mdna:188]
[same as prior period, unchanged from 0000804328-23-000006:mdna:171]

[0000804328-23-000023:mdna:189]
[same as prior period, unchanged from 0000804328-23-000006:mdna:172]

[0000804328-23-000023:mdna:190]
[same as prior period, unchanged from 0000804328-23-000006:mdna:173]

[0000804328-23-000023:mdna:191]
Climate change concerns and the potential resulting environmental impact may result in new environmental, health and safety laws and regulations that may affect us, our suppliers and our customers. Such laws or regulations could cause us to incur additional direct costs for compliance, including costs associated with changes to manufacturing processes or the procurement of raw materials used in manufacturing processes, as well as increased indirect costs resulting from our customers, suppliers or both incurring additional compliance costs that are passed on to us. These costs may adversely impact our results of operations and financial condition. In addition, climate change could cause certain natural disasters, such as

[0000804328-23-000023:mdna:192]
[same as prior period, unchanged from 0000804328-23-000006:mdna:169]

[0000804328-23-000023:mdna:193]
drought, wildfires, storms, flooding or rising sea levels, to occur more frequently or with greater intensity, which could pose physical risks to our manufacturing facilities or our suppliers’ facilities, could disrupt the availability of water necessary for the operation of such facilities, and could increase or decrease temperatures resulting in increased operating costs and/or business disruption.

[0000804328-23-000023:mdna:194]
[same as prior period, unchanged from 0000804328-23-000006:mdna:175]

[0000804328-23-000023:mdna:195]
[same as prior period, unchanged from 0000804328-23-000006:mdna:176]

[0000804328-23-000023:mdna:196]
[same as prior period, unchanged from 0000804328-23-000006:mdna:177]

[0000804328-23-000023:mdna:197]
[same as prior period, unchanged from 0000804328-23-000006:mdna:178]

[0000804328-23-000023:mdna:198]
36

[0000804328-23-000023:mdna:199]
[same as prior period, unchanged from 0000804328-23-000006:mdna:179]

[0000804328-23-000023:mdna:200]
[same as prior period, unchanged from 0000804328-23-000006:mdna:180]

[0000804328-23-000023:mdna:201]
Third parties regularly attempt to gain unauthorized access to our IT systems, and many such attacks are increasingly more sophisticated. These attacks, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, exploiting vulnerabilities in hardware, software or other IT infrastructure and impersonating authorized users, among others. We are also subject to ransom-style cyber-attacks, which could expose our confidential or proprietary information, request payment of money and/or impact our IT systems and cause widespread disruption to our business, including our manufacturing operations. Third parties that store and/or process our confidential information, or that provide products, software or services used in our IT infrastructure (including applications), may be subject to similar attacks, which could also result in malware being introduced into our IT infrastructure, e.g., through the third parties’ software and/or software updates. Such attacks could result in the misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our IT systems. We believe that we have a robust cybersecurity program that is aligned to international cybersecurity frameworks, and that we leverage industry best practices across people, processes and technologies in an attempt to mitigate cybersecurity threats. However, we cannot anticipate, detect, repel or implement fully effective preventative measures against all cybersecurity threats, particularly because the techniques used are increasingly sophisticated and constantly evolving. As part of our cybersecurity program, we seek to identify and remediate vulnerabilities in our IT systems and software (including third party software used in our IT systems) that could be exploited by hackers or other malicious actors. However, we may not be aware of all such vulnerabilities, and we may fail to identify and/or remediate such vulnerabilities before they are exploited. Attempts to gain unauthorized access to our IT systems or other attacks have in the past, in certain instances and to certain degrees, been successful (but have not caused significant harm), and may in the future be successful, and in some cases, we might be unaware of an incident or its magnitude and effects.

[0000804328-23-000023:mdna:202]
In addition, employees and former employees, in particular former employees who become employees of our competitors, customers, licensees or other third parties, including state actors, have in the past and may in the future misappropriate, wrongfully use, publish or provide to our competitors, customers, licensees or other third parties, including state actors, our technology, intellectual property or other proprietary or confidential information. This risk is exacerbated as competitors for talent, particularly engineering talent, increasingly attempt to hire our employees. See also the Risk Factor titled “We may not be able to attract and retain qualified employees, and recent changes to our hybrid work model may not be successful.” Similarly, we provide access to certain of our technology, intellectual property and other proprietary or confidential information to our direct and indirect customers and licensees and certain of our consultants, who have in the past and may in the future wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. We also provide access to certain of our technology, intellectual property and other proprietary or confidential information to certain of our joint venture partners, including those affiliated with state actors and including in foreign jurisdictions where ownership restrictions may require us to take a minority ownership interest in the joint venture. Such joint venture partners may wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. Our technology, intellectual property and other proprietary or confidential information that we have provided to customers, licensees or other business partners could also be wrongfully obtained by third parties through cyber-attacks on such customers’, licensees’ or other business partners’ IT systems.

[0000804328-23-000023:mdna:203]
[same as prior period, unchanged from 0000804328-23-000006:mdna:185]

[0000804328-23-000023:mdna:204]
Further, certain countries in which we operate have implemented, and other countries or regions may implement, cybersecurity laws that require our overall IT security environment to meet certain standards and/or be certified. Such laws may be complex, ambiguous and subject to interpretation, which may create uncertainty regarding compliance. As a result, our efforts to comply with such laws may be expensive and may fail, which could adversely affect our business, results of

[0000804328-23-000023:mdna:205]
[same as prior period, unchanged from 0000804328-23-000006:mdna:182]

[0000804328-23-000023:mdna:206]
operations and cash flows. In addition, our contracts with certain of our customers require us to obtain cybersecurity certifications for our IT systems. Failure to obtain or maintain the necessary cybersecurity certifications could result in loss of future revenues, damage to our customer relationships and reputation, and a shift of business to our competitors.

[0000804328-23-000023:mdna:207]
[same as prior period, unchanged from 0000804328-23-000006:mdna:187]

[0000804328-23-000023:mdna:208]
We may not be able to attract and retain qualified employees, and recent changes to our hybrid work model may not be successful.

[0000804328-23-000023:mdna:209]
Our future success depends upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. In addition, in order to extend our business into certain new and expanded product areas and industries and applications beyond mobile handsets, we need to attract, retain and motivate engineering and other technical personnel with specialized skills in these areas, and these skills are in high demand among our competitors. The market for employees in our industry is extremely competitive, and competitors for talent, particularly engineering talent, increasingly attempt to hire, and to varying degrees have been successful in hiring, our employees or employment candidates, including by establishing or expanding local offices near our headquarters in San Diego, California. Further, the increased availability of remote working arrangements has expanded the pool of companies that can compete for our employees and employment candidates. A number of such competitors for talent are significantly larger than us and/or offer compensation in excess of what we offer or other benefits that we do not offer. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0000804328-23-000023:mdna:210]
The COVID-19 pandemic caused us to modify our workforce practices, including having the vast majority of our employees work from home. Since the reopening of our offices, we have been operating under a hybrid work model, meaning that the majority of our employees have the flexibility to work remotely at least some of the time. The hybrid work model may impair our ability to maintain our collaborative and innovative culture, and may cause disruptions among our employees, including decreases in productivity, challenges in communications between on-site and off-site employees and, potentially, employee dissatisfaction and attrition. We recently implemented changes to our hybrid work model that require the majority of our employees to significantly increase the number of days they work in the office. This requirement for greater in-office attendance may not meet the needs or expectations of our employees and could negatively impact our ability to attract and retain employees, particularly if it is perceived as less favorable compared to other companies’ remote work policies. If we fail to retain key employees or maintain employee productivity as a result of the hybrid work model or the shift to more on-site work, our business could be adversely impacted.

[0000804328-23-000023:mdna:211]
[same as prior period, unchanged from 0000804328-23-000006:mdna:193]

[0000804328-23-000023:mdna:212]
[same as prior period, unchanged from 0000804328-23-000006:mdna:194]

[0000804328-23-000023:mdna:213]
[same as prior period, unchanged from 0000804328-23-000006:mdna:195]

[0000804328-23-000023:mdna:214]
Our patent license agreements in effect that generate a significant portion of our licensing revenues are effective for a specified term. To receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms, and may impact the financial or other terms of license agreements not subject to the litigation or arbitration. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such licensees.

[0000804328-23-000023:mdna:215]
[same as prior period, unchanged from 0000804328-23-000006:mdna:197]

[0000804328-23-000023:mdna:216]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, alleging that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) attempts by licensees to shift their royalty obligation to their suppliers in order to make royalty collection more difficult or reduce the amount of royalties collected.

[0000804328-23-000023:mdna:217]
In addition, certain licensees have disputed, underreported, underpaid, not reported or not paid royalties owed to us under their license agreements or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or have delayed entering into or renewing license agreements with us for their use of our intellectual property, and they or others may engage in such behavior in the future. The fact that one or more licensees dispute, underreport, underpay, do not report or do not pay royalties owed to us may encourage other licensees to take similar actions or not renew their existing license agreements, and may encourage other licensees or unlicensed companies to delay entering into, or to not enter into, new license agreements. Further, to the extent such licensees and companies increase their device share, the negative impact of their underreporting, underpayment, non-payment or non-reporting on our business, revenues, results of operations, cash flows and financial condition will be exacerbated.

[0000804328-23-000023:mdna:218]
We have been in the past and are currently subject to various litigation and/or governmental investigations and proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. See also the Risk Factors below titled “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.”

[0000804328-23-000023:mdna:219]
[same as prior period, unchanged from 0000804328-23-000006:mdna:202]

[0000804328-23-000023:mdna:220]
[same as prior period, unchanged from 0000804328-23-000006:mdna:203]

[0000804328-23-000023:mdna:221]
39

[0000804328-23-000023:mdna:222]
Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party. Further, SDOs in certain countries may attempt to modify widely accepted standards and claim the resulting standard as their own.

[0000804328-23-000023:mdna:223]
[same as prior period, unchanged from 0000804328-23-000006:mdna:205]

[0000804328-23-000023:mdna:224]
[same as prior period, unchanged from 0000804328-23-000006:mdna:206]

[0000804328-23-000023:mdna:225]
As described in the Risk Factor below titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings,” we have been in the past, currently are and may in the future be subject to various governmental investigations and/or legal proceedings challenging our patent licensing practices. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We believe that one intent of certain of these governmental investigations and legal proceedings has been to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0000804328-23-000023:mdna:226]
[same as prior period, unchanged from 0000804328-23-000006:mdna:209]

[0000804328-23-000023:mdna:227]
[same as prior period, unchanged from 0000804328-23-000006:mdna:210]

[0000804328-23-000023:mdna:228]
[same as prior period, unchanged from 0000804328-23-000006:mdna:211]

[0000804328-23-000023:mdna:229]
[same as prior period, unchanged from 0000804328-23-000006:mdna:212]

[0000804328-23-000023:mdna:230]
[same as prior period, unchanged from 0000804328-23-000006:mdna:208]

[0000804328-23-000023:mdna:231]
[same as prior period, unchanged from 0000804328-23-000006:mdna:213]

[0000804328-23-000023:mdna:232]
Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.

[0000804328-23-000023:mdna:233]
We have been in the past and currently are subject to various governmental investigations and/or legal proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations or findings in those matters include or have in the past included, among others: that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers; that our royalty rates are too high; that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions); that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets; that we have entered into exclusive agreements with chipset customers that foreclose competition; that we leverage our position in baseband chipsets in the RFFE space; and that we violate antitrust laws and engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0000804328-23-000023:mdna:234]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others: the loss of our ability to enforce one or more of our patents; injunctions; monetary damages, fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers or other component suppliers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any revenues under such agreements. The renegotiation of license agreements could result in terms that are less favorable to us than existing terms, or lead to arbitration or litigation to resolve the licensing terms, which could also be less favorable to us than existing terms, and each of which could take months or years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. The occurrence of any of the above could have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies. Further, depending on the breadth and severity of the circumstances above, we may have to reduce, suspend or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted.

[0000804328-23-000023:mdna:235]
[same as prior period, unchanged from 0000804328-23-000006:mdna:218]

[0000804328-23-000023:mdna:236]
[same as prior period, unchanged from 0000804328-23-000006:mdna:219]

[0000804328-23-000023:mdna:237]
[same as prior period, unchanged from 0000804328-23-000006:mdna:220]

[0000804328-23-000023:mdna:238]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on our customers and licensees to develop devices and services based on these technologies to drive consumer demand for new 3G/4G/5G multimode and single-mode devices, and to establish the selling prices for such devices. Further, the timing of our shipments of our products is dependent on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries and applications beyond mobile handsets, such as automotive and IoT, among others. Commercial deployments of 5G networks and devices have begun and are expected to continue for the foreseeable future. However, the timing and scale of certain such deployments were delayed due to the COVID-19 pandemic, and future deployments may similarly be delayed for reasons that are beyond our control.

[0000804328-23-000023:mdna:239]
[same as prior period, unchanged from 0000804328-23-000006:mdna:222]

[0000804328-23-000023:mdna:240]
[same as prior period, unchanged from 0000804328-23-000006:mdna:223]

[0000804328-23-000023:mdna:241]
[same as prior period, unchanged from 0000804328-23-000006:mdna:224]

[0000804328-23-000023:mdna:242]
We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, and technological and public policy changes. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape. For example, if any key supplier of technologies and intellectual property to the semiconductor industry was sold to one of our competitors, it could negatively affect our ability to procure or license such technologies and intellectual property in the future, at all or upon acceptable terms, which could have wide-ranging impacts on our business and operations.

[0000804328-23-000023:mdna:243]
[same as prior period, unchanged from 0000804328-23-000006:mdna:227]

[0000804328-23-000023:mdna:244]
[same as prior period, unchanged from 0000804328-23-000006:mdna:228]

[0000804328-23-000023:mdna:245]
[same as prior period, unchanged from 0000804328-23-000006:mdna:229]

[0000804328-23-000023:mdna:246]
[same as prior period, unchanged from 0000804328-23-000006:mdna:230]

[0000804328-23-000023:mdna:247]
[same as prior period, unchanged from 0000804328-23-000006:mdna:231]

[0000804328-23-000023:mdna:248]
[same as prior period, unchanged from 0000804328-23-000006:mdna:232]

[0000804328-23-000023:mdna:249]
[same as prior period, unchanged from 0000804328-23-000006:mdna:233]

[0000804328-23-000023:mdna:250]
[same as prior period, unchanged from 0000804328-23-000006:mdna:234]

[0000804328-23-000023:mdna:251]
[same as prior period, unchanged from 0000804328-23-000006:mdna:235]

[0000804328-23-000023:mdna:252]
[same as prior period, unchanged from 0000804328-23-000006:mdna:236]

[0000804328-23-000023:mdna:253]
42

[0000804328-23-000023:mdna:254]
[same as prior period, unchanged from 0000804328-23-000006:mdna:237]

[0000804328-23-000023:mdna:255]
[same as prior period, unchanged from 0000804328-23-000006:mdna:238]

[0000804328-23-000023:mdna:256]
[same as prior period, unchanged from 0000804328-23-000006:mdna:239]

[0000804328-23-000023:mdna:257]
We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application, industry or standard product, including those that produce products for mobile handsets, automotive or IoT, among others. Most of these competitors compete with us with respect to some, but not all, of our businesses or product lines. Companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Apple, Broadcom, MediaTek, Nvidia, NXP Semiconductors, Qorvo, Samsung, Skyworks, Texas Instruments and UNISOC. Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to use our competitors’ integrated circuit products, to utilize their own internally-developed integrated circuit products and/or sell such products to others, or to utilize alternative technologies; lower cost structures or a willingness and ability to accept lower prices or lower margins for their products, particularly in China; foreign government support of other technologies, competitors or OEMs that sell devices that do not contain our integrated circuit products; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; the development and sale of infrastructure equipment for wireless networks, which may enable such competitors to better optimize their integrated circuit products for performance on those networks; more extensive relationships with local distribution companies and OEMs in certain geographic regions (such as China); more experience in industries and applications beyond mobile handsets (such as automotive and IoT); and a more established presence in certain regions.

[0000804328-23-000023:mdna:258]
[same as prior period, unchanged from 0000804328-23-000006:mdna:242]

[0000804328-23-000023:mdna:259]
[same as prior period, unchanged from 0000804328-23-000006:mdna:243]

[0000804328-23-000023:mdna:260]
[same as prior period, unchanged from 0000804328-23-000006:mdna:244]

[0000804328-23-000023:mdna:261]
[same as prior period, unchanged from 0000804328-23-000006:mdna:245]

[0000804328-23-000023:mdna:262]
[same as prior period, unchanged from 0000804328-23-000006:mdna:246]

[0000804328-23-000023:mdna:263]
[same as prior period, unchanged from 0000804328-23-000006:mdna:247]

[0000804328-23-000023:mdna:264]
[same as prior period, unchanged from 0000804328-23-000006:mdna:248]

[0000804328-23-000023:mdna:265]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, meet certain regulatory or industry standards (including product safety and information security standards, which may differ by region, geography and industry, and which are particularly stringent in the automotive industry), or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and the end users of such devices, and potentially to our customers’ IT infrastructure. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products, repairing or replacing defective products, writing down defective inventory or indemnification obligations under our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, and losses on unfavorable purchase commitments. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products.

[0000804328-23-000023:mdna:266]
In addition, the occurrence of defects, errors or security vulnerabilities may give rise to product liability claims, particularly if such defects, errors or security vulnerabilities in our products or the technology we use, or the products into which they are integrated, result in personal injury or death, and could result in significant costs, expenses and losses. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the attention of our technical and management personnel and harm our business, even if we are successful. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. We may also be required to indemnify and/or defend our customers from product liability claims relating to our products. Further, our business liability insurance may be inadequate, may not cover the claims, and future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as: automobiles, including ADAS/AD functions; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for

[0000804328-23-000023:mdna:267]
44

[0000804328-23-000023:mdna:268]
child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and XR for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0000804328-23-000023:mdna:269]
[same as prior period, unchanged from 0000804328-23-000006:mdna:252]

[0000804328-23-000023:mdna:270]
[same as prior period, unchanged from 0000804328-23-000006:mdna:253]

[0000804328-23-000023:mdna:271]
[same as prior period, unchanged from 0000804328-23-000006:mdna:254]

[0000804328-23-000023:mdna:272]
[same as prior period, unchanged from 0000804328-23-000006:mdna:255]

[0000804328-23-000023:mdna:273]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. We cannot predict with certainty the long-term effects of any potential changes. In the United States, there is continued discussion regarding potential patent law changes, and there is current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. Further, the laws in certain foreign countries in which our patents are or may be licensed, or our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in ways that are detrimental to our licensing programs or to the sale or use of our products or technologies.

[0000804328-23-000023:mdna:274]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies or political actions of governments, including trade protection and national security policies; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business or the pricing and integration of additional features and functionality into our chipset products. See also the Risk Factors titled “Efforts by some original equipment manufacturers (OEMs) to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.”

[0000804328-23-000023:mdna:275]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0000804328-23-000023:mdna:276]
[same as prior period, unchanged from 0000804328-23-000006:mdna:260]

[0000804328-23-000023:mdna:277]
[same as prior period, unchanged from 0000804328-23-000006:mdna:261]

[0000804328-23-000023:mdna:278]
[same as prior period, unchanged from 0000804328-23-000006:mdna:262]

[0000804328-23-000023:mdna:279]
From time to time, companies have asserted, and may again assert, patent, copyright or other intellectual property claims against us relating to our technologies or products, including those we have acquired from other companies. These claims have resulted and may again result in our involvement in litigation, and we are currently involved in such litigation, including those described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products were found to infringe another company’s intellectual property, we could be subject to an injunction or be required to redesign our products, or to license such intellectual property or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products, license such intellectual property used in our products or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling our products. Similarly, our suppliers could be found to infringe another company’s intellectual property, and such suppliers could then be enjoined from providing products or services to us.

[0000804328-23-000023:mdna:280]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products sold by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel and/or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0000804328-23-000023:mdna:281]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing corresponding declines in our chipset or licensing revenues.

[0000804328-23-000023:mdna:282]
[same as prior period, unchanged from 0000804328-23-000006:mdna:267]

[0000804328-23-000023:mdna:283]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe that we will continue to see, customers request that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of our products’ source code and

[0000804328-23-000023:mdna:284]
may expose our related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of that software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers, or to license such derivative works under a particular type of license that is different than what we customarily use to license our software. Furthermore, in the course of product development, we may make contributions to third-party open source projects that could subject our intellectual property to adverse licensing conditions. For example, to encourage the growth of a software ecosystem that is interoperable with our products, we may need to contribute certain implementations under the open source licensing terms that govern such projects, which may adversely impact our associated intellectual property. Developing open source products, while adequately protecting the intellectual property upon which our licensing programs depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental and third-party scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products.

[0000804328-23-000023:mdna:285]
[same as prior period, unchanged from 0000804328-23-000006:mdna:269]

[0000804328-23-000023:mdna:286]
[same as prior period, unchanged from 0000804328-23-000006:mdna:270]

[0000804328-23-000023:mdna:287]
[same as prior period, unchanged from 0000804328-23-000006:mdna:271]

[0000804328-23-000023:mdna:288]
The COVID-19 pandemic also caused us to modify our workforce practices, such as having the vast majority of our employees work from home. Although we have generally reopened our offices, we could be negatively affected in the future if, among others, a significant number of our employees, or employees who perform critical functions, become ill and/or are quarantined as the result of exposure to COVID-19 or a similar health crisis, or if government policies restrict the ability of those employees to perform their critical functions. See also the Risk Factor titled “We may not be able to attract and retain qualified employees, and recent changes to our hybrid work model may not be successful.”

[0000804328-23-000023:mdna:289]
[same as prior period, unchanged from 0000804328-23-000006:mdna:274]

[0000804328-23-000023:mdna:290]
[same as prior period, unchanged from 0000804328-23-000006:mdna:275]

[0000804328-23-000023:mdna:291]
The semiconductor industry is highly cyclical, volatile, subject to downturns and characterized by constant and rapid technological change, price erosion, evolving technical standards, frequent new product introductions, short product life cycles and fluctuations in product supply and demand. Periods of downturns have been characterized by diminished demand for end-user products, high inventory levels, excess or obsolete inventory adjustments or reserves, underutilization of manufacturing capacity, changes in revenue mix and erosion of average selling prices. We expect our business to continue to be subject to such cyclical downturns. During such downturns, our revenues may decline, and our results of operations and

[0000804328-23-000023:mdna:292]
47

[0000804328-23-000023:mdna:293]
financial condition may be adversely impacted. We are currently seeing and expect to continue to see weakness in the macroeconomic environment (negatively impacting consumer demand for smartphones and other devices that incorporate our products and technologies) and elevated inventory levels at our customers (negatively impacting the volume of chipsets they purchase from us until such inventory is depleted). Until these conditions improve, we expect that both of these dynamics will have a negative impact on our revenues, results of operations and cash flows.

[0000804328-23-000023:mdna:294]
[same as prior period, unchanged from 0000804328-23-000006:mdna:277]

[0000804328-23-000023:mdna:295]
Our stock price and financial results have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and our financial results include those identified above and throughout this Risk Factors section, as well as: volatility of the stock market in general and technology and semiconductor companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees, including any announcement concerning the initiation of, or any developments in, any lawsuit or governmental investigation or proceeding against us; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0000804328-23-000023:mdna:296]
[same as prior period, unchanged from 0000804328-23-000006:mdna:281]

[0000804328-23-000023:mdna:297]
Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). These include, among others, Regulations related to: patent licensing practices; antitrust, competition and competitive business practices; the flow of funds out of certain countries (e.g., China); cybersecurity; imports and exports, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; protection of intellectual property; trade and trade protection including tariffs; foreign policy and national security; environmental protection (including climate change), health and safety; supply chain, responsible sourcing, including the use of conflict minerals, and human rights; spectrum availability and license issuance; adoption of standards; taxation; privacy and data protection; labor, employment and human capital; corporate governance; public disclosure; automotive industry safety and quality standards; and business conduct. Compliance with, or changes in the interpretation of, existing Regulations, the adoption of new Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, among others, could have an adverse effect on our business and results of operations. See also the Risk Factors titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises, geopolitical conflicts and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

[0000804328-23-000023:mdna:298]
[same as prior period, unchanged from 0000804328-23-000006:mdna:279]

[0000804328-23-000023:mdna:299]
[same as prior period, unchanged from 0000804328-23-000006:mdna:283]

[0000804328-23-000023:mdna:300]
[same as prior period, unchanged from 0000804328-23-000006:mdna:284]

[0000804328-23-000023:mdna:301]
[same as prior period, unchanged from 0000804328-23-000006:mdna:285]

[0000804328-23-000023:mdna:302]
[same as prior period, unchanged from 0000804328-23-000006:mdna:286]

[0000804328-23-000023:mdna:303]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed, as well as countries where we own intellectual property. The final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0000804328-23-000023:mdna:304]
Tax rules may change in a manner that adversely affects our future reported results of operations or the way we conduct our business. Most of our income is taxable in the United States with a significant portion qualifying for preferential treatment as FDII (foreign-derived intangible income). Beginning in fiscal 2027, the effective tax rate for FDII increases from 13% to 16%. Further, if U.S. tax rates increase and/or the FDII deduction is eliminated or reduced, both of which have been proposed by the current U.S. presidential administration, our provision for income taxes, results of operations and cash flows would be adversely (potentially materially) affected. Also, if our customers move manufacturing operations to the United States, our FDII deduction may be reduced.

[0000804328-23-000023:mdna:305]
Further changes in the tax laws of foreign jurisdictions could arise as a result of the base erosion and profit shifting (BEPS) project that was undertaken by the Organization for Economic Co-operation and Development (OECD). The OECD, which represents a coalition of member countries, recommended changes to numerous long-standing tax principles related to transfer pricing and continues to develop new proposals including allocating greater taxing rights to countries where customers are located and establishing a minimum tax on global income. These changes, if and as adopted by countries, may increase tax uncertainty and may adversely affect our provision for income taxes, results of operations and cash flows.
