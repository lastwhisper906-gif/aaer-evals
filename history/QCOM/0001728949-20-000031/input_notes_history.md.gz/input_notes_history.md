# QCOM note change history — 0001728949-20-000011 → 0001728949-20-000031


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-04-29):
[0001728949-20-000031:note_history:1]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On January 22, 2019, the court appointed the lead plaintiff in the action. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint, and on March 10, 2020, the court granted our motion. The plaintiffs have until May 11, 2020 to file an amended complaint. We believe the plaintiffs’ claims are without merit.
  (was, 2020-02-05, similarity 0.8856):
[0001728949-20-000011:note_history:1]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On January 22, 2019, the court appointed the lead plaintiff in the action. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

- changed (2020-04-29):
[0001728949-20-000031:note_history:2]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Currently, twenty-two such cases remained outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) granted us
  (was, 2020-02-05, similarity 0.6724):
[0001728949-20-000011:note_history:2]
that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. The Ninth Circuit has not yet ruled on our appeal. We believe the plaintiffs’ claims are without merit.

- added (2020-04-29):
[0001728949-20-000031:note_history:3]
permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. The Ninth Circuit has not yet ruled on our appeal. We believe the plaintiffs’ claims are without merit.

- changed (2020-04-29):
[0001728949-20-000031:note_history:4]
We believe that our business practices do not violate the MRFTA. On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019 and, on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC.
  (was, 2020-02-05, similarity 0.8524):
[0001728949-20-000011:note_history:4]
We believe that our business practices do not violate the MRFTA. On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019 and, on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our

- changed (2020-04-29):
[0001728949-20-000031:note_history:5]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision confirming their preliminary view that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the
  (was, 2020-02-05, similarity 0.8733):
[0001728949-20-000011:note_history:5]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision confirming their preliminary view that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

- added (2020-04-29):
[0001728949-20-000031:note_history:6]
EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

- changed (2020-04-29):
[0001728949-20-000031:note_history:7]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At March 29, 2020, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other (expense) income, net), was $272 million and included in other current liabilities.
  (was, 2020-02-05, similarity 0.987):
[0001728949-20-000011:note_history:7]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 29, 2019, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $271 million and included in other current liabilities.

- changed (2020-04-29):
[0001728949-20-000031:note_history:8]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At March 29, 2020, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other (expense) income, net), was $1.1 billion and included in other current liabilities.
  (was, 2020-02-05, similarity 0.987):
[0001728949-20-000011:note_history:8]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 29, 2019, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.1 billion and included in other current liabilities.

- changed (2020-04-29):
[0001728949-20-000031:note_history:9]
European Commission (EC) Investigation regarding Radio Frequency Front Ends (RFFE): On December 3, 2019, we received a Request for Information from the EC notifying us that it is investigating whether we engaged in anti-competitive behavior in the European Union (EU)/European Economic Area (EEA) by leveraging our market position in 5G baseband processors in the RFFE space. We have responded to the Request for Information. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of our annual revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. We believe that our business practices do not violate the EU competition rules.
  (was, 2020-02-05, similarity 0.9536):
[0001728949-20-000011:note_history:9]
European Commission (EC) Investigation regarding Radio Frequency Front Ends (RFFE): On December 3, 2019, we received a Request for Information from the EC notifying us that it is investigating whether we engaged in anti-competitive behavior in the European Union (EU)/European Economic Area (EEA) by leveraging our market position in 5G baseband processors in the RFFE space. We are in the process of responding. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of our annual revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. We believe that our business practices do not violate the EU competition rules.

- changed (2020-04-29):
[0001728949-20-000031:note_history:10]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of cellular modem chipsets on the purchaser first agreeing to a license to our cellular standard-essential patents, paying incentives to purchasers of cellular modem chipsets to induce them to accept certain license terms, refusing to license our cellular standard-essential patents to our competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint sought a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief. On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to rival sellers of cellular modem chipsets. On November 6, 2018, the court granted the FTC’s partial summary judgment motion. Trial was held January 4-29, 2019.
  (was, 2020-02-05, similarity 0.9463):
[0001728949-20-000011:note_history:10]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of cellular modem chipsets on the purchaser first agreeing to a license to our cellular standard-essential patents, paying incentives to purchasers of cellular modem chipsets to induce them to accept certain license terms, refusing to license our cellular standard-essential patents to our competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint sought a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief. On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to

- added (2020-04-29):
[0001728949-20-000031:note_history:11]
On May 21, 2019, the court issued an Order setting forth its Findings of Fact and Conclusions of Law. The court concluded that we had monopoly power in the CDMA and premium-tier Long Term Evolution (LTE) cellular modem chip markets, and that we had used that power in these two markets to engage in anticompetitive acts, including (1) using threats of lack of access to cellular modem chip supply to coerce OEMs to accept license terms that include unreasonably high royalty rates; (2) refusing to license our cellular standard-essential patents to competitors selling cellular modem chips; and

- changed (2020-04-29):
[0001728949-20-000031:note_history:12]
(3) entering into exclusive dealing arrangements with OEMs that foreclosed our rivals. The court further found that the royalties we charge OEMs are unreasonably high and reflect the use of our monopoly power over CDMA and premium-tier LTE cellular modem chips rather than just the value of our patents. The court concluded that our unreasonably high royalties constitute an anticompetitive surcharge on cellular modem chips sold by our competitors, which increases the effective price of our competitors’ cellular modem chips, reduces their margins and results in exclusivity. The court also found that our practice of not licensing competitors’ cellular modem chips violated our commitments to certain standard-development organizations and a duty under the antitrust laws to license competing cellular modem chip makers and helped us maintain our royalties at unreasonably high levels. Finally, the court found that incentive funds entered into with certain OEMs further harmed competing cellular modem chip makers’ ability to undermine our monopoly position, prevented rivals from entering the market and restricted the sales of those competitors that do enter. The court concluded that the combined effect of our conduct, together with our monopoly power, harmed the competitive process.
  (was, 2020-02-05, similarity 0.8144):
[0001728949-20-000011:note_history:12]
On May 21, 2019, the court issued an Order setting forth its Findings of Fact and Conclusions of Law. The court concluded that we had monopoly power in the CDMA and premium-tier Long Term Evolution (LTE) cellular modem chip markets, and that we had used that power in these two markets to engage in anticompetitive acts, including (1) using threats of lack of access to cellular modem chip supply to coerce OEMs to accept license terms that include unreasonably high royalty rates; (2) refusing to license our cellular standard-essential patents to competitors selling cellular modem chips; and (3) entering into exclusive dealing arrangements with OEMs that foreclosed our rivals. The court further found that the royalties we charge OEMs are unreasonably high and reflect the use of our monopoly power over CDMA and premium-tier LTE cellular modem chips rather than just the value of our patents. The court concluded that our unreasonably high royalties constitute an anticompetitive surcharge on cellular modem chips sold by our competitors, which increases the effective price of our competitors’ cellular modem chips, reduces their margins and results in exclusivity. The court also found that our practice of not licensing competitors’ cellular modem chips violated our commitments to certain standard-development organizations and a duty under the antitrust laws to license competing cellular modem chip makers and helped us maintain our royalties at unreasonably high levels. Finally, the court found that incentive funds entered into with certain OEMs further harmed competing cellular modem chip makers’ ability to undermine our monopoly position, prevented rivals from entering the market and restricted the sales of those competitors that do enter. The court concluded that the combined effect of our conduct, together with our monopoly power, harmed the competitive process.

- changed (2020-04-29):
[0001728949-20-000031:note_history:13]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On August 23, 2019, the Ninth Circuit granted our Motion. Thus, pending the resolution of the appeal in the Ninth Circuit or until further order of the Ninth Circuit, the portions of the court’s injunction requiring that we must (i) make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers and (ii) not condition the supply of cellular modem chips on a customer’s patent license status and must negotiate or renegotiate license terms with customers are stayed. On July 10, 2019, the Ninth Circuit granted our Motion to Expedite Appeal. On February 13, 2020, the Ninth Circuit heard oral argument, but has not yet ruled on our appeal.
  (was, 2020-02-05, similarity 0.9472):
[0001728949-20-000011:note_history:13]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On August 23, 2019, the Ninth Circuit granted our Motion. Thus, pending the resolution of the appeal in the Ninth Circuit or until further order of the Ninth Circuit, the portions of the court’s injunction requiring that we must (i) make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers and (ii) not condition the supply of cellular modem chips on a customer’s patent license status and must negotiate or renegotiate license terms with customers are stayed. On July 10, 2019, the Ninth Circuit granted our Motion to Expedite Appeal. Oral argument is scheduled for February 13, 2020.

- changed (2020-04-29):
[0001728949-20-000031:note_history:14]
Contingent losses and other considerations: We will continue to vigorously defend ourself in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at March 29, 2020 for contingent losses associated with these matters based on our belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.
  (was, 2020-02-05, similarity 0.9942):
[0001728949-20-000011:note_history:14]
Contingent losses and other considerations: We will continue to vigorously defend ourself in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at December 29, 2019 for contingent losses associated with these matters based on our belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- changed (2020-04-29):
[0001728949-20-000031:note_history:15]
Indemnifications. We generally do not indemnify our customers, licensees and suppliers for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain agreements to defend and/or indemnify certain customers, licensees and suppliers against certain types of liability and/or damages arising from the infringement of third-party intellectual property rights. Our obligations under these agreements may be limited in terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us.
  (was, 2020-02-05, similarity 0.883):
[0001728949-20-000011:note_history:15]
Indemnifications. We generally do not indemnify our customers, licensees and suppliers for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain agreements to defend and/or indemnify certain customers, licensees and suppliers against certain types of liability and/or damages arising from the infringement of third-party intellectual property rights. Our obligations under these agreements may be limited in

- changed (2020-04-29):
[0001728949-20-000031:note_history:16]
Claims and reimbursements under indemnification arrangements have not been material to our consolidated financial statements. At March 29, 2020, accruals for contingent liabilities associated with these indemnification arrangements were negligible. We have not recorded accruals for certain claims under indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.
  (was, 2020-02-05, similarity 0.9868):
[0001728949-20-000011:note_history:16]
Claims and reimbursements under indemnification arrangements have not been material to our consolidated financial statements. At December 29, 2019, accruals for contingent liabilities associated with these indemnification arrangements were negligible. We have not recorded accruals for certain claims under indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- changed (2020-04-29):
[0001728949-20-000031:note_history:17]
Operating Leases. We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years. At March 29, 2020, other assets included $475 million of operating lease assets, with corresponding lease liabilities of $132 million recorded in other current liabilities and $389 million recorded in other liabilities.
  (was, 2020-02-05, similarity 0.9845):
[0001728949-20-000011:note_history:17]
Operating Leases. We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years. At December 29, 2019, other assets included $479 million of operating lease assets, with corresponding lease liabilities of $136 million recorded in other current liabilities and $393 million recorded in other liabilities.

- changed (2020-04-29):
[0001728949-20-000031:note_history:18]
Operating lease expense for the three and six months ended March 29, 2020 was $44 million and $88 million, respectively, and $35 million and $72 million for the three and six months ended March 31, 2019, respectively. Cash paid under our operating leases was $74 million for the six months ended March 29, 2020. As of March 29, 2020, the weighted-average remaining lease term and weighted-average discount rate for operating leases were 6.0 years and 4%, respectively.
  (was, 2020-02-05, similarity 0.7336):
[0001728949-20-000011:note_history:18]
Operating lease expense for the three months ended December 29, 2019 and December 30, 2018 was $44 million and $37 million, respectively. Cash paid under our operating leases was $38 million for the three months ended December 29, 2019. As of December 29, 2019, the weighted-average remaining lease term and weighted-average discount rate for operating leases were 5.7 years and 4%, respectively.

- changed (2020-04-29):
[0001728949-20-000031:note_history:19]
At March 29, 2020, future lease payments under our operating leases were as follows (in millions):
  (was, 2020-02-05, similarity 0.9519):
[0001728949-20-000011:note_history:19]
At December 29, 2019, future lease payments under our operating leases were as follows (in millions):

- changed (2020-04-29):
[0001728949-20-000031:note_history:20]
|  |  |  | Operating Leases |
| Remainder of fiscal 2020 |  |  | $ | 76 |  |
| 2021 |  |  | 130 |  |
| 2022 |  |  | 109 |  |
| 2023 |  |  | 66 |  |
| 2024 |  |  | 47 |  |
| Thereafter |  |  | 172 |  |
| Total future lease payments |  |  | 600 |  |
| Imputed interest |  |  | (79) |  |
| Total lease liability balance |  |  | $ | 521 |  |
  (was, 2020-02-05, similarity 0.7853):
[0001728949-20-000011:note_history:20]
|  | Operating Leases |
| Remainder of fiscal 2020 | $ | 115 |  |
| 2021 | 140 |  |
| 2022 | 107 |  |
| 2023 | 62 |  |
| 2024 | 43 |  |
| Thereafter | 140 |  |
| Total future lease payments | 607 |  |
| Imputed interest | (78 | ) |
| Total lease liability balance | $ | 529 |  |

- changed (2020-04-29):
[0001728949-20-000031:note_history:21]
|  |  |  | Operating Leases |
| 2020 |  |  | $ | 138 |  |
| 2021 |  |  | 97 |  |
| 2022 |  |  | 66 |  |
| 2023 |  |  | 31 |  |
| 2024 |  |  | 18 |  |
| Thereafter |  |  | 35 |  |
| Total |  |  | $ | 385 |  |
  (was, 2020-02-05, similarity 0.8322):
[0001728949-20-000011:note_history:21]
|  | Operating Leases |
| 2020 | $ | 138 |  |
| 2021 | 97 |  |
| 2022 | 66 |  |
| 2023 | 31 |  |
| 2024 | 18 |  |
| Thereafter | 35 |  |
| Total | $ | 385 |  |

- removed (2020-04-29):
[0001728949-20-000011:note_history:22]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, a securities class action complaint was filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers. On April 29, 2016, the plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, the plaintiffs filed a second amended complaint, alleging that we and certain of our current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding our business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint sought unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, we filed a motion to dismiss the second amended complaint. On October 20, 2017, the court entered an order granting in part our motion to dismiss, and on November 29, 2017, the court entered an order granting the remaining portions of our motion to dismiss. On December 28, 2017, the plaintiffs filed an appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). A hearing was held on July 11, 2019, and on July 23, 2019, the Ninth Circuit affirmed the District Court’s dismissal of the second amended complaint in its entirety. On August 29, 2019, the Ninth Circuit denied the plaintiffs’ request for en banc review. The plaintiffs did not file a petition for certiorari to request that the United States Supreme Court hear the matter prior to the November 27, 2019 deadline. Accordingly, the dismissal is final.

- removed (2020-04-29):
[0001728949-20-000011:note_history:23]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. At December 29, 2019, twenty-two such cases remained outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging

- removed (2020-04-29):
[0001728949-20-000011:note_history:24]
favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC.

- removed (2020-04-29):
[0001728949-20-000011:note_history:25]
rival sellers of cellular modem chipsets. On November 6, 2018, the court granted the FTC’s partial summary judgment motion. Trial was held January 4-29, 2019.

- removed (2020-04-29):
[0001728949-20-000011:note_history:26]
terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-04-29):
[0001728949-20-000031:note_history:27]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 29, 2019. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 29, 2020 and March 31, 2019 included 13 weeks and 26 weeks, respectively.
  (was, 2020-02-05, similarity 0.9589):
[0001728949-20-000011:note_history:27]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for the fiscal year ended September 29, 2019. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 29, 2019 and December 30, 2018 included 13 weeks.

- changed (2020-04-29):
[0001728949-20-000031:note_history:28]
Financial Assets: In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) will be estimated based on expected losses rather than the current incurred loss impairment model. The new accounting guidance also modifies the impairment model for available-for-sale debt securities. These changes will result in earlier recognition of credit losses, if any. The new accounting guidance generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. We will adopt the new accounting guidance in the first quarter of fiscal 2021, and the impact of this new 
accounting guidance will largely depend on the composition and credit quality of our investment portfolio and accounts receivable, as well as economic conditions, at the time of adoption. Based on facts and factors currently known by us, we do not expect the impact of adoption to be material to our consolidated financial statements.
  (was, 2020-02-05, similarity 0.9359):
[0001728949-20-000011:note_history:28]
Financial Assets: In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) will be estimated based on expected losses rather than the current incurred loss impairment model. The new accounting guidance also modifies the impairment model for available-for-sale debt securities. These changes will result in earlier recognition of credit losses, if any. The new accounting guidance generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. We will adopt the new accounting guidance in the first quarter of fiscal 2021, and the impact of this new 
accounting guidance will largely depend on the composition and credit quality of our investment portfolio, as well as economic conditions, at the time of adoption.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-04-29):
[0001728949-20-000031:note_history:29]
Note 8. Marketable Securities

- added (2020-04-29):
[0001728949-20-000031:note_history:30]
We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Our marketable securities were comprised as follows (in millions):

- added (2020-04-29):
[0001728949-20-000031:note_history:31]
|  | Current |  |  |  | Noncurrent (1) |  |  |
|  | March 29,2020 |  | September 29,2019 |  | March 29,2020 |  | September 29,2019 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 1,253 |  |  | 4 |  |  | — |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 48 |  |  | — |  |  | 33 |  |  | 35 |  |
| Total available-for-sale debt securities | 1,304 |  |  | 4 |  |  | 33 |  |  | 35 |  |
| Equity securities | 239 |  |  | 417 |  |  | — |  |  | 1 |  |
| Total marketable securities | $ | 1,543 |  |  | $ | 421 |  |  | $ | 33 |  |  | $ | 36 |  |

- added (2020-04-29):
[0001728949-20-000031:note_history:32]
(1) Noncurrent marketable securities were included in other assets.

- added (2020-04-29):
[0001728949-20-000031:note_history:33]
The contractual maturities of available-for-sale marketable debt securities were as follows (in millions):

- added (2020-04-29):
[0001728949-20-000031:note_history:34]
|  | March 29,2020 |
| Years to Maturity |  |
| Less than one year | $ | 813 |  |
| One to five years | 443 |  |
| No single maturity date | 81 |  |
| Total | $ | 1,337 |  |

- added (2020-04-29):
[0001728949-20-000031:note_history:35]
Debt securities with no single maturity date included mortgage- and asset-backed securities and auction rate securities.


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-04-29):
[0001728949-20-000031:note_history:36]
| Short-term Debt (in millions) |  |  |  |
|  | March 29,2020 |  | September 29,2019 |
| Commercial paper | $ | 499 |  |  | $ | 499 |  |
| Current portion of long-term debt | 2,000 |  |  | 1,997 |  |
|  | $ | 2,499 |  |  | $ | 2,496 |  |
  (was, 2020-02-05, similarity 0.9664):
[0001728949-20-000011:note_history:36]
| Short-term debt (in millions) |  |  |  |
|  | December 29, 2019 |  | September 29, 2019 |
| Commercial paper | $ | 499 |  |  | $ | 499 |  |
| Current portion of long-term debt | 1,999 |  |  | 1,997 |  |
|  | $ | 2,498 |  |  | $ | 2,496 |  |
