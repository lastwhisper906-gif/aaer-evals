# QCOM MD&A — 0001728949-20-000031


## mdna

[0001728949-20-000031:mdna:1]
[same as prior period, unchanged from 0001728949-20-000011:mdna:1]

[0001728949-20-000031:mdna:2]
[same as prior period, unchanged from 0001728949-20-000011:mdna:2]

[0001728949-20-000031:mdna:3]
This Quarterly Report (including but not limited to this section entitled Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements regarding our business, investments, financial condition, results of operations and prospects. Forward-looking statements also include but are not limited to statements regarding the rapid, global spread of the recent coronavirus (COVID-19) pandemic, and its potential future impact on the global economy, including the potential for a global recession; economic uncertainty and consumer and business confidence; demand for devices that incorporate our products and intellectual property; our and the global wireless industry’s supply chains, transportation and distribution networks and workforces; 5G network deployments; and our business, revenues, results of operations, cash flows and financial condition; as well as statements regarding our planning assumptions, workforce practices, the duration and severity of the pandemic, and government and other actions to mitigate the spread of, and to treat, COVID-19. Forward-looking statements further include but are not limited to statements regarding industry, market, business, product, technology, commercial, competitive or consumer trends; our businesses, growth potential or strategies, or factors that may impact them; challenges to our licensing business, including by licensees, governments, governmental agencies or regulators, standards bodies or others; challenges to our QCT business; other legal or regulatory matters; competition; new or expanded product areas, adjacent industry segments or applications; costs or expenditures including research and development, selling, general and administrative, restructuring or restructuring-related charges, working capital or information technology systems; our financing, stock repurchase or dividend programs; strategic investments or acquisitions; adoption and application of future accounting guidance; tax law changes; our tax structure or strategies; or the potential business or financial statement impacts of any of the above, among others. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report.

[0001728949-20-000031:mdna:4]
Second Quarter Fiscal 2020 Overview and Other Recent Events

[0001728949-20-000031:mdna:5]
Revenues for the second quarter of fiscal 2020 were $5.2 billion, an increase of 5% compared to the year ago quarter, with net income of $468 million, a decrease of 29% compared to the year ago quarter. Highlights and other key developments from the second quarter of fiscal 2020 and other recent events included:

[0001728949-20-000031:mdna:6]
•The rapid, global spread of COVID-19 has negatively impacted consumer demand for devices that incorporate our products and intellectual property, which negatively impacted our business and results of operations in the second quarter of fiscal 2020. The negative impacts of the COVID-19 pandemic varied by region. In China, sales were significantly impacted early in the second fiscal quarter, but we started to see meaningful recovery by the end of March. Other regions were impacted later in the second fiscal quarter, with increasing impacts exiting March. The impact of COVID-19 on our ability to fulfill customer orders has been minimal. In response to the pandemic, we implemented significant workforce changes that we determined were in the best interest of our employees, as well as the communities in which we operate, and which comply with government regulations. This included significantly

[0001728949-20-000031:mdna:7]
[same as prior period, unchanged from 0001728949-20-000011:mdna:25]

[0001728949-20-000031:mdna:8]
reducing the number of people in our offices and implementing additional safety measures for employees continuing critical on-site work.

[0001728949-20-000031:mdna:9]
•QTL revenues in the second quarter of fiscal 2020 benefited from the inclusion of royalties from Apple for sales made during the March 2020 quarter (as a result of the settlement with Apple and its contract manufacturers in April 2019), which was partially offset by the negative impact of COVID-19. We did not record any revenues in the second quarter of fiscal 2020 for royalties due on the sales of Huawei’s consumer wireless products.

[0001728949-20-000031:mdna:10]
•QCT revenues increased by 10% in the second quarter of fiscal 2020 compared to the year ago quarter, primarily due to an increase in demand for 5G products, partially offset by the negative impact of COVID-19.

[0001728949-20-000031:mdna:11]
•In the second quarter of fiscal 2020, we recorded $265 million in non-marketable investment impairments, resulting in part from the impacts of COVID-19.

[0001728949-20-000031:mdna:12]
•We entered into new long-term, world-wide patent license agreements with Guangdong OPPO Mobile Telecommunications Corp., Ltd. (Oppo) and BBK Communication Technology Co., Ltd. (vivo) (who were previously disclosed as two key Chinese licensees), effective as of April 1, 2020, covering 3G/4G/5G multimode devices. We also reached agreements with these licensees to provide for payment of amounts due under the license agreements that expired on March 31, 2020 and for which certain of such amounts for prior periods were withheld while good faith negotiations occurred. The licensees have agreed to make full payment in the near term according to agreed upon payment schedules. These licensees/customers continue to make timely payments on purchases of integrated circuit products.

[0001728949-20-000031:mdna:13]
[same as prior period, unchanged from 0001728949-20-000011:mdna:8]

[0001728949-20-000031:mdna:14]
[same as prior period, unchanged from 0001728949-20-000011:mdna:9]

[0001728949-20-000031:mdna:15]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in mobile devices (primarily smartphones), tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, broadband gateway equipment, data cards and infrastructure equipment, IoT devices and applications, other consumer electronics and automotive telematics and infotainment systems. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale and/or use of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and other technology and service initiatives.

[0001728949-20-000031:mdna:16]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering, research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001728949-20-000031:mdna:17]
Seasonality. Many of our products and/or much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when the related royalties were recognized, which prior to fiscal 2019 was when licensees reported their sales and beginning in fiscal 2019 when the licensees’ sales occurred. Our historical trends were impacted by our prior dispute with Apple and its contract manufacturers, which was settled in April 2019. We expect to begin recording equipment revenues for new chipset models under our multi-year chipset agreement with Apple in the second half of fiscal 2020. These trends may or may not continue in the future and have been impacted by the decline in consumer demand resulting from COVID-19. Further, the trends for QTL have been, and/or may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings, including the lawsuit filed against us by the FTC.

[0001728949-20-000031:mdna:18]
[same as prior period, unchanged from 0001728949-20-000011:mdna:14]

[0001728949-20-000031:mdna:19]
| Revenues (in millions) |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | March 29,2020 |  | March 31,2019 |  | Change |  | March 29,2020 |  | March 31,2019 |  | Change |
| Equipment and services | $ | 4,050 |  |  | $ | 3,753 |  |  | $ | 297 |  |  | $ | 7,583 |  |  | $ | 7,506 |  |  | $ | 77 |  |
| Licensing | 1,166 |  |  | 1,229 |  |  | (63) |  |  | 2,709 |  |  | 2,318 |  |  | 391 |  |
|  | $ | 5,216 |  |  | $ | 4,982 |  |  | $ | 234 |  |  | $ | 10,292 |  |  | $ | 9,824 |  |  | $ | 468 |  |

[0001728949-20-000031:mdna:20]
Second quarter 2020 vs. 2019

[0001728949-20-000031:mdna:21]
The increase in revenues in the second quarter of fiscal 2020 was primarily due to:

[0001728949-20-000031:mdna:22]
+ $389 million in higher equipment and services revenues from our QCT segment

[0001728949-20-000031:mdna:23]
- $88 million in lower equipment and services revenues from our QSI segment

[0001728949-20-000031:mdna:24]
- $50 million in lower licensing revenues from our QTL segment

[0001728949-20-000031:mdna:25]
First six months 2020 vs. 2019

[0001728949-20-000031:mdna:26]
The increase in revenues in the first six months of fiscal 2020 was primarily due to:

[0001728949-20-000031:mdna:27]
+ $336 million in higher licensing revenues from our QTL segment

[0001728949-20-000031:mdna:28]
+ $196 million in higher equipment and services revenues from our QCT segment

[0001728949-20-000031:mdna:29]
- $95 million in lower equipment and services revenues from our QSI segment

[0001728949-20-000031:mdna:30]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | March 29,2020 |  | March 31,2019 |  | Change |  | March 29,2020 |  | March 31,2019 |  | Change |
| Cost of revenues | $ | 2,297 |  |  | $ | 2,179 |  |  | $ | 118 |  |  | $ | 4,410 |  |  | $ | 4,367 |  |  | $ | 43 |  |
| Gross margin | 56 | % |  | 56 | % |  |  |  | 57 | % |  | 56 | % |  |  |

[0001728949-20-000031:mdna:31]
Second quarter 2020 vs. 2019

[0001728949-20-000031:mdna:32]
Gross margin percentage remained flat in the second quarter of fiscal 2020 primarily due to:

[0001728949-20-000031:mdna:33]
- decrease in higher margin QTL licensing revenues as a proportion of total revenues

[0001728949-20-000031:mdna:34]
+ increase in QCT gross margin

[0001728949-20-000031:mdna:35]
First six months 2020 vs. 2019

[0001728949-20-000031:mdna:36]
Gross margin percentage increased in the first six months of fiscal 2020 primarily due to:

[0001728949-20-000031:mdna:37]
+ increase in higher margin QTL licensing revenues as a proportion of total revenues

[0001728949-20-000031:mdna:38]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | March 29,2020 |  | March 31,2019 |  | Change |  | March 29,2020 |  | March 31,2019 |  | Change |
| Research and development | $ | 1,468 |  |  | $ | 1,308 |  |  | $ | 160 |  |  | $ | 2,873 |  |  | $ | 2,577 |  |  | $ | 296 |  |
| % of revenues |  | 28 | % |  | 26 | % |  |  |  | 28 | % |  | 26 | % |  |  |

[0001728949-20-000031:mdna:39]
Second quarter 2020 vs. 2019

[0001728949-20-000031:mdna:40]
The increase in research and development expenses in the second quarter of fiscal 2020 was primarily due to:

[0001728949-20-000031:mdna:41]
+ $149 million increase driven by higher costs related to the development of wireless and integrated circuit technologies, including 5G and RFFE technologies

[0001728949-20-000031:mdna:42]
+ $64 million increase in share-based compensation expense

[0001728949-20-000031:mdna:43]
- $49 million in lower expenses driven by revaluation of our deferred compensation plan liabilities on weakened stock market performance (which resulted in a corresponding increase in net losses on marketable securities within investment and other (expense) income, net due to the revaluation of the related assets)

[0001728949-20-000031:mdna:44]
First six months 2020 vs. 2019

[0001728949-20-000031:mdna:45]
The increase in research and development expenses in the first six months of fiscal 2020 was primarily due to:

[0001728949-20-000031:mdna:46]
+ $213 million increase driven by higher costs related to the development of wireless and integrated circuit technologies, including 5G and RFFE technologies

[0001728949-20-000031:mdna:47]
+ $115 million increase in share-based compensation expense

[0001728949-20-000031:mdna:48]
[same as prior period, unchanged from 0001728949-20-000011:mdna:52]

[0001728949-20-000031:mdna:49]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | March 29,2020 |  | March 31,2019 |  | Change |  | March 29,2020 |  | March 31,2019 |  | Change |
| Selling, general and administrative | $ | 483 |  |  | $ | 573 |  |  | $ | (90) |  |  | $ | 1,011 |  |  | $ | 1,100 |  |  | $ | (89) |  |
| % of revenues |  | 9 | % |  | 12 | % |  |  |  | 10 | % |  | 11 | % |  |  |

[0001728949-20-000031:mdna:50]
Second quarter 2020 vs. 2019

[0001728949-20-000031:mdna:51]
The decrease in selling, general and administrative expenses in the second quarter of fiscal 2020 was primarily due to:

[0001728949-20-000031:mdna:52]
- $84 million in lower litigation costs, primarily resulting from the settlement of our prior dispute with Apple and its contract manufacturers in April 2019

[0001728949-20-000031:mdna:53]
- $58 million in lower expenses driven by revaluation of our deferred compensation plan liabilities on weakened stock market performance

[0001728949-20-000031:mdna:54]
+ $23 million increase in share-based compensation expense

[0001728949-20-000031:mdna:55]
First six months 2020 vs. 2019

[0001728949-20-000031:mdna:56]
The decrease in selling, general and administrative expenses in the first six months of fiscal 2020 was primarily due to:

[0001728949-20-000031:mdna:57]
- $144 million in lower litigation costs, primarily resulting from the settlement of our prior dispute with Apple and its contract manufacturers in April 2019

[0001728949-20-000031:mdna:58]
+ $35 million increase in share-based compensation expense

[0001728949-20-000031:mdna:59]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | March 29,2020 |  | March 31,2019 |  | Change |  | March 29,2020 |  | March 31,2019 |  | Change |
| Other (income) expense | $ | (23) |  |  | $ | (18) |  |  | $ | (5) |  |  | $ | (23) |  |  | $ | 130 |  |  | $ | (153) |  |

[0001728949-20-000031:mdna:60]
Second quarter and first six months 2020

[0001728949-20-000031:mdna:61]
Other income in the three and six months ended March 29, 2020 consisted of:

[0001728949-20-000031:mdna:62]
+ $23 million gain related to a favorable legal settlement

[0001728949-20-000031:mdna:63]
Second quarter 2019

[0001728949-20-000031:mdna:64]
Other income in the second quarter of fiscal 2019 consisted of:

[0001728949-20-000031:mdna:65]
+ $43 million gain due to partial recovery of a fine imposed in fiscal 2009 resulting from our appeal of the Korea Fair Trade Commission (KFTC) decision

[0001728949-20-000031:mdna:66]
- $25 million in net charges related to our Cost Plan that concluded in fiscal 2019, which included $70 million in restructuring and restructuring-related charges, partially offset by a $45 million net gain from the sale of certain assets related to wireless electric vehicle charging applications and the sale of our mobile health nonreportable segment

[0001728949-20-000031:mdna:67]
First six months 2019

[0001728949-20-000031:mdna:68]
Other expenses in the first six months of fiscal 2019 consisted of:

[0001728949-20-000031:mdna:69]
+ $204 million net charges related to our Cost Plan, which included $249 million in restructuring and restructuring-related charges, partially offset by a $45 million net gain from the sale of certain assets related to wireless electric vehicle charging applications and the sale of our mobile health nonreportable segment

[0001728949-20-000031:mdna:70]
- $43 million gain due to the partial recovery of a fine imposed in fiscal 2009 resulting from our appeal of the KFTC decision

[0001728949-20-000031:mdna:71]
- $31 million gain related to a favorable legal settlement

[0001728949-20-000031:mdna:72]
| Interest Expense and Investment and Other (Expense) Income, Net (in millions) |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | March 29,2020 |  | March 31,2019 |  | Change |  | March 29,2020 |  | March 31,2019 |  | Change |
| Interest expense |  | $ | 146 |  |  | $ | 162 |  |  | $ | (16) |  |  | $ | 294 |  |  | $ | 317 |  |  | $ | (23) |  |
| Investment and other (expense) income, net |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income |  | $ | 47 |  |  | $ | 78 |  |  | $ | (31) |  |  | $ | 107 |  |  | $ | 143 |  |  | $ | (36) |  |
| Net gains (losses) on marketable securities |  | 55 |  |  | 5 |  |  | 50 |  |  | 66 |  |  | (19) |  |  | 85 |  |
| Net (losses) gains on other investments |  | (12) |  |  | 6 |  |  | (18) |  |  | 36 |  |  | 42 |  |  | (6) |  |
| Net (losses) gains on deferred compensation plan assets |  | (72) |  |  | 37 |  |  | (109) |  |  | (42) |  |  | (2) |  |  | (40) |  |
| Impairment losses on other investments |  | (265) |  |  | (60) |  |  | (205) |  |  | (337) |  |  | (69) |  |  | (268) |  |
| Net (losses) gains on derivative instruments |  | — |  |  | (1) |  |  | 1 |  |  | 1 |  |  | (9) |  |  | 10 |  |
| Equity in net losses of investees |  | (6) |  |  | (36) |  |  | 30 |  |  | (16) |  |  | (58) |  |  | 42 |  |
| Net gains (losses) on foreign currency transactions | 6 |  |  | (1) |  |  | 7 |  |  | 3 |  |  | 5 |  |  | (2) |  |
|  | $ | (247) |  |  | $ | 28 |  |  | $ | (275) |  |  | $ | (182) |  |  | $ | 33 |  |  | $ | (215) |  |

[0001728949-20-000031:mdna:73]
COVID-19 had an impact on certain companies in which we hold non-marketable investments, resulting in an increase in impairment losses on other investments for the three and six months ended March 29, 2020. A significant portion of the impairment losses related to our investment in OneWeb (an equity method investee) who filed for bankruptcy in the second quarter of fiscal 2020. Additionally, COVID-19 had a negative impact on the fair values of our deferred compensation plan assets, resulting in a net loss in the three and six months ended March 29, 2020.

[0001728949-20-000031:mdna:74]
Income Tax Expense (Benefit) (in millions, except percentages)

[0001728949-20-000031:mdna:75]
[same as prior period, unchanged from 0001728949-20-000011:mdna:43]

[0001728949-20-000031:mdna:76]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | March 29,2020 |  | March 31,2019 |  | March 29,2020 |  | March 31,2019 |
| Expected income tax provision at federal statutory tax rate |  | $ | 126 |  |  | $ | 169 |  |  | $ | 324 |  |  | $ | 287 |  |
| Benefit from foreign-derived intangible income (FDII) deduction |  | (43) |  |  | (48) |  |  | (89) |  |  | (88) |  |
| Benefit related to the research and development tax credit |  | (35) |  |  | (22) |  |  | (60) |  |  | (46) |  |
| Excess tax (benefit) deficiency associated with share-based awards |  | (10) |  |  | 1 |  |  | (56) |  |  | (1) |  |
| Valuation allowance on unused foreign tax credits |  | 14 |  |  | — |  |  | 20 |  |  | — |  |
| Foreign currency loss related to foreign withholding tax receivable |  | 47 |  |  | — |  |  | 4 |  |  | — |  |
| Benefit from establishing new U.S. net deferred tax assets | — |  |  | — |  |  | — |  |  | (570) |  |
| Other |  | 31 |  |  | 43 |  |  | 9 |  |  | 53 |  |
| Income tax expense (benefit) |  | $ | 130 |  |  | $ | 143 |  |  | $ | 152 |  |  | $ | (365) |  |
| Effective tax rate |  | 22 | % |  | 18 | % |  | 10 | % |  | (27 | %) |

[0001728949-20-000031:mdna:77]
We estimate our annual effective income tax rate to be 12% for fiscal 2020. The estimated annual effective tax rate for fiscal 2020 is lower than the U.S. federal statutory rate, primarily due to a significant portion of our income qualifying for preferential treatment as FDII at a 13% effective tax rate and benefits from our research and development tax credit.

[0001728949-20-000031:mdna:78]
[same as prior period, unchanged from 0001728949-20-000011:mdna:82]

[0001728949-20-000031:mdna:79]
The United States Treasury Department has issued proposed regulations on several provisions of the 2017 Tax Cuts and Jobs Act (the Tax Legislation), including FDII and interest expense deduction limitations, which may be finalized in the next several months. When finalized, these proposed regulations may adversely affect our provision for income taxes, results of operations and/or cash flows.

[0001728949-20-000031:mdna:80]
[same as prior period, unchanged from 0001728949-20-000011:mdna:47]

[0001728949-20-000031:mdna:81]
The following should be read in conjunction with our financial results for the second quarter and first six months of fiscal 2020 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0001728949-20-000031:mdna:82]
[same as prior period, unchanged from 0001728949-20-000011:mdna:49]

[0001728949-20-000031:mdna:83]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | March 29,2020 |  | March 31,2019 |  | Change |  | March 29,2020 |  | March 31,2019 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services | $ | 4,011 |  |  | $ | 3,622 |  |  | $ | 389 |  |  | $ | 7,496 |  |  | $ | 7,300 |  |  | $ | 196 |  |
| Licensing | 89 |  |  | 100 |  |  | (11) |  |  | 223 |  |  | 161 |  |  | 62 |  |
| Total revenues | $ | 4,100 |  |  | $ | 3,722 |  |  | $ | 378 |  |  | $ | 7,719 |  |  | $ | 7,461 |  |  | $ | 258 |  |
| Earnings before taxes (EBT) | $ | 667 |  |  | $ | 542 |  |  | $ | 125 |  |  | $ | 1,145 |  |  | $ | 1,140 |  |  | $ | 5 |  |
| EBT as a % of revenues | 16 | % |  | 15 | % |  | 1 | % |  | 15 | % |  | 15 | % |  | — | % |

[0001728949-20-000031:mdna:84]
Equipment and services revenues primarily relate to sales of MSM, Radio Frequency (RF), Power Management (PM) and wireless connectivity chipsets. MSM integrated circuits include our stand-alone Mobile Data Modems (MDMs) and Snapdragon platforms, which include processors and modems. Approximately 129 million and 155 million MSM integrated circuits were sold in the second quarter of fiscal 2020 and 2019, respectively, and approximately 283 million and 341 million MSM integrated circuits were sold in the first six months of fiscal 2020 and 2019, respectively. We use the volume of MSM integrated circuit shipments to allow management and investors to, in part, evaluate, assess and benchmark our QCT segment’s performance. MSM integrated circuit shipments do not fully reflect the performance of our QCT segment, which can be impacted by other factors including changes in mix and average selling price of our MSM integrated circuits and revenues generated from products other than MSM integrated circuits, such as RFFE products, among others.

[0001728949-20-000031:mdna:85]
Second quarter 2020 vs. 2019

[0001728949-20-000031:mdna:86]
The increase in QCT equipment and services revenues in the second quarter of fiscal 2020 was primarily due to:

[0001728949-20-000031:mdna:87]
+ $378 million in higher revenues per MSM and accompanying RF, PM and wireless connectivity chipset shipments, primarily driven by a favorable shift in product mix as 5G devices launched

[0001728949-20-000031:mdna:88]
+ $265 million in higher RFFE product revenues, primarily driven by 5G device launches

[0001728949-20-000031:mdna:89]
- $262 million in lower MSM and accompanying chipset shipments, primarily driven by a decrease in demand due to COVID-19 and lower modem sales to Apple

[0001728949-20-000031:mdna:90]
QCT EBT as a percentage of revenues increased in the second quarter of fiscal 2020 primarily due to:

[0001728949-20-000031:mdna:91]
+ higher QCT revenues

[0001728949-20-000031:mdna:92]
+ higher gross margin, primarily driven by a favorable shift in product mix towards 5G products

[0001728949-20-000031:mdna:93]
- higher operating expenses, primarily driven by higher research and development costs

[0001728949-20-000031:mdna:94]
First six months 2020 vs. 2019

[0001728949-20-000031:mdna:95]
The increase in QCT equipment and services revenues in the first six months of fiscal 2020 was primarily due to:

[0001728949-20-000031:mdna:96]
+ $422 million in higher revenues per MSM and accompanying RF, PM and wireless connectivity chipset shipments, primarily driven by a favorable shift in product mix as 5G devices launched

[0001728949-20-000031:mdna:97]
+ $295 million in higher RFFE product revenues, primarily driven by 5G device launches

[0001728949-20-000031:mdna:98]
- $584 million in lower MSM and accompanying chipset shipments, primarily driven by a decrease in demand due to COVID-19 and lower modem sales to Apple

[0001728949-20-000031:mdna:99]
QCT EBT as a percentage of revenues remained flat in the first six months of fiscal 2020 primarily due to:

[0001728949-20-000031:mdna:100]
+ higher QCT revenues

[0001728949-20-000031:mdna:101]
- higher operating expenses, primarily driven by higher research and development costs

[0001728949-20-000031:mdna:102]
QCT accounts receivable increased by 75% in the first six months of fiscal 2020 from $908 million to $1.59 billion, primarily driven by an increase in revenues combined with the timing of integrated circuit shipments during the quarter and a

[0001728949-20-000031:mdna:103]
25

[0001728949-20-000031:mdna:104]
decrease in the relative proportion of customer incentive arrangements that are recorded in accounts receivable. QCT inventories increased by 21% in the first six months of fiscal 2020 from $1.40 billion to $1.70 billion, primarily driven by the ramp in 5G.

[0001728949-20-000031:mdna:105]
[same as prior period, unchanged from 0001728949-20-000011:mdna:58]

[0001728949-20-000031:mdna:106]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | March 29,2020 |  | March 31,2019 |  | Change |  | March 29,2020 |  | March 31,2019 |  | Change |
| Licensing revenues | $ | 1,072 |  |  | $ | 1,122 |  |  | $ | (50) |  |  | $ | 2,477 |  |  | $ | 2,141 |  |  | $ | 336 |  |
| EBT | 671 |  |  | 674 |  |  | (3) |  |  | 1,689 |  |  | 1,264 |  |  | 425 |  |
| EBT as a % of revenues | 63 | % |  | 60 | % |  | 3 | % |  | 68 | % |  | 59 | % |  | 9 | % |

[0001728949-20-000031:mdna:107]
As a result of the settlement with Apple and its contract manufacturers in April 2019, QTL results for the second quarter and first six months of fiscal 2020 included royalties from Apple and its contract manufactures. Revenues in the second quarter and first six months of fiscal 2019 did not include royalties from sales of Apple or other products by Apple’s contract manufacturers.

[0001728949-20-000031:mdna:108]
QTL revenues in the second quarter and first six months of fiscal 2019 included $150 million and $300 million, respectively, of royalties from Huawei under a second interim agreement that concluded in the third quarter of fiscal 2019. This represented a minimum, non-refundable amount for royalties due and does not reflect the full amount of royalties due under the underlying license agreement, which expired on December 31, 2019. We have not reached a final amended or new agreement with Huawei, and we did not record any revenues in the first six months of fiscal 2020 for royalties due on the sales of Huawei’s consumer wireless products.

[0001728949-20-000031:mdna:109]
Second quarter 2020 vs. 2019

[0001728949-20-000031:mdna:110]
The decrease in QTL licensing revenues in the second quarter of fiscal 2020 was primarily due to:

[0001728949-20-000031:mdna:111]
- $150 million in lower royalty revenues from Huawei due to the expiration of the interim agreement

[0001728949-20-000031:mdna:112]
- $76 million in lower estimated revenues per unit, in part reflecting licensees entering into new 5G multimode license agreements with rights to our cellular standard-essential patents only (compared to previous licenses which also included rights to certain other non-cellular essential patents) and decreases in our per unit royalty caps

[0001728949-20-000031:mdna:113]
+ $182 million increase in estimated sales of 3G/4G/5G-based products (including multimode products), primarily due to the new license agreement with Apple, partially offset by the negative impact of COVID-19 to licensees’ sales

[0001728949-20-000031:mdna:114]
QTL EBT as a percentage of revenues increased in the second quarter of fiscal 2020 primarily due to:

[0001728949-20-000031:mdna:115]
+ lower selling, general and administrative expenses, primarily from lower litigation costs

[0001728949-20-000031:mdna:116]
- higher research and development expenses

[0001728949-20-000031:mdna:117]
- lower QTL revenues

[0001728949-20-000031:mdna:118]
First six months 2020 vs. 2019

[0001728949-20-000031:mdna:119]
The increase in QTL licensing revenues in the first six months of fiscal 2020 was primarily due to:

[0001728949-20-000031:mdna:120]
+ $775 million increase in estimated sales of 3G/4G/5G-based products (including multimode products), primarily due to the new license agreement with Apple, which reflected the impact of Apple’s fall device launches in advance of the holiday season, partially offset by the negative impact of COVID-19 to licensees’ sales

[0001728949-20-000031:mdna:121]
- $300 million in lower royalty revenues from Huawei due to the expiration of the interim agreement

[0001728949-20-000031:mdna:122]
- $177 million in lower estimated revenues per unit, in part reflecting licensees entering into new 5G multimode license agreements with rights to our cellular standard-essential patents only (compared to previous licenses which also included rights to certain other non-cellular essential patents) and decreases in our per unit royalty caps

[0001728949-20-000031:mdna:123]
QTL EBT as a percentage of revenues increased in the first six months of fiscal 2020 primarily due to:

[0001728949-20-000031:mdna:124]
+ higher QTL revenues

[0001728949-20-000031:mdna:125]
+ lower selling, general and administrative expenses, primarily from lower litigation costs

[0001728949-20-000031:mdna:126]
- higher research and development expenses

[0001728949-20-000031:mdna:127]
[same as prior period, unchanged from 0001728949-20-000011:mdna:110]

[0001728949-20-000031:mdna:128]
[same as prior period, unchanged from 0001728949-20-000011:mdna:71]

[0001728949-20-000031:mdna:129]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | March 29,2020 |  | March 31,2019 |  | Change |  | March 29,2020 |  | March 31,2019 |  | Change |
| Equipment and services revenues |  | $ | 10 |  |  | $ | 98 |  |  | $ | (88) |  |  | $ | 30 |  |  | $ | 125 |  |  | $ | (95) |  |
| EBT |  | (208) |  |  | 17 |  |  | (225) |  |  | (210) |  |  | 25 |  |  | (235) |  |

[0001728949-20-000031:mdna:130]
Second quarter 2020 vs. 2019

[0001728949-20-000031:mdna:131]
The decrease in QSI EBT in the second quarter of fiscal 2020 was primarily due to:

[0001728949-20-000031:mdna:132]
-  $203 million increase in impairment losses on other investments, of which a significant portion related to the full impairment of our investment in OneWeb (an equity method investee) who filed for bankruptcy in the second quarter of fiscal 2020

[0001728949-20-000031:mdna:133]
-  $88 million decrease in revenues associated with certain development contracts with OneWeb

[0001728949-20-000031:mdna:134]
+  $36 million increase in net gains on investments

[0001728949-20-000031:mdna:135]
+  $26 million decrease in our share of equity method investee losses

[0001728949-20-000031:mdna:136]
First six months 2020 vs. 2019

[0001728949-20-000031:mdna:137]
The decrease in QSI EBT in the first six months of fiscal 2020 was primarily due to:

[0001728949-20-000031:mdna:138]
-  $264 million increase in impairment losses on other investments, of which a significant portion related to our investment in OneWeb

[0001728949-20-000031:mdna:139]
-  $95 million decrease in revenues associated with certain development contracts with OneWeb

[0001728949-20-000031:mdna:140]
+  $81 million increase in net gains on investments

[0001728949-20-000031:mdna:141]
+  $29 million decrease in our share of equity method investee losses

[0001728949-20-000031:mdna:142]
QSI segment assets, which primarily consist of non-marketable and marketable equity investments, decreased by 25% in the first six months of fiscal 2020 from $1.71 billion to $1.28 billion, primarily due to impairment losses on other investments and the sale of certain marketable equity investments.

[0001728949-20-000031:mdna:143]
[same as prior period, unchanged from 0001728949-20-000011:mdna:77]

[0001728949-20-000031:mdna:144]
In the coming years, we expect consumer demand for 3G/4G multimode and 4G products and services to decline as new consumer demand for 3G/4G/5G multimode and 5G products and services ramps around the world. We expect growth in emerging device categories and industries, resulting from the expanding adoption of certain technologies that are already commonly used in smartphones by industry segments outside traditional cellular industries, such as automotive, computing, IoT and networking.

[0001728949-20-000031:mdna:145]
[same as prior period, unchanged from 0001728949-20-000011:mdna:79]

[0001728949-20-000031:mdna:146]
•It is likely that the economic slowdown caused by the COVID-19 pandemic will continue, potentially for an extended duration, and there may be a global recession. We expect the pandemic to have an increasingly negative impact on QTL and QCT revenues in the near term based on a reduction in consumer demand for smartphones and other products. Our current planning assumption is that sales in China for devices that incorporate our products and intellectual property will continue to improve throughout the June quarter, which reflects gradual recovery from the exit rate of the March quarter. Outside of China, our current planning assumption is that device sales will follow a similar pattern to that experienced in China, with a recovery starting in June. Our near-term planning assumptions also reflect the latest demand signals from our customers as they contemplate the impact of COVID-19 and reconcile their supply chains to lower anticipated device sell through. We have not experienced, and we currently do not anticipate a material adverse impact on our ability, or our suppliers’ ability, to manufacture and test our products or on our ability to provide our products to our customers. Workforce changes that we implemented in the second quarter of fiscal 2020 are expected to remain in effect in the near term. The degree to which the COVID-19 pandemic impacts our business, financial condition and results of operations will depend on future developments, which are highly uncertain. See “Risk Factors” in this Quarterly Report, specifically the Risk Factor entitled “The recent coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and we expect its impact will increase, at least in the near term.”

[0001728949-20-000031:mdna:147]
•In May 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the court issued an Order ruling against us and imposing certain injunctive relief. We disagree with the court’s conclusions, interpretation of the facts and application of the law. Accordingly, we filed a motion to stay certain of the remedies with, and appealed the decision to, the Ninth Circuit Court of Appeals (Ninth Circuit). In July 2019, the Ninth

[0001728949-20-000031:mdna:148]
Circuit granted our appeal. In August 2019, the Ninth Circuit granted our partial motion to stay in its entirety. In February 2020, the Ninth Circuit heard oral arguments from Qualcomm and the FTC. The Ninth Circuit also heard oral arguments from the Department of Justice who presented positions in support of Qualcomm’s appeal. Regulatory authorities in certain other jurisdictions are investigating and/or have investigated our business practices and instituted proceedings against us, and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. These activities have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs until the respective matters are resolved. See “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report, including the Risk Factors entitled “Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations” and “Efforts by some OEMs or their customers to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.”

[0001728949-20-000031:mdna:149]
•We did not record any revenues in the first six months of fiscal 2020 for royalties due on the sales of Huawei’s consumer wireless products, and our license agreement with Huawei expired on December 31, 2019. The agreement provides either party the right to initiate binding arbitration for a period of several months, the result of which will be a new license agreement effective January 1, 2020. To date, neither party has initiated arbitration. Huawei may not make any other payments or may not make full payments due under the prior or any new license agreement. This may result in significant legal costs and will negatively impact our future revenues, as well as our financial condition, results of operations and cash flows, until the dispute is resolved.

[0001728949-20-000031:mdna:150]
•We have not been the sole supplier of modems for iPhone products beginning with products that launched in September 2016, and Apple is not utilizing our modems for iPhone products that launched in September 2019. We currently expect QCT to begin recording revenues in the second half of fiscal 2020 under our multi-year chipset agreement with Apple announced in April 2019.

[0001728949-20-000031:mdna:151]
•We expect our business, particularly QCT, to continue to be impacted by industry dynamics, including:

[0001728949-20-000031:mdna:152]
◦Increased concentration of device share among a few companies, particularly within the premium tier, resulting in significant supply chain leverage for those companies, and exacerbating the negative impact to our business and financial results to the extent those companies do not utilize our chipsets. For example, Huawei has taken, and may continue to take, share in China from other Chinese OEMs, negatively impacting QCT as we sell a limited number of chipsets to Huawei as compared to many of those other OEMs. In addition, the negative impact to our overall business of Huawei share gains at the expense of other Chinese OEMs may be further exacerbated if a new license agreement with Huawei is not signed in the near term and/or Huawei continues to not pay us royalties or does not make full payment due to us under the prior or any new license agreement;

[0001728949-20-000031:mdna:153]
◦Decisions by companies to utilize their own internally-developed integrated circuit products and/or sell such products to others, including by selling them together with certain of their other products;

[0001728949-20-000031:mdna:154]
◦Decisions by certain companies to utilize our competitors’ integrated circuit products in all or a portion of their devices;

[0001728949-20-000031:mdna:155]
◦Intense competition, particularly in China, as our competitors expand their product offerings and/or reduce the prices of their products as part of a strategy to attract new and/or retain existing customers;

[0001728949-20-000031:mdna:156]
[same as prior period, unchanged from 0001728949-20-000011:mdna:145]

[0001728949-20-000031:mdna:157]
◦Lengthened handset replacement cycles and consumer demand, which is increasingly driven by new product launches and/or innovation cycles; and

[0001728949-20-000031:mdna:158]
◦Growth of device share by certain Chinese OEMs in China and in regions outside of China.

[0001728949-20-000031:mdna:159]
•Current U.S./China trade relations and/or national security protection policies, which may be further exacerbated by COVID-19, may negatively impact our business, growth prospects and results of operations.

[0001728949-20-000031:mdna:160]
•Commercial 5G network deployments and device launches will continue through calendar 2020 and beyond. We currently anticipate no significant delays in the timing of 5G network deployments and device launches in key regions resulting from the impacts of COVID-19; however, the timing of such deployments may be delayed and consumer demand for devices that are launched has been and may continue to be negatively impacted by COVID-19. The degree to which such delays and lower demand impacts our future business, financial condition and results of operations will depend on future developments, which are uncertain. We believe that 5G technologies will empower a new era of smartphones and connected devices. We also believe that 5G will drive transformation across industries beyond traditional cellular communications that will create new business models and new services. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing of 5G technologies, and to be a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long term.

[0001728949-20-000031:mdna:161]
[same as prior period, unchanged from 0001728949-20-000011:mdna:95]

[0001728949-20-000031:mdna:162]
[same as prior period, unchanged from 0001728949-20-000011:mdna:96]

[0001728949-20-000031:mdna:163]
[same as prior period, unchanged from 0001728949-20-000011:mdna:97]

[0001728949-20-000031:mdna:164]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following table presents selected financial information related to our liquidity as of March 29, 2020 and September 29, 2019 and for the first six months of fiscal 2020 and 2019 (in millions):

[0001728949-20-000031:mdna:165]
|  | March 29,2020 |  | September 29,2019 |  | Change |  |  |
| Cash, cash equivalents and marketable securities | $ | 9,979 |  |  | $ | 12,296 |  |  | $ | (2,317) |  |  |  |
| Accounts receivable, net | 3,081 |  |  | 2,471 |  |  | 610 |  |  |  |
| Inventories | 1,700 |  |  | 1,400 |  |  | 300 |  |  |  |
| Short-term debt | 2,499 |  |  | 2,496 |  |  | 3 |  |  |  |
| Long-term debt | 13,449 |  |  | 13,437 |  |  | 12 |  |  |  |
| Noncurrent income taxes payable | 1,879 |  |  | 2,088 |  |  | (209) |  |  |  |

[0001728949-20-000031:mdna:166]
|  | Six Months Ended |  |  |  |  |  |  |
|  | March 29,2020 |  | March 31,2019 |  | Change |  |  |
| Net cash provided by operating activities | $ | 2,201 |  |  | $ | 1,150 |  |  | $ | 1,051 |  |  |  |
| Net cash used by investing activities | (1,769) |  |  | (261) |  |  | (1,508) |  |  |  |
| Net cash used by financing activities | (3,868) |  |  | (2,531) |  |  | (1,337) |  |  |  |

[0001728949-20-000031:mdna:167]
The net decrease in cash, cash equivalents and marketable securities was primarily due to $2.3 billion in payments to repurchase shares of our common stock, $1.4 billion in cash dividends paid, $641 million in capital expenditures and $232 million in payments of tax withholdings related to the vesting of share-based awards, partially offset by net cash provided by operating activities and $174 million in proceeds from the issuance of common stock.

[0001728949-20-000031:mdna:168]
The increase in accounts receivable was primarily due to an increase in QCT revenues combined with the timing of QCT integrated circuit shipments during the quarter and a decrease in the relative proportion of customer incentive arrangements

[0001728949-20-000031:mdna:169]
recorded as a reduction to QCT accounts receivable at March 29, 2020, as compared to September 29, 2019. The increase in inventories was primarily driven by the ramp in 5G.

[0001728949-20-000031:mdna:170]
Debt. At March 29, 2020, we had $15.5 billion of principal floating- and fixed-rate notes outstanding, $2.0 billion of which mature in May 2020. The remaining debt has maturity dates in 2022 through 2047.

[0001728949-20-000031:mdna:171]
Our Amended and Restated Revolving Credit Facility (Revolving Credit Facility) provides for unsecured revolving facility loans, swing line loans and letters of credit in the aggregate amount of up to $4.5 billion, which expires on November 8, 2021. At March 29, 2020, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-20-000031:mdna:172]
We have an unsecured commercial paper program, which currently provides for the issuance of up to $4.5 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At March 29, 2020, we had $499 million of commercial paper outstanding.

[0001728949-20-000031:mdna:173]
We currently expect to issue additional debt in the near future. COVID-19 has led to disruption and volatility in the global capital markets, which may adversely impact the cost of and access to capital. The amount and timing of such additional borrowings, if any, will depend on a number of factors, including maturities of our existing debt, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law. Additional information regarding our outstanding debt is provided in “Notes to Consolidated Financial Statements, Note 6. Debt” in our 2019 Annual Report on Form 10-K.

[0001728949-20-000031:mdna:174]
Income Taxes. At March 29, 2020, we estimated remaining future payments of $2.1 billion for the one-time U.S. repatriation tax accrued in fiscal 2018 (Toll Charge), after application of certain tax credits, which is payable in installments over the next six years. At March 29, 2020, other current liabilities included $176 million reflecting our estimate of the next installment due in January 2021.

[0001728949-20-000031:mdna:175]
[same as prior period, unchanged from 0001728949-20-000011:mdna:108]

[0001728949-20-000031:mdna:176]
Capital Return Program. In fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. In the first six months of fiscal 2020, we repurchased and retired 29.3 million shares of our common stock for $2.3 billion, before commissions. At March 29, 2020, $4.7 billion remained authorized for repurchase under the stock repurchase program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time. Subsequent to March 29, 2020, to maintain our financial liquidity position and flexibility, we suspended our stock repurchases, at least for the near-term, in light of COVID-19. We have the ability to reinstate repurchases if we determine it to be in the best interest of stockholders.

[0001728949-20-000031:mdna:177]
On March 10, 2020, we announced a 5% increase in our quarterly dividend per share of common stock from $0.62 to $0.65, which is effective for dividends payable after March 26, 2020.In the first six months of fiscal 2020, we paid cash dividends totaling $1.4 billion, or $1.24 per share. On April 21, 2020, we announced a cash dividend of $0.65 per share on our common stock, payable on June 25, 2020 to stockholders of record as of the close of business on June 4, 2020. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability, which may be impacted by COVID-19, and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-20-000031:mdna:178]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2019 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At March 29, 2020, there have been no material changes to our expected working and other capital requirements described in our 2019 Annual Report on Form 10-K. At March 29, 2020, $1.4 billion was accrued related to two fines imposed by the EC (based on the exchange rate at March 29, 2020, including related foreign currency gains and accrued interest). We have provided financial guarantees in lieu of cash payment to satisfy the obligations while we appeal the EC’s decisions.

[0001728949-20-000031:mdna:179]
Further, regulatory authorities in certain jurisdictions are investigating and/or have investigated our business practices and instituted proceedings against us, including the lawsuit filed against us by the FTC in which a ruling was issued in favor of the FTC in May 2019, and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees, have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0001728949-20-000031:mdna:180]
30

[0001728949-20-000031:mdna:181]
Although we expect future estimated operating cash flows to be adversely affected by the impact of COVID-19, most significantly through reduced QTL royalty revenues and QCT equipment revenues, we believe, based on our current business plan and the facts and factors known by us, our cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months. See “Risk Factors” in this Quarterly Report, including the Risk Factor entitled “The recent coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and we expect its impact will increase, at least in the near term.”

[0001728949-20-000031:mdna:182]
[same as prior period, unchanged from 0001728949-20-000011:mdna:116]

[0001728949-20-000031:mdna:183]
We have no significant contractual obligations not fully recorded on our consolidated balance sheets or fully disclosed in the notes to our condensed consolidated financial statements, or otherwise disclosed in our 2019 Annual Report on Form 10-K. We have no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001728949-20-000031:mdna:184]
Additional information regarding our financial commitments at March 29, 2020 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items,” “Note 3. Income Taxes” and “Note 5. Commitments and Contingencies.”

[0001728949-20-000031:mdna:185]
[same as prior period, unchanged from 0001728949-20-000011:mdna:119]

[0001728949-20-000031:mdna:186]
[same as prior period, unchanged from 0001728949-20-000011:mdna:120]

[0001728949-20-000031:mdna:187]
[same as prior period, unchanged from 0001728949-20-000011:mdna:121]

[0001728949-20-000031:mdna:188]
You should consider each of the following factors in evaluating our business and our prospects. The risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also negatively impact our business, results of operations, financial condition and cash flows, and require significant management time and attention. In that case, the trading price of our common stock could decline. In addition to the risks and uncertainties set forth in the Risk Factor below entitled “The recent coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and we expect its impact will increase, at least in the near term,” many of the risks and uncertainties set forth in the other Risk Factors below will be exacerbated by the COVID-19 pandemic, government and business responses thereto and any further resulting decline in the global business and economic environment. You should also consider the other information set forth in this Quarterly Report in evaluating our business and our prospects, including but not limited to our financial statements and the related notes, and “Part I, Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” References to “and” and “or” should be read to include the other as well as “and/or,” as appropriate.

[0001728949-20-000031:mdna:189]
[same as prior period, unchanged from 0001728949-20-000011:mdna:123]

[0001728949-20-000031:mdna:190]
The recent coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and we expect its impact will increase, at least in the near term.

[0001728949-20-000031:mdna:191]
The rapid, global spread of COVID-19 and the fear it has created has resulted in significant economic uncertainty, significant declines in business and consumer confidence and global demand in the wireless industry (among others), a global economic slowdown, and could lead to a global recession. Government policies and other preventive and precautionary measures that we, other businesses and governments have implemented to limit the spread of COVID-19, including but not limited to travel bans and restrictions, quarantines, shelter-in-place and social distancing orders, declarations of states of emergency and shutdowns, have exacerbated these issues and we expect will continue to do so, at least in the near term. Specifically, the decline in demand for smartphones and other consumer devices sold by our customers or licensees has resulted in decreased demand for our integrated circuit products (which are incorporated into such devices) and a decrease in the royalties we earn on the licensing of our intellectual property (which is dependent upon the number of such devices sold that utilize our intellectual property).

[0001728949-20-000031:mdna:192]
We expect that demand for our products and demand for the products of our customers or licensees will be increasingly negatively impacted in the near term, and to the extent that economic uncertainty, business and consumer confidence, demand for our products and demand for the products of our customers or licensees does not improve, our business and results of operations will be further negatively impacted.

[0001728949-20-000031:mdna:193]
The COVID-19 pandemic, and government policies and business measures in response thereto, such as those described above, have also negatively impacted the global wireless supply chain and workforce, including the manufacturing facilities and workforces of our suppliers, customers and licensees. In particular, travel bans and restrictions, quarantines, shelter-in-

[0001728949-20-000031:mdna:194]
[same as prior period, unchanged from 0001728949-20-000011:mdna:177]

[0001728949-20-000031:mdna:195]
place and social distancing orders, declarations of states of emergency and shutdowns have resulted in longer product cycle times, transportation, shipment and delivery delays, additional costs and reductions in output across the supply chain. However, to date, we have not seen a significant impact on our manufacturing facilities, the ability of our suppliers to deliver on their commitments to us, or our ability to ship our products to our customers, and we expect this to continue to be true, at least in the near term.

[0001728949-20-000031:mdna:196]
Nonetheless, continued negative effects on the global wireless supply chain could result in a reduction in our ability, or our inability, to supply our products to our customers, or a reduction in the ability, or the inability, of our suppliers to deliver on their commitments to us or of our customers or licensees to supply their products to consumers or other end users. In addition, if the suppliers (or their suppliers) that we rely on to perform the manufacturing and assembly, and most of the testing, of our integrated circuits produced in our fabless production model, the suppliers (or their suppliers) of raw materials or products utilized in our facilities that manufacture our RFFE modules and RF filter acoustic products, or our sources of distribution or transportation, continue to be or are further impacted, we may need to procure alternative or additional suppliers or sources of distribution or transportation, which may not be available or which may increase our costs or cause delays in our ability to provide our products to our customers or licensees. This risk is exacerbated to the extent we procure products, services or materials from a single source or limited sources. See also the Risk Factor entitled “We depend on a limited number of third-party suppliers for the procurement, manufacture and testing of our products manufactured in a fabless production model. If we fail to execute supply strategies that provide technology leadership, supply assurance and reasonable margins, our business and results of operations may be harmed. We are also subject to order and shipment uncertainties that could negatively impact our results of operations.”

[0001728949-20-000031:mdna:197]
Further, the spread of COVID-19 has caused us to modify our workforce practices, and we may take further actions that we determine are in the best interests of our employees or as required by governments. Since January 2020, we have complied with government restrictions in China which have limited our employees’ ability to work in our offices in China, although such restrictions have since lessened. On March 12, 2020, we announced a global mandatory work from home policy for all of our other employees who are able to perform their jobs remotely, which remains in place. Prior to this announcement, we took various other measures to mitigate the risk to our employees and operations globally, including certain employee travel and visitor restrictions, and cancellation of or limitations on physical participation in meetings, events and conferences, among others. On March 19, 2020, California, where our corporate headquarters is located, issued a shelter-in-place order, and other states and countries where we have employees have implemented similar restrictions. While this has not been the case to date, our business and results of operations could be negatively affected if a significant number of our employees, or employees who perform critical functions such as certain engineering employees, employees necessary to maintain the continuity of our business operations, or employees that are critical to complete and support our key accounting close processes, financial reporting systems, internal control over financial reporting and disclosure controls and procedures, become ill and/or are quarantined as the result of exposure to COVID-19, or if government policies restrict the ability of those employees to perform their critical functions. Any actions we take with respect to our workforce may not be sufficient to mitigate the risks posed by COVID-19, and our ability to perform critical functions could be harmed.

[0001728949-20-000031:mdna:198]
We expect the foregoing demand, supply and workforce issues to continue, and in some instances increase, at least in the near term. Our business, financial condition and results of operations could also be impacted by delayed, reduced or cancelled customer orders; the inability of our customers or licensees to purchase or pay for our products or technologies; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our customers or licensees; or failures by other counterparties.

[0001728949-20-000031:mdna:199]
Further, trade and/or national security protection policies may be adjusted as a result of the COVID-19 pandemic, such as actions by governments that limit, restrict or prevent the movement of certain goods into a country and/or region, and current U.S./China trade relations may be further exacerbated by the pandemic.

[0001728949-20-000031:mdna:200]
We monitor goodwill and other long-lived assets for events or changes in circumstances in interim periods that could indicate such assets may be impaired. At September 29, 2019, the estimated fair values of our QCT and QTL reporting units were substantially in excess of their respective carrying values. Based on facts and factors currently known by us, we did not record any impairment of goodwill or other long-lived assets during the second quarter of fiscal 2020 as a result of the impact of the COVID-19 pandemic on our business. Although we believe that our estimates and the assumptions supporting our impairment assessments are reasonable, future events or changes in circumstances could cause us to conclude that impairment indicators exist, and that goodwill or other long-lived assets are impaired.

[0001728949-20-000031:mdna:201]
In addition, in the second quarter of fiscal 2020, we recorded impairment losses on certain of our equity method and non-marketable equity and debt investments in part resulting from the impact of COVID-19, and we may in the future record additional impairment losses in part or entirely resulting from COVID-19. Any resulting impairment losses in the future could have an adverse impact on our financial condition and results of operations. Further, while we have experienced

[0001728949-20-000031:mdna:202]
minimal impact to date, our customers or licensees may experience a negative impact to their cash flow, which may impact our ability to recognize revenues and/or result in the recognition of an allowance for doubtful accounts related to our accounts receivables, both of which would adversely impact our results of operations.

[0001728949-20-000031:mdna:203]
The degree to which the COVID-19 pandemic impacts our future business, financial condition and results of operations will depend on future developments, which are uncertain, including but not limited to the duration, spread and severity of the pandemic, government responses and other actions to mitigate the spread of and to treat COVID-19, and when and to what extent normal business, economic and social activity and conditions resume. We are similarly unable to predict the extent to which the pandemic impacts our customers, licensees, suppliers and other partners (and their suppliers and partners) and their financial conditions, but adverse effects on these parties could also adversely affect us. Finally, the COVID-19 pandemic makes it challenging for management to estimate the future performance of our business.

[0001728949-20-000031:mdna:204]
[same as prior period, unchanged from 0001728949-20-000011:mdna:124]

[0001728949-20-000031:mdna:205]
[same as prior period, unchanged from 0001728949-20-000011:mdna:125]

[0001728949-20-000031:mdna:206]
We have historically been successful during wireless technology transitions, including 3G and 4G. The latest generation of wireless technologies is 5G, which we expect will empower a new era of connected devices and will be utilized not only in handsets but also in new device types, industries and applications beyond traditional cellular communications, as described above (see also Part I, Item 1, “Business” in our most recent Annual Report on Form 10-K for further description of 5G). Commercial deployments of 5G networks and devices have begun and will continue through fiscal 2020 and beyond. However, the timing and scale of such deployments, in certain regions, may be delayed due to the COVID-19 pandemic. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and technology licensing, and that we develop, commercialize and be a leading supplier of 5G integrated circuit products and services, in order to sustain and grow our business long-term.

[0001728949-20-000031:mdna:207]
[same as prior period, unchanged from 0001728949-20-000011:mdna:128]

[0001728949-20-000031:mdna:208]
•wireless operators and industries beyond traditional cellular communications deploy alternative technologies;

[0001728949-20-000031:mdna:209]
•wireless operators delay next-generation network deployments, expansions or upgrades or delay moving customers to 3G/4G and 3G/4G/5G multimode devices, as well as 4G and 5G single-mode devices;

[0001728949-20-000031:mdna:210]
•government regulators delay making sufficient spectrum available for 4G and 5G wireless technologies, including unlicensed spectrum and shared spectrum technologies, thereby delaying or precluding the initial deployment or expanded deployment of these technologies;

[0001728949-20-000031:mdna:211]
•wireless operators delay or do not drive improvements in 4G or 5G, or 3G/4G or 3G/4G/5G multimode network performance and capacity;

[0001728949-20-000031:mdna:212]
•our customers’ and licensees’ revenues and sales of products, particularly premium-tier products, and services using these technologies, and average selling prices of such products, decline, do not grow or do not grow meaningfully due to, for example, the maturity of smartphone penetration in developed regions and China;

[0001728949-20-000031:mdna:213]
•our intellectual property and technical leadership included in the continued 5G standardization effort is less than in 3G and 4G standards;

[0001728949-20-000031:mdna:214]
•the continued standardization or commercial deployment of 5G technologies is delayed or not widely deployed and/or adopted;

[0001728949-20-000031:mdna:215]
•we are unable to drive the adoption of our products and services into networks and devices, including devices beyond traditional cellular applications, based on CDMA, OFDMA and other communications technologies; or

[0001728949-20-000031:mdna:216]
•consumers’ rates of replacement of smartphones and other computing devices decline, do not grow or do not grow meaningfully.

[0001728949-20-000031:mdna:217]
33

[0001728949-20-000031:mdna:218]
[same as prior period, unchanged from 0001728949-20-000011:mdna:139]

[0001728949-20-000031:mdna:219]
Our products, services and technologies face significant competition. We expect competition to increase as our current competitors expand their product offerings, improve their products or reduce the prices of their products as part of a strategy to maintain existing business and customers or attract new business and customers, as new opportunities develop, and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: OEM concentrations; vertical integration; growth in demand, consumption and competition in certain geographic regions; government intervention or support of national industries or competitors; evolving industry standards and business models; evolving methods of transmission of voice and data communications; increasing data traffic and densification of wireless networks; convergence and aggregation of connectivity technologies (including Wi-Fi and LTE) in both devices and access points; consolidation of wireless technologies and infrastructure at the network edge; networking and connectivity trends (including cloud services); use of licensed, shared and unlicensed spectrum; the evolving nature of computing (including demand for always on, always connected capabilities); the speed of technological change (including the transition to smaller geometry process technologies); value-added features that drive selling prices and consumer demand for new 3G/4G and 3G/4G/5G multimode devices, as well as 3G, 4G and 5G single-mode devices; turnkey, integrated products that incorporate hardware, software, user interface, applications and reference designs; scalability; and the ability of the system technology to meet customers’ immediate and future network requirements.

[0001728949-20-000031:mdna:220]
We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, technological and public policy changes and relatively low barriers to entry in certain segments of the industry. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape.

[0001728949-20-000031:mdna:221]
[same as prior period, unchanged from 0001728949-20-000011:mdna:141]

[0001728949-20-000031:mdna:222]
•differentiate our integrated circuit products with innovative technologies across multiple products and features (e.g., modem, Radio Frequency front-end (RFFE), graphics and other processors, camera and connectivity) and with smaller geometry process technologies that drive both performance and lower power consumption;

[0001728949-20-000031:mdna:223]
•develop and offer integrated circuit products at competitive cost and price points to effectively cover all geographic regions and all device tiers;

[0001728949-20-000031:mdna:224]
•drive the adoption of our integrated circuit products into the most popular device models and across a broad spectrum of devices, such as smartphones, tablets, laptops and other computing devices, automobiles, wearables, voice and music and other connected devices and infrastructure products;

[0001728949-20-000031:mdna:225]
•maintain or accelerate demand for our integrated circuit products at the premium device tier, while also driving the adoption of our 5G products into high, mid- and low-tier devices across all regions;

[0001728949-20-000031:mdna:226]
•continue to be a leader in 4G and 5G technology evolution and continue to innovate and introduce 4G and 5G turnkey, integrated products and services that differentiate us from our competition;

[0001728949-20-000031:mdna:227]
•remain a leader in 5G technology development, standardization, intellectual property creation and licensing, and develop, commercialize and be a leading supplier of 5G integrated circuit products and services;

[0001728949-20-000031:mdna:228]
•increase or accelerate demand for our semiconductor component products, including RFFE, and our wireless connectivity products, including networking products for consumers, carriers and enterprise equipment and connected devices;

[0001728949-20-000031:mdna:229]
•become a leading supplier of RFFE products, which are designed to address cellular RF band fragmentation while improving RF performance and assist OEMs in developing multiband, multimode mobile devices;

[0001728949-20-000031:mdna:230]
•create standalone value and contribute to the success of our existing businesses through acquisitions, joint ventures and other transactions, and by developing customer, licensee, vendor, distributor and other channel relationships in new industry segments and with disruptive technologies, products and services, such as products for automotive, computing, IoT (including the connected home, smart cities, wearables, voice and music and robotics) and networking, among others;

[0001728949-20-000031:mdna:231]
•identify potential acquisition targets that will grow or sustain our business or address strategic needs, reach agreement on terms acceptable to us, close the transactions and effectively integrate these new businesses, products and technologies;

[0001728949-20-000031:mdna:232]
•provide a leading service to OEMs, high level operating systems (HLOS) providers, operators, cloud providers and other industry participants as competitors, new industry entrants and other factors continue to affect the industry landscape;

[0001728949-20-000031:mdna:233]
•be a preferred partner and sustain preferred relationships providing integrated circuit products that support multiple operating system and infrastructure platforms to industry participants that effectively commercialize new devices using these platforms; and

[0001728949-20-000031:mdna:234]
•continue to develop brand recognition to effectively compete against better known companies in computing and other consumer driven segments and to deepen our presence in significant emerging regions and China.

[0001728949-20-000031:mdna:235]
[same as prior period, unchanged from 0001728949-20-000011:mdna:156]

[0001728949-20-000031:mdna:236]
In particular, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past utilized, and currently utilize, in certain of their devices and may in the future choose to utilize in certain (or all) of their devices, rather than our products (and they may sell their integrated circuit products to third parties, discretely or together with certain of their other products, in competition with us). Also, Apple, which has historically been one of our largest customers, has utilized products of one of our competitors in many of its devices rather than our products, and is solely utilizing one of our competitors’ products in its most recent smartphone launches. In April 2019, we entered into a new multi-year chipset supply agreement with Apple. We currently expect to begin recording revenues under this agreement in the second half of fiscal 2020. However, Apple may choose to use our competitors’ products or its own modem products in one or more of its future devices.

[0001728949-20-000031:mdna:237]
[same as prior period, unchanged from 0001728949-20-000011:mdna:158]

[0001728949-20-000031:mdna:238]
[same as prior period, unchanged from 0001728949-20-000011:mdna:159]

[0001728949-20-000031:mdna:239]
[same as prior period, unchanged from 0001728949-20-000011:mdna:160]

[0001728949-20-000031:mdna:240]
Our QCT segment derives a significant portion of its revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. Chinese OEMs continue to grow their device share in China and are increasing their device share in regions outside of China, and we derive a significant and increasing portion of our revenues from a small number of these OEMs. In addition, certain of our largest integrated

[0001728949-20-000031:mdna:241]
circuit customers develop their own integrated circuit products, which they have in the past utilized, and currently utilize, in certain of their devices and may in the future choose to utilize in certain (or all) of their devices, rather than our products (and they may sell their integrated circuit products to third parties, discretely or together with certain of their other products, in competition with us). Also, Apple, which has historically been one of our largest customers, has utilized products of one of our competitors in many of its devices rather than our products, and is solely utilizing one of our competitor’s products in its most recent smartphone launches. In April 2019, we entered into a new multi-year chipset supply agreement with Apple. We currently expect to begin recording revenues under this agreement in the second half of fiscal 2020. However, Apple may choose to use our competitors’ products or its own modem products in one or more of its future devices.

[0001728949-20-000031:mdna:242]
Similarly, certain of our Chinese OEM customers have developed and others may in the future develop their own integrated circuit products and use such integrated circuit products, or other integrated circuit products, in their devices rather than our integrated circuit products, including due to pressure from the Chinese government as part of its broader economic policies, the OEMs’ concerns over losing access to our integrated circuit products as a result of U.S./China trade tensions, or otherwise.

[0001728949-20-000031:mdna:243]
[same as prior period, unchanged from 0001728949-20-000011:mdna:163]

[0001728949-20-000031:mdna:244]
In addition, we spend a significant amount of engineering and development time, funds and resources in understanding our key customers’ feedback and/or specifications and attempt to incorporate such input into our product launches and technologies. These efforts may not require or result in purchase commitments from such customers or we may have lower purchases from such customers than expected, and consequently, we may not achieve the anticipated revenues from these efforts, or these efforts may result in non-recoverable costs.

[0001728949-20-000031:mdna:245]
The loss of any one of our significant customers, a reduction in the purchases of our products by such customers or the cancelation of significant purchases by any of these customers, whether due to the use of their own integrated circuit products or our competitors’ integrated circuit products, government restrictions or otherwise, would reduce our revenues and could harm our ability to achieve or sustain expected results of operations, and a delay of significant purchases, even if only temporary, would reduce our revenues in the period of the delay. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development. Further, the concentration of device share among a few companies, and the corresponding purchasing power of these companies, may result in lower prices for our products which, if not accompanied by a sufficient increase in the volume of purchases of our products, could have an adverse effect on our revenues and margins. In addition, the timing and size of purchases by our significant customers may be impacted by the timing of such customers’ new or next generation product introductions, over which we have no control, and the timing and success of such introductions may cause our revenues and results of operations to fluctuate. Accordingly, if current industry dynamics continue, our QCT segment’s revenues will continue to depend largely upon, and be impacted by, future purchases, and the timing and size of any such future purchases, by these significant customers.

[0001728949-20-000031:mdna:246]
Further, to the extent Apple purchases our modem products, it purchases our MDM (or thin modem) products, which do not include our integrated application processor technology, and which have lower revenue and margin contributions than our combined modem and application processor products. To the extent Apple takes device share from our customers who purchase our integrated modem and application processor products, our revenues and margins may be negatively impacted.

[0001728949-20-000031:mdna:247]
[same as prior period, unchanged from 0001728949-20-000011:mdna:168]

[0001728949-20-000031:mdna:248]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products or intellectual property, and rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001728949-20-000031:mdna:249]
Although we have more than 300 licensees, our QTL segment derives a significant portion of its revenues from a limited number of licensees, which increasingly includes a small number of Chinese OEMs. In the event that one or more of our significant licensees fail to meet their reporting and payment obligations, or we are unable to renew or modify one or more of such license agreements under similar terms, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We do not have control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful.

[0001728949-20-000031:mdna:250]
36

[0001728949-20-000031:mdna:251]
Reductions in sales of our licensees’ products, or reductions in the average selling prices of wireless devices sold by our licensees without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues. Such adverse impact may be mitigated by our per unit royalty caps that apply to certain categories of our licensees’ complete wireless devices, namely smartphones, tablets, laptops and smartwatches.

[0001728949-20-000031:mdna:252]
[same as prior period, unchanged from 0001728949-20-000011:mdna:171]

[0001728949-20-000031:mdna:253]
[same as prior period, unchanged from 0001728949-20-000011:mdna:172]

[0001728949-20-000031:mdna:254]
[same as prior period, unchanged from 0001728949-20-000011:mdna:173]

[0001728949-20-000031:mdna:255]
A reduction in sales of premium-tier devices, a reduction in sales of our premium-tier integrated circuit products (which have a higher revenue and margin contribution than our lower-tier integrated circuit products) or a shift in share away from OEMs that utilize our premium-tier products, would reduce our revenues and margins and may harm our ability to achieve or sustain expected financial results. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0001728949-20-000031:mdna:256]
[same as prior period, unchanged from 0001728949-20-000011:mdna:175]

[0001728949-20-000031:mdna:257]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, taking a position that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) various attempts by licensees to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated.

[0001728949-20-000031:mdna:258]
[same as prior period, unchanged from 0001728949-20-000011:mdna:179]

[0001728949-20-000031:mdna:259]
We have been in the past and are currently subject to various litigation and governmental investigations and proceedings, including the lawsuit filed against us by the FTC. Certain of these matters are described more fully in this Quarterly Report in

[0001728949-20-000031:mdna:260]
[same as prior period, unchanged from 0001728949-20-000011:mdna:231]

[0001728949-20-000031:mdna:261]
“Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See also the Risk Factors below entitled “Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings” and “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations.”

[0001728949-20-000031:mdna:262]
[same as prior period, unchanged from 0001728949-20-000011:mdna:181]

[0001728949-20-000031:mdna:263]
Further, some companies or entities have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions should not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by severely limiting the base upon which the royalty rate may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies. Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001728949-20-000031:mdna:264]
We expect that such proposals, interpretations and strategies will continue in the future, and if successful, our business model would be harmed, either by limiting or eliminating our ability to collect royalties (or by reducing the royalties we can collect) on all or a portion of our standard-essential patent portfolio, limiting our return on investment with respect to new technologies, limiting our ability to seek injunctions against infringers of our standard-essential patents, constraining our ability to make licensing commitments when submitting our technology for inclusion in future standards (which could make our technology less likely to be included in such standards) or forcing us to work outside of SDOs or other industry groups to promote our new technologies, and our revenues, results of operations and cash flows could be negatively impacted. In addition, the legal and other costs associated with asserting or defending our positions have been and continue to be significant. We assume that such challenges, regardless of their merits, will continue into the foreseeable future and will require the investment of substantial management time and financial resources.

[0001728949-20-000031:mdna:265]
[same as prior period, unchanged from 0001728949-20-000011:mdna:186]

[0001728949-20-000031:mdna:266]
We have been in the past and are currently subject to various governmental investigations and proceedings, particularly with respect to our licensing business, including the lawsuit filed against us by the FTC. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Key allegations or findings in those matters include, among others, that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers, that our royalty rates are too high, that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions), that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets, that we have entered into exclusive agreements with chipset customers that foreclose competition, and that we violate antitrust laws, engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-20-000031:mdna:267]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our

[0001728949-20-000031:mdna:268]
royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any licensing or royalty revenues under such agreements. The renegotiation of license agreements could lead to arbitration or litigation to resolve the licensing terms, which could be less favorable to us than existing terms, and each of which could take months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. Further, if our appeal in the FTC lawsuit is unsuccessful, it could have a material adverse effect on our business. The occurrence of any of the above could have a material adverse effect on our business, results of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies such as 5G. Further, depending on the breadth and severity of the circumstances above, we may have to reduce or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region.

[0001728949-20-000031:mdna:269]
[same as prior period, unchanged from 0001728949-20-000011:mdna:189]

[0001728949-20-000031:mdna:270]
Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations.

[0001728949-20-000031:mdna:271]
As described in the Risk Factor above entitled “Our business, particularly our licensing business, may suffer as a result of adverse rulings in government investigations or proceedings,” we have been in the past and are currently subject to various governmental investigations and proceedings, as well as private legal proceedings, challenging our patent licensing and chipset sales practices, including the lawsuit filed against us by the FTC. Certain of these matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We believe that one intent of certain of these investigations and legal proceedings is to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-20-000031:mdna:272]
We historically licensed our cellular standard-essential patents together with our other patents that may be useful to licensed products because licensees desired to obtain the commercial benefits of receiving such broad patent rights from us. However, we also licensed only our cellular standard-essential patents to licensees who requested such licenses. Since 2015, our standard practice in China is to offer licenses to our 3G and 4G (and now 5G) cellular standard-essential Chinese patents for devices sold for use in China separately from our other patents. In addition, we also offer licenses to only our cellular standard-essential patents (including 3G, 4G and 5G) for both single-mode and multimode devices on a worldwide basis, and since 2018, an increasing number of new and existing licensees have elected to enter into worldwide license agreements covering only our cellular standard-essential patents. Going forward, we anticipate that a significant portion of our licensing revenues will continue to be derived from licensees that have entered into license agreements covering only our cellular standard-essential patents. Our royalty rates for licenses to only our cellular standard-essential patents are lower than our royalty rates for licenses to substantially all of our patent portfolio. If more licensees choose to obtain a license to only our cellular standard-essential patents instead of a portfolio license than has historically been the case, our licensing revenues and earnings would be negatively impacted unless we were able to license our other patents at rates that offset all or a portion of any difference between the royalties previously received for licenses of substantially all of our patent portfolio as compared to licenses of only our cellular standard-essential patents or there was a sufficient increase in the overall volume of sales of devices upon which royalties are paid.

[0001728949-20-000031:mdna:273]
If we were required to grant patent licenses to chipset manufacturers (which could lead to implementing a more complex, multi-level licensing structure in which we license certain portions of our patent portfolio to chipset manufacturers and other portions to OEMs), we would incur additional transaction costs, which may be significant, and we could incur delays in recognizing revenues until license negotiations were completed. In addition, our licensing revenues and earnings would be

[0001728949-20-000031:mdna:274]
39

[0001728949-20-000031:mdna:275]
negatively impacted if we were not able to obtain, in the aggregate, equivalent revenues under such a multi-level licensing structure.

[0001728949-20-000031:mdna:276]
If we were required to reduce the royalty rates in our patent license agreements, our revenues, earnings and cash flows would be negatively impacted absent a sufficient increase in the volume of sales of devices upon which royalties are paid. Similarly, if we were required to reduce the base on which our royalties are calculated, our revenues, results of operations and cash flows would be negatively impacted unless there was a sufficient increase in the volume of sales of devices upon which royalties are paid or we were able to increase our royalty rates to offset the decrease in revenues resulting from such lower royalty base (assuming the absolute royalty dollars were below any relevant royalty caps).

[0001728949-20-000031:mdna:277]
If we were required to sell chipsets to OEMs that do not have a license to our patents, our licensing program could be negatively impacted by patent exhaustion claims raised by such unlicensed OEMs (i.e., claims that our sale of chipsets to such OEMs forecloses us from asserting any patents substantially embodied by the chipsets against such OEMs). Such sales would provide OEMs with a defense in the event we asserted our patents against them to obtain licensing revenue for those patents. This could have a material adverse effect on our licensing program and our results of operations, financial condition and cash flows.

[0001728949-20-000031:mdna:278]
[same as prior period, unchanged from 0001728949-20-000011:mdna:197]

[0001728949-20-000031:mdna:279]
[same as prior period, unchanged from 0001728949-20-000011:mdna:198]

[0001728949-20-000031:mdna:280]
The enforcement and protection of our intellectual property rights may be expensive, could fail to prevent misappropriation or unauthorized use of our intellectual property, could result in the loss of our ability to enforce one or more patents, and could be adversely affected by changes in patent laws, by laws in certain foreign jurisdictions that may not effectively protect our intellectual property rights and by ineffective enforcement of laws in such jurisdictions.

[0001728949-20-000031:mdna:281]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our proprietary information, technologies and processes, including our patent portfolio. Policing unauthorized use of our products, technologies and proprietary information is difficult and time consuming. The steps we have taken have not always prevented, and we cannot be certain the steps we will take in the future will prevent, the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as U.S. laws or where the enforcement of such laws may be lacking or ineffective. See also the Risk Factor entitled “Our business and operations could suffer in the event of security breaches of our information technology systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0001728949-20-000031:mdna:282]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that the European Union (EU) will adopt a unitary patent system in the next few years that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-20-000031:mdna:283]
We have had, currently have, and may in the future have, difficulty in certain circumstances in protecting or enforcing our intellectual property rights and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies of foreign governments; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business and the pricing and integration of additional features and functionality into our chipset products. Certain licensees have disputed, underreported,

[0001728949-20-000031:mdna:284]
underpaid, not reported or not paid royalties owed to us under their license agreements with us or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or have delayed entering into or renewing license agreements for their use of our intellectual property. Further, certain licensees and companies are currently engaged in such behavior and they or others may engage in such behavior in the future. The fact that one or more licensees dispute, underreport, underpay, do not report or do not pay royalties owed to us may encourage other licensees to take similar actions or not renew their existing license agreements, and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Additionally, although our license agreements provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements. Similarly, we provide access to certain of our intellectual property and proprietary and confidential business information to our direct and indirect customers and licensees, who have in the past and may in the future wrongfully use such intellectual property and information or wrongfully disclose such intellectual property and information to third parties, including our competitors. See also the Risk Factor entitled “Efforts by some OEMs or their customers to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.”

[0001728949-20-000031:mdna:285]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0001728949-20-000031:mdna:286]
Our growth increasingly depends on our ability to extend our technologies, products and services into new and expanded product areas, such as RFFE, and adjacent industry segments and applications outside of traditional cellular industries, such as automotive, computing, IoT and networking, among others. Our research, development and other investments in these new and expanded product areas, industry segments and applications, and related technologies, products and services, as well as in our existing technologies, products and services and new technologies, such as 5G, may not generate operating income or contribute to future results of operations that meet our expectations.

[0001728949-20-000031:mdna:287]
[same as prior period, unchanged from 0001728949-20-000011:mdna:208]

[0001728949-20-000031:mdna:288]
[same as prior period, unchanged from 0001728949-20-000011:mdna:209]

[0001728949-20-000031:mdna:289]
[same as prior period, unchanged from 0001728949-20-000011:mdna:210]

[0001728949-20-000031:mdna:290]
41

[0001728949-20-000031:mdna:291]
[same as prior period, unchanged from 0001728949-20-000011:mdna:211]

[0001728949-20-000031:mdna:292]
[same as prior period, unchanged from 0001728949-20-000011:mdna:212]

[0001728949-20-000031:mdna:293]
[same as prior period, unchanged from 0001728949-20-000011:mdna:213]

[0001728949-20-000031:mdna:294]
[same as prior period, unchanged from 0001728949-20-000011:mdna:214]

[0001728949-20-000031:mdna:295]
[same as prior period, unchanged from 0001728949-20-000011:mdna:215]

[0001728949-20-000031:mdna:296]
In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the automotive, computing, IoT and networking industry segments. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties at all or that are equivalent to those that we receive for products used in cellular communications. Although we believe that our patented technologies are essential and useful to the commercialization of such services, any royalties we receive may be lower than those we receive from our current licensing program.

[0001728949-20-000031:mdna:297]
Further, the licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, all of our patent license agreements in China that were entered into in 2015 or thereafter, as well as our recent worldwide cellular standard-essential patent only agreements, are effective for a specified term. In order to license or to obtain a license to such later patents or after the expiration of the specified term, and to receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. In particular, our license agreement with Huawei expired on December 31, 2019. Such agreement provides either party with the right to initiate binding arbitration for a period of several months, the result of which will be a new license agreement. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001728949-20-000031:mdna:298]
We depend on a limited number of third-party suppliers for the procurement, manufacture and testing of our products manufactured in a fabless production model. If we fail to execute supply strategies that provide technology leadership,

[0001728949-20-000031:mdna:299]
42

[0001728949-20-000031:mdna:300]
supply assurance and reasonable margins, our business and results of operations may be harmed. We are also subject to order and shipment uncertainties that could negatively impact our results of operations.

[0001728949-20-000031:mdna:301]
[same as prior period, unchanged from 0001728949-20-000011:mdna:220]

[0001728949-20-000031:mdna:302]
[same as prior period, unchanged from 0001728949-20-000011:mdna:221]

[0001728949-20-000031:mdna:303]
•a reduction, interruption, delay or limitation in our product supply sources;

[0001728949-20-000031:mdna:304]
•a failure by our suppliers to procure raw materials, or to provide or allocate adequate raw materials or manufacturing or test capacity, for our products;

[0001728949-20-000031:mdna:305]
•our suppliers’ inability to react to shifts in product demand or an increase in raw material or component prices;

[0001728949-20-000031:mdna:306]
•our suppliers’ delay in developing leading process technologies, or inability to develop or maintain leading process technologies, including transitions to smaller geometry process technologies;

[0001728949-20-000031:mdna:307]
•the loss of a supplier or the inability of a supplier to meet performance, quality or yield specifications or delivery schedules;

[0001728949-20-000031:mdna:308]
•additional expense or production delays as a result of qualifying a new supplier and commencing volume production or testing in the event of a loss of, or a decision to add or change, a supplier;

[0001728949-20-000031:mdna:309]
•natural disasters or geopolitical conflicts impacting our suppliers; and

[0001728949-20-000031:mdna:310]
•health crises, including epidemics or pandemics, such as the COVID-19 pandemic, and government and business responses thereto, which impact our suppliers, including as a result of quarantines or closure.

[0001728949-20-000031:mdna:311]
[same as prior period, unchanged from 0001728949-20-000011:mdna:230]

[0001728949-20-000031:mdna:312]
[same as prior period, unchanged from 0001728949-20-000011:mdna:232]

[0001728949-20-000031:mdna:313]
[same as prior period, unchanged from 0001728949-20-000011:mdna:233]

[0001728949-20-000031:mdna:314]
43

[0001728949-20-000031:mdna:315]
Our suppliers or potential alternate suppliers may manufacture CDMA- or OFDMA-based integrated circuits, for themselves or for other companies, that compete with our products. Such suppliers have in the past and could again elect to allocate raw materials and manufacturing capacity to their own products or products of our competitors and reduce or limit the production of our products.

[0001728949-20-000031:mdna:316]
[same as prior period, unchanged from 0001728949-20-000011:mdna:235]

[0001728949-20-000031:mdna:317]
[same as prior period, unchanged from 0001728949-20-000011:mdna:236]

[0001728949-20-000031:mdna:318]
[same as prior period, unchanged from 0001728949-20-000011:mdna:237]

[0001728949-20-000031:mdna:319]
[same as prior period, unchanged from 0001728949-20-000011:mdna:238]

[0001728949-20-000031:mdna:320]
We are subject to many environmental, health and safety laws and regulations in each jurisdiction in which we operate our manufacturing facilities, which govern, among other things, emissions of pollutants into the air; wastewater discharges; the use, storage, generation, handling and disposal of hazardous substances and other waste; the investigation and remediation of soil and ground water contamination; and the health and safety of our employees. Certain environmental laws impose strict, and in certain circumstances joint and several, liability on current or previous owners or operators of real property, or parties who arranged for hazardous substances to be sent to disposal or treatment facilities, for the cost of investigation, removal or remediation of hazardous substances. As a result, we may incur clean-up costs in connection with any such removal or remediation efforts, as well as other third-party claims in connection with contaminated sites. In addition, we could be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage. If we or companies or facilities we acquire have in the past failed or in the future fail to comply with any such laws and regulations, then we could incur liabilities, fines or prohibitions on the sale of products we manufacture, and our operations could be suspended. Such laws and regulations could also restrict our ability to modify or expand our facilities, could require us to acquire costly equipment, or could require other significant expenditures. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. While we have designed policies and procedures to ensure compliance with applicable laws, regulations and permits, we cannot make assurances that we, or our employees, contractors or agents, will at all times be in compliance with such laws, regulations and permits, or our related policies and procedures.

[0001728949-20-000031:mdna:321]
Climate change concerns and the potential resulting environmental impact may result in new environmental, health and safety laws and regulations that may affect us, our suppliers and/or our customers. Such laws or regulations could cause us to incur additional direct costs for compliance, as well as increased indirect costs resulting from our customers, suppliers or both incurring additional compliance costs that are passed on to us. These costs may adversely impact our results of operations and financial condition. In addition, climate change may pose physical risks to us or our suppliers, including increased extreme weather events that could result in supply delays or disruptions.

[0001728949-20-000031:mdna:322]
We have manufacturing facilities in Asia and Europe. If tsunamis, flooding, earthquakes, volcanic eruptions or other natural disasters, or geopolitical conflicts, were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, delay new production and shipments of inventory and result in costly repairs, replacements or other costs. In addition, natural disasters or geopolitical conflicts may result in disruptions in transportation, distribution channels and supply chains, and significant increases in the prices of raw materials. Further, health crises, including epidemics or pandemics, such as the COVID-19 pandemic, and government and business responses thereto, could affect our manufacturing

[0001728949-20-000031:mdna:323]
facilities, including by resulting in quarantines and/or closures, which would result in disruptions to and potentially closures of our manufacturing operations.

[0001728949-20-000031:mdna:324]
[same as prior period, unchanged from 0001728949-20-000011:mdna:243]

[0001728949-20-000031:mdna:325]
[same as prior period, unchanged from 0001728949-20-000011:mdna:244]

[0001728949-20-000031:mdna:326]
[same as prior period, unchanged from 0001728949-20-000011:mdna:245]

[0001728949-20-000031:mdna:327]
[same as prior period, unchanged from 0001728949-20-000011:mdna:246]

[0001728949-20-000031:mdna:328]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, or to license such rights or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling such products or providing such services. Similarly, our suppliers could be found to infringe another company’s intellectual property rights, and such suppliers could then be enjoined from providing products or services to us.

[0001728949-20-000031:mdna:329]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products or services sold or provided by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-20-000031:mdna:330]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in

[0001728949-20-000031:mdna:331]
such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset or licensing revenues.

[0001728949-20-000031:mdna:332]
Certain legal matters, which may include certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0001728949-20-000031:mdna:333]
[same as prior period, unchanged from 0001728949-20-000011:mdna:252]

[0001728949-20-000031:mdna:334]
[same as prior period, unchanged from 0001728949-20-000011:mdna:253]

[0001728949-20-000031:mdna:335]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models (including manufacturing), geographic regions, industry segments or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0001728949-20-000031:mdna:336]
[same as prior period, unchanged from 0001728949-20-000011:mdna:256]

[0001728949-20-000031:mdna:337]
[same as prior period, unchanged from 0001728949-20-000011:mdna:257]

[0001728949-20-000031:mdna:338]
[same as prior period, unchanged from 0001728949-20-000011:mdna:258]

[0001728949-20-000031:mdna:339]
[same as prior period, unchanged from 0001728949-20-000011:mdna:259]

[0001728949-20-000031:mdna:340]
[same as prior period, unchanged from 0001728949-20-000011:mdna:260]

[0001728949-20-000031:mdna:341]
[same as prior period, unchanged from 0001728949-20-000011:mdna:261]

[0001728949-20-000031:mdna:342]
[same as prior period, unchanged from 0001728949-20-000011:mdna:262]

[0001728949-20-000031:mdna:343]
[same as prior period, unchanged from 0001728949-20-000011:mdna:263]

[0001728949-20-000031:mdna:344]
Further, political actions, including trade and/or national security protection policies, or other actions by governments, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our customers, or limit or prevent certain of our customers from transacting business with us. Similarly, due to pressure from the Chinese government as part of its broader economic policies, our Chinese OEMs’ concerns over losing access to our integrated circuit products as a result of U.S./China trade tensions, or other policies, regulations or decisions arising out of U.S./China trade tensions, our Chinese OEM customers may develop their own integrated circuit products and use such products, or use other integrated circuit products, in their devices rather than our integrated circuit products, and our Chinese licensees may delay or cease payments of license fees they owe to us. See also the Risk Factor entitled “Global, regional or local economic conditions, or political actions including trade and/or national security protection policies, such as tariffs, that impact the mobile communications industry or the other industries in which we operate could negatively affect the demand for our products and services and our customers’ or licensees’ products and services, which may negatively affect our revenues.”

[0001728949-20-000031:mdna:345]
National, state and local environmental laws and regulations affect our operations around the world. These laws may make it more expensive to manufacture and sell products, and our costs could increase if our vendors (e.g., suppliers, third-party manufacturers or utility companies) pass on their costs to us. The imposition of tariffs on raw materials or our products could also have a negative impact on our revenues and results of operations. We are also subject to laws and regulations impacting our manufacturing operations. See also the Risk Factor entitled “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model, environmental compliance and liability, issues related to climate change, exposure to natural disasters, timely supply of equipment and materials, and various manufacturing issues.”

[0001728949-20-000031:mdna:346]
47

[0001728949-20-000031:mdna:347]
[same as prior period, unchanged from 0001728949-20-000011:mdna:265]

[0001728949-20-000031:mdna:348]
[same as prior period, unchanged from 0001728949-20-000011:mdna:266]

[0001728949-20-000031:mdna:349]
[same as prior period, unchanged from 0001728949-20-000011:mdna:267]

[0001728949-20-000031:mdna:350]
[same as prior period, unchanged from 0001728949-20-000011:mdna:268]

[0001728949-20-000031:mdna:351]
[same as prior period, unchanged from 0001728949-20-000011:mdna:269]

[0001728949-20-000031:mdna:352]
The semiconductor industry is highly cyclical and characterized by constant and rapid technological change, price erosion, evolving technical standards, frequent new product introductions, short product life cycles (for both semiconductors and for many of the products in which they are used) and fluctuations in product supply and demand. From time to time, these factors, together with changes in general economic conditions, cause significant upturns and downturns in the semiconductor industry. Periods of downturns have been characterized by diminished demand for end-user products, high inventory levels, periods of inventory adjustment, underutilization of manufacturing capacity, changes in revenue mix and erosion of average selling prices. We expect our business to continue to be subject to cyclical downturns, even when overall economic conditions are relatively stable. If we cannot offset semiconductor industry or market downturns, our revenues may decline, and our financial condition and results of operations may be adversely impacted.

[0001728949-20-000031:mdna:353]
Our stock price and earnings have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and earnings include those identified above and throughout this Risk

[0001728949-20-000031:mdna:354]
Factors section; volatility of the stock market in general and technology-based and semiconductor companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. Further, increased volatility in the financial markets and overall economic conditions may reduce the amounts that we realize in the future on our cash equivalents and marketable securities and may reduce our earnings as a result of any reductions in the fair values of marketable securities.

[0001728949-20-000031:mdna:355]
In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0001728949-20-000031:mdna:356]
[same as prior period, unchanged from 0001728949-20-000011:mdna:274]

[0001728949-20-000031:mdna:357]
[same as prior period, unchanged from 0001728949-20-000011:mdna:275]

[0001728949-20-000031:mdna:358]
•requiring us to use cash to pay the principal of and interest on our indebtedness, thereby reducing the amount of cash available for other purposes;

[0001728949-20-000031:mdna:359]
•limiting our ability to obtain additional financing for working capital, capital expenditures, acquisitions, stock repurchases, dividends or general corporate or other purposes;

[0001728949-20-000031:mdna:360]
•limiting our flexibility in planning for, or reacting to, changes in our business, our industry and the market; and

[0001728949-20-000031:mdna:361]
•increasing our vulnerability to interest rate fluctuations to the extent a portion of our debt has variable interest rates.

[0001728949-20-000031:mdna:362]
Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to economic and political conditions, industry cycles and financial, business and other factors, including factors which negatively impact our cash flows, such as licensees withholding some or all of the royalty payments they owe to us or our paying fines or modifying our business practices in connection with regulatory investigations or litigation, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations in the future to service our debt, we may be required to, among other things: refinance or restructure all or a portion of our indebtedness; reduce or delay planned capital or operating expenditures; reduce or eliminate our dividend payments; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing or restructuring are higher than our current rates, interest expense related to such refinancing or restructuring would increase. If there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt in the future and the terms of such debt could be adversely affected.

[0001728949-20-000031:mdna:363]
[same as prior period, unchanged from 0001728949-20-000011:mdna:281]

[0001728949-20-000031:mdna:364]
We have implemented a stock repurchase program to repurchase up to $30 billion of our outstanding common stock. At March 29, 2020, $4.7 billion remained authorized for repurchase under the stock repurchase program. This stock repurchase program has significantly reduced and is expected to continue to reduce the amount of cash that we have available to fund our operations, including research and development, working capital, capital expenditures, acquisitions, investments, dividends and other corporate purposes; and increases our exposure to adverse economic, market, industry and competitive conditions and developments, and other changes in our business and our industry. In addition, this significant decrease in our cash reserves exacerbates the risks described above associated with our indebtedness.

[0001728949-20-000031:mdna:365]
[same as prior period, unchanged from 0001728949-20-000011:mdna:283]

[0001728949-20-000031:mdna:366]
Third parties regularly attempt to gain unauthorized access to our information technology systems, and most of such attempts are increasingly more sophisticated. These attempts, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, and impersonating authorized users, among others. In addition, third party suppliers that we may rely on to store and/or process our confidential information may also be subject to similar

[0001728949-20-000031:mdna:367]
attacks. Such attempts could result in the misappropriation, theft, misuse, disclosure or loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our information technology systems. These threats are constantly evolving, thereby increasing the difficulty of successfully defending against them or implementing adequate preventative measures. We seek to detect and investigate all security incidents and to prevent their recurrence, but attempts to gain unauthorized access to our information technology systems may be successful, and in some cases, we might be unaware of an incident or its magnitude and effects.

[0001728949-20-000031:mdna:368]
In addition, employees and former employees, in particular former employees who become employees of our competitors, customers, licensees or other third parties, including state actors, have in the past and may in the future misappropriate, use, publish or provide to our competitors, customers, licensees or other third parties, including state actors, our technology, intellectual property or other proprietary or confidential information. This risk is exacerbated as competitors for talent, particularly engineering talent, increasingly attempt to hire our employees. See also the Risk Factor entitled “We may not be able to attract and retain qualified employees.” Similarly, we provide access to certain of our technology, intellectual property and other proprietary or confidential information to our direct and indirect customers and licensees and certain of our consultants, who have in the past and may in the future wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. We also provide access to certain of our technology, intellectual property and other proprietary or confidential information to certain of our joint venture partners, including those affiliated with state actors and including in foreign jurisdictions where ownership restrictions may require us to take a minority ownership interest in the joint venture. Such joint venture partners may wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors.

[0001728949-20-000031:mdna:369]
[same as prior period, unchanged from 0001728949-20-000011:mdna:286]

[0001728949-20-000031:mdna:370]
[same as prior period, unchanged from 0001728949-20-000011:mdna:287]

[0001728949-20-000031:mdna:371]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed. Our current examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts giving rise to a revision become known. Although we believe that our tax estimates are reasonable, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-20-000031:mdna:372]
[same as prior period, unchanged from 0001728949-20-000011:mdna:289]

[0001728949-20-000031:mdna:373]
We have tax incentives in Singapore provided that we meet specified employment and other criteria, and as a result of the expiration of these incentives, our Singapore tax rate is expected to increase in fiscal 2022 and again in fiscal 2027. If we do not meet the criteria required to retain such incentives, our historical and future Singapore tax rate could increase prior to fiscal 2022 and/or fiscal 2027, and our results of operations and cash flows could be adversely affected.

[0001728949-20-000031:mdna:374]
Tax rules may change in a manner that adversely affects our future reported results of operations or the way we conduct our business. Further changes in the tax laws of foreign jurisdictions could arise as a result of the base erosion and profit shifting (BEPS) project that was undertaken by the Organization for Economic Co-operation and Development (OECD). The OECD, which represents a coalition of member countries, recommended changes to numerous long-standing tax principles related to transfer pricing. These changes, as adopted by countries, may increase tax uncertainty and may adversely affect our provision for income taxes, results of operations and cash flows. Partially to address BEPS, we moved certain intellectual

[0001728949-20-000031:mdna:375]
50

[0001728949-20-000031:mdna:376]
property from Singapore to the United States. As a result, if tax rates were to increase in the United States, our results of operations, cash flows and financial condition could be adversely affected.

[0001728949-20-000031:mdna:377]
[same as prior period, unchanged from 0001728949-20-000011:mdna:293]

[0001728949-20-000031:mdna:378]
A decline in global, regional or local economic conditions, a slow-down in economic growth, political actions including trade and/or national security protection policies, such as tariffs, or actions by governments that limit or prevent us from transacting business with certain companies or that limit or prevent certain companies from transacting business with us, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could have adverse, wide-ranging effects on demand for our products and services and for the products and services of our customers or licensees, particularly equipment manufacturers or others in the wireless communications industry who buy their products, such as wireless operators.

[0001728949-20-000031:mdna:379]
Similarly, due to pressure from the Chinese government as part of its broader economic policies, our Chinese OEMs’ concerns over losing access to our integrated circuit products as a result of U.S./China trade tensions, or other policies, regulations or decisions arising out of U.S./China trade tensions, our Chinese OEM customers may develop their own integrated circuit products and use such products, or use other integrated circuit products, in their devices rather than our integrated circuit products, and our Chinese licensees may delay or cease payments of license fees they owe to us.

[0001728949-20-000031:mdna:380]
Further, the COVID-19 pandemic, and government and business responses thereto, are currently negatively affecting, and we expect will continue to, at least in the near term, negatively affect global economic conditions, resulting in reduced consumer confidence and demand for consumer devices and other goods containing our integrated circuit products or that use our intellectual property and may negatively affect our manufacturing facilities and/or the manufacturing facilities of our customers, licensees and/or suppliers, including due to quarantines and/or closures. A prolonged COVID-19 health crisis may result in an even more significant negative impact on global economic conditions and may lead to a global recession.

[0001728949-20-000031:mdna:381]
Any such prolonged economic downturn, “trade war” or outbreak may result in a decrease in demand for our products and technologies; a decrease in demand for the products and services of our customers or licensees; the inability of our suppliers to deliver on their supply commitments to us, our inability to supply our products to our customers and/or the inability of our customers or licensees to supply their products to end users; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our licensees or customers; failures by counterparties; and/or negative effects on wireless device inventories. In addition, our customers’ ability to purchase or pay for our products and services and network operators’ ability to upgrade their wireless networks could be adversely affected by economic conditions, leading to a reduction, cancellation or delay of orders for our products and services.

[0001728949-20-000031:mdna:382]
[same as prior period, unchanged from 0001728949-20-000011:mdna:295]

[0001728949-20-000031:mdna:383]
[same as prior period, unchanged from 0001728949-20-000011:mdna:296]

[0001728949-20-000031:mdna:384]
[same as prior period, unchanged from 0001728949-20-000011:mdna:297]

[0001728949-20-000031:mdna:385]
[same as prior period, unchanged from 0001728949-20-000011:mdna:298]

[0001728949-20-000031:mdna:386]
•Our products and those of our customers and licensees that are sold outside the United States may become less price-competitive, which may result in reduced demand for those products or downward pressure on average selling prices;

[0001728949-20-000031:mdna:387]
•Certain of our revenues that are derived from products that are sold in foreign currencies could decrease, resulting in lower revenues, cash flows and margins;

[0001728949-20-000031:mdna:388]
•Certain of our revenues, such as royalties, that are derived from licensee or customer sales denominated in foreign currencies could decrease, resulting in lower revenues and cash flows;

[0001728949-20-000031:mdna:389]
•Our foreign suppliers may raise their prices if they are impacted by currency fluctuations, resulting in higher than expected costs, and lower margins and cash flows;

[0001728949-20-000031:mdna:390]
•Certain of our costs that are denominated in foreign currencies could increase, resulting in higher than expected costs and cash outflows; and

[0001728949-20-000031:mdna:391]
•Foreign exchange hedging exposes us to counterparty risk and may require the payment of structuring fees. If the foreign exchange hedges do not qualify for hedge accounting, the hedge results may cause earnings volatility. The foreign exchange hedging activities are designed to lessen earnings volatility; therefore, hedges may reduce the impact of currency fluctuations to certain revenues and costs.

[0001728949-20-000031:mdna:392]
[same as prior period, unchanged from 0001728949-20-000011:mdna:305]

[0001728949-20-000031:mdna:393]
[same as prior period, unchanged from 0001728949-20-000011:mdna:306]

[0001728949-20-000031:mdna:394]
[same as prior period, unchanged from 0001728949-20-000011:mdna:307]

[0001728949-20-000031:mdna:395]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and to the end users of such devices. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products, repairing or replacing defective products, writing down defective inventory, or indemnification clauses in our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, losses on unfavorable purchase commitments, and a decrease in demand for connected devices and wireless services generally. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products generally and our premium-tier products in particular.

[0001728949-20-000031:mdna:396]
In addition, the occurrence of defects may give rise to product liability claims, particularly if defects in our products or the products into which they are integrated result in personal injury or death. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the efforts of our technical and management personnel and harm our business. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. Further, our business liability insurance may be inadequate, or future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as automobiles, including autonomous driver assistance programs; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality

[0001728949-20-000031:mdna:397]
vehicles; and extended reality (XR) for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0001728949-20-000031:mdna:398]
[same as prior period, unchanged from 0001728949-20-000011:mdna:311]
