# QCOM 8-K — 0000804328-22-000020 filed 2022-11-02

## item codes, every 8-K on or before 2022-11-02

- 2022-11-02 0000804328-22-000020 — 2.02, 9.01
- 2022-07-27 0001728949-22-000039 — 2.02, 9.01
- 2022-05-09 0001104659-22-057562 — 1.01, 8.01, 9.01
- 2022-04-27 0001728949-22-000025 — 2.02, 9.01
- 2022-03-14 0001728949-22-000016 — 5.07
- 2022-02-02 0001728949-22-000011 — 2.02, 9.01
- 2021-11-03 0001728949-21-000075 — 2.02, 9.01
- 2021-10-04 0001104659-21-122578 — 1.01, 7.01, 9.01
- 2021-07-28 0001728949-21-000065 — 2.02, 9.01
- 2021-07-23 0001728949-21-000055 — 5.03, 9.01
- 2021-05-21 0001728949-21-000048 — 5.02
- 2021-04-28 0001728949-21-000042 — 2.02, 9.01
- 2021-03-15 0001628280-21-004741 — 5.07
- 2021-02-03 0001728949-21-000021 — 2.02, 9.01
- 2021-01-13 0001728949-21-000009 — 1.01, 9.01
- 2021-01-08 0001728949-21-000004 — 5.02
- 2020-12-10 0001104659-20-134200 — 1.01, 1.02, 2.03, 9.01
- 2020-11-19 0001728949-20-000070 — 5.02
- 2020-11-04 0001728949-20-000066 — 2.02, 9.01
- 2020-08-18 0001104659-20-096322 — 1.01, 8.01, 9.01
- 2020-08-05 0001104659-20-090597 — 8.01, 9.01
- 2020-07-29 0001728949-20-000056 — 2.02, 9.01
- 2020-07-24 0001728949-20-000047 — 5.02
- 2020-05-11 0001104659-20-058923 — 1.01, 8.01, 9.01
- 2020-05-04 0001728949-20-000037 — 5.02
- 2020-04-29 0001728949-20-000030 — 2.02, 9.01
- 2020-03-13 0001728949-20-000015 — 5.07
- 2020-02-05 0001728949-20-000010 — 2.02, 9.01
- 2019-11-06 0001728949-19-000074 — 5.02
- 2019-11-06 0001728949-19-000071 — 2.02, 9.01
- 2019-08-28 0001728949-19-000058 — 5.02
- 2019-07-31 0001728949-19-000053 — 2.02, 9.01
- 2019-05-10 0001728949-19-000044 — 5.02
- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2022-11-02

- none on or before 2022-11-02

## item 2.02 — earnings release, exhibit 99.1

[0000804328-22-000020:8k_2_02:1]
EX-99.1
2
qcom092522erex991.htm
EX-99.1

[0000804328-22-000020:8k_2_02:2]
Document

[0000804328-22-000020:8k_2_02:3]
Exhibit 99.1

[0000804328-22-000020:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000804328-22-000020:8k_2_02:5]
Qualcomm Contact:

[0000804328-22-000020:8k_2_02:6]
Mauricio Lopez-Hodoyan

[0000804328-22-000020:8k_2_02:7]
Vice President, Investor Relations

[0000804328-22-000020:8k_2_02:8]
Phone: 1-858-658-4813 | e-mail: ir@qualcomm.com

[0000804328-22-000020:8k_2_02:9]
Qualcomm Announces Fourth Quarter and Fiscal 2022 Results

[0000804328-22-000020:8k_2_02:10]
Fiscal 2022 Revenues: $44.2 billion

[0000804328-22-000020:8k_2_02:11]
Fiscal 2022 EPS: GAAP $11.37, Non-GAAP $12.53

[0000804328-22-000020:8k_2_02:12]
—Record Fiscal Year Revenues and EPS—

[0000804328-22-000020:8k_2_02:13]
—QCT Diversification: Combined Fiscal Year IoT and Automotive Revenues Grew 38% Year-Over-Year—

[0000804328-22-000020:8k_2_02:14]
—QCT Delivered Strong Fiscal Year EBT Growth: 65% Year-Over-Year—

[0000804328-22-000020:8k_2_02:15]
SAN DIEGO - November 2, 2022 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal fourth quarter and year ended September 25, 2022.

[0000804328-22-000020:8k_2_02:16]
“We are pleased to report another strong year, despite the macroeconomic challenges, as we continue to execute our strategy of transforming Qualcomm from a wireless communications company for the mobile industry to a connected processor company for the intelligent edge,” said Cristiano Amon, President and CEO of Qualcomm Incorporated.  “While our financial outlook is being temporarily impacted by elevated channel inventory, our diversification strategy and long-term opportunities remain unchanged.”

[0000804328-22-000020:8k_2_02:17]
Fourth Quarter Results1

[0000804328-22-000020:8k_2_02:18]
|  | GAAP |  | Non-GAAP |  |
| (in millions, except per share data and percentages) | Q4 Fiscal 2022 |  | Q4 Fiscal 2021 |  | Change |  | Q4 Fiscal 2022 |  | Q4 Fiscal 2021 |  |  |  |  | Change |  |
| Revenues | $11,396 |  | $9,336 |  | +22% |  | $11,387 |  | $9,321 |  |  |  |  | +22% |  |
| Earnings before taxes (EBT) | $3,470 |  | $3,285 |  | +6% |  | $4,142 |  | $3,278 |  |  |  |  | +26% |  |
| Net income | $2,873 |  | $2,798 |  | +3% |  | $3,548 |  | $2,916 |  |  |  |  | +22% |  |
| Diluted earnings per share (EPS) | $2.54 |  | $2.45 |  | +4% |  | $3.13 |  | $2.55 |  |  |  |  | +23% |  |

[0000804328-22-000020:8k_2_02:19]
Fiscal 2022 Results1, 2

[0000804328-22-000020:8k_2_02:20]
|  | GAAP |  | Non-GAAP |  |
| (in millions, except per share data and percentages) | Fiscal 2022 |  | Fiscal 2021 |  | Change |  | Fiscal 2022 |  | Fiscal 2021 |  |  |  |  | Change |  |
| Revenues | $44,200 |  | $33,566 |  | +32% |  | $44,169 |  | $33,467 |  |  |  |  | +32% |  |
| EBT | $14,998 |  | $10,274 |  | +46% |  | $16,598 |  | $11,263 |  |  |  |  | +47% |  |
| Net income | $12,936 |  | $9,043 |  | +43% |  | $14,254 |  | $9,811 |  |  |  |  | +45% |  |
| EPS | $11.37 |  | $7.87 |  | +44% |  | $12.53 |  | $8.54 |  |  |  |  | +47% |  |

[0000804328-22-000020:8k_2_02:21]
(1)  Discussion regarding our use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results are included at the end of this news release in the sections labeled “Note Regarding Use of Non-GAAP Financial Measures” and “Reconciliations of GAAP Results to Non-GAAP Results.”

[0000804328-22-000020:8k_2_02:22]
(2)  Fiscal 2022 GAAP results included a $1.1 billion benefit, or $0.97 per share, resulting from the reversal of the accrued fine imposed on us by the European Commission (EC) in fiscal 2018 (2018 EC fine) and the associated accrued interest.

[0000804328-22-000020:8k_2_02:23]
| Qualcomm Announces Fourth Quarter and Fiscal 2022 Results | Page 2 of 10 |

[0000804328-22-000020:8k_2_02:24]
Segment Results

[0000804328-22-000020:8k_2_02:25]
Fourth Quarter

[0000804328-22-000020:8k_2_02:26]
|  | QCT |  | QTL |
| (in millions, except percentages) | Q4 Fiscal 2022 |  | Q4 Fiscal 2021 |  | Change |  | Q4 Fiscal 2022 |  | Q4 Fiscal 2021 |  | Change |  |  |  |
| Revenues | $9,904 |  | $7,733 |  | +28% |  | $1,441 |  | $1,558 |  | (8%) |  |  |  |
| EBT | $3,386 |  | $2,464 |  | +37% |  | $989 |  | $1,114 |  | (11%) |  |  |  |
| EBT as % of revenues | 34% |  | 32% |  | +2 points |  | 69% |  | 72% |  | -3 points |  |  |  |

[0000804328-22-000020:8k_2_02:27]
Fiscal 2022

[0000804328-22-000020:8k_2_02:28]
|  | QCT |  | QTL |
| (in millions, except percentages) | Fiscal 2022 |  | Fiscal 2021 |  | Change |  | Fiscal 2022 |  | Fiscal 2021 |  | Change |  |  |  |
| Revenues | $37,677 |  | $27,019 |  | +39% |  | $6,358 |  | $6,320 |  | +1% |  |  |  |
| EBT | $12,837 |  | $7,763 |  | +65% |  | $4,628 |  | $4,627 |  | — |  |  |  |
| EBT as % of revenues | 34% |  | 29% |  | +5 points |  | 73% |  | 73% |  | — |  |  |  |

[0000804328-22-000020:8k_2_02:29]
QCT Revenue Streams1

[0000804328-22-000020:8k_2_02:30]
|  |  |  |  |  |  |  | Fourth Quarter |  | Fiscal |  |  |  |
| (in millions, except percentages) |  |  |  |  |  |  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |  |  |  |
| Handsets |  |  |  |  |  |  | $6,570 |  | $4,686 |  | +40% |  | $25,027 |  | $16,830 |  | +49% |  |  |  |
| RF front-end |  |  |  |  |  |  | 992 |  | 1,237 |  | (20%) |  | 4,330 |  | 4,158 |  | +4% |  |  |  |
| Automotive |  |  |  |  |  |  | 427 |  | 270 |  | +58% |  | 1,372 |  | 975 |  | +41% |  |  |  |
| IoT |  |  |  |  |  |  | 1,915 |  | 1,540 |  | +24% |  | 6,948 |  | 5,056 |  | +37% |  |  |  |
| Total QCT revenues |  |  |  |  |  |  | $9,904 |  | $7,733 |  | +28% |  | $37,677 |  | $27,019 |  | +39% |  |  |  |

[0000804328-22-000020:8k_2_02:31]
(1)  We disaggregate QCT revenues based on the industries and applications in which our products are sold.

[0000804328-22-000020:8k_2_02:32]
Return of Capital to Stockholders

[0000804328-22-000020:8k_2_02:33]
|  | Stock Repurchases |  | Dividends Paid |  | Total Amount |
| (in millions, except per share data) | Shares |  | Amount |  | Per Share |  | Amount |  |
| Q4 Fiscal 2022 | 3 |  | $500 |  | $0.75 |  | $841 |  | $1,341 |
| Fiscal 2022 | 21 |  | $3,129 |  | $2.86 |  | $3,212 |  | $6,341 |

[0000804328-22-000020:8k_2_02:34]
| Qualcomm Announces Fourth Quarter and Fiscal 2022 Results | Page 3 of 10 |

[0000804328-22-000020:8k_2_02:35]
Business Outlook

[0000804328-22-000020:8k_2_02:36]
Given the uncertainty caused by the macroeconomic environment, we are updating our guidance for calendar year 2022 3G/4G/5G handset volumes from a year-over-year mid-single-digit percentage decline, to a low double-digit percentage decline.

[0000804328-22-000020:8k_2_02:37]
The rapid deterioration in demand and easing of supply constraints across the semiconductor industry have resulted in elevated channel inventory.  Due to these elevated levels, our largest customers are now drawing down on their inventory, negatively impacting the mid-point of our EPS guidance for the first quarter of fiscal 2023 by approximately ($0.80).  This is the primary driver of the variance relative to our prior expectations.

[0000804328-22-000020:8k_2_02:38]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.

[0000804328-22-000020:8k_2_02:39]
|  |  |  | Current Guidance Q1 FY23 Estimates1, 2 |  |
|  | Revenues |  | $9.2B - $10.0B |  |
|  | Supplemental Revenue Information |  |  |  |
|  | QCT revenues |  | $7.7B - $8.3B |  |
|  | QTL revenues |  | $1.45B - $1.65B |  |
|  | GAAP diluted EPS |  | $1.72- $1.92 |  |
|  | Less diluted EPS attributable to QSI |  | $— |  |  |
|  | Less diluted EPS attributable to share-based compensation |  | ($0.43) |  |  |
|  | Less diluted EPS attributable to other items3 |  | ($0.10) |  |  |
|  | Non-GAAP diluted EPS |  | $2.25 - $2.45 |  |

[0000804328-22-000020:8k_2_02:40]
(1)  Our diluted EPS guidance for the first quarter of fiscal 2023 excludes the impact of the mandatory capitalization and amortization of R&D expenditures required under U.S. Federal income tax law (which is effective for us beginning in fiscal 2023), given the uncertainty surrounding whether the existing law will be delayed or repealed.  If the law is not delayed or repealed by the end of our first fiscal quarter, we estimate a tax benefit of approximately $0.10 will be included in our GAAP EPS results for the quarter.

[0000804328-22-000020:8k_2_02:41]
(2)  Our outlook does not include provisions for proposed tax law changes (except as otherwise discussed in (1) above), future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as certain investments, derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain.  Our outlook includes the impact of any pending business combinations to the extent they are expected to close in the upcoming quarter.  Actual results may differ materially from the outlook.

[0000804328-22-000020:8k_2_02:42]
(3)  Our guidance for diluted EPS attributable to other items for the first quarter of fiscal 2023 is primarily related to acquisition-related items, including the discontinued operations of the Non-Arriver businesses.

[0000804328-22-000020:8k_2_02:43]
| Qualcomm Announces Fourth Quarter and Fiscal 2022 Results | Page 4 of 10 |

[0000804328-22-000020:8k_2_02:44]
Conference Call

[0000804328-22-000020:8k_2_02:45]
Qualcomm’s fourth quarter and fiscal 2022 earnings conference call will be broadcast live on November 2, 2022, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to our financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at http://investor.qualcomm.com/ immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415.  Callers should use reservation number 13733389.

[0000804328-22-000020:8k_2_02:46]
About Qualcomm

[0000804328-22-000020:8k_2_02:47]
Qualcomm is the world’s leading wireless technology innovator and the driving force behind the development, launch and expansion of 5G.  When we connected the phone to the internet, the mobile revolution was born.  Today, our foundational technologies enable the mobile ecosystem and are found in every 3G, 4G and 5G smartphone.  We bring the benefits of mobile to new industries, including automotive, the internet of things and computing, and are leading the way to a world where everything and everyone can communicate and interact seamlessly.

[0000804328-22-000020:8k_2_02:48]
Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of our engineering and research and development functions and substantially all of our products and services businesses, including our QCT semiconductor business.

[0000804328-22-000020:8k_2_02:49]
Note Regarding Forward-Looking Statements

[0000804328-22-000020:8k_2_02:50]
###

[0000804328-22-000020:8k_2_02:51]
| Qualcomm Announces Fourth Quarter and Fiscal 2022 Results | Page 5 of 10 |

[0000804328-22-000020:8k_2_02:52]
QUALCOMM Incorporated

[0000804328-22-000020:8k_2_02:53]
CONSOLIDATED BALANCE SHEETS

[0000804328-22-000020:8k_2_02:54]
(In millions, except par value amounts)

[0000804328-22-000020:8k_2_02:55]
(Unaudited)

[0000804328-22-000020:8k_2_02:56]
|  | September 25,2022 |  | September 26,2021 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,773 |  |  | $ | 7,116 |  |
| Marketable securities | 3,609 |  |  | 5,298 |  |
| Accounts receivable, net | 5,643 |  |  | 3,579 |  |
| Inventories | 6,341 |  |  | 3,228 |  |
| Held for sale assets | 733 |  |  | — |  |
| Other current assets | 1,625 |  |  | 854 |  |
| Total current assets | 20,724 |  |  | 20,075 |  |
| Deferred tax assets | 1,803 |  |  | 1,591 |  |
| Property, plant and equipment, net | 5,168 |  |  | 4,559 |  |
| Goodwill | 10,508 |  |  | 7,246 |  |
| Other intangible assets, net | 1,882 |  |  | 1,458 |  |
| Held for sale assets | 1,200 |  |  | — |  |
| Other assets | 7,729 |  |  | 6,311 |  |
| Total assets | $ | 49,014 |  |  | $ | 41,240 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 3,796 |  |  | $ | 2,750 |  |
| Payroll and other benefits related liabilities | 1,486 |  |  | 1,531 |  |
| Unearned revenues | 369 |  |  | 612 |  |
| Short-term debt | 1,945 |  |  | 2,044 |  |
| Held for sale liabilities | 581 |  |  | — |  |
| Other current liabilities | 3,689 |  |  | 5,014 |  |
| Total current liabilities | 11,866 |  |  | 11,951 |  |
| Unearned revenues | 144 |  |  | 364 |  |
| Income taxes payable | 1,472 |  |  | 1,713 |  |
| Long-term debt | 13,537 |  |  | 13,701 |  |
| Held for sale liabilities | 119 |  |  | — |  |
| Other liabilities | 3,863 |  |  | 3,561 |  |
| Total liabilities | 31,001 |  |  | 31,290 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,121 and 1,125 shares issued and outstanding, respectively | 195 |  |  | — |  |
| Retained earnings | 17,840 |  |  | 9,822 |  |
| Accumulated other comprehensive (loss) income | (22) |  |  | 128 |  |
| Total stockholders’ equity | 18,013 |  |  | 9,950 |  |
| Total liabilities and stockholders’ equity | $ | 49,014 |  |  | $ | 41,240 |  |

[0000804328-22-000020:8k_2_02:57]
| Qualcomm Announces Fourth Quarter and Fiscal 2022 Results | Page 6 of 10 |

[0000804328-22-000020:8k_2_02:58]
QUALCOMM Incorporated

[0000804328-22-000020:8k_2_02:59]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000804328-22-000020:8k_2_02:60]
(In millions, except per share data)

[0000804328-22-000020:8k_2_02:61]
(Unaudited)

[0000804328-22-000020:8k_2_02:62]
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  |  |  |  | September 25,2022 |  | September 26,2021 |  | September 25,2022 |  | September 26,2021 |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services |  |  |  |  |  | $ | 9,807 |  |  | $ | 7,632 |  |  | $ | 37,171 |  |  | $ | 26,741 |  |
| Licensing |  |  |  |  |  | 1,589 |  |  | 1,704 |  |  | 7,029 |  |  | 6,825 |  |
| Total revenues |  |  |  |  |  | 11,396 |  |  | 9,336 |  |  | 44,200 |  |  | 33,566 |  |
| Costs and expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  |  |  |  | 4,868 |  |  | 3,937 |  |  | 18,635 |  |  | 14,262 |  |
| Research and development |  |  |  |  |  | 2,179 |  |  | 1,878 |  |  | 8,194 |  |  | 7,176 |  |
| Selling, general and administrative |  |  |  |  |  | 683 |  |  | 619 |  |  | 2,570 |  |  | 2,339 |  |
| Other |  |  |  |  |  | — |  |  | — |  |  | (1,059) |  |  | — |  |
| Total costs and expenses |  |  |  |  |  | 7,730 |  |  | 6,434 |  |  | 28,340 |  |  | 23,777 |  |
| Operating income |  |  |  |  |  | 3,666 |  |  | 2,902 |  |  | 15,860 |  |  | 9,789 |  |
| Interest expense |  |  |  |  |  | (145) |  |  | (138) |  |  | (490) |  |  | (559) |  |
| Investment and other (expense) income, net |  |  |  |  |  | (51) |  |  | 521 |  |  | (372) |  |  | 1,044 |  |
| Income from continuing operations before income taxes |  |  |  |  |  | 3,470 |  |  | 3,285 |  |  | 14,998 |  |  | 10,274 |  |
| Income tax expense |  |  |  |  |  | (547) |  |  | (487) |  |  | (2,012) |  |  | (1,231) |  |
| Income from continuing operations |  |  |  |  |  | 2,923 |  |  | 2,798 |  |  | 12,986 |  |  | 9,043 |  |
| Discontinued operations, net of income taxes |  |  |  |  |  | (50) |  |  | — |  |  | (50) |  |  | — |  |
| Net income |  |  |  |  |  | $ | 2,873 |  |  | $ | 2,798 |  |  | $ | 12,936 |  |  | $ | 9,043 |  |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  |  |  |  |  | $ | 2.60 |  |  | $ | 2.48 |  |  | $ | 11.56 |  |  | $ | 7.99 |  |
| Discontinued operations |  |  |  |  |  | (0.04) |  |  | — |  |  | (0.04) |  |  | — |  |
| Net income |  |  |  |  |  | $ | 2.56 |  |  | $ | 2.48 |  |  | $ | 11.52 |  |  | $ | 7.99 |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  |  |  |  |  | $ | 2.58 |  |  | $ | 2.45 |  |  | $ | 11.41 |  |  | $ | 7.87 |  |
| Discontinued operations |  |  |  |  |  | (0.04) |  |  | — |  |  | (0.04) |  |  | — |  |
| Net income |  |  |  |  |  | $ | 2.54 |  |  | $ | 2.45 |  |  | $ | 11.37 |  |  | $ | 7.87 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  | 1,122 |  |  | 1,129 |  |  | 1,123 |  |  | 1,131 |  |
| Diluted |  |  |  |  |  | 1,133 |  |  | 1,144 |  |  | 1,137 |  |  | 1,149 |  |

[0000804328-22-000020:8k_2_02:63]
| Qualcomm Announces Fourth Quarter and Fiscal 2022 Results | Page 7 of 10 |

[0000804328-22-000020:8k_2_02:64]
QUALCOMM Incorporated

[0000804328-22-000020:8k_2_02:65]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000804328-22-000020:8k_2_02:66]
(In millions)

[0000804328-22-000020:8k_2_02:67]
(Unaudited)

[0000804328-22-000020:8k_2_02:68]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 25,2022 |  | September 26,2021 |  | September 25,2022 |  | September 26,2021 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income from continuing operations | $ | 2,923 |  |  | $ | 2,798 |  |  | $ | 12,986 |  |  | $ | 9,043 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 490 |  |  | 425 |  |  | 1,762 |  |  | 1,582 |  |
| Income tax provision in excess of (less than) income tax payments | 96 |  |  | 113 |  |  | (138) |  |  | (245) |  |
| Share-based compensation expense | 521 |  |  | 425 |  |  | 2,031 |  |  | 1,663 |  |
| Net losses (gains) on marketable securities and other investments | 58 |  |  | (515) |  |  | 432 |  |  | (1,002) |  |
| Impairment losses on marketable securities and other investments | 6 |  |  | 9 |  |  | 47 |  |  | 33 |  |
| Other items, net | (13) |  |  | (4) |  |  | (54) |  |  | (77) |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (1,850) |  |  | (626) |  |  | (2,066) |  |  | 426 |  |
| Inventories | (936) |  |  | (113) |  |  | (3,137) |  |  | (622) |  |
| Other assets | 94 |  |  | (1,688) |  |  | (2,266) |  |  | (1,649) |  |
| Trade accounts payable | 88 |  |  | 46 |  |  | 1,036 |  |  | 495 |  |
| Payroll, benefits and other liabilities | 231 |  |  | 286 |  |  | (1,043) |  |  | 1,091 |  |
| Unearned revenues | (92) |  |  | (79) |  |  | (324) |  |  | (202) |  |
| Net cash used by operating activities from discontinued operations | (170) |  |  | — |  |  | (170) |  |  | — |  |
| Net cash provided by operating activities | 1,446 |  |  | 1,077 |  |  | 9,096 |  |  | 10,536 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (634) |  |  | (430) |  |  | (2,262) |  |  | (1,888) |  |
| Purchases of debt and equity marketable securities | (145) |  |  | (449) |  |  | (1,414) |  |  | (5,907) |  |
| Proceeds from sales and maturities of debt and equity marketable securities | 662 |  |  | 1,073 |  |  | 2,622 |  |  | 5,555 |  |
| Acquisitions and other investments, net of cash acquired | (169) |  |  | (93) |  |  | (4,912) |  |  | (1,377) |  |
| Proceeds from other investments | 7 |  |  | 86 |  |  | 132 |  |  | 320 |  |
| Other items, net | (11) |  |  | (137) |  |  | 30 |  |  | (59) |  |
| Net cash (used) provided by investing activities | (290) |  |  | 50 |  |  | (5,804) |  |  | (3,356) |  |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 3,935 |  |  | 701 |  |  | 7,000 |  |  | 2,886 |  |
| Repayment of short-term debt | (3,937) |  |  | (700) |  |  | (7,003) |  |  | (2,885) |  |
| Repayment of debt of acquired company | — |  |  | — |  |  | (349) |  |  | — |  |
| Proceeds from long-term debt | — |  |  | — |  |  | 1,477 |  |  | — |  |
| Repayment of long-term debt | — |  |  | — |  |  | (1,540) |  |  | — |  |
| Proceeds from issuance of common stock | 168 |  |  | 173 |  |  | 356 |  |  | 347 |  |
| Repurchases and retirements of common stock | (500) |  |  | (771) |  |  | (3,129) |  |  | (3,366) |  |
| Dividends paid | (841) |  |  | (768) |  |  | (3,212) |  |  | (3,008) |  |
| Payments of tax withholdings related to vesting of share-based awards | (15) |  |  | (27) |  |  | (766) |  |  | (737) |  |
| Other items, net | (2) |  |  | (10) |  |  | (30) |  |  | (35) |  |
| Net cash used by financing activities | (1,192) |  |  | (1,402) |  |  | (7,196) |  |  | (6,798) |  |
| Effect of exchange rate changes on cash and cash equivalents | (63) |  |  | (8) |  |  | (113) |  |  | 27 |  |
| Net (decrease) increase in total cash and cash equivalents | (99) |  |  | (283) |  |  | (4,017) |  |  | 409 |  |
| Total cash and cash equivalents at beginning of period (including $522 million classified as held for sale at June 26, 2022) | 3,198 |  |  | 7,399 |  |  | 7,116 |  |  | 6,707 |  |
| Total cash and cash equivalents at end of period (including $326 million classified as held for sale at September 25, 2022) | $ | 3,099 |  |  | $ | 7,116 |  |  | $ | 3,099 |  |  | $ | 7,116 |  |

[0000804328-22-000020:8k_2_02:69]
| Qualcomm Announces Fourth Quarter and Fiscal 2022 Results | Page 8 of 10 |

[0000804328-22-000020:8k_2_02:70]
Note Regarding Use of Non-GAAP Financial Measures

[0000804328-22-000020:8k_2_02:71]
The Non-GAAP financial measures presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, our Non-GAAP financial measures might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP financial measures are presented herein.

[0000804328-22-000020:8k_2_02:72]
We use Non-GAAP financial information: (i) to evaluate, assess and benchmark our operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of our ongoing core operating businesses, including our QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by us include revenues, cost of revenues, research and development (R&D) expenses, selling, general and administrative (SG&A) expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  We are able to assess what we believe is a meaningful and comparable set of financial performance measures by using Non-GAAP information.  In addition, the HR and Compensation Committee of our Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  We present Non-GAAP financial information to provide greater transparency to investors with respect to our use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0000804328-22-000020:8k_2_02:73]
Non-GAAP information presented herein excludes our QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0000804328-22-000020:8k_2_02:74]
•QSI is excluded because we generally expect to exit our strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed as unrelated to our operational performance.

[0000804328-22-000020:8k_2_02:75]
•Share-based compensation expense primarily relates to restricted stock units.  We believe that excluding share-based compensation from Non-GAAP financial information allows us and investors to make additional comparisons of the operating activities of our ongoing core businesses over time and with respect to other companies.

[0000804328-22-000020:8k_2_02:76]
•Certain other items are excluded because we view such items as unrelated to the operating activities of our ongoing core businesses, as follows:

[0000804328-22-000020:8k_2_02:77]
◦Acquisition-related items include amortization of acquisition-related intangible assets, substantially all of which relate to the amortization of technology-based intangible assets that is recorded in cost of revenues and will recur in future periods until the related intangible assets have been fully amortized.  We view acquisition-related intangible assets as items arising from pre-acquisition activities determined at the time of an acquisition.  Acquisition-related intangible assets contribute to revenue generation that has not been excluded from our Non-GAAP financial information.  Acquisition-related items also include recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of acquisition-related items, as well as any effects from restructuring the ownership of such acquired assets.  We also exclude the operating results of acquired and/or consolidated businesses that, as of close, are expected or required to be sold.  Additionally, we exclude certain other acquisition-related charges such as third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition.

[0000804328-22-000020:8k_2_02:78]
◦We exclude certain other items that we view as unrelated to our ongoing businesses, such as major restructuring and restructuring-related costs, asset impairments and awards, settlements and/or damages arising from legal or regulatory matters.  We exclude gains and losses driven by the revaluation of our deferred compensation plan liabilities recognized in operating expenses and the offsetting gains and losses on the related plan assets recognized in investment and other income (expense).

[0000804328-22-000020:8k_2_02:79]
◦Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of our ongoing Non-GAAP tax rate and after-tax earnings.

[0000804328-22-000020:8k_2_02:80]
| Qualcomm Announces Fourth Quarter and Fiscal 2022 Results | Page 9 of 10 |

[0000804328-22-000020:8k_2_02:81]
Reconciliations of GAAP Results to Non-GAAP Results

[0000804328-22-000020:8k_2_02:82]
| (in millions, except per share data and percentages) |  |  |  | GAAP to Non-GAAP Reconciliation | Non-GAAP Supplemental Information |
|  |  |  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1 | Non-GAAP Results | QCT | QTL | Non-GAAP Reconciling Items2 |
| Q4 Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $11,396 |  | $9 |  | $— |  |  | $— |  |  | $11,387 |  | $9,904 |  | $1,441 |  | $42 |  |
| Operating income (loss) |  |  |  | 3,666 |  | 2 |  | (522) |  | (70) |  | 4,256 |  |  |  |  |  |  |  |
| EBT |  |  |  | 3,470 |  | (30) |  | (522) |  | (120) |  | 4,142 |  | 3,386 |  | 989 |  | (233) |  |
| EBT as % of revenues |  |  |  | 30 | % |  |  |  |  |  |  |  | 36 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 2,873 |  | (24) |  | (437) |  | (214) |  | 3,548 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $2.54 |  | ($0.02) |  | ($0.39) |  | ($0.19) |  | $3.13 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,133 |  | 1,133 |  | 1,133 |  | 1,133 |  | 1,133 |  |  |  |  |  |  |  |
| Q4 Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $9,336 |  | $15 |  | $— |  |  | $— |  |  | $9,321 |  | $7,733 |  | $1,558 |  | $30 |  |
| Operating income (loss) |  |  |  | 2,902 |  | 5 |  | (429) |  | (76) |  | 3,402 |  |  |  |  |  |  |  |
| EBT |  |  |  | 3,285 |  | 504 |  | (429) |  | (68) |  | 3,278 |  | 2,464 |  | 1,114 |  | (300) |  |
| EBT as % of revenues |  |  |  | 35 | % |  |  |  |  |  |  |  | 35 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 2,798 |  | 398 |  | (356) |  | (160) |  | 2,916 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $2.45 |  | $0.35 |  | ($0.31) |  | ($0.14) |  | $2.55 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,144 |  | 1,144 |  | 1,144 |  | 1,144 |  | 1,144 |  |  |  |  |  |  |  |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $44,200 |  | $31 |  | $— |  |  | $— |  | $44,169 |  | $37,677 |  | $6,358 |  | $134 |  |
| Operating income (loss) |  |  |  | 15,860 |  | 2 |  | (2,061) |  | 852 |  | 17,067 |  |  |  |  |  |  |  |
| EBT |  |  |  | 14,998 |  | (279) |  | (2,061) |  | 740 |  | 16,598 |  | 12,837 |  | 4,628 |  | (867) |  |
| EBT as % of revenues |  |  |  | 34 | % |  |  |  |  |  |  |  | 38 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 12,936 |  | (207) |  | (1,572) |  | 461 |  | 14,254 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $11.37 |  | ($0.18) |  | ($1.38) |  | $0.41 |  | $12.53 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,137 |  | 1,137 |  | 1,137 |  | 1,137 |  | 1,137 |  |  |  |  |  |  |  |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $33,566 |  | $45 |  | $— |  |  | $54 |  | $33,467 |  | $27,019 |  | $6,320 |  | $128 |  |
| Operating income (loss) |  |  |  | 9,789 |  | 22 |  | (1,670) |  | (335) |  | 11,772 |  |  |  |  |  |  |  |
| EBT |  |  |  | 10,274 |  | 916 |  | (1,670) |  | (235) |  | 11,263 |  | 7,763 |  | 4,627 |  | (1,127) |  |
| EBT as % of revenues |  |  |  | 31 | % |  |  |  |  |  |  |  | 34 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 9,043 |  | 751 |  | (1,235) |  | (284) |  | 9,811 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $7.87 |  | $0.65 |  | ($1.07) |  | ($0.25) |  | $8.54 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,149 |  | 1,149 |  | 1,149 |  | 1,149 |  | 1,149 |  |  |  |  |  |  |  |

[0000804328-22-000020:8k_2_02:83]
(1)  Further details of amounts included in the “Other Items” column for the current period are included at the end of this news release in the sections labeled “Supplemental Information and Reconciliations.”  Details of amounts included in the “Other Items” column for the prior periods are included in the news release for those periods.

[0000804328-22-000020:8k_2_02:84]
(2)   Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations.  Non-GAAP reconciling items related to EBT consisted primarily of certain R&D expenses, SG&A expenses, other expenses or income, interest expense and certain investment income (expense) that are not allocated to segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit.

[0000804328-22-000020:8k_2_02:85]
Sums may not equal totals due to rounding.

[0000804328-22-000020:8k_2_02:86]
| Qualcomm Announces Fourth Quarter and Fiscal 2022 Results | Page 10 of 10 |

[0000804328-22-000020:8k_2_02:87]
|  | Q4 Fiscal 2022 Supplemental Information and Reconciliations |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |
|  | Cost of revenues |  | $4,868 |  |  | $4 |  |  | $16 |  |  | $64 |  |  | $4,784 |  |
|  | Research and development expenses |  | 2,179 |  |  | — |  |  |  | 396 |  |  | (13) |  |  | 1,796 |  |
|  | Selling, general and administrative expenses |  | 683 |  |  | 3 |  |  | 110 |  |  | 19 |  |  | 551 |  |
|  | Other income |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
|  | Interest expense |  | 145 |  |  | — |  |  |  | — |  |  |  | 1 |  |  | 144 |  |
|  | Investment and other (expense) income, net |  | (51) |  |  | (32) |  |  | — |  |  |  | (49) |  |  | 30 |  |
|  | Income tax expense (benefit) |  | 547 |  |  | (6) |  |  |  | (85) |  |  |  | 44 |  |  | 594 |  |
|  | Discontinued operations, net of income taxes |  | (50) |  |  |  | — |  |  |  | — |  |  |  | (50) |  |  |  | — |  |  |

[0000804328-22-000020:8k_2_02:88]
(1)  Other items excluded from Non-GAAP results included $50 million of losses, net of income taxes, from the discontinued operations of the Non-Arriver businesses, as well as $110 million of other acquisition-related charges, a $9 million loss attributable to restructuring-related activities and $1 million of interest expense related to the fine imposed on us by the EC in 2019 (2019 EC fine).  Other items excluded from Non-GAAP results also included $32 million of gains driven by the revaluation of our deferred compensation plan liabilities, which decreased operating expenses, offset by corresponding $32 million of losses driven by the revaluation of the associated plan assets, which were included within investment and other (expense) income, net.

[0000804328-22-000020:8k_2_02:89]
(2)   At fiscal year end, the quarterly tax provision for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP.  In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column.  Tax expense in the “Other Items” column included a $98 million foreign currency loss related to a noncurrent receivable resulting from our refund claim of Korean withholding taxes paid in prior periods, partially offset by a $43 million benefit to reconcile the tax provision of each column to the total GAAP tax provision for the quarter, a $7 million benefit for the tax effect of acquisition-related charges and a $4 million benefit from the combined effect of other items in EBT.

[0000804328-22-000020:8k_2_02:90]
|  | Fiscal 2022 Supplemental Information and Reconciliations |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |
|  | Cost of revenues |  | $18,635 |  |  | $15 |  |  | $61 |  |  | $195 |  |  | $18,364 |  |
|  | Research and development expenses |  | 8,194 |  |  | — |  |  |  | 1,537 |  |  | (64) |  |  | 6,721 |  |
|  | Selling, general and administrative expenses |  | 2,570 |  |  | 14 |  |  | 463 |  |  | 76 |  |  | 2,017 |  |
|  | Other income |  | (1,059) |  |  |  | — |  |  |  | — |  |  |  | (1,059) |  |  |  | — |  |  |
|  | Interest expense |  | (490) |  |  | — |  |  |  | — |  |  |  | 46 |  |  | (536) |  |
|  | Investment and other (expense) income, net |  | (372) |  |  | (281) |  |  | — |  |  |  | (158) |  |  | 67 |  |
|  | Income tax expense (benefit) |  | 2,012 |  |  | (72) |  |  | (489) |  |  | 229 |  |  | 2,344 |  |
|  | Discontinued operations, net of income taxes |  | (50) |  |  |  | — |  |  |  | — |  |  |  | (50) |  |  |  | — |  |  |

[0000804328-22-000020:8k_2_02:91]
(1)  Other items excluded from Non-GAAP results included a $1.1 billion benefit resulting from the reversal of the 2018 EC fine (including a $1.1 billion benefit in other income and a $51 million reduction in interest expense) and a $2 million gain related to a favorable legal settlement, partially offset by $50 million of losses, net of income taxes, from the discontinued operations of the Non-Arriver businesses, as well as $328 million of other acquisition-related charges, a $38 million loss attributable to restructuring-related activities and $5 million of interest expense related to the 2019 EC fine.  Other items excluded from Non-GAAP results also included $140 million of gains driven by the revaluation of our deferred compensation plan liabilities, which decreased operating expenses, offset by corresponding $141 million of losses driven by the revaluation of the associated plan assets, which were included within investment and other (expense) income, net.

[0000804328-22-000020:8k_2_02:92]
(2)   Tax expense in the “Other Items” column included a $226 million foreign currency loss related to a noncurrent receivable resulting from our refund claim of Korean withholding taxes paid in prior periods, a $28 million charge related to a foreign tax audit and a $1 million charge from the combined effect of other items in EBT, partially offset by a $26 million benefit for the tax effect of acquisition-related charges.
