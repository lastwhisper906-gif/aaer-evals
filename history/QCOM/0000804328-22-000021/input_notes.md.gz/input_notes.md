# QCOM notes — 0000804328-22-000021


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000804328-22-000021:notes:1]
Significant Accounting Policies
We are a global leader in the development and commercialization of foundational technologies for the wireless industry. Our technologies and products are used in mobile devices and other wireless products, including those used in the internet of things (IoT) and automotive systems for connectivity, digital cockpit and advanced driver assistance and automated driving (ADAS/AD). We derive revenues principally from sales of integrated circuit products and through the licensing of our intellectual property, including patents and other rights.

[0000804328-22-000021:notes:2]
Principles of Consolidation. The consolidated financial statements include the assets, liabilities and operating results of Qualcomm, its subsidiaries and any variable interest entities for which we are deemed to be the primary beneficiary (Note 9). Intercompany transactions and balances have been eliminated.

[0000804328-22-000021:notes:3]
Financial Statement Preparation. The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in our consolidated financial statements and the accompanying notes. Examples of our significant accounting estimates and policies that may involve a higher degree of judgment and complexity than others include: the estimation of sales-based royalty revenues; the impairment of non-marketable equity investments; the valuation of inventories; the impairment of goodwill, other indefinite-lived assets and long-lived assets; the recognition, measurement and disclosure of loss contingencies related to legal and regulatory proceedings; and the calculation of our income tax provision, including the recognition and measurement of uncertain tax positions. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

[0000804328-22-000021:notes:4]
Fiscal Year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. The fiscal years presented each included 52 weeks.

[0000804328-22-000021:notes:5]
Cash Equivalents. We consider all highly liquid investments with original maturities of 90 days or less to be cash equivalents. Cash equivalents may be comprised of money market funds, certificates of deposit, commercial paper, corporate bonds and notes, certain bank time and demand deposits and government agencies’ securities. The carrying amounts approximate fair value due to the short maturities of these instruments.

[0000804328-22-000021:notes:6]
Marketable Securities. Marketable securities include marketable equity securities, available-for-sale debt securities and, from time-to-time, certain time deposits. We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value with all realized and unrealized gains and losses on investments in marketable equity securities and realized gains and losses on available-for-sale debt securities recognized in investment and other income (expense), net. Debt securities are classified as available for sale or held to maturity at the time of purchase and reevaluated at each balance sheet date. The realized and unrealized gains and losses on marketable securities are determined using the specific identification method.

[0000804328-22-000021:notes:7]
If a debt security has an unrealized loss and we either intend to sell the security or it is more likely than not that we will be required to sell the security before its anticipated recovery, we record an impairment charge to investment and other income (expense), net for the entire amount of the unrealized loss and adjust the amortized cost basis of the security. For the remaining debt securities, if an unrealized loss exists, we separate the impairment into the portion of the loss related to credit factors and the portion of the loss that is not related to credit factors. Unrealized gains or unrealized losses that are not related to credit factors on available-for-sale debt securities are recorded as a component of accumulated other comprehensive income (loss), net of income taxes. Unrealized losses that are related to credit loss factors on available-for-sale debt securities and subsequent adjustments to the credit loss are recorded as an allowance for credit losses, which is included in investment and other income (expense), net. In evaluating whether a credit loss exists, we consider a variety of factors, including the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; the security’s relative performance versus its peers, sector or asset class; the market and economy in general; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.

[0000804328-22-000021:notes:8]
Equity Method and Non-marketable Equity Investments. Equity investments for which we have significant influence, but not control, over the investee and are not the primary beneficiary of the investee’s activities are accounted for under the equity method. Our share of gains and losses in equity method investments are recorded in investment and other income (expense), net. We eliminate unrealized profit or loss related to transactions with equity method investees in relation to our ownership interest in the investee, which is recorded as a component of equity in net earnings (losses) in investees in investment and other income (expense), net. Non-marketable equity investments (for which we do not have significant influence or control) are investments without readily determinable fair values that are recorded based on initial cost minus impairment, if any, plus or minus adjustments resulting from observable price changes in orderly transactions for identical or similar securities, if any. All gains and losses on investments in non-marketable equity securities, realized and unrealized, are recognized in investment and other income (expense), net. We monitor equity method and non-marketable equity investments for events or circumstances that could indicate the investments are impaired, such as a deterioration in the investee’s financial condition and business forecasts and lower valuations in recently completed or anticipated financings, and recognize a charge to investment and other income (expense), net for the difference between the estimated fair value and the carrying value. For

[0000804328-22-000021:notes:9]
equity method investments, we record impairment losses in earnings only when impairments are considered other-than-temporary.

[0000804328-22-000021:notes:10]
Derivatives. Our primary objectives for holding derivative instruments are to manage foreign exchange risk for certain foreign currency revenues, operating expenses, receivables and payables and to manage interest rate risk associated with our cash equivalents, marketable securities and long-term debt. Derivative instruments are recorded at fair value and included in other current or noncurrent assets or liabilities based on their maturity dates. Counterparties to these derivative instruments are all major banking institutions. At September 25, 2022, the aggregate fair value of our derivative instruments recorded in total assets and in total liabilities were $271 million and $346 million, respectively. At September 26, 2021, the aggregate fair value of our derivative instruments recorded in total assets and in total liabilities were $42 million and $111 million, respectively.

[0000804328-22-000021:notes:11]
Foreign Currency Hedges: We manage our exposure to foreign exchange market risks, when deemed appropriate, through the use of derivative instruments, including foreign currency forward and option contracts with financial counterparties, that may or may not be designated as hedging instruments. At September 25, 2022 and September 26, 2021, these derivative instruments had maturity dates between one and 21 months. Gains and losses arising from such contracts that are designated as cash flow hedging instruments are recorded as a component of accumulated other comprehensive income (loss) as gains and losses on derivative instruments, net of income taxes. The hedging gains and losses in accumulated other comprehensive income (loss) are subsequently reclassified to revenues or costs and expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect our earnings. The cash flows associated with derivative instruments designated as cash flow hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction.

[0000804328-22-000021:notes:12]
For foreign currency forward contracts not designated as hedging instruments, the changes in fair value are recorded in investment and other income (expense), net in the period of change. The cash flows associated with such derivative instruments not designated as hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction.

[0000804328-22-000021:notes:13]
Interest Rate Swaps: From time to time, we enter into interest rate swap agreements that allow us to effectively convert fixed-rate payments into floating-rate payments on portions of our outstanding long-term debt. We enter into these agreements, in part, to manage interest rate risk associated with our cash equivalents and marketable securities, in addition to changes in the fair value of our outstanding debt. These transactions are designated as fair value hedges, and the gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate debt attributable to the hedged risks, are recognized as interest expense in the current period. The interest settlement payments associated with the interest rate swap agreements are classified as cash flows from operating activities in the consolidated statements of cash flows.

[0000804328-22-000021:notes:14]
During fiscal 2021, we entered into forward-starting interest rate swaps to hedge the variability of forecasted interest payments on certain anticipated debt issuances. These have been designated as cash flow hedges of forecasted transactions. The gains and losses arising from such contracts are recorded as a component in accumulated other comprehensive income (loss) as gains and losses on derivative instruments. When the anticipated debt issuances are completed, the hedging gains and losses in accumulated other comprehensive income (loss) are reclassified as interest expense over the terms of the related debt issued.

[0000804328-22-000021:notes:15]
Gross Notional Amounts: The gross notional amounts of our foreign currency and interest rate derivatives by instrument type were as follows (in millions):

[0000804328-22-000021:notes:16]
|  | September 25,2022 |  | September 26,2021 |
| Forwards | $ | 3,176 |  |  | $ | 2,449 |  |
| Options | 881 |  |  | 870 |  |
| Swaps | 3,650 |  |  | 2,600 |  |
|  | $ | 7,707 |  |  | $ | 5,919 |  |

[0000804328-22-000021:notes:17]
The gross notional amounts of our derivatives by currency were as follows (in millions):

[0000804328-22-000021:notes:18]
|  | September 25,2022 |  | September 26,2021 |
| British pound sterling | $ | 172 |  |  | $ | 83 |  |
| Chinese renminbi | 1,920 |  |  | 1,627 |  |
| Euro | 206 |  |  | — |  |
| Indian rupee | 1,657 |  |  | 1,262 |  |
| Japanese yen | 8 |  |  | 27 |  |
| United States dollar | 3,744 |  |  | 2,920 |  |
|  | $ | 7,707 |  |  | $ | 5,919 |  |

[0000804328-22-000021:notes:19]
Other Hedging Activities. At September 25, 2022 and September 26, 2021, we designated $235 million and $1.5 billion, respectively, of foreign currency-denominated liabilities, excluding accrued interest, related to the fine(s) imposed by the European Commission as hedges of our net investment in certain foreign subsidiary(ies). Gains and losses arising from the portion of these balances that are designated as net investment hedges are recorded as a component of accumulated other comprehensive income (loss) as foreign currency translation adjustments. During fiscal 2022, we discontinued the net investment hedge related to one of the fines previously recorded related to the European Commission (EC) Investigation (Note 7). The associated foreign currency gains related to this fine previously recorded will remain in accumulated other comprehensive income (loss) until the foreign subsidiaries are sold or substantially liquidated, at which point it will be reclassified into earnings.

[0000804328-22-000021:notes:20]
Fair Value Measurements. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants as of the measurement date. Applicable accounting guidance provides an established hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Observable inputs are inputs that market participants would use in valuing the asset or liability and are developed based on market data obtained from sources independent of us. Unobservable inputs are inputs that reflect our assumptions about the factors that market participants would use in valuing the asset or liability. There are three levels of inputs that may be used to measure fair value:

[0000804328-22-000021:notes:21]
•Level 1 includes financial instruments for which quoted market prices for identical instruments are available in active markets.

[0000804328-22-000021:notes:22]
•Level 2 includes financial instruments for which there are inputs other than quoted prices included within Level 1 that are observable for the instrument.

[0000804328-22-000021:notes:23]
•Level 3 includes financial instruments for which fair value is derived from valuation techniques in which one or more significant inputs are unobservable, including our own assumptions.

[0000804328-22-000021:notes:24]
Assets and liabilities measured at fair value are classified based on the lowest level of input that is significant to the fair value measurement. We review the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy. We recognize transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer to occur.

[0000804328-22-000021:notes:25]
Cash Equivalents and Marketable Securities: We obtain pricing information from quoted market prices, pricing vendors or quotes from brokers/dealers. We conduct reviews of our primary pricing vendors to determine whether the inputs used in the vendor’s pricing processes are deemed to be observable. Contractual sale restrictions are not considered in measuring the fair value of marketable equity securities. The fair value for interest-bearing securities includes accrued interest. The fair value of U.S. Treasury securities and government-related securities, corporate bonds and notes and common stock is generally determined using standard observable inputs, including reported trades, quoted market prices, matrix pricing, benchmark yields, broker/dealer quotes, issuer spreads, two-sided markets and/or benchmark securities. The fair value of mortgage- and asset-backed securities is derived from the use of matrix pricing (prices for similar securities) or, in some cases, cash flow pricing models with observable inputs, such as contractual terms, maturity, credit rating and/or securitization structure to determine the timing and amount of future cash flows.

[0000804328-22-000021:notes:26]
Derivative Instruments: Derivative instruments that are traded on an exchange are valued using quoted market prices and are included in Level 1. Derivative instruments that are not traded on an exchange are valued using conventional calculations/models that are primarily based on observable inputs, such as foreign currency exchange rates, volatilities and interest rates, and therefore, such derivative instruments are included in Level 2.

[0000804328-22-000021:notes:27]
Other Investments and Other Liabilities: Other investments and other liabilities included in Level 1 are comprised of our deferred compensation plan liabilities and related assets, which consist of mutual funds and are included in other current assets and other assets. Gains and losses on the revaluation of our deferred compensation plan assets are recorded in investment and other income (expense), net. Corresponding offsetting amounts related to the revaluation of our deferred compensation plan liabilities are included in operating expenses. Other investments included in Level 3 are comprised of contingently issuable equity instruments and warrants issued in connection with certain mergers and initial public offerings of

[0000804328-22-000021:notes:28]
our non-marketable equity investees and convertible debt instruments issued by private companies. The inputs we use to estimate the fair values of these instruments are generally unobservable, and therefore, they are included in Level 3.

[0000804328-22-000021:notes:29]
Nonrecurring Fair Value Measurements: We measure certain assets and liabilities at fair value on a nonrecurring basis. These assets and liabilities include equity method and non-marketable equity investments, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired, all of which are generally measured based on unobservable inputs using an income or market approach.

[0000804328-22-000021:notes:30]
Inventories. Inventories are valued at the lower of cost and net realizable value using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers and our own forecasts of customer demand, among other factors. This valuation also requires us to make judgments and assumptions based on information currently available about market conditions, including competition, anticipated technological changes, internal product life cycle and development plans, product pricing and other broader market conditions that may impact customer demand, such as the impact of certain capacity constraints experienced across the semiconductor industry through the third quarter of fiscal 2022 and in fiscal 2021, as well as the impact of the macroeconomic environment in fiscal 2022. We generally place binding purchase orders with our suppliers in advance of receiving contractually binding forecasts and/or purchase orders from our customers. The time period between placing purchase orders with our suppliers and receiving contractually binding forecasts and/or purchase orders from our customers has increased and may continue to increase as a result of extended manufacturing lead-times, driven in part by a continued transition to leading-edge technologies and/or increased complexity in the manufacturing process of our products. If we overestimate demand for our products, the amount of our loss will be impacted by our contractual ability to reduce inventory purchases from our suppliers. Our manufacturing relationships generally allow for cancellation of outstanding purchase commitments, but in some cases may require incremental fees and/or the loss of amounts paid in advance related to capacity underutilization. Further, if our customers cancel purchase orders or alter forecasts this may result in excess inventory on hand. Our assumptions of future product demand are inherently uncertain, and changes in our estimates and assumptions may cause us to record additional write-downs in the future if demand forecasted for specific products is greater than actual demand.

[0000804328-22-000021:notes:31]
Property, Plant and Equipment. Property, plant and equipment are recorded at cost and depreciated or amortized using the straight-line method over their estimated useful lives. Upon the retirement or disposition of property, plant and equipment, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded, when appropriate. Buildings on owned land are depreciated over 30 years, and building improvements are depreciated over 15 years. Leasehold improvements and buildings on leased land are amortized over the shorter of their estimated useful lives, not to exceed 15 years and 30 years, respectively, or the remaining term of the related lease. Other property, plant and equipment have useful lives ranging from 2 to 15 years. Maintenance, repairs and minor renewals or betterments are charged to expense as incurred.

[0000804328-22-000021:notes:32]
Operating Leases. Operating lease assets and liabilities are recognized for leases with lease terms greater than 12 months based on the present value of the future lease payments over the lease term at the commencement date. Operating leases are included in other assets, other current liabilities and other liabilities on our consolidated balance sheet. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise such option. We account for substantially all lease and related non-lease components together as a single lease component. Operating lease expense is recognized on a straight-line basis over the lease term.

[0000804328-22-000021:notes:33]
Goodwill and Other Intangible Assets. Goodwill represents the excess of purchase price over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Acquired intangible assets other than goodwill are amortized over their useful lives unless the lives are determined to be indefinite. For intangible assets purchased in a business combination, the estimated fair values of the assets received are used to establish their recorded values. For intangible assets acquired in a nonmonetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value. An estimate of fair value can be affected by many assumptions that require significant judgment. For example, the income approach generally requires us to use assumptions to estimate future cash flows including those related to total addressable market, pricing and share forecasts, competition, technology obsolescence, future tax rates and discount rates. Our estimate of the fair value of certain assets may differ materially from that determined by others who use different assumptions or utilize different business models and from the future cash flows actually realized.

[0000804328-22-000021:notes:34]
Impairment of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. Goodwill and other indefinite-lived intangible assets are tested annually for impairment in the fourth fiscal quarter, and in interim periods if events or changes in circumstances indicate that the assets may be impaired. If a qualitative assessment is used and we determine that the fair value of a reporting unit or indefinite-lived intangible asset is more likely than not (i.e., a likelihood of more than 50%) less than its carrying amount, a quantitative impairment test will be performed. If goodwill is quantitatively assessed for impairment and a reporting unit’s carrying value exceeds its fair value, the difference is recorded as an impairment. Other

[0000804328-22-000021:notes:35]
indefinite-lived intangible assets are quantitatively assessed for impairment, if necessary, by comparing their estimated fair values to their carrying values. If the carrying value exceeds the fair value, the difference is recorded as an impairment. Our judgments regarding the existence of impairment indicators and future cash flows related to goodwill, other indefinite-lived assets and long-lived assets may be based on operational performance of our businesses, market conditions, expected selling price and/or other factors. Although there are inherent uncertainties in this assessment process, the estimates and assumptions we use, including estimates of future cash flows and discount rates, are consistent with our internal planning, when appropriate. If these estimates or their related assumptions change in the future, we may be required to record an impairment charge on a portion or all of such assets. Furthermore, we cannot predict the occurrence of future impairment-triggering events nor the impact such events might have on our reported asset values.

[0000804328-22-000021:notes:36]
Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by comparing the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Long-lived assets to be disposed of by sale are reported at the lower of their carrying amounts or their estimated fair values less costs to sell and are not depreciated.

[0000804328-22-000021:notes:37]
Revenue Recognition. We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We also generate revenues from licensing system software and by performing development and other services and from other product sales. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of our performance obligations.

[0000804328-22-000021:notes:38]
Revenues from sales of our products are recognized upon transfer of control to the customer, which is generally at the time of shipment. Revenues from providing services are typically recognized over time as our performance obligation is satisfied. Revenues from providing services and licensing system software were each less than 5% of total revenues for all periods presented.

[0000804328-22-000021:notes:39]
We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, such as smartphones, tablets, laptops and smartwatches, and provide for a maximum royalty amount payable per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, considering all relevant information (historical, current and forecasted) that is reasonably available to us. Our estimates of sales-based royalties are based largely on preliminary royalty estimates provided by our licensees and, to a lesser extent, an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property, combined with an estimate of the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products. In the periods presented, we have recognized immaterial differences between preliminary royalty estimates provided to us by licensees and actual amounts reported and paid by licensees, which are generally received the following quarter, as licensees have not completed their royalty reporting process at the time estimates are provided to us, and in certain cases, they do not provide all necessary information in order for us to calculate an estimate of royalties due, which requires us to independently estimate certain information. We also consider in our estimates of sales-based royalties any changes in pricing we plan or expect to make and certain constraints on our ability to estimate such royalties. As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

[0000804328-22-000021:notes:40]
License agreements that require payment of license fees contain a single performance obligation that represents ongoing access to a portfolio of intellectual property over the license term since such agreements provide the licensee the right to access a portfolio of intellectual property that exists at inception of the license agreement and to updates and new intellectual property that is added to the licensed portfolio during the term of the agreement that are highly interdependent or interrelated. Since we expect to expend efforts to develop and transfer updates to our licensed portfolio on an even basis, license fees are recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee.

[0000804328-22-000021:notes:41]
We account for a contract with a customer/licensee when it is legally enforceable, the parties are committed to perform their respective obligations, the rights of the parties regarding the goods and/or services to be transferred are identified, payment terms are identified, the contract has commercial substance and collectability of substantially all of the consideration is probable, which for product sales, is generally when a customer purchase order is executed and for licensing revenues, is generally upon execution of a license agreement. If all such conditions are not met, revenues and any associated receivables

[0000804328-22-000021:notes:42]
are generally not recognized until such time that the required conditions are met. Cash collected from customers prior to a contract existing is recorded to other customer-related liabilities in other current liabilities.

[0000804328-22-000021:notes:43]
From time to time, regulatory authorities investigate our business practices, particularly with respect to our licensing business, and institute proceedings against us. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed original equipment manufacturers (OEMs) or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. Additionally, from time to time, companies initiate various strategies in an attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property, which may include disputing, underreporting, underpaying, not reporting and/or not paying royalties owed to us under their license agreements with us, or reporting to us in a manner that is not in compliance with their contractual obligations. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in the revenue recognition guidance, which includes, among other items, evaluating whether our license agreements remain valid and enforceable and evaluating licensees’ conduct and whether they remain committed to perform their respective obligations. We also estimate and recognize licensing revenues only to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur, which includes, among other items, determining the expected impact, if any, to revenues of any license agreements that may be renegotiated and/or are newly entered into. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us. These aforementioned estimates may require significant judgment.

[0000804328-22-000021:notes:44]
We measure revenues (including our estimates of sales-based royalties) based on the amount of consideration we expect to receive in exchange for products or services. We record reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of our products and technologies, in the period that the related revenues are earned. For certain QCT (Qualcomm CDMA Technologies) customer incentive arrangements, there is complexity in applying certain contractual terms to determine the amount recorded as a reduction to revenues. For the periods presented, no significant reversals of revenues have been made related to such amounts previously recorded. The amounts accrued for customer incentive arrangements are recorded as a reduction to accounts receivable, net or as other current liabilities based on whether we have the intent and contractual right of offset. Certain amounts recorded as a reduction to revenues for customer incentive arrangements are considered variable consideration and are included in the transaction price primarily based on estimating the most likely amount expected to be provided to the customer/licensee.

[0000804328-22-000021:notes:45]
Adjustments made to revenues in subsequent periods to reflect changes in estimates as new information becomes available are included in our disclosure of revenues recognized from previously satisfied performance obligations (Note 2).

[0000804328-22-000021:notes:46]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied performance obligations.

[0000804328-22-000021:notes:47]
Concentrations. A significant portion of our revenues are concentrated with a small number of customers/licensees of our QCT and QTL (Qualcomm Technology Licensing) segments. The comparability of customer/licensee concentrations for the periods presented are impacted by the timing of customer/licensees device launches and/or innovation cycles and other seasonal trends, among other fluctuations in demand. Revenues from each customer/licensee that were 10% or greater of total revenues were as follows:

[0000804328-22-000021:notes:48]
|  | September 25,2022 |  | September 26,2021 |  | September 27,2020 |
| Customer/licensee (w) | 21 | % |  | 14 | % |  | 19 | % |
| Customer/licensee (x) | 21 |  |  | 23 |  |  | 10 |  |
| Customer/licensee (y) | * |  | 13 |  |  | 12 |  |
| Customer/licensee (z) | * |  | * |  | 10 |  |

[0000804328-22-000021:notes:49]
* Less than 10%

[0000804328-22-000021:notes:50]
We rely on sole- or limited-source suppliers for some products, particularly products in our QCT segment, subjecting us to possible shortages of raw materials or manufacturing capacity. The loss of a supplier or the inability of a supplier to meet performance or quality specifications or delivery schedules could harm our ability to meet our delivery obligations and/or negatively impact our revenues, business operations and ability to compete for future business.

[0000804328-22-000021:notes:51]
Share-Based Compensation. Share-based compensation expense for equity-classified awards, principally related to restricted stock units (RSUs), is measured at the grant date, or at the acquisition date for awards assumed in business combinations, based on the estimated fair value of the award and is recognized over the employee’s requisite service period. The fair values of RSUs are estimated based on the fair market values of the underlying stock on the dates of grant or dates

[0000804328-22-000021:notes:52]
the RSUs are assumed. Share-based compensation expense is adjusted to exclude amounts related to share-based awards that are expected to be forfeited.

[0000804328-22-000021:notes:53]
Legal and Regulatory Proceedings. We are currently involved in certain legal and regulatory proceedings. Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Investigations by antitrust and trade regulation agencies are not conducted in a consistent manner across jurisdictions. Further, each country and agency has different sets of laws, rules and regulations, both substantive and procedural, as well as different legal principles, theories and potential remedies, and some agencies may seek to use the investigation to advance domestic policy goals. Depending on the jurisdiction, these investigations can involve non-transparent procedures under which we may not receive access to evidence relied upon by the enforcement agency or that may be exculpatory and may not be informed of the specific legal theories or evidence considered or relied upon by the agency. Unlike in civil litigation in the United States, in foreign proceedings, we may not be entitled to discovery or depositions, allowed to cross-examine witnesses or confront our accusers. As a result, we may not be aware of, and may not be entitled to know, all allegations against us, or the information or documents provided to, or discovered or prepared by, the agency. Accordingly, we may have little or no idea what an agency’s intent is with respect to liability, penalties or the timing of a decision. In many cases the agencies are given significant discretion, and any available precedent may have limited, if any, predictive value in their jurisdictions or other jurisdictions. Accordingly, we cannot predict the outcome of these matters. A broad range of remedies with respect to our business practices that are deemed to violate applicable laws are potentially available. These remedies may include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or to modify our business practices.

[0000804328-22-000021:notes:54]
If there is at least a reasonable possibility that a material loss may have been incurred associated with pending legal and regulatory proceedings, we disclose such fact, and if reasonably estimable, we provide an estimate of the possible loss or range of possible loss. We record our best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, we record the minimum estimated liability. As additional information becomes available, we assess the potential liability related to pending legal and regulatory proceedings and revise our estimates and update our disclosures accordingly. Significant judgment is required in both the determination of probability and the determination as to whether a loss is reasonably estimable. Our legal costs associated with defending ourself are recorded to expense as incurred.

[0000804328-22-000021:notes:55]
Foreign Currency. Certain foreign subsidiaries use a local currency as the functional currency. Resulting translation gains or losses are recorded as a component of accumulated other comprehensive income (loss). Transaction gains or losses related to balances denominated in a currency other than the functional currency of the entity involved are recognized in the consolidated statements of operations.

[0000804328-22-000021:notes:56]
Income Taxes. The asset and liability approach is used to recognize deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax bases of assets and liabilities. Tax law and rate changes are reflected in income in the period such changes are enacted. We record a valuation allowance to reduce deferred tax assets to the amount that is more likely than not to be realized. We include interest and penalties related to income taxes, including unrecognized tax benefits, within income tax expense. We classify all deferred tax assets and liabilities as noncurrent in the consolidated balance sheets. We recognize excess tax benefits and shortfall tax detriments associated with share-based awards in the consolidated statements of operations, as a component of income tax expense, when realized.

[0000804328-22-000021:notes:57]
Our income tax returns are based on calculations and assumptions that are subject to examination by the Internal Revenue Service (IRS) and other tax authorities. In addition, the calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. While we believe we have appropriate support for the positions taken on our tax returns, we regularly assess the potential outcomes of examinations by tax authorities in determining the adequacy of our provision for income taxes. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts that give rise to a revision become known.

[0000804328-22-000021:notes:58]
We are subject to income taxes in the United States and numerous foreign jurisdictions, and the assessment of our income tax positions involves dealing with uncertainties in the application of complex tax laws and regulations in various taxing jurisdictions. In addition, the application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws and regulations themselves are subject to change as a result of changes in fiscal policy, changes in legislation, the evolution of regulations and court rulings. Significant judgments and estimates are required in determining our provision for income taxes, including those related to special deductions such as FDII (foreign-derived intangible income), tax incentives, intercompany research and development cost-sharing arrangements, transfer pricing, tax credits and the realizability of deferred tax assets. While we believe we have appropriate support for the positions we have taken or that we plan to take on our tax returns, we regularly assess the potential outcomes of examinations by taxing authorities in determining the adequacy of our provision for income taxes. Therefore, the actual liability for U.S. or foreign

[0000804328-22-000021:notes:59]
taxes may be materially different from our estimates, which could result in the need to record additional tax liabilities or potentially reverse previously recorded tax liabilities. For tax years prior to fiscal 2021, we are participating in the IRS Compliance Assurance Process program whereby we endeavor to agree with the IRS on the treatment of all issues prior to filing our federal return.

[0000804328-22-000021:notes:60]
Stock Repurchases. To reflect share repurchases in the consolidated balance sheet, we (i) reduce common stock for the par value of the shares, (ii) reduce paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) record the residual amount, if any, to retained earnings.

[0000804328-22-000021:notes:61]
In August 2022, the Inflation Reduction Act was enacted in the United States, which included, among other items, a 1% excise tax on certain net stock repurchases after December 31, 2022. Any such excise tax on our stock repurchases will be recorded as a component of stockholders’ equity.

[0000804328-22-000021:notes:62]
Earnings (Loss) Per Share. Basic earnings (loss) per share is computed by dividing net income (loss) by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of the weighted-average number of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans and shares subject to accelerated share repurchase programs, if any, and the weighted-average number of common shares outstanding during the reporting period. The following table provides information about the diluted earnings per share calculation (in millions):

[0000804328-22-000021:notes:63]
|  | 2022 |  | 2021 |  | 2020 |
| Dilutive common share equivalents included in diluted shares | 14 |  |  | 18 |  |  | 14 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 1 |  |  | — |  |  | 1 |  |


## us-gaap:LesseeLeasesPolicyTextBlock

[0000804328-22-000021:notes:64]
Operating Leases. Operating lease assets and liabilities are recognized for leases with lease terms greater than 12 months based on the present value of the future lease payments over the lease term at the commencement date. Operating leases are included in other assets, other current liabilities and other liabilities on our consolidated balance sheet. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise such option. We account for substantially all lease and related non-lease components together as a single lease component. Operating lease expense is recognized on a straight-line basis over the lease term.We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000804328-22-000021:notes:65]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied performance obligations.
We disaggregate our revenues by segment (Note 8), by product and service (as presented on our consolidated statements of operations), and for our QCT segment, by revenue stream, which is based on the industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-22-000021:notes:66]
Composition of Certain Financial Statement Items

[0000804328-22-000021:notes:67]
| Accounts Receivable (in millions) |  |  |  |
|  | September 25,2022 |  | September 26,2021 |
| Trade, net of allowances for doubtful accounts | $ | 4,175 |  |  | $ | 2,214 |  |
| Unbilled | 1,435 |  |  | 1,354 |  |
| Other | 33 |  |  | 11 |  |
|  | $ | 5,643 |  |  | $ | 3,579 |  |

[0000804328-22-000021:notes:68]
| Inventories (in millions) |  |  |  |
|  | September 25,2022 |  | September 26,2021 |
| Raw materials | $ | 221 |  |  | $ | 267 |  |
| Work-in-process | 3,329 |  |  | 1,475 |  |
| Finished goods | 2,791 |  |  | 1,486 |  |
|  | $ | 6,341 |  |  | $ | 3,228 |  |

[0000804328-22-000021:notes:69]
| Property, Plant and Equipment (in millions) |  |  |  |
|  | September 25,2022 |  | September 26,2021 |
| Land | $ | 170 |  |  | $ | 172 |  |
| Buildings and improvements | 1,767 |  |  | 1,642 |  |
| Computer equipment and software | 1,680 |  |  | 1,483 |  |
| Machinery and equipment | 7,349 |  |  | 6,420 |  |
| Furniture and office equipment | 105 |  |  | 94 |  |
| Leasehold improvements | 369 |  |  | 374 |  |
| Construction in progress | 330 |  |  | 269 |  |
|  | 11,770 |  |  | 10,454 |  |
| Less accumulated depreciation and amortization | (6,602) |  |  | (5,895) |  |
|  | $ | 5,168 |  |  | $ | 4,559 |  |

[0000804328-22-000021:notes:70]
Depreciation and amortization expense related to property, plant and equipment for fiscal 2022, 2021 and 2020 was $1.3 billion, $1.0 billion and $772 million, respectively.

[0000804328-22-000021:notes:71]
Goodwill and Other Intangible Assets. We allocate goodwill to our reporting units for impairment testing purposes. The following table presents the goodwill allocated to our segments, as described in Note 8, as well as the changes in the carrying amounts of goodwill during fiscal 2022 and 2021 (in millions):

[0000804328-22-000021:notes:72]
|  |  | QCT |  | QTL |  |  |  | Total |
| Balance at September 27, 2020 |  | $ | 5,605 |  |  | $ | 718 |  |  |  |  | $ | 6,323 |  |
| Acquisitions |  | 912 |  |  | 5 |  |  |  |  | 917 |  |
| Foreign currency translation adjustments |  | 6 |  |  | — |  |  |  |  | 6 |  |
| Balance at September 26, 2021 (1) |  | 6,523 |  |  | 723 |  |  |  |  | 7,246 |  |
| Acquisitions |  | 3,375 |  |  | 12 |  |  |  |  | 3,387 |  |
| Foreign currency translation adjustments |  | (121) |  |  | (4) |  |  |  |  | (125) |  |
| Balance at September 25, 2022 (1) |  | $ | 9,777 |  |  | $ | 731 |  |  |  |  | $ | 10,508 |  |

[0000804328-22-000021:notes:73]
(1) Cumulative goodwill impairments were $812 million at both September 25, 2022 and September 26, 2021.

[0000804328-22-000021:notes:74]
The components of other intangible assets, net were as follows (in millions):

[0000804328-22-000021:notes:75]
|  | September 25, 2022 |  | September 26, 2021 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |
| Technology-based | $ | 5,517 |  |  | $ | (3,669) |  |  | 12 |  | $ | 5,385 |  |  | $ | (3,971) |  |  | 11 |
| Other | 90 |  |  | (56) |  |  | 10 |  | 93 |  |  | (49) |  |  | 10 |
|  | $ | 5,607 |  |  | $ | (3,725) |  |  | 10 |  | $ | 5,478 |  |  | $ | (4,020) |  |  | 11 |

[0000804328-22-000021:notes:76]
All of these intangible assets are subject to amortization, other than acquired in-process research and development which had a carrying value of $546 million and $247 million at September 25, 2022 and September 26, 2021, respectively. Amortization expense related to these intangible assets was $482 million, $537 million and $621 million for fiscal 2022, 2021 and 2020, respectively. At September 25, 2022, amortization expense related to other intangible assets, including acquired in-process research and development beginning upon the completion of the underlying projects, is expected to be $429 million, $275 million, $245 million, $246 million and $168 million for each of the five years from fiscal 2023 through 2027, respectively, and $519 million thereafter.

[0000804328-22-000021:notes:77]
Equity Method and Non-marketable Equity Investments. The carrying values of our equity method and non-marketable equity investments are recorded in other assets and were as follows (in millions):

[0000804328-22-000021:notes:78]
|  | September 25,2022 |  | September 26,2021 |
| Equity method investments | $ | 189 |  |  | $ | 214 |  |
| Non-marketable equity investments | 1,105 |  |  | 1,051 |  |
|  | $ | 1,294 |  |  | $ | 1,265 |  |

[0000804328-22-000021:notes:79]
| Other Current Liabilities (in millions) |  |  |  |
|  | September 25,2022 |  | September 26,2021 |
| Customer incentives and other customer-related liabilities | $ | 1,879 |  |  | $ | 1,974 |  |
| Accrual for EC fines (Note 7) | 245 |  |  | 1,522 |  |
| Income taxes payable | 634 |  |  | 862 |  |
| Other | 931 |  |  | 656 |  |
|  | $ | 3,689 |  |  | $ | 5,014 |  |

[0000804328-22-000021:notes:80]
Revenues. We disaggregate our revenues by segment (Note 8), by product and service (as presented on our consolidated statements of operations), and for our QCT segment, by revenue stream, which is based on the industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets. QCT revenue streams were as follows (in millions):

[0000804328-22-000021:notes:81]
|  |  |  |  |  | 2022 |  | 2021 |  | 2020 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 25,027 |  |  | $ | 16,830 |  |  | $ | 10,461 |  |
| RFFE (2) |  |  |  |  |  |  |  |  | 4,330 |  |  | 4,158 |  |  | 2,362 |  |
| Automotive (3) |  |  |  |  |  |  |  |  | 1,372 |  |  | 975 |  |  | 644 |  |
| IoT (internet of things) (4) |  |  |  |  |  |  |  |  | 6,948 |  |  | 5,056 |  |  | 3,026 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 37,677 |  |  | $ | 27,019 |  |  | $ | 16,493 |  |

[0000804328-22-000021:notes:82]
(1) Includes revenues from products sold for use in mobile handsets, excluding RFFE (radio frequency front-end) components.

[0000804328-22-000021:notes:83]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in mobile handsets) and excludes radio frequency transceiver components.

[0000804328-22-000021:notes:84]
(3) Includes revenues from products sold for use in automobiles, including connectivity, digital cockpit and advanced driver assistance and automated driving.

[0000804328-22-000021:notes:85]
(4) Primarily includes products sold for use in the following industries and applications: consumer (including computing, voice and music and XR), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, transportation and logistics and utilities).

[0000804328-22-000021:notes:86]
Revenue recognized from performance obligations satisfied (or partially satisfied) in previous periods were as follows (in millions):

[0000804328-22-000021:notes:87]
|  | 2022 (1) |  | 2021 (2) |  | 2020 (3) |
| Revenues recognized from previously satisfied performance obligations | $ | 788 |  |  | $ | 283 |  |  | $ | 1,480 |  |

[0000804328-22-000021:notes:88]
(1) Primarily related to certain QCT sales-based royalty revenues related to system software, certain QCT customer incentives and, to a lesser extent, QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due).

[0000804328-22-000021:notes:89]
(2) Primarily related to certain QCT customer incentives, QTL revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due) and the release of a variable constraint against revenues not previously allocated to our segment results (Note 8).

[0000804328-22-000021:notes:90]
(3) Primarily related to licensing revenues recognized in the fourth quarter of fiscal 2020 (a portion of which was attributable to fiscal 2020) resulting from the settlement with Huawei and, to a lesser extent, QTL royalties recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due) and certain QCT customer incentives.

[0000804328-22-000021:notes:91]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In fiscal 2022 and fiscal 2021, we recognized revenues of $609 million and $557 million, respectively, that were recorded as unearned revenues at September 26, 2021 and September 27, 2020, respectively.

[0000804328-22-000021:notes:92]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront and certain customer contracts for which QCT received upfront fees for licensing system software. At September 25, 2022, we had $690 million of remaining performance obligations, of which $451 million, $173 million, $57 million, $5 million and $1 million is expected to be recognized as revenues for each of the subsequent five years from fiscal 2023 through 2027, respectively, and $3 million expected thereafter.

[0000804328-22-000021:notes:93]
Share-based Compensation Expense. Total share-based compensation expense, related to all of our share-based awards, was comprised as follows (in millions):

[0000804328-22-000021:notes:94]
|  |  |  |  |  | 2022 |  | 2021 |  | 2020 |
| Cost of revenues |  |  |  |  |  |  |  |  | $ | 61 |  |  | $ | 47 |  |  | $ | 34 |  |
| Research and development |  |  |  |  |  |  |  |  | 1,537 |  |  | 1,234 |  |  | 872 |  |
| Selling, general and administrative |  |  |  |  |  |  |  |  | 463 |  |  | 389 |  |  | 306 |  |
| Share-based compensation expense before income taxes |  |  |  |  |  |  |  |  | 2,061 |  |  | 1,670 |  |  | 1,212 |  |
| Related income tax benefit |  |  |  |  |  |  |  |  | (489) |  |  | (435) |  |  | (238) |  |
|  |  |  |  |  |  |  |  |  | $ | 1,572 |  |  | $ | 1,235 |  |  | $ | 974 |  |

[0000804328-22-000021:notes:95]
Other Income, Costs and Expenses. In the third quarter of fiscal 2022, the General Court of the European Union issued a ruling annulling a decision made by the EC in fiscal 2018 (Note 7). As a result of the court’s decision, we recorded a $1.1 billion benefit to other income in fiscal 2022. Other expenses in fiscal 2020 consisted of $28 million in gains related to a favorable legal settlement.

[0000804328-22-000021:notes:96]
| Investment and Other (Expense) Income, Net (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  | 2022 |  | 2021 |  | 2020 |
| Interest and dividend income |  |  |  |  |  |  |  | $ | 91 |  |  | $ | 83 |  |  | $ | 156 |  |
| Net (losses) gains on marketable securities |  |  |  |  |  |  |  | (363) |  |  | 427 |  |  | 198 |  |
| Net gains on other investments |  |  |  |  |  |  |  | 113 |  |  | 470 |  |  | 108 |  |
| Net (losses) gains on deferred compensation plan assets |  |  |  |  |  |  |  | (141) |  |  | 130 |  |  | 47 |  |
| Impairment losses on other investments |  |  |  |  |  |  |  | (47) |  |  | (33) |  |  | (405) |  |
| Net (losses) gains on derivative instruments |  |  |  |  |  |  |  | (37) |  |  | (14) |  |  | 8 |  |
| Equity in net (losses) earnings of investees |  |  |  |  |  |  |  | (7) |  |  | 13 |  |  | (21) |  |
| Net gains (losses) on foreign currency transactions |  |  |  |  |  |  |  | 19 |  |  | (32) |  |  | (25) |  |
|  |  |  |  |  |  |  |  | $ | (372) |  |  | $ | 1,044 |  |  | $ | 66 |  |

[0000804328-22-000021:notes:97]
In fiscal 2020, in part due to the impact of COVID-19, certain of our investments were impaired and written down to their estimated fair values (a significant portion of which related to the full impairment of our investment in OneWeb, who filed for bankruptcy in the second quarter of fiscal 2020).


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-22-000021:notes:98]
Income Taxes
The components of the income tax provision from continuing operations were as follows (in millions):

[0000804328-22-000021:notes:99]
|  | 2022 |  | 2021 |  | 2020 |
| Current provision: |  |  |  |  |  |
| Federal | $ | 1,114 |  |  | $ | 942 |  |  | $ | 210 |  |
| State | 1 |  |  | 8 |  |  | 1 |  |
| Foreign (1) | 906 |  |  | 518 |  |  | 526 |  |
|  | 2,021 |  |  | 1,468 |  |  | 737 |  |
| Deferred (benefit) provision: |  |  |  |  |  |
| Federal | (34) |  |  | (251) |  |  | (192) |  |
| State | 15 |  |  | 2 |  |  | 2 |  |
| Foreign (1) | 10 |  |  | 12 |  |  | (26) |  |
|  | (9) |  |  | (237) |  |  | (216) |  |
|  | $ | 2,012 |  |  | $ | 1,231 |  |  | $ | 521 |  |

[0000804328-22-000021:notes:100]
(1) The foreign component of the income tax provision included foreign withholding taxes on royalty revenues included in U.S. earnings.

[0000804328-22-000021:notes:101]
The components of income from continuing operations before income taxes by U.S. and foreign jurisdictions were as follows (in millions):

[0000804328-22-000021:notes:102]
|  | 2022 |  | 2021 |  | 2020 |
| United States | $ | 12,537 |  |  | $ | 8,781 |  |  | $ | 5,004 |  |
| Foreign | 2,461 |  |  | 1,493 |  |  | 715 |  |
|  | $ | 14,998 |  |  | $ | 10,274 |  |  | $ | 5,719 |  |

[0000804328-22-000021:notes:103]
The following is a reconciliation of the expected statutory federal income tax provision to our actual income tax provision from continuing operations (in millions, except percentages). Substantially all of our income from continuing operations is in the U.S., of which a significant portion qualifies for preferential treatment as FDII at a 13% effective tax rate.

[0000804328-22-000021:notes:104]
|  | 2022 |  | 2021 |  | 2020 |
| Expected income tax provision at federal statutory tax rate | $ | 3,150 |  |  | $ | 2,158 |  |  | $ | 1,201 |  |
| Benefit from FDII deduction | (753) |  |  | (550) |  |  | (381) |  |
| Excess tax benefit associated with share-based awards | (257) |  |  | (265) |  |  | (83) |  |
| Foreign currency losses (gains) related to Korean withholding tax receivable | 243 |  |  | 12 |  |  | (37) |  |
| Nontaxable reversal of 2018 EC fine | (224) |  |  | — |  |  | — |  |
| Benefit related to research and development tax credits | (224) |  |  | (195) |  |  | (125) |  |
| Other | 77 |  |  | 71 |  |  | (54) |  |
|  | $ | 2,012 |  |  | $ | 1,231 |  |  | $ | 521 |  |
| Effective tax rate | 13 | % |  | 12 | % |  | 9 | % |

[0000804328-22-000021:notes:105]
Beginning in fiscal 2019, as a result of certain court rulings in Korea, among other factors, we decided to apply for a partial refund claim for taxes previously withheld from licensees in Korea on payments due under their license agreements to which we have claimed a foreign tax credit in the United States. As a result, $1.7 billion and $1.9 billion was recorded as a noncurrent income taxes receivable (recorded in other assets) at September 25, 2022 and September 26, 2021, respectively, and $2.1 billion and $1.9 billion was recorded as a noncurrent liability for uncertain tax benefits (recorded in other liabilities) at September 25, 2022 and September 26, 2021, respectively.

[0000804328-22-000021:notes:106]
At September 25, 2022, we estimated remaining future payments of $1.7 billion for a one-time repatriation tax accrued in fiscal 2018, after application of certain tax credits, which is payable in installments over the next four years. At September 25, 2022, $207 million was recorded in other current liabilities, reflecting the next installment due in January 2023, with the remaining noncurrent portion presented as income taxes payable on our balance sheet.

[0000804328-22-000021:notes:107]
We continue to assert that certain of our foreign earnings are not indefinitely reinvested. At September 25, 2022, we had not recorded a deferred tax liability of approximately $70 million related to foreign withholding taxes on approximately $851 million of undistributed earnings of certain subsidiaries that we continue to consider to be indefinitely reinvested outside the

[0000804328-22-000021:notes:108]
United States. Should we decide to no longer indefinitely reinvest such earnings outside the U.S., we would have to adjust the income tax provision in the period we make such determination.

[0000804328-22-000021:notes:109]
We have tax incentives in Singapore that require we meet specified employment and other criteria. Although our profit in Singapore declined as a result of restructuring our operations in 2018, we were required to meet (and did meet) certain incentive requirements through March 2022. Failure to meet such requirements could have required us to refund previously realized material tax benefits for 2017 and 2018.

[0000804328-22-000021:notes:110]
We had deferred tax assets and deferred tax liabilities as follows (in millions):

[0000804328-22-000021:notes:111]
|  | September 25,2022 |  | September 26,2021 |
| Unused tax credits | $ | 1,624 |  |  | $ | 1,504 |  |
| Unused net operating losses | 887 |  |  | 663 |  |
| Customer incentives | 807 |  |  | 762 |  |
| Accrued liabilities and reserves | 264 |  |  | 483 |  |
| Share-based compensation | 225 |  |  | 175 |  |
| Operating lease liabilities | 202 |  |  | 188 |  |
| Unrealized losses on other investments and marketable securities | 197 |  |  | 106 |  |
| Unearned revenues | 100 |  |  | 181 |  |
| Other | 335 |  |  | 165 |  |
| Total gross deferred tax assets | 4,641 |  |  | 4,227 |  |
| Valuation allowance | (2,223) |  |  | (1,926) |  |
| Total net deferred tax assets | 2,418 |  |  | 2,301 |  |
| Intangible assets | (315) |  |  | (198) |  |
| Operating lease assets | (184) |  |  | (174) |  |
| Property, plant and equipment | (101) |  |  | (111) |  |
| Unrealized gains on other investments and marketable securities | (84) |  |  | (215) |  |
| Accrued withholding taxes | (62) |  |  | (42) |  |
| Other | (36) |  |  | (34) |  |
| Total deferred tax liabilities | (782) |  |  | (774) |  |
| Net deferred tax assets | $ | 1,636 |  |  | $ | 1,527 |  |
| Reported as: |  |  |  |
| Non-current deferred tax assets | $ | 1,803 |  |  | $ | 1,591 |  |
| Non-current deferred tax liabilities (1) | (167) |  |  | (64) |  |
|  | $ | 1,636 |  |  | $ | 1,527 |  |

[0000804328-22-000021:notes:112]
(1) Non-current deferred tax liabilities were included in other liabilities in the consolidated balance sheets.

[0000804328-22-000021:notes:113]
At September 25, 2022, we had unused federal net operating loss carryforwards of $808 million, of which $134 million expire from 2023 through 2037 and $674 million may be carried forward indefinitely, unused state net operating loss carryforwards of $896 million expiring from 2023 through 2037 and unused foreign net operating loss carryforwards of $2.6 billion, of which substantially all may be carried forward indefinitely. At September 25, 2022, we had unused state tax credits of $1.5 billion, of which substantially all may be carried forward indefinitely, unused federal tax credits of $135 million expiring from 2028 through 2041 and unused tax credits of $54 million in foreign jurisdictions expiring from 2034 through 2042. We do not expect our federal net operating loss carryforwards to expire unused.

[0000804328-22-000021:notes:114]
At September 25, 2022, we have provided a valuation allowance on certain state tax credits, foreign deferred tax assets, state net operating losses and federal tax credits of $1.5 billion, $673 million, $42 million and $4 million, respectively. The valuation allowance reflects the uncertainties surrounding our ability to generate sufficient future taxable income in certain tax jurisdictions to utilize our net operating losses. We believe, more likely than not, that we will have sufficient taxable income after deductions related to share-based awards to utilize our remaining deferred tax assets.

[0000804328-22-000021:notes:115]
A summary of the changes in the amount of unrecognized tax benefits for fiscal 2022, 2021 and 2020 follows (in millions):

[0000804328-22-000021:notes:116]
|  | 2022 |  | 2021 |  | 2020 |
| Beginning balance of unrecognized tax benefits | $ | 2,136 |  |  | $ | 1,901 |  |  | $ | 1,705 |  |
| Additions based on prior year tax positions | 58 |  |  | 56 |  |  | 20 |  |
| Reductions for prior year tax positions and lapse in statute of limitations | (136) |  |  | (13) |  |  | (2) |  |
| Additions for current year tax positions | 184 |  |  | 213 |  |  | 192 |  |
| Settlements with taxing authorities | (51) |  |  | (21) |  |  | (14) |  |
| Ending balance of unrecognized tax benefits | $ | 2,191 |  |  | $ | 2,136 |  |  | $ | 1,901 |  |

[0000804328-22-000021:notes:117]
Of the $2.2 billion of unrecognized tax benefits, $2.0 billion has been recorded to other liabilities. We believe that it is reasonably possible that certain unrecognized tax benefits recorded at September 25, 2022 may result in a cash payment in fiscal 2023. Unrecognized tax benefits at September 25, 2022 included $135 million for tax positions that, if recognized, would impact the effective tax rate. The unrecognized tax benefits differ from the amount that would affect our effective tax rate primarily because the unrecognized tax benefits were included on a gross basis and did not reflect related receivables or secondary impacts, such as the federal deduction for state taxes, adjustments to deferred tax assets and the valuation allowance that might be required if our tax positions are sustained. The increase in unrecognized tax benefits for all periods presented was primarily due to expected refunds of Korean withholding tax previously paid (which such increase had an insignificant impact to our income tax provision). If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We believe that it is likely that the total amount of unrecognized tax benefits at September 25, 2022 will increase in fiscal 2023 as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision. At September 25, 2022, total interest and penalties related to unrecognized tax benefits accrued in other current liabilities and other liabilities was $168 million, with a corresponding noncurrent income taxes receivable of $108 million recorded in other assets for expected refunds of certain tax benefits.

[0000804328-22-000021:notes:118]
We file income tax returns in the U.S. federal jurisdiction and various state and foreign jurisdictions. For tax years prior to fiscal 2021, we are a participant in the IRS Compliance Assurance Process (CAP) Program, whereby we and the IRS endeavor to agree on the treatment of all tax issues prior to the tax return being filed. We are no longer subject to U.S. federal income tax examinations for years prior to fiscal 2018. We are also subject to examination in other taxing jurisdictions in the U.S. and numerous foreign jurisdictions. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2001. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. At September 25, 2022, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0000804328-22-000021:notes:119]
Cash amounts paid for income taxes, net of refunds received, were $2.1 billion, $1.5 billion and $0.8 billion for fiscal 2022, 2021 and 2020, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-22-000021:notes:120]
Capital Stock
Stock Repurchase Program. On October 12, 2021, we announced a $10.0 billion stock repurchase program. The stock repurchase program has no expiration date. At September 25, 2022, $8.1 billion remained authorized for repurchase under our stock repurchase program.

[0000804328-22-000021:notes:121]
Shares Outstanding. Shares of common stock outstanding at September 25, 2022 were as follows (in millions):

[0000804328-22-000021:notes:122]
| Balance at beginning of period | 1,125 |  |
| Issued | 17 |  |
| Repurchased | (21) |  |
| Balance at end of period | 1,121 |

[0000804328-22-000021:notes:123]
Dividends. On October 14, 2022, we announced a cash dividend of $0.75 per share on our common stock, payable on December 15, 2022 to stockholders of record as of the close of business on December 1, 2022.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000804328-22-000021:notes:124]
Employee Benefit PlansEquity Compensation Plans. On March 10, 2020, our stockholders approved the amended and restated Qualcomm Incorporated 2016 Long-Term Incentive Plan (the 2016 Plan), including an increase in the share reserve by 75 million shares. The 2016 Plan provides for the grant of RSUs and other stock-based awards. The RSUs generally include dividend-equivalent rights and vest over three years from the date of grant. The Board of Directors may amend or terminate the 2016 
Plan at any time. Certain amendments, including an increase in the share reserve, require stockholder approval. At September 25, 2022, approximately 43 million shares were available for future grant under the 2016 Plan.

[0000804328-22-000021:notes:125]
The following is a summary of employee RSU transactions under our 2016 Plan that contain only service requirements to vest:

[0000804328-22-000021:notes:126]
|  | Number of Shares(in millions) |  | Weighted-AverageGrant Date Fair Value |  |  |
| RSUs outstanding at September 26, 2021 | 29 |  |  | $ | 102.83 |  |  |  |
| RSUs granted | 20 |  |  | 136.09 |  |  |  |
| RSUs canceled/forfeited | (2) |  |  | 120.94 |  |  |  |
| RSUs vested | (17) |  |  | 96.02 |  |  |  |
| RSUs outstanding at September 25, 2022 | 30 |  |  | 127.58 |  |  |  |

[0000804328-22-000021:notes:127]
The weighted-average estimated grant date fair values of employee RSUs under our 2016 Plan that contain only service requirements to vest granted during fiscal 2021 and 2020 were $124.22 and $82.57 per share, respectively. Upon vesting, we issue new shares of common stock. For the majority of RSUs, shares are issued on the vesting dates net of the amount of shares needed to satisfy statutory tax withholding requirements to be paid by us on behalf of the employees. As a result, the actual number of shares issued will be fewer than the number of RSUs outstanding. The annual pre-vest forfeiture rate for RSUs was estimated to be approximately 6%, 6% and 7% in fiscal 2022, 2021 and 2020, respectively.

[0000804328-22-000021:notes:128]
At September 25, 2022, total unrecognized compensation expense related to such non-vested RSUs granted prior to that date was $2.6 billion, which is expected to be recognized over a weighted-average period of 1.8 years. The total vest-date fair value of such RSUs that vested during fiscal 2022, 2021 and 2020 was $2.9 billion, $2.6 billion and $1.3 billion, respectively. The total shares withheld to satisfy statutory tax withholding requirements related to all share-based awards were 5 million, 5 million and 4 million in fiscal 2022, 2021 and 2020, respectively and were based on the value of the awards on their vesting dates as determined by our closing stock price.

[0000804328-22-000021:notes:129]
The total tax benefits realized, including the excess tax benefits, related to share-based awards during fiscal 2022, 2021 and 2020 were $627 million, $567 million and $273 million, respectively.

[0000804328-22-000021:notes:130]
Employee Stock Purchase Plan. We have an employee stock purchase plan for eligible employees to purchase shares of common stock at 85% of the lower of the fair market value on the first or the last day of each offering period, which is generally six months. Employees may authorize us to withhold up to 15% of their compensation during any offering period, subject to certain limitations. The employee stock purchase plan includes a non-423(b) plan. The shares reserved for future issuance under the employee stock purchase plan were 22 million at September 25, 2022. During fiscal 2022, 2021 and 2020, 3 million, 3 million and 5 million shares, respectively, were issued under the plan at an average price of $124.98, $107.48 and $66.53 per share, respectively. At September 25, 2022, total unrecognized compensation expense related to non-vested purchase rights granted prior to that date was $44 million. We recorded cash received from the exercise of purchase rights of $355 million, $343 million and $306 million during fiscal 2022, 2021 and 2020, respectively.


## us-gaap:DebtDisclosureTextBlock

[0000804328-22-000021:notes:131]
Debt
Long-term Debt. In May 2022, we issued unsecured fixed-rate notes, consisting of $500 million of fixed-rate 4.25% notes and $1.0 billion of fixed-rate 4.50% notes (May 2022 Notes) that mature on May 20, 2032 and May 20, 2052, respectively. The net proceeds from the May 2022 Notes, together with cash on hand, were used to repay $1.5 billion of fixed-rate notes that matured in May 2022.

[0000804328-22-000021:notes:132]
The following table provides a summary of our long-term debt and current portion of long-term debt:

[0000804328-22-000021:notes:133]
|  | September 25, 2022 |  | September 26, 2021 |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |  | 2022 - 2045 |  | $ | 5,405 |  |  | 2.63% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 5,860 |  |  | 2.68% - 4.46% |  | 2023 - 2047 |  | 5,860 |  |  | 0.92% - 4.46% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.97% - 3.30% |  | 2030 - 2050 |  | 2,000 |  |  | 2.31% - 3.30% |
| August 2020 Notes | 2028 - 2032 |  | 2,207 |  |  | 2.50% - 3.52% |  | 2028 - 2032 |  | 2,207 |  |  | 1.98% - 2.66% |
| May 2022 Notes | 2032 - 2052 |  | 1,500 |  |  | 3.13% - 4.26% |  |  |  | — |  |  |  |
| Total principal |  |  | 15,432 |  |  |  |  |  |  | 15,472 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (241) |  |  |  |  |  |  | (234) |  |  |  |
| Hedge accounting adjustments |  | (208) |  |  |  |  |  |  | 7 |  |  |  |
| Total long-term debt |  |  | $ | 14,983 |  |  |  |  |  |  | $ | 15,245 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 1,446 |  |  |  |  |  |  | $ | 1,544 |  |  |  |
| Long-term debt |  |  | 13,537 |  |  |  |  |  |  | 13,701 |  |  |  |
| Total |  |  | $ | 14,983 |  |  |  |  |  |  | $ | 15,245 |  |  |  |

[0000804328-22-000021:notes:134]
At September 25, 2022, future principal payments were $1.4 billion in fiscal 2023, $914 million in fiscal 2024, $1.4 billion in fiscal 2025, $2.0 billion in fiscal 2027 and $9.7 billion after fiscal 2027; no principal payments are due in fiscal 2026. At September 25, 2022, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $14.0 billion.

[0000804328-22-000021:notes:135]
At September 25, 2022, with the exception of $500 million of outstanding unsecured floating-rate notes due January 30, 2023, all of our outstanding long-term debt is comprised of unsecured fixed-rate notes. We may redeem the outstanding fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. We may not redeem the outstanding floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of our other senior unsecured indebtedness and will effectively rank junior to all liabilities of our subsidiaries.

[0000804328-22-000021:notes:136]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to our commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $491 million, $477 million and $507 million during fiscal 2022, 2021 and 2020, respectively.

[0000804328-22-000021:notes:137]
Interest Rate Swaps. At September 25, 2022 and September 26, 2021, we had outstanding forward-starting interest rate swaps with an aggregate notional amount of $1.6 billion and $2.6 billion, respectively. During the third quarter of fiscal 2022, we terminated $1 billion of swaps associated with our May 2022 Notes, and the related gains of $123 million are being reclassified from accumulated comprehensive income as a reduction to interest expense over the terms of the related debt.

[0000804328-22-000021:notes:138]
At September 25, 2022, we had outstanding interest rate swaps with an aggregate notional amount of $2.1 billion that are designated as fair value hedges and allow us to effectively convert fixed-rate payments into floating-rate payments on a portion of our outstanding long-term debt.

[0000804328-22-000021:notes:139]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion. Net proceeds from this program are for general corporate purposes. Maturities of commercial paper can range from 1 to up to 397 days. At September 25, 2022 and September 26, 2021, we had $499 million and $500 million, respectively, of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 2.69% and 0.13%, respectively, which included fees paid to the commercial paper dealers. At September 25, 2022 and September 26, 2021, the weighted-average remaining days to maturity were 27 days and 39 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at September 25, 2022.

[0000804328-22-000021:notes:140]
Revolving Credit Facility. We have a Revolving Credit Facility that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At September 25, 2022, no amounts were outstanding under the Revolving Credit Facility.
Debt Covenants. The Revolving Credit Facility requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. We are not subject to any financial covenants under the notes nor any covenants that would prohibit us from incurring additional indebtedness ranking equal to the notes, paying dividends or issuing securities or repurchasing securities issued by us or our subsidiaries. At September 25, 2022, we were in compliance with the applicable covenants under the Revolving Credit Facility.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-22-000021:notes:141]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0000804328-22-000021:notes:142]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions. On July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint, and on March 18, 2019, the court denied our motion. On January 15, 2020, we filed a motion for judgment on the pleadings, which the court denied on February 3, 2022. On May 23, 2022, the plaintiffs filed a motion for class certification, and a hearing on the motion was held on October 19, 2022. The court has not yet ruled on the motion. We believe the plaintiffs’ claims are without merit.

[0000804328-22-000021:notes:143]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On July 5, 2018, the plaintiffs filed a motion for class certification, and on September 27, 2018, the court granted that motion. We appealed the district court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit), and on September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class. The Ninth Circuit remanded the case to the district court and instructed the court to consider the effect of United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated (which the Ninth Circuit decided in favor of Qualcomm in August 2020) on this case. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class, and on August 1, 2022, we filed a motion to dismiss the amended complaint. A hearing on our motion is scheduled for November 15, 2022. We believe the plaintiffs’ claims are without merit.

[0000804328-22-000021:notes:144]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

[0000804328-22-000021:notes:145]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit. We believe ParkerVision’s claims are without merit.

[0000804328-22-000021:notes:146]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (ARM) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries, Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia), are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with ARM (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. The complaint seeks specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology. ARM also contends that we violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of ARM’s

[0000804328-22-000021:notes:147]
trademarks and seeks associated injunctive and declaratory relief. ARM further seeks exemplary or punitive damages, costs, expenses and reasonable attorney’s fees, and equitable relief addressing any infringement occurring after entry of judgment. We believe ARM’s claims are without merit.

[0000804328-22-000021:notes:148]
On September 30, 2022, we filed our Answer and Counterclaim in response to ARM’s complaint denying ARM’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and ARM and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia), server System-on-Chip (SoC) and compute SoC are fully licensed under our existing Architecture License Agreement and Technology License Agreement with ARM (the ARM-Qualcomm Agreements). We further seek an order enjoining ARM from making any claim that our products are not licensed under the ARM-Qualcomm Agreements, are not ARM-compliant or that we are prohibited from using ARM’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements ARM is making in the marketplace concerning our rights under the ARM-Qualcomm Agreements are false, and that ARM has no right to prevent us from shipping our products, which are validly licensed.

[0000804328-22-000021:notes:149]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0000804328-22-000021:notes:150]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019, and on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC. We believe that our business practices do not violate the MRFTA.

[0000804328-22-000021:notes:151]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of its investigation, but we believe it concerns our business practices in connection with our sale of RFFE components. We continue to cooperate with the KFTC as it conducts its investigation. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

[0000804328-22-000021:notes:152]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision finding that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

[0000804328-22-000021:notes:153]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding and included in other current liabilities.

[0000804328-22-000021:notes:154]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. From May 4, 2021 to May 6, 2021, a hearing on our appeal was held before the court. On June 15, 2022, the court issued a ruling annulling the EC’s decision in its entirety. The deadline for the EC to appeal the General Court’s decision to the European Court of Justice expired in August 2022. Consequently, the case is now over.

[0000804328-22-000021:notes:155]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appealed the EC’s decision. The fine accrued interest at a rate of 1.50% per annum while it was outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income (loss) as a component of the foreign currency translation adjustment. As a result of the General Court’s ruling, in the third quarter of fiscal 2022, we recorded a $1.1 billion benefit in other income and a $62 million reduction in interest expense resulting from the reversal of the accrued fine and the associated interest previously recorded.

[0000804328-22-000021:notes:156]
Contingent Losses and Other Considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. Other than with respect to the EC fine related to the Icera Complaint to the European Commission, we have not recorded any accrual at September 25, 2022 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0000804328-22-000021:notes:157]
Indemnifications. We generally do not indemnify our customers, licensees and suppliers for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain agreements to defend and/or indemnify certain customers, licensees and suppliers against certain types of liability and/or damages arising from the infringement of third-party intellectual property rights. Our obligations under these agreements may be limited in terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us. Claims and reimbursements under indemnification arrangements have not been material to our consolidated financial statements. We have not recorded accruals for certain claims under indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0000804328-22-000021:notes:158]
Purchase Obligations. We have agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Such agreements include multi-year capacity purchase commitments with certain suppliers of our integrated circuit products. Total advance payments related to multi-year capacity commitments recorded on the consolidated balance sheets at September 25, 2022 and September 26, 2021 were $3.8 billion and $1.7 billion, respectively, of which $701 million and $90 million were recorded in other current assets, respectively, and $3.1 billion and $1.6 billion were recorded in other assets, respectively. Integrated circuit product inventory obligations represent purchase commitments (including those under multi-year capacity purchase commitments to the extent such minimum amounts are both fixed and determinable) for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancellation of outstanding purchase commitments is generally allowed but may result in the payment of costs incurred through the date of cancellation, and in some cases, incremental fees and/or the loss of amounts paid in advance related to capacity underutilization and the failure to meet future minimum purchase volumes under multi-year capacity purchase commitments. Obligations under our purchase agreements, which primarily relate to integrated circuit product inventory obligations, at September 25, 2022 totaled $24.5 billion of which, $13.3 billion is expected to be paid in the next 12 months.

[0000804328-22-000021:notes:159]
Operating Leases. We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years. At September 25, 2022 and September 26, 2021, the weighted-average remaining lease term for operating leases were eight years and seven years, respectively. Operating lease expense for fiscal 2022, 2021 and 2020 was $207 million, $203 million and $181 million,

[0000804328-22-000021:notes:160]
respectively. At September 25, 2022, other assets included $631 million of operating lease assets, with corresponding lease liabilities of $104 million recorded in other current liabilities and $573 million recorded in other liabilities. At September 26, 2021, other assets included $513 million of operating lease assets, with corresponding lease liabilities of $126 million recorded in other current liabilities and $428 million recorded in other liabilities.

[0000804328-22-000021:notes:161]
At September 25, 2022, future lease payments under our operating leases were as follows (in millions):

[0000804328-22-000021:notes:162]
|  |  |  | September 25,2022 |
| 2023 |  |  | $ | 129 |  |
| 2024 |  |  | 114 |  |
| 2025 |  |  | 92 |  |
| 2026 |  |  | 87 |  |
| 2027 |  |  | 83 |  |
| Thereafter |  |  | 358 |  |
| Total future lease payments |  |  | 863 |  |
| Imputed interest |  |  | (186) |  |
| Total lease liability balance |  |  | $ | 677 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-22-000021:notes:163]
Segment Information
We are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarities and the level of centralized resource planning within our operating segments, such as the nature of products, the level of shared products, technology and other resources, production processes and customer base. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies, including RFFE, for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices; industrial devices; and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our cloud AI inference processing initiative.

[0000804328-22-000021:notes:164]
Our CODM allocates resources to and evaluates the performance of our segments based on revenues and earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense, certain net investment income, certain share-based compensation, gains and losses on our deferred compensation plan liabilities and related assets and certain research and development expenses, certain selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories and property, plant and equipment to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, asset impairment charges and awards, settlements and/or damages arising from legal or regulatory matters. Our CODM does not evaluate our operating segments using discrete asset information.

[0000804328-22-000021:notes:165]
The table below presents revenues and EBT for reportable segments (in millions):

[0000804328-22-000021:notes:166]
|  | 2022 |  | 2021 |  | 2020 |
| Revenues: |  |  |  |  |  |
| QCT | $ | 37,677 |  |  | $ | 27,019 |  |  | $ | 16,493 |  |
| QTL | 6,358 |  |  | 6,320 |  |  | 5,028 |  |
| QSI | 31 |  |  | 45 |  |  | 36 |  |
| Reconciling items | 134 |  |  | 182 |  |  | 1,974 |  |
| Total | $ | 44,200 |  |  | $ | 33,566 |  |  | $ | 23,531 |  |
| EBT: |  |  |  |  |  |
| QCT | $ | 12,837 |  |  | $ | 7,763 |  |  | $ | 2,763 |  |
| QTL | 4,628 |  |  | 4,627 |  |  | 3,442 |  |
| QSI | (279) |  |  | 916 |  |  | (11) |  |
| Reconciling items | (2,188) |  |  | (3,032) |  |  | (475) |  |
| Total | $ | 14,998 |  |  | $ | 10,274 |  |  | $ | 5,719 |  |

[0000804328-22-000021:notes:167]
The net book value of long-lived tangible assets located outside of the U.S. was $3.5 billion and $2.9 billion at September 25, 2022 and September 26, 2021, respectively. The net book value of long-lived tangible assets located in the U.S. was $2.3 billion and $2.2 billion at September 25, 2022 and September 26, 2021, respectively.

[0000804328-22-000021:notes:168]
We report revenues from external customers by country based on the location to which our products or services are delivered, which for QCT is generally the country in which our customers manufacture their products, and for licensing revenues, the invoiced addresses of our licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues could include revenues related to shipments of integrated circuits for a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States. Revenues by country were as follows (in millions):

[0000804328-22-000021:notes:169]
|  | 2022 |  | 2021 |  | 2020 |
| China (including Hong Kong) | $ | 28,119 |  |  | $ | 22,512 |  |  | $ | 14,001 |  |
| Vietnam | 6,063 |  |  | 3,114 |  |  | 2,212 |  |
| South Korea | 3,164 |  |  | 2,368 |  |  | 2,964 |  |
| United States | 1,482 |  |  | 1,406 |  |  | 1,129 |  |
| Other foreign | 5,372 |  |  | 4,166 |  |  | 3,225 |  |
|  | $ | 44,200 |  |  | $ | 33,566 |  |  | $ | 23,531 |  |

[0000804328-22-000021:notes:170]
Reconciling items for revenues and EBT in a previous table were as follows (in millions):

[0000804328-22-000021:notes:171]
|  |  |  |  | 2022 |  | 2021 |  | 2020 |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonreportable segments |  |  |  |  |  |  |  | $ | 134 |  |  | $ | 128 |  |  | $ | 133 |  |
| Unallocated revenues (Note 2) |  |  |  |  |  |  |  | — |  |  | 54 |  |  | 1,841 |  |
|  |  |  |  |  |  |  |  | $ | 134 |  |  | $ | 182 |  |  | $ | 1,974 |  |
| EBT: |  |  |  |  |  |  |  |  |  |  |  |  |
| Unallocated revenues (Note 2) |  |  |  |  |  |  |  | $ | — |  |  | $ | 54 |  |  | $ | 1,841 |  |
| Unallocated cost of revenues |  |  |  |  |  |  |  | (266) |  |  | (277) |  |  | (340) |  |
| Unallocated research and development expenses |  |  |  |  |  |  |  | (1,767) |  |  | (1,820) |  |  | (1,046) |  |
| Unallocated selling, general and administrative expenses |  |  |  |  |  |  |  | (609) |  |  | (538) |  |  | (401) |  |
| Unallocated other income (Note 2) |  |  |  |  |  |  |  | 1,059 |  |  | — |  |  | 28 |  |
| Unallocated interest expense |  |  |  |  |  |  |  | (490) |  |  | (559) |  |  | (599) |  |
| Unallocated investment and other (expense) income, net |  |  |  |  |  |  |  | (91) |  |  | 166 |  |  | 105 |  |
| Nonreportable segments |  |  |  |  |  |  |  | (24) |  |  | (58) |  |  | (63) |  |
|  |  |  |  |  |  |  |  | $ | (2,188) |  |  | $ | (3,032) |  |  | $ | (475) |  |

[0000804328-22-000021:notes:172]
Certain revenues were not allocated to our segments in our management reports because they were not considered in evaluating segment results. Unallocated revenues in fiscal 2021 were comprised of the release of a variable constraint against revenues not previously allocated to our segment results. Unallocated revenues in fiscal 2020 were comprised of licensing revenues from Huawei resulting from the settlement agreement signed in July 2020 and royalties for sales made in the March 2020 and June 2020 quarters under a new global patent license agreement signed in July 2020.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000804328-22-000021:notes:173]
Acquisitions 
Nuvia. On March 16, 2021, we completed the acquisition of Nuvia for $1.1 billion (net of $174 million cash acquired), substantially all of which was paid in cash. In connection with the acquisition, we assumed or replaced unvested Nuvia stock awards with Qualcomm stock awards with an estimated fair value of $258 million, which have post-acquisition requisite service periods of up to four years. At the time of the acquisition, Nuvia had certain in-process technologies and was comprised of a CPU (central processing unit) and technology design team with expertise in high performance processors, SoC and power management for compute-intensive devices and applications. Upon completion of development, Nuvia’s technologies are expected to be integrated into certain QCT products. We recorded $885 million of goodwill, which is not deductible for tax purposes and was allocated to our QCT segment for annual impairment testing purposes. Goodwill is primarily attributable to assembled workforce and certain revenue and cost synergies expected to arise after the acquisition. We also recorded a $247 million in-process research and development intangible asset related to a single project, which is expected to be completed in fiscal 2023 and, upon completion, will be amortized over its useful life, which is expected to be seven years. Our results of operations for fiscal 2021 included the operating results of Nuvia since the acquisition date, the amounts of which were not material.

[0000804328-22-000021:notes:174]
Veoneer. On October 4, 2021, we and SSW Partners, a New York-based investment partnership, entered into a definitive agreement to acquire Veoneer, Inc. (Veoneer). The transaction closed on April 1, 2022 (the Closing Date). Total cash consideration paid in the transaction was $4.7 billion, consisting of (i) $4.6 billion paid in respect of Veoneer’s outstanding capital stock and equity awards and amounts paid to settle Veoneer’s convertible senior notes (which were converted at the election of the note holders and settled in cash in the third quarter of fiscal 2022) and (ii) a $110 million termination fee paid to Magna International Inc. (Magna) in the first quarter of fiscal 2022. We funded substantially all of the cash consideration payable in the transaction in exchange for (i) the Arriver business (which SSW transferred to us shortly after the Closing Date) and (ii) the right to receive a majority of the proceeds upon the sale of the Non-Arriver businesses by SSW Partners. We intend to incorporate Arriver’s computer vision, drive policy and driver assistance technologies into our Snapdragon automotive platform to deliver an integrated software SoC ADAS platform for automakers and Tier-1 automotive suppliers. SSW Partners retained Veoneer’s Tier-1 automotive supplier businesses, primarily consisting of the Active Safety and Restraint Control Systems businesses (the Non-Arriver businesses), which it intends to sell in one or more transactions.

[0000804328-22-000021:notes:175]
We have agreed to provide certain funding of approximately $300 million to the Non-Arriver businesses while SSW Partners seeks a buyer(s), of which approximately $150 million of funding remained available to the Non-Arriver businesses at September 25, 2022. Such amounts, along with cash retained in the Non-Arriver business, are expected to be used to fund working and other near-term capital needs, as well as certain costs incurred in connection with the close of the acquisition.

[0000804328-22-000021:notes:176]
Although we do not own or operate the Non-Arriver businesses, we have determined that we are the primary beneficiary, within the meaning of the Financial Accounting Standards Board (FASB) accounting guidance related to consolidation (ASC 810), of these businesses under the variable interest model. Factors considered in reaching this conclusion included, among others: (i) our involvement in the design of and our funding of substantially all of the total cash consideration payable in the

[0000804328-22-000021:notes:177]
transaction and (ii) our obligations to absorb losses and rights to receive returns from the Non-Arriver businesses. We expect that SSW Partners will complete the sale of the Non-Arriver businesses within fiscal 2023, subject to any required regulatory approvals and other closing conditions being met. Accordingly, the assets and liabilities of the Non-Arriver businesses are consolidated and presented as held for sale on our balance sheet, and the operating results are presented as discontinued operations.

[0000804328-22-000021:notes:178]
Our accounting purchase price was approximately $4.3 billion, substantially all of which relates to our share of cash consideration at close for the outstanding common shares of Veoneer and the Magna termination fee and excludes Veoneer’s convertible senior notes that are reflected as an assumed liability. We have finalized the purchase price allocation, except for certain tax matters. Accordingly, the preliminary purchase price allocation shown below could change during the remainder of the measurement period (which will not exceed 12 months from the Closing Date). The preliminary allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0000804328-22-000021:notes:179]
| Cash | $ | 30 |  |
| Current held for sale assets, net of costs to sell (1) | 626 |  |
| Completed technology-based intangible assets | 349 |  |
| In-process research and development (IPR&D) | 298 |  |
| Goodwill | 2,789 |  |
| Noncurrent held for sale assets (1) | 1,186 |  |
| Other assets | 333 |  |
| Total assets | 5,611 |  |
| Current held for sale liabilities (1) | (677) |  |
| Convertible senior notes | (352) |  |
| Noncurrent held for sale liabilities (1) | (128) |  |
| Other liabilities | (203) |  |
| Total liabilities | (1,360) |  |
| Net assets acquired | $ | 4,251 |  |

[0000804328-22-000021:notes:180]
(1) Held for sale assets and liabilities relate to the Non-Arriver businesses and were measured at fair value less costs to sell (including SSW Partners’ estimated return with respect to the sale proceeds of the Non-Arriver businesses), which was estimated using a market approach based on significant inputs that were not observable. In the fourth quarter of fiscal 2022, we finalized and adjusted the valuation of the Non-Arriver businesses by $229 million and recorded an offsetting adjustment to decrease goodwill for this amount. The Non-Arriver businesses’ assets are not available to be used to settle our obligations, and the Non-Arriver businesses’ creditors do not have recourse to us. SSW Partners owns and operates the Non-Arriver businesses, and its funding of the purchase price for Veoneer was recorded as a component of held for sale liabilities. The underlying classes of assets and liabilities held for sale have not been presented because such amounts are not material.

[0000804328-22-000021:notes:181]
Goodwill related to this transaction was allocated to our QCT segment, and $471 million of which is expected to be deductible for tax purposes. Goodwill is primarily attributable to assembled workforce and certain synergies expected to arise after the acquisition. Completed technology-based intangible assets are being amortized on a straight-line basis over the weighted-average useful life of nine years. IPR&D relates to a single project that is expected to be completed in fiscal 2025. Upon completion, we expect the IPR&D to be amortized over its useful life of seven years. We valued the completed technology and IPR&D using an income approach based on significant unobservable inputs.

[0000804328-22-000021:notes:182]
Since the Closing Date, the operating results of the Arriver and Non-Arriver businesses were initially reported on a one quarter lag. During the fourth quarter of fiscal 2022, we eliminated the one-quarter reporting lag previously used to consolidate the Arriver business to provide contemporaneous reporting within our consolidated financial statements, which we believe is preferable. The effect of this change was not material to our consolidated financial statements, and the impact of eliminating the one quarter reporting lag has been included in our operating results in the fourth quarter of fiscal 2022. The Non-Arriver businesses are presented as discontinued operations and remain on a one quarter reporting lag. Pro forma results of operations have not been presented because the effects of this acquisition were not material to our consolidated results of operations. The cash flows generated from (used by) the Non-Arriver businesses are reflected as discontinued operations and are classified as operating, investing and financing activities in the consolidated statements of cash flows. Investing and financing activities from discontinued operations reported in fiscal 2022 were not material.

[0000804328-22-000021:notes:183]
Other. During fiscal 2022, we acquired eight other businesses for a total accounting purchase price of $792 million. We recognized $202 million of intangible assets (which primarily relate to completed technology) that will be amortized on a straight-line basis over a weighted-average useful life of six years. Substantially all of the goodwill recognized in these transactions of $598 million was allocated to our QCT segment.


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-22-000021:notes:184]
Fair Value Measurements
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at September 25, 2022 (in millions):

[0000804328-22-000021:notes:185]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 922 |  |  | $ | 198 |  |  | $ | — |  |  | $ | 1,120 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 3,330 |  |  | — |  |  | 3,330 |  |
| Equity securities | 164 |  |  | — |  |  | — |  |  | 164 |  |
| Mortgage- and asset-backed securities | — |  |  | 99 |  |  | — |  |  | 99 |  |
| U.S. Treasury securities and government-related securities | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total marketable securities | 164 |  |  | 3,445 |  |  | — |  |  | 3,609 |  |
| Derivative instruments | — |  |  | 271 |  |  | — |  |  | 271 |  |
| Other investments | 613 |  |  | — |  |  | 15 |  |  | 628 |  |
| Total assets measured at fair value | $ | 1,699 |  |  | $ | 3,914 |  |  | $ | 15 |  |  | $ | 5,628 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 346 |  |  | $ | — |  |  | $ | 346 |  |
| Other liabilities | 612 |  |  | — |  |  | — |  |  | 612 |  |
| Total liabilities measured at fair value | $ | 612 |  |  | $ | 346 |  |  | $ | — |  |  | $ | 958 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000804328-22-000021:notes:186]
Marketable Securities
Our marketable securities were all classified as current and were comprised as follows (in millions):

[0000804328-22-000021:notes:187]
|  | September 25,2022 |  | September 26,2021 |  |  |  |  |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 3,330 |  |  | $ | 4,459 |  |  |  |  |  |
| Mortgage- and asset-backed securities | 99 |  |  | 147 |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 16 |  |  | 10 |  |  |  |  |  |
| Total available-for-sale debt securities | 3,445 |  |  | 4,616 |  |  |  |  |  |
| Equity securities | 164 |  |  | 682 |  |  |  |  |  |
| Total marketable securities | $ | 3,609 |  |  | $ | 5,298 |  |  |  |  |  |

[0000804328-22-000021:notes:188]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0000804328-22-000021:notes:189]
|  | September 25,2022 |
| Years to Maturity: |  |
| Less than one year | $ | 994 |  |
| One to five years | 2,352 |  |
| No single maturity date | 99 |  |
| Total | $ | 3,445 |  |

[0000804328-22-000021:notes:190]
Debt securities with no single maturity date included mortgage- and asset-backed securities.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000804328-22-000021:notes:191]
SCHEDULE II

[0000804328-22-000021:notes:192]
QUALCOMM Incorporated

[0000804328-22-000021:notes:193]
VALUATION AND QUALIFYING ACCOUNTS

[0000804328-22-000021:notes:194]
The table below details the activity of the valuation allowance on deferred tax assets for fiscal 2022, 2021 and 2020 (in millions):

[0000804328-22-000021:notes:195]
|  | Balance atBeginning ofPeriod |  | Charged toCosts andExpenses |  |  |  | Other |  | Balance atEnd ofPeriod |
| Year ended September 25, 2022 | $ | 1,926 |  |  | $ | 278 |  |  |  |  | $ | 19 |  |  | $ | 2,223 |  |
| Year ended September 26, 2021 | 1,728 |  |  | 197 |  |  |  |  | 1 |  |  | 1,926 |  |
| Year ended September 27, 2020 | 1,672 |  |  | 60 |  |  |  |  | (4) |  |  | 1,728 |  |
