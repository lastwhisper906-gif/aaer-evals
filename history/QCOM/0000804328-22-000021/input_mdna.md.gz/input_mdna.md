# QCOM MD&A — 0000804328-22-000021


## mdna

[0000804328-22-000021:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000804328-22-000021:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes included in “Part II, Item 8. Financial Statements and Supplementary Data” of this Annual Report.

[0000804328-22-000021:mdna:3]
The following section generally discusses fiscal 2022 and 2021 items and year-to-year comparisons between fiscal 2022 and 2021. Discussions of fiscal 2020 items and year-to-year comparisons between fiscal 2021 and 2020 that are not included in this Annual Report can be found in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended September 26, 2021.

[0000804328-22-000021:mdna:4]
Our Business and Operating Segments

[0000804328-22-000021:mdna:5]
We develop and commercialize foundational technologies and products used in mobile devices and other wireless products. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents and other rights.

[0000804328-22-000021:mdna:6]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our cloud AI inference processing initiative.

[0000804328-22-000021:mdna:7]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering and research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0000804328-22-000021:mdna:8]
Further information regarding our business and operating segments is provided in “Part I, Item 1. Business” of this Annual Report.

[0000804328-22-000021:mdna:9]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when licensees’ sales occur. These trends may or may not continue in the future. Further, the trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings.

[0000804328-22-000021:mdna:10]
Fiscal 2022 Overview and Other Recent Events

[0000804328-22-000021:mdna:11]
Revenues were $44.2 billion, an increase of 32% compared to revenues of $33.6 billion in fiscal 2021, with net income of $12.9 billion, an increase of 43% compared to net income of $9.0 billion in fiscal 2021. Highlights from fiscal 2022 and other recent events included:

[0000804328-22-000021:mdna:12]
•QCT revenues increased by 39% in fiscal 2022 compared to the prior year, primarily due to an increase in average selling prices and favorable mix toward higher-tier 5G products along with higher integrated circuit shipments in handsets, as well as higher IoT revenues.

[0000804328-22-000021:mdna:13]
•On June 15, 2022, the General Court of the European Union issued a ruling annulling in its entirety the European Commission’s (EC) 2018 decision, which previously imposed a fine of 997 million euros for which we had provided financial guarantees to satisfy the obligation in lieu of cash payment. As a result, in the third quarter of fiscal 2022, we recorded a $1.1 billion benefit in other income and a $62 million reduction in interest expense resulting from the reversal of the accrued fine and the associated interest previously recorded. See “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies.”

[0000804328-22-000021:mdna:14]
•On October 4, 2021, we and SSW Partners entered into a definitive agreement to acquire Veoneer, Inc. (Veoneer). The transaction closed on April 1, 2022. We funded substantially all of the total cash consideration paid in the transaction, which was approximately $4.7 billion. The operating results of the Non-Arriver businesses are reported as discontinued operations on a one quarter lag. Additional information related to this acquisition is included in this Annual Report in “Notes to Consolidated Financial Statements, Note 9. Acquisitions.”

[0000804328-22-000021:mdna:15]
Results of Operations

[0000804328-22-000021:mdna:16]
| Revenues (in millions) |  |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  | Change |  |  |
| Equipment and services | $ | 37,171 |  |  | $ | 26,741 |  |  |  |  | $ | 10,430 |  |  |  |
| Licensing | 7,029 |  |  | 6,825 |  |  |  |  | 204 |  |  |  |
|  | $ | 44,200 |  |  | $ | 33,566 |  |  |  |  | $ | 10,634 |  |  |  |

[0000804328-22-000021:mdna:17]
2022 vs. 2021

[0000804328-22-000021:mdna:18]
The increase in revenues in fiscal 2022 was primarily due to $10.4 billion in higher equipment and services revenues and $216 million in higher licensing revenues from our QCT segment.

[0000804328-22-000021:mdna:19]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  | Change |  |  |
| Cost of revenues | $ | 18,635 |  |  | $ | 14,262 |  |  |  |  | $ | 4,373 |  |  |  |
| Gross margin | 58 | % |  | 58 | % |  |  |  |  |  |  |

[0000804328-22-000021:mdna:20]
2022 vs. 2021

[0000804328-22-000021:mdna:21]
Gross margin percentage remained flat in fiscal 2022 primarily due to:

[0000804328-22-000021:mdna:22]
+    increase in QCT gross margin

[0000804328-22-000021:mdna:23]
-    decrease in higher margin QTL licensing revenues in proportion to QCT revenues

[0000804328-22-000021:mdna:24]
|  | 2022 |  | 2021 |  |  |  | Change |  |  |
| Research and development | $ | 8,194 |  |  | $ | 7,176 |  |  |  |  | $ | 1,018 |  |  |  |
| % of revenues | 19 | % |  | 21 | % |  |  |  |  |  |  |

[0000804328-22-000021:mdna:25]
2022 vs. 2021

[0000804328-22-000021:mdna:26]
The increase in research and development expenses in fiscal 2022 was due to:

[0000804328-22-000021:mdna:27]
+    $856 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), primarily driven by an increase in employee-related expenses

[0000804328-22-000021:mdna:28]
+    $303 million increase in share-based compensation expense

[0000804328-22-000021:mdna:29]
-    $141 million decrease in expenses driven by revaluation of our deferred compensation obligation on lower relative stock market performance (which resulted in a corresponding increase in net losses on deferred compensation plan assets within investment and other (expense) income, net due to the revaluation of the related assets)

[0000804328-22-000021:mdna:30]
|  | 2022 |  | 2021 |  |  |  | Change |  |  |
| Selling, general and administrative | $ | 2,570 |  |  | $ | 2,339 |  |  |  |  | $ | 231 |  |  |  |
| % of revenues | 6 | % |  | 7 | % |  |  |  |  |  |  |

[0000804328-22-000021:mdna:31]
2022 vs. 2021

[0000804328-22-000021:mdna:32]
The increase in selling, general and administrative expenses in fiscal 2022 was primarily due to:

[0000804328-22-000021:mdna:33]
+    $110 million increase in acquisition-related expenses, primarily related to the Veoneer transaction

[0000804328-22-000021:mdna:34]
+    $94 million increase in employee-related expenses

[0000804328-22-000021:mdna:35]
+    $74 million increase in share-based compensation expense

[0000804328-22-000021:mdna:36]
+    $33 million increase in litigation costs

[0000804328-22-000021:mdna:37]
+    $32 million increase in sales and marketing expenses

[0000804328-22-000021:mdna:38]
-    $127 million decrease in expenses driven by revaluation of our deferred compensation obligation on lower relative stock market performance

[0000804328-22-000021:mdna:39]
|  | 2022 |  | 2021 |  |  |  | Change |  |  |
| Other (income) expense | $ | (1,059) |  |  | $ | — |  |  |  |  | $ | (1,059) |  |  |  |

[0000804328-22-000021:mdna:40]
2022

[0000804328-22-000021:mdna:41]
Other income in fiscal 2022 consisted of a $1.1 billion benefit resulting from the 2018 EC fine reversal.

[0000804328-22-000021:mdna:42]
| Interest Expense and Investment and Other (Expense) Income, Net (in millions) |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  | Change |  |  |
| Interest expense | $ | 490 |  |  | $ | 559 |  |  |  |  | $ | (69) |  |  |  |
| Investment and other (expense) income, net |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 91 |  |  | $ | 83 |  |  |  |  | $ | 8 |  |  |  |
| Net (losses) gains on marketable securities | (363) |  |  | 427 |  |  |  |  | (790) |  |  |  |
| Net gains on other investments | 113 |  |  | 470 |  |  |  |  | (357) |  |  |  |
| Net (losses) gains on deferred compensation plan assets | (141) |  |  | 130 |  |  |  |  | (271) |  |  |  |
| Impairment losses on other investments | (47) |  |  | (33) |  |  |  |  | (14) |  |  |  |
| Net losses on derivative instruments | (37) |  |  | (14) |  |  |  |  | (23) |  |  |  |
| Equity in net (losses) earnings of investees | (7) |  |  | 13 |  |  |  |  | (20) |  |  |  |
| Net gains (losses) on foreign currency transactions | 19 |  |  | (32) |  |  |  |  | 51 |  |  |  |
|  | $ | (372) |  |  | $ | 1,044 |  |  |  |  | $ | (1,416) |  |  |  |

[0000804328-22-000021:mdna:43]
The decrease in interest expense in fiscal 2022 was primarily driven by a $62 million reversal of accrued interest recorded in the third quarter of fiscal 2022 related to the annulled 2018 EC fine.

[0000804328-22-000021:mdna:44]
Net losses on marketable securities in fiscal 2022 was primarily driven by the change in fair value of certain of our QSI marketable equity investments in early or growth stage companies. Net gains on marketable securities in fiscal 2021 was primarily driven by the initial public offerings of certain QSI equity investments. Net gains on other investments in fiscal 2021 was primarily driven by realized gains resulting from the sale of certain of our QSI non-marketable investments.

[0000804328-22-000021:mdna:45]
Income Tax Expense (in millions, except percentages)

[0000804328-22-000021:mdna:46]
The following table summarizes the primary factors that caused our annual tax provision from continuing operations to differ from the expected income tax provision at the U.S. federal statutory rate. Substantially all of our income is taxed in the U.S., of which a significant portion qualifies for preferential treatment as FDII (foreign-derived intangible income) at a 13% effective tax rate.

[0000804328-22-000021:mdna:47]
|  | 2022 |  | 2021 |  |  |
| Expected income tax provision at federal statutory tax rate | $ | 3,150 |  |  | $ | 2,158 |  |  |  |
| Benefit from FDII deduction | (753) |  |  | (550) |  |  |  |
| Excess tax benefit associated with share-based awards | (257) |  |  | (265) |  |  |  |
| Foreign currency losses related to foreign withholding tax receivable | 243 |  |  | 12 |  |  |  |
| Nontaxable reversal of 2018 EC fine | (224) |  |  | — |  |  |  |
| Benefit related to the research and development tax credit | (224) |  |  | (195) |  |  |  |
| Other | 77 |  |  | 71 |  |  |  |
| Income tax expense | $ | 2,012 |  |  | $ | 1,231 |  |  |  |
| Effective tax rate | 13 | % |  | 12 | % |  |  |

[0000804328-22-000021:mdna:48]
Unrecognized tax benefits were $2.2 billion and $2.1 billion at September 25, 2022 and September 26, 2021, respectively. The increase in unrecognized tax benefits in fiscal 2022 was primarily due to expected refunds of Korean withholding taxes previously paid as licensees in Korea continue to withhold taxes on payments due under their licensing agreements at a rate higher than we believe is owed (which had an insignificant impact to our income tax provision). If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We are subject to income taxes in the U.S. and numerous foreign jurisdictions and are currently under examination by various tax authorities worldwide, primarily related to transfer pricing. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts giving rise to a revision become known. At September 25, 2022, we believe our reserves are adequate based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0000804328-22-000021:mdna:49]
Beginning in fiscal 2023, for federal income tax purposes, we are required to capitalize and amortize domestic research and development expenditures over five years and foreign research and development expenditures over fifteen years. Prior to such date, such expenditures are deducted as incurred. If this requirement is not delayed or repealed, our cash flow generated from operations will be adversely affected due to significantly higher cash tax payments. However, since the resulting deferred tax asset will be established at the statutory rate of 21% (rather than the effective rate of 13% to 16% after considering the FDII deduction), capitalization will favorably affect our provision for income taxes and results of operations. The adverse cash flow impact and favorable tax provision impact will diminish in future years as capitalized research and development expenditures amortize.

[0000804328-22-000021:mdna:50]
In August 2022, the Inflation Reduction Act (IRA) was enacted in the United States, which included, among other items, a 15% book minimum tax on adjusted financial statement earnings beginning in fiscal 2024. We do not expect this provision to have a material impact on our provision for income taxes, results of operations or cash flows. If the requirement to capitalize and amortize research and development expenditures beginning in fiscal 2023 is delayed or repealed, our cash flows may be impacted in future years under the IRA.

[0000804328-22-000021:mdna:51]
Discontinued Operations (in millions)

[0000804328-22-000021:mdna:52]
|  | 2022 |  | 2021 |  |  |  | Change |  |  |
| Discontinued operations, net of income taxes | $ | (50) |  |  | $ | — |  |  |  |  | $ | (50) |  |  |  |

[0000804328-22-000021:mdna:53]
Discontinued operations in fiscal 2022 related to net losses from the Non-Arriver businesses. Information regarding the Non-Arriver businesses is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 9. Acquisitions.”

[0000804328-22-000021:mdna:54]
Segment Results

[0000804328-22-000021:mdna:55]
The following should be read in conjunction with the fiscal 2022 and 2021 results of operations for each reportable segment included in this Annual Report in “Notes to Consolidated Financial Statements, Note 8. Segment Information.”

[0000804328-22-000021:mdna:56]
QCT Segment (in millions, except percentages)

[0000804328-22-000021:mdna:57]
|  | 2022 |  | 2021 |  |  |  | Change |  |  |
| Revenues |  |  |  |  |  |  |  |  |  |
| Handsets (1) | $ | 25,027 |  |  | $ | 16,830 |  |  |  |  | $ | 8,197 |  |  |  |
| RFFE (2) | 4,330 |  |  | 4,158 |  |  |  |  | 172 |  |  |  |
| Automotive (3) | 1,372 |  |  | 975 |  |  |  |  | 397 |  |  |  |
| IoT (internet of things) (4) | 6,948 |  |  | 5,056 |  |  |  |  | 1,892 |  |  |  |
| Total revenues | $ | 37,677 |  |  | $ | 27,019 |  |  |  |  | $ | 10,658 |  |  |  |
| EBT (5) | $ | 12,837 |  |  | $ | 7,763 |  |  |  |  | $ | 5,074 |  |  |  |
| EBT as a % of revenues | 34 | % |  | 29 | % |  |  |  | 5 points |  |  |

[0000804328-22-000021:mdna:58]
(1) Includes revenues from products sold for use in mobile handsets, excluding RFFE (radio frequency front-end) components.

[0000804328-22-000021:mdna:59]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in mobile handsets) and excludes radio frequency transceiver components.

[0000804328-22-000021:mdna:60]
(3) Includes revenues from products sold for use in automobiles, including connectivity, digital cockpit and advanced driver assistance and automated driving.

[0000804328-22-000021:mdna:61]
(4) Primarily includes products sold for use in the following industries and applications: consumer (including computing, voice and music and XR), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, transportation and logistics and utilities).

[0000804328-22-000021:mdna:62]
(5) Earnings (loss) before income taxes.

[0000804328-22-000021:mdna:63]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $37.0 billion and $26.6 billion in fiscal 2022 and 2021, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets.

[0000804328-22-000021:mdna:64]
2022 vs. 2021

[0000804328-22-000021:mdna:65]
The increase in QCT revenues in fiscal 2022 was primarily due to:

[0000804328-22-000021:mdna:66]
+    higher handset revenues, primarily driven by $6.6 billion in higher revenues per integrated circuit from increases in average selling prices and favorable mix toward higher-tier 5G products and $1.3 billion in higher integrated circuit shipments to major OEMs

[0000804328-22-000021:mdna:67]
+    higher RFFE revenues, driven by an increase in demand for 4G/5G products from major OEMs

[0000804328-22-000021:mdna:68]
+    higher automotive revenues, primarily driven by an increase in demand for digital cockpit products

[0000804328-22-000021:mdna:69]
+    higher IoT revenues across consumer, edge networking and industrial products, driven by a $951 million increase in demand, with the remaining increase of $941 million primarily due to favorable mix and higher average selling prices

[0000804328-22-000021:mdna:70]
QCT EBT as a percentage of revenues increased in fiscal 2022 due to:

[0000804328-22-000021:mdna:71]
+    higher revenues

[0000804328-22-000021:mdna:72]
+    higher gross margin percentage, primarily driven by higher average selling price and favorable mix towards higher-tier 5G products, partially offset by higher product costs

[0000804328-22-000021:mdna:73]
-    higher operating expenses, primarily driven by higher research and development expenses

[0000804328-22-000021:mdna:74]
QTL Segment (in millions, except percentages)

[0000804328-22-000021:mdna:75]
|  | 2022 |  | 2021 |  |  |  | Change |  |  |
| Licensing revenues | $ | 6,358 |  |  | $ | 6,320 |  |  |  |  | $ | 38 |  |  |  |
| EBT | 4,628 |  |  | 4,627 |  |  |  |  | 1 |  |  |  |
| EBT as a % of revenues | 73 | % |  | 73 | % |  |  |  | — |  |  |

[0000804328-22-000021:mdna:76]
2022 vs. 2021

[0000804328-22-000021:mdna:77]
The increase in QTL licensing revenues in fiscal 2022 was primarily due to:

[0000804328-22-000021:mdna:78]
+    $308 million increase in estimated revenues per unit, which was primarily driven by favorable mix, including 5G

[0000804328-22-000021:mdna:79]
-    $299 million decrease in estimated sales of 3G/4G/5G-based multimode products

[0000804328-22-000021:mdna:80]
QTL EBT as a percentage of revenues remained flat in fiscal 2022.

[0000804328-22-000021:mdna:81]
QSI Segment (in millions)

[0000804328-22-000021:mdna:82]
|  | 2022 |  | 2021 |  |  |  | Change |  |  |
| Equipment and services revenues | $ | 31 |  |  | $ | 45 |  |  |  |  | $ | (14) |  |  |  |
| EBT | (279) |  |  | 916 |  |  |  |  | (1,195) |  |  |  |

[0000804328-22-000021:mdna:83]
2022 vs. 2021

[0000804328-22-000021:mdna:84]
The decrease in QSI EBT in fiscal 2022 was primarily due to a $1.1 billion decrease resulting from net losses on investments in fiscal 2022 compared to net gains on investments in fiscal 2021, which were primarily driven by the change in fair value of certain of our marketable equity investments in early or growth stage companies and lower realized gains resulting from the sale of certain of our non-marketable investments.

[0000804328-22-000021:mdna:85]
Looking Forward

[0000804328-22-000021:mdna:86]
In the coming years, we expect consumer demand for 3G/4G/5G multimode and 5G products and services to continue to ramp around the world as we continue to transition from 3G/4G multimode and 4G products and services. We believe that 5G combined with high-performance, low-power processing and on-device intelligence will continue to drive adoption of certain technologies that are already commonly used in smartphones by industries and applications beyond mobile handsets, such as automotive and IoT. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing, and a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long term.

[0000804328-22-000021:mdna:87]
As we look forward to the next several quarters:

[0000804328-22-000021:mdna:88]
•We expect continued weakness in the macroeconomic environment (which will continue to negatively impact consumer demand for smartphones and other devices that incorporate our products and technologies) and our customers to draw down on their inventory (which is at elevated levels given the rapid deceleration in consumer demand and the easing of supply constraints, and which may take the next couple quarters to resolve), and that both of these dynamics will have a negative impact on our revenues, results of operations and cash flows compared to the prior year.

[0000804328-22-000021:mdna:89]
•While capacity constraints have largely abated, we expect to continue to see price increases from certain of our key semiconductor wafer suppliers.

[0000804328-22-000021:mdna:90]
•We expect commercial 5G network deployments and device launches will continue.

[0000804328-22-000021:mdna:91]
•We expect continued intense competition, particularly in China.

[0000804328-22-000021:mdna:92]
•Current U.S./China trade relations and/or national security protection policies may negatively impact our business, growth prospects and results of operations. See “Risk Factors” in this Annual Report, including the Risk Factor titled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0000804328-22-000021:mdna:93]
The degree to which the COVID-19 pandemic impacts our business, financial condition and results of operations will depend on future developments, which are highly uncertain. See “Risk Factors” in this Annual Report, specifically the Risk Factor titled “The COVID-19 pandemic, or a similar health crisis, may impact our business or results of operations in the future.”

[0000804328-22-000021:mdna:94]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless industry and governments as to the benefits of our licensing programs and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may be dissatisfied with the need to pay reasonable royalties for the use of our technologies and not welcome the success of our licensing programs in enabling new, highly cost-effective competitors to their products. Accordingly, such companies, and/or governments or regulators, may continue to challenge our business model in various forums throughout the world.

[0000804328-22-000021:mdna:95]
Further discussion of risks related to our business is provided in “Part I, Item 1A. Risk Factors” included in this Annual Report.

[0000804328-22-000021:mdna:96]
Liquidity and Capital Resources

[0000804328-22-000021:mdna:97]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following table presents selected financial information related to our liquidity as of and for the years ended September 25, 2022 and September 26, 2021 (in millions):

[0000804328-22-000021:mdna:98]
|  | September 25,2022 |  | September 26,2021 |  | Change |  |  |
| Cash and cash equivalents (1) | $ | 2,773 |  |  | $ | 7,116 |  |  | $ | (4,343) |  |  |  |
| Marketable securities | 3,609 |  |  | 5,298 |  |  | (1,689) |  |  |  |
| Cash, cash equivalents and marketable securities | $ | 6,382 |  |  | $ | 12,414 |  |  | $ | (6,032) |  |  |  |

[0000804328-22-000021:mdna:99]
(1) Excludes $326 million of cash and cash equivalents classified as held for sale (included in other current assets) at September 25, 2022.

[0000804328-22-000021:mdna:100]
|  | 2022 |  | 2021 |  | Change |
| Net cash provided by operating activities | $ | 9,096 |  |  | $ | 10,536 |  |  | $ | (1,440) |  |
| Net cash used by investing activities | (5,804) |  |  | (3,356) |  |  | (2,448) |  |
| Net cash used by financing activities | (7,196) |  |  | (6,798) |  |  | (398) |  |

[0000804328-22-000021:mdna:101]
Cash, cash equivalents and marketable securities. The net decrease in cash, cash equivalents and marketable securities was primarily due to $4.9 billion in cash paid for acquisitions and other investments, net of cash acquired (primarily related to Veoneer), $3.2 billion in cash dividends paid, $3.1 billion in payments to repurchase shares of our common stock, $2.3 billion in capital expenditures and $766 million in payments of tax withholdings related to vesting of share-based awards. This was partially offset by net cash provided by operating activities, which was negatively impacted by advanced payments of $2.3 billion made to suppliers of our integrated circuit products under multi-year capacity commitments (which were included within other current assets and other assets), as well as $4.5 billion of net changes in other operating assets and liabilities (excluding the reversal of the 2018 EC fine), primarily consisting of increased working capital requirements, including higher inventory and related operating liabilities and an increase in accounts receivable as a result of higher revenues combined with the timing of integrated circuit shipments during the period (net of an increase in amounts accrued for customer incentive arrangements recorded as a reduction to accounts receivable). We may continue to see elevated working capital requirements in the near term.

[0000804328-22-000021:mdna:102]
Debt. In May 2022, we issued an aggregate principal amount of $1.5 billion of unsecured fixed-rate notes with varying maturities. The net proceeds, together with cash on hand, were used to repay $1.5 billion of fixed-rate notes that matured in May 2022. At September 25, 2022, we had $15.4 billion of principal floating- and fixed-rate notes outstanding, $1.4 billion of which matures in January 2023. The remaining debt has maturity dates in 2024 through 2052.

[0000804328-22-000021:mdna:103]
We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At September 25, 2022, we had $499 million of commercial paper outstanding.

[0000804328-22-000021:mdna:104]
We also have a Revolving Credit Facility, which provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At September 25, 2022, no amounts were outstanding under the Revolving Credit Facility.

[0000804328-22-000021:mdna:105]
We expect to issue new debt in the future. The amount and timing of any such new debt will depend on a number of factors, including but not limited to maturities of our existing debt, acquisitions and strategic investments, favorable and/or acceptable interest rates and changes in corporate income tax law. Additional information regarding our outstanding debt at September 25, 2022 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 6. Debt.”

[0000804328-22-000021:mdna:106]
Income Taxes. At September 25, 2022, we estimated remaining future payments of $1.7 billion for a one-time U.S. repatriation tax accrued in fiscal 2018, after application of certain tax credits, which is payable in installments over the next four years. At September 25, 2022, other current liabilities included $207 million for the next installment due in January 2023. Beginning in fiscal 2023, we are required to capitalize and amortize research and development expenditures for federal income tax purposes. If this requirement is not delayed or repealed, our cash flow generated from operations will be adversely affected due to significantly higher cash tax payments in the near term. Additional information regarding our income taxes is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 3. Income Taxes.”

[0000804328-22-000021:mdna:107]
45

[0000804328-22-000021:mdna:108]
Capital Return Program. The following table summarizes stock repurchases, before commissions, and dividends paid during fiscal 2022 and 2021 (in millions, except per-share amounts):

[0000804328-22-000021:mdna:109]
|  |  | Stock Repurchase Program |  | Dividends |  | Total |
|  |  | Shares |  | Average Price Paid Per Share |  | Amount |  | Per Share |  | Amount |  | Amount |
| 2022 |  | 21 |  |  | $ | 149.95 |  |  | $ | 3,129 |  |  | $ | 2.86 |  |  | $ | 3,212 |  |  | $ | 6,341 |  |
| 2021 |  | 24 |  |  | 141.17 |  |  | 3,366 |  |  | 2.66 |  |  | 3,008 |  |  | 6,374 |  |

[0000804328-22-000021:mdna:110]
On October 12, 2021, we announced a $10.0 billion stock repurchase program. The stock repurchase program has no expiration date. At September 25, 2022, $8.1 billion remained authorized for repurchase under our stock repurchase program. Our stock repurchase programs are subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time.

[0000804328-22-000021:mdna:111]
On October 14, 2022, we announced a cash dividend of $0.75 per share on our common stock, payable on December 15, 2022 to stockholders of record as of the close of business on December 1, 2022. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0000804328-22-000021:mdna:112]
Additional Capital Requirements. We believe our cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements, in addition to the above matters, also include the items described below:

[0000804328-22-000021:mdna:113]
•Our purchase obligations at September 25, 2022, which primarily relate to purchase commitments with certain suppliers of our integrated circuit products, including those under multi-year capacity commitments, and certain other expenses, some of which relate to research and development activities and capital expenditures, totaled $24.5 billion, of which, $13.3 billion is expected to be paid in the next 12 months. We expect a significant decrease in advance payments made under our multi-year capacity commitments as compared to fiscal 2022.

[0000804328-22-000021:mdna:114]
•Our research and development expenditures were $8.2 billion in fiscal 2022 and $7.2 billion in fiscal 2021.

[0000804328-22-000021:mdna:115]
•Cash outflows for capital expenditures were $2.3 billion in fiscal 2022 and $1.9 billion in fiscal 2021.

[0000804328-22-000021:mdna:116]
•Amounts related to future lease payments for operating lease obligations at September 25, 2022 totaled $863 million, with $129 million expected to be paid within the next 12 months.

[0000804328-22-000021:mdna:117]
•We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly. For further information related to our most recent acquisitions, including details regarding the Non-Arriver businesses presented as held for sale, see “Notes to Consolidated Financial Statements, Note 9. Acquisitions” in this Annual Report.

[0000804328-22-000021:mdna:118]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies” and “Part I, Item 1A. Risk Factors” in this Annual Report.

[0000804328-22-000021:mdna:119]
Critical Accounting Estimates

[0000804328-22-000021:mdna:120]
The preparation of our consolidated financial statements in accordance with accounting principles generally accepted in the United States requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and disclosure of contingent assets and liabilities. We base our estimates on historical and anticipated results and trends and on various other assumptions that we believe are reasonable under the circumstances, including assumptions as to future events. By their nature, estimates are inherently subject to a degree of uncertainty. Although we believe that our estimates and the assumptions supporting our assessments are reasonable, actual results could differ materially from our estimates and assumptions, and could be material to our consolidated financial statements.

[0000804328-22-000021:mdna:121]
In addition to our critical accounting estimates and policies below, refer to “Note 1. Significant Accounting Policies” and “Note 2. Composition of Certain Financial Statement Items” included in this Annual Report in “Notes to Consolidated Financial Statements” for further information. If the impact of changes in our critical accounting estimates are material or considered necessary to understand our results of operations for the periods presented, then such information is disclosed within this Annual Report in “Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.”

[0000804328-22-000021:mdna:122]
Revenue Recognition. We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. We estimate and recognize sales-based royalties on such licensed products in the period in which the licensees’ sales occur, which is based largely on preliminary royalty estimates provided by our licensees. For fiscal 2022 and

[0000804328-22-000021:mdna:123]
2021, actual amounts for sales-based royalties have been materially consistent with such estimates, and no significant reversals of revenues have been required as a result of adjustments to prior period royalty estimates.

[0000804328-22-000021:mdna:124]
Impairment of Non-marketable Equity Investments. We monitor our investments for events or circumstances that could indicate impairment, including those that result from observable price adjustments. In fiscal 2021, and to a lesser extent in fiscal 2022, significant evaluation and judgments were required in determining whether such investments were impaired due to the continuing effects of the COVID-19 pandemic (as well as the effects of other macroeconomic factors), and if so, the extent of such impairment. This included, among other items: (i) assessing the business impacts that COVID-19 had on our investees, including taking into consideration the investee’s industry and geographic location and the impact to its customers, suppliers and employees, as applicable; (ii) evaluating the investees’ ability to respond to the impacts of COVID-19, including any significant deterioration in the investee’s financial condition and cash flows, as well as assessing liquidity and/or going concern risks; and (iii) considering any appreciation in fair value that has not been recognized in the carrying values of such investments. In fiscal 2022 and 2021, there were no significant impairment losses or adjustments to our previous judgments and estimates recorded.

[0000804328-22-000021:mdna:125]
Inventories. We measure inventory at the lower of cost or net realizable value considering judgments and estimates related to future customer demand and other market conditions, such as the impact of certain capacity constraints experienced across the semiconductor industry through the third quarter of fiscal 2022 and in fiscal 2021, as well as the impact of the macroeconomic environment in fiscal 2022. Although we believe these estimates are reasonable, any significant changes in customer demand that are less favorable than our previous estimates may require additional inventory write-downs and would be reflected in cost of sales resulting in a negative impact to our gross margin in that period. For fiscal 2022 and 2021, the net effect from changes in this estimate and related reserves was less than 2% of cost of revenues during each period.

[0000804328-22-000021:mdna:126]
Impairment of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. We monitor our goodwill, other indefinite-lived assets and long-lived assets for the existence of impairment indicators and apply judgments in the valuation methods and underlying assumptions utilized in such assessments. During fiscal 2022 and fiscal 2021, impairment charges for long-lived assets were not material. Additionally, the estimated fair values of our QCT and QTL reporting units, based on our qualitative assessment, were substantially in excess of their respective carrying values at September 25, 2022.

[0000804328-22-000021:mdna:127]
Legal and Regulatory Proceedings. We record our best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. We face difficulties in evaluating or estimating likely outcomes or the amount of possible loss in certain legal and regulatory proceedings.

[0000804328-22-000021:mdna:128]
Income Taxes. We make significant judgments and estimates in determining our provision for income taxes, including our assessment of our income tax positions given the uncertainties involved in the interpretation and application of complex tax laws and regulations in various taxing jurisdictions.
