# QCOM note change history — 0000804328-25-000031 → 0000804328-25-000045


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0000804328-25-000045:note_history:1]
On April 18, 2024, we filed a separate complaint (captioned QUALCOMM Incorporated v. Arm Ltd.) against Arm in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief. Arm moved to dismiss this complaint, and on October 30, 2024, the court denied Arm’s motion to dismiss. On December 16, 2024, we filed a First Amended Complaint alleging additional causes of action based on Arm improperly seeking to terminate the Qualcomm ALA and improperly publicizing that it was seeking to terminate the Qualcomm ALA. On June 3, 2025, we filed a Second Amended Complaint to add a claim that Arm has breached the Qualcomm TLA by failing to provide license offers at commercially reasonable prices and terms. Arm has moved to dismiss our amended complaint. Trial is scheduled to begin on March 9, 2026.
  (was, 2025-04-30, similarity 0.9335):
[0000804328-25-000031:note_history:1]
On April 18, 2024, we filed a separate complaint (captioned QUALCOMM Incorporated v. Arm Ltd.) against Arm in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief. Arm moved to dismiss this complaint, and on October 30, 2024, the court denied Arm’s motion to dismiss. On December 16, 2024, we filed a First Amended Complaint, alleging additional causes of action based on Arm improperly seeking to terminate the Qualcomm ALA and improperly publicizing that it was seeking to terminate the Qualcomm ALA. Arm has moved to dismiss the First Amended Complaint. On March 27, 2025, we moved to file a Second Amended Complaint to add a claim that Arm has breached the Qualcomm TLA by failing to provide license offers at commercially reasonable prices and terms. Trial is scheduled to begin on March 9, 2026.

- added (2025-07-30):
[0000804328-25-000045:note_history:2]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at June 29, 2025 for contingent losses associated with the matters described

- added (2025-07-30):
[0000804328-25-000045:note_history:3]
above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (for example, certain consumer class action lawsuits in jurisdictions outside the United States, and other matters arising in the ordinary course of our business, including those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- removed (2025-07-30):
[0000804328-25-000031:note_history:4]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. The cases filed in the Southern District of California were subsequently transferred to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On September 27, 2018, the court certified the class. We appealed the court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class, and remanded the case to the district court. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. We filed a motion to dismiss the amended complaint, and on January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. We subsequently filed a motion for summary judgment on the plaintiffs’ remaining claims. The court granted our motion in its entirety and, on October 5, 2023, entered final judgment in Qualcomm’s favor. The plaintiffs appealed the decision to the Ninth Circuit. On February 25, 2025, the Ninth Circuit issued a ruling dismissing all but one of the plaintiffs’ claims with prejudice and dismissing the remaining claim without prejudice.

- removed (2025-07-30):
[0000804328-25-000031:note_history:5]
Beginning in November 2017, several other consumer class action complaints were filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws and seeking damages. The claims in these complaints are similar to those in the U.S. consumer class action complaints described above. These matters are at various stages of litigation, and we intend to continue to vigorously defend ourselves.

- removed (2025-07-30):
[0000804328-25-000031:note_history:6]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at March 30, 2025 for contingent losses associated with the pending matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (for example, our 2010 European Commission matter relating to the Icera complaint, and other matters arising in the ordinary course of our business, including those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0000804328-25-000045:note_history:7]
We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and nine months ended June 29, 2025 and June 23, 2024 included 13 weeks and 39 weeks, respectively. Our fiscal year for 2025 will include 52 weeks.
  (was, 2025-04-30, similarity 0.8524):
[0000804328-25-000031:note_history:7]
We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 30, 2025 and March 24, 2024 included 13 weeks and 26 weeks, respectively. Our fiscal year for 2025 will include 52 weeks.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0000804328-25-000045:note_history:8]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  | June 29,2025 |  | June 23,2024 |  | June 29,2025 |  | June 23,2024 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,328 |  |  | $ | 5,899 |  |  | $ | 20,831 |  |  | $ | 18,766 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 984 |  |  | 811 |  |  | 2,904 |  |  | 2,012 |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,681 |  |  | 1,359 |  |  | 4,811 |  |  | 3,740 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 8,993 |  |  | $ | 8,069 |  |  | $ | 28,546 |  |  | $ | 24,518 |  |
  (was, 2025-04-30, similarity 0.9025):
[0000804328-25-000031:note_history:8]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  | March 30,2025 |  | March 24,2024 |  | March 30,2025 |  | March 24,2024 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,929 |  |  | $ | 6,180 |  |  | $ | 14,503 |  |  | $ | 12,867 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 959 |  |  | 603 |  |  | 1,920 |  |  | 1,201 |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,581 |  |  | 1,243 |  |  | 3,130 |  |  | 2,381 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 9,469 |  |  | $ | 8,026 |  |  | $ | 19,553 |  |  | $ | 16,449 |  |
