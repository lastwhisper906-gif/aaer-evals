# QCOM MD&A — 0000804328-25-000045


## mdna

[0000804328-25-000045:mdna:1]
[same as prior period, unchanged from 0000804328-25-000031:mdna:1]

[0000804328-25-000045:mdna:2]
[same as prior period, unchanged from 0000804328-25-000031:mdna:2]

[0000804328-25-000045:mdna:3]
This Quarterly Report (including but not limited to this section titled Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates,” “may,” “will,” “would” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report. Additionally, statements concerning future matters such as our future business, prospects, results of operations or financial condition; research and development or technology investments; new or enhanced products, services or technologies; emerging industries or business models; design wins or product launches; industry, market or technology trends, dynamics or transitions; our expectations regarding future demand or supply conditions; strategic investments or acquisitions, and the anticipated timing or benefits thereof; legal or regulatory matters, including the expected impacts of recently enacted or pending tax or other regulatory changes; U.S./China trade or national security tensions; vertical integration by our customers; competition; annual effective tax rates; and other statements regarding matters that are not historical are also forward-looking statements.

[0000804328-25-000045:mdna:4]
Third Quarter Fiscal 2025 Overview

[0000804328-25-000045:mdna:5]
Revenues for the third quarter of fiscal 2025 were $10.4 billion, an increase of 10% compared to the year ago quarter, with net income of $2.7 billion, an increase of 25% compared to the year ago quarter. Key items from the third quarter of fiscal 2025 included:

[0000804328-25-000045:mdna:6]
•QCT revenues increased by 11% in the third quarter of fiscal 2025 compared to the year ago quarter due to higher handsets, IoT and automotive revenues.

[0000804328-25-000045:mdna:7]
•QTL revenues increased by 4% in the third quarter of fiscal 2025 compared to the year ago quarter, primarily due to an increase in estimated sales of 3G/4G/5G-based multimode products.

[0000804328-25-000045:mdna:8]
[same as prior period, unchanged from 0000804328-25-000031:mdna:8]

[0000804328-25-000045:mdna:9]
[same as prior period, unchanged from 0000804328-25-000031:mdna:9]

[0000804328-25-000045:mdna:10]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our Data Center business (formerly referred to as our cloud computing processing initiative).

[0000804328-25-000045:mdna:11]
[same as prior period, unchanged from 0000804328-25-000031:mdna:11]

[0000804328-25-000045:mdna:12]
[same as prior period, unchanged from 0000804328-25-000031:mdna:13]

[0000804328-25-000045:mdna:13]
[same as prior period, unchanged from 0000804328-25-000031:mdna:14]

[0000804328-25-000045:mdna:14]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | Change |  | June 29,2025 |  | June 23,2024 |  | Change |
| Equipment and services | $ | 8,893 |  |  | $ | 7,993 |  |  | $ | 900 |  |  | $ | 28,193 |  |  | $ | 24,259 |  |  | $ | 3,934 |  |
| Licensing | 1,472 |  |  | 1,400 |  |  | 72 |  |  | 4,820 |  |  | 4,459 |  |  | 361 |  |
|  | $ | 10,365 |  |  | $ | 9,393 |  |  | $ | 972 |  |  | $ | 33,013 |  |  | $ | 28,718 |  |  | $ | 4,295 |  |

[0000804328-25-000045:mdna:15]
Third quarter 2025 vs. 2024

[0000804328-25-000045:mdna:16]
The increase in revenues in the third quarter of fiscal 2025 was primarily due to:

[0000804328-25-000045:mdna:17]
+    $898 million in higher equipment and services revenues from our QCT segment

[0000804328-25-000045:mdna:18]
First nine months 2025 vs. 2024

[0000804328-25-000045:mdna:19]
The increase in revenues in the first nine months of fiscal 2025 was primarily due to:

[0000804328-25-000045:mdna:20]
+    $3.9 billion in higher equipment and services revenues from our QCT segment

[0000804328-25-000045:mdna:21]
+    $143 million in licensing revenues resulting from a settlement of a licensing dispute in the second quarter of fiscal 2025, which was not allocated to our segment results

[0000804328-25-000045:mdna:22]
+    $121 million in higher licensing revenues from our QTL segment

[0000804328-25-000045:mdna:23]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | Change |  | June 29,2025 |  | June 23,2024 |  | Change |
| Cost of revenues | $ | 4,606 |  |  | $ | 4,174 |  |  | $ | 432 |  |  | $ | 14,704 |  |  | $ | 12,593 |  |  | $ | 2,111 |  |
| Gross margin | 56 | % |  | 56 | % |  |  |  | 55 | % |  | 56 | % |  |  |

[0000804328-25-000045:mdna:24]
Third quarter 2025 vs. 2024

[0000804328-25-000045:mdna:25]
Gross margin percentage remained approximately flat in the third quarter of fiscal 2025.

[0000804328-25-000045:mdna:26]
First nine months 2025 vs. 2024

[0000804328-25-000045:mdna:27]
Gross margin percentage decreased in the first nine months of fiscal 2025 primarily due to a decrease in the proportion of total revenues related to QTL licensing revenues (which have a higher margin contribution).

[0000804328-25-000045:mdna:28]
[same as prior period, unchanged from 0000804328-25-000031:mdna:30]

[0000804328-25-000045:mdna:29]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | Change |  | June 29,2025 |  | June 23,2024 |  | Change |
| Research and development | $ | 2,226 |  |  | $ | 2,259 |  |  | $ | (33) |  |  | $ | 6,672 |  |  | $ | 6,591 |  |  | $ | 81 |  |
| % of revenues | 21 | % |  | 24 | % |  |  |  | 20 | % |  | 23 | % |  |  |

[0000804328-25-000045:mdna:30]
Third quarter 2025 vs. 2024

[0000804328-25-000045:mdna:31]
The decrease in research and development expenses in the third quarter of fiscal 2025 was primarily due to:

[0000804328-25-000045:mdna:32]
-    $83 million decrease driven by lower costs related to the development of wireless and integrated circuit technologies (including investments in key growth and diversification opportunities), primarily driven by $189 million in higher non-recurring engineering cost reimbursements for product-related development work, partially offset by higher employee-related costs

[0000804328-25-000045:mdna:33]
+    $35 million increase in expenses driven by the revaluation of our deferred compensation obligation (which resulted in a corresponding increase in net gains on deferred compensation plan assets within investment and other income, net due to the revaluation of the related assets)

[0000804328-25-000045:mdna:34]
First nine months 2025 vs. 2024

[0000804328-25-000045:mdna:35]
The increase in research and development expenses in the first nine months of fiscal 2025 was primarily due to a $132 million increase in share-based compensation expense. Our costs related to the development of wireless and integrated circuit technologies (including investments in key growth and diversification opportunities) remained approximately flat, primarily driven by $288 million in higher non-recurring engineering cost reimbursements for product-related development work, partially offset by an increase in employee-related costs.

[0000804328-25-000045:mdna:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | Change |  | June 29,2025 |  | June 23,2024 |  | Change |
| Selling, general and administrative | $ | 771 |  |  | $ | 664 |  |  | $ | 107 |  |  | $ | 2,200 |  |  | $ | 1,998 |  |  | $ | 202 |  |
| % of revenues | 7 | % |  | 7 | % |  |  |  | 7 | % |  | 7 | % |  |  |

[0000804328-25-000045:mdna:37]
Third quarter and first nine months 2025 vs. 2024

[0000804328-25-000045:mdna:38]
The increase in selling, general and administrative expenses in the third quarter and first nine months of fiscal 2025 was primarily due to an increase in sales and marketing expenses.

[0000804328-25-000045:mdna:39]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | Change |  | June 29,2025 |  | June 23,2024 |  | Change |
| Interest expense | $ | 168 |  |  | $ | 168 |  |  | $ | — |  |  | $ | 493 |  |  | $ | 517 |  |  | $ | (24) |  |
| Investment and other income, net |
| Interest and dividend income | $ | 160 |  |  | $ | 182 |  |  | $ | (22) |  |  | $ | 495 |  |  | $ | 490 |  |  | $ | 5 |  |
| Net gains on marketable securities | 204 |  |  | 8 |  |  | 196 |  |  | 241 |  |  | 16 |  |  | 225 |  |
| Net gains on other investments | 5 |  |  | 10 |  |  | (5) |  |  | 30 |  |  | 170 |  |  | (140) |  |
| Net gains on deferred compensation plan assets | 84 |  |  | 26 |  |  | 58 |  |  | 65 |  |  | 153 |  |  | (88) |  |
| Impairment losses on other investments | (52) |  |  | (5) |  |  | (47) |  |  | (93) |  |  | (66) |  |  | (27) |  |
| Other | (43) |  |  | 5 |  |  | (48) |  |  | 10 |  |  | 5 |  |  | 5 |  |
|  | $ | 358 |  |  | $ | 226 |  |  | $ | 132 |  |  | $ | 748 |  |  | $ | 768 |  |  | $ | (20) |  |

[0000804328-25-000045:mdna:40]
Net gains on marketable securities in the third quarter and first nine months of fiscal 2025 was primarily driven by the initial public offerings of certain QSI equity investments.

[0000804328-25-000045:mdna:41]
Net gains on other investments in the first nine months of fiscal 2024 was primarily driven by certain of our QSI non-marketable equity investments.

[0000804328-25-000045:mdna:42]
[same as prior period, unchanged from 0000804328-25-000031:mdna:54]

[0000804328-25-000045:mdna:43]
[same as prior period, unchanged from 0000804328-25-000031:mdna:55]

[0000804328-25-000045:mdna:44]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | June 29,2025 |  | June 23,2024 |
| Expected income tax provision at federal statutory tax rate | $ | 620 |  |  | $ | 479 |  |  | $ | 2,035 |  |  | $ | 1,625 |  |
| Benefit from foreign-derived intangible income (FDII) deduction, excluding the impact of capitalizing research and development expenditures | (150) |  |  | (130) |  |  | (547) |  |  | (439) |  |
| Benefit from FDII deduction related to capitalizing research and development expenditures | (119) |  |  | (94) |  |  | (382) |  |  | (417) |  |
| Benefit related to the federal research and development tax credit | (67) |  |  | (61) |  |  | (186) |  |  | (195) |  |
| Excess tax benefit associated with share-based awards | (21) |  |  | (89) |  |  | (98) |  |  | (141) |  |
| Foreign currency (gain) loss related to foreign withholding tax receivable | (123) |  |  | 55 |  |  | 42 |  |  | 57 |  |
| Other | 146 |  |  | 11 |  |  | 170 |  |  | 55 |  |
| Income tax expense | $ | 286 |  |  | $ | 171 |  |  | $ | 1,034 |  |  | $ | 545 |  |
| Effective tax rate | 10 | % |  | 8 | % |  | 11 | % |  | 7 | % |

[0000804328-25-000045:mdna:45]
For the third quarter of fiscal 2025, we estimate our annual effective income tax rate to be 11% for fiscal 2025, which is lower than the U.S. federal statutory rate. Additional information regarding our annual effective income tax rate and income tax expense is provided in this Quarterly Report in “Notes to Condensed Consolidated Statements, Note 3. Income Taxes.”

[0000804328-25-000045:mdna:46]
On July 4, 2025, tax reform legislation included in the One Big Beautiful Bill Act (OBBB) was enacted in the United States. The impact of the OBBB is excluded from our estimated annual effective tax rate and provision for income taxes for the third quarter of fiscal 2025 as it is a nonrecognized subsequent event. The OBBB includes significant corporate tax reforms, including the permanent reinstatement of deducting domestic research and development expenditures as incurred beginning in fiscal 2026 (under prior law such expenditures were capitalized and amortized over five years). We expect this change will have a favorable effect on our cash flows from operations due to significantly lower cash tax payments.

[0000804328-25-000045:mdna:47]
[same as prior period, unchanged from 0000804328-25-000031:mdna:59]

[0000804328-25-000045:mdna:48]
However, we expect it will adversely affect our total provision for income taxes and results of operations, as these expenditures will no longer result in a deferred tax asset that is established at the statutory rate of 21% rather than the current effective tax rate of 13% after considering the FDII deduction. The legislation also modifies international tax provisions, including changes to the FDII regime. Specifically, it renames FDII as Foreign-Derived Deduction Eligible Income (FDDEI), maintains the current FDDEI effective tax rate of 13% through fiscal 2026 and adjusts the FDDEI effective tax rate to a permanent 14% rate in fiscal 2027 (compared to 16% under prior law).

[0000804328-25-000045:mdna:49]
While we continue to evaluate the impact of these tax law changes, we may be subject to the corporate alternative minimum tax of 15% beginning in fiscal 2026, and we are assessing our ability to realize our existing deferred tax assets. As such, our future provision for income taxes and results of operations may be adversely affected (potentially materially).

[0000804328-25-000045:mdna:50]
| Discontinued Operations (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | Change |  | June 29,2025 |  | June 23,2024 |  | Change |
| Discontinued operations, net of income taxes | $ | — |  |  | $ | 21 |  |  | $ | (21) |  |  | $ | — |  |  | $ | 27 |  |  | $ | (27) |  |

[0000804328-25-000045:mdna:51]
Discontinued operations in the third quarter and first nine months of fiscal 2024 are related to the Non-Arriver businesses. Information regarding the Non-Arriver businesses is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Discontinued Operations.”

[0000804328-25-000045:mdna:52]
[same as prior period, unchanged from 0000804328-25-000031:mdna:62]

[0000804328-25-000045:mdna:53]
The following should be read in conjunction with our financial results for the third quarter of fiscal 2025 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0000804328-25-000045:mdna:54]
[same as prior period, unchanged from 0000804328-25-000031:mdna:64]

[0000804328-25-000045:mdna:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | Change |  | June 29,2025 |  | June 23,2024 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets | $ | 6,328 |  |  | $ | 5,899 |  |  | $ | 429 |  | $ | 20,831 |  |  | $ | 18,766 |  |  | $ | 2,065 |
| Automotive | 984 |  |  | 811 |  |  | 173 |  | 2,904 |  |  | 2,012 |  |  | 892 |
| IoT (internet of things) | 1,681 |  |  | 1,359 |  |  | 322 |  | 4,811 |  |  | 3,740 |  |  | 1,071 |
| Total revenues (1) | $ | 8,993 |  |  | $ | 8,069 |  |  | $ | 924 |  | $ | 28,546 |  |  | $ | 24,518 |  |  | $ | 4,028 |
| EBT (2) | $ | 2,671 |  |  | $ | 2,181 |  |  | $ | 490 |  | $ | 8,774 |  |  | $ | 7,062 |  |  | $ | 1,712 |
| EBT as a % of revenues | 30 | % |  | 27 | % |  | 3 points |  | 31 | % |  | 29 | % |  | 2 points |

[0000804328-25-000045:mdna:56]
[same as prior period, unchanged from 0000804328-25-000031:mdna:66]

[0000804328-25-000045:mdna:57]
[same as prior period, unchanged from 0000804328-25-000031:mdna:67]

[0000804328-25-000045:mdna:58]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $8.8 billion and $7.9 billion in the third quarter of fiscal 2025 and 2024, respectively, and $28.0 billion and $24.1 billion in the first nine months of fiscal 2025 and 2024, respectively. QCT revenues mostly relate to sales of our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets as well as sales of RFFE products.

[0000804328-25-000045:mdna:59]
Third quarter 2025 vs. 2024

[0000804328-25-000045:mdna:60]
The increase in QCT revenues in the third quarter of fiscal 2025 was primarily due to:

[0000804328-25-000045:mdna:61]
+    higher handsets revenues, primarily due to $387 million in higher revenues per chipset primarily driven by higher average selling prices and favorable mix toward premium-tier Snapdragon platforms

[0000804328-25-000045:mdna:62]
+    higher IoT revenues, primarily due to higher shipments primarily across edge networking, industrial and consumer products

[0000804328-25-000045:mdna:63]
[same as prior period, unchanged from 0000804328-25-000031:mdna:72]

[0000804328-25-000045:mdna:64]
QCT EBT as a percentage of revenues increased in the third quarter of fiscal 2025 primarily due to higher revenues.

[0000804328-25-000045:mdna:65]
[same as prior period, unchanged from 0000804328-25-000031:mdna:80]

[0000804328-25-000045:mdna:66]
Gross margin percentage remained approximately flat in the third quarter of fiscal 2025, primarily driven by higher product costs, partially offset by higher average selling prices.

[0000804328-25-000045:mdna:67]
First nine months 2025 vs. 2024

[0000804328-25-000045:mdna:68]
The increase in QCT revenues in the first nine months of fiscal 2025 was primarily due to:

[0000804328-25-000045:mdna:69]
+    higher handsets revenues, primarily due to $1.3 billion in higher revenues per chipset (primarily driven by higher average selling prices) and $810 million in higher chipset shipments by certain major OEMs, both of which benefited from an increase in demand in premium-tier Snapdragon platforms

[0000804328-25-000045:mdna:70]
+    higher IoT revenues, primarily due to higher shipments across edge networking, consumer and industrial products

[0000804328-25-000045:mdna:71]
[same as prior period, unchanged from 0000804328-25-000031:mdna:82]

[0000804328-25-000045:mdna:72]
QCT EBT as a percentage of revenues increased in the first nine months of fiscal 2025 primarily due to higher revenues.

[0000804328-25-000045:mdna:73]
Gross margin percentage remained approximately flat in the first nine months of fiscal 2025, primarily driven by higher product costs, partially offset by higher average selling prices.

[0000804328-25-000045:mdna:74]
[same as prior period, unchanged from 0000804328-25-000031:mdna:87]

[0000804328-25-000045:mdna:75]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | Change |  | June 29,2025 |  | June 23,2024 |  | Change |
| Licensing revenues | $ | 1,318 |  |  | $ | 1,273 |  |  | $ | 45 |  |  | $ | 4,172 |  |  | $ | 4,051 |  |  | $ | 121 |  |
| EBT | 942 |  |  | 894 |  |  | 48 |  |  | 3,028 |  |  | 2,907 |  |  | 121 |  |
| EBT as a % of revenues | 71 | % |  | 70 | % |  | 1 point |  | 73 | % |  | 72 | % |  | 1 point |

[0000804328-25-000045:mdna:76]
During the second quarter of fiscal 2025, we executed final agreements for new long-term licenses with two key Chinese OEMs (for which the initial terms had expired) and entered into comprehensive 4G and 5G license agreements with Transsion (a growing, China-headquartered OEM that sells primarily in developing regions). As a result of our agreements with Transsion, all outstanding litigation between the parties has been dismissed. Beginning in the second quarter of fiscal 2025, QTL revenues did not include royalties from Huawei, whose license agreement has expired.

[0000804328-25-000045:mdna:77]
Third quarter and first nine months 2025 vs. 2024

[0000804328-25-000045:mdna:78]
The increase in QTL licensing revenues in the third quarter and first nine months of fiscal 2025 was primarily due to an increase in estimated sales of 3G/4G/5G-based multimode products.

[0000804328-25-000045:mdna:79]
QTL EBT as a percentage of revenues increased in the third quarter and first nine months of fiscal 2025 primarily due to higher revenues.

[0000804328-25-000045:mdna:80]
[same as prior period, unchanged from 0000804328-25-000031:mdna:97]

[0000804328-25-000045:mdna:81]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | Change |  | June 29,2025 |  | June 23,2024 |  | Change |
| Equipment and services revenues | $ | — |  |  | $ | 2 |  |  | $ | (2) |  |  | $ | — |  |  | $ | 18 |  |  | $ | (18) |  |
| EBT | 149 |  |  | 14 |  |  | 135 |  |  | 179 |  |  | 121 |  |  | 58 |  |

[0000804328-25-000045:mdna:82]
Third quarter and first nine months 2025 vs. 2024

[0000804328-25-000045:mdna:83]
QSI EBT increased in the third quarter of fiscal 2025 primarily due to higher net gains on marketable securities resulting from the initial public offerings of certain of our equity investments.

[0000804328-25-000045:mdna:84]
QSI EBT increased in the first nine months of fiscal 2025 primarily due to higher net gains on marketable securities resulting from the initial public offerings of certain of our equity investments, partially offset by lower net gains on certain of our non-marketable equity investments.

[0000804328-25-000045:mdna:85]
[same as prior period, unchanged from 0000804328-25-000031:mdna:101]

[0000804328-25-000045:mdna:86]
[same as prior period, unchanged from 0000804328-25-000031:mdna:102]

[0000804328-25-000045:mdna:87]
[same as prior period, unchanged from 0000804328-25-000031:mdna:103]

[0000804328-25-000045:mdna:88]
•We continue to monitor the recent changes in global trade policy, including tariffs and related trade actions announced by the U.S., China and other countries. The degree to which such tariffs and other related actions impact our business, financial condition and results of operations will depend on future developments, which are uncertain. Changes to global trade policies may negatively impact demand, pricing and cost for our products and technologies, and contribute to the inherent uncertainties in estimating future customer demand, which may result in increased excess or obsolete inventory or reserve charges, negatively impacting our results of operations and cash flows. See “Risk Factors” in this Quarterly Report, including the Risk Factor titled “We operate in the highly cyclical semiconductor industry, which is subject to significant downturns. We are also susceptible to declines in global, regional and local economic conditions generally. Our stock price and financial results are subject to substantial quarterly and annual fluctuations due to these dynamics, among others.”

[0000804328-25-000045:mdna:89]
[same as prior period, unchanged from 0000804328-25-000031:mdna:107]

[0000804328-25-000045:mdna:90]
•We expect continued intense competition, including from vertical integration by certain of our customers. In particular, Apple began utilizing its own modem (rather than our products) in its recently released smartphone and we expect that Apple will increasingly use its own modem products, rather than our products, in its future devices, which will have a significant negative impact on our QCT revenues, results of operations and cash flows.

[0000804328-25-000045:mdna:91]
[same as prior period, unchanged from 0000804328-25-000031:mdna:109]

[0000804328-25-000045:mdna:92]
We are also involved in certain legal proceedings, including those described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Litigation is inherently uncertain, and, while we intend to continue to vigorously defend ourselves in such matters, the unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0000804328-25-000045:mdna:93]
[same as prior period, unchanged from 0000804328-25-000031:mdna:111]

[0000804328-25-000045:mdna:94]
[same as prior period, unchanged from 0000804328-25-000031:mdna:112]

[0000804328-25-000045:mdna:95]
23

[0000804328-25-000045:mdna:96]
[same as prior period, unchanged from 0000804328-25-000031:mdna:113]

[0000804328-25-000045:mdna:97]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities (including restricted cash), cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at June 29, 2025 and September 29, 2024 and for the first nine months of fiscal 2025 and 2024 (in millions):

[0000804328-25-000045:mdna:98]
|  | June 29,2025 |  | September 29,2024 |  | Change |  |  |
| Cash, cash equivalents and marketable securities (including restricted cash) |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 5,448 |  |  | $ | 7,849 |  |  | $ | (2,401) |  |  |  |
| Restricted cash (1) | 2,323 |  |  | — |  |  | 2,323 |  |  |  |
| Marketable securities | 4,563 |  |  | 5,451 |  |  | (888) |  |  |  |
|  | $ | 12,334 |  |  | $ | 13,300 |  |  | $ | (966) |  |  |  |
| Debt (2) | $ | 14,788 |  |  | $ | 14,634 |  |  | $ | 154 |  |  |  |

[0000804328-25-000045:mdna:99]
(1) In connection with the pending acquisition of Alphawave, we agreed to restrict the use of approximately $2.3 billion of cash to be held for purposes of satisfying payment of the consideration to effect the acquisition. Additional information regarding our pending acquisition of Alphawave is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 8. Acquisitions.”

[0000804328-25-000045:mdna:100]
(2) Includes our issued debt reported as long-term and short-term debt. As of June 29, 2025 and September 29, 2024, our credit facility was undrawn, and we had no commercial paper outstanding.

[0000804328-25-000045:mdna:101]
|  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | Change |  |  |
| Net cash provided by operating activities | $ | 10,016 |  |  | $ | 9,555 |  |  | $ | 461 |  |  |  |
| Net cash used by investing activities | (329) |  |  | (3,238) |  |  | 2,909 |  |  |  |
| Net cash used by financing activities | (9,760) |  |  | (7,070) |  |  | (2,690) |  |  |  |

[0000804328-25-000045:mdna:102]
Cash, cash equivalents and marketable securities (including restricted cash). The net decrease in cash, cash equivalents and marketable securities (including restricted cash) for the first nine months of fiscal 2025 was primarily due to $6.3 billion in payments to repurchase 41 million shares of our common stock, $2.8 billion in cash dividends paid, $1.4 billion repayment of unsecured fixed-rate notes that matured in May 2025, $878 million in payments of tax withholdings related to the vesting of share-based awards, $785 million in capital expenditures and $711 million in cash paid for acquisitions and other investments, partially offset by net cash provided by operating activities and the issuance of $1.5 billion of unsecured fixed-rate notes.

[0000804328-25-000045:mdna:103]
During the first nine months of fiscal 2025, income taxes paid were in excess of our provision, negatively impacting net cash provided by operating activities. This was driven primarily by our installment payment for a one-time U.S. repatriation tax accrued in fiscal 2018 of $530 million and the adverse impact of the requirement to capitalize and amortize research and development expenditures for federal income tax purposes. The OBBB includes significant corporate tax reforms, including the permanent reinstatement of deducting domestic research and development expenditures as incurred beginning in fiscal 2026 (under prior law such expenditures were capitalized and amortized over five years). We expect this change will have a favorable effect on our cash flows from operations due to significantly lower cash tax payments beginning in fiscal 2026.

[0000804328-25-000045:mdna:104]
Net changes in our operating assets and liabilities for the first nine months of fiscal 2025 negatively impacted our operating cash flows primarily from a decrease in payroll, benefit and other liabilities, partially offset by a decrease in accounts receivable and other assets. The decrease in payroll, benefits and other liabilities and accounts receivable was primarily due to an increase in the portion of customer incentive amounts recorded as a reduction to accounts receivable. The decrease in other assets was primarily driven by utilization of prior advanced supply agreement payments.

[0000804328-25-000045:mdna:105]
Debt. During the third quarter of fiscal 2025, we repaid $1.4 billion of unsecured fixed-rate notes that matured in May 2025. In May 2025, we also issued $1.5 billion of unsecured fixed-rate notes, consisting of $500 million of 4.50% notes, $400 million of 4.75% notes and $600 million of 5.00% notes (collectively, May 2025 Notes) that mature on May 20, 2030, May 20, 2032 and May 20, 2035, respectively. The net proceeds from the May 2025 Notes will be used for general corporate purposes. We also entered into interest rate swaps which are designated as fair value hedges and allow us to effectively convert all of our fixed-rate payments due under the May 2025 Notes into floating-rate payments. Additional information regarding our debt is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items.”

[0000804328-25-000045:mdna:106]
[same as prior period, unchanged from 0000804328-25-000031:mdna:128]

[0000804328-25-000045:mdna:107]
Capital Return Program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time. Our stock repurchases in the first nine months of fiscal 2025 have increased compared to the prior year, and we expect our stock repurchases to remain at an increased level compared to the prior year through the remainder of fiscal 2025. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors. Additional information regarding our capital returns is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 4. Capital Stock.”

[0000804328-25-000045:mdna:108]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2024 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At June 29, 2025, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements”, “Looking Forward” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2024 Annual Report on Form 10-K.

[0000804328-25-000045:mdna:109]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Risk Factors” in this Quarterly Report.

[0000804328-25-000045:mdna:110]
[same as prior period, unchanged from 0000804328-25-000031:mdna:125]

[0000804328-25-000045:mdna:111]
[same as prior period, unchanged from 0000804328-25-000031:mdna:126]

[0000804328-25-000045:mdna:112]
[same as prior period, unchanged from 0000804328-25-000031:mdna:127]
