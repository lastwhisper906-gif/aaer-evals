# QCOM notes — 0000804328-25-000045


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000804328-25-000045:notes:1]
[same as prior period, unchanged from 0000804328-25-000031:notes:1]

[0000804328-25-000045:notes:2]
[same as prior period, unchanged from 0000804328-25-000031:notes:2]

[0000804328-25-000045:notes:3]
We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and nine months ended June 29, 2025 and June 23, 2024 included 13 weeks and 39 weeks, respectively. Our fiscal year for 2025 will include 52 weeks.

[0000804328-25-000045:notes:4]
[same as prior period, unchanged from 0000804328-25-000031:notes:4]

[0000804328-25-000045:notes:5]
[same as prior period, unchanged from 0000804328-25-000031:notes:5]

[0000804328-25-000045:notes:6]
[same as prior period, unchanged from 0000804328-25-000031:notes:6]

[0000804328-25-000045:notes:7]
[same as prior period, unchanged from 0000804328-25-000031:notes:7]

[0000804328-25-000045:notes:8]
[same as prior period, unchanged from 0000804328-25-000031:notes:8]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-25-000045:notes:9]
[same as prior period, unchanged from 0000804328-25-000031:notes:9]

[0000804328-25-000045:notes:10]
| Inventories (in millions) |  |  |  |
|  | June 29,2025 |  | September 29,2024 |
| Raw materials | $ | 301 |  |  | $ | 340 |  |
| Work-in-process | 3,944 |  |  | 3,497 |  |
| Finished goods | 2,093 |  |  | 2,586 |  |
|  | $ | 6,338 |  |  | $ | 6,423 |  |

[0000804328-25-000045:notes:11]
We have multi-year capacity purchase commitments with certain suppliers of our integrated circuit products. Total advance payments related to multi-year capacity purchase commitments recorded on our condensed consolidated balance sheets at June 29, 2025 and September 29, 2024 were $2.4 billion and $3.0 billion, respectively, of which $1.9 billion and $765 million were recorded in other current assets, respectively, and $557 million and $2.2 billion were recorded in other assets, respectively.

[0000804328-25-000045:notes:12]
| Other Current Liabilities (in millions) |  |  |  |
|  | June 29,2025 |  | September 29,2024 |
| Customer incentives and other customer-related liabilities | $ | 1,823 |  |  | $ | 2,480 |  |
| Income taxes payable | 938 |  |  | 1,080 |  |
| Other | 831 |  |  | 865 |  |
|  | $ | 3,592 |  |  | $ | 4,425 |  |

[0000804328-25-000045:notes:13]
Long-term Debt. During the third quarter of fiscal 2025, we repaid $1.4 billion of unsecured fixed-rate notes that matured in May 2025. In May 2025, we also issued $1.5 billion of unsecured fixed-rate notes, consisting of $500 million of 4.50% notes, $400 million of 4.75% notes and $600 million of 5.00% notes (collectively, May 2025 Notes) that mature on May 20, 2030, May 20, 2032 and May 20, 2035, respectively. The net proceeds from the May 2025 Notes will be used for general corporate purposes.

[0000804328-25-000045:notes:14]
At June 29, 2025, the aggregate fair value of our outstanding fixed-rate notes, based on Level 2 inputs, was approximately $13.9 billion.

[0000804328-25-000045:notes:15]
Interest Rate Swaps. During the third quarter of fiscal 2025, in connection with the issuance of the May 2025 Notes, we entered into interest rate swaps with an aggregate notional amount of $1.5 billion, which are designated as fair value hedges and allow us to effectively convert all of our fixed-rate payments due under the May 2025 Notes into floating-rate payments. We entered into these agreements, in part, to manage interest rate risk associated with our cash equivalents and marketable securities, in addition to changes in the fair value of our outstanding debt.

[0000804328-25-000045:notes:16]
[same as prior period, unchanged from 0000804328-25-000031:notes:12]

[0000804328-25-000045:notes:17]
[same as prior period, unchanged from 0000804328-25-000031:notes:13]

[0000804328-25-000045:notes:18]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  | June 29,2025 |  | June 23,2024 |  | June 29,2025 |  | June 23,2024 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,328 |  |  | $ | 5,899 |  |  | $ | 20,831 |  |  | $ | 18,766 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 984 |  |  | 811 |  |  | 2,904 |  |  | 2,012 |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,681 |  |  | 1,359 |  |  | 4,811 |  |  | 3,740 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 8,993 |  |  | $ | 8,069 |  |  | $ | 28,546 |  |  | $ | 24,518 |  |

[0000804328-25-000045:notes:19]
[same as prior period, unchanged from 0000804328-25-000031:notes:15]

[0000804328-25-000045:notes:20]
[same as prior period, unchanged from 0000804328-25-000031:notes:16]

[0000804328-25-000045:notes:21]
[same as prior period, unchanged from 0000804328-25-000031:notes:17]

[0000804328-25-000045:notes:22]
[same as prior period, unchanged from 0000804328-25-000031:notes:18]

[0000804328-25-000045:notes:23]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | June 29,2025 |  | June 23,2024 |
| Revenues recognized from previously satisfied performance obligations | $ | 189 |  |  | $ | 163 |  |  | $ | 691 |  |  | $ | 364 |  |

[0000804328-25-000045:notes:24]
[same as prior period, unchanged from 0000804328-25-000031:notes:20]

[0000804328-25-000045:notes:25]
[same as prior period, unchanged from 0000804328-25-000031:notes:21]

[0000804328-25-000045:notes:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | June 29,2025 |  | June 23,2024 |
| Customer/licensee (x) | 21 | % |  | 18 | % |  | 21 | % |  | 20 | % |
| Customer/licensee (y) | 18 |  |  | 17 |  |  | 20 |  |  | 20 |  |
| Customer/licensee (z) | 13 |  |  | 11 |  |  | 13 |  |  | 13 |  |

[0000804328-25-000045:notes:27]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | June 29,2025 |  | June 23,2024 |
| Interest and dividend income | $ | 160 |  |  | $ | 182 |  |  | $ | 495 |  |  | $ | 490 |  |
| Net gains on marketable securities | 204 |  |  | 8 |  |  | 241 |  |  | 16 |  |
| Net gains on other investments | 5 |  |  | 10 |  |  | 30 |  |  | 170 |  |
| Net gains on deferred compensation plan assets | 84 |  |  | 26 |  |  | 65 |  |  | 153 |  |
| Impairment losses on other investments | (52) |  |  | (5) |  |  | (93) |  |  | (66) |  |
| Other | (43) |  |  | 5 |  |  | 10 |  |  | 5 |  |
|  | $ | 358 |  |  | $ | 226 |  |  | $ | 748 |  |  | $ | 768 |  |

[0000804328-25-000045:notes:28]
[same as prior period, unchanged from 0000804328-25-000031:notes:24]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-25-000045:notes:29]
Note 3. Income Taxes

[0000804328-25-000045:notes:30]
For the third quarter of fiscal 2025, we estimate our annual effective income tax rate to be 11% for fiscal 2025, which is lower than the U.S. federal statutory rate, primarily due to a significant portion of our income qualifying for preferential

[0000804328-25-000045:notes:31]
treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, which includes certain additional benefits from the requirement to capitalize research and development expenditures for federal income tax purposes and a benefit from our federal research and development tax credit. Our effective tax rate of 10% for the third quarter of fiscal 2025 was lower than our estimated annual effective tax rate, primarily due to net discrete tax benefits realized in the third quarter of fiscal 2025.

[0000804328-25-000045:notes:32]
On July 4, 2025, tax reform legislation included in the One Big Beautiful Bill Act (OBBB) was enacted in the United States. The impact of the OBBB is excluded from our estimated annual effective tax rate and provision for income taxes for the third quarter of fiscal 2025 as it is a nonrecognized subsequent event. The OBBB includes significant corporate tax reforms, including the permanent reinstatement of deducting domestic research and development expenditures as incurred beginning in fiscal 2026 (under prior law such expenditures were capitalized and amortized over five years). We expect this change will have a favorable effect on our cash flows from operations due to significantly lower cash tax payments. However, we expect it will adversely affect our total provision for income taxes and results of operations, as these expenditures will no longer result in a deferred tax asset that is established at the statutory rate of 21% rather than the current effective tax rate of 13% after considering the FDII deduction. The legislation also modifies international tax provisions, including changes to the FDII regime. Specifically, it renames FDII as Foreign-Derived Deduction Eligible Income (FDDEI), maintains the current FDDEI effective tax rate of 13% through fiscal 2026 and adjusts the FDDEI effective tax rate to a permanent 14% rate in fiscal 2027 (compared to 16% under prior law).

[0000804328-25-000045:notes:33]
While we continue to evaluate the impact of these tax law changes, we may be subject to the corporate alternative minimum tax of 15% beginning in fiscal 2026, and we are assessing our ability to realize our existing deferred tax assets. As such, our future provision for income taxes and results of operations may be adversely affected (potentially materially).


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-25-000045:notes:34]
[same as prior period, unchanged from 0000804328-25-000031:notes:26]

[0000804328-25-000045:notes:35]
Stock Repurchase Program. During the first quarter of fiscal 2025, we utilized the remaining repurchase authority under the $10.0 billion stock repurchase program announced on October 12, 2021 and we began repurchases under the $15.0 billion stock repurchase program announced on November 6, 2024, which has no expiration date. At June 29, 2025, $9.7 billion remained authorized for repurchase under our stock repurchase program.

[0000804328-25-000045:notes:36]
Shares Outstanding. Shares of common stock outstanding at June 29, 2025 were as follows (in millions):

[0000804328-25-000045:notes:37]
| Balance at September 29, 2024 | 1,113 |  |
| Issued | 12 |  |
| Repurchased | (41) |  |
| Balance at June 29, 2025 | 1,084 |  |

[0000804328-25-000045:notes:38]
[same as prior period, unchanged from 0000804328-25-000031:notes:31]

[0000804328-25-000045:notes:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | June 29,2025 |  | June 23,2024 |
| Dilutive common share equivalents included in diluted shares | 7 |  |  | 18 |  |  | 10 |  |  | 14 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 2 |  |  | — |  |  | 1 |  |  | 5 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-25-000045:notes:40]
Note 5. Commitments and Contingencies

[0000804328-25-000045:notes:41]
Legal and Regulatory Proceedings.

[0000804328-25-000045:notes:42]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the district court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit (Federal Circuit). On September 6, 2024, the Federal Circuit reversed the judgment of the district court, citing certain substantive and procedural issues, and remanded the case to the district court for further proceedings. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-25-000045:notes:43]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (Arm) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with Arm (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. Arm is seeking specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology (which Arm alleges includes our custom Qualcomm Oryon CPU cores). Arm’s complaint also contended that we violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of Arm’s trademarks and sought associated injunctive and declaratory relief; however, Arm dismissed these claims prior to trial. On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm, and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia) and System-on-Chip (SoC) products incorporating such cores are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm (the Qualcomm TLA). A trial was held beginning on December 16, 2024, and on December 20, 2024, the jury found that (i) Qualcomm did not breach the Nuvia ALA and (ii) Qualcomm CPUs that include designs acquired in the Nuvia acquisition are licensed under the Qualcomm ALA. The jury was unable to reach a verdict with respect to Arm’s claim as to whether Nuvia breached the Nuvia ALA. The parties have filed various post-trial motions in this matter, including motions for judgment as a matter of law. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.

[0000804328-25-000045:notes:44]
On April 18, 2024, we filed a separate complaint (captioned QUALCOMM Incorporated v. Arm Ltd.) against Arm in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief. Arm moved to dismiss this complaint, and on October 30, 2024, the court denied Arm’s motion to dismiss. On December 16, 2024, we filed a First Amended Complaint alleging additional causes of action based on Arm improperly seeking to terminate the Qualcomm ALA and improperly publicizing that it was seeking to terminate the Qualcomm ALA. On June 3, 2025, we filed a Second Amended Complaint to add a claim that Arm has breached the Qualcomm TLA by failing to provide license offers at commercially reasonable prices and terms. Arm has moved to dismiss our amended complaint. Trial is scheduled to begin on March 9, 2026.

[0000804328-25-000045:notes:45]
On October 22, 2024, Arm provided us with a notice alleging that we have breached the Qualcomm ALA by marketing products that contain CPUs that Arm alleges use designs, technology and code created by Nuvia employees prior to our acquisition of Nuvia; by seeking support and verification from Arm for additional products that use such alleged designs, technology and code; and by suing Arm for breach of the Qualcomm ALA. Arm’s notice asserts that it will have the right to terminate the Qualcomm ALA if such alleged breaches are not cured within 60 days of such notice. We disagree with Arm’s allegations, including that we are, or have been, in breach of the Qualcomm ALA. On January 8, 2025, Arm notified us that it was withdrawing its October 22, 2024 notice of breach and indicated that it has no current plan to terminate the Qualcomm ALA, while reserving its rights pending the outcome of the ongoing litigation.

[0000804328-25-000045:notes:46]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at June 29, 2025 for contingent losses associated with the matters described

[0000804328-25-000045:notes:47]
above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (for example, certain consumer class action lawsuits in jurisdictions outside the United States, and other matters arising in the ordinary course of our business, including those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-25-000045:notes:48]
[same as prior period, unchanged from 0000804328-25-000031:notes:42]

[0000804328-25-000045:notes:49]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software with advanced connectivity and high-performance, low-power computing technologies for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices, industrial devices and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our Data Center business (formerly referred to as our cloud computing processing initiative).

[0000804328-25-000045:notes:50]
[same as prior period, unchanged from 0000804328-25-000031:notes:44]

[0000804328-25-000045:notes:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | June 29,2025 |  | June 23,2024 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 8,993 |  |  | $ | 8,069 |  |  | $ | 28,546 |  |  | $ | 24,518 |  |
| QTL | 1,318 |  |  | 1,273 |  |  | 4,172 |  |  | 4,051 |  |
| QSI | — |  |  | 2 |  |  | — |  |  | 18 |  |
| Reconciling items | 54 |  |  | 49 |  |  | 295 |  |  | 131 |  |
| Total | $ | 10,365 |  |  | $ | 9,393 |  |  | $ | 33,013 |  |  | $ | 28,718 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 2,671 |  |  | $ | 2,181 |  |  | $ | 8,774 |  |  | $ | 7,062 |  |
| QTL | 942 |  |  | 894 |  |  | 3,028 |  |  | 2,907 |  |
| QSI | 149 |  |  | 14 |  |  | 179 |  |  | 121 |  |
| Reconciling items | (810) |  |  | (810) |  |  | (2,289) |  |  | (2,350) |  |
| Total | $ | 2,952 |  |  | $ | 2,279 |  |  | $ | 9,692 |  |  | $ | 7,740 |  |

[0000804328-25-000045:notes:52]
[same as prior period, unchanged from 0000804328-25-000031:notes:46]

[0000804328-25-000045:notes:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29,2025 |  | June 23,2024 |  | June 29,2025 |  | June 23,2024 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 54 |  |  | $ | 49 |  |  | $ | 152 |  |  | $ | 131 |  |
| Unallocated revenues | — |  |  | — |  |  | 143 |  |  | — |  |
|  | $ | 54 |  |  | $ | 49 |  |  | $ | 295 |  |  | $ | 131 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated revenues | $ | — |  |  | $ | — |  |  | $ | 143 |  |  | $ | — |  |
| Unallocated cost of revenues | (65) |  |  | (54) |  |  | (185) |  |  | (168) |  |
| Unallocated research and development expenses | (595) |  |  | (549) |  |  | (1,752) |  |  | (1,664) |  |
| Unallocated selling, general and administrative expenses | (182) |  |  | (175) |  |  | (554) |  |  | (588) |  |
| Unallocated other income | — |  |  | (75) |  |  | — |  |  | (47) |  |
| Unallocated interest expense | (168) |  |  | (168) |  |  | (493) |  |  | (518) |  |
| Unallocated investment and other income, net | 210 |  |  | 213 |  |  | 567 |  |  | 648 |  |
| Nonreportable segments | (10) |  |  | (2) |  |  | (15) |  |  | (13) |  |
|  | $ | (810) |  |  | $ | (810) |  |  | $ | (2,289) |  |  | $ | (2,350) |  |

[0000804328-25-000045:notes:54]
Certain revenues were not allocated to our segments in our management reports because they were not considered in evaluating segment results. Unallocated revenues in the first nine months of fiscal 2025 were comprised of licensing revenues resulting from a settlement of a licensing dispute in the second quarter of fiscal 2025.


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-25-000045:notes:55]
[same as prior period, unchanged from 0000804328-25-000031:notes:49]

[0000804328-25-000045:notes:56]
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at June 29, 2025 (in millions):

[0000804328-25-000045:notes:57]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 2,932 |  |  | $ | 257 |  |  | $ | — |  |  | $ | 3,189 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 2,990 |  |  | — |  |  | 2,990 |  |
| Mortgage- and asset-backed securities | — |  |  | 813 |  |  | — |  |  | 813 |  |
| U.S. Treasury securities and government-related securities | 238 |  |  | 183 |  |  | — |  |  | 421 |  |
| Equity securities | 339 |  |  | — |  |  | — |  |  | 339 |  |
| Total marketable securities | 577 |  |  | 3,986 |  |  | — |  |  | 4,563 |  |
| Derivative instruments | — |  |  | 91 |  |  | — |  |  | 91 |  |
| Other investments (1) | 1,052 |  |  | — |  |  | 34 |  |  | 1,086 |  |
| Total assets measured at fair value | $ | 4,561 |  |  | $ | 4,334 |  |  | $ | 34 |  |  | $ | 8,929 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 139 |  |  | $ | — |  |  | $ | 139 |  |
| Other liabilities (1) | 1,049 |  |  | — |  |  | — |  |  | 1,049 |  |
| Total liabilities measured at fair value | $ | 1,049 |  |  | $ | 139 |  |  | $ | — |  |  | $ | 1,188 |  |

[0000804328-25-000045:notes:58]
[same as prior period, unchanged from 0000804328-25-000031:notes:52]

[0000804328-25-000045:notes:59]
Marketable Securities. At June 29, 2025 and September 29, 2024, our marketable securities were all classified as current and were primarily comprised of available-for-sale debt securities (the vast majority of which were corporate bonds and notes).

[0000804328-25-000045:notes:60]
[same as prior period, unchanged from 0000804328-25-000031:notes:55]

[0000804328-25-000045:notes:61]
|  | June 29,2025 |
| Years to Maturity |  |
| Less than one year | $ | 1,066 |  |
| One to five years | 2,342 |  |
| Five to ten years | 3 |  |
| No single maturity date | 813 |  |
| Total | $ | 4,224 |  |

[0000804328-25-000045:notes:62]
[same as prior period, unchanged from 0000804328-25-000031:notes:57]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000804328-25-000045:notes:63]
Note 8. Acquisitions

[0000804328-25-000045:notes:64]
Pending. On June 9, 2025, we announced that we reached an agreement with Alphawave IP Group plc (Alphawave) regarding the terms and conditions of a recommended acquisition by Aqua Acquisition Sub LLC, an indirect wholly-owned subsidiary of Qualcomm Incorporated, for the entire issued and to be issued ordinary share capital of Alphawave at an implied enterprise value of approximately $2.4 billion (as of the announcement date). The purchase price will be paid in cash or, if validly elected by eligible shareholders of Alphawave, in shares of our common stock or securities exchangeable for shares of our common stock. Alphawave is a developer of high-speed wired connectivity and compute technologies delivering IP, custom silicon, connectivity products and chiplets. The acquisition aims to further accelerate, and provide key assets for, our expansion into data centers. This acquisition is expected to complete during the first calendar quarter of 2026, subject to certain conditions, including receipt of regulatory approvals and approval from the requisite majority of Alphawave’s shareholders. In connection with the pending acquisition, we agreed to restrict the use of $2.3 billion in cash, which is presented as restricted cash on our condensed consolidated balance sheets, for the purpose of satisfying payment of the consideration to effect the acquisition.

[0000804328-25-000045:notes:65]
Completed. During the first nine months of fiscal 2025, we acquired seven businesses for a total accounting purchase price of $668 million. These acquisitions were primarily for the purpose of executing on certain products and technology that support our diversification strategy in QCT industrial IoT and automotive. The acquired assets primarily consisted of $120 million of intangible assets and $532 million of goodwill, which was allocated to our QCT segment and which is primarily attributable to assembled workforce and certain synergies expected to arise after the acquisition.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000804328-25-000045:notes:66]
On June 9, 2025, Cristiano Amon, our President and Chief Executive Officer, acting as trustee on behalf of his family trust, adopted a Rule 10b5-1 trading arrangement (as defined in Item 408 of Regulation S-K) providing for the sale of up to 150,000 shares of our common stock. The plan is scheduled to terminate on August 31, 2026.
