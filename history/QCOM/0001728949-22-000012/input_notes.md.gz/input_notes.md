# QCOM notes — 0001728949-22-000012


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-22-000012:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 26, 2021. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 26, 2021 and December 27, 2020 included 13 weeks.

[0001728949-22-000012:notes:2]
[same as prior period, unchanged from 0001728949-21-000066:notes:2]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-22-000012:notes:3]
[same as prior period, unchanged from 0001728949-21-000066:notes:9]

[0001728949-22-000012:notes:4]
| Inventories (in millions) |  |  |  |
|  | December 26,2021 |  | September 26,2021 |
| Raw materials | $ | 243 |  |  | $ | 267 |  |
| Work-in-process | 2,125 |  |  | 1,475 |  |
| Finished goods | 1,493 |  |  | 1,486 |  |
|  | $ | 3,861 |  |  | $ | 3,228 |  |

[0001728949-22-000012:notes:5]
Revenues. We disaggregate our revenues by segment (Note 6), by products and services (as presented on our condensed consolidated statement of operations), and for our QCT (Qualcomm CDMA Technologies) segment, by revenue stream, which is based on industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s (Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets. QCT revenue streams were as follows (in millions):

[0001728949-22-000012:notes:6]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | December 26,2021 |  | December 27,2020 |  |  |  |  |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 5,983 |  |  | $ | 4,216 |  |  |  |  |  |
| RFFE (2) |  |  |  |  |  |  |  |  | 1,132 |  |  | 1,061 |  |  |  |  |  |
| Automotive (3) |  |  |  |  |  |  |  |  | 256 |  |  | 212 |  |  |  |  |  |
| IoT (internet of things) (4) |  |  |  |  |  |  |  |  | 1,476 |  |  | 1,044 |  |  |  |  |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 8,847 |  |  | $ | 6,533 |  |  |  |  |  |

[0001728949-22-000012:notes:7]
[same as prior period, unchanged from 0001728949-21-000066:notes:16]

[0001728949-22-000012:notes:8]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in mobile handsets) and excludes radio frequency transceiver components.

[0001728949-22-000012:notes:9]
(3) Includes revenues from products sold for use in automobiles, including telematics, connectivity and digital cockpit.

[0001728949-22-000012:notes:10]
(4) Primarily includes products sold for use in the following industries and applications: consumer (including computing, voice and music and XR), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, transportation and logistics and utilities).

[0001728949-22-000012:notes:11]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were as follows (in millions):

[0001728949-22-000012:notes:12]
|  | Three Months Ended |
|  | December 26,2021 (1) |  | December 27,2020 (2) |
| Revenues recognized from previously satisfied performance obligations | $ | 242 |  |  | $ | 110 |  |

[0001728949-22-000012:notes:13]
(1) Primarily related to certain QCT sales-based royalty revenues related to system software, QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due) and certain QCT customer incentives.

[0001728949-22-000012:notes:14]
(2) Primarily related to QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due) and certain QCT customer incentives.

[0001728949-22-000012:notes:15]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In the three months ended December 26, 2021 and December 27, 2020, we recognized revenues of $187 million and $185 million, respectively, that were recorded as unearned revenues at September 26, 2021 and September 27, 2020, respectively.

[0001728949-22-000012:notes:16]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront. At December 26, 2021, we had $969 million of remaining performance obligations, of which $508 million, $332 million, $94 million, $33 million and $2 million was expected to be recognized as revenues for the remainder of fiscal 2022 and each of the subsequent four years from fiscal 2023 through 2026, respectively, and no amounts expected thereafter.

[0001728949-22-000012:notes:17]
[same as prior period, unchanged from 0001728949-21-000066:notes:23]

[0001728949-22-000012:notes:18]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |  |  |
|  | December 26,2021 |  | December 27,2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer/licensee (x) | 26 | % |  | 34 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer/licensee (y) | 19 |  |  | 13 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer/licensee (z) | * |  | 10 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001728949-22-000012:notes:19]
[same as prior period, unchanged from 0001728949-21-000066:notes:25]

[0001728949-22-000012:notes:20]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  |  |  |  |
| Interest and dividend income | $ | 17 |  |  | $ | 21 |  |  |  |  |  |
| Net gains on marketable securities | 17 |  |  | 118 |  |  |  |  |  |
| Net gains on other investments | 93 |  |  | 34 |  |  |  |  |  |
| Net gains on deferred compensation plan assets | 13 |  |  | 54 |  |  |  |  |  |
| Impairment losses on other investments | (1) |  |  | (1) |  |  |  |  |  |
| Net (losses) gains on derivative investments | (13) |  |  | 9 |  |  |  |  |  |
| Equity in net earnings (losses) of investees | 7 |  |  | (2) |  |  |  |  |  |
| Net gains (losses) on foreign currency transactions | 7 |  |  | (14) |  |  |  |  |  |
|  | $ | 140 |  |  | $ | 219 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-22-000012:notes:21]
Income Taxes
We estimate our annual effective income tax rate to be 14% for fiscal 2022, which is lower than the U.S. federal statutory rate primarily due to a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, excess tax benefits associated with share-based awards and benefits from our federal research and development tax credit. Our effective tax rate of 12% for the first quarter of fiscal 2022 was lower than our estimated annual effective tax rate of 14% primarily due to $103 million of discrete net tax benefits recorded in the first quarter of fiscal 2022, which principally related to excess tax benefits associated with share-based awards that vested in the first fiscal quarter. Our effective tax rate of 6% for the first quarter of fiscal 2021 included $212 million of discrete net tax benefits recorded in the first quarter of fiscal 2021, which principally related to excess tax benefits associated with share-based awards that vested in that quarter, foreign currency gains on a noncurrent receivable related to our refund claim of Korean withholding tax and valuation allowance release on foreign tax credit carryforwards.

[0001728949-22-000012:notes:22]
Unrecognized tax benefits were $2.1 billion at both December 26, 2021 and September 26, 2021 and primarily related to our refund claim of Korean withholding tax. If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We expect that the total amount of unrecognized tax benefits at December 26, 2021 will increase in the next 12 months as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-22-000012:notes:23]
Capital Stock
Stock Repurchase Program. On October 12, 2021, we announced a new $10.0 billion stock repurchase program, which was in addition to the then-remaining repurchase authority of $0.9 billion under the previous program. The stock repurchase programs have no expiration date. At December 26, 2021, $10.1 billion remained authorized for repurchase under our stock repurchase programs.

[0001728949-22-000012:notes:24]
Shares Outstanding. Shares of common stock outstanding at December 26, 2021 were as follows (in millions):

[0001728949-22-000012:notes:25]
|  | Three Months Ended |
|  | December 26,2021 |
| Balance at beginning of period | 1,125 |  |
| Issued | 8 |  |
| Repurchased | (8) |  |
| Balance at end of period | 1,125 |  |

[0001728949-22-000012:notes:26]
Dividends. On January 18, 2022, we announced a cash dividend of $0.68 per share on our common stock, payable on March 24, 2022 to stockholders of record as of the close of business on March 3, 2022.

[0001728949-22-000012:notes:27]
[same as prior period, unchanged from 0001728949-21-000066:notes:34]

[0001728949-22-000012:notes:28]
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  |  |  |  |
| Dilutive common share equivalents included in diluted shares | 18 |  |  | 22 |  |  |  |  |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | — |  |  | — |  |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-22-000012:notes:29]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0001728949-22-000012:notes:30]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions. On July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint, and on March 18, 2019, the court denied our motion. On January 15, 2020, we filed a motion for judgment on the pleadings. A hearing on the motion was held on February 2, 2022. We believe the plaintiffs’ claims are without merit.

[0001728949-22-000012:notes:31]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our then current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint, and on March 10, 2020, the court granted our motion. On May 11, 2020, the plaintiffs filed a second amended complaint, and on October 8, 2020, the court granted our motion to dismiss the case with prejudice. On November 7, 2020, the plaintiffs filed a notice of appeal with the United States Court of Appeals for the Ninth Circuit (Ninth Circuit), and a hearing on the appeal was held on November 16, 2021. The Ninth Circuit has not yet issued a ruling. We believe the plaintiffs’ claims are without merit.

[0001728949-22-000012:notes:32]
Consumer Class Action Lawsuits: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and on September 27, 2018, the court granted that motion. On January 23, 2019, the Ninth

[0001728949-22-000012:notes:33]
Circuit granted us permission to appeal the court’s class certification order, and on January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit, and on September 29, 2021, the Ninth Circuit vacated the district court’s class certification order, ruling that the court had failed to correctly assess the propriety of applying California law to a nationwide class. The Ninth Circuit remanded the case to the district court and instructed the court to consider the effect of United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated (which the Ninth Circuit decided in favor of Qualcomm in August 2020) on this case. We believe the plaintiffs’ claims are without merit.

[0001728949-22-000012:notes:34]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

[0001728949-22-000012:notes:35]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision has subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. From January 24, 2022 to January 25, 2022, the court held a hearing on various summary judgment and evidentiary motions. The court has not yet ruled on the motions, and no trial date has been set. We believe that ParkerVision’s claims are without merit.

[0001728949-22-000012:notes:36]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0001728949-22-000012:notes:37]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019, and on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-22-000012:notes:38]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of its investigation, but we believe it concerns our business practices in connection with our sale of radio frequency front-end (RFFE) components. We continue to cooperate with the KFTC as it conducts its investigation. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-22-000012:notes:39]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision finding that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

[0001728949-22-000012:notes:40]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 26, 2021, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $283 million and included in other current liabilities.

[0001728949-22-000012:notes:41]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. From May 4, 2021 to May 6, 2021, a hearing on our appeal was held before the court. The court has not yet issued a ruling. We believe that our business practices do not violate the EU competition rules.

[0001728949-22-000012:notes:42]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At December 26, 2021, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.2 billion and included in other current liabilities.

[0001728949-22-000012:notes:43]
Contingent Losses and Other Considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. Other than with respect to the EC fines, we have not recorded any accrual at December 26, 2021 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-22-000012:notes:44]
Segment Information
We are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarity of activities within our operating segments, such as the nature of products, the level of shared products, technology and other resources, production processes and customer base. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies, including RFFE, for use in mobile devices, automotive systems for telematics, connectivity and digital cockpit and IoT including wireless networks, broadband gateway equipment, consumer electronic devices and industrial devices. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our cloud AI inference processing initiative and other technology and service initiatives.

[0001728949-22-000012:notes:45]
Our CODM allocates resources to and evaluates the performance of our segments based on revenues and earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense, certain net investment income, certain share-based compensation, gains and losses on our deferred compensation plan liabilities and related assets and certain research and development expenses, certain selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories and property, plant and equipment to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, asset impairment charges and awards, settlements and/or damages arising from legal or regulatory matters. Our CODM does not evaluate our operating segments using discrete asset information.

[0001728949-22-000012:notes:46]
[same as prior period, unchanged from 0001728949-21-000066:notes:54]

[0001728949-22-000012:notes:47]
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 8,847 |  |  | $ | 6,533 |  |  |  |  |  |
| QTL | 1,818 |  |  | 1,660 |  |  |  |  |  |
| QSI | 8 |  |  | 9 |  |  |  |  |  |
| Reconciling items | 32 |  |  | 33 |  |  |  |  |  |
| Total | $ | 10,705 |  |  | $ | 8,235 |  |  |  |  |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 3,114 |  |  | $ | 1,919 |  |  |  |  |  |
| QTL | 1,406 |  |  | 1,270 |  |  |  |  |  |
| QSI | 122 |  |  | 158 |  |  |  |  |  |
| Reconciling items | (777) |  |  | (743) |  |  |  |  |  |
| Total | $ | 3,865 |  |  | $ | 2,604 |  |  |  |  |  |

[0001728949-22-000012:notes:48]
[same as prior period, unchanged from 0001728949-21-000066:notes:56]

[0001728949-22-000012:notes:49]
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 32 |  |  | $ | 33 |  |  |  |  |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of revenues | $ | (53) |  |  | $ | (74) |  |  |  |  |  |
| Unallocated research and development expenses | (453) |  |  | (406) |  |  |  |  |  |
| Unallocated selling, general and administrative expenses | (152) |  |  | (178) |  |  |  |  |  |
| Unallocated interest expense | (139) |  |  | (142) |  |  |  |  |  |
| Unallocated investment and other income, net | 23 |  |  | 71 |  |  |  |  |  |
| Nonreportable segments | (3) |  |  | (14) |  |  |  |  |  |
|  | $ | (777) |  |  | $ | (743) |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001728949-22-000012:notes:50]
Acquisitions 
Completed. On March 16, 2021 (the Closing Date), we completed the acquisition of NuVia, Inc. (NUVIA) for $1.1 billion (net of $174 million cash acquired), substantially all of which was paid in cash. In connection with the acquisition, we assumed or replaced unvested NUVIA stock awards with Qualcomm stock awards with an estimated fair value of $258 million, which have post-acquisition requisite service periods of up to four years. NUVIA has certain in-process technologies and is comprised of a CPU (central processing unit) and technology design team with expertise in high performance processors, SoC (system-on-chip) and power management for compute-intensive devices and applications. Upon completion of development, NUVIA’s technologies are expected to be integrated into certain QCT products. We recorded $885 million of goodwill which is not deductible for tax purposes and was allocated to our QCT segment for annual impairment testing purposes. Goodwill is primarily attributable to assembled workforce and certain revenue and cost synergies expected to arise after the acquisition. We also recorded a $247 million in-process research and development intangible asset related to a single project, which is expected to be completed in fiscal 2023 and, upon completion, will be amortized over its useful life, which is expected to be seven years. Our results of operations for fiscal 2021 included the operating results of NUVIA since the Closing Date, the amounts of which were not material.

[0001728949-22-000012:notes:51]
Pending. On October 4, 2021, we and SSW Partners, a New York-based investment partnership, entered into a definitive agreement (the Merger Agreement) to acquire Veoneer, Inc. (Veoneer) for $37.00 per share in cash, which values the estimated total cash consideration to be paid to Veoneer’s shareholders, inclusive of amounts expected to be paid at closing for Veoneer’s outstanding equity awards and convertible senior notes due 2024, at approximately $4.5 billion. At closing, SSW Partners will acquire all of the outstanding capital stock of Veoneer, shortly after which it will sell Veoneer’s Arriver business to Qualcomm and retain Veoneer’s Tier-1 automotive supplier businesses. Following the close of the Arriver business sale, we intend to incorporate Arriver’s computer vision, drive policy and driver assistance technologies into our Snapdragon automotive platform to deliver an ADAS (advanced driver assistance systems) platform for automakers and Tier-1 automotive suppliers. The Merger Agreement was approved by Veoneer’s shareholders on December 16, 2021. The acquisition is subject to certain other closing conditions. The Merger Agreement also provides that Qualcomm and SSW Partners are not required to complete the acquisition prior to April 4, 2022. Subject to the satisfaction of these conditions, the acquisition is expected to close in 2022.

[0001728949-22-000012:notes:52]
We will fund substantially all of the cash consideration that SSW Partners will pay to Veoneer’s shareholders in exchange for (i) our right to acquire, and SSW Partners’ obligation to sell to us, Veoneer’s Arriver business and (ii) our right to receive a portion of the proceeds upon the sale of Veoneer’s Tier-1 automotive supplier businesses by SSW Partners. In addition, we entered into a loan facility under which we will provide financing to Veoneer to support the Arriver business, to the extent requested by Veoneer, in the event that the acquisition has not closed, for the quarter commencing April 1, 2022 and each of the two subsequent quarters of up to $120 million per quarter (up to $360 million in the aggregate), which amounts may be forgiven in certain circumstances in which the Merger Agreement is terminated. An additional amount of up to $120 million for the first quarter of calendar 2023 may be provided under the loan facility if the final outside date, as defined in the Merger Agreement, is extended to April 4, 2023.
In accordance with the Merger Agreement, we paid to Magna International Inc. (Magna) a termination fee of $110 million in the first quarter of fiscal 2022 on behalf of Veoneer in connection with the termination of the previously announced agreement and plan of merger, dated as of July 22, 2021, by and among Magna and Veoneer. The termination fee was recorded in other noncurrent assets as advanced consideration for the acquisition at December 26, 2021 and was classified as cash used by investing activities in the condensed consolidated statements of cash flows in the three months ended December 26, 2021.


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-22-000012:notes:53]
Fair Value Measurements
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at December 26, 2021 (in millions):

[0001728949-22-000012:notes:54]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 3,452 |  |  | $ | 1,376 |  |  | $ | — |  |  | $ | 4,828 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 3,856 |  |  | — |  |  | 3,856 |  |
| Equity securities | 700 |  |  | — |  |  | — |  |  | 700 |  |
| Mortgage- and asset-backed securities | — |  |  | 137 |  |  | — |  |  | 137 |  |
| U.S. Treasury securities and government-related securities | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total marketable securities | 700 |  |  | 4,003 |  |  | — |  |  | 4,703 |  |
| Derivative instruments | — |  |  | 46 |  |  | — |  |  | 46 |  |
| Other investments | 751 |  |  | — |  |  | 50 |  |  | 801 |  |
| Total assets measured at fair value | $ | 4,903 |  |  | $ | 5,425 |  |  | $ | 50 |  |  | $ | 10,378 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 117 |  |  | $ | — |  |  | $ | 117 |  |
| Other liabilities | 751 |  |  | — |  |  | — |  |  | 751 |  |
| Total liabilities measured at fair value | $ | 751 |  |  | $ | 117 |  |  | $ | — |  |  | $ | 868 |  |

[0001728949-22-000012:notes:55]
Long-term Debt. At December 26, 2021, the aggregate fair value of our outstanding floating- and fixed-rate notes, based on Level 2 inputs, was approximately $16.9 billion.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-22-000012:notes:56]
Marketable Securities
Our marketable securities were all classified as current and were comprised as follows (in millions):

[0001728949-22-000012:notes:57]
|  | December 26,2021 |  | September 26,2021 |  |  |  |  |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 3,856 |  |  | $ | 4,459 |  |  |  |  |  |
| Mortgage- and asset-backed securities | 137 |  |  | 147 |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 10 |  |  | 10 |  |  |  |  |  |
| Total available-for-sale debt securities | 4,003 |  |  | 4,616 |  |  |  |  |  |
| Equity securities | 700 |  |  | 682 |  |  |  |  |  |
| Total marketable securities | $ | 4,703 |  |  | $ | 5,298 |  |  |  |  |  |

[0001728949-22-000012:notes:58]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001728949-22-000012:notes:59]
|  | December 26,2021 |
| Years to Maturity |  |
| Less than one year | $ | 566 |  |
| One to five years | 3,300 |  |
| No single maturity date | 137 |  |
| Total | $ | 4,003 |  |

[0001728949-22-000012:notes:60]
Debt securities with no single maturity date included mortgage- and asset-backed securities.
