# QCOM MD&A — 0001728949-22-000012


## mdna

[0001728949-22-000012:mdna:1]
[same as prior period, unchanged from 0001728949-21-000066:mdna:1]

[0001728949-22-000012:mdna:2]
This information should be read in conjunction with the condensed consolidated financial statements and the notes thereto included in “Part I, Item 1” of this Quarterly Report and with “Management’s Discussion and Analysis of Financial Condition and Results of Operations” for the fiscal year ended September 26, 2021 contained in our 2021 Annual Report on Form 10-K.

[0001728949-22-000012:mdna:3]
This Quarterly Report (including but not limited to this section titled Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates,” “may,” “will,” “would” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report. Additionally, statements concerning future matters such as our future business, prospects, results of operations, financial condition or research and development or technology investments; new or enhanced products, services or technologies; emerging industries or business models; design wins or product launches; industry, market, business, product, technology, commercial, competitive or consumer trends, including seasonality; the 5G transition; our expectations regarding future demand or supply conditions; strategic investments or acquisitions, and the anticipated timing or benefits thereof; potential impacts of the COVID-19 pandemic, legal or regulatory matters, U.S./China trade or national security tensions or vertical integration by our customers; competition; and other statements regarding matters that are not historical are also forward-looking statements.

[0001728949-22-000012:mdna:4]
First Quarter Fiscal 2022 Overview

[0001728949-22-000012:mdna:5]
Revenues for the first quarter of fiscal 2022 were $10.7 billion, an increase of 30% compared to the year ago quarter, with net income of $3.4 billion, an increase of 38% compared to the year ago quarter. Highlights from the first quarter of fiscal 2022 included:

[0001728949-22-000012:mdna:6]
•QCT revenues increased by 35% in the first quarter of fiscal 2022 compared to the year ago quarter, primarily due to an increase in average selling prices and favorable mix toward higher-tier 5G products in handsets, in part reflecting demand from certain Chinese OEMs as they continue to gain device share, along with higher IoT revenues.

[0001728949-22-000012:mdna:7]
•QTL revenues increased by 10% in the first quarter of fiscal 2022 compared to the year ago quarter, primarily due to higher estimated revenues per unit, which was primarily driven by favorable mix, including 5G.

[0001728949-22-000012:mdna:8]
•On October 4, 2021, we and SSW Partners, a New York-based investment partnership, entered into a definitive agreement to acquire Veoneer, Inc. (Veoneer) for $37.00 per share in cash, which values the estimated total cash consideration to be paid to Veoneer’s shareholders, inclusive of amounts expected to be paid at closing for Veoneer’s outstanding equity awards and convertible senior notes due 2024, at approximately $4.5 billion. At closing, SSW Partners will acquire all of the outstanding capital stock of Veoneer, shortly after which it will sell Veoneer’s Arriver business to Qualcomm and retain Veoneer’s Tier-1 automotive supplier businesses. Following close of the Arriver business sale, we intend to incorporate Arriver’s computer vision, drive policy and driver assistance technologies into our Snapdragon automotive platform to deliver an ADAS (advanced driver assistance systems) platform for automakers and Tier-1 automotive suppliers. The acquisition is expected to close in 2022, subject to certain closing conditions.

[0001728949-22-000012:mdna:9]
[same as prior period, unchanged from 0001728949-21-000066:mdna:8]

[0001728949-22-000012:mdna:10]
[same as prior period, unchanged from 0001728949-21-000066:mdna:9]

[0001728949-22-000012:mdna:11]
21

[0001728949-22-000012:mdna:12]
[same as prior period, unchanged from 0001728949-21-000066:mdna:10]

[0001728949-22-000012:mdna:13]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering and research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001728949-22-000012:mdna:14]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when licensees’ sales occur. These trends may or may not continue in the future. Further, the trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings.

[0001728949-22-000012:mdna:15]
[same as prior period, unchanged from 0001728949-21-000066:mdna:14]

[0001728949-22-000012:mdna:16]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  | Change |  |  |  |  |  |  |
| Equipment and services | $ | 8,682 |  |  | $ | 6,442 |  |  | $ | 2,240 |  |  |  |  |  |  |  |
| Licensing | 2,023 |  |  | 1,793 |  |  | 230 |  |  |  |  |  |  |  |
|  | $ | 10,705 |  |  | $ | 8,235 |  |  | $ | 2,470 |  |  |  |  |  |  |  |

[0001728949-22-000012:mdna:17]
First quarter 2022 vs. 2021

[0001728949-22-000012:mdna:18]
The increase in revenues in the first quarter of fiscal 2022 was primarily due to:

[0001728949-22-000012:mdna:19]
+    $2.2 billion in higher equipment and services revenues from our QCT segment

[0001728949-22-000012:mdna:20]
+    $158 million in higher licensing revenues from our QTL segment

[0001728949-22-000012:mdna:21]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  | Change |  |  |  |  |  |  |
| Cost of revenues | $ | 4,303 |  |  | $ | 3,489 |  |  | $ | 814 |  |  |  |  |  |  |  |
| Gross margin | 60 | % |  | 58 | % |  |  |  |  |  |  |  |  |

[0001728949-22-000012:mdna:22]
First quarter 2022 vs. 2021

[0001728949-22-000012:mdna:23]
Gross margin percentage increased in the first quarter of fiscal 2022 primarily due to:

[0001728949-22-000012:mdna:24]
+    increase in QCT gross margin

[0001728949-22-000012:mdna:25]
-    decrease in higher margin QTL licensing revenues in proportion to QCT revenues

[0001728949-22-000012:mdna:26]
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  | Change |  |  |  |  |  |  |
| Research and development | $ | 1,930 |  |  | $ | 1,653 |  |  | $ | 277 |  |  |  |  |  |  |  |
| % of revenues | 18 | % |  | 20 | % |  |  |  |  |  |  |  |  |

[0001728949-22-000012:mdna:27]
First quarter 2022 vs. 2021

[0001728949-22-000012:mdna:28]
The increase in research and development expenses in the first quarter of fiscal 2022 was primarily due to:

[0001728949-22-000012:mdna:29]
+    $197 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), primarily driven by an increase in employee-related expenses

[0001728949-22-000012:mdna:30]
+    $91 million increase in share-based compensation expense

[0001728949-22-000012:mdna:31]
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  | Change |  |  |  |  |  |  |
| Selling, general and administrative | $ | 608 |  |  | $ | 567 |  |  | $ | 41 |  |  |  |  |  |  |  |
| % of revenues | 6 | % |  | 7 | % |  |  |  |  |  |  |  |  |

[0001728949-22-000012:mdna:32]
First quarter 2022 vs. 2021

[0001728949-22-000012:mdna:33]
The increase in selling, general and administrative expenses in the first quarter of fiscal 2022 was primarily due to:

[0001728949-22-000012:mdna:34]
+    $69 million increase in employee-related expenses

[0001728949-22-000012:mdna:35]
-    $29 million decrease in expenses driven by revaluation of our deferred compensation obligation on lower relative stock market performance (which resulted in a corresponding decrease in net gains on deferred compensation plan assets within investment and other income, net due to the revaluation of the related assets)

[0001728949-22-000012:mdna:36]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  | Change |  |  |  |  |  |  |
| Interest expense | $ | 139 |  |  | $ | 141 |  |  | $ | (2) |  |  |  |  |  |  |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 17 |  |  | $ | 21 |  |  | $ | (4) |  |  |  |  |  |  |  |
| Net gains on marketable securities | 17 |  |  | 118 |  |  | (101) |  |  |  |  |  |  |  |
| Net gains on other investments | 93 |  |  | 34 |  |  | 59 |  |  |  |  |  |  |  |
| Net gains on deferred compensation plan assets | 13 |  |  | 54 |  |  | (41) |  |  |  |  |  |  |  |
| Impairment losses on other investments | (1) |  |  | (1) |  |  | — |  |  |  |  |  |  |  |
| Net (losses) gains on derivative instruments | (13) |  |  | 9 |  |  | (22) |  |  |  |  |  |  |  |
| Equity in net earnings (losses) of investees | 7 |  |  | (2) |  |  | 9 |  |  |  |  |  |  |  |
| Net gains (losses) on foreign currency transactions | 7 |  |  | (14) |  |  | 21 |  |  |  |  |  |  |  |
|  | $ | 140 |  |  | $ | 219 |  |  | $ | (79) |  |  |  |  |  |  |  |

[0001728949-22-000012:mdna:37]
[same as prior period, unchanged from 0001728949-21-000066:mdna:57]

[0001728949-22-000012:mdna:38]
[same as prior period, unchanged from 0001728949-21-000066:mdna:58]

[0001728949-22-000012:mdna:39]
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  |  |  |  |
| Expected income tax provision at federal statutory tax rate | $ | 812 |  |  | $ | 547 |  |  |  |  |  |
| Excess tax benefit associated with share-based awards | (188) |  |  | (163) |  |  |  |  |  |
| Benefit from foreign-derived intangible income (FDII) deduction | (140) |  |  | (75) |  |  |  |  |  |
| Benefit related to the research and development tax credit | (58) |  |  | (59) |  |  |  |  |  |
| Foreign currency loss (gains) related to foreign withholding tax receivable | 12 |  |  | (79) |  |  |  |  |  |
| Other | 28 |  |  | (22) |  |  |  |  |  |
| Income tax expense | $ | 466 |  |  | $ | 149 |  |  |  |  |  |
| Effective tax rate | 12 | % |  | 6 | % |  |  |  |  |

[0001728949-22-000012:mdna:40]
We estimate our annual effective income tax rate to be 14% for fiscal 2022, which is lower than the U.S. federal statutory rate, primarily due to a significant portion of our income qualifying for preferential treatment as FDII at a 13% effective tax rate, excess tax benefits associated with share-based awards and benefits from our federal research and development tax credit.

[0001728949-22-000012:mdna:41]
The current U.S. presidential administration and Congress have proposed to increase U.S. tax rates and/or eliminate or reduce the FDII deduction. Substantially all of our income is taxable in the U.S., of which a significant portion qualifies for preferential treatment as FDII. If such proposals are enacted into law, our provision for income taxes, results of operations and cash flows would be adversely (potentially materially) affected.

[0001728949-22-000012:mdna:42]
[same as prior period, unchanged from 0001728949-21-000066:mdna:64]

[0001728949-22-000012:mdna:43]
The following should be read in conjunction with our financial results for the first quarter of fiscal 2022 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0001728949-22-000012:mdna:44]
[same as prior period, unchanged from 0001728949-21-000066:mdna:66]

[0001728949-22-000012:mdna:45]
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  | Change |  |  |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets (1) | $ | 5,983 |  |  | $ | 4,216 |  |  | $ | 1,767 |  |  |  |  |  |  |  |
| RFFE (2) | 1,132 |  |  | 1,061 |  |  | 71 |  |  |  |  |  |  |  |
| Automotive (3) | 256 |  |  | 212 |  |  | 44 |  |  |  |  |  |  |  |
| IoT (internet of things) (4) | 1,476 |  |  | 1,044 |  |  | 432 |  |  |  |  |  |  |  |
| Total revenues | $ | 8,847 |  |  | $ | 6,533 |  |  | $ | 2,314 |  |  |  |  |  |  |  |
| EBT (5) | $ | 3,114 |  |  | $ | 1,919 |  |  | $ | 1,195 |  |  |  |  |  |  |  |
| EBT as a % of revenues | 35 | % |  | 29 | % |  | 6 points |  |  |  |  |  |  |

[0001728949-22-000012:mdna:46]
[same as prior period, unchanged from 0001728949-21-000066:mdna:68]

[0001728949-22-000012:mdna:47]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in mobile handsets) and excludes radio frequency transceiver components.

[0001728949-22-000012:mdna:48]
(3) Includes revenues from products sold for use in automobiles, including telematics, connectivity and digital cockpit.

[0001728949-22-000012:mdna:49]
(4) Primarily includes products sold for use in the following industries and applications: consumer (including computing, voice and music and XR), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, transportation and logistics and utilities).

[0001728949-22-000012:mdna:50]
[same as prior period, unchanged from 0001728949-21-000066:mdna:72]

[0001728949-22-000012:mdna:51]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $8.6 billion and $6.4 billion in the first quarter of fiscal 2022 and 2021, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of

[0001728949-22-000012:mdna:52]
our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets.

[0001728949-22-000012:mdna:53]
First quarter 2022 vs. 2021

[0001728949-22-000012:mdna:54]
The increase in QCT revenues in the first quarter of fiscal 2022 was primarily due to:

[0001728949-22-000012:mdna:55]
+    higher handsets revenues, primarily driven by $1.9 billion in higher revenues per chipset, which was primarily due to increases in average selling prices and favorable mix toward higher-tier 5G products, particularly from certain Chinese OEMs as they continue to gain device share

[0001728949-22-000012:mdna:56]
[same as prior period, unchanged from 0001728949-21-000066:mdna:78]

[0001728949-22-000012:mdna:57]
+    higher automotive revenues, primarily driven by an increase in demand for digital cockpit products

[0001728949-22-000012:mdna:58]
+    higher IoT revenues, primarily driven by a $245 million increase in revenues per unit due to an increase in average selling prices and favorable mix primarily in consumer products and a $187 million increase in demand across edge networking and industrial products

[0001728949-22-000012:mdna:59]
QCT EBT as a percentage of revenues increased in the first quarter of fiscal 2022 primarily due to:

[0001728949-22-000012:mdna:60]
[same as prior period, unchanged from 0001728949-21-000066:mdna:82]

[0001728949-22-000012:mdna:61]
+    higher gross margin percentage, primarily driven by higher average selling prices and favorable mix due to an increase in demand for 5G products, partially offset by higher product costs

[0001728949-22-000012:mdna:62]
[same as prior period, unchanged from 0001728949-21-000066:mdna:83]

[0001728949-22-000012:mdna:63]
[same as prior period, unchanged from 0001728949-21-000066:mdna:93]

[0001728949-22-000012:mdna:64]
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  | Change |  |  |  |  |  |  |
| Licensing revenues | $ | 1,818 |  |  | $ | 1,660 |  |  | $ | 158 |  |  |  |  |  |  |  |
| EBT | 1,406 |  |  | 1,270 |  |  | 136 |  |  |  |  |  |  |  |
| EBT as a % of revenues | 77 | % |  | 77 | % |  | — |  |  |  |  |  |  |

[0001728949-22-000012:mdna:65]
First quarter 2022 vs. 2021

[0001728949-22-000012:mdna:66]
The increase in QTL licensing revenues in the first quarter of fiscal 2022 was primarily due to a $144 million increase in estimated revenues per unit, primarily driven by favorable mix, including 5G.

[0001728949-22-000012:mdna:67]
QTL EBT as a percentage of revenues remained flat in the first quarter of fiscal 2022 primarily due to:

[0001728949-22-000012:mdna:68]
[same as prior period, unchanged from 0001728949-21-000066:mdna:91]

[0001728949-22-000012:mdna:69]
-    higher operating expenses, primarily driven by higher selling, general and administrative expenses

[0001728949-22-000012:mdna:70]
[same as prior period, unchanged from 0001728949-21-000066:mdna:111]

[0001728949-22-000012:mdna:71]
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  | Change |  |  |  |  |  |  |
| Equipment and services revenues | $ | 8 |  |  | $ | 9 |  |  | $ | (1) |  |  |  |  |  |  |  |
| EBT | 122 |  |  | 158 |  |  | (36) |  |  |  |  |  |  |  |

[0001728949-22-000012:mdna:72]
First quarter 2022 vs. 2021

[0001728949-22-000012:mdna:73]
The decrease in QSI EBT in the first quarter of fiscal 2022 was primarily due to a $36 million decrease in net gains on investments.

[0001728949-22-000012:mdna:74]
[same as prior period, unchanged from 0001728949-21-000066:mdna:121]

[0001728949-22-000012:mdna:75]
In the coming years, we expect consumer demand for 3G/4G/5G multimode and 5G products and services to continue to ramp around the world as we continue to transition from 3G/4G multimode and 4G products and services. We believe that 5G will continue to drive adoption of certain technologies that are already commonly used in smartphones by industries and applications beyond mobile handsets, such as automotive and IoT. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing, and a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long-term.

[0001728949-22-000012:mdna:76]
As we look forward to the next several quarters, our business may be impacted by the following key items:

[0001728949-22-000012:mdna:77]
•We expect QCT revenues to continue to be favorably impacted compared to the prior year, reflecting continued strength across handsets, RFFE, automotive and IoT revenue streams.

[0001728949-22-000012:mdna:78]
•While we and the semiconductor industry continue to experience capacity constraints, we have entered into several, and we expect to enter into additional, multi-year capacity purchase commitments with certain suppliers of our integrated circuit products in an effort to secure commitments for future supply, which we expect will allow us to continue to realize benefits from increased demand for integrated circuit products, particularly from certain Chinese OEMs as they continue to gain device share. Despite these realized benefits, there continues to be supply chain complexities and challenges that have prevented, and we expect will continue to prevent, us from securing supply to fully realize the benefits of increased customer demand.

[0001728949-22-000012:mdna:79]
•We expect commercial 5G network deployments and device launches will continue.

[0001728949-22-000012:mdna:80]
[same as prior period, unchanged from 0001728949-21-000066:mdna:127]

[0001728949-22-000012:mdna:81]
[same as prior period, unchanged from 0001728949-21-000066:mdna:128]

[0001728949-22-000012:mdna:82]
[same as prior period, unchanged from 0001728949-21-000066:mdna:129]

[0001728949-22-000012:mdna:83]
•We currently do not expect a significant impact on our results of operations in the future due to COVID-19. The degree to which the COVID-19 pandemic impacts our business, financial condition and results of operations will depend on future developments, which are highly uncertain. See “Risk Factors” in this Quarterly Report, specifically the Risk Factor titled “The coronavirus (COVID-19) pandemic had an adverse effect on our business and results of operations, and may continue to impact us in the future.”

[0001728949-22-000012:mdna:84]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless industry and governments as to the benefits of our licensing program and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may be dissatisfied with the need to pay reasonable royalties for the use of our technologies and not welcome the success of our licensing program in enabling new, highly cost-effective competitors to their products. Accordingly, such companies and/or governments or regulators may continue to challenge our business model in various forums throughout the world.

[0001728949-22-000012:mdna:85]
[same as prior period, unchanged from 0001728949-21-000066:mdna:132]

[0001728949-22-000012:mdna:86]
[same as prior period, unchanged from 0001728949-21-000066:mdna:134]

[0001728949-22-000012:mdna:87]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at December 26, 2021 and September 26, 2021 and for the first three months of fiscal 2022 and 2021 (in millions):

[0001728949-22-000012:mdna:88]
|  | December 26,2021 |  | September 26,2021 |  | Change |  |  |
| Cash and cash equivalents | $ | 6,607 |  |  | $ | 7,116 |  |  | $ | (509) |  |  |  |
| Marketable securities | 4,703 |  |  | 5,298 |  |  | (595) |  |  |  |
| Cash, cash equivalents and marketable securities | $ | 11,310 |  |  | $ | 12,414 |  |  | $ | (1,104) |  |  |  |

[0001728949-22-000012:mdna:89]
|  | Three Months Ended |
|  | December 26,2021 |  | December 27,2020 |  | Change |  |  |
| Net cash provided by operating activities | $ | 2,057 |  |  | $ | 3,175 |  |  | $ | (1,118) |  |  |  |
| Net cash used by investing activities | (112) |  |  | (1,202) |  |  | 1,090 |  |  |  |
| Net cash used by financing activities | (2,446) |  |  | (1,645) |  |  | (801) |  |  |  |

[0001728949-22-000012:mdna:90]
Cash, cash equivalents and marketable securities. The net decrease in cash, cash equivalents and marketable securities was primarily due to $1.2 billion in payments to repurchase shares of our common stock, $765 million in cash dividends paid, $583 million in capital expenditures, $500 million in payments of tax withholdings related to the vesting of share-based awards and $238 million in cash paid for acquisitions and other investments. This was partially offset by net cash provided by

[0001728949-22-000012:mdna:91]
operating activities, which was impacted by advanced payments of $1.4 billion made to suppliers of our integrated circuit products under multi-year capacity commitments, as well as $1.0 billion of net changes in other operating assets and liabilities, consisting of increased working capital, including higher inventory and related operating liabilities to support QCT demand, an increase in accounts receivable as a result of higher revenues (net of an increase in amounts accrued for customer incentive arrangements recorded as a reduction to accounts receivable) and the timing of payments related to payroll, benefits and other liabilities. We currently expect our working capital requirements to increase in the near term to support QCT demand.

[0001728949-22-000012:mdna:92]
Capital Return Program. On October 12, 2021, we announced a new $10.0 billion stock repurchase program, which was in addition to the then-remaining repurchase authority of $0.9 billion under the previous program. The stock repurchase programs have no expiration date. In the first three months of fiscal 2022, we repurchased and retired 8 million shares of our common stock for $1.2 billion, before commissions. At December 26, 2021, $10.1 billion remained authorized for repurchase under our stock repurchase programs. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-22-000012:mdna:93]
In the first quarter of fiscal 2022, we paid cash dividends totaling $765 million, or $0.68 per share. On January 18, 2022, we announced a cash dividend of $0.68 per share on our common stock, payable on March 24, 2022 to stockholders of record as of the close of business on March 3, 2022. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-22-000012:mdna:94]
Debt. At December 26, 2021, we had $15.5 billion of principal floating- and fixed-rate notes outstanding, $1.5 billion of which matures in May 2022. The remaining debt has maturity dates in 2023 through 2050. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At December 26, 2021, we had $500 million of commercial paper outstanding. We also have a Revolving Credit Facility, which provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At December 26, 2021, no amounts were outstanding under the Revolving Credit Facility. We expect to issue debt in the future. The amount and timing of such debt will depend on a number of factors, including but not limited to maturities of our existing debt, acquisitions and strategic investments, favorable and/or acceptable interest rates and changes in corporate income tax law. Additional information regarding our outstanding debt is provided in “Notes to Consolidated Financial Statements, Note 6. Debt” in our 2021 Annual Report on Form 10-K.

[0001728949-22-000012:mdna:95]
Acquisitions. In October 2021, we and SSW Partners entered into a definitive agreement to acquire Veoneer for total estimated cash consideration of approximately $4.5 billion, substantially all of which will be funded by Qualcomm, and in the first quarter of fiscal 2022, we paid a $110 million termination fee to Magna International Inc. on behalf of Veoneer. Further, we have entered into a loan facility under which we will provide financing to Veoneer of up to $480 million under certain conditions. The acquisition is expected to close in 2022, subject to certain closing conditions. Additional information related to this definitive agreement to acquire Veoneer and our obligations under the loan facility is included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Acquisitions.” We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly, to open new opportunities for our technologies, obtain development resources, grow our patent portfolio or pursue new businesses.

[0001728949-22-000012:mdna:96]
Long-term Capacity Commitments. We have entered into several multi-year capacity purchase commitments with certain suppliers of our integrated circuit products. In the first quarter of fiscal 2022, we made $1.4 billion in advance payments related to certain obligations under these purchase agreements, which were included within other assets and other current assets at December 26, 2021. Additional information regarding long-term capacity commitments and other purchase obligations is provided in “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies” in our 2021 Annual Report on Form 10-K.

[0001728949-22-000012:mdna:97]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2021 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At December 26, 2021, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2021 Annual Report on Form 10-K.

[0001728949-22-000012:mdna:98]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies

[0001728949-22-000012:mdna:99]
against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0001728949-22-000012:mdna:100]
[same as prior period, unchanged from 0001728949-21-000066:mdna:151]

[0001728949-22-000012:mdna:101]
[same as prior period, unchanged from 0001728949-21-000066:mdna:154]

[0001728949-22-000012:mdna:102]
You should consider each of the following factors in evaluating our business and our prospects, any of which could negatively impact our business, results of operations, cash flows and financial condition, and require significant management time and attention. Further, the risks and uncertainties described below are not the only ones we face. Additional risks and uncertainties not presently known to us or that we currently consider immaterial may also negatively impact our business, results of operations, cash flows and financial condition, and require significant management time and attention. In such cases, the trading price of our common stock could decline. You should also consider the other information set forth in this Quarterly Report in evaluating our business and our prospects, including but not limited to our financial statements and the related notes, and “Part I, Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” References to “and,” “or” and “and/or” should be read to include the others, as appropriate.

[0001728949-22-000012:mdna:103]
[same as prior period, unchanged from 0001728949-21-000066:mdna:158]

[0001728949-22-000012:mdna:104]
The coronavirus (COVID-19) pandemic had an adverse effect on our business and results of operations, and may continue to impact us in the future.

[0001728949-22-000012:mdna:105]
The rapid, global spread of COVID-19 and the fear it created resulted in significant economic uncertainty, significant declines in business and consumer confidence and global demand in the wireless industry (among others) and a global economic slowdown, which resulted in a global recession. Specifically, throughout most of calendar 2020 and into early calendar 2021, the decline in demand for smartphones and other consumer devices sold by our customers or licensees resulted in decreased demand for our integrated circuit products (which are incorporated into such devices) and a decrease in the royalties we earned on the licensing of our intellectual property (which is dependent upon the number of such devices sold that utilize our intellectual property).

[0001728949-22-000012:mdna:106]
The COVID-19 pandemic could impact our business, results of operations and financial condition in the future as described above, and/or through delayed, reduced or cancelled customer orders; disruptions or delays in our supply chain; the inability of our customers or licensees to purchase or pay for our products or technologies; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our customers or licensees; or failures by other counterparties. Additionally, federal, state or foreign governments may in the future increase corporate tax rates, increase employer payroll tax obligations and/or otherwise change tax laws to pay for stimulus and other actions that have been and may in the future be taken as a result of the COVID-19 pandemic.

[0001728949-22-000012:mdna:107]
The COVID-19 pandemic also caused us to modify our workforce practices, such as having the vast majority of our employees working from home. We could be negatively affected in the future if, among others, a significant number of our employees, or employees who perform critical functions, become ill and/or are quarantined as the result of exposure to COVID-19, or if government policies restrict the ability of those employees to perform their critical functions. Further, our efforts to reopen our offices safely may not be successful, could expose our employees, customers, licensees and partners to health risks and us to associated liability, and could result in disruptions among our employees. See also the Risk Factor titled “We may not be able to attract and retain qualified employees, and our attempts to fully reopen our offices and operate under a hybrid working environment may not be successful.”

[0001728949-22-000012:mdna:108]
The degree to which the COVID-19 pandemic impacts our future business, results of operations and financial condition will depend on future developments, which are uncertain, including but not limited to the duration, spread and severity of the pandemic; the availability, adoption and efficacy of vaccines; the emergence, spread and severity of new variants of COVID-19, and the protection afforded by vaccines against such variants; government responses and other actions to mitigate the spread of and to treat COVID-19; and when and to what extent normal business, economic and social activity and conditions resume. We are similarly unable to predict the extent to which the pandemic impacts our customers, licensees, suppliers and other partners and their financial conditions, but adverse effects on these parties could also adversely affect us. Finally, the COVID-19 pandemic may make it harder for management to estimate the future performance of our business. To

[0001728949-22-000012:mdna:109]
[same as prior period, unchanged from 0001728949-21-000066:mdna:133]

[0001728949-22-000012:mdna:110]
the extent the COVID-19 pandemic adversely affects our business, results of operations and financial condition, it may also have the effect of exacerbating the other risks discussed in this “Risk Factors” section.

[0001728949-22-000012:mdna:111]
[same as prior period, unchanged from 0001728949-21-000066:mdna:193]

[0001728949-22-000012:mdna:112]
[same as prior period, unchanged from 0001728949-21-000066:mdna:194]

[0001728949-22-000012:mdna:113]
We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. Certain Chinese OEMs continue to grow their device share in China and are increasing their device share in regions outside of China, and we derive a significant portion of our revenues from a small number of these OEMs as well. See also “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Concentrations.”

[0001728949-22-000012:mdna:114]
[same as prior period, unchanged from 0001728949-21-000066:mdna:196]

[0001728949-22-000012:mdna:115]
[same as prior period, unchanged from 0001728949-21-000066:mdna:197]

[0001728949-22-000012:mdna:116]
[same as prior period, unchanged from 0001728949-21-000066:mdna:198]

[0001728949-22-000012:mdna:117]
[same as prior period, unchanged from 0001728949-21-000066:mdna:199]

[0001728949-22-000012:mdna:118]
[same as prior period, unchanged from 0001728949-21-000066:mdna:200]

[0001728949-22-000012:mdna:119]
Apple purchases our MDM (or thin modem) products, which do not include our integrated application processor technology, and which have lower revenue and margin contributions than our combined modem and application processor products. Consequently, to the extent Apple takes device share from our customers who purchase our integrated modem and application processor products, our revenues and margins may be negatively impacted.

[0001728949-22-000012:mdna:120]
Our industry has also experienced slowing growth in the premium-tier device segment due to, among other factors, a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and innovation cycles.

[0001728949-22-000012:mdna:121]
A reduction in sales of premium-tier devices, a reduction in sales of our premium-tier integrated circuit products (which have a higher revenue and margin contribution than our lower-tier integrated circuit products), or a shift in share away from

[0001728949-22-000012:mdna:122]
[same as prior period, unchanged from 0001728949-21-000066:mdna:145]

[0001728949-22-000012:mdna:123]
OEMs that utilize our premium-tier products, would reduce our revenues and margins and may harm our ability to achieve or sustain expected financial results. Any such reduction in revenues would also impact our cash resources available for other purposes, such as research and development.

[0001728949-22-000012:mdna:124]
Further, while our product and revenue diversification strategies have resulted in an increasing portion of our revenues coming from outside of mobile handsets, e.g., from industries such as automotive and IoT, certain product categories within those industries may in themselves be subject to high levels of customer concentration.

[0001728949-22-000012:mdna:125]
Although we have more than 300 licensees, we derive a significant portion of our licensing revenues from a limited number of licensees, which includes a number of Chinese OEMs. In the event that one or more of our significant licensees fail to meet their reporting and payment obligations, or we are unable to renew or modify one or more of their license agreements under similar terms as their existing agreements, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We do not have control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in sales of our licensees’ products, or reductions in the average selling prices of wireless devices sold by our licensees without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues.

[0001728949-22-000012:mdna:126]
[same as prior period, unchanged from 0001728949-21-000066:mdna:206]

[0001728949-22-000012:mdna:127]
[same as prior period, unchanged from 0001728949-21-000066:mdna:207]

[0001728949-22-000012:mdna:128]
Apple has utilized modem products of one of our competitors in some of its devices rather than our products, and solely utilized one of our competitors’ products in several of its prior device launches. In April 2019, we entered into a multi-year chipset supply agreement with Apple and began shipping modems under this agreement in the third quarter of fiscal 2020. In December 2019, Apple acquired Intel’s modem assets and is developing its own modem products using these assets. Accordingly, Apple is expected to use its own modem products, rather than our products, in some or all of its future devices.

[0001728949-22-000012:mdna:129]
Similarly, we derive a significant portion of our revenues from Chinese OEMs. Certain of our customers in China have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products in their devices rather than our integrated circuit products, including due to pressure from or policies of the Chinese government (whose Made in China 2025 campaign targets 70% semiconductor self-sufficiency by 2025), concerns over losing access to our integrated circuit products as a result of actual, threatened or potential U.S. or Chinese government actions or policies, including trade protection or national security policies, or other reasons. See also the Risk Factor titled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0001728949-22-000012:mdna:130]
In addition, supply/capacity constraints within the semiconductor industry may further incentivize our integrated circuit customers to vertically integrate in an effort to secure additional control over their supply chains.

[0001728949-22-000012:mdna:131]
[same as prior period, unchanged from 0001728949-21-000066:mdna:210]

[0001728949-22-000012:mdna:132]
[same as prior period, unchanged from 0001728949-21-000066:mdna:211]

[0001728949-22-000012:mdna:133]
[same as prior period, unchanged from 0001728949-21-000066:mdna:212]

[0001728949-22-000012:mdna:134]
[same as prior period, unchanged from 0001728949-21-000066:mdna:213]

[0001728949-22-000012:mdna:135]
policies, or other reasons, some of our Chinese integrated circuit customers have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products in their devices, or use our competitors’ integrated circuit products in their devices, rather than our products, which could materially harm our business, revenues, results of operations, cash flows and financial position. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0001728949-22-000012:mdna:136]
Political actions, including trade protection and national security policies of the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our Chinese customers or suppliers, limit, prevent or discourage certain of our Chinese customers or suppliers from transacting business with us, or make it more expensive to do so. Given our revenue concentration in China, if, due to actual, threatened or potential U.S. or Chinese government actions or policies: we were further limited in, or prohibited from, selling our integrated circuit products to Chinese OEMs; our non-Chinese OEM customers were limited in, or prohibited from, selling devices into China that incorporate our integrated circuit products; Chinese OEMs develop and use their own integrated circuit products or use our competitors’ integrated circuit products in some (or all) of their devices rather than our integrated circuit products; Chinese tariffs on our integrated circuit products or on devices which incorporate our integrated circuit products made purchasing such products or devices more expensive to Chinese OEMs or Chinese consumers; or our Chinese licensees delay or cease making payments of license fees they owe us, our business, revenues, results of operations, cash flows and financial position could be materially harmed. Similarly, if, due to U.S. or Chinese government actions or policies, we were limited in or prohibited from obtaining critical integrated circuit products from our suppliers in China, our business, revenues, results of operations, cash flows and financial position could be materially harmed. See also the Risk Factor titled “We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected.”

[0001728949-22-000012:mdna:137]
[same as prior period, unchanged from 0001728949-21-000066:mdna:216]

[0001728949-22-000012:mdna:138]
RISKS RELATED TO NEW INITIATIVES

[0001728949-22-000012:mdna:139]
Our growth depends in part on our ability to extend our technologies and products into new and expanded product areas, and industries and applications beyond mobile handsets. Our research, development and other investments in these new and expanded product areas, industries and applications, and related technologies and products, as well as in our existing technologies and products, and new technologies, may not generate operating income or contribute to future results of operations that meet our expectations.

[0001728949-22-000012:mdna:140]
While we continue to invest significant resources toward advancements primarily in support of 4G- and 5G-based technologies, we also invest in new and expanded product areas, and industries and applications beyond mobile handsets, by utilizing our existing technical and business expertise and through acquisitions or other strategic transactions.

[0001728949-22-000012:mdna:141]
In particular, our future growth depends in part on new and expanded product areas, such as RFFE, and industries and applications beyond mobile handsets, such as automotive and IoT; our ability to develop leading and cost-effective technologies and products for these new and expanded product areas, industries and applications; and third parties incorporating our technologies and products into devices used in these product areas, industries and applications. Accordingly, we intend to continue to make substantial investments in these new and expanded product areas, industries and applications, and in developing new products and technologies for these product areas, industries and applications. Our growth also depends significantly on our ability to develop and patent 5G technologies, and to develop and commercialize products using 5G technologies.

[0001728949-22-000012:mdna:142]
However, our research, development and other investments in these new and expanded product areas, industries and applications, and corresponding technologies and products, as well as in our existing, technologies and products and new technologies, such as 5G, use of licensed, shared and unlicensed spectrum and convergence of cellular and Wi-Fi, may not succeed because, among other reasons: we may not be issued patents on the technologies we develop; the technologies we develop may not be incorporated into relevant standards; new and expanded product areas, industries and applications beyond mobile handsets, and consumer demand therein, may not develop or grow as anticipated; we may be unable to attract or retain employees with the necessary skills in such new and expanded product areas, industries and applications; our strategies or the strategies of our customers, licensees or partners may not be successful; alternate technologies or products may be better or may reduce the advantages we anticipate from our investments; competitors’ technologies or products may be more cost

[0001728949-22-000012:mdna:143]
effective, have more capabilities or fewer limitations or be brought to market faster than our new technologies or products; we may not be able to develop, or our competitors may have more established and/or stronger, customer, vendor, distributor or other channel relationships; and competitors may have longer operating histories in industries and applications that are new to us. We may also underestimate the costs of, or overestimate the future revenues or margins that could result from, these investments, and these investments may not, or may take many years to, generate material returns.

[0001728949-22-000012:mdna:144]
[same as prior period, unchanged from 0001728949-21-000066:mdna:281]

[0001728949-22-000012:mdna:145]
In addition, in order to successfully extend our technologies and products into new and expanded product areas, and industries and applications beyond mobile handsets, we may need to transition to new business models and transform aspects of our organization, and we may not be successful in doing so.

[0001728949-22-000012:mdna:146]
If we are not successful in extending our technologies and products into new and expanded product areas, and industries and applications beyond mobile handsets, if our new technologies and products are not successful, or if we are not successful in the time frames we anticipate, we may incur significant costs and asset impairments, our business and revenues may not grow or grow as anticipated, our revenues and margins may be negatively impacted, our stock price may decline and our reputation may be harmed.

[0001728949-22-000012:mdna:147]
We may engage in acquisitions and other strategic transactions or make investments, or be unable to consummate planned strategic acquisitions, which could adversely affect our results of operations or fail to enhance stockholder value.

[0001728949-22-000012:mdna:148]
We engage in acquisitions and other strategic transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. From time to time, we acquire businesses and other assets, including patents, technology and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies, including those that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our products and technologies and supporting the design and introduction of new products (or enhancing existing products) for mobile handsets, and for new industries and applications beyond mobile handsets. Many of our strategic activities entail a high degree of risk and require the use of significant amounts of capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not be successful, generate financial returns or result in increased adoption or continued use of our technologies or products. We may underestimate the costs or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership or variable interests. In addition, we have in the past recorded, and may in the future record, impairment or other charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our results of operations and financial condition, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001728949-22-000012:mdna:149]
Achieving the anticipated benefits of business acquisitions depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models, geographic regions, industries and applications served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0001728949-22-000012:mdna:150]
[same as prior period, unchanged from 0001728949-21-000066:mdna:287]

[0001728949-22-000012:mdna:151]
Many of our acquisitions and other strategic investments require approval by the United States and/or foreign government agencies. Certain agencies in the past have, and may in the future, deny the transaction or fail to approve in a timely manner, resulting in us not realizing the anticipated benefits of the proposed transaction. Future acquisitions or other

[0001728949-22-000012:mdna:152]
strategic investments may be more difficult, complex or expensive to the extent that our reputation for our ability to consummate acquisitions has been harmed. Further, if U.S./China relations remain strained, our ability to consummate any transaction that would require approval from the relevant regulatory agency(ies) in China may be severely impacted.

[0001728949-22-000012:mdna:153]
[same as prior period, unchanged from 0001728949-21-000066:mdna:243]

[0001728949-22-000012:mdna:154]
[same as prior period, unchanged from 0001728949-21-000066:mdna:244]

[0001728949-22-000012:mdna:155]
We primarily utilize a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Other than the facilities we own that manufacture certain of our RFFE modules and RF (radio frequency) filter products, we rely on third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. There are a limited number of such third-party suppliers, and even fewer who are capable of manufacturing at the leading process technology nodes or who are willing to operate at older process technology nodes. The semiconductor manufacturing foundries that supply our products are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders.

[0001728949-22-000012:mdna:156]
[same as prior period, unchanged from 0001728949-21-000066:mdna:246]

[0001728949-22-000012:mdna:157]
•demand for integrated circuits that exceeds suppliers’ capacity to meet that demand;

[0001728949-22-000012:mdna:158]
[same as prior period, unchanged from 0001728949-21-000066:mdna:247]

[0001728949-22-000012:mdna:159]
[same as prior period, unchanged from 0001728949-21-000066:mdna:248]

[0001728949-22-000012:mdna:160]
[same as prior period, unchanged from 0001728949-21-000066:mdna:249]

[0001728949-22-000012:mdna:161]
[same as prior period, unchanged from 0001728949-21-000066:mdna:250]

[0001728949-22-000012:mdna:162]
[same as prior period, unchanged from 0001728949-21-000066:mdna:251]

[0001728949-22-000012:mdna:163]
•our suppliers’ inability to develop or maintain, or a delay in developing or building out, manufacturing capacity for leading process technologies, including transitions to smaller geometry process technologies;

[0001728949-22-000012:mdna:164]
[same as prior period, unchanged from 0001728949-21-000066:mdna:253]

[0001728949-22-000012:mdna:165]
[same as prior period, unchanged from 0001728949-21-000066:mdna:254]

[0001728949-22-000012:mdna:166]
•natural disasters, the effects of climate change or geopolitical conflicts impacting our suppliers and their manufacturing foundries or assembly, test or other facilities;

[0001728949-22-000012:mdna:167]
•health crises, including epidemics or pandemics such as the COVID-19 pandemic, and government and business responses thereto, which impact our suppliers, including as a result of quarantines or closures;

[0001728949-22-000012:mdna:168]
[same as prior period, unchanged from 0001728949-21-000066:mdna:257]

[0001728949-22-000012:mdna:169]
[same as prior period, unchanged from 0001728949-21-000066:mdna:258]

[0001728949-22-000012:mdna:170]
While we have established alternate suppliers for certain technologies, there are a limited number of such suppliers, and even fewer who are capable of operating at the leading process technology nodes or who are willing to operate at older process technology nodes. We rely on sole- or limited-source suppliers for certain products, which may exacerbate the risks identified above, and subject us to other significant risks, including poor product performance and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. To the extent we have

[0001728949-22-000012:mdna:171]
established or in the future establish alternate suppliers, these suppliers may require significant amounts of time and levels of support to bring such technologies to production, both of which may increase for complex or leading process technologies. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, the elimination or limitation of a foundry supplier’s ability to manufacture components or products for us due to trade or national security protection policies could increase our vulnerability to sole- or limited-source arrangements and limit or prevent us from procuring critical components or products from those suppliers. Future consolidation of foundry suppliers could also increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions, increase our manufacturing costs and limit the amount of capacity available to us. Our arrangements with our suppliers may obligate us to incur costs to manufacture, assemble and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies (which adds risk to manufacturing yields and reliability), and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Any of the above could negatively impact our business, results of operations and cash flows.

[0001728949-22-000012:mdna:172]
Although we have long-term contracts with our suppliers, some of these contracts do not provide for long-term capacity commitments. To the extent we do not have firm commitments from our suppliers over a specific time period or for any specific quantity, our suppliers may allocate, and in the past have allocated, capacity to the manufacture, assembly and testing of products for their other customers (including our competitors) while reducing or limiting capacity to manufacture, assemble or test our products, and such capacity may be limited based on our suppliers’ ability and willingness to invest in the capital required to manufacture in the leading process technologies. Our suppliers or potential alternate suppliers may also manufacture their own integrated circuits that compete with our products. Such suppliers have in the past allocated and may again allocate raw materials and manufacturing capacity to their own products and reduce or limit the production of our products. Accordingly, capacity for our products may not be available when we need it. To the extent we do obtain long-term capacity commitments, we may incur additional costs related to those commitments or make non-refundable payments for capacity commitments that are not used. In addition, we may not receive reasonable pricing, manufacturing or delivery terms from our suppliers, and our ability to obtain favorable terms may be diminished during times of high demand and/or limited manufacturing capacity for integrated circuit products.

[0001728949-22-000012:mdna:173]
We cannot guarantee that the actions of our suppliers will not cause disruptions in our operations that could harm our ability to meet our delivery obligations to our customers or increase our cost of sales. To the extent we are unable to obtain adequate supply to meet our delivery obligations, we may be obligated to make payments to our customers for such shortfalls. Currently, the global semiconductor industry is experiencing demand for integrated circuits that exceeds the industry’s capacity to meet that demand. Our ability to meet increased demand for our products has been and may continue to be limited due to the inability to obtain the additional manufacturing, assembly and test capacity necessary to fully meet such demand. If we are unable to fully meet customer demand, this could result in lost sales opportunities, reduced revenue growth and harm to our customer relationships. These issues may be exacerbated if customers overstate their expected demand requirements in order to procure additional supply, which could negatively impact our ability to forecast and to allocate supply appropriately among our customers. These issues may also be exacerbated with respect to our platform solutions, which already entail a great deal of complexity due to differing lead-times, technologies and suppliers for each integrated circuit product included in such solutions.

[0001728949-22-000012:mdna:174]
Additionally, we place orders with our suppliers using our and our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates. As we move to smaller geometry process technologies, the manufacturing lead-time increases. As a result, the orders we place with our suppliers are generally only partially covered by commitments from our customers. If we, or our customers, overestimate demand, or if demand is impacted by factors outside of our or our customers’ control, and such demand is not covered by a binding commitment from our customers, we may experience increased excess or obsolete inventory, which would negatively impact our results of operations.

[0001728949-22-000012:mdna:175]
See also the Risk Factor below titled “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues” as similar risks, as well as additional risks, may be applicable to our third-party suppliers’ manufacturing facilities, which could result in disruptions to our business or additional costs to us, and negatively impact our results of operations.

[0001728949-22-000012:mdna:176]
34

[0001728949-22-000012:mdna:177]
There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues.

[0001728949-22-000012:mdna:178]
[same as prior period, unchanged from 0001728949-21-000066:mdna:268]

[0001728949-22-000012:mdna:179]
We are subject to many complex environmental, health and safety laws, regulations and rules in each jurisdiction in which we operate our manufacturing (and research and development) facilities. The regulatory landscape in these areas continues to evolve, and we anticipate additional laws, regulations and rules in the future. In particular, new, or changes in, environmental and climate change laws, regulations or rules, including relating to GHG emissions, could lead to new or additional investments in production processes and could increase environmental compliance expenditures. In addition, certain environmental laws impose strict, and in certain circumstances joint and several, liability on current or previous owners or operators of real property, or parties who arranged for hazardous substances to be sent to disposal or treatment facilities, for the cost of investigation, removal or remediation of hazardous substances. As a result, we may incur clean-up costs in connection with any such removal or remediation efforts, as well as other third-party claims in connection with contaminated sites. In addition, we could be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage. If we, or companies or facilities we acquire or have acquired, in the past failed or in the future fail to comply with any such laws and regulations, then we could incur regulatory penalties, fines and legal liabilities; suspension of production; significant compliance requirements; alteration of our manufacturing, assembly or test processes; restriction on our ability to modify or expand our facilities; damage to our reputation; and restrictions on our operations or sales. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. We cannot make assurances that we will at all times be in compliance with such laws, regulations, rules and permits. See also the risk factor titled “Our business may suffer due to the impact of, or our failure to comply with, the various existing, new or amended laws, regulations, policies or standards to which we are subject.”

[0001728949-22-000012:mdna:180]
Climate change concerns and the potential resulting environmental impact may result in new environmental, health and safety laws and regulations that may affect us, our suppliers and our customers. Such laws or regulations could cause us to incur additional direct costs for compliance, including costs associated with changes to manufacturing processes or the procurement of raw materials used in manufacturing processes, as well as increased indirect costs resulting from our customers, suppliers or both incurring additional compliance costs that are passed on to us. These costs may adversely impact our results of operations and financial condition. In addition, climate change could cause certain natural disasters, such as drought, wildfires, storms, flooding or rising sea levels, to occur more frequently or with greater intensity, which could pose physical risks to our manufacturing facilities or our suppliers’ facilities, could disrupt the availability of water necessary for the operation of our manufacturing facilities or our suppliers’ facilities, and could increase or decrease temperatures resulting in increased operating costs and/or business disruption.

[0001728949-22-000012:mdna:181]
We have manufacturing facilities in Asia and Europe. If tsunamis, flooding, earthquakes, volcanic eruptions, drought or other natural disasters, effects of climate change or geopolitical conflicts, were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, cease or delay production and shipments of inventory and result in costly repairs, replacements or other costs and lost business. In addition, natural disasters, effects of climate change or geopolitical conflicts may result in disruptions in transportation, distribution channels and supply chains, and significant increases in the prices of raw materials. Further, health crises, including epidemics or pandemics, such as the COVID-19 pandemic, and government and business responses thereto, could affect our manufacturing facilities, including by resulting in quarantines and/or closures, which would result in disruptions to and potential closures of our manufacturing operations. Our manufacturing operations could also be disrupted by cyber-attacks on our IT systems, as described in the Risk Factor below titled “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0001728949-22-000012:mdna:182]
Our manufacturing operations depend on securing raw materials and other supplies in adequate quality and quantity in a timely manner from multiple suppliers, and in some cases, we rely on a limited number of suppliers, including in some cases sole suppliers, particularly in Asia. There may be cases where supplies of raw materials and other products are interrupted by disaster, accident or some other event at a supplier; supply is suspended due to quality or other issues; there is a shortage of supply due to a rapid increase in demand; and/or we or our suppliers are prohibited from utilizing certain raw materials, or

[0001728949-22-000012:mdna:183]
35

[0001728949-22-000012:mdna:184]
products or components that incorporate such raw materials, due to government restrictions related to the countries from which such raw materials originate, and acceptable alternative suppliers, raw materials or raw materials sources are not available or not available in acceptable time frames or upon acceptable terms, among others, which could impact production and prevent us from supplying our products to our customers. If the supply-demand balance is disrupted, it may considerably increase costs of manufacturing due to increased prices we pay for raw materials. From time to time, suppliers may extend lead times, limit amounts supplied to us or increase prices due to capacity constraints or other factors. Additionally, supply and costs of raw materials may be negatively impacted by trade and/or national security protection policies, such as tariffs, or actions by governments that limit or prevent us from transacting business with certain countries or companies or that limit or prevent certain companies from transacting business with us, or trade tensions, particularly with countries in Asia. Further, it may be difficult or impossible to substitute one piece of equipment for another or replace one type of material with another. A failure by our suppliers to deliver our requirements could result in disruptions to our manufacturing operations.

[0001728949-22-000012:mdna:185]
[same as prior period, unchanged from 0001728949-21-000066:mdna:274]

[0001728949-22-000012:mdna:186]
From time to time, we begin to purchase equipment to meet expected customer demand in advance of any purchase orders or long-term purchase commitments. Further, we typically begin manufacturing our products using our or our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates and may not be covered by long-term purchase commitments. As a result, we may incur increased inventory and manufacturing costs and/or record impairment charges to the extent anticipated sales ultimately do not materialize or are lower than expected. If we or our customers overestimate demand, or if demand is impacted by factors outside of our or our customers’ control such as the COVID-19 pandemic or trade or national security protection policies, that is not under a binding commitment from our customers, we may experience higher inventory carrying and operating costs and/or increased excess or obsolete inventory, which would negatively impact our results of operations

[0001728949-22-000012:mdna:187]
[same as prior period, unchanged from 0001728949-21-000066:mdna:289]

[0001728949-22-000012:mdna:188]
[same as prior period, unchanged from 0001728949-21-000066:mdna:290]

[0001728949-22-000012:mdna:189]
Third parties regularly attempt to gain unauthorized access to our IT systems, and many such attacks are increasingly more sophisticated. These attacks, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, exploiting vulnerabilities in hardware, software or other IT infrastructure and impersonating authorized users, among others. We may also be subject to ransom-style cyber-attacks, which could impact our IT systems and cause widespread disruption to our business, including our manufacturing operations, and expose our confidential or propriety information. Third parties that store and/or process our confidential information, or that provide products, software or services used in our IT infrastructure (including applications), may be subject to similar attacks, which could also result in malware being introduced into our IT infrastructure, e.g., through the third parties’ software and/or software updates. Such attacks could result in the misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our IT systems. We believe that we have a robust cybersecurity program that is aligned to international cybersecurity frameworks, and that we leverage industry best practices across people, processes and technologies in an attempt to mitigate cybersecurity threats. However, we may not be able to anticipate, detect, repel or implement effective preventative measures against all cybersecurity threats, particularly because the techniques used are increasingly sophisticated and constantly evolving. As part of our cybersecurity program, we seek to identify and remediate vulnerabilities in our IT systems and software (including third party software used in our IT systems) that could be exploited by hackers or other malicious actors. However, we may not be aware of all such vulnerabilities, and we may fail to identify and/or remediate such vulnerabilities before they are exploited. Attempts to gain unauthorized access to our IT systems or other attacks have in the past, in certain instances and to certain degrees, been successful (but have not caused significant harm), and may in the future be successful, and in some cases, we might be unaware of an incident or its magnitude and effects.

[0001728949-22-000012:mdna:190]
In addition, employees and former employees, in particular former employees who become employees of our competitors, customers, licensees or other third parties, including state actors, have in the past and may in the future misappropriate, wrongfully use, publish or provide to our competitors, customers, licensees or other third parties, including

[0001728949-22-000012:mdna:191]
state actors, our technology, intellectual property or other proprietary or confidential information. This risk is exacerbated as competitors for talent, particularly engineering talent, increasingly attempt to hire our employees. See also the Risk Factor titled “We may not be able to attract and retain qualified employees, and our attempts to fully reopen our offices and operate under a hybrid working environment may not be successful.” Similarly, we provide access to certain of our technology, intellectual property and other proprietary or confidential information to our direct and indirect customers and licensees and certain of our consultants, who have in the past and may in the future wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. We also provide access to certain of our technology, intellectual property and other proprietary or confidential information to certain of our joint venture partners, including those affiliated with state actors and including in foreign jurisdictions where ownership restrictions may require us to take a minority ownership interest in the joint venture. Such joint venture partners may wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors.

[0001728949-22-000012:mdna:192]
The misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, could harm our competitive position, reduce the value of our investment in research and development and other strategic initiatives, cause us to lose business, damage our reputation, subject us to legal or regulatory proceedings, cause us to incur other loss or liability and otherwise adversely affect our business. We expect to continue to devote significant resources to the security of our IT systems, and our technology, intellectual property and proprietary and confidential information.

[0001728949-22-000012:mdna:193]
Further, China has implemented, and other countries or regions may implement, cybersecurity laws that require our overall IT security environment to meet certain standards and/or be certified. Such laws may be complex, ambiguous and subject to interpretation, which may create uncertainty regarding compliance. As a result, our efforts to comply with such laws may be expensive and may fail, which could adversely affect our business, results of operations and cash flows. In addition, our contracts with certain of our customers will require us to obtain cybersecurity certifications for our IT systems. Failure to obtain or maintain the necessary cybersecurity certifications could result in loss of future revenues, damage to our customer relationships and reputation, and a shifting of business to our competitors.

[0001728949-22-000012:mdna:194]
[same as prior period, unchanged from 0001728949-21-000066:mdna:312]

[0001728949-22-000012:mdna:195]
We may not be able to attract and retain qualified employees, and our attempts to fully reopen our offices and operate under a hybrid working environment may not be successful.

[0001728949-22-000012:mdna:196]
Our future success depends upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. In addition, in order to extend our business into certain new and expanded product areas and industries and applications beyond mobile handsets, we will be required to attract, retain and motivate engineering and other technical personnel with specialized skills in these areas, and these skills are in high demand among our competitors. The market for employees in our industry is extremely competitive, and competitors for talent, particularly engineering talent, increasingly attempt to hire, and to varying degrees have been successful in hiring, our employees or employment candidates, including by establishing or expanding local offices near our headquarters in San Diego, California. Further, the increased availability of remote working arrangements, largely driven by the COVID-19 pandemic, has expanded the pool of companies that can compete for our employees and employment candidates. A number of such competitors for talent are significantly larger than us and are able to offer compensation in excess of what we are able to offer or other benefits that we generally do not offer, such as the ability to permanently work from home. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001728949-22-000012:mdna:197]
The COVID-19 pandemic caused us to modify our workforce practices, including having the vast majority of our employees work from home. As we reopen our offices, we intend to operate under a “hybrid” working environment, meaning that the majority of our employees will have the flexibility to work remotely at least some of the time for the foreseeable future. The hybrid working environment may impair our ability to maintain our collaborative and innovative culture, and may cause disruptions among our employees, including decreases in productivity, challenges in communications between on-site and off-site employees and, potentially, employee dissatisfaction and attrition. If our attempts to safely reopen our offices and operate under a hybrid working environment are not successful, our business could be adversely impacted.

[0001728949-22-000012:mdna:198]
[same as prior period, unchanged from 0001728949-21-000066:mdna:217]

[0001728949-22-000012:mdna:199]
[same as prior period, unchanged from 0001728949-21-000066:mdna:233]

[0001728949-22-000012:mdna:200]
[same as prior period, unchanged from 0001728949-21-000066:mdna:234]

[0001728949-22-000012:mdna:201]
Our patent license agreements in effect that generate a significant portion of our licensing revenues are effective for a specified term. To receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms, and may impact the financial or other terms of license agreements not subject to the litigation or arbitration. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such licensees.

[0001728949-22-000012:mdna:202]
Efforts by some original equipment manufacturers (OEMs) to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.

[0001728949-22-000012:mdna:203]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, alleging that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) attempts by licensees to shift their royalty obligation to their suppliers in order to lower the wholesale (i.e., licensee’s) selling price on which the royalty is calculated.

[0001728949-22-000012:mdna:204]
[same as prior period, unchanged from 0001728949-21-000066:mdna:220]

[0001728949-22-000012:mdna:205]
We have been in the past and are currently subject to various litigation and/or governmental investigations and proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. See also the Risk Factors below titled “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings.”

[0001728949-22-000012:mdna:206]
[same as prior period, unchanged from 0001728949-21-000066:mdna:223]

[0001728949-22-000012:mdna:207]
Further, some third parties have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions should not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by limiting the base upon which the royalty rate may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies.

[0001728949-22-000012:mdna:208]
Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party. Further, SDOs in certain countries may attempt to modify widely accepted standards and claim the resulting standard as their own.

[0001728949-22-000012:mdna:209]
We expect that such proposals, interpretations and strategies will continue in the future, and if successful, our business model would be harmed, either by limiting or eliminating our ability to collect royalties (or by reducing the royalties we can collect) on all or a portion of our standard-essential patent portfolio, limiting our return on investment with respect to new technologies, limiting our ability to seek injunctions against infringers of our standard-essential patents, constraining our ability to make licensing commitments when submitting our technologies for inclusion in future standards (which could make our technologies less likely to be included in such standards) or forcing us to work outside of SDOs or other industry groups to promote our new technologies, and our revenues, results of operations and cash flows could be negatively impacted. In addition, the legal and other costs associated with asserting or defending our positions have been and may in the future be significant. We expect that such challenges, regardless of their merits, will continue into the foreseeable future and will require the investment of substantial management time and financial resources.

[0001728949-22-000012:mdna:210]
[same as prior period, unchanged from 0001728949-21-000066:mdna:227]

[0001728949-22-000012:mdna:211]
As described in the Risk Factor below titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings,” we have been in the past, currently are and may in the future be subject to various governmental investigations and legal proceedings challenging our patent licensing (or chipset sales) practices. We are currently subject to certain governmental investigations and/or legal proceedings, including those described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We believe that one intent of certain of these governmental investigations and legal proceedings has been to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0001728949-22-000012:mdna:212]
[same as prior period, unchanged from 0001728949-21-000066:mdna:229]

[0001728949-22-000012:mdna:213]
[same as prior period, unchanged from 0001728949-21-000066:mdna:230]

[0001728949-22-000012:mdna:214]
If we were required to sell chipsets to OEMs that do not have a license to our patents, our licensing program could be negatively impacted by patent exhaustion claims raised by such unlicensed OEMs (i.e., claims that our sale of chipsets to such OEMs forecloses us from asserting any patents substantially embodied by the chipsets against such OEMs). Such sales could provide OEMs with a defense in the event we asserted our patents against them to obtain licensing revenue for those patents. This could have a material adverse effect on our licensing program and our results of operations, cash flows and financial condition.

[0001728949-22-000012:mdna:215]
To the extent that we were required to implement any of these licensing and/or business practices, including by modifying or renegotiating our existing license agreements or pursuing other commercial arrangements, we would incur additional transaction costs, which may be significant, we could incur delays in recognizing revenues until license negotiations were completed, and our business, revenues, results of operations, cash flows and financial condition could be harmed. The impact of any such changes to our licensing practices could vary widely and by jurisdiction, depending on the specific outcomes and the geographic scope of such outcomes. In addition, if we were required to make modifications to our licensing practices in one jurisdiction, licensees or governmental agencies in other jurisdictions may attempt to obtain similar outcomes for themselves or for such other jurisdictions, as applicable, which could result in increased legal costs and further harm to our business, revenues, results of operations, cash flows and financial condition.

[0001728949-22-000012:mdna:216]
[same as prior period, unchanged from 0001728949-21-000066:mdna:236]

[0001728949-22-000012:mdna:217]
Our business may suffer as a result of adverse rulings in governmental investigations or proceedings.

[0001728949-22-000012:mdna:218]
We have been in the past and currently are subject to various governmental investigations and proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Key allegations or findings in those matters include or have in the past included, among others: that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers; that our royalty rates are too high; that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions); that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets; that we have entered into exclusive agreements with chipset customers that foreclose competition; that we leverage our position in baseband chipsets in the RFFE space; and that we violate antitrust laws and engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-22-000012:mdna:219]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others: the loss of our ability to enforce one or more of our patents; injunctions; monetary damages, fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any revenues under such agreements. The renegotiation of license agreements could result in terms that are less favorable to us than existing terms, or lead to arbitration or litigation to resolve the licensing terms, which could also be less favorable to us than existing terms, and each of which could take months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. The occurrence of any of the above could have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies. Further, depending on the breadth and severity of the circumstances above, we may have to reduce, suspend or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted.

[0001728949-22-000012:mdna:220]
These challenges have required, and may in the future require, the investment of significant management time and attention and have resulted, and may in the future result, in significant legal costs.

[0001728949-22-000012:mdna:221]
[same as prior period, unchanged from 0001728949-21-000066:mdna:165]

[0001728949-22-000012:mdna:222]
[same as prior period, unchanged from 0001728949-21-000066:mdna:166]

[0001728949-22-000012:mdna:223]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on our customers and licensees to develop devices and services based on these technologies to drive consumer demand for new 3G/4G and 3G/4G/5G multimode and single-mode devices, and to establish the selling prices for such devices. Further, the timing of our shipments of our products is dependent on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries and applications beyond mobile handsets, such as automotive and IoT, among others.

[0001728949-22-000012:mdna:224]
We have historically been successful during wireless technology transitions, including 3G, 4G and now 5G. Commercial deployments of 5G networks and devices have begun and will continue. However, the timing and scale of such deployments, in certain regions, have been and may in the future be delayed due to the COVID-19 pandemic or for other reasons that are beyond our control.

[0001728949-22-000012:mdna:225]
Our revenues and growth in revenues could be negatively impacted, our business may be harmed and our substantial investments in these technologies may not provide us an adequate return, if: our customers’ and licensees’ revenues and sales of products, particularly premium-tier products, and services using these technologies, and average selling prices of such products, decline due to, for example, the maturity of smartphone penetration in developed regions, including China; we do not continue to maintain our intellectual property and technical leadership in 5G, including in ongoing 5G standardization efforts; we are unable to drive the adoption of our products into networks and devices, including devices beyond mobile handsets; or consumers’ rates of replacement of smartphones and other computing devices decline.

[0001728949-22-000012:mdna:226]
[same as prior period, unchanged from 0001728949-21-000066:mdna:172]

[0001728949-22-000012:mdna:227]
Our products and technologies face significant competition. Competition may intensify as our current competitors expand their product offerings, improve their products or reduce the prices of their products as part of a strategy to maintain existing business and customers or attract new business and customers, as new opportunities develop, and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: OEM concentrations; vertical integration; competition in certain geographic regions; government intervention or support of national industries or competitors; the ability to maintain product differentiation in light of evolving industry standards and speed of technological change (including the transition to smaller geometry process technologies and the demand for always on, always connected capabilities); access to capacity in the supply chain; and value-added features that drive selling prices and consumer demand for new 3G/4G and 3G/4G/5G multimode and single-mode devices.

[0001728949-22-000012:mdna:228]
[same as prior period, unchanged from 0001728949-21-000066:mdna:174]

[0001728949-22-000012:mdna:229]
[same as prior period, unchanged from 0001728949-21-000066:mdna:175]

[0001728949-22-000012:mdna:230]
[same as prior period, unchanged from 0001728949-21-000066:mdna:176]

[0001728949-22-000012:mdna:231]
•develop and offer integrated circuit products at competitive cost and price points and to effectively cover all geographic regions and all device tiers;

[0001728949-22-000012:mdna:232]
41

[0001728949-22-000012:mdna:233]
[same as prior period, unchanged from 0001728949-21-000066:mdna:178]

[0001728949-22-000012:mdna:234]
•increase or accelerate adoption of our technologies and products in industries and applications outside of mobile handsets, including automotive and IoT;

[0001728949-22-000012:mdna:235]
[same as prior period, unchanged from 0001728949-21-000066:mdna:180]

[0001728949-22-000012:mdna:236]
[same as prior period, unchanged from 0001728949-21-000066:mdna:181]

[0001728949-22-000012:mdna:237]
[same as prior period, unchanged from 0001728949-21-000066:mdna:182]

[0001728949-22-000012:mdna:238]
•create standalone value and contribute to the success of our existing businesses through acquisitions, joint ventures and other strategic transactions, and by developing customer, licensee, vendor, distributor and other channel relationships in new industries and applications;

[0001728949-22-000012:mdna:239]
•identify potential acquisition targets that will grow or sustain our business or address strategic needs, reach agreement on terms acceptable to us, close the transactions and effectively integrate these new businesses, products, technologies and employees;

[0001728949-22-000012:mdna:240]
[same as prior period, unchanged from 0001728949-21-000066:mdna:185]

[0001728949-22-000012:mdna:241]
[same as prior period, unchanged from 0001728949-21-000066:mdna:186]

[0001728949-22-000012:mdna:242]
[same as prior period, unchanged from 0001728949-21-000066:mdna:187]

[0001728949-22-000012:mdna:243]
We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application, industry or standard product, including those that produce products for mobile handsets, automotive and IoT, among others. Most of these competitors compete with us with respect to some, but not all, of our businesses or product lines. Companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom, MediaTek, Nvidia, NXP Semiconductors, Qorvo, Samsung, Skyworks, Texas Instruments and UNISOC (formally known as Spreadtrum Communications). Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to use our competitors’ integrated circuit products, to utilize their own internally-developed integrated circuit products and/or sell such products to others, or to utilize alternative technologies; lower cost structures or a willingness and ability to accept lower prices or lower margins for their products, particularly in China; foreign government support of other technologies, competitors or OEMs that sell devices that do not contain our integrated circuit products; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and OEMs in certain geographic regions (such as China); more experience in industries and applications beyond mobile handsets (such as automotive and IoT); and a more established presence in certain regions.

[0001728949-22-000012:mdna:244]
In addition, certain of our largest integrated circuit customers have in the past utilized, currently utilize and may in the future utilize our competitors’ integrated circuit products in some (or all) of their devices, rather than our products. Further, certain of those customers have developed, are developing or may develop their own integrated circuit products (effectively making them competitors), which they have in the past utilized, currently utilize and may in the future utilize in some (or all) of their devices, rather than our products. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0001728949-22-000012:mdna:245]
Further, political actions, including trade and/or national security protection policies, or other actions by governments, particularly the U.S. and Chinese governments, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our customers or suppliers, limit, prevent or discourage certain of our customers or

[0001728949-22-000012:mdna:246]
suppliers from transacting business with us, or make it more expensive to do so. This could advantage our competitors by enabling them with increased sales, economies of scale, operating income and/or cash flows and/or enable critical technology transfer, allowing them to increase their investments in technology development, research and development and commercialization of products. See also the Risk Factor titled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0001728949-22-000012:mdna:247]
Further, certain of our competitors develop and sell multiple components (including integrated circuit products) for use in devices and sell those components together to OEMs. Our competitors’ sales of multiple components put us (and our discrete integrated circuit products) at a competitive disadvantage. Certain of our competitors also develop and sell infrastructure equipment for wireless networks and can optimize their integrated circuit products to perform on such networks to a degree that we are not able to, which again puts us at a competitive disadvantage.

[0001728949-22-000012:mdna:248]
Competition in any or all product tiers may result in the loss of business or customers, which would negatively impact our business, revenues, results of operations, cash flows and financial condition. Such competition may also reduce average selling prices for our chipset products or the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging regions and China where competitors may have lower cost structures or may have a willingness and ability to accept lower prices or lower margins on their products. Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0001728949-22-000012:mdna:249]
[same as prior period, unchanged from 0001728949-21-000066:mdna:315]

[0001728949-22-000012:mdna:250]
[same as prior period, unchanged from 0001728949-21-000066:mdna:316]

[0001728949-22-000012:mdna:251]
Our products (including for purposes of this Risk Factor, related software) are complex and may contain defects, errors or security vulnerabilities, or experience failures or unsatisfactory performance, due to any number of issues, including issues in materials, design, fabrication, packaging and/or use within a system. Development of products in new domains of technology, such as the transition to 5G, and the migration to integrated circuit technologies with smaller geometric feature sizes, increases complexity and adds risk to manufacturing yields and reliability, and increases the likelihood of product defects, errors or security vulnerabilities. Defects, errors, security vulnerabilities or other unintended functionality could also be introduced into our products by cyber-attacks or other actions by malicious actors, either directly or through third-party products or software used in our products or IT infrastructure (including applications). Further, because of the complexity of our products, defects, errors or security vulnerabilities might only be detected when the products are in use. Risks associated with product or technology defects, errors or security vulnerabilities are exacerbated by the fact that our customers typically integrate our products into consumer and other devices.

[0001728949-22-000012:mdna:252]
The use of devices containing our products to interact with untrusted systems or otherwise access untrusted content creates a risk of exposing the system hardware and software in those devices to malicious attacks. Further, security vulnerabilities in our products or the technologies we use could expose our customers, or end users of our customers’ products, to hackers or other unscrupulous third parties who develop and deploy malware that could attack our products or our customers’ products or IT infrastructure. Such attacks could result in the disruption of our customers’ businesses or the misappropriation, theft, misuse, disclosure, loss or destruction of the technology or intellectual property, or the proprietary, confidential or personal information, of our customers, their employees or the end users of our customers’ devices. While we continue to focus on this issue and take measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and applications, and increasing the risk of security failures, and techniques used to perpetrate cybersecurity attacks are increasingly sophisticated and constantly evolving. See also the Risk Factor titled “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0001728949-22-000012:mdna:253]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and the end users of such devices, and, potentially, to our customers’ IT infrastructure. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products, repairing or replacing defective products, writing down defective inventory, or indemnification obligations under our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of

[0001728949-22-000012:mdna:254]
business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, and losses on unfavorable purchase commitments. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products.

[0001728949-22-000012:mdna:255]
In addition, the occurrence of defects, errors or security vulnerabilities may give rise to product liability claims, particularly if such defects, errors or security vulnerabilities in our products or the technology we use, or the products into which they are integrated, result in personal injury or death, and could result in significant costs, expenses and losses. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the attention of our technical and management personnel and harm our business, even if we are successful. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. Further, our business liability insurance may be inadequate, or future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as: (i) automobiles, including autonomous driver assistance programs; (ii) cameras and artificial intelligence, including home and enterprise security; (iii) home automation, including smoke and noxious gas detectors; (iv) medical condition monitoring; (v) location and asset tracking and management, including wearables for child safety and elderly health; (vi) robotics, including public safety drones and autonomous municipality vehicles; and (vii) extended reality (XR) for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0001728949-22-000012:mdna:256]
[same as prior period, unchanged from 0001728949-21-000066:mdna:323]

[0001728949-22-000012:mdna:257]
[same as prior period, unchanged from 0001728949-21-000066:mdna:296]

[0001728949-22-000012:mdna:258]
[same as prior period, unchanged from 0001728949-21-000066:mdna:297]

[0001728949-22-000012:mdna:259]
[same as prior period, unchanged from 0001728949-21-000066:mdna:298]

[0001728949-22-000012:mdna:260]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our patents are or may be licensed, or our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in ways that are detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-22-000012:mdna:261]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies or political actions of governments, including trade protection and national security policies; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce

[0001728949-22-000012:mdna:262]
44

[0001728949-22-000012:mdna:263]
judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business and the pricing and integration of additional features and functionality into our chipset products. See also the Risk Factors titled “Efforts by some original equipment manufacturers (OEMs) to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings.”

[0001728949-22-000012:mdna:264]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0001728949-22-000012:mdna:265]
Additionally, although our license agreements generally provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements. Similarly, we provide access to certain of our intellectual property and proprietary and confidential business information to our direct and indirect customers and licensees, who have in the past and may in the future wrongfully use such intellectual property and information or wrongfully disclose such intellectual property and information to third parties, including our competitors. See also the Risk Factor titled “Efforts by some original equipment manufacturers (OEMs) to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.”

[0001728949-22-000012:mdna:266]
[same as prior period, unchanged from 0001728949-21-000066:mdna:304]

[0001728949-22-000012:mdna:267]
From time to time, companies have asserted, and may again assert, patent, copyright or other intellectual property claims against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation, and we are currently involved in such litigation, including those described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products were found to infringe another company’s intellectual property, we could be subject to an injunction or be required to redesign our products, or to license such intellectual property or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products, license such intellectual property used in our products or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling our products. Similarly, our suppliers could be found to infringe another company’s intellectual property, and such suppliers could then be enjoined from providing products or services to us.

[0001728949-22-000012:mdna:268]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products sold by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result

[0001728949-22-000012:mdna:269]
45

[0001728949-22-000012:mdna:270]
in costly litigation, divert the efforts of our technical and management personnel and/or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-22-000012:mdna:271]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing corresponding declines in our chipset or licensing revenues.

[0001728949-22-000012:mdna:272]
[same as prior period, unchanged from 0001728949-21-000066:mdna:310]

[0001728949-22-000012:mdna:273]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe that we will continue to see, customers request that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of our products’ source code and may expose our related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of that software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Furthermore, in the course of product development, we may make contributions to third-party open source projects that could subject our intellectual property to adverse licensing conditions. For example, to encourage the growth of a software ecosystem that is interoperable with our products, we may need to contribute certain implementations under the open source licensing terms that govern such projects, which may adversely impact our associated intellectual property. Developing open source products, while adequately protecting the intellectual property upon which our licensing program depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental and third-party scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products.

[0001728949-22-000012:mdna:274]
[same as prior period, unchanged from 0001728949-21-000066:mdna:324]

[0001728949-22-000012:mdna:275]
[same as prior period, unchanged from 0001728949-21-000066:mdna:325]

[0001728949-22-000012:mdna:276]
[same as prior period, unchanged from 0001728949-21-000066:mdna:326]

[0001728949-22-000012:mdna:277]
A decline in global, regional or local economic conditions, a slow-down in economic growth, particularly in geographic regions with high concentrations of wireless voice and data users or high concentrations of our customers or licensees, could also have adverse, wide-ranging effects on our business and financial results, including: a decrease in demand for our products and technologies; a decrease in demand for the products and services of our customers or licensees; the inability of our suppliers to deliver on their supply commitments to us, our inability to supply our products to our customers and/or the inability of our customers or licensees to supply their products to end users; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our customers or licensees; failures by counterparties; and/or negative effects on wireless device inventories. In addition, our customers’ and licensees’ ability to purchase or pay for our products and intellectual property and network operators’ ability to upgrade their wireless networks could be adversely affected, potentially leading to a reduction, cancellation or delay of orders for our products. Further, inflationary pressure may increase our costs,

[0001728949-22-000012:mdna:278]
reduce demand for our products or those of our customers or licensees due to increased prices of those products, or result in employee attrition to the extent our compensation does not keep up with inflation, particularly if our competitors’ compensation does.

[0001728949-22-000012:mdna:279]
Our stock price and financial results have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and our financial results include those identified above and throughout this Risk Factors section, as well as: volatility of the stock market in general and technology and semiconductor companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0001728949-22-000012:mdna:280]
[same as prior period, unchanged from 0001728949-21-000066:mdna:331]

[0001728949-22-000012:mdna:281]
Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). These include, among others: Regulations affecting: patent licensing practices; antitrust, competition and competitive business practices; the flow of funds out of certain countries (e.g., China); cybersecurity; import and export regulations, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; protection of intellectual property; trade and trade protection including tariffs; foreign policy and national security; environmental protection (including climate change), health and safety; supply chain, responsible sourcing, including the use of conflict minerals, and human rights; spectrum availability and license issuance; adoption of standards; taxation; privacy and data protection; labor, employment and human capital; corporate governance; public disclosure; and business conduct. Compliance with, or changes in the interpretation of, existing Regulations, the adoption of new Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, among others, could have an adverse effect on our business and results of operations. See also the Risk Factors titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

[0001728949-22-000012:mdna:282]
Regulations are complex and changing (which may create uncertainty regarding compliance), are subject to varying interpretations, and their application in practice may evolve over time. As a result, our efforts to comply with Regulations may fail, particularly if there is ambiguity as to how they should be applied in practice. Failure to comply with any Regulation may adversely affect our business, results of operations and cash flows. New Regulations, or evolving interpretations thereof, may cause us to incur higher costs as we revise current practices, policies or procedures and may divert management time and attention to compliance activities.

[0001728949-22-000012:mdna:283]
[same as prior period, unchanged from 0001728949-21-000066:mdna:334]

[0001728949-22-000012:mdna:284]
Our outstanding debt and any additional debt we incur may have negative consequences on our business, including, among others: requiring us to use cash to pay the principal of and interest on our debt, thereby reducing the amount of cash available for other purposes; limiting our ability to obtain additional financing for working capital, capital expenditures, acquisitions, stock repurchases, dividends, general corporate or other purposes; and limiting our flexibility in planning for, or reacting to, changes in our business, industries or the market. Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to economic and political conditions, industry cycles and financial, business and other factors, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations to service our debt, we may be required to, among other things: refinance or restructure all or a portion of our debt; reduce or delay planned capital or operating expenditures; reduce, suspend or eliminate our dividend payments and/or our stock repurchase program; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing or restructuring are higher than our current rates,

[0001728949-22-000012:mdna:285]
interest expense related to such refinancing or restructuring would increase. Further, if there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt financing in the future and the terms of such debt could be adversely affected.

[0001728949-22-000012:mdna:286]
[same as prior period, unchanged from 0001728949-21-000066:mdna:338]

[0001728949-22-000012:mdna:287]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed, as well as countries where we own intellectual property. The final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-22-000012:mdna:288]
Tax rules may change in a manner that adversely affects our future reported results of operations or the way we conduct our business. Most of our income is taxable in the United States with a significant portion qualifying for preferential treatment as FDII (foreign-derived intangible income). Beginning in fiscal 2027, the effective tax rate for FDII increases from 13% to 16%. Further, if U.S. tax rates increase and/or the FDII deduction is eliminated or reduced, both of which have been proposed by the current U.S. presidential administration and Congress, our provision for income taxes, results of operations and cash flows would be adversely (potentially materially) affected. Also, if our customers move manufacturing operations to the United States, our FDII deduction may be reduced.

[0001728949-22-000012:mdna:289]
We have tax incentives in Singapore that require we meet specified employment and other criteria. Although our profit in Singapore has declined as a result of our 2018 restructuring and such tax incentives were not significant beginning in fiscal 2019, failure to meet these incentive requirements through March 2022 could require us to refund previously realized material tax benefits for 2017 and 2018.

[0001728949-22-000012:mdna:290]
Further changes in the tax laws of foreign jurisdictions could arise as a result of the base erosion and profit shifting (BEPS) project that was undertaken by the Organization for Economic Co-operation and Development (OECD). The OECD, which represents a coalition of member countries, recommended changes to numerous long-standing tax principles related to transfer pricing and continues to develop new proposals including allocating greater taxing rights to countries where customers are located and establishing a minimum tax on global income. These changes, as adopted by countries, may increase tax uncertainty and may adversely affect our provision for income taxes, results of operations and cash flows.
