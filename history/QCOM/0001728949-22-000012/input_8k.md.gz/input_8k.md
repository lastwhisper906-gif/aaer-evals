# QCOM 8-K — 0001728949-22-000011 filed 2022-02-02

## item codes, every 8-K on or before 2022-02-02

- 2022-02-02 0001728949-22-000011 — 2.02, 9.01
- 2021-11-03 0001728949-21-000075 — 2.02, 9.01
- 2021-10-04 0001104659-21-122578 — 1.01, 7.01, 9.01
- 2021-07-28 0001728949-21-000065 — 2.02, 9.01
- 2021-07-23 0001728949-21-000055 — 5.03, 9.01
- 2021-05-21 0001728949-21-000048 — 5.02
- 2021-04-28 0001728949-21-000042 — 2.02, 9.01
- 2021-03-15 0001628280-21-004741 — 5.07
- 2021-02-03 0001728949-21-000021 — 2.02, 9.01
- 2021-01-13 0001728949-21-000009 — 1.01, 9.01
- 2021-01-08 0001728949-21-000004 — 5.02
- 2020-12-10 0001104659-20-134200 — 1.01, 1.02, 2.03, 9.01
- 2020-11-19 0001728949-20-000070 — 5.02
- 2020-11-04 0001728949-20-000066 — 2.02, 9.01
- 2020-08-18 0001104659-20-096322 — 1.01, 8.01, 9.01
- 2020-08-05 0001104659-20-090597 — 8.01, 9.01
- 2020-07-29 0001728949-20-000056 — 2.02, 9.01
- 2020-07-24 0001728949-20-000047 — 5.02
- 2020-05-11 0001104659-20-058923 — 1.01, 8.01, 9.01
- 2020-05-04 0001728949-20-000037 — 5.02
- 2020-04-29 0001728949-20-000030 — 2.02, 9.01
- 2020-03-13 0001728949-20-000015 — 5.07
- 2020-02-05 0001728949-20-000010 — 2.02, 9.01
- 2019-11-06 0001728949-19-000074 — 5.02
- 2019-11-06 0001728949-19-000071 — 2.02, 9.01
- 2019-08-28 0001728949-19-000058 — 5.02
- 2019-07-31 0001728949-19-000053 — 2.02, 9.01
- 2019-05-10 0001728949-19-000044 — 5.02
- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2022-02-02

- none on or before 2022-02-02

## item 2.02 — earnings release, exhibit 99.1

[0001728949-22-000011:8k_2_02:1]
EX-99.1
2
qcom122621erex991.htm
EX-99.1

[0001728949-22-000011:8k_2_02:2]
Document

[0001728949-22-000011:8k_2_02:3]
Exhibit 99.1

[0001728949-22-000011:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001728949-22-000011:8k_2_02:5]
Qualcomm Contact:

[0001728949-22-000011:8k_2_02:6]
Mauricio Lopez-Hodoyan

[0001728949-22-000011:8k_2_02:7]
Vice President, Investor Relations

[0001728949-22-000011:8k_2_02:8]
Phone: 1-858-658-4813 | e-mail: ir@qualcomm.com

[0001728949-22-000011:8k_2_02:9]
Qualcomm Announces First Quarter Fiscal 2022 Results

[0001728949-22-000011:8k_2_02:10]
Revenues: $10.7 billion

[0001728949-22-000011:8k_2_02:11]
GAAP EPS: $2.98, Non-GAAP EPS: $3.23

[0001728949-22-000011:8k_2_02:12]
—Record Quarterly Revenues and EPS—

[0001728949-22-000011:8k_2_02:13]
—QCT: Second Consecutive Quarter of Record Results and Greater Than 60% Year-Over-Year EBT Growth—

[0001728949-22-000011:8k_2_02:14]
—Connected Intelligent Edge Drives 41% Year-Over-Year Growth in QCT IoT Revenues—

[0001728949-22-000011:8k_2_02:15]
SAN DIEGO - February 2, 2022 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal first quarter ended December 26, 2021.

[0001728949-22-000011:8k_2_02:16]
“Our record quarterly results reflect the strong demand for our products and technologies, with QCT revenues exceeding those of any fabless semiconductor company,” said Cristiano Amon, President and CEO of Qualcomm Incorporated.1 “We are at the beginning of one of the largest opportunities in our history, with our addressable market expanding by more than seven times to approximately $700 billion in the next decade. Our one technology roadmap positions us as the partner of choice for both mobile and the connected intelligent edge.”

[0001728949-22-000011:8k_2_02:17]
First Quarter Results 2

[0001728949-22-000011:8k_2_02:18]
|  | GAAP |  | Non-GAAP |  |
| (in millions, except per share data and percentages) | Q1 Fiscal 2022 |  | Q1 Fiscal 2021 |  | Change |  | Q1 Fiscal 2022 |  | Q1 Fiscal 2021 |  |  |  |  | Change |  |
| Revenues | $10,705 |  | $8,235 |  | +30% |  | $10,697 |  | $8,226 |  |  |  |  | +30% |  |
| Earnings before taxes (EBT) | $3,865 |  | $2,604 |  | +48% |  | $4,306 |  | $2,912 |  |  |  |  | +48% |  |
| Net income | $3,399 |  | $2,455 |  | +38% |  | $3,686 |  | $2,510 |  |  |  |  | +47% |  |
| Diluted earnings per share (EPS) | $2.98 |  | $2.12 |  | +41% |  | $3.23 |  | $2.17 |  |  |  |  | +49% |  |

[0001728949-22-000011:8k_2_02:19]
Segment Results

[0001728949-22-000011:8k_2_02:20]
|  | QCT |  | QTL |
| (in millions, except percentages) | Q1 Fiscal 2022 |  | Q1 Fiscal 2021 |  | Change |  | Q1 Fiscal 2022 |  | Q1 Fiscal 2021 |  | Change |  |  |  |
| Revenues | $8,847 |  | $6,533 |  | +35% |  | $1,818 |  | $1,660 |  | +10% |  |  |  |
| EBT | $3,114 |  | $1,919 |  | +62% |  | $1,406 |  | $1,270 |  | +11% |  |  |  |
| EBT as % of revenues | 35% |  | 29% |  | +6 points |  | 77% |  | 77% |  | — |  |  |  |

[0001728949-22-000011:8k_2_02:21]
(1)  Based on review of fabless, public semiconductor and semiconductor equipment companies’ (according to GICS 4530 classification) most recent quarterly financial results released prior to February 2, 2022.  Our analysis is based on QCT revenues, including products manufactured in our RF front-end internal fabrication facilities.

[0001728949-22-000011:8k_2_02:22]
(2)  Discussion regarding our use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results are included at the end of this news release in the sections labeled “Note Regarding Use of Non-GAAP Financial Measures” and “Reconciliations of GAAP Results to Non-GAAP Results.”

[0001728949-22-000011:8k_2_02:23]
| Qualcomm Announces First Quarter Fiscal 2022 Results | Page 2 of 8 |

[0001728949-22-000011:8k_2_02:24]
QCT Revenue Streams

[0001728949-22-000011:8k_2_02:25]
We disaggregate QCT revenues based on the industries and applications in which our products are sold.

[0001728949-22-000011:8k_2_02:26]
| (in millions, except percentages) |  |  |  |  |  |  | Q1 Fiscal 2022 |  | Q1 Fiscal 2021 |  | Change |  |  |  |
| Handsets |  |  |  |  |  |  | $5,983 |  | $4,216 |  | +42% |  |  |  |
| RF front-end |  |  |  |  |  |  | 1,132 |  | 1,061 |  | +7% |  |  |  |
| Automotive |  |  |  |  |  |  | 256 |  | 212 |  | +21% |  |  |  |
| IoT |  |  |  |  |  |  | 1,476 |  | 1,044 |  | +41% |  |  |  |
| Total QCT revenues |  |  |  |  |  |  | $8,847 |  | $6,533 |  | +35% |  |  |  |

[0001728949-22-000011:8k_2_02:27]
Return of Capital to Stockholders

[0001728949-22-000011:8k_2_02:28]
During the first quarter of fiscal 2022, we returned $1.9 billion to stockholders, including $765 million, or $0.68 per share, of cash dividends paid and $1.2 billion through repurchases of 8 million shares of common stock.

[0001728949-22-000011:8k_2_02:29]
Business Outlook

[0001728949-22-000011:8k_2_02:30]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.

[0001728949-22-000011:8k_2_02:31]
|  |  |  | Current Guidance Q2 FY22 Estimates1 |  |
|  | Revenues |  | $10.2B - $11.0B |  |
|  | Supplemental Revenue Information |  |  |  |
|  | QCT revenues |  | $8.7B - $9.3B |  |
|  | QTL revenues |  | $1.45B - $1.65B |  |
|  | GAAP diluted EPS |  | $2.39 - $2.59 |  |
|  | Less diluted EPS attributable to QSI |  | $— |  |  |
|  | Less diluted EPS attributable to share-based compensation |  | ($0.36) |  |  |
|  | Less diluted EPS attributable to other items2 |  | ($0.05) |  |  |
|  | Non-GAAP diluted EPS |  | $2.80 - $3.00 |  |

[0001728949-22-000011:8k_2_02:32]
Our GAAP financial guidance for the second quarter of fiscal 2022 does not include an estimate of unrealized losses on QSI marketable equity securities based on recent volatility in the stock market as such losses cannot be accurately forecast.

[0001728949-22-000011:8k_2_02:33]
(1)  Our outlook does not include provisions for proposed tax law changes, future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as certain investments, derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain.  Our outlook includes the impact of any pending business combinations to the extent they are expected to close in the upcoming quarter.  Actual results may differ materially from the outlook.

[0001728949-22-000011:8k_2_02:34]
(2)  Our guidance for diluted EPS attributable to other items for the second quarter of fiscal 2022 is primarily attributable to acquisition-related items.

[0001728949-22-000011:8k_2_02:35]
| Qualcomm Announces First Quarter Fiscal 2022 Results | Page 3 of 8 |

[0001728949-22-000011:8k_2_02:36]
Conference Call

[0001728949-22-000011:8k_2_02:37]
Qualcomm’s first quarter fiscal 2022 earnings conference call will be broadcast live on February 2, 2022, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to our financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at http://investor.qualcomm.com/ immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415.  Callers should use reservation number 13726028.

[0001728949-22-000011:8k_2_02:38]
About Qualcomm

[0001728949-22-000011:8k_2_02:39]
Qualcomm is the world’s leading wireless technology innovator and the driving force behind the development, launch and expansion of 5G.  When we connected the phone to the internet, the mobile revolution was born.  Today, our foundational technologies enable the mobile ecosystem and are found in every 3G, 4G and 5G smartphone.  We bring the benefits of mobile to new industries, including automotive, the internet of things and computing, and are leading the way to a world where everything and everyone can communicate and interact seamlessly.

[0001728949-22-000011:8k_2_02:40]
Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of our engineering and research and development functions and substantially all of our products and services businesses, including our QCT semiconductor business.

[0001728949-22-000011:8k_2_02:41]
Note Regarding Forward-Looking Statements

[0001728949-22-000011:8k_2_02:42]
###

[0001728949-22-000011:8k_2_02:43]
Qualcomm is a trademark or registered trademark of Qualcomm Incorporated.  Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-22-000011:8k_2_02:44]
| Qualcomm Announces First Quarter Fiscal 2022 Results | Page 4 of 8 |

[0001728949-22-000011:8k_2_02:45]
QUALCOMM Incorporated

[0001728949-22-000011:8k_2_02:46]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001728949-22-000011:8k_2_02:47]
(In millions, except par value amounts)

[0001728949-22-000011:8k_2_02:48]
(Unaudited)

[0001728949-22-000011:8k_2_02:49]
|  | December 26,2021 |  | September 26,2021 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 6,607 |  |  | $ | 7,116 |  |
| Marketable securities | 4,703 |  |  | 5,298 |  |
| Accounts receivable, net | 4,032 |  |  | 3,579 |  |
| Inventories | 3,861 |  |  | 3,228 |  |
| Other current assets | 1,019 |  |  | 854 |  |
| Total current assets | 20,222 |  |  | 20,075 |  |
| Deferred tax assets | 1,454 |  |  | 1,591 |  |
| Property, plant and equipment, net | 4,723 |  |  | 4,559 |  |
| Goodwill | 7,264 |  |  | 7,246 |  |
| Other intangible assets, net | 1,373 |  |  | 1,458 |  |
| Other assets | 7,784 |  |  | 6,311 |  |
| Total assets | $ | 42,820 |  |  | $ | 41,240 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 3,526 |  |  | $ | 2,750 |  |
| Payroll and other benefits related liabilities | 1,440 |  |  | 1,531 |  |
| Unearned revenues | 604 |  |  | 612 |  |
| Short-term debt | 2,042 |  |  | 2,044 |  |
| Other current liabilities | 4,661 |  |  | 5,014 |  |
| Total current liabilities | 12,273 |  |  | 11,951 |  |
| Unearned revenues | 257 |  |  | 364 |  |
| Income taxes payable | 1,687 |  |  | 1,713 |  |
| Long-term debt | 13,708 |  |  | 13,701 |  |
| Other liabilities | 3,562 |  |  | 3,561 |  |
| Total liabilities | 31,487 |  |  | 31,290 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,125 and 1,125 shares issued and outstanding, respectively | — |  |  | — |  |
| Retained earnings | 11,275 |  |  | 9,822 |  |
| Accumulated other comprehensive income | 58 |  |  | 128 |  |
| Total stockholders’ equity | 11,333 |  |  | 9,950 |  |
| Total liabilities and stockholders’ equity | $ | 42,820 |  |  | $ | 41,240 |  |

[0001728949-22-000011:8k_2_02:50]
| Qualcomm Announces First Quarter Fiscal 2022 Results | Page 5 of 8 |

[0001728949-22-000011:8k_2_02:51]
QUALCOMM Incorporated

[0001728949-22-000011:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-22-000011:8k_2_02:53]
(In millions, except per share data)

[0001728949-22-000011:8k_2_02:54]
(Unaudited)

[0001728949-22-000011:8k_2_02:55]
|  |  | Three Months Ended |  |  |
|  |  |  |  |  |  | December 26,2021 |  | December 27,2020 |  |  |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services |  |  |  |  |  | $ | 8,682 |  |  | $ | 6,442 |  |  |  |  |  |
| Licensing |  |  |  |  |  | 2,023 |  |  | 1,793 |  |  |  |  |  |
| Total revenues |  |  |  |  |  | 10,705 |  |  | 8,235 |  |  |  |  |  |
| Costs and expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  |  |  |  | 4,303 |  |  | 3,489 |  |  |  |  |  |
| Research and development |  |  |  |  |  | 1,930 |  |  | 1,653 |  |  |  |  |  |
| Selling, general and administrative |  |  |  |  |  | 608 |  |  | 567 |  |  |  |  |  |
| Total costs and expenses |  |  |  |  |  | 6,841 |  |  | 5,709 |  |  |  |  |  |
| Operating income |  |  |  |  |  | 3,864 |  |  | 2,526 |  |  |  |  |  |
| Interest expense |  |  |  |  |  | (139) |  |  | (141) |  |  |  |  |  |
| Investment and other income, net |  |  |  |  |  | 140 |  |  | 219 |  |  |  |  |  |
| Income before income taxes |  |  |  |  |  | 3,865 |  |  | 2,604 |  |  |  |  |  |
| Income tax expense |  |  |  |  |  | (466) |  |  | (149) |  |  |  |  |  |
| Net income |  |  |  |  |  | $ | 3,399 |  |  | $ | 2,455 |  |  |  |  |  |
| Basic earnings per share |  |  |  |  |  | $ | 3.02 |  |  | $ | 2.16 |  |  |  |  |  |
| Diluted earnings per share |  |  |  |  |  | $ | 2.98 |  |  | $ | 2.12 |  |  |  |  |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  | 1,124 |  |  | 1,134 |  |  |  |  |  |
| Diluted |  |  |  |  |  | 1,142 |  |  | 1,156 |  |  |  |  |  |

[0001728949-22-000011:8k_2_02:56]
| Qualcomm Announces First Quarter Fiscal 2022 Results | Page 6 of 8 |

[0001728949-22-000011:8k_2_02:57]
QUALCOMM Incorporated

[0001728949-22-000011:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-22-000011:8k_2_02:59]
(In millions)

[0001728949-22-000011:8k_2_02:60]
(Unaudited)

[0001728949-22-000011:8k_2_02:61]
|  | Three Months Ended |  |  |
|  | December 26,2021 |  | December 27,2020 |  |  |  |  |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 3,399 |  |  | $ | 2,455 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 406 |  |  | 364 |  |  |  |  |  |
| Income tax provision in excess of income tax payments | 272 |  |  | 53 |  |  |  |  |  |
| Share-based compensation expense | 496 |  |  | 392 |  |  |  |  |  |
| Net gains on marketable securities and other investments | (103) |  |  | (195) |  |  |  |  |  |
| Other items, net | (25) |  |  | (18) |  |  |  |  |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (454) |  |  | (141) |  |  |  |  |  |
| Inventories | (638) |  |  | 62 |  |  |  |  |  |
| Other assets | (1,504) |  |  | (97) |  |  |  |  |  |
| Trade accounts payable | 781 |  |  | 129 |  |  |  |  |  |
| Payroll, benefits and other liabilities | (495) |  |  | 278 |  |  |  |  |  |
| Unearned revenues | (78) |  |  | (107) |  |  |  |  |  |
| Net cash provided by operating activities | 2,057 |  |  | 3,175 |  |  |  |  |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (583) |  |  | (469) |  |  |  |  |  |
| Purchases of debt and equity marketable securities | (517) |  |  | (2,248) |  |  |  |  |  |
| Proceeds from sales and maturities of debt and equity marketable securities | 1,133 |  |  | 1,612 |  |  |  |  |  |
| Acquisitions and other investments, net of cash acquired | (238) |  |  | (138) |  |  |  |  |  |
| Proceeds from other investments | 93 |  |  | 10 |  |  |  |  |  |
| Other items, net | — |  |  | 31 |  |  |  |  |  |
| Net cash used by investing activities | (112) |  |  | (1,202) |  |  |  |  |  |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 710 |  |  | 819 |  |  |  |  |  |
| Repayment of short-term debt | (710) |  |  | (818) |  |  |  |  |  |
| Repurchases and retirements of common stock | (1,178) |  |  | (444) |  |  |  |  |  |
| Dividends paid | (765) |  |  | (739) |  |  |  |  |  |
| Payments of tax withholdings related to vesting of share-based awards | (500) |  |  | (449) |  |  |  |  |  |
| Other items, net | (3) |  |  | (14) |  |  |  |  |  |
| Net cash used by financing activities | (2,446) |  |  | (1,645) |  |  |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents | (8) |  |  | 41 |  |  |  |  |  |
| Net (decrease) increase in total cash and cash equivalents | (509) |  |  | 369 |  |  |  |  |  |
| Total cash and cash equivalents at beginning of period | 7,116 |  |  | 6,707 |  |  |  |  |  |
| Total cash and cash equivalents at end of period | $ | 6,607 |  |  | $ | 7,076 |  |  |  |  |  |

[0001728949-22-000011:8k_2_02:62]
| Qualcomm Announces First Quarter Fiscal 2022 Results | Page 7 of 8 |

[0001728949-22-000011:8k_2_02:63]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-22-000011:8k_2_02:64]
The Non-GAAP financial measures presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, our Non-GAAP financial measures might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP financial measures are presented herein.

[0001728949-22-000011:8k_2_02:65]
We use Non-GAAP financial information: (i) to evaluate, assess and benchmark our operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of our ongoing core operating businesses, including our QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by us include revenues, cost of revenues, research and development (R&D) expenses, selling, general and administrative (SG&A) expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  We are able to assess what we believe is a more meaningful and comparable set of financial performance measures by using Non-GAAP information.  In addition, the HR and Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  We present Non-GAAP financial information to provide greater transparency to investors with respect to our use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0001728949-22-000011:8k_2_02:66]
Non-GAAP information presented herein excludes our QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-22-000011:8k_2_02:67]
•QSI is excluded because we generally expect to exit our strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed as unrelated to our operational performance.

[0001728949-22-000011:8k_2_02:68]
•Share-based compensation expense primarily relates to restricted stock units.  We believe that excluding non-cash share-based compensation from the Non-GAAP financial information allows us and investors to make additional comparisons of the operating activities of our ongoing core businesses over time and with respect to other companies.

[0001728949-22-000011:8k_2_02:69]
•Certain other items are excluded because we view such items as unrelated to the operating activities of our ongoing core businesses, as follows:

[0001728949-22-000011:8k_2_02:70]
◦Acquisition-related items include amortization of acquisition-related intangible assets, substantially all of which relate to the amortization of technology-based intangible assets that is recorded in cost of revenues and will recur in future periods until the related intangible assets have been fully amortized.  We view acquisition-related intangible assets as items arising from pre-acquisition activities determined at the time of an acquisition.  Acquisition-related intangible assets contribute to revenue generation that has not been excluded from our Non-GAAP financial information.  Acquisition-related items also include recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of acquisition-related items, as well as any effects from restructuring the ownership of such acquired assets.  Additionally, we exclude third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition.

[0001728949-22-000011:8k_2_02:71]
◦We exclude certain other items that we view as unrelated to our ongoing businesses, such as major restructuring and restructuring-related costs, asset impairments and awards, settlements and/or damages arising from legal or regulatory matters.  We exclude gains and losses driven by the revaluation of our deferred compensation plan liabilities recognized in operating expenses and the offsetting gains and losses on the related plan assets recognized in investment and other income.

[0001728949-22-000011:8k_2_02:72]
◦Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of our ongoing Non-GAAP tax rate and after-tax earnings.

[0001728949-22-000011:8k_2_02:73]
| Qualcomm Announces First Quarter Fiscal 2022 Results | Page 8 of 8 |

[0001728949-22-000011:8k_2_02:74]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-22-000011:8k_2_02:75]
| (in millions, except per share data and percentages) |  |  |  | GAAP to Non-GAAP Reconciliation | Non-GAAP Supplemental Information |
|  |  |  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1 | Non-GAAP Results | QCT | QTL | Non-GAAP Reconciling Items2 |
| Q1 Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $10,705 |  | $8 |  | $— |  |  | $— |  |  | $10,697 |  | $8,847 |  | $1,818 |  | $32 |  |
| Operating income (loss) |  |  |  | 3,864 |  | 1 |  | (499) |  | (70) |  | 4,432 |  |  |  |  |  |  |  |
| EBT |  |  |  | 3,865 |  | 122 |  | (499) |  | (64) |  | 4,306 |  | 3,114 |  | 1,406 |  | (214) |  |
| EBT as % of revenues |  |  |  | 36 | % |  |  |  |  |  |  |  | 40 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 3,399 |  | 109 |  | (309) |  | (87) |  | 3,686 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $2.98 |  | $0.10 |  | ($0.27) |  | ($0.08) |  | $3.23 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,142 |  | 1,142 |  | 1,142 |  | 1,142 |  | 1,142 |  |  |  |  |  |  |  |
| Q1 Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $8,235 |  | $9 |  | $— |  |  | $— |  |  | $8,226 |  | $6,533 |  | $1,660 |  | $33 |  |
| Operating income (loss) |  |  |  | 2,526 |  | 6 |  | (393) |  | (118) |  | 3,031 |  |  |  |  |  |  |  |
| EBT |  |  |  | 2,604 |  | 158 |  | (393) |  | (73) |  | 2,912 |  | 1,919 |  | 1,270 |  | (277) |  |
| EBT as % of revenues |  |  |  | 32 | % |  |  |  |  |  |  |  | 35 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 2,455 |  | 150 |  | (231) |  | 26 |  | 2,510 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $2.12 |  | $0.13 |  | ($0.20) |  | $0.02 |  | $2.17 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,156 |  | 1,156 |  | 1,156 |  | 1,156 |  | 1,156 |  |  |  |  |  |  |  |

[0001728949-22-000011:8k_2_02:76]
(1)  Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” table below.  Details of amounts included in the “Other Items” column for the prior periods are included in the news release for those periods.

[0001728949-22-000011:8k_2_02:77]
(2)    Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations.  Non-GAAP reconciling items related to EBT consisted primarily of certain R&D expenses, SG&A expenses, other expenses or income, interest expense and certain investment income that are not allocated to segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit.

[0001728949-22-000011:8k_2_02:78]
Sums may not equal totals due to rounding.

[0001728949-22-000011:8k_2_02:79]
|  | Q1 Fiscal 2022 Supplemental Information and Reconciliations |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |
|  | Cost of revenues |  | $4,303 |  |  | $4 |  |  | $15 |  |  | $37 |  |  | $4,247 |  |
|  | Research and development expenses |  | 1,930 |  |  | — |  |  |  | 375 |  |  | 9 |  |  | 1,546 |  |
|  | Selling, general and administrative expenses |  | 608 |  |  | 3 |  |  | 109 |  |  | 24 |  |  | 472 |  |
|  | Interest expense |  | 139 |  |  | — |  |  |  | — |  |  |  | 7 |  |  | 132 |  |
|  | Investment and other income, net |  | 140 |  |  | 121 |  |  | — |  |  |  | 13 |  |  | 6 |  |
|  | Income tax expense (benefit) |  | 466 |  |  | 13 |  |  | (190) |  |  | 23 |  |  | 620 |  |

[0001728949-22-000011:8k_2_02:80]
(1)  Other items excluded from Non-GAAP results included $55 million of acquisition-related charges, $7 million of interest expense related to the 2018 and 2019 European Commission fines and $2 million of restructuring-related losses.  Other items excluded from Non-GAAP results also included $13 million of losses driven by the revaluation of our deferred compensation plan liabilities, which increased operating expenses, offset by corresponding $13 million of gains driven by the revaluation of the associated plan assets, which were included within investment and other income, net.

[0001728949-22-000011:8k_2_02:81]
(2)   At fiscal year end, the quarterly tax provision for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP.  In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column.  Tax expense in the “Other Items” column included a $26 million charge related to a foreign tax audit and a $12 million foreign currency loss related to a noncurrent receivable resulting from our refund claim of Korean withholding taxes paid in prior periods, partially offset by a $9 million benefit to reconcile the tax provision of each column to the total GAAP tax provision for the quarter, a $5 million benefit for the tax effect of acquisition-related charges and a $1 million benefit from the combined effect of other items in EBT.
