# QCOM 10-Q controls and the auditor's report


## item_4_controls

[0001728949-22-000012:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001728949-22-000012:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures. Under the supervision and with the participation of our management, including our principal executive officer and principal financial officer, we conducted an evaluation of our disclosure controls and procedures, as defined under Rule 13a-15(e) promulgated under the Securities Exchange Act of 1934, as amended (the Exchange Act). Based on this evaluation, our principal executive officer and our principal financial officer concluded that our disclosure controls and procedures were effective as of the end of the period covered by this Quarterly Report.

[0001728949-22-000012:item_4_controls:3]
Changes in Internal Control over Financial Reporting. There were no changes in our internal control over financial reporting, as defined under Rule 13a-15(f) promulgated under the Exchange Act, in the first quarter of fiscal 2022 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001728949-22-000012:item_4_controls:4]
48
