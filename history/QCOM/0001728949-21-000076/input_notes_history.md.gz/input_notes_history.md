# QCOM note change history — 0001728949-21-000043 → 0001728949-21-000066


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-07-28):
[0001728949-21-000066:note_history:1]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

- changed (2021-07-28):
[0001728949-21-000066:note_history:2]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises.
  (was, 2021-04-28, similarity 0.9743):
[0001728949-21-000043:note_history:2]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

- added (2021-07-28):
[0001728949-21-000066:note_history:3]
The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

- changed (2021-07-28):
[0001728949-21-000066:note_history:4]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At June 27, 2021, the liability, including related foreign currency losses and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $296 million and included in other current liabilities.
  (was, 2021-04-28, similarity 0.8931):
[0001728949-21-000043:note_history:4]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At March 28, 2021, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.2 billion and included in other current liabilities.

- changed (2021-07-28):
[0001728949-21-000066:note_history:5]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. From May 4, 2021 to May 6, 2021, a hearing on our appeal was held before the court. The court has not yet issued a ruling. We believe that our business practices do not violate the EU competition rules.
  (was, 2021-04-28, similarity 0.8421):
[0001728949-21-000043:note_history:5]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. A hearing before the court is scheduled for May 4-6, 2021. We believe that our business practices do not violate the EU competition rules.

- changed (2021-07-28):
[0001728949-21-000066:note_history:6]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At June 27, 2021, the liability, including related foreign currency losses and accrued interest (which, to the extent they were
  (was, 2021-04-28, similarity 0.8321):
[0001728949-21-000043:note_history:6]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation

- added (2021-07-28):
[0001728949-21-000066:note_history:7]
not related to the net investment hedge, were recorded in investment and other income, net), was $1.2 billion and included in other current liabilities.

- changed (2021-07-28):
[0001728949-21-000066:note_history:8]
Contingent losses and other considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at June 27, 2021 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.
Long-term Capacity Commitments. In the third quarter of fiscal 2021, we entered into several multi-year capacity purchase commitments with certain suppliers of our integrated circuit products. Failure to meet future minimum purchase volumes may result in incremental fees or the loss of amounts paid in advance. We currently expect to meet all future minimum purchase volume commitments in addition to other requirements related to advance and/or ongoing payment obligations. As a result of these arrangements, our future purchase obligation commitments have increased materially since September 27, 2020.
  (was, 2021-04-28, similarity 0.8103):
[0001728949-21-000043:note_history:8]
Contingent losses and other considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at March 28, 2021 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- removed (2021-07-28):
[0001728949-21-000043:note_history:9]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by

- removed (2021-07-28):
[0001728949-21-000043:note_history:10]
making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

- removed (2021-07-28):
[0001728949-21-000043:note_history:11]
adjustment. At March 28, 2021, the liability, including related foreign currency losses and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $292 million and included in other current liabilities.

- removed (2021-07-28):
[0001728949-21-000043:note_history:12]
European Commission (EC) Investigation regarding Radio Frequency Front End (RFFE): On December 3, 2019, we received a Request for Information from the EC notifying us that it was investigating whether we engaged in anti-competitive behavior in the European Union (EU)/European Economic Area (EEA) by leveraging our market position in 5G baseband processors in the RFFE space. We responded to the Request for Information and had several discussions with the EC. In March 2021, the EC informed us that it had closed its investigation.

- removed (2021-07-28):
[0001728949-21-000043:note_history:13]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of cellular modem chipsets on the purchaser first agreeing to a license to our cellular standard-essential patents, paying incentives to purchasers of cellular modem chipsets to induce them to accept certain license terms, refusing to license our cellular standard-essential patents to our competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint sought a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief. On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to rival sellers of cellular modem chipsets. On November 6, 2018, the court granted the FTC’s partial summary judgment motion. Trial was held January 4-29, 2019.

- removed (2021-07-28):
[0001728949-21-000043:note_history:14]
On May 21, 2019, the court issued an Order setting forth its Findings of Fact and Conclusions of Law. The court concluded that we had monopoly power in the CDMA and premium-tier Long Term Evolution (LTE) cellular modem chip markets, and that we had used that power in these two markets to engage in anticompetitive acts, including (1) using threats of lack of access to cellular modem chip supply to coerce OEMs to accept license terms that include unreasonably high royalty rates; (2) refusing to license our cellular standard-essential patents to competitors selling cellular modem chips; and (3) entering into exclusive dealing arrangements with OEMs that foreclosed our rivals. The court further found that the royalties we charge OEMs are unreasonably high and reflect the use of our monopoly power over CDMA and premium-tier LTE cellular modem chips rather than just the value of our patents. The court concluded that our unreasonably high royalties constitute an anticompetitive surcharge on cellular modem chips sold by our competitors, which increases the effective price of our competitors’ cellular modem chips, reduces their margins and results in exclusivity. The court also found that our practice of not licensing competitors’ cellular modem chips violated our commitments to certain standard-development organizations and a duty under the antitrust laws to license competing cellular modem chip makers and helped us maintain our royalties at unreasonably high levels. Finally, the court found that incentive funds entered into with certain OEMs further harmed competing cellular modem chip makers’ ability to undermine our monopoly position, prevented rivals from entering

- removed (2021-07-28):
[0001728949-21-000043:note_history:15]
the market and restricted the sales of those competitors that do enter. The court concluded that the combined effect of our conduct, together with our monopoly power, harmed the competitive process.

- removed (2021-07-28):
[0001728949-21-000043:note_history:16]
The court imposed the following injunctive relief: (1) we must not condition the supply of cellular modem chips on a customer’s patent license status, and we must negotiate or renegotiate license terms with customers in good faith under conditions free from the threat of lack of access to or discriminatory provision of cellular modem chip supply or associated technical support or access to software; (2) we must make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers on fair, reasonable and non-discriminatory (FRAND) terms and submit, as necessary, to arbitral or judicial dispute resolution to determine such terms; (3) we may not enter into express or de facto exclusive dealing agreements for the supply of cellular modem chips; and (4) we may not interfere with the ability of any customer to communicate with a government agency about a potential law enforcement or regulatory matter. The court also ordered us to submit to compliance and monitoring procedures for a period of seven years and to report to the FTC on an annual basis regarding our compliance with the above remedies.

- removed (2021-07-28):
[0001728949-21-000043:note_history:17]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth Circuit. On August 23, 2019, the Ninth Circuit granted our Motion for Partial Stay. On February 13, 2020, the Ninth Circuit heard oral argument.

- removed (2021-07-28):
[0001728949-21-000043:note_history:18]
On August 11, 2020, the Ninth Circuit issued its opinion, which reversed the district court’s judgment, vacated its injunction and vacated its partial grant of summary judgment. The Ninth Circuit stated that the district court erred in holding that we are under an antitrust duty to license rival chip manufacturers and noted that our practice of licensing our standard-essential patents exclusively at the OEM level does not violate the antitrust laws. The Ninth Circuit also held that the district court’s “anticompetitive surcharge” theory failed to state a cogent theory of anticompetitive harm and that our patent-licensing royalties and “no license, no chips” policy do not impose an anticompetitive surcharge on rivals’ modem chip sales and do not undermine competition in either the CDMA or premium LTE chip markets. While agreeing with the district court that our 2011 and 2013 agreements with Apple were structured like exclusive dealing contracts, the Ninth Circuit nonetheless held that neither agreement had the actual or practical effect of substantially foreclosing competition in the CDMA modem chip market, and because Apple terminated these agreements years ago, the district court had improperly issued an injunction. The Ninth Circuit noted that neither the Sherman Act nor any other law prohibits companies like us from (1) licensing their standard-essential patents independently from their chip sales and collecting royalties, and/or (2) limiting their chip customer base to licensed OEMs. On September 25, 2020, the FTC filed a Petition for Rehearing En Banc. On October 28, 2020, the Ninth Circuit denied the FTC’s petition. On March 26, 2021, the FTC’s deadline for filing a petition for certiorari with the U.S. Supreme Court to seek review of the Ninth Circuit’s decision expired. The case is now over.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0001728949-21-000066:note_history:19]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 27, 2020. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and nine months ended June 27, 2021 and June 28, 2020 included 13 weeks and 39 weeks, respectively.
  (was, 2021-04-28, similarity 0.9687):
[0001728949-21-000043:note_history:19]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 27, 2020. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 28, 2021 and March 29, 2020 included 13 weeks and 26 weeks, respectively.

- changed (2021-07-28):
[0001728949-21-000066:note_history:20]
Financial Assets: In June 2016, the Financial Accounting Standards Board (FASB) issued new accounting guidance that changed the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) are estimated based on expected losses rather than the previous incurred loss impairment model. The new accounting guidance also eliminated the concept of other-than-temporary impairment with credit losses related to available-for-sale debt securities recorded through an allowance for credit losses rather than as a reduction in the amortized cost basis of the securities. We adopted the new accounting guidance in the first quarter of fiscal 2021 under the modified retrospective transition method, except for certain available-for-sale debt securities where the prospective transition method was required, and as a result, prior period results have not been restated. The impact upon adoption was not material to our condensed consolidated financial statements. The future impact of such accounting guidance will largely depend on the future composition and credit quality of our investment portfolio and accounts receivable, as well as future economic conditions.
  (was, 2021-04-28, similarity 0.9992):
[0001728949-21-000043:note_history:20]
Financial Assets: In June 2016, the Financial Accounting Standards Board (FASB) issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) are estimated based on expected losses rather than the previous incurred loss impairment model. The new accounting guidance also eliminated the concept of other-than-temporary impairment with credit losses related to available-for-sale debt securities recorded through an allowance for credit losses rather than as a reduction in the amortized cost basis of the securities. We adopted the new accounting guidance in the first quarter of fiscal 2021 under the modified retrospective transition method, except for certain available-for-sale debt securities where the prospective transition method was required, and as a result, prior period results have not been restated. The impact upon adoption was not material to our condensed consolidated financial statements. The future impact of such accounting guidance will largely depend on the future composition and credit quality of our investment portfolio and accounts receivable, as well as future economic conditions.

- changed (2021-07-28):
[0001728949-21-000066:note_history:21]
Marketable securities include marketable equity securities, available-for-sale debt securities and, from time-to-time, certain time deposits. We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value with all realized and unrealized gains and losses on investments in marketable equity securities and realized gains and losses on available-for-sale debt securities recognized in investment and other income, net. Debt securities are classified as available for sale or held to maturity at the time of purchase and reevaluated at each balance sheet date. The realized and unrealized gains and losses on marketable securities are determined using the specific identification method.
  (was, 2021-04-28, similarity 0.9939):
[0001728949-21-000043:note_history:21]
Marketable securities include marketable equity securities, available-for-sale debt securities and, from time-to-time, certain time deposits. We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value with all realized and unrealized gains and losses on investments in marketable equity securities and realized gains and losses on available-for-sale debt securities recognized in investment and other income (expense), net. Debt securities are classified as available for sale or held to maturity at the time of purchase and reevaluated at each balance sheet date. The realized and unrealized gains and losses on marketable securities are determined using the specific identification method.

- changed (2021-07-28):
[0001728949-21-000066:note_history:22]
If a debt security has an unrealized loss and we either intend to sell the security or it is more likely than not that we will be required to sell the security before its anticipated recovery, we record an impairment charge to investment and other income, net for the entire amount of the unrealized loss and adjust the amortized cost basis of the security. For the remaining debt securities, if an unrealized loss exists, we separate the impairment into the portion of the loss related to credit factors and the portion of the loss that is not related to credit factors. Unrealized gains or unrealized losses that are not related to credit factors on available-for-sale debt securities are recorded as a component of accumulated other comprehensive income, net of income taxes. Unrealized losses that are related to credit loss factors on available-for-sale debt securities and subsequent adjustments to the credit loss are recorded as an allowance for credit losses, which is included in investment and other income, net. In evaluating whether a credit loss exists, we consider a variety of factors, including the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; the security’s relative performance versus its peers, sector or asset class; the market and economy in general; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.
  (was, 2021-04-28, similarity 0.9969):
[0001728949-21-000043:note_history:22]
If a debt security has an unrealized loss and we either intend to sell the security or it is more likely than not that we will be required to sell the security before its anticipated recovery, we record an impairment charge to investment and other income (expense), net for the entire amount of the unrealized loss and adjust the amortized cost basis of the security. For the remaining debt securities, if an unrealized loss exists, we separate the impairment into the portion of the loss related to credit factors and the portion of the loss that is not related to credit factors. Unrealized gains or unrealized losses that are not related to credit factors on available-for-sale debt securities are recorded as a component of accumulated other comprehensive income, net of income taxes. Unrealized losses that are related to credit loss factors on available-for-sale debt securities and subsequent adjustments to the credit loss are recorded as an allowance for credit losses, which is included in investment and other income, net. In evaluating whether a credit loss exists, we consider a variety of factors, including the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; the security’s relative performance versus its peers, sector or asset class; the market and economy in general; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0001728949-21-000066:note_history:23]
|  | Current |  | Noncurrent (1) |
|  | June 27,2021 |  | September 27,2020 |  | June 27,2021 |  | September 27,2020 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 5,035 |  |  | $ | 4,049 |  |  | $ | — |  |  | $ | — |  |
| Mortgage- and asset-backed and auction rate securities | 160 |  |  | 66 |  |  | — |  |  | 35 |  |
| U.S. Treasury securities and government-related securities | 10 |  |  | 10 |  |  | — |  |  | — |  |
| Total available-for-sale debt securities | 5,205 |  |  | 4,125 |  |  | — |  |  | 35 |  |
| Equity securities | 303 |  |  | 352 |  |  | — |  |  | — |  |
| Time deposit (2) | — |  |  | 30 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 5,508 |  |  | $ | 4,507 |  |  | $ | — |  |  | $ | 35 |  |
  (was, 2021-04-28, similarity 0.7473):
[0001728949-21-000043:note_history:23]
|  | Current |  | Noncurrent (1) |
|  | March 28,2021 |  | September 27,2020 |  | March 28,2021 |  | September 27,2020 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 11 |  |  | $ | 10 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 5,003 |  |  | 4,049 |  |  | — |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 176 |  |  | 66 |  |  | 35 |  |  | 35 |  |
| Total available-for-sale debt securities | 5,190 |  |  | 4,125 |  |  | 35 |  |  | 35 |  |
| Equity securities | 336 |  |  | 352 |  |  | — |  |  | — |  |
| Time deposit (2) | — |  |  | 30 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 5,526 |  |  | $ | 4,507 |  |  | $ | 35 |  |  | $ | 35 |  |

- changed (2021-07-28):
[0001728949-21-000066:note_history:24]
|  | June 27,2021 |
| Years to Maturity |  |
| Less than one year | $ | 1,938 |  |
| One to five years | 3,107 |  |
| No single maturity date | 160 |  |
| Total | $ | 5,205 |  |
  (was, 2021-04-28, similarity 0.9703):
[0001728949-21-000043:note_history:24]
|  | March 28,2021 |
| Years to Maturity |  |
| Less than one year | $ | 2,103 |  |
| One to five years | 2,911 |  |
| No single maturity date | 211 |  |
| Total | $ | 5,225 |  |

- changed (2021-07-28):
[0001728949-21-000066:note_history:25]
Debt securities with no single maturity date included mortgage- and asset-backed securities.
  (was, 2021-04-28, similarity 0.8679):
[0001728949-21-000043:note_history:25]
Debt securities with no single maturity date included mortgage- and asset-backed securities and auction rate securities.


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-07-28):
[0001728949-21-000066:note_history:26]
| Short-term Debt (in millions) |  |  |  |
|  | June 27,2021 |  | September 27,2020 |
| Commercial paper | $ | 500 |  |  | $ | 500 |  |
| Current portion of long-term debt | 1,545 |  |  | — |  |
|  | $ | 2,045 |  |  | $ | 500 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0001728949-21-000066:note_history:27]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  | June 27,2021 |  | June 28,2020 |  | June 27,2021 |  | June 28,2020 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 3,863 |  |  | $ | 2,457 |  |  | $ | 12,144 |  |  | $ | 7,461 |  |
| RFFE (2) |  |  |  |  |  |  |  |  | 957 |  |  | 447 |  |  | 2,921 |  |  | 1,509 |  |
| Automotive (3) |  |  |  |  |  |  |  |  | 253 |  |  | 138 |  |  | 705 |  |  | 456 |  |
| IoT (internet of things) (4) |  |  |  |  |  |  |  |  | 1,399 |  |  | 765 |  |  | 3,517 |  |  | 2,100 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 6,472 |  |  | $ | 3,807 |  |  | $ | 19,287 |  |  | $ | 11,526 |  |
  (was, 2021-04-28, similarity 0.9143):
[0001728949-21-000043:note_history:27]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  | March 28,2021 |  | March 29,2020 |  | March 28,2021 |  | March 29,2020 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 4,065 |  |  | $ | 2,652 |  |  | $ | 8,281 |  |  | $ | 5,004 |  |
| RFFE (2) |  |  |  |  |  |  |  |  | 903 |  |  | 650 |  |  | 1,964 |  |  | 1,063 |  |
| Automotive (3) |  |  |  |  |  |  |  |  | 240 |  |  | 171 |  |  | 452 |  |  | 318 |  |
| IoT (Internet of Things) (4) |  |  |  |  |  |  |  |  | 1,073 |  |  | 627 |  |  | 2,117 |  |  | 1,334 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 6,281 |  |  | $ | 4,100 |  |  | $ | 12,814 |  |  | $ | 7,719 |  |

- changed (2021-07-28):
[0001728949-21-000066:note_history:28]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in handsets) and excludes radio frequency transceiver components.
  (was, 2021-04-28, similarity 0.8539):
[0001728949-21-000043:note_history:28]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in handsets).

- changed (2021-07-28):
[0001728949-21-000066:note_history:29]
(3) Includes revenues from products sold for use in automobiles, including telematics, connectivity and infotainment (also known as digital cockpit).
  (was, 2021-04-28, similarity 0.8922):
[0001728949-21-000043:note_history:29]
(3) Includes revenues from products sold for use in automobiles, including telematics, connectivity and digital cockpit.

- added (2021-07-28):
[0001728949-21-000066:note_history:30]
(4) Primarily includes products sold for use in the following industry segments and applications: consumer (including computing, voice and music and XR), industrial (including handhelds, retail, transportation and logistics, and utilities) and edge networking (including mobile broadband and wireless access points).

- removed (2021-07-28):
[0001728949-21-000043:note_history:31]
(4) Primarily includes products sold for use in cellular and non-cellular connected devices within the following industry segments and applications: consumer, computing, industrial, fixed wireless broadband, voice and music and wireless networking.
