# QCOM 10-K controls and the auditor's report


## auditors_report

[0001728949-21-000076:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001728949-21-000076:auditors_report:2]
To the Board of Directors and Stockholders of QUALCOMM Incorporated

[0001728949-21-000076:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001728949-21-000076:auditors_report:4]
We have audited the accompanying consolidated balance sheets of QUALCOMM Incorporated and its subsidiaries (the “Company”) as of September 26, 2021 and September 27, 2020, and the related consolidated statements of operations, comprehensive income, stockholders’ equity and cash flows for each of the three years in the period ended September 26, 2021, including the related notes and financial statement schedule listed in the index appearing under Item 15(a)(2) (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of September 26, 2021, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001728949-21-000076:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of September 26, 2021 and September 27, 2020, and the results of its operations and its cash flows for each of the three years in the period ended September 26, 2021 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of September 26, 2021, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001728949-21-000076:auditors_report:6]
Changes in Accounting Principles

[0001728949-21-000076:auditors_report:7]
As discussed in Note 1 to the consolidated financial statements, the Company changed the manner in which it accounts for leases in fiscal 2020 and the manner in which it accounts for revenues from contracts with customers and income tax effects of intra-entity transfers of assets other than inventory in fiscal 2019.

[0001728949-21-000076:auditors_report:8]
Basis for Opinions

[0001728949-21-000076:auditors_report:9]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Report on Internal Control over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001728949-21-000076:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001728949-21-000076:auditors_report:11]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001728949-21-000076:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0001728949-21-000076:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001728949-21-000076:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001728949-21-000076:auditors_report:15]
F-1

[0001728949-21-000076:auditors_report:16]
Critical Audit Matters

[0001728949-21-000076:auditors_report:17]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001728949-21-000076:auditors_report:18]
Revenue recognition – Qualcomm CDMA Technologies (QCT) customer incentive arrangements

[0001728949-21-000076:auditors_report:19]
As described in Notes 1 and 2 to the consolidated financial statements, the Company’s QCT segment, which recorded revenues of $27.0 billion in fiscal 2021, records reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain products and technologies, in the period that the related revenues are earned. For certain QCT customer incentive arrangements, there is complexity in applying certain contractual terms to determine the amount recorded as a reduction to revenues. The amounts accrued for customer incentive arrangements are recorded as a reduction to accounts receivable, net or as other current liabilities based on whether the Company has the intent and contractual right of offset. Certain amounts recorded as a reduction to revenues for customer incentive arrangements are considered variable consideration and are included in the transaction price primarily based on estimating the most likely amount expected to be provided to the customer.

[0001728949-21-000076:auditors_report:20]
The principal considerations for our determination that performing procedures relating to revenue recognition of QCT customer incentive arrangements is a critical audit matter are the significant audit effort in performing procedures and evaluating audit evidence obtained related to the completeness and accuracy of reductions to QCT revenues recognized.

[0001728949-21-000076:auditors_report:21]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to management’s review of and accounting for customer incentive arrangements as well as controls relating to management’s review over the completeness and accuracy of reductions to revenues in fiscal 2021 and accruals for customer incentive arrangements as of the balance sheet date. These procedures also included, among others, testing the completeness and accuracy of customer incentive arrangement reductions to revenues and customer incentive arrangement accruals recorded in the consolidated financial statements, and recalculating, on a test basis, reductions to revenues and accruals for customer incentive arrangements based upon customer-specific contractual terms.

[0001728949-21-000076:auditors_report:22]
/s/ PricewaterhouseCoopers LLP

[0001728949-21-000076:auditors_report:23]
San Diego, California

[0001728949-21-000076:auditors_report:24]
November 3, 2021

[0001728949-21-000076:auditors_report:25]
We have served as the Company’s auditor since 1985.

[0001728949-21-000076:auditors_report:26]
F-2

[0001728949-21-000076:auditors_report:27]
QUALCOMM Incorporated


## item_9a

[0001728949-21-000076:item_9a:1]
Item 9A. Controls and Procedures

[0001728949-21-000076:item_9a:2]
Conclusion Regarding the Effectiveness of Disclosure Controls and Procedures

[0001728949-21-000076:item_9a:3]
Under the supervision and with the participation of our management, including our principal executive officer and our principal financial officer, we conducted an evaluation of our disclosure controls and procedures, as such terms are defined under Rule 13a-15(e) promulgated under the Securities Exchange Act of 1934, as amended (the Exchange Act). Based on this evaluation, our principal executive officer and our principal financial officer concluded that our disclosure controls and procedures were effective as of the end of the period covered by this Annual Report.

[0001728949-21-000076:item_9a:4]
Management’s Report on Internal Control over Financial Reporting

[0001728949-21-000076:item_9a:5]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). Under the supervision and with the participation of our management, including our principal executive officer and our principal financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting based on the framework in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on our evaluation under this framework, our management concluded that our internal control over financial reporting was effective as of September 26, 2021.

[0001728949-21-000076:item_9a:6]
PricewaterhouseCoopers LLP, the independent registered public accounting firm that audited our consolidated financial statements included in this Annual Report, has also audited the effectiveness of our internal control over financial reporting as of September 26, 2021, as stated in its report which appears on pages F-1 through F-2 in this Annual Report.

[0001728949-21-000076:item_9a:7]
51

[0001728949-21-000076:item_9a:8]
Inherent Limitations over Internal Controls

[0001728949-21-000076:item_9a:9]
Our internal control over financial reporting is designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of consolidated financial statements for external purposes in accordance with generally accepted accounting principles. Our internal control over financial reporting includes those policies and procedures that:

[0001728949-21-000076:item_9a:10]
i.pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of our assets;

[0001728949-21-000076:item_9a:11]
ii.provide reasonable assurance that transactions are recorded as necessary to permit preparation of consolidated financial statements in accordance with generally accepted accounting principles, and that our receipts and expenditures are being made only in accordance with authorizations of our management and directors; and

[0001728949-21-000076:item_9a:12]
iii.provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on the consolidated financial statements.

[0001728949-21-000076:item_9a:13]
Internal control over financial reporting cannot provide absolute assurance of achieving financial reporting objectives because of its inherent limitations, including the possibility of human error and circumvention by collusion or overriding of controls. Accordingly, even an effective internal control system may not prevent or detect material misstatements on a timely basis. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions or that the degree of compliance with the policies or procedures may deteriorate.

[0001728949-21-000076:item_9a:14]
Changes in Internal Control over Financial Reporting

[0001728949-21-000076:item_9a:15]
There were no changes in our internal control over financial reporting during the fourth quarter of fiscal 2021 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
