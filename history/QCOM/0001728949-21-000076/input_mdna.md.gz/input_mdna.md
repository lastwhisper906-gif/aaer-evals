# QCOM MD&A — 0001728949-21-000076


## mdna

[0001728949-21-000076:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001728949-21-000076:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes included in “Part II, Item 8. Financial Statements and Supplementary Data” of this Annual Report.

[0001728949-21-000076:mdna:3]
The following section generally discusses fiscal 2021 and 2020 items and year-to-year comparisons between fiscal 2021 and 2020. Discussions of fiscal 2019 items and year-to-year comparisons between fiscal 2020 and 2019 that are not included in this Annual Report can be found in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended September 27, 2020.

[0001728949-21-000076:mdna:4]
Fiscal 2021 Overview and Other Recent Events

[0001728949-21-000076:mdna:5]
Revenues were $33.6 billion, an increase of 43% compared to revenues of $23.5 billion in fiscal 2020, with net income of $9.0 billion, an increase of 74% compared to net income of $5.2 billion in fiscal 2020. Highlights from fiscal 2021 and other recent events included:

[0001728949-21-000076:mdna:6]
•QCT revenues increased by 64% in fiscal 2021 compared to the prior year, primarily due to an increase in demand for 5G products across handsets and RFFE, in part reflecting a recovery from the negative impacts of COVID-19, along with higher automotive and IoT revenues.

[0001728949-21-000076:mdna:7]
•QTL revenues increased by 26% in fiscal 2021 compared to the prior year, primarily due to an increase in estimated sales of 3G/4G/5G-based multimode products, in part reflecting a recovery from the negative impacts of COVID-19.

[0001728949-21-000076:mdna:8]
•QSI earnings before income taxes increased by $927 million compared to the prior year, primarily due to higher net gains on investments.

[0001728949-21-000076:mdna:9]
•On March 16, 2021, we completed the acquisition of NUVIA for $1.1 billion, net of cash acquired. NUVIA has certain in-process technologies and is comprised of a CPU (central processing unit) and technology design team with expertise in high performance processors, SoC (system-on-chip) and power management for compute-intensive devices and applications. Upon completion of development, NUVIA’s technologies are expected to be integrated into certain QCT products.

[0001728949-21-000076:mdna:10]
•On March 26, 2021, the FTC’s deadline for filing a petition for certiorari with the U.S. Supreme Court to seek review of the Ninth Circuit’s decision in our favor in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated expired. The case is now over.

[0001728949-21-000076:mdna:11]
•In October 2021, we and SSW Partners, a New York-based investment partnership, entered into a definitive agreement to acquire Veoneer, Inc. (Veoneer) for $37.00 per share in cash, which values the estimated total cash consideration to be paid to Veoneer’s shareholders at approximately $4.5 billion. At closing, SSW Partners will acquire all of the outstanding capital stock of Veoneer, shortly after which it will sell Veoneer’s Arriver business to Qualcomm and retain Veoneer’s Tier-1 automotive supplier businesses. Following the close of the Arriver business sale, we intend to incorporate Arriver’s computer vision, drive policy and driver assistance technologies into our Snapdragon automotive platform to deliver an open and competitive ADAS platform for automakers and Tier-1 automotive suppliers. Subject to the satisfaction of closing conditions, the acquisition is expected to close in 2022.

[0001728949-21-000076:mdna:12]
Our Business and Operating Segments

[0001728949-21-000076:mdna:13]
We develop and commercialize foundational technologies and products used in mobile devices and other wireless products. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents and other rights.

[0001728949-21-000076:mdna:14]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies), our cloud AI inference processing initiative and other technology and service initiatives.

[0001728949-21-000076:mdna:15]
Further information regarding our business and operating segments is provided in “Part I, Item 1. Business” of this Annual Report.

[0001728949-21-000076:mdna:16]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when licensees’ sales occur. These trends may or may not continue in the future. Further, the trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings.

[0001728949-21-000076:mdna:17]
Results of Operations

[0001728949-21-000076:mdna:18]
| Revenues (in millions) |  |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  | 2021 vs. 2020 Change |  |  |
| Equipment and services | $ | 26,741 |  |  | $ | 16,298 |  |  |  |  | $ | 10,443 |  |  |  |
| Licensing | 6,825 |  |  | 7,233 |  |  |  |  | (408) |  |  |  |
|  | $ | 33,566 |  |  | $ | 23,531 |  |  |  |  | $ | 10,035 |  |  |  |

[0001728949-21-000076:mdna:19]
2021 vs. 2020

[0001728949-21-000076:mdna:20]
The increase in revenues in fiscal 2021 was primarily due to:

[0001728949-21-000076:mdna:21]
+    $10.4 billion in higher equipment and services revenues from our QCT segment

[0001728949-21-000076:mdna:22]
+    $1.3 billion in higher licensing revenues from our QTL segment

[0001728949-21-000076:mdna:23]
-    $1.8 billion in licensing revenues from Huawei recorded in the fourth quarter of fiscal 2020 resulting from amounts due under the settlement agreement signed in July 2020 and royalties for sales made in the March 2020 and June 2020 quarters under the new global patent license agreement signed in July 2020 (which were not allocated to our segment results)

[0001728949-21-000076:mdna:24]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  | 2021 vs. 2020 Change |  |  |
| Cost of revenues | $ | 14,262 |  |  | $ | 9,255 |  |  |  |  | $ | 5,007 |  |  |  |
| Gross margin | 58 | % |  | 61 | % |  |  |  |  |  |  |

[0001728949-21-000076:mdna:25]
2021 vs. 2020

[0001728949-21-000076:mdna:26]
Gross margin percentage decreased in fiscal 2021 primarily due to:

[0001728949-21-000076:mdna:27]
-    decrease in licensing revenues from Huawei recorded in fiscal 2020 resulting from amounts due under the settlement agreement and royalties for sales made in the March 2020 and June 2020 quarters under the new global patent licensing agreement

[0001728949-21-000076:mdna:28]
-    decrease in higher margin QTL licensing revenues in proportion to QCT revenues

[0001728949-21-000076:mdna:29]
+    increase in QCT gross margin

[0001728949-21-000076:mdna:30]
|  | 2021 |  | 2020 |  |  |  | 2021 vs. 2020 Change |  |  |
| Research and development | $ | 7,176 |  |  | $ | 5,975 |  |  |  |  | $ | 1,201 |  |  |  |
| % of revenues | 21 | % |  | 25 | % |  |  |  |  |  |  |

[0001728949-21-000076:mdna:31]
2021 vs. 2020

[0001728949-21-000076:mdna:32]
The increase in research and development expenses in fiscal 2021 was due to:

[0001728949-21-000076:mdna:33]
+    $793 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), a portion of which was attributable to higher employee cash incentive program costs

[0001728949-21-000076:mdna:34]
+    $362 million increase in share-based compensation expense

[0001728949-21-000076:mdna:35]
+    $46 million increase in expenses driven by revaluation of our deferred compensation obligation on improved stock market performance (which resulted in a corresponding increase in net gains on deferred compensation plan assets within investment and other income, net due to the revaluation of the related assets)

[0001728949-21-000076:mdna:36]
|  | 2021 |  | 2020 |  |  |  | 2021 vs. 2020 Change |  |  |
| Selling, general and administrative | $ | 2,339 |  |  | $ | 2,074 |  |  |  |  | $ | 265 |  |  |  |
| % of revenues | 7 | % |  | 9 | % |  |  |  |  |  |  |

[0001728949-21-000076:mdna:37]
2021 vs. 2020

[0001728949-21-000076:mdna:38]
The increase in selling, general and administrative expenses in fiscal 2021 was primarily due to:

[0001728949-21-000076:mdna:39]
+    $164 million increase in employee-related expenses, a portion of which was attributable to higher employee cash incentive program costs

[0001728949-21-000076:mdna:40]
+    $83 million increase in share-based compensation expense

[0001728949-21-000076:mdna:41]
+    $38 million increase in expenses driven by revaluation of our deferred compensation obligation on improved stock market performance (which resulted in a corresponding increase in net gains on deferred compensation plan assets within investment and other income, net due to the revaluation of the related assets)

[0001728949-21-000076:mdna:42]
+    $32 million increase in sales and marketing expenses

[0001728949-21-000076:mdna:43]
-    $73 million decrease in litigation costs

[0001728949-21-000076:mdna:44]
|  | 2021 |  | 2020 |  |  |  | 2021 vs. 2020 Change |  |  |
| Other (income) expense | $ | — |  |  | $ | (28) |  |  |  |  | $ | 28 |  |  |  |

[0001728949-21-000076:mdna:45]
2020

[0001728949-21-000076:mdna:46]
Other income in fiscal 2020 consisted of $28 million in gains related to a favorable legal settlement.

[0001728949-21-000076:mdna:47]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  | 2021 vs. 2020 Change |  |  |
| Interest expense | $ | 559 |  |  | $ | 602 |  |  |  |  | $ | (43) |  |  |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 83 |  |  | $ | 156 |  |  |  |  | $ | (73) |  |  |  |
| Net gains on marketable securities | 427 |  |  | 198 |  |  |  |  | 229 |  |  |  |
| Net gains on other investments | 470 |  |  | 108 |  |  |  |  | 362 |  |  |  |
| Net gains on deferred compensation plan assets | 130 |  |  | 47 |  |  |  |  | 83 |  |  |  |
| Impairment losses on other investments | (33) |  |  | (405) |  |  |  |  | 372 |  |  |  |
| Net (losses) gains on derivative instruments | (14) |  |  | 8 |  |  |  |  | (22) |  |  |  |
| Equity in net earnings (losses) of investees | 13 |  |  | (21) |  |  |  |  | 34 |  |  |  |
| Net losses on foreign currency transactions | (32) |  |  | (25) |  |  |  |  | (7) |  |  |  |
|  | $ | 1,044 |  |  | $ | 66 |  |  |  |  | $ | 978 |  |  |  |

[0001728949-21-000076:mdna:48]
Net gains on marketable securities for fiscal 2021 was primarily driven by the initial public offerings of certain QSI equity investments. Net gains on other investments for fiscal 2021 was primarily driven by realized gains resulting from the sale of certain of our QSI non-marketable investments.

[0001728949-21-000076:mdna:49]
The impairment losses in fiscal 2020 were due in part to the impact COVID-19 had on certain of our investees. A significant portion of the impairment losses related to our investment in OneWeb who filed for bankruptcy in the second quarter of fiscal 2020.

[0001728949-21-000076:mdna:50]
Income Tax Expense (in millions, except percentages)

[0001728949-21-000076:mdna:51]
The following table summarizes the primary factors that caused our annual tax provision to differ from the expected income tax provision at the U.S. federal statutory rate. Substantially all of our income is in the U.S., of which a significant portion qualifies for preferential treatment as FDII (foreign-derived intangible income) at a 13% effective tax rate.

[0001728949-21-000076:mdna:52]
|  | 2021 |  | 2020 |  |  |
| Expected income tax provision at federal statutory tax rate | $ | 2,158 |  |  | $ | 1,201 |  |  |  |
| Benefit from FDII deduction | (550) |  |  | (381) |  |  |  |
| Excess tax benefit associated with share-based awards | (265) |  |  | (83) |  |  |  |
| Benefit related to the research and development tax credit | (195) |  |  | (125) |  |  |  |
| Other | 83 |  |  | (91) |  |  |  |
| Income tax expense | $ | 1,231 |  |  | $ | 521 |  |  |  |
| Effective tax rate | 12 | % |  | 9 | % |  |  |

[0001728949-21-000076:mdna:53]
In the first quarter of fiscal 2021, the United States Treasury Department issued final regulations on the foreign tax credit, which generally are applicable beginning in fiscal 2021, with certain provisions retroactive to fiscal 2019. As a result of these regulations, our fiscal 2021 effective tax rate increased by approximately 1%. The retroactive impact resulting from these new regulations, which was related to fiscal 2019 and fiscal 2020 and recorded in fiscal 2021, was not significant.

[0001728949-21-000076:mdna:54]
Unrecognized tax benefits were $2.1 billion and $1.9 billion at September 26, 2021 and September 27, 2020, respectively. The increase in unrecognized tax benefits in fiscal 2021 was primarily due to expected refunds of Korean withholding taxes previously paid as licensees in Korea continue to withhold taxes on payments due under their licensing agreements at a rate higher than we believe is owed (which had an insignificant impact to our income tax provision). If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We are subject to income taxes in the U.S. and numerous foreign jurisdictions and are currently under examination by various tax authorities worldwide, primarily related to transfer pricing. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of September 26, 2021, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0001728949-21-000076:mdna:55]
The current U.S. presidential administration and Congress have proposed to increase U.S. tax rates and/or eliminate or reduce the FDII deduction. Substantially all of our income is taxable in the U.S., of which a significant portion qualifies for preferential treatment as FDII. If such proposals are enacted into law, our provision for income taxes, results of operations and cash flows would be adversely affected (potentially materially) beginning as early as the first quarter of fiscal 2022.

[0001728949-21-000076:mdna:56]
Segment Results

[0001728949-21-000076:mdna:57]
The following should be read in conjunction with the fiscal 2021 and 2020 results of operations for each reportable segment included in this Annual Report in “Notes to Consolidated Financial Statements, Note 8. Segment Information.”

[0001728949-21-000076:mdna:58]
QCT Segment (in millions, except percentages)

[0001728949-21-000076:mdna:59]
|  | 2021 |  | 2020 |  |  |  | 2021 vs. 2020 Change |  |  |
| Revenues |  |  |  |  |  |  |  |  |  |
| Handsets (1) | $ | 16,830 |  |  | $ | 10,461 |  |  |  |  | $ | 6,369 |  |  |  |
| RFFE (2) | 4,158 |  |  | 2,362 |  |  |  |  | 1,796 |  |  |  |
| Automotive (3) | 975 |  |  | 644 |  |  |  |  | 331 |  |  |  |
| IoT (internet of things) (4) | 5,056 |  |  | 3,026 |  |  |  |  | 2,030 |  |  |  |
| Total revenues | $ | 27,019 |  |  | $ | 16,493 |  |  |  |  | $ | 10,526 |  |  |  |
| EBT (5) | $ | 7,763 |  |  | $ | 2,763 |  |  |  |  | $ | 5,000 |  |  |  |
| EBT as a % of revenues | 29 | % |  | 17 | % |  |  |  | 12 points |  |  |

[0001728949-21-000076:mdna:60]
(1) Includes revenues from products sold for use in mobile handsets, excluding RFFE (radio frequency front-end) components.

[0001728949-21-000076:mdna:61]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in mobile handsets) and excludes radio frequency transceiver components.

[0001728949-21-000076:mdna:62]
(3) Includes revenues from products sold for use in automobiles, including telematics, connectivity and digital cockpit.

[0001728949-21-000076:mdna:63]
(4) Primarily includes products sold for use in the following industries and applications: consumer (including computing, voice and music and XR), industrial (including handhelds, retail, transportation and logistics and utilities) and edge networking (including mobile broadband and wireless access points).

[0001728949-21-000076:mdna:64]
(5) Earnings (loss) before income taxes.

[0001728949-21-000076:mdna:65]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $26.6 billion and $16.1 billion in fiscal 2021 and 2020, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our stand-alone Mobile Data Modems, Snapdragon platforms (which include processors and modems), radio frequency transceiver, power management and wireless connectivity integrated chipsets.

[0001728949-21-000076:mdna:66]
QCT results for fiscal 2021 compared to the prior year reflect a recovery from the negative impacts of COVID-19.

[0001728949-21-000076:mdna:67]
2021 vs. 2020

[0001728949-21-000076:mdna:68]
The increase in QCT revenues in fiscal 2021 was primarily due to:

[0001728949-21-000076:mdna:69]
+    higher handset revenues, primarily driven by $3.6 billion in higher chipset shipments and $2.6 billion in higher revenue per chipset, both of which were primarily due to an increase in demand for 5G products from Apple and other major OEMs

[0001728949-21-000076:mdna:70]
+    higher RFFE product revenues, driven by an increase in demand for 4G/5G products from Apple and other major OEMs

[0001728949-21-000076:mdna:71]
+    higher automotive revenues, primarily driven by an increase in demand for telematics and digital cockpit products

[0001728949-21-000076:mdna:72]
+    higher IoT revenues, driven by $1.7 billion in higher shipments across consumer, edge networking and industrial products and $378 million in revenue per unit due to an increase in demand for 5G

[0001728949-21-000076:mdna:73]
QCT EBT as a percentage of revenues increased in fiscal 2021 due to:

[0001728949-21-000076:mdna:74]
+    higher revenues

[0001728949-21-000076:mdna:75]
+    higher gross margin percentage, primarily driven by favorable mix and higher average selling prices, partially offset by higher average unit costs, all of which were due to an increase in demand for 5G products

[0001728949-21-000076:mdna:76]
-    higher operating expenses, primarily driven by higher research and development expenses

[0001728949-21-000076:mdna:77]
QTL Segment (in millions, except percentages)

[0001728949-21-000076:mdna:78]
|  | 2021 |  | 2020 |  |  |  | 2021 vs. 2020 Change |  |  |
| Licensing revenues | $ | 6,320 |  |  | $ | 5,028 |  |  |  |  | $ | 1,292 |  |  |  |
| EBT | 4,627 |  |  | 3,442 |  |  |  |  | 1,185 |  |  |  |
| EBT as a % of revenues | 73 | % |  | 68 | % |  |  |  | 5 points |  |  |

[0001728949-21-000076:mdna:79]
In July 2020, we entered into a settlement agreement with Huawei to resolve our prior dispute related to the license agreement that expired on December 31, 2019. We also entered into a new long-term, global patent license agreement that applies to sales of certain wireless products by Huawei beginning on January 1, 2020. We did not record any QTL revenues for the first nine months of fiscal 2020 for royalties due on the sales of Huawei’s consumer wireless products. Revenues of $1.8 billion recorded in the fourth quarter of fiscal 2020 resulting from the settlement agreement with Huawei and royalties for sales made in the March 2020 and June 2020 quarters under the new global patent license agreement with Huawei were not allocated to our segment results.

[0001728949-21-000076:mdna:80]
2021 vs. 2020

[0001728949-21-000076:mdna:81]
The increase in QTL licensing revenues in fiscal 2021 was due to:

[0001728949-21-000076:mdna:82]
+    $1.1 billion in estimated sales of 3G/4G/5G-based multimode products, primarily due to a recovery from the negative impacts of COVID-19 and as a result of not recognizing any QTL revenues for the first nine months of fiscal 2020 for royalties due on the sales of Huawei’s consumer wireless products

[0001728949-21-000076:mdna:83]
+    $273 million in higher estimated revenues per unit, primarily due to favorable OEM mix

[0001728949-21-000076:mdna:84]
-    $103 million in lower royalty revenues recognized related to devices sold in prior periods

[0001728949-21-000076:mdna:85]
QTL EBT as a percentage of revenues increased in fiscal 2021 due to:

[0001728949-21-000076:mdna:86]
+    higher revenues

[0001728949-21-000076:mdna:87]
-    higher operating expenses, primarily driven by higher research and development expenses

[0001728949-21-000076:mdna:88]
QSI Segment (in millions)

[0001728949-21-000076:mdna:89]
|  | 2021 |  | 2020 |  |  |  | 2021 vs. 2020 Change |  |  |
| Equipment and services revenues | $ | 45 |  |  | $ | 36 |  |  |  |  | $ | 9 |  |  |  |
| EBT | 916 |  |  | (11) |  |  |  |  | 927 |  |  |  |

[0001728949-21-000076:mdna:90]
2021 vs. 2020

[0001728949-21-000076:mdna:91]
The increase in QSI EBT in fiscal 2021 was due to:

[0001728949-21-000076:mdna:92]
+     $575 million increase in net gains on investments, primarily driven by gains resulting from the initial public offerings of certain of our equity investments

[0001728949-21-000076:mdna:93]
+     $313 million decrease in impairment losses on other investments, of which a significant portion in fiscal 2020 related to our investment in OneWeb

[0001728949-21-000076:mdna:94]
+     $38 million increase in equity in net earnings of investees

[0001728949-21-000076:mdna:95]
45

[0001728949-21-000076:mdna:96]
Looking Forward

[0001728949-21-000076:mdna:97]
In the coming years, we expect new consumer demand for 3G/4G/5G multimode and 5G products and services to continue to ramp around the world as we continue to transition from 3G/4G multimode and 4G products and services. We believe that 5G will continue to drive adoption of certain technologies that are already commonly used in smartphones by industries and applications beyond mobile handsets, such as automotive and IoT. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing, and a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long term.

[0001728949-21-000076:mdna:98]
As we look forward to the next several quarters, our business may be impacted by the following key items:

[0001728949-21-000076:mdna:99]
•We expect QCT revenues to continue to be favorably impacted compared to fiscal 2021 due to increased demand across handset, RFFE, automotive and IoT revenue streams.

[0001728949-21-000076:mdna:100]
•While the semiconductor industry continues to experience certain capacity constraints, we have entered into several, and we expect to enter into additional, multi-year capacity purchase commitments with certain suppliers of our integrated circuit products in an effort to secure commitments for future supply, which we expect will allow us to continue to realize benefits from increased demand for integrated circuit products, particularly from certain Chinese OEMs as they continue to position to gain device share.

[0001728949-21-000076:mdna:101]
•We expect commercial 5G network deployments and device launches will continue.

[0001728949-21-000076:mdna:102]
•We expect our research and development costs will increase compared to fiscal 2021, primarily due to increased investment towards advancements in 5G and application processor technologies and certain other long-term initiatives, as well as an increase in share-based compensation expense.

[0001728949-21-000076:mdna:103]
•We expect continued intense competition, particularly in China.

[0001728949-21-000076:mdna:104]
•Current U.S./China trade relations and/or national security protection policies may negatively impact our business, growth prospects and results of operations. See “Risk Factors” in this Annual Report, including the Risk Factor entitled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0001728949-21-000076:mdna:105]
•We currently do not expect a significant impact on our results of operations in the future due to COVID-19. The degree to which the COVID-19 pandemic impacts our business, financial condition and results of operations will depend on future developments, which are highly uncertain. See “Risk Factors” in this Annual Report, specifically the Risk Factor titled “The coronavirus (COVID-19) pandemic had an adverse effect on our business and results of operations, and may continue to impact us in the future.”

[0001728949-21-000076:mdna:106]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless industry and governments as to the benefits of our licensing program and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may be dissatisfied with the need to pay reasonable royalties for the use of our technologies and not welcome the success of our licensing program in enabling new, highly cost-effective competitors to their products. Accordingly, such companies, and/or governments or regulators, may continue to challenge our business model in various forums throughout the world.

[0001728949-21-000076:mdna:107]
Further discussion of risks related to our business is provided in “Part I, Item 1A. Risk Factors” included in this Annual Report.

[0001728949-21-000076:mdna:108]
Liquidity and Capital Resources

[0001728949-21-000076:mdna:109]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following table presents selected financial information related to our liquidity as of and for the years ended September 26, 2021 and September 27, 2020 (in millions):

[0001728949-21-000076:mdna:110]
|  | September 26,2021 |  | September 27,2020 |  | Change |
| Cash, cash equivalents and marketable securities | $ | 12,414 |  |  | $ | 11,249 |  |  | $ | 1,165 |  |
| Accounts receivable, net | 3,579 |  |  | 4,003 |  |  | (424) |  |
| Inventories | 3,228 |  |  | 2,598 |  |  | 630 |  |
| Short-term debt | 2,044 |  |  | 500 |  |  | 1,544 |  |
| Long-term debt | 13,701 |  |  | 15,226 |  |  | (1,525) |  |
| Noncurrent income taxes payable | 1,713 |  |  | 1,872 |  |  | (159) |  |
|  | 2021 |  | 2020 |  | Change |
| Net cash provided by operating activities | $ | 10,536 |  |  | $ | 5,814 |  |  | $ | 4,722 |  |
| Net cash used by investing activities | (3,356) |  |  | (5,263) |  |  | 1,907 |  |
| Net cash used by financing activities | (6,798) |  |  | (5,707) |  |  | (1,091) |  |

[0001728949-21-000076:mdna:111]
Cash, cash equivalents and marketable securities. The net increase in cash, cash equivalents and marketable securities was primarily due to net cash provided by operating activities (which includes $1.6 billion of cash outflows related to certain advance payments made to suppliers of our integrated circuit products under multi-year capacity commitments), $430 million increase in marketable securities resulting from initial public offerings of certain non-marketable equity investments, $347 million in proceeds from the issuance of common stock (primarily under our Employee Stock Purchase Plan) and $320 million in proceeds from other investments, partially offset by $3.4 billion in payments to repurchase shares of our common stock, $3.0 billion in cash dividends paid, $1.9 billion in capital expenditures, $1.4 billion in cash paid for acquisitions and other investments (primarily related to the acquisition of NUVIA) and $737 million in payments of tax withholdings related to the vesting of share-based awards.

[0001728949-21-000076:mdna:112]
Accounts receivable, net. The decrease in accounts receivable was primarily due to payments received under the previously disclosed settlement agreement with Huawei. The decrease in accounts receivable was also partially attributable to the timing of collection of payments from certain of our QTL licensees, partially offset by an increase in QCT accounts receivable resulting from an increase in QCT revenues in the fourth quarter of fiscal 2021 as compared to the fourth quarter of fiscal 2020.

[0001728949-21-000076:mdna:113]
Inventories. The increase in inventories was primarily driven by the increase in demand for 5G products.

[0001728949-21-000076:mdna:114]
Debt. At September 26, 2021, we had $15.5 billion of principal floating- and fixed-rate notes outstanding, $1.5 billion of which matures in May 2022. The remaining debt has maturity dates in 2023 through 2050.

[0001728949-21-000076:mdna:115]
We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At September 26, 2021, we had $500 million of commercial paper outstanding.

[0001728949-21-000076:mdna:116]
On December 8, 2020, we entered into a Revolving Credit Facility replacing our prior Amended and Restated Revolving Credit Facility. There were no outstanding borrowings under the Amended and Restated Revolving Credit Facility at the time of termination. The Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At September 26, 2021, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-21-000076:mdna:117]
We expect to issue new debt in the future. The amount and timing of any such new debt will depend on a number of factors, including but not limited to maturities of our existing debt, acquisitions and strategic investments, favorable and/or acceptable interest rates and changes in corporate income tax law. Additional information regarding our outstanding debt at September 26, 2021 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 6. Debt.”

[0001728949-21-000076:mdna:118]
Income Taxes. At September 26, 2021, we estimated remaining future payments of $1.9 billion for a one-time U.S. repatriation tax accrued in fiscal 2018, after application of certain tax credits, which is payable in installments over the next five years. At September 26, 2021, other current liabilities included $196 million for the next installment due in January 2022. Additional information regarding our income taxes is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 3. Income Taxes.”

[0001728949-21-000076:mdna:119]
Acquisitions. In October 2021, we and SSW Partners entered into a definitive agreement to acquire Veoneer for total estimated cash consideration of approximately $4.5 billion, substantially all of which will be funded by Qualcomm, and we paid a $110 million termination fee to Magna International Inc., on behalf of Veoneer. Further, we have agreed to provide a

[0001728949-21-000076:mdna:120]
47

[0001728949-21-000076:mdna:121]
loan facility (or guarantee amounts provided by a third party) that provides financing to Veoneer of up to $480 million. The acquisition is expected to close in 2022. Information related to this definitive agreement to acquire Veoneer, including additional information related to certain contingent financing obligations, is included in this Annual Report in “Notes to Consolidated Financial Statements, Note 12. Subsequent Events.” We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly, to open new opportunities for our technologies, obtain development resources, grow our patent portfolio or pursue new businesses.

[0001728949-21-000076:mdna:122]
Capital Return Program. The following table summarizes stock repurchases, before commissions, and dividends paid during fiscal 2021 and 2020 (in millions, except per-share amounts):

[0001728949-21-000076:mdna:123]
|  |  | Stock Repurchase Program |  | Dividends |  | Total |
|  |  | Shares |  | Average Price Paid Per Share |  | Amount |  | Per Share |  | Amount |  | Amount |
| 2021 |  | 24 |  |  | $ | 141.17 |  |  | $ | 3,366 |  |  | $ | 2.66 |  |  | $ | 3,008 |  |  | $ | 6,374 |  |
| 2020 |  | 31 |  |  | 79.32 |  |  | 2,450 |  |  | 2.54 |  |  | 2,882 |  |  | 5,332 |  |

[0001728949-21-000076:mdna:124]
In fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30.0 billion of our common stock. On October 12, 2021, we announced a new $10.0 billion stock repurchase authorization, which is in addition to the remaining repurchase authority of $0.9 billion under the aforementioned program. The stock repurchase programs have no expiration date. Since September 26, 2021, we repurchased and retired 5.4 million shares of common stock for $703 million. Our stock repurchase programs are subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-21-000076:mdna:125]
On October 13, 2021, we announced a cash dividend of $0.68 per share on our common stock, payable on December 16, 2021 to stockholders of record as of the close of business on December 2, 2021. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-21-000076:mdna:126]
Additional Capital Requirements. We believe our cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements, in addition to the above matters, also include the items described below:

[0001728949-21-000076:mdna:127]
•Our purchase obligations at September 26, 2021, which primarily relate to purchase commitments with certain suppliers of our integrated circuit products, including those under multi-year capacity commitments, and certain other expenses, some of which relate to research and development activities and capital expenditures, totaled $23.5 billion, of which, $12.9 billion is expected to be paid in the next 12 months. We expect an increase in operating cash outflows as compared to fiscal 2021 as we make payments under the multi-year capacity commitments and as we enter into additional agreements with certain suppliers of our integrated circuit products.

[0001728949-21-000076:mdna:128]
•Our research and development expenditures were $7.2 billion in fiscal 2021 and $6.0 billion in fiscal 2020, and we expect to increase our investment in research and development in fiscal 2022, including in advancements in existing and new technologies and products.

[0001728949-21-000076:mdna:129]
•Cash outflows for capital expenditures were $1.9 billion in fiscal 2021 and $1.4 billion in fiscal 2020. We expect capital expenditures to increase in fiscal 2022 to support the increase in our manufacturing and production capacity needs.

[0001728949-21-000076:mdna:130]
•Amounts related to future lease payments for operating lease obligations at September 26, 2021 totaled $677 million, with $141 million expected to be paid within the next 12 months.

[0001728949-21-000076:mdna:131]
•At September 26, 2021, $1.5 billion was accrued related to two fines imposed by the EC (based on the exchange rate at September 26, 2021, including related foreign currency gains and accrued interest). We have provided financial guarantees in lieu of cash payment to satisfy the obligations while we appeal the EU’s decisions.

[0001728949-21-000076:mdna:132]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies” and “Part I, Item 1A. Risk Factors” in this Annual Report.

[0001728949-21-000076:mdna:133]
Critical Accounting Estimates

[0001728949-21-000076:mdna:134]
The preparation of our consolidated financial statements in accordance with accounting principles generally accepted in the United States requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and disclosure of contingent assets and liabilities. We base our estimates on historical and anticipated results and trends and on various other assumptions that we believe are reasonable under the circumstances, including assumptions as to future events. By their nature, estimates are subject to an inherent degree of uncertainty. Although we believe that our estimates and the assumptions supporting our assessments are reasonable, actual results that differ from our estimates could be material to our consolidated financial statements.

[0001728949-21-000076:mdna:135]
Refer to “Note 1. Significant Accounting Policies” and “Note 2. Composition of Certain Financial Statement Items” included in this Annual Report in “Notes to Consolidated Financial Statements” for further information on our critical accounting estimates and policies, which are as follows. In addition, if the impact of changes in our critical accounting estimates are material or considered necessary to understand our results of operations for the periods presented, then such information is disclosed within this Annual Report in “Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations, Results of Operations.”

[0001728949-21-000076:mdna:136]
Revenue Recognition. We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. We estimate and recognize sales-based royalties on such licensed products in the period in which the licensees’ sales occur, which is based largely on preliminary royalty estimates provided by our licensees. Actual amounts for sales-based royalties have been materially consistent with such estimates, and no significant reversals of revenues have been required as a result of adjustments to prior period royalty estimates. Significant evaluation and judgment were required in determining the appropriate accounting for the settlement agreement and the global patent license agreement with Huawei, which were signed in the fourth quarter of fiscal 2020. We considered, among other items, Huawei’s commitment to perform under such agreements (including Huawei’s intent and ability to pay amounts due), Huawei’s performance as of the date of assessment under the agreements (including timely payments made), Huawei’s then-current and projected financial condition (including the impact of enacted national security protection policies by the U.S. government on Huawei’s business) and certain contractual protections that we obtained under these agreements. In the fourth quarter of fiscal 2021, Huawei paid the final installment under the settlement agreement, and there were no changes to our previous judgments, estimates and initial evaluation related to the revenues recorded in fiscal 2020 under the settlement agreement.

[0001728949-21-000076:mdna:137]
Impairment of Non-marketable Equity Investments. We monitor our investments for events or circumstances that could indicate impairment, including those that result from observable price adjustments. In fiscal 2021, we recorded impairment losses on other investments (which primarily related to our non-marketable equity investments) of $33 million, a decrease of $372 million compared to fiscal 2020. Significant evaluation and judgments were required in determining if the negative effects of COVID-19 indicated that such investments were impaired, and if so, the extent of such impairment. This included, among other items: (i) assessing the business impacts that COVID-19 had on our investees, including taking into consideration the investee’s industry and geographic location and the impact to its customers, suppliers and employees, as applicable, (ii) evaluating the investees’ ability to respond to the impacts of COVID-19, including any significant deterioration in the investee’s financial condition and cash flows, as well as assessing liquidity and/or going concern risks and (iii) considering any appreciation in fair value that has not been recognized in the carrying values of such investments. Based on this evaluation, certain of our investments were impaired and written down to their estimated fair values in fiscal 2020 (a significant portion of which related to the full impairment of our investment in OneWeb, who filed for bankruptcy in the second quarter of fiscal 2020). For a significant portion of the impairment losses recorded in 2020, the estimated fair values resulted in a full write-off of the carrying value. In fiscal 2021, there were no significant impairment losses or adjustments to our previous judgments and estimates recorded.

[0001728949-21-000076:mdna:138]
Inventories. We measure inventory at the lower of cost or net realizable value considering judgments related to future demand and market conditions, such as the impact of certain capacity constraints experienced across the semiconductor industry in fiscal 2021 and the impacts of COVID-19 in fiscal 2020. For fiscal 2021 and 2020, the overall net effect on our operating results from changes in this estimate were not material.

[0001728949-21-000076:mdna:139]
Impairment of Goodwill and Long-Lived Assets. We monitor our goodwill and long-lived assets for the existence of impairment indicators and apply judgments in the valuation methods and underlying assumptions utilized in such assessments. During fiscal 2021 and fiscal 2020, impairment charges for long-lived assets were negligible. Additionally, the estimated fair values of our QCT and QTL reporting units, based on our qualitative assessment, were substantially in excess of their respective carrying values at September 26, 2021.

[0001728949-21-000076:mdna:140]
Legal and Regulatory Proceedings. We record our best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. We face difficulties in evaluating or estimating likely outcomes or the amount of possible loss in certain legal and regulatory proceedings.

[0001728949-21-000076:mdna:141]
Income Taxes. We make significant judgments and estimates in determining our provision for income taxes, including our assessment of our income tax positions given the uncertainties involved in the interpretation and application of complex tax laws and regulations in various taxing jurisdictions.

[0001728949-21-000076:mdna:142]
Recent Accounting Pronouncements

[0001728949-21-000076:mdna:143]
Information regarding recent accounting pronouncements and the impact of those pronouncements, if any, on our consolidated financial statements is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 1. Significant Accounting Policies.”
