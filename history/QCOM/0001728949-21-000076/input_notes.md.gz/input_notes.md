# QCOM notes — 0001728949-21-000076


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001728949-21-000076:notes:1]
Significant Accounting Policies
We are a global leader in the development and commercialization of foundational technologies for the wireless industry. Our technologies and products are used in mobile devices and other wireless products, including those used in the internet of things (IoT) and automotive systems for telematics, connectivity and digital cockpit (also known as infotainment). We derive revenues principally from sales of integrated circuit products and through the licensing of our intellectual property, including patents and other rights.

[0001728949-21-000076:notes:2]
Principles of Consolidation. The consolidated financial statements include the assets, liabilities and operating results of Qualcomm and its subsidiaries. Intercompany transactions and balances have been eliminated.

[0001728949-21-000076:notes:3]
Financial Statement Preparation. The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in our consolidated financial statements and the accompanying notes. Examples of our significant accounting estimates and policies that may involve a higher degree of judgment and complexity than others include: the estimation of sales-based royalty revenues; the impairment of non-marketable equity investments; the valuation of inventories; the impairment of goodwill and long-lived assets; the recognition, measurement and disclosure of loss contingencies related to legal and regulatory proceedings; and the calculation of our income tax provision, including the recognition and measurement of uncertain tax positions. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

[0001728949-21-000076:notes:4]
Fiscal Year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. The fiscal years ended September 26, 2021, September 27, 2020 and September 29, 2019 each included 52 weeks.

[0001728949-21-000076:notes:5]
Recently Adopted Accounting Pronouncements.

[0001728949-21-000076:notes:6]
Financial Assets: In June 2016, the Financial Accounting Standards Board (FASB) issued new accounting guidance that changed the accounting for recognizing impairments of financial assets (ASC 326). Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) are estimated based on expected losses rather than the previous incurred loss impairment model. The new accounting guidance also eliminated the concept of other-than-temporary impairment with credit losses related to available-for-sale debt securities recorded through an allowance for credit losses rather than as a reduction in the amortized cost basis of the securities. We adopted the new accounting guidance in the first quarter of fiscal 2021 under the modified retrospective transition method, except for certain available-for-sale debt securities where the prospective transition method was required, and as a result, prior period results have not been restated. The impact upon adoption was not material to our consolidated financial statements. The future impact of such accounting guidance will largely depend on the future composition and credit quality of our investment portfolio and accounts receivable, as well as future economic conditions.

[0001728949-21-000076:notes:7]
Leases: In February 2016, the FASB issued new accounting guidance related to leases that outlines a new comprehensive lease accounting model and requires expanded disclosures (ASC 842). Under the new accounting guidance, we are required to recognize right-of-use assets and corresponding lease liabilities on the consolidated balance sheet. We adopted ASC 842 in the first quarter of fiscal 2020 using the modified retrospective approach, with the cumulative effect of initial adoption recorded as an adjustment to our opening consolidated balance sheet at September 30, 2019. We elected to not record leases with a term of 12 months or less on our consolidated balance sheet. In addition, we applied the package of practical expedients permitted under the transition guidance, which among other things, does not require reassessment of lease classification upon adoption. Finance leases were not material for all periods presented. Adoption of the new accounting guidance did not have a material impact on our consolidated statements of operations or cash flows. Results for fiscal 2019 have not been restated and continue to be reported in accordance with the accounting guidance in effect for those periods.

[0001728949-21-000076:notes:8]
Revenue Recognition: In May 2014, the FASB issued new accounting guidance related to revenue recognition (ASC 606). We adopted ASC 606 in the first quarter of fiscal 2019 using the modified retrospective transition method only to those contracts that were not completed as of October 1, 2018. We recognized the cumulative effect of initially applying the new revenue accounting guidance as an adjustment to opening retained earnings.

[0001728949-21-000076:notes:9]
Income Taxes: In October 2016, the FASB issued new accounting guidance that changes the accounting for the income tax effects of intra-entity transfers of assets other than inventory. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings of $2.6 billion, primarily as the result of establishing a deferred tax asset on the basis difference of certain intellectual property distributed from one of our foreign subsidiaries to a subsidiary in the United States in fiscal 2018.

[0001728949-21-000076:notes:10]
Cash Equivalents. We consider all highly liquid investments with original maturities of 90 days or less to be cash equivalents. Cash equivalents may be comprised of money market funds, certificates of deposit, commercial paper, corporate bonds and notes, certain bank time and demand deposits and government agencies’ securities. The carrying amounts approximate fair value due to the short maturities of these instruments.

[0001728949-21-000076:notes:11]
Marketable Securities. As a result of the adoption of ASC 326, we revised our accounting policy beginning in fiscal 2021 as follows.

[0001728949-21-000076:notes:12]
Marketable securities include marketable equity securities, available-for-sale debt securities and, from time-to-time, certain time deposits. We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value with all realized and unrealized gains and losses on investments in marketable equity securities and realized gains and losses on available-for-sale debt securities recognized in investment and other income, net. Debt securities are classified as available for sale or held to maturity at the time of purchase and reevaluated at each balance sheet date. The realized and unrealized gains and losses on marketable securities are determined using the specific identification method.

[0001728949-21-000076:notes:13]
If a debt security has an unrealized loss and we either intend to sell the security or it is more likely than not that we will be required to sell the security before its anticipated recovery, we record an impairment charge to investment and other income, net for the entire amount of the unrealized loss and adjust the amortized cost basis of the security. For the remaining debt securities, if an unrealized loss exists, we separate the impairment into the portion of the loss related to credit factors and the portion of the loss that is not related to credit factors. Unrealized gains or unrealized losses that are not related to credit factors on available-for-sale debt securities are recorded as a component of accumulated other comprehensive income, net of income taxes. Unrealized losses that are related to credit loss factors on available-for-sale debt securities and subsequent adjustments to the credit loss are recorded as an allowance for credit losses, which is included in investment and other income, net. In evaluating whether a credit loss exists, we consider a variety of factors, including the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; the security’s relative performance versus its peers, sector or asset class; the market and economy in general; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.

[0001728949-21-000076:notes:14]
Equity Method and Non-marketable Equity Investments. Equity investments for which we have significant influence, but not control, over the investee and are not the primary beneficiary of the investee’s activities are accounted for under the equity method. Our share of gains and losses in equity method investments are recorded in investment and other income, net. We eliminate unrealized profit or loss related to transactions with equity method investees in relation to our ownership interest in the investee, which is recorded as a component of equity in net earnings (losses) in investees in investment and other income, net. Non-marketable equity investments (for which we do not have significant influence or control) are investments without readily determinable fair values that are recorded based on initial cost minus impairment, if any, plus or minus adjustments resulting from observable price changes in orderly transactions for identical or similar securities, if any. All gains and losses on investments in non-marketable equity securities, realized and unrealized, are recognized in investment and other income, net. We monitor equity method and non-marketable equity investments for events or circumstances that could indicate the investments are impaired, such as a deterioration in the investee’s financial condition and business forecasts and lower valuations in recently completed or anticipated financings, and recognize a charge to investment and other income, net for the difference between the estimated fair value and the carrying value. For equity method investments, we record impairment losses in earnings only when impairments are considered other-than-temporary.

[0001728949-21-000076:notes:15]
Derivatives. Our primary objectives for holding derivative instruments are to manage foreign exchange risk for certain foreign currency revenues, operating expenses, receivables and payables and to manage interest rate risk on our long-term debt. Derivative instruments are recorded at fair value and included in other current or noncurrent assets or other current or noncurrent liabilities based on their maturity dates. Counterparties to these derivative instruments are all major banking institutions.

[0001728949-21-000076:notes:16]
Foreign Currency Hedges: We manage our exposure to foreign exchange market risks, when deemed appropriate, through the use of derivative instruments, including foreign currency forward and option contracts with financial counterparties, that may or may not be designated as hedging instruments. At September 26, 2021, these derivative instruments have maturity dates between one and 21 months. Gains and losses arising from such contracts that are designated as cash flow hedging instruments are recorded as a component of accumulated other comprehensive income as gains and losses on derivative instruments, net of income taxes. The hedging gains and losses in accumulated other comprehensive income are subsequently reclassified to revenues or costs and expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect our earnings. The cash flows associated with derivative instruments designated as cash flow hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The fair values of our foreign currency forward and option contracts used to hedge foreign currency risk designated as cash flow hedges recorded in total assets and in total liabilities were $42 million and negligible, respectively, at September 26, 2021. The fair values of our foreign currency forward and option contracts used to hedge foreign currency risk designated as cash flow hedges recorded in total assets and in total liabilities were $51 million and negligible, respectively, at September 27, 2020.

[0001728949-21-000076:notes:17]
For foreign currency forward and option contracts not designated as hedging instruments, the changes in fair value are recorded in investment and other income, net in the period of change. The cash flows associated with such derivative instruments not designated as hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The fair values of our foreign currency

[0001728949-21-000076:notes:18]
forward and option contracts not designated as hedging instruments were negligible at September 26, 2021 and September 27, 2020.

[0001728949-21-000076:notes:19]
Interest Rate Swaps: From time to time, we manage our exposure to certain interest rate risks related to our long-term debt through the use of interest rate swaps. Such swaps allow us to effectively convert fixed-rate payments into floating-rate payments based on LIBOR. These transactions are designated as fair value hedges, and the gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate debt attributable to the hedged risks, are recognized in earnings as interest expense in the current period. The interest settlement payments associated with the interest rate swap agreements are classified as cash flows from operating activities in the consolidated statements of cash flows. There were no outstanding interest rate swaps related to long-term debt at September 26, 2021 and September 27, 2020.

[0001728949-21-000076:notes:20]
During fiscal 2021, we entered into forward-starting interest rate swaps to hedge the variability of forecasted interest payments on anticipated debt issuances through 2025. These transactions are designated as cash flow hedges of a forecasted transaction. The gains and losses arising from such contracts are recorded as a component in accumulated other comprehensive income as gains and losses on derivative instruments, net of taxes. When the anticipated debt issuances are completed, the hedging gains and losses in accumulated other comprehensive income are reclassified as interest expense over the terms of the related debt issued. The fair values of our forward-starting interest rate swaps recorded in total liabilities were $105 million at September 26, 2021.

[0001728949-21-000076:notes:21]
Gross Notional Amounts: The gross notional amounts of our foreign currency and interest rate derivatives by instrument type were as follows (in millions):

[0001728949-21-000076:notes:22]
|  | September 26,2021 |  | September 27,2020 |
| Forwards | $ | 2,449 |  |  | $ | 1,096 |  |
| Options | 870 |  |  | 789 |  |
| Swaps | 2,600 |  |  | — |  |
|  | $ | 5,919 |  |  | $ | 1,885 |  |

[0001728949-21-000076:notes:23]
The gross notional amounts of our derivatives by currency were as follows (in millions):

[0001728949-21-000076:notes:24]
|  | September 26,2021 |  | September 27,2020 |
| Chinese renminbi | $ | 1,627 |  |  | $ | 1,058 |  |
| Indian rupee | 1,262 |  |  | 595 |  |
| British pound sterling | 83 |  |  | — |  |
| Japanese yen | 27 |  |  | 33 |  |
| United States dollar | 2,920 |  |  | 199 |  |
|  | $ | 5,919 |  |  | $ | 1,885 |  |

[0001728949-21-000076:notes:25]
Other Hedging Activities. We have designated $1.5 billion of foreign currency-denominated liabilities, excluding accrued interest, related to the fines imposed by the European Commission as hedges of our net investment in certain foreign subsidiaries at September 26, 2021 and September 27, 2020. Gains and losses arising from the portion of these balances that are designated as net investment hedges are recorded as a component of accumulated other comprehensive income as foreign currency translation adjustment.

[0001728949-21-000076:notes:26]
Fair Value Measurements. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants as of the measurement date. Applicable accounting guidance provides an established hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Observable inputs are inputs that market participants would use in valuing the asset or liability and are developed based on market data obtained from sources independent of us. Unobservable inputs are inputs that reflect our assumptions about the factors that market participants would use in valuing the asset or liability. There are three levels of inputs that may be used to measure fair value:

[0001728949-21-000076:notes:27]
•Level 1 includes financial instruments for which quoted market prices for identical instruments are available in active markets.

[0001728949-21-000076:notes:28]
•Level 2 includes financial instruments for which there are inputs other than quoted prices included within Level 1 that are observable for the instrument.

[0001728949-21-000076:notes:29]
•Level 3 includes financial instruments for which fair value is derived from valuation techniques in which one or more significant inputs are unobservable, including our own assumptions.

[0001728949-21-000076:notes:30]
Assets and liabilities measured at fair value are classified based on the lowest level of input that is significant to the fair value measurement. We review the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy. We recognize transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer to occur.

[0001728949-21-000076:notes:31]
Cash Equivalents and Marketable Securities: With the exception of auction rate securities, we obtain pricing information from quoted market prices, pricing vendors or quotes from brokers/dealers. We conduct reviews of our primary pricing vendors to determine whether the inputs used in the vendor’s pricing processes are deemed to be observable. The fair value for interest-bearing securities includes accrued interest.

[0001728949-21-000076:notes:32]
The fair value of U.S. Treasury securities and government-related securities, corporate bonds and notes and common stock is generally determined using standard observable inputs, including reported trades, quoted market prices, matrix pricing, benchmark yields, broker/dealer quotes, issuer spreads, two-sided markets and/or benchmark securities.

[0001728949-21-000076:notes:33]
The fair value of mortgage- and asset-backed securities is derived from the use of matrix pricing (prices for similar securities) or, in some cases, cash flow pricing models with observable inputs, such as contractual terms, maturity, credit rating and/or securitization structure to determine the timing and amount of future cash flows.

[0001728949-21-000076:notes:34]
The fair value of auction rate securities is estimated using a discounted cash flow model that incorporates transaction details, such as contractual terms, maturity and timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery, the future state of the auction rate market and credit valuation adjustments of market participants. Though most of the securities we held were pools of student loans guaranteed by the United States government, prepayment speeds and illiquidity discounts are considered significant unobservable inputs, and therefore, auction rate securities were included in Level 3. During fiscal 2021, we sold all of our investments held in auction rate securities.

[0001728949-21-000076:notes:35]
Derivative Instruments: Derivative instruments that are traded on an exchange are valued using quoted market prices and are included in Level 1. Derivative instruments that are not traded on an exchange are valued using conventional calculations/models that are primarily based on observable inputs, such as foreign currency exchange rates, volatilities and interest rates, and therefore, such derivative instruments are included in Level 2.

[0001728949-21-000076:notes:36]
Other Investments and Other Liabilities: Other investments and other liabilities included in Level 1 are comprised of our deferred compensation plan liabilities and related assets, which consist of mutual funds and are included in other current assets and other assets. Gains and losses on the revaluation of our deferred compensation plan assets are recorded in investment and other income, net and are not allocated to our segments. Corresponding offsetting amounts related to the revaluation of our deferred compensation plan liabilities are included in unallocated operating expenses. Other investments included in Level 3 are comprised of contingently issuable equity instruments and warrants issued in connection with certain mergers and initial public offerings of our non-marketable equity investees and convertible debt instruments issued by private companies. The inputs we use to estimate the fair values of these instruments are generally unobservable, and therefore, they are included in Level 3.

[0001728949-21-000076:notes:37]
Nonrecurring Fair Value Measurements: We measure certain assets and liabilities at fair value on a nonrecurring basis. These assets and liabilities include equity method and non-marketable equity investments, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired, all of which are generally measured based on unobservable inputs using an income or market approach.

[0001728949-21-000076:notes:38]
Inventories. Inventories are valued at the lower of cost and net realizable value using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers and our own forecasts of customer demand, among other factors. This valuation also requires us to make judgments and assumptions based on information currently available about market conditions, including competition, product pricing, product life cycle, development plans and other broader market conditions that may impact customer demand, such as the impact of certain capacity constraints experienced across the semiconductor industry in fiscal 2021 and the impacts of COVID-19 in fiscal 2020. As we move to smaller geometry process technologies, the manufacturing lead-time increases, resulting in an increased reliance on our own forecasts of customer demand, rather than our customers’ forecasts. If we overestimate demand for our products, the amount of our loss will be impacted by our contractual ability to reduce inventory purchases from our suppliers, including those under our multi-year capacity purchase commitments. Our assumptions of future product demand are inherently uncertain, and changes in our estimates and assumptions may cause us to record additional write-downs in the future if demand forecasted for specific products is greater than actual demand.

[0001728949-21-000076:notes:39]
Property, Plant and Equipment. Property, plant and equipment are recorded at cost and depreciated or amortized using the straight-line method over their estimated useful lives. Upon the retirement or disposition of property, plant and equipment, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded, when appropriate. Buildings on owned land are depreciated over 30 years, and building improvements are depreciated over 15 years. Leasehold improvements and buildings on leased land are amortized over the shorter of their estimated useful lives, not to exceed 15 years and 30 years, respectively, or the remaining term of the related lease. Other property, plant and equipment

[0001728949-21-000076:notes:40]
have useful lives ranging from 2 to 25 years. Maintenance, repairs and minor renewals or betterments are charged to expense as incurred.

[0001728949-21-000076:notes:41]
Operating Leases. Operating lease assets and liabilities are recognized for leases with lease terms greater than 12 months based on the present value of the future lease payments over the lease term at the commencement date. Operating leases are included in other assets, other current liabilities and other liabilities on our consolidated balance sheet. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise such option. We account for substantially all lease and related non-lease components together as a single lease component. Operating lease expense is recognized on a straight-line basis over the lease term.

[0001728949-21-000076:notes:42]
Goodwill and Other Intangible Assets. Goodwill represents the excess of purchase price over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Acquired intangible assets other than goodwill are amortized over their useful lives unless the lives are determined to be indefinite. For intangible assets purchased in a business combination, the estimated fair values of the assets received are used to establish their recorded values. For intangible assets acquired in a nonmonetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value. An estimate of fair value can be affected by many assumptions that require significant judgment. For example, the income approach generally requires us to use assumptions to estimate future cash flows including those related to total addressable market, pricing and share forecasts, competition, technology obsolescence, future tax rates and discount rates. Our estimate of the fair value of certain assets may differ materially from that determined by others who use different assumptions or utilize different business models and from the future cash flows actually realized.

[0001728949-21-000076:notes:43]
Impairment of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. Goodwill and other indefinite-lived intangible assets are tested annually for impairment in the fourth fiscal quarter and in interim periods, if events or changes in circumstances indicate that the assets may be impaired. If a qualitative assessment is used and we determine that the fair value of a reporting unit or indefinite-lived intangible asset is more likely than not (i.e., a likelihood of more than 50%) less than its carrying amount, a quantitative impairment test will be performed. If goodwill is quantitatively assessed for impairment and a reporting unit’s carrying value exceeds its fair value, the difference is recorded as an impairment. Other indefinite-lived intangible assets are quantitatively assessed for impairment, if necessary, by comparing their estimated fair values to their carrying values. If the carrying value exceeds the fair value, the difference is recorded as an impairment. Our judgments regarding the existence of impairment indicators and future cash flows related to goodwill and long-lived assets may be based on operational performance of our businesses, market conditions, expected selling price and/or other factors. Although there are inherent uncertainties in this assessment process, the estimates and assumptions we use, including estimates of future cash flows and discount rates, are consistent with our internal planning, when appropriate. If these estimates or their related assumptions change in the future, we may be required to record an impairment charge on a portion or all of our goodwill and/or long-lived assets. Furthermore, we cannot predict the occurrence of future impairment-triggering events nor the impact such events might have on our reported asset values. Future events could cause us to conclude that impairment indicators exist, and that goodwill associated with our acquired businesses are impaired.

[0001728949-21-000076:notes:44]
Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by comparing the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Long-lived assets to be disposed of by sale are reported at the lower of their carrying amounts or their estimated fair values less costs to sell and are not depreciated.

[0001728949-21-000076:notes:45]
Revenue Recognition. We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We also generate revenues from licensing system software and by performing development and other services and from other product sales. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of our performance obligations.

[0001728949-21-000076:notes:46]
Revenues from sales of our products are recognized upon transfer of control to the customer, which is generally at the time of shipment. Revenues from providing services are typically recognized over time as our performance obligation is satisfied. Revenues from providing services and licensing system software were each less than 5% of total revenues for all periods presented.

[0001728949-21-000076:notes:47]
We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain

[0001728949-21-000076:notes:48]
categories of complete wireless devices, namely smartphones, tablets, laptops and smartwatches, and provide for a maximum royalty amount payable per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, considering all relevant information (historical, current and forecasted) that is reasonably available to us. Our estimates of sales-based royalties are based largely on preliminary royalty estimates provided by our licensees and, to a lesser extent, an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property, combined with an estimate of the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products. We have recognized immaterial differences between preliminary royalty estimates provided to us by licensees and actual amounts reported and paid by licensees, which are generally received the following quarter, as licensees have not completed their royalty reporting process at the time estimates are provided to us, and in certain cases, they do not provide all necessary information in order for us to calculate an estimate of royalties due, which requires us to independently estimate certain information. We also consider in our estimates of sales-based royalties any changes in pricing we plan or expect to make and certain constraints on our ability to estimate such royalties. As a result of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

[0001728949-21-000076:notes:49]
License agreements that require payment of license fees contain a single performance obligation that represents ongoing access to a portfolio of intellectual property over the license term since such agreements provide the licensee the right to access a portfolio of intellectual property that exists at inception of the license agreement and to updates and new intellectual property that is added to the licensed portfolio during the term of the agreement that are highly interdependent or interrelated. Since we expect to expend efforts to develop and transfer updates to our licensed portfolio on an even basis, license fees are recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee.

[0001728949-21-000076:notes:50]
We account for a contract with a customer/licensee when it is legally enforceable, the parties are committed to perform their respective obligations, the rights of the parties regarding the goods and/or services to be transferred are identified, payment terms are identified, the contract has commercial substance and collectability of substantially all of the consideration is probable. If all such conditions are not met, revenues and any associated receivables are generally not recognized until such time that the required conditions are met. Cash collected from customers prior to a contract existing is recorded to other customer-related liabilities in other current liabilities.

[0001728949-21-000076:notes:51]
From time to time, regulatory authorities investigate our business practices, particularly with respect to our licensing business, and institute proceedings against us. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed original equipment manufacturers (OEMs) or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. Additionally, from time to time, companies initiate various strategies in an attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property, which may include disputing, underreporting, underpaying, not reporting and/or not paying royalties owed to us under their license agreements with us, or reporting to us in a manner that is not in compliance with their contractual obligations. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in the revenue recognition guidance, which includes, among other items, evaluating whether our license agreements remain valid and enforceable and evaluating licensees’ conduct and whether they remain committed to perform their respective obligations. We also estimate and recognize licensing revenues only to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur, which includes, among other items, determining the expected impact, if any, to revenues of any license agreements that may be renegotiated and/or are newly entered into. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us. These aforementioned estimates may require significant judgment.

[0001728949-21-000076:notes:52]
We measure revenues (including our estimates of sales-based royalties) based on the amount of consideration we expect to receive in exchange for products or services. We record reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of our products and technologies, in the period that the related revenues are earned. For certain QCT (Qualcomm CDMA Technologies) customer incentive arrangements, there is complexity in applying certain contractual terms to determine the amount recorded as a reduction to revenues. No significant reversals of revenues have been made related to such amounts previously recorded. The amounts accrued for customer incentive arrangements are recorded as a reduction to accounts receivable, net or as other current liabilities based on whether we have the intent and contractual right of offset. Certain amounts recorded as a reduction to revenues for customer incentive arrangements are considered variable

[0001728949-21-000076:notes:53]
consideration and are included in the transaction price primarily based on estimating the most likely amount expected to be provided to the customer/licensee.

[0001728949-21-000076:notes:54]
Adjustments made to revenues in subsequent periods to reflect changes in estimates as new information becomes available are included in our disclosure of revenues recognized from previously satisfied performance obligations.

[0001728949-21-000076:notes:55]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied performance obligations.

[0001728949-21-000076:notes:56]
Concentrations. A significant portion of our revenues are concentrated with a small number of customers/licensees of our QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments. The comparability of customer/licensee concentrations for the periods presented are impacted by the timing of customer/licensees device launches and/or innovation cycles, among other fluctuations in demand. Revenues from each customer/licensee that were 10% or greater of total revenues were as follows:

[0001728949-21-000076:notes:57]
|  | September 26,2021 |  | September 27,2020 |  | September 29,2019 |
| Customer/licensee (w) | 23 | % |  | 10 | % |  | 24 | % |
| Customer/licensee (x) | 14 |  |  | 19 |  |  | 15 |  |
| Customer/licensee (y) | 13 |  |  | 12 |  |  | 10 |  |
| Customer/licensee (z) | * |  | 10 |  |  | * |

[0001728949-21-000076:notes:58]
* Less than 10%

[0001728949-21-000076:notes:59]
We rely on sole- or limited-source suppliers for some products, particularly products in the QCT segment, subjecting us to possible shortages of raw materials or manufacturing capacity. The loss of a supplier or the inability of a supplier to meet performance or quality specifications or delivery schedules could harm our ability to meet our delivery obligations and/or negatively impact our revenues, business operations and ability to compete for future business.

[0001728949-21-000076:notes:60]
Share-Based Compensation. Share-based compensation expense for equity-classified awards, principally related to restricted stock units (RSUs), is measured at the grant date, or at the acquisition date for awards assumed in business combinations, based on the estimated fair value of the award and is recognized over the employee’s requisite service period. The fair values of RSUs are estimated based on the fair market values of the underlying stock on the dates of grant or dates the RSUs are assumed. Share-based compensation expense is adjusted to exclude amounts related to share-based awards that are expected to be forfeited.

[0001728949-21-000076:notes:61]
Legal and Regulatory Proceedings. We are currently involved in certain legal and regulatory proceedings. Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Investigations by antitrust and trade regulation agencies are not conducted in a consistent manner across jurisdictions. Further, each country and agency has different sets of laws, rules and regulations, both substantive and procedural, as well as different legal principles, theories and potential remedies, and some agencies may seek to use the investigation to advance domestic policy goals. Depending on the jurisdiction, these investigations can involve non-transparent procedures under which we may not receive access to evidence relied upon by the enforcement agency or that may be exculpatory and may not be informed of the specific legal theories or evidence considered or relied upon by the agency. Unlike in civil litigation in the United States, in foreign proceedings, we may not be entitled to discovery or depositions, allowed to cross-examine witnesses or confront our accusers. As a result, we may not be aware of, and may not be entitled to know, all allegations against us, or the information or documents provided to, or discovered or prepared by, the agency. Accordingly, we may have little or no idea what an agency’s intent is with respect to liability, penalties or the timing of a decision. In many cases the agencies are given significant discretion, and any available precedent may have limited, if any, predictive value in their jurisdictions, much less in other jurisdictions. Accordingly, we cannot predict the outcome of these matters. A broad range of remedies with respect to our business practices that are deemed to violate applicable laws are potentially available. These remedies may include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or to modify our business practices.

[0001728949-21-000076:notes:62]
If there is at least a reasonable possibility that a material loss may have been incurred associated with pending legal and regulatory proceedings, we disclose such fact, and if reasonably estimable, we provide an estimate of the possible loss or range of possible loss. We record our best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, we record the minimum estimated liability. As additional information becomes available, we assess the potential liability related to pending legal and regulatory proceedings and revise our estimates and update our disclosures accordingly. Significant judgment is required in both the determination of probability and the determination as to whether a loss is reasonably estimable. Our legal costs associated with defending ourself are recorded to expense as incurred.

[0001728949-21-000076:notes:63]
Foreign Currency. Certain foreign subsidiaries use a local currency as the functional currency. Resulting translation gains or losses are recorded as a component of accumulated other comprehensive income. Transaction gains or losses related

[0001728949-21-000076:notes:64]
to balances denominated in a currency other than the functional currency are recognized in the consolidated statements of operations.

[0001728949-21-000076:notes:65]
Income Taxes. The asset and liability approach is used to recognize deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax bases of assets and liabilities. Tax law and rate changes are reflected in income in the period such changes are enacted. We record a valuation allowance to reduce deferred tax assets to the amount that is more likely than not to be realized. We include interest and penalties related to income taxes, including unrecognized tax benefits, within income tax expense. We classify all deferred tax assets and liabilities as noncurrent in the consolidated balance sheets.

[0001728949-21-000076:notes:66]
Our income tax returns are based on calculations and assumptions that are subject to examination by the Internal Revenue Service (IRS) and other tax authorities. In addition, the calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. While we believe we have appropriate support for the positions taken on our tax returns, we regularly assess the potential outcomes of examinations by tax authorities in determining the adequacy of our provision for income taxes. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts that give rise to a revision become known.

[0001728949-21-000076:notes:67]
We recognize excess tax benefits and shortfall tax detriments associated with share-based awards in the consolidated statements of operations, as a component of income tax expense, when realized.

[0001728949-21-000076:notes:68]
We are subject to income taxes in the United States and numerous foreign jurisdictions, and the assessment of our income tax positions involves dealing with uncertainties in the application of complex tax laws and regulations in various taxing jurisdictions. In addition, the application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws and regulations themselves are subject to change as a result of changes in fiscal policy, changes in legislation, the evolution of regulations and court rulings. Significant judgments and estimates are required in determining our provision for income taxes, including those related to special deductions such as FDII (foreign-derived intangible income), tax incentives, intercompany research and development cost-sharing arrangements, transfer pricing, tax credits and the realizability of deferred tax assets. While we believe we have appropriate support for the positions we have taken or that we plan to take on our tax returns, we regularly assess the potential outcomes of examinations by taxing authorities in determining the adequacy of our provision for income taxes. Therefore, the actual liability for U.S. or foreign taxes may be materially different from our estimates, which could result in the need to record additional tax liabilities or potentially reverse previously recorded tax liabilities. We are participating in the IRS Compliance Assurance Process program whereby we endeavor to agree with the IRS on the treatment of all issues prior to filing our federal return. A benefit of participation in this program is that post-filing adjustments by the IRS are less likely to occur.

[0001728949-21-000076:notes:69]
Stock Repurchases. To reflect share repurchases in the consolidated balance sheet, we (i) reduce common stock for the par value of the shares, (ii) reduce paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) record the residual amount, if any, to retained earnings.

[0001728949-21-000076:notes:70]
Earnings (Loss) Per Share. Basic earnings (loss) per share is computed by dividing net income (loss) by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of the weighted-average number of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans and shares subject to accelerated share repurchase programs, if any, and the weighted-average number of common shares outstanding during the reporting period. The following table provides information about the diluted earnings per share calculation (in millions):

[0001728949-21-000076:notes:71]
|  | 2021 |  | 2020 |  | 2019 |
| Dilutive common share equivalents included in diluted shares | 18 |  |  | 14 |  |  | 10 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | — |  |  | 1 |  |  | 8 |  |


## us-gaap:LesseeLeasesPolicyTextBlock

[0001728949-21-000076:notes:72]
Operating Leases. Operating lease assets and liabilities are recognized for leases with lease terms greater than 12 months based on the present value of the future lease payments over the lease term at the commencement date. Operating leases are included in other assets, other current liabilities and other liabilities on our consolidated balance sheet. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise such option. We account for substantially all lease and related non-lease components together as a single lease component. Operating lease expense is recognized on a straight-line basis over the lease term.We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001728949-21-000076:notes:73]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied performance obligations.
We disaggregate our revenues by segment (Note 8), by product and service (as presented on our consolidated statements of operations) and for our QCT segment by revenue stream, which is based on the industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-21-000076:notes:74]
Composition of Certain Financial Statement Items

[0001728949-21-000076:notes:75]
| Accounts Receivable (in millions) |  |  |  |
|  | September 26,2021 |  | September 27,2020 |
| Trade, net of allowances for doubtful accounts | $ | 2,214 |  |  | $ | 2,687 |  |
| Unbilled | 1,354 |  |  | 1,305 |  |
| Other | 11 |  |  | 11 |  |
|  | $ | 3,579 |  |  | $ | 4,003 |  |

[0001728949-21-000076:notes:76]
In July 2020, we entered into a settlement agreement with Huawei to resolve our prior dispute related to the license agreement that expired on December 31, 2019. We also entered into a new long-term, global patent license agreement that applies to sales of certain wireless products by Huawei beginning on January 1, 2020. As a result, we recorded revenues of $1.8 billion in the fourth quarter of fiscal 2020 related to the full amount due from Huawei under the settlement agreement and amounts paid for the March 2020 and June 2020 quarters under the new global patent license agreement. Accounts receivable at September 27, 2020 included approximately $1.3 billion, excluding the impact of foreign withholding taxes, from Huawei related to the remaining amounts due under the settlement agreement and estimated royalties for sales made in the September 2020 quarter. Since September 27, 2020, Huawei paid all such amounts, including the final installment under the settlement agreement in accordance with the agreed upon payment schedule.

[0001728949-21-000076:notes:77]
| Inventories (in millions) |  |  |  |
|  | September 26,2021 |  | September 27,2020 |
| Raw materials | $ | 267 |  |  | $ | 94 |  |
| Work-in-process | 1,475 |  |  | 1,155 |  |
| Finished goods | 1,486 |  |  | 1,349 |  |
|  | $ | 3,228 |  |  | $ | 2,598 |  |

[0001728949-21-000076:notes:78]
| Property, Plant and Equipment (in millions) |  |  |  |
|  | September 26,2021 |  | September 27,2020 |
| Land | $ | 172 |  |  | $ | 173 |  |
| Buildings and improvements | 1,642 |  |  | 1,606 |  |
| Computer equipment and software | 1,483 |  |  | 1,427 |  |
| Machinery and equipment | 6,420 |  |  | 5,095 |  |
| Furniture and office equipment | 94 |  |  | 90 |  |
| Leasehold improvements | 374 |  |  | 320 |  |
| Construction in progress | 269 |  |  | 134 |  |
|  | 10,454 |  |  | 8,845 |  |
| Less accumulated depreciation and amortization | (5,895) |  |  | (5,134) |  |
|  | $ | 4,559 |  |  | $ | 3,711 |  |

[0001728949-21-000076:notes:79]
Depreciation and amortization expense related to property, plant and equipment for fiscal 2021, 2020 and 2019 was $1.0 billion, $772 million and $674 million, respectively.

[0001728949-21-000076:notes:80]
Goodwill and Other Intangible Assets. We allocate goodwill to our reporting units for impairment testing purposes. The following table presents the goodwill allocated to our reportable and nonreportable segments, as described in Note 8, as well as the changes in the carrying amounts of goodwill during fiscal 2021 and 2020 (in millions):

[0001728949-21-000076:notes:81]
|  |  | QCT |  | QTL |  | Nonreportable Segments |  | Total |
| Balance at September 29, 2019 |  | $ | 5,565 |  |  | $ | 717 |  |  | $ | — |  |  | $ | 6,282 |  |
| Foreign currency translation adjustments |  | 40 |  |  | 1 |  |  | — |  |  | 41 |  |
| Balance at September 27, 2020 (1) |  | 5,605 |  |  | 718 |  |  | — |  |  | 6,323 |  |
| Acquisitions |  | 912 |  |  | 5 |  |  | — |  |  | 917 |  |
| Foreign currency translation adjustments |  | 6 |  |  | — |  |  | — |  |  | 6 |  |
| Balance at September 26, 2021 (1) |  | $ | 6,523 |  |  | $ | 723 |  |  | $ | — |  |  | $ | 7,246 |  |

[0001728949-21-000076:notes:82]
(1) Cumulative goodwill impairments were $812 million at both September 26, 2021 and September 27, 2020.

[0001728949-21-000076:notes:83]
The components of other intangible assets, net were as follows (in millions):

[0001728949-21-000076:notes:84]
|  | September 26, 2021 |  | September 27, 2020 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |
| Technology-based | $ | 5,385 |  |  | $ | (3,971) |  |  | 11 |  | $ | 5,556 |  |  | $ | (3,958) |  |  | 11 |
| Other | 93 |  |  | (49) |  |  | 10 |  | 105 |  |  | (50) |  |  | 9 |
|  | $ | 5,478 |  |  | $ | (4,020) |  |  | 11 |  | $ | 5,661 |  |  | $ | (4,008) |  |  | 11 |

[0001728949-21-000076:notes:85]
All of these intangible assets are subject to amortization, other than acquired in-process research and development which had a carrying value of $247 million at September 26, 2021. At September 27, 2020, there was no in-process research and development. Amortization expense related to these intangible assets was $537 million, $621 million and $727 million for fiscal 2021, 2020 and 2019, respectively. Amortization expense related to these intangible assets and acquired in-process research and development, beginning upon the completion of the underlying projects, is expected to be $449 million, $340 million, $186 million, $153 million and $132 million for each of the five years from fiscal 2022 through 2026, respectively, and $198 million thereafter.

[0001728949-21-000076:notes:86]
Equity Method and Non-marketable Equity Investments. The carrying values of our equity method and non-marketable equity investments are recorded in other assets and were as follows (in millions):

[0001728949-21-000076:notes:87]
|  | September 26,2021 |  | September 27,2020 |
| Equity method investments | $ | 214 |  |  | $ | 161 |  |
| Non-marketable equity investments | 1,051 |  |  | 821 |  |
|  | $ | 1,265 |  |  | $ | 982 |  |

[0001728949-21-000076:notes:88]
| Other Current Liabilities (in millions) |  |  |  |
|  | September 26,2021 |  | September 27,2020 |
| Customer incentives and other customer-related liabilities | $ | 1,974 |  |  | $ | 1,721 |  |
| Accrual for EC fines (Note 7) | 1,522 |  |  | 1,487 |  |
| Income taxes payable | 862 |  |  | 549 |  |
| Other | 656 |  |  | 546 |  |
|  | $ | 5,014 |  |  | $ | 4,303 |  |

[0001728949-21-000076:notes:89]
Revenues. We disaggregate our revenues by segment (Note 8), by product and service (as presented on our consolidated statements of operations) and for our QCT segment by revenue stream, which is based on the industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets. QCT revenue streams were as follows (in millions):

[0001728949-21-000076:notes:90]
|  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 16,830 |  |  | $ | 10,461 |  |  | $ | 9,793 |  |
| RFFE (2) |  |  |  |  |  |  |  |  | 4,158 |  |  | 2,362 |  |  | 1,478 |  |
| Automotive (3) |  |  |  |  |  |  |  |  | 975 |  |  | 644 |  |  | 640 |  |
| IoT (internet of things) (4) |  |  |  |  |  |  |  |  | 5,056 |  |  | 3,026 |  |  | 2,728 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 27,019 |  |  | $ | 16,493 |  |  | $ | 14,639 |  |

[0001728949-21-000076:notes:91]
(1) Includes revenues from products sold for use in mobile handsets, excluding RFFE (radio frequency front-end) components.

[0001728949-21-000076:notes:92]
(2) Includes all revenues from sales of 4G, 5G sub-6 and 5G millimeter wave RFFE products (a substantial portion of which are sold for use in mobile handsets) and excludes radio frequency transceiver components.

[0001728949-21-000076:notes:93]
(3) Includes revenues from products sold for use in automobiles, including telematics, connectivity and digital cockpit.

[0001728949-21-000076:notes:94]
(4) Primarily includes products sold for use in the following industries and applications: consumer (including computing, voice and music and XR), industrial (including handhelds, retail, transportation and logistics and utilities) and edge networking (including mobile broadband and wireless access points).

[0001728949-21-000076:notes:95]
Revenue recognized from performance obligations satisfied (or partially satisfied) in previous periods were as follows (in millions):

[0001728949-21-000076:notes:96]
|  | 2021 (1) |  | 2020 (2) |  | 2019 (3) |
| Revenues recognized from previously satisfied performance obligations | $ | 283 |  |  | $ | 1,480 |  |  | $ | 4,080 |  |

[0001728949-21-000076:notes:97]
(1) Primarily related to certain QCT customer incentives, QTL revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalty due) and the release of a variable constraint against revenues not previously allocated to our segment results (Note 8).

[0001728949-21-000076:notes:98]
(2) Primarily related to licensing revenues recognized in the fourth quarter of fiscal 2020 (a portion of which was attributable to fiscal 2020) resulting from the settlement with Huawei and, to a lesser extent, QTL royalties recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due) and certain QCT customer incentives.

[0001728949-21-000076:notes:99]
(3) Primarily related to licensing revenues recognized in the third quarter of fiscal 2019 (a portion of which was attributable to fiscal 2019) resulting from the settlement with Apple and its contract manufacturers in April 2019.

[0001728949-21-000076:notes:100]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In fiscal 2021 and fiscal 2020, we recognized revenues of $557 million and $540 million, respectively, that were recorded as unearned revenues at September 27, 2020 and September 29, 2019, respectively.

[0001728949-21-000076:notes:101]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront. At September 26, 2021, we had $1.1 billion of remaining performance obligations, of which $653 million, $308 million, $84 million, $31 million and $2 million is expected to be recognized as revenues for each of the subsequent five years from fiscal 2022 through 2026, respectively, and no amounts expected thereafter.

[0001728949-21-000076:notes:102]
Share-based Compensation Expense. Total share-based compensation expense, related to all of our share-based awards, was comprised as follows (in millions):

[0001728949-21-000076:notes:103]
|  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
| Cost of revenues |  |  |  |  |  |  |  |  | $ | 47 |  |  | $ | 34 |  |  | $ | 35 |  |
| Research and development |  |  |  |  |  |  |  |  | 1,234 |  |  | 872 |  |  | 725 |  |
| Selling, general and administrative |  |  |  |  |  |  |  |  | 389 |  |  | 306 |  |  | 277 |  |
| Share-based compensation expense before income taxes |  |  |  |  |  |  |  |  | 1,670 |  |  | 1,212 |  |  | 1,037 |  |
| Related income tax benefit |  |  |  |  |  |  |  |  | (435) |  |  | (238) |  |  | (184) |  |
|  |  |  |  |  |  |  |  |  | $ | 1,235 |  |  | $ | 974 |  |  | $ | 853 |  |

[0001728949-21-000076:notes:104]
Other Income, Costs and Expenses. Other expenses in fiscal 2020 consisted of $28 million in gains related to a favorable legal settlement. Other expenses in fiscal 2019 consisted of a $275 million charge related to a fine imposed by the European Commission (EC) related to the Icera complaint (2019 EC fine) (Note 7) and $213 million in net charges related to our Cost Plan that concluded in fiscal 2019 (primarily related to certain asset impairment charges and also included a $52 million net gain from the sale of certain assets related to wireless electric vehicle charging applications and the sale of our mobile health nonreportable segment), partially offset by a $43 million gain due to the partial recovery of a fine imposed in 2009 resulting from our appeal of the Korea Fair Trade Commission (KFTC) decision and a $31 million gain related to a favorable legal settlement.

[0001728949-21-000076:notes:105]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
| Interest and dividend income |  |  |  |  |  |  |  | $ | 83 |  |  | $ | 156 |  |  | $ | 300 |  |
| Net gains on marketable securities |  |  |  |  |  |  |  | 427 |  |  | 198 |  |  | 295 |  |
| Net gains on other investments |  |  |  |  |  |  |  | 470 |  |  | 108 |  |  | 68 |  |
| Net gains on deferred compensation plan assets |  |  |  |  |  |  |  | 130 |  |  | 47 |  |  | 9 |  |
| Impairment losses on other investments |  |  |  |  |  |  |  | (33) |  |  | (405) |  |  | (135) |  |
| Net (losses) gains on derivative instruments |  |  |  |  |  |  |  | (14) |  |  | 8 |  |  | (14) |  |
| Equity in net earnings (losses) of investees |  |  |  |  |  |  |  | 13 |  |  | (21) |  |  | (93) |  |
| Net (losses) gains on foreign currency transactions |  |  |  |  |  |  |  | (32) |  |  | (25) |  |  | 11 |  |
|  |  |  |  |  |  |  |  | $ | 1,044 |  |  | $ | 66 |  |  | $ | 441 |  |

[0001728949-21-000076:notes:106]
I


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-21-000076:notes:107]
Income Taxes
The components of the income tax provision were as follows (in millions):

[0001728949-21-000076:notes:108]
|  | 2021 |  | 2020 |  | 2019 |
| Current provision (benefit): |  |  |  |  |  |
| Federal | $ | 942 |  |  | $ | 210 |  |  | $ | 1,563 |  |
| State | 8 |  |  | 1 |  |  | 2 |  |
| Foreign | 518 |  |  | 526 |  |  | (407) |  |
|  | 1,468 |  |  | 737 |  |  | 1,158 |  |
| Deferred (benefit) provision: |  |  |  |  |  |
| Federal | (251) |  |  | (192) |  |  | 2,037 |  |
| State | 2 |  |  | 2 |  |  | 17 |  |
| Foreign | 12 |  |  | (26) |  |  | (117) |  |
|  | (237) |  |  | (216) |  |  | 1,937 |  |
|  | $ | 1,231 |  |  | $ | 521 |  |  | $ | 3,095 |  |

[0001728949-21-000076:notes:109]
The foreign component of the income tax provision included foreign withholding taxes on royalty revenues included in U.S. earnings.

[0001728949-21-000076:notes:110]
The components of income before income taxes by U.S. and foreign jurisdictions were as follows (in millions):

[0001728949-21-000076:notes:111]
|  | 2021 |  | 2020 |  | 2019 |
| United States | $ | 8,781 |  |  | $ | 5,004 |  |  | $ | 7,042 |  |
| Foreign | 1,493 |  |  | 715 |  |  | 439 |  |
|  | $ | 10,274 |  |  | $ | 5,719 |  |  | $ | 7,481 |  |

[0001728949-21-000076:notes:112]
The following is a reconciliation of the expected statutory federal income tax provision to our actual income tax provision (in millions, except percentages). Substantially all of our income is in the U.S., of which a significant portion qualifies for preferential treatment as FDII at a 13% effective tax rate.

[0001728949-21-000076:notes:113]
|  | 2021 |  | 2020 |  | 2019 |
| Expected income tax provision at federal statutory tax rate | $ | 2,158 |  |  | $ | 1,201 |  |  | $ | 1,571 |  |
| Benefit from FDII deduction | (550) |  |  | (381) |  |  | (419) |  |
| Excess tax benefit associated with share-based awards | (265) |  |  | (83) |  |  | (27) |  |
| Benefit related to research and development tax credits | (195) |  |  | (125) |  |  | (110) |  |
| Derecognition of deferred tax asset on distributed intellectual property | — |  |  | — |  |  | 2,472 |  |
| Benefit from establishing new U.S. net deferred tax assets | — |  |  | — |  |  | (570) |  |
| Other | 83 |  |  | (91) |  |  | 178 |  |
|  | $ | 1,231 |  |  | $ | 521 |  |  | $ | 3,095 |  |
| Effective tax rate | 12 | % |  | 9 | % |  | 41 | % |

[0001728949-21-000076:notes:114]
In fiscal 2019, several of our foreign subsidiaries made elections to be treated as U.S. branches for federal income tax purposes (commonly referred to as “check-the-box” elections) effective beginning in fiscal 2018 and 2019. As a result of making these check-the-box elections, we recorded a tax benefit of $570 million in the first quarter of fiscal 2019 due to establishing new U.S. net deferred tax assets resulting from the difference between the GAAP basis and the U.S. federal tax carryover basis of the existing assets and liabilities of those foreign subsidiaries, primarily related to customer incentive liabilities that have not been deducted for tax purposes. Additionally, during fiscal 2018, one of our foreign subsidiaries distributed certain intellectual property to a U.S. subsidiary resulting in a difference between the GAAP basis and the U.S. federal tax basis of the distributed intellectual property. Upon adoption of new accounting guidance in the first quarter of fiscal 2019, which changed the accounting for the income tax effects of intra-entity transfers of assets other than inventory, we recorded a deferred tax asset of approximately $2.6 billion primarily related to the distributed intellectual property, with an adjustment to opening retained earnings. During the third quarter of fiscal 2019, the United States Treasury Department issued new temporary regulations that resulted in a change to the deductibility of dividend income received by a U.S. stockholder from a foreign corporation. As a result of this change, pursuant to an agreement with the IRS, we relinquished the federal tax basis step-up of intellectual property that was distributed in fiscal 2018 by one of our foreign subsidiaries to a U.S. subsidiary. Therefore, the related deferred tax asset was derecognized, resulting in a $2.5 billion charge to income tax expense in fiscal 2019.

[0001728949-21-000076:notes:115]
In fiscal 2019, as a result of certain court rulings in Korea, among other factors, we decided to apply for a partial refund claim for taxes previously withheld from licensees in Korea on payments due under their license agreements to which we have claimed a foreign tax credit in the United States. As a result, $1.9 billion and $1.6 billion was recorded as a noncurrent income taxes receivable (recorded in other assets) at September 26, 2021 and September 27, 2020, respectively, and $1.9 billion and $1.6 billion was recorded as a noncurrent liability for uncertain tax benefits (recorded in other liabilities) at September 26, 2021 and September 27, 2020, respectively.

[0001728949-21-000076:notes:116]
At September 26, 2021, we estimated remaining future payments of $1.9 billion for a one-time repatriation tax accrued in fiscal 2018, after application of certain tax credits, which is payable in installments over the next five years. At September 26, 2021, $196 million was recorded in other current liabilities, reflecting the next installment due in January 2022.

[0001728949-21-000076:notes:117]
We continue to assert that certain of our foreign earnings are not indefinitely reinvested. At September 26, 2021, we had not recorded a deferred tax liability of approximately $63 million related to foreign withholding taxes on approximately $761 million of undistributed earnings of certain subsidiaries that we continue to consider to be indefinitely reinvested outside the United States. Should we decide to no longer indefinitely reinvest such earnings outside the U.S., we would have to adjust the income tax provision in the period we make such determination.

[0001728949-21-000076:notes:118]
We have tax incentives in Singapore that require we meet specified employment and other criteria. Although our profit in Singapore has declined as a result of our 2018 restructuring and such tax incentives were not significant for all periods presented, failure to meet these incentive requirements through March 2022 could require us to refund previously realized material tax benefits for 2017 and 2018.

[0001728949-21-000076:notes:119]
We had deferred tax assets and deferred tax liabilities as follows (in millions):

[0001728949-21-000076:notes:120]
|  | September 26,2021 |  | September 27,2020 |
| Unused tax credits | $ | 1,504 |  |  | $ | 1,311 |  |
| Customer incentives | 762 |  |  | 537 |  |
| Unused net operating losses | 663 |  |  | 576 |  |
| Accrued liabilities and reserves | 483 |  |  | 275 |  |
| Operating lease liabilities | 188 |  |  | 107 |  |
| Unearned revenues | 181 |  |  | 262 |  |
| Share-based compensation | 175 |  |  | 151 |  |
| Unrealized losses on other investments and marketable securities | 106 |  |  | 235 |  |
| Other | 165 |  |  | 141 |  |
| Total gross deferred tax assets | 4,227 |  |  | 3,595 |  |
| Valuation allowance | (1,926) |  |  | (1,728) |  |
| Total net deferred tax assets | 2,301 |  |  | 1,867 |  |
| Unrealized gains on other investments and marketable securities | (215) |  |  | (97) |  |
| Intangible assets | (198) |  |  | (181) |  |
| Operating lease assets | (174) |  |  | (100) |  |
| Property, plant and equipment | (111) |  |  | (162) |  |
| Other | (76) |  |  | (32) |  |
| Total deferred tax liabilities | (774) |  |  | (572) |  |
| Net deferred tax assets | $ | 1,527 |  |  | $ | 1,295 |  |
| Reported as: |  |  |  |
| Non-current deferred tax assets | $ | 1,591 |  |  | $ | 1,351 |  |
| Non-current deferred tax liabilities (1) | (64) |  |  | (56) |  |
|  | $ | 1,527 |  |  | $ | 1,295 |  |

[0001728949-21-000076:notes:121]
(1) Non-current deferred tax liabilities were included in other liabilities in the consolidated balance sheets.

[0001728949-21-000076:notes:122]
At September 26, 2021, we had unused federal net operating loss carryforwards of $214 million, of which $150 million expire from 2022 through 2035 and $64 million may be carried forward indefinitely, unused state net operating loss carryforwards of $474 million expiring from 2022 through 2040 and unused foreign net operating loss carryforwards of $2.3 billion, of which substantially all may be carried forward indefinitely. At September 26, 2021, we had unused state tax credits of $1.3 billion, of which substantially all may be carried forward indefinitely, unused federal tax credits of $215 million expiring from 2026 through 2031 and unused tax credits of $51 million in foreign jurisdictions expiring from 2033 through 2041. We do not expect our federal net operating loss carryforwards to expire unused.

[0001728949-21-000076:notes:123]
At September 26, 2021, we have provided a valuation allowance on certain state tax credits, foreign deferred tax assets and state net operating losses of $1.3 billion, $607 million and $13 million, respectively. The valuation allowance reflects the uncertainties surrounding our ability to generate sufficient future taxable income in certain foreign and state tax jurisdictions to utilize our net operating losses. We believe, more likely than not, that we will have sufficient taxable income after deductions related to share-based awards to utilize our remaining deferred tax assets.

[0001728949-21-000076:notes:124]
A summary of the changes in the amount of unrecognized tax benefits for fiscal 2021, 2020 and 2019 follows (in millions):

[0001728949-21-000076:notes:125]
|  | 2021 |  | 2020 |  | 2019 |
| Beginning balance of unrecognized tax benefits | $ | 1,901 |  |  | $ | 1,705 |  |  | $ | 217 |  |
| Additions based on prior year tax positions | 56 |  |  | 20 |  |  | 1,238 |  |
| Reductions for prior year tax positions and lapse in statute of limitations | (13) |  |  | (2) |  |  | (3) |  |
| Additions for current year tax positions | 213 |  |  | 192 |  |  | 253 |  |
| Settlements with taxing authorities | (21) |  |  | (14) |  |  | — |  |
| Ending balance of unrecognized tax benefits | $ | 2,136 |  |  | $ | 1,901 |  |  | $ | 1,705 |  |

[0001728949-21-000076:notes:126]
Of the $2.1 billion of unrecognized tax benefits, $1.9 billion has been recorded to other liabilities. We believe that it is reasonably possible that certain unrecognized tax benefits recorded at September 26, 2021 may result in a cash payment in fiscal 2022. Unrecognized tax benefits at September 26, 2021 included $146 million for tax positions that, if recognized, would impact the effective tax rate. The unrecognized tax benefits differ from the amount that would affect our effective tax rate primarily because the unrecognized tax benefits were included on a gross basis and did not reflect related receivables or secondary impacts, such as the federal deduction for state taxes, adjustments to deferred tax assets and the valuation allowance that might be required if our tax positions are sustained. The increase in unrecognized tax benefits for all periods presented was primarily due to expected refunds of Korean withholding tax previously paid (which had an insignificant impact to our income tax provision). If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We believe that it is likely that the total amount of unrecognized tax benefits at September 26, 2021 will increase in fiscal 2022 as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision. At September 26, 2021, total interest and penalties related to unrecognized tax benefits accrued in other current liabilities and other liabilities was $184 million, with a corresponding noncurrent income taxes receivable of $107 million recorded in other assets for expected refunds of certain tax benefits.

[0001728949-21-000076:notes:127]
We file income tax returns in the U.S. federal jurisdiction and various state and foreign jurisdictions. We are currently a participant in the IRS Compliance Assurance Process (CAP) Program, whereby we and the IRS endeavor to agree on the treatment of all tax issues prior to the tax return being filed. We are no longer subject to U.S. federal income tax examinations for years prior to fiscal 2018. We are also subject to examination in other taxing jurisdictions in the U.S. and numerous foreign jurisdictions. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2001. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. At September 26, 2021, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0001728949-21-000076:notes:128]
Cash amounts paid for income taxes, net of refunds received, were $1.5 billion, $830 million and $1.1 billion for fiscal 2021, 2020 and 2019, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-21-000076:notes:129]
Capital Stock
Stock Repurchase Program. On July 26, 2018, we announced a stock repurchase program authorizing us to repurchase up to $30.0 billion of our common stock. On October 12, 2021, we announced a new $10.0 billion stock repurchase authorization, which is in addition to the remaining repurchase authority of $0.9 billion under the aforementioned program. The stock repurchase programs have no expiration date. Since September 26, 2021, we repurchased and retired 5.4 million shares of common stock for $703 million.

[0001728949-21-000076:notes:130]
Shares Outstanding. Shares of common stock outstanding at September 26, 2021 were as follows (in millions):

[0001728949-21-000076:notes:131]
|  | 2021 |
| Balance at beginning of period | 1,131 |  |
| Issued | 18 |  |
| Repurchased | (24) |  |
| Balance at end of period | 1,125 |  |

[0001728949-21-000076:notes:132]
Dividends. On October 13, 2021, we announced a cash dividend of $0.68 per share on our common stock, payable on December 16, 2021 to stockholders of record as of the close of business on December 2, 2021.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001728949-21-000076:notes:133]
Employee Benefit PlansEquity Compensation Plans. On March 10, 2020, our stockholders approved the amended and restated Qualcomm Incorporated 2016 Long-Term Incentive Plan (the 2016 Plan), including an increase in the share reserve by 75 million shares. The 2016 Plan provides for the grant of RSUs and other stock-based awards. The Board of Directors may amend or terminate the 2016 Plan at any time. Certain amendments, including an increase in the share reserve, require stockholder approval. At September 26, 2021, approximately 71 million shares were available for future grant under the 2016 Plan.
RSUs are share awards that entitle the holder to receive shares of our common stock upon vesting. The RSUs generally include dividend-equivalent rights and vest over three years from the date of grant. A summary of RSU transactions under our 2016 Plan that contain only service requirements to vest follows:

[0001728949-21-000076:notes:134]
|  | Number of Shares(in millions) |  | Weighted-AverageGrant Date Fair Value |  |  |
| RSUs outstanding at September 27, 2020 | 32 |  |  | $ | 74.99 |  |  |  |
| RSUs granted | 16 |  |  | 124.22 |  |  |  |
| RSUs assumed in acquisition | 1 |  |  | 133.65 |  |  |  |
| RSUs canceled/forfeited | (2) |  |  | 97.81 |  |  |  |
| RSUs vested | (18) |  |  | 73.51 |  |  |  |
| RSUs outstanding at September 26, 2021 | 29 |  |  | 102.83 |  |  |  |

[0001728949-21-000076:notes:135]
The weighted-average estimated grant date fair values of employee RSUs under our 2016 Plan that contain only service requirements to vest granted during fiscal 2020 and 2019 were $82.57 and $63.10 per share, respectively. Upon vesting, we issue new shares of common stock. For the majority of RSUs, shares are issued on the vesting dates net of the amount of shares needed to satisfy statutory tax withholding requirements to be paid by us on behalf of the employees. As a result, the actual number of shares issued will be fewer than the number of RSUs outstanding. The annual pre-vest forfeiture rate for RSUs was estimated to be approximately 6%, 7% and 7% in fiscal 2021, 2020 and 2019, respectively.

[0001728949-21-000076:notes:136]
At September 26, 2021, total unrecognized compensation expense related to such non-vested RSUs granted prior to that date was $2.0 billion, which is expected to be recognized over a weighted-average period of 1.7 years. The total vest-date fair value of such RSUs that vested during fiscal 2021, 2020 and 2019 was $2.6 billion, $1.3 billion and $977 million, respectively. The total shares withheld to satisfy statutory tax withholding requirements related to all share-based awards were 5 million in fiscal 2021 and 4 million in fiscal 2020 and 2019, and were based on the value of the awards on their vesting dates as determined by our closing stock price.

[0001728949-21-000076:notes:137]
The total tax benefits realized, including the excess tax benefits, related to share-based awards during fiscal 2021, 2020 and 2019 were $567 million, $273 million and $237 million, respectively.

[0001728949-21-000076:notes:138]
Employee Stock Purchase Plan. We have an employee stock purchase plan for eligible employees to purchase shares of common stock at 85% of the lower of the fair market value on the first or the last day of each offering period, which is generally six months. Employees may authorize us to withhold up to 15% of their compensation during any offering period, subject to certain limitations. The employee stock purchase plan includes a non-423(b) plan. The shares reserved for future issuance under the employee stock purchase plan were 25 million at September 26, 2021. During fiscal 2021, 2020 and 2019, 3 million, 5 million and 6 million shares, respectively, were issued under the plan at an average price of $107.48, $66.53 and $42.13 per share, respectively. At September 26, 2021, total unrecognized compensation expense related to non-vested purchase rights granted prior to that date was $35 million. We recorded cash received from the exercise of purchase rights of $343 million, $306 million and $257 million during fiscal 2021, 2020 and 2019, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001728949-21-000076:notes:139]
Debt
Long-term Debt. The following table provides a summary of our long-term debt and current portion of long-term debt:

[0001728949-21-000076:notes:140]
|  | September 26, 2021 |  | September 27, 2020 |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2022 - 2045 |  | $ | 5,405 |  |  | 2.63% - 4.73% |  | 2022 - 2045 |  | $ | 5,405 |  |  | 2.62% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 5,860 |  |  | 0.92% - 4.46% |  | 2023 - 2047 |  | 5,860 |  |  | 1.06% - 4.46% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.31% - 3.30% |  | 2030 - 2050 |  | 2,000 |  |  | 2.31% - 3.30% |
| August 2020 Notes | 2028 - 2032 |  | 2,207 |  |  | 1.98% - 2.66% |  | 2028 - 2032 |  | 2,207 |  |  | 1.96% - 2.65% |
| Total principal |  |  | 15,472 |  |  |  |  |  |  | 15,472 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (234) |  |  |  |  |  |  | (260) |  |  |  |
| Hedge accounting adjustments |  | 7 |  |  |  |  |  |  | 14 |  |  |  |
| Total long-term debt |  |  | $ | 15,245 |  |  |  |  |  |  | $ | 15,226 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 1,544 |  |  |  |  |  |  | $ | — |  |  |  |
| Long-term debt |  |  | 13,701 |  |  |  |  |  |  | 15,226 |  |  |  |
| Total |  |  | $ | 15,245 |  |  |  |  |  |  | $ | 15,226 |  |  |  |

[0001728949-21-000076:notes:141]
At September 26, 2021, future principal payments were $1.5 billion in fiscal 2022, $1.5 billion in fiscal 2023, $914 million in fiscal 2024, $1.4 billion in fiscal 2025 and $10.2 billion after fiscal 2026. At September 26, 2021, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $17.0 billion.

[0001728949-21-000076:notes:142]
At September 26, 2021, with the exception of $500 million of outstanding unsecured floating-rate notes due January 30, 2023, all of our outstanding long-term debt is comprised of unsecured fixed-rate notes. We may redeem the outstanding fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. We may not redeem the outstanding floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of our other senior unsecured indebtedness and will effectively rank junior to all liabilities of our subsidiaries.

[0001728949-21-000076:notes:143]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to our commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $477 million, $507 million and $563 million during fiscal 2021, 2020 and 2019, respectively.

[0001728949-21-000076:notes:144]
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 to up to 397 days. At September 26, 2021 and September 27, 2020, we had $500 million of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 0.13% and 0.21%, respectively, which included fees paid to the commercial paper dealers. At September 26, 2021 and September 27, 2020, the weighted-average remaining days to maturity were 39 days and 37 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at September 26, 2021.

[0001728949-21-000076:notes:145]
Revolving Credit Facility. On December 8, 2020, we entered into a Revolving Credit Facility replacing our prior Amended and Restated Revolving Credit Facility. There were no outstanding borrowings under the Amended and Restated Revolving Credit Facility at the time of termination and September 27, 2020. The Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At September 26, 2021, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-21-000076:notes:146]
Debt Covenants. The Revolving Credit Facility requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. We are not subject to any financial covenants under the notes nor any covenants that would prohibit us from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by us or our subsidiaries. At September 26, 2021, we were in compliance with the applicable covenants under the Revolving Credit Facility.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-21-000076:notes:147]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0001728949-21-000076:notes:148]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions. On July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint, and on March 18, 2019, the court denied our motion. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000076:notes:149]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our then current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint, and on March 10, 2020, the court granted our motion. On May 11, 2020, the plaintiffs filed a second amended complaint, and on October 8, 2020, the court granted our motion to dismiss the case with prejudice. On November 7, 2020, the plaintiffs filed a notice of appeal with the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). A hearing on the appeal is scheduled for November 16, 2021. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000076:notes:150]
Consumer Class Action Lawsuits: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and on September 27, 2018, the court granted that motion. On January 23, 2019, the Ninth Circuit granted us permission to appeal the court’s class certification order, and on January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. On September 29, 2021, the Ninth Circuit vacated the district court’s class certification order, ruling that the court had failed to correctly assess the propriety of applying California law to a nationwide class. The Ninth Circuit remanded the case to the district court and instructed the court to consider the effect of United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated (which the Ninth Circuit decided in favor of Qualcomm in August 2020) on this case. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000076:notes:151]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

[0001728949-21-000076:notes:152]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision has subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 26, 2021, the court issued an order stating that trial is extremely unlikely to occur before November or December 2021, if then. We believe that ParkerVision’s claims are without merit.

[0001728949-21-000076:notes:153]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December

[0001728949-21-000076:notes:154]
27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0001728949-21-000076:notes:155]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019 and, on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-21-000076:notes:156]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of its investigation, but we believe it concerns our business practices in connection with our sale of radio frequency front-end (RFFE) components. We continue to cooperate with the KFTC as it conducts its investigation. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-21-000076:notes:157]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision finding that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

[0001728949-21-000076:notes:158]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At September 26, 2021, the liability, including related foreign currency losses and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $292 million and included in other current liabilities.

[0001728949-21-000076:notes:159]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. From May 4, 2021 to May 6, 2021, a hearing on our appeal was held before the court. The court has not yet issued a ruling. We believe that our business practices do not violate the EU competition rules.

[0001728949-21-000076:notes:160]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At September 26, 2021, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.2 billion and included in other current liabilities.

[0001728949-21-000076:notes:161]
Contingent Losses and Other Considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at September 26, 2021 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0001728949-21-000076:notes:162]
Indemnifications. We generally do not indemnify our customers, licensees and suppliers for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain agreements to defend and/or indemnify certain customers, licensees and suppliers against certain types of liability and/or damages arising from the infringement of third-party intellectual property rights. Our obligations under these agreements may be limited in terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us.

[0001728949-21-000076:notes:163]
Claims and reimbursements under indemnification arrangements have not been material to our consolidated financial statements. We have not recorded accruals for certain claims under indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001728949-21-000076:notes:164]
Purchase Obligations. We have agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. During fiscal 2021, we entered into several multi-year capacity purchase commitments with certain suppliers of our integrated circuit products. Integrated circuit product inventory obligations represent purchase commitments (including those under multi-year capacity purchase commitments to the extent such minimum amounts are both fixed and determinable) for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancellation of outstanding purchase commitments is generally allowed but may result in the payment of costs incurred through the date of cancellation, and in some cases, incremental fees and/or the loss of amounts paid in advance related to capacity underutilization and the failure to meet future minimum purchase volumes under multi-year capacity purchase commitments. Obligations under our purchase agreements, which primarily relate to integrated circuit product inventory obligations, at September 26, 2021 totaled $23.5 billion of which, $12.9 billion is expected to be paid in the next 12 months.

[0001728949-21-000076:notes:165]
Operating Leases. We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years. As of September 26, 2021 and September 27, 2020, the weighted-average remaining lease term for operating leases were 7 years and 6 years, respectively. Operating lease expense for fiscal 2021, 2020 and 2019 was $203 million, $181 million and $146 million, respectively. At September 26, 2021, other assets included $513 million of operating lease assets, with corresponding lease liabilities of $126 million recorded in other current liabilities and $428 million recorded in other liabilities. At September 27, 2020, other assets included $460 million of operating lease assets, with corresponding lease liabilities of $134 million recorded in other current liabilities and $371 million recorded in other liabilities. 
At September 26, 2021, future lease payments under our operating leases were as follows (in millions):

[0001728949-21-000076:notes:166]
|  |  |  | September 26,2021 |
| 2022 |  |  | $ | 141 |  |
| 2023 |  |  | 102 |  |
| 2024 |  |  | 80 |  |
| 2025 |  |  | 55 |  |
| 2026 |  |  | 49 |  |
| Thereafter |  |  | 250 |  |
| Total future lease payments |  |  | 677 |  |
| Imputed interest |  |  | (123) |  |
| Total lease liability balance |  |  | $ | 554 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-21-000076:notes:167]
Segment Information
We are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarity of activities within our operating segments, such as the nature of products, the level of shared products, technology and other resources, production processes and customer base. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies, including RFFE, for use in mobile devices, automotive systems for telematics, connectivity and digital cockpit and IoT including wireless networks, broadband gateway equipment, consumer electronic devices and industrial devices. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI reportable segment makes strategic investments. We also have nonreportable segments, including QGOV and our cloud AI inference processing initiative and other technology and service initiatives.

[0001728949-21-000076:notes:168]
Our CODM allocates resources to and evaluates the performance of our segments based on revenues and earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense, certain net investment income, certain share-based compensation, gains and losses on our deferred compensation plan liabilities and related assets and certain research and development expenses, certain selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories and property, plant and equipment to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and awards, settlements and/or damages arising from legal or regulatory matters. Our CODM does not evaluate our operating segments using discrete asset information.

[0001728949-21-000076:notes:169]
The table below presents revenues and EBT for reportable segments (in millions):

[0001728949-21-000076:notes:170]
|  | 2021 |  | 2020 |  | 2019 |
| Revenues |  |  |  |  |  |
| QCT | $ | 27,019 |  |  | $ | 16,493 |  |  | $ | 14,639 |  |
| QTL | 6,320 |  |  | 5,028 |  |  | 4,591 |  |
| QSI | 45 |  |  | 36 |  |  | 152 |  |
| Reconciling items | 182 |  |  | 1,974 |  |  | 4,891 |  |
| Total | $ | 33,566 |  |  | $ | 23,531 |  |  | $ | 24,273 |  |
| EBT |  |  |  |  |  |
| QCT | $ | 7,763 |  |  | $ | 2,763 |  |  | $ | 2,143 |  |
| QTL | 4,627 |  |  | 3,442 |  |  | 2,954 |  |
| QSI | 916 |  |  | (11) |  |  | 344 |  |
| Reconciling items | (3,032) |  |  | (475) |  |  | 2,040 |  |
| Total | $ | 10,274 |  |  | $ | 5,719 |  |  | $ | 7,481 |  |

[0001728949-21-000076:notes:171]
The net book value of long-lived tangible assets located outside of the U.S. was $2.9 billion and $2.3 billion at September 26, 2021 and September 27, 2020, respectively. The net book value of long-lived tangible assets located in the U.S. was $2.2 billion and $1.9 billion at September 26, 2021 and September 27, 2020, respectively.

[0001728949-21-000076:notes:172]
We report revenues from external customers by country based on the location to which our products or services are delivered, which for QCT is generally the country in which our customers manufacture their products, and for licensing revenues, the invoiced addresses of our licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues could include revenues related to shipments of integrated circuits for a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States. Revenues by country were as follows (in millions):

[0001728949-21-000076:notes:173]
|  | 2021 |  | 2020 |  | 2019 |
| China (including Hong Kong) | $ | 22,512 |  |  | $ | 14,001 |  |  | $ | 11,610 |  |
| South Korea | 2,368 |  |  | 2,964 |  |  | 2,400 |  |
| United States | 1,406 |  |  | 1,129 |  |  | 2,774 |  |
| Ireland | 1,160 |  |  | 867 |  |  | 2,957 |  |
| Other foreign | 6,120 |  |  | 4,570 |  |  | 4,532 |  |
|  | $ | 33,566 |  |  | $ | 23,531 |  |  | $ | 24,273 |  |

[0001728949-21-000076:notes:174]
Reconciling items for revenues and EBT in a previous table were as follows (in millions):

[0001728949-21-000076:notes:175]
|  |  |  |  | 2021 |  | 2020 |  | 2019 |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonreportable segments |  |  |  |  |  |  |  | $ | 128 |  |  | $ | 133 |  |  | $ | 168 |  |
| Unallocated revenues (Note 2) |  |  |  |  |  |  |  | 54 |  |  | 1,841 |  |  | 4,723 |  |
|  |  |  |  |  |  |  |  | $ | 182 |  |  | $ | 1,974 |  |  | $ | 4,891 |  |
| EBT |  |  |  |  |  |  |  |  |  |  |  |  |
| Unallocated revenues (Note 2) |  |  |  |  |  |  |  | $ | 54 |  |  | $ | 1,841 |  |  | $ | 4,723 |  |
| Unallocated cost of revenues |  |  |  |  |  |  |  | (277) |  |  | (340) |  |  | (430) |  |
| Unallocated research and development expenses |  |  |  |  |  |  |  | (1,820) |  |  | (1,046) |  |  | (989) |  |
| Unallocated selling, general and administrative expenses |  |  |  |  |  |  |  | (538) |  |  | (401) |  |  | (413) |  |
| Unallocated other income (expenses) (Note 2) |  |  |  |  |  |  |  | — |  |  | 28 |  |  | (414) |  |
| Unallocated interest expense |  |  |  |  |  |  |  | (559) |  |  | (599) |  |  | (619) |  |
| Unallocated investment and other income, net |  |  |  |  |  |  |  | 166 |  |  | 105 |  |  | 243 |  |
| Nonreportable segments |  |  |  |  |  |  |  | (58) |  |  | (63) |  |  | (61) |  |
|  |  |  |  |  |  |  |  | $ | (3,032) |  |  | $ | (475) |  |  | $ | 2,040 |  |

[0001728949-21-000076:notes:176]
Certain revenues were not allocated to our segments in our management reports because they were not considered in evaluating segment results. Unallocated revenues in fiscal 2021 were comprised of the release of a variable constraint against revenues not previously allocated to our segment results. Unallocated revenues in fiscal 2020 were comprised of licensing revenues from Huawei resulting from the settlement agreement signed in July 2020 and royalties for sales made in the March 2020 and June 2020 quarters under the new global patent license agreement signed in July 2020. Unallocated revenues in fiscal 2019 were comprised of licensing revenues resulting from the settlement with Apple and its contract manufacturers in April 2019.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001728949-21-000076:notes:177]
Acquisitions 
On March 16, 2021 (the Closing Date), we completed the acquisition of NuVia, Inc. (NUVIA) for $1.1 billion (net of cash acquired), substantially all of which was paid in cash. In connection with the acquisition, we assumed or replaced unvested NUVIA stock awards with Qualcomm stock awards with an estimated fair value of $258 million, for which $10 million was attributable to pre-acquisition services and included in the purchase price, and the remaining amount is recognized as compensation expense over the related post-acquisition requisite service period of up to four years.

[0001728949-21-000076:notes:178]
NUVIA has certain in-process technologies and is comprised of a CPU (central processing unit) and technology design team with expertise in high performance processors, SoC (system-on-chip) and power management for compute-intensive devices and applications. Upon completion of development, NUVIA’s technologies are expected to be integrated into certain QCT products.

[0001728949-21-000076:notes:179]
The allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0001728949-21-000076:notes:180]
| Cash | $ | 174 |  |
| In-process research and development (IPR&D) | 247 |  |
| Goodwill | 885 |  |
| Other assets | 26 |  |
| Total assets | 1,332 |  |
| Liabilities | (68) |  |
| Net assets acquired | $ | 1,264 |  |

[0001728949-21-000076:notes:181]
Goodwill recognized in this transaction is not deductible for tax purposes and was allocated to our QCT segment for annual impairment testing purposes. Goodwill is primarily attributable to assembled workforce and certain revenue and cost synergies expected to arise after the acquisition. IPR&D is related to a single project, which is expected to be completed in fiscal 2023 and, upon completion, will be amortized over its useful life, which is expected to be seven years. The estimated fair value of the IPR&D asset acquired was determined using an income approach based on significant inputs that were not observable.

[0001728949-21-000076:notes:182]
Our results of operations for fiscal 2021 included the operating results of NUVIA since the Closing Date, the amounts of which were not material. Pro forma results of operations have not been presented because the effects of this acquisition were not material to our consolidated results of operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-21-000076:notes:183]
Fair Value MeasurementsThe following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at September 26, 2021 (in millions):

[0001728949-21-000076:notes:184]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 4,303 |  |  | $ | 1,378 |  |  | $ | — |  |  | $ | 5,681 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 4,459 |  |  | — |  |  | 4,459 |  |
| Equity securities | 682 |  |  | — |  |  | — |  |  | 682 |  |
| Mortgage- and asset-backed securities | — |  |  | 147 |  |  | — |  |  | 147 |  |
| U.S. Treasury securities and government-related securities | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total marketable securities | 682 |  |  | 4,616 |  |  | — |  |  | 5,298 |  |
| Derivative instruments | — |  |  | 42 |  |  | — |  |  | 42 |  |
| Other investments | 685 |  |  | — |  |  | 41 |  |  | 726 |  |
| Total assets measured at fair value | $ | 5,670 |  |  | $ | 6,036 |  |  | $ | 41 |  |  | $ | 11,747 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 111 |  |  | $ | — |  |  | $ | 111 |  |
| Other liabilities | 685 |  |  | — |  |  | — |  |  | 685 |  |
| Total liabilities measured at fair value | $ | 685 |  |  | $ | 111 |  |  | $ | — |  |  | $ | 796 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-21-000076:notes:185]
Marketable Securities
Our marketable securities were comprised as follows (in millions):

[0001728949-21-000076:notes:186]
|  | Current |  | Noncurrent (1) |
|  | September 26,2021 |  | September 27,2020 |  | September 26,2021 |  | September 27,2020 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 4,459 |  |  | $ | 4,049 |  |  | $ | — |  |  | $ | — |  |
| Mortgage- and asset-backed and auction rate securities | 147 |  |  | 66 |  |  | — |  |  | 35 |  |
| U.S. Treasury securities and government-related securities | 10 |  |  | 10 |  |  | — |  |  | — |  |
| Total available-for-sale debt securities | 4,616 |  |  | 4,125 |  |  | — |  |  | 35 |  |
| Equity securities | 682 |  |  | 352 |  |  | — |  |  | — |  |
| Time deposit (2) | — |  |  | 30 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 5,298 |  |  | $ | 4,507 |  |  | $ | — |  |  | $ | 35 |  |

[0001728949-21-000076:notes:187]
(1) Noncurrent marketable securities were included in other assets.

[0001728949-21-000076:notes:188]
(2) At September 27, 2020, marketable securities also included a time deposit with an original maturity of greater than 90 days.

[0001728949-21-000076:notes:189]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001728949-21-000076:notes:190]
|  | September 26,2021 |
| Years to Maturity: |  |
| Less than one year | $ | 1,241 |  |
| One to five years | 3,219 |  |
| Five to ten years | 9 |  |
| No single maturity date | 147 |  |
| Total | $ | 4,616 |  |

[0001728949-21-000076:notes:191]
Debt securities with no single maturity date included mortgage- and asset-backed securities.


## us-gaap:SubsequentEventsTextBlock

[0001728949-21-000076:notes:192]
Note 12. Subsequent Events

[0001728949-21-000076:notes:193]
In October 2021, we and SSW Partners, a New York-based investment partnership, entered into a definitive agreement (the Merger Agreement) to acquire Veoneer, Inc. (Veoneer) for $37.00 per share in cash, which values the estimated total cash consideration to be paid to Veoneer’s shareholders, inclusive of amounts expected to be paid at closing for Veoneer’s outstanding equity awards and convertible senior notes due 2024, at approximately $4.5 billion. At closing, SSW Partners will acquire all of the outstanding capital stock of Veoneer, shortly after which it will sell Veoneer’s Arriver business to Qualcomm and retain Veoneer’s Tier-1 automotive supplier businesses. Following close of the Arriver business sale, we intend to incorporate Arriver’s computer vision, drive policy and driver assistance technologies into our Snapdragon automotive platform to deliver an open and competitive ADAS (advanced driver assistance systems) platform for automakers and Tier-1 automotive suppliers. The acquisition is subject to a number of conditions, including receipt of United States and other regulatory approvals and the approval of Veoneer’s shareholders, and is not required to be completed by Qualcomm and SSW Partners prior to April 4, 2022. Subject to the satisfaction of these conditions, the acquisition is expected to close in 2022.

[0001728949-21-000076:notes:194]
We will fund substantially all of the cash consideration that SSW Partners will pay to Veoneer’s shareholders in exchange for (i) our right to acquire, and SSW Partners’ obligation to sell to us, Veoneer’s Arriver business and (ii) our right to receive a portion of the proceeds upon the sale of Veoneer’s Tier-1 automotive supplier businesses by SSW Partners. In addition, we will provide a loan facility (or guarantee amounts provided by a third party) that provides financing to Veoneer to support the Arriver business, to the extent requested by Veoneer in the event that the acquisition has not closed, for the quarter commencing April 1, 2022 and each of the two subsequent quarters, of $120 million per quarter (up to $360 million in the aggregate), which amounts may be forgiven in certain circumstances in which the Merger Agreement is terminated. An additional $120 million for the first quarter of calendar 2023 may be provided under the loan facility if the final outside date, as defined in the Merger Agreement is extended to April 4, 2023.

[0001728949-21-000076:notes:195]
In accordance with the Merger Agreement, we paid to Magna International Inc. (Magna) a termination fee of $110 million in October 2021 on behalf of Veoneer in connection with the termination of the previously announced agreement and plan of merger, dated as of July 22, 2021, by and among Magna and Veoneer.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001728949-21-000076:notes:196]
SCHEDULE II

[0001728949-21-000076:notes:197]
QUALCOMM Incorporated

[0001728949-21-000076:notes:198]
VALUATION AND QUALIFYING ACCOUNTS

[0001728949-21-000076:notes:199]
The table below details the activity of the valuation allowance on deferred tax assets for fiscal 2021, 2020 and 2019 (in millions):

[0001728949-21-000076:notes:200]
|  | Balance atBeginning ofPeriod |  | Charged toCosts andExpenses |  |  |  | Other |  | Balance atEnd ofPeriod |
| Year ended September 26, 2021 | $ | 1,728 |  |  | $ | 197 |  |  |  |  | $ | 1 |  |  | $ | 1,926 |  |
| Year ended September 27, 2020 | 1,672 |  |  | 60 |  |  |  |  | (4) |  |  | 1,728 |  |
| Year ended September 29, 2019 | 1,529 |  |  | 143 |  |  |  |  | — |  |  | 1,672 |  |
