# QCOM 8-K — 0000804328-25-000010 filed 2025-02-05

## item codes, every 8-K on or before 2025-02-05

- 2025-02-05 0000804328-25-000010 — 2.02, 9.01
- 2024-12-12 0000804328-24-000079 — 5.02
- 2024-11-06 0000804328-24-000074 — 2.02, 9.01
- 2024-10-09 0000804328-24-000064 — 5.02
- 2024-08-09 0000804328-24-000061 — 1.01, 1.02, 2.03, 9.01
- 2024-07-31 0000804328-24-000055 — 2.02, 9.01
- 2024-05-09 0000804328-24-000042 — 7.01
- 2024-05-01 0000804328-24-000038 — 2.02, 9.01
- 2024-03-07 0000804328-24-000020 — 5.07, 9.01
- 2024-01-31 0000804328-24-000015 — 2.02, 9.01
- 2024-01-23 0000804328-24-000005 — 5.02
- 2023-11-01 0000804328-23-000054 — 2.02, 9.01
- 2023-08-02 0000804328-23-000042 — 2.02, 9.01
- 2023-07-21 0000804328-23-000033 — 5.03, 9.01
- 2023-05-03 0000804328-23-000022 — 2.02, 9.01
- 2023-03-09 0000804328-23-000014 — 5.07
- 2023-02-02 0000804328-23-000005 — 2.02, 9.01
- 2022-12-08 0001728949-22-000041 — 5.02
- 2022-11-09 0001104659-22-116535 — 1.01, 8.01, 9.01
- 2022-11-02 0000804328-22-000020 — 2.02, 9.01
- 2022-07-27 0001728949-22-000039 — 2.02, 9.01
- 2022-05-09 0001104659-22-057562 — 1.01, 8.01, 9.01
- 2022-04-27 0001728949-22-000025 — 2.02, 9.01
- 2022-03-14 0001728949-22-000016 — 5.07
- 2022-02-02 0001728949-22-000011 — 2.02, 9.01
- 2021-11-03 0001728949-21-000075 — 2.02, 9.01
- 2021-10-04 0001104659-21-122578 — 1.01, 7.01, 9.01
- 2021-07-28 0001728949-21-000065 — 2.02, 9.01
- 2021-07-23 0001728949-21-000055 — 5.03, 9.01
- 2021-05-21 0001728949-21-000048 — 5.02
- 2021-04-28 0001728949-21-000042 — 2.02, 9.01
- 2021-03-15 0001628280-21-004741 — 5.07
- 2021-02-03 0001728949-21-000021 — 2.02, 9.01
- 2021-01-13 0001728949-21-000009 — 1.01, 9.01
- 2021-01-08 0001728949-21-000004 — 5.02
- 2020-12-10 0001104659-20-134200 — 1.01, 1.02, 2.03, 9.01
- 2020-11-19 0001728949-20-000070 — 5.02
- 2020-11-04 0001728949-20-000066 — 2.02, 9.01
- 2020-08-18 0001104659-20-096322 — 1.01, 8.01, 9.01
- 2020-08-05 0001104659-20-090597 — 8.01, 9.01
- 2020-07-29 0001728949-20-000056 — 2.02, 9.01
- 2020-07-24 0001728949-20-000047 — 5.02
- 2020-05-11 0001104659-20-058923 — 1.01, 8.01, 9.01
- 2020-05-04 0001728949-20-000037 — 5.02
- 2020-04-29 0001728949-20-000030 — 2.02, 9.01
- 2020-03-13 0001728949-20-000015 — 5.07
- 2020-02-05 0001728949-20-000010 — 2.02, 9.01
- 2019-11-06 0001728949-19-000074 — 5.02
- 2019-11-06 0001728949-19-000071 — 2.02, 9.01
- 2019-08-28 0001728949-19-000058 — 5.02
- 2019-07-31 0001728949-19-000053 — 2.02, 9.01
- 2019-05-10 0001728949-19-000044 — 5.02
- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2025-02-05

- none on or before 2025-02-05

## item 2.02 — earnings release, exhibit 99.1

[0000804328-25-000010:8k_2_02:1]
EX-99.1
2
qcom122924erex991.htm
EX-99.1

[0000804328-25-000010:8k_2_02:2]
Document

[0000804328-25-000010:8k_2_02:3]
Exhibit 99.1

[0000804328-25-000010:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000804328-25-000010:8k_2_02:5]
Qualcomm Contact:

[0000804328-25-000010:8k_2_02:6]
Mauricio Lopez-Hodoyan

[0000804328-25-000010:8k_2_02:7]
Vice President, Investor Relations

[0000804328-25-000010:8k_2_02:8]
Phone: 1-858-658-4813 | e-mail: ir@qualcomm.com

[0000804328-25-000010:8k_2_02:9]
Qualcomm Announces First Quarter Fiscal 2025 Results

[0000804328-25-000010:8k_2_02:10]
Record Revenues: $11.7 billion

[0000804328-25-000010:8k_2_02:11]
GAAP EPS: $2.83, Record Non-GAAP EPS: $3.41

[0000804328-25-000010:8k_2_02:12]
—Record Quarterly QCT Revenues of Greater Than $10 Billion—

[0000804328-25-000010:8k_2_02:13]
—QCT Handsets: Record Quarterly Revenues—

[0000804328-25-000010:8k_2_02:14]
—QCT Automotive: 6th Consecutive Quarter of Record Revenues—

[0000804328-25-000010:8k_2_02:15]
SAN DIEGO - February 5, 2025 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal first quarter ended December 29, 2024.

[0000804328-25-000010:8k_2_02:16]
“We are very pleased to have achieved quarterly revenue records, which reflect the strength of our technology, product roadmap and end-customer demand,” said Cristiano Amon, CEO of Qualcomm Incorporated. “We are delivering growth across our diversification initiatives and remain committed to executing on our fiscal 2029 targets to achieve $22 billion of non-handset revenues.”

[0000804328-25-000010:8k_2_02:17]
First Quarter Results1

[0000804328-25-000010:8k_2_02:18]
|  | GAAP |  | Non-GAAP |  |
| (in millions, except per share data and percentages) | Q1 Fiscal 2025 |  | Q1 Fiscal 2024 |  | Change |  | Q1 Fiscal 2025 |  | Q1 Fiscal 2024 |  |  |  |  | Change |  |
| Revenues | $11,669 |  | $9,935 |  | +17% |  | $11,669 |  | $9,922 |  |  |  |  | +18% |  |
| Earnings before taxes (EBT) | $3,635 |  | $2,962 |  | +23% |  | $4,427 |  | $3,585 |  |  |  |  | +23% |  |
| Net income | $3,180 |  | $2,767 |  | +15% |  | $3,830 |  | $3,101 |  |  |  |  | +24% |  |
| Diluted earnings per share (EPS) | $2.83 |  | $2.46 |  | +15% |  | $3.41 |  | $2.75 |  |  |  |  | +24% |  |

[0000804328-25-000010:8k_2_02:19]
(1)  Discussion regarding our use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results are included at the end of this news release in the sections labeled “Note Regarding Use of Non-GAAP Financial Measures” and “Reconciliations of GAAP Results to Non-GAAP Results.”

[0000804328-25-000010:8k_2_02:20]
Segment Results

[0000804328-25-000010:8k_2_02:21]
|  | QCT |  | QTL |
| (in millions, except percentages) | Q1 Fiscal 2025 |  | Q1 Fiscal 2024 |  | Change |  | Q1 Fiscal 2025 |  | Q1 Fiscal 2024 |  | Change |  |  |  |
| Revenues | $10,084 |  | $8,423 |  | +20% |  | $1,535 |  | $1,460 |  | +5% |  |  |  |
| EBT | $3,246 |  | $2,593 |  | +25% |  | $1,158 |  | $1,080 |  | +7% |  |  |  |
| EBT as % of revenues | 32% |  | 31% |  | +1 point |  | 75% |  | 74% |  | +1 point |  |  |  |

[0000804328-25-000010:8k_2_02:22]
| Qualcomm Announces First Quarter Fiscal 2025 Results | Page 2 of 8 |

[0000804328-25-000010:8k_2_02:23]
QCT Revenue Streams1

[0000804328-25-000010:8k_2_02:24]
| (in millions, except percentages) | Q1 Fiscal 2025 |  | Q1 Fiscal 2024 |  | Change |
| Handsets | $7,574 |  | $6,687 |  | +13% |
| Automotive | 961 |  | 598 |  | +61% |
| IoT | 1,549 |  | 1,138 |  | +36% |
| Total QCT revenues | $10,084 |  | $8,423 |  | +20% |

[0000804328-25-000010:8k_2_02:25]
(1) We disaggregate QCT revenues based on the industries and applications in which our products are sold.

[0000804328-25-000010:8k_2_02:26]
Return of Capital to Stockholders

[0000804328-25-000010:8k_2_02:27]
During the first quarter of fiscal 2025, we returned $2.7 billion to stockholders, including $942 million, or $0.85 per share, of cash dividends paid and $1.8 billion through repurchases of 11 million shares of common stock.

[0000804328-25-000010:8k_2_02:28]
Business Outlook

[0000804328-25-000010:8k_2_02:29]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.

[0000804328-25-000010:8k_2_02:30]
|  |  |  | Current Guidance Q2 FY25 Estimates1 |  |
|  | GAAP Revenues |  | $10.3B - $11.2B |  |
|  | Less revenues attributable to other items2 |  | $0.1B - $0.2B |  |
|  | Non-GAAP Revenues |  | $10.2B - $11.0B |  |
|  | Supplemental Revenue Information |  |  |  |
|  | QCT revenues |  | $8.9B - $9.5B |  |
|  | QTL revenues |  | $1.25B - $1.45B |  |
|  | GAAP diluted EPS |  | $2.38 - $2.58 |  |
|  | Less diluted EPS attributable to QSI |  | $— |  |  |
|  | Less diluted EPS attributable to share-based compensation |  | ($0.52) |  |  |
|  | Less diluted EPS attributable to other items2 |  | $0.20 |  |  |
|  | Non-GAAP diluted EPS |  | $2.70 - $2.90 |  |

[0000804328-25-000010:8k_2_02:31]
(1)  Our outlook does not include provisions for proposed tax law changes, future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable. Further, due to their nature, certain income and expense items, such as certain investments, derivative and foreign currency transaction gains or losses, cannot be accurately forecast. Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain. Our outlook includes the impact of any pending business combinations to the extent they are expected to close in the upcoming quarter. Actual results may differ materially from the outlook.

[0000804328-25-000010:8k_2_02:32]
(2)  Our guidance for revenues and diluted EPS attributable to other items excluded from Non-GAAP for the second quarter of fiscal 2025 is primarily related to expected revenues resulting from the settlement of a dispute. Our guidance for diluted EPS attributable to other items excluded from Non-GAAP for the second quarter of fiscal 2025 also includes the requirement to capitalize research and development expenditures under U.S. Federal income tax law, partially offset by acquisition-related items.

[0000804328-25-000010:8k_2_02:33]
| Qualcomm Announces First Quarter Fiscal 2025 Results | Page 3 of 8 |

[0000804328-25-000010:8k_2_02:34]
Conference Call and Available Information

[0000804328-25-000010:8k_2_02:35]
Qualcomm’s first quarter fiscal 2025 earnings conference call will be broadcast live on February 5, 2025, beginning at 1:45 p.m. Pacific Time (PT) at https://investor.qualcomm.com/news-events/investor-events. This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G. The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to our financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted to our Investor Relations website at https://investor.qualcomm.com immediately prior to the commencement of the call. An audio replay will be available on our website and via telephone following the live call for 30 days thereafter. To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415. Callers should use reservation number 13750899.

[0000804328-25-000010:8k_2_02:36]
Our Investor Relations website at https://investor.qualcomm.com contains a significant amount of information about us, including financial and other information for investors, and it is possible that this information could be deemed to be material information. Accordingly, investors and others interested in Qualcomm should review the information posted on our website in addition to following our press releases, SEC filings and public conference calls and webcasts.

[0000804328-25-000010:8k_2_02:37]
About Qualcomm

[0000804328-25-000010:8k_2_02:38]
Qualcomm relentlessly innovates to deliver intelligent computing everywhere, helping the world tackle some of its most important challenges. Our proven solutions drive transformation across major industries, and our Snapdragon® branded platforms power extraordinary consumer experiences. Building on our nearly 40-year leadership in setting industry standards and creating era-defining technology breakthroughs, we deliver leading edge AI, high-performance, low-power computing, and unrivaled connectivity. Together with our ecosystem partners, we enable next-generation digital transformation to enrich lives, improve businesses, and advance societies. At Qualcomm, we are engineering human progress.

[0000804328-25-000010:8k_2_02:39]
Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio. Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of our engineering and research and development functions and substantially all of our products and services businesses, including our QCT semiconductor business. Snapdragon and Qualcomm branded products are products of Qualcomm Technologies, Inc. and/or its subsidiaries. Qualcomm patents are licensed by Qualcomm Incorporated.

[0000804328-25-000010:8k_2_02:40]
Note Regarding Forward-Looking Statements

[0000804328-25-000010:8k_2_02:41]
| Qualcomm Announces First Quarter Fiscal 2025 Results | Page 4 of 8 |

[0000804328-25-000010:8k_2_02:42]
QUALCOMM Incorporated

[0000804328-25-000010:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000804328-25-000010:8k_2_02:44]
(In millions, except par value amounts)

[0000804328-25-000010:8k_2_02:45]
(Unaudited)

[0000804328-25-000010:8k_2_02:46]
|  | December 29,2024 |  | September 29,2024 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 8,713 |  |  | $ | 7,849 |  |
| Marketable securities | 5,592 |  |  | 5,451 |  |
| Accounts receivable, net | 3,550 |  |  | 3,929 |  |
| Inventories | 6,303 |  |  | 6,423 |  |
| Other current assets | 1,907 |  |  | 1,579 |  |
| Total current assets | 26,065 |  |  | 25,231 |  |
| Deferred tax assets | 5,409 |  |  | 5,162 |  |
| Property, plant and equipment, net | 4,460 |  |  | 4,665 |  |
| Goodwill | 10,908 |  |  | 10,799 |  |
| Other intangible assets, net | 1,225 |  |  | 1,244 |  |
| Other assets | 7,508 |  |  | 8,053 |  |
| Total assets | $ | 55,575 |  |  | $ | 55,154 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 2,581 |  |  | $ | 2,584 |  |
| Payroll and other benefits related liabilities | 1,424 |  |  | 1,834 |  |
| Unearned revenues | 212 |  |  | 297 |  |
| Short-term debt | 1,365 |  |  | 1,364 |  |
| Other current liabilities | 4,372 |  |  | 4,425 |  |
| Total current liabilities | 9,954 |  |  | 10,504 |  |
| Unearned revenues | 77 |  |  | 88 |  |
| Long-term debt | 13,212 |  |  | 13,270 |  |
| Other liabilities | 5,452 |  |  | 5,018 |  |
| Total liabilities | 28,695 |  |  | 28,880 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,106 and 1,113 shares issued and outstanding, respectively | — |  |  | — |  |
| Retained earnings | 26,607 |  |  | 25,687 |  |
| Accumulated other comprehensive income | 273 |  |  | 587 |  |
| Total stockholders’ equity | 26,880 |  |  | 26,274 |  |
| Total liabilities and stockholders’ equity | $ | 55,575 |  |  | $ | 55,154 |  |

[0000804328-25-000010:8k_2_02:47]
| Qualcomm Announces First Quarter Fiscal 2025 Results | Page 5 of 8 |

[0000804328-25-000010:8k_2_02:48]
QUALCOMM Incorporated

[0000804328-25-000010:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000804328-25-000010:8k_2_02:50]
(In millions, except per share data)

[0000804328-25-000010:8k_2_02:51]
(Unaudited)

[0000804328-25-000010:8k_2_02:52]
|  |  | Three Months Ended |
|  |  |  |  |  |  | December 29,2024 |  | December 24,2023 |
| Revenues: |  |  |  |  |  |  |  |  |
| Equipment and services |  |  |  |  |  | $ | 9,942 |  |  | $ | 8,316 |  |
| Licensing |  |  |  |  |  | 1,727 |  |  | 1,619 |  |
| Total revenues |  |  |  |  |  | 11,669 |  |  | 9,935 |  |
| Costs and expenses: |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  |  |  |  | 5,161 |  |  | 4,312 |  |
| Research and development |  |  |  |  |  | 2,230 |  |  | 2,096 |  |
| Selling, general and administrative |  |  |  |  |  | 723 |  |  | 627 |  |
| Other |  |  |  |  |  | — |  |  | (28) |  |
| Total costs and expenses |  |  |  |  |  | 8,114 |  |  | 7,007 |  |
| Operating income |  |  |  |  |  | 3,555 |  |  | 2,928 |  |
| Interest expense |  |  |  |  |  | (163) |  |  | (178) |  |
| Investment and other income, net |  |  |  |  |  | 243 |  |  | 212 |  |
| Income from continuing operations before income taxes |  |  |  |  |  | 3,635 |  |  | 2,962 |  |
| Income tax expense |  |  |  |  |  | (455) |  |  | (151) |  |
| Income from continuing operations |  |  |  |  |  | 3,180 |  |  | 2,811 |  |
| Discontinued operations, net of income taxes |  |  |  |  |  | — |  |  | (44) |  |
| Net income |  |  |  |  |  | $ | 3,180 |  |  | $ | 2,767 |  |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |
| Continuing operations |  |  |  |  |  | $ | 2.86 |  |  | $ | 2.52 |  |
| Discontinued operations |  |  |  |  |  | — |  |  | (0.04) |  |
| Net income |  |  |  |  |  | $ | 2.86 |  |  | $ | 2.48 |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |
| Continuing operations |  |  |  |  |  | $ | 2.83 |  |  | $ | 2.50 |  |
| Discontinued operations |  |  |  |  |  | — |  |  | (0.04) |  |
| Net income |  |  |  |  |  | $ | 2.83 |  |  | $ | 2.46 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  | 1,110 |  |  | 1,116 |  |
| Diluted |  |  |  |  |  | 1,122 |  |  | 1,127 |  |

[0000804328-25-000010:8k_2_02:53]
| Qualcomm Announces First Quarter Fiscal 2025 Results | Page 6 of 8 |

[0000804328-25-000010:8k_2_02:54]
QUALCOMM Incorporated

[0000804328-25-000010:8k_2_02:55]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000804328-25-000010:8k_2_02:56]
(In millions)

[0000804328-25-000010:8k_2_02:57]
(Unaudited)

[0000804328-25-000010:8k_2_02:58]
|  | Three Months Ended |  |  |  |  |  |  |
|  | December 29,2024 |  | December 24,2023 |  |  |  |  |  |  |
| Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net income from continuing operations | $ | 3,180 |  |  | $ | 2,811 |  |  |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 436 |  |  | 437 |  |  |  |  |  |  |  |
| Income tax provision in excess of (less than) income tax payments | 247 |  |  | (1,012) |  |  |  |  |  |  |  |
| Share-based compensation expense | 759 |  |  | 602 |  |  |  |  |  |  |  |
| Net gains on marketable securities and other investments | (45) |  |  | (71) |  |  |  |  |  |  |  |
| Other items | (23) |  |  | 9 |  |  |  |  |  |  |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net | 392 |  |  | (325) |  |  |  |  |  |  |  |
| Inventories | 111 |  |  | 165 |  |  |  |  |  |  |  |
| Other assets | 148 |  |  | 115 |  |  |  |  |  |  |  |
| Trade accounts payable | 11 |  |  | 241 |  |  |  |  |  |  |  |
| Payroll, benefits and other liabilities | (541) |  |  | 74 |  |  |  |  |  |  |  |
| Unearned revenues | (88) |  |  | (81) |  |  |  |  |  |  |  |
| Net cash used by operating activities from discontinued operations | — |  |  | (16) |  |  |  |  |  |  |  |
| Net cash provided by operating activities | 4,587 |  |  | 2,949 |  |  |  |  |  |  |  |
| Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | (277) |  |  | (214) |  |  |  |  |  |  |  |
| Purchases of debt and equity marketable securities | (914) |  |  | (1,452) |  |  |  |  |  |  |  |
| Proceeds from sales and maturities of debt and equity marketable securities | 752 |  |  | 463 |  |  |  |  |  |  |  |
| Acquisitions and other investments, net of cash acquired | (260) |  |  | (60) |  |  |  |  |  |  |  |
| Other items | 28 |  |  | 7 |  |  |  |  |  |  |  |
| Net cash used by investing activities | (671) |  |  | (1,256) |  |  |  |  |  |  |  |
| Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 500 |  |  | 400 |  |  |  |  |  |  |  |
| Repayment of short-term debt | (500) |  |  | (400) |  |  |  |  |  |  |  |
| Repurchases and retirements of common stock | (1,750) |  |  | (784) |  |  |  |  |  |  |  |
| Dividends paid | (942) |  |  | (895) |  |  |  |  |  |  |  |
| Payments of tax withholdings related to vesting of share-based awards | (315) |  |  | (370) |  |  |  |  |  |  |  |
| Other items | (1) |  |  | 8 |  |  |  |  |  |  |  |
| Net cash used by financing activities | (3,008) |  |  | (2,041) |  |  |  |  |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents | (44) |  |  | 15 |  |  |  |  |  |  |  |
| Net increase (decrease) in total cash and cash equivalents | 864 |  |  | (333) |  |  |  |  |  |  |  |
| Total cash and cash equivalents at beginning of period (including $77 classified as held for sale at September 24, 2023) | 7,849 |  |  | 8,527 |  |  |  |  |  |  |  |
| Total cash and cash equivalents at end of period (including $61 classified as held for sale at December 24, 2023) | $ | 8,713 |  |  | $ | 8,194 |  |  |  |  |  |  |  |

[0000804328-25-000010:8k_2_02:59]
| Qualcomm Announces First Quarter Fiscal 2025 Results | Page 7 of 8 |

[0000804328-25-000010:8k_2_02:60]
Note Regarding Use of Non-GAAP Financial Measures

[0000804328-25-000010:8k_2_02:61]
The Non-GAAP financial measures presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP. In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, our Non-GAAP financial measures might be different than similarly titled measures used by other companies. Reconciliations between GAAP and Non-GAAP financial measures are presented herein.

[0000804328-25-000010:8k_2_02:62]
We use Non-GAAP financial information: (i) to evaluate, assess and benchmark our operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of our ongoing core operating businesses, including our QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors. Non-GAAP measurements used by us include revenues, cost of revenues, research and development (R&D) expenses, selling, general and administrative (SG&A) expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share. We are able to assess what we believe is a meaningful and comparable set of financial performance measures by using Non-GAAP information. In addition, the HR and Compensation Committee of our Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers. We present Non-GAAP financial information to provide greater transparency to investors with respect to our use of such information in financial and operational decision-making. This Non-GAAP financial information is also used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0000804328-25-000010:8k_2_02:63]
Non-GAAP information presented herein excludes our QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0000804328-25-000010:8k_2_02:64]
•QSI is excluded because we generally expect to exit our strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed as unrelated to our operational performance.

[0000804328-25-000010:8k_2_02:65]
•Share-based compensation expense primarily relates to restricted stock units. We believe that excluding share-based compensation from Non-GAAP financial information allows us and investors to make additional comparisons of the operating activities of our ongoing core businesses over time and with respect to other companies.

[0000804328-25-000010:8k_2_02:66]
•Certain other items are excluded because we view such items as unrelated to the operating activities of our ongoing core businesses, as follows:

[0000804328-25-000010:8k_2_02:67]
◦Acquisition-related items include amortization of acquisition-related intangible assets, substantially all of which relate to the amortization of technology-based intangible assets that is recorded in cost of revenues and will recur in future periods until the related intangible assets have been fully amortized. We view acquisition-related intangible assets as items arising from pre-acquisition activities determined at the time of an acquisition. Acquisition-related intangible assets contribute to revenue generation that has not been excluded from our Non-GAAP financial information. Acquisition-related items also include recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of acquisition-related items, as well as any effects from restructuring the ownership of such acquired assets. We also exclude the operating results of acquired and/or consolidated businesses that, as of close, are expected or required to be sold. Additionally, we exclude certain other acquisition-related charges such as third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition.

[0000804328-25-000010:8k_2_02:68]
◦We exclude certain other items that we view as unrelated to our ongoing businesses, such as major restructuring and restructuring-related costs, asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. We exclude gains and losses driven by the revaluation of our deferred compensation plan liabilities recognized in operating expenses and the offsetting gains and losses on the related plan assets recognized in investment and other income (expense).

[0000804328-25-000010:8k_2_02:69]
◦Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of our ongoing Non-GAAP tax rate and after-tax earnings. Beginning in the first quarter of fiscal 2023 and for the initial five-year period in which we are required to capitalize and amortize R&D expenditures for U.S. federal income tax purposes, we also exclude the favorable impact to our provision for income taxes and results of operations resulting from such change in treatment of R&D expenditures. The favorable tax provision impact will diminish in future years as capitalized research and development expenditures continue to amortize.

[0000804328-25-000010:8k_2_02:70]
| Qualcomm Announces First Quarter Fiscal 2025 Results | Page 8 of 8 |

[0000804328-25-000010:8k_2_02:71]
Reconciliations of GAAP Results to Non-GAAP Results

[0000804328-25-000010:8k_2_02:72]
| (in millions, except per share data and percentages) |  |  |  | GAAP to Non-GAAP Reconciliation | Non-GAAP Supplemental Information |
|  |  |  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1 | Non-GAAP Results | QCT | QTL | Non-GAAP Reconciling Items2 |
| Q1 Fiscal 2025 |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $11,669 |  | $— |  | $— |  |  | $— |  |  | $11,669 |  | $10,084 |  | $1,535 |  | $50 |  |
| Operating income (loss) |  |  |  | 3,555 |  | (3) |  | (758) |  | (67) |  | 4,383 |  |  |  |  |  |  |  |
| EBT |  |  |  | 3,635 |  | 19 |  | (758) |  | (53) |  | 4,427 |  | 3,246 |  | 1,158 |  | 23 |  |
| EBT as % of revenues |  |  |  | 31 | % |  |  |  |  |  |  |  | 38 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 3,180 |  | 15 |  | (611) |  | (54) |  | 3,830 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $2.83 |  | $0.01 |  | ($0.54) |  | ($0.05) |  | $3.41 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,122 |  | 1,122 |  | 1,122 |  | 1,122 |  | 1,122 |  |  |  |  |  |  |  |
| Q1 Fiscal 2024 |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $9,935 |  | $13 |  | $— |  |  | $— |  | $9,922 |  | $8,423 |  | $1,460 |  | $39 |  |
| Operating income (loss) |  |  |  | 2,928 |  | 7 |  | (602) |  | (97) |  | 3,620 |  |  |  |  |  |  |  |
| EBT |  |  |  | 2,962 |  | 11 |  | (602) |  | (32) |  | 3,585 |  | 2,593 |  | 1,080 |  | (88) |  |
| EBT as % of revenues |  |  |  | 30 | % |  |  |  |  |  |  |  | 36 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 2,767 |  | 8 |  | (476) |  | 134 |  | 3,101 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $2.46 |  | $0.01 |  | ($0.42) |  | $0.12 |  | $2.75 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,127 |  | 1,127 |  | 1,127 |  | 1,127 |  | 1,127 |  |  |  |  |  |  |  |

[0000804328-25-000010:8k_2_02:73]
(1)  Further details of amounts included in the “Other Items” column for the current period are included at the end of this news release in the section labeled “Supplemental Information and Reconciliations.” Details of amounts included in the “Other Items” column for the prior period are included in the news release for that period.

[0000804328-25-000010:8k_2_02:74]
(2)   Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues. Non-GAAP reconciling items related to EBT consisted primarily of certain cost of revenues, R&D expenses, SG&A expenses, other expenses or income, interest expense and certain investment income (expense) that are not allocated to segments for management reporting purposes; and nonreportable segment results.

[0000804328-25-000010:8k_2_02:75]
Sums may not equal totals due to rounding.

[0000804328-25-000010:8k_2_02:76]
|  | Q1 Fiscal 2025 Supplemental Information and Reconciliations |  |
| (in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |
| Cost of revenues |  | $5,161 |  |  | $— |  |  | $25 |  |  | $34 |  |  | $5,102 |  |
| Research and development expenses |  | 2,230 |  |  | — |  |  | 564 |  |  | 17 |  |  | 1,649 |  |
| Selling, general and administrative expenses |  | 723 |  |  | 3 |  |  | 169 |  |  | 16 |  |  | 535 |  |
| Interest expense |  | 163 |  |  | — |  |  | — |  |  | 1 |  |  | 162 |  |
| Investment and other income, net |  | 243 |  |  | 22 |  |  | — |  |  | 15 |  |  | 206 |  |
| Income tax expense (benefit) |  | 455 |  |  | 4 |  |  | (147) |  |  | 1 |  |  | 597 |  |

[0000804328-25-000010:8k_2_02:77]
(1)  Other items excluded from Non-GAAP results included $52 million of acquisition-related charges and $1 million of interest expense related to a fine imposed on us by the European Commission in 2019. Other items excluded from Non-GAAP results also included $15 million of losses driven by the revaluation of our deferred compensation plan liabilities, which increases operating expenses, offset by corresponding $15 million of gains driven by the revaluation of the associated plan assets, which were included within investment and other income, net.

[0000804328-25-000010:8k_2_02:78]
(2)   At fiscal year end, the quarterly tax expense for each column equals the annual tax expense (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these expenses (benefits) may not equal the total GAAP tax expense, and this difference is included in the tax expense (benefit) in the “Other Items” column. Tax expense in the “Other Items” column included a $164 million foreign currency loss related to a noncurrent receivable resulting from our refund claim of Korean withholding taxes paid in prior periods, partially offset by a $128 million benefit from the foreign-derived intangible income deduction resulting from the requirement to capitalize and amortize R&D expenditures, a $19 million foreign currency gain related to a tax liability accrued in the fourth quarter of fiscal 2024 related to the transfer of intellectual property between foreign subsidiaries, an $8 million benefit for the tax effect of acquisition-related charges, a $6 million benefit to reconcile the tax provision of each column to the total GAAP tax provision for the quarter and a $2 million benefit from the combined effect of other items in EBT.

[0000804328-25-000010:8k_2_02:79]
Sums may not equal totals due to rounding.
