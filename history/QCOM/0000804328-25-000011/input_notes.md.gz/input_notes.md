# QCOM notes — 0000804328-25-000011


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000804328-25-000011:notes:1]
Note 1. Basis of Presentation and Significant Accounting Policies Update

[0000804328-25-000011:notes:2]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 29, 2024. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year.

[0000804328-25-000011:notes:3]
We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 29, 2024 and December 24, 2023 included 13 weeks. Our fiscal year for 2025 will include 52 weeks.

[0000804328-25-000011:notes:4]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in our condensed consolidated financial statements and the accompanying notes. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

[0000804328-25-000011:notes:5]
[same as prior period, unchanged from 0000804328-24-000056:notes:3]

[0000804328-25-000011:notes:6]
[same as prior period, unchanged from 0000804328-24-000056:notes:4]

[0000804328-25-000011:notes:7]
[same as prior period, unchanged from 0000804328-24-000056:notes:5]

[0000804328-25-000011:notes:8]
Income Statement - Expense Disaggregation Disclosures: In November 2024, the FASB issued new requirements to disclose certain additional expense information on an annual and interim basis, including (among other items) the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We will adopt the new requirements for our annual periods starting in fiscal 2028 (and interim periods thereafter) on a prospective basis.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-25-000011:notes:9]
Note 2. Composition of Certain Financial Statement Items

[0000804328-25-000011:notes:10]
| Inventories (in millions) |  |  |  |
|  | December 29,2024 |  | September 29,2024 |
| Raw materials | $ | 333 |  |  | $ | 340 |  |
| Work-in-process | 3,636 |  |  | 3,497 |  |
| Finished goods | 2,334 |  |  | 2,586 |  |
|  | $ | 6,303 |  |  | $ | 6,423 |  |

[0000804328-25-000011:notes:11]
Revenues. We disaggregate our revenues by segment (Note 6), by products and services (as presented on our condensed consolidated statements of operations), and for our QCT (Qualcomm CDMA Technologies) segment, by revenue stream, which is based on the industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s (Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets.

[0000804328-25-000011:notes:12]
[same as prior period, unchanged from 0000804328-24-000056:notes:12]

[0000804328-25-000011:notes:13]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | December 29,2024 |  | December 24,2023 |  |  |  |  |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 7,574 |  |  | $ | 6,687 |  |  |  |  |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 961 |  |  | 598 |  |  |  |  |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,549 |  |  | 1,138 |  |  |  |  |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 10,084 |  |  | $ | 8,423 |  |  |  |  |  |

[0000804328-25-000011:notes:14]
[same as prior period, unchanged from 0000804328-24-000056:notes:14]

[0000804328-25-000011:notes:15]
[same as prior period, unchanged from 0000804328-24-000056:notes:15]

[0000804328-25-000011:notes:16]
(3) Primarily includes products sold for use in the following industries and applications: consumer (including personal computers (PCs), tablets, voice and music and extended reality (XR)), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, tracking and logistics and utilities).

[0000804328-25-000011:notes:17]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods generally include certain sales-based royalty revenues related to system software, certain amounts related to customer incentives and licensing revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which include the impact of the reporting by our licensees of actual royalties due) and were as follows (in millions):

[0000804328-25-000011:notes:18]
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  |  |  |  |
| Revenues recognized from previously satisfied performance obligations | $ | 263 |  |  | $ | 176 |  |  |  |  |  |

[0000804328-25-000011:notes:19]
Remaining performance obligations, which are primarily included in unearned revenues (as presented on our condensed consolidated balance sheet), represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our patent license agreements with key OEMs are generally long-term, with remaining terms expiring between fiscal 2027 and 2031. Separately, we have finalized renewal negotiations for long-term licenses with two key Chinese OEMs (for which the initial terms have expired) and expect to execute final agreements shortly. We are also in discussions with Huawei, whose agreement has expired.

[0000804328-25-000011:notes:20]
[same as prior period, unchanged from 0000804328-24-000056:notes:21]

[0000804328-25-000011:notes:21]
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  |  |  |  |
| Customer/licensee (x) | 24 | % |  | 25 | % |  |  |  |  |
| Customer/licensee (y) | 15 |  |  | 18 |  |  |  |  |  |
| Customer/licensee (z) | 14 |  |  | 14 |  |  |  |  |  |

[0000804328-25-000011:notes:22]
| Investment and Other Income (Expense), Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  |  |  |  |
| Interest and dividend income | $ | 169 |  |  | $ | 149 |  |  |  |  |  |
| Net gains on marketable securities | 19 |  |  | 11 |  |  |  |  |  |
| Net gains on other investments | 30 |  |  | 5 |  |  |  |  |  |
| Net gains on deferred compensation plan assets | 15 |  |  | 66 |  |  |  |  |  |
| Impairment losses on other investments | (24) |  |  | (12) |  |  |  |  |  |
| Other | 34 |  |  | (7) |  |  |  |  |  |
|  | $ | 243 |  |  | $ | 212 |  |  |  |  |  |

[0000804328-25-000011:notes:23]
Discontinued Operations. On June 1, 2023, SSW Partners completed the sale of Veoneer’s Active Safety business to Magna International Inc. for net cash proceeds of $1.5 billion. On March 1, 2024, SSW Partners completed the sale of Veoneer’s Restraint Control Systems business (collectively with the Active Safety business, the Non-Arriver businesses) to American Industrial Partners Capital Fund VII. Through the date of disposition by SSW Partners, the results of operations and cash flows of Veoneer’s Non-Arriver businesses are presented as discontinued operations. Cash flows from investing and financing activities from discontinued operations reported for the periods presented were not material.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-25-000011:notes:24]
Note 3. Income Taxes

[0000804328-25-000011:notes:25]
We estimate our annual effective income tax rate to be 11% for fiscal 2025, which is lower than the U.S. federal statutory rate, primarily due to a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, which includes certain additional benefits from the requirement to capitalize research and development expenditures for federal income tax purposes (that are expected to continue to decline over time as capitalized research and development expenditures continue to amortize) and a benefit from our federal research and development tax credit. Our effective tax rate of 13% for the first quarter of fiscal 2025 was higher than our estimated annual effective tax rate, primarily due to $107 million of net discrete tax charges, which principally related to foreign currency losses on a noncurrent receivable related to our refund claim of Korean withholding tax. Our effective tax rate of 5% for the first quarter of fiscal 2024 included $79 million of net discrete tax benefits.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-25-000011:notes:26]
Note 4. Capital Stock

[0000804328-25-000011:notes:27]
Stock Repurchase Program. During the first quarter of fiscal 2025, we utilized the remaining repurchase authority under the $10.0 billion stock repurchase program announced on October 12, 2021 and we began repurchases under the $15.0 billion stock repurchase program announced on November 6, 2024, which has no expiration date. At December 29, 2024, $14.3 billion remained authorized for repurchase under our stock repurchase program.

[0000804328-25-000011:notes:28]
Shares Outstanding. Shares of common stock outstanding at December 29, 2024 were as follows (in millions):

[0000804328-25-000011:notes:29]
| Balance at September 29, 2024 | 1,113 |  |
| Issued | 4 |  |
| Repurchased | (11) |  |
| Balance at December 29, 2024 | 1,106 |  |

[0000804328-25-000011:notes:30]
Dividends. On January 17, 2025, we announced a cash dividend of $0.85 per share on our common stock, payable on March 27, 2025 to stockholders of record as of the close of business on March 6, 2025.

[0000804328-25-000011:notes:31]
[same as prior period, unchanged from 0000804328-24-000056:notes:32]

[0000804328-25-000011:notes:32]
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  |  |  |  |
| Dilutive common share equivalents included in diluted shares | 12 |  |  | 11 |  |  |  |  |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 1 |  |  | 14 |  |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-25-000011:notes:33]
Note 5. Commitments and Contingencies

[0000804328-25-000011:notes:34]
Legal and Regulatory Proceedings.

[0000804328-25-000011:notes:35]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. The cases filed in the Southern District of California were subsequently transferred to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On September 27, 2018, the court certified the class. We appealed the court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class, and remanded the case to the district court. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. We filed a motion to dismiss the amended complaint, and on January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. We subsequently filed a motion for summary judgment on the plaintiffs’ remaining claims. The court granted our motion in its entirety and, on October 5, 2023, entered final judgment in Qualcomm’s favor. On November 2, 2023, the plaintiffs filed a notice of appeal to the Ninth Circuit, and on October 15, 2024, the court held a hearing on the appeal. The court has not yet issued a ruling. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-25-000011:notes:36]
Beginning in November 2017, several other consumer class action complaints were filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws and seeking damages. The claims in these complaints are similar to those in the U.S. consumer class action complaints described above. These matters are at various stages of litigation, and we intend to continue to vigorously defend ourselves.

[0000804328-25-000011:notes:37]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the district court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit (Federal Circuit). On September 6, 2024, the Federal Circuit reversed the judgment of the district court, citing certain substantive and procedural issues, and remanded the case to the district court for further proceedings. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-25-000011:notes:38]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (Arm) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with Arm (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. Arm is seeking specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology (which Arm alleges includes our custom Qualcomm Oryon CPU cores). Arm’s complaint also contended that we violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of Arm’s trademarks and sought associated injunctive and declaratory relief; however, Arm dismissed these claims prior to trial. On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm, and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia) and System-on-Chip (SoC) products incorporating such cores are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm. A trial was held beginning on December 16, 2024, and on December 20, 2024, the jury found that (i) Qualcomm did not breach the Nuvia ALA and (ii) Qualcomm CPUs that include designs acquired in the Nuvia acquisition are licensed under the Qualcomm ALA. The jury was unable to reach a verdict with respect to Arm’s claim as to whether Nuvia breached the Nuvia ALA. The parties have filed various post-trial motions in this matter, including motions for judgment as a matter of law. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.

[0000804328-25-000011:notes:39]
On April 18, 2024, we filed a separate complaint (captioned QUALCOMM Incorporated v. Arm Ltd.) against Arm in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief. Arm moved to dismiss this complaint, and on October 30, 2024, the court denied Arm’s motion to dismiss. On December 16, 2024, we filed a First Amended Complaint, alleging additional causes of action based on Arm improperly seeking to terminate the Qualcomm ALA and improperly publicizing that it was seeking to terminate the Qualcomm ALA. Trial is scheduled to begin on March 9, 2026.

[0000804328-25-000011:notes:40]
On October 22, 2024, Arm provided us with a notice alleging that we have breached the Qualcomm ALA by marketing products that contain CPUs that Arm alleges use designs, technology and code created by Nuvia employees prior to our acquisition of Nuvia; by seeking support and verification from Arm for additional products that use such alleged designs, technology and code; and by suing Arm for breach of the Qualcomm ALA. Arm’s notice asserts that it will have the right to terminate the Qualcomm ALA if such alleged breaches are not cured within 60 days of such notice. We disagree with Arm’s allegations, including that we are, or have been, in breach of the Qualcomm ALA. On January 8, 2025, Arm notified us that it was withdrawing its October 22, 2024 notice of breach and indicated that it has no current plan to terminate the Qualcomm ALA, while reserving its rights pending the outcome of the ongoing litigation.

[0000804328-25-000011:notes:41]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at December 29, 2024 for contingent losses associated with the pending matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (for example, our 2010 European Commission matter relating to the Icera complaint, and other matters arising in the ordinary course of our business, including those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-25-000011:notes:42]
Note 6. Segment Information

[0000804328-25-000011:notes:43]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software with advanced connectivity and high-performance, low-power computing technologies for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices, industrial devices and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our cloud computing processing initiative.

[0000804328-25-000011:notes:44]
[same as prior period, unchanged from 0000804328-24-000056:notes:45]

[0000804328-25-000011:notes:45]
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 10,084 |  |  | $ | 8,423 |  |  |  |  |  |
| QTL | 1,535 |  |  | 1,460 |  |  |  |  |  |
| QSI | — |  |  | 13 |  |  |  |  |  |
| Reconciling items | 50 |  |  | 39 |  |  |  |  |  |
| Total | $ | 11,669 |  |  | $ | 9,935 |  |  |  |  |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 3,246 |  |  | $ | 2,593 |  |  |  |  |  |
| QTL | 1,158 |  |  | 1,080 |  |  |  |  |  |
| QSI | 19 |  |  | 11 |  |  |  |  |  |
| Reconciling items | (788) |  |  | (722) |  |  |  |  |  |
| Total | $ | 3,635 |  |  | $ | 2,962 |  |  |  |  |  |

[0000804328-25-000011:notes:46]
[same as prior period, unchanged from 0000804328-24-000056:notes:47]

[0000804328-25-000011:notes:47]
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 50 |  |  | $ | 39 |  |  |  |  |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of revenues | $ | (59) |  |  | $ | (56) |  |  |  |  |  |
| Unallocated research and development expenses | (598) |  |  | (533) |  |  |  |  |  |
| Unallocated selling, general and administrative expenses | (189) |  |  | (185) |  |  |  |  |  |
| Unallocated other income | — |  |  | 28 |  |  |  |  |  |
| Unallocated interest expense | (163) |  |  | (178) |  |  |  |  |  |
| Unallocated investment and other income, net | 221 |  |  | 208 |  |  |  |  |  |
| Nonreportable segments | — |  |  | (6) |  |  |  |  |  |
|  | $ | (788) |  |  | $ | (722) |  |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-25-000011:notes:48]
Note 7. Fair Value Measurements and Marketable Securities

[0000804328-25-000011:notes:49]
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at December 29, 2024 (in millions):

[0000804328-25-000011:notes:50]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 4,111 |  |  | $ | 363 |  |  | $ | — |  |  | $ | 4,474 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 4,727 |  |  | — |  |  | 4,727 |  |
| Mortgage- and asset-backed securities | — |  |  | 457 |  |  | — |  |  | 457 |  |
| U.S. Treasury securities and government-related securities | 245 |  |  | 72 |  |  | — |  |  | 317 |  |
| Equity securities | 91 |  |  | — |  |  | — |  |  | 91 |  |
| Total marketable securities | 336 |  |  | 5,256 |  |  | — |  |  | 5,592 |  |
| Derivative instruments | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Other investments (1) | 1,012 |  |  | — |  |  | 41 |  |  | 1,053 |  |
| Total assets measured at fair value | $ | 5,459 |  |  | $ | 5,624 |  |  | $ | 41 |  |  | $ | 11,124 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 244 |  |  | $ | — |  |  | $ | 244 |  |
| Other liabilities (1) | 1,008 |  |  | — |  |  | — |  |  | 1,008 |  |
| Total liabilities measured at fair value | $ | 1,008 |  |  | $ | 244 |  |  | $ | — |  |  | $ | 1,252 |  |

[0000804328-25-000011:notes:51]
(1) Other investments and other liabilities included in Level 1 are comprised of our deferred compensation plan assets and liabilities.

[0000804328-25-000011:notes:52]
Long-term Debt. At December 29, 2024, the aggregate fair value of our outstanding fixed-rate notes, based on Level 2 inputs, was approximately $13.6 billion.

[0000804328-25-000011:notes:53]
Marketable Securities. At December 29, 2024 and September 29, 2024, our marketable securities were all classified as current and were primarily comprised of available-for-sale debt securities (substantially all of which were corporate bonds and notes).

[0000804328-25-000011:notes:54]
[same as prior period, unchanged from 0000804328-24-000056:notes:52]

[0000804328-25-000011:notes:55]
|  | December 29,2024 |
| Years to Maturity |  |
| Less than one year | $ | 1,477 |  |
| One to five years | 3,567 |  |
| No single maturity date | 457 |  |
| Total | $ | 5,501 |  |

[0000804328-25-000011:notes:56]
[same as prior period, unchanged from 0000804328-24-000056:notes:54]


## ecd:MtrlTermsOfTrdArrTextBlock

[0000804328-25-000011:notes:57]
On November 26, 2024, Akash Palkhiwala, our Chief Financial Officer and Chief Operating Officer, adopted a Rule 10b5-1 trading arrangement (as defined in Item 408 of Regulation S-K) providing for the sale of an aggregate of (i) 40,000 shares of our common stock plus (ii) 100% of the net shares issued to Mr. Palkhiwala upon the vesting of restricted stock unit awards representing 25,269 shares of our common stock, including accrued dividend-equivalent shares and excluding any shares withheld to satisfy tax withholding obligations in connection with the settlement of such awards. The plan is scheduled to terminate on February 27, 2026.

[0000804328-25-000011:notes:58]
On December 11, 2024, Heather Ace, our Chief Human Resources Officer, acting as trustee on behalf of her family trust, adopted a Rule 10b5-1 trading arrangement providing for the sale of 6,400 shares of our common stock. The plan is scheduled to terminate on November 13, 2025.
