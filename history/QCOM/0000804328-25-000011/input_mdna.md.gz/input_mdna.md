# QCOM MD&A — 0000804328-25-000011


## mdna

[0000804328-25-000011:mdna:1]
[same as prior period, unchanged from 0000804328-24-000056:mdna:1]

[0000804328-25-000011:mdna:2]
This information should be read in conjunction with the condensed consolidated financial statements and the notes thereto included in “Part I, Item 1” of this Quarterly Report and with “Management’s Discussion and Analysis of Financial Condition and Results of Operations” for the fiscal year ended September 29, 2024 contained in our 2024 Annual Report on Form 10-K.

[0000804328-25-000011:mdna:3]
This Quarterly Report (including but not limited to this section titled Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates,” “may,” “will,” “would” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report. Additionally, statements concerning future matters such as our future business, prospects, results of operations or financial condition; research and development or technology investments; new or enhanced products, services or technologies; emerging industries or business models; design wins or product launches; industry, market or technology trends, dynamics or transitions; our expectations regarding future demand or supply conditions; strategic investments or acquisitions, and the anticipated timing or benefits thereof; licensing discussions and negotiations; legal or regulatory matters, including the expected impacts of pending tax or other regulatory changes; U.S./China trade or national security tensions; vertical integration by our customers; competition; annual effective tax rates; and other statements regarding matters that are not historical are also forward-looking statements.

[0000804328-25-000011:mdna:4]
First Quarter Fiscal 2025 Overview

[0000804328-25-000011:mdna:5]
Revenues for the first quarter of fiscal 2025 were $11.7 billion, an increase of 17% compared to the year ago quarter, with net income of $3.2 billion, an increase of 15% compared to the year ago quarter. Key items from the first quarter of fiscal 2025 included:

[0000804328-25-000011:mdna:6]
•QCT revenues increased by 20% in the first quarter of fiscal 2025 compared to the year ago quarter, due to higher handsets, IoT and automotive revenues.

[0000804328-25-000011:mdna:7]
•QTL revenues increased by 5% in the first quarter of fiscal 2025 compared to the year ago quarter.

[0000804328-25-000011:mdna:8]
[same as prior period, unchanged from 0000804328-24-000056:mdna:8]

[0000804328-25-000011:mdna:9]
[same as prior period, unchanged from 0000804328-24-000056:mdna:9]

[0000804328-25-000011:mdna:10]
[same as prior period, unchanged from 0000804328-24-000056:mdna:10]

[0000804328-25-000011:mdna:11]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering and research and development functions are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0000804328-25-000011:mdna:12]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products (for example, certain major handset OEMs accelerated their premium-tier device launches into the first quarter of fiscal 2025) and in QTL revenues when licensees’ sales occur. These trends may or may not continue in the future. Further, the trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings.

[0000804328-25-000011:mdna:13]
[same as prior period, unchanged from 0000804328-24-000056:mdna:14]

[0000804328-25-000011:mdna:14]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  | Change |  |  |  |  |  |  |
| Equipment and services | $ | 9,942 |  |  | $ | 8,316 |  |  | $ | 1,626 |  |  |  |  |  |  |  |
| Licensing | 1,727 |  |  | 1,619 |  |  | 108 |  |  |  |  |  |  |  |
|  | $ | 11,669 |  |  | $ | 9,935 |  |  | $ | 1,734 |  |  |  |  |  |  |  |

[0000804328-25-000011:mdna:15]
First quarter 2025 vs. 2024

[0000804328-25-000011:mdna:16]
The increase in revenues in the first quarter of fiscal 2025 was primarily due to:

[0000804328-25-000011:mdna:17]
+    $1.6 billion in higher equipment and services revenues from our QCT segment

[0000804328-25-000011:mdna:18]
+    $75 million in higher licensing revenues from our QTL segment

[0000804328-25-000011:mdna:19]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  | Change |  |  |  |  |  |  |
| Cost of revenues | $ | 5,161 |  |  | $ | 4,312 |  |  | $ | 849 |  |  |  |  |  |  |  |
| Gross margin | 56 | % |  | 57 | % |  |  |  |  |  |  |  |  |

[0000804328-25-000011:mdna:20]
First quarter 2025 vs. 2024

[0000804328-25-000011:mdna:21]
Gross margin percentage decreased in the first quarter of fiscal 2025 primarily due to a decrease in the proportion of total revenues related to QTL licensing revenues (which have a higher margin contribution).

[0000804328-25-000011:mdna:22]
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  | Change |  |  |  |  |  |  |
| Research and development | $ | 2,230 |  |  | $ | 2,096 |  |  | $ | 134 |  |  |  |  |  |  |  |
| % of revenues | 19 | % |  | 21 | % |  |  |  |  |  |  |  |  |

[0000804328-25-000011:mdna:23]
First quarter 2025 vs. 2024

[0000804328-25-000011:mdna:24]
The increase in research and development expenses in the first quarter of fiscal 2025 was primarily due to:

[0000804328-25-000011:mdna:25]
+    $103 million increase in share-based compensation expense

[0000804328-25-000011:mdna:26]
+    $61 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including investments in key growth and diversification opportunities)

[0000804328-25-000011:mdna:27]
-    $31 million decrease in expenses driven by the revaluation of our deferred compensation obligation (which resulted in a corresponding decrease in net gains on deferred compensation plan assets within investment and other income, net due to the revaluation of the related assets)

[0000804328-25-000011:mdna:28]
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  | Change |  |  |  |  |  |  |
| Selling, general and administrative | $ | 723 |  |  | $ | 627 |  |  | $ | 96 |  |  |  |  |  |  |  |
| % of revenues | 6 | % |  | 6 | % |  |  |  |  |  |  |  |  |

[0000804328-25-000011:mdna:29]
First quarter 2025 vs. 2024

[0000804328-25-000011:mdna:30]
The increase in selling, general and administrative expenses in the first quarter of fiscal 2025 was primarily due to:

[0000804328-25-000011:mdna:31]
+    $48 million increase in share-based compensation expense

[0000804328-25-000011:mdna:32]
+    $46 million increase in sales and marketing expenses

[0000804328-25-000011:mdna:33]
-    $19 million decrease in expenses driven by the revaluation of our deferred compensation obligation

[0000804328-25-000011:mdna:34]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  | Change |  |  |  |  |  |  |
| Interest expense | $ | 163 |  |  | $ | 178 |  |  | $ | (15) |  |  |  |  |  |  |  |
| Investment and other income (expense), net |
| Interest and dividend income | $ | 169 |  |  | $ | 149 |  |  | $ | 20 |  |  |  |  |  |  |  |
| Net gains on marketable securities | 19 |  |  | 11 |  |  | 8 |  |  |  |  |  |  |  |
| Net gains on other investments | 30 |  |  | 5 |  |  | 25 |  |  |  |  |  |  |  |
| Net gains on deferred compensation plan assets | 15 |  |  | 66 |  |  | (51) |  |  |  |  |  |  |  |
| Impairment losses on other investments | (24) |  |  | (12) |  |  | (12) |  |  |  |  |  |  |  |
| Other | 34 |  |  | (7) |  |  | 41 |  |  |  |  |  |  |  |
|  | $ | 243 |  |  | $ | 212 |  |  | $ | 31 |  |  |  |  |  |  |  |

[0000804328-25-000011:mdna:35]
[same as prior period, unchanged from 0000804328-24-000056:mdna:48]

[0000804328-25-000011:mdna:36]
[same as prior period, unchanged from 0000804328-24-000056:mdna:49]

[0000804328-25-000011:mdna:37]
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  |  |  |  |
| Expected income tax provision at federal statutory tax rate | $ | 763 |  |  | $ | 622 |  |  |  |  |  |
| Benefit from foreign-derived intangible income (FDII) deduction, excluding the impact of capitalizing research and development expenditures | (207) |  |  | (164) |  |  |  |  |  |
| Foreign currency loss (gain) related to foreign withholding tax receivable | 166 |  |  | (39) |  |  |  |  |  |
| Benefit from FDII deduction related to capitalizing research and development expenditures | (152) |  |  | (189) |  |  |  |  |  |
| Benefit related to the research and development tax credit | (74) |  |  | (75) |  |  |  |  |  |
| Excess tax benefit associated with share-based awards | (37) |  |  | (29) |  |  |  |  |  |
| Other | (4) |  |  | 25 |  |  |  |  |  |
| Income tax expense | $ | 455 |  |  | $ | 151 |  |  |  |  |  |
| Effective tax rate | 13 | % |  | 5 | % |  |  |  |  |

[0000804328-25-000011:mdna:38]
We estimate our annual effective income tax rate to be 11% for fiscal 2025, which is lower than the U.S. federal statutory rate. Additional information regarding our annual effective income tax rate and income tax expense is provided in this Quarterly Report in “Notes to Condensed Consolidated Statements, Note 3. Income Taxes.”

[0000804328-25-000011:mdna:39]
The Organization for Economic Co-operation and Development (OECD) has announced a framework to implement a global minimum tax of 15% (referred to as Pillar Two). Certain countries have implemented or are in the process of implementing the Pillar Two legislation, which applies to us beginning in fiscal 2025. While we do not currently expect this to materially impact our consolidated financial statements, we continue to monitor the impact as countries implement legislation and the OECD provides additional guidance.

[0000804328-25-000011:mdna:40]
| Discontinued Operations (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  | Change |  |  |  |  |  |  |
| Discontinued operations, net of income taxes | $ | — |  |  | $ | (44) |  |  | $ | 44 |  |  |  |  |  |  |  |

[0000804328-25-000011:mdna:41]
Discontinued operations in the first quarter of fiscal 2024 are related to the Non-Arriver businesses. Information regarding the Non-Arriver businesses is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Discontinued Operations.”

[0000804328-25-000011:mdna:42]
[same as prior period, unchanged from 0000804328-24-000056:mdna:55]

[0000804328-25-000011:mdna:43]
The following should be read in conjunction with our financial results for the first quarter of fiscal 2025 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0000804328-25-000011:mdna:44]
[same as prior period, unchanged from 0000804328-24-000056:mdna:57]

[0000804328-25-000011:mdna:45]
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  | Change |  |  |  |  |  |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets | $ | 7,574 |  |  | $ | 6,687 |  |  | $ | 887 |  |  |  |  |  |  |  |
| Automotive | 961 |  |  | 598 |  |  | 363 |  |  |  |  |  |  |  |
| IoT (internet of things) | 1,549 |  |  | 1,138 |  |  | 411 |  |  |  |  |  |  |  |
| Total revenues (1) | $ | 10,084 |  |  | $ | 8,423 |  |  | $ | 1,661 |  |  |  |  |  |  |  |
| EBT (2) | $ | 3,246 |  |  | $ | 2,593 |  |  | $ | 653 |  |  |  |  |  |  |  |
| EBT as a % of revenues | 32 | % |  | 31 | % |  | 1 point |  |  |  |  |  |  |

[0000804328-25-000011:mdna:46]
[same as prior period, unchanged from 0000804328-24-000056:mdna:59]

[0000804328-25-000011:mdna:47]
[same as prior period, unchanged from 0000804328-24-000056:mdna:60]

[0000804328-25-000011:mdna:48]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $9.9 billion and $8.3 billion in the first quarter of fiscal 2025 and 2024, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets as well as sales of 4G, 5G sub 6 and 5G millimeter wave RFFE products.

[0000804328-25-000011:mdna:49]
First quarter 2025 vs. 2024

[0000804328-25-000011:mdna:50]
The increase in QCT revenues in the first quarter of fiscal 2025 was primarily due to:

[0000804328-25-000011:mdna:51]
+    higher handsets revenues, primarily due to $448 million in higher chipset shipments driven by certain major OEMs, and $424 million in higher revenues per chipset (driven by higher average selling prices and favorable mix), both of which benefited from an increase in demand in premium-tier Snapdragon platforms

[0000804328-25-000011:mdna:52]
+    higher IoT revenues, due to $513 million in higher shipments across consumer, industrial and edge networking products, partially offset by unfavorable product mix

[0000804328-25-000011:mdna:53]
+    higher automotive revenues, primarily driven by an increase in shipments from new vehicle launches with our Snapdragon digital cockpit products

[0000804328-25-000011:mdna:54]
QCT EBT as a percentage of revenues increased in the first quarter of fiscal 2025 primarily due to:

[0000804328-25-000011:mdna:55]
[same as prior period, unchanged from 0000804328-24-000056:mdna:68]

[0000804328-25-000011:mdna:56]
-    higher operating expenses, primarily driven by higher research and development and selling, general and administrative expenses

[0000804328-25-000011:mdna:57]
Gross margin percentage remained approximately flat in the first quarter of fiscal 2025, primarily driven by higher product costs, offset by higher average selling prices.

[0000804328-25-000011:mdna:58]
[same as prior period, unchanged from 0000804328-24-000056:mdna:12]

[0000804328-25-000011:mdna:59]
[same as prior period, unchanged from 0000804328-24-000056:mdna:79]

[0000804328-25-000011:mdna:60]
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  | Change |  |  |  |  |  |  |
| Licensing revenues | $ | 1,535 |  |  | $ | 1,460 |  |  | $ | 75 |  |  |  |  |  |  |  |
| EBT | 1,158 |  |  | 1,080 |  |  | 78 |  |  |  |  |  |  |  |
| EBT as a % of revenues | 75 | % |  | 74 | % |  | 1 point |  |  |  |  |  |  |

[0000804328-25-000011:mdna:61]
First quarter 2025 vs. 2024

[0000804328-25-000011:mdna:62]
The increase in QTL licensing revenues in the first quarter of fiscal 2025 was primarily due to:

[0000804328-25-000011:mdna:63]
+    $32 million increase in estimated sales of 3G/4G/5G-based multimode products

[0000804328-25-000011:mdna:64]
+    $30 million in higher royalty revenues recognized related to devices sold in prior periods

[0000804328-25-000011:mdna:65]
QTL EBT as a percentage of revenues increased in the first quarter of fiscal 2025 primarily due to higher revenues.

[0000804328-25-000011:mdna:66]
[same as prior period, unchanged from 0000804328-24-000056:mdna:92]

[0000804328-25-000011:mdna:67]
|  | Three Months Ended |  |  |
|  | December 29,2024 |  | December 24,2023 |  | Change |  |  |  |  |  |  |
| Equipment and services revenues | $ | — |  |  | $ | 13 |  |  | $ | (13) |  |  |  |  |  |  |  |
| EBT | 19 |  |  | 11 |  |  | 8 |  |  |  |  |  |  |  |

[0000804328-25-000011:mdna:68]
First quarter 2025 vs. 2024

[0000804328-25-000011:mdna:69]
QSI segment results were not material in the first quarter of fiscal 2025 and 2024.

[0000804328-25-000011:mdna:70]
[same as prior period, unchanged from 0000804328-24-000056:mdna:98]

[0000804328-25-000011:mdna:71]
We believe that 5G combined with high-performance, low-power computing and on-device artificial intelligence will continue to drive adoption of certain technologies that are already commonly used in smartphones by industries and applications beyond mobile handsets, such as automotive and IoT. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing, and a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long-term.

[0000804328-25-000011:mdna:72]
[same as prior period, unchanged from 0000804328-24-000056:mdna:100]

[0000804328-25-000011:mdna:73]
[same as prior period, unchanged from 0000804328-24-000056:mdna:103]

[0000804328-25-000011:mdna:74]
•We expect continued intense competition, including from vertical integration by certain of our customers (e.g., Apple).

[0000804328-25-000011:mdna:75]
[same as prior period, unchanged from 0000804328-24-000056:mdna:106]

[0000804328-25-000011:mdna:76]
We have recently entered into comprehensive 4G and 5G license agreements with Shenzhen Transsion Holdings Limited (a growing, China-headquartered OEM that sells primarily in developing regions). As a result of our agreements with Transsion, all outstanding litigation between the parties has been, or is in the process of being, dismissed.

[0000804328-25-000011:mdna:77]
Further, we have finalized renewal negotiations for long-term licenses with two key Chinese OEMs, and expect to execute final agreements shortly. We are also in discussions with Huawei, whose agreement has expired. See “Risk Factors” in this Quarterly Report, including the Risk Factors titled “The continued and future success of our licensing programs requires us to continue to evolve our patent portfolio and to renew or renegotiate license agreements that are expiring.”

[0000804328-25-000011:mdna:78]
We are also involved in other legal proceedings, including those described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Litigation is inherently uncertain, and, while we intend to continue to vigorously defend ourselves in such matters, the unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0000804328-25-000011:mdna:79]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless industry and governments as to the benefits of our licensing programs and our extensive

[0000804328-25-000011:mdna:80]
20

[0000804328-25-000011:mdna:81]
technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may be dissatisfied with the need to pay reasonable royalties for the use of our technologies and not welcome the success of our licensing programs in enabling new, highly cost-effective competitors to their products. Accordingly, such companies and/or governments or regulators may continue to challenge our business model in various forums throughout the world.

[0000804328-25-000011:mdna:82]
[same as prior period, unchanged from 0000804328-24-000056:mdna:109]

[0000804328-25-000011:mdna:83]
[same as prior period, unchanged from 0000804328-24-000056:mdna:110]

[0000804328-25-000011:mdna:84]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at December 29, 2024 and September 29, 2024 and for the first three months of fiscal 2025 and 2024 (in millions):

[0000804328-25-000011:mdna:85]
|  | December 29,2024 |  | September 29,2024 |  | Change |  |  |
| Cash, cash equivalents and marketable securities |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 8,713 |  |  | $ | 7,849 |  |  | $ | 864 |  |  |  |
| Marketable securities | 5,592 |  |  | 5,451 |  |  | 141 |  |  |  |
|  | $ | 14,305 |  |  | $ | 13,300 |  |  | $ | 1,005 |  |  |  |
| Debt (1) | $ | 14,577 |  |  | $ | 14,634 |  |  | $ | (57) |  |  |  |

[0000804328-25-000011:mdna:86]
(1) Includes our issued debt reported as long-term and $1.4 billion reported as short-term debt (which matures in May 2025). As of December 29, 2024 and September 29, 2024, our credit facility was undrawn, and we had no commercial paper outstanding.

[0000804328-25-000011:mdna:87]
|  | Three Months Ended |
|  | December 29,2024 |  | December 24,2023 |  | Change |  |  |
| Net cash provided by operating activities | $ | 4,587 |  |  | $ | 2,949 |  |  | $ | 1,638 |  |  |  |
| Net cash used by investing activities | (671) |  |  | (1,256) |  |  | 585 |  |  |  |
| Net cash used by financing activities | (3,008) |  |  | (2,041) |  |  | (967) |  |  |  |

[0000804328-25-000011:mdna:88]
Cash, cash equivalents and marketable securities. The net increase in cash, cash equivalents and marketable securities for the first three months of fiscal 2025 was primarily due to net cash provided by operating activities, partially offset by $1.8 billion in payments to repurchase 11 million shares of our common stock, $942 million in cash dividends paid, $315 million in payments of tax withholdings related to the vesting of share-based awards, $277 million in capital expenditures and $260 million in cash paid for acquisitions and other investments.

[0000804328-25-000011:mdna:89]
The impact on our operating cash flows from net changes in our operating assets and liabilities for the first three months of fiscal 2025 was largely flat primarily from a decrease in accounts receivable (despite having higher revenues compared to the fourth quarter of fiscal 2024) due to the timing of integrated circuit shipments during the period and an increase in customer incentive arrangements that are included in accounts receivable, which included the impact of timing of related payments. This was largely offset by a decrease in payroll and other benefit related liabilities primarily driven by payments related to our employee cash incentive program.

[0000804328-25-000011:mdna:90]
[same as prior period, unchanged from 0000804328-24-000056:mdna:121]

[0000804328-25-000011:mdna:91]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2024 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At December 29, 2024, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements”, “Looking Forward” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2024 Annual Report on Form 10-K.

[0000804328-25-000011:mdna:92]
[same as prior period, unchanged from 0000804328-24-000056:mdna:47]

[0000804328-25-000011:mdna:93]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Risk Factors” in this Quarterly Report.

[0000804328-25-000011:mdna:94]
[same as prior period, unchanged from 0000804328-24-000056:mdna:124]

[0000804328-25-000011:mdna:95]
[same as prior period, unchanged from 0000804328-24-000056:mdna:125]

[0000804328-25-000011:mdna:96]
Information regarding recent accounting guidance and the impact of such guidance on our condensed consolidated financial statements is provided in this Quarterly Report in the “Notes to Condensed Consolidated Financial Statements, Note 1. Basis of Presentation and Significant Accounting Policies Update.”
