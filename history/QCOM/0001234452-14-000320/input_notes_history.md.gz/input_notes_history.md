# QCOM note change history — 0001234452-14-000154 → 0001234452-14-000238


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-07-23):
[0001234452-14-000238:note_history:1]
Legal Proceedings. Tessera, Inc. v. QUALCOMM Incorporated: On April 17, 2007, Tessera filed a patent infringement lawsuit in the United States District Court for the Eastern District of Texas and a complaint with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company and other companies, alleging infringement of two patents. The district court action was stayed pending resolution of the ITC proceeding, including all appeals. On January 18, 2012, pursuant to the parties’ stipulation, the District Court for the Eastern District of Texas lifted the stay and ordered that the case be moved to the United States District Court for the Northern District of California. On March 27, 2014, Tessera and the Company reached an agreement that the lawsuit against the Company would be dismissed with prejudice, and the parties will engage in discussions to explore potential technical collaborations. The court dismissed the lawsuit on April 1, 2014 based on the parties’ stipulation.
  (was, 2014-04-23, similarity 0.706):
[0001234452-14-000154:note_history:1]
Legal Proceedings. Tessera, Inc. v. QUALCOMM Incorporated: On April 17, 2007, Tessera filed a patent infringement lawsuit in the United States District Court for the Eastern District of Texas and a complaint with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company and other companies, alleging infringement of two patents. The district court action was stayed pending resolution of the ITC proceeding, including all appeals. On May 20, 2009, the ITC issued a limited exclusion order and a cease and desist order, both of which were terminated when the patents expired on September 24, 2010. During the period of the exclusion order, the Company shifted supply of accused chips for customers who manufacture products that may be imported to the United States to a licensed supplier of Tessera, and the Company continued to supply those customers without interruption. The ITC’s orders were affirmed on appeal, and on November 28, 2011, the United States Supreme Court denied the Company’s petition for review. On January 18, 2012, pursuant to the parties’ stipulation, the District Court in the Eastern District of Texas lifted the stay and ordered that the case be moved to the United States District Court for the Northern District of California. On March 1, 2012, that court consolidated the case with an earlier-filed lawsuit filed by Tessera against multiple parties, including some of the Company’s semiconductor chip package suppliers. On March 27, 2014, Tessera and the Company reached an agreement that the lawsuit against the Company would be dismissed with prejudice, and the parties will engage in discussions to explore potential technical collaborations. The court dismissed the lawsuit on April 1, 2014 based on the parties’ stipulation.

- added (2014-07-23):
[0001234452-14-000238:note_history:2]
ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. The trial began on October 7, 2013. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of approximately $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. On June 25, 2014, ParkerVision filed a notice of appeal with the court. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company has reversed all recorded amounts related to the damages verdict. On May 1, 2014, ParkerVision filed another complaint, captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation and HTC America, Inc., also in the United States District Court for the Middle District of Florida, alleging that certain of the Company’s products infringe seven additional ParkerVision patents. The complaint seeks damages and injunctive and other relief. The Company has not been served with the complaint in this action.

- added (2014-07-23):
[0001234452-14-000238:note_history:3]
Icera Complaint to the European Commission: On June 7, 2010, the European Commission (the Commission) notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. The Company continues to cooperate fully with the Commission’s preliminary investigation.

- changed (2014-07-23):
[0001234452-14-000238:note_history:4]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee has completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.
  (was, 2014-04-23, similarity 0.9924):
[0001234452-14-000154:note_history:4]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). As previously disclosed, the audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee has completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.

- changed (2014-07-23):
[0001234452-14-000238:note_history:5]
A Wells Notice is not a formal allegation or finding by the SEC of wrongdoing or violation of law. Rather, the purpose of a Wells Notice is to give the recipient an opportunity to make a “Wells submission” setting forth reasons why the proposed enforcement action should not be filed and/or bringing additional facts to the SEC’s attention before any decision is made by the SEC as to whether to commence a proceeding. On April 4, 2014 and May 29, 2014, the Company made Wells submissions to the staff of the Los Angeles Regional Office explaining why the Company believes it has not violated the FCPA and therefore enforcement action is not warranted.
  (was, 2014-04-23, similarity 0.9631):
[0001234452-14-000154:note_history:5]
A Wells Notice is not a formal allegation or finding by the SEC of wrongdoing or violation of law. Rather, the purpose of a Wells Notice is to give the recipient an opportunity to make a “Wells submission” setting forth reasons why the proposed enforcement action should not be filed and/or bringing additional facts to the SEC’s attention before any decision is made by the SEC as to whether to commence a proceeding. On April 4, 2014, the Company made a Wells submission to the staff of the Los Angeles Regional Office explaining why the Company believes it has not violated the FCPA and therefore enforcement action is not warranted.

- changed (2014-07-23):
[0001234452-14-000238:note_history:6]
China National Development and Reform Commission (NDRC) Investigation: In November 2013, the NDRC notified the Company that it had commenced an investigation of the Company relating to the Chinese Anti-Monopoly Law (AML). The Company understands that the investigation concerns primarily the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business, including how royalties are calculated in the Company’s patent licenses, the value exchanged for cross-licenses to patents of the Company’s licensees, whether the Company will offer license agreements limited to patents essential to certain standards, whether royalties are sought for the Company’s expired patents, the Company’s policy of selling chipsets only to the Company’s patent licensees, the alleged refusal of the Company to grant patent licenses to chipset manufacturers, and certain other terms and conditions in the Company’s patent license and chipset sale agreements. A broad range of remedies with respect to business practices deemed to violate the AML is potentially available to the NDRC, including but not limited to issuing an order to cease conduct deemed illegal, confiscating gains deemed illegally obtained, imposing a fine in the range of 1% to 10% of the prior year’s revenues and requiring modifications to business practices. Given the limited precedent of enforcement actions and penalties under the AML, it is difficult to predict the outcome of this matter or what remedies may be imposed by the NDRC. The Company continues to cooperate with the NDRC as it conducts its investigation.
  (was, 2014-04-23, similarity 0.7786):
[0001234452-14-000154:note_history:6]
China National Development and Reform Commission (NDRC) Investigation: In November 2013, the NDRC notified the Company that it had commenced an investigation of the Company relating to the Chinese Anti-Monopoly Law (AML). The Company understands that the investigation concerns primarily the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business. A broad range of remedies with respect to business practices deemed to violate the AML is potentially available to the NDRC, including but not limited to issuing an order to cease conduct deemed illegal, confiscating gains deemed illegally obtained, imposing a fine in the range of 1% to 10% of the prior year’s revenues and requiring modifications to business practices. Given the limited precedent of enforcement actions and penalties under the AML, it is difficult to predict the outcome of this matter or what, if any, remedies may be imposed by the NDRC. The Company continues to cooperate with the NDRC as it conducts its investigation.

- added (2014-07-23):
[0001234452-14-000238:note_history:7]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at June 29, 2014 for contingent losses associated with these matters based on its belief that, with the exception of the NDRC matter, losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. Regarding the NDRC matter, the Company believes that a loss is probable but that any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

- changed (2014-07-23):
[0001234452-14-000238:note_history:8]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through June 29, 2014, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.
  (was, 2014-04-23, similarity 0.9955):
[0001234452-14-000154:note_history:8]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through March 30, 2014, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

- changed (2014-07-23):
[0001234452-14-000238:note_history:9]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at June 29, 2014 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.
  (was, 2014-04-23, similarity 0.9951):
[0001234452-14-000154:note_history:9]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at March 30, 2014 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

- changed (2014-07-23):
[0001234452-14-000238:note_history:10]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations, which generally have a remaining term of less than one year, under these agreements at June 29, 2014 for the remainder of fiscal 2014 and for each of the subsequent four years from fiscal 2015 through fiscal 2018 were approximately $3.0 billion, $387 million, $64 million, $19 million and $17 million, respectively, and $40 million thereafter. Of these amounts, for the remainder of fiscal 2014 and for fiscal 2015, commitments to purchase integrated circuit product inventories comprised $2.6 billion and $228 million, respectively. Integrated circuit product inventory obligations represent purchase commitments for wafers, die and assembly and test services. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase orders is generally allowed but requires payment of costs incurred through the date of cancelation.
  (was, 2014-04-23, similarity 0.7223):
[0001234452-14-000154:note_history:10]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations, which generally have a remaining term of less than one year, under these agreements at March 30, 2014 for the remainder of fiscal 2014 and for each of the subsequent four years from fiscal 2015 through fiscal 2018 were approximately $3.1 billion, $243 million, $67 million, $8 million and $2 million, respectively, and $6 million thereafter. Of these amounts, for the remainder of fiscal 2014 and for fiscal 2015, commitments to purchase integrated circuit product inventories comprised $2.7 billion and $98 million, respectively. Integrated circuit product inventory obligations represent purchase commitments for silicon wafers and assembly and test services. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase orders is generally allowed but requires payment of costs incurred through the date of cancelation.

- changed (2014-07-23):
[0001234452-14-000238:note_history:11]
Leases. The future minimum lease payments for all capital leases and operating leases at June 29, 2014 by fiscal year were as follows (in millions):
  (was, 2014-04-23, similarity 0.9686):
[0001234452-14-000154:note_history:11]
Leases. The future minimum lease payments for all capital leases and operating leases at March 30, 2014 by fiscal year were as follows (in millions):

- changed (2014-07-23):
[0001234452-14-000238:note_history:12]
|  | CapitalLeases |  | OperatingLeases |  | Total |
| Remainder of fiscal 2014 | $ | — |  |  | $ | 25 |  |  | $ | 25 |  |
| 2015 | 1 |  |  | 93 |  |  | 94 |  |
| 2016 | 1 |  |  | 79 |  |  | 80 |  |
| 2017 | 1 |  |  | 58 |  |  | 59 |  |
| 2018 | 1 |  |  | 31 |  |  | 32 |  |
| Thereafter | 18 |  |  | 50 |  |  | 68 |  |
| Total minimum lease payments | 22 |  |  | $ | 336 |  |  | $ | 358 |  |
| Deduct: Amounts representing interest | 10 |  |  |  |  |  |
| Present value of minimum lease payments | 12 |  |  |  |  |  |
| Deduct: Current portion of capital lease obligations | 1 |  |  |  |  |  |
| Long-term portion of capital lease obligations | $ | 11 |  |  |  |  |  |
  (was, 2014-04-23, similarity 0.9983):
[0001234452-14-000154:note_history:12]
|  | CapitalLeases |  | OperatingLeases |  | Total |
| Remainder of fiscal 2014 | $ | 1 |  |  | $ | 49 |  |  | $ | 50 |  |
| 2015 | 1 |  |  | 83 |  |  | 84 |  |
| 2016 | 1 |  |  | 71 |  |  | 72 |  |
| 2017 | 1 |  |  | 54 |  |  | 55 |  |
| 2018 | 1 |  |  | 29 |  |  | 30 |  |
| Thereafter | 20 |  |  | 48 |  |  | 68 |  |
| Total minimum lease payments | 25 |  |  | $ | 334 |  |  | $ | 359 |  |
| Deduct: Amounts representing interest | 12 |  |  |  |  |  |
| Present value of minimum lease payments | 13 |  |  |  |  |  |
| Deduct: Current portion of capital lease obligations | 1 |  |  |  |  |  |
| Long-term portion of capital lease obligations | $ | 12 |  |  |  |  |  |

- removed (2014-07-23):
[0001234452-14-000154:note_history:13]
ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. On February 28, 2012, ParkerVision filed an amended complaint dropping two patents from the case and adding one new patent. Subsequently, ParkerVision narrowed its allegations to assert only four patents. The trial began on October 7, 2013. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of approximately $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. The court’s briefing schedule for post-verdict motions, including the parties’ respective motions for judgment as a matter of law and a new trial and ParkerVision’s motions for injunctive relief and ongoing royalties concluded on January 24, 2014. A hearing on the post-verdict motions is scheduled for May 1, 2014.

- removed (2014-07-23):
[0001234452-14-000154:note_history:14]
Icera Complaint to the European Commission: On June 7, 2010, the European Commission (the Commission) notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. The Company continues to cooperate fully with the Commission’s preliminary investigation.

- removed (2014-07-23):
[0001234452-14-000154:note_history:15]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. Other than amounts accrued for the ParkerVision matter, which have not been paid, the Company has not recorded any accrual at March 30, 2014 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. Nonetheless, the unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-07-23):
[0001234452-14-000238:note_history:16]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim data includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 29, 2013. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 29, 2014 and June 30, 2013 included 13 weeks and 39 weeks, respectively.
  (was, 2014-04-23, similarity 0.9817):
[0001234452-14-000154:note_history:16]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim data includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 29, 2013. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and six-month periods ended March 30, 2014 and March 31, 2013 included 13 weeks and 26 weeks, respectively.

- changed (2014-07-23):
[0001234452-14-000238:note_history:17]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 29, 2014 were 30,642,000 and 31,985,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and nine months ended June 30, 2013 were 37,927,000 and 40,132,000, respectively.
  (was, 2014-04-23, similarity 0.9694):
[0001234452-14-000154:note_history:17]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 30, 2014 were 30,989,000 and 32,656,000, respectively. The dilutive common share equivalents, calculated using the treasury stock method, for the three and six months ended March 31, 2013 were 41,007,000 and 41,235,000, respectively.

- changed (2014-07-23):
[0001234452-14-000238:note_history:18]
Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 7,000 and 278,000 during the three and nine months ended June 29, 2014, respectively, and 720,000 and 589,000 during the three and nine months ended June 30, 2013, respectively.
  (was, 2014-04-23, similarity 0.8883):
[0001234452-14-000154:note_history:18]
Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 12,000 and 413,000 during the three and six months ended March 30, 2014, respectively, and 402,000 and 524,000 during the three and six months ended March 31, 2013, respectively.

- changed (2014-07-23):
[0001234452-14-000238:note_history:19]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | June 29, 2014 |  | June 30, 2013 |
| Cost of equipment and services revenues | $ | 12 |  |  | $ | 18 |  |  | $ | 37 |  |  | $ | 55 |  |
| Research and development | 174 |  |  | 166 |  |  | 510 |  |  | 479 |  |
| Selling, general and administrative | 88 |  |  | 96 |  |  | 259 |  |  | 297 |  |
| Share-based compensation expense before income taxes | 274 |  |  | 280 |  |  | 806 |  |  | 831 |  |
| Related income tax benefit | (42 | ) |  | (58 | ) |  | (151 | ) |  | (169 | ) |
|  | $ | 232 |  |  | $ | 222 |  |  | $ | 655 |  |  | $ | 662 |  |
  (was, 2014-04-23, similarity 0.8709):
[0001234452-14-000154:note_history:19]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2014 |  | March 31, 2013 |  | March 30, 2014 |  | March 31, 2013 |
| Cost of equipment and services revenues | $ | 13 |  |  | $ | 17 |  |  | $ | 25 |  |  | $ | 37 |  |
| Research and development | 163 |  |  | 156 |  |  | 336 |  |  | 313 |  |
| Selling, general and administrative | 75 |  |  | 95 |  |  | 171 |  |  | 201 |  |
| Share-based compensation expense before income taxes | 251 |  |  | 268 |  |  | 532 |  |  | 551 |  |
| Related income tax benefit | (53 | ) |  | (48 | ) |  | (109 | ) |  | (111 | ) |
|  | $ | 198 |  |  | $ | 220 |  |  | $ | 423 |  |  | $ | 440 |  |

- changed (2014-07-23):
[0001234452-14-000238:note_history:20]
The Company recorded $177 million and $152 million in share-based compensation expense during the nine months ended June 29, 2014 and June 30, 2013, respectively, related to share-based awards granted during those periods.
  (was, 2014-04-23, similarity 0.8289):
[0001234452-14-000154:note_history:20]
The Company recorded $82 million and $71 million in share-based compensation expense during the six months ended March 30, 2014 and March 31, 2013, respectively, related to share-based awards granted during those periods.

- changed (2014-07-23):
[0001234452-14-000238:note_history:21]
At June 29, 2014, total unrecognized compensation costs related to non-vested restricted stock units granted prior to that date were $1.5 billion, which are expected to be recognized over a weighted-average period of 2.0 years. During the nine months ended June 29, 2014 and June 30, 2013, net share-based awards granted, after forfeitures and cancelations, represented 0.8% and 0.7%, respectively, of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.9% and 0.8%, respectively, of outstanding shares as of the end of each fiscal period.
  (was, 2014-04-23, similarity 0.7255):
[0001234452-14-000154:note_history:21]
At March 30, 2014, total unrecognized compensation costs related to non-vested restricted stock units granted prior to that date were $1.3 billion, which are expected to be recognized over a weighted-average period of 1.8 years. During the six months ended March 30, 2014 and March 31, 2013, net share-based awards granted, after forfeitures and cancelations, represented 0.4% of outstanding shares as of the beginning of each fiscal period, and total share-based awards granted represented 0.5% and 0.4%, respectively, of outstanding shares as of the end of each fiscal period.

- added (2014-07-23):
[0001234452-14-000238:note_history:22]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers.” ASU 2014-09 outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. ASU 2014-09 will be effective for the Company starting in the first quarter of fiscal 2018. ASU 2014-09 allows for two methods of adoption: (a) “full retrospective” adoption, meaning the standard is applied to all periods presented, or (b) “modified retrospective” adoption, meaning the cumulative effect of applying ASU 2014-09 is recognized as an adjustment to the fiscal 2018 opening retained earnings balance. The Company is in the process of determining the adoption method as well as the effects the adoption of ASU 2014-09 will have on its consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-07-23):
[0001234452-14-000238:note_history:23]
|  | Current |  | Noncurrent |
|  | June 29, 2014 |  | September 29, 2013 |  | June 29, 2014 |  | September 29, 2013 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 317 |  |  | $ | 241 |  |  | $ | 47 |  |  | $ | 49 |  |
| Corporate bonds and notes | 195 |  |  | 269 |  |  | 380 |  |  | 256 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 215 |  |  | 104 |  |
| Total trading | 512 |  |  | 510 |  |  | 642 |  |  | 409 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 872 |  |  | 721 |  |  | 390 |  |  | 71 |  |
| Corporate bonds and notes | 6,553 |  |  | 4,533 |  |  | 7,687 |  |  | 6,812 |  |
| Mortgage- and asset-backed securities | 860 |  |  | 745 |  |  | 200 |  |  | 328 |  |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | 83 |  |
| Common and preferred stock | 342 |  |  | 8 |  |  | 1,664 |  |  | 2,351 |  |
| Equity funds | 160 |  |  | — |  |  | 521 |  |  | 960 |  |
| Debt funds | 910 |  |  | 2,307 |  |  | 2,589 |  |  | 2,889 |  |
| Total available-for-sale | 9,697 |  |  | 8,314 |  |  | 13,134 |  |  | 13,494 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 787 |  |  | 537 |  |
| Total marketable securities | $ | 10,209 |  |  | $ | 8,824 |  |  | $ | 14,563 |  |  | $ | 14,440 |  |
  (was, 2014-04-23, similarity 0.9909):
[0001234452-14-000154:note_history:23]
|  | Current |  | Noncurrent |
|  | March 30, 2014 |  | September 29, 2013 |  | March 30, 2014 |  | September 29, 2013 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 319 |  |  | $ | 241 |  |  | $ | 13 |  |  | $ | 49 |  |
| Corporate bonds and notes | 189 |  |  | 269 |  |  | 263 |  |  | 256 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 134 |  |  | 104 |  |
| Total trading | 508 |  |  | 510 |  |  | 410 |  |  | 409 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 945 |  |  | 721 |  |  | 431 |  |  | 71 |  |
| Corporate bonds and notes | 5,737 |  |  | 4,533 |  |  | 7,981 |  |  | 6,812 |  |
| Mortgage- and asset-backed securities | 896 |  |  | 745 |  |  | 421 |  |  | 328 |  |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | 83 |  |
| Common and preferred stock | 40 |  |  | 8 |  |  | 2,398 |  |  | 2,351 |  |
| Equity funds | — |  |  | — |  |  | 633 |  |  | 960 |  |
| Debt funds | 2,165 |  |  | 2,307 |  |  | 2,513 |  |  | 2,889 |  |
| Total available-for-sale | 9,783 |  |  | 8,314 |  |  | 14,460 |  |  | 13,494 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 555 |  |  | 537 |  |
| Total marketable securities | $ | 10,291 |  |  | $ | 8,824 |  |  | $ | 15,425 |  |  | $ | 14,440 |  |

- added (2014-07-23):
[0001234452-14-000238:note_history:24]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At June 29, 2014, the Company had an effective ownership interest in the debt fund of 27%. Changes in fair value associated with this investment are recognized in net investment income. During the three and nine months ended June 29, 2014, net increases in fair value associated with this investment were $12 million and $30 million, respectively. During the three months ended June 30, 2013, the net decrease in fair value associated with this investment was $4 million. During the nine months ended June 30, 2013, the net increase in fair value associated with this investment was $14 million.

- changed (2014-07-23):
[0001234452-14-000238:note_history:25]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains recognized on debt securities classified as trading held at June 29, 2014 were $7 million and $8 million for the three and nine months ended June 29, 2014, respectively. Net losses recognized on debt securities classified as trading held at June 30, 2013 were $21 million and $36 million for the three and nine months ended June 30, 2013, respectively.
  (was, 2014-04-23, similarity 0.6523):
[0001234452-14-000154:note_history:25]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net gains recognized on debt securities classified as trading held at March 30, 2014 were negligible for both the three and six months ended March 30, 2014. Net losses recognized on debt securities classified as trading held at March 31, 2013 were $15 million and $16 million for the three and six months ended March 31, 2013, respectively.

- changed (2014-07-23):
[0001234452-14-000238:note_history:26]
At June 29, 2014, the contractual maturities of available-for-sale debt securities were as follows (in millions):
  (was, 2014-04-23, similarity 0.9581):
[0001234452-14-000154:note_history:26]
At March 30, 2014, the contractual maturities of available-for-sale debt securities were as follows (in millions):

- changed (2014-07-23):
[0001234452-14-000238:note_history:27]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| June 29, 2014 | $ | 267 |  |  | $ | (8 | ) |  | $ | 259 |  |
| June 30, 2013 | 52 |  |  | (5 | ) |  | 47 |  |
| For the nine months ended |  |  |  |  |  |
| June 29, 2014 | $ | 610 |  |  | $ | (16 | ) |  | $ | 594 |  |
| June 30, 2013 | 204 |  |  | (14 | ) |  | 190 |  |
  (was, 2014-04-23, similarity 0.8516):
[0001234452-14-000154:note_history:27]
|  | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| For the three months ended |  |  |  |  |  |
| March 30, 2014 | $ | 227 |  |  | $ | (5 | ) |  | $ | 222 |  |
| March 31, 2013 | 69 |  |  | (4 | ) |  | 65 |  |
| For the six months ended |  |  |  |  |  |
| March 30, 2014 | $ | 343 |  |  | $ | (8 | ) |  | $ | 335 |  |
| March 31, 2013 | 153 |  |  | (9 | ) |  | 144 |  |

- changed (2014-07-23):
[0001234452-14-000238:note_history:28]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| June 29, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 2,000 |  |  | $ | 692 |  |  | $ | (5 | ) |  | $ | 2,687 |  |
| Debt securities (including debt funds) | 19,741 |  |  | 423 |  |  | (20 | ) |  | 20,144 |  |
|  | $ | 21,741 |  |  | $ | 1,115 |  |  | $ | (25 | ) |  | $ | 22,831 |  |
| September 29, 2013 |  |  |  |  |  |  |  |
| Equity securities | $ | 2,570 |  |  | $ | 793 |  |  | $ | (44 | ) |  | $ | 3,319 |  |
| Debt securities (including debt funds) | 18,255 |  |  | 396 |  |  | (162 | ) |  | 18,489 |  |
|  | $ | 20,825 |  |  | $ | 1,189 |  |  | $ | (206 | ) |  | $ | 21,808 |  |
  (was, 2014-04-23, similarity 0.9915):
[0001234452-14-000154:note_history:28]
|  | Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| March 30, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 2,340 |  |  | $ | 743 |  |  | $ | (12 | ) |  | $ | 3,071 |  |
| Debt securities (including debt funds) | 20,849 |  |  | 386 |  |  | (63 | ) |  | 21,172 |  |
|  | $ | 23,189 |  |  | $ | 1,129 |  |  | $ | (75 | ) |  | $ | 24,243 |  |
| September 29, 2013 |  |  |  |  |  |  |  |
| Equity securities | $ | 2,570 |  |  | $ | 793 |  |  | $ | (44 | ) |  | $ | 3,319 |  |
| Debt securities (including debt funds) | 18,255 |  |  | 396 |  |  | (162 | ) |  | 18,489 |  |
|  | $ | 20,825 |  |  | $ | 1,189 |  |  | $ | (206 | ) |  | $ | 21,808 |  |

- added (2014-07-23):
[0001234452-14-000238:note_history:29]
|  | June 29, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| Corporate bonds and notes | $ | 2,033 |  |  | $ | (5 | ) |  | $ | 96 |  |  | $ | (2 | ) |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Debt funds | 50 |  |  | (1 | ) |  | 394 |  |  | (11 | ) |
| Equity funds | 30 |  |  | — |  |  | 115 |  |  | (5 | ) |
|  | $ | 2,113 |  |  | $ | (6 | ) |  | $ | 688 |  |  | $ | (19 | ) |

- changed (2014-07-23):
[0001234452-14-000238:note_history:30]
At June 29, 2014, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common and preferred stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.
  (was, 2014-04-23, similarity 0.992):
[0001234452-14-000154:note_history:30]
At March 30, 2014, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common and preferred stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover, which is expected to be within a reasonable period of time. For debt securities with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

- added (2014-07-23):
[0001234452-14-000238:note_history:31]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 29, 2014 |  | June 30, 2013 |  | June 29, 2014 |  | June 30, 2013 |
| Beginning balance of credit losses | $ | 8 |  |  | $ | 8 |  |  | $ | 4 |  |  | $ | 31 |  |
| Reduction in credit losses related to securities the Company intends to sell | — |  |  | — |  |  | — |  |  | (6 | ) |
| Credit losses recognized on securities not previously impaired | — |  |  | — |  |  | 5 |  |  | 1 |  |
| Additional credit losses recognized on securities previously impaired | — |  |  | — |  |  | — |  |  | 1 |  |
| Reductions in credit losses related to securities sold | (3 | ) |  | (3 | ) |  | (4 | ) |  | (21 | ) |
| Accretion of credit losses due to an increase in cash flows expected to be collected | — |  |  | — |  |  | — |  |  | (1 | ) |
| Ending balance of credit losses | $ | 5 |  |  | $ | 5 |  |  | $ | 5 |  |  | $ | 5 |  |

- removed (2014-07-23):
[0001234452-14-000154:note_history:32]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At March 30, 2014, the Company had an effective ownership interest in the debt fund of 20%. Net increases in fair value associated with this investment recognized in net investment income were $12 million and $18 million during the three and six months ended March 30, 2014, respectively, and $8 million and $18 million during the three and six months ended March 31, 2013, respectively.

- removed (2014-07-23):
[0001234452-14-000154:note_history:33]
|  | March 30, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. Treasury securities and government-related securities | $ | 236 |  |  | $ | (3 | ) |  | $ | 5 |  |  | $ | — |  |
| Corporate bonds and notes | 3,724 |  |  | (21 | ) |  | 26 |  |  | (1 | ) |
| Mortgage- and asset-backed securities | 313 |  |  | (2 | ) |  | 41 |  |  | (1 | ) |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Debt funds | 672 |  |  | (34 | ) |  | 88 |  |  | — |  |
| Equity funds | 202 |  |  | (12 | ) |  | 5 |  |  | — |  |
|  | $ | 5,147 |  |  | $ | (72 | ) |  | $ | 248 |  |  | $ | (3 | ) |

- removed (2014-07-23):
[0001234452-14-000154:note_history:34]
|  | Three Months Ended |  | Six Months Ended |
|  | March 30, 2014 |  | March 31, 2013 |  | March 30, 2014 |  | March 31, 2013 |
| Beginning balance of credit losses | $ | 6 |  |  | $ | 19 |  |  | $ | 4 |  |  | $ | 31 |  |
| Reduction in credit losses related to securities the Company intends to sell | — |  |  | (6 | ) |  | — |  |  | (6 | ) |
| Credit losses recognized on securities not previously impaired | 2 |  |  | — |  |  | 5 |  |  | — |  |
| Reductions in credit losses related to securities sold | — |  |  | (5 | ) |  | (1 | ) |  | (17 | ) |
| Ending balance of credit losses | $ | 8 |  |  | $ | 8 |  |  | $ | 8 |  |  | $ | 8 |  |
