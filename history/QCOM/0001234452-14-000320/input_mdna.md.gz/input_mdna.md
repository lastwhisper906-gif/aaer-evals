# QCOM MD&A — 0001234452-14-000320


## mdna

[0001234452-14-000320:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001234452-14-000320:mdna:2]
Overview

[0001234452-14-000320:mdna:3]
Fiscal 2014 Overview

[0001234452-14-000320:mdna:4]
The transition of wireless networks and devices to 3G/4G (CDMA-based, OFDMA-based and CDMA/OFDMA multimode) continued around the world. 3G/4G connections increased to approximately 2.8 billion, up 24% year-over-year, and represent approximately 40% of total cellular connections, up from 34% at the end of fiscal 2013.(1)

[0001234452-14-000320:mdna:5]
Revenues were $26.5 billion, an increase of 7% compared to fiscal 2013, with net income attributable to Qualcomm of $8.0 billion, an increase of 16% compared to fiscal 2013.

[0001234452-14-000320:mdna:6]
We shipped approximately 861 million Mobile Station Modem (MSM) integrated circuits for CDMA- and OFDMA-based wireless devices, an increase of 20%, compared to approximately 716 million MSM integrated circuits in fiscal 2013, largely driven by the adoption of 4G LTE, particularly in China. Growth in fiscal 2014 was largely driven by shipments to key customers for both 3G and 3G/4G multimode mobile devices in emerging regions. In particular, our LTE leadership position contributed to growth from regions adopting 3G/4G LTE multimode.

[0001234452-14-000320:mdna:7]
Total reported device sales(2) by licensees were approximately $243.6 billion in fiscal 2014, an increase of approximately 5%, compared to approximately $231.2 billion in fiscal 2013. Our fiscal 2014 results were favorably impacted by increased 3G/4G device shipments by licensees as a result of the continued adoption of smartphones. Our results were negatively impacted by the challenges we are facing in China. Our business practices continue to be the subject of an investigation by the China National Development and Reform Commission (NDRC). We also believe that certain licensees in China currently are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes certain licensees underreporting a portion of their 3G/4G device sales and a dispute with a licensee) and that unlicensed companies may seek to delay execution of new licenses while the NDRC investigation is ongoing. We are taking steps to address these matters, although the nature and timing of any resolution is uncertain.

[0001234452-14-000320:mdna:8]
During the first quarter of fiscal 2014, we announced our intention of returning 75% of our free cash flow (3) to stockholders through stock repurchases and dividends over the foreseeable future, where free cash flow is defined as net cash provided by operating activities less capital expenditures. In fiscal 2014, we returned $7.1 billion, or 93% of free cash flow, to stockholders, including $4.5 billion through repurchases of 60.3 million shares of common stock and $2.6 billion, or $1.54 per share, of cash dividends. Shares outstanding decreased to 1.67 billion at September 28, 2014 from 1.69 billion at September 29, 2013 due to share repurchases, partially offset by net shares issued under our employee benefit plans.

[0001234452-14-000320:mdna:9]
| (1) | According to GSMA Intelligence estimates as of November 3, 2014 for the quarter ended September 30, 2014 (estimates excluded Wireless Local Loop). |

[0001234452-14-000320:mdna:10]
| (2) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). Not all licensees report sales the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-14-000320:mdna:11]
| (3) | Free cash flow is a non-GAAP financial measure. See “Non-GAAP Financial Information.” |

[0001234452-14-000320:mdna:12]
Our Business and Operating Segments

[0001234452-14-000320:mdna:13]
We design, manufacture, have manufactured on our behalf and market digital communications products and services based on CDMA, OFDMA and other technologies. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents, software and other rights.

[0001234452-14-000320:mdna:14]
We have three reportable segments. We conduct business primarily through two reportable segments, QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing), and our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Following our corporate reorganization at the beginning of fiscal 2013, substantially all of our products

[0001234452-14-000320:mdna:15]
and services businesses, including QCT, and substantially all of our engineering, research and development functions, are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL continues to be operated by QUALCOMM Incorporated, which continues to own the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0001234452-14-000320:mdna:16]
QCT is a leading developer and supplier of integrated circuits and system software based on CDMA, OFDMA and other technologies for use in voice and data communications, networking, application processing, multimedia and global positioning system products. QCT’s integrated circuit products and system software are sold to or licensed to manufacturers that use our products in wireless devices, particularly mobile phones, tablets, laptops, data modules, handheld wireless computers and gaming devices, access points and routers, data cards and infrastructure equipment, and in wired devices, particularly broadband gateway equipment, desktop computers and streaming media players. Our MSM integrated circuits, which include the Mobile Data Modem, Qualcomm Single Chip and Qualcomm Snapdragon processors, perform the core baseband modem functionality in wireless devices providing voice and data communications, as well as multimedia applications and global positioning functions. In addition, our Snapdragon processors provide advanced application and graphics processing capabilities. QCT’s system software enables the other device components to interface with the integrated circuit products and is the foundation software enabling manufacturers to develop devices utilizing the functionality within the integrated circuits. QCT revenues comprised 70%, 67% and 63% of total consolidated revenues in fiscal 2014, 2013 and 2012, respectively.

[0001234452-14-000320:mdna:17]
QCT utilizes a fabless production business model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Integrated circuits are die cut from silicon wafers that have completed the package assembly and test manufacturing processes. We rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits based primarily on our proprietary designs and test programs. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Turnkey is when our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die or wafers from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services, such as wafer bump, probe, assembly and final test.

[0001234452-14-000320:mdna:18]
QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD (including TD-SCDMA), GSM/GPRS/EDGE and/or OFDMA standards and their derivatives. QTL licensing revenues are comprised of license fees as well as royalties based on sales by licensees of products incorporating or using our intellectual property. License fees are fixed amounts paid in one or more installments. Royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). QTL recognizes royalty revenues based on royalties reported by licensees during the quarter and when other revenue recognition criteria are met. Licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. QTL revenues comprised 29%, 30% and 33% of total consolidated revenues in fiscal 2014, 2013 and 2012, respectively. The vast majority of such revenues were generated through our licensees’ sales of CDMA2000- and WCDMA-based products, such as feature phones and smartphones.

[0001234452-14-000320:mdna:19]
QSI makes strategic investments that are focused on opening new or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications. Many of these strategic investments are in early-stage companies in a variety of industries, including, but not limited to, digital media, e-commerce, energy, healthcare and wearable devices. Investments primarily include non-marketable equity instruments, which generally are recorded using the cost method or the equity method, and convertible debt instruments, which are recorded at fair value. QSI also holds wireless spectrum, which at September 28, 2014, consisted of L-Band spectrum in the United Kingdom. As part of our strategic investment activities, we intend to pursue various exit strategies for each of our QSI investments in the foreseeable future. During fiscal 2013, we deconsolidated subsidiaries reported in QSI that were established to operate a wireless network in India (the former BWA subsidiaries), and all of our remaining interest was sold in fiscal 2014.

[0001234452-14-000320:mdna:20]
During the first quarter of fiscal 2014, we reassessed our management reporting as a result of the sale of the North and Latin America operations of our Omnitracs division, among other reasons. The Omnitracs division was previously aggregated with three other divisions into the Qualcomm Wireless & Internet (QWI) reportable segment. Starting in fiscal 2014, the QWI segment was eliminated, and the former QWI divisions are included in nonreportable segments.

[0001234452-14-000320:mdna:21]
Nonreportable segments include our QMT (Qualcomm MEMS Technologies), Pixtronix and Small Cells divisions and other wireless technology and service initiatives. QMT plans to license its next generation IMOD (interferometric modulator) display technology and to focus on wearable devices. Pixtronix develops and licenses display technologies based on MEMS (micro-electro-mechanical-systems) structure optimized for portable multimedia devices. Small Cells develops and supplies

[0001234452-14-000320:mdna:22]
3G/LTE and Wi-Fi products designed for implementation of small mobile base stations (known as small cells). Other nonreportable segments develop and offer products and services that include, but are not limited to: software products and content and push-to-talk enablement services to wireless operators; development, other services and related products to U.S. government agencies and their contractors; device-to-device communication, including software for the connected home; data center products; medical device connectivity and related data management;  and augmented reality.

[0001234452-14-000320:mdna:23]
During fiscal 2014, we updated QMT’s business plans and related internal forecasts to reflect decreases in expected cash flows. As a result of these updates, we tested the QMT division’s long-lived assets and goodwill for impairment and recorded total charges of $607 million in other expenses in fiscal 2014.

[0001234452-14-000320:mdna:24]
Discontinued Operations

[0001234452-14-000320:mdna:25]
On November 25, 2013, we completed the sale of the North and Latin America operations of our Omnitracs division to a U.S.-based private equity firm for cash consideration of $788 million (net of cash sold). As a result, we recorded a gain in discontinued operations of $665 million ($430 million net of income tax expense) during fiscal 2014. Total assets and total liabilities were reduced by $150 million and $45 million, respectively. The revenues and operating results of the North and Latin America operations of the Omnitracs division, which comprised substantially all of the Omnitracs division, were not presented as discontinued operations in any fiscal period because they were immaterial. The related assets (included in other current assets and other noncurrent assets) and liabilities (included in other current liabilities and other noncurrent liabilities) of $139 million and $43 million, respectively, were classified as held for sale at September 29, 2013.

[0001234452-14-000320:mdna:26]
On March 27, 2011, the FLO TV business and network were shut down. On December 27, 2011, we completed the sale of substantially all of our 700 MHz spectrum for $1.9 billion, and as a result, we recognized a gain in discontinued operations of $1.2 billion during fiscal 2012. Accordingly, the results of operations of the FLO TV business were presented as discontinued operations. Income (loss) from discontinued operations included share-based compensation and excluded certain general corporate expenses allocated to the FLO TV business during the periods presented. Discontinued operations in fiscal 2012 were $1.2 billion ($776 million net of income tax expense).

[0001234452-14-000320:mdna:27]
Looking Forward

[0001234452-14-000320:mdna:28]
We expect continued growth in the coming years in consumer demand for 3G, 3G/4G multimode and 4G products and services around the world, driven primarily by smartphones. We also expect growth in new device categories and industries, driven by the expanding adoption of certain technologies that are already commonly used in smartphones. As we look forward to the next several months, we expect our business to be impacted by the following key items:

[0001234452-14-000320:mdna:29]
| • | Further expansion of 3G and 3G/4G multimode in emerging regions, particularly in China. We expect that the increased availability of low-tier 3G/4G smartphone products will help enable such expansion. |

[0001234452-14-000320:mdna:30]
| • | We expect that 3G/4G device prices will continue to vary broadly due to the increased penetration of smartphones combined with competition throughout the world at all price tiers. Additionally, varying rates of economic growth by region, and stronger growth of device shipments in emerging regions as compared to developed regions, are expected to continue to impact the average and range of selling prices of 3G/4G devices. |

[0001234452-14-000320:mdna:31]
| • | China continues to present significant opportunities for us, particularly with the rollout of 3G/4G LTE multimode. We expect the rollout of 4G services in China will encourage competition and growth, bring the benefits of 3G/4G LTE multimode to consumers, encourage consumers to replace 2G (GSM) and 3G devices and enable new opportunities (e.g., machine-to-machine) for the industry. |

[0001234452-14-000320:mdna:32]
| • | China also presents significant challenges, as our business practices continue to be the subject of an investigation by the China National Development and Reform Commission (NDRC). We also believe that certain licensees in China currently are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes certain licensees underreporting a portion of their 3G/4G device sales and a dispute with a licensee) and that unlicensed companies may seek to delay execution of new licenses while the NDRC investigation is ongoing. Litigation and/or other actions may be necessary to compel these licensees to report such sales and pay the required royalties for such sales and unlicensed companies to execute new licenses. Further, our success in China is in part dependent upon the rate of commercialization of 4G LTE products in China. |

[0001234452-14-000320:mdna:33]
| • | We continue to invest significant resources toward advancements in 3G, 3G/4G multimode and 4G LTE (an OFDMA-based standard) technologies, audio and video codecs, wireless baseband chips, our converged computing/communications (Snapdragon) chips, graphics, connectivity, multimedia products, software and services. We are also investing across a broad spectrum of opportunities that leverage our existing technical and business expertise to deploy new business models and enter into new industry segments, such as products designed for implementation of small cells and addressing the challenge of meeting the increased demand for data; products for the connected home and the |

[0001234452-14-000320:mdna:34]
Internet of Everything; automotive; very high speed connectivity; new display technologies; data centers; mobile health; wireless charging; and machine learning, including robotics.

[0001234452-14-000320:mdna:35]
| • | In October 2014, we announced that we had reached agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.5 billion based upon an exchange rate of USD: GBP 1.6057). CSR is an innovator in the development of multifunction semiconductor platforms and technologies for the auto, consumer and voice and music market segments. The acquisition complements our current offerings by adding products, channels and customers in the growth categories of the Internet of Everything and automotive infotainment, accelerating our presence and path to leadership. The acquisition is subject to a number of conditions, including receipt of United States and other regulatory approvals and the approval of CSR’s shareholders. Subject to the satisfaction of these conditions, the acquisition is expected to close by the end of the summer of 2015. |

[0001234452-14-000320:mdna:36]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants and governments in the wireless value chain as to the benefits of our business model and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not welcome the success of our business model in enabling new, highly cost-effective competitors to their products. We expect that such companies and/or governments or regulators will continue to challenge our business model in various forums throughout the world.

[0001234452-14-000320:mdna:37]
Further discussion of risks related to our business is presented in the Risk Factors included in this Annual Report.

[0001234452-14-000320:mdna:38]
Critical Accounting Estimates

[0001234452-14-000320:mdna:39]
Our discussion and analysis of our results of operations and liquidity and capital resources are based on our consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and disclosure of contingent assets and liabilities. On an ongoing basis, we evaluate our estimates and judgments, including those related to valuation of goodwill, other indefinite-lived assets and long-lived assets, valuation of marketable securities, income taxes and litigation. We base our estimates on historical and anticipated results and trends and on various other assumptions that we believe are reasonable under the circumstances, including assumptions as to future events. These estimates form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. By their nature, estimates are subject to an inherent degree of uncertainty. Although we believe that our estimates and the assumptions supporting our assessments are reasonable, actual results that differ from our estimates could have a significant adverse effect on our operating results and financial position. We believe that the following significant accounting estimates may involve a higher degree of judgment and complexity than others.

[0001234452-14-000320:mdna:40]
Valuation of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. Our business acquisitions typically result in the recording of goodwill, other intangible assets and property, plant and equipment and the recorded values of those assets may become impaired in the future. We also acquire intangible assets in other types of transactions. At September 28, 2014, our goodwill, other intangible assets, net of accumulated amortization, and property, plant and equipment, net of depreciation, were $4.5 billion, $2.6 billion and $2.5 billion, respectively. The determination of the value of intangible assets acquired in a business combination requires management to make estimates and assumptions that affect our consolidated financial statements. The estimated fair values of such intangible assets are used to establish their recorded values. For intangible assets acquired in a non-monetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value. An estimate of fair value can be affected by many assumptions that require significant judgment. For example, the income approach generally requires assumptions related to the appropriate business model to be used to estimate cash flows, total addressable market, pricing and share forecasts, competition, technology obsolescence, future tax rates and discount rates. Our estimate of the fair value of certain assets may differ materially from that determined by others who use different assumptions or utilize different business models. New information may arise in the future that affects our fair value estimates and could result in adjustments to our estimates in the future, which could have an adverse impact on our results of operations.

[0001234452-14-000320:mdna:41]
Goodwill and other indefinite-lived intangible assets are tested annually for impairment and in interim periods if certain events occur indicating that the carrying amounts may be impaired. Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in

[0001234452-14-000320:mdna:42]
circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Our judgments regarding the existence of impairment indicators and future cash flows related to goodwill, other indefinite-lived intangible assets and long-lived assets may be based on operational performance of our businesses, market conditions, expected selling price and/or other factors. Although there are inherent uncertainties in this assessment process, the estimates and assumptions we use, including estimates of future cash flows, volumes, market penetration and discount rates, are consistent with our internal planning, when appropriate. If these estimates or their related assumptions change in the future, we may be required to record an impairment charge on a portion or all of our goodwill, other indefinite-lived intangible assets and long-lived assets. Furthermore, we cannot predict the occurrence of future impairment-triggering events nor the impact such events might have on our reported asset values. Future events could cause us to conclude that impairment indicators exist and that goodwill or other intangible assets associated with our acquired businesses are impaired. Any resulting impairment loss could have an adverse impact on our financial position and results of operations. During fiscal 2014, 2013 and 2012, we recorded $607 million, $158 million and $54 million, respectively, in impairment charges for goodwill and long-lived assets resulting from updates to our estimates of the expected cash flows of our QMT division as we transition to a licensing model. Goodwill of nonreportable segments that was at risk of failing step one of the goodwill impairment test was not material at September 28, 2014.

[0001234452-14-000320:mdna:43]
Valuation of Marketable Securities. We hold investments in marketable securities, including U.S. Treasury and government-related securities, corporate bonds and notes, mortgage- and asset-backed securities, auction rate securities, common and preferred stock and equity and debt funds. The fair value of these investments totaled $24.1 billion at September 28, 2014, with increases and decreases in fair value generally recorded through stockholders’ equity as other comprehensive income or loss. We record impairment charges through the statement of operations when we believe an investment has experienced a decline that is other than temporary. The determination that a decline is other than temporary is subjective and influenced by many factors. Adverse changes in market conditions or poor operating results of investees could result in losses or an inability to recover the carrying value of the investments, thereby requiring impairment charges. When assessing these investments for an other-than-temporary decline in value, we consider such factors as, among other things, the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; how long the market value of the security has been less than its cost basis; the security’s relative performance versus its peers, sector or asset class; expected market volatility; the market and economy in general; analyst recommendations and price targets; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates, as applicable. If we determine that a security price decline is other than temporary, we record an impairment loss, which could have an adverse impact on our results of operations. During fiscal 2014, 2013 and 2012, we recorded $156 million, $72 million and $71 million, respectively, in impairment losses on our investments in marketable securities.

[0001234452-14-000320:mdna:44]
Income Taxes. Our income tax returns are based on calculations and assumptions that are subject to examination by the Internal Revenue Service (IRS) and other tax authorities. In addition, the calculation of our tax liabilities involves uncertainties in the application of complex tax regulations. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. While we believe we have appropriate support for the positions taken on our tax returns, we regularly assess the potential outcomes of examinations by taxing authorities in determining the adequacy of our provision for income taxes. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts that give rise to a revision become known. We are participating in the IRS Compliance Assurance Process program whereby we endeavor to agree with the IRS on the treatment of all issues prior to filing our federal return. A benefit of participation in this program is that post-filing adjustments by the IRS are less likely to occur.

[0001234452-14-000320:mdna:45]
Our QCT segment’s non-United States headquarters is located in Singapore. We obtained tax incentives in Singapore that commenced in March 2012, including a tax exemption for the first five years, provided that we meet specified employment and incentive criteria, and as a result of expiration of these incentives, our Singapore tax rate will increase in fiscal 2017 and again in fiscal 2027.

[0001234452-14-000320:mdna:46]
We consider the operating earnings of certain non-United States subsidiaries to be indefinitely reinvested outside the United States based on our plans for use and/or investment outside of the United States and our belief that our sources of cash and liquidity in the United States will be sufficient to meet future domestic cash needs. On a regular basis, we consider projected cash needs for, among other things, investments in our existing businesses, future research and development, potential acquisitions and capital transactions, including repurchases of our common stock and debt repayments. We estimate the amount of cash or other liquidity that is available or needed in the jurisdictions where these investments are expected, as well as our ability to generate cash in those jurisdictions and our access to capital markets. This analysis enables us to conclude whether or not we will indefinitely reinvest the current period’s foreign earnings. We have not recorded a deferred tax liability of approximately $9.1 billion related to the United States federal and state income taxes and foreign withholding taxes on

[0001234452-14-000320:mdna:47]
35

[0001234452-14-000320:mdna:48]
approximately $25.7 billion of undistributed earnings of certain non-United States subsidiaries indefinitely reinvested outside the United States. Should we decide to no longer indefinitely reinvest such earnings outside the United States, we would have to adjust the income tax provision in the period we make such determination.

[0001234452-14-000320:mdna:49]
Legal Proceedings. We are currently involved in certain legal proceedings, and we intend to continue to vigorously defend ourselves. However, the unfavorable resolution of one or more of these proceedings could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. A broad range of remedies with respect to our business practices that are deemed to violate applicable laws are potentially available. These remedies may include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or to modify our business practices. We record our best estimate of a loss related to pending legal proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, we record the minimum estimated liability. As additional information becomes available, we assess the potential liability related to pending legal proceedings and revise our estimates. Revisions in our estimates of the potential liability could materially impact our results of operations. Regarding the NDRC matter, we believe that a loss is probable but that any possible range of loss cannot be reasonably estimated at this time.

[0001234452-14-000320:mdna:50]
Results of Operations

[0001234452-14-000320:mdna:51]
| Revenues (in millions) | Year Ended |  |  |  |  |
|  | September 28, 2014 |  | September 29, 2013 |  | September 30, 2012 |  | 2014 vs. 2013 Change |  | 2013 vs. 2012 Change |
| Equipment and services | $ | 18,625 |  |  | $ | 16,988 |  |  | $ | 12,465 |  |  | $ | 1,637 |  |  | $ | 4,523 |  |
| Licensing | 7,862 |  |  | 7,878 |  |  | 6,656 |  |  | (16 | ) |  | 1,222 |  |
|  | $ | 26,487 |  |  | $ | 24,866 |  |  | $ | 19,121 |  |  | $ | 1,621 |  |  | $ | 5,745 |  |

[0001234452-14-000320:mdna:52]
The increases in equipment and services revenues in fiscal 2014 and 2013 were primarily due to increases in QCT revenues of $1.94 billion and $4.58 billion, respectively. The increase in equipment and services revenues in fiscal 2014 was partially offset by a decrease of $305 million as a result of the sale of our Omnitracs division during fiscal 2014. The decrease in our licensing revenues in fiscal 2014 was primarily due to a decrease in a nonreportable segment’s revenues of $32 million, partially offset by an increase in QTL revenues of $15 million. The increase in our licensing revenues in fiscal 2013 was primarily due to an increase in QTL revenues of $1.23 billion.

[0001234452-14-000320:mdna:53]
QCT and QTL segment revenues related to the products of Samsung Electronics and Hon Hai Precision Industry Co., Ltd/Foxconn, its affiliates and other suppliers to Apple Inc. comprised 49%, 43% and 38% of total consolidated revenues in fiscal 2014, 2013 and 2012, respectively.

[0001234452-14-000320:mdna:54]
Revenues from customers in China, South Korea and Taiwan comprised 50%, 23% and 11%, respectively, of total consolidated revenues for fiscal 2014, compared to 49%, 20%, and 11%, respectively, for fiscal 2013, and 42%, 22% and 14%, respectively, for fiscal 2012. We report revenues from external customers by country based on the location to which our products or services are delivered, which for QCT is generally the country in which our customers manufacture their products, or for licensing revenues, the invoiced addresses of our licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues would include revenues related to shipments of integrated circuits to a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States.

[0001234452-14-000320:mdna:55]
| Costs and Expenses (in millions) | Year Ended |  |  |  |  |
|  | September 28, 2014 |  | September 29, 2013 |  | September 30, 2012 |  | 2014 vs. 2013 Change |  | 2013 vs. 2012 Change |
| Cost of equipment and services (E&S) revenues | $ | 10,686 |  |  | $ | 9,820 |  |  | $ | 7,096 |  |  | $ | 866 |  |  | $ | 2,724 |  |
| Cost as % of E&S revenues | 57 | % |  | 58 | % |  | 57 | % |  |  |  |  |

[0001234452-14-000320:mdna:56]
36

[0001234452-14-000320:mdna:57]
The increase in margin percentage in fiscal 2014 was primarily attributable to a net decrease in gross margin losses incurred by our nonreportable segments, partially offset by a decrease in QCT’s gross margin. The decrease in margin percentage in fiscal 2013 was primarily attributable to a decrease in QCT gross margin percentage. Our margin percentage may continue to fluctuate in future periods depending on the mix of products sold and services provided, competitive pricing, new product introduction costs and other factors.

[0001234452-14-000320:mdna:58]
|  | Year Ended |  |  |  |  |
|  | September 28, 2014 |  | September 29, 2013 |  | September 30, 2012 |  | 2014 vs. 2013 Change |  | 2013 vs. 2012 Change |
| Research and development | $ | 5,477 |  |  | $ | 4,967 |  |  | $ | 3,915 |  |  | $ | 510 |  |  | $ | 1,052 |  |
| % of revenues | 21 | % |  | 20 | % |  | 20 | % |  |  |  |  |
| Selling, general, and administrative | $ | 2,290 |  |  | $ | 2,518 |  |  | $ | 2,270 |  |  | $ | (228 | ) |  | $ | 248 |  |
| % of revenues | 9 | % |  | 10 | % |  | 12 | % |  |  |  |  |
| Other | $ | 484 |  |  | $ | 331 |  |  | $ | 158 |  |  | $ | 153 |  |  | $ | 173 |  |

[0001234452-14-000320:mdna:59]
The dollar increases in research and development expenses in fiscal 2014 and 2013 were primarily attributable to increases of $395 million and $904 million, respectively, in costs related to the development of CDMA-based 3G, OFDMA-based 4G LTE and other technologies for integrated circuit products and to expand our intellectual property portfolio and increases of $29 million and $97 million, respectively, in share-based compensation. Remaining dollar increases were related to research and development of other new product and licensing initiatives.

[0001234452-14-000320:mdna:60]
The dollar decrease in selling, general and administrative expenses in fiscal 2014 was primarily attributable to decreases of $59 million in costs related to litigation and other legal matters, $53 million in share-based compensation, $53 million in selling and marketing expenses and $22 million in employee-related expenses. The decrease in employee-related expenses and a portion of the decrease in share-based compensation in fiscal 2014 were due to the sale of our Omnitracs division during fiscal 2014. The dollar increase in selling, general and administrative expenses in fiscal 2013 was primarily attributable to a $113 million increase in employee-related expenses, a $56 million increase in selling and marketing expenses, a $40 million increase in patent-related expenses and a $29 million increase in depreciation and amortization expense, partially offset by a decrease of $23 million in share-based compensation.

[0001234452-14-000320:mdna:61]
Other expenses in fiscal 2014 were comprised of $607 million in long-lived asset and goodwill impairment charges and $19 million in restructuring-related costs incurred by our QMT division, a $16 million goodwill impairment charge related to our former QRS (Qualcomm Retail Solutions) division and a $15 million legal settlement, partially offset by the reversal of a $173 million expense accrual recorded in fiscal 2013 related to the ParkerVision verdict against us. Other expenses in fiscal 2013 were comprised of the $173 million ParkerVision charge and a $158 million impairment charge related to certain long-lived assets of our QMT division. Other expenses in fiscal 2012 were comprised of an $81 million charge related to the former BWA subsidiaries, a $54 million impairment charge related to certain long-lived assets of our QMT division and $23 million in goodwill impairment charges related to our former QRS division.

[0001234452-14-000320:mdna:62]
| Net Investment Income (in millions) | Year Ended |  |  |  |  |
|  | September 28, 2014 |  | September 29, 2013 |  | September 30, 2012 |  | 2014 vs. 2013 Change |  | 2013 vs. 2012 Change |
| Interest and dividend income | $ | 586 |  |  | $ | 697 |  |  | $ | 609 |  |  | $ | (111 | ) |  | $ | 88 |  |
| Interest expense | (5 | ) |  | (23 | ) |  | (90 | ) |  | 18 |  |  | 67 |  |
| Net realized gains on marketable securities | 770 |  |  | 317 |  |  | 342 |  |  | 453 |  |  | (25 | ) |
| Net realized gains on other investments | 56 |  |  | 52 |  |  | 27 |  |  | 4 |  |  | 25 |  |
| Impairment losses on marketable securities and other investments | (180 | ) |  | (85 | ) |  | (83 | ) |  | (95 | ) |  | (2 | ) |
| Net gains on derivative instruments | 5 |  |  | — |  |  | 84 |  |  | 5 |  |  | (84 | ) |
| Equity in net losses of investees | (10 | ) |  | (6 | ) |  | (9 | ) |  | (4 | ) |  | 3 |  |
| Net gains on deconsolidation of subsidiaries | 6 |  |  | 12 |  |  | — |  |  | (6 | ) |  | 12 |  |
|  | $ | 1,228 |  |  | $ | 964 |  |  | $ | 880 |  |  | $ | 264 |  |  | $ | 84 |  |

[0001234452-14-000320:mdna:63]
In fiscal 2014, we rebalanced our marketable securities portfolio, which resulted in lower interest and dividend income, due to lower interest rates, and higher net realized gains on marketable securities, compared to fiscal 2013. The increase in impairment losses on marketable securities and other investments in fiscal 2014 was primarily due to an increase in our recognition of unrealized losses on marketable debt securities that we intended to sell or that we more likely than not would sell

[0001234452-14-000320:mdna:64]
37

[0001234452-14-000320:mdna:65]
before recovery, which was also impacted by our portfolio rebalancing. We have completed the majority of our rebalancing, and as a result, we expect to earn lower interest and dividend income and record lower realized gains in fiscal 2015, compared to fiscal 2014.

[0001234452-14-000320:mdna:66]
The increase in interest and dividend income in fiscal 2013 resulted from higher average balances of cash, cash equivalents and marketable securities in fiscal 2013, compared to fiscal 2012. The decrease in interest expense in fiscal 2013 resulted from capitalizing a portion of interest starting in fiscal 2012 related to the former BWA subsidiaries, which were deconsolidated in fiscal 2013. Net gains on derivative instruments in fiscal 2012 primarily resulted from changes in the fair value of put options sold in connection with our stock repurchase program that expired in fiscal 2012.

[0001234452-14-000320:mdna:67]
| Income Tax Expense (in millions) | Year Ended |  |  |  |  |
|  | September 28, 2014 |  | September 29, 2013 |  | September 30, 2012 |  | 2014 vs. 2013 Change |  | 2013 vs. 2012 Change |
| Income tax expense | $ | 1,244 |  |  | $ | 1,349 |  |  | $ | 1,279 |  |  | $ | (105 | ) |  | $ | 70 |  |
| Effective tax rate | 14 | % |  | 16 | % |  | 19 | % |  | (2 | )% |  | (3 | %) |

[0001234452-14-000320:mdna:68]
The following table summarizes the primary factors that caused our annual effective tax rates to be less than the United States federal statutory rate:

[0001234452-14-000320:mdna:69]
|  | Year Ended |
|  | September 28, 2014 |  | September 29, 2013 |  | September 30, 2012 |
| Expected income tax provision at federal statutory tax rate | 35 | % |  | 35 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (20 | %) |  | (17 | %) |  | (16 | %) |
| Benefits related to the research and development tax credits | (1 | %) |  | (2 | %) |  | (1 | %) |
| Change in valuation allowance | — | % |  | — | % |  | 1 | % |
| Effective tax rate | 14 | % |  | 16 | % |  | 19 | % |

[0001234452-14-000320:mdna:70]
The effective tax rate for our state income tax provision, net of federal benefit, was negligible for all years presented. The effective tax rate for fiscal 2014 reflected a tax benefit of $66 million related to fiscal 2013 resulting from an agreement reached with the Internal Revenue Service on components of our fiscal 2013 tax return. Additionally, the effective tax rate for fiscal 2014 as compared to fiscal 2013 reflected increased foreign earnings taxed at less than the United States federal rate. The effective tax rate for fiscal 2013 reflected a tax benefit of $64 million related to fiscal 2012 resulting from the retroactive extension of the United States research and development tax credit. Additionally, the effective tax rate for fiscal 2013 as compared to fiscal 2012 reflected increased foreign earnings taxed at less than the United States federal rate. The effective tax rate for fiscal 2012 reflected a reduction in our effective state tax rate as a result of California tax legislation previously enacted, partially offset by increased earnings taxed at the United States tax rate. The annual effective tax rate for fiscal 2012 only reflected the United States federal research and development credit generated through December 31, 2011, the date on which the credit expired.

[0001234452-14-000320:mdna:71]
Our Segment Results (in millions)

[0001234452-14-000320:mdna:72]
The following should be read in conjunction with the fiscal 2014, 2013 and 2012 financial results for each reporting segment. See “Notes to Consolidated Financial Statements, Note 8. Segment Information.”

[0001234452-14-000320:mdna:73]
|  | QCT |  | QTL |  | QSI |
| 2014 |  |  |  |  |  |
| Revenues | $ | 18,665 |  |  | $ | 7,569 |  |  | $ | — |  |
| EBT (1) | 3,807 |  |  | 6,590 |  |  | (7 | ) |
| EBT as a % of revenues | 20 | % |  | 87 | % |  |  |
| 2013 |  |  |  |  |  |
| Revenues | $ | 16,715 |  |  | $ | 7,554 |  |  | $ | — |  |
| EBT (1) | 3,189 |  |  | 6,590 |  |  | 56 |  |
| EBT as a % of revenues | 19 | % |  | 87 | % |  |  |
| 2012 |  |  |  |  |  |
| Revenues | $ | 12,141 |  |  | $ | 6,327 |  |  | $ | — |  |
| EBT (1) | 2,296 |  |  | 5,585 |  |  | (170 | ) |
| EBT as a % of revenues | 19 | % |  | 88 | % |  |  |

[0001234452-14-000320:mdna:74]
| (1) | Earnings (loss) before taxes. |

[0001234452-14-000320:mdna:75]
QCT Segment. The increases in QCT revenues in fiscal 2014 and 2013 of $1.95 billion and $4.57 billion, respectively, were primarily due to increases in equipment and services revenues. Equipment and services revenues, mostly related to sales of MSM and accompanying RF and PM integrated circuits, were $18.43 billion, $16.49 billion and $11.91 billion in fiscal 2014, 2013 and 2012, respectively. The increase in equipment and services revenues in 2014 resulted primarily from increases of $2.66 billion related to higher MSM and accompanying RF and PM unit shipments and $203 million related to sales of connectivity products, partially offset by a net decrease of $1.08 billion resulting from lower average selling prices offset by higher-priced product mix. The increase in equipment and services revenues in 2013 resulted primarily from a net increase of $2.09 billion resulting from higher-priced product mix offset by lower average selling prices and increases of $2.05 billion related to higher MSM and accompanying RF and PM unit shipments and $212 million related to sales of connectivity products. Approximately 861 million, 716 million and 590 million MSM integrated circuits were sold during fiscal 2014, 2013 and 2012, respectively.

[0001234452-14-000320:mdna:76]
QCT EBT as a percentage of revenues increased in fiscal 2014, compared to fiscal 2013. During fiscal 2014, QCT revenues increased 12% relative to a combined increase of 5% in research and development expenses and selling, general and administrative expenses, whereas gross margin percentage decreased as a result of lower average selling prices and lower-margin product mix, partially offset by lower average unit costs. QCT EBT as a percentage of revenues remained flat in fiscal 2013, compared to fiscal 2012. During fiscal 2013, QCT revenues increased 38% relative to a combined increase of 26% in research and development expenses and selling, general and administrative expenses, whereas QCT gross margin percentage decreased as a result of lower average selling prices and lower-margin product mix, partially offset by lower average unit costs.

[0001234452-14-000320:mdna:77]
QCT inventories increased by 12% in fiscal 2014 from $1.30 billion to $1.46 billion primarily due to an increase in work-in-process and finished goods related to the growth of the business.

[0001234452-14-000320:mdna:78]
QTL Segment. The increases in QTL revenues in fiscal 2014 and 2013 of $15 million and $1.23 billion, respectively, were primarily due to increases in sales of CDMA-based products, including multimode products that also implement OFDMA, by licensees, partially offset by decreases in revenues per unit. QTL EBT as a percentage of revenues remained flat in fiscal 2014, compared to fiscal 2013. During fiscal 2014, QTL revenues increased slightly relative to an increase of 2% in costs and expenses. QTL revenues and EBT for fiscal 2014 were impacted by units that we believe are being underreported by certain licensees, a dispute with a licensee and sales of certain unlicensed products in China. The decrease in QTL EBT as a percentage of revenues during fiscal 2013 was attributable to an increase of 19% in revenues relative to an increase of 29% in costs and expenses primarily due to increased allocation of patent expenses in connection with the corporate reorganization and increased research and development expenses.

[0001234452-14-000320:mdna:79]
QSI Segment. The decrease in QSI EBT in fiscal 2014 of $63 million was primarily due to a decrease of $39 million in net realized gains on investments and an increase of $35 million in impairment losses on investments, partially offset by a decrease of $16 million in interest expense related to the former BWA subsidiaries. QSI costs and expenses for fiscal 2012 included $81 million related to the former BWA subsidiaries; the increase in QSI EBT in fiscal 2013 of $145 million, excluding the impact of this fiscal 2012 expense, was primarily due to an increase of $67 million in net realized gains on investments and a decrease of $60 million in interest expense incurred by the former BWA subsidiaries.

[0001234452-14-000320:mdna:80]
39

[0001234452-14-000320:mdna:81]
Liquidity and Capital Resources

[0001234452-14-000320:mdna:82]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. Cash, cash equivalents and marketable securities were $32.0 billion at September 28, 2014, an increase of $2.6 billion from September 29, 2013. This increase included $1.4 billion in proceeds from the issuance of common stock under our equity compensation plans and $788 million in net proceeds from the sale of the North and Latin America operations of our Omnitracs division. Our cash, cash equivalents and marketable securities at September 28, 2014 consisted of $5.8 billion held by United States-based entities and $26.2 billion held by foreign entities. Most of our cash, cash equivalents and marketable securities held by foreign entities is indefinitely reinvested and would be subject to material tax effects if repatriated. However, we believe that our United States sources of cash and liquidity are sufficient to meet our business needs in the United States and do not expect that we will need to repatriate the funds. Total cash provided by operating activities increased to $8.9 billion during fiscal 2014, compared to $8.8 billion during fiscal 2013.

[0001234452-14-000320:mdna:83]
Accounts receivable increased 13% during fiscal 2014. Days sales outstanding, on a consolidated basis, were 32 days at September 28, 2014, compared to 30 days at September 29, 2013. The increase in accounts receivable was primarily due to the effects of increased revenues related to integrated circuits and a receivable related to a dispute with a licensee. The increase in days sales outstanding was primarily due to a receivable related to a dispute with a licensee.

[0001234452-14-000320:mdna:84]
During fiscal 2014, we repurchased and retired 60,253,000 shares of common stock for $4.5 billion, before commissions. On March 4, 2014, we announced that we had been authorized to repurchase up to $7.8 billion of our common stock. At September 28, 2014, approximately $5.3 billion remained available for repurchase under our stock repurchase program. Since September 28, 2014, we repurchased and retired 8,595,000 shares of common stock for $638 million. We continue to evaluate repurchases as a means of returning capital to stockholders, subject to our periodic determinations that repurchases are in the best interests of our stockholders.

[0001234452-14-000320:mdna:85]
We paid cash dividends totaling $2.6 billion and $2.1 billion, or $1.54 and $1.20 per common share, during fiscal 2014 and 2013, respectively. On March 4, 2014, we announced an increase in our quarterly dividend from $0.35 to $0.42 per share of common stock. On October 16, 2014, we announced a cash dividend of $0.42 per share on our common stock, payable on December 18, 2014 to stockholders of record as of the close of business on December 1, 2014. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001234452-14-000320:mdna:86]
We intend to return 75% of our free cash flow to stockholders through stock repurchases and dividends over the foreseeable future, where free cash flow is defined as net cash provided by operating activities less capital expenditures. To meet this goal, we expect to use existing cash and marketable securities held by, and cash flow generated from, United States-based entities, and we anticipate that we will supplement this by borrowing additional funds in fiscal 2015. The requirement for and timing of such borrowing is subject to a number of factors, including the cash flow generated by United States-based entities, acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001234452-14-000320:mdna:87]
Subject to the foregoing paragraph, we believe our current cash, cash equivalents and marketable securities and our expected cash flow generated from operations will satisfy our working and other capital requirements over the next fiscal year and beyond based on our current business plans. Recent and expected working and other capital requirements also include:

[0001234452-14-000320:mdna:88]
| • | Our research and development expenditures were $5.5 billion and $5.0 billion in fiscal 2014 and 2013, respectively, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications, primarily in the wireless industry. |

[0001234452-14-000320:mdna:89]
| • | Cash outflows for capital expenditures were $1.2 billion and $1.0 billion in fiscal 2014 and 2013, respectively. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001234452-14-000320:mdna:90]
| • | Our purchase obligations for fiscal 2015, some of which relate to research and development activities and capital expenditures, totaled $3.4 billion at September 28, 2014. |

[0001234452-14-000320:mdna:91]
| • | In October 2014, we announced that we had reached agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.5 billion based upon an exchange rate of USD: GBP 1.6057). We expect to use existing cash resources to fund the acquisition. The acquisition is subject to a number of conditions, including receipt of United States and other regulatory approvals and the approval of CSR’s shareholders. Subject to the satisfaction of these conditions, the acquisition is expected to close by the end of the summer of 2015. |

[0001234452-14-000320:mdna:92]
| • | We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly, to open new opportunities for our technologies, obtain development resources, grow our patent portfolio and/or pursue new businesses. |

[0001234452-14-000320:mdna:93]
Contractual Obligations / Off-Balance Sheet Arrangements

[0001234452-14-000320:mdna:94]
We have no significant contractual obligations not fully recorded on our consolidated balance sheets or fully disclosed in the notes to our consolidated financial statements. We have no material off-balance sheet arrangements as defined in S-K 303(a)(4)(ii).

[0001234452-14-000320:mdna:95]
The following table summarizes the payments due by fiscal period for our outstanding contractual obligations at September 28, 2014 (in millions):

[0001234452-14-000320:mdna:96]
|  | Total |  | 2015 |  | 2016-2017 |  | 2018-2019 |  | Beyond2019 |  | NoExpirationDate |
| Purchase obligations (1) | $ | 3,607 |  |  | $ | 3,421 |  |  | $ | 121 |  |  | $ | 36 |  |  | $ | 29 |  |  | $ | — |  |
| Operating lease obligations | 304 |  |  | 91 |  |  | 137 |  |  | 51 |  |  | 25 |  |  | — |  |
| Equity funding and financing commitments (2) | 78 |  |  | 22 |  |  | 52 |  |  | — |  |  | — |  |  | 4 |  |
| Other long-term liabilities (3)(4) | 53 |  |  | 1 |  |  | 23 |  |  | 14 |  |  | 8 |  |  | 7 |  |
| Total contractual obligations | $ | 4,042 |  |  | $ | 3,535 |  |  | $ | 333 |  |  | $ | 101 |  |  | $ | 62 |  |  | $ | 11 |  |

[0001234452-14-000320:mdna:97]
| (1) | Total purchase obligations include $2.8 billion in commitments to purchase integrated circuit product inventories. Integrated circuit product inventory obligations represent purchase commitments for wafers, die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancelation of outstanding purchase orders is generally allowed but requires payment of all costs incurred through the date of cancelation. |

[0001234452-14-000320:mdna:98]
| (2) | Certain of these commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all. |

[0001234452-14-000320:mdna:99]
| (3) | Certain long-term liabilities reflected on our balance sheet, such as unearned revenues, are not presented in this table because they do not require cash settlement in the future. Other long-term liabilities as presented in this table include the related current portions. |

[0001234452-14-000320:mdna:100]
| (4) | Our consolidated balance sheet at September 28, 2014 included $76 million in noncurrent liabilities for uncertain tax positions, some of which may result in cash payment. The future payments related to uncertain tax positions have not been presented in the table above due to the uncertainty of the amounts and timing of cash settlement with the taxing authorities. |

[0001234452-14-000320:mdna:101]
Additional information regarding our financial commitments at September 28, 2014 is provided in the notes to our consolidated financial statements. See “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies.”

[0001234452-14-000320:mdna:102]
Recent Accounting Pronouncements

[0001234452-14-000320:mdna:103]
In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue which may require a company to use more judgment and make more estimates than under the current guidance. This ASU will be effective for us starting in the first quarter of fiscal 2018. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the fiscal 2018 opening retained earnings balance. We are in the process of determining the adoption method as well as the effects the adoption will have on our consolidated financial statements.

[0001234452-14-000320:mdna:104]
Non-GAAP Financial Information

[0001234452-14-000320:mdna:105]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations includes references to free cash flow and return of capital to stockholders as a percent of free cash flow. These are financial measures that were not prepared in accordance with GAAP.  We define “free cash flow” as net cash provided by operating activities less capital expenditures and “return of capital to stockholders” as cash paid to repurchase shares of our common stock and cash dividends paid.

[0001234452-14-000320:mdna:106]
The non-GAAP financial information presented should be considered in addition to, not as a substitute for, or superior to, financial measures calculated in accordance with GAAP.  In addition, “non-GAAP” is not a term defined by GAAP, and as a result, our measure of non-GAAP results might be different than similarly titled measures used by other companies.

[0001234452-14-000320:mdna:107]
We use free cash flow to facilitate an understanding of the amount of cash flow generated that is available to grow our business and to create long-term stockholder value. We believe return of capital to stockholders as a percentage of free cash flow provides insight into our cash-generating activities relative to the amount of capital returned to stockholders. These non-GAAP measures are supplemental to the comparable GAAP measures. The following is a reconciliation between GAAP and non-GAAP results for fiscal 2014 (dollars in millions):

[0001234452-14-000320:mdna:108]
| Net cash provided by operating activities (GAAP) | $ | 8,887 |  |
| Capital expenditures | (1,185 | ) |
| Free cash flow (non-GAAP) | $ | 7,702 |  |
| Cash paid to repurchase shares of our common stock (before commissions) | $ | 4,548 |  |
| Cash dividends paid | 2,586 |  |
| Total return of capital to stockholders | $ | 7,134 |  |
| Total return of capital to stockholders as a percentage of net cash provided by operating activities (GAAP) | 80 | % |
| Total return of capital to stockholders as a percentage of free cash flow (non-GAAP) | 93 | % |
