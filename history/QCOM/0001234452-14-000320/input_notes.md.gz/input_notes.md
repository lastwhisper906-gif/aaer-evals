# QCOM notes — 0001234452-14-000320


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001234452-14-000320:notes:1]
Available-for-sale securities were comprised as follows (in millions):

[0001234452-14-000320:notes:2]
|  | Cost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |
| September 28, 2014 |  |  |  |  |  |  |  |
| Equity securities | $ | 1,769 |  |  | $ | 575 |  |  | $ | (6 | ) |  | $ | 2,338 |  |
| Debt securities (including debt funds) | 19,582 |  |  | 312 |  |  | (60 | ) |  | 19,834 |  |
|  | $ | 21,351 |  |  | $ | 887 |  |  | $ | (66 | ) |  | $ | 22,172 |  |
| September 29, 2013 |  |  |  |  |  |  |  |
| Equity securities | $ | 2,570 |  |  | $ | 793 |  |  | $ | (44 | ) |  | $ | 3,319 |  |
| Debt securities (including debt funds) | 18,255 |  |  | 396 |  |  | (162 | ) |  | 18,489 |  |
|  | $ | 20,825 |  |  | $ | 1,189 |  |  | $ | (206 | ) |  | $ | 21,808 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001234452-14-000320:notes:3]
Note 9. Acquisitions

[0001234452-14-000320:notes:4]
During fiscal 2014, the Company acquired 11 businesses for total cash consideration of $775 million and the exchange of unvested stock options that had a negligible fair value. Technology-based intangible assets recognized in the amount of $146 million are being amortized on a straight-line basis over a weighted-average useful life of six years. Goodwill of $628 million was recognized in these transactions, of which $294 million is expected to be deductible for tax purposes.

[0001234452-14-000320:notes:5]
During fiscal 2013, the Company acquired five businesses for total cash consideration of $114 million. Technology-based intangible assets recognized in the amount of $24 million are being amortized on a straight-line basis over a weighted-average useful life of six years. Goodwill of $83 million was recognized in these transactions, of which $21 million is expected to be deductible for tax purposes.

[0001234452-14-000320:notes:6]
During fiscal 2012, the Company acquired eight businesses for total cash consideration of $774 million. Technology-based intangible assets recognized in the amount of $164 million are being amortized on a straight-line basis over a weighted-average useful life of six years. Goodwill of $517 million was recognized in these transactions, of which $71 million is expected to be deductible for tax purposes.

[0001234452-14-000320:notes:7]
The Company recorded $26 million, $2 million and $62 million related to four in-process research and development (IPR&D) projects during fiscal 2014, one IPR&D project in fiscal 2013 and 10 IPR&D projects in fiscal 2012, respectively. During fiscal 2014, the Company recorded $20 million in impairment charges related to two IPR&D projects acquired in fiscal 2012. At September 28, 2014, remaining IPR&D of $55 million consisted of eight projects, which are expected to be completed within three years. Upon completion, the IPR&D projects will be amortized over their useful lives, which are expected to range from three to nine years.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001234452-14-000320:notes:8]
Cash Equivalents. The Company considers all highly liquid investments with original maturities of 90 days or less to be cash equivalents. Cash equivalents are comprised of money market funds, certificates of deposit, commercial paper, government agencies’ securities, certain bank time deposits and repurchase agreements fully collateralized by government agencies’ securities. The carrying amounts approximate fair value due to the short maturities of these instruments.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001234452-14-000320:notes:9]
Note 7. Commitments and Contingencies

[0001234452-14-000320:notes:10]
Legal Proceedings. ParkerVision, Inc. v. QUALCOMM Incorporated: On July 20, 2011, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe seven of its patents alleged to cover direct down-conversion receivers. ParkerVision’s complaint sought damages and injunctive and other relief. Subsequently, ParkerVision narrowed its allegations to assert only four patents. On October 17, 2013, the jury returned a verdict finding all asserted claims of the four at-issue patents to be infringed and finding that none of the asserted claims are invalid. On October 24, 2013, the jury returned a separate verdict assessing total past damages of approximately $173 million and finding that the Company’s infringement was not willful. The Company recorded the verdict amount in fiscal 2013 as a charge in other expenses. Post-verdict motions, including the Company’s motions for judgment as a matter of law and a new trial on invalidity and non-infringement and ParkerVision’s motions for injunctive relief and ongoing royalties, were filed by January 24, 2014. A hearing on these motions was held on May 1, 2014. On June 20, 2014, the court granted the Company’s motion to overturn the infringement verdict, denied the Company’s motion to overturn the invalidity verdict, and denied the remaining motions as moot. The court then entered judgment in the Company’s favor. As a result of the court’s judgment, the Company is not liable for any damages to ParkerVision, and therefore, the Company reversed all recorded amounts related to the damages verdict in fiscal 2014. On June 25, 2014, ParkerVision filed a notice of appeal with the court. On May 1, 2014, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. On August 21, 2014, ParkerVision amended the compliant, now captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision now alleges that the Company infringes 11 additional patents and seeks damages and injunctive and other relief. The Company was served with the complaint in this second action on August 28, 2014 and has not yet responded.

[0001234452-14-000320:notes:11]
Nvidia Corporation v. Qualcomm Incorporated: On September 4, 2014, Nvidia filed a complaint in the United States District Court for the District of Delaware and also with the United States International Trade Commission (ITC) pursuant to Section 337 of the Tariff Act of 1930 against the Company, Samsung Electronics Co., Ltd., and other Samsung entities, alleging infringement of seven patents related to graphics processing. In the ITC complaint, Nvidia seeks an exclusion order barring the importation of the Company’s consumer electronics and display device products that infringe, induce infringement and/or contribute to the infringement of at least one of the seven asserted graphics processing patents as well as a cease and desist order preventing the Company from carrying out commercial activities within the United States related to such products. In the District of Delaware complaint, Nvidia is seeking an award of damages for the infringement of the asserted patents, a finding that such infringement is willful and treble damages for such willful infringement, and an order permanently enjoining the Company from infringing the asserted patents. The ITC instituted an investigation into Nvidia’s allegations on October 6, 2014. The evidentiary hearing for the investigation is set for June 8 to June 15, 2015. The Initial Determination of the Administrative Law Judge is due October 9, 2015, and the target date for completion of the investigation by the Commission is set for February 10, 2016. The district court case was stayed on October 23, 2014 pending completion of the ITC investigation including appeals.

[0001234452-14-000320:notes:12]
Icera Complaint to the European Commission (Commission): On June 7, 2010, the Commission notified and provided the Company with a redacted copy of a complaint filed with the Commission by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the Commission to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company has provided and continues to provide additional documents and information as requested by the Commission. The Company continues to cooperate fully with the Commission’s preliminary investigation.

[0001234452-14-000320:notes:13]
European Commission Investigation: On October 15, 2014, the Commission notified the Company that it is conducting an investigation of the Company relating to Article 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU) and Article 53 and/or 54 of the Agreement for the European Economic Area (EEA Agreement). The Company understands that the investigation concerns primarily the sale and/or marketing of the Company’s baseband chipsets, including alleged conditions relating to the provision by the Company of rebates and/or other financial incentives. If a violation is found, a broad range of remedies is potentially available to the Commission, including imposing a fine and/or injunctive relief prohibiting or restricting certain business practices. Given that this investigation is in its early stages, it is difficult to predict the outcome or what remedies, if any, may be imposed by the Commission. The Company continues to cooperate with the Commission as it conducts its investigation.

[0001234452-14-000320:notes:14]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated South Korean law by offering certain discounts and rebates for purchases of its CDMA chips and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments with respect to this matter.

[0001234452-14-000320:notes:15]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 24 different dates, with the next hearing scheduled for December 8, 2014.

[0001234452-14-000320:notes:16]
Securities and Exchange Commission (SEC) Formal Order of Private Investigation and Department of Justice Investigation: On September 8, 2010, the Company was notified by the SEC’s Los Angeles Regional office of a formal order of private investigation. The Company understands that the investigation arose from a “whistleblower’s” allegations made in December 2009 to the audit committee of the Company’s Board of Directors and to the SEC. In 2010, the audit committee completed an internal review of the allegations with the assistance of independent counsel and independent forensic accountants. This internal review into the whistleblower’s allegations and related accounting practices did not identify any errors in the Company’s financial statements. On January 27, 2012, the Company learned that the U.S. Attorney’s Office for the Southern District of California/Department of Justice (collectively, DOJ) had begun an investigation regarding the Company’s compliance with the Foreign Corrupt Practices Act (FCPA). The audit committee conducted an internal review of the Company’s compliance with the FCPA and its related policies and procedures with the assistance of independent counsel and independent forensic accountants. The audit committee has completed this comprehensive review, made findings consistent with the Company’s findings described below and suggested enhancements to the Company’s overall FCPA compliance program. In part as a result of the audit committee’s review, the Company has made and continues to make enhancements to its FCPA compliance program, including implementation of the audit committee’s recommendations.

[0001234452-14-000320:notes:17]
As previously disclosed, the Company discovered, and as a part of its cooperation with these investigations informed the SEC and the DOJ of, instances in which special hiring consideration, gifts or other benefits (collectively, benefits) were provided to several individuals associated with Chinese state-owned companies or agencies. Based on the facts currently known, the Company believes the aggregate monetary value of the benefits in question to be less than $250,000, excluding employment compensation.

[0001234452-14-000320:notes:18]
On March 13, 2014, the Company received a Wells Notice from the SEC’s Los Angeles Regional Office indicating that the staff has made a preliminary determination to recommend that the SEC file an enforcement action against the Company for violations of the anti-bribery, books and records and internal control provisions of the FCPA. The bribery allegations relate to benefits offered or provided to individuals associated with Chinese state-owned companies or agencies. The Wells Notice indicated that the recommendation could involve a civil injunctive action and could seek remedies that include disgorgement of profits, the retention of an independent compliance monitor to review the Company’s FCPA policies and procedures, an injunction, civil monetary penalties and prejudgment interest.

[0001234452-14-000320:notes:19]
A Wells Notice is not a formal allegation or finding by the SEC of wrongdoing or violation of law. Rather, the purpose of a Wells Notice is to give the recipient an opportunity to make a “Wells submission” setting forth reasons why the proposed enforcement action should not be filed and/or bringing additional facts to the SEC’s attention before any decision is made by the SEC as to whether to commence a proceeding. On April 4, 2014 and May 29, 2014, the Company made Wells submissions to the staff of the Los Angeles Regional Office explaining why the Company believes it has not violated the FCPA and therefore enforcement action is not warranted.

[0001234452-14-000320:notes:20]
The Company is continuing to cooperate with the SEC and the DOJ, but is unable to predict the outcome of their investigations or any action that the SEC may decide to file.

[0001234452-14-000320:notes:21]
China National Development and Reform Commission (NDRC) Investigation: In November 2013, the NDRC notified the Company that it had commenced an investigation of the Company relating to the Chinese Anti-Monopoly Law (AML). The Company understands that the investigation concerns primarily the Company’s licensing business and certain interactions between the Company’s licensing business and its chipset business, including how royalties are calculated in the Company’s patent licenses, the value exchanged for cross-licenses to patents of the Company’s licensees, whether the Company will offer license agreements limited to patents essential to certain standards, whether royalties are sought for the Company’s expired patents, the Company’s policy of selling chipsets only to the Company’s patent licensees, the alleged refusal of the Company to grant patent licenses to chipset manufacturers, and certain other terms and conditions in the Company’s patent license and chipset sale agreements. A broad range of remedies with respect to business practices deemed to violate the AML is potentially available to the NDRC, including but not limited to issuing an order to cease conduct deemed illegal, confiscating gains deemed illegally obtained, imposing a fine in the range of 1% to 10% of the prior year’s revenues and requiring modifications to business practices. Given the limited precedent of enforcement actions and penalties under the AML, it is difficult to predict the outcome of this matter or what remedies may be imposed by the NDRC. The Company continues to cooperate with the NDRC as it conducts its investigation.

[0001234452-14-000320:notes:22]
Federal Trade Commission (FTC) Investigation: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act. The Company understands that the investigation concerns primarily the Company’s licensing business, including potential breach of FRAND commitments. If a violation of Section 5 is found, a broad range of remedies is potentially available to the FTC, including imposing a fine or requiring modifications to the Company’s licensing practices. Given that this investigation is in its early stages, it is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the FTC. The Company continues to cooperate with the FTC as it conducts its investigation.

[0001234452-14-000320:notes:23]
The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain. Accordingly, the Company cannot predict the outcome of these matters. The Company has not recorded any accrual at September 28, 2014 for contingent losses associated with these matters based on its belief that, with the exception of the NDRC matter, losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. Regarding the NDRC matter, the Company believes that a loss is probable but that any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001234452-14-000320:notes:24]
Loans and Debentures. The Company’s former BWA subsidiaries (Note 10) had loan and debenture liabilities in connection with the BWA spectrum won in India in fiscal 2010. The subsidiaries were merged into one remaining former BWA subsidiary in August 2013, and that subsidiary had a loan from a bank related to payment of $81 million to the India Government’s Department of Telecommunications in March 2012 (the DoT loan), which was recorded by the Company as a charge to other expenses in fiscal 2012. On June 25, 2013, all outstanding debentures ($492 million, including accrued interest) were redeemed, and on August 30, 2013, all outstanding loans, excluding the DoT loan, ($368 million) were repaid in full using funding provided by Bharti, and the Company’s related guarantee and indemnification agreements were terminated. Prior to the deconsolidation of the BWA subsidiaries on June 25, 2013, cash paid for interest on the loans and debentures was $92 million and $88 million for fiscal 2013 and 2012, respectively.

[0001234452-14-000320:notes:25]
The DoT loan was guaranteed by QUALCOMM Incorporated and one of its wholly owned subsidiaries and was denominated in Indian rupees. The fair value of the guarantee was recorded as a liability when the Company deconsolidated the BWA subsidiaries (Note 10). The DoT loan was repaid in full on October 15, 2013 ($67 million) using funding provided by Bharti as a condition to Bharti’s acquisition of all of the Company’s interest in the remaining former BWA subsidiary, which occurred on October 17, 2013.

[0001234452-14-000320:notes:26]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company. Through September 28, 2014, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products.

[0001234452-14-000320:notes:27]
These indemnification arrangements are not initially measured and recognized at fair value because they are deemed to be similar to product warranties in that they relate to claims and/or other actions that could impair the ability of the Company’s direct or indirect customers to use the Company’s products or services. Accordingly, the Company records liabilities resulting from the arrangements when they are probable and can be reasonably estimated. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at September 28, 2014 associated with these indemnification arrangements, other than insignificant amounts, based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001234452-14-000320:notes:28]
Purchase Obligations. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Obligations, which generally have a remaining term of less than one year, under these agreements at September 28, 2014 for each of the subsequent five years from fiscal 2015 through 2019 were approximately $3.4 billion, $91 million, $30 million, $18 million and $18 million, respectively, and $29 million thereafter. Of these amounts, for fiscal 2015, commitments to purchase integrated circuit product inventories comprised $2.8 billion. Integrated circuit product inventory obligations represent purchase commitments for wafers, die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase orders is generally allowed but requires payment of costs incurred through the date of cancelation.

[0001234452-14-000320:notes:29]
Operating Leases. The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 20 years and with provisions in certain leases for cost-of-living increases. Rental expense for fiscal 2014, 2013 and 2012 was $91 million, $90 million and $87 million, respectively. Future minimum lease payments in each of the next five years from fiscal 2015 through 2019 are $91 million, $79 million, $58 million, $31 million and $20 million, respectively, and $25 million thereafter.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001234452-14-000320:notes:30]
Note 6. Employee Benefit Plans

[0001234452-14-000320:notes:31]
Employee Savings and Retirement Plan. The Company has a 401(k) plan that allows eligible employees to contribute up to 100% of their eligible compensation, subject to annual limits. The Company matches a portion of the employee contributions and may, at its discretion, make additional contributions based upon earnings. The Company’s contribution expense was $77 million, $70 million and $60 million in fiscal 2014, 2013 and 2012, respectively.

[0001234452-14-000320:notes:32]
Equity Compensation Plans. The 2006 Long-Term Incentive Plan (the 2006 Plan) was adopted during the second quarter of fiscal 2006 and replaced the 2001 Stock Option Plan and the 2001 Non-Employee Directors’ Stock Option Plan and their predecessor plans (the Prior Plans). The 2006 Plan provides for the grant of incentive and non-qualified stock options, restricted stock units, stock appreciation rights, restricted stock, performance stock units and other share-based awards and is the source of shares issued under the Non-Qualified Deferred Compensation Plan (the NQDCP). The shares authorized under the 2006 Plan were approximately 573,284,000 at September 28, 2014. The share reserve remaining under the 2006 Plan was approximately 226,754,000 at September 28, 2014. Shares subject to any stock option under a Prior Plan that is terminated or canceled (but not a stock option under a Prior Plan that expires) following the date that the 2006 Plan was approved by stockholders, and shares that are subject to an award under the NQDCP and are returned to the Company because they fail to vest, will again become available for grant under the 2006 Plan. The Board of Directors of the Company may amend or terminate the 2006 Plan at any time. Certain amendments, including an increase in the share reserve, require stockholder approval.

[0001234452-14-000320:notes:33]
During fiscal 2014, the Company assumed 152,000 outstanding stock options under various stock-based incentive plans (the Assumed Plans) as a result of a business acquisition (Note 9). All remaining shares available under Assumed Plans were terminated on the date of the acquisition, and no additional shares may be granted under those plans.

[0001234452-14-000320:notes:34]
Net share-based awards, after forfeitures and cancelations, granted during fiscal 2014, 2013 and 2012 represented 0.8%, 0.8% and 0.9% of outstanding shares as of the beginning of each fiscal year, respectively. Total share-based awards granted during fiscal 2014, 2013 and 2012 represented 1.0% of outstanding shares as of the end of each fiscal year.

[0001234452-14-000320:notes:35]
RSUs are share awards that entitle the holder to receive shares of the Company’s common stock upon vesting. The RSUs generally include dividend-equivalent rights and vest over periods of three years from the date of grant. A summary of RSU transactions for all equity compensation plans follows:

[0001234452-14-000320:notes:36]
|  | Number of Shares |  | Weighted-AverageGrant Date FairValue |  | Aggregate IntrinsicValue |
|  | (In thousands) |  |  |  | (In billions) |
| RSUs outstanding at September 29, 2013 | 31,078 |  |  | $ | 59.91 |  |  |  |
| RSUs granted | 14,558 |  |  | 72.80 |  |  |  |
| RSUs canceled/forfeited | (2,223 | ) |  | 63.66 |  |  |  |
| RSUs vested | (14,863 | ) |  | 57.66 |  |  |  |
| RSUs outstanding at September 28, 2014 | 28,550 |  |  | $ | 67.36 |  |  | $ | 2.1 |  |

[0001234452-14-000320:notes:37]
At September 28, 2014, total unrecognized compensation expense related to non-vested RSUs granted prior to that date was $1.3 billion, which is expected to be recognized over a weighted-average period of 1.8 years. The total vest-date fair value of RSUs that vested during fiscal 2014, 2013 and 2012 was $1.1 billion, $1.0 billion and $352 million, respectively. Upon vesting, the Company issues new shares of common stock. For the majority of RSUs, shares are issued on the vesting dates net of the amount of shares needed to satisfy statutory tax withholding requirements to be paid by the Company on behalf of the employees. The total shares withheld related to all share-based awards were approximately 5,568,000, 5,805,000 and 1,965,000 in fiscal 2014, 2013 and 2012, respectively, and were based on the value of the awards on their vesting dates as determined by the Company’s closing stock price. Total payments for the employees’ tax obligations to the taxing authorities were $417 million, $374 million and $131 million in fiscal 2014, 2013 and 2012, respectively.

[0001234452-14-000320:notes:38]
The Board of Directors may grant stock options to selected employees, directors and consultants to the Company to purchase shares of the Company’s common stock at an exercise price not less than the fair market value of the stock at the date of grant. Stock options vest over periods not exceeding five years and are exercisable for up to 10 years from the grant date. A summary of stock option transactions for all equity compensation plans follows:

[0001234452-14-000320:notes:39]
|  | Number of Shares |  | Weighted- AverageExercisePrice |  | Average RemainingContractual Term |  | Aggregate IntrinsicValue |
|  | (In thousands) |  |  |  | (Years) |  | (In billions) |
| Stock options outstanding at September 29, 2013 | 71,026 |  |  | $ | 41.17 |  |  |  |  |  |
| Stock options assumed (1) | 152 |  |  | 4.73 |  |  |  |  |  |
| Stock options canceled/forfeited/expired | (220 | ) |  | 42.03 |  |  |  |  |  |
| Stock options exercised | (28,845 | ) |  | 40.87 |  |  |  |  |  |
| Stock options outstanding at September 28, 2014 | 42,113 |  |  | $ | 41.23 |  |  | 3.5 |  | $ | 1.4 |  |
| Exercisable at September 28, 2014 | 41,701 |  |  | $ | 41.27 |  |  | 3.5 |  | $ | 1.4 |  |

[0001234452-14-000320:notes:40]
| (1) | Represents activity related to options that were assumed as a result of an acquisition (Note 9). |

[0001234452-14-000320:notes:41]
At September 28, 2014, total unrecognized estimated compensation expense related to non-vested stock options granted prior to that date was $12 million, which is expected to be recognized over a weighted-average period of 1.7 years. The total intrinsic value of stock options exercised during fiscal 2014, 2013 and 2012 was $971 million, $949 million and $1.0 billion, respectively, and the amount of cash received from the exercise of stock options was $1.2 billion, $1.3 billion and $1.5 billion, respectively. Upon option exercise, the Company issues new shares of stock.

[0001234452-14-000320:notes:42]
The total tax benefits realized, including the excess tax benefits, related to share-based awards was $690 million, $659 million and $438 million during fiscal 2014, 2013 and 2012, respectively.

[0001234452-14-000320:notes:43]
Employee Stock Purchase Plan. The Company has an employee stock purchase plan for eligible employees to purchase shares of common stock at 85% of the lower of the fair market value on the first or the last day of each offering period, which is generally six months. Employees may authorize the Company to withhold up to 15% of their compensation during any offering period, subject to certain limitations. The employee stock purchase plan includes a non-423(b) plan. The shares authorized under the employee stock purchase plan were approximately 46,709,000 at September 28, 2014. The shares reserved for future issuance were approximately 6,338,000 at September 28, 2014. During fiscal 2014, 2013 and 2012, approximately 4,376,000, 4,044,000 and 3,654,000 shares, respectively, were issued under the plan at an average price of $58.81, $52.70 and $48.31 per share, respectively. At September 28, 2014, total unrecognized compensation expense related to non-vested purchase rights granted prior to that date was $22 million. The Company recorded cash received from the exercise of purchase rights of $257 million, $213 million and $177 million during fiscal 2014, 2013 and 2012, respectively.


## us-gaap:ConsolidationPolicyTextBlock

[0001234452-14-000320:notes:44]
Principles of Consolidation. The Company’s consolidated financial statements include the assets, liabilities and operating results of majority-owned subsidiaries. In addition, the Company consolidates its investment in an immaterial less than majority-owned variable interest entity as the Company is the primary beneficiary. The ownership of the other interest holders of consolidated subsidiaries and the variable interest entity is presented separately in the consolidated balance sheets and statements of operations. All significant intercompany accounts and transactions have been eliminated.


## us-gaap:DerivativesPolicyTextBlock

[0001234452-14-000320:notes:45]
Derivatives. The Company’s primary objective for holding derivative instruments is to manage foreign exchange risk for certain foreign currency revenue and operating expenditure transactions. To a lesser extent, the Company also holds derivative instruments in its investment portfolios to manage risk by acquiring or reducing foreign exchange risk, interest rate risk and/or equity, prepayment and credit risk. The Company also uses derivative instruments as part of its stock repurchase program.  Derivative instruments are recorded at fair value and included in other current assets, noncurrent assets, other accrued liabilities or other noncurrent liabilities based on their maturity dates. Counterparties to the Company’s derivative instruments are all major institutions.

[0001234452-14-000320:notes:46]
Foreign Currency Hedges: The Company manages its exposure to foreign exchange market risks, when deemed appropriate, through the use of derivative instruments, including foreign currency forward and option contracts with financial counterparties. These derivative instruments mature between three and six months. Gains and losses arising from the effective portion of such contracts that are designated as cash flow hedging instruments are recorded as a component of accumulated other comprehensive income as gains and losses on derivative instruments, net of income taxes. The hedging gains and losses in accumulated other comprehensive income are subsequently reclassified to revenues or costs and expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect the Company’s earnings. Gains and losses arising from the ineffective portion of such contracts are recorded in net investment income as gains and losses on derivative instruments. The cash flows associated with derivative instruments designated as cash flow or net investment hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The cash flows associated with the ineffective portion of such derivative instruments are classified as cash flows from investing activities in the consolidated statements of cash flows.

[0001234452-14-000320:notes:47]
The aggregate fair value of the Company’s foreign currency option and forward contracts used to hedge foreign currency risk recorded in total assets and in total liabilities was negligible at September 28, 2014. At September 29, 2013, the fair value recorded in total assets and in total liabilities was $38 million and $9 million, respectively. All such instruments were designated as cash flow hedges.

[0001234452-14-000320:notes:48]
Investment Portfolio Derivatives: The Company also utilizes currency forwards, futures, options and swaps that are not designated as hedging instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks in its marketable securities investment portfolios. The Company primarily uses such derivative instruments for risk management, and not speculative, purposes. These derivative instruments mature over various periods up to 3 years. Gains and losses arising from changes in the fair values of such derivative instruments are recorded in net investment income as gains and losses on derivative instruments. The cash flows associated with such derivative instruments are classified as cash flows from investing activities in the consolidated statements of cash flows. At September 28, 2014 and September 29, 2013, the fair values of these derivative instruments recorded in total assets and in total liabilities were negligible.

[0001234452-14-000320:notes:49]
Gross Notional Amounts. The gross notional amounts of the Company’s foreign currency and investment portfolio derivatives by instrument type were as follows (in millions):

[0001234452-14-000320:notes:50]
|  | September 28, 2014 |  | September 29, 2013 |
| Futures | $ | 260 |  |  | $ | 106 |  |
| Forwards | 210 |  |  | 544 |  |
| Options | 122 |  |  | 609 |  |
| Swaps | 5 |  |  | 18 |  |
|  | $ | 597 |  |  | $ | 1,277 |  |

[0001234452-14-000320:notes:51]
The gross notional amounts by currency were as follows (in millions):

[0001234452-14-000320:notes:52]
|  | September 28, 2014 |  | September 29, 2013 |
| United States dollar | $ | 266 |  |  | $ | 108 |  |
| Korean won | 121 |  |  | — |  |
| British pound sterling | 97 |  |  | 46 |  |
| Euro | 43 |  |  | 161 |  |
| Japanese yen | 19 |  |  | 617 |  |
| Canadian dollar | 10 |  |  | 62 |  |
| Indian rupee | 3 |  |  | 205 |  |
| Other | 38 |  |  | 78 |  |
|  | $ | 597 |  |  | $ | 1,277 |  |


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0001234452-14-000320:notes:53]
A summary of RSU transactions for all equity compensation plans follows:

[0001234452-14-000320:notes:54]
A summary of stock option transactions for all equity compensation plans follows:


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001234452-14-000320:notes:55]
Note 11. Discontinued Operations

[0001234452-14-000320:notes:56]
On November 25, 2013, the Company completed its sale of the North and Latin America operations of its Omnitracs division to a U.S.-based private equity firm for cash consideration of $788 million (net of cash sold). As a result, the Company recorded a gain in discontinued operations of $665 million ($430 million net of income tax expense) during fiscal 2014. Total assets and total liabilities were reduced by $150 million and $45 million, respectively. The revenues and operating results of the North and Latin America operations of the Omnitracs division, which comprised substantially all of the Omnitracs division, were not presented as discontinued operations in any fiscal period because they were immaterial. The related assets (included in other current assets and other noncurrent assets) and liabilities (included in other current liabilities and other noncurrent liabilities) of $139 million and $43 million, respectively, were classified as held for sale at September 29, 2013.

[0001234452-14-000320:notes:57]
On March 27, 2011, the FLO TV business and network were shut down. On December 27, 2011, the Company completed the sale of substantially all of its 700 MHz spectrum for $1.9 billion, and as a result, the Company recognized a gain in discontinued operations of $1.2 billion during fiscal 2012. Accordingly, the results of operations of the FLO TV business were presented as discontinued operations. Income (loss) from discontinued operations included share-based compensation and excluded certain general corporate expenses allocated to the FLO TV business during the periods presented. Discontinued operations in fiscal 2012 were $1.2 billion ($776 million net of income tax expense).


## us-gaap:DividendsDeclaredTableTextBlock

[0001234452-14-000320:notes:58]
Dividends charged to retained earnings in fiscal 2014, 2013 and 2012 were as follows (in millions, except per share data):

[0001234452-14-000320:notes:59]
|  | 2014 |  | 2013 |  | 2012 |
|  | Per Share |  | Total |  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.350 |  |  | $ | 599 |  |  | $ | 0.250 |  |  | $ | 435 |  |  | $ | 0.215 |  |  | $ | 368 |  |
| Second quarter | 0.350 |  |  | 599 |  |  | 0.250 |  |  | 439 |  |  | 0.215 |  |  | 377 |  |
| Third quarter | 0.420 |  |  | 718 |  |  | 0.350 |  |  | 615 |  |  | 0.250 |  |  | 429 |  |
| Fourth quarter | 0.420 |  |  | 713 |  |  | 0.350 |  |  | 604 |  |  | 0.250 |  |  | 438 |  |
|  | $ | 1.540 |  |  | $ | 2,629 |  |  | $ | 1.200 |  |  | $ | 2,093 |  |  | $ | 0.930 |  |  | $ | 1,612 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001234452-14-000320:notes:60]
Earnings Per Common Share. Basic earnings per common share are computed by dividing net income attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share are computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans and shares subject to written put options, if any, and the weighted-average number of common shares outstanding during the reporting period. Dilutive common share equivalents include the dilutive effect of in-the-money share equivalents, which are calculated based on the average share price for each period using the treasury stock method. Under the treasury stock method, the exercise price of an award, if any, the amount of compensation cost for future service that the Company has not yet recognized, if any, and the estimated tax benefits that would be recorded in paid-in capital when an award is settled, if any, are assumed to be used to repurchase shares in the current period. The dilutive common share equivalents, calculated using the treasury stock method, for fiscal 2014, 2013 and 2012 were 30,655,000, 38,670,000 and 40,978,000, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001234452-14-000320:notes:61]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 3,603 |  |  | $ | 3,884 |  |  | $ | — |  |  | $ | 7,487 |  |
| Marketable securities |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 715 |  |  | 840 |  |  | — |  |  | 1,555 |  |
| Corporate bonds and notes | — |  |  | 14,481 |  |  | — |  |  | 14,481 |  |
| Mortgage- and asset-backed securities | — |  |  | 1,309 |  |  | 186 |  |  | 1,495 |  |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | 83 |  |
| Common and preferred stock | 1,056 |  |  | 741 |  |  | — |  |  | 1,797 |  |
| Equity funds | 541 |  |  | — |  |  | — |  |  | 541 |  |
| Debt funds | 813 |  |  | 3,350 |  |  | — |  |  | 4,163 |  |
| Total marketable securities | 3,125 |  |  | 20,721 |  |  | 269 |  |  | 24,115 |  |
| Derivative instruments | 1 |  |  | 4 |  |  | — |  |  | 5 |  |
| Other investments | 262 |  |  | — |  |  | — |  |  | 262 |  |
| Total assets measured at fair value | $ | 6,991 |  |  | $ | 24,609 |  |  | $ | 269 |  |  | $ | 31,869 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Other liabilities | 261 |  |  | — |  |  | — |  |  | 261 |  |
| Total liabilities measured at fair value | $ | 261 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 262 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001234452-14-000320:notes:62]
|  | 2014 |  | 2013 |
|  | Auction RateSecurities |  | Mortgage- and Asset-BackedSecurities |  | Auction RateSecurities |  | Mortgage- and Asset-BackedSecurities |
| Beginning balance of Level 3 | $ | 83 |  |  | $ | 239 |  |  | $ | 118 |  |  | $ | 203 |  |
| Total realized and unrealized gains (losses): |  |  |  |  |  |  |  |
| Included in investment income, net | — |  |  | 11 |  |  | — |  |  | 8 |  |
| Included in other comprehensive income | — |  |  | (3 | ) |  | 1 |  |  | (6 | ) |
| Purchases | — |  |  | 107 |  |  | — |  |  | 163 |  |
| Sales | — |  |  | (126 | ) |  | — |  |  | (70 | ) |
| Settlements | — |  |  | (40 | ) |  | (36 | ) |  | (77 | ) |
| Transfers (out of) into Level 3 | — |  |  | (2 | ) |  | — |  |  | 18 |  |
| Ending balance of Level 3 | $ | 83 |  |  | $ | 186 |  |  | $ | 83 |  |  | $ | 239 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001234452-14-000320:notes:63]
Note 12. Fair Value Measurements

[0001234452-14-000320:notes:64]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at September 28, 2014 (in millions):

[0001234452-14-000320:notes:65]
Activity between Levels of the Fair Value Hierarchy. There were no significant transfers between Level 1 and Level 2 during fiscal 2014 or 2013. When a determination is made to classify an asset or liability within Level 3, the determination is based upon the significance of the unobservable inputs to the overall fair value measurement. The following table includes the activity for marketable securities and other liabilities classified within Level 3 of the valuation hierarchy (in millions):

[0001234452-14-000320:notes:66]
The Company recognizes transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer occurs. Transfers out of Level 3 during fiscal 2014 primarily consisted of debt securities with significant upgrades in credit ratings. Transfers into Level 3 in fiscal 2013 primarily consisted of debt securities with significant inputs that became unobservable as a result of an increased likelihood of a shortfall in contractual cash flows or a significant downgrade in credit ratings.

[0001234452-14-000320:notes:67]
Nonrecurring Fair Value Measurements. The Company measures certain assets at fair value on a nonrecurring basis. These assets include cost and equity method investments when they are deemed to be other-than-temporarily impaired, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During fiscal 2014, 2013 and 2012, certain long-lived assets and goodwill related to the Company’s QMT division were written down to their estimated fair values resulting in impairment charges of $607 million, $158 million and $54 million, respectively (Note 2). At September 28, 2014, the carrying values of the QMT division’s property, plant and equipment and goodwill were $148 million and $35 million. During fiscal 2013, the Company recorded its retained investment in the former BWA subsidiaries at its estimated fair value of $34 million (Note 10). During fiscal 2014 and 2012, goodwill related to the Company’s former QRS (Qualcomm Retail Solutions) division was written down to its implied fair value resulting in impairment charges of $16 million and $23 million, respectively, which were recorded in other expenses. The estimation of fair values and cash flows used in these fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. During fiscal 2014, 2013 and 2012, the Company did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001234452-14-000320:notes:68]
Foreign Currency. Certain foreign subsidiaries use a local currency as the functional currency. Resulting translation gains or losses are recognized as a component of accumulated other comprehensive income.

[0001234452-14-000320:notes:69]
Transaction gains or losses related to balances denominated in a currency other than the functional currency are recognized in the consolidated statements of operations. Net foreign currency transaction losses included in the Company’s consolidated statements of operations were negligible for all years presented.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001234452-14-000320:notes:70]
Goodwill and Other Intangible Assets. Goodwill represents the excess of purchase price over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Acquired intangible assets other than goodwill are amortized over their useful lives unless the lives are determined to be indefinite. For intangible assets purchased in a business combination, the estimated fair values of the assets received are used to establish their recorded values. For intangible assets acquired in a non-monetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value.

[0001234452-14-000320:notes:71]
Weighted-average amortization periods for finite-lived intangible assets, by class, were as follows (in years):

[0001234452-14-000320:notes:72]
|  | September 28, 2014 |  | September 29, 2013 |
| Wireless spectrum | 14 |  | 14 |
| Marketing-related | 9 |  | 9 |
| Technology-based | 11 |  | 11 |
| Customer-related | 6 |  | 2 |
| Total finite-lived intangible assets | 11 |  | 11 |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001234452-14-000320:notes:73]
Impairment of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. Goodwill and other indefinite-lived intangible assets are tested annually for impairment in the fourth fiscal quarter and in interim periods if certain events occur indicating that the carrying amounts may be impaired. If a qualitative assessment is used and the Company determines that the fair value of a reporting unit or indefinite-lived intangible asset is more likely than not (i.e., a likelihood of more than 50%) less than its carrying amount, a quantitative impairment test will be performed. If goodwill is quantitatively assessed for impairment, a two-step approach is applied. First, the Company compares the estimated fair value of the reporting unit in which the goodwill resides to its carrying value. The second step, if necessary, measures the amount of impairment, if any, by comparing the implied fair value of goodwill to its carrying value. Other indefinite-lived intangible assets are quantitatively assessed for impairment, if necessary, by comparing their estimated fair values to their carrying values. If the carrying value exceeds the fair value, the difference is recorded as an impairment.

[0001234452-14-000320:notes:74]
Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by comparing the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Long-lived assets to be disposed of by sale are reported at the lower of their carrying amounts or their estimated fair values less costs to sell and are not depreciated.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001234452-14-000320:notes:75]
Note 4. Income Taxes

[0001234452-14-000320:notes:76]
The components of the income tax provision for continuing operations were as follows (in millions):

[0001234452-14-000320:notes:77]
|  | 2014 |  | 2013 |  | 2012 |
| Current provision: |  |  |  |  |  |
| Federal | $ | 172 |  |  | $ | 324 |  |  | $ | 140 |  |
| State | 10 |  |  | 15 |  |  | 1 |  |
| Foreign | 1,116 |  |  | 1,068 |  |  | 934 |  |
|  | 1,298 |  |  | 1,407 |  |  | 1,075 |  |
| Deferred (benefit) provision: |  |  |  |  |  |
| Federal | (30 | ) |  | (32 | ) |  | 208 |  |
| State | (10 | ) |  | 6 |  |  | (16 | ) |
| Foreign | (14 | ) |  | (32 | ) |  | 12 |  |
|  | (54 | ) |  | (58 | ) |  | 204 |  |
|  | $ | 1,244 |  |  | $ | 1,349 |  |  | $ | 1,279 |  |

[0001234452-14-000320:notes:78]
The foreign component of the income tax provision consists primarily of foreign withholding taxes on royalty fees included in United States earnings.

[0001234452-14-000320:notes:79]
The components of income from continuing operations before income taxes by United States and foreign jurisdictions were as follows (in millions):

[0001234452-14-000320:notes:80]
|  | 2014 |  | 2013 |  | 2012 |
| United States | $ | 3,213 |  |  | $ | 3,798 |  |  | $ | 3,525 |  |
| Foreign | 5,565 |  |  | 4,396 |  |  | 3,037 |  |
|  | $ | 8,778 |  |  | $ | 8,194 |  |  | $ | 6,562 |  |

[0001234452-14-000320:notes:81]
The following is a reconciliation of the expected statutory federal income tax provision to the Company’s actual income tax provision for continuing operations (in millions):

[0001234452-14-000320:notes:82]
|  | 2014 |  | 2013 |  | 2012 |
| Expected income tax provision at federal statutory tax rate | $ | 3,072 |  |  | $ | 2,868 |  |  | $ | 2,297 |  |
| State income tax provision, net of federal benefit | 24 |  |  | 26 |  |  | 24 |  |
| Foreign income taxed at other than U.S. rates | (1,750 | ) |  | (1,362 | ) |  | (1,045 | ) |
| Research and development tax credits | (61 | ) |  | (195 | ) |  | (36 | ) |
| Other | (41 | ) |  | 12 |  |  | 39 |  |
|  | $ | 1,244 |  |  | $ | 1,349 |  |  | $ | 1,279 |  |

[0001234452-14-000320:notes:83]
The Company’s QCT segment’s non-United States headquarters is located in Singapore. The Company has obtained tax incentives in Singapore that commenced in March 2012, which are effective through March 2027, that result in a tax exemption for the first five years provided that the Company meets specified employment and investment criteria. The Company’s Singapore tax rate will increase in fiscal 2017 and again in fiscal 2027 as a result of expiration of these incentives. Had the Company established QCT’s non-United States headquarters in Singapore without these tax incentives, the Company’s income tax expense would have been higher and impacted earnings per share attributable to Qualcomm as follows (in millions, except per share amounts):

[0001234452-14-000320:notes:84]
|  | 2014 |  | 2013 |  | 2012 |
| Additional income tax expense | $ | 690 |  |  | $ | 758 |  |  | $ | 193 |  |
| Reduction to basic earnings per share | $ | 0.41 |  |  | $ | 0.44 |  |  | $ | 0.11 |  |
| Reduction to diluted earnings per share | $ | 0.40 |  |  | $ | 0.43 |  |  | $ | 0.11 |  |

[0001234452-14-000320:notes:85]
The Company considers the operating earnings of certain non-United States subsidiaries to be indefinitely reinvested outside the United States based on the Company’s plans for use and/or investment outside the United States and the Company’s belief that its sources of cash and liquidity in the United States will be sufficient to meet future domestic cash needs. The Company has not recorded a deferred tax liability of approximately $9.1 billion related to the United States federal and state income taxes and foreign withholding taxes on approximately $25.7 billion of undistributed earnings of certain non-United States subsidiaries indefinitely reinvested outside the United States. Should the Company decide to no longer indefinitely reinvest such earnings outside the United States, the Company would have to adjust the income tax provision in the period management makes such determination.

[0001234452-14-000320:notes:86]
The Company files income tax returns in the United States federal jurisdiction and various state and foreign jurisdictions. The Company is currently a participant in the Internal Revenue Service (IRS) Compliance Assurance Process, whereby the IRS and the Company endeavor to agree on the treatment of all tax issues prior to the tax return being filed. The IRS completed its examination of the Company’s tax return for fiscal 2013 and issued a no change letter in October 2014, resulting in no change to the income tax provision. The Company is no longer subject to United States federal income tax examinations for years prior to fiscal 2014. The Company is subject to examination by the California Franchise Tax Board for fiscal years after 2008. The Company is also subject to income taxes in other taxing jurisdictions in the United States and around the world, many of which are open to tax examinations for periods after fiscal 2000. The Company does not expect the impact of any future state or foreign audits to be material.

[0001234452-14-000320:notes:87]
The Company had deferred tax assets and deferred tax liabilities as follows (in millions):

[0001234452-14-000320:notes:88]
|  | September 28, 2014 |  | September 29, 2013 |
| Unearned revenues | $ | 1,189 |  |  | $ | 1,305 |  |
| Accrued liabilities and reserves | 529 |  |  | 305 |  |
| Share-based compensation | 404 |  |  | 497 |  |
| Unrealized losses on marketable securities | 370 |  |  | 293 |  |
| Unused net operating losses | 120 |  |  | 91 |  |
| Other | 127 |  |  | 149 |  |
| Total gross deferred tax assets | 2,739 |  |  | 2,640 |  |
| Valuation allowance | (60 | ) |  | (51 | ) |
| Total net deferred tax assets | 2,679 |  |  | 2,589 |  |
| Unrealized gains on marketable securities | (484 | ) |  | (536 | ) |
| Intangible assets | (315 | ) |  | (265 | ) |
| Property, plant and equipment | (104 | ) |  | (129 | ) |
| Other | (31 | ) |  | (27 | ) |
| Total deferred tax liabilities | (934 | ) |  | (957 | ) |
| Net deferred tax assets | $ | 1,745 |  |  | $ | 1,632 |  |
| Reported as: |  |  |  |
| Current deferred tax assets | $ | 577 |  |  | $ | 573 |  |
| Non-current deferred tax assets | 1,174 |  |  | 1,059 |  |
| Non-current deferred tax assets held for sale (1) | — |  |  | 2 |  |
| Non-current deferred tax liabilities (1) | (6 | ) |  | (2 | ) |
|  | $ | 1,745 |  |  | $ | 1,632 |  |

[0001234452-14-000320:notes:89]
| (1) | Non-current deferred tax assets held for sale and non-current deferred tax liabilities were included in other assets and other liabilities, respectively, in the consolidated balance sheets. |

[0001234452-14-000320:notes:90]
At September 28, 2014, the Company had unused federal net operating loss carryforwards of $137 million expiring from 2021 through 2033, unused state net operating loss carryforwards of $1.3 billion expiring from 2015 through 2034, and unused foreign net operating loss carryforwards of $42 million, which expire from 2019 through 2024. At September 28, 2014, the Company had unused tax credits of $31 million in foreign jurisdictions, which begin to expire in 2015. The Company does not expect its federal net operating loss carryforwards and its state income tax credits to expire unused.

[0001234452-14-000320:notes:91]
The Company believes, more likely than not, that it will have sufficient taxable income after deductions related to share-based awards to utilize the majority of its deferred tax assets. At September 28, 2014, the Company has provided a valuation allowance on certain foreign deferred tax assets, state net operating losses and state net capital losses of $9 million, $50 million and $1 million, respectively. The valuation allowances reflect the uncertainties surrounding the Company’s ability to generate sufficient future taxable income in certain foreign and state tax jurisdictions to utilize its net operating losses and the Company’s ability to generate sufficient capital gains to utilize all capital losses.

[0001234452-14-000320:notes:92]
A summary of the changes in the amount of unrecognized tax benefits for fiscal 2014, 2013 and 2012 follows (in millions):

[0001234452-14-000320:notes:93]
|  | 2014 |  | 2013 |  | 2012 |
| Beginning balance of unrecognized tax benefits | $ | 221 |  |  | $ | 86 |  |  | $ | 96 |  |
| Additions based on prior year tax positions | 1 |  |  | 1 |  |  | — |  |
| Reductions for prior year tax positions and lapse in statute of limitations | (67 | ) |  | — |  |  | (18 | ) |
| Additions for current year tax positions | 5 |  |  | 145 |  |  | 10 |  |
| Settlements with taxing authorities | (73 | ) |  | (11 | ) |  | (2 | ) |
| Ending balance of unrecognized tax benefits | $ | 87 |  |  | $ | 221 |  |  | $ | 86 |  |

[0001234452-14-000320:notes:94]
The Company does not expect any unrecognized tax benefits recorded at September 28, 2014 to result in a significant cash payment in fiscal 2015. Unrecognized tax benefits at September 28, 2014 included $85 million for tax positions that, if recognized, would impact the effective tax rate. The unrecognized tax benefits differ from the amount that would affect the Company’s effective tax rate primarily because the unrecognized tax benefits were included on a gross basis and did not reflect secondary impacts such as the federal deduction for state taxes, adjustments to deferred tax assets and the valuation allowance that might be required if the Company’s tax positions are sustained. The decrease in unrecognized tax benefits in fiscal 2014 was primarily due to an agreement reached with the IRS on components of the Company’s fiscal 2013 tax return. The increase in unrecognized tax benefits in fiscal 2013 was primarily due to tax positions related to transfer pricing. The decrease in unrecognized tax benefits in fiscal 2012 was primarily due to settlement of the Company’s California tax examination for fiscal 2005 through fiscal 2008, which was partially offset by an increase in unrecognized tax benefits generated in fiscal 2012. The Company does not believe that it is reasonably possible that the total amounts of unrecognized tax benefits at September 28, 2014 will significantly increase or decrease in fiscal 2015. Interest expense related to uncertain tax positions was negligible in fiscal 2014, 2013 and 2012. The amount of accrued interest and penalties was negligible at September 28, 2014 and September 29, 2013.

[0001234452-14-000320:notes:95]
Cash amounts paid for income taxes, net of refunds received, were $1.2 billion, $1.1 billion and $1.3 billion for fiscal 2014, 2013 and 2012, respectively.


## us-gaap:IncomeTaxPolicyTextBlock

[0001234452-14-000320:notes:96]
Income Taxes. The asset and liability approach is used to recognize deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax bases of assets and liabilities. Tax law and rate changes are reflected in income in the period such changes are enacted. The Company records a valuation allowance to reduce deferred tax assets to the amount that is more likely than not to be realized. The Company includes interest and penalties related to income taxes, including unrecognized tax benefits, within income tax expense.

[0001234452-14-000320:notes:97]
The Company’s income tax returns are based on calculations and assumptions that are subject to examination by the Internal Revenue Service and other tax authorities. In addition, the calculation of the Company’s tax liabilities involves dealing with uncertainties in the application of complex tax regulations. The Company recognizes liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. While the Company believes it has appropriate support for the positions taken on its tax returns, the Company regularly assesses the potential outcomes of examinations by tax authorities in determining the adequacy of its provision for income taxes. The Company continually assesses the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts that give rise to a revision become known.

[0001234452-14-000320:notes:98]
The Company recognizes windfall tax benefits associated with share-based awards directly to stockholders’ equity when realized. A windfall tax benefit occurs when the actual tax benefit realized by the Company upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that the Company had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, the Company follows the tax law ordering method, under which current year share-based compensation deductions are assumed to be utilized before net operating loss carryforwards and other tax attributes.


## us-gaap:InterestAndOtherIncomeTextBlock

[0001234452-14-000320:notes:99]
Note 3. Investment Income

[0001234452-14-000320:notes:100]
Investment income, net was comprised as follows (in millions):

[0001234452-14-000320:notes:101]
|  | 2014 |  | 2013 |  | 2012 |
| Interest and dividend income | $ | 586 |  |  | $ | 697 |  |  | $ | 609 |  |
| Interest expense | (5 | ) |  | (23 | ) |  | (90 | ) |
| Net realized gains on marketable securities | 770 |  |  | 317 |  |  | 342 |  |
| Net realized gains on other investments | 56 |  |  | 52 |  |  | 27 |  |
| Impairment losses on marketable securities | (156 | ) |  | (72 | ) |  | (71 | ) |
| Impairment losses on other investments | (24 | ) |  | (13 | ) |  | (12 | ) |
| Net gains on derivative instruments | 5 |  |  | — |  |  | 84 |  |
| Equity in net losses of investees | (10 | ) |  | (6 | ) |  | (9 | ) |
| Net gains on deconsolidation of subsidiaries | 6 |  |  | 12 |  |  | — |  |
|  | $ | 1,228 |  |  | $ | 964 |  |  | $ | 880 |  |

[0001234452-14-000320:notes:102]
Net impairment losses on marketable securities related to the noncredit portion of losses on debt securities recognized in other comprehensive income were negligible for all periods presented.


## us-gaap:InventoryPolicyTextBlock

[0001234452-14-000320:notes:103]
Inventories. Inventories are valued at the lower of cost or market (replacement cost, not to exceed net realizable value) using the first-in, first-out method. Recoverability of inventories is assessed based on review of committed purchase orders from customers, as well as purchase commitment projections provided by customers, among other things.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001234452-14-000320:notes:104]
At September 28, 2014, the contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001234452-14-000320:notes:105]
| Years to Maturity |  | No Single |  |  |
| Less Than |  | One to |  | Five to |  | Greater Than |  | Maturity |  |  |
| One Year |  | Five Years |  | Ten Years |  | Ten Years |  | Date |  | Total |
| $ | 3,577 |  |  | $ | 9,334 |  |  | $ | 1,509 |  |  | $ | 700 |  |  | $ | 4,714 |  |  | $ | 19,834 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001234452-14-000320:notes:106]
Note 13. Marketable Securities

[0001234452-14-000320:notes:107]
Marketable securities were comprised as follows (in millions):

[0001234452-14-000320:notes:108]
|  | Current |  | Noncurrent |
|  | September 28, 2014 |  | September 29, 2013 |  | September 28, 2014 |  | September 29, 2013 |
| Trading: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 320 |  |  | $ | 241 |  |  | $ | 38 |  |  | $ | 49 |  |
| Corporate bonds and notes | 191 |  |  | 269 |  |  | 367 |  |  | 256 |  |
| Mortgage- and asset-backed securities | — |  |  | — |  |  | 237 |  |  | 104 |  |
| Total trading | 511 |  |  | 510 |  |  | 642 |  |  | 409 |  |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 805 |  |  | 721 |  |  | 392 |  |  | 71 |  |
| Corporate bonds and notes | 6,274 |  |  | 4,533 |  |  | 7,649 |  |  | 6,812 |  |
| Mortgage- and asset-backed securities | 1,063 |  |  | 745 |  |  | 195 |  |  | 328 |  |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | 83 |  |
| Common and preferred stock | 192 |  |  | 8 |  |  | 1,605 |  |  | 2,351 |  |
| Equity funds | — |  |  | — |  |  | 541 |  |  | 960 |  |
| Debt funds | 813 |  |  | 2,307 |  |  | 2,560 |  |  | 2,889 |  |
| Total available-for-sale | 9,147 |  |  | 8,314 |  |  | 13,025 |  |  | 13,494 |  |
| Fair value option: |  |  |  |  |  |  |  |
| Debt fund | — |  |  | — |  |  | 790 |  |  | 537 |  |
| Total marketable securities | $ | 9,658 |  |  | $ | 8,824 |  |  | $ | 14,457 |  |  | $ | 14,440 |  |

[0001234452-14-000320:notes:109]
The Company holds an investment in a debt fund for which the Company elected the fair value option because the Company is able to redeem its shares at net asset value, which is determined daily. The investment would have otherwise been recorded using the equity method. The debt fund has no single maturity date. At September 28, 2014, the Company had an effective ownership interest in the debt fund of 26%. Net increases in fair value associated with this investment of $33 million, $17 million and $45 million were recognized in net investment income in fiscal 2014, 2013 and 2012, respectively.

[0001234452-14-000320:notes:110]
The Company classifies certain portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange, interest rate and/or equity, prepayment and credit risks as trading. Net losses recognized on debt securities classified as trading held at September 28, 2014 and September 29, 2013 were $5 million and $20 million, respectively.

[0001234452-14-000320:notes:111]
Debt securities with no single maturity date included debt funds, mortgage- and asset-backed securities, auction rate securities and corporate bonds and notes.

[0001234452-14-000320:notes:112]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001234452-14-000320:notes:113]
| Fiscal Year | Gross Realized Gains |  | Gross Realized Losses |  | Net Realized Gains |
| 2014 | $ | 732 |  |  | $ | (18 | ) |  | $ | 714 |  |
| 2013 | 430 |  |  | (142 | ) |  | 288 |  |
| 2012 | 296 |  |  | (25 | ) |  | 271 |  |

[0001234452-14-000320:notes:114]
The following table shows the gross unrealized losses and fair values of the Company’s investments in individual securities that are classified as available-for-sale and have been in a continuous unrealized loss position deemed to be temporary for less than 12 months and for more than 12 months, aggregated by investment category (in millions):

[0001234452-14-000320:notes:115]
|  | September 28, 2014 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |
| U.S. Treasury securities and government-related securities | $ | 279 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,924 |  |  | (31 | ) |  | 104 |  |  | (4 | ) |
| Mortgage- and asset-backed securities | 484 |  |  | (1 | ) |  | 52 |  |  | (1 | ) |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Common and preferred stock | 86 |  |  | (3 | ) |  | 52 |  |  | (3 | ) |
| Debt funds | 133 |  |  | (1 | ) |  | 384 |  |  | (19 | ) |
|  | $ | 5,906 |  |  | $ | (38 | ) |  | $ | 675 |  |  | $ | (28 | ) |

[0001234452-14-000320:notes:116]
|  | September 29, 2013 |
|  | Less than 12 months |  | More than 12 months |
|  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |
| U.S. Treasury securities and government-related securities | $ | 42 |  |  | $ | (1 | ) |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 2,084 |  |  | (31 | ) |  | 24 |  |  | (1 | ) |
| Mortgage- and asset-backed securities | 367 |  |  | (5 | ) |  | 24 |  |  | — |  |
| Auction rate securities | — |  |  | — |  |  | 83 |  |  | (1 | ) |
| Common and preferred stock | 291 |  |  | (41 | ) |  | — |  |  | — |  |
| Debt funds | 2,776 |  |  | (123 | ) |  | 4 |  |  | — |  |
| Equity funds | 82 |  |  | (3 | ) |  | — |  |  | — |  |
|  | $ | 5,642 |  |  | $ | (204 | ) |  | $ | 135 |  |  | $ | (2 | ) |

[0001234452-14-000320:notes:117]
At September 28, 2014, the Company concluded that the unrealized losses on its available-for-sale securities were temporary. Further, for common and preferred stock and for equity and debt funds with unrealized losses, the Company has the ability and the intent to hold such securities until they recover. For debt securities with unrealized losses, the Company does not have the intent to sell, nor is it more likely than not that the Company will be required to sell, such securities before recovery or maturity.

[0001234452-14-000320:notes:118]
The ending balance of the credit loss portion of other-than-temporary impairments on debt securities held by the Company for fiscal 2014, 2013 and 2012 was $8 million, $4 million and $31 million, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001234452-14-000320:notes:119]
Recent Accounting Pronouncements. In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update (ASU) No. 2014-09, “Revenue from Contracts with Customers,” which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new standard requires a company to recognize revenue upon transfer of goods or services to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. ASU 2014-09 defines a five-step approach for recognizing revenue which may require a company to use more judgment and make more estimates than under the current guidance. This ASU will be effective for the Company starting in the first quarter of fiscal 2018. The new standard allows for two methods of adoption: (a) full retrospective adoption, meaning the standard is applied to all periods presented, or (b) modified retrospective adoption, meaning the cumulative effect of applying the new standard is recognized as an adjustment to the fiscal 2018 opening retained earnings balance. The Company is in the process of determining the adoption method as well as the effects the adoption will have on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001234452-14-000320:notes:120]
Note 1. The Company and Its Significant Accounting Policies

[0001234452-14-000320:notes:121]
The Company. QUALCOMM Incorporated, a Delaware corporation, and its subsidiaries (collectively the Company or Qualcomm), develop, design, manufacture, have manufactured on its behalf and market digital communications products and services. The Company is a leading developer and supplier of integrated circuits and system software based on CDMA (Code Division Multiple Access), OFDMA (Orthogonal Frequency Division Multiple Access) and other technologies for use in voice and data communications, networking, application processing, multimedia and global positioning system products to device and infrastructure manufacturers. The Company grants licenses to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, and receives fixed license fees (payable in one or more installments) as well as ongoing royalties based on sales by licensees of wireless telecommunications equipment products incorporating its patented technologies. The Company provides software services for content and push-to-talk enablement across a wide variety of platforms and devices for the wireless industry and sells products designed for the implementation of small cells. The Company also makes strategic investments to support the global adoption of its technologies and services.

[0001234452-14-000320:notes:122]
Financial Statement Preparation. The preparation of financial statements in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in the Company’s consolidated financial statements and the accompanying notes. Examples of the Company’s significant accounting estimates that may involve a higher degree of judgment and complexity than others include: the valuation and assessment of the recoverability of goodwill, other indefinite-lived assets and long-lived assets; the valuation of marketable securities and the determination of other-than-temporary impairments; the calculation of tax liabilities, including the recognition and measurement of uncertain tax positions, and the determination that the operating earnings of certain non-United States subsidiaries are indefinitely reinvested outside the United States; and the recognition and measurement of loss contingencies related to legal proceedings. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

[0001234452-14-000320:notes:123]
Fiscal Year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. The fiscal years ended September 28, 2014 and September 29, 2013 included 52 weeks. The fiscal year ended September 30, 2012 included 53 weeks.

[0001234452-14-000320:notes:124]
Marketable Securities. Marketable securities include trading securities, available-for-sale securities and securities for which the Company has elected the fair value option. The classification of marketable securities within these categories is determined at the time of purchase and reevaluated at each balance sheet date. The Company classifies portfolios of debt securities that utilize derivative instruments to acquire or reduce foreign exchange and/or equity, prepayment and credit risk as trading. The Company classifies marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Marketable securities are stated at fair value. The net unrealized gains or losses on available-for-sale securities are recorded as a component of accumulated other comprehensive income, net of income taxes. The unrealized gains or losses on trading securities and securities for which the Company has elected the fair value option are recognized in net investment income. The realized gains and losses on marketable securities are determined using the specific identification method.

[0001234452-14-000320:notes:125]
At each balance sheet date, the Company assesses available-for-sale securities in an unrealized loss position to determine whether the unrealized loss is other than temporary. The Company considers factors including: the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; how long the market value of the security has been less than its cost basis; the security’s relative performance versus its peers, sector or asset class; expected market volatility; the market and economy in general; analyst recommendations and price targets; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.

[0001234452-14-000320:notes:126]
If a debt security’s market value is below amortized cost and the Company either intends to sell the security or it is more likely than not that the Company will be required to sell the security before its anticipated recovery, the Company records an other-than-temporary impairment charge to net investment income for the entire amount of the impairment. For the remaining debt securities, if an other-than-temporary impairment exists, the Company separates the other-than-temporary impairment into the portion of the loss related to credit factors, or the credit loss portion, and the portion of the loss that is not related to credit factors, or the noncredit loss portion. The credit loss portion is the difference between the amortized cost of the security and the Company’s best estimate of the present value of the cash flows expected to be collected from the debt security. The noncredit loss portion is the residual amount of the other-than-temporary impairment. The credit loss portion is recorded as a charge to net investment income, and the noncredit loss portion is recorded as a component of other accumulated comprehensive income, net of income taxes.

[0001234452-14-000320:notes:127]
When calculating the present value of expected cash flows to determine the credit loss portion of the other-than-temporary impairment, the Company estimates the amount and timing of projected cash flows, the probability of default and the timing and amount of recoveries on a security-by-security basis. These calculations use inputs primarily based on observable market data, such as credit default swap spreads, historical default and recovery statistics, rating agency data, credit ratings and other data relevant to analyzing the collectibility of the security. The amortized cost basis of a debt security is adjusted for any credit loss portion of the impairment recorded to net investment income. The difference between the new cost basis and cash flows expected to be collected is accreted to net investment income over the remaining expected life of the security.

[0001234452-14-000320:notes:128]
Securities that are accounted for as equity securities include investments in common stock, certain preferred stock, equity funds and debt funds. For equity securities, the Company considers the loss relative to the expected volatility and the likelihood of recovery over a reasonable period of time. If events and circumstances indicate that a decline in the value of an equity security has occurred and is other than temporary, the Company records a charge to net investment income for the difference between fair value and cost at the balance sheet date. Additionally, if the Company has either the intent to sell the equity security or does not have both the intent and the ability to hold the equity security until its anticipated recovery, the Company records a charge to net investment income for the difference between fair value and cost at the balance sheet date.

[0001234452-14-000320:notes:129]
Stock Repurchase Program: In connection with the Company’s stock repurchase program, the Company may sell put options that require it to repurchase shares of its common stock at fixed prices. These put options subject the Company to equity price risk. Changes in the fair value of these put options are recorded in net investment income as gains and losses on derivative instruments. The cash flows associated with the put options are classified as cash flows from investing activities in the consolidated statements of cash flows. There were no put options outstanding at September 28, 2014 and September 29, 2013.

[0001234452-14-000320:notes:130]
Fair Value Measurements. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants as of the measurement date. Applicable accounting guidance provides an established hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Observable inputs are inputs that market participants would use in valuing the asset or liability and are developed based on market data obtained from sources independent of the Company. Unobservable inputs are inputs that reflect the Company’s assumptions about the factors that market participants would use in valuing the asset or liability. There are three levels of inputs that may be used to measure fair value:

[0001234452-14-000320:notes:131]
| • | Level 1 includes financial instruments for which quoted market prices for identical instruments are available in active markets. |

[0001234452-14-000320:notes:132]
| • | Level 2 includes financial instruments for which there are inputs other than quoted prices included within Level 1 that are observable for the instrument. |

[0001234452-14-000320:notes:133]
| • | Level 3 includes financial instruments for which fair value is derived from valuation techniques in which one or more significant inputs are unobservable, including the Company’s own assumptions. |

[0001234452-14-000320:notes:134]
Assets and liabilities are classified based on the lowest level of input that is significant to the fair value measurements. The Company reviews the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy.

[0001234452-14-000320:notes:135]
Cash Equivalents and Marketable Securities: With the exception of auction rate securities, the Company obtains pricing information from quoted market prices, pricing vendors or quotes from brokers/dealers. The Company conducts reviews of its primary pricing vendors to determine whether the inputs used in the vendor’s pricing processes are deemed to be observable. The fair value for interest-bearing securities includes accrued interest.

[0001234452-14-000320:notes:136]
The fair value of U.S. Treasury securities and government-related securities, corporate bonds and notes and common and preferred stock is generally determined using standard observable inputs, including reported trades, quoted market prices, matrix pricing, benchmark yields, broker/dealer quotes, issuer spreads, two-sided markets and/or benchmark securities.

[0001234452-14-000320:notes:137]
The fair value of debt and equity funds is reported at published net asset values. The Company assesses the daily frequency and size of transactions at published net asset values and/or the funds’ underlying holdings to determine whether fair value is based on observable or unobservable inputs.

[0001234452-14-000320:notes:138]
The fair value of highly rated mortgage- and asset-backed securities is derived from the use of matrix pricing (prices for similar securities) or, in some cases, cash flow pricing models with observable inputs, such as contractual terms, maturity, credit rating and/or securitization structure to determine the timing and amount of future cash flows. Certain mortgage- and asset-backed securities, principally those rated below AAA, may require the use of significant unobservable inputs to estimate fair value, such as default likelihood, recovery rates and prepayment speed.

[0001234452-14-000320:notes:139]
The fair value of auction rate securities is estimated by the Company using a discounted cash flow model that incorporates transaction details, such as contractual terms, maturity and timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery, the future state of the auction rate market and credit valuation adjustments of market participants. Though most of the securities held by the Company are pools of student loans guaranteed by the U.S. government, prepayment speeds and illiquidity discounts are considered significant unobservable inputs. These additional inputs are generally unobservable, and therefore, auction rate securities are included in Level 3.

[0001234452-14-000320:notes:140]
Derivative Instruments: Derivative instruments that are traded on an exchange are valued using quoted market prices and are included in Level 1. Derivative instruments that are not traded on an exchange are valued using conventional calculations/models that are primarily based on observable inputs, such as foreign currency exchange rates, the Company’s stock price, volatilities and interest rates, and therefore, such derivative instruments are included in Level 2.

[0001234452-14-000320:notes:141]
Other Investments and Other Liabilities: Other investments and other liabilities included in Level 1 are comprised of the Company’s deferred compensation plan liability and related assets, which consist of mutual funds classified as trading securities, and are included in other assets.

[0001234452-14-000320:notes:142]
Allowances for Doubtful Accounts. The Company maintains allowances for doubtful accounts for estimated losses resulting from the inability of the Company’s customers to make required payments. The Company considers the following factors when determining if collection of required payments is reasonably assured: customer credit-worthiness, past transaction history with the customer, current economic industry trends, changes in customer payment terms and bank credit-worthiness for letters of credit. If the Company has no previous experience with the customer, the Company may request financial information, including financial statements or other documents to determine that the customer has the means of making payment. The Company may also obtain reports from various credit organizations to determine that the customer has a history of paying its creditors. If these factors do not indicate collection is reasonably assured, revenue is deferred as a reduction to accounts receivable until collection becomes reasonably assured, which is generally upon receipt of cash. If the financial condition of the Company’s customers was to deteriorate, adversely affecting their ability to make payments, additional allowances would be required.

[0001234452-14-000320:notes:143]
Property, Plant and Equipment. Property, plant and equipment are recorded at cost and depreciated or amortized using the straight-line method over their estimated useful lives. Upon the retirement or disposition of property, plant and equipment, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. Buildings and building improvements on owned land are depreciated over 30 years and 15 years, respectively. Leasehold improvements and buildings on leased land are amortized over the shorter of their estimated useful lives, not to exceed 15 and 30 years, respectively, or the remaining term of the related lease. Other property, plant and equipment have useful lives ranging from 2 to 25 years. Leased property meeting certain capital lease criteria is capitalized, and the net present value of the related lease payments is recorded as a liability. Amortization of assets under capital leases is recorded using the straight-line method over the shorter of the estimated useful lives or the lease terms. Maintenance, repairs and minor renewals or betterments are charged to expense as incurred. Interest expense related to the broadband wireless access (BWA) spectrum and related construction of the network infrastructure assets in India by the Company’s former BWA subsidiaries was capitalized beginning in May 2012 through the third quarter of fiscal 2013 when the BWA subsidiaries were deconsolidated (Note 10). Interest capitalized by the former BWA subsidiaries totaled $65 million in fiscal 2013.

[0001234452-14-000320:notes:144]
Revenue Recognition. The Company derives revenues principally from sales of integrated circuit products, licensing of its intellectual property and sales of software hosting, software development and other services. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of the Company’s deliverables and obligations.

[0001234452-14-000320:notes:145]
Revenues from sales of the Company’s products are recognized at the time of shipment, or when title and risk of loss pass to the customer and other criteria for revenue recognition are met, if later. Revenues from providing services are recognized when earned. Revenues from providing services were less than 10% of total revenues for all periods presented.

[0001234452-14-000320:notes:146]
The Company licenses or otherwise provides rights to use portions of its intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Licensees typically pay a fixed license fee in one or more installments and royalties based on their sales of products incorporating or using the Company’s licensed intellectual property. License fees are recognized over the estimated period of benefit of the license to the licensee, typically 5 to 15 years. The Company earns royalties on such licensed products sold worldwide by its licensees at the time that the licensees’ sales occur. The Company’s licensees, however, do not report and pay royalties owed for sales in any given quarter until after the conclusion of that quarter. The Company recognizes royalty revenues based on royalties reported by licensees during the quarter and when other revenue recognition criteria are met.

[0001234452-14-000320:notes:147]
The Company records reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of the Company’s products and technologies. The Company recognizes the maximum potential liability at the later of the date at which the Company records the related revenues or the date at which the Company offers the incentive or, if payment is contingent, when the contingency is resolved. In certain arrangements, the liabilities are based on customer forecasts. The Company reverses accruals for unclaimed incentive amounts to revenues when the unclaimed amounts are no longer subject to payment.

[0001234452-14-000320:notes:148]
Unearned revenues consist primarily of license fees for intellectual property with continuing performance obligations.

[0001234452-14-000320:notes:149]
Concentrations. A significant portion of the Company’s revenues is concentrated with a small number of customers/licensees of the Company’s QCT and QTL segments. Revenues related to the products of two companies comprised 28% and 21% of total consolidated revenues in fiscal 2014, compared to 24% and 19% in fiscal 2013 and 20% and 18% in fiscal 2012. Aggregate accounts receivable from two customers/licensees comprised 44% and 43% of gross accounts receivable at September 28, 2014 and September 29, 2013, respectively.

[0001234452-14-000320:notes:150]
The Company relies on sole- or limited-source suppliers for some products, particularly products in the QCT segment, subjecting the Company to possible shortages of raw materials or manufacturing capacity. While the Company has established alternate suppliers for certain technologies that the Company considers critical, the loss of a supplier or the inability of a supplier to meet performance or quality specifications or delivery schedules could harm the Company’s ability to meet its delivery obligations and/or negatively impact the Company’s revenues, business operations and ability to compete for future business.

[0001234452-14-000320:notes:151]
Shipping and Handling Costs. Costs incurred for shipping and handling are included in cost of equipment and services revenues. Amounts billed to a customer for shipping and handling are reported as revenues.

[0001234452-14-000320:notes:152]
Share-Based Compensation. Share-based compensation expense for equity-classified awards, principally related to restricted stock units (RSUs), is measured at the grant date, or at the acquisition date for awards assumed in business combinations, based on the estimated fair value of the award and is recognized over the employee’s requisite service period. Share-based compensation expense is adjusted to exclude amounts related to share-based awards that are expected to be forfeited.

[0001234452-14-000320:notes:153]
The fair values of RSUs are estimated based on the fair market values of the underlying stock on the dates of grant or dates the RSUs are assumed. If RSUs do not have the right to participate in dividends, the fair values are discounted by the dividend yield. The weighted-average estimated fair values of employee RSUs granted during fiscal 2014, 2013 and 2012 were $72.81, $64.21 and $58.57 per share, respectively. For the majority of RSUs, shares are issued on the vesting dates net of the amount of shares needed to satisfy statutory tax withholding requirements to be paid by the Company on behalf of the employees. As a result, the actual number of shares issued will be fewer than the number of RSUs outstanding. The annual pre-vest forfeiture rate for RSUs granted in fiscal 2014, 2013 and 2012 was estimated to be approximately 3% based on historical experience.

[0001234452-14-000320:notes:154]
Total share-based compensation expense, related to all of the Company’s share-based awards, was comprised as follows (in millions):

[0001234452-14-000320:notes:155]
|  | 2014 |  | 2013 |  | 2012 |
| Cost of equipment and services revenues | $ | 49 |  |  | $ | 71 |  |  | $ | 75 |  |
| Research and development | 672 |  |  | 643 |  |  | 546 |  |
| Selling, general and administrative | 338 |  |  | 391 |  |  | 414 |  |
| Continuing operations | 1,059 |  |  | 1,105 |  |  | 1,035 |  |
| Related income tax benefit | (203 | ) |  | (217 | ) |  | (225 | ) |
| Continuing operations, net of income taxes | 856 |  |  | 888 |  |  | 810 |  |
| Discontinued operations | — |  |  | — |  |  | 1 |  |
| Related income tax benefit | — |  |  | — |  |  | — |  |
| Discontinued operations, net of income taxes | — |  |  | — |  |  | 1 |  |
|  | $ | 856 |  |  | $ | 888 |  |  | $ | 811 |  |

[0001234452-14-000320:notes:156]
The Company recorded $249 million, $242 million and $270 million in share-based compensation expense during fiscal 2014, 2013 and 2012, respectively, related to share-based awards granted during those periods. The remaining share-based compensation expense was primarily related to share-based awards granted in earlier periods and share-based awards assumed. In addition, for fiscal 2014, 2013 and 2012, $280 million, $231 million and $168 million, respectively, were reclassified to reduce net cash provided by operating activities with an offset to net cash used by financing activities in the consolidated statements of cash flows to reflect the incremental tax benefits from stock options exercised and restricted stock units and other share-based awards that vested in those periods. The amount of compensation cost capitalized related to share-based awards was negligible for all periods presented.

[0001234452-14-000320:notes:157]
Legal Proceedings. The Company is currently involved in certain legal proceedings. The Company records its best estimate of a loss related to pending legal proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, the Company records the minimum estimated liability. As additional information becomes available, the Company assesses the potential liability related to pending legal proceedings and revises its estimates. The Company’s legal costs associated with defending itself are recorded to expense as incurred.

[0001234452-14-000320:notes:158]
Shares of common stock equivalents outstanding that were not included in the computation of diluted earnings per common share because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period were 846,000, 507,000 and 3,537,000 during fiscal 2014, 2013 and 2012, respectively. Put options outstanding during fiscal 2012 were not included in the earnings per common share computation because the put options’ exercise prices were less than the average market price of the common stock while they were outstanding, and therefore, the effect on diluted earnings per common share would be anti-dilutive.

[0001234452-14-000320:notes:159]
Other Comprehensive Income. Other comprehensive income is defined as the change in equity of a business enterprise during a period from transactions and other events and circumstances from non-owner sources, other than net income and including foreign currency translation adjustments and unrealized gains and losses on marketable securities and derivative instruments. Changes in the components of accumulated other comprehensive income, net of income taxes, in the Company’s stockholders’ equity during the fiscal year ended September 28, 2014 were as follows (in millions):

[0001234452-14-000320:notes:160]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain on Other Available-for-Sale Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Total Accumulated Other Comprehensive Income |
| Balance at September 29, 2013 | $ | (115 | ) |  | $ | 25 |  |  | $ | 825 |  |  | $ | 18 |  |  | $ | 753 |  |
| Other comprehensive income (loss) before reclassifications | 1 |  |  | (1 | ) |  | 259 |  |  | 8 |  |  | 267 |  |
| Reclassifications from accumulated other comprehensive income (loss) | 1 |  | (a) | — |  | (a) | (361 | ) | (a) | (26 | ) | (b) | (386 | ) |
| Other comprehensive income (loss) | 2 |  |  | (1 | ) |  | (102 | ) |  | (18 | ) |  | (119 | ) |
| Balance at September 28, 2014 | $ | (113 | ) |  | $ | 24 |  |  | $ | 723 |  |  | $ | — |  |  | $ | 634 |  |

[0001234452-14-000320:notes:161]
| (a) | Reclassifications from accumulated other comprehensive income (loss) of $360 million for the fiscal year ended September 28, 2014 were recorded in investment income, net (Note 3). |

[0001234452-14-000320:notes:162]
| (b) | Reclassifications from accumulated other comprehensive income (loss) of $26 million for the fiscal year ended September 28, 2014 were recorded in revenues, cost of equipment and services revenues, research and development expenses and selling, general and administrative expenses. |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001234452-14-000320:notes:163]
| Property, Plant and Equipment (in millions) | September 28, 2014 |  | September 29, 2013 |
| Land | $ | 225 |  |  | $ | 212 |  |
| Buildings and improvements | 1,456 |  |  | 1,733 |  |
| Computer equipment and software | 1,349 |  |  | 1,425 |  |
| Machinery and equipment | 2,117 |  |  | 2,013 |  |
| Furniture and office equipment | 85 |  |  | 87 |  |
| Leasehold improvements | 247 |  |  | 218 |  |
| Construction in progress | 201 |  |  | 480 |  |
|  | 5,680 |  |  | 6,168 |  |
| Less accumulated depreciation and amortization | (3,193 | ) |  | (3,173 | ) |
|  | $ | 2,487 |  |  | $ | 2,995 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001234452-14-000320:notes:164]
Note 15. Summarized Quarterly Data (Unaudited)

[0001234452-14-000320:notes:165]
The following financial information reflects all normal recurring adjustments that are, in the opinion of management, necessary for a fair statement of the results of the interim periods.

[0001234452-14-000320:notes:166]
The table below presents quarterly data for fiscal 2014 and 2013 (in millions, except per share data):

[0001234452-14-000320:notes:167]
|  | 1st Quarter |  | 2nd Quarter |  | 3rd Quarter |  | 4th Quarter |
| 2014 (1) |  |  |  |  |  |  |  |
| Revenues | $ | 6,622 |  |  | $ | 6,367 |  |  | $ | 6,806 |  |  | $ | 6,692 |  |
| Operating income | 1,493 |  |  | 1,990 |  |  | 2,075 |  |  | 1,992 |  |
| Income from continuing operations | 1,444 |  |  | 1,958 |  |  | 2,237 |  |  | 1,893 |  |
| Discontinued operations, net of tax | 430 |  |  | — |  |  | — |  |  | — |  |
| Net income | 1,874 |  |  | 1,958 |  |  | 2,237 |  |  | 1,893 |  |
| Net income attributable to Qualcomm | 1,875 |  |  | 1,959 |  |  | 2,238 |  |  | 1,894 |  |
| Basic earnings per share attributable to Qualcomm (2): |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.86 |  |  | $ | 1.16 |  |  | $ | 1.33 |  |  | $ | 1.13 |  |
| Discontinued operations | 0.25 |  |  | — |  |  | — |  |  | — |  |
| Net income | 1.11 |  |  | 1.16 |  |  | 1.33 |  |  | 1.13 |  |
| Diluted earnings per share attributable to Qualcomm (2): |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.84 |  |  | $ | 1.14 |  |  | $ | 1.31 |  |  | $ | 1.11 |  |
| Discontinued operations | 0.25 |  |  | — |  |  | — |  |  | — |  |
| Net income | 1.09 |  |  | 1.14 |  |  | 1.31 |  |  | 1.11 |  |
| 2013 (1) |  |  |  |  |  |  |  |
| Revenues | $ | 6,018 |  |  | $ | 6,124 |  |  | $ | 6,243 |  |  | $ | 6,480 |  |
| Operating income | 2,088 |  |  | 1,877 |  |  | 1,677 |  |  | 1,588 |  |
| Net income | 1,903 |  |  | 1,863 |  |  | 1,578 |  |  | 1,501 |  |
| Net income attributable to Qualcomm | 1,906 |  |  | 1,866 |  |  | 1,580 |  |  | 1,501 |  |
| Basic earnings per share attributable to Qualcomm (2): | $ | 1.12 |  |  | $ | 1.08 |  |  | $ | 0.91 |  |  | $ | 0.88 |  |
| Diluted earnings per share attributable to Qualcomm (2): | $ | 1.09 |  |  | $ | 1.06 |  |  | $ | 0.90 |  |  | $ | 0.86 |  |

[0001234452-14-000320:notes:168]
| (1) | Amounts, other than per share amounts, are rounded to millions each quarter. Therefore, the sum of the quarterly amounts may not equal the annual amounts reported. |

[0001234452-14-000320:notes:169]
| (2) | Earnings per share attributable to Qualcomm are computed independently for each quarter and the full year based upon respective average shares outstanding. Therefore, the sum of the quarterly earnings per share amounts may not equal the annual amounts reported. |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001234452-14-000320:notes:170]
Unallocated acquisition-related expenses were comprised as follows (in millions):

[0001234452-14-000320:notes:171]
|  | 2014 |  | 2013 |  | 2012 |
| Cost of equipment and services revenues | $ | 251 |  |  | $ | 264 |  |  | $ | 225 |  |
| Research and development expenses | 30 |  |  | 3 |  |  | — |  |
| Selling, general and administrative expenses | 25 |  |  | 26 |  |  | 43 |  |

[0001234452-14-000320:notes:172]
Other reconciling items were comprised as follows (in millions):

[0001234452-14-000320:notes:173]
|  | 2014 |  | 2013 |  | 2012 |
| Revenues |  |  |  |  |  |
| Nonreportable segments | $ | 258 |  |  | $ | 601 |  |  | $ | 657 |  |
| Intersegment eliminations | (5 | ) |  | (4 | ) |  | (4 | ) |
|  | $ | 253 |  |  | $ | 597 |  |  | $ | 653 |  |
| EBT |  |  |  |  |  |
| Unallocated cost of equipment and services revenues | $ | (300 | ) |  | $ | (335 | ) |  | $ | (300 | ) |
| Unallocated research and development expenses | (860 | ) |  | (789 | ) |  | (702 | ) |
| Unallocated selling, general and administrative expenses | (412 | ) |  | (502 | ) |  | (549 | ) |
| Unallocated other income (expense) | 142 |  |  | (173 | ) |  | — |  |
| Unallocated investment income, net | 1,213 |  |  | 877 |  |  | 928 |  |
| Nonreportable segments | (1,395 | ) |  | (719 | ) |  | (526 | ) |
|  | $ | (1,612 | ) |  | $ | (1,641 | ) |  | $ | (1,149 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001234452-14-000320:notes:174]
Note 10. Deconsolidation of and Retained Investment in the BWA Subsidiaries

[0001234452-14-000320:notes:175]
In fiscal 2010, the Company established subsidiaries in India to operate a wireless network using Broadband Wireless Access (BWA) spectrum (the BWA subsidiaries). In June 2012, Bharti Airtel Limited (Bharti), an Indian wireless network operator, purchased shares in the BWA subsidiaries that were held by two third-party Indian investors, and the BWA subsidiaries issued additional equity interests to Bharti for $85 million, reducing the Company’s ownership interest in each of the BWA subsidiaries to 51%. On June 25, 2013, the BWA subsidiaries issued additional equity interests to Bharti for $11 million, further reducing the Company’s ownership interests to 49%, and redeemed all of the outstanding debentures using funding provided by Bharti through subordinated debt (Note 7). Also, Bharti gained additional power over significant activities through certain leadership changes. These events resulted in a change in control of the BWA subsidiaries and therefore, the BWA subsidiaries were deconsolidated from the Company’s financial statements. Prior to the deconsolidation, the assets and liabilities of the BWA subsidiaries were classified as held for sale.

[0001234452-14-000320:notes:176]
As a result of the deconsolidation, the Company recognized a gain in net investment income of $6 million measured as the difference between (a) the net fair values of the retained noncontrolling investment and the Company’s guarantee of the former BWA subsidiaries’ bank loans (Note 7) and (b) the carrying values of the former BWA subsidiaries’ net assets, including cumulative translation losses and noncontrolling interests. Total assets and total liabilities were reduced by $1.0 billion and $999 million, respectively. Such assets and liabilities consisted primarily of wireless spectrum, network-related assets and loan obligations. The deconsolidation of these amounts represented a noncash investing and noncash financing transaction and was not reflected in the statement of cash flows for fiscal 2013. The fair value of the Company’s retained noncontrolling investment of $34 million was determined by applying a discounted cash flow valuation model to the estimated cash proceeds that the Company expected to receive upon the sale of its interest to Bharti.

[0001234452-14-000320:notes:177]
The former BWA subsidiaries were merged into one entity on August 5, 2013. On August 30, 2013, the remaining former BWA subsidiary repaid all of the outstanding loans, excluding the DoT loan, using funding provided by Bharti in the form of subordinated debt (Note 7). Also on August 30, 2013, Bharti converted the subordinated debt, and the former BWA subsidiary issued additional equity interests to Bharti, further reducing the Company’s ownership interest to 7%. On October 15, 2013, the DoT loan was repaid using funding provided by Bharti (Note 7), and on October 17, 2013, Bharti acquired all of the Company’s interest in the remaining former subsidiary.


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001234452-14-000320:notes:178]
| Accounts Receivable (in millions) | September 28, 2014 |  | September 29, 2013 |
| Trade, net of allowances for doubtful accounts of $5 and $2, respectively | $ | 2,362 |  |  | $ | 2,066 |  |
| Long-term contracts | 17 |  |  | 27 |  |
| Other | 33 |  |  | 49 |  |
|  | $ | 2,412 |  |  | $ | 2,142 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001234452-14-000320:notes:179]
Goodwill was allocable to reporting units included in the Company’s reportable and nonreportable segments, as described in Note 8, as follows (in millions):

[0001234452-14-000320:notes:180]
|  | September 28, 2014 |  | September 29, 2013 |
| QCT | $ | 3,467 |  |  | $ | 2,875 |  |
| QTL | 712 |  |  | 706 |  |
| Nonreportable segments | 309 |  |  | 395 |  |
|  | $ | 4,488 |  |  | $ | 3,976 |  |

[0001234452-14-000320:notes:181]
The increase in goodwill from September 29, 2013 to September 28, 2014 was the result of business acquisitions (Note 9), partially offset by impairments (Notes 2 and 12). Cumulative goodwill impairments were $260 million at September 28, 2014.


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001234452-14-000320:notes:182]
The components of other intangible assets, net were as follows (in millions):

[0001234452-14-000320:notes:183]
|  | September 28, 2014 |  | September 29, 2013 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Gross CarryingAmount |  | AccumulatedAmortization |
| Wireless spectrum | $ | 18 |  |  | $ | (9 | ) |  | $ | 19 |  |  | $ | (8 | ) |
| Marketing-related | 78 |  |  | (47 | ) |  | 76 |  |  | (37 | ) |
| Technology-based | 4,460 |  |  | (1,956 | ) |  | 3,964 |  |  | (1,512 | ) |
| Customer-related | 85 |  |  | (49 | ) |  | 87 |  |  | (36 | ) |
|  | $ | 4,641 |  |  | $ | (2,061 | ) |  | $ | 4,146 |  |  | $ | (1,593 | ) |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001234452-14-000320:notes:184]
| Inventories (in millions) | September 28, 2014 |  | September 29, 2013 |
| Raw materials | $ | 1 |  |  | $ | 2 |  |
| Work-in-process | 656 |  |  | 631 |  |
| Finished goods | 801 |  |  | 669 |  |
|  | $ | 1,458 |  |  | $ | 1,302 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001234452-14-000320:notes:185]
|  | 2014 |  | 2013 |  | 2012 |
| China (including Hong Kong) | $ | 13,200 |  |  | $ | 12,288 |  |  | $ | 7,971 |  |
| South Korea | 6,172 |  |  | 4,983 |  |  | 4,203 |  |
| Taiwan | 2,876 |  |  | 2,683 |  |  | 2,648 |  |
| United States | 372 |  |  | 805 |  |  | 967 |  |
| Other foreign | 3,867 |  |  | 4,107 |  |  | 3,332 |  |
|  | $ | 26,487 |  |  | $ | 24,866 |  |  | $ | 19,121 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001234452-14-000320:notes:186]
|  | QCT |  | QTL |  | QSI |  | ReconcilingItems |  | Total |
| 2014 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 18,665 |  |  | $ | 7,569 |  |  | $ | — |  |  | $ | 253 |  |  | $ | 26,487 |  |
| EBT | 3,807 |  |  | 6,590 |  |  | (7 | ) |  | (1,612 | ) |  | 8,778 |  |
| Total assets | 3,639 |  |  | 161 |  |  | 484 |  |  | 44,290 |  |  | 48,574 |  |
| 2013 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 16,715 |  |  | $ | 7,554 |  |  | $ | — |  |  | $ | 597 |  |  | $ | 24,866 |  |
| EBT | 3,189 |  |  | 6,590 |  |  | 56 |  |  | (1,641 | ) |  | 8,194 |  |
| Total assets | 3,305 |  |  | 28 |  |  | 511 |  |  | 41,672 |  |  | 45,516 |  |
| 2012 |  |  |  |  |  |  |  |  |  |
| Revenues | $ | 12,141 |  |  | $ | 6,327 |  |  | $ | — |  |  | $ | 653 |  |  | $ | 19,121 |  |
| EBT | 2,296 |  |  | 5,585 |  |  | (170 | ) |  | (1,149 | ) |  | 6,562 |  |
| Total assets | 2,278 |  |  | 63 |  |  | 1,424 |  |  | 39,247 |  |  | 43,012 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001234452-14-000320:notes:187]
SCHEDULE II

[0001234452-14-000320:notes:188]
QUALCOMM INCORPORATED

[0001234452-14-000320:notes:189]
VALUATION AND QUALIFYING ACCOUNTS

[0001234452-14-000320:notes:190]
(In millions)

[0001234452-14-000320:notes:191]
|  | Balance atBeginning ofPeriod |  | Charged(Credited) toCosts andExpenses |  | Deductions |  | Other |  | Balance atEnd ofPeriod |
| Year ended September 28, 2014 |  |  |  |  |  |  |  |  |  |
| Allowances: |  |  |  |  |  |  |  |  |  |
| — trade receivables | $ | 2 |  |  | $ | 5 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | 5 |  |
| — notes receivable | 10 |  |  | (3 | ) |  | (1 | ) |  | (2 | ) | (a) | 4 |  |
| Valuation allowance on deferred tax assets | 51 |  |  | 8 |  |  | — |  |  | 1 |  | (b) | 60 |  |
|  | $ | 63 |  |  | $ | 10 |  |  | $ | (3 | ) |  | $ | (1 | ) |  | $ | 69 |  |
| Year ended September 29, 2013 |  |  |  |  |  |  |  |  |  |
| Allowances: |  |  |  |  |  |  |  |  |  |
| — trade receivables | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |
| — notes receivable | 7 |  |  | 5 |  |  | — |  |  | (2 | ) | (a) | 10 |  |
| Valuation allowance on deferred tax assets | 142 |  |  | (15 | ) |  | — |  |  | (76 | ) | (c) | 51 |  |
|  | $ | 150 |  |  | $ | (9 | ) |  | $ | — |  |  | $ | (78 | ) |  | $ | 63 |  |
| Year ended September 30, 2012 |  |  |  |  |  |  |  |  |  |
| Allowances: |  |  |  |  |  |  |  |  |  |
| — trade receivables | $ | 2 |  |  | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | 1 |  |
| — notes receivable | 3 |  |  | 4 |  |  | — |  |  | — |  |  | 7 |  |
| Valuation allowance on deferred tax assets | 98 |  |  | 43 |  |  | — |  |  | 1 |  | (d) | 142 |  |
|  | $ | 103 |  |  | $ | 47 |  |  | $ | (1 | ) |  | $ | 1 |  |  | $ | 150 |  |

[0001234452-14-000320:notes:192]
| (a) | This amount relates to notes receivable on strategic investments that were converted to cost method equity investments. |

[0001234452-14-000320:notes:193]
| (b) | This amount was recorded to goodwill in connection with a business acquisition. |

[0001234452-14-000320:notes:194]
| (c) | This amount represents $88 million recorded as part of the gain on deconsolidation of certain subsidiaries, partially offset by $12 million recorded as a component of other comprehensive income. |

[0001234452-14-000320:notes:195]
| (d) | This amount was recorded as a component of other comprehensive income. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001234452-14-000320:notes:196]
Note 8. Segment Information

[0001234452-14-000320:notes:197]
The Company is organized on the basis of products and services. The Company aggregates two of its divisions into the QSI segment. Reportable segments are as follows:

[0001234452-14-000320:notes:198]
| • | QCT (Qualcomm CDMA Technologies) segment — develops and supplies integrated circuits and system software based on CDMA, OFDMA and other technologies for use in voice and data communications, networking, application processing, multimedia and global positioning system products. |

[0001234452-14-000320:notes:199]
| • | QTL (Qualcomm Technology Licensing) segment — grants licenses or otherwise provides rights to use portions of the Company’s intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products, including, without limitation, products implementing CDMA2000, WCDMA, CDMA TDD (including TD-SCDMA), GSM/GPRS/EDGE and/or OFDMA (including LTE) standards and their derivatives. |

[0001234452-14-000320:notes:200]
| • | QSI (Qualcomm Strategic Initiatives) segment — comprised of the Company’s Qualcomm Ventures and Structured Finance & Strategic Investments divisions. QSI makes strategic investments that are focused on opening new or expanding opportunities for its technologies and supporting the design and introduction of new products or services (or enhancing existing products or services) for voice and data communications. Many of these strategic investments are in early-stage companies. QSI also holds wireless spectrum. |

[0001234452-14-000320:notes:201]
During the first quarter of fiscal 2014, the Company reassessed its management reporting as a result of the sale of the North and Latin America operations of its Omnitracs division (Note 11), which comprised substantially all of the Omnitracs division, among other reasons. The Omnitracs division was previously aggregated with three other divisions into the Qualcomm Wireless & Internet (QWI) reportable segment. Starting in fiscal 2014, the QWI segment was eliminated, and revenues and operating results for the divisions that comprised the QWI reportable segment are included in nonreportable segments as components of reconciling items. Prior period segment information has been adjusted to conform to the new segment presentation.

[0001234452-14-000320:notes:202]
Nonreportable segments include the Company’s QMT (Qualcomm MEMS Technologies), Pixtronix and Small Cells divisions and other wireless technology and service initiatives. QMT plans to license its next generation IMOD display technology and to focus on wearable devices. Pixtronix develops and licenses display technologies based on MEMS (micro-electro-mechanical-systems)structure optimized for portable multimedia devices. Small Cells develops and supplies 3G/LTE and Wi-Fi products designed for implementation of small mobile base stations (known as small cells). Other nonreportable segments develop and offer products and services that include, but are not limited to: software products and content enablement services to wireless operators; development, other services and related products to U.S. government agencies and their contractors; device-to-device communication, including software for the connected home; data center; medical device connectivity and related data management; and augmented reality.

[0001234452-14-000320:notes:203]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT) from continuing operations. Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in the Company’s management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain net investment income; certain share-based compensation; and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories to fair value, amortization and impairment of certain intangible assets and certain other acquisition-related charges. The table below presents revenues, EBT and total assets for reportable segments (in millions):

[0001234452-14-000320:notes:204]
Intersegment revenues included in QCT revenues were negligible in all periods presented. All other revenues for reportable segments were from external customers for all periods presented.

[0001234452-14-000320:notes:205]
The Company reports revenues from external customers by country based on the location to which its products or services are delivered, which for QCT is generally the country in which its customers manufacture their products, or for licensing revenues, the invoiced addresses of its licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues could include revenues related to shipments of integrated circuits to a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States. Revenues by country were as follows (in millions):

[0001234452-14-000320:notes:206]
Interest income included in QSI EBT was negligible in fiscal 2014 and 2013 and was $19 million in fiscal 2012, and interest expense included in QSI EBT was negligible in fiscal 2014 and was $18 million and $79 million in fiscal 2013 and 2012, respectively. Interest income and interest expense recorded by other segments were negligible in all periods presented. Effectively all equity in losses of investees (Note 3) was recorded in QSI in fiscal 2014, 2013 and 2012.

[0001234452-14-000320:notes:207]
Segment assets are comprised of accounts receivable and inventories for all reportable segments other than QSI. QSI segment assets include certain marketable securities, notes receivable, wireless spectrum, other investments and all assets of consolidated subsidiaries included in QSI. QSI assets at September 28, 2014, September 29, 2013 and September 30, 2012 included $18 million, $17 million and $11 million, respectively, related to investments in equity method investees. Reconciling items for total assets included $313 million, $892 million and $1.2 billion at September 28, 2014, September 29, 2013 and September 30, 2012, respectively, of goodwill and other assets related to the Company’s QMT division. Total segment assets also differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable securities, property, plant and equipment, deferred tax assets, intangible assets and assets of nonreportable segments. The net book values of long-lived tangible assets located outside of the United States were $288 million, $896 million and $1.1 billion at September 28, 2014, September 29, 2013 and September 30, 2012, respectively. The net book values of long-lived tangible assets located in the United States were $2.2 billion, $2.1 billion and $1.8 billion at September 28, 2014, September 29, 2013 and September 30, 2012, respectively.

[0001234452-14-000320:notes:208]
Nonreportable segments’ losses before taxes during fiscal 2014, 2013 and 2012 were primarily attributable to the Company’s QMT division, including $607 million, $158 million and $54 million in impairment charges, respectively (Note 2). Unallocated acquisition-related expenses were comprised as follows (in millions):


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001234452-14-000320:notes:209]
Note 5. Capital Stock

[0001234452-14-000320:notes:210]
Preferred Stock. The Company has 8,000,000 shares of preferred stock authorized for issuance in one or more series, at a par value of $0.0001 per share. In conjunction with the distribution of preferred share purchase rights, 4,000,000 shares of preferred stock are designated as Series A Junior Participating Preferred Stock, and such shares are reserved for issuance upon exercise of the preferred share purchase rights. At September 28, 2014 and September 29, 2013, no shares of preferred stock were outstanding.

[0001234452-14-000320:notes:211]
Preferred Share Purchase Rights Agreement. The Company has a Preferred Share Purchase Rights Agreement (Rights Agreement) to protect stockholders’ interests in the event of a proposed takeover of the Company. Under the original Rights Agreement, adopted on September 26, 1995, the Company declared a dividend of one preferred share purchase right (a Right) for each share of the Company’s common stock outstanding. Pursuant to the Rights Agreement, as amended and restated on December 7, 2006, each Right entitles the registered holder to purchase from the Company a one one-thousandth share of Series A Junior Participating Preferred Stock, $0.0001 par value per share, subject to adjustment for subsequent stock splits, at a purchase price of $180. The Rights are exercisable only if a person or group (an Acquiring Person) acquires beneficial ownership of 20% or more of the Company’s outstanding shares of common stock without approval of the Board of Directors. Upon exercise, holders, other than an Acquiring Person, will have the right, subject to termination, to receive the Company’s common stock or other securities, cash or other assets having a market value, as defined, equal to twice such purchase price. The Rights, which expire on September 25, 2015, are redeemable in whole, but not in part, at the Company’s option prior to the time such Rights are triggered for a price of $0.001 per Right.

[0001234452-14-000320:notes:212]
Stock Repurchase Program. On March 4, 2014, the Company announced a new stock repurchase program authorizing it to repurchase up to $7.8 billion of the Company’s common stock. This stock repurchase program replaced the previous $5.0 billion stock repurchase program announced on September 11, 2013. The stock repurchase program has no expiration date. Any shares repurchased are retired, and the amount paid in excess of par value is recorded to paid-in capital. During fiscal 2014, 2013 and 2012, the Company repurchased and retired 60,253,000, 71,696,000 and 23,893,000 shares of common stock, respectively, for $4.5 billion, $4.6 billion and $1.3 billion, respectively, before commissions. At September 28, 2014, approximately $5.3 billion remained authorized for repurchase under the Company’s stock repurchase program. Since September 28, 2014, the Company repurchased 8,595,000 shares of common stock for $638 million.

[0001234452-14-000320:notes:213]
During fiscal 2012, three put options that the Company sold on its own stock in connection with prior stock repurchase programs expired unexercised, and the Company recognized gains of $80 million in net investment income due to changes in the fair values of the put options. No put options were outstanding during fiscal 2014 and 2013.

[0001234452-14-000320:notes:214]
Dividends. Dividends charged to retained earnings in fiscal 2014, 2013 and 2012 were as follows (in millions, except per share data):

[0001234452-14-000320:notes:215]
On October 16, 2014, the Company announced a cash dividend of $0.42 per share of common stock, payable on December 18, 2014 to stockholders of record as of December 1, 2014, which will be reflected in the consolidated financial statements in the first quarter of fiscal 2015.


## us-gaap:SubsequentEventsTextBlock

[0001234452-14-000320:notes:216]
Note 14. Subsequent Event

[0001234452-14-000320:notes:217]
In October 2014, the Company announced that it had reached agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.5 billion based upon an exchange rate of USD: GBP 1.6057). CSR is an innovator in the development of multifunction semiconductor platforms and technologies for the auto, consumer and voice and music market segments. The acquisition complements the Company’s current offerings by adding products, channels and customers in the growth categories of the Internet of Everything and automotive infotainment, accelerating the Company’s presence and path to leadership. The acquisition is subject to a number of conditions, including receipt of United States and other regulatory approvals and the approval of CSR’s shareholders. Subject to the satisfaction of these conditions, the acquisition is expected to close by the end of the summer of 2015.


## qcom:CompositionOfCertainFinancialStatementCaptionsTextBlock

[0001234452-14-000320:notes:218]
Note 2. Composition of Certain Financial Statement Items

[0001234452-14-000320:notes:219]
During the first quarter of fiscal 2014, as a result of discussions with potential buyers and consideration of alternative uses for the separate asset groups that comprise one of the QMT division’s manufacturing facilities in Taiwan, the Company decreased its estimates of expected cash flows from those assets and recorded an impairment charge of $444 million in other expenses. The Company concluded that a triggering event had not occurred in the first quarter of fiscal 2014 that would have required impairment testing for its remaining QMT assets, including goodwill, as QMT’s licensing business plan did not utilize this manufacturing facility. During the third quarter of fiscal 2014, the Company updated QMT’s licensing business plan and related internal forecasts to reflect a further decrease in expected cash flows. The updated business plan reflects an acceleration of the Company’s plans to transition from QMT’s current generation technology to the licensing of its next generation IMOD (interferometric modulator) display technology and to focus on wearable devices. QMT will continue to make and sell current generation products for a period of time in support of certain existing customer requirements. As a result of this triggering event, the Company assessed the recoverability of the QMT division’s long-lived assets, performed a goodwill impairment test of the QMT reporting unit and recorded impairment charges of $64 million on property, plant and equipment and $100 million on goodwill, respectively, in other expenses. During fiscal 2013 and 2012, the Company recorded $158 million and $54 million in impairment charges on property, plant and equipment as a result of updates to internal forecasts that reflected reductions in expected cash flows. At September 28, 2014, the carrying values of the QMT division’s goodwill and property, plant and equipment were $35 million and $148 million, respectively, including $116 million in property, plant and equipment that was classified as held for sale and included in other assets.

[0001234452-14-000320:notes:220]
Depreciation and amortization expense related to property, plant and equipment for fiscal 2014, 2013 and 2012 was $609 million, $515 million and $427 million, respectively. The gross book values of property under capital leases included in buildings and improvements were $1 million and $18 million at September 28, 2014 and September 29, 2013, respectively. These capital leases principally related to base station towers and buildings.

[0001234452-14-000320:notes:221]
At September 28, 2014 and September 29, 2013, buildings and improvements and leasehold improvements that were leased to third parties or held for lease to third parties were negligible. Future minimum rental income on facilities leased to others is expected to be negligible.

[0001234452-14-000320:notes:222]
Goodwill and Other Intangible Assets. The Company allocates goodwill to its reporting units for annual impairment testing purposes. Goodwill was allocable to reporting units included in the Company’s reportable and nonreportable segments, as described in Note 8, as follows (in millions):

[0001234452-14-000320:notes:223]
All of these intangible assets are subject to amortization, other than acquired in-process research and development with carrying values of $55 million and $54 million at September 28, 2014 and September 29, 2013, respectively. Amortization expense related to these intangible assets was $543 million, $499 million and $473 million for fiscal 2014, 2013 and 2012, respectively. Amortization expense related to these intangible assets and acquired in-process research and development, beginning upon the expected completion of the underlying projects, is expected to be $521 million, $417 million, $302 million, $265 million and $242 million for fiscal 2015 to 2019, respectively, and $833 million thereafter.

[0001234452-14-000320:notes:224]
| Other Current Liabilities (in millions) | September 28, 2014 |  | September 29, 2013 |
| Customer incentives and other customer-related liabilities | $ | 1,777 |  |  | $ | 1,706 |  |
| Other | 466 |  |  | 613 |  |
|  | $ | 2,243 |  |  | $ | 2,319 |  |
