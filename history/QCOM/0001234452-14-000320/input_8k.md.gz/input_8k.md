# QCOM 8-K — 0001234452-14-000318 filed 2014-11-05

## item codes, every 8-K on or before 2014-11-05

- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2014-11-05

- none on or before 2014-11-05

## item 2.02 — earnings release, exhibit 99.1

[0001234452-14-000318:8k_2_02:1]
EX-99.1
2
qcom92814erex991.htm
EX 99.1

[0001234452-14-000318:8k_2_02:2]
QCOM 9.28.14 ER EX 99.1

[0001234452-14-000318:8k_2_02:3]
Exhibit 99.1

[0001234452-14-000318:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001234452-14-000318:8k_2_02:5]
Qualcomm Contact:

[0001234452-14-000318:8k_2_02:6]
Warren Kneeshaw

[0001234452-14-000318:8k_2_02:7]
Vice President, Investor Relations

[0001234452-14-000318:8k_2_02:8]
Phone: 1-858-658-4813

[0001234452-14-000318:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001234452-14-000318:8k_2_02:10]
Qualcomm Announces Fourth Quarter and Fiscal 2014 Results

[0001234452-14-000318:8k_2_02:11]
Fiscal 2014 Revenues $26.5 billion

[0001234452-14-000318:8k_2_02:12]
GAAP EPS $4.65, Non-GAAP EPS $5.27

[0001234452-14-000318:8k_2_02:13]
- Record Fiscal Year Results -

[0001234452-14-000318:8k_2_02:14]
SAN DIEGO - November 5, 2014 - Qualcomm Incorporated (Nasdaq:  QCOM), a leading developer and innovator of advanced wireless technologies, products and services, today announced results for the fiscal  fourth quarter and year ended September 28, 2014.

[0001234452-14-000318:8k_2_02:15]
“We are pleased to report another year of record financial performance as our 3G/4G LTE multimode and other advanced technologies continue to enable the growth of wireless data around the world, driven by our broad chipset roadmap,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “We are forecasting continued growth of global 3G/4G device shipments in calendar year 2015, particularly in emerging regions.  Our fiscal 2015 outlook reflects continued LTE leadership in our semiconductor business and is tempered by the issues we are facing in China related to our licensing business.  Through this time, we remain focused on building our technology leadership in smartphones, while pursuing opportunities to extend our solutions into adjacent areas.”

[0001234452-14-000318:8k_2_02:16]
GAAP Results

[0001234452-14-000318:8k_2_02:17]
Fourth Quarter Fiscal 2014*

[0001234452-14-000318:8k_2_02:18]
| • | Revenues: 1 $6.69 billion, up 3 percent year-over-year (y-o-y) and down 2 percent sequentially. |

[0001234452-14-000318:8k_2_02:19]
| • | Operating income: 1 $1.99 billion, up 25 percent y-o-y and down 4 percent sequentially. |

[0001234452-14-000318:8k_2_02:20]
| • | Net income: 2 $1.89 billion, up 26 percent y-o-y and down 15 percent sequentially. |

[0001234452-14-000318:8k_2_02:21]
| • | Diluted earnings per share: 2 $1.11, up 29 percent y-o-y and down 15 percent sequentially. |

[0001234452-14-000318:8k_2_02:22]
| • | Effective tax rate: 1 16 percent. |

[0001234452-14-000318:8k_2_02:23]
| • | Operating cash flow: $1.62 billion, down 36 percent y-o-y; 24 percent of revenues. |

[0001234452-14-000318:8k_2_02:24]
| • | Return of capital to stockholders: $1.90 billion, including $1.20 billion through repurchases of 15.6 million shares of common stock and $702 million, or $0.42 per share, of cash dividends paid. |

[0001234452-14-000318:8k_2_02:25]
__________________________

[0001234452-14-000318:8k_2_02:26]
1 Throughout this news release, revenues, operating expenses, operating income, earnings before tax (EBT) and effective tax rates are from continuing operations (i.e., before adjustments for noncontrolling interests and discontinued operations), unless otherwise stated.

[0001234452-14-000318:8k_2_02:27]
2 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests and discontinued operations), unless otherwise stated.

[0001234452-14-000318:8k_2_02:28]
Fiscal 2014*

[0001234452-14-000318:8k_2_02:29]
| • | Revenues: $26.49 billion, up 7 percent y-o-y. |

[0001234452-14-000318:8k_2_02:30]
| • | Operating income: $7.55 billion, up 4 percent y-o-y. |

[0001234452-14-000318:8k_2_02:31]
| • | Net income: $7.97 billion, up 16 percent y-o-y. |

[0001234452-14-000318:8k_2_02:32]
| • | Diluted earnings per share: $4.65, up 19 percent y-o-y. |

[0001234452-14-000318:8k_2_02:33]
| • | Effective tax rate: 14 percent. |

[0001234452-14-000318:8k_2_02:34]
| • | Operating cash flow: $8.89 billion, up 1 percent y-o-y; 34 percent of revenues. |

[0001234452-14-000318:8k_2_02:35]
| • | Return of capital to stockholders: $7.13 billion, including $4.55 billion through repurchases of 60.3 million shares of common stock and $2.59 billion, or $1.54 per share, of cash dividends paid. |

[0001234452-14-000318:8k_2_02:36]
Non-GAAP Results

[0001234452-14-000318:8k_2_02:37]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items and tax items.

[0001234452-14-000318:8k_2_02:38]
Fourth Quarter Fiscal 2014*

[0001234452-14-000318:8k_2_02:39]
| • | Revenues: $6.69 billion, up 3 percent y-o-y and down 2 percent sequentially. |

[0001234452-14-000318:8k_2_02:40]
| • | Operating income: $2.32 billion, up 20 percent y-o-y and down 4 percent sequentially. |

[0001234452-14-000318:8k_2_02:41]
| • | Net income: $2.14 billion, up 18 percent y-o-y and down 13 percent sequentially. |

[0001234452-14-000318:8k_2_02:42]
| • | Diluted earnings per share: $1.26, up 20 percent y-o-y and down 13 percent sequentially. |

[0001234452-14-000318:8k_2_02:43]
| • | Effective tax rate: 16 percent. |

[0001234452-14-000318:8k_2_02:44]
Fiscal 2014*

[0001234452-14-000318:8k_2_02:45]
| • | Revenues: $26.49 billion, up 7 percent y-o-y. |

[0001234452-14-000318:8k_2_02:46]
| • | Operating income: $8.93 billion, up 3 percent y-o-y. |

[0001234452-14-000318:8k_2_02:47]
| • | Net income: $9.03 billion, up 14 percent y-o-y. |

[0001234452-14-000318:8k_2_02:48]
| • | Diluted earnings per share: $5.27, up 17 percent y-o-y. |

[0001234452-14-000318:8k_2_02:49]
| • | Effective tax rate: 15 percent. |

[0001234452-14-000318:8k_2_02:50]
Detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001234452-14-000318:8k_2_02:51]
* The following should be considered in regards to the year-over-year and sequential comparisons:

[0001234452-14-000318:8k_2_02:52]
| • | The fiscal 2014 results included: |

[0001234452-14-000318:8k_2_02:53]
| • | $665 million gain, or $0.25 per share, in discontinued operations associated with the sale of substantially all of the operations of our Omnitracs division in the first quarter of fiscal 2014; |

[0001234452-14-000318:8k_2_02:54]
| • | $444 million charge, or $0.20 per share, that resulted from an impairment on long-lived assets related to our QMT (Qualcomm MEMS Technologies) division in the first quarter of fiscal 2014; |

[0001234452-14-000318:8k_2_02:55]
| • | $208 million of income, or $0.12 per share, due to the reversal of expense accruals related to our litigation with ParkerVision in the third quarter of fiscal 2014; and |

[0001234452-14-000318:8k_2_02:56]
| • | $164 million of charges, or $0.08 per share, that resulted from an impairment on goodwill and long-lived assets related to our QMT division in the third quarter of fiscal 2014. |

[0001234452-14-000318:8k_2_02:57]
| • | The fiscal 2013 results included: |

[0001234452-14-000318:8k_2_02:58]
| • | $158 million charge, or $0.06 per share, that resulted from an impairment on long-lived assets related to our QMT division in the third quarter of fiscal 2013; and |

[0001234452-14-000318:8k_2_02:59]
| • | $173 million charge, or $0.10 per share, related to the verdict in our litigation with ParkerVision in the fourth quarter of fiscal 2013. |

[0001234452-14-000318:8k_2_02:60]
Key Business Metrics

[0001234452-14-000318:8k_2_02:61]
Fourth Quarter Fiscal 2014

[0001234452-14-000318:8k_2_02:62]
| • | MSMTM chip shipments: 236 million units, up 24 percent y-o-y and 5 percent sequentially. |

[0001234452-14-000318:8k_2_02:63]
| • | June quarter total reported device sales: approximately $57.4 billion, down 5 percent y-o-y and 1 percent sequentially. |

[0001234452-14-000318:8k_2_02:64]
| • | Includes an estimated 256 to 260 million 3G/4G devices at an estimated average selling price of approximately $220 to $226 per unit. |

[0001234452-14-000318:8k_2_02:65]
Fiscal 2014

[0001234452-14-000318:8k_2_02:66]
| • | MSM chip shipments: 861 million units, up 20 percent y-o-y. |

[0001234452-14-000318:8k_2_02:67]
| • | Total reported device sales (September quarter through June quarter): approximately $243.6 billion, up 5 percent y-o-y. |

[0001234452-14-000318:8k_2_02:68]
| • | Includes an estimated 1,077 to 1,093 million 3G/4G devices at an estimated average selling price of approximately $222 to $228 per unit. |

[0001234452-14-000318:8k_2_02:69]
Cash and Marketable Securities

[0001234452-14-000318:8k_2_02:70]
Our cash, cash equivalents and marketable securities totaled $32.0 billion at the end of fiscal 2014, compared to $29.4 billion a year ago and $32.7 billion at the end of the third quarter of fiscal 2014.  On October 16, 2014, we announced a cash dividend of $0.42 per share payable on December 18, 2014 to stockholders of record as of December 1, 2014.  Since September 28, 2014, we repurchased and retired an additional 8.6 million shares of common stock for $638 million.

[0001234452-14-000318:8k_2_02:71]
In October 2014, we announced an agreement with CSR plc on the terms of a recommended cash offer to acquire the entire issued and to be issued ordinary share capital of CSR for £9.00 per ordinary share, which values the entire issued and to be issued share capital of CSR at approximately £1.6 billion (approximately $2.5 billion based upon an exchange rate of USD: GBP 1.6057).  The transaction is expected to close by the end of summer 2015, subject to the satisfaction of a number of conditions, including receipt of United States and other regulatory approvals and the approval of CSR’s shareholders.

[0001234452-14-000318:8k_2_02:72]
Research and Development

[0001234452-14-000318:8k_2_02:73]
| ($ in millions) | Non-GAAP |  | QSI |  | Share-Based Compensation |  | Acquisition-Related Items |  | GAAP |
| Fourth quarter fiscal 2014 | $ | 1,197 |  |  | $ | 1 |  |  | $ | 163 |  |  | $ | 3 |  |  | $ | 1,364 |  |
| As % of revenues | 18 | % |  |  |  |  |  |  |  | 20 | % |
| Fourth quarter fiscal 2013 | $ | 1,182 |  |  | $ | 1 |  |  | $ | 164 |  |  | $ | 1 |  |  | $ | 1,348 |  |
| As % of revenues | 18 | % |  |  |  |  |  |  |  | 21 | % |
| Year-over-year change ($) | 1 | % |  | N/M |  |  | (1 | %) |  | N/M |  |  | 1 | % |

[0001234452-14-000318:8k_2_02:74]
N/M - Not Meaningful

[0001234452-14-000318:8k_2_02:75]
Non-GAAP research and development (R&D) expenses increased 1 percent y-o-y.  R&D expenses primarily consisted of costs related to the development of CDMA-based 3G, OFDMA-based 4G LTE and other technologies for integrated circuit and related software products and to expand our intellectual property portfolio.

[0001234452-14-000318:8k_2_02:76]
Selling, General and Administrative

[0001234452-14-000318:8k_2_02:77]
| ($ in millions) | Non-GAAP |  | QSI |  | Share-Based Compensation |  | Acquisition-Related Items |  | GAAP |
| Fourth quarter fiscal 2014 | $ | 458 |  |  | $ | 2 |  |  | $ | 78 |  |  | $ | 7 |  |  | $ | 545 |  |
| As % of revenues | 7 | % |  |  |  |  |  |  |  | 8 | % |
| Fourth quarter fiscal 2013 | $ | 547 |  |  | $ | 10 |  |  | $ | 94 |  |  | $ | 6 |  |  | $ | 657 |  |
| As % of revenues | 8 | % |  |  |  |  |  |  |  | 10 | % |
| Year-over-year change ($) | (16 | %) |  | (80 | %) |  | (17 | %) |  | 17 | % |  | (17 | %) |

[0001234452-14-000318:8k_2_02:78]
Non-GAAP selling, general and administrative (SG&A) expenses decreased 16 percent y-o-y primarily due to decreases in selling and marketing expenses, employee-related expenses and litigation and other legal matters.

[0001234452-14-000318:8k_2_02:79]
Effective Income Tax Rates

[0001234452-14-000318:8k_2_02:80]
Our fiscal 2014 annual effective income tax rates were 14 percent for GAAP and 15 percent for Non-GAAP, both of which included the United States federal R&D tax credit generated through December 31,

[0001234452-14-000318:8k_2_02:81]
2013, the date on which the credit expired.  The fiscal 2014 GAAP effective tax rate included a tax benefit of $66 million related to an agreement reached with the Internal Revenue Service on components of our fiscal 2013 tax return.  This benefit was excluded from our Non-GAAP results.

[0001234452-14-000318:8k_2_02:82]
Business Outlook

[0001234452-14-000318:8k_2_02:83]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment and certain derivative gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001234452-14-000318:8k_2_02:84]
Our outlook for fiscal 2015 diluted earnings per share includes an estimate of the benefit related to stock repurchases that we plan to complete over the course of fiscal 2015 under our current stock repurchase program.

[0001234452-14-000318:8k_2_02:85]
China continues to present significant opportunities for us, particularly with the rollout of 3G/4G LTE multimode, but also presents significant challenges, as our business practices continue to be the subject of an investigation by the China National Development and Reform Commission (NDRC).  Please refer to our Annual Report on Form 10-K for the year ended September 28, 2014 filed with the SEC for our most recent disclosures regarding the NDRC investigation.

[0001234452-14-000318:8k_2_02:86]
We also believe that certain licensees in China currently are not fully complying with their contractual obligations to report their sales of licensed products to us (which includes certain licensees underreporting a portion of their 3G/4G device sales and a dispute with a licensee) and that unlicensed companies may seek to delay execution of new licenses while the NDRC investigation is ongoing.  We expect calendar year 2014 and 2015 global 3G/4G device shipments to be approximately 1.3 billion and 1.5 billion, respectively.  However, our estimate of calendar year 2014 3G/4G device shipments that we currently expect to be reported to us is approximately 1.04 billion to 1.13 billion, which is adjusted for units that we believe may not be reported to us, are in dispute or are currently unlicensed.  We have not provided a forecast for calendar year 2015 reported 3G/4G device shipments at this time.  We are providing a

[0001234452-14-000318:8k_2_02:87]
guidance range for estimated 3G/4G total reported device sales that we currently expect to be reported to us in our fiscal 2015 (for sales by licensees in the September quarter of calendar 2014 through the June quarter of calendar 2015), which does not include sales that we believe may not be reported to us or may be in dispute but does include an estimate for some prior period activity that may be reported to us during fiscal 2015.  We are taking steps to address these issues, although the outcome and timing of any resolutions are uncertain.

[0001234452-14-000318:8k_2_02:88]
We have not included any estimates related to the proposed acquisition of CSR plc in our fiscal 2015 outlook. The acquisition is expected to close by the end of the summer of 2015.  We expect the acquisition to be accretive to Non-GAAP earnings per share in fiscal 2016, the first full year of combined operations.

[0001234452-14-000318:8k_2_02:89]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001234452-14-000318:8k_2_02:90]
Qualcomm’s Business Outlook Summary

[0001234452-14-000318:8k_2_02:91]
| FIRST FISCAL QUARTER |
|  |  | Q1 FY14Results | Current Guidance Q1 FY15 Estimates |
|  | Revenues |  | $6.62 | B | $6.6B - $7.2B |  |
|  | Year-over-year change |  | even - increase 9% |  |
|  | Non-GAAP diluted earnings per share (EPS) |  | $1.26 |  | $1.18 - $1.30 |  |
|  | Year-over-year change |  | decrease 6% - increase 3% |  |
|  | Diluted EPS attributable to QSI |  | $0.00 |  |  | $0.00 |  |
|  | Diluted EPS attributable to share-based compensation |  | ($0.13 | ) |  | ($0.14 | ) |
|  | Diluted EPS attributable to acquisition-related items |  | ($0.04 | ) |  | ($0.04 | ) |
|  | GAAP diluted EPS |  | $1.09 |  | $1.00 - $1.12 |  |
|  | Year-over-year change |  | decrease 8% - increase 3% |  |
|  | Metrics |  |  |
|  | MSM chip shipments | 213M |  | 250M - 270M |  |
|  | Year-over-year change |  | increase 17% - 27% |  |
|  | Total reported device sales* (1) | approx. $61.6B |  | approx. $53.0B - $59.0B (3) |  |
|  | Year-over-year change |  | decrease 4% - 14% |  |
|  | *Est. sales in September quarter, reported in December quarter |  |  |

[0001234452-14-000318:8k_2_02:92]
| FISCAL YEAR |
|  |  | FY 2014 Results | Current Guidance FY 2015 Estimates (2) |
|  | Revenues |  | $26.49 | B | $26.8B - $28.8B |  |
|  | Year-over-year change |  | increase 1% - 9% |  |
|  | Non-GAAP operating income |  | $8.93 | B | $9.2B - $10.0B |  |
|  | Year-over-year change |  | increase 3% - 12% |  |
|  | Operating (loss) income attributable to QSI |  | ($0.02B) |  | $0.0B |  |
|  | Operating loss attributable to share-based compensation |  | ($1.06B) |  | ($1.1B) |  |
|  | Operating loss attributable to acquisition-related items |  | ($0.31B) |  | ($0.3B) |  |
|  | GAAP operating income |  | $7.55 | B | $7.8B - $8.6B |  |
|  | Year-over-year change |  | increase 3% - 14% |  |
|  | Non-GAAP diluted EPS |  | $5.27 |  | $5.05 - $5.35 |  |
|  | Year-over-year change |  | decrease 4% - increase 2% |  |
|  | Diluted EPS attributable to QSI |  | $0.01 |  |  | ($0.01 | ) |
|  | Diluted EPS attributable to share-based compensation |  | ($0.50 | ) |  | ($0.55 | ) |
|  | Diluted EPS attributable to acquisition-related items |  | ($0.17 | ) |  | ($0.16 | ) |
|  | Diluted EPS attributable to tax items |  | $0.04 |  | N/A |  |
|  | GAAP diluted EPS |  | $4.65 |  | $4.33 - $4.63 |  |
|  | Year-over-year change |  | decrease 7% - even |  |
|  | Metrics |  |  |
|  | Total reported device sales* (1) | approx. $243.6B |  | approx. $240.0B - $270.0B (3) |  |
|  | Year-over-year change |  | decrease 1% - increase 11% |  |
|  | *Est. sales in Sept. to June quarters, reported in Dec. to Sept. quarters |  |  |

[0001234452-14-000318:8k_2_02:93]
| CALENDAR YEAR Device Estimates (1) |
|  |  | Prior GuidanceCalendar 2014Estimates | Current GuidanceCalendar 2014Estimates |
|  | Est. 3G/4G device shipments |  |  |
|  | March quarter | approx. 250M - 254M | approx. 250M - 254M |
|  | June quarter | not provided | approx. 256M - 260M |
|  | September quarter | not provided | not provided |
|  | December quarter | not provided | not provided |
|  | Est. calendar year range (approx.) | 1,040M - 1,130M | 1,040M - 1,130M (4) |

[0001234452-14-000318:8k_2_02:94]
| (1) | Total reported device sales is the sum of all reported sales in U.S. dollars (as reported to us by our licensees) of all licensed CDMA-based, OFDMA-based and CDMA/OFDMA multimode subscriber devices (including handsets, modules, modem cards and other subscriber devices) by our licensees during a particular period (collectively, 3G/4G devices). The reported quarterly estimated ranges of average selling prices (ASPs) and unit shipments are determined based on the information as reported to us by our licensees during the relevant period and our own estimates of the selling prices and unit shipments for licensees that do not provide such information. Not all licensees report sales, selling prices and/or unit shipments the same way (e.g., some licensees report sales net of permitted deductions, including transportation, insurance, packing costs and other items, while other licensees report sales and then identify the amount of permitted deductions in their reports), and the way in which licensees report such information may change from time to time. In addition, certain licensees may not report (in the quarter in which they are contractually obligated to report) their sales of certain types of subscriber units, which (as a result of audits, legal actions or for other reasons) may be reported in a subsequent quarter. Accordingly, total reported device sales, estimated unit shipments and estimated ASPs for a particular period may include prior period activity that was not reported by the licensee until such particular period. |

[0001234452-14-000318:8k_2_02:95]
| (2) | Fiscal 2015 guidance includes an estimate of the benefit related to stock repurchases that we plan to complete over the course of fiscal 2015 under our current stock repurchase program. |

[0001234452-14-000318:8k_2_02:96]
| (3) | Our guidance range for the first quarter of fiscal 2015 and fiscal 2015 total reported device sales reflects estimated 3G/4G total reported device sales that we currently expect to be reported to us, which does not include sales that we believe may not be reported to us or may be in dispute and, for fiscal 2015, includes an estimate for some prior period activity that may be reported to us during fiscal 2015. |

[0001234452-14-000318:8k_2_02:97]
| (4) | We expect calendar year 2014 global 3G/4G device shipments to be approximately 1.3 billion. However, our estimate of calendar year 2014 3G/4G device shipments that we currently expect to be reported to us is approximately 1.04 billion to 1.13 billion, which is adjusted for units that we believe may not be reported to us, are in dispute or are currently unlicensed. |

[0001234452-14-000318:8k_2_02:98]
N/A - Not Applicable

[0001234452-14-000318:8k_2_02:99]
Sums may not equal totals due to rounding.

[0001234452-14-000318:8k_2_02:100]
Results of Business Segments

[0001234452-14-000318:8k_2_02:101]
The following table reconciles our Non-GAAP results to our GAAP results (in millions, except per share data):

[0001234452-14-000318:8k_2_02:102]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (1) (2) | Non-GAAP (3) | QSI (3) | Share-Based Compensation (3) | Acquisition-Related Items (3) | Tax Items | GAAP |
| Q4 - FISCAL 2014 |  |
| Revenues | $4,849 | $1,795 | $48 | $6,692 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $6,692 |  |
| Change from prior year | 9 | % | (4 | %) | (68 | %) | 3 | % |  |  |  |  |  |  | 3 | % |  |
| Change from prior quarter | (2 | %) | — | % | 4 | % | (2 | %) |  |  |  |  |  |  | (2 | %) |  |
| Operating income (loss) |  |  |  | $2,323 |  | ($3) | ($252) | ($76) |  | $— |  |  | $1,992 |  |
| Change from prior year |  |  |  | 20 | % |  | 73 | % | 8 | % | (13 | %) |  |  | 25 | % |  |
| Change from prior quarter |  |  |  | (4 | %) |  | 40 | % | 8 | % | (7 | %) |  |  |  | (4 | %) |  |
| EBT | $1,045 | $1,536 | ($30) | $2,551 |  | $29 | ($252) | ($76) |  | $— |  |  | $2,252 |  |
| Change from prior year | 49 | % | (5 | %) | 80 | % | 17 | % |  | N/M |  | 8 | % | (13 | %) |  |  |  | 24 | % |  |
| Change from prior quarter | (6 | %) | (1 | %) | N/M |  | (10 | %) |  | N/M |  | 8 | % | (7 | %) |  |  |  | (10 | %) |  |
| EBT as % of revenues | 22 | % | 86 | % | N/M |  | 38 | % |  |  |  |  |  |  | 34 | % |  |
| Net income (loss) |  |  |  | $2,143 |  | $28 | ($199) | ($78) |  | $— |  |  | $1,894 |  |
| Change from prior year |  |  |  | 18 | % |  | N/M |  | 12 | % | (16 | %) | N/A |  |  | 26 | % |  |
| Change from prior quarter |  |  |  | (13 | %) |  | N/M |  | 14 | % | (18 | %) | N/M |  |  | (15 | %) |  |
| Diluted EPS |  |  |  | $1.26 |  | $0.02 | ($0.12) | ($0.05) |  | $— |  |  | $1.11 |  |
| Change from prior year |  |  |  | 20 | % |  | N/M |  | 8 | % | (25 | %) | N/A |  |  | 29 | % |  |
| Change from prior quarter |  |  |  | (13 | %) |  | N/M |  | 14 | % | (25 | %) | N/M |  |  | (15 | %) |  |
| Diluted shares used |  |  |  | 1,701 |  | 1,701 | 1,701 | 1,701 | 1,701 |  | 1,701 |  |
| Q3 - FISCAL 2014 |  |
| Revenues | $4,957 | $1,803 | $46 | $6,806 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $6,806 |  |
| Operating income (loss) |  |  |  | 2,425 |  | (5) | (274) | (71) | — |  |  | 2,075 |  |
| EBT | $1,116 | $1,550 | $177 | 2,843 |  | (1) | (274) | (71) | — |  |  | 2,497 |  |
| Net income (loss) |  |  |  | 2,470 |  | — |  | (232) | (66) | 66 |  |  | 2,238 |  |
| Diluted EPS |  |  |  | $1.44 |  | $0.00 | ($0.14) | ($0.04) | $0.04 |  | $1.31 |  |
| Diluted shares used |  |  |  | 1,714 |  | 1,714 | 1,714 | 1,714 | 1,714 |  | 1,714 |  |
| Q4 - FISCAL 2013 |  |
| Revenues | $4,457 | $1,874 | $149 | $6,480 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $6,480 |  |
| Operating income (loss) |  |  |  | 1,940 |  | (11) | (274) | (67) | — |  |  | 1,588 |  |
| EBT | $702 | $1,622 | ($151) | 2,173 |  | (11) | (274) | (67) | — |  |  | 1,821 |  |
| Net income (loss) |  |  |  | 1,818 |  | (24) | (226) | (67) | — |  |  | 1,501 |  |
| Diluted EPS |  |  |  | $1.05 |  | ($0.01) | ($0.13) | ($0.04) |  | $— |  |  | $0.86 |  |
| Diluted shares used |  |  |  | 1,738 |  | 1,738 | 1,738 | 1,738 | 1,738 |  | 1,738 |  |
| Q1 - FISCAL 2014 |  |
| Revenues | $4,616 | $1,900 | $106 | $6,622 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $6,622 |  |
| Operating income (loss) |  |  |  | 1,848 |  | (5) | (281) | (69) | — |  |  | 1,493 |  |
| EBT | $906 | $1,670 | ($473) | 2,103 |  | 4 | (281) | (69) | — |  |  | 1,757 |  |
| Discontinued operations, net of tax (4) |  |  |  | 430 |  | — |  | — |  | — |  | — |  |  | 430 |  |
| Net income (loss) |  |  |  | 2,163 |  | 4 | (226) | (66) | — |  |  | 1,875 |  |
| Diluted EPS |  |  |  | $1.26 |  | $0.00 | ($0.13) | ($0.04) |  | $— |  |  | $1.09 |  |
| Diluted shares used |  |  |  | 1,722 |  | 1,722 | 1,722 | 1,722 | 1,722 |  | 1,722 |  |

[0001234452-14-000318:8k_2_02:103]
| SEGMENTS | QCT | QTL | Non-GAAP Reconciling Items (1) (2) | Non-GAAP (3) | QSI (3) | Share-Based Compensation (3) | Acquisition-Related Items (3) | Tax Items | GAAP |
| 12 MONTHS - FISCAL 2014 |  |
| Revenues | $18,665 | $7,569 | $253 | $26,487 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $26,487 |  |
| Change from prior year | 12 | % | — | % | (58 | %) | 7 | % |  |  |  |  |  |  | 7 | % |  |
| Operating income (loss) |  |  |  | $8,933 |  | ($18) | ($1,059) | ($306) |  | $— |  |  | $7,550 |  |
| Change from prior year |  |  |  | 3 | % |  | 42 | % | 4 | % | (4 | %) |  |  | 4 | % |  |
| EBT | $3,807 | $6,590 | ($247) | $10,150 |  | ($7) | ($1,059) | ($306) |  | $— |  |  | $8,778 |  |
| Change from prior year | 19 | % | — | % | (1 | %) | 6 | % |  | N/M |  | 4 | % | (4 | %) |  |  | 7 | % |  |
| EBT as % of revenues | 20 | % | 87 | % | N/M |  | 38 | % |  |  |  |  |  |  | 33 | % |  |
| Discontinued operations, net of tax (4) |  |  |  | $430 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $430 |  |
| Net income (loss) |  |  |  | $9,032 |  | $15 | ($856) | ($290) | $66 |  | $7,967 |  |
| Change from prior year |  |  |  | 14 | % |  | (65 | %) | 3 | % | (4 | %) | 3 | % |  | 16 | % |  |
| Diluted EPS |  |  |  | $5.27 |  | $0.01 | ($0.50) | ($0.17) | $0.04 |  | $4.65 |  |
| Change from prior year |  |  |  | 17 | % |  | (50 | %) | 2 | % | (6 | %) | — | % |  | 19 | % |  |
| Diluted shares used |  |  |  | 1,714 |  | 1,714 | 1,714 | 1,714 | 1,714 |  | 1,714 |  |
| 12 MONTHS - FISCAL 2013 |  |
| Revenues | $16,715 | $7,554 | $597 | $24,866 |  |  | $— |  |  | $— |  |  | $— |  |  | $— |  |  | $24,866 |  |
| Operating income (loss) |  |  |  | 8,657 |  | (31) | (1,103) | (293) | — |  |  | 7,230 |  |
| EBT | $3,189 | $6,590 | ($245) | 9,534 |  | 56 | (1,103) | (293) | — |  |  | 8,194 |  |
| Net income (loss) |  |  |  | 7,911 |  | 43 | (886) | (279) | 64 |  | 6,853 |  |
| Diluted EPS |  |  |  | $4.51 |  | $0.02 | ($0.51) | ($0.16) | $0.04 |  | $3.91 |  |
| Diluted shares used |  |  |  | 1,754 |  | 1,754 | 1,754 | 1,754 | 1,754 |  | 1,754 |  |

[0001234452-14-000318:8k_2_02:104]
| (1) | Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations. Non-GAAP reconciling items related to earnings before taxes consisted primarily of certain research and development expenses, selling, general and administrative expenses, other expenses or income and certain investment income that are not allocated to the segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit. |

[0001234452-14-000318:8k_2_02:105]
| (2) | During the first quarter of fiscal 2014, as a result of the reassessment of management reporting, the former Qualcomm Wireless & Internet (QWI) segment was eliminated. Revenues and operating results for the divisions that comprised the QWI segment are included in Non-GAAP reconciling items. Prior period information has been adjusted to conform to the current presentation. |

[0001234452-14-000318:8k_2_02:106]
| (3) | At fiscal year end, the sum of the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is allocated to tax provisions (benefits) among the columns. |

[0001234452-14-000318:8k_2_02:107]
| (4) | During the first quarter of fiscal 2014, a gain of $665 million was recorded associated with the sale of substantially all of the operations of our Omnitracs division. |

[0001234452-14-000318:8k_2_02:108]
N/M - Not Meaningful

[0001234452-14-000318:8k_2_02:109]
N/A - Not Applicable

[0001234452-14-000318:8k_2_02:110]
Sums may not equal totals due to rounding.

[0001234452-14-000318:8k_2_02:111]
Conference Call

[0001234452-14-000318:8k_2_02:112]
Qualcomm’s fiscal fourth quarter and fiscal 2014 earnings conference call will be broadcast live on November 5, 2014, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 20823606.

[0001234452-14-000318:8k_2_02:113]
Note Regarding Use of Non-GAAP Financial Measures

[0001234452-14-000318:8k_2_02:114]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for, or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results are presented herein.

[0001234452-14-000318:8k_2_02:115]
The Company uses Non-GAAP financial information (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against each other and against competitors.  Non-GAAP measurements used by the Company include revenues, cost of equipment and services revenues, R&D expenses, SG&A expenses, operating income, net investment income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  As a result, management compensation decisions and the review of executive compensation by the Compensation Committee of the Board of Directors focus primarily on Non-GAAP financial measures applicable to the Company and its business segments.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.

[0001234452-14-000318:8k_2_02:116]
Non-GAAP information used by management excludes QSI and certain share-based compensation, acquisition-related items and tax items.

[0001234452-14-000318:8k_2_02:117]
| • | QSI is excluded because the Company expects to exit its strategic investments at various times, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001234452-14-000318:8k_2_02:118]
| • | Share-based compensation expense primarily relates to restricted stock units. Non-cash share-based compensation is excluded because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses. |

[0001234452-14-000318:8k_2_02:119]
| • | Acquisition-related items include amortization and impairment of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items starting with acquisitions completed in the third quarter of fiscal 2011, as well as any tax effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property. These acquisition-related items are excluded and are not allocated to the Company’s segments because management views such expenses as unrelated to the operating activities of the Company’s ongoing core businesses. In addition, these charges are impacted by the size and timing of acquisitions, potentially obscuring period-to-period comparisons of the Company’s operating businesses. |

[0001234452-14-000318:8k_2_02:120]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. |

[0001234452-14-000318:8k_2_02:121]
About Qualcomm

[0001234452-14-000318:8k_2_02:122]
Qualcomm Incorporated (Nasdaq:  QCOM) is a world leader in 3G, 4G and next-generation wireless technologies.  Qualcomm Incorporated includes Qualcomm’s licensing business, QTL, and the vast majority of its patent portfolio.  Qualcomm Technologies, Inc., a wholly-owned subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of Qualcomm’s engineering, research and development functions, and substantially all of its products and services businesses, including its semiconductor business, QCT.  For more than 25 years, Qualcomm ideas and inventions have driven the evolution of digital communications, linking people everywhere more closely to information, entertainment and each other.  For more information, visit www.qualcomm.com.

[0001234452-14-000318:8k_2_02:123]
Note Regarding Forward-Looking Statements

[0001234452-14-000318:8k_2_02:124]
###

[0001234452-14-000318:8k_2_02:125]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries.  All other trademarks are the property of their respective owners.

[0001234452-14-000318:8k_2_02:126]
Supplemental Information

[0001234452-14-000318:8k_2_02:127]
(Unaudited)

[0001234452-14-000318:8k_2_02:128]
| Three Months Ended September 28, 2014 |
|  | Non-GAAP Results | QSI | Share-Based Compensation | Acquisition-Related Items | GAAP Results |
| ($ in millions, except per share data) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Cost of equipment and services revenues |  | $ | 2,680 |  |  |  | $ | — |  |  |  | $ | 11 |  |  |  | $ | 66 |  |  |  | $ | 2,757 |  |  |
|  | R&D |  | 1,197 |  |  |  | 1 |  |  |  | 163 |  |  |  | 3 |  |  |  | 1,364 |  |  |
|  | SG&A |  | 458 |  |  |  | 2 |  |  |  | 78 |  |  |  | 7 |  |  |  | 545 |  |  |
|  | Other expenses |  | 34 |  | (a) |  | — |  |  |  | — |  |  |  | — |  |  |  | 34 |  |  |
|  | Operating income (loss) |  | 2,323 |  |  |  | (3 | ) |  |  | (252 | ) |  |  | (76 | ) |  |  | 1,992 |  |  |
|  | Investment income, net |  | $ | 228 |  | (b) |  | $ | 32 |  | (c) |  | $ | — |  |  |  | $ | — |  |  |  | $ | 260 |  |  |
|  | Tax rate |  | 16 | % |  |  | 7 | % |  |  | 21 | % |  |  | (3 | )% |  |  | 16 | % |  |
|  | Net income (loss) |  | $ | 2,143 |  |  |  | $ | 28 |  |  |  | $ | (199 | ) |  |  | $ | (78 | ) |  |  | $ | 1,894 |  |  |
|  | Diluted EPS |  | $ | 1.26 |  |  |  | $ | 0.02 |  |  |  | $ | (0.12 | ) |  |  | $ | (0.05 | ) |  |  | $ | 1.11 |  |  |

[0001234452-14-000318:8k_2_02:129]
| (a) | Included $19 million in restructuring-related costs incurred by our QMT division and a $15 million legal settlement. |

[0001234452-14-000318:8k_2_02:130]
| (b) | Included $125 million in interest and dividend income, $106 million in net realized gains on investments, $6 million in net gains on derivatives and $1 million in gains on deconsolidation of subsidiaries, partially offset by $7 million in other-than-temporary losses on investments, $2 million in equity in losses of investees and $1 million in interest expense. |

[0001234452-14-000318:8k_2_02:131]
| (c) | Included $35 million in net realized gains on investments and $1 million in interest and dividend income, partially offset by $2 million in other-than-temporary losses on investments and $2 million in equity in losses of investees. |

[0001234452-14-000318:8k_2_02:132]
| Twelve Months Ended September 28, 2014 |
|  | Non-GAAP Results | QSI | Share-Based Compensation | Acquisition-Related Items | Tax Items (d) | GAAP Results |
| ($ in millions, except per share data) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Cost of equipment and services revenues |  | $ | 10,386 |  |  |  | $ | — |  |  |  | $ | 49 |  |  |  | $ | 251 |  |  |  | $ | — |  |  |  | $ | 10,686 |  |  |
|  | R&D |  | 4,770 |  |  |  | 5 |  |  |  | 672 |  |  |  | 30 |  |  |  | — |  |  |  | 5,477 |  |  |
|  | SG&A |  | 1,914 |  |  |  | 13 |  |  |  | 338 |  |  |  | 25 |  |  |  | — |  |  |  | 2,290 |  |  |
|  | Other expenses, net |  | 484 |  | (e) |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 484 |  |  |
|  | Operating income (loss) |  | 8,933 |  |  |  | (18 | ) |  |  | (1,059 | ) |  |  | (306 | ) |  |  | — |  |  |  | 7,550 |  |  |
|  | Investment income, net |  | $ | 1,217 |  | (f) |  | $ | 11 |  | (g) |  | $ | — |  |  |  | $ | — |  |  |  | $ | — |  |  |  | $ | 1,228 |  |  |
|  | Tax rate |  | 15 | % |  |  | N/M |  |  |  | 19 | % |  |  | 5 | % |  |  | N/A |  |  |  | 14 | % |  |
|  | Net income (loss) |  | $ | 9,032 |  |  |  | $ | 15 |  |  |  | $ | (856 | ) |  |  | $ | (290 | ) |  |  | $ | 66 |  |  |  | $ | 7,967 |  |  |
|  | Diluted EPS |  | $ | 5.27 |  |  |  | $ | 0.01 |  |  |  | $ | (0.50 | ) |  |  | $ | (0.17 | ) |  |  | $ | 0.04 |  |  |  | $ | 4.65 |  |  |

[0001234452-14-000318:8k_2_02:133]
| (d) | Included a $66 million tax benefit related to an agreement reached with the Internal Revenue Service on components of our fiscal 2013 tax return. |

[0001234452-14-000318:8k_2_02:134]
| (e) | Included $607 million in long-lived asset and goodwill impairment charges and $19 million in restructuring-related costs incurred by our QMT division, a $16 million goodwill impairment charge related to our former QRS (Qualcomm Retail Solutions) division and a $15 million legal settlement, partially offset by the reversal of a $173 million expense accrual recorded in fiscal 2013 related to our litigation with ParkerVision. |

[0001234452-14-000318:8k_2_02:135]
| (f) | Included $756 million in net realized gains on investments, $584 million in interest and dividend income, $7 million in net gains on derivatives and $6 million in gains on deconsolidation of subsidiaries, partially offset by $131 million in other-than-temporary losses on investments, $4 million in interest expense and $1 million in equity in losses of investees. |

[0001234452-14-000318:8k_2_02:136]
| (g) | Included $70 million in net realized gains on investments and $2 million in interest and dividend income, partially offset by $49 million in other-than-temporary losses on investments, $9 million in equity in losses of investees, $2 million in net losses on derivatives and $1 million in interest expense. |

[0001234452-14-000318:8k_2_02:137]
N/M - Not Meaningful

[0001234452-14-000318:8k_2_02:138]
N/A - Not Applicable

[0001234452-14-000318:8k_2_02:139]
Sums may not equal totals due to rounding.

[0001234452-14-000318:8k_2_02:140]
Reconciliation of Non-GAAP Tax Rates to GAAP Tax Rates (a)

[0001234452-14-000318:8k_2_02:141]
(Unaudited)

[0001234452-14-000318:8k_2_02:142]
| Three Months Ended September 28, 2014 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Acquisition-Related Items |  |  | GAAP Results |  |
| Income (loss) from continuing operations before income taxes |  | $ | 2,551 |  |  |  | $ | 29 |  |  |  | $ | (252 | ) |  |  | $ | (76 | ) |  |  | $ | 2,252 |  |  |
| Income tax (expense) benefit |  | (408 | ) |  |  | (2 | ) |  |  | 53 |  |  |  | (2 | ) |  |  | (359 | ) |  |
| Income (loss) from continuing operations |  | $ | 2,143 |  |  |  | $ | 27 |  |  |  | $ | (199 | ) |  |  | $ | (78 | ) |  |  | $ | 1,893 |  |  |
| Tax rate |  | 16 | % |  |  | 7 | % |  |  | 21 | % |  |  | (3 | )% |  |  | 16 | % |  |

[0001234452-14-000318:8k_2_02:143]
| Twelve Months Ended September 28, 2014 |
| ($ in millions) |  | Non-GAAP Results |  |  | QSI |  |  | Share-Based Compensation |  |  | Acquisition-Related Items |  |  | Tax Items (b) |  |  | GAAP Results |  |
| Income (loss) from continuing operations before income taxes |  | $ | 10,150 |  |  |  | $ | (7 | ) |  |  | $ | (1,059 | ) |  |  | $ | (306 | ) |  |  | $ | — |  |  |  | $ | 8,778 |  |  |
| Income tax (expense) benefit |  | (1,548 | ) |  |  | 19 |  |  |  | 203 |  |  |  | 16 |  |  |  | 66 |  |  |  | (1,244 | ) |  |
| Income (loss) from continuing operations |  | $ | 8,602 |  |  |  | $ | 12 |  |  |  | $ | (856 | ) |  |  | $ | (290 | ) |  |  | $ | 66 |  |  |  | $ | 7,534 |  |  |
| Tax rate |  | 15 | % |  |  | N/M |  |  |  | 19 | % |  |  | 5 | % |  |  | N/A |  |  |  | 14 | % |  |

[0001234452-14-000318:8k_2_02:144]
| (a) | At fiscal year end, the sum of the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is allocated to tax provisions (benefits) among the columns. |

[0001234452-14-000318:8k_2_02:145]
| (b) | During the third quarter of fiscal 2014, we recorded a $66 million tax benefit as a result of an agreement reached with the Internal Revenue Service on components of our fiscal 2013 tax return. |

[0001234452-14-000318:8k_2_02:146]
N/M - Not Meaningful

[0001234452-14-000318:8k_2_02:147]
N/A - Not Applicable

[0001234452-14-000318:8k_2_02:148]
Qualcomm Incorporated

[0001234452-14-000318:8k_2_02:149]
CONSOLIDATED BALANCE SHEETS

[0001234452-14-000318:8k_2_02:150]
(In millions, except per share data)

[0001234452-14-000318:8k_2_02:151]
(Unaudited)

[0001234452-14-000318:8k_2_02:152]
|  | September 28, 2014 |  | September 29, 2013 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 7,907 |  |  | $ | 6,142 |  |
| Marketable securities | 9,658 |  |  | 8,824 |  |
| Accounts receivable, net | 2,412 |  |  | 2,142 |  |
| Inventories | 1,458 |  |  | 1,302 |  |
| Deferred tax assets | 577 |  |  | 573 |  |
| Other current assets | 401 |  |  | 572 |  |
| Total current assets | 22,413 |  |  | 19,555 |  |
| Marketable securities | 14,457 |  |  | 14,440 |  |
| Deferred tax assets | 1,174 |  |  | 1,059 |  |
| Property, plant and equipment, net | 2,487 |  |  | 2,995 |  |
| Goodwill | 4,488 |  |  | 3,976 |  |
| Other intangible assets, net | 2,580 |  |  | 2,553 |  |
| Other assets | 975 |  |  | 938 |  |
| Total assets | $ | 48,574 |  |  | $ | 45,516 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 2,183 |  |  | $ | 1,554 |  |
| Payroll and other benefits related liabilities | 802 |  |  | 839 |  |
| Unearned revenues | 785 |  |  | 501 |  |
| Other current liabilities | 2,243 |  |  | 2,319 |  |
| Total current liabilities | 6,013 |  |  | 5,213 |  |
| Unearned revenues | 2,967 |  |  | 3,666 |  |
| Other liabilities | 428 |  |  | 550 |  |
| Total liabilities | 9,408 |  |  | 9,429 |  |
| Stockholders’ equity: |  |  |  |
| Qualcomm stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,669 and 1,685 shares issued and outstanding, respectively | 7,736 |  |  | 9,874 |  |
| Retained earnings | 30,799 |  |  | 25,461 |  |
| Accumulated other comprehensive income | 634 |  |  | 753 |  |
| Total Qualcomm stockholders’ equity | 39,169 |  |  | 36,088 |  |
| Noncontrolling interests | (3 | ) |  | (1 | ) |
| Total stockholders’ equity | 39,166 |  |  | 36,087 |  |
| Total liabilities and stockholders’ equity | $ | 48,574 |  |  | $ | 45,516 |  |

[0001234452-14-000318:8k_2_02:153]
Qualcomm Incorporated

[0001234452-14-000318:8k_2_02:154]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001234452-14-000318:8k_2_02:155]
(In millions, except per share data)

[0001234452-14-000318:8k_2_02:156]
(Unaudited)

[0001234452-14-000318:8k_2_02:157]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 28, 2014 |  | September 29, 2013 |  | September 28, 2014 |  | September 29, 2013 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 4,822 |  |  | $ | 4,513 |  |  | $ | 18,625 |  |  | $ | 16,988 |  |
| Licensing | 1,870 |  |  | 1,967 |  |  | 7,862 |  |  | 7,878 |  |
| Total revenues | 6,692 |  |  | 6,480 |  |  | 26,487 |  |  | 24,866 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of equipment and services revenues | 2,757 |  |  | 2,714 |  |  | 10,686 |  |  | 9,820 |  |
| Research and development | 1,364 |  |  | 1,348 |  |  | 5,477 |  |  | 4,967 |  |
| Selling, general and administrative | 545 |  |  | 657 |  |  | 2,290 |  |  | 2,518 |  |
| Other | 34 |  |  | 173 |  |  | 484 |  |  | 331 |  |
| Total costs and expenses | 4,700 |  |  | 4,892 |  |  | 18,937 |  |  | 17,636 |  |
| Operating income | 1,992 |  |  | 1,588 |  |  | 7,550 |  |  | 7,230 |  |
| Investment income, net | 260 |  |  | 233 |  |  | 1,228 |  |  | 964 |  |
| Income from continuing operations before income taxes | 2,252 |  |  | 1,821 |  |  | 8,778 |  |  | 8,194 |  |
| Income tax expense | (359 | ) |  | (320 | ) |  | (1,244 | ) |  | (1,349 | ) |
| Income from continuing operations | 1,893 |  |  | 1,501 |  |  | 7,534 |  |  | 6,845 |  |
| Discontinued operations, net of income taxes | — |  |  | — |  |  | 430 |  |  | — |  |
| Net income | 1,893 |  |  | 1,501 |  |  | 7,964 |  |  | 6,845 |  |
| Net loss attributable to noncontrolling interests | 1 |  |  | — |  |  | 3 |  |  | 8 |  |
| Net income attributable to Qualcomm | $ | 1,894 |  |  | $ | 1,501 |  |  | $ | 7,967 |  |  | $ | 6,853 |  |
| Basic earnings per share attributable to Qualcomm: |  |  |  |  |  |  |  |
| Continuing operations | $ | 1.13 |  |  | $ | 0.88 |  |  | $ | 4.48 |  |  | $ | 3.99 |  |
| Discontinued operations | — |  |  | — |  |  | 0.25 |  |  | — |  |
| Net income | $ | 1.13 |  |  | $ | 0.88 |  |  | $ | 4.73 |  |  | $ | 3.99 |  |
| Diluted earnings per share attributable to Qualcomm: |  |  |  |  |  |  |  |
| Continuing operations | $ | 1.11 |  |  | $ | 0.86 |  |  | $ | 4.40 |  |  | $ | 3.91 |  |
| Discontinued operations | — |  |  | — |  |  | 0.25 |  |  | — |  |
| Net income | $ | 1.11 |  |  | $ | 0.86 |  |  | $ | 4.65 |  |  | $ | 3.91 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,674 |  |  | 1,703 |  |  | 1,683 |  |  | 1,715 |  |
| Diluted | 1,701 |  |  | 1,738 |  |  | 1,714 |  |  | 1,754 |  |
| Dividends per share announced | $ | 0.42 |  |  | $ | 0.35 |  |  | $ | 1.54 |  |  | $ | 1.20 |  |

[0001234452-14-000318:8k_2_02:158]
Qualcomm Incorporated

[0001234452-14-000318:8k_2_02:159]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001234452-14-000318:8k_2_02:160]
(In millions)

[0001234452-14-000318:8k_2_02:161]
(Unaudited)

[0001234452-14-000318:8k_2_02:162]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 28, 2014 |  | September 29, 2013 |  | September 28, 2014 |  | September 29, 2013 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,894 |  |  | $ | 1,501 |  |  | $ | 7,964 |  |  | $ | 6,845 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 297 |  |  | 273 |  |  | 1,150 |  |  | 1,017 |  |
| Gain on sale of discontinued operations | — |  |  | — |  |  | (665 | ) |  | — |  |
| Long-lived asset and goodwill impairment charges | — |  |  | 1 |  |  | 642 |  |  | 192 |  |
| Income tax provision in excess of income tax payments | 54 |  |  | 48 |  |  | 298 |  |  | 268 |  |
| Non-cash portion of share-based compensation expense | 252 |  |  | 274 |  |  | 1,059 |  |  | 1,105 |  |
| Incremental tax benefit from share-based compensation | (41 | ) |  | (53 | ) |  | (280 | ) |  | (231 | ) |
| Net realized gains on marketable securities and other investments | (141 | ) |  | (129 | ) |  | (826 | ) |  | (369 | ) |
| Impairment losses on marketable securities and other investments | 9 |  |  | 36 |  |  | 180 |  |  | 85 |  |
| Other items, net | (10 | ) |  | 52 |  |  | (17 | ) |  | (19 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (324 | ) |  | (235 | ) |  | (281 | ) |  | (680 | ) |
| Inventories | (271 | ) |  | 399 |  |  | (155 | ) |  | (300 | ) |
| Other assets | (28 | ) |  | (98 | ) |  | 108 |  |  | (209 | ) |
| Trade accounts payable | 298 |  |  | (291 | ) |  | 619 |  |  | 307 |  |
| Payroll, benefits and other liabilities | (280 | ) |  | 700 |  |  | (617 | ) |  | 752 |  |
| Unearned revenues | (90 | ) |  | 45 |  |  | (292 | ) |  | 15 |  |
| Net cash provided by operating activities | 1,619 |  |  | 2,523 |  |  | 8,887 |  |  | 8,778 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (230 | ) |  | (200 | ) |  | (1,185 | ) |  | (1,048 | ) |
| Purchases of available-for-sale securities | (3,266 | ) |  | (1,839 | ) |  | (13,581 | ) |  | (13,951 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 3,843 |  |  | 6,157 |  |  | 13,587 |  |  | 13,494 |  |
| Purchases of trading securities | (207 | ) |  | (654 | ) |  | (3,075 | ) |  | (3,312 | ) |
| Proceeds from sales and maturities of trading securities | 205 |  |  | 1,002 |  |  | 2,824 |  |  | 3,367 |  |
| Purchases of other marketable securities | — |  |  | — |  |  | (220 | ) |  | — |  |
| Proceeds from sale of discontinued operations, net of cash sold | — |  |  | — |  |  | 788 |  |  | — |  |
| Acquisitions and other investments, net of cash acquired | (436 | ) |  | (13 | ) |  | (883 | ) |  | (192 | ) |
| Other items, net | 4 |  |  | (4 | ) |  | 106 |  |  | 64 |  |
| Net cash (used) provided by investing activities | (87 | ) |  | 4,449 |  |  | (1,639 | ) |  | (1,578 | ) |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock | 292 |  |  | 561 |  |  | 1,439 |  |  | 1,525 |  |
| Incremental tax benefit from share-based compensation | 41 |  |  | 53 |  |  | 280 |  |  | 231 |  |
| Repurchases and retirements of common stock | (1,195 | ) |  | (3,321 | ) |  | (4,549 | ) |  | (4,610 | ) |
| Dividends paid | (702 | ) |  | (592 | ) |  | (2,586 | ) |  | (2,055 | ) |
| Borrowings under loans and debentures | — |  |  | — |  |  | — |  |  | 534 |  |
| Repayments of loans and debentures | — |  |  | — |  |  | — |  |  | (439 | ) |
| Other items, net | 1 |  |  | (66 | ) |  | (64 | ) |  | (31 | ) |
| Net cash used by financing activities | (1,563 | ) |  | (3,365 | ) |  | (5,480 | ) |  | (4,845 | ) |
| Changes in cash and cash equivalents held for sale | — |  |  | — |  |  | — |  |  | (15 | ) |
| Effect of exchange rate changes on cash | (6 | ) |  | 2 |  |  | (3 | ) |  | (5 | ) |
| Net (decrease) increase in cash and cash equivalents | (37 | ) |  | 3,609 |  |  | 1,765 |  |  | 2,335 |  |
| Cash and cash equivalents at beginning of year | 7,944 |  |  | 2,533 |  |  | 6,142 |  |  | 3,807 |  |
| Cash and cash equivalents at end of year | $ | 7,907 |  |  | $ | 6,142 |  |  | $ | 7,907 |  |  | $ | 6,142 |  |
