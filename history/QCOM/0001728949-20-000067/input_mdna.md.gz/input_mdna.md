# QCOM MD&A — 0001728949-20-000067


## mdna

[0001728949-20-000067:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001728949-20-000067:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated financial statements and related notes included in “Part II, Item 8. Financial Statements and Supplementary Data” of this Annual Report.

[0001728949-20-000067:mdna:3]
Fiscal 2020 Overview and Other Recent Events

[0001728949-20-000067:mdna:4]
Revenues were $23.5 billion, a decrease of 3% compared to revenues of $24.3 billion in fiscal 2019, with net income of $5.2 billion, an increase of 19% compared to net income of $4.4 billion in fiscal 2019. Highlights and other events from fiscal 2020 and other recent events included:

[0001728949-20-000067:mdna:5]
•The rapid, global spread of COVID-19 has negatively impacted consumer demand for certain devices that incorporate our products and intellectual property, which negatively impacted our business and results of operations in fiscal 2020. The impact of the COVID-19 pandemic on sales of devices that incorporate our products and intellectual property was most significant in the March 2020 and June 2020 quarters. The impact of COVID-19 on our ability to fulfill customer orders has been minimal. Workforce changes that we implemented in the second quarter of fiscal 2020 remained in effect throughout fiscal 2020.

[0001728949-20-000067:mdna:6]
•In July 2020, we entered into a settlement agreement with Huawei to resolve our prior dispute related to our license agreement that expired on December 31, 2019. We also entered into a new long-term, global patent license agreement that contains a cross license granting rights to certain of Huawei’s patents and applies to sales of certain wireless products by Huawei beginning on January 1, 2020. Amounts due under the settlement agreement (which are incremental to the $1.2 billion previously paid under two interim agreements) are to be paid in installments by the end of June 2021 in accordance with an agreed upon payment schedule. We recorded revenues of $1.8 billion in fiscal 2020, which were not allocated to our segment results, related to the amounts due from Huawei under the settlement agreement and royalties for sales made in the March 2020 and June 2020 quarters under the new global patent license agreement. In the fourth quarter of fiscal 2020, Huawei paid the first installment under the settlement agreement and the royalties due for the March 2020 and June 2020 quarters.

[0001728949-20-000067:mdna:7]
•QCT results in fiscal 2020 benefited from an increase in demand for 5G and IoT products, partially offset by the negative impact of COVID-19. Additionally, in the second half of fiscal 2020, QCT began shipments under the multi-year chipset supply agreement with Apple to support 2020 iPhone product launches.

[0001728949-20-000067:mdna:8]
•QTL results in fiscal 2020 benefited from the inclusion of a full year of royalties from Apple (as a result of the settlement with Apple and its contract manufacturers in April 2019) and an estimate of royalties due from Huawei for sales made in the September 2020 quarter, partially offset by the negative impact of COVID-19.

[0001728949-20-000067:mdna:9]
•We entered into new long-term, world-wide patent license agreements with Guangdong OPPO Mobile Telecommunications Corp., Ltd. (Oppo) and BBK Communication Technology Co., Ltd. (vivo) (who were previously disclosed as two key Chinese licensees), effective as of April 1, 2020. We also reached agreements with these licensees to provide for scheduled payments of amounts due under the license agreements that expired on March 31, 2020 and for which certain of such amounts for prior periods were withheld while good faith negotiations occurred. Oppo and vivo paid all such amounts due under the settlement agreements by the end of September 2020.

[0001728949-20-000067:mdna:10]
•In May 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the district court issued an Order ruling against us and imposing certain injunctive relief. On August 11, 2020, on appeal, the Ninth Circuit reversed the district court’s judgment, vacated its injunction and vacated its partial grant of summary judgment. On September 25, 2020, the FTC filed a Petition for Rehearing En Banc. On October 28, 2020, the Ninth Circuit denied the FTC’s petition.

[0001728949-20-000067:mdna:11]
•In fiscal 2020, we recorded $405 million in non-marketable investment impairments, a portion of which was due in part from the impacts of COVID-19 on certain of our investees.

[0001728949-20-000067:mdna:12]
Our Business and Operating Segments

[0001728949-20-000067:mdna:13]
We develop and commercialize foundational technologies and products used in mobile devices and other wireless products. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents and other rights.

[0001728949-20-000067:mdna:14]
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm

[0001728949-20-000067:mdna:15]
38

[0001728949-20-000067:mdna:16]
Technology Licensing) licensing business. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies), our cloud AI inference processing initiative and other technology and service initiatives.

[0001728949-20-000067:mdna:17]
Further information regarding our business and operating segments is provided in “Part I, Item 1. Business” of this Annual Report.

[0001728949-20-000067:mdna:18]
Seasonality. Many of our products and much of our intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. Our revenues have historically fluctuated based on consumer demand for devices, as well as on the timing of customer/licensee device launches and/or innovation cycles (such as the transition to the next generation of wireless technologies). This has resulted in fluctuations in QCT revenues in advance of and during device launches incorporating our products and in QTL revenues when the related royalties were recognized, which prior to fiscal 2019 was when licensees reported their sales and beginning in fiscal 2019 when the licensees’ sales occurred. Our historical trends were impacted by our prior dispute with Apple and its contract manufacturers (which was settled in April 2019). Looking forward, we expect QCT revenues to be impacted by seasonal trends related to product launch timing for sales made to Apple under our multi-year chipset supply agreement. These trends may or may not continue in the future and have been impacted by the decline in consumer demand resulting from COVID-19. Further, the trends for QTL have been, and may in the future be, impacted by disputes and/or resolutions with licensees and/or governmental investigations or proceedings, including the lawsuit filed against us by the FTC.

[0001728949-20-000067:mdna:19]
Results of Operations

[0001728949-20-000067:mdna:20]
| Revenues (in millions) |  |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |  | 2020 vs. 2019 Change |  | 2019 vs. 2018 Change |
| Equipment and services | $ | 16,298 |  |  | $ | 14,611 |  |  | $ | 17,400 |  |  | $ | 1,687 |  |  | $ | (2,789) |  |
| Licensing | 7,233 |  |  | 9,662 |  |  | 5,211 |  |  | (2,429) |  |  | 4,451 |  |
|  | $ | 23,531 |  |  | $ | 24,273 |  |  | $ | 22,611 |  |  | $ | (742) |  |  | $ | 1,662 |  |

[0001728949-20-000067:mdna:21]
2020 vs. 2019

[0001728949-20-000067:mdna:22]
The decrease in revenues in fiscal 2020 was primarily due to:

[0001728949-20-000067:mdna:23]
-    $4.7 billion in licensing revenues recorded in the third quarter of fiscal 2019 resulting from the settlement with Apple and its contract manufacturers (which were not allocated to our segment results)

[0001728949-20-000067:mdna:24]
-    $116 million in lower equipment and services revenues from our QSI segment

[0001728949-20-000067:mdna:25]
+    $1.8 billion in licensing revenues from Huawei recorded in the fourth quarter of fiscal 2020 resulting from amounts due under the settlement agreement and royalties for sales made in the March 2020 and June 2020 quarters under the new global patent license agreement (which were not allocated to our segment results)

[0001728949-20-000067:mdna:26]
+    $1.8 billion in higher equipment and services revenues from our QCT segment

[0001728949-20-000067:mdna:27]
+    $437 million in higher licensing revenues from our QTL segment

[0001728949-20-000067:mdna:28]
2019 vs. 2018

[0001728949-20-000067:mdna:29]
The increase in revenues in fiscal 2019 was primarily due to:

[0001728949-20-000067:mdna:30]
+    $4.7 billion in licensing revenues recorded in the third quarter of fiscal 2019 resulting from the settlement with Apple and its contract manufacturers

[0001728949-20-000067:mdna:31]
-    $2.7 billion in lower equipment and services revenues from our QCT segment

[0001728949-20-000067:mdna:32]
-    $451 million in lower licensing revenues from our QTL segment

[0001728949-20-000067:mdna:33]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |  | 2020 vs. 2019 Change |  | 2019 vs. 2018 Change |
| Cost of revenues | $ | 9,255 |  |  | $ | 8,599 |  |  | $ | 10,244 |  |  | $ | 656 |  |  | $ | (1,645) |  |
| Gross margin | 61 | % |  | 65 | % |  | 55 | % |  |  |  |  |

[0001728949-20-000067:mdna:34]
2020 vs. 2019

[0001728949-20-000067:mdna:35]
The decrease in margin percentage in fiscal 2020 was primarily due to:

[0001728949-20-000067:mdna:36]
-    lower licensing revenues resulting from the settlement with Apple and its contract manufacturers in fiscal 2019

[0001728949-20-000067:mdna:37]
+    higher licensing revenues from Huawei recorded in fiscal 2020 resulting from amounts due under the settlement agreement and royalties for sales made in the March 2020 and June 2020 quarters under the new global patent license agreement

[0001728949-20-000067:mdna:38]
2019 vs. 2018

[0001728949-20-000067:mdna:39]
The increase in margin percentage in fiscal 2019 was primarily due to:

[0001728949-20-000067:mdna:40]
+    higher licensing revenues resulting from the settlement with Apple and its contract manufacturers in fiscal 2019

[0001728949-20-000067:mdna:41]
|  | 2020 |  | 2019 |  | 2018 |  | 2020 vs. 2019 Change |  | 2019 vs. 2018 Change |
| Research and development | $ | 5,975 |  |  | $ | 5,398 |  |  | $ | 5,625 |  |  | $ | 577 |  |  | $ | (227) |  |
| % of revenues | 25 | % |  | 22 | % |  | 25 | % |  |  |  |  |

[0001728949-20-000067:mdna:42]
2020 vs. 2019

[0001728949-20-000067:mdna:43]
The increase in research and development expenses in fiscal 2020 was primarily due to:

[0001728949-20-000067:mdna:44]
+     $426 million increase driven by higher costs related to the development of wireless and integrated circuit technologies, including 5G and application processor technologies, partially offset by lower employee cash incentive program costs

[0001728949-20-000067:mdna:45]
+    $148 million in higher share-based compensation expense

[0001728949-20-000067:mdna:46]
2019 vs. 2018

[0001728949-20-000067:mdna:47]
The decrease in research and development expenses in fiscal 2019 was primarily due to:

[0001728949-20-000067:mdna:48]
-    $221 million decrease primarily driven by actions taken under our Cost Plan that concluded in fiscal 2019, partially offset by higher share-based compensation expense and higher employee cash incentive program costs

[0001728949-20-000067:mdna:49]
In fiscal 2018, all of the costs ($474 million) related to pre-commercial research and development of 5G technologies were included in unallocated corporate research and development expenses. Beginning in fiscal 2019, all research and development costs associated with 5G technologies were included in segment results. Additionally, beginning in fiscal 2019, certain research and development costs associated with early research and development that were historically included in our QCT segment were allocated to our QTL segment. The net effect of these changes negatively impacted QTL’s EBT by $489 million in fiscal 2019 and positively impacted QCT’s EBT by $160 million in fiscal 2019.

[0001728949-20-000067:mdna:50]
|  | 2020 |  | 2019 |  | 2018 |  | 2020 vs. 2019 Change |  | 2019 vs. 2018 Change |
| Selling, general and administrative | $ | 2,074 |  |  | $ | 2,195 |  |  | $ | 2,986 |  |  | $ | (121) |  |  | $ | (791) |  |
| % of revenues | 9 | % |  | 9 | % |  | 13 | % |  |  |  |  |

[0001728949-20-000067:mdna:51]
2020 vs. 2019

[0001728949-20-000067:mdna:52]
The decrease in selling, general and administrative expenses in fiscal 2020 was primarily due to:

[0001728949-20-000067:mdna:53]
-    $167 million in lower litigation costs, primarily resulting from the settlement of our prior dispute with Apple and its contract manufacturers in April 2019

[0001728949-20-000067:mdna:54]
+    $44 million in higher patent costs, primarily resulting from 5G patent filings

[0001728949-20-000067:mdna:55]
2019 vs. 2018

[0001728949-20-000067:mdna:56]
The decrease in selling, general and administrative expenses in fiscal 2019 was primarily due to:

[0001728949-20-000067:mdna:57]
-    $287 million in lower professional fees and costs, primarily driven by Broadcom’s withdrawn takeover proposal in fiscal 2018 and our then proposed acquisition of NXP Semiconductors N.V. (NXP) in fiscal 2018

[0001728949-20-000067:mdna:58]
-    $235 million in lower litigation costs, primarily resulting from the settlement of our prior dispute with Apple and its contract manufacturers and the end of the District Court trial in the lawsuit filed against us by the FTC

[0001728949-20-000067:mdna:59]
-    $162 million in lower employee-related expenses, primarily driven by actions taken under our Cost Plan

[0001728949-20-000067:mdna:60]
-    $75 million in lower sales and marketing expenses, primarily driven by actions taken under our Cost Plan

[0001728949-20-000067:mdna:61]
|  | 2020 |  | 2019 |  | 2018 |  | 2020 vs. 2019 Change |  | 2019 vs. 2018 Change |
| Other | $ | (28) |  |  | $ | 414 |  |  | $ | 3,135 |  |  | $ | (442) |  |  | $ | (2,721) |  |

[0001728949-20-000067:mdna:62]
2020

[0001728949-20-000067:mdna:63]
Other income in fiscal 2020 consisted of $28 million in gains related to a favorable legal settlement.

[0001728949-20-000067:mdna:64]
40

[0001728949-20-000067:mdna:65]
2019

[0001728949-20-000067:mdna:66]
Other expenses in fiscal 2019 consisted of:

[0001728949-20-000067:mdna:67]
+    $275 million charge related to a fine imposed by the European Commission (EC) related to the Icera complaint

[0001728949-20-000067:mdna:68]
+    $213 million in net charges related to our Cost Plan

[0001728949-20-000067:mdna:69]
-    $43 million gain due to the partial recovery of a fine imposed in fiscal 2009 resulting from our appeal of the Korea Fair Trade Commission (KFTC) decision

[0001728949-20-000067:mdna:70]
-    $31 million gain related to a favorable legal settlement

[0001728949-20-000067:mdna:71]
2018

[0001728949-20-000067:mdna:72]
Other expenses in fiscal 2018 consisted of:

[0001728949-20-000067:mdna:73]
+    $2.0 billion charge related to a fee in connection with the termination of the purchase agreement to acquire NXP

[0001728949-20-000067:mdna:74]
+    $1.2 billion charge related to a fine imposed by the EC

[0001728949-20-000067:mdna:75]
+    $629 million in restructuring and restructuring-related charges related to our Cost Plan

[0001728949-20-000067:mdna:76]
-    $676 million benefit related to the settlement of the Taiwan Fair Trade Commission (TFTC) investigation

[0001728949-20-000067:mdna:77]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | 2018 |  | 2020 vs. 2019 Change |  | 2019 vs. 2018 Change |
| Interest expense | $ | 602 |  |  | $ | 627 |  |  | $ | 768 |  |  | $ | (25) |  |  | $ | (141) |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 156 |  |  | $ | 300 |  |  | $ | 611 |  |  | $ | (144) |  |  | $ | (311) |  |
| Net gains on marketable securities | 198 |  |  | 295 |  |  | 21 |  |  | (97) |  |  | 274 |  |
| Net gains on other investments | 108 |  |  | 68 |  |  | 83 |  |  | 40 |  |  | (15) |  |
| Net gains on deferred compensation plan assets | 47 |  |  | 9 |  |  | 34 |  |  | 38 |  |  | (25) |  |
| Impairment losses on other investments | (405) |  |  | (135) |  |  | (75) |  |  | (270) |  |  | (60) |  |
| Net gains (losses) on derivative instruments | 8 |  |  | (14) |  |  | (27) |  |  | 22 |  |  | 13 |  |
| Equity in net losses of investees | (21) |  |  | (93) |  |  | (145) |  |  | 72 |  |  | 52 |  |
| Net (losses) gains on foreign currency transactions | (25) |  |  | 11 |  |  | 37 |  |  | (36) |  |  | (26) |  |
|  | $ | 66 |  |  | $ | 441 |  |  | $ | 539 |  |  | $ | (375) |  |  | $ | (98) |  |

[0001728949-20-000067:mdna:78]
The increase in impairment losses in fiscal 2020 was due in part to the impact COVID-19 had on certain of our investees. A significant portion of the impairment losses related to our investment in OneWeb who filed for bankruptcy in the second quarter of fiscal 2020. The decrease in interest and dividend income in fiscal 2020 was primarily driven by lower interest rates earned on interest-bearing securities. The decrease in net gains on marketable securities in fiscal 2020 was primarily driven by prior year gains resulting from the initial public offering of certain non-marketable equity investments in fiscal 2019.

[0001728949-20-000067:mdna:79]
In the fourth quarter of fiscal 2018, we implemented a stock repurchase program to repurchase up to $30 billion of our outstanding common stock. Stock repurchases made under this program significantly reduced the amount of our cash, cash equivalents and marketable securities, resulting in a decrease to interest and dividend income in fiscal 2019. The increase in net gains on marketable securities in fiscal 2019 was primarily driven by gains resulting from the initial public offering of certain non-marketable equity investments.

[0001728949-20-000067:mdna:80]
41

[0001728949-20-000067:mdna:81]
Income Tax Expense (in millions, except percentages)

[0001728949-20-000067:mdna:82]
The following table summarizes the primary factors that caused our annual tax provision to differ from the expected income tax provision at the U.S. federal statutory rate:

[0001728949-20-000067:mdna:83]
|  | 2020 |  | 2019 |  | 2018 |
| Expected income tax provision at federal statutory tax rate | $ | 1,201 |  |  | $ | 1,571 |  |  | $ | 97 |  |
| State income tax provision, net of federal benefit | 7 |  |  | 10 |  |  | 2 |  |
| Benefit from foreign-derived intangible income (FDII) deduction | (381) |  |  | (419) |  |  | — |  |
| Benefit related to the research and development tax credit | (125) |  |  | (110) |  |  | (136) |  |
| Excess tax benefit associated with share-based awards | (83) |  |  | (27) |  |  | (20) |  |
| Benefit from foreign income taxed at other than U.S. rates | (11) |  |  | (54) |  |  | (834) |  |
| Derecognition of deferred tax asset on distributed intellectual property | — |  |  | 2,472 |  |  | — |  |
| Benefit from establishing new U.S. net deferred tax assets | — |  |  | (570) |  |  | — |  |
| Nondeductible charges (reversals) related to the EC, KFTC and TFTC investigations | — |  |  | 51 |  |  | (119) |  |
| Toll Charge from U.S. tax reform | — |  |  | — |  |  | 5,236 |  |
| Valuation allowance on deferred tax asset related to the NXP termination fee | — |  |  | — |  |  | 494 |  |
| Remeasurement of deferred taxes due to changes in the statutory rate due to U.S. tax reform | — |  |  | — |  |  | 443 |  |
| Other | (87) |  |  | 171 |  |  | 193 |  |
| Income tax expense | $ | 521 |  |  | $ | 3,095 |  |  | $ | 5,356 |  |
| Effective tax rate | 9 | % |  | 41 | % |  | N/M |

[0001728949-20-000067:mdna:84]
N/M - Not meaningful

[0001728949-20-000067:mdna:85]
The 2017 Tax Cuts and Jobs Act (the Tax Legislation) was enacted in fiscal 2018, which, among other things, lowered the corporate income tax rate to 21%, and as a fiscal-year taxpayer, certain provisions of the Tax Legislation became effective for us at the beginning of fiscal 2019, including FDII (foreign-derived intangible income). In response to the Tax Legislation and to better align our profits with our activities, we implemented certain tax restructuring in fiscal 2018 and 2019. As a result, beginning in fiscal 2019, substantially all of our income is in the U.S., of which a significant portion qualifies for preferential treatment as FDII at a 13% effective tax rate. Our annual effective tax rate for fiscal 2018 reflected a blended federal statutory rate of approximately 25%.

[0001728949-20-000067:mdna:86]
In the fourth quarter of fiscal 2020, the United States Treasury Department issued final regulations on deductions for FDII, which are retroactive to fiscal 2019. As a result of these regulations, our fiscal 2020 annual effective tax rate increased by approximately 1%. In the first quarter of fiscal 2021, the United States Treasury Department issued final regulations on the foreign tax credit, which we anticipate will adversely affect our effective tax rate. The impact of these regulations, which are retroactive to fiscal 2019, has not been included in our fiscal 2020 effective tax rate. While we continue to evaluate these new regulations, we currently do not expect the adverse impact to fiscal 2019 and 2020 to be significant.

[0001728949-20-000067:mdna:87]
As a result of the Tax Legislation, in fiscal 2019, several of our foreign subsidiaries made tax elections to be treated as U.S. branches for federal income tax purposes (commonly referred to as “check-the-box” elections) effective beginning in fiscal 2018 and 2019. As a result of making these check-the-box elections, we recorded a tax benefit of $570 million in fiscal 2019. Additionally, in fiscal 2019, the United States Treasury Department issued new temporary regulations that resulted in a change to the deductibility of dividend income received by a U.S. stockholder from a foreign corporation. As a result of this change, pursuant to an agreement with the Internal Revenue Service, we relinquished the federal tax basis step-up of intellectual property that was distributed in fiscal 2018 by one of our foreign subsidiaries to a U.S. subsidiary. Therefore, the related deferred tax asset was derecognized, resulting in a $2.5 billion charge to income tax expense in fiscal 2019.

[0001728949-20-000067:mdna:88]
In fiscal 2018, as a result of the Tax Legislation, we recorded a charge of $5.7 billion to income tax expense, comprised of $5.2 billion related to the estimated one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge) and $438 million resulting from the remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate, which included a $135 million tax benefit in fiscal 2018 related to the remeasurement of a U.S. deferred tax liability that was established as a result of a change in one of our positions due to the Tax Legislation.

[0001728949-20-000067:mdna:89]
Unrecognized tax benefits were $1.9 billion and $1.7 billion at September 27, 2020 and September 29, 2019, respectively. The increase in unrecognized tax benefits in fiscal 2020 was primarily due to our decision in fiscal 2019 to request a refund of Korean withholding taxes as licensees in Korea continue to withhold taxes on payments due under their licensing agreements at a rate higher than we believe is owed (which had an insignificant impact to our income tax provision). If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We are subject to

[0001728949-20-000067:mdna:90]
income taxes in the United States and numerous foreign jurisdictions and are currently under examination by various tax authorities worldwide, primarily related to transfer pricing. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of September 27, 2020, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0001728949-20-000067:mdna:91]
Segment Results

[0001728949-20-000067:mdna:92]
The following should be read in conjunction with the fiscal 2020, 2019 and 2018 results of operations for each reportable segment included in this Annual Report in “Notes to Consolidated Financial Statements, Note 8. Segment Information.”

[0001728949-20-000067:mdna:93]
QCT Segment (in millions, except percentages)

[0001728949-20-000067:mdna:94]
|  | 2020 |  | 2019 |  | 2018 |  | 2020 vs. 2019 Change |  | 2019 vs. 2018 Change |
| Revenues |  |  |  |  |  |  |  |  |  |
| Equipment and services | $ | 16,143 |  |  | $ | 14,318 |  |  | $ | 17,060 |  |  | $ | 1,825 |  |  | $ | (2,742) |  |
| Licensing | 350 |  |  | 321 |  |  | 222 |  |  | 29 |  |  | 99 |  |
| Total revenues | $ | 16,493 |  |  | $ | 14,639 |  |  | $ | 17,282 |  |  | $ | 1,854 |  |  | $ | (2,643) |  |
| EBT (1) | $ | 2,763 |  |  | $ | 2,143 |  |  | $ | 2,966 |  |  | $ | 620 |  |  | $ | (823) |  |
| EBT as a % of revenues | 17 | % |  | 15 | % |  | 17 | % |  | 2 | % |  | (2 | %) |

[0001728949-20-000067:mdna:95]
(1)Earnings (loss) before taxes.

[0001728949-20-000067:mdna:96]
Equipment and services revenues are predominantly related to sales of products used in mobile devices and mostly relate to sales of Mobile Station Modem (MSM™), radio frequency (RF), power management (PM) and wireless connectivity integrated chipsets. MSM integrated circuits include our stand-alone Mobile Data Modems and Snapdragon platforms, which include processors and modems. Approximately 575 million, 650 million and 855 million MSM integrated circuits were sold during fiscal 2020, 2019 and 2018, respectively. Through fiscal 2020, we provided the volume of MSM integrated circuit shipments to allow management and investors to, in part, evaluate, assess and benchmark our QCT segment’s performance. Beginning in fiscal 2021, we will no longer provide MSM integrated circuit shipments since such measure is becoming increasingly less meaningful in understanding and evaluating the performance of our QCT segment, which can be impacted by other factors including changes in mix and average selling price of our MSM integrated circuits and revenues generated from products other than MSM integrated circuits, such as RFFE products, among others.

[0001728949-20-000067:mdna:97]
2020 vs. 2019

[0001728949-20-000067:mdna:98]
The increase in QCT equipment and services revenues was primarily due to:

[0001728949-20-000067:mdna:99]
+    $1.6 billion in higher revenues per MSM and accompanying RF, PM and wireless connectivity chipset shipments, primarily driven by a favorable mix due to an increase in demand for 5G products

[0001728949-20-000067:mdna:100]
+    $864 million in higher RFFE product revenues, primarily driven by an increase in demand for 5G products

[0001728949-20-000067:mdna:101]
-    $764 million in lower MSM and accompanying chipset shipments, primarily driven by a decrease in demand due to COVID-19, lower legacy MDM sales to Apple and lower sales to Huawei, partially offset by an increase in shipments to Apple under the multi-year chipset supply agreement and an increase in demand for IoT products

[0001728949-20-000067:mdna:102]
QCT EBT as a percentage of revenues increased in fiscal 2020 primarily due to:

[0001728949-20-000067:mdna:103]
+    higher revenues and gross margin, primarily driven by a favorable shift in product mix due to an increase in demand for 5G products

[0001728949-20-000067:mdna:104]
-    higher operating expenses, primarily driven by higher research and development costs

[0001728949-20-000067:mdna:105]
QCT accounts receivable increased by 53% in fiscal 2020 from $908 million to $1.39 billion, primarily driven by an increase in revenues. QCT inventories increased by 86% in fiscal 2020 from $1.40 billion to $2.60 billion, primarily driven by the ramp in 5G demand.

[0001728949-20-000067:mdna:106]
2019 vs. 2018

[0001728949-20-000067:mdna:107]
The decrease in QCT equipment and services revenues was primarily due to:

[0001728949-20-000067:mdna:108]
-    $2.7 billion in lower MSM and accompanying unit shipments, primarily driven by lower modem sales to Apple and a decline in demand from OEMs in China

[0001728949-20-000067:mdna:109]
-    $515 million in lower connectivity product revenues, primarily driven by a decline in demand for Wi-Fi and Bluetooth products from OEMs in China

[0001728949-20-000067:mdna:110]
+    $552 million in higher revenues per MSM and accompanying unit shipment, primarily driven by a favorable shift in mix related to our premium-tier products

[0001728949-20-000067:mdna:111]
QCT EBT as a percentage of revenues decreased in fiscal 2019 primarily due to:

[0001728949-20-000067:mdna:112]
-    lower QCT revenues

[0001728949-20-000067:mdna:113]
+    decrease in operating expenses, primarily driven by a decrease in the amount of research and development expense allocated to QCT in fiscal 2019 and actions under our Cost Plan

[0001728949-20-000067:mdna:114]
QTL Segment (in millions, except percentages)

[0001728949-20-000067:mdna:115]
|  | 2020 |  | 2019 |  | 2018 |  | 2020 vs. 2019 Change |  | 2019 vs. 2018 Change |
| Licensing revenues | $ | 5,028 |  |  | $ | 4,591 |  |  | $ | 5,042 |  |  | $ | 437 |  |  | $ | (451) |  |
| EBT | $ | 3,442 |  |  | $ | 2,954 |  |  | $ | 3,404 |  |  | $ | 488 |  |  | $ | (450) |  |
| EBT as a % of revenues | 68 | % |  | 64 | % |  | 68 | % |  | 4 | % |  | (4 | %) |

[0001728949-20-000067:mdna:116]
QTL results in fiscal 2020 and fiscal 2019 reflected the adoption of new revenue recognition guidance that requires us to estimate and recognize QTL royalties in the period in which the associated sales occur, resulting in an acceleration of royalty revenues by one quarter as compared to fiscal 2018. QTL results in fiscal 2018 have not been adjusted for the adoption of the new accounting guidance.

[0001728949-20-000067:mdna:117]
As a result of the settlement with Apple and its contract manufacturers in April 2019, QTL results for fiscal 2020 and the second half of fiscal 2019 included royalties from Apple and its contract manufactures. Revenues in the first six months of fiscal 2019 and all of fiscal 2018 did not include royalties from sales of Apple or other products by Apple’s contract manufacturers due to our prior dispute. Revenues of $4.7 billion recorded in the third quarter of fiscal 2019 resulting from the settlement with Apple and its contract manufacturers were not allocated to our segment results.

[0001728949-20-000067:mdna:118]
QTL revenues for fiscal 2020 included royalties from Huawei for sales made in the September 2020 quarter under the new long-term, global patent license agreement. QTL revenues in fiscal 2019 included $450 million of royalties due under a second interim agreement with Huawei that concluded in the third quarter of fiscal 2019. Due to our prior dispute that was resolved in July 2020, we did not record any revenues in the first three quarters of fiscal 2020 or the fourth quarter of fiscal 2019 for royalties due on the sales of Huawei’s consumer wireless products. QTL revenues in fiscal 2018 included $600 million paid under an interim agreement with Huawei. Revenues of $1.8 billion recorded in the fourth quarter of fiscal 2020 resulting from the settlement agreement with Huawei and royalties for sales made in the March 2020 and June 2020 quarters under the new global patent license agreement with Huawei were not allocated to our segment results.

[0001728949-20-000067:mdna:119]
2020 vs. 2019

[0001728949-20-000067:mdna:120]
The increase in QTL licensing revenues in fiscal 2020 was primarily due to:

[0001728949-20-000067:mdna:121]
+    $906 million increase in estimated sales of 3G/4G/5G-based multimode products, primarily due to new license agreements with Apple and Huawei signed in April 2019 and July 2020, respectively, partially offset by the negative impact of COVID-19 on demand for licensees’ products that incorporate our intellectual property

[0001728949-20-000067:mdna:122]
+    $110 million increase in royalty revenues recognized related to devices sold in prior periods

[0001728949-20-000067:mdna:123]
-    $450 million in licensing revenues recorded in fiscal 2019 resulting from the second interim agreement with Huawei

[0001728949-20-000067:mdna:124]
-    $129 million in lower estimated revenues per unit, in part reflecting licensees entering into new 5G multimode license agreements with rights to our cellular standard-essential patents only (compared to previous licenses that also included rights to certain other non-cellular essential patents) and decreases in our per unit royalty caps

[0001728949-20-000067:mdna:125]
QTL EBT as a percentage of revenues increased in fiscal 2020 primarily due to:

[0001728949-20-000067:mdna:126]
+    higher QTL revenues

[0001728949-20-000067:mdna:127]
+    lower selling, general and administrative expenses, primarily from lower litigation costs

[0001728949-20-000067:mdna:128]
-    higher research and development expenses

[0001728949-20-000067:mdna:129]
QTL accounts receivable increased by 4% in fiscal 2020 from $1.54 billion to $1.60 billion, primarily driven by an increase in estimated royalties for the September 2020 quarter (in part due to the new license agreement with Huawei), partially offset by scheduled payments received from Oppo and vivo for amounts due under agreements reached in fiscal 2020 related to license agreements that expired on March 31, 2020 (for which payments were withheld while good faith negotiations occurred).

[0001728949-20-000067:mdna:130]
2019 vs. 2018

[0001728949-20-000067:mdna:131]
QTL licensing revenues in fiscal 2019, which primarily related to royalties due on sales made by our licensees in the December 2018, March 2019, June 2019 and September 2019 quarters, decreased compared to licensing revenues in fiscal 2018, which primarily related to royalties due on sales made by our licensees in the September 2017, December 2017, March 2018 and June 2018 quarters, primarily due to:

[0001728949-20-000067:mdna:132]
-    $757 million in lower estimated revenues per unit compared to revenues per reported unit, in part reflecting licensees entering into new 5G multimode license agreements with rights to our cellular standard-essential patents only (compared to previous licenses that also included rights to certain other non-cellular essential patents), and decreases in our per unit royalty caps

[0001728949-20-000067:mdna:133]
-    $150 million in lower royalty revenues from Huawei under the interim agreements

[0001728949-20-000067:mdna:134]
+    $484 million increase in estimated sales of 3G/4G/5G-based multimode products compared to reported sales of 3G/4G-based products, primarily due to the April 2019 license agreement with Apple, partially offset by a decline in unit demand and a shift in OEM share towards Huawei

[0001728949-20-000067:mdna:135]
QTL EBT as a percentage of revenues decreased in fiscal 2019 primarily due to:

[0001728949-20-000067:mdna:136]
-    higher research and development costs due to an increase in the amount of research and development expense allocated to QTL in fiscal 2019

[0001728949-20-000067:mdna:137]
-    lower QTL revenues

[0001728949-20-000067:mdna:138]
+    lower selling, general and administrative expenses, primarily from lower litigation costs and lower bad debt expense

[0001728949-20-000067:mdna:139]
QSI Segment (in millions)

[0001728949-20-000067:mdna:140]
|  | 2020 |  | 2019 |  | 2018 |  | 2020 vs. 2019 Change |  | 2019 vs. 2018 Change |
| Equipment and services revenues | $ | 36 |  |  | $ | 152 |  |  | $ | 100 |  |  | $ | (116) |  |  | $ | 52 |  |
| EBT | $ | (11) |  |  | $ | 344 |  |  | $ | 24 |  |  | $ | (355) |  |  | $ | 320 |  |

[0001728949-20-000067:mdna:141]
2020 vs. 2019

[0001728949-20-000067:mdna:142]
The decrease in QSI EBT in of fiscal 2020 was primarily due to:

[0001728949-20-000067:mdna:143]
-     $248 million increase in impairment losses on other investments, of which a significant portion related to our investment in OneWeb

[0001728949-20-000067:mdna:144]
-     $116 million decrease in revenues associated with certain development contracts with OneWeb

[0001728949-20-000067:mdna:145]
-     $60 million decrease in net gains on investments, primarily driven by a gain in fiscal 2019 resulting from the initial public offering of certain of our non-marketable equity investments

[0001728949-20-000067:mdna:146]
+     $50 million decrease in our share of equity method investee losses

[0001728949-20-000067:mdna:147]
QSI segment assets, which primarily consist of marketable and non-marketable equity investments, decreased by 20% in fiscal 2020 from $1.71 billion to $1.37 billion, primarily due to impairments of certain non-marketable investments and sale of marketable securities.

[0001728949-20-000067:mdna:148]
2019 vs. 2018

[0001728949-20-000067:mdna:149]
The increase in QSI EBT in fiscal 2019 was primarily due to:

[0001728949-20-000067:mdna:150]
+     $270 million increase in net gains on investments, primarily driven by gains resulting from the initial public offering of certain non-marketable equity investments

[0001728949-20-000067:mdna:151]
+    $91 million increase resulting from higher revenues and lower costs associated with certain development contracts with OneWeb

[0001728949-20-000067:mdna:152]
-     $41 million increase in impairment losses on investments, primarily related to our investment in OneWeb

[0001728949-20-000067:mdna:153]
Looking Forward

[0001728949-20-000067:mdna:154]
In the coming years, we expect new consumer demand for 3G/4G/5G multimode and 5G products and services to ramp around the world as we transition from 3G/4G multimode and 4G products and services. We believe that 5G will drive growth and transformation in emerging device categories and industries that will create new business models and new services, resulting from the expanding adoption of certain technologies that are already commonly used in smartphones by industry segments or applications beyond mobile, such as automotive and IoT. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing of 5G technologies, and to be a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long term.

[0001728949-20-000067:mdna:155]
As we look forward to the next several months and beyond, we expect our business to be impacted by the following key items:

[0001728949-20-000067:mdna:156]
•The COVID-19 pandemic has resulted in significant economic uncertainty and has led to a global recession. We expect the pandemic will continue to have a negative impact on QTL and QCT revenues in the near term based on a reduction in consumer demand for smartphones and other products. We have not experienced, and we currently do not anticipate a material adverse impact on our ability, or our suppliers’ ability, to manufacture and test our products or on our ability to provide our products to our customers. Workforce changes that we implemented in the second quarter of fiscal 2020 are expected to remain in effect in the near term. The degree to which the COVID-19 pandemic impacts our business, financial condition and results of operations will depend on future developments, which are highly uncertain. See “Risk Factors” in this Annual Report, specifically the Risk Factor entitled “The recent coronavirus (COVID-19) pandemic has had an adverse effect on our business and results of operations, and we expect its impact will continue, at least in the near term.”

[0001728949-20-000067:mdna:157]
•In May 2019, in United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated, the district court issued an Order ruling against us and imposing certain injunctive relief. On August 11, 2020, on appeal, the Ninth Circuit reversed the district court’s judgment, vacated its injunction and vacated its partial grant of summary judgment. On September 25, 2020, the FTC filed a Petition for Rehearing En Banc. On October 28, 2020, the Ninth Circuit denied the FTC’s petition. Regulatory authorities in certain other jurisdictions are investigating and/or have investigated our business practices and instituted proceedings against us, and they or other regulatory authorities may do so in the future. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies” and “Risk Factors” in

[0001728949-20-000067:mdna:158]
this Annual Report, including the Risk Factor entitled “Changes in our patent licensing practices, whether due to governmental investigations or private legal proceedings challenging those practices, or otherwise, could adversely impact our business and results of operations.”

[0001728949-20-000067:mdna:159]
•We have not been the sole supplier of modems for iPhone products beginning with products that launched in September 2016, and Apple is not utilizing our modems for iPhone products that launched in September 2019. We expect QCT revenues to be favorably impacted in the near-term as we anticipate a ramp in volume of shipments to support Apple’s 2020 iPhone product launches.

[0001728949-20-000067:mdna:160]
•We expect our research and development costs will increase in the near-term primarily due to increased investment towards advancements in 5G and application processor technologies and certain other long-term initiatives, as well as an increase in share-based compensation expense.

[0001728949-20-000067:mdna:161]
•We expect increased demand in the December quarter from certain Chinese OEMs as they position to gain device share, particularly in China. Since it will take time for us to adapt our supply chain process, we do not expect to realize the full benefit from this increased demand from OEMs.

[0001728949-20-000067:mdna:162]
•We expect continued intense competition, particularly in China, as our competitors expand their product offerings and/or reduce the prices of their products as part of a strategy to attract new and/or retain existing customers;

[0001728949-20-000067:mdna:163]
•Current U.S./China trade relations and/or national security protection policies may negatively impact our business, growth prospects and results of operations. See “Risk Factors” in this Annual Report, including the Risk Factor entitled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0001728949-20-000067:mdna:164]
•Commercial 5G network deployments and device launches will continue into calendar 2021 and beyond.

[0001728949-20-000067:mdna:165]
In addition to the foregoing business and market-based matters, we continue to devote resources to working with and educating participants in the wireless value chain and governments as to the benefits of our licensing program and our extensive technology investments in promoting a highly competitive and innovative wireless industry. However, we expect that certain companies may continue to be dissatisfied with the need to pay reasonable royalties for the use of our technology and not welcome the success of our licensing program in enabling new, highly cost-effective competitors to their products. Accordingly, such companies, and/or governments or regulators, may continue to challenge our business model in various forums throughout the world.

[0001728949-20-000067:mdna:166]
Further discussion of risks related to our business is provided in “Part I, Item 1A. Risk Factors” included in this Annual Report.

[0001728949-20-000067:mdna:167]
Liquidity and Capital Resources

[0001728949-20-000067:mdna:168]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following table presents selected financial information related to our liquidity as of and for the years ended September 27, 2020 and September 29, 2019 (in millions):

[0001728949-20-000067:mdna:169]
|  | September 27,2020 |  | September 29,2019 |  | Change |
| Cash, cash equivalents and marketable securities | $ | 11,249 |  |  | $ | 12,296 |  |  | $ | (1,047) |  |
| Accounts receivable, net | 4,003 |  |  | 2,471 |  |  | 1,532 |  |
| Inventories | 2,598 |  |  | 1,400 |  |  | 1,198 |  |
| Short-term debt | 500 |  |  | 2,496 |  |  | (1,996) |  |
| Long-term debt | 15,226 |  |  | 13,437 |  |  | 1,789 |  |
| Noncurrent income taxes payable | 1,872 |  |  | 2,088 |  |  | (216) |  |
|  | 2020 |  | 2019 |  | Change |
| Net cash provided by operating activities | $ | 5,814 |  |  | $ | 7,286 |  |  | $ | (1,472) |  |
| Net cash used by investing activities | (5,263) |  |  | (806) |  |  | (4,457) |  |
| Net cash used by financing activities | (5,707) |  |  | (6,386) |  |  | 679 |  |

[0001728949-20-000067:mdna:170]
The net decrease in cash, cash equivalents and marketable securities was primarily due to $2.9 billion in cash dividends paid, $2.4 billion to repurchase shares of our common stock, $1.4 billion in capital expenditures and $344 million in payments of tax withholdings related to the vesting of share-based awards, partially offset by net cash provided by operating activities and $329 million in proceeds from issuance of common stock.

[0001728949-20-000067:mdna:171]
The increase in accounts receivable was primarily due to the remaining amounts due under the settlement agreement with Huawei and increases in QCT and QTL accounts receivable. The increase in inventories was primarily driven by the ramp in 5G demand.

[0001728949-20-000067:mdna:172]
Debt. In May 2020, we issued an aggregate principal amount of $2.0 billion of unsecured fixed-rate notes with varying maturities (May 2020 Notes). The net proceeds were used to repay the $250 million floating-rate and $1.75 billion fixed-rate notes that matured on May 20, 2020, which were classified as short-term debt at September 29, 2019. In August 2020, we completed an exchange of $2.0 billion of our outstanding fixed-rate notes maturing between 2022 and 2025 (Old Notes) for $2.2 billion of fixed-rate notes maturing in 2028 and 2032 (August 2020 Notes). We also repurchased $202 million of the Old Notes from holders not eligible to participate in the exchange. At September 27, 2020, we had $15.5 billion of principal floating- and fixed-rate notes outstanding, with maturity dates in 2022 through 2050.

[0001728949-20-000067:mdna:173]
We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At September 27, 2020, we had $500 million of commercial paper outstanding.

[0001728949-20-000067:mdna:174]
Our Amended and Restated Revolving Credit Facility (Revolving Credit Facility) provides for unsecured revolving facility loans, swing line loans and letters of credit in the aggregate amount of up to $4.5 billion and expires on November 8, 2021. At September 27, 2020, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-20-000067:mdna:175]
We may issue new debt in the future. COVID-19 has led to disruption and volatility in the global capital markets, which may adversely impact the cost of and access to capital. The amount and timing of such borrowings will be subject to a number of factors, including acquisitions and strategic investments, acceptable interest rates and changes in corporate income tax law, among other factors.

[0001728949-20-000067:mdna:176]
Additional information regarding our outstanding debt at September 27, 2020 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 6. Debt.”

[0001728949-20-000067:mdna:177]
Income Taxes. At September 27, 2020, we estimated remaining future payments of $2.0 billion for a one-time U.S. repatriation tax accrued in fiscal 2018 (Toll Charge), after application of certain tax credits, which is payable in installments over the next six years. At September 27, 2020, other current liabilities included $174 million for the next installment due in January 2021.

[0001728949-20-000067:mdna:178]
Additional information regarding our income taxes is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 3. Income Taxes.”

[0001728949-20-000067:mdna:179]
Capital Return Program. The following table summarizes stock repurchases, before commissions, and dividends paid during fiscal 2020, 2019 and 2018 (in millions, except per-share amounts):

[0001728949-20-000067:mdna:180]
|  |  | Stock Repurchase Program |  | Dividends |  | Total |
|  |  | Shares |  | Average Price Paid Per Share (1) |  | Amount |  | Per Share |  | Amount |  | Amount |
| 2020 |  | 31 |  |  | $ | 79.32 |  |  | $ | 2,450 |  |  | $ | 2.54 |  |  | $ | 2,882 |  |  | $ | 5,332 |  |
| 2019 |  | 96 |  |  | 66.18 |  |  | 1,793 |  |  | 2.48 |  |  | 2,968 |  |  | 4,761 |  |
| 2018 |  | 279 |  |  | 65.41 |  |  | 22,569 |  |  | 2.38 |  |  | 3,466 |  |  | 26,035 |  |

[0001728949-20-000067:mdna:181]
(1)Average Price Paid Per Share in fiscal 2018 and 2019 excludes the impact of the three accelerated share repurchase agreements (the ASR Agreements) executed in September 2018 and completed in September 2019. The average price per share under the ASR Agreements was $64.76.

[0001728949-20-000067:mdna:182]
In fiscal 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. At September 27, 2020, $4.6 billion remained authorized for repurchase under the stock repurchase program. The stock repurchase program has no expiration date. Subsequent to September 27, 2020, we resumed stock repurchases under the stock repurchase program, which we had suspended in the third quarter of fiscal 2020 in light of COVID-19 to maintain our financial liquidity position and flexibility. We periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders and may reinstate, accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-20-000067:mdna:183]
On October 14, 2020, we announced a cash dividend of $0.65 per share on our common stock, payable on December 17, 2020 to stockholders of record as of the close of business on December 3, 2020. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability, which may be impacted by COVID-19, and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-20-000067:mdna:184]
Additional Capital Requirements. We believe our cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements

[0001728949-20-000067:mdna:185]
47

[0001728949-20-000067:mdna:186]
for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements, in addition to the above matters, also include the items described below:

[0001728949-20-000067:mdna:187]
•Our purchase obligations at September 27, 2020, some of which relate to research and development activities and capital expenditures, totaled $5.5 billion and $350 million for fiscal 2021 and 2022, respectively, and $242 million thereafter.

[0001728949-20-000067:mdna:188]
•Our research and development expenditures were $6.0 billion in fiscal 2020 and $5.4 billion in fiscal 2019, and we expect to increase our investment in research and development in fiscal 2021, including in advancements in existing and new technologies and products.

[0001728949-20-000067:mdna:189]
•Cash outflows for capital expenditures were $1.4 billion in fiscal 2020 and $887 million in fiscal 2019. We expect capital expenditures to increase in the near term to support the increase in our manufacturing and production capacity needs primarily resulting from the ramp in 5G devices.

[0001728949-20-000067:mdna:190]
•At September 27, 2020, $1.5 billion was accrued related to two fines imposed by the EC (based on the exchange rate at September 27, 2020, including related foreign currency gains and accrued interest). We have provided financial guarantees in lieu of cash payment to satisfy the obligations while we appeal the EU’s decisions.

[0001728949-20-000067:mdna:191]
•We expect to continue making strategic investments and acquisitions, the amounts of which could vary significantly, to open new opportunities for our technologies, obtain development resources, grow our patent portfolio or pursue new businesses.

[0001728949-20-000067:mdna:192]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees, have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies” and “Part I, Item 1A. Risk Factors” in this Annual Report.

[0001728949-20-000067:mdna:193]
Contractual Obligations/Off-Balance Sheet Arrangements

[0001728949-20-000067:mdna:194]
We have no significant contractual obligations not fully recorded on our consolidated balance sheets or fully disclosed in the notes to our consolidated financial statements. We have no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001728949-20-000067:mdna:195]
The following table summarizes the payments due by fiscal period for our outstanding contractual obligations at September 27, 2020 (in millions):

[0001728949-20-000067:mdna:196]
|  | Total |  | 2021 |  | 2022-2023 |  | 2024-2025 |  | Beyond2025 |  | NoExpirationDate |
| Purchase obligations (1) | $ | 6,060 |  |  | $ | 5,468 |  |  | $ | 539 |  |  | $ | 53 |  |  | $ | — |  |  | $ | — |  |
| Operating lease obligations (2) | 578 |  |  | 141 |  |  | 196 |  |  | 91 |  |  | 150 |  |  | — |  |
| Finance lease obligations (2) | 130 |  |  | 14 |  |  | 20 |  |  | 16 |  |  | 80 |  |  | — |  |
| Equity funding and financing commitments (3) | 185 |  |  | 103 |  |  | 1 |  |  | — |  |  | — |  |  | 81 |  |
| Long-term debt (4) | 22,057 |  |  | 476 |  |  | 3,890 |  |  | 3,067 |  |  | 14,624 |  |  | — |  |
| Other long-term liabilities (5) (6) | 2,807 |  |  | 220 |  |  | 472 |  |  | 862 |  |  | 631 |  |  | 622 |  |
| Total contractual obligations | $ | 31,817 |  |  | $ | 6,422 |  |  | $ | 5,118 |  |  | $ | 4,089 |  |  | $ | 15,485 |  |  | $ | 703 |  |

[0001728949-20-000067:mdna:197]
(1)Purchase obligations primarily relate to integrated circuit product inventory obligations, which represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancellation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancellation, and in some cases, incremental fees related to capacity underutilization.

[0001728949-20-000067:mdna:198]
(2)Amounts represent future lease payments. Operating and finance lease obligations include the related current portions. Operating and finance lease liabilities were included in other current liabilities and other noncurrent liabilities in the consolidated balance sheet at September 27, 2020.

[0001728949-20-000067:mdna:199]
(3)Certain of these commitments do not have fixed funding dates and are subject to certain conditions and have, therefore, been presented as having no expiration date. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all.

[0001728949-20-000067:mdna:200]
(4)Amounts represent contractual payments of principal and interest.

[0001728949-20-000067:mdna:201]
(5)Amounts represent contractual payments of amounts recorded on our consolidated balance sheet. Certain long-term liabilities reflected on our balance sheet, such as unearned revenues, are not presented in this table because they do not require cash settlement in the future. Other long-term liabilities as presented in this table include the related current portions, as applicable. These amounts do not include the EC fines recorded as current liabilities on our consolidated balance sheet. For further information regarding these fines, refer to “Notes to Consolidated Financial Statements, Note 7. Commitments and Contingencies.”

[0001728949-20-000067:mdna:202]
(6)Our consolidated balance sheet at September 27, 2020 included $1.8 billion in other noncurrent liabilities for uncertain tax positions, which primarily relate to a reduction of U.S. foreign tax credits that will occur if we are successful in our claim for a refund of Korean withholding tax (for which a $1.6 billion receivable was recorded at September 27, 2020). If we are successful in our claim for a refund, the majority of this liability will be payable when we receive the Korean tax refund, with the remainder payable over periods up to and including the last payment of the Toll Charge in January 2026. The future payments related to uncertain tax positions recorded as other noncurrent liabilities have not been presented in the table above due to the uncertainty of the amounts and timing of cash settlement with the taxing authorities.

[0001728949-20-000067:mdna:203]
Additional information regarding our financial commitments at September 27, 2020 is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 3. Income Taxes,” “Note 6. Debt” and “Note 7. Commitments and Contingencies.”

[0001728949-20-000067:mdna:204]
Critical Accounting Estimates

[0001728949-20-000067:mdna:205]
The preparation of our consolidated financial statements in accordance with accounting principles generally accepted in the United States requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and disclosure of contingent assets and liabilities. We base our estimates on historical and anticipated results and trends and on various other assumptions that we believe are reasonable under the circumstances, including assumptions as to future events. By their nature, estimates are subject to an inherent degree of uncertainty. Although we believe that our estimates and the assumptions supporting our assessments are reasonable, actual results that differ from our estimates could be material to our consolidated financial statements.

[0001728949-20-000067:mdna:206]
Refer to “Note 1. Significant Accounting Policies” and “Note 2. Composition of Certain Financial Statement Items” included in this Annual Report in “Notes to Consolidated Financial Statements” for further information on our critical accounting estimates and policies, which are as follows. In addition, if the impact of changes in our critical accounting estimates are material or considered necessary to understand our results of operations for the periods presented, then such information is disclosed within this Annual Report in “Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations, Results of Operations.”

[0001728949-20-000067:mdna:207]
Revenue Recognition. We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Since the adoption of ASC 606 in fiscal 2019, we estimate and recognize sales-based royalties on such licensed products in the period in which the licensees’ sales occur, which is based largely on preliminary royalty estimates provided by our licensees. Actual amounts for sales-based royalties have been materially consistent with such estimates, and no significant reversals of revenues have been required as a result of adjustments to prior period royalty estimates. Additionally, with respect to our settlement agreement and new global patent license agreement with Huawei, significant evaluation and judgment were required in determining the appropriate accounting.

[0001728949-20-000067:mdna:208]
Impairment of Non-marketable Equity Investments. We monitor our investments for events or circumstances that could indicate impairment and observable price adjustments. In fiscal 2020, we recorded impairment losses on other investments of $405 million, an increase of $270 million compared to fiscal 2019, a portion of which was due in part to the impacts of COVID-19 on certain companies in which we hold non-marketable investments. For a significant portion of these impairments, the estimated fair values resulted in a full write-off of the carrying values.

[0001728949-20-000067:mdna:209]
Inventories. We measure inventory at the lower of cost or net realizable value considering judgments related to future demand and market conditions, such as COVID-19 in fiscal 2020 that negatively impacted consumer demand for devices that incorporate our products. For fiscal 2020, 2019 and 2018, the overall net effect on our operating results from changes in this estimate were not material.

[0001728949-20-000067:mdna:210]
Impairment of Goodwill and Long-Lived Assets. We monitor our goodwill and long-lived assets for the existence of impairment indicators and apply judgments in the valuation methods and underlying assumptions utilized in such assessments. During fiscal 2020, we did not record any impairment charges for goodwill and long-lived assets. Additionally, the estimated fair values of our QCT and QTL reporting units were substantially in excess of their respective carrying values at September 27, 2020. In fiscal 2019 and 2018, we recorded $203 million and $273 million, respectively, of impairment charges for goodwill and long-lived assets.

[0001728949-20-000067:mdna:211]
Legal and Regulatory Proceedings. We record our best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. We face difficulties in evaluating or estimating likely outcomes or the amount of possible loss in certain legal and regulatory proceedings.

[0001728949-20-000067:mdna:212]
Income Taxes. We make significant judgments and estimates in determining our provision for income taxes, including our assessment of our income tax positions given the uncertainties involved in the interpretation and application of complex tax laws and regulations in various taxing jurisdictions.

[0001728949-20-000067:mdna:213]
Recent Accounting Pronouncements

[0001728949-20-000067:mdna:214]
Information regarding recent accounting pronouncements and the impact of those pronouncements, if any, on our consolidated financial statements is provided in this Annual Report in “Notes to Consolidated Financial Statements, Note 1. Significant Accounting Policies.”
