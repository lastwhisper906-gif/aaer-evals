# QCOM 8-K — 0001728949-20-000066 filed 2020-11-04

## item codes, every 8-K on or before 2020-11-04

- 2020-11-04 0001728949-20-000066 — 2.02, 9.01
- 2020-08-18 0001104659-20-096322 — 1.01, 8.01, 9.01
- 2020-08-05 0001104659-20-090597 — 8.01, 9.01
- 2020-07-29 0001728949-20-000056 — 2.02, 9.01
- 2020-07-24 0001728949-20-000047 — 5.02
- 2020-05-11 0001104659-20-058923 — 1.01, 8.01, 9.01
- 2020-05-04 0001728949-20-000037 — 5.02
- 2020-04-29 0001728949-20-000030 — 2.02, 9.01
- 2020-03-13 0001728949-20-000015 — 5.07
- 2020-02-05 0001728949-20-000010 — 2.02, 9.01
- 2019-11-06 0001728949-19-000074 — 5.02
- 2019-11-06 0001728949-19-000071 — 2.02, 9.01
- 2019-08-28 0001728949-19-000058 — 5.02
- 2019-07-31 0001728949-19-000053 — 2.02, 9.01
- 2019-05-10 0001728949-19-000044 — 5.02
- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2020-11-04

- none on or before 2020-11-04

## item 2.02 — earnings release, exhibit 99.1

[0001728949-20-000066:8k_2_02:1]
EX-99.1
2
qcom092720erex991.htm
EX-99.1

[0001728949-20-000066:8k_2_02:2]
Document

[0001728949-20-000066:8k_2_02:3]
Exhibit 99.1

[0001728949-20-000066:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001728949-20-000066:8k_2_02:5]
Qualcomm Contact:

[0001728949-20-000066:8k_2_02:6]
Mauricio Lopez-Hodoyan

[0001728949-20-000066:8k_2_02:7]
Vice President, Investor Relations

[0001728949-20-000066:8k_2_02:8]
Phone: 1-858-658-4813 | e-mail: ir@qualcomm.com

[0001728949-20-000066:8k_2_02:9]
Qualcomm Announces Fourth Quarter and Fiscal 2020 Results

[0001728949-20-000066:8k_2_02:10]
Fourth Quarter EPS: GAAP $2.58, Non-GAAP $1.45

[0001728949-20-000066:8k_2_02:11]
Fiscal 2020 Revenues: GAAP $23.5 billion, Non-GAAP $21.7 billion

[0001728949-20-000066:8k_2_02:12]
Fiscal 2020 EPS: GAAP $4.52, Non-GAAP $4.19

[0001728949-20-000066:8k_2_02:13]
—Record Quarterly EPS Exceeded High End of Guidance Range—

[0001728949-20-000066:8k_2_02:14]
SAN DIEGO - November 4, 2020 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal fourth quarter and year ended September 27, 2020.

[0001728949-20-000066:8k_2_02:15]
“Our fiscal fourth quarter results demonstrate that our investments in 5G are coming to fruition and showing benefits in our licensing and product businesses,” said Steve Mollenkopf, CEO of Qualcomm Incorporated. “We concluded the year with exceptional fourth quarter results and are well positioned for growth in 2021 and beyond. As the pace of disruption in wireless technology accelerates, we will continue to drive growth and scale across our RF front-end, Automotive and IoT adjacencies.”

[0001728949-20-000066:8k_2_02:16]
Fourth Quarter Results 1, 2

[0001728949-20-000066:8k_2_02:17]
|  | GAAP |  | Non-GAAP |  |
| (in millions, except per share dataand percentages) | Q4 Fiscal 2020 |  | Q4 Fiscal 2019 |  | Change |  | Q4 Fiscal 2020 |  | Q4 Fiscal 2019 |  |  |  |  | Change |  |
| Revenues | $8,346 |  | $4,814 |  | +73% |  | $6,502 |  | $4,804 |  |  |  |  | +35% |  |
| Earnings before taxes (EBT) | $3,306 |  | $615 |  | N/M |  | $1,862 |  | $1,049 |  |  |  |  | +78% |  |
| Net income | $2,960 |  | $506 |  | N/M |  | $1,669 |  | $947 |  |  |  |  | +76% |  |
| Diluted earnings per share (EPS) | $2.58 |  | $0.42 |  | N/M |  | $1.45 |  | $0.78 |  |  |  |  | +86% |  |

[0001728949-20-000066:8k_2_02:18]
Fiscal 2020 Results 2, 3, 4

[0001728949-20-000066:8k_2_02:19]
|  | GAAP |  | Non-GAAP |  |
| (in millions, except per share dataand percentages) | Fiscal 2020 |  | Fiscal 2019 |  | Change |  | Fiscal 2020 |  | Fiscal 2019 |  |  |  |  | Change |  |
| Revenues | $23,531 |  | $24,273 |  | (3%) |  | $21,654 |  | $19,398 |  |  |  |  | +12% |  |
| EBT | $5,719 |  | $7,481 |  | (24%) |  | $5,484 |  | $4,285 |  |  |  |  | +28% |  |
| Net income | $5,198 |  | $4,386 |  | +19% |  | $4,816 |  | $4,323 |  |  |  |  | +11% |  |
| EPS | $4.52 |  | $3.59 |  | +26% |  | $4.19 |  | $3.54 |  |  |  |  | +18% |  |

[0001728949-20-000066:8k_2_02:20]
(1)  Discussion regarding our use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results is included at the end of this news release.

[0001728949-20-000066:8k_2_02:21]
(2)  Fourth quarter and fiscal 2020 GAAP results included $1.8 billion, or $1.37 per share, resulting from the settlement agreement with Huawei and royalties for sales made in the March 2020 and June 2020 quarters under the new global patent license agreement with Huawei.  GAAP and Non-GAAP results for the fourth quarter and fiscal 2020 included an estimate of royalties due from Huawei for sales made in the September 2020 quarter under the new global patent license agreement.  GAAP and Non-GAAP results in fiscal 2019 included $450 million of royalties due under a second interim agreement with Huawei that concluded in the third quarter of fiscal 2019.  We did not record any revenues in the fourth quarter of fiscal 2019 or the first three quarters of fiscal 2020 for royalties due on the sales of Huawei’s consumer wireless products.

[0001728949-20-000066:8k_2_02:22]
(3)  Fiscal 2019 GAAP results included $4.7 billion, or $3.23 per share, resulting from the settlement with Apple and its contract manufacturers in April 2019.  GAAP and Non-GAAP results for fiscal 2020 and the second half of fiscal 2019 included royalties from Apple and its contract manufactures.  Revenues in the first six months of fiscal 2019 did not include royalties from sales of Apple or other products by Apple’s contract manufacturers.

[0001728949-20-000066:8k_2_02:23]
(4)  Fiscal 2019 GAAP results included a $2.5 billion tax expense, or ($2.01) per share, due to the derecognition of a deferred tax asset as a result of an agreement with the Internal Revenue Service under which we forwent the federal tax basis step-up in certain distributed intellectual property.  Fiscal 2019 results included a $570 million tax benefit, or $0.47 per share, for GAAP and a $552 million tax benefit, or $0.45 per share, for Non-GAAP relating to certain tax elections made in the first quarter of fiscal 2019.

[0001728949-20-000066:8k_2_02:24]
N/M: Not meaningful

[0001728949-20-000066:8k_2_02:25]
| Qualcomm Announces Fourth Quarter and Fiscal 2020 Results | Page 2 of 10 |

[0001728949-20-000066:8k_2_02:26]
Segment Results

[0001728949-20-000066:8k_2_02:27]
Fourth Quarter

[0001728949-20-000066:8k_2_02:28]
|  | QCT |  | QTL |
| (in millions, except percentages) | Q4 Fiscal 2020 |  | Q4 Fiscal 2019 |  | Change |  | Q4 Fiscal 2020 |  | Q4 Fiscal 2019 |  | Change |  |  |  |
| Revenues | $4,967 |  | $3,611 |  | +38% |  | $1,507 |  | $1,158 |  | +30% |  |  |  |
| EBT | $1,015 |  | $499 |  | +103% |  | $1,107 |  | $792 |  | +40% |  |  |  |
| EBT as % of revenues | 20% |  | 14% |  | +6 points |  | 73% |  | 68% |  | +5 points |  |  |  |
| MSMTM chip shipments | 162 |  | 152 |  | +7% |  |  |  |  |  |  |  |  |  |

[0001728949-20-000066:8k_2_02:29]
Fiscal 2020

[0001728949-20-000066:8k_2_02:30]
|  | QCT |  | QTL |
| (in millions, except percentages) | Fiscal 2020 |  | Fiscal 2019 |  | Change |  | Fiscal 2020 |  | Fiscal 2019 |  | Change |  |  |  |
| Revenues | $16,493 |  | $14,639 |  | +13% |  | $5,028 |  | $4,591 |  | +10% |  |  |  |
| EBT | $2,763 |  | $2,143 |  | +29% |  | $3,442 |  | $2,954 |  | +17% |  |  |  |
| EBT as % of revenues | 17% |  | 15% |  | +2 points |  | 68% |  | 64% |  | +4 points |  |  |  |
| MSMTM chip shipments | 575 |  | 650 |  | (12%) |  |  |  |  |  |  |  |  |  |

[0001728949-20-000066:8k_2_02:31]
Return of Capital to Stockholders

[0001728949-20-000066:8k_2_02:32]
The following table summarizes stock repurchases, before commissions, and dividends paid during the fourth quarter and fiscal 2020:

[0001728949-20-000066:8k_2_02:33]
|  | Stock Repurchases |  | Dividends |  | Total Amount |
| (in millions, except per share data) | Shares |  | Amount |  | Per Share |  | Amount |  |
| Q4 fiscal 2020 | — |  | — |  | $0.65 |  | $734 |  | $734 |
| Fiscal 2020 | 31 |  | $2,450 |  | $2.54 |  | $2,882 |  | $5,332 |

[0001728949-20-000066:8k_2_02:34]
| Qualcomm Announces Fourth Quarter and Fiscal 2020 Results | Page 3 of 10 |

[0001728949-20-000066:8k_2_02:35]
Business Outlook

[0001728949-20-000066:8k_2_02:36]
Starting with our fourth quarter and fiscal 2020 results, we will provide a revenue breakout by Handsets, RF front-end, Automotive and IoT for the QCT segment.  Beginning in fiscal 2021, we will no longer provide MSM chip shipment guidance or actual results.  Additional information is available on our website in our QCT Revenue Streams supplement.

[0001728949-20-000066:8k_2_02:37]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.

[0001728949-20-000066:8k_2_02:38]
|  |  |  | Current Guidance Q1 FY21 Estimates1 |  |
|  | Revenues |  | $7.8B - $8.6B |  |
|  | GAAP diluted EPS |  | $1.67 - $1.87 |  |
|  | Less diluted EPS attributable to QSI |  | $— |  |  |
|  | Less diluted EPS attributable to share-based compensation |  | ($0.24) |  |  |
|  | Less diluted EPS attributable to other items2 |  | ($0.04) |  |  |
|  | Non-GAAP diluted EPS |  | $1.95 - $2.15 |  |
|  | Other Information |  |  |  |
|  | QCT revenues |  | $6.2B - $6.8B |  |
|  | QTL revenues |  | $1.6B - $1.8B |  |

[0001728949-20-000066:8k_2_02:39]
(1)   Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable. Further, due to their nature, certain income and expense items, such as certain investments, derivative and foreign currency transaction gains or losses, cannot be accurately forecast. Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001728949-20-000066:8k_2_02:40]
(2)  Our guidance for diluted EPS attributable to other items for the first quarter of fiscal 2021 is primarily attributable to acquisition-related items.

[0001728949-20-000066:8k_2_02:41]
| Qualcomm Announces Fourth Quarter and Fiscal 2020 Results | Page 4 of 10 |

[0001728949-20-000066:8k_2_02:42]
Conference Call

[0001728949-20-000066:8k_2_02:43]
Qualcomm’s fiscal fourth quarter 2020 earnings conference call will be broadcast live on November 4, 2020, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to our financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at http://investor.qualcomm.com/ immediately prior to the commencement of the call. An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415.  Callers should use reservation number 13711766.

[0001728949-20-000066:8k_2_02:44]
About Qualcomm

[0001728949-20-000066:8k_2_02:45]
Qualcomm is the world’s leading wireless technology innovator and the driving force behind the development, launch and expansion of 5G.  When we connected the phone to the internet, the mobile revolution was born.  Today, our foundational technologies enable the mobile ecosystem and are found in every 3G, 4G and 5G smartphone.  We bring the benefits of mobile to new industries, including automotive, the internet of things and computing, and are leading the way to a world where everything and everyone can communicate and interact seamlessly.

[0001728949-20-000066:8k_2_02:46]
Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of our engineering, research and development functions and substantially all of our products and services businesses, including our QCT semiconductor business.

[0001728949-20-000066:8k_2_02:47]
Note Regarding Forward-Looking Statements

[0001728949-20-000066:8k_2_02:48]
###

[0001728949-20-000066:8k_2_02:49]
Qualcomm and MSM are trademarks or registered trademarks of Qualcomm Incorporated.  Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-20-000066:8k_2_02:50]
MSM is a product of Qualcomm Technologies, Inc.

[0001728949-20-000066:8k_2_02:51]
| Qualcomm Announces Fourth Quarter and Fiscal 2020 Results | Page 5 of 10 |

[0001728949-20-000066:8k_2_02:52]
QUALCOMM Incorporated

[0001728949-20-000066:8k_2_02:53]
CONSOLIDATED BALANCE SHEETS

[0001728949-20-000066:8k_2_02:54]
(In millions, except par value amounts)

[0001728949-20-000066:8k_2_02:55]
(Unaudited)

[0001728949-20-000066:8k_2_02:56]
|  | September 27,2020 |  | September 29,2019 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 6,707 |  |  | $ | 11,839 |  |
| Marketable securities | 4,507 |  |  | 421 |  |
| Accounts receivable, net | 4,003 |  |  | 2,471 |  |
| Inventories | 2,598 |  |  | 1,400 |  |
| Other current assets | 704 |  |  | 634 |  |
| Total current assets | 18,519 |  |  | 16,765 |  |
| Deferred tax assets | 1,351 |  |  | 1,196 |  |
| Property, plant and equipment, net | 3,711 |  |  | 3,081 |  |
| Goodwill | 6,323 |  |  | 6,282 |  |
| Other intangible assets, net | 1,653 |  |  | 2,172 |  |
| Other assets | 4,037 |  |  | 3,461 |  |
| Total assets | $ | 35,594 |  |  | $ | 32,957 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 2,248 |  |  | $ | 1,368 |  |
| Payroll and other benefits related liabilities | 1,053 |  |  | 1,048 |  |
| Unearned revenues | 568 |  |  | 565 |  |
| Short-term debt | 500 |  |  | 2,496 |  |
| Other current liabilities | 4,303 |  |  | 3,458 |  |
| Total current liabilities | 8,672 |  |  | 8,935 |  |
| Unearned revenues | 761 |  |  | 1,160 |  |
| Income taxes payable | 1,872 |  |  | 2,088 |  |
| Long-term debt | 15,226 |  |  | 13,437 |  |
| Other liabilities | 2,986 |  |  | 2,428 |  |
| Total liabilities | 29,517 |  |  | 28,048 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,131 and 1,145 shares issued and outstanding, respectively | 586 |  |  | 343 |  |
| Retained earnings | 5,284 |  |  | 4,466 |  |
| Accumulated other comprehensive income | 207 |  |  | 100 |  |
| Total stockholders’ equity | 6,077 |  |  | 4,909 |  |
| Total liabilities and stockholders’ equity | $ | 35,594 |  |  | $ | 32,957 |  |

[0001728949-20-000066:8k_2_02:57]
| Qualcomm Announces Fourth Quarter and Fiscal 2020 Results | Page 6 of 10 |

[0001728949-20-000066:8k_2_02:58]
QUALCOMM Incorporated

[0001728949-20-000066:8k_2_02:59]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-20-000066:8k_2_02:60]
(In millions, except per share data)

[0001728949-20-000066:8k_2_02:61]
(Unaudited)

[0001728949-20-000066:8k_2_02:62]
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  |  |  |  | September 27,2020 |  | September 29,2019 |  | September 27,2020 |  | September 29,2019 |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services |  |  |  |  |  | $ | 4,921 |  |  | $ | 3,573 |  |  | $ | 16,298 |  |  | $ | 14,611 |  |
| Licensing |  |  |  |  |  | 3,425 |  |  | 1,241 |  |  | 7,233 |  |  | 9,662 |  |
| Total revenues |  |  |  |  |  | 8,346 |  |  | 4,814 |  |  | 23,531 |  |  | 24,273 |  |
| Costs and expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  |  |  |  | 2,766 |  |  | 2,118 |  |  | 9,255 |  |  | 8,599 |  |
| Research and development |  |  |  |  |  | 1,583 |  |  | 1,441 |  |  | 5,975 |  |  | 5,398 |  |
| Selling, general and administrative |  |  |  |  |  | 551 |  |  | 548 |  |  | 2,074 |  |  | 2,195 |  |
| Other |  |  |  |  |  | (6) |  |  | 6 |  |  | (28) |  |  | 414 |  |
| Total costs and expenses |  |  |  |  |  | 4,894 |  |  | 4,113 |  |  | 17,276 |  |  | 16,606 |  |
| Operating income |  |  |  |  |  | 3,452 |  |  | 701 |  |  | 6,255 |  |  | 7,667 |  |
| Interest expense |  |  |  |  |  | (166) |  |  | (150) |  |  | (602) |  |  | (627) |  |
| Investment and other income, net |  |  |  |  |  | 20 |  |  | 64 |  |  | 66 |  |  | 441 |  |
| Income before income taxes |  |  |  |  |  | 3,306 |  |  | 615 |  |  | 5,719 |  |  | 7,481 |  |
| Income tax expense |  |  |  |  |  | (346) |  |  | (109) |  |  | (521) |  |  | (3,095) |  |
| Net income |  |  |  |  |  | $ | 2,960 |  |  | $ | 506 |  |  | $ | 5,198 |  |  | $ | 4,386 |  |
| Basic earnings per share |  |  |  |  |  | $ | 2.62 |  |  | $ | 0.42 |  |  | $ | 4.58 |  |  | $ | 3.63 |  |
| Diluted earnings per share |  |  |  |  |  | $ | 2.58 |  |  | $ | 0.42 |  |  | $ | 4.52 |  |  | $ | 3.59 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  | 1,130 |  |  | 1,197 |  |  | 1,135 |  |  | 1,210 |  |
| Diluted |  |  |  |  |  | 1,148 |  |  | 1,211 |  |  | 1,149 |  |  | 1,220 |  |

[0001728949-20-000066:8k_2_02:63]
| Qualcomm Announces Fourth Quarter and Fiscal 2020 Results | Page 7 of 10 |

[0001728949-20-000066:8k_2_02:64]
QUALCOMM Incorporated

[0001728949-20-000066:8k_2_02:65]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-20-000066:8k_2_02:66]
(In millions)

[0001728949-20-000066:8k_2_02:67]
(Unaudited)

[0001728949-20-000066:8k_2_02:68]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 27,2020 |  | September 29,2019 |  | September 27,2020 |  | September 29,2019 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 2,960 |  |  | $ | 506 |  |  | $ | 5,198 |  |  | $ | 4,386 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization expense | 339 |  |  | 350 |  |  | 1,393 |  |  | 1,401 |  |
| Income tax provision in excess of (less than) income tax payments | 150 |  |  | (230) |  |  | (309) |  |  | 1,976 |  |
| Share-based compensation expense | 313 |  |  | 339 |  |  | 1,212 |  |  | 1,037 |  |
| Net gains on marketable securities and other investments | (67) |  |  | (16) |  |  | (336) |  |  | (356) |  |
| Indefinite and long-lived asset impairment charges | — |  |  | — |  |  | — |  |  | 203 |  |
| Impairment losses on marketable securities and other investments | 57 |  |  | 24 |  |  | 405 |  |  | 135 |  |
| Other items, net | (35) |  |  | (65) |  |  | (142) |  |  | (272) |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | (2,151) |  |  | (78) |  |  | (1,529) |  |  | 1,373 |  |
| Inventories | (219) |  |  | 368 |  |  | (1,157) |  |  | 273 |  |
| Other assets | 29 |  |  | 63 |  |  | (110) |  |  | 78 |  |
| Trade accounts payable | 162 |  |  | (176) |  |  | 907 |  |  | (443) |  |
| Payroll, benefits and other liabilities | 251 |  |  | 158 |  |  | 528 |  |  | (2,376) |  |
| Unearned revenues | (48) |  |  | (16) |  |  | (246) |  |  | (129) |  |
| Net cash provided by operating activities | 1,741 |  |  | 1,227 |  |  | 5,814 |  |  | 7,286 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (348) |  |  | (317) |  |  | (1,407) |  |  | (887) |  |
| Purchases of debt and equity marketable securities | (1,365) |  |  | — |  |  | (6,213) |  |  | — |  |
| Proceeds from sales and maturities of debt and equity marketable securities | 1,388 |  |  | 24 |  |  | 2,399 |  |  | 198 |  |
| Acquisitions and other investments, net of cash acquired | (26) |  |  | (67) |  |  | (185) |  |  | (252) |  |
| Proceeds from other investments | 42 |  |  | 23 |  |  | 100 |  |  | 68 |  |
| Other items, net | (29) |  |  | — |  |  | 43 |  |  | 67 |  |
| Net cash used by investing activities | (338) |  |  | (337) |  |  | (5,263) |  |  | (806) |  |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 562 |  |  | 1,181 |  |  | 2,848 |  |  | 5,989 |  |
| Repayment of short-term debt | (561) |  |  | (1,679) |  |  | (2,846) |  |  | (6,492) |  |
| Proceeds from long-term debt | — |  |  | — |  |  | 1,988 |  |  | — |  |
| Repayment of long-term debt | (219) |  |  | — |  |  | (2,219) |  |  | — |  |
| Proceeds from issuance of common stock | 153 |  |  | 150 |  |  | 329 |  |  | 414 |  |
| Repurchases and retirements of common stock | — |  |  | (705) |  |  | (2,450) |  |  | (1,793) |  |
| Dividends paid | (734) |  |  | (711) |  |  | (2,882) |  |  | (2,968) |  |
| Payments of tax withholdings related to vesting of share-based awards | (18) |  |  | (41) |  |  | (344) |  |  | (266) |  |
| Payment of purchase consideration related to RF360 Holdings | (6) |  |  | (1,119) |  |  | (55) |  |  | (1,163) |  |
| Other items, net | (13) |  |  | (16) |  |  | (76) |  |  | (107) |  |
| Net cash used by financing activities | (836) |  |  | (2,940) |  |  | (5,707) |  |  | (6,386) |  |
| Effect of exchange rate changes on cash and cash equivalents | 20 |  |  | (34) |  |  | 24 |  |  | (32) |  |
| Net increase (decrease) in total cash and cash equivalents | 587 |  |  | (2,084) |  |  | (5,132) |  |  | 62 |  |
| Total cash and cash equivalents at beginning of period | 6,120 |  |  | 13,923 |  |  | 11,839 |  |  | 11,777 |  |
| Total cash and cash equivalents at end of period | $ | 6,707 |  |  | $ | 11,839 |  |  | $ | 6,707 |  |  | $ | 11,839 |  |

[0001728949-20-000066:8k_2_02:69]
| Qualcomm Announces Fourth Quarter and Fiscal 2020 Results | Page 8 of 10 |

[0001728949-20-000066:8k_2_02:70]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-20-000066:8k_2_02:71]
The Non-GAAP financial measures presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, our Non-GAAP financial measures might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP financial measures are presented herein.

[0001728949-20-000066:8k_2_02:72]
We use Non-GAAP financial information: (i) to evaluate, assess and benchmark our operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of our ongoing core operating businesses, including our QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by us include revenues, cost of revenues, research and development (R&D) expenses, selling, general and administrative (SG&A) expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  We are able to assess what we believe is a more meaningful and comparable set of financial performance measures by using Non-GAAP information.  In addition, the HR and Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  We present Non-GAAP financial information to provide greater transparency to investors with respect to our use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0001728949-20-000066:8k_2_02:73]
Non-GAAP information excludes our QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-20-000066:8k_2_02:74]
•QSI is excluded because we expect to exit our strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed as unrelated to our operational performance.

[0001728949-20-000066:8k_2_02:75]
•Share-based compensation expense primarily relates to restricted stock units.  We believe that excluding non-cash share-based compensation from the Non-GAAP financial information allows us and investors to make additional comparisons of the operating activities of our ongoing core businesses over time and with respect to other companies.

[0001728949-20-000066:8k_2_02:76]
•Certain other items are excluded because we view such items as unrelated to the operating activities of our ongoing core businesses, as follows:

[0001728949-20-000066:8k_2_02:77]
◦Acquisition-related items include amortization of acquisition-related intangible assets, substantially all of which relate to the amortization of technology-based intangible assets that is recorded in cost of revenues and will recur in future periods until the related intangible assets have been fully amortized.  We view acquisition-related intangible assets as items arising from pre-acquisition activities determined at the time of an acquisition.  Acquisition-related intangible assets contribute to revenue generation that has not been excluded from our Non-GAAP financial information.  Acquisition-related items also include recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of acquisition-related items, as well as any effects from restructuring the ownership of such acquired assets.  Additionally, we exclude third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition.

[0001728949-20-000066:8k_2_02:78]
◦We exclude certain other items that we view as unrelated to our ongoing businesses, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters.  Beginning in the second quarter of fiscal 2020, we exclude gains and losses driven by the revaluation of our deferred compensation plan liabilities recognized in operating expenses and the offsetting gains and losses on the related plan assets recognized in investment and other income.  Amounts prior to the second quarter of fiscal 2020, which were not material, continue to be included in Non-GAAP results.

[0001728949-20-000066:8k_2_02:79]
◦Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of our ongoing Non-GAAP tax rate and after-tax earnings.

[0001728949-20-000066:8k_2_02:80]
| Qualcomm Announces Fourth Quarter and Fiscal 2020 Results | Page 9 of 10 |

[0001728949-20-000066:8k_2_02:81]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-20-000066:8k_2_02:82]
| (in millions, except per share data and percentages) |  |  |  | GAAP to Non-GAAP Reconciliation | Non-GAAP Supplemental Information |
|  |  |  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items2, 3 | Non-GAAP Results | QCT | QTL | Non-GAAP Reconciling Items4 |
| Q4 FISCAL 2020 |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $8,346 |  | $3 |  | $— |  |  | $1,841 |  |  | $6,502 |  | $4,967 |  | $1,507 |  | $28 |  |
| Operating income (loss) |  |  |  | 3,452 |  | (1) |  | (313) |  | 1,740 |  | 2,026 |  |  |  |  |  |  |  |
| EBT |  |  |  | 3,306 |  | 47 |  | (313) |  | 1,710 |  | 1,862 |  | 1,015 |  | 1,107 |  | (260) |  |
| EBT as % of revenues |  |  |  | 40 | % |  |  |  |  |  |  |  | 29 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 2,960 |  | 28 |  | (252) |  | 1,515 |  | 1,669 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $2.58 |  | $0.02 |  | ($0.22) |  | $1.32 |  | $1.45 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,148 |  | 1,148 |  | 1,148 |  | 1,148 |  | 1,148 |  |  |  |  |  |  |  |
| Q4 FISCAL 2019 |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $4,814 |  | $10 |  | $— |  |  | $— |  |  | $4,804 |  | $3,611 |  | $1,158 |  | $35 |  |
| Operating income (loss) |  |  |  | 701 |  | 3 |  | (339) |  | (100) |  | 1,137 |  |  |  |  |  |  |  |
| EBT |  |  |  | 615 |  | 7 |  | (339) |  | (102) |  | 1,049 |  | 499 |  | 792 |  | (242) |  |
| EBT as % of revenues |  |  |  | 13 | % |  |  |  |  |  |  |  | 22 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 506 |  | 5 |  | (282) |  | (164) |  | 947 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $0.42 |  | $0.00 |  | ($0.23) |  | ($0.14) |  | $0.78 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,211 |  | 1,211 |  | 1,211 |  | 1,211 |  | 1,211 |  |  |  |  |  |  |  |
| FISCAL 20201 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $23,531 |  | $36 |  | $— |  |  | $1,841 |  | $21,654 |  | $16,493 |  | $5,028 |  | $133 |  |
| Operating income (loss) |  |  |  | 6,255 |  | 13 |  | (1,212) |  | 1,522 |  | 5,932 |  |  |  |  |  |  |  |
| EBT |  |  |  | 5,719 |  | (11) |  | (1,212) |  | 1,458 |  | 5,484 |  | 2,763 |  | 3,442 |  | (721) |  |
| EBT as % of revenues |  |  |  | 24 | % |  |  |  |  |  |  |  | 25 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 5,198 |  | (3) |  | (974) |  | 1,359 |  | 4,816 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $4.52 |  | $0.00 |  | ($0.85) |  | $1.18 |  | $4.19 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,149 |  | 1,149 |  | 1,149 |  | 1,149 |  | 1,149 |  |  |  |  |  |  |  |
| FISCAL 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $24,273 |  | $152 |  | $— |  |  | $4,723 |  | $19,398 |  | $14,639 |  | $4,591 |  | $168 |  |
| Operating income (loss) |  |  |  | 7,667 |  | 113 |  | (1,037) |  | 3,891 |  | 4,700 |  |  |  |  |  |  |  |
| EBT |  |  |  | 7,481 |  | 344 |  | (1,037) |  | 3,889 |  | 4,285 |  | 2,143 |  | 2,954 |  | (812) |  |
| EBT as % of revenues |  |  |  | 31 | % |  |  |  |  |  |  |  | 22 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 4,386 |  | 271 |  | (853) |  | 645 |  | 4,323 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $3.59 |  | $0.22 |  | ($0.70) |  | $0.53 |  | $3.54 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,220 |  | 1,220 |  | 1,220 |  | 1,220 |  | 1,220 |  |  |  |  |  |  |  |

[0001728949-20-000066:8k_2_02:83]
(1)   The rapid, global spread of COVID-19 negatively impacted consumer demand for devices that incorporate our products and intellectual property, which negatively impacted our GAAP and Non-GAAP results in fiscal 2020.

[0001728949-20-000066:8k_2_02:84]
(2)   In the fourth quarter and fiscal 2020, other items excluded from Non-GAAP revenues were comprised of revenues related to the amounts due from Huawei under the settlement agreement and royalties due for sales made in the March 2020 and June 2020 quarters under the new global patent license agreement, which were not allocated to our segment results.

[0001728949-20-000066:8k_2_02:85]
(3)  Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” section herein.  Details of amounts included in the “Other Items” column for the prior period are included in the news release for that period.

[0001728949-20-000066:8k_2_02:86]
(4)   Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations.  Non-GAAP reconciling items related to EBT consisted primarily of certain R&D expenses, SG&A expenses, other expenses or income, interest expense and certain investment income that are not allocated to segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit.

[0001728949-20-000066:8k_2_02:87]
Sums may not equal totals due to rounding.

[0001728949-20-000066:8k_2_02:88]
| Qualcomm Announces Fourth Quarter and Fiscal 2020 Results | Page 10 of 10 |

[0001728949-20-000066:8k_2_02:89]
|  | Q4 FISCAL 2020 Supplemental Information and Reconciliations |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |
|  | Cost of revenues |  | $2,766 |  |  | $1 |  |  | $9 |  |  | $68 |  |  | $2,688 |  |
|  | Research and development expenses |  | 1,583 |  |  | — |  |  |  | 226 |  |  | 15 |  |  | 1,342 |  |
|  | Selling, general and administrative expenses |  | 551 |  |  | 3 |  |  | 78 |  |  | 24 |  |  | 446 |  |
|  | Other income |  | (6) |  |  |  | — |  |  |  | — |  |  |  | (6) |  |  |  | — |  |  |
|  | Interest expense |  | 166 |  |  | — |  |  |  | — |  |  |  | 7 |  |  | 159 |  |
|  | Investment and other income (expense), net |  | 20 |  |  | 48 |  |  | — |  |  |  | (23) |  |  | (5) |  |
|  | Income tax expense (benefit) |  | 346 |  |  | 19 |  |  | (61) |  |  | 195 |  |  | 193 |  |

[0001728949-20-000066:8k_2_02:90]
(1)  Other items excluded from Non-GAAP results included $74 million of acquisition-related charges, $54 million of non-marketable investment impairments, $7 million of interest expense related to the 2018 and 2019 European Commission fines and $2 million of charges related to restructuring-related activities, partially offset by a $6 million gain related to a favorable legal settlement. Other items excluded from Non-GAAP results also included $31 million of losses driven by the revaluation of our deferred compensation plan liabilities, which increased operating expenses, offset by corresponding $31 million of gains driven by the revaluation of the associated plan assets, which were included within investment and other income, net.

[0001728949-20-000066:8k_2_02:91]
(2)   At fiscal year end, the quarterly tax provision for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP.  In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column.  Tax expense in the “Other Items” column included a $266 million charge from the combined effect of other items in EBT and a $25 million charge related to the issuance of final foreign-derived intangible income regulations, partially offset by a $61 million tax benefit from tax incentives in a foreign jurisdiction, $26 million of foreign currency gains related to a noncurrent receivable resulting from our refund claim of Korean withholding taxes paid in prior periods and a $9 million tax benefit for the tax effect of acquisition-related charges.

[0001728949-20-000066:8k_2_02:92]
|  | FISCAL 2020 Supplemental Information and Reconciliations |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |
|  | Cost of revenues |  | $9,255 |  |  | $10 |  |  | $34 |  |  | $305 |  |  | $8,906 |  |
|  | Research and development expenses |  | 5,975 |  |  | — |  |  |  | 872 |  |  | 8 |  |  | 5,095 |  |
|  | Selling, general and administrative expenses |  | 2,074 |  |  | 13 |  |  | 306 |  |  | 34 |  |  | 1,721 |  |
|  | Other income |  | (28) |  |  |  | — |  |  |  | — |  |  |  | (28) |  |  | — |  |  |
|  | Interest expense |  | 602 |  |  |  | — |  |  |  | — |  |  |  | 27 |  |  | 575 |  |
|  | Investment and other income (expense), net |  | 66 |  |  | (24) |  |  | — |  |  |  | (37) |  |  | 127 |  |
|  | Income tax expense (benefit) |  | 521 |  |  |  | (8) |  |  | (238) |  |  | 99 |  |  | 668 |  |

[0001728949-20-000066:8k_2_02:93]
(1)  Other items excluded from Non-GAAP results included $329 million of acquisition-related charges, $54 million of non-marketable investment impairments, $26 million of interest expense related to the 2018 and 2019 European Commission fines and $2 million of charges related to restructuring-related activities, partially offset by a $28 million gain related to a favorable legal settlement. Other items excluded from Non-GAAP results also included $17 million of losses driven by the revaluation of our deferred compensation plan liabilities, which increased operating expenses, offset by corresponding $17 million of gains driven by the revaluation of the associated plan assets, which were included within investment and other income, net.

[0001728949-20-000066:8k_2_02:94]
(2)   The tax expense in the “Other Items” column included a $267 million charge from the combined effect of other items in EBT, a $25 million charge related to the issuance of final foreign-derived intangible income regulations, a $13 million charge related to a change in prior period tax rate of a foreign jurisdiction and an $11 million charge related to a foreign tax audit, partially offset by a $61 million tax benefit from tax incentives in a foreign jurisdiction, a $57 million tax benefit from the release of a valuation allowance, a $46 million tax benefit for the tax effect of acquisition-related charges, $32 million of foreign currency gains related to a noncurrent receivable resulting from our refund claim of Korea withholding taxes paid in prior periods and a $21 million tax benefit related to a prior year.
