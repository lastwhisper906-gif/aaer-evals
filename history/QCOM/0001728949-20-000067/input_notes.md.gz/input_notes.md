# QCOM notes — 0001728949-20-000067


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001728949-20-000067:notes:1]
Significant Accounting Policies
We are a global leader in the development and commercialization of foundational technologies for the wireless industry. Our technologies and products are used in mobile devices and other wireless products, including network equipment, broadband gateway equipment, consumer electronic devices and other connected devices, including those used in the internet of things (IoT) and automotive systems for telematics and infotainment. We derive revenues principally from sales of integrated circuit products and through the licensing of our intellectual property, including patents and other rights.

[0001728949-20-000067:notes:2]
Principles of Consolidation. The consolidated financial statements include the assets, liabilities and operating results of Qualcomm and its subsidiaries. During the third quarter of fiscal 2018, we eliminated the one-month reporting lag that was used to consolidate RF360 Holdings Singapore Pte., Ltd. (since its formation in fiscal 2017) to provide contemporaneous reporting within our consolidated financial statements. The effect of this change was not material to the consolidated financial statements, and therefore, the impact of eliminating the one-month reporting lag was included in our results of operations for fiscal 2018. Intercompany transactions and balances have been eliminated.

[0001728949-20-000067:notes:3]
Financial Statement Preparation. The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts and the disclosure of contingent amounts in our consolidated financial statements and the accompanying notes. Examples of our significant accounting estimates and policies that may involve a higher degree of judgment and complexity than others include: the estimation of sales-based royalty revenues; determining the appropriate accounting for the settlement agreement and new global patent license agreement with Huawei; the impairment of non-marketable investments; the valuation of inventories; the impairment of goodwill and long-lived assets; the recognition, measurement and disclosure of loss contingencies related to legal and regulatory proceedings; and the calculation of our income tax provision, including the recognition and measurement of uncertain tax positions. Actual results could differ from those estimates. Certain prior year amounts have been reclassified to conform to the current year presentation.

[0001728949-20-000067:notes:4]
Fiscal Year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. The fiscal year ended September 27, 2020 and September 29, 2019 each included 52 weeks. The fiscal years ended September 30, 2018 included 53 weeks.

[0001728949-20-000067:notes:5]
Recently Adopted Accounting Pronouncements.

[0001728949-20-000067:notes:6]
Leases: In February 2016, the Financial Accounting Standards Board (FASB) issued new accounting guidance related to leases (ASC 842) that outlines a new comprehensive lease accounting model and requires expanded disclosures. Under the new accounting guidance, we are required to recognize right-of-use assets and corresponding lease liabilities on the consolidated balance sheet. We adopted ASC 842 in the first quarter of fiscal 2020 using the modified retrospective approach, with the cumulative effect of initial adoption recorded as an adjustment to our opening consolidated balance sheet at September 30, 2019. We elected to not record leases with a term of 12 months or less on our consolidated balance sheet. In addition, we applied the package of practical expedients permitted under the transition guidance, which among other things, does not require reassessment of lease classification upon adoption. Prior period results have not been restated and continue to be reported in accordance with the accounting guidance in effect for those periods (ASC 840).

[0001728949-20-000067:notes:7]
Upon adoption, we recorded $449 million of operating lease assets in other assets and $500 million of corresponding lease liabilities ($127 million recorded in other current liabilities and $373 million recorded in other liabilities). The difference between the operating lease assets and liabilities of $51 million primarily related to deferred rent liabilities that existed as of the date of adoption. Finance leases were not material for all periods presented. Adoption of the new accounting guidance did not have a material impact on our consolidated statements of operations or cash flows.

[0001728949-20-000067:notes:8]
Revenue Recognition: In May 2014, the FASB issued new accounting guidance related to revenue recognition (ASC 606). We adopted ASC 606 in the first quarter of fiscal 2019 using the modified retrospective transition method only to those contracts that were not completed as of October 1, 2018. We recognized the cumulative effect of initially applying the new revenue accounting guidance as an adjustment to opening retained earnings. Prior period results have not been restated and continue to be reported in accordance with the accounting guidance in effect for those periods (ASC 605).

[0001728949-20-000067:notes:9]
Income Taxes: In October 2016, the FASB issued new accounting guidance that changes the accounting for the income tax effects of intra-entity transfers of assets other than inventory. We adopted the new accounting guidance in the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings of $2.6 billion, primarily as the result of establishing a deferred tax asset on the basis difference of certain intellectual property distributed from one of our foreign subsidiaries to a subsidiary in the United States in fiscal 2018.

[0001728949-20-000067:notes:10]
Cash Equivalents. We consider all highly liquid investments with original maturities of 90 days or less to be cash equivalents. Cash equivalents are comprised of money market funds, certificates of deposit, commercial paper, corporate bonds and notes, certain bank time and demand deposits and government agencies’ securities. The carrying amounts approximate fair value due to the short maturities of these instruments.

[0001728949-20-000067:notes:11]
Marketable Securities. Marketable securities include marketable equity securities, available-for-sale debt securities and, from time-to-time, certain time deposits. We classify marketable securities as current or noncurrent based on the nature of the

[0001728949-20-000067:notes:12]
securities and their availability for use in current operations. Marketable securities are stated at fair value with all realized and unrealized gains and losses on investments in marketable equity securities and realized gains and losses on available-for-sale debt securities recognized in investment and other income, net. Net unrealized gains or losses on available-for-sale debt securities are recorded as a component of accumulated other comprehensive income, net of income taxes. The realized gains and losses on marketable securities are determined using the specific identification method.

[0001728949-20-000067:notes:13]
Debt securities are classified as available for sale or held to maturity at the time of purchase and reevaluated at each balance sheet date. At each balance sheet date, we assess available-for-sale debt securities in an unrealized loss position to determine whether the unrealized loss is other than temporary. We consider factors including: the significance of the decline in value as compared to the cost basis; underlying factors contributing to a decline in the prices of securities in a single asset class; how long the market value of the security has been less than its cost basis; the security’s relative performance versus its peers, sector or asset class; the market and economy in general; views of external investment managers; news or financial information that has been released specific to the investee; and the outlook for the overall industry in which the investee operates.

[0001728949-20-000067:notes:14]
If a debt security’s market value is below amortized cost and we either intend to sell the security or it is more likely than not that we will be required to sell the security before its anticipated recovery, we record an other-than-temporary impairment charge to investment and other income, net for the entire amount of the impairment. For the remaining debt securities, if an other-than-temporary impairment exists, we separate the other-than-temporary impairment into the portion of the loss related to credit factors, or the credit loss portion, which is recorded as a charge to investment and other income, net, and the portion of the loss that is not related to credit factors, or the noncredit loss portion, which is recorded as a component of other accumulated comprehensive income, net of income taxes.

[0001728949-20-000067:notes:15]
Equity Method and Non-marketable Equity Investments. Equity investments for which we have significant influence, but not control, over the investee and are not the primary beneficiary of the investee’s activities are accounted for under the equity method. Our share of gains and losses in equity method investments are recorded in investment and other income, net. We eliminate unrealized profit or loss related to transactions with equity method investees in relation to our ownership interest in the investee, which is recorded as a component of equity in net losses in investees in investment and other income, net. Non-marketable equity investments (for which we do not have significant influence or control) are investments without readily determinable fair values that are recorded based on initial cost minus impairment, if any, plus or minus adjustments resulting from observable price changes in orderly transactions for identical or similar securities. All gains and losses on investments in non-marketable equity securities, realized and unrealized, are recognized in investment and other income, net. We monitor equity method investments and non-marketable equity securities for events or circumstances that could indicate the investments are impaired, such as a deterioration in the investee’s financial condition and business forecasts and lower valuations in recently completed or anticipated financings, and recognize a charge to investment and other income, net for the difference between the estimated fair value and the carrying value. For equity method investments, we record impairment losses in earnings only when impairments are considered other-than-temporary.

[0001728949-20-000067:notes:16]
Derivatives. Our primary objectives for holding derivative instruments are to manage foreign exchange risk for certain foreign currency revenues, operating expenses, receivables and payables and to manage interest rate risk on our long-term debt. Derivative instruments are recorded at fair value and included in other current or noncurrent assets or other current or noncurrent liabilities based on their maturity dates. Counterparties to our derivative instruments are all major banking institutions.

[0001728949-20-000067:notes:17]
Foreign Currency Hedges: We manage our exposure to foreign exchange market risks, when deemed appropriate, through the use of derivative instruments, including foreign currency forward and option contracts with financial counterparties, that may or may not be designated as hedging instruments. At September 27, 2020, these derivative instruments have maturity dates of less than twelve months. Gains and losses arising from such contracts that are designated as cash flow hedging instruments are recorded as a component of accumulated other comprehensive income as gains and losses on derivative instruments, net of income taxes. The hedging gains and losses in accumulated other comprehensive income are subsequently reclassified to revenues or costs and expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect our earnings. The cash flows associated with derivative instruments designated as cash flow hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The fair values of our foreign currency forward and option contracts used to hedge foreign currency risk designated as cash flow hedges recorded in total assets and in total liabilities were $51 million and negligible, respectively, at September 27, 2020. The fair values of our foreign currency forward and option contracts used to hedge foreign currency risk designated as cash flow hedges recorded in total assets were negligible at September 29, 2019.

[0001728949-20-000067:notes:18]
For foreign currency forward and option contracts not designated as hedging instruments, the changes in fair value are recorded in investment and other income, net in the period of change. The cash flows associated with derivative instruments not designated as hedging instruments are classified as cash flows from operating activities in the consolidated statements of cash flows, which is the same category as the hedged transaction. The fair values of our foreign currency forward and option contracts not designated as hedging instruments were negligible at September 27, 2020 and September 29, 2019.

[0001728949-20-000067:notes:19]
Interest Rate Swaps: From time to time, we manage our exposure to certain interest rate risks related to our long-term debt through the use of interest rate swaps. Such swaps allow us to effectively convert fixed-rate payments into floating-rate payments based on LIBOR. These transactions are designated as fair value hedges, and the gains and losses related to

[0001728949-20-000067:notes:20]
changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to changes in the market interest rates. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate debt attributable to the hedged risks, are recognized in earnings as interest expense in the current period. The interest settlement payments associated with the interest rate swap agreements are classified as cash flows from operating activities in the consolidated statements of cash flows. During fiscal 2020, our remaining interest rate swaps related to certain of our May 2015 Notes were terminated. The aggregate fair value of our interest rate swaps related to long-term debt was negligible at September 29, 2019.

[0001728949-20-000067:notes:21]
Gross Notional Amounts: The gross notional amounts of our foreign currency and interest rate derivatives by instrument type were as follows (in millions):

[0001728949-20-000067:notes:22]
|  | September 27,2020 |  | September 29,2019 |
| Forwards | $ | 1,096 |  |  | $ | 878 |  |
| Options | 789 |  |  | 176 |  |
| Swaps | — |  |  | 1,750 |  |
|  | $ | 1,885 |  |  | $ | 2,804 |  |

[0001728949-20-000067:notes:23]
The gross notional amounts of our derivatives by currency were as follows (in millions):

[0001728949-20-000067:notes:24]
|  | September 27,2020 |  | September 29,2019 |
| Chinese renminbi | $ | 1,058 |  |  | $ | 463 |  |
| Indian rupee | 595 |  |  | 440 |  |
| Japanese yen | 33 |  |  | 12 |  |
| United States dollar | 199 |  |  | 1,889 |  |
|  | $ | 1,885 |  |  | $ | 2,804 |  |

[0001728949-20-000067:notes:25]
Other Hedging Activities. We have designated $1.4 billion of foreign currency-denominated liabilities, excluding accrued interest, related to the fines imposed by the European Commission (Note 7) as hedges of our net investment in certain foreign subsidiaries as of September 27, 2020 and September 29, 2019. Gains and losses arising from the portion of these balances that are designated as net investment hedges are recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment.

[0001728949-20-000067:notes:26]
Fair Value Measurements. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants as of the measurement date. Applicable accounting guidance provides an established hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Observable inputs are inputs that market participants would use in valuing the asset or liability and are developed based on market data obtained from sources independent of us. Unobservable inputs are inputs that reflect our assumptions about the factors that market participants would use in valuing the asset or liability. There are three levels of inputs that may be used to measure fair value:

[0001728949-20-000067:notes:27]
•Level 1 includes financial instruments for which quoted market prices for identical instruments are available in active markets.

[0001728949-20-000067:notes:28]
•Level 2 includes financial instruments for which there are inputs other than quoted prices included within Level 1 that are observable for the instrument.

[0001728949-20-000067:notes:29]
•Level 3 includes financial instruments for which fair value is derived from valuation techniques in which one or more significant inputs are unobservable, including our own assumptions.

[0001728949-20-000067:notes:30]
Assets and liabilities measured at fair value are classified based on the lowest level of input that is significant to the fair value measurement. We review the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy. We recognize transfers into and out of levels within the fair value hierarchy at the end of the fiscal month in which the actual event or change in circumstances that caused the transfer to occur.

[0001728949-20-000067:notes:31]
Cash Equivalents and Marketable Securities: With the exception of auction rate securities, we obtain pricing information from quoted market prices, pricing vendors or quotes from brokers/dealers. We conduct reviews of our primary pricing

[0001728949-20-000067:notes:32]
vendors to determine whether the inputs used in the vendor’s pricing processes are deemed to be observable. The fair value for interest-bearing securities includes accrued interest.

[0001728949-20-000067:notes:33]
The fair value of U.S. Treasury securities and government-related securities, corporate bonds and notes and common stock is generally determined using standard observable inputs, including reported trades, quoted market prices, matrix pricing, benchmark yields, broker/dealer quotes, issuer spreads, two-sided markets and/or benchmark securities.

[0001728949-20-000067:notes:34]
The fair value of mortgage- and asset-backed securities is derived from the use of matrix pricing (prices for similar securities) or, in some cases, cash flow pricing models with observable inputs, such as contractual terms, maturity, credit rating and/or securitization structure to determine the timing and amount of future cash flows.

[0001728949-20-000067:notes:35]
The fair value of auction rate securities is estimated using a discounted cash flow model that incorporates transaction details, such as contractual terms, maturity and timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery, the future state of the auction rate market and credit valuation adjustments of market participants. Though most of the securities we hold are pools of student loans guaranteed by the United States government, prepayment speeds and illiquidity discounts are considered significant unobservable inputs, and therefore, auction rate securities are included in Level 3.

[0001728949-20-000067:notes:36]
Derivative Instruments: Derivative instruments that are traded on an exchange are valued using quoted market prices and are included in Level 1. Derivative instruments that are not traded on an exchange are valued using conventional calculations/models that are primarily based on observable inputs, such as foreign currency exchange rates, volatilities and interest rates, and therefore, such derivative instruments are included in Level 2.

[0001728949-20-000067:notes:37]
Other Investments and Other Liabilities: Other investments and other liabilities included in Level 1 are comprised of our deferred compensation plan liabilities and related assets, which consist of mutual funds and are included in other assets. Gains and losses on the revaluation of our deferred compensation plan assets are recorded in investment and other income, net (Note 2) and are not allocated to our segments. Corresponding offsetting amounts related to the revaluation of our deferred compensation plan liabilities are included in unallocated operating expenses (Note 8). Other investments and other liabilities included in Level 3 are primarily comprised of convertible debt instruments issued by private companies. The fair value of convertible debt instruments is estimated based on the estimated timing and amount of future cash flows, as well as assumptions related to liquidity, default likelihood and recovery. The inputs we use to estimate the fair values of the convertible debt instruments are generally unobservable, and therefore, they are included in Level 3.

[0001728949-20-000067:notes:38]
Inventories. Inventories are valued at the lower of cost and net realizable value using the first-in, first-out method. Recoverability of inventories is assessed based on review of future customer demand that considers multiple factors, including committed purchase orders from customers as well as purchase commitment projections provided by customers and our own forecasts of customer demand, among other factors. This valuation also requires us to make judgments and assumptions based on information currently available about market conditions, including competition, product pricing, product life cycle, development plans and other broader market conditions that may impact customer demand, such as the coronavirus (COVID-19) pandemic in fiscal 2020 that negatively impacted consumer demand for certain devices that incorporate our products. As we move to smaller geometry process technologies, the manufacturing lead-time increases, resulting in an increased reliance on our own forecasts of customer demand, rather than our customers’ forecasts. If we overestimate demand for our products, the amount of our loss will be impacted by our contractual ability to reduce inventory purchases from our suppliers. Our assumptions of future product demand are inherently uncertain, and changes in our estimates and assumptions may cause us to record additional write-downs in the future if demand forecasted for specific products is greater than actual demand.

[0001728949-20-000067:notes:39]
Property, Plant and Equipment. Property, plant and equipment are recorded at cost and depreciated or amortized using the straight-line method over their estimated useful lives. Upon the retirement or disposition of property, plant and equipment, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded, when appropriate. Buildings on owned land are depreciated over 30 years, and building improvements are depreciated over 15 years. Leasehold improvements and buildings on leased land are amortized over the shorter of their estimated useful lives, not to exceed 15 years and 30 years, respectively, or the remaining term of the related lease. Other property, plant and equipment have useful lives ranging from 2 to 25 years. Maintenance, repairs and minor renewals or betterments are charged to expense as incurred.

[0001728949-20-000067:notes:40]
Operating Leases. As a result of the adoption of ASC 842, we revised our operating lease accounting policy beginning in fiscal 2020 as follows.

[0001728949-20-000067:notes:41]
Operating lease assets and liabilities are recognized for leases with lease terms greater than 12 months based on the present value of the future lease payments over the lease term at the commencement date. Operating leases are included in other assets, other current liabilities and other liabilities on our consolidated balance sheet. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise such option. We account for substantially all lease and related non-lease components together as a single lease component. Operating lease expense is recognized on a straight-line basis over the lease term.

[0001728949-20-000067:notes:42]
Goodwill and Other Intangible Assets. Goodwill represents the excess of purchase price over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Acquired intangible assets other than goodwill are amortized over their useful lives unless the lives are determined to be indefinite. For intangible assets purchased in a business

[0001728949-20-000067:notes:43]
combination, the estimated fair values of the assets received are used to establish their recorded values. For intangible assets acquired in a nonmonetary exchange, the estimated fair values of the assets transferred (or the estimated fair values of the assets received, if more clearly evident) are used to establish their recorded values, unless the values of neither the assets received nor the assets transferred are determinable within reasonable limits, in which case the assets received are measured based on the carrying values of the assets transferred. Valuation techniques consistent with the market approach, income approach and/or cost approach are used to measure fair value. An estimate of fair value can be affected by many assumptions that require significant judgment. For example, the income approach generally requires us to use assumptions to estimate future cash flows including those related to total addressable market, pricing and share forecasts, competition, technology obsolescence, future tax rates and discount rates. Our estimate of the fair value of certain assets may differ materially from that determined by others who use different assumptions or utilize different business models and from the future cash flows actually realized.

[0001728949-20-000067:notes:44]
Impairment of Goodwill, Other Indefinite-Lived Assets and Long-Lived Assets. Goodwill and other indefinite-lived intangible assets are tested annually for impairment in the fourth fiscal quarter and in interim periods if events or changes in circumstances indicate that the assets may be impaired. If a qualitative assessment is used and we determine that the fair value of a reporting unit or indefinite-lived intangible asset is more likely than not (i.e., a likelihood of more than 50%) less than its carrying amount, a quantitative impairment test will be performed. If goodwill is quantitatively assessed for impairment and a reporting unit’s carrying value exceeds its fair value, the difference is recorded as an impairment. Other indefinite-lived intangible assets are quantitatively assessed for impairment, if necessary, by comparing their estimated fair values to their carrying values. If the carrying value exceeds the fair value, the difference is recorded as an impairment. Our judgments regarding the existence of impairment indicators and future cash flows related to goodwill and long-lived assets may be based on operational performance of our businesses, market conditions, expected selling price and/or other factors. Although there are inherent uncertainties in this assessment process, the estimates and assumptions we use, including estimates of future cash flows and discount rates, are consistent with our internal planning, when appropriate. If these estimates or their related assumptions change in the future, we may be required to record an impairment charge on a portion or all of our goodwill and/or long-lived assets. Furthermore, we cannot predict the occurrence of future impairment-triggering events nor the impact such events might have on our reported asset values. Future events could cause us to conclude that impairment indicators exist, and that goodwill associated with our acquired businesses are impaired.

[0001728949-20-000067:notes:45]
Long-lived assets, such as property, plant and equipment and intangible assets subject to amortization, are reviewed for impairment when there is evidence that events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by comparing the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Long-lived assets to be disposed of by sale are reported at the lower of their carrying amounts or their estimated fair values less costs to sell and are not depreciated.

[0001728949-20-000067:notes:46]
Revenue Recognition. We derive revenues principally from sales of integrated circuit products and licensing of our intellectual property. We also generate revenues from licensing system software and by performing development and other services and from other product sales. The timing of revenue recognition and the amount of revenue actually recognized in each case depends upon a variety of factors, including the specific terms of each arrangement and the nature of our performance obligations.

[0001728949-20-000067:notes:47]
Revenues from sales of our products are recognized upon transfer of control to the customer, which is generally at the time of shipment. Revenues from providing services are typically recognized over time as our performance obligation is satisfied. Revenues from providing services and licensing system software were each less than 5% of total revenues for all periods presented.

[0001728949-20-000067:notes:48]
We grant licenses or otherwise provide rights to use portions of our intellectual property portfolio, which, among other rights, includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Licensees pay royalties based on their sales of products incorporating or using our licensed intellectual property and may also pay a fixed license fee in one or more installments. Sales-based royalties are generally based upon a percentage of the wholesale (i.e., licensee’s) selling price of complete licensed products, net of certain permissible deductions (including transportation, insurance, packing costs and other items). We broadly provide per unit royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets, laptops and smartwatches, and provide for a maximum royalty amount payable per device. We estimate and recognize sales-based royalties on such licensed products in the period in which the associated sales occur, considering all relevant information (historical, current and forecasted) that is reasonably available to us. Our estimates of sales-based royalties are based largely on preliminary royalty estimates provided by our licensees and, to a lesser extent, an assessment of the volume of devices supplied into the market that incorporate or use our licensed intellectual property, combined with an estimate of the mix of such sales on a licensee-by-licensee basis, as well as the licensees’ average wholesale prices of such products. We have recognized immaterial differences between preliminary royalty estimates provided to us by licensees and actual amounts reported and paid by licensees, which are generally received the following quarter, as licensees have not completed their royalty reporting process at the time estimates are provided to us, and in certain cases, they do not provide all necessary information in order for us to calculate an estimate of royalties due, which requires us to independently estimate certain information. We also consider in our estimates of sales-based royalties any changes in pricing we plan or expect to make and certain constraints on our ability to estimate such royalties. As a result

[0001728949-20-000067:notes:49]
of recognizing revenues in the period in which the licensees’ sales occur using estimates, adjustments to revenues are required in subsequent periods to reflect changes in estimates as new information becomes available, primarily resulting from actual amounts reported by our licensees.

[0001728949-20-000067:notes:50]
License agreements that require payment of license fees contain a single performance obligation that represents ongoing access to a portfolio of intellectual property over the license term since such agreements provide the licensee the right to access a portfolio of intellectual property that exists at inception of the license agreement and to updates and new intellectual property that is added to the licensed portfolio during the term of the agreement that are highly interdependent or interrelated. Since we expect to expend efforts to develop and transfer updates to our licensed portfolio on an even basis, license fees are recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee.

[0001728949-20-000067:notes:51]
We account for a contract with a customer/licensee when it is legally enforceable, the parties are committed to perform their respective obligations, the rights of the parties regarding the goods and/or services to be transferred are identified, payment terms are identified, the contract has commercial substance and collectability of substantially all of the consideration is probable. If all such conditions are not met, revenues and any associated receivables are generally not recognized until such time that the required conditions are met. Cash collected from customers prior to a contract existing is recorded to other customer-related liabilities in other current liabilities.

[0001728949-20-000067:notes:52]
From time to time, regulatory authorities investigate our business practices, particularly with respect to our licensing business, and institute proceedings against us. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others, the loss of our ability to enforce one or more of our patents; injunctions; monetary damages or fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed original equipment manufacturers (OEMs) or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. Additionally, from time to time, companies initiate various strategies in an attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property, which may include disputing, underreporting, underpaying, not reporting and/or not paying royalties owed to us under their license agreements with us, or reporting to us in a manner that is not in compliance with their contractual obligations. In such cases, we estimate and recognize licensing revenues only when we have a contract, as defined in the revenue recognition guidance, which includes, among other items, evaluating whether our license agreements remain valid and enforceable and evaluating licensees’ conduct and whether they remain committed to perform their respective obligations. We also estimate and recognize licensing revenues only to the extent it is probable that a significant reversal of cumulative revenues recognized will not occur, which includes, among other items, determining the expected impact, if any, to revenues of any license agreements that may be renegotiated and/or are newly entered into. We analyze the risk of a significant revenue reversal considering both the likelihood and magnitude of the reversal and, if necessary, constrain the amount of estimated revenues recognized in order to mitigate this risk, which may result in recognizing revenues less than amounts contractually owed to us. These aforementioned estimates may require significant judgment.

[0001728949-20-000067:notes:53]
We measure revenues (including our estimates of sales-based royalties) based on the amount of consideration we expect to receive in exchange for products or services. We record reductions to revenues for customer incentive arrangements, including volume-related and other pricing rebates and cost reimbursements for marketing and other activities involving certain of our products and technologies, in the period that the related revenues are earned. The charges for such arrangements are recorded as a reduction to accounts receivable, net or as other current liabilities based on whether we have the intent and contractual right of offset. Certain of these charges are considered variable consideration and are included in the transaction price primarily based on estimating the most likely amount expected to be provided to the customer/licensee.

[0001728949-20-000067:notes:54]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied performance obligations.

[0001728949-20-000067:notes:55]
Concentrations. A significant portion of our revenues are concentrated with a small number of customers/licensees of our QCT and QTL segments. Revenues from four customers/licensees comprised 19%, 12%, 10% and 10% of total consolidated revenues in fiscal 2020. Revenues from three customers/licensees comprised 15%, 10% and 24% of total consolidated revenues in fiscal 2019 and 16%, 11% and 11% in fiscal 2018. Revenues in fiscal 2020 were positively impacted by the settlement of our prior dispute with Huawei (Note 8). Revenues in fiscal 2018 were negatively impacted by our prior dispute with Apple and its contract manufacturers.

[0001728949-20-000067:notes:56]
We rely on sole- or limited-source suppliers for some products, particularly products in the QCT segment, subjecting us to possible shortages of raw materials or manufacturing capacity. The loss of a supplier or the inability of a supplier to meet performance or quality specifications or delivery schedules could harm our ability to meet our delivery obligations and/or negatively impact our revenues, business operations and ability to compete for future business.

[0001728949-20-000067:notes:57]
Shipping and Handling Costs. Costs incurred for shipping and handling are included in cost of revenues. Amounts billed to a customer for shipping and handling are reported as revenues.

[0001728949-20-000067:notes:58]
Share-Based Compensation. Share-based compensation expense for equity-classified awards, principally related to restricted stock units (RSUs), is measured at the grant date, or at the acquisition date for awards assumed in business combinations, based on the estimated fair value of the award and is recognized over the employee’s requisite service period.

[0001728949-20-000067:notes:59]
The fair values of RSUs are estimated based on the fair market values of the underlying stock on the dates of grant or dates the RSUs are assumed. Share-based compensation expense is adjusted to exclude amounts related to share-based awards that are expected to be forfeited.

[0001728949-20-000067:notes:60]
Legal and Regulatory Proceedings. We are currently involved in certain legal and regulatory proceedings. Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Investigations by antitrust and trade regulation agencies are not conducted in a consistent manner across jurisdictions. Further, each country and agency has different sets of laws, rules and regulations, both substantive and procedural, as well as different legal principles, theories and potential remedies, and some agencies may seek to use the investigation to advance domestic policy goals. Depending on the jurisdiction, these investigations can involve non-transparent procedures under which we may not receive access to evidence relied upon by the enforcement agency or that may be exculpatory and may not be informed of the specific legal theories or evidence considered or relied upon by the agency. Unlike in civil litigation in the United States, in foreign proceedings, we may not be entitled to discovery or depositions, allowed to cross-examine witnesses or confront our accusers. As a result, we may not be aware of, and may not be entitled to know, all allegations against us, or the information or documents provided to, or discovered or prepared by, the agency. Accordingly, we may have little or no idea what an agency’s intent is with respect to liability, penalties or the timing of a decision. In many cases the agencies are given significant discretion, and any available precedent may have limited, if any, predictive value in their jurisdictions, much less in other jurisdictions. Accordingly, we cannot predict the outcome of these matters. A broad range of remedies with respect to our business practices that are deemed to violate applicable laws are potentially available. These remedies may include, among others, injunctions, monetary damages or fines or other orders to pay money and the issuance of orders to cease certain conduct and/or to modify our business practices.

[0001728949-20-000067:notes:61]
If there is at least a reasonable possibility that a material loss may have been incurred associated with pending legal and regulatory proceedings, we disclose such fact, and if reasonably estimable, we provide an estimate of the possible loss or range of possible loss. We record our best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of loss can be reasonably estimated with no best estimate in the range, we record the minimum estimated liability. As additional information becomes available, we assess the potential liability related to pending legal and regulatory proceedings and revise our estimates and update our disclosures accordingly. Significant judgment is required in both the determination of probability and the determination as to whether a loss is reasonably estimable. Our legal costs associated with defending ourself are recorded to expense as incurred.

[0001728949-20-000067:notes:62]
Foreign Currency. Certain foreign subsidiaries use a local currency as the functional currency. Resulting translation gains or losses are recorded as a component of accumulated other comprehensive income. Transaction gains or losses related to balances denominated in a currency other than the functional currency are recognized in the consolidated statements of operations.

[0001728949-20-000067:notes:63]
Income Taxes. The asset and liability approach is used to recognize deferred tax assets and liabilities for the expected future tax consequences of temporary differences between the carrying amounts and the tax bases of assets and liabilities. Tax law and rate changes are reflected in income in the period such changes are enacted. We record a valuation allowance to reduce deferred tax assets to the amount that is more likely than not to be realized. We include interest and penalties related to income taxes, including unrecognized tax benefits, within income tax expense. We classify all deferred tax assets and liabilities as noncurrent in the consolidated balance sheets.

[0001728949-20-000067:notes:64]
Our income tax returns are based on calculations and assumptions that are subject to examination by the Internal Revenue Service (IRS) and other tax authorities. In addition, the calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations. We recognize liabilities for uncertain tax positions based on a two-step process. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. While we believe we have appropriate support for the positions taken on our tax returns, we regularly assess the potential outcomes of examinations by tax authorities in determining the adequacy of our provision for income taxes. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts that give rise to a revision become known.

[0001728949-20-000067:notes:65]
We recognize excess tax benefits and shortfall tax detriments associated with share-based awards in the consolidated statements of operations, as a component of income tax expense, when realized.

[0001728949-20-000067:notes:66]
We are subject to income taxes in the United States and numerous foreign jurisdictions, and the assessment of our income tax positions involves dealing with uncertainties in the application of complex tax laws and regulations in various taxing jurisdictions. In addition, the application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws and regulations themselves are subject to change as a result of changes in fiscal policy, changes in legislation, the evolution of regulations and court rulings. Significant judgments and estimates are required in determining our provision for income taxes, including those related to special deductions such as FDII (foreign-derived intangible income), tax incentives, intercompany research and development cost-sharing arrangements, transfer pricing, tax credits and the realizability of deferred tax assets. While we believe we have appropriate support for the positions we have taken or that we plan to take on our tax returns, we regularly assess the potential outcomes of examinations by taxing

[0001728949-20-000067:notes:67]
authorities in determining the adequacy of our provision for income taxes. Therefore, the actual liability for U.S. or foreign taxes may be materially different from our estimates, which could result in the need to record additional tax liabilities or potentially reverse previously recorded tax liabilities. We are participating in the Internal Revenue Service (IRS) Compliance Assurance Process program whereby we endeavor to agree with the IRS on the treatment of all issues prior to filing our federal return. A benefit of participation in this program is that post-filing adjustments by the IRS are less likely to occur.

[0001728949-20-000067:notes:68]
Earnings (Loss) Per Common Share. Basic earnings (loss) per common share is computed by dividing net income (loss) by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per common share is computed by dividing net income by the combination of the weighted-average number of dilutive common share equivalents, comprised of shares issuable under our share-based compensation plans and shares subject to accelerated share repurchase agreements, if any, and the weighted-average number of common shares outstanding during the reporting period. Due to the net loss in fiscal 2018, all of the common share equivalents issuable under share-based compensation plans and the accelerated share repurchase agreements we entered into in fiscal 2018 had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share. The following table provides information about the diluted earnings per share calculation (in millions):

[0001728949-20-000067:notes:69]
|  | 2020 |  | 2019 |  | 2018 |
| Dilutive common share equivalents included in diluted shares | 14 |  |  | 10 |  |  | — |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 1 |  |  | 8 |  |  | 51 |  |

[0001728949-20-000067:notes:70]
Recent Accounting Pronouncements Not Yet Adopted.

[0001728949-20-000067:notes:71]
Financial Assets: In June 2016, the FASB issued new accounting guidance that changes the accounting for recognizing impairments of financial assets. Under the new accounting guidance, credit losses for financial assets held at amortized cost (such as accounts receivable) will be estimated based on expected losses rather than the current incurred loss impairment model. Our historical credit losses for accounts receivable have been immaterial. The new accounting guidance also eliminates the concept of other-than-temporary impairment and requires credit losses related to available-for-sale debt securities to be recorded through an allowance for credit losses rather than as a reduction in the amortized cost basis of the securities. These changes will result in earlier recognition of credit losses, if any. The new accounting guidance generally requires the modified retrospective transition method, with the cumulative effect of applying the new accounting guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. We will adopt the new accounting guidance in the first quarter of fiscal 2021. We do not expect this new accounting guidance will have a material impact to our consolidated financial statements at adoption. The future impact of such accounting guidance will largely depend on the future composition and credit quality of our investment portfolio and accounts receivable, as well as future economic conditions.


## us-gaap:LesseeLeasesPolicyTextBlock

[0001728949-20-000067:notes:72]
Operating lease assets and liabilities are recognized for leases with lease terms greater than 12 months based on the present value of the future lease payments over the lease term at the commencement date. Operating leases are included in other assets, other current liabilities and other liabilities on our consolidated balance sheet. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise such option. We account for substantially all lease and related non-lease components together as a single lease component. Operating lease expense is recognized on a straight-line basis over the lease term.
We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001728949-20-000067:notes:73]
Revenues recognized from sales of our products and sales-based royalties are generally included in accounts receivable, net (including unbilled receivables) based on our unconditional right to payment for satisfied or partially satisfied performance obligations.
Shipping and Handling Costs. Costs incurred for shipping and handling are included in cost of revenues. Amounts billed to a customer for shipping and handling are reported as revenues.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-20-000067:notes:74]
Composition of Certain Financial Statement Items

[0001728949-20-000067:notes:75]
| Accounts Receivable (in millions) |  |  |  |
|  | September 27,2020 |  | September 29,2019 |
| Trade, net of allowances for doubtful accounts | $ | 2,687 |  |  | $ | 1,046 |  |
| Unbilled | 1,305 |  |  | 1,411 |  |
| Other | 11 |  |  | 14 |  |
|  | $ | 4,003 |  |  | $ | 2,471 |  |

[0001728949-20-000067:notes:76]
Accounts receivable at September 27, 2020 included $1.3 billion, excluding the impact of foreign withholding taxes, from Huawei related to the remaining amounts due under the settlement agreement and estimated royalties for sales made in the September 2020 quarter. In July 2020, we entered into a settlement agreement with Huawei to resolve our prior dispute related to the license agreement that expired on December 31, 2019. We also entered into a new long-term, global patent license agreement that applies to sales of certain wireless products by Huawei beginning on January 1, 2020. Amounts due under the settlement agreement are to be paid in installments by the end of June 2021 in accordance with an agreed upon payment schedule. In the fourth quarter of fiscal 2020, Huawei paid the first installment under the settlement agreement and the royalties due for the March 2020 and June 2020 quarters under the new global patent license agreement.

[0001728949-20-000067:notes:77]
Significant evaluation and judgment were required in determining the appropriate accounting for the settlement agreement and new global patent license agreement with Huawei. We considered, among other items, Huawei’s commitment to perform under such agreements (including Huawei’s intent and ability to pay amounts due), Huawei’s performance to date under the agreements (including timely payments made), Huawei’s current and projected financial condition (including the

[0001728949-20-000067:notes:78]
impact of enacted national security protection policies by the U.S. government on Huawei’s business) and certain contractual protections that we obtained under these agreements.

[0001728949-20-000067:notes:79]
Based on this evaluation, we concluded that the revenue recognition criteria were met, and we recorded revenues of $1.8 billion in the fourth quarter of fiscal 2020 related to the full amount due from Huawei under the settlement agreement and amounts paid for the March 2020 and June 2020 quarters under the new global patent license agreement. In addition, QTL results for the fourth quarter of fiscal 2020 included estimated royalties due from Huawei for sales made in the September 2020 quarter under the new global patent license agreement.

[0001728949-20-000067:notes:80]
Although we believe that the judgments supporting our assessment are reasonable based on facts and factors currently known, our judgments, including those discussed in the preceding paragraph, as it relates to future events are inherently uncertain and actual results and outcomes may differ from the results and outcomes currently anticipated.

[0001728949-20-000067:notes:81]
| Inventories (in millions) |  |  |  |
|  | September 27,2020 |  | September 29,2019 |
| Raw materials | $ | 94 |  |  | $ | 77 |  |
| Work-in-process | 1,155 |  |  | 667 |  |
| Finished goods | 1,349 |  |  | 656 |  |
|  | $ | 2,598 |  |  | $ | 1,400 |  |

[0001728949-20-000067:notes:82]
| Property, Plant and Equipment (in millions) |  |  |  |
|  | September 27,2020 |  | September 29,2019 |
| Land | $ | 173 |  |  | $ | 170 |  |
| Buildings and improvements | 1,606 |  |  | 1,546 |  |
| Computer equipment and software | 1,427 |  |  | 1,356 |  |
| Machinery and equipment | 5,095 |  |  | 4,007 |  |
| Furniture and office equipment | 90 |  |  | 86 |  |
| Leasehold improvements | 320 |  |  | 301 |  |
| Construction in progress | 134 |  |  | 182 |  |
|  | 8,845 |  |  | 7,648 |  |
| Less accumulated depreciation and amortization | (5,134) |  |  | (4,567) |  |
|  | $ | 3,711 |  |  | $ | 3,081 |  |

[0001728949-20-000067:notes:83]
Depreciation and amortization expense related to property, plant and equipment for fiscal 2020, 2019 and 2018 was $772 million, $674 million and $776 million, respectively.

[0001728949-20-000067:notes:84]
Goodwill and Other Intangible Assets. We allocate goodwill to our reporting units for impairment testing purposes. The following table presents the goodwill allocated to our reportable and nonreportable segments, as described in Note 8, as well as the changes in the carrying amounts of goodwill during fiscal 2020 and 2019 (in millions):

[0001728949-20-000067:notes:85]
|  |  | QCT |  | QTL |  | Nonreportable Segments |  | Total |
| Balance at September 30, 2018 |  | $ | 5,587 |  |  | $ | 718 |  |  | $ | 193 |  |  | $ | 6,498 |  |
| Acquisitions |  | 18 |  |  | — |  |  | — |  |  | 18 |  |
| Impairments (Note 9) |  | — |  |  | — |  |  | (146) |  |  | (146) |  |
| Other (1) |  | (40) |  |  | (1) |  |  | (47) |  |  | (88) |  |
| Balance at September 29, 2019 (2) |  | 5,565 |  |  | 717 |  |  | — |  |  | 6,282 |  |
| Other (1) |  | 40 |  |  | 1 |  |  | — |  |  | 41 |  |
| Balance at September 27, 2020 (2) |  | $ | 5,605 |  |  | $ | 718 |  |  | $ | — |  |  | $ | 6,323 |  |

[0001728949-20-000067:notes:86]
(1)In fiscal 2020, changes in goodwill resulted from certain foreign currency translation adjustments. In fiscal 2019, changes in goodwill amounts resulted from the sale of our mobile health nonreportable segment, foreign currency translation and purchase accounting adjustments.

[0001728949-20-000067:notes:87]
(2)Cumulative goodwill impairments were $812 million at both September 27, 2020 and September 29, 2019.

[0001728949-20-000067:notes:88]
The components of other intangible assets, net were as follows (in millions):

[0001728949-20-000067:notes:89]
|  | September 27, 2020 |  | September 29, 2019 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Weighted-average amortization period(years) |
| Technology-based | $ | 5,556 |  |  | $ | (3,958) |  |  | 11 |  | $ | 5,958 |  |  | $ | (3,851) |  |  | 10 |
| Other | 105 |  |  | (50) |  |  | 9 |  | 134 |  |  | (69) |  |  | 9 |
|  | $ | 5,661 |  |  | $ | (4,008) |  |  | 11 |  | $ | 6,092 |  |  | $ | (3,920) |  |  | 10 |

[0001728949-20-000067:notes:90]
All of these intangible assets are subject to amortization and the amortization expense related to these intangible assets was $621 million, $727 million and $785 million for fiscal 2020, 2019 and 2018, respectively. Amortization expense related to these intangible assets is expected to be $519 million, $422 million, $295 million, $136 million and $111 million for each of the five years from fiscal 2021 through 2025, respectively, and $170 million thereafter. At September 27, 2020 and September 29, 2019, all acquired in-process research and development projects were completed and are being amortized over their useful lives.

[0001728949-20-000067:notes:91]
Equity Method and Non-marketable Equity Investments. The carrying values of our equity method and non-marketable equity investments are recorded in other noncurrent assets and were as follows (in millions):

[0001728949-20-000067:notes:92]
|  | September 27,2020 |  | September 29,2019 |
| Equity method investments | $ | 161 |  |  | $ | 343 |  |
| Non-marketable equity investments | 821 |  |  | 787 |  |
|  | $ | 982 |  |  | $ | 1,130 |  |

[0001728949-20-000067:notes:93]
Beginning in the second quarter of fiscal 2020, the rapid, global spread of COVID-19 and associated containment and mitigation measures have negatively impacted the condition of economies and financial markets globally, which has negatively impacted certain companies in which we hold non-marketable equity investments, including those accounted for under the equity method and, to a lesser extent, non-marketable debt securities. Since the second quarter of fiscal 2020, significant evaluation and judgments were required in determining if the negative effects of COVID-19 indicated that such investments were impaired, and if so, the extent of such impairment. This included, among other items: (i) assessing the business impacts that COVID-19 had, and we currently expect to have in the future, on our investees, including taking into consideration the investee’s industry and geographic location and the impact to its customers, suppliers and employees, as applicable, (ii) evaluating the investees’ ability to respond to the impacts of COVID-19, including any significant deterioration in the investee’s financial condition and cash flows, as well as assessing liquidity and/or going concern risks and (iii) considering any appreciation in fair value that has not been recognized in the carrying values of such investments. Based on this evaluation, certain of our investments were impaired and written down to their estimated fair values in fiscal 2020 (a significant portion of which related to the full impairment of our investment in OneWeb, who filed for bankruptcy in the second quarter of fiscal 2020). Although we believe that our judgments supporting our impairment assessments are reasonable (which rely on information reasonably available to us), the COVID-19 pandemic makes it challenging for us and our investees to estimate the future performance of our investees’ businesses. As circumstances change and/or new information becomes available, we may be required to record additional impairments in subsequent periods.

[0001728949-20-000067:notes:94]
Revenues from certain services contracts with OneWeb were $36 million, $152 million and $100 million in fiscal 2020, 2019 and 2018, respectively.

[0001728949-20-000067:notes:95]
During fiscal 2019, non-marketable debt and equity securities (non-cash consideration) with an aggregate estimated fair value of $98 million were received related to a development contract with OneWeb that was recognized as revenues in fiscal 2019. In addition, during fiscal 2019, non-marketable equity securities (non-cash consideration) with an estimated fair value of $53 million were received in connection with the sale of certain assets as part of the Cost Plan that concluded in fiscal 2019.

[0001728949-20-000067:notes:96]
| Other Current Liabilities (in millions) |  |  |  |
|  | September 27,2020 |  | September 29,2019 |
| Customer incentives and other customer-related liabilities | $ | 1,721 |  |  | $ | 1,129 |  |
| Accrual for EC fines (Note 7) | 1,487 |  |  | 1,379 |  |
| Income taxes payable | 549 |  |  | 480 |  |
| Other | 546 |  |  | 470 |  |
|  | $ | 4,303 |  |  | $ | 3,458 |  |

[0001728949-20-000067:notes:97]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in stockholders’ equity during fiscal 2020 were as follows (in millions):

[0001728949-20-000067:notes:98]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gains (Losses) on Other Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Derivative Instruments |  | Other Gains (Losses) |  | Total Accumulated Other Comprehensive Income |
| Balance at September 29, 2019 | $ | (99) |  |  | $ | 23 |  |  | $ | 186 |  |  | $ | 8 |  |  | $ | (18) |  |  | $ | 100 |  |
| Other comprehensive income before reclassifications | 60 |  |  | — |  |  | 22 |  |  | 29 |  |  | 7 |  |  | 118 |  |
| Reclassifications from accumulated other comprehensive income | 7 |  |  | — |  |  | (2) |  |  | (16) |  |  | — |  |  | (11) |  |
| Other comprehensive income | 67 |  |  | — |  |  | 20 |  |  | 13 |  |  | 7 |  |  | 107 |  |
| Balance at September 27, 2020 | $ | (32) |  |  | $ | 23 |  |  | $ | 206 |  |  | $ | 21 |  |  | $ | (11) |  |  | $ | 207 |  |

[0001728949-20-000067:notes:99]
Reclassifications from accumulated other comprehensive income related to derivative instruments were $16 million during fiscal 2020 and negligible for all other periods presented, and were recorded in revenues, cost of revenues, research and development expenses and selling, general and administrative expenses. Reclassifications from accumulated other comprehensive income in fiscal 2019 included adjustments of $51 million to the opening retained earnings balance as a result of the adoption of new accounting guidance in 2019 related to financial instruments and hedge instruments. Other reclassifications from accumulated other comprehensive income related to available-for-sale securities and foreign currency translation adjustments were negligible for all periods presented.

[0001728949-20-000067:notes:100]
Revenues. We disaggregate our revenues by segment (Note 8), by type of product and services (as presented on our consolidated statement of operations) and, for our QCT segment by revenue stream, which is based on industry segment or application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry segment or application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets. QCT revenue streams were as follows (in millions):

[0001728949-20-000067:notes:101]
|  |  |  |  |  | 2020 |  | 2019 |
| Handsets |  |  |  |  |  |  |  |  | $ | 10,461 |  |  | $ | 9,793 |  |
| RFFE (1) |  |  |  |  |  |  |  |  | 2,362 |  |  | 1,478 |  |
| Automotive |  |  |  |  |  |  |  |  | 644 |  |  | 640 |  |
| IoT (2) |  |  |  |  |  |  |  |  | 3,026 |  |  | 2,728 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 16,493 |  |  | $ | 14,639 |  |

[0001728949-20-000067:notes:102]
(1) Includes all revenues from sales of RFFE integrated circuit products (substantially all of which are used in handsets).

[0001728949-20-000067:notes:103]
(2) Internet of Things (IoT) revenues primarily include products sold for use in cellular and non-cellular connected devices within the following industry segments or applications: consumer, computing, industrial, fixed wireless broadband, voice and music and wireless networking.

[0001728949-20-000067:notes:104]
Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were $1.5 billion for fiscal 2020, and primarily related to licensing revenues recognized in the fourth quarter of fiscal 2020 (a portion of which was attributable to fiscal 2020) resulting from the settlement with Huawei, and to a lesser extent, QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, in part based on actual reporting of royalties by our licensees) and certain QCT customer incentives. Revenues recognized from performance obligations satisfied (or partially satisfied) in previous periods were $4.1 billion for fiscal 2019 and primarily related to licensing revenues recognized in the third quarter of fiscal 2019 (a portion of which was attributable to fiscal 2019) resulting from the settlement with Apple and its contract manufacturers in April 2019.

[0001728949-20-000067:notes:105]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In fiscal 2020 and fiscal 2019, we recognized revenues of $540 million and $481 million, respectively, that were recorded as unearned revenues at September 29, 2019 and October 1, 2018, respectively.

[0001728949-20-000067:notes:106]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which QTL received license fees upfront. At September 27, 2020, we had $1.4 billion of remaining performance obligations, of which $581 million, $493 million, $234 million, $64 million and $26 million is expected to be recognized as revenues for each of the subsequent five years from fiscal 2021 through 2025, respectively, with no amounts expected thereafter.

[0001728949-20-000067:notes:107]
Share-based Compensation Expense. Total share-based compensation expense, related to all of our share-based awards, was comprised as follows (in millions):

[0001728949-20-000067:notes:108]
|  |  |  |  |  | 2020 |  | 2019 |  | 2018 |
| Cost of revenues |  |  |  |  |  |  |  |  | $ | 34 |  |  | $ | 35 |  |  | $ | 38 |  |
| Research and development |  |  |  |  |  |  |  |  | 872 |  |  | 725 |  |  | 594 |  |
| Selling, general and administrative |  |  |  |  |  |  |  |  | 306 |  |  | 277 |  |  | 251 |  |
| Share-based compensation expense before income taxes |  |  |  |  |  |  |  |  | 1,212 |  |  | 1,037 |  |  | 883 |  |
| Related income tax benefit |  |  |  |  |  |  |  |  | (238) |  |  | (184) |  |  | (140) |  |
|  |  |  |  |  |  |  |  |  | $ | 974 |  |  | $ | 853 |  |  | $ | 743 |  |

[0001728949-20-000067:notes:109]
Other Income, Costs and Expenses. Other expenses in fiscal 2020 consisted of $28 million in gains related to a favorable legal settlement.

[0001728949-20-000067:notes:110]
Other expenses in fiscal 2019 consisted of a $275 million charge related to a fine imposed by the European Commission (EC) related to the Icera complaint (2019 EC fine) (Note 7) and $213 million in net charges related to our Cost Plan that concluded in fiscal 2019, partially offset by a $43 million gain due to the partial recovery of a fine imposed in 2009 resulting from our appeal of the Korea Fair Trade Commission (KFTC) decision and a $31 million gain related to a favorable legal settlement.

[0001728949-20-000067:notes:111]
Other expenses in fiscal 2018 consisted of a $2.0 billion charge related to a fee paid in connection with the termination of our purchase agreement to acquire NXP Semiconductors N.V., a $1.2 billion charge for the fine imposed by the EC related to an investigation (2018 EC fine) (Note 7) and $629 million in restructuring and restructuring-related charges related to our Cost Plan, partially offset by a $676 million benefit related to the settlement of the Taiwan Fair Trade Commission (TFTC) investigation.

[0001728949-20-000067:notes:112]
Total restructuring and restructuring-related charges related to the Cost Plan were as follows (in millions):

[0001728949-20-000067:notes:113]
|  | 2019 |  | 2018 (1) |  | Total |
| Restructuring-related charges (2) | $ | 151 |  |  | $ | 334 |  |  | $ | 485 |  |
| Restructuring charges (3) | 62 |  |  | 353 |  |  | 415 |  |
|  | $ | 213 |  |  | $ | 687 |  |  | $ | 900 |  |

[0001728949-20-000067:notes:114]
(1)During fiscal 2018, we recorded restructuring and restructuring-related charges of $629 million in other expenses and charges of $58 million in investment and other income, net.

[0001728949-20-000067:notes:115]
(2)Restructuring-related charges primarily related to asset impairment charges in fiscal 2019 and 2018 and also included a $52 million net gain in fiscal 2019 from the sale of certain assets related to wireless electric vehicle charging applications and the sale of our mobile health nonreportable segment, as well as a $41 million gain in fiscal 2018 resulting from fair value adjustments of certain contingent consideration related to a business combination.

[0001728949-20-000067:notes:116]
(3)Restructuring charges primarily consisted of severance and consulting costs in fiscal 2019 and 2018, which were payable in cash.

[0001728949-20-000067:notes:117]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  | 2020 |  | 2019 |  | 2018 |
| Interest and dividend income |  |  |  |  |  |  |  | $ | 156 |  |  | $ | 300 |  |  | $ | 611 |  |
| Net gains on marketable securities |  |  |  |  |  |  |  | 198 |  |  | 295 |  |  | 21 |  |
| Net gains on other investments |  |  |  |  |  |  |  | 108 |  |  | 68 |  |  | 83 |  |
| Net gains on deferred compensation plan assets |  |  |  |  |  |  |  | 47 |  |  | 9 |  |  | 34 |  |
| Impairment losses on other investments |  |  |  |  |  |  |  | (405) |  |  | (135) |  |  | (75) |  |
| Net gains (losses) on derivative instruments |  |  |  |  |  |  |  | 8 |  |  | (14) |  |  | (27) |  |
| Equity in net losses of investees |  |  |  |  |  |  |  | (21) |  |  | (93) |  |  | (145) |  |
| Net (losses) gains on foreign currency transactions |  |  |  |  |  |  |  | (25) |  |  | 11 |  |  | 37 |  |
|  |  |  |  |  |  |  |  | $ | 66 |  |  | $ | 441 |  |  | $ | 539 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-20-000067:notes:118]
Income Taxes
The components of the income tax provision were as follows (in millions):

[0001728949-20-000067:notes:119]
|  | 2020 |  | 2019 |  | 2018 |
| Current provision (benefit): |  |  |  |  |  |
| Federal | $ | 210 |  |  | $ | 1,563 |  |  | $ | 2,559 |  |
| State | 1 |  |  | 2 |  |  | (1) |  |
| Foreign | 526 |  |  | (407) |  |  | 777 |  |
|  | 737 |  |  | 1,158 |  |  | 3,335 |  |
| Deferred provision (benefit): |  |  |  |  |  |
| Federal | (192) |  |  | 2,037 |  |  | 1,846 |  |
| State | 2 |  |  | 17 |  |  | 1 |  |
| Foreign | (26) |  |  | (117) |  |  | 174 |  |
|  | (216) |  |  | 1,937 |  |  | 2,021 |  |
|  | $ | 521 |  |  | $ | 3,095 |  |  | $ | 5,356 |  |

[0001728949-20-000067:notes:120]
The foreign component of the income tax provision (benefit) included foreign withholding taxes on royalty revenues included in U.S. earnings.

[0001728949-20-000067:notes:121]
The components of income before income taxes by U.S. and foreign jurisdictions were as follows (in millions):

[0001728949-20-000067:notes:122]
|  | 2020 |  | 2019 |  | 2018 |
| United States | $ | 5,004 |  |  | $ | 7,042 |  |  | $ | (1,834) |  |
| Foreign | 715 |  |  | 439 |  |  | 2,226 |  |
|  | $ | 5,719 |  |  | $ | 7,481 |  |  | $ | 392 |  |

[0001728949-20-000067:notes:123]
In fiscal 2018, the foreign component of income before income taxes in foreign jurisdictions primarily consisted of income earned in Singapore.

[0001728949-20-000067:notes:124]
The following is a reconciliation of the expected statutory federal income tax provision to our actual income tax provision (in millions, except percentages):

[0001728949-20-000067:notes:125]
|  | 2020 |  | 2019 |  | 2018 |
| Expected income tax provision at federal statutory tax rate | $ | 1,201 |  |  | $ | 1,571 |  |  | $ | 97 |  |
| State income tax provision, net of federal benefit | 7 |  |  | 10 |  |  | 2 |  |
| Benefit from foreign-derived intangible income (FDII) deduction | (381) |  |  | (419) |  |  | — |  |
| Benefit related to research and development tax credits | (125) |  |  | (110) |  |  | (136) |  |
| Excess tax benefit associated with share-based awards | (83) |  |  | (27) |  |  | (20) |  |
| Benefit from foreign income taxed at other than U.S. rates | (11) |  |  | (54) |  |  | (834) |  |
| Derecognition of deferred tax asset on distributed intellectual property | — |  |  | 2,472 |  |  | — |  |
| Benefit from establishing new U.S. net deferred tax assets | — |  |  | (570) |  |  | — |  |
| Nondeductible charges (reversals) related to the EC, KFTC and TFTC investigations | — |  |  | 51 |  |  | (119) |  |
| Toll Charge from U.S. tax reform | — |  |  | — |  |  | 5,236 |  |
| Valuation allowance on deferred tax assets related to the NXP termination fee | — |  |  | — |  |  | 494 |  |
| Remeasurement of deferred taxes due to changes in the statutory rate due to U.S. tax reform | — |  |  | — |  |  | 443 |  |
| Other | (87) |  |  | 171 |  |  | 193 |  |
|  | $ | 521 |  |  | $ | 3,095 |  |  | $ | 5,356 |  |
| Effective tax rate | 9 | % |  | 41 | % |  | N/M |

[0001728949-20-000067:notes:126]
N/M - Not meaningful

[0001728949-20-000067:notes:127]
The 2017 Tax Cuts and Jobs Act (the Tax Legislation) was enacted in fiscal 2018, which, among other things, lowered the corporate income tax rate to 21%, and as a fiscal-year taxpayer, certain provisions of the Tax Legislation became effective for us at the beginning of fiscal 2019, including FDII (foreign-derived intangible income). In response to the Tax Legislation and to better align our profits with our activities, we implemented certain tax restructuring in fiscal 2018 and 2019. As a result, beginning in fiscal 2019, substantially all of our income is in the U.S., of which a significant portion qualifies for preferential treatment as FDII at a 13% effective tax rate. Our annual effective tax rate for fiscal 2018 reflected a blended federal statutory rate of approximately 25%.

[0001728949-20-000067:notes:128]
In the fourth quarter of fiscal 2020, the United States Treasury Department issued final regulations on deductions for FDII, which are retroactive to fiscal 2019. As a result of these regulations, our fiscal 2020 annual effective tax rate increased by approximately 1%. In the first quarter of fiscal 2021, the United States Treasury Department issued final regulations on the foreign tax credit, which we anticipate will adversely affect our effective tax rate. The impact of these regulations, which are retroactive to fiscal 2019, has not been included in our fiscal 2020 effective tax rate. While we continue to evaluate these new regulations, we currently do not expect the adverse impact to fiscal 2019 and 2020 to be significant.

[0001728949-20-000067:notes:129]
As a result of the Tax Legislation, in fiscal 2019, several of our foreign subsidiaries made elections to be treated as U.S. branches for federal income tax purposes (commonly referred to as “check-the-box” elections) effective beginning in fiscal 2018 and 2019. Although beginning in fiscal 2019 the income of these entities is included in our consolidated U.S. tax return, we believe that by treating these foreign subsidiaries as U.S. branches for federal income taxes, rather than controlled foreign corporations, we will significantly reduce the risk of being subject to GILTI (global intangible low-taxed income) and BEAT (base-erosion and anti-abuse tax) taxes. As a result of making these check-the-box elections, we recorded a tax benefit of $570 million in the first quarter of fiscal 2019 due to establishing new U.S. net deferred tax assets resulting from the difference between the GAAP basis and the U.S. federal tax carryover basis of the existing assets and liabilities of those foreign subsidiaries, primarily related to customer incentive liabilities that have not been deducted for tax purposes. Additionally, during fiscal 2018, one of our foreign subsidiaries distributed certain intellectual property to a U.S. subsidiary resulting in a difference between the GAAP basis and the U.S. federal tax basis of the distributed intellectual property. Upon adoption of new accounting guidance in the first quarter of fiscal 2019, which changed the accounting for the income tax effects of intra-entity transfers of assets other than inventory, we recorded a deferred tax asset of approximately $2.6 billion primarily related to the distributed intellectual property, with an adjustment to opening retained earnings. During the third quarter of fiscal 2019, the United States Treasury Department issued new temporary regulations that resulted in a change to the deductibility of dividend income received by a U.S. stockholder from a foreign corporation. As a result of this change, pursuant to an agreement with the Internal Revenue Service, we relinquished the federal tax basis step-up of intellectual property that was distributed in fiscal 2018 by one of our foreign subsidiaries to a U.S. subsidiary. Therefore, the related deferred tax asset was derecognized, resulting in a $2.5 billion charge to income tax expense in fiscal 2019.

[0001728949-20-000067:notes:130]
In fiscal 2019, as a result of recent court rulings in Korea, among other factors, we decided to apply for a partial refund claim for taxes previously withheld from licensees in Korea on payments due under their license agreements to which we

[0001728949-20-000067:notes:131]
have claimed a foreign tax credit in the United States. As a result, $1.6 billion and $1.4 billion was recorded as a noncurrent income taxes receivable (recorded in other assets) at September 27, 2020 and September 29, 2019, respectively, and $1.6 billion and $1.4 billion was recorded a noncurrent liability for uncertain tax benefits of (recorded in other liabilities) at September 27, 2020 and September 29, 2019, respectively.

[0001728949-20-000067:notes:132]
In fiscal 2018, as a result of the Tax Legislation, we recorded a charge of $5.7 billion to income tax expense, comprised of $5.2 billion related to the estimated one-time repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (the Toll Charge) and $438 million resulting from the remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate, which included a $135 million tax benefit recorded in fiscal 2018 related to the remeasurement of a U.S. deferred tax liability that was established as a result of a change in one of our tax positions due to Tax Legislation. After application of certain tax credits, the total cash payment is $2.5 billion. At September 27, 2020, we estimated remaining future payments of $2.0 billion for the Toll Charge, after application of certain tax credits (including excess tax credits generated in fiscal 2019), which is payable in installments over the next six years. At September 27, 2020, $174 million was recorded in other current liabilities, reflecting the next installment due in January 2021.

[0001728949-20-000067:notes:133]
Income tax expense for fiscal 2018 was also impacted by the charge recorded in fiscal 2018 related to the termination fee paid to NXP, which did not result in a tax benefit after the consideration of realizability of such loss. Fiscal 2018 income tax expense was impacted by the EC fine and settlement with the TFTC, which were not deductible for tax purposes (or taxable in the case of the settlement) and which were attributable to foreign jurisdictions and to the United States.

[0001728949-20-000067:notes:134]
Certain of our tax incentives in Singapore expired in March 2017. In fiscal 2018, we entered into a new tax incentive agreement in Singapore that results in a reduced tax rate from March 2017 through March 2022, provided that we meet specified employment and investment criteria in Singapore. Our Singapore tax rate will increase in March 2022 as a result of expiration of these incentives and again in March 2027 upon the expiration of tax incentives under a prior agreement. During fiscal 2018, one of our Singapore subsidiaries distributed certain intellectual property to a U.S. subsidiary reducing the benefit of these tax incentives almost entirely going forward. Without these tax incentives, our income tax expense would have been higher in fiscal 2018 by $652 million and impacted earnings per share by $0.45 per share. The impact in fiscal 2019 and 2020 was not significant.

[0001728949-20-000067:notes:135]
We continue to assert that certain of our foreign earnings are not indefinitely reinvested. At September 27, 2020, we had not recorded a deferred tax liability of approximately $66 million related to foreign withholding taxes on approximately $635 million of undistributed earnings of certain subsidiaries that we continue to consider to be indefinitely reinvested outside the United States. Should we decide to no longer indefinitely reinvest such earnings outside the United States, we would have to adjust the income tax provision in the period we make such determination.

[0001728949-20-000067:notes:136]
We had deferred tax assets and deferred tax liabilities as follows (in millions):

[0001728949-20-000067:notes:137]
|  | September 27,2020 |  | September 29,2019 |
| Unused tax credits | $ | 1,311 |  |  | $ | 1,137 |  |
| Accrued liabilities and reserves | 812 |  |  | 648 |  |
| Unused net operating losses | 576 |  |  | 619 |  |
| Unearned revenues | 262 |  |  | 376 |  |
| Unrealized losses on other investments and marketable securities | 235 |  |  | 164 |  |
| Share-based compensation | 151 |  |  | 115 |  |
| Operating lease liabilities | 107 |  |  | — |  |
| Other | 141 |  |  | 144 |  |
| Total gross deferred tax assets | 3,595 |  |  | 3,203 |  |
| Valuation allowance | (1,728) |  |  | (1,672) |  |
| Total net deferred tax assets | 1,867 |  |  | 1,531 |  |
| Intangible assets | (181) |  |  | (216) |  |
| Property, plant and equipment | (162) |  |  | (102) |  |
| Operating lease assets | (100) |  |  | — |  |
| Unrealized gains on other investments and marketable securities | (97) |  |  | (99) |  |
| Other | (32) |  |  | (21) |  |
| Total deferred tax liabilities | (572) |  |  | (438) |  |
| Net deferred tax assets | $ | 1,295 |  |  | $ | 1,093 |  |
| Reported as: |  |  |  |
| Non-current deferred tax assets | $ | 1,351 |  |  | $ | 1,196 |  |
| Non-current deferred tax liabilities (1) | (56) |  |  | (103) |  |
|  | $ | 1,295 |  |  | $ | 1,093 |  |

[0001728949-20-000067:notes:138]
(1)Non-current deferred tax liabilities were included in other liabilities in the consolidated balance sheets.

[0001728949-20-000067:notes:139]
At September 27, 2020, we had unused federal net operating loss carryforwards of $167 million expiring from 2021 through 2035, unused state net operating loss carryforwards of $579 million expiring from 2021 through 2040 and unused foreign net operating loss carryforwards of $2.2 billion, of which $2.0 billion expire in 2027. At September 27, 2020, we had unused state tax credits of $1.1 billion, of which substantially all may be carried forward indefinitely, unused federal tax credits of $187 million expiring from 2026 through 2031 and unused tax credits of $42 million in foreign jurisdictions expiring from 2033 through 2040. We do not expect our federal net operating loss carryforwards to expire unused.

[0001728949-20-000067:notes:140]
At September 27, 2020, we have provided a valuation allowance on certain state tax credits, foreign deferred tax assets, federal capital losses, federal foreign tax credits and state net operating losses of $1.1 billion, $524 million, $29 million, $28 million and $14 million, respectively. The valuation allowance reflects the uncertainties surrounding our ability to generate sufficient future taxable income in certain foreign and state tax jurisdictions to utilize our net operating losses and our ability to generate sufficient capital gains to utilize all capital losses. We believe, more likely than not, that we will have sufficient taxable income after deductions related to share-based awards to utilize our remaining deferred tax assets.

[0001728949-20-000067:notes:141]
A summary of the changes in the amount of unrecognized tax benefits for fiscal 2020, 2019 and 2018 follows (in millions):

[0001728949-20-000067:notes:142]
|  | 2020 |  | 2019 |  | 2018 |
| Beginning balance of unrecognized tax benefits | $ | 1,705 |  |  | $ | 217 |  |  | $ | 372 |  |
| Additions based on prior year tax positions | 20 |  |  | 1,238 |  |  | 7 |  |
| Reductions for prior year tax positions and lapse in statute of limitations | (2) |  |  | (3) |  |  | (11) |  |
| Additions for current year tax positions | 192 |  |  | 253 |  |  | 18 |  |
| Settlements with taxing authorities | (14) |  |  | — |  |  | (169) |  |
| Ending balance of unrecognized tax benefits | $ | 1,901 |  |  | $ | 1,705 |  |  | $ | 217 |  |

[0001728949-20-000067:notes:143]
Of the $1.9 billion of unrecognized tax benefits, $1.8 billion has been recorded to other noncurrent liabilities. We believe that it is reasonably possible that certain unrecognized tax benefits recorded at September 27, 2020 may result in a cash payment in fiscal 2021. Unrecognized tax benefits at September 27, 2020 included $127 million for tax positions that, if recognized, would impact the effective tax rate. The unrecognized tax benefits differ from the amount that would affect our effective tax rate primarily because the unrecognized tax benefits were included on a gross basis and did not reflect related receivables or secondary impacts, such as the federal deduction for state taxes, adjustments to deferred tax assets and the valuation allowance that might be required if our tax positions are sustained. The increase in unrecognized tax benefits in fiscal 2020 and fiscal 2019 was primarily due to our decision in fiscal 2019 to request for a refund of Korean withholding tax (which had an insignificant impact to our income tax provision). If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We believe that it is likely that the total amount of unrecognized tax benefits at September 27, 2020 will increase in fiscal 2021 as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision.

[0001728949-20-000067:notes:144]
We file income tax returns in the United States federal jurisdiction and various state and foreign jurisdictions. We are currently a participant in the IRS Compliance Assurance Process, whereby we and the IRS endeavor to agree on the treatment of all tax issues prior to the tax return being filed. We are no longer subject to U.S. federal income tax examinations for years prior to fiscal 2015. We are subject to examination by the California Franchise Tax Board for fiscal years after 2014. We are also subject to examination in other taxing jurisdictions in the United States and numerous foreign jurisdictions. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2000. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. At September 27, 2020, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0001728949-20-000067:notes:145]
Cash amounts paid for income taxes, net of refunds received, were $830 million, $1.1 billion and $877 million for fiscal 2020, 2019 and 2018, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-20-000067:notes:146]
Capital Stock
Stock Repurchase Program. On July 26, 2018, we announced a stock repurchase program authorizing us to repurchase up to $30 billion of our common stock. The stock repurchase program has no expiration date. In the first quarter of fiscal 2021, we resumed stock repurchases under the stock repurchase program, which we had suspended in the third quarter of fiscal 2020 in light of COVID-19 to maintain our financial liquidity position and flexibility.

[0001728949-20-000067:notes:147]
In September 2018, we entered into three accelerated share repurchase agreements (ASR Agreements) with three financial institutions under which we paid an aggregate of $16.0 billion upfront to the financial institutions and received from them an initial delivery of 178 million shares of our common stock, which were retired and recorded as a $12.8 billion reduction to stockholders’ equity. The remaining $3.2 billion was recorded as a reduction to stockholders’ equity as an unsettled forward contract indexed to our own stock. During September 2019, the ASR Agreements were completed, and an additional 69 million shares were delivered to us, which were retired, and the forward contract was settled with no adjustment to stockholders’ equity. In total, we purchased 247 million shares based on the volume-weighted average stock price of our common stock during the terms of the transactions, less a discount.

[0001728949-20-000067:notes:148]
During fiscal 2020, 2019 and 2018, we repurchased and retired an additional 31 million, 27 million and 24 million shares of common stock, respectively, for $2.4 billion, $1.8 billion and $1.4 billion, respectively, before commissions. To reflect share repurchases in the consolidated balance sheet, we (i) reduce common stock for the par value of the shares, (ii) reduce paid-in capital for the amount in excess of par to zero during the quarter in which the shares are repurchased and (iii) record the residual amount, if any, to retained earnings. At September 27, 2020, $4.6 billion remained authorized for repurchase under our stock repurchase program.

[0001728949-20-000067:notes:149]
Shares Outstanding. Shares of common stock outstanding at September 27, 2020 were as follows (in millions):

[0001728949-20-000067:notes:150]
|  | 2020 |
| Balance at beginning of period | 1,145 |  |
| Issued | 17 |  |
| Repurchased | (31) |  |
| Balance at end of period | 1,131 |  |

[0001728949-20-000067:notes:151]
Dividends. On October 14, 2020, we announced a cash dividend of $0.65 per share on our common stock, payable on December 17, 2020 to stockholders of record as of the close of business on December 3, 2020.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001728949-20-000067:notes:152]
Employee Benefit Plans
Employee Savings and Retirement Plan. We have a 401(k) plan that allows eligible employees to contribute up to 85% of their eligible compensation, subject to annual limits. We match a portion of the employee contributions and may, at our discretion, make additional contributions based upon earnings. Our contribution expense was $69 million, $64 million and $78 million in fiscal 2020, 2019 and 2018, respectively.

[0001728949-20-000067:notes:153]
Equity Compensation Plans. On March 10, 2020, our stockholders approved the amended and restated Qualcomm Incorporated 2016 Long-Term Incentive Plan (the 2016 Plan), including an increase in the share reserve by 75 million shares. The 2016 Plan provides for the grant of incentive and nonstatutory stock options, stock appreciation rights, restricted stock, unrestricted stock, restricted stock units, performance units, performance shares, deferred compensation awards and other stock-based awards. The Board of Directors may amend or terminate the 2016 Plan at any time. Certain amendments, including an increase in the share reserve, require stockholder approval. At September 27, 2020, approximately 92 million shares were available for future grant under the 2016 Plan.

[0001728949-20-000067:notes:154]
RSUs are share awards that entitle the holder to receive shares of our common stock upon vesting. The RSUs generally include dividend-equivalent rights and vest over three years from the date of grant. A summary of RSU transactions that contain only service requirements to vest for all equity compensation plans follows:

[0001728949-20-000067:notes:155]
|  | Number of Shares |  | Weighted-AverageGrant Date FairValue |  | Aggregate IntrinsicValue |
|  | (In millions) |  |  |  | (In billions) |
| RSUs outstanding at September 29, 2019 | 27 |  |  | $ | 62.57 |  |  |  |
| RSUs granted | 20 |  |  | 82.57 |  |  |  |
| RSUs canceled/forfeited | (1) |  |  | 72.04 |  |  |  |
| RSUs vested | (14) |  |  | 62.58 |  |  |  |
| RSUs outstanding at September 27, 2020 | 32 |  |  | $ | 74.99 |  |  | $ | 3.6 |  |

[0001728949-20-000067:notes:156]
The weighted-average estimated fair values of employee RSUs that contain only service requirements to vest granted during fiscal 2019 and 2018 were $63.10 and $62.61 per share, respectively. Upon vesting, we issue new shares of common stock. For the majority of RSUs, shares are issued on the vesting dates net of the amount of shares needed to satisfy statutory tax withholding requirements to be paid by us on behalf of the employees. As a result, the actual number of shares issued will be fewer than the number of RSUs outstanding. The annual pre-vest forfeiture rate for RSUs was estimated to be approximately 7%, 7% and 6% in fiscal 2020, 2019 and 2018, respectively.

[0001728949-20-000067:notes:157]
At September 27, 2020, total unrecognized compensation expense related to such non-vested RSUs granted prior to that date was $1.5 billion, which is expected to be recognized over a weighted-average period of 1.8 years. The total vest-date fair value of such RSUs that vested during fiscal 2020, 2019 and 2018 was $1.3 billion, $977 million and $940 million, respectively. The total shares withheld to satisfy statutory tax withholding requirements related to all share-based awards were approximately 4 million in fiscal 2020, 2019 and 2018, and were based on the value of the awards on their vesting dates as determined by our closing stock price.

[0001728949-20-000067:notes:158]
The total tax benefits realized, including the excess tax benefits, related to share-based awards during fiscal 2020, 2019 and 2018 were $273 million, $237 million and $254 million, respectively.

[0001728949-20-000067:notes:159]
Employee Stock Purchase Plan. We have an employee stock purchase plan for eligible employees to purchase shares of common stock at 85% of the lower of the fair market value on the first or the last day of each offering period, which is generally six months. Employees may authorize us to withhold up to 15% of their compensation during any offering period, subject to certain limitations. The employee stock purchase plan includes a non-423(b) plan. On March 23, 2018, our stockholders approved an amendment to the Amended and Restated QUALCOMM Incorporated 2001 Employee Stock Purchase Plan to increase the share reserve by 30 million shares. The shares authorized under the plan were approximately 102 million at September 27, 2020. The shares reserved for future issuance were approximately 28 million at September 27, 2020. During fiscal 2020, 2019 and 2018, approximately 5 million, 6 million and 6 million shares, respectively, were issued under the plan at an average price of $66.53, $42.13 and $49.41 per share, respectively. At September 27, 2020, total unrecognized compensation expense related to non-vested purchase rights granted prior to that date was $35 million. We recorded cash received from the exercise of purchase rights of $306 million, $257 million and $286 million during fiscal 2020, 2019 and 2018, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001728949-20-000067:notes:160]
DebtLong-term Debt. In May 2020, we issued unsecured fixed-rate notes, consisting of $1.2 billion fixed-rate 2.15% notes and $800 million fixed-rate 3.25% notes (May 2020 Notes) that mature on May 20, 2030 and May 20, 2050, respectively. The proceeds from the May 2020 Notes, net of underwriting discounts and offering expenses, were used to repay the $250 
million floating-rate and $1.75 billion fixed-rate notes that matured on May 20, 2020, which were classified as short-term debt at September 29, 2019.

[0001728949-20-000067:notes:161]
In August 2020, we completed an exchange of $2.0 billion of our outstanding fixed-rate notes maturing between 2022 and 2025 (Old Notes) for $1.0 billion fixed-rate 1.30% notes due May 20, 2028 and $1.2 billion fixed-rate 1.65% notes due May 20, 2032 (August 2020 Notes). In connection with this exchange, we also repurchased $202 million of the Old Notes from holders not eligible to participate in the exchange, which resulted in a $17 million loss on extinguishment recorded in interest expense.

[0001728949-20-000067:notes:162]
The following table provides a summary of our long-term debt and current portion of long-term debt:

[0001728949-20-000067:notes:163]
|  | September 27, 2020 |  | September 29, 2019 |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2022 - 2045 |  | $ | 5,405 |  |  | 2.62% - 4.73% |  | 2020 - 2045 |  | $ | 8,500 |  |  | 2.64% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 5,860 |  |  | 1.06% - 4.46% |  | 2023 - 2047 |  | 7,000 |  |  | 2.70% - 4.47% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.31% - 3.30% |  |  |  | — |  |  |  |
| August 2020 Notes | 2028 - 2032 |  | 2,207 |  |  | 1.96% - 2.65% |  |  |  | — |  |  |  |
| Total principal |  |  | 15,472 |  |  |  |  |  |  | 15,500 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (260) |  |  |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  | 14 |  |  |  |  |  |  | 9 |  |  |  |
| Total long-term debt |  |  | $ | 15,226 |  |  |  |  |  |  | $ | 15,434 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | — |  |  |  |  |  |  | $ | 1,997 |  |  |  |
| Long-term debt |  |  | 15,226 |  |  |  |  |  |  | 13,437 |  |  |  |
| Total |  |  | $ | 15,226 |  |  |  |  |  |  | $ | 15,434 |  |  |  |

[0001728949-20-000067:notes:164]
At September 27, 2020, future principal payments were $1.5 billion in fiscal 2022, $1.5 billion in fiscal 2023, $914 million in fiscal 2024, $1.4 billion in fiscal 2025 and $10.2 billion after fiscal 2025; no principal payments are due in fiscal 2021. At September 27, 2020 and September 29, 2019, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $17.5 billion and $16.5 billion, respectively.

[0001728949-20-000067:notes:165]
We may redeem the outstanding fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. We may not redeem the outstanding floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of our other senior unsecured indebtedness and will effectively rank junior to all liabilities of our subsidiaries. At September 27, 2020, with the exception of $500 million of outstanding unsecured floating-rate notes due January 30, 2023, all of our outstanding long-term debt is comprised of unsecured fixed-rate notes.

[0001728949-20-000067:notes:166]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to our commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $507 million, $563 million and $662 million during fiscal 2020, 2019 and 2018, respectively.

[0001728949-20-000067:notes:167]
Commercial Paper Program. In fiscal 2020, we reduced the total amount available for issuance under our unsecured commercial paper program from $5.0 billion to $4.5 billion. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 to up to 397 days. At September 27, 2020 and September 29, 2019, we had $500 million and $499 million, respectively, of outstanding commercial paper recorded as short-term debt with a weighted-average interest rate of 0.21% and 2.17%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 37 days and 41 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at September 27, 2020 and September 29, 2019.

[0001728949-20-000067:notes:168]
Revolving Credit Facility. We have an Amended and Restated Revolving Credit Facility (Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on November 8, 2021. At September 27, 2020 and September 29, 2019, no amounts were outstanding under the Revolving Credit Facility.

[0001728949-20-000067:notes:169]
Debt Covenants. The Revolving Credit Facility requires that we comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. We are not subject to any financial covenants under the notes nor any covenants that would prohibit us from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by us 
or our subsidiaries. At September 27, 2020 and September 29, 2019, we were in compliance with the applicable covenants under the Revolving Credit Facility.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-20-000067:notes:170]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0001728949-20-000067:notes:171]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint. On March 18, 2019, the court denied our motion to dismiss. On January 15, 2020, we filed a motion for judgment on the pleadings. The court has not yet ruled on our motion. We believe the plaintiffs’ claims are without merit.

[0001728949-20-000067:notes:172]
In re Qualcomm/Broadcom Merger Securities Litigation: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and two of our current officers. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by failing to disclose that we had submitted a notice to the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints sought unspecified damages, interest, fees and costs. On January 22, 2019, the court appointed the lead plaintiff in the action. On March 18, 2019, the plaintiffs filed a consolidated complaint asserting the same basic theories of liability and requesting the same basic relief. On May 10, 2019, we filed a motion to dismiss the consolidated complaint, and on March 10, 2020, the court granted our motion. On May 11, 2020, the plaintiffs filed a second amended complaint, and on June 25, 2020, we filed a motion to dismiss that complaint. On October 8, 2020, the court heard oral arguments on our motion to dismiss, following which it granted our motion and dismissed the case with prejudice. We believe the plaintiffs’ claims are without merit.

[0001728949-20-000067:notes:173]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and the court granted that motion on September 27, 2018. On January 23, 2019, the United States Court of Appeals for the Ninth Circuit (Ninth Circuit) granted us permission to appeal the court’s class certification order. On January 24, 2019, the court stayed the case pending our appeal. On December 2, 2019, a hearing on our appeal of the class certification order was held before the Ninth Circuit. The Ninth Circuit has not yet ruled on our appeal. We believe the plaintiffs’ claims are without merit.

[0001728949-20-000067:notes:174]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia and the Quebec Superior Court) and Israel (in the Haifa District Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek unspecified damages. We believe the plaintiffs’ claims are without merit.

[0001728949-20-000067:notes:175]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, then captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision has subsequently reduced the number of patents asserted to four, granted covenants not to sue on the other patents, and dismissed the Samsung and HTC entities from the case. The asserted patents are now expired and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. Trial is currently scheduled to begin on May 3, 2021, but may be delayed due to the

[0001728949-20-000067:notes:176]
COVID-19 pandemic. We have previously prevailed on infringement claims asserted by ParkerVision in related lawsuits and have successfully invalidated a number of their patent claims in patent office proceedings. We believe that ParkerVision’s claims are without merit.

[0001728949-20-000067:notes:177]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0001728949-20-000067:notes:178]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019 and, on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-20-000067:notes:179]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of their investigation, but we believe it concerns our business practices in connection with our sale of radio frequency front end (RFFE) components. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-20-000067:notes:180]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision confirming their preliminary view that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

[0001728949-20-000067:notes:181]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At September 27, 2020, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $286 million and included in other current liabilities.

[0001728949-20-000067:notes:182]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it

[0001728949-20-000067:notes:183]
exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the EU competition rules.

[0001728949-20-000067:notes:184]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At September 27, 2020, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other income, net), was $1.2 billion and included in other current liabilities.

[0001728949-20-000067:notes:185]
European Commission (EC) Investigation regarding Radio Frequency Front End (RFFE): On December 3, 2019, we received a Request for Information from the EC notifying us that it is investigating whether we engaged in anti-competitive behavior in the European Union (EU)/European Economic Area (EEA) by leveraging our market position in 5G baseband processors in the RFFE space. We have responded to the Request for Information. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of our annual revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. We believe that our business practices do not violate the EU competition rules.

[0001728949-20-000067:notes:186]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified us that it was conducting an investigation of us relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against us in the United States District Court for the Northern District of California alleging that we were engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of cellular modem chipsets on the purchaser first agreeing to a license to our cellular standard-essential patents, paying incentives to purchasers of cellular modem chipsets to induce them to accept certain license terms, refusing to license our cellular standard-essential patents to our competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint sought a permanent injunction against our alleged violations of the FTCA and other unspecified ancillary equitable relief. On August 30, 2018, the FTC moved for partial summary judgment that our commitments to license our cellular standard-essential patents to the Alliance for Telecommunications Industry Solutions (ATIS) and the Telecommunications Industry Association (TIA) require us to make licenses available to rival sellers of cellular modem chipsets. On November 6, 2018, the court granted the FTC’s partial summary judgment motion. Trial was held January 4-29, 2019.

[0001728949-20-000067:notes:187]
On May 21, 2019, the court issued an Order setting forth its Findings of Fact and Conclusions of Law. The court concluded that we had monopoly power in the CDMA and premium-tier Long Term Evolution (LTE) cellular modem chip markets, and that we had used that power in these two markets to engage in anticompetitive acts, including (1) using threats of lack of access to cellular modem chip supply to coerce OEMs to accept license terms that include unreasonably high royalty rates; (2) refusing to license our cellular standard-essential patents to competitors selling cellular modem chips; and (3) entering into exclusive dealing arrangements with OEMs that foreclosed our rivals. The court further found that the royalties we charge OEMs are unreasonably high and reflect the use of our monopoly power over CDMA and premium-tier LTE cellular modem chips rather than just the value of our patents. The court concluded that our unreasonably high royalties constitute an anticompetitive surcharge on cellular modem chips sold by our competitors, which increases the effective price of our competitors’ cellular modem chips, reduces their margins and results in exclusivity. The court also found that our practice of not licensing competitors’ cellular modem chips violated our commitments to certain standard-development organizations and a duty under the antitrust laws to license competing cellular modem chip makers and helped us maintain our royalties at unreasonably high levels. Finally, the court found that incentive funds entered into with certain OEMs further harmed competing cellular modem chip makers’ ability to undermine our monopoly position, prevented rivals from entering the market and restricted the sales of those competitors that do enter. The court concluded that the combined effect of our conduct, together with our monopoly power, harmed the competitive process.

[0001728949-20-000067:notes:188]
The court imposed the following injunctive relief: (1) we must not condition the supply of cellular modem chips on a customer’s patent license status, and we must negotiate or renegotiate license terms with customers in good faith under conditions free from the threat of lack of access to or discriminatory provision of cellular modem chip supply or associated technical support or access to software; (2) we must make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers on fair, reasonable and non-discriminatory (FRAND) terms and submit, as necessary, to arbitral or judicial dispute resolution to determine such terms; (3) we may not enter into express or de facto exclusive dealing agreements for the supply of cellular modem chips; and (4) we may not interfere with the ability of any customer to communicate with a government agency about a potential law enforcement or regulatory matter. The court also ordered us to submit to compliance and monitoring procedures for a period of seven years and to report to the FTC on an annual basis regarding our compliance with the above remedies.

[0001728949-20-000067:notes:189]
We disagree with the court’s conclusions, interpretation of the facts and application of the law. On May 31, 2019, we filed with the court a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On July 8, 2019, we filed a Motion for Partial Stay of Injunction Pending Appeal and a Consent Motion to Expedite Appeal in the Ninth

[0001728949-20-000067:notes:190]
Circuit. On August 23, 2019, the Ninth Circuit granted our Motion for Partial Stay. Thus, pending the resolution of the appeal in the Ninth Circuit or until further order of the Ninth Circuit, the portions of the district court’s injunction requiring that we must (i) make exhaustive cellular standard-essential patent licenses available to cellular modem chip suppliers and (ii) not condition the supply of cellular modem chips on a customer’s patent license status and must negotiate or renegotiate license terms with customers are stayed. On July 10, 2019, the Ninth Circuit granted our Motion to Expedite Appeal. On February 13, 2020, the Ninth Circuit heard oral argument.

[0001728949-20-000067:notes:191]
On August 11, 2020, the Ninth Circuit issued its opinion, which reversed the district court’s judgment, vacated its injunction and vacated its partial grant of summary judgment. The Ninth Circuit stated that the district court erred in holding that we are under an antitrust duty to license rival chip manufacturers and noted that our practice of licensing our standard-essential patents exclusively at the OEM level does not violate the antitrust laws. The Ninth Circuit also held that the district court’s “anticompetitive surcharge” theory failed to state a cogent theory of anticompetitive harm and that our patent-licensing royalties and “no license, no chips” policy do not impose an anticompetitive surcharge on rivals’ modem chip sales and do not undermine competition in either the CDMA or premium LTE chip markets. While agreeing with the district court that our 2011 and 2013 agreements with Apple were structured like exclusive dealing contracts, the Ninth Circuit nonetheless held that neither agreement had the actual or practical effect of substantially foreclosing competition in the CDMA modem chip market, and because Apple terminated these agreements years ago, the district court had improperly issued an injunction. The Ninth Circuit noted that neither the Sherman Act nor any other law prohibits companies like us from (1) licensing their standard-essential patents independently from their chip sales and collecting royalties, and/or (2) limiting their chip customer base to licensed OEMs. On September 25, 2020, the FTC filed a Petition for Rehearing En Banc. On October 28, 2020, the Ninth Circuit denied the FTC’s petition.

[0001728949-20-000067:notes:192]
Contingent losses and other considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Other than with respect to the EC fines, we have not recorded any accrual at September 27, 2020 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

[0001728949-20-000067:notes:193]
Indemnifications. We generally do not indemnify our customers, licensees and suppliers for losses sustained from infringement of third-party intellectual property rights. However, we are contingently liable under certain agreements to defend and/or indemnify certain customers, licensees and suppliers against certain types of liability and/or damages arising from the infringement of third-party intellectual property rights. Our obligations under these agreements may be limited in terms of time and/or amount, and in some instances, we may have recourse against third parties for certain payments made by us.

[0001728949-20-000067:notes:194]
Claims and reimbursements under indemnification arrangements have not been material to our consolidated financial statements. We have not recorded accruals for certain claims under indemnification arrangements based on our belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001728949-20-000067:notes:195]
Purchase Obligations. We have agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under our manufacturing relationships with our foundry suppliers and assembly and test service providers, cancellation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancellation, and in some cases, incremental fees related to capacity underutilization.

[0001728949-20-000067:notes:196]
Obligations under our purchase agreements, which primarily relate to integrated circuit product inventory obligations, at September 27, 2020 were as follows (in millions):

[0001728949-20-000067:notes:197]
|  |  |  |  | September 27,2020 |  |  |
| 2021 |  |  |  | $ | 5,468 |  |  |  |
| 2022 |  |  |  | 350 |  |  |  |
| 2023 |  |  |  | 189 |  |  |  |
| 2024 |  |  |  | 45 |  |  |  |
| 2025 |  |  |  | 8 |  |  |  |
| Thereafter |  |  |  | — |  |  |  |
| Total |  |  |  | $ | 6,060 |  |  |  |

[0001728949-20-000067:notes:198]
Operating Leases. We lease certain of our land, facilities and equipment under operating leases, with terms ranging from less than one year to 20 years, some of which include options to extend for up to 20 years. At September 27, 2020, other assets included $460 million of operating lease assets, with corresponding lease liabilities of $134 million recorded in other current liabilities and $371 million recorded in other liabilities.

[0001728949-20-000067:notes:199]
Operating lease expense for fiscal 2020, 2019 and 2018 was $181 million, $146 million and $160 million, respectively. Cash paid under our operating leases was $153 million for fiscal 2020. As of September 27, 2020, the weighted-average remaining lease term and weighted-average discount rate for operating leases were 6 years and 4%, respectively.

[0001728949-20-000067:notes:200]
At September 27, 2020, future lease payments under our operating leases were as follows (in millions):

[0001728949-20-000067:notes:201]
|  |  |  | September 27,2020 |
| 2021 |  |  | $ | 141 |  |
| 2022 |  |  | 121 |  |
| 2023 |  |  | 75 |  |
| 2024 |  |  | 53 |  |
| 2025 |  |  | 38 |  |
| Thereafter |  |  | 150 |  |
| Total future lease payments |  |  | 578 |  |
| Imputed interest |  |  | (73) |  |
| Total lease liability balance |  |  | $ | 505 |  |

[0001728949-20-000067:notes:202]
At September 29, 2019, future minimum lease payments under our noncancelable operating leases under ASC 840 were as follows (in millions):

[0001728949-20-000067:notes:203]
|  |  |  | September 29,2019 |
| 2020 |  |  | $ | 138 |  |
| 2021 |  |  | 97 |  |
| 2022 |  |  | 66 |  |
| 2023 |  |  | 31 |  |
| 2024 |  |  | 18 |  |
| Thereafter |  |  | 35 |  |
| Total |  |  | $ | 385 |  |

[0001728949-20-000067:notes:204]
Other Commitments. At September 27, 2020, we have committed to fund certain strategic investments up to $185 million, of which $103 million is expected to be funded in fiscal 2021. The substantial majority of the remaining commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-20-000067:notes:205]
Segment Information
We are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarity of business activities within our operating segments, such as the nature of products, the level of shared products, technology and other resources, production processes and customer base. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies for use in mobile devices, wireless networks, devices used in the internet of things (IoT), broadband gateway equipment, consumer electronic devices and automotive systems for telematics and infotainment. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture, sale or use of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments and includes revenues and related costs associated with development contracts with an investee. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies), our cloud AI inference processing initiative and other technology and service initiatives.

[0001728949-20-000067:notes:206]
Our CODM allocates resources to and evaluates the performance of our segments based on revenues and earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense, certain net investment income, certain share-based compensation, gains and losses on our deferred compensation plan liabilities and related assets and certain research and development expenses, selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories and property, plant and equipment to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, goodwill and long-lived asset impairment charges and awards, settlements and/or damages arising from legal or regulatory matters.

[0001728949-20-000067:notes:207]
In fiscal 2018, all of the costs ($474 million) related to pre-commercial research and development of 5G technologies were included in unallocated corporate research and development expenses, whereas similar costs related to the research and development of other technologies, including 3G and 4G technologies, were recorded in the QCT and QTL segments. Beginning in fiscal 2019, all research and development costs associated with 5G technologies were included in segment results. Additionally, beginning in fiscal 2019, certain research and development costs associated with early research and development that were historically included in our QCT segment were allocated to our QTL segment. The net effect of these changes negatively impacted QTL’s EBT by $489 million in fiscal 2019 and positively impacted QCT’s EBT by $160 million in fiscal 2019.

[0001728949-20-000067:notes:208]
The table below presents revenues, EBT and total assets for reportable segments (in millions):

[0001728949-20-000067:notes:209]
|  | 2020 |  | 2019 |  | 2018 |
| Revenues |  |  |  |  |  |
| QCT | $ | 16,493 |  |  | $ | 14,639 |  |  | $ | 17,282 |  |
| QTL | 5,028 |  |  | 4,591 |  |  | 5,042 |  |
| QSI | 36 |  |  | 152 |  |  | 100 |  |
| Reconciling items | 1,974 |  |  | 4,891 |  |  | 187 |  |
| Total | $ | 23,531 |  |  | $ | 24,273 |  |  | $ | 22,611 |  |
| EBT |  |  |  |  |  |
| QCT | $ | 2,763 |  |  | $ | 2,143 |  |  | $ | 2,966 |  |
| QTL | 3,442 |  |  | 2,954 |  |  | 3,404 |  |
| QSI | (11) |  |  | 344 |  |  | 24 |  |
| Reconciling items | (475) |  |  | 2,040 |  |  | (6,002) |  |
| Total | $ | 5,719 |  |  | $ | 7,481 |  |  | $ | 392 |  |
| Assets |  |  |  |  |  |
| QCT | $ | 3,990 |  |  | $ | 2,307 |  |  | $ | 3,041 |  |
| QTL | 1,601 |  |  | 1,541 |  |  | 1,472 |  |
| QSI | 1,371 |  |  | 1,708 |  |  | 1,279 |  |
| Reconciling items | 28,632 |  |  | 27,401 |  |  | 26,926 |  |
| Total | $ | 35,594 |  |  | $ | 32,957 |  |  | $ | 32,718 |  |

[0001728949-20-000067:notes:210]
Segment assets are comprised of accounts receivable and inventories for QCT and QTL. QSI segment assets include certain non-marketable equity instruments, receivables and other investments. QSI assets at September 27, 2020, September 29, 2019 and September 30, 2018 included $110 million, $230 million and $283 million, respectively, related to investments in equity method investees. Total segment assets differ from total assets on a consolidated basis as a result of unallocated corporate assets primarily comprised of certain cash, cash equivalents, marketable and non-marketable securities, accounts receivable from Huawei related to the remaining amounts due under the settlement agreement (Note 2), property, plant and equipment, deferred tax assets, goodwill, intangible assets, operating lease assets, noncurrent income taxes receivables, deferred compensation plan assets and assets of nonreportable segments. The net book value of long-lived tangible assets located outside of the United States was $2.3 billion, $1.4 billion and $1.4 billion at September 27, 2020, September 29, 2019 and September 30, 2018, respectively. The net book value of long-lived tangible assets located in the United States was $1.9 billion, $1.7 billion and $1.6 billion at September 27, 2020, September 29, 2019 and September 30, 2018, respectively.

[0001728949-20-000067:notes:211]
We report revenues from external customers by country based on the location to which our products or services are delivered, which for QCT is generally the country in which our customers manufacture their products, and for licensing revenues, the invoiced addresses of our licensees. As a result, the revenues by country presented herein are not necessarily indicative of either the country in which the devices containing our products and/or intellectual property are ultimately sold to consumers or the country in which the companies that sell the devices are headquartered. For example, China revenues could include revenues related to shipments of integrated circuits for a company that is headquartered in South Korea but that manufactures devices in China, which devices are then sold to consumers in Europe and/or the United States. Revenues by country were as follows (in millions):

[0001728949-20-000067:notes:212]
|  | 2020 |  | 2019 |  | 2018 |
| China (including Hong Kong) | $ | 14,001 |  |  | $ | 11,610 |  |  | $ | 15,149 |  |
| South Korea | 2,964 |  |  | 2,400 |  |  | 3,175 |  |
| United States | 1,129 |  |  | 2,774 |  |  | 603 |  |
| Ireland | 867 |  |  | 2,957 |  |  | 1 |  |
| Other foreign | 4,570 |  |  | 4,532 |  |  | 3,683 |  |
|  | $ | 23,531 |  |  | $ | 24,273 |  |  | $ | 22,611 |  |

[0001728949-20-000067:notes:213]
Reconciling items for revenues and EBT in a previous table were as follows (in millions):

[0001728949-20-000067:notes:214]
|  |  |  |  | 2020 |  | 2019 |  | 2018 |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonreportable segments |  |  |  |  |  |  |  | $ | 133 |  |  | $ | 168 |  |  | $ | 287 |  |
| Unallocated revenues |  |  |  |  |  |  |  | 1,841 |  |  | 4,723 |  |  | (100) |  |
|  |  |  |  |  |  |  |  | $ | 1,974 |  |  | $ | 4,891 |  |  | $ | 187 |  |
| EBT |  |  |  |  |  |  |  |  |  |  |  |  |
| Unallocated revenues |  |  |  |  |  |  |  | $ | 1,841 |  |  | $ | 4,723 |  |  | $ | (100) |  |
| Unallocated cost of revenues |  |  |  |  |  |  |  | (340) |  |  | (430) |  |  | (486) |  |
| Unallocated research and development expenses |  |  |  |  |  |  |  | (1,046) |  |  | (989) |  |  | (1,154) |  |
| Unallocated selling, general and administrative expenses |  |  |  |  |  |  |  | (401) |  |  | (413) |  |  | (576) |  |
| Unallocated other income (expenses) (Note 2) |  |  |  |  |  |  |  | 28 |  |  | (414) |  |  | (3,135) |  |
| Unallocated interest expense |  |  |  |  |  |  |  | (599) |  |  | (619) |  |  | (761) |  |
| Unallocated investment and other income, net |  |  |  |  |  |  |  | 105 |  |  | 243 |  |  | 566 |  |
| Nonreportable segments |  |  |  |  |  |  |  | (63) |  |  | (61) |  |  | (356) |  |
|  |  |  |  |  |  |  |  | $ | (475) |  |  | $ | 2,040 |  |  | $ | (6,002) |  |

[0001728949-20-000067:notes:215]
Certain revenues (and reduction to revenues) were not allocated to our segments in our management reports because they were not considered in evaluating segment results. Unallocated revenues in fiscal 2020 were comprised of licensing revenues from Huawei resulting from the settlement agreement and royalties for sales made in the March 2020 and June 2020 quarters under the new global patent license agreement (Note 2). Unallocated revenues in fiscal 2019 were comprised of licensing revenues resulting from the settlement with Apple and its contract manufacturers in April 2019. Unallocated revenues in fiscal 2018 were comprised of reductions to licensing revenues related to the portions of business arrangements that resolved legal disputes and were not allocated to our QTL segment.


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-20-000067:notes:216]
Fair Value Measurements
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at September 27, 2020 (in millions):

[0001728949-20-000067:notes:217]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 2,283 |  |  | $ | 3,248 |  |  | $ | — |  |  | $ | 5,531 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Corporate bonds and notes | — |  |  | 4,049 |  |  | — |  |  | 4,049 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 66 |  |  | 35 |  |  | 101 |  |
| Equity securities | 352 |  |  | — |  |  | — |  |  | 352 |  |
| Total marketable securities | 352 |  |  | 4,125 |  |  | 35 |  |  | 4,512 |  |
| Derivative instruments | — |  |  | 51 |  |  | — |  |  | 51 |  |
| Other investments | 501 |  |  | — |  |  | 13 |  |  | 514 |  |
| Total assets measured at fair value | $ | 3,136 |  |  | $ | 7,424 |  |  | $ | 48 |  |  | $ | 10,608 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |
| Other liabilities | 501 |  |  | — |  |  | — |  |  | 501 |  |
| Total liabilities measured at fair value | $ | 501 |  |  | $ | 7 |  |  | $ | — |  |  | $ | 508 |  |

[0001728949-20-000067:notes:218]
Activity within Level 3 of the Fair Value Hierarchy. Other investments included in Level 3 at September 27, 2020 and September 29, 2019 were comprised of non-marketable debt instruments, and other liabilities included in Level 3 at September 29, 2019 were comprised of contingent consideration related to business combinations. Activity for marketable securities, other investments and other liabilities classified within Level 3 of the valuation hierarchy was insignificant during fiscal 2020 (primarily related to impairment of certain of our non-marketable debt instruments, purchases and settlements of

[0001728949-20-000067:notes:219]
non-marketable debt instruments and payments of contingent consideration related to certain business acquisitions) and fiscal 2019 (primarily related to issuances of non-marketable debt instruments and payments of contingent consideration).

[0001728949-20-000067:notes:220]
Nonrecurring Fair Value Measurements. We measure certain assets and liabilities at fair value on a nonrecurring basis. These assets and liabilities include equity method and non-marketable equity investments, assets acquired and liabilities assumed in an acquisition or in a nonmonetary exchange, and property, plant and equipment and intangible assets that are written down to fair value when they are held for sale or determined to be impaired. During fiscal 2020, certain of our non-marketable equity investments were written down to their estimated fair values, which was recorded as a component of impairment losses on other investments in investment and other income, net (Note 2), and certain other non-marketable equity investments were remeasured to their estimated fair values based on observable price changes in orderly transactions for identical or similar securities, which was recorded as a component of net gains on other investments in investment and other income, net (Note 2). For a significant portion of the impairments, the estimated fair values resulted in a full write-off of the carrying values. The estimation of fair values was judgmental in nature and involved the use of significant estimates and assumptions. We determined these fair value measurements primarily using a market approach and key inputs and assumptions included estimated market value of assets, ability of investees to access additional financing or otherwise continue as a going concern, volatility and liquidation and other rights of the securities we hold.

[0001728949-20-000067:notes:221]
During 2019, certain property, plant and equipment, non-marketable equity investments, intangible assets and goodwill were written down to their estimated fair values. We also measured certain non-marketable equity investments received as non-cash consideration at fair value on a nonrecurring basis (Note 2). We determined these fair value measurements using cost, market and income approaches.

[0001728949-20-000067:notes:222]
The estimation of fair value used in the fair value measurements required the use of significant unobservable inputs, and as a result, the fair value measurements were classified as Level 3. We did not have any other significant assets or liabilities that were measured at fair value on a nonrecurring basis in periods subsequent to initial recognition for all periods presented.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-20-000067:notes:223]
Marketable Securities
We classify marketable securities as current or noncurrent based on the nature of the securities and their availability for use in current operations. Our marketable securities were comprised as follows (in millions):

[0001728949-20-000067:notes:224]
|  | Current |  | Noncurrent (1) |
|  | September 27,2020 |  | September 29,2019 |  | September 27,2020 |  | September 29,2019 |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | 10 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes | 4,049 |  |  | 4 |  |  | — |  |  | — |  |
| Mortgage- and asset-backed and auction rate securities | 66 |  |  | — |  |  | 35 |  |  | 35 |  |
| Total available-for-sale debt securities | 4,125 |  |  | 4 |  |  | 35 |  |  | 35 |  |
| Equity securities | 352 |  |  | 417 |  |  | — |  |  | 1 |  |
| Time deposit (2) | 30 |  |  | — |  |  | — |  |  | — |  |
| Total marketable securities | $ | 4,507 |  |  | $ | 421 |  |  | $ | 35 |  |  | $ | 36 |  |

[0001728949-20-000067:notes:225]
(1) Noncurrent marketable securities were included in other assets.

[0001728949-20-000067:notes:226]
(2) At September 27, 2020, marketable securities also included a time deposit with an original maturity of greater than 90 days.

[0001728949-20-000067:notes:227]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001728949-20-000067:notes:228]
|  | September 27,2020 |
| Years to Maturity: |  |
| Less than one year | $ | 2,868 |  |
| One to five years | 1,192 |  |
| No single maturity date | 100 |  |
| Total | $ | 4,160 |  |

[0001728949-20-000067:notes:229]
Debt securities with no single maturity date included mortgage- and asset-backed securities and auction rate securities.

[0001728949-20-000067:notes:230]
At September 27, 2020, unrealized gains and unrealized losses on available-for-sale debt securities were $20 million and negligible, respectively. At September 29, 2019, unrealized gains and losses on available-for-sale debt securities were negligible.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001728949-20-000067:notes:231]
Summarized Quarterly Data (Unaudited)
The following financial information reflects all normal recurring adjustments that are, in the opinion of management, necessary for a fair statement of the results of the interim periods.

[0001728949-20-000067:notes:232]
The table below presents quarterly data for fiscal 2020 and 2019 (in millions, except per share data):

[0001728949-20-000067:notes:233]
|  | 1st Quarter |  | 2nd Quarter |  | 3rd Quarter |  | 4th Quarter |
| 2020 (1) |  |  |  |  |  |  |  |
| Revenues (2) | $ | 5,077 |  |  | $ | 5,216 |  |  | $ | 4,893 |  |  | $ | 8,346 |  |
| Operating income (2) | 1,030 |  |  | 991 |  |  | 782 |  |  | 3,452 |  |
| Net income (2) | 925 |  |  | 468 |  |  | 845 |  |  | 2,960 |  |
| Basic earnings per share (4) | $ | 0.81 |  |  | $ | 0.41 |  |  | $ | 0.75 |  |  | $ | 2.62 |  |
| Diluted earnings per share (4) | 0.80 |  |  | 0.41 |  |  | 0.74 |  |  | 2.58 |  |
| 2019 (1) |  |  |  |  |  |  |  |
| Revenues (3) | $ | 4,842 |  |  | $ | 4,982 |  |  | $ | 9,635 |  |  | $ | 4,814 |  |
| Operating income (3) | 710 |  |  | 940 |  |  | 5,317 |  |  | 701 |  |
| Net income (3) | 1,068 |  |  | 663 |  |  | 2,149 |  |  | 506 |  |
| Basic earnings per share (4) | $ | 0.88 |  |  | $ | 0.55 |  |  | $ | 1.77 |  |  | $ | 0.42 |  |
| Diluted earnings per share (4) | 0.87 |  |  | 0.55 |  |  | 1.75 |  |  | 0.42 |  |

[0001728949-20-000067:notes:234]
(1)Amounts, other than per share amounts, are rounded to millions each quarter. Therefore, the sum of the quarterly amounts may not equal the annual amounts reported.

[0001728949-20-000067:notes:235]
(2)Revenues, operating income and net income in the fourth quarter of fiscal 2020 included $1.8 billion resulting from the settlement of our prior dispute with Huawei. Net income in the second quarter of fiscal 2020 was impacted by $265 million in non-marketable investment impairments due in part from the impact that the COVID-19 pandemic had on certain of our investees.

[0001728949-20-000067:notes:236]
(3)Revenues, operating income and net income in the third quarter of fiscal 2019 included $4.7 billion resulting from the settlement with Apple and its contract manufacturers. Operating income and net income in the third quarter of fiscal 2019 were impacted by a $275 million charge related to the 2019 EC Fine. Net income in the first quarter of fiscal 2019 was impacted by an income tax benefit of $570 million due to establishing new U.S. net deferred tax assets from making certain check-the-box elections. Net income in the third quarter of fiscal 2019 was impacted by a $2.5 billion charge to income tax expense resulting from the derecognition of a deferred tax asset related to the distributed intellectual property.

[0001728949-20-000067:notes:237]
(4)Earnings per share and earnings per share are computed independently for each quarter and the full year based upon respective average shares outstanding. Therefore, the sum of the quarterly earnings per share amounts may not equal the annual amounts reported.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001728949-20-000067:notes:238]
SCHEDULE II

[0001728949-20-000067:notes:239]
QUALCOMM Incorporated

[0001728949-20-000067:notes:240]
VALUATION AND QUALIFYING ACCOUNTS

[0001728949-20-000067:notes:241]
The table below details the activity of the valuation allowance on deferred tax assets for fiscal 2020, 2019 and 2018 (in millions):

[0001728949-20-000067:notes:242]
|  | Balance atBeginning ofPeriod |  | Charged toCosts andExpenses |  |  |  | Other |  | Balance atEnd ofPeriod |
| Year ended September 27, 2020 | $ | 1,672 |  |  | $ | 60 |  |  |  |  | $ | (4) |  |  | $ | 1,728 |  |
| Year ended September 29, 2019 | 1,529 |  |  | 143 |  |  |  |  | — |  |  | 1,672 |  |
| Year ended September 30, 2018 | 863 |  |  | 666 |  |  |  |  | — |  |  | 1,529 |  |
