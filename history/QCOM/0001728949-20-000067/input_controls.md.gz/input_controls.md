# QCOM 10-K controls and the auditor's report


## auditors_report

[0001728949-20-000067:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001728949-20-000067:auditors_report:2]
To the Board of Directors and Stockholders of QUALCOMM Incorporated

[0001728949-20-000067:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001728949-20-000067:auditors_report:4]
We have audited the accompanying consolidated balance sheets of QUALCOMM Incorporated and its subsidiaries as of September 27, 2020 and September 29, 2019, and the related consolidated statements of operations, comprehensive income (loss), stockholders’ equity and cash flows for each of the three years in the period ended September 27, 2020, including the related notes and financial statement schedule listed in the index appearing under Item 15(a)(2) (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of September 27, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001728949-20-000067:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of September 27, 2020 and September 29, 2019, and the results of its operations and its cash flows for each of the three years in the period ended September 27, 2020 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of September 27, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001728949-20-000067:auditors_report:6]
Changes in Accounting Principles

[0001728949-20-000067:auditors_report:7]
As discussed in Note 1 to the consolidated financial statements, the Company changed the manner in which it accounts for leases in fiscal 2020 and the manner in which it accounts for revenues from contracts with customers and income tax effects of intra-entity transfers of assets other than inventory in fiscal 2019.

[0001728949-20-000067:auditors_report:8]
Basis for Opinions

[0001728949-20-000067:auditors_report:9]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Report on Internal Control over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001728949-20-000067:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001728949-20-000067:auditors_report:11]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001728949-20-000067:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0001728949-20-000067:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001728949-20-000067:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001728949-20-000067:auditors_report:15]
F-1

[0001728949-20-000067:auditors_report:16]
Critical Audit Matters

[0001728949-20-000067:auditors_report:17]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that (i) relate to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001728949-20-000067:auditors_report:18]
Legal and Regulatory Proceedings

[0001728949-20-000067:auditors_report:19]
As described in Notes 1 and 7 to the consolidated financial statements, the Company is currently involved in certain legal and regulatory proceedings. If there is at least a reasonable possibility that a material loss may have been incurred associated with a pending legal and regulatory proceeding, management discloses such fact, and if reasonably estimable, management provides an estimate of the possible loss or range of possible loss. Management records the best estimate of a loss related to pending legal and regulatory proceedings when the loss is considered probable and the amount can be reasonably estimated. Where a range of a loss can be reasonably estimated with no best estimate in the range, management records the minimum estimated liability. As additional information becomes available, management assesses the potential liability related to pending legal or regulatory proceedings and revises the estimates and updates the disclosures accordingly. Significant judgment is required by management in both the determination of probability of loss and the determination as to whether a loss is reasonably estimable.

[0001728949-20-000067:auditors_report:20]
The principal considerations for our determination that performing procedures relating to legal and regulatory proceedings is a critical audit matter are the significant judgment by management when assessing the likelihood of a loss being incurred and when determining whether a reasonable estimate of the loss or range of loss can be made; this led to a high degree of auditor judgment, subjectivity and significant audit effort in evaluating management’s assessment of the loss contingencies associated with the legal and regulatory proceedings.

[0001728949-20-000067:auditors_report:21]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to management’s evaluation of legal and regulatory proceedings, including controls over determining whether a loss is probable and whether the amount of loss can be reasonably estimated, as well as financial statement disclosures. These procedures also included, among others: (i) obtaining and evaluating the letters of audit inquiry with external and internal legal counsel; (ii) reading certain correspondence the Company received from regulators; (iii) reading certain documents the Company has filed with the courts and related counterparty filings; (iv) reading certain documents issued by the courts; (v) evaluating the reasonableness of management’s process for identifying and assessing loss contingencies regarding whether an unfavorable outcome is probable and reasonably estimable; and (vi) evaluating the sufficiency of the Company’s legal and regulatory proceedings disclosures in the consolidated financial statements.

[0001728949-20-000067:auditors_report:22]
Revenue Recognition - Huawei Agreements

[0001728949-20-000067:auditors_report:23]
As described in Note 2 to the consolidated financial statements, in July 2020, the Company entered into a settlement agreement with Huawei to resolve their prior dispute related to their license agreement that expired on December 31, 2019 and also entered into a new long term, global patent license agreement that applies to sales of certain wireless products by Huawei beginning on January 1, 2020 (collectively “Huawei Agreements”). Amounts due under the settlement agreement are to be paid in installments by the end of June 2021 in accordance with an agreed upon payment schedule. Significant evaluation and judgment were required by management in determining the appropriate accounting for the Huawei Agreements. Management considered, among other items, (i) Huawei’s commitment to perform under the Huawei Agreements (including Huawei’s intent and ability to pay amounts due); (ii) Huawei’s performance to date under the Huawei Agreements (including timely payments made); (iii) Huawei’s current and projected financial condition (including the impact of enacted national security protection policies by the U.S. government on Huawei’s business); and (iv) certain contractual protections obtained under the Huawei Agreements. Based on this evaluation, management concluded the revenue recognition criteria were met, and recorded revenues of $1.8 billion in the fourth quarter of fiscal 2020 related to the full amount due from Huawei under the settlement agreement and amounts for the March 2020 and June 2020 quarters under the new global patent license agreement. In addition, revenues recorded for the fourth quarter of fiscal 2020 included estimated royalties due from Huawei for sales made in the September 2020 quarter under the new global patent license agreement.

[0001728949-20-000067:auditors_report:24]
The principal considerations for our determination that performing procedures relating to revenue recognition for the Huawei Agreements is a critical audit matter are the significant judgment by management in determining the appropriate accounting for the Huawei Agreements, including evaluating the significant judgments related to determining Huawei's commitment to perform its contractual obligations and probability of collection under the Huawei Agreements; this led to a high degree of auditor judgment, subjectivity and significant audit effort in performing procedures to evaluate the appropriateness of revenue recognized for the Huawei Agreements.

[0001728949-20-000067:auditors_report:25]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the revenue recognition process, including the assessment and evaluation of the Huawei Agreements. These procedures also included, among others, evaluating the revenue recognized for the Huawei Agreements and the reasonableness of significant judgments related to determining Huawei’s commitment to perform its contractual obligations and probability of collection

[0001728949-20-000067:auditors_report:26]
F-2

[0001728949-20-000067:auditors_report:27]
under the Huawei Agreements. Evaluating the reasonableness of management’s judgments included (i) reading the Huawei Agreements; (ii) performing inquiries with key members of management who were involved in the negotiation and execution of the Huawei Agreements; (iii) evaluating Huawei’s compliance with initial payment and reporting obligations under the Huawei Agreements; (iv) evaluating management’s assessment of collectability, including the analysis of the impact of enacted national security protection policies by the U.S. government on Huawei’s business; and (v) confirming the outstanding receivable balance from the settlement agreement as of September 27, 2020 with Huawei.

[0001728949-20-000067:auditors_report:28]
/s/ PricewaterhouseCoopers LLP

[0001728949-20-000067:auditors_report:29]
San Diego, California

[0001728949-20-000067:auditors_report:30]
November 4, 2020

[0001728949-20-000067:auditors_report:31]
We have served as the Company’s auditor since 1985.

[0001728949-20-000067:auditors_report:32]
F-3

[0001728949-20-000067:auditors_report:33]
QUALCOMM Incorporated


## item_9a

[0001728949-20-000067:item_9a:1]
Item 9A. Controls and Procedures

[0001728949-20-000067:item_9a:2]
Conclusion Regarding the Effectiveness of Disclosure Controls and Procedures

[0001728949-20-000067:item_9a:3]
Under the supervision and with the participation of our management, including our principal executive officer and our principal financial officer, we conducted an evaluation of our disclosure controls and procedures, as such terms are defined under Rule 13a-15(e) promulgated under the Securities Exchange Act of 1934, as amended (the Exchange Act). Based on this evaluation, our principal executive officer and our principal financial officer concluded that our disclosure controls and procedures were effective as of the end of the period covered by this Annual Report.

[0001728949-20-000067:item_9a:4]
Management’s Report on Internal Control over Financial Reporting

[0001728949-20-000067:item_9a:5]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). Under the supervision and with the participation of our management, including our principal executive officer and our principal financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting based on the framework in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on our evaluation under this framework, our management concluded that our internal control over financial reporting was effective as of September 27, 2020.

[0001728949-20-000067:item_9a:6]
PricewaterhouseCoopers LLP, the independent registered public accounting firm that audited our consolidated financial statements included in this Annual Report, has also audited the effectiveness of our internal control over financial reporting as of September 27, 2020, as stated in its report which appears on pages F-1 through F-3 in this Annual Report.

[0001728949-20-000067:item_9a:7]
Inherent Limitations over Internal Controls

[0001728949-20-000067:item_9a:8]
Our internal control over financial reporting is designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of consolidated financial statements for external purposes in accordance with generally accepted accounting principles. Our internal control over financial reporting includes those policies and procedures that:

[0001728949-20-000067:item_9a:9]
51

[0001728949-20-000067:item_9a:10]
i.pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of our assets;

[0001728949-20-000067:item_9a:11]
ii.provide reasonable assurance that transactions are recorded as necessary to permit preparation of consolidated financial statements in accordance with generally accepted accounting principles, and that our receipts and expenditures are being made only in accordance with authorizations of our management and directors; and

[0001728949-20-000067:item_9a:12]
iii.provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on the consolidated financial statements.

[0001728949-20-000067:item_9a:13]
Internal control over financial reporting cannot provide absolute assurance of achieving financial reporting objectives because of its inherent limitations, including the possibility of human error and circumvention by collusion or overriding of controls. Accordingly, even an effective internal control system may not prevent or detect material misstatements on a timely basis. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions or that the degree of compliance with the policies or procedures may deteriorate.

[0001728949-20-000067:item_9a:14]
Changes in Internal Control over Financial Reporting

[0001728949-20-000067:item_9a:15]
There were no changes in our internal control over financial reporting during the fourth quarter of fiscal 2020 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
