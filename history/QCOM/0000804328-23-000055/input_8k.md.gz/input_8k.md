# QCOM 8-K — 0000804328-23-000054 filed 2023-11-01

## item codes, every 8-K on or before 2023-11-01

- 2023-11-01 0000804328-23-000054 — 2.02, 9.01
- 2023-08-02 0000804328-23-000042 — 2.02, 9.01
- 2023-07-21 0000804328-23-000033 — 5.03, 9.01
- 2023-05-03 0000804328-23-000022 — 2.02, 9.01
- 2023-03-09 0000804328-23-000014 — 5.07
- 2023-02-02 0000804328-23-000005 — 2.02, 9.01
- 2022-12-08 0001728949-22-000041 — 5.02
- 2022-11-09 0001104659-22-116535 — 1.01, 8.01, 9.01
- 2022-11-02 0000804328-22-000020 — 2.02, 9.01
- 2022-07-27 0001728949-22-000039 — 2.02, 9.01
- 2022-05-09 0001104659-22-057562 — 1.01, 8.01, 9.01
- 2022-04-27 0001728949-22-000025 — 2.02, 9.01
- 2022-03-14 0001728949-22-000016 — 5.07
- 2022-02-02 0001728949-22-000011 — 2.02, 9.01
- 2021-11-03 0001728949-21-000075 — 2.02, 9.01
- 2021-10-04 0001104659-21-122578 — 1.01, 7.01, 9.01
- 2021-07-28 0001728949-21-000065 — 2.02, 9.01
- 2021-07-23 0001728949-21-000055 — 5.03, 9.01
- 2021-05-21 0001728949-21-000048 — 5.02
- 2021-04-28 0001728949-21-000042 — 2.02, 9.01
- 2021-03-15 0001628280-21-004741 — 5.07
- 2021-02-03 0001728949-21-000021 — 2.02, 9.01
- 2021-01-13 0001728949-21-000009 — 1.01, 9.01
- 2021-01-08 0001728949-21-000004 — 5.02
- 2020-12-10 0001104659-20-134200 — 1.01, 1.02, 2.03, 9.01
- 2020-11-19 0001728949-20-000070 — 5.02
- 2020-11-04 0001728949-20-000066 — 2.02, 9.01
- 2020-08-18 0001104659-20-096322 — 1.01, 8.01, 9.01
- 2020-08-05 0001104659-20-090597 — 8.01, 9.01
- 2020-07-29 0001728949-20-000056 — 2.02, 9.01
- 2020-07-24 0001728949-20-000047 — 5.02
- 2020-05-11 0001104659-20-058923 — 1.01, 8.01, 9.01
- 2020-05-04 0001728949-20-000037 — 5.02
- 2020-04-29 0001728949-20-000030 — 2.02, 9.01
- 2020-03-13 0001728949-20-000015 — 5.07
- 2020-02-05 0001728949-20-000010 — 2.02, 9.01
- 2019-11-06 0001728949-19-000074 — 5.02
- 2019-11-06 0001728949-19-000071 — 2.02, 9.01
- 2019-08-28 0001728949-19-000058 — 5.02
- 2019-07-31 0001728949-19-000053 — 2.02, 9.01
- 2019-05-10 0001728949-19-000044 — 5.02
- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2023-11-01

- none on or before 2023-11-01

## item 2.02 — earnings release, exhibit 99.1

[0000804328-23-000054:8k_2_02:1]
EX-99.1
2
qcom092423erex991.htm
EX-99.1

[0000804328-23-000054:8k_2_02:2]
Document

[0000804328-23-000054:8k_2_02:3]
Exhibit 99.1

[0000804328-23-000054:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000804328-23-000054:8k_2_02:5]
Qualcomm Contact:

[0000804328-23-000054:8k_2_02:6]
Mauricio Lopez-Hodoyan

[0000804328-23-000054:8k_2_02:7]
Vice President, Investor Relations

[0000804328-23-000054:8k_2_02:8]
Phone: 1-858-658-4813 | e-mail: ir@qualcomm.com

[0000804328-23-000054:8k_2_02:9]
Qualcomm Announces Fourth Quarter and Fiscal 2023 Results

[0000804328-23-000054:8k_2_02:10]
Fiscal 2023 Revenues: $35.8 billion

[0000804328-23-000054:8k_2_02:11]
Fiscal 2023 EPS: GAAP $6.42, Non-GAAP: $8.43

[0000804328-23-000054:8k_2_02:12]
—Quarterly Revenues Exceeded Midpoint of Guidance Range—

[0000804328-23-000054:8k_2_02:13]
—QCT Automotive: Record Quarterly and Fiscal Year Revenues—

[0000804328-23-000054:8k_2_02:14]
SAN DIEGO - November 1, 2023 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal fourth quarter and year ended September 24, 2023.

[0000804328-23-000054:8k_2_02:15]
“As we enter fiscal 2024, we are pleased with our roadmap and product execution, which position us well across our businesses,” said Cristiano Amon, President and CEO of Qualcomm Incorporated. “Our recent Snapdragon Summit announcements underscore our technology leadership, establishing Qualcomm as a leader in on-device generative AI and mobile computing performance.”

[0000804328-23-000054:8k_2_02:16]
Fourth Quarter Results1,2

[0000804328-23-000054:8k_2_02:17]
|  | GAAP |  | Non-GAAP |  |
| (in millions, except per share data and percentages) | Q4 Fiscal 2023 |  | Q4 Fiscal 2022 |  | Change |  | Q4 Fiscal 2023 |  | Q4 Fiscal 2022 |  |  |  |  | Change |  |
| Revenues | $8,631 |  | $11,396 |  | (24%) |  | $8,665 |  | $11,387 |  |  |  |  | (24%) |  |
| Earnings before taxes (EBT) | $1,420 |  | $3,470 |  | (59%) |  | $2,617 |  | $4,142 |  |  |  |  | (37%) |  |
| Net income | $1,489 |  | $2,873 |  | (48%) |  | $2,277 |  | $3,548 |  |  |  |  | (36%) |  |
| Diluted earnings per share (EPS) | $1.32 |  | $2.54 |  | (48%) |  | $2.02 |  | $3.13 |  |  |  |  | (35%) |  |

[0000804328-23-000054:8k_2_02:18]
Fiscal 2023 Results1,2,3

[0000804328-23-000054:8k_2_02:19]
|  | GAAP |  | Non-GAAP |  |
| (in millions, except per share data and percentages) | Fiscal 2023 |  | Fiscal 2022 |  | Change |  | Fiscal 2023 |  | Fiscal 2022 |  |  |  |  | Change |  |
| Revenues | $35,820 |  | $44,200 |  | (19%) |  | $35,832 |  | $44,169 |  |  |  |  | (19%) |  |
| EBT | $7,443 |  | $14,998 |  | (50%) |  | $11,070 |  | $16,598 |  |  |  |  | (33%) |  |
| Net income | $7,232 |  | $12,936 |  | (44%) |  | $9,486 |  | $14,254 |  |  |  |  | (33%) |  |
| EPS | $6.42 |  | $11.37 |  | (44%) |  | $8.43 |  | $12.53 |  |  |  |  | (33%) |  |

[0000804328-23-000054:8k_2_02:20]
(1)  Discussion regarding our use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results are included at the end of this news release in the sections labeled “Note Regarding Use of Non-GAAP Financial Measures” and “Reconciliations of GAAP Results to Non-GAAP Results.”

[0000804328-23-000054:8k_2_02:21]
(2)  Fourth quarter and fiscal 2023 GAAP results included $427 million and $723 million, or $0.30 and $0.53 per share, respectively, of restructuring and restructuring-related charges.

[0000804328-23-000054:8k_2_02:22]
(3)  Fiscal 2022 GAAP results included a $1.1 billion benefit, or $0.97 per share, resulting from the reversal of the accrued fine imposed by the European Commission (EC) in fiscal 2018 and the associated accrued interest.

[0000804328-23-000054:8k_2_02:23]
| Qualcomm Announces Fourth Quarter and Fiscal 2023 Results | Page 2 of 10 |

[0000804328-23-000054:8k_2_02:24]
Segment Results

[0000804328-23-000054:8k_2_02:25]
Fourth Quarter

[0000804328-23-000054:8k_2_02:26]
|  | QCT |  | QTL |
| (in millions, except percentages) | Q4 Fiscal 2023 |  | Q4 Fiscal 2022 |  | Change |  | Q4 Fiscal 2023 |  | Q4 Fiscal 2022 |  | Change |  |  |  |
| Revenues | $7,374 |  | $9,904 |  | (26%) |  | $1,262 |  | $1,441 |  | (12%) |  |  |  |
| EBT | $1,889 |  | $3,386 |  | (44%) |  | $829 |  | $989 |  | (16%) |  |  |  |
| EBT as % of revenues | 26% |  | 34% |  | -8 points |  | 66% |  | 69% |  | -3 points |  |  |  |

[0000804328-23-000054:8k_2_02:27]
Fiscal 2023

[0000804328-23-000054:8k_2_02:28]
|  | QCT |  | QTL |
| (in millions, except percentages) | Fiscal 2023 |  | Fiscal 2022 |  | Change |  | Fiscal 2023 |  | Fiscal 2022 |  | Change |  |  |  |
| Revenues | $30,382 |  | $37,677 |  | (19%) |  | $5,306 |  | $6,358 |  | (17%) |  |  |  |
| EBT | $7,924 |  | $12,837 |  | (38%) |  | $3,628 |  | $4,628 |  | (22%) |  |  |  |
| EBT as % of revenues | 26% |  | 34% |  | -8 points |  | 68% |  | 73% |  | -5 points |  |  |  |

[0000804328-23-000054:8k_2_02:29]
QCT Revenue Streams1

[0000804328-23-000054:8k_2_02:30]
|  | Fourth Quarter |  | Fiscal |
| (in millions, except percentages) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |  |  |  |
| Handsets | $5,456 |  | $7,431 |  | (27%) |  | $22,570 |  | $28,815 |  | (22%) |  |  |  |
| Automotive | 535 |  | 465 |  | +15% |  | 1,872 |  | 1,509 |  | +24% |  |  |  |
| IoT | 1,383 |  | 2,008 |  | (31%) |  | 5,940 |  | 7,353 |  | (19%) |  |  |  |
| Total QCT revenues | $7,374 |  | $9,904 |  | (26%) |  | $30,382 |  | $37,677 |  | (19%) |  |  |  |

[0000804328-23-000054:8k_2_02:31]
(1) We disaggregate QCT revenues based on the industries and applications in which our products are sold. Beginning in the first quarter of fiscal 2023, QCT RFFE (radio frequency front-end) revenues, which were previously presented as a separate revenue stream, are now included within our Handsets, Automotive and internet of things (IoT) revenue streams, as applicable. Prior period information has been recast to reflect this change.

[0000804328-23-000054:8k_2_02:32]
Return of Capital to Stockholders

[0000804328-23-000054:8k_2_02:33]
|  | Stock Repurchases |  | Dividends Paid |  | Total Amount |
| (in millions, except per share data) | Shares |  | Amount |  | Per Share |  | Amount |  |
| Q4 Fiscal 2023 | 4 |  | $400 |  | $0.80 |  | $893 |  | $1,293 |
| Fiscal 2023 | 25 |  | $2,973 |  | $3.10 |  | $3,462 |  | $6,435 |

[0000804328-23-000054:8k_2_02:34]
| Qualcomm Announces Fourth Quarter and Fiscal 2023 Results | Page 3 of 10 |

[0000804328-23-000054:8k_2_02:35]
Business Outlook

[0000804328-23-000054:8k_2_02:36]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.

[0000804328-23-000054:8k_2_02:37]
|  |  |  | Current Guidance Q1 FY24 Estimates1 |  |
|  | Revenues |  | $9.1B - $9.9B |  |
|  | Supplemental Revenue Information |  |  |  |
|  | QCT revenues |  | $7.7B - $8.3B |  |
|  | QTL revenues |  | $1.3B - $1.5B |  |
|  | GAAP diluted EPS |  | $1.82 - $2.02 |  |
|  | Less diluted EPS attributable to QSI |  | $— |  |  |
|  | Less diluted EPS attributable to share-based compensation |  | ($0.45) |  |  |
|  | Less diluted EPS attributable to other items2 |  | $0.02 |  |  |
|  | Non-GAAP diluted EPS |  | $2.25 - $2.45 |  |

[0000804328-23-000054:8k_2_02:38]
(1)  Our outlook does not include provisions for proposed tax law changes, future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable. Further, due to their nature, certain income and expense items, such as certain investments, derivative and foreign currency transaction gains or losses, cannot be accurately forecast. Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain. Our outlook includes the impact of any pending business combinations to the extent they are expected to close in the upcoming quarter. Actual results may differ materially from the outlook.

[0000804328-23-000054:8k_2_02:39]
(2)  Our guidance for diluted EPS attributable to other items for the first quarter of fiscal 2024 is primarily related to the tax benefit resulting from the requirement to capitalize research and development expenditures under U.S. Federal income tax law, partially offset by acquisition-related items.

[0000804328-23-000054:8k_2_02:40]
| Qualcomm Announces Fourth Quarter and Fiscal 2023 Results | Page 4 of 10 |

[0000804328-23-000054:8k_2_02:41]
Conference Call

[0000804328-23-000054:8k_2_02:42]
Qualcomm’s fourth quarter and fiscal 2023 earnings conference call will be broadcast live on November 1, 2023, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm. This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G. The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to our financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at http://investor.qualcomm.com/ immediately prior to the commencement of the call. An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter. To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415. Callers should use reservation number 13741657.

[0000804328-23-000054:8k_2_02:43]
About Qualcomm

[0000804328-23-000054:8k_2_02:44]
Qualcomm is enabling a world where everyone and everything can be intelligently connected. Our one technology roadmap allows us to efficiently scale the technologies that launched the mobile revolution – including advanced connectivity, high-performance, low-power compute, on-device intelligence and more – to the next generation of connected smart devices across industries. Innovations from Qualcomm and our family of Snapdragon platforms will help enable cloud-edge convergence, transform industries, accelerate the digital economy, and revolutionize how we experience the world, for the greater good.

[0000804328-23-000054:8k_2_02:45]
Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio. Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of our engineering and research and development functions and substantially all of our products and services businesses, including our QCT semiconductor business. Snapdragon and Qualcomm branded products are products of Qualcomm Technologies, Inc. and/or its subsidiaries. Qualcomm patented technologies are licensed by Qualcomm Incorporated.

[0000804328-23-000054:8k_2_02:46]
Note Regarding Forward-Looking Statements

[0000804328-23-000054:8k_2_02:47]
| Qualcomm Announces Fourth Quarter and Fiscal 2023 Results | Page 5 of 10 |

[0000804328-23-000054:8k_2_02:48]
QUALCOMM Incorporated

[0000804328-23-000054:8k_2_02:49]
CONSOLIDATED BALANCE SHEETS

[0000804328-23-000054:8k_2_02:50]
(In millions, except par value amounts)

[0000804328-23-000054:8k_2_02:51]
(Unaudited)

[0000804328-23-000054:8k_2_02:52]
|  | September 24,2023 |  | September 25,2022 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 8,450 |  |  | $ | 2,773 |  |
| Marketable securities | 2,874 |  |  | 3,609 |  |
| Accounts receivable, net | 3,183 |  |  | 5,643 |  |
| Inventories | 6,422 |  |  | 6,341 |  |
| Held for sale assets | 341 |  |  | 733 |  |
| Other current assets | 1,194 |  |  | 1,625 |  |
| Total current assets | 22,464 |  |  | 20,724 |  |
| Deferred tax assets | 3,310 |  |  | 1,803 |  |
| Property, plant and equipment, net | 5,042 |  |  | 5,168 |  |
| Goodwill | 10,642 |  |  | 10,508 |  |
| Other intangible assets, net | 1,408 |  |  | 1,882 |  |
| Held for sale assets | 88 |  |  | 1,200 |  |
| Other assets | 8,086 |  |  | 7,729 |  |
| Total assets | $ | 51,040 |  |  | $ | 49,014 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,912 |  |  | $ | 3,796 |  |
| Payroll and other benefits related liabilities | 1,685 |  |  | 1,486 |  |
| Unearned revenues | 293 |  |  | 369 |  |
| Short-term debt | 914 |  |  | 1,945 |  |
| Held for sale liabilities | 333 |  |  | 581 |  |
| Other current liabilities | 4,491 |  |  | 3,689 |  |
| Total current liabilities | 9,628 |  |  | 11,866 |  |
| Unearned revenues | 99 |  |  | 144 |  |
| Income taxes payable | 1,080 |  |  | 1,472 |  |
| Long-term debt | 14,484 |  |  | 13,537 |  |
| Held for sale liabilities | 38 |  |  | 119 |  |
| Other liabilities | 4,130 |  |  | 3,863 |  |
| Total liabilities | 29,459 |  |  | 31,001 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,114 and 1,121 shares issued and outstanding, respectively | 490 |  |  | 195 |  |
| Retained earnings | 20,733 |  |  | 17,840 |  |
| Accumulated other comprehensive income (loss) | 358 |  |  | (22) |  |
| Total stockholders’ equity | 21,581 |  |  | 18,013 |  |
| Total liabilities and stockholders’ equity | $ | 51,040 |  |  | $ | 49,014 |  |

[0000804328-23-000054:8k_2_02:53]
| Qualcomm Announces Fourth Quarter and Fiscal 2023 Results | Page 6 of 10 |

[0000804328-23-000054:8k_2_02:54]
QUALCOMM Incorporated

[0000804328-23-000054:8k_2_02:55]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000804328-23-000054:8k_2_02:56]
(In millions, except per share data)

[0000804328-23-000054:8k_2_02:57]
(Unaudited)

[0000804328-23-000054:8k_2_02:58]
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  |  |  |  | September 24,2023 |  | September 25,2022 |  | September 24,2023 |  | September 25,2022 |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services |  |  |  |  |  | $ | 7,290 |  |  | $ | 9,807 |  |  | $ | 30,028 |  |  | $ | 37,171 |  |
| Licensing |  |  |  |  |  | 1,341 |  |  | 1,589 |  |  | 5,792 |  |  | 7,029 |  |
| Total revenues |  |  |  |  |  | 8,631 |  |  | 11,396 |  |  | 35,820 |  |  | 44,200 |  |
| Costs and expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  |  |  |  | 3,880 |  |  | 4,868 |  |  | 15,869 |  |  | 18,635 |  |
| Research and development |  |  |  |  |  | 2,135 |  |  | 2,179 |  |  | 8,818 |  |  | 8,194 |  |
| Selling, general and administrative |  |  |  |  |  | 628 |  |  | 683 |  |  | 2,483 |  |  | 2,570 |  |
| Other |  |  |  |  |  | 577 |  |  | — |  |  | 862 |  |  | (1,059) |  |
| Total costs and expenses |  |  |  |  |  | 7,220 |  |  | 7,730 |  |  | 28,032 |  |  | 28,340 |  |
| Operating income |  |  |  |  |  | 1,411 |  |  | 3,666 |  |  | 7,788 |  |  | 15,860 |  |
| Interest expense |  |  |  |  |  | (174) |  |  | (145) |  |  | (694) |  |  | (490) |  |
| Investment and other income (expense), net |  |  |  |  |  | 183 |  |  | (51) |  |  | 349 |  |  | (372) |  |
| Income from continuing operations before income taxes |  |  |  |  |  | 1,420 |  |  | 3,470 |  |  | 7,443 |  |  | 14,998 |  |
| Income tax benefit (expense) |  |  |  |  |  | 209 |  |  | (547) |  |  | (104) |  |  | (2,012) |  |
| Income from continuing operations |  |  |  |  |  | 1,629 |  |  | 2,923 |  |  | 7,339 |  |  | 12,986 |  |
| Discontinued operations, net of income taxes |  |  |  |  |  | (140) |  |  | (50) |  |  | (107) |  |  | (50) |  |
| Net income |  |  |  |  |  | $ | 1,489 |  |  | $ | 2,873 |  |  | $ | 7,232 |  |  | $ | 12,936 |  |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  |  |  |  |  | $ | 1.46 |  |  | $ | 2.60 |  |  | $ | 6.57 |  |  | $ | 11.56 |  |
| Discontinued operations |  |  |  |  |  | (0.13) |  |  | (0.04) |  |  | (0.10) |  |  | (0.04) |  |
| Net income |  |  |  |  |  | $ | 1.33 |  |  | $ | 2.56 |  |  | $ | 6.47 |  |  | $ | 11.52 |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  |  |  |  |  | $ | 1.44 |  |  | $ | 2.58 |  |  | $ | 6.52 |  |  | $ | 11.41 |  |
| Discontinued operations |  |  |  |  |  | (0.12) |  |  | (0.04) |  |  | (0.10) |  |  | (0.04) |  |
| Net income |  |  |  |  |  | $ | 1.32 |  |  | $ | 2.54 |  |  | $ | 6.42 |  |  | $ | 11.37 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  | 1,116 |  |  | 1,122 |  |  | 1,117 |  |  | 1,123 |  |
| Diluted |  |  |  |  |  | 1,125 |  |  | 1,133 |  |  | 1,126 |  |  | 1,137 |  |

[0000804328-23-000054:8k_2_02:59]
| Qualcomm Announces Fourth Quarter and Fiscal 2023 Results | Page 7 of 10 |

[0000804328-23-000054:8k_2_02:60]
QUALCOMM Incorporated

[0000804328-23-000054:8k_2_02:61]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000804328-23-000054:8k_2_02:62]
(In millions)

[0000804328-23-000054:8k_2_02:63]
(Unaudited)

[0000804328-23-000054:8k_2_02:64]
|  | Three Months Ended |  | Twelve Months Ended |  |  |  |  |  |  |
|  | September 24,2023 |  | September 25,2022 |  | September 24,2023 |  | September 25,2022 |  |  |  |  |  |  |
| Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income from continuing operations | $ | 1,629 |  |  | $ | 2,923 |  |  | $ | 7,339 |  |  | $ | 12,986 |  |  |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 462 |  |  | 490 |  |  | 1,809 |  |  | 1,762 |  |  |  |  |  |  |  |
| Indefinite and long-lived asset impairment charges | 179 |  |  | — |  |  | 182 |  |  | 2 |  |  |  |  |  |  |  |
| Income tax provision (less than) in excess of income tax payments | (433) |  |  | 96 |  |  | (1,269) |  |  | (138) |  |  |  |  |  |  |  |
| Share-based compensation expense | 608 |  |  | 521 |  |  | 2,484 |  |  | 2,031 |  |  |  |  |  |  |  |
| Net (gains) losses on marketable securities and other investments | (68) |  |  | 58 |  |  | (152) |  |  | 432 |  |  |  |  |  |  |  |
| Impairment losses on other investments | 12 |  |  | 6 |  |  | 132 |  |  | 47 |  |  |  |  |  |  |  |
| Other items, net | 5 |  |  | (13) |  |  | 25 |  |  | (56) |  |  |  |  |  |  |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net | 665 |  |  | (1,850) |  |  | 2,472 |  |  | (2,066) |  |  |  |  |  |  |  |
| Inventories | 200 |  |  | (936) |  |  | 8 |  |  | (3,137) |  |  |  |  |  |  |  |
| Other assets | (1) |  |  | 94 |  |  | 603 |  |  | (2,266) |  |  |  |  |  |  |  |
| Trade accounts payable | 172 |  |  | 88 |  |  | (1,880) |  |  | 1,036 |  |  |  |  |  |  |  |
| Payroll, benefits and other liabilities | 605 |  |  | 231 |  |  | 1 |  |  | (1,043) |  |  |  |  |  |  |  |
| Unearned revenues | 60 |  |  | (92) |  |  | (56) |  |  | (324) |  |  |  |  |  |  |  |
| Net cash used by operating activities from discontinued operations | (5) |  |  | (170) |  |  | (399) |  |  | (170) |  |  |  |  |  |  |  |
| Net cash provided by operating activities | 4,090 |  |  | 1,446 |  |  | 11,299 |  |  | 9,096 |  |  |  |  |  |  |  |
| Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | (293) |  |  | (634) |  |  | (1,450) |  |  | (2,262) |  |  |  |  |  |  |  |
| Purchases of debt and equity marketable securities | (646) |  |  | (145) |  |  | (668) |  |  | (1,414) |  |  |  |  |  |  |  |
| Proceeds from sales and maturities of debt and equity marketable securities | 447 |  |  | 662 |  |  | 1,566 |  |  | 2,622 |  |  |  |  |  |  |  |
| Acquisitions and other investments, net of cash acquired | (128) |  |  | (169) |  |  | (235) |  |  | (4,912) |  |  |  |  |  |  |  |
| Proceeds from sales of property, plant and equipment | 6 |  |  | 4 |  |  | 127 |  |  | 5 |  |  |  |  |  |  |  |
| Proceeds from other investments | 7 |  |  | 7 |  |  | 20 |  |  | 132 |  |  |  |  |  |  |  |
| Other items, net | 1 |  |  | 1 |  |  | 19 |  |  | 41 |  |  |  |  |  |  |  |
| Net cash (used) provided by investing activities from discontinued operations | (12) |  |  | (16) |  |  | 1,383 |  |  | (16) |  |  |  |  |  |  |  |
| Net cash (used) provided by investing activities | (618) |  |  | (290) |  |  | 762 |  |  | (5,804) |  |  |  |  |  |  |  |
| Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 400 |  |  | 3,935 |  |  | 5,068 |  |  | 7,000 |  |  |  |  |  |  |  |
| Repayment of short-term debt | (400) |  |  | (3,937) |  |  | (5,566) |  |  | (7,003) |  |  |  |  |  |  |  |
| Repayment of debt of acquired company | — |  |  | — |  |  | — |  |  | (349) |  |  |  |  |  |  |  |
| Proceeds from long-term debt | — |  |  | — |  |  | 1,880 |  |  | 1,477 |  |  |  |  |  |  |  |
| Repayment of long-term debt | — |  |  | — |  |  | (1,446) |  |  | (1,540) |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock | 201 |  |  | 168 |  |  | 434 |  |  | 356 |  |  |  |  |  |  |  |
| Repurchases and retirements of common stock | (400) |  |  | (500) |  |  | (2,973) |  |  | (3,129) |  |  |  |  |  |  |  |
| Dividends paid | (893) |  |  | (841) |  |  | (3,462) |  |  | (3,212) |  |  |  |  |  |  |  |
| Payments of tax withholdings related to vesting of share-based awards | (22) |  |  | (15) |  |  | (521) |  |  | (766) |  |  |  |  |  |  |  |
| Other items, net | (3) |  |  | (6) |  |  | (19) |  |  | (34) |  |  |  |  |  |  |  |
| Net cash provided (used) by financing activities from discontinued operations | — |  |  | 4 |  |  | (58) |  |  | 4 |  |  |  |  |  |  |  |
| Net cash used by financing activities | (1,117) |  |  | (1,192) |  |  | (6,663) |  |  | (7,196) |  |  |  |  |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents | (5) |  |  | (63) |  |  | 30 |  |  | (113) |  |  |  |  |  |  |  |
| Net increase (decrease) in total cash and cash equivalents | 2,350 |  |  | (99) |  |  | 5,428 |  |  | (4,017) |  |  |  |  |  |  |  |
| Total cash and cash equivalents at beginning of period (including $90, $522, and $326 classified as held for sale at June 25, 2023, June 26, 2022, and September 25, 2022, respectively) | 6,177 |  |  | 3,198 |  |  | 3,099 |  |  | 7,116 |  |  |  |  |  |  |  |
| Total cash and cash equivalents at end of period (including $77 and $326 classified as held for sale at September 24, 2023 and September 25, 2022, respectively) | $ | 8,527 |  |  | $ | 3,099 |  |  | $ | 8,527 |  |  | $ | 3,099 |  |  |  |  |  |  |  |

[0000804328-23-000054:8k_2_02:65]
| Qualcomm Announces Fourth Quarter and Fiscal 2023 Results | Page 8 of 10 |

[0000804328-23-000054:8k_2_02:66]
Note Regarding Use of Non-GAAP Financial Measures

[0000804328-23-000054:8k_2_02:67]
The Non-GAAP financial measures presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP. In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, our Non-GAAP financial measures might be different than similarly titled measures used by other companies. Reconciliations between GAAP and Non-GAAP financial measures are presented herein.

[0000804328-23-000054:8k_2_02:68]
We use Non-GAAP financial information: (i) to evaluate, assess and benchmark our operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of our ongoing core operating businesses, including our QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors. Non-GAAP measurements used by us include revenues, cost of revenues, research and development (R&D) expenses, selling, general and administrative (SG&A) expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share. We are able to assess what we believe is a meaningful and comparable set of financial performance measures by using Non-GAAP information. In addition, the HR and Compensation Committee of our Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers. We present Non-GAAP financial information to provide greater transparency to investors with respect to our use of such information in financial and operational decision-making. This Non-GAAP financial information is also used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0000804328-23-000054:8k_2_02:69]
Non-GAAP information presented herein excludes our QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0000804328-23-000054:8k_2_02:70]
•QSI is excluded because we generally expect to exit our strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed as unrelated to our operational performance.

[0000804328-23-000054:8k_2_02:71]
•Share-based compensation expense primarily relates to restricted stock units. We believe that excluding share-based compensation from Non-GAAP financial information allows us and investors to make additional comparisons of the operating activities of our ongoing core businesses over time and with respect to other companies.

[0000804328-23-000054:8k_2_02:72]
•Certain other items are excluded because we view such items as unrelated to the operating activities of our ongoing core businesses, as follows:

[0000804328-23-000054:8k_2_02:73]
◦Acquisition-related items include amortization of acquisition-related intangible assets, substantially all of which relate to the amortization of technology-based intangible assets that is recorded in cost of revenues and will recur in future periods until the related intangible assets have been fully amortized. We view acquisition-related intangible assets as items arising from pre-acquisition activities determined at the time of an acquisition. Acquisition-related intangible assets contribute to revenue generation that has not been excluded from our Non-GAAP financial information. Acquisition-related items also include recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of acquisition-related items, as well as any effects from restructuring the ownership of such acquired assets. We also exclude the operating results of acquired and/or consolidated businesses that, as of close, are expected or required to be sold. Additionally, we exclude certain other acquisition-related charges such as third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition.

[0000804328-23-000054:8k_2_02:74]
◦We exclude certain other items that we view as unrelated to our ongoing businesses, such as major restructuring and restructuring-related costs, asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. We exclude gains and losses driven by the revaluation of our deferred compensation plan liabilities recognized in operating expenses and the offsetting gains and losses on the related plan assets recognized in investment and other income (expense).

[0000804328-23-000054:8k_2_02:75]
◦Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of our ongoing Non-GAAP tax rate and after-tax earnings. Beginning in the first quarter of fiscal 2023 and for the initial five-year period in which we are required to capitalize and amortize R&D expenditures for U.S. federal income tax purposes, we also exclude the favorable impact to our provision for income taxes and results of operations resulting from such change in treatment of R&D expenditures. The favorable tax provision impact will diminish in future years as capitalized research and development expenditures continue to amortize.

[0000804328-23-000054:8k_2_02:76]
| Qualcomm Announces Fourth Quarter and Fiscal 2023 Results | Page 9 of 10 |

[0000804328-23-000054:8k_2_02:77]
Reconciliations of GAAP Results to Non-GAAP Results

[0000804328-23-000054:8k_2_02:78]
| (in millions, except per share data and percentages) |  |  |  | GAAP to Non-GAAP Reconciliation | Non-GAAP Supplemental Information |
|  |  |  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results | QCT | QTL | Non-GAAP Reconciling Items3 |
| Q4 Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $8,631 |  | $6 |  | $— |  |  | ($40) |  |  | $8,665 |  | $7,374 |  | $1,262 |  | $29 |  |
| Operating income (loss) |  |  |  | 1,411 |  | — |  |  | (608) |  | (650) |  | 2,669 |  |  |  |  |  |  |  |
| EBT |  |  |  | 1,420 |  | 70 |  | (608) |  | (659) |  | 2,617 |  | 1,889 |  | 829 |  | (101) |  |
| EBT as % of revenues |  |  |  | 16 | % |  |  |  |  |  |  |  | 30 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 1,489 |  | 55 |  | (480) |  | (363) |  | 2,277 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $1.32 |  | $0.05 |  | ($0.43) |  | ($0.32) |  | $2.02 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,125 |  | 1,125 |  | 1,125 |  | 1,125 |  | 1,125 |  |  |  |  |  |  |  |
| Q4 Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $11,396 |  | $9 |  | $— |  |  | $— |  |  | $11,387 |  | $9,904 |  | $1,441 |  | $42 |  |
| Operating income (loss) |  |  |  | 3,666 |  | 2 |  | (522) |  | (70) |  | 4,256 |  |  |  |  |  |  |  |
| EBT |  |  |  | 3,470 |  | (30) |  | (522) |  | (120) |  | 4,142 |  | 3,386 |  | 989 |  | (233) |  |
| EBT as % of revenues |  |  |  | 30 | % |  |  |  |  |  |  |  | 36 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 2,873 |  | (24) |  | (437) |  | (214) |  | 3,548 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $2.54 |  | ($0.02) |  | ($0.39) |  | ($0.19) |  | $3.13 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,133 |  | 1,133 |  | 1,133 |  | 1,133 |  | 1,133 |  |  |  |  |  |  |  |
| Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $35,820 |  | $28 |  | $— |  |  | ($40) |  | $35,832 |  | $30,382 |  | $5,306 |  | $144 |  |
| Operating income (loss) |  |  |  | 7,788 |  | 1 |  | (2,484) |  | (1,189) |  | 11,460 |  |  |  |  |  |  |  |
| EBT |  |  |  | 7,443 |  | (12) |  | (2,484) |  | (1,131) |  | 11,070 |  | 7,924 |  | 3,628 |  | (482) |  |
| EBT as % of revenues |  |  |  | 21 | % |  |  |  |  |  |  |  | 31 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 7,232 |  | (10) |  | (2,021) |  | (223) |  | 9,486 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $6.42 |  | ($0.01) |  | ($1.80) |  | ($0.20) |  | $8.43 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,126 |  | 1,126 |  | 1,126 |  | 1,126 |  | 1,126 |  |  |  |  |  |  |  |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $44,200 |  | $31 |  | $— |  |  | $— |  | $44,169 |  | $37,677 |  | $6,358 |  | $134 |  |
| Operating income (loss) |  |  |  | 15,860 |  | 2 |  | (2,061) |  | 852 |  | 17,067 |  |  |  |  |  |  |  |
| EBT |  |  |  | 14,998 |  | (279) |  | (2,061) |  | 740 |  | 16,598 |  | 12,837 |  | 4,628 |  | (867) |  |
| EBT as % of revenues |  |  |  | 34 | % |  |  |  |  |  |  |  | 38 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 12,936 |  | (207) |  | (1,572) |  | 461 |  | 14,254 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $11.37 |  | ($0.18) |  | ($1.38) |  | $0.41 |  | $12.53 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,137 |  | 1,137 |  | 1,137 |  | 1,137 |  | 1,137 |  |  |  |  |  |  |  |

[0000804328-23-000054:8k_2_02:79]
(1)  Further details of amounts included in the “Other Items” column for the current periods are included at the end of this news release in the sections labeled “Supplemental Information and Reconciliations.” Details of amounts included in the “Other Items” column for the prior periods are included in the news releases for those periods.

[0000804328-23-000054:8k_2_02:80]
(2)  In the fourth quarter and fiscal 2023, other items excluded from Non-GAAP revenues included a reduction to licensing revenues related to a portion of a business arrangement that resolves a legal dispute.

[0000804328-23-000054:8k_2_02:81]
(3)   Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations. Non-GAAP reconciling items related to EBT consisted primarily of certain cost of revenues, R&D expenses, SG&A expenses, other expenses or income, interest expense and certain investment income (expense) that are not allocated to segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit.

[0000804328-23-000054:8k_2_02:82]
Sums may not equal totals due to rounding.

[0000804328-23-000054:8k_2_02:83]
| Qualcomm Announces Fourth Quarter and Fiscal 2023 Results | Page 10 of 10 |

[0000804328-23-000054:8k_2_02:84]
|  | Q4 Fiscal 2023 Supplemental Information and Reconciliations |  |
|  | (in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |
|  | Cost of revenues |  | $3,880 |  |  | $3 |  |  | $19 |  |  | $26 |  |  | $3,832 |  |
|  | Research and development expenses |  | 2,135 |  |  | — |  |  |  | 475 |  |  | 1 |  |  | 1,659 |  |
|  | Selling, general and administrative expenses |  | 628 |  |  | 3 |  |  | 114 |  |  | 6 |  |  | 505 |  |
|  | Other |  | 577 |  |  |  | — |  |  |  | — |  |  |  | 577 |  |  |  | — |  |  |
|  | Interest expense |  | 174 |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 173 |  |
|  | Investment and other income (expense), net |  | 183 |  |  | 70 |  |  | — |  |  |  | (8) |  |  | 121 |  |
|  | Income tax (benefit) expense |  | (209) |  |  | 15 |  |  |  | (128) |  |  |  | (436) |  |  | 340 |  |
|  | Discontinued operations, net of income taxes |  | (140) |  |  | — |  |  |  | — |  |  |  | (140) |  |  | — |  |  |

[0000804328-23-000054:8k_2_02:85]
(1)  Other items excluded from Non-GAAP results included $427 million of restructuring and restructuring-related charges, a $150 million intangible asset impairment charge related to in-process research and development, $43 million of acquisition-related charges, and $1 million of interest expense related to the fine imposed on us by the EC in 2019 (2019 EC fine). Other items excluded from Non-GAAP results also included $10 million of gains driven by the revaluation of our deferred compensation plan liabilities, which decreased operating expenses, offset by corresponding $8 million of losses driven by the revaluation of the associated plan assets, which were included within investment and other income (expense), net, as well as $140 million of losses, net of income taxes, from the discontinued operations of the Non-Arriver businesses.

[0000804328-23-000054:8k_2_02:86]
(2)   At fiscal year end, the quarterly tax provision for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. Tax benefit in the “Other Items” column included a $260 million benefit from the foreign-derived intangible income (FDII) deduction resulting from the requirement to capitalize and amortize R&D expenditures, a $133 million benefit from the combined effect of other items in EBT, a $59 million net benefit from the release of a valuation allowance, a $19 million benefit for the tax effect of acquisition-related charges, partially offset by a $33 million foreign currency loss related to a noncurrent receivable resulting from our refund claim of Korean withholding taxes paid in prior periods and a $2 million charge to reconcile the tax provision of each column to the total GAAP tax provision for the quarter.

[0000804328-23-000054:8k_2_02:87]
Sums may not equal totals due to rounding.

[0000804328-23-000054:8k_2_02:88]
|  | Fiscal 2023 Supplemental Information and Reconciliations |  |
|  | (in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |
|  | Cost of revenues |  | $15,869 |  |  | $15 |  |  | $76 |  |  | $129 |  |  | $15,649 |  |
|  | Research and development expenses |  | 8,818 |  |  | — |  |  |  | 1,911 |  |  | 79 |  |  | 6,828 |  |
|  | Selling, general and administrative expenses |  | 2,483 |  |  | 12 |  |  | 497 |  |  | 79 |  |  | 1,895 |  |
|  | Other |  | 862 |  |  |  | — |  |  |  | — |  |  |  | 862 |  |  |  | — |  |  |
|  | Interest expense |  | 694 |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | 690 |  |
|  | Investment and other income (expense), net |  | 349 |  |  | (13) |  |  | — |  |  |  | 62 |  |  | 300 |  |
|  | Income tax expense (benefit) |  | 104 |  |  | (2) |  |  | (463) |  |  |  | (1,015) |  |  | 1,584 |  |
|  | Discontinued operations, net of income taxes |  | (107) |  |  | — |  |  |  | — |  |  |  | (107) |  |  | — |  |  |

[0000804328-23-000054:8k_2_02:89]
(1)  Other items excluded from Non-GAAP results included $723 million of restructuring and restructuring-related charges, $189 million of acquisition-related charges, a $150 million intangible asset impairment charge related to in-process research and development, a $25 million impairment loss on investments, and $4 million of interest expense related to the 2019 EC fine. Other items excluded from Non-GAAP results also included $87 million of losses driven by the revaluation of our deferred compensation plan liabilities, which increased operating expenses, offset by corresponding $87 million of gains driven by the revaluation of the associated plan assets, which were included within investment and other income (expense), net, as well as $107 million of losses, net of income taxes, from the discontinued operations of the Non-Arriver businesses.

[0000804328-23-000054:8k_2_02:90]
(2)   Tax benefit in the “Other Items” column included a $503 million benefit from the FDII deduction resulting from the requirement to capitalize and amortize R&D expenditures, a $175 million benefit from the combined effect of other items in EBT, a $115 million benefit from fiscal 2021 and 2022 FDII deductions related to a change in sourcing of R&D expenditures, a $68 million foreign currency gain related to a noncurrent receivable resulting from our refund claim of Korean withholding taxes paid in prior periods, a $59 million net benefit from the release of a valuation allowance, a $57 million benefit related to a foreign tax audit, and a $38 million benefit for the tax effect of acquisition-related charges.

[0000804328-23-000054:8k_2_02:91]
Sums may not equal totals due to rounding.
