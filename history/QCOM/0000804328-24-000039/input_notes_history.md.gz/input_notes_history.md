# QCOM note change history — 0000804328-24-000017 → 0000804328-24-000039


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000804328-24-000039:note_history:1]
On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm (together with the Nuvia ALA, the Arm-Nuvia Agreements) and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia), server System-on-Chip (SoC) and compute SoC are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm (together with the Qualcomm ALA, the Arm-Qualcomm Agreements). We further seek an order enjoining Arm from making any claim that our products are not licensed under the Arm-Qualcomm Agreements, are not Arm-compliant or that we are prohibited from using Arm’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements Arm is making in the marketplace concerning our rights under the Arm-Qualcomm Agreements are false, and that Arm has no right to prevent us from shipping our products, which are validly licensed. On March 22, 2024, we filed a Second Amended Counterclaim asserting that Arm has breached the Arm-Nuvia Agreements by continuing to use Nuvia technology and by failing to return or destroy Nuvia confidential information after the Arm-Nuvia Agreements were terminated. The Second Amended Counterclaim seeks damages related to the asserted breaches. Trial is scheduled to begin on December 16, 2024. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.
  (was, 2024-01-31, similarity 0.7543):
[0000804328-24-000017:note_history:1]
On September 30, 2022, we filed our Answer and Counterclaim in response to ARM’s complaint denying ARM’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and ARM and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia), server System-on-Chip (SoC) and compute SoC are fully licensed under our existing Architecture License Agreement and Technology License Agreement with ARM (the ARM-Qualcomm Agreements). We further seek an order enjoining ARM from making any claim that our products are not licensed under the ARM-Qualcomm Agreements, are not ARM-compliant or that we are prohibited from using ARM’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements ARM is making in the marketplace concerning our rights under the ARM-Qualcomm Agreements are false, and that ARM has no right to prevent us from shipping our products, which are validly licensed. Trial is scheduled to begin on September 23, 2024. We intend to continue to vigorously defend ourselves in this matter.

- added (2024-05-01):
[0000804328-24-000039:note_history:2]
On April 18, 2024, we filed a separate complaint (captioned QUALCOMM Incorporated v. Arm Ltd.) against Arm in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief.

- changed (2024-05-01):
[0000804328-24-000039:note_history:3]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at March 24, 2024 for contingent losses associated with the pending matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (for example, our 2010 European Commission matter relating to the Icera
  (was, 2024-01-31, similarity 0.7937):
[0000804328-24-000017:note_history:3]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at December 24, 2023 for contingent losses associated with the pending matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (for example, our 2010 European Commission matter relating to the Icera complaint, and other matters arising in the ordinary course of our business, including those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.

- added (2024-05-01):
[0000804328-24-000039:note_history:4]
complaint, and other matters arising in the ordinary course of our business, including those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000804328-24-000039:note_history:5]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 24, 2023. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 24, 2024 and March 26, 2023 included 13 weeks and 26 weeks, respectively.
  (was, 2024-01-31, similarity 0.9616):
[0000804328-24-000017:note_history:5]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 24, 2023. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three months ended December 24, 2023 and December 25, 2022 included 13 weeks.

- changed (2024-05-01):
[0000804328-24-000039:note_history:6]
Income Tax Disclosures: In December 2023, the FASB issued new requirements to disclose annually certain additional detailed income tax information related to the effective tax rate reconciliation and income taxes paid, among other items. We will adopt the new requirements starting in fiscal 2026 on a retrospective basis.
  (was, 2024-01-31, similarity 0.9764):
[0000804328-24-000017:note_history:6]
Income Tax Disclosures: In December 2023, the FASB issued new requirements to disclose annually certain additional disaggregated income tax information related to the effective tax rate reconciliation and income taxes paid, among other items. We will adopt the new requirements starting in fiscal 2026 on a retrospective basis.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000804328-24-000039:note_history:7]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  | March 24,2024 |  | March 26,2023 |  | March 24,2024 |  | March 26,2023 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,180 |  |  | $ | 6,105 |  |  | $ | 12,867 |  |  | $ | 11,860 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 603 |  |  | 447 |  |  | 1,201 |  |  | 903 |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,243 |  |  | 1,390 |  |  | 2,381 |  |  | 3,071 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 8,026 |  |  | $ | 7,942 |  |  | $ | 16,449 |  |  | $ | 15,834 |  |
  (was, 2024-01-31, similarity 0.7677):
[0000804328-24-000017:note_history:7]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | December 24,2023 |  | December 25,2022 |  |  |  |  |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,687 |  |  | $ | 5,754 |  |  |  |  |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 598 |  |  | 456 |  |  |  |  |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,138 |  |  | 1,682 |  |  |  |  |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 8,423 |  |  | $ | 7,892 |  |  |  |  |  |
