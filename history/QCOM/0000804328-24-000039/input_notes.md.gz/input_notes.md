# QCOM notes — 0000804328-24-000039


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000804328-24-000039:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 24, 2023. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and six months ended March 24, 2024 and March 26, 2023 included 13 weeks and 26 weeks, respectively.

[0000804328-24-000039:notes:2]
[same as prior period, unchanged from 0000804328-24-000017:notes:2]

[0000804328-24-000039:notes:3]
[same as prior period, unchanged from 0000804328-24-000017:notes:3]

[0000804328-24-000039:notes:4]
[same as prior period, unchanged from 0000804328-24-000017:notes:4]

[0000804328-24-000039:notes:5]
Income Tax Disclosures: In December 2023, the FASB issued new requirements to disclose annually certain additional detailed income tax information related to the effective tax rate reconciliation and income taxes paid, among other items. We will adopt the new requirements starting in fiscal 2026 on a retrospective basis.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000804328-24-000039:notes:6]
[same as prior period, unchanged from 0000804328-24-000017:notes:6]

[0000804328-24-000039:notes:7]
| Inventories (in millions) |  |  |  |
|  | March 24,2024 |  | September 24,2023 |
| Raw materials | $ | 157 |  |  | $ | 176 |  |
| Work-in-process | 3,670 |  |  | 4,096 |  |
| Finished goods | 2,260 |  |  | 2,150 |  |
|  | $ | 6,087 |  |  | $ | 6,422 |  |

[0000804328-24-000039:notes:8]
| Other Current Liabilities (in millions) |  |  |  |
|  | March 24,2024 |  | September 24,2023 |
| Customer incentives and other customer-related liabilities | $ | 2,441 |  |  | $ | 1,821 |  |
| Income taxes payable | 1,093 |  |  | 1,717 |  |
| Other | 875 |  |  | 953 |  |
|  | $ | 4,409 |  |  | $ | 4,491 |  |

[0000804328-24-000039:notes:9]
[same as prior period, unchanged from 0000804328-24-000017:notes:8]

[0000804328-24-000039:notes:10]
[same as prior period, unchanged from 0000804328-24-000017:notes:9]

[0000804328-24-000039:notes:11]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  | March 24,2024 |  | March 26,2023 |  | March 24,2024 |  | March 26,2023 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,180 |  |  | $ | 6,105 |  |  | $ | 12,867 |  |  | $ | 11,860 |  |
| Automotive (2) |  |  |  |  |  |  |  |  | 603 |  |  | 447 |  |  | 1,201 |  |  | 903 |  |
| IoT (internet of things) (3) |  |  |  |  |  |  |  |  | 1,243 |  |  | 1,390 |  |  | 2,381 |  |  | 3,071 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 8,026 |  |  | $ | 7,942 |  |  | $ | 16,449 |  |  | $ | 15,834 |  |

[0000804328-24-000039:notes:12]
[same as prior period, unchanged from 0000804328-24-000017:notes:11]

[0000804328-24-000039:notes:13]
[same as prior period, unchanged from 0000804328-24-000017:notes:12]

[0000804328-24-000039:notes:14]
[same as prior period, unchanged from 0000804328-24-000017:notes:13]

[0000804328-24-000039:notes:15]
[same as prior period, unchanged from 0000804328-24-000017:notes:14]

[0000804328-24-000039:notes:16]
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | March 24,2024 |  | March 26,2023 |
| Revenues recognized from previously satisfied performance obligations | $ | 55 |  |  | $ | 170 |  |  | $ | 206 |  |  | $ | 337 |  |

[0000804328-24-000039:notes:17]
Unearned revenues (which are considered contract liabilities) consist primarily of certain customer contracts for which QCT received fees upfront and QTL license fees for intellectual property with continuing performance obligations. In the six months ended March 24, 2024 and March 26, 2023, we recognized revenues of $227 million and $241 million, respectively, that were recorded as unearned revenues at September 24, 2023 and September 25, 2022, respectively.

[0000804328-24-000039:notes:18]
[same as prior period, unchanged from 0000804328-24-000017:notes:17]

[0000804328-24-000039:notes:19]
[same as prior period, unchanged from 0000804328-24-000017:notes:18]

[0000804328-24-000039:notes:20]
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | March 24,2024 |  | March 26,2023 |
| Customer/licensee (x) | 24 | % |  | 25 | % |  | 21 | % |  | 19 | % |
| Customer/licensee (y) | 19 |  |  | 27 |  |  | 22 |  |  | 31 |  |
| Customer/licensee (z) | 14 |  |  | * |  | 14 |  |  | * |

[0000804328-24-000039:notes:21]
*Less than 10%

[0000804328-24-000039:notes:22]
Other Income, Costs and Expenses. Other income and expenses in the three months ended March 26, 2023 and six months ended March 24, 2024 and March 26, 2023 included certain restructuring amounts (primarily related to accrued severance costs) from cost reduction actions initiated in fiscal 2023.

[0000804328-24-000039:notes:23]
| Investment and Other Income (Expense), Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | March 24,2024 |  | March 26,2023 |
| Interest and dividend income | $ | 160 |  |  | $ | 59 |  |  | $ | 312 |  |  | $ | 114 |  |
| Net (losses) gains on marketable securities | (3) |  |  | 9 |  |  | 8 |  |  | 20 |  |
| Net gains on other investments | 155 |  |  | — |  |  | 159 |  |  | — |  |
| Net gains on deferred compensation plan assets | 62 |  |  | 21 |  |  | 126 |  |  | 47 |  |
| Impairment losses on other investments | (50) |  |  | (87) |  |  | (62) |  |  | (101) |  |
| Other | 6 |  |  | (18) |  |  | (1) |  |  | (20) |  |
|  | $ | 330 |  |  | $ | (16) |  |  | $ | 542 |  |  | $ | 60 |  |

[0000804328-24-000039:notes:24]
Discontinued Operations. On June 1, 2023, SSW Partners completed the sale of Veoneer’s Active Safety business to Magna International Inc. for net cash proceeds of $1.5 billion. On March 1, 2024, SSW Partners completed the sale of Veoneer’s Restraint Control Systems (RCS) business (collectively with the Active Safety business, the Non-Arriver businesses) to American Industrial Partners Capital Fund VII. Through the date of disposition by SSW Partners, the assets and liabilities of the Non-Arriver businesses have been presented as held for sale on our condensed consolidated balance sheets, and the operating results (including the gain or loss on sale, the amounts of which were not material) and cash flows have been presented as discontinued operations. Cash flows from investing (which includes cash proceeds from the sale of the RCS business) and financing activities from discontinued operations reported for the periods presented were not material.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000804328-24-000039:notes:25]
Income Taxes
We estimate our annual effective income tax rate to be 7% for fiscal 2024, which is lower than the U.S. federal statutory rate, primarily due to (i) a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, which includes certain additional benefits from the requirement to capitalize research and development expenditures for federal income tax purposes, (ii) a benefit from our federal research and development tax credit and (iii) excess tax benefits associated with share-based awards. Our effective tax rate of 9% for the second quarter of fiscal 2024 was higher than our estimated annual effective tax rate of 7% primarily due to net discrete tax benefits realized in the first quarter of fiscal 2024. Our effective tax rate of 9% for the second quarter of fiscal 2024 was lower than our effective tax rate of 10% for the second quarter of fiscal 2023, in part reflecting the additional benefit from FDII deductions related to certain changes made in the second half of fiscal 2023 related to income attribution and sourcing of research and development expenditures.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000804328-24-000039:notes:26]
Capital Stock
Stock Repurchase Program. On October 12, 2021, we announced a $10.0 billion stock repurchase program. The stock repurchase program has no expiration date. At March 24, 2024, $3.6 billion remained authorized for repurchase under our stock repurchase program.

[0000804328-24-000039:notes:27]
Shares Outstanding. Shares of common stock outstanding at March 24, 2024 were as follows (in millions):

[0000804328-24-000039:notes:28]
| Balance at September 24, 2023 | 1,114 |  |
| Issued | 15 |  |
| Repurchased | (11) |  |
| Balance at March 24, 2024 | 1,118 |  |

[0000804328-24-000039:notes:29]
Dividends. On March 5, 2024, we announced an increase in our quarterly dividend per share of common stock from $0.80 to $0.85, which is effective for dividends payable after March 21, 2024. On April 17, 2024, we announced a cash dividend of $0.85 per share on our common stock, payable on June 20, 2024 to stockholders of record as of the close of business on May 30, 2024.

[0000804328-24-000039:notes:30]
[same as prior period, unchanged from 0000804328-24-000017:notes:28]

[0000804328-24-000039:notes:31]
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | March 24,2024 |  | March 26,2023 |
| Dilutive common share equivalents included in diluted shares | 13 |  |  | 7 |  |  | 12 |  |  | 8 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | — |  |  | 5 |  |  | 7 |  |  | 5 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000804328-24-000039:notes:32]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0000804328-24-000039:notes:33]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. The court consolidated the two actions, and on July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On May 23, 2022, the plaintiffs filed a motion for class certification, and on March 20, 2023, the court issued an order granting in part and denying in part the plaintiffs’ motion for class certification. The order denied class certification on the basis of alleged misrepresentations relating to our chip-level licensing practices, but certified a class on the basis of alleged misrepresentations relating to the separate operations of QCT and QTL. Trial is scheduled to begin on October 28, 2024. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-24-000039:notes:34]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. The cases filed in the Southern District of California were subsequently transferred to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On September 27, 2018, the court certified the class. We appealed the court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit). On September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class, and remanded the case to the district court. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. We filed a motion to dismiss the amended complaint, and on January 6, 2023, the court issued an order granting in part and denying in part our motion to dismiss. We subsequently filed a motion for summary judgment on the plaintiffs’ remaining claims. The court granted our motion in its entirety and, on October 5, 2023, entered final judgment in Qualcomm’s favor. On November 2, 2023, the plaintiffs filed a notice of appeal to the Ninth Circuit. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-24-000039:notes:35]
Beginning in November 2017, several other consumer class action complaints were filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws and seeking damages. The claims in these complaints are similar to those in the U.S. consumer class action complaints described above. These matters are at various stages of litigation, and we intend to continue to vigorously defend ourselves.

[0000804328-24-000039:notes:36]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a notice of appeal to the United States Court of Appeals for the Federal Circuit, and on November 6, 2023, the court held a hearing on the appeal. The court has not yet issued a ruling. We intend to continue to vigorously defend ourselves in this matter.

[0000804328-24-000039:notes:37]
Arm Ltd. v. QUALCOMM Incorporated: On August 31, 2022, Arm Ltd. (Arm) filed a complaint against us in the United States District Court for the District of Delaware. Our subsidiaries Qualcomm Technologies, Inc. and NuVia, Inc. (Nuvia) are also named in the complaint. The complaint alleges that following our acquisition of Nuvia, we and Nuvia breached Nuvia’s Architecture License Agreement with Arm (the Nuvia ALA) by failing to comply with the termination obligations under the Nuvia ALA. The complaint seeks specific performance, including that we cease all use of and destroy any technology that was developed under the Nuvia ALA, including processor core technology. Arm also contends that we violated the Lanham Act through trademark infringement and false designation of origin through unauthorized use of Arm’s trademarks and seeks associated injunctive and declaratory relief. Arm further seeks exemplary or punitive damages, costs, expenses and reasonable attorney’s fees, and equitable relief addressing any infringement occurring after entry of judgment.

[0000804328-24-000039:notes:38]
On September 30, 2022, we filed our Answer and Counterclaim in response to Arm’s complaint denying Arm’s claims. Our counterclaim seeks a declaratory judgment that we did not breach the Nuvia ALA or the Technology License Agreement between Nuvia and Arm (together with the Nuvia ALA, the Arm-Nuvia Agreements) and that, following the acquisition of Nuvia, our architected cores (including all further developments, iterations or instantiations of the technology we acquired from Nuvia), server System-on-Chip (SoC) and compute SoC are fully licensed under our existing Architecture License Agreement with Arm (the Qualcomm ALA) and Technology License Agreement with Arm (together with the Qualcomm ALA, the Arm-Qualcomm Agreements). We further seek an order enjoining Arm from making any claim that our products are not licensed under the Arm-Qualcomm Agreements, are not Arm-compliant or that we are prohibited from using Arm’s marks in the marketing of any such products. On October 26, 2022, we filed an Amended Counterclaim seeking additional declaratory relief that certain statements Arm is making in the marketplace concerning our rights under the Arm-Qualcomm Agreements are false, and that Arm has no right to prevent us from shipping our products, which are validly licensed. On March 22, 2024, we filed a Second Amended Counterclaim asserting that Arm has breached the Arm-Nuvia Agreements by continuing to use Nuvia technology and by failing to return or destroy Nuvia confidential information after the Arm-Nuvia Agreements were terminated. The Second Amended Counterclaim seeks damages related to the asserted breaches. Trial is scheduled to begin on December 16, 2024. We intend to continue to vigorously defend ourselves against Arm’s claims in this matter.

[0000804328-24-000039:notes:39]
On April 18, 2024, we filed a separate complaint (captioned QUALCOMM Incorporated v. Arm Ltd.) against Arm in the United States District Court for the District of Delaware. The complaint alleges that Arm has breached the Qualcomm ALA by failing to provide certain deliverables that Arm is obligated to provide. The complaint seeks an order that Arm comply with its contractual obligations, damages, and additional relief.

[0000804328-24-000039:notes:40]
Contingent Losses and Other Considerations: Litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. We have not recorded any accrual at March 24, 2024 for contingent losses associated with the pending matters described above based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above (for example, our 2010 European Commission matter relating to the Icera

[0000804328-24-000039:notes:41]
complaint, and other matters arising in the ordinary course of our business, including those relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000804328-24-000039:notes:42]
Segment Information
We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies, including RFFE (radio frequency front-end), for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices, industrial devices, and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our cloud computing processing initiative.

[0000804328-24-000039:notes:43]
[same as prior period, unchanged from 0000804328-24-000017:notes:39]

[0000804328-24-000039:notes:44]
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | March 24,2024 |  | March 26,2023 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 8,026 |  |  | $ | 7,942 |  |  | $ | 16,449 |  |  | $ | 15,834 |  |
| QTL | 1,318 |  |  | 1,290 |  |  | 2,778 |  |  | 2,814 |  |
| QSI | 3 |  |  | 7 |  |  | 16 |  |  | 13 |  |
| Reconciling items | 42 |  |  | 36 |  |  | 82 |  |  | 77 |  |
| Total | $ | 9,389 |  |  | $ | 9,275 |  |  | $ | 19,325 |  |  | $ | 18,738 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 2,288 |  |  | $ | 2,107 |  |  | $ | 4,881 |  |  | $ | 4,291 |  |
| QTL | 933 |  |  | 871 |  |  | 2,013 |  |  | 1,988 |  |
| QSI | 96 |  |  | (53) |  |  | 107 |  |  | (61) |  |
| Reconciling items | (819) |  |  | (1,030) |  |  | (1,541) |  |  | (1,952) |  |
| Total | $ | 2,498 |  |  | $ | 1,895 |  |  | $ | 5,460 |  |  | $ | 4,266 |  |

[0000804328-24-000039:notes:45]
[same as prior period, unchanged from 0000804328-24-000017:notes:41]

[0000804328-24-000039:notes:46]
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | March 24,2024 |  | March 26,2023 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 42 |  |  | $ | 36 |  |  | $ | 82 |  |  | $ | 77 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated cost of revenues | $ | (57) |  |  | $ | (47) |  |  | $ | (113) |  |  | $ | (112) |  |
| Unallocated research and development expenses | (584) |  |  | (494) |  |  | (1,116) |  |  | (1,018) |  |
| Unallocated selling, general and administrative expenses | (229) |  |  | (126) |  |  | (414) |  |  | (292) |  |
| Unallocated other (expenses) income (Note 2) | — |  |  | (208) |  |  | 28 |  |  | (288) |  |
| Unallocated interest expense | (172) |  |  | (178) |  |  | (350) |  |  | (348) |  |
| Unallocated investment and other income, net | 228 |  |  | 36 |  |  | 434 |  |  | 123 |  |
| Nonreportable segments | (5) |  |  | (13) |  |  | (10) |  |  | (17) |  |
|  | $ | (819) |  |  | $ | (1,030) |  |  | $ | (1,541) |  |  | $ | (1,952) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000804328-24-000039:notes:47]
Fair Value Measurements and Marketable Securities
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at March 24, 2024 (in millions):

[0000804328-24-000039:notes:48]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 6,197 |  |  | $ | 1,813 |  |  | $ | — |  |  | $ | 8,010 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 3,844 |  |  | — |  |  | 3,844 |  |
| U.S. Treasury securities and government-related securities | 217 |  |  | 39 |  |  | — |  |  | 256 |  |
| Mortgage- and asset-backed securities | — |  |  | 402 |  |  | — |  |  | 402 |  |
| Equity securities | 130 |  |  | — |  |  | — |  |  | 130 |  |
| Total marketable securities | 347 |  |  | 4,285 |  |  | — |  |  | 4,632 |  |
| Derivative instruments | — |  |  | 27 |  |  | — |  |  | 27 |  |
| Other investments | 889 |  |  | — |  |  | 33 |  |  | 922 |  |
| Total assets measured at fair value | $ | 7,433 |  |  | $ | 6,125 |  |  | $ | 33 |  |  | $ | 13,591 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 243 |  |  | $ | — |  |  | $ | 243 |  |
| Other liabilities | 886 |  |  | — |  |  | — |  |  | 886 |  |
| Total liabilities measured at fair value | $ | 886 |  |  | $ | 243 |  |  | $ | — |  |  | $ | 1,129 |  |

[0000804328-24-000039:notes:49]
Long-term Debt. At March 24, 2024, the aggregate fair value of our outstanding fixed-rate notes, based on Level 2 inputs, was approximately $14.8 billion.

[0000804328-24-000039:notes:50]
Marketable Securities. At March 24, 2024 and September 24, 2023, our marketable securities were all classified as current and were primarily comprised of available-for-sale debt securities (substantially all of which were corporate bonds and notes).

[0000804328-24-000039:notes:51]
[same as prior period, unchanged from 0000804328-24-000017:notes:47]

[0000804328-24-000039:notes:52]
|  | March 24,2024 |
| Years to Maturity |  |
| Less than one year | $ | 1,728 |  |
| One to five years | 2,367 |  |
| Five to ten years | 5 |  |
| No single maturity date | 402 |  |
| Total | $ | 4,502 |  |

[0000804328-24-000039:notes:53]
[same as prior period, unchanged from 0000804328-24-000017:notes:49]


## ecd:MtrlTermsOfTrdArrTextBlock

[0000804328-24-000039:notes:54]
On February 7, 2024, Alex Rogers, our President, QTL and Global Affairs, adopted a Rule 10b5-1 trading arrangement (as defined in Item 408 of Regulation S-K) providing for the sale of an aggregate of (i) 13,373 shares of our common stock plus (ii) 90% of the net shares issued to Mr. Rogers upon the vesting of equity awards representing 83,280 shares of our common stock (assuming that any shares underlying performance stock units vest at target amounts), including accrued dividend-equivalent shares and excluding any shares withheld to satisfy tax withholding obligations in connection with the settlement of such equity awards. Trades under the plan are scheduled to commence in calendar 2025, and the plan is scheduled to terminate on December 31, 2026.
