# QCOM MD&A — 0000804328-24-000039


## mdna

[0000804328-24-000039:mdna:1]
[same as prior period, unchanged from 0000804328-24-000017:mdna:1]

[0000804328-24-000039:mdna:2]
[same as prior period, unchanged from 0000804328-24-000017:mdna:2]

[0000804328-24-000039:mdna:3]
This Quarterly Report (including but not limited to this section titled Management’s Discussion and Analysis of Financial Condition and Results of Operations) contains forward-looking statements. Words such as “expects,” “anticipates,” “intends,” “plans,” “believes,” “seeks,” “estimates,” “may,” “will,” “would” and similar expressions or variations of such words are intended to identify forward-looking statements, but are not the exclusive means of identifying forward-looking statements in this Quarterly Report. Additionally, statements concerning future matters such as our future business, prospects, results of operations or financial condition; research and development or technology investments; new or enhanced products, services or technologies; emerging industries or business models; design wins or product launches; industry, market or technology trends, dynamics or transitions; our expectations regarding future demand or supply conditions; strategic investments or acquisitions, and the anticipated timing or benefits thereof; legal or regulatory matters; U.S./China trade or national security tensions; vertical integration by our customers; competition; annual effective tax rates; and other statements regarding matters that are not historical are also forward-looking statements.

[0000804328-24-000039:mdna:4]
Second Quarter Fiscal 2024 Overview

[0000804328-24-000039:mdna:5]
Revenues for the second quarter of fiscal 2024 were $9.4 billion, an increase of 1% compared to the year ago quarter, with net income of $2.3 billion, an increase of 37% compared to the year ago quarter. Key items from the second quarter of fiscal 2024 included:

[0000804328-24-000039:mdna:6]
•QCT revenues increased by 1% in the second quarter of fiscal 2024 compared to the year ago quarter, due to higher automotive and handsets revenues, partially offset by lower IoT revenues.

[0000804328-24-000039:mdna:7]
•QTL revenues increased by 2% in the second quarter of fiscal 2024 compared to the year ago quarter, due to an increase in estimated sales of 3G/4G/5G-based multimode products.

[0000804328-24-000039:mdna:8]
•Investment and other income (expense), net increased $346 million compared to the year ago quarter, primarily due to higher net gains on QSI investments and higher interest and dividend income.

[0000804328-24-000039:mdna:9]
[same as prior period, unchanged from 0000804328-24-000017:mdna:8]

[0000804328-24-000039:mdna:10]
[same as prior period, unchanged from 0000804328-24-000017:mdna:9]

[0000804328-24-000039:mdna:11]
[same as prior period, unchanged from 0000804328-24-000017:mdna:10]

[0000804328-24-000039:mdna:12]
Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering and research and development functions are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated,

[0000804328-24-000039:mdna:13]
and QTI’s subsidiaries. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

[0000804328-24-000039:mdna:14]
[same as prior period, unchanged from 0000804328-24-000017:mdna:12]

[0000804328-24-000039:mdna:15]
[same as prior period, unchanged from 0000804328-24-000017:mdna:13]

[0000804328-24-000039:mdna:16]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | Change |  | March 24,2024 |  | March 26,2023 |  | Change |
| Equipment and services | $ | 7,950 |  |  | $ | 7,846 |  |  | $ | 104 |  |  | $ | 16,266 |  |  | $ | 15,630 |  |  | $ | 636 |  |
| Licensing | 1,439 |  |  | 1,429 |  |  | 10 |  |  | 3,059 |  |  | 3,108 |  |  | (49) |  |
|  | $ | 9,389 |  |  | $ | 9,275 |  |  | $ | 114 |  |  | $ | 19,325 |  |  | $ | 18,738 |  |  | $ | 587 |  |

[0000804328-24-000039:mdna:17]
Second quarter 2024 vs. 2023

[0000804328-24-000039:mdna:18]
The increase in revenues in the second quarter of fiscal 2024 was primarily due to $98 million in higher equipment and services revenues from our QCT segment.

[0000804328-24-000039:mdna:19]
First six months 2024 vs. 2023

[0000804328-24-000039:mdna:20]
The increase in revenues in the first six months of fiscal 2024 was primarily due to $624 million in higher equipment and services revenues from our QCT segment.

[0000804328-24-000039:mdna:21]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | Change |  | March 24,2024 |  | March 26,2023 |  | Change |
| Cost of revenues | $ | 4,106 |  |  | $ | 4,153 |  |  | $ | (47) |  |  | $ | 8,418 |  |  | $ | 8,197 |  |  | $ | 221 |  |
| Gross margin | 56 | % |  | 55 | % |  |  |  | 56 | % |  | 56 | % |  |  |

[0000804328-24-000039:mdna:22]
Second quarter 2024 vs. 2023

[0000804328-24-000039:mdna:23]
Gross margin percentage increased in the second quarter of fiscal 2024 primarily due to an increase in QCT gross margin.

[0000804328-24-000039:mdna:24]
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | Change |  | March 24,2024 |  | March 26,2023 |  | Change |
| Research and development | $ | 2,236 |  |  | $ | 2,210 |  |  | $ | 26 |  |  | $ | 4,332 |  |  | $ | 4,461 |  |  | $ | (129) |  |
| % of revenues | 24 | % |  | 24 | % |  |  |  | 22 | % |  | 24 | % |  |  |

[0000804328-24-000039:mdna:25]
Second quarter 2024 vs. 2023

[0000804328-24-000039:mdna:26]
The increase in research and development expenses in the second quarter of fiscal 2024 was primarily due to:

[0000804328-24-000039:mdna:27]
+    $42 million increase in share-based compensation expense

[0000804328-24-000039:mdna:28]
+    $23 million increase in expenses driven by revaluation of our deferred compensation obligation

[0000804328-24-000039:mdna:29]
-    $38 million decrease driven by lower costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies). This was primarily driven by a decrease in employee-related costs as a result of certain restructuring actions initiated in fiscal 2023 (which were substantially completed by the first quarter of fiscal 2024) to fund continued investments in key growth and diversification opportunities, partially offset by higher employee cash incentive program costs.

[0000804328-24-000039:mdna:30]
[same as prior period, unchanged from 0000804328-24-000017:mdna:25]

[0000804328-24-000039:mdna:31]
First six months 2024 vs. 2023

[0000804328-24-000039:mdna:32]
The decrease in research and development expenses in the first six months of fiscal 2024 was primarily due to:

[0000804328-24-000039:mdna:33]
-    $194 million decrease driven by lower costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies). This was primarily driven by a decrease in employee-related costs as a result of certain restructuring actions initiated in fiscal 2023 (which were substantially completed by the first quarter of fiscal 2024) to fund continued investments in key growth and diversification opportunities, partially offset by higher employee cash incentive program costs.

[0000804328-24-000039:mdna:34]
+    $48 million increase in expenses driven by revaluation of our deferred compensation obligation

[0000804328-24-000039:mdna:35]
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | Change |  | March 24,2024 |  | March 26,2023 |  | Change |
| Selling, general and administrative | $ | 707 |  |  | $ | 614 |  |  | $ | 93 |  |  | $ | 1,335 |  |  | $ | 1,238 |  |  | $ | 97 |  |
| % of revenues | 8 | % |  | 7 | % |  |  |  | 7 | % |  | 7 | % |  |  |

[0000804328-24-000039:mdna:36]
Second quarter 2024 vs. 2023

[0000804328-24-000039:mdna:37]
The increase in selling, general and administrative expenses in the second quarter of fiscal 2024 included:

[0000804328-24-000039:mdna:38]
+    $30 million increase in share-based compensation expense

[0000804328-24-000039:mdna:39]
+    $15 million increase in expenses driven by revaluation of our deferred compensation obligation

[0000804328-24-000039:mdna:40]
+    $15 million increase in sales and marketing expenses

[0000804328-24-000039:mdna:41]
First six months 2024 vs. 2023

[0000804328-24-000039:mdna:42]
The increase in selling, general and administrative expenses in the first six months of fiscal 2024 included:

[0000804328-24-000039:mdna:43]
+    $30 million increase in expenses driven by revaluation of our deferred compensation obligation

[0000804328-24-000039:mdna:44]
+    $21 million increase in share-based compensation expense

[0000804328-24-000039:mdna:45]
+    $21 million increase in litigation costs

[0000804328-24-000039:mdna:46]
-    $26 million decrease in employee-related expenses (which included higher employee cash incentive program costs)

[0000804328-24-000039:mdna:47]
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | Change |  | March 24,2024 |  | March 26,2023 |  | Change |
| Other expense (income) | $ | — |  |  | $ | 208 |  |  | $ | (208) |  |  | $ | (28) |  |  | $ | 288 |  |  | $ | (316) |  |

[0000804328-24-000039:mdna:48]
Second quarter and first six months 2024 vs. 2023

[0000804328-24-000039:mdna:49]
Other income and expenses in the second quarter of fiscal 2023 and the first six months of fiscal 2024 and 2023 included certain restructuring amounts (primarily related to accrued severance costs) from cost reduction actions initiated in fiscal 2023.

[0000804328-24-000039:mdna:50]
[same as prior period, unchanged from 0000804328-24-000017:mdna:34]

[0000804328-24-000039:mdna:51]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | Change |  | March 24,2024 |  | March 26,2023 |  | Change |
| Interest expense | $ | 172 |  |  | $ | 179 |  |  | $ | (7) |  |  | $ | 350 |  |  | $ | 348 |  |  | $ | 2 |  |
| Investment and other income (expense), net |
| Interest and dividend income | $ | 160 |  |  | $ | 59 |  |  | $ | 101 |  |  | $ | 312 |  |  | $ | 114 |  |  | $ | 198 |  |
| Net (losses) gains on marketable securities | (3) |  |  | 9 |  |  | (12) |  |  | 8 |  |  | 20 |  |  | (12) |  |
| Net gains on other investments | 155 |  |  | — |  |  | 155 |  |  | 159 |  |  | — |  |  | 159 |  |
| Net gains on deferred compensation plan assets | 62 |  |  | 21 |  |  | 41 |  |  | 126 |  |  | 47 |  |  | 79 |  |
| Impairment losses on other investments | (50) |  |  | (87) |  |  | 37 |  |  | (62) |  |  | (101) |  |  | 39 |  |
| Other | 6 |  |  | (18) |  |  | 24 |  |  | (1) |  |  | (20) |  |  | 19 |  |
|  | $ | 330 |  |  | $ | (16) |  |  | $ | 346 |  |  | $ | 542 |  |  | $ | 60 |  |  | $ | 482 |  |

[0000804328-24-000039:mdna:52]
The increase in interest and dividend income in the second quarter and first six months of fiscal 2024 was primarily due to higher interest rates earned on higher balances of interest-bearing securities.

[0000804328-24-000039:mdna:53]
Net gains on other investments in the second quarter and first six months of fiscal 2024 was primarily driven by certain of our QSI non-marketable equity investments.

[0000804328-24-000039:mdna:54]
[same as prior period, unchanged from 0000804328-24-000017:mdna:35]

[0000804328-24-000039:mdna:55]
[same as prior period, unchanged from 0000804328-24-000017:mdna:36]

[0000804328-24-000039:mdna:56]
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | March 24,2024 |  | March 26,2023 |
| Expected income tax provision at federal statutory tax rate | $ | 525 |  |  | $ | 398 |  |  | $ | 1,147 |  |  | $ | 896 |  |
| Benefit from foreign-derived intangible income (FDII) deduction related to capitalizing research and development expenditures | (133) |  |  | (140) |  |  | (323) |  |  | (252) |  |
| Benefit from FDII deduction, excluding the impact of capitalizing research and development expenditures | (145) |  |  | (88) |  |  | (309) |  |  | (209) |  |
| Benefit related to the research and development tax credit | (59) |  |  | (68) |  |  | (135) |  |  | (122) |  |
| Foreign currency loss (gain) related to foreign withholding tax receivable | 41 |  |  | 17 |  |  | 2 |  |  | (113) |  |
| Excess tax (benefit) deficiency associated with share-based awards | (23) |  |  | 2 |  |  | (51) |  |  | (21) |  |
| Other | 17 |  |  | 72 |  |  | 42 |  |  | 112 |  |
| Income tax expense | $ | 223 |  |  | $ | 193 |  |  | $ | 373 |  |  | $ | 291 |  |
| Effective tax rate | 9 | % |  | 10 | % |  | 7 | % |  | 7 | % |

[0000804328-24-000039:mdna:57]
We estimate our annual effective income tax rate to be 7% for fiscal 2024, which is lower than the U.S. federal statutory rate. Our estimated annual, second quarter and first six months of fiscal 2024 effective tax rates reflect the additional benefit from FDII deductions related to certain changes made in the second half of fiscal 2023 related to income attribution and sourcing of research and development expenditures. Additional information regarding our annual effective income tax rate and income tax expense is provided in this Quarterly Report in “Notes to Condensed Consolidated Statements, Note 3. Income Taxes.”

[0000804328-24-000039:mdna:58]
[same as prior period, unchanged from 0000804328-24-000017:mdna:41]

[0000804328-24-000039:mdna:59]
| Discontinued Operations (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | Change |  | March 24,2024 |  | March 26,2023 |  | Change |
| Discontinued operations, net of income taxes | $ | 51 |  |  | $ | 2 |  |  | $ | 49 |  |  | $ | 6 |  |  | $ | (36) |  |  | $ | 42 |  |

[0000804328-24-000039:mdna:60]
Discontinued operations in the second quarter and first six months of fiscal 2024 and 2023 related to the Non-Arriver businesses. Information regarding the Non-Arriver businesses is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Discontinued Operations.”

[0000804328-24-000039:mdna:61]
[same as prior period, unchanged from 0000804328-24-000017:mdna:42]

[0000804328-24-000039:mdna:62]
The following should be read in conjunction with our financial results for the second quarter of fiscal 2024 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Segment Information.”

[0000804328-24-000039:mdna:63]
[same as prior period, unchanged from 0000804328-24-000017:mdna:44]

[0000804328-24-000039:mdna:64]
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | Change |  | March 24,2024 |  | March 26,2023 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets | $ | 6,180 |  |  | $ | 6,105 |  |  | $ | 75 |  |  | $ | 12,867 |  |  | $ | 11,860 |  |  | $ | 1,007 |  |
| Automotive | 603 |  |  | 447 |  |  | 156 |  |  | 1,201 |  |  | 903 |  |  | 298 |  |
| IoT (internet of things) | 1,243 |  |  | 1,390 |  |  | (147) |  |  | 2,381 |  |  | 3,071 |  |  | (690) |  |
| Total revenues (1) | $ | 8,026 |  |  | $ | 7,942 |  |  | $ | 84 |  |  | $ | 16,449 |  |  | $ | 15,834 |  |  | $ | 615 |  |
| EBT (2) | $ | 2,288 |  |  | $ | 2,107 |  |  | $ | 181 |  |  | $ | 4,881 |  |  | $ | 4,291 |  |  | $ | 590 |  |
| EBT as a % of revenues | 29 | % |  | 27 | % |  | 2 points |  | 30 | % |  | 27 | % |  | 3 points |

[0000804328-24-000039:mdna:65]
[same as prior period, unchanged from 0000804328-24-000017:mdna:46]

[0000804328-24-000039:mdna:66]
(2) Earnings (loss) before income taxes.

[0000804328-24-000039:mdna:67]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $7.9 billion and $7.8 billion in the second quarter of fiscal 2024 and 2023, respectively, and $16.2 billion and $15.5 billion in the first six months of fiscal 2024 and 2023, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets as well as sales of 4G, 5G sub 6 and 5G millimeter wave RFFE products.

[0000804328-24-000039:mdna:68]
Second quarter 2024 vs. 2023

[0000804328-24-000039:mdna:69]
The increase in QCT revenues in the second quarter of fiscal 2024 was primarily due to:

[0000804328-24-000039:mdna:70]
+    higher automotive revenues, primarily driven by an increase in demand for digital cockpit and connectivity products

[0000804328-24-000039:mdna:71]
+    higher handsets revenues, due to $384 million in higher revenues per chipset driven by favorable mix, partially offset by $328 million in lower chipset shipments driven by certain major OEMs

[0000804328-24-000039:mdna:72]
-    lower IoT revenues, primarily driven by unfavorable mix

[0000804328-24-000039:mdna:73]
QCT EBT as a percentage of revenues increased in the second quarter of fiscal 2024 primarily due to:

[0000804328-24-000039:mdna:74]
[same as prior period, unchanged from 0000804328-24-000017:mdna:55]

[0000804328-24-000039:mdna:75]
+    higher gross margin percentage, primarily driven by lower net product reserve charges

[0000804328-24-000039:mdna:76]
First six months 2024 vs. 2023

[0000804328-24-000039:mdna:77]
The increase in QCT revenues in the first six months of fiscal 2024 was primarily due to:

[0000804328-24-000039:mdna:78]
+    higher handsets revenues, due to $549 million in higher revenues per chipset primarily driven by favorable mix and an increase in average selling prices, and $449 million in higher chipset shipments driven by certain major OEMs (primarily driven by the normalization of customer inventory levels, which were elevated in the prior year)

[0000804328-24-000039:mdna:79]
+    higher automotive revenues, primarily driven by an increase in demand for digital cockpit and connectivity products

[0000804328-24-000039:mdna:80]
-    lower IoT revenues, due to $411 million in lower revenues per unit primarily driven by unfavorable mix and $279 million decrease in demand (primarily in edge networking products)

[0000804328-24-000039:mdna:81]
22

[0000804328-24-000039:mdna:82]
QCT EBT as a percentage of revenues increased in the first six months of fiscal 2024 primarily due to:

[0000804328-24-000039:mdna:83]
+    lower research and development expenses

[0000804328-24-000039:mdna:84]
[same as prior period, unchanged from 0000804328-24-000017:mdna:56]

[0000804328-24-000039:mdna:85]
[same as prior period, unchanged from 0000804328-24-000017:mdna:58]

[0000804328-24-000039:mdna:86]
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | Change |  | March 24,2024 |  | March 26,2023 |  | Change |
| Licensing revenues | $ | 1,318 |  |  | $ | 1,290 |  |  | $ | 28 |  |  | $ | 2,778 |  |  | $ | 2,814 |  |  | $ | (36) |  |
| EBT | 933 |  |  | 871 |  |  | 62 |  |  | 2,013 |  |  | 1,988 |  |  | 25 |  |
| EBT as a % of revenues | 71 | % |  | 68 | % |  | 3 points |  | 72 | % |  | 71 | % |  | 1 point |

[0000804328-24-000039:mdna:87]
Second quarter 2024 vs. 2023

[0000804328-24-000039:mdna:88]
The increase in QTL licensing revenues in the second quarter of fiscal 2024 was primarily due to an increase in estimated sales of 3G/4G/5G-based multimode products.

[0000804328-24-000039:mdna:89]
QTL EBT as a percentage of revenues increased in the second quarter of fiscal 2024 primarily due to lower cost of sales driven by a decrease in amortization expense related to acquired patents.

[0000804328-24-000039:mdna:90]
First six months 2024 vs. 2023

[0000804328-24-000039:mdna:91]
The decrease in QTL licensing revenues in the first six months of fiscal 2024 was primarily due to:

[0000804328-24-000039:mdna:92]
-    $75 million decrease in estimated revenues per unit

[0000804328-24-000039:mdna:93]
-    $68 million decrease in revenues from the ending of the recognition of certain upfront license fee consideration in the first quarter of fiscal 2023 from our long-term license agreement with Nokia

[0000804328-24-000039:mdna:94]
+    $119 million increase in estimated sales of 3G/4G/5G-based multimode products

[0000804328-24-000039:mdna:95]
QTL EBT as a percentage of revenues increased in the first six months of fiscal 2024 primarily due to lower cost of sales driven by a decrease in amortization expense related to acquired patents.

[0000804328-24-000039:mdna:96]
[same as prior period, unchanged from 0000804328-24-000017:mdna:65]

[0000804328-24-000039:mdna:97]
|  | Three Months Ended |  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | Change |  | March 24,2024 |  | March 26,2023 |  | Change |
| Equipment and services revenues | $ | 3 |  |  | $ | 7 |  |  | $ | (4) |  |  | $ | 16 |  |  | $ | 13 |  |  | $ | 3 |  |
| EBT | 96 |  |  | (53) |  |  | 149 |  |  | 107 |  |  | (61) |  |  | 168 |  |

[0000804328-24-000039:mdna:98]
Second quarter and first six months 2024 vs. 2023

[0000804328-24-000039:mdna:99]
QSI EBT increased in the second quarter and first six months of fiscal 2024 primarily due to net gains on certain of our non-marketable equity investments.

[0000804328-24-000039:mdna:100]
[same as prior period, unchanged from 0000804328-24-000017:mdna:69]

[0000804328-24-000039:mdna:101]
[same as prior period, unchanged from 0000804328-24-000017:mdna:70]

[0000804328-24-000039:mdna:102]
[same as prior period, unchanged from 0000804328-24-000017:mdna:71]

[0000804328-24-000039:mdna:103]
•We expect certain IoT customers will continue to draw down on their inventory (which remains at elevated levels), which will continue to have a negative impact on our revenues, results of operations and cash flows.

[0000804328-24-000039:mdna:104]
[same as prior period, unchanged from 0000804328-24-000017:mdna:73]

[0000804328-24-000039:mdna:105]
[same as prior period, unchanged from 0000804328-24-000017:mdna:74]

[0000804328-24-000039:mdna:106]
[same as prior period, unchanged from 0000804328-24-000017:mdna:75]

[0000804328-24-000039:mdna:107]
[same as prior period, unchanged from 0000804328-24-000017:mdna:76]

[0000804328-24-000039:mdna:108]
We have recently extended, renewed or entered into license agreements with several key OEMs. We are currently pursuing negotiations with other key OEMs whose agreements expire in early fiscal 2025 (including Huawei). We also continue to engage in negotiations toward a comprehensive resolution with a growing, China-headquartered OEM that sells primarily in developing regions. See “Risk Factors” in this Quarterly Report, including the Risk Factor titled “The continued and future success of our licensing programs requires us to continue to evolve our patent portfolio and to renew or renegotiate license agreements that are expiring.”

[0000804328-24-000039:mdna:109]
[same as prior period, unchanged from 0000804328-24-000017:mdna:78]

[0000804328-24-000039:mdna:110]
[same as prior period, unchanged from 0000804328-24-000017:mdna:79]

[0000804328-24-000039:mdna:111]
[same as prior period, unchanged from 0000804328-24-000017:mdna:80]

[0000804328-24-000039:mdna:112]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at March 24, 2024 and September 24, 2023 and for the first six months of fiscal 2024 and 2023 (in millions):

[0000804328-24-000039:mdna:113]
|  | March 24,2024 |  | September 24,2023 |  | Change |  |  |
| Cash, cash equivalents and marketable securities |  |  |  |  |  |  |  |
| Cash and cash equivalents (1) | $ | 9,219 |  |  | $ | 8,450 |  |  | $ | 769 |  |  |  |
| Marketable securities | 4,632 |  |  | 2,874 |  |  | 1,758 |  |  |  |
|  | $ | 13,851 |  |  | $ | 11,324 |  |  | $ | 2,527 |  |  |  |
| Debt (2) | $ | 15,457 |  |  | $ | 15,398 |  |  | $ | 59 |  |  |  |

[0000804328-24-000039:mdna:114]
(1) Excludes $77 million of cash and cash equivalents classified as held for sale at September 24, 2023.

[0000804328-24-000039:mdna:115]
(2) Includes our issued debt reported as long-term and $914 million reported as short-term debt (which matures in May 2024). As of March 24, 2024 and September 24, 2023, our credit facility was undrawn, and we had no commercial paper outstanding.

[0000804328-24-000039:mdna:116]
|  | Six Months Ended |
|  | March 24,2024 |  | March 26,2023 |  | Change |  |  |
| Net cash provided by operating activities | $ | 6,503 |  |  | $ | 4,552 |  |  | $ | 1,951 |  |  |  |
| Net cash used by investing activities | (2,195) |  |  | (357) |  |  | (1,838) |  |  |  |
| Net cash used by financing activities | (3,621) |  |  | (3,558) |  |  | (63) |  |  |  |

[0000804328-24-000039:mdna:117]
Cash, cash equivalents and marketable securities. The net increase in cash, cash equivalents and marketable securities for the first six months of fiscal 2024 was primarily due to net cash provided by operating activities, partially offset by $1.8 billion in cash dividends paid, $1.5 billion in payments to repurchase 11 million shares of our common stock, $515 million in payments of tax withholdings related to the vesting of share-based awards and $398 million in capital expenditures.

[0000804328-24-000039:mdna:118]
During the first six months of fiscal 2024, income taxes paid were in excess of our provision, negatively impacting net cash provided by operating activities. This was driven primarily by our payment of $1.0 billion related to certain previously postponed U.S. federal income tax-payments from fiscal 2023, the adverse impact of the requirement to capitalize and amortize research and development expenditures for federal income tax purposes and an installment payment for a one-time U.S. repatriation tax accrued in fiscal 2018 of $414 million.

[0000804328-24-000039:mdna:119]
[same as prior period, unchanged from 0000804328-24-000017:mdna:89]

[0000804328-24-000039:mdna:120]
Net changes in our operating assets and liabilities for the first six months of fiscal 2024 positively impacted our operating cash flows primarily from an increase in accrued customer incentives, which included the impact of timing of related payments, a decrease in inventory as we sold a portion of our elevated inventory and an increase in accounts payable due to timing and amount of inventory purchases. This was partially offset by approximately $360 million in severance payments related to restructuring actions initiated in fiscal 2023.

[0000804328-24-000039:mdna:121]
Capital Return Program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time.

[0000804328-24-000039:mdna:122]
On March 5, 2024, we announced an increase in our quarterly dividend per share of common stock from $0.80 to $0.85, which is effective for dividends payable after March 21, 2024. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors. Additional information regarding our capital returns is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 4. Capital Stock.”

[0000804328-24-000039:mdna:123]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2023 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At March 24, 2024, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements”, “Looking Forward” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2023 Annual Report on Form 10-K.

[0000804328-24-000039:mdna:124]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Risk Factors” in this Quarterly Report.

[0000804328-24-000039:mdna:125]
[same as prior period, unchanged from 0000804328-24-000017:mdna:92]

[0000804328-24-000039:mdna:126]
[same as prior period, unchanged from 0000804328-24-000017:mdna:93]

[0000804328-24-000039:mdna:127]
[same as prior period, unchanged from 0000804328-24-000017:mdna:94]

[0000804328-24-000039:mdna:128]
[same as prior period, unchanged from 0000804328-24-000017:mdna:95]

[0000804328-24-000039:mdna:129]
[same as prior period, unchanged from 0000804328-24-000017:mdna:96]

[0000804328-24-000039:mdna:130]
[same as prior period, unchanged from 0000804328-24-000017:mdna:97]

[0000804328-24-000039:mdna:131]
[same as prior period, unchanged from 0000804328-24-000017:mdna:98]

[0000804328-24-000039:mdna:132]
We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier handset devices, and we expect this trend to continue in the foreseeable future. The mobile industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. Certain Chinese original equipment manufacturers (OEMs) have increased and may

[0000804328-24-000039:mdna:133]
[same as prior period, unchanged from 0000804328-24-000017:mdna:102]

[0000804328-24-000039:mdna:134]
continue to increase their device share in China and in certain regions outside of China, and we derive a significant portion of our revenues from a small number of these OEMs as well. See also “Notes to Condensed Consolidated Financial Statements, Note 2. Composition of Certain Financial Statement Items - Concentrations.”

[0000804328-24-000039:mdna:135]
[same as prior period, unchanged from 0000804328-24-000017:mdna:100]

[0000804328-24-000039:mdna:136]
Further, political actions, including trade and/or national security protection policies, or other actions by governments, particularly the U.S. and Chinese governments, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our customers, limit, prevent or discourage those customers from transacting business with us, or make it more expensive to do so, any of which could also significantly reduce the revenues we derive from these customers. See also the Risk Factor titled “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions.”

[0000804328-24-000039:mdna:137]
[same as prior period, unchanged from 0000804328-24-000017:mdna:104]

[0000804328-24-000039:mdna:138]
[same as prior period, unchanged from 0000804328-24-000017:mdna:105]

[0000804328-24-000039:mdna:139]
[same as prior period, unchanged from 0000804328-24-000017:mdna:106]

[0000804328-24-000039:mdna:140]
[same as prior period, unchanged from 0000804328-24-000017:mdna:107]

[0000804328-24-000039:mdna:141]
[same as prior period, unchanged from 0000804328-24-000017:mdna:108]

[0000804328-24-000039:mdna:142]
[same as prior period, unchanged from 0000804328-24-000017:mdna:109]

[0000804328-24-000039:mdna:143]
Although we have more than 300 licensees, we derive a significant portion of our licensing revenues from a limited number of licensees, which includes a number of Chinese OEMs. In the event that one or more of our significant licensees fail to meet their reporting and payment obligations, or we are unable to renew or modify one or more of their license agreements under similar terms as their existing agreements, our revenues, results of operations and cash flows would be

[0000804328-24-000039:mdna:144]
[same as prior period, unchanged from 0000804328-24-000017:mdna:113]

[0000804328-24-000039:mdna:145]
adversely impacted. Moreover, the success of our core licensing business depends in part on the ability of our licensees to continue to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We do not have control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful in these efforts. Reductions in sales of our licensees’ products, or reductions in the average selling prices of such products without a sufficient increase in the volumes sold, would generally have an adverse effect on our licensing revenues.

[0000804328-24-000039:mdna:146]
[same as prior period, unchanged from 0000804328-24-000017:mdna:111]

[0000804328-24-000039:mdna:147]
[same as prior period, unchanged from 0000804328-24-000017:mdna:112]

[0000804328-24-000039:mdna:148]
[same as prior period, unchanged from 0000804328-24-000017:mdna:114]

[0000804328-24-000039:mdna:149]
[same as prior period, unchanged from 0000804328-24-000017:mdna:115]

[0000804328-24-000039:mdna:150]
[same as prior period, unchanged from 0000804328-24-000017:mdna:116]

[0000804328-24-000039:mdna:151]
[same as prior period, unchanged from 0000804328-24-000017:mdna:117]

[0000804328-24-000039:mdna:152]
[same as prior period, unchanged from 0000804328-24-000017:mdna:118]

[0000804328-24-000039:mdna:153]
[same as prior period, unchanged from 0000804328-24-000017:mdna:119]

[0000804328-24-000039:mdna:154]
[same as prior period, unchanged from 0000804328-24-000017:mdna:120]

[0000804328-24-000039:mdna:155]
Political actions, including trade protection and national security policies of the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our Chinese customers or suppliers, limit, prevent or discourage certain of our Chinese customers or suppliers from transacting business with us, or make it more expensive to do so. Given our revenue concentration in China, if, due to actual, threatened or potential U.S. or Chinese government actions or policies: we were further limited in, or prohibited from, selling our integrated circuit products to Chinese customers; our non-Chinese OEM customers were limited in, or prohibited from, selling devices that incorporate our integrated circuit products into

[0000804328-24-000039:mdna:156]
27

[0000804328-24-000039:mdna:157]
China; Chinese OEMs develop and use their own integrated circuit products or use our competitors’ integrated circuit products in some or all of their devices rather than our integrated circuit products; Chinese tariffs on our integrated circuit products or on devices which incorporate our integrated circuit products made purchasing such products or devices more expensive to our Chinese customers or Chinese consumers; or our Chinese licensees delay or cease making payments of license fees they owe us, our business, revenues, results of operations, cash flows and financial position could be materially harmed. Similarly, if, due to U.S. or Chinese government actions or policies, we were limited in or prohibited from obtaining critical integrated circuit products from our suppliers in China, our business, revenues, results of operations, cash flows and financial position could be materially harmed. See also the Risk Factors titled “We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier handset devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected” and “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0000804328-24-000039:mdna:158]
For example, we currently have export licenses from the U.S. Department of Commerce that allow us to sell 4G and other integrated circuit products, including Wi-Fi products, but excluding 5G products, to Huawei. Recent news reports have indicated that the Department of Commerce is considering not granting any new licenses for sales to Huawei. Further, Huawei recently launched new 5G-capable devices using its own integrated circuit products. While we have continued to sell integrated circuit products to Huawei under our licenses, we do not expect to receive product revenues from Huawei beyond the current calendar year. Additionally, to the extent that Huawei’s 5G devices take share from Chinese OEMs that utilize our 5G products or from non-Chinese OEMs that utilize our 5G products in devices they sell into China, our revenues, results of operations and cash flows could be further impacted.

[0000804328-24-000039:mdna:159]
[same as prior period, unchanged from 0000804328-24-000017:mdna:123]

[0000804328-24-000039:mdna:160]
[same as prior period, unchanged from 0000804328-24-000017:mdna:124]

[0000804328-24-000039:mdna:161]
[same as prior period, unchanged from 0000804328-24-000017:mdna:125]

[0000804328-24-000039:mdna:162]
[same as prior period, unchanged from 0000804328-24-000017:mdna:126]

[0000804328-24-000039:mdna:163]
[same as prior period, unchanged from 0000804328-24-000017:mdna:127]

[0000804328-24-000039:mdna:164]
[same as prior period, unchanged from 0000804328-24-000017:mdna:128]

[0000804328-24-000039:mdna:165]
[same as prior period, unchanged from 0000804328-24-000017:mdna:131]

[0000804328-24-000039:mdna:166]
[same as prior period, unchanged from 0000804328-24-000017:mdna:129]

[0000804328-24-000039:mdna:167]
[same as prior period, unchanged from 0000804328-24-000017:mdna:130]

[0000804328-24-000039:mdna:168]
[same as prior period, unchanged from 0000804328-24-000017:mdna:132]

[0000804328-24-000039:mdna:169]
[same as prior period, unchanged from 0000804328-24-000017:mdna:133]

[0000804328-24-000039:mdna:170]
[same as prior period, unchanged from 0000804328-24-000017:mdna:134]

[0000804328-24-000039:mdna:171]
[same as prior period, unchanged from 0000804328-24-000017:mdna:135]

[0000804328-24-000039:mdna:172]
Achieving the anticipated benefits of business acquisitions depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from acquired technologies or products or from future technologies or products based on these technologies, and we may become subject to liabilities, including liabilities arising as a result of litigation, that are not covered by any indemnification protection that we may obtain. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models, geographic regions, industries and applications served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0000804328-24-000039:mdna:173]
29

[0000804328-24-000039:mdna:174]
[same as prior period, unchanged from 0000804328-24-000017:mdna:137]

[0000804328-24-000039:mdna:175]
[same as prior period, unchanged from 0000804328-24-000017:mdna:138]

[0000804328-24-000039:mdna:176]
[same as prior period, unchanged from 0000804328-24-000017:mdna:139]

[0000804328-24-000039:mdna:177]
[same as prior period, unchanged from 0000804328-24-000017:mdna:140]

[0000804328-24-000039:mdna:178]
[same as prior period, unchanged from 0000804328-24-000017:mdna:141]

[0000804328-24-000039:mdna:179]
[same as prior period, unchanged from 0000804328-24-000017:mdna:142]

[0000804328-24-000039:mdna:180]
[same as prior period, unchanged from 0000804328-24-000017:mdna:143]

[0000804328-24-000039:mdna:181]
[same as prior period, unchanged from 0000804328-24-000017:mdna:144]

[0000804328-24-000039:mdna:182]
[same as prior period, unchanged from 0000804328-24-000017:mdna:145]

[0000804328-24-000039:mdna:183]
[same as prior period, unchanged from 0000804328-24-000017:mdna:146]

[0000804328-24-000039:mdna:184]
[same as prior period, unchanged from 0000804328-24-000017:mdna:147]

[0000804328-24-000039:mdna:185]
[same as prior period, unchanged from 0000804328-24-000017:mdna:148]

[0000804328-24-000039:mdna:186]
[same as prior period, unchanged from 0000804328-24-000017:mdna:149]

[0000804328-24-000039:mdna:187]
[same as prior period, unchanged from 0000804328-24-000017:mdna:150]

[0000804328-24-000039:mdna:188]
[same as prior period, unchanged from 0000804328-24-000017:mdna:151]

[0000804328-24-000039:mdna:189]
30

[0000804328-24-000039:mdna:190]
[same as prior period, unchanged from 0000804328-24-000017:mdna:152]

[0000804328-24-000039:mdna:191]
[same as prior period, unchanged from 0000804328-24-000017:mdna:153]

[0000804328-24-000039:mdna:192]
[same as prior period, unchanged from 0000804328-24-000017:mdna:154]

[0000804328-24-000039:mdna:193]
We rely on sole- or limited-source suppliers for certain products, which may exacerbate the risks identified above, and subject us to other significant risks, including poor product performance and reduced control over delivery schedules, manufacturing capability and yields, quality assurance, quantity and costs. While we have established and may in the future establish alternate suppliers for certain products, these suppliers may require significant amounts of time and levels of support to bring such products to production, both of which may increase for complex or leading process technologies. As a result, we may invest a significant amount of effort and resources and incur higher costs to support and maintain such alternate suppliers. Further, the elimination or limitation of a foundry supplier’s ability to manufacture components or products for us due to trade or national security protection policies could increase our vulnerability to sole- or limited-source arrangements and limit or prevent us from procuring critical components or products from those suppliers. Future consolidation of foundry suppliers could also increase our vulnerability to sole- or limited-source arrangements and reduce our suppliers’ willingness to negotiate pricing, which could negatively impact our ability to achieve cost reductions, increase our manufacturing costs and limit the amount of capacity available to us. Our arrangements with our suppliers may obligate us to incur costs to manufacture, assemble and test our products that do not decrease at the same rate as decreases in pricing to our customers. Our ability, and that of our suppliers, to develop or maintain leading process technologies, including transitions to smaller geometry process technologies (which adds risk to manufacturing yields and reliability), and to effectively compete with the manufacturing processes and performance of our competitors, could impact our ability to introduce new products and meet customer demand, could increase our costs (possibly decreasing our margins) and could subject us to the risk of excess inventories. Any of the above could negatively impact our business, results of operations and cash flows.

[0000804328-24-000039:mdna:194]
[same as prior period, unchanged from 0000804328-24-000017:mdna:157]

[0000804328-24-000039:mdna:195]
[same as prior period, unchanged from 0000804328-24-000017:mdna:158]

[0000804328-24-000039:mdna:196]
[same as prior period, unchanged from 0000804328-24-000017:mdna:162]

[0000804328-24-000039:mdna:197]
[same as prior period, unchanged from 0000804328-24-000017:mdna:159]

[0000804328-24-000039:mdna:198]
[same as prior period, unchanged from 0000804328-24-000017:mdna:160]

[0000804328-24-000039:mdna:199]
See also the Risk Factor below titled “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises, geopolitical conflicts and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues” as similar risks, as well as additional risks, may be applicable to our third-party suppliers’ manufacturing facilities, which could result in disruptions to our business or additional costs to us, and negatively impact our results of operations.

[0000804328-24-000039:mdna:200]
[same as prior period, unchanged from 0000804328-24-000017:mdna:164]

[0000804328-24-000039:mdna:201]
[same as prior period, unchanged from 0000804328-24-000017:mdna:165]

[0000804328-24-000039:mdna:202]
[same as prior period, unchanged from 0000804328-24-000017:mdna:166]

[0000804328-24-000039:mdna:203]
Climate change concerns and the potential resulting environmental impact may result in new environmental, health and safety laws and regulations that may affect us, our suppliers and our customers. Such laws or regulations could cause us to incur additional direct costs for compliance, including costs associated with changes to manufacturing processes or the procurement of raw materials used in manufacturing processes, as well as increased indirect costs resulting from our customers, suppliers or both incurring additional compliance costs that are passed on to us. These costs may adversely impact our results of operations and financial condition. In addition, climate change could cause certain natural disasters, such as

[0000804328-24-000039:mdna:204]
drought, wildfires, storms, flooding or rising sea levels, to occur more frequently or with greater intensity, which could pose physical risks to our manufacturing facilities or our suppliers’ facilities, could disrupt the availability of water necessary for the operation of such facilities, and could increase or decrease temperatures resulting in increased operating costs and/or business disruption.

[0000804328-24-000039:mdna:205]
[same as prior period, unchanged from 0000804328-24-000017:mdna:168]

[0000804328-24-000039:mdna:206]
[same as prior period, unchanged from 0000804328-24-000017:mdna:169]

[0000804328-24-000039:mdna:207]
[same as prior period, unchanged from 0000804328-24-000017:mdna:170]

[0000804328-24-000039:mdna:208]
[same as prior period, unchanged from 0000804328-24-000017:mdna:171]

[0000804328-24-000039:mdna:209]
[same as prior period, unchanged from 0000804328-24-000017:mdna:172]

[0000804328-24-000039:mdna:210]
[same as prior period, unchanged from 0000804328-24-000017:mdna:173]

[0000804328-24-000039:mdna:211]
Third parties regularly attempt to gain unauthorized access to our IT systems, and many such attacks are increasingly more sophisticated. These attacks, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, exploiting vulnerabilities in hardware, software or other IT infrastructure and impersonating authorized users, among others. We are also subject to ransom-style cyber-attacks, which could expose our confidential or proprietary information, demand payment of money and/or impact our IT systems and cause widespread disruption to our business, including our manufacturing operations. Third parties that store and/or process our confidential information, or that provide products, software or services used in our IT infrastructure, may be subject to similar attacks, which could also result in malware being introduced into our IT infrastructure, e.g., through the third parties’ software and/or software updates. Such attacks could result in the misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our IT systems. We believe that we have a robust cybersecurity program that is aligned to international cybersecurity frameworks, and that we leverage industry best practices across people, processes and technologies in an attempt to mitigate cybersecurity threats. However, we cannot anticipate, detect, repel or implement fully effective preventative measures against all cybersecurity threats, particularly because the techniques used are increasingly sophisticated and constantly evolving. For example, as AI continues to evolve, cyber-attackers could also use AI to develop malicious code and sophisticated phishing attempts. As part of our cybersecurity program, we seek to identify and remediate vulnerabilities in our IT systems and software (including third party software used in our IT systems) that could be exploited by hackers or other malicious actors. However, we may not be aware of all such vulnerabilities, and we may fail to identify and/or remediate such vulnerabilities before they are exploited. Attempts to gain unauthorized access to our IT systems or other attacks have in the past, in certain instances and to certain degrees, been successful (but have not caused significant harm), and may in the future be successful, and in some cases, we might be unaware of an incident or its magnitude and effects.

[0000804328-24-000039:mdna:212]
[same as prior period, unchanged from 0000804328-24-000017:mdna:177]

[0000804328-24-000039:mdna:213]
[same as prior period, unchanged from 0000804328-24-000017:mdna:178]

[0000804328-24-000039:mdna:214]
[same as prior period, unchanged from 0000804328-24-000017:mdna:179]

[0000804328-24-000039:mdna:215]
34

[0000804328-24-000039:mdna:216]
[same as prior period, unchanged from 0000804328-24-000017:mdna:180]

[0000804328-24-000039:mdna:217]
[same as prior period, unchanged from 0000804328-24-000017:mdna:181]

[0000804328-24-000039:mdna:218]
[same as prior period, unchanged from 0000804328-24-000017:mdna:182]

[0000804328-24-000039:mdna:219]
The COVID-19 pandemic caused us to modify our workforce practices, including having the vast majority of our employees work from home. Upon the reopening of our offices, we initially operated under a hybrid work model, meaning that the majority of our employees had the flexibility to work remotely at least some of the time. In fiscal 2023, we implemented changes to our hybrid work model that require the majority of our employees to spend the majority of their working time in the office. This requirement for greater in-office attendance may not meet the needs or expectations of our employees and could negatively impact our ability to attract and retain employees, particularly if it is perceived as less favorable compared to other companies’ remote work policies.

[0000804328-24-000039:mdna:220]
[same as prior period, unchanged from 0000804328-24-000017:mdna:185]

[0000804328-24-000039:mdna:221]
[same as prior period, unchanged from 0000804328-24-000017:mdna:186]

[0000804328-24-000039:mdna:222]
[same as prior period, unchanged from 0000804328-24-000017:mdna:187]

[0000804328-24-000039:mdna:223]
[same as prior period, unchanged from 0000804328-24-000017:mdna:188]

[0000804328-24-000039:mdna:224]
Our patent license agreements in effect that generate a significant portion of our licensing revenues are effective for a specified term. To receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms, and may impact the financial or other terms of license agreements not subject to the litigation or arbitration. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such licensees. Finally, certain of our license agreements contain binding renewal provisions which provide that if the parties are unable to agree upon the terms and conditions of a new license agreement by a specified date, either party may initiate binding arbitration proceedings to establish such terms and conditions. Such new license agreement would become effective immediately after the expiration of the prior agreement. Nonetheless, in either event, we may not be able to recognize some or any revenues related to that licensee’s product sales until such new license agreement is finalized.

[0000804328-24-000039:mdna:225]
[same as prior period, unchanged from 0000804328-24-000017:mdna:190]

[0000804328-24-000039:mdna:226]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging

[0000804328-24-000039:mdna:227]
infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, alleging that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) attempts by licensees to shift their royalty obligation to their suppliers in order to make royalty collection more difficult or reduce the amount of royalties collected.

[0000804328-24-000039:mdna:228]
In addition, certain licensees have disputed, underreported, underpaid, not reported or not paid royalties owed to us under their license agreements or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or have delayed entering into or renewing license agreements with us for their use of our intellectual property, and they or others may engage in such behavior in the future. The fact that one or more licensees dispute, underreport, underpay, do not report or do not pay royalties owed to us may encourage other licensees to take similar actions or not renew their existing license agreements, and may encourage other licensees or unlicensed companies to delay entering into, or to not enter into, new license agreements. Further, to the extent such licensees and companies increase their device share, the negative impact of their underreporting, underpayment, non-payment or non-reporting on our business, revenues, results of operations, cash flows and financial condition will be exacerbated.

[0000804328-24-000039:mdna:229]
We have been in the past and are currently subject to various litigation and/or governmental investigations and proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. See also the Risk Factors below titled “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.”

[0000804328-24-000039:mdna:230]
[same as prior period, unchanged from 0000804328-24-000017:mdna:195]

[0000804328-24-000039:mdna:231]
[same as prior period, unchanged from 0000804328-24-000017:mdna:196]

[0000804328-24-000039:mdna:232]
Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party. Further, SDOs in certain countries may attempt to modify widely accepted standards and claim the resulting standard as their own. In addition, governments may enact policies concerning standard-essential patents, such as the European Commission’s recently proposed regulations which would create a new regulatory scheme for standard-essential patents, that may have various consequences, some of which may be detrimental, such as by devaluing standard-essential patents or disrupting

[0000804328-24-000039:mdna:233]
36

[0000804328-24-000039:mdna:234]
worldwide technology standards. Other jurisdictions may adopt similar regulatory schemes, which could also have such effects.

[0000804328-24-000039:mdna:235]
[same as prior period, unchanged from 0000804328-24-000017:mdna:198]

[0000804328-24-000039:mdna:236]
[same as prior period, unchanged from 0000804328-24-000017:mdna:199]

[0000804328-24-000039:mdna:237]
As described in the Risk Factor below titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings,” we have been in the past, currently are and may in the future be subject to various governmental investigations and/or legal proceedings challenging our patent licensing practices. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We believe that one intent of certain of these governmental investigations and legal proceedings has been to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0000804328-24-000039:mdna:238]
[same as prior period, unchanged from 0000804328-24-000017:mdna:202]

[0000804328-24-000039:mdna:239]
[same as prior period, unchanged from 0000804328-24-000017:mdna:203]

[0000804328-24-000039:mdna:240]
[same as prior period, unchanged from 0000804328-24-000017:mdna:204]

[0000804328-24-000039:mdna:241]
[same as prior period, unchanged from 0000804328-24-000017:mdna:205]

[0000804328-24-000039:mdna:242]
37

[0000804328-24-000039:mdna:243]
[same as prior period, unchanged from 0000804328-24-000017:mdna:206]

[0000804328-24-000039:mdna:244]
Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.

[0000804328-24-000039:mdna:245]
We have been in the past and currently are subject to various governmental investigations and/or legal proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” Key allegations or findings in those matters include or have in the past included, among others: that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers; that our royalty rates are too high; that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions); that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets; that we have entered into exclusive agreements with chipset customers that foreclose competition; that we leverage our position in baseband chipsets in the RFFE space; and that we violate antitrust laws and engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0000804328-24-000039:mdna:246]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others: the loss of our ability to enforce one or more of our patents; injunctions; monetary damages, fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers or other component suppliers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any revenues under such agreements. The renegotiation of license agreements could result in terms that are less favorable to us than existing terms, or lead to arbitration or litigation to resolve the licensing terms, which could also be less favorable to us than existing terms, and each of which could take months or years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. The occurrence of any of the above could have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies. Further, depending on the breadth and severity of the circumstances above, we may have to reduce, suspend or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted.

[0000804328-24-000039:mdna:247]
[same as prior period, unchanged from 0000804328-24-000017:mdna:211]

[0000804328-24-000039:mdna:248]
[same as prior period, unchanged from 0000804328-24-000017:mdna:212]

[0000804328-24-000039:mdna:249]
[same as prior period, unchanged from 0000804328-24-000017:mdna:213]

[0000804328-24-000039:mdna:250]
[same as prior period, unchanged from 0000804328-24-000017:mdna:214]

[0000804328-24-000039:mdna:251]
[same as prior period, unchanged from 0000804328-24-000017:mdna:215]

[0000804328-24-000039:mdna:252]
[same as prior period, unchanged from 0000804328-24-000017:mdna:216]

[0000804328-24-000039:mdna:253]
[same as prior period, unchanged from 0000804328-24-000017:mdna:217]

[0000804328-24-000039:mdna:254]
[same as prior period, unchanged from 0000804328-24-000017:mdna:218]

[0000804328-24-000039:mdna:255]
[same as prior period, unchanged from 0000804328-24-000017:mdna:219]

[0000804328-24-000039:mdna:256]
[same as prior period, unchanged from 0000804328-24-000017:mdna:220]

[0000804328-24-000039:mdna:257]
[same as prior period, unchanged from 0000804328-24-000017:mdna:221]

[0000804328-24-000039:mdna:258]
[same as prior period, unchanged from 0000804328-24-000017:mdna:222]

[0000804328-24-000039:mdna:259]
[same as prior period, unchanged from 0000804328-24-000017:mdna:223]

[0000804328-24-000039:mdna:260]
[same as prior period, unchanged from 0000804328-24-000017:mdna:224]

[0000804328-24-000039:mdna:261]
[same as prior period, unchanged from 0000804328-24-000017:mdna:225]

[0000804328-24-000039:mdna:262]
[same as prior period, unchanged from 0000804328-24-000017:mdna:226]

[0000804328-24-000039:mdna:263]
[same as prior period, unchanged from 0000804328-24-000017:mdna:227]

[0000804328-24-000039:mdna:264]
39

[0000804328-24-000039:mdna:265]
[same as prior period, unchanged from 0000804328-24-000017:mdna:228]

[0000804328-24-000039:mdna:266]
[same as prior period, unchanged from 0000804328-24-000017:mdna:229]

[0000804328-24-000039:mdna:267]
[same as prior period, unchanged from 0000804328-24-000017:mdna:230]

[0000804328-24-000039:mdna:268]
[same as prior period, unchanged from 0000804328-24-000017:mdna:231]

[0000804328-24-000039:mdna:269]
We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application, industry or standard product, including those that produce products for mobile handsets, automotive or IoT, among others. Most of these competitors compete with us with respect to some, but not all, of our businesses or product lines. Companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Apple, Broadcom, HiSilicon, MediaTek, Mobileye, Nvidia, NXP Semiconductors, Qorvo, Samsung, Skyworks, Texas Instruments and UNISOC. Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to use our competitors’ integrated circuit products, to utilize their own internally-developed integrated circuit products and/or sell such products to others, or to utilize alternative technologies; lower cost structures or a willingness and ability to accept lower prices or lower margins for their products, particularly in China; foreign government support of other technologies, competitors or OEMs that sell devices that do not contain our integrated circuit products; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; the development and sale of infrastructure equipment for wireless networks, which may enable such competitors to better optimize their integrated circuit products for performance on those networks; more extensive relationships with local distribution companies and OEMs in certain geographic regions (such as China); more experience in industries and applications beyond mobile handsets (such as automotive and IoT); and a more established presence in certain regions.

[0000804328-24-000039:mdna:270]
[same as prior period, unchanged from 0000804328-24-000017:mdna:234]

[0000804328-24-000039:mdna:271]
[same as prior period, unchanged from 0000804328-24-000017:mdna:235]

[0000804328-24-000039:mdna:272]
[same as prior period, unchanged from 0000804328-24-000017:mdna:236]

[0000804328-24-000039:mdna:273]
[same as prior period, unchanged from 0000804328-24-000017:mdna:237]

[0000804328-24-000039:mdna:274]
[same as prior period, unchanged from 0000804328-24-000017:mdna:238]

[0000804328-24-000039:mdna:275]
Our products are complex and may contain defects, errors or security vulnerabilities, or experience failures or unsatisfactory performance, due to any number of issues, including issues in materials, design, fabrication, packaging and/or use within a system. Development of products in new domains of technology, and the migration to integrated circuit technologies with smaller geometric feature sizes, increases complexity and adds risk to manufacturing yields and reliability, and increases the likelihood of product defects, errors or security vulnerabilities. Defects, errors, security vulnerabilities or other unintended functionality could also be introduced into our products by cyber-attacks or other actions by malicious actors, either directly or through third-party products or software used in our products or IT infrastructure. Further, because of the complexity of our products, defects, errors or security vulnerabilities might only be detected when the products are in use. Risks associated with product or technology defects, errors or security vulnerabilities are exacerbated by the fact that our customers typically integrate our products into consumer and other devices. We routinely monitor for and assess security vulnerabilities in our products and offer remediation measures if appropriate. However, we may not be aware of all such vulnerabilities, and we may fail to identify and/or provide remediation measures for vulnerabilities (or our customers may fail to implement remediation measures) before they are exploited.

[0000804328-24-000039:mdna:276]
Our products may be used in devices that interact with untrusted systems or otherwise access untrusted content, which creates a risk of exposing the system hardware and software in those devices to malicious attacks. Further, security vulnerabilities in our products or the technologies we use could expose our customers, or end users of our customers’ products, to hackers or other unscrupulous third parties who develop and deploy malware that could attack our products or our customers’ products or IT infrastructure. Such attacks could result in the disruption of our customers’ businesses or the misappropriation, theft, misuse, disclosure, loss or destruction of the technology or intellectual property, or the proprietary, confidential or personal information, of our customers, their employees or the end users of our customers’ devices. While we continue to focus on this issue and take measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and applications, and increasing the risk of security failures, and techniques used to perpetrate cybersecurity attacks are increasingly sophisticated and constantly evolving. See also the Risk Factor titled “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0000804328-24-000039:mdna:277]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, meet certain regulatory or industry standards (including product safety and information security standards, which may differ by region, geography and industry, and which are particularly stringent in the automotive industry), or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and the end users of such devices, and potentially to our customers’ IT infrastructure. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products or participating in customer recalls (for example, in the automotive industry), repairing or replacing defective products, writing down defective inventory or indemnification obligations under our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, and losses on unfavorable purchase commitments. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products.

[0000804328-24-000039:mdna:278]
In addition, the occurrence of defects, errors or security vulnerabilities may give rise to product liability claims, particularly if such defects, errors or security vulnerabilities in our products or the technology we use, or the products into which they are integrated, result in personal injury or death, and could result in significant costs, expenses and losses. If a product liability claim is brought against us, the cost of defending the claim could be significant, and could divert the attention of our technical and management personnel and harm our business, even if we are successful. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. We may also be required to indemnify and/or defend our customers from product liability claims relating to our products. Further, our business liability insurance may be inadequate, may not cover the claims, and future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products

[0000804328-24-000039:mdna:279]
41

[0000804328-24-000039:mdna:280]
may be used, and perform critical functions, in various high-risk applications such as: automobiles, including ADAS/AD functions; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and XR for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

[0000804328-24-000039:mdna:281]
[same as prior period, unchanged from 0000804328-24-000017:mdna:245]

[0000804328-24-000039:mdna:282]
[same as prior period, unchanged from 0000804328-24-000017:mdna:246]

[0000804328-24-000039:mdna:283]
[same as prior period, unchanged from 0000804328-24-000017:mdna:247]

[0000804328-24-000039:mdna:284]
[same as prior period, unchanged from 0000804328-24-000017:mdna:248]

[0000804328-24-000039:mdna:285]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. We cannot predict with certainty the long-term effects of any potential changes. In the United States, Europe (including the United Kingdom), India, China and elsewhere, there is continued discussion regarding potential patent law changes, and there is current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. Some proposed changes would apply to only standard-essential patents, and such changes may substantially alter the incentives to participate in standardization or develop standards-compliant products. See also the Risk Factor entitled “Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business.”

[0000804328-24-000039:mdna:286]
[same as prior period, unchanged from 0000804328-24-000017:mdna:251]

[0000804328-24-000039:mdna:287]
We have had and may in the future have difficulty in certain circumstances in protecting or enforcing our intellectual property and contracts, including collecting royalties for use of our patent portfolio due to, among others: refusal by certain licensees to report and pay all or a portion of the royalties they owe to us; policies or political actions of governments, including trade protection and national security policies; challenges to our licensing practices under competition laws; adoption of mandatory licensing provisions by foreign jurisdictions; failure of foreign courts to recognize and enforce judgments of contract breach and damages issued by courts in the United States; and challenges before competition agencies to our licensing business or the pricing and integration of additional features and functionality into our chipset products. See also the Risk Factors titled “Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings.”

[0000804328-24-000039:mdna:288]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of

[0000804328-24-000039:mdna:289]
42

[0000804328-24-000039:mdna:290]
proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0000804328-24-000039:mdna:291]
[same as prior period, unchanged from 0000804328-24-000017:mdna:254]

[0000804328-24-000039:mdna:292]
[same as prior period, unchanged from 0000804328-24-000017:mdna:255]

[0000804328-24-000039:mdna:293]
[same as prior period, unchanged from 0000804328-24-000017:mdna:256]

[0000804328-24-000039:mdna:294]
From time to time, companies have asserted, and may again assert, patent, copyright or other intellectual property claims against us relating to our technologies or products, including those we have acquired from other companies. These claims have resulted and may again result in our involvement in litigation, and we are currently involved in such litigation, including certain matters described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products were found to infringe another company’s intellectual property, we could be subject to an injunction or be required to redesign our products, or to license such intellectual property or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products, license such intellectual property used in our products or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling our products. Similarly, our suppliers could be found to infringe another company’s intellectual property, and such suppliers could then be enjoined from providing products or services to us.

[0000804328-24-000039:mdna:295]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products sold by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel and/or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0000804328-24-000039:mdna:296]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative

[0000804328-24-000039:mdna:297]
outcome in any such proceeding could severely disrupt the business of our customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing corresponding declines in our chipset or licensing revenues.

[0000804328-24-000039:mdna:298]
[same as prior period, unchanged from 0000804328-24-000017:mdna:261]

[0000804328-24-000039:mdna:299]
[same as prior period, unchanged from 0000804328-24-000017:mdna:262]

[0000804328-24-000039:mdna:300]
[same as prior period, unchanged from 0000804328-24-000017:mdna:264]

[0000804328-24-000039:mdna:301]
[same as prior period, unchanged from 0000804328-24-000017:mdna:265]

[0000804328-24-000039:mdna:302]
The semiconductor industry is highly cyclical, volatile, subject to downturns and characterized by constant and rapid technological change, price erosion, evolving technical standards, frequent new product introductions, short product life cycles and fluctuations in product supply and demand. Periods of downturns have been characterized by diminished demand for end-user products, high inventory levels, excess or obsolete inventory adjustments or reserves, underutilization of manufacturing capacity, changes in revenue mix and erosion of average selling prices. During such downturns, our revenues have declined, and our results of operations and financial condition have been adversely impacted. We expect our business to continue to be subject to such cyclical downturns. In addition, we are currently seeing and expect to continue to see elevated inventory levels at certain of our IoT customers (negatively impacting the volume of chipsets they purchase from us until such inventory is depleted).

[0000804328-24-000039:mdna:303]
[same as prior period, unchanged from 0000804328-24-000017:mdna:267]

[0000804328-24-000039:mdna:304]
Our stock price and financial results have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and our financial results include those identified above and throughout this Risk Factors section, as well as: volatility of the stock market in general and technology and semiconductor companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees, including any announcement concerning the initiation of, or any developments in, any lawsuit or governmental investigation

[0000804328-24-000039:mdna:305]
or proceeding against us; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.”

[0000804328-24-000039:mdna:306]
[same as prior period, unchanged from 0000804328-24-000017:mdna:269]

[0000804328-24-000039:mdna:307]
We have operations and facilities in the United States and many other countries throughout the world. We derive a significant portion of our revenues from Chinese OEMs and from non-Chinese OEMs that utilize our integrated circuit products in devices they sell into China (which has the largest number of smartphone users in the world); our key suppliers and their manufacturing foundries and assembly, test and other facilities are primarily located in Taiwan and Korea; our manufacturing facilities for RFFE and RF products are located in China, Germany and Singapore; the primary warehouses where we store finished goods for fulfillment of customer orders are located in Singapore; and a significant portion of our workforce (including engineering and other technical personnel) is based in India. Acts of war, terrorism, geopolitical conflicts, political instability or tensions such as the current geopolitical tensions involving China and Taiwan, natural disasters, the effects of climate change, pandemics such as the COVID-19 pandemic, or other health crises affecting any of the regions in which we operate, and particularly those in which our customers, suppliers, manufacturing facilities and/or significant portions of our workforce are concentrated, could significantly disrupt our business by, among others: reducing demand for our products and services or end-user devices incorporating our products or intellectual property; impairing our customers’ or licensees’ ability to purchase or pay for our products, services or intellectual property; delaying or preventing our suppliers from providing us with critical components or raw materials; delaying or preventing our foundry or semiconductor assembly and test providers from manufacturing, assembling or testing our products; preventing us from manufacturing products or shipping finished products; damaging or destroying inventory; delaying or preventing network operators from upgrading their wireless networks to meet new technology standards; or preventing a significant number of our employees, or employees who perform critical functions, from performing their duties for us. For example, our business depends on our ability to receive consistent and reliable chipset supply from our foundry partners, particularly in Taiwan. Consequently, a significant or prolonged military or other geopolitical conflict involving China and Taiwan could severely limit or prevent us from receiving chipset supply from Taiwan, which would have a material adverse impact on our business (and likely on the semiconductor industry as a whole). In addition, acts of war, terrorism, geopolitical conflicts, political instability or tensions, natural disasters, the effects of climate change, pandemics or other health crises impacting any of these regions could also result in a decline in global, regional or local economic conditions generally, or increased volatility in financial markets, which could have adverse effects on our business and financial results. See also the Risk Factor titled “We operate in the highly cyclical semiconductor industry, which is subject to significant downturns. We are also susceptible to declines in global, regional and local economic conditions generally. Our stock price and financial results are subject to substantial quarterly and annual fluctuations due to these dynamics, among others.” Any such events may also have the effect of exacerbating the other risks discussed in this “Risk Factors” section.

[0000804328-24-000039:mdna:308]
[same as prior period, unchanged from 0000804328-24-000017:mdna:272]

[0000804328-24-000039:mdna:309]
Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). These include, among others, Regulations related to: patent licensing practices; antitrust, competition and competitive business practices; the flow of funds out of certain countries (e.g., China); cybersecurity; privacy and data protection; imports and exports, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; protection of intellectual property; trade and trade protection including tariffs; foreign policy and national security; environmental protection (including climate change), health and safety; supply chain, responsible sourcing, including the use of conflict minerals, and human rights; spectrum availability and license issuance; adoption of standards; taxation; labor, employment and human capital; corporate governance; public disclosure and reporting (including reporting of ESG-related data); automotive industry safety and quality standards; AI technologies; and business conduct. Compliance with, or changes in the interpretation of, existing Regulations, the adoption of new Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, among others, could have an adverse effect on our business and results of operations. See also the Risk Factors titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of

[0000804328-24-000039:mdna:310]
[same as prior period, unchanged from 0000804328-24-000017:mdna:277]

[0000804328-24-000039:mdna:311]
operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises, geopolitical conflicts and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

[0000804328-24-000039:mdna:312]
[same as prior period, unchanged from 0000804328-24-000017:mdna:274]

[0000804328-24-000039:mdna:313]
[same as prior period, unchanged from 0000804328-24-000017:mdna:275]

[0000804328-24-000039:mdna:314]
Our outstanding debt and any additional debt we incur may have negative consequences on our business, including, among others: requiring us to use cash to pay the principal of and interest on our debt, thereby reducing the amount of cash available for other purposes; limiting our ability to obtain additional financing for working capital, capital expenditures, acquisitions, stock repurchases, dividends, general corporate or other purposes; and limiting our flexibility in planning for, or reacting to, changes in our business, industries or the market. Our ability to make payments of principal and interest on our debt depends upon our future performance, which is subject to economic and political conditions, industry cycles and financial, business and other factors, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations to service our debt, we may be required to, among others: refinance or restructure all or a portion of our debt; reduce or delay planned capital or operating expenditures; reduce, suspend or eliminate our dividend payments and/or our stock repurchase program; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing or restructuring are higher than our current rates, interest expense related to such refinancing or restructuring would increase. Further, if there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt financing in the future and the terms of such debt could be adversely affected.

[0000804328-24-000039:mdna:315]
[same as prior period, unchanged from 0000804328-24-000017:mdna:279]

[0000804328-24-000039:mdna:316]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed, as well as countries where we own intellectual property. The final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0000804328-24-000039:mdna:317]
[same as prior period, unchanged from 0000804328-24-000017:mdna:281]

[0000804328-24-000039:mdna:318]
[same as prior period, unchanged from 0000804328-24-000017:mdna:282]
