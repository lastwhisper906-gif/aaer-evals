# QCOM MD&A — 0001728949-22-000040


## mdna

[0001728949-22-000040:mdna:1]
[same as prior period, unchanged from 0001728949-22-000026:mdna:1]

[0001728949-22-000040:mdna:2]
[same as prior period, unchanged from 0001728949-22-000026:mdna:2]

[0001728949-22-000040:mdna:3]
[same as prior period, unchanged from 0001728949-22-000026:mdna:3]

[0001728949-22-000040:mdna:4]
Third Quarter Fiscal 2022 Overview and Other Recent Events

[0001728949-22-000040:mdna:5]
Revenues for the third quarter of fiscal 2022 were $10.9 billion, an increase of 36% compared to the year ago quarter, with net income of $3.7 billion, an increase of 84% compared to the year ago quarter. Highlights from the third quarter of fiscal 2022 and other recent events included:

[0001728949-22-000040:mdna:6]
•QCT revenues increased by 45% in the third quarter of fiscal 2022 compared to the year ago quarter, primarily due to an increase in average selling prices and higher chipset shipments in handsets, along with higher IoT revenues.

[0001728949-22-000040:mdna:7]
•On June 15, 2022, the General Court of the European Union issued a ruling annulling in its entirety the European Commission’s (EC) 2018 decision, which previously imposed a fine of 997 million euros for which we had provided financial guarantees to satisfy the obligation in lieu of cash payment. As a result, in the third quarter of fiscal 2022, we recorded a $1.1 billion benefit in other income and a $62 million reduction in interest expense, resulting from the reversal of the accrued fine and the associated interest previously recorded. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” in this Quarterly Report.

[0001728949-22-000040:mdna:8]
•On October 4, 2021, we and SSW Partners entered into a definitive agreement to acquire Veoneer, Inc. (Veoneer). The transaction closed on April 1, 2022. We funded substantially all of the total cash consideration paid in the transaction, which was approximately $4.7 billion. The operating results of the Arriver and Non-Arriver businesses are reported on a one quarter lag. Therefore, no such amounts were included in our results of operations for the three and nine months ended June 26, 2022. Additional information related to this acquisition is included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 8. Acquisitions.”

[0001728949-22-000040:mdna:9]
[same as prior period, unchanged from 0001728949-22-000026:mdna:8]

[0001728949-22-000040:mdna:10]
[same as prior period, unchanged from 0001728949-22-000026:mdna:9]

[0001728949-22-000040:mdna:11]
[same as prior period, unchanged from 0001728949-22-000026:mdna:28]

[0001728949-22-000040:mdna:12]
[same as prior period, unchanged from 0001728949-22-000026:mdna:11]

[0001728949-22-000040:mdna:13]
[same as prior period, unchanged from 0001728949-22-000026:mdna:12]

[0001728949-22-000040:mdna:14]
[same as prior period, unchanged from 0001728949-22-000026:mdna:13]

[0001728949-22-000040:mdna:15]
[same as prior period, unchanged from 0001728949-22-000026:mdna:14]

[0001728949-22-000040:mdna:16]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | Change |  | June 26,2022 |  | June 27,2021 |  | Change |
| Equipment and services | $ | 9,266 |  |  | $ | 6,428 |  |  | $ | 2,838 |  |  | $ | 27,365 |  |  | $ | 19,109 |  |  | $ | 8,256 |  |
| Licensing | 1,670 |  |  | 1,632 |  |  | 38 |  |  | 5,440 |  |  | 5,121 |  |  | 319 |  |
|  | $ | 10,936 |  |  | $ | 8,060 |  |  | $ | 2,876 |  |  | $ | 32,805 |  |  | $ | 24,230 |  |  | $ | 8,575 |  |

[0001728949-22-000040:mdna:17]
Third quarter 2022 vs. 2021

[0001728949-22-000040:mdna:18]
The increase in revenues in the third quarter of fiscal 2022 was primarily due to $2.8 billion in higher equipment and services revenues from our QCT segment.

[0001728949-22-000040:mdna:19]
First nine months 2022 vs. 2021

[0001728949-22-000040:mdna:20]
The increase in revenues in the first nine months of fiscal 2022 was primarily due to:

[0001728949-22-000040:mdna:21]
+    $8.3 billion in higher equipment and services revenues and $217 million in higher licensing revenues from our QCT segment

[0001728949-22-000040:mdna:22]
+    $155 million in higher licensing revenues from our QTL segment

[0001728949-22-000040:mdna:23]
| Costs and Expenses (in millions, except percentages) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | Change |  | June 26,2022 |  | June 27,2021 |  | Change |
| Cost of revenues | $ | 4,816 |  |  | $ | 3,404 |  |  | $ | 1,412 |  |  | $ | 13,767 |  |  | $ | 10,325 |  |  | $ | 3,442 |  |
| Gross margin | 56 | % |  | 58 | % |  |  |  | 58 | % |  | 57 | % |  |  |

[0001728949-22-000040:mdna:24]
Third quarter 2022 vs. 2021

[0001728949-22-000040:mdna:25]
Gross margin percentage decreased in the third quarter of fiscal 2022 primarily due to a decrease in higher margin QTL licensing revenues in proportion to QCT revenues.

[0001728949-22-000040:mdna:26]
First nine months 2022 vs. 2021

[0001728949-22-000040:mdna:27]
Gross margin percentage increased in the first nine months of fiscal 2022 primarily due to:

[0001728949-22-000040:mdna:28]
[same as prior period, unchanged from 0001728949-22-000026:mdna:26]

[0001728949-22-000040:mdna:29]
[same as prior period, unchanged from 0001728949-22-000026:mdna:27]

[0001728949-22-000040:mdna:30]
[same as prior period, unchanged from 0001728949-22-000026:mdna:49]

[0001728949-22-000040:mdna:31]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | Change |  | June 26,2022 |  | June 27,2021 |  | Change |
| Research and development | $ | 2,052 |  |  | $ | 1,864 |  |  | $ | 188 |  |  | $ | 6,016 |  |  | $ | 5,297 |  |  | $ | 719 |  |
| % of revenues | 19 | % |  | 23 | % |  |  |  | 18 | % |  | 22 | % |  |  |

[0001728949-22-000040:mdna:32]
Third quarter 2022 vs. 2021

[0001728949-22-000040:mdna:33]
The increase in research and development expenses in the third quarter of fiscal 2022 was primarily due to:

[0001728949-22-000040:mdna:34]
+    $178 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), primarily driven by an increase in employee-related expenses

[0001728949-22-000040:mdna:35]
+    $72 million increase in share-based compensation expense

[0001728949-22-000040:mdna:36]
-    $61 million decrease in expenses driven by revaluation of our deferred compensation plan obligation on lower relative stock market performance (which resulted in a corresponding increase in net losses on deferred compensation plan assets within investment and other (expense) income, net due to the revaluation of the related assets)

[0001728949-22-000040:mdna:37]
First nine months 2022 vs. 2021

[0001728949-22-000040:mdna:38]
The increase in research and development expenses in the first nine months of fiscal 2022 was primarily due to:

[0001728949-22-000040:mdna:39]
+    $607 million increase driven by higher costs related to the development of wireless and integrated circuit technologies (including 5G and application processor technologies), primarily driven by an increase in employee-related expenses

[0001728949-22-000040:mdna:40]
+    $228 million increase in share-based compensation expense

[0001728949-22-000040:mdna:41]
-    $116 million decrease in expenses driven by revaluation of our deferred compensation plan obligation on lower relative stock market performance

[0001728949-22-000040:mdna:42]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | Change |  | June 26,2022 |  | June 27,2021 |  | Change |
| Selling, general and administrative | $ | 655 |  |  | $ | 597 |  |  | $ | 58 |  |  | $ | 1,887 |  |  | $ | 1,721 |  |  | $ | 166 |  |
| % of revenues | 6 | % |  | 7 | % |  |  |  | 6 | % |  | 7 | % |  |  |

[0001728949-22-000040:mdna:43]
Third quarter 2022 vs. 2021

[0001728949-22-000040:mdna:44]
The increase in selling, general and administrative expenses in the third quarter of fiscal 2022 was primarily due to:

[0001728949-22-000040:mdna:45]
+    $63 million increase in acquisition-related expenses, primarily related to the Veoneer transaction

[0001728949-22-000040:mdna:46]
+    $44 million increase in share-based compensation expense

[0001728949-22-000040:mdna:47]
[same as prior period, unchanged from 0001728949-22-000026:mdna:39]

[0001728949-22-000040:mdna:48]
First nine months 2022 vs. 2021

[0001728949-22-000040:mdna:49]
The increase in selling, general and administrative expenses in the first nine months of fiscal 2022 was primarily due to:

[0001728949-22-000040:mdna:50]
+    $92 million increase in employee-related expenses

[0001728949-22-000040:mdna:51]
+    $90 million increase in acquisition-related expenses, primarily related to the Veoneer transaction

[0001728949-22-000040:mdna:52]
+    $60 million increase in share-based compensation expense

[0001728949-22-000040:mdna:53]
-    $105 million decrease in expenses driven by revaluation of our deferred compensation plan obligation on lower relative stock market performance

[0001728949-22-000040:mdna:54]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | Change |  | June 26,2022 |  | June 27,2021 |  | Change |
| Other income | $ | 1,059 |  |  | $ | — |  |  | $ | 1,059 |  |  | $ | 1,059 |  |  | $ | — |  |  | $ | 1,059 |  |

[0001728949-22-000040:mdna:55]
Third quarter and first nine months 2022

[0001728949-22-000040:mdna:56]
Other income in the third quarter and first nine months of fiscal 2022 consisted of a $1.1 billion benefit resulting from the 2018 EC fine reversal.

[0001728949-22-000040:mdna:57]
| Interest Expense and Investment and Other (Expense) Income, Net (in millions) |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | Change |  | June 26,2022 |  | June 27,2021 |  | Change |
| Interest expense | $ | 70 |  |  | $ | 138 |  |  | $ | (68) |  |  | $ | 345 |  |  | $ | 421 |  |  | $ | (76) |  |
| Investment and other (expense) income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 22 |  |  | $ | 21 |  |  | $ | 1 |  |  | $ | 59 |  |  | $ | 63 |  |  | $ | (4) |  |
| Net (losses) gains on marketable securities | (104) |  |  | 53 |  |  | (157) |  |  | (327) |  |  | 86 |  |  | (413) |  |
| Net gains on other investments | 25 |  |  | 97 |  |  | (72) |  |  | 97 |  |  | 307 |  |  | (210) |  |
| Net (losses) gains on deferred compensation plan assets | (80) |  |  | 38 |  |  | (118) |  |  | (110) |  |  | 115 |  |  | (225) |  |
| Impairment losses on other investments | (20) |  |  | (7) |  |  | (13) |  |  | (41) |  |  | (24) |  |  | (17) |  |
| Net losses on derivative instruments | (7) |  |  | — |  |  | (7) |  |  | (25) |  |  | (7) |  |  | (18) |  |
| Equity in net (losses) earnings of investees | (12) |  |  | 1 |  |  | (13) |  |  | 5 |  |  | 12 |  |  | (7) |  |
| Net gains (losses) on foreign currency transactions | 13 |  |  | (3) |  |  | 16 |  |  | 21 |  |  | (29) |  |  | 50 |  |
|  | $ | (163) |  |  | $ | 200 |  |  | $ | (363) |  |  | $ | (321) |  |  | $ | 523 |  |  | $ | (844) |  |

[0001728949-22-000040:mdna:58]
The decrease in interest expense for the three and nine months ended June 26, 2022 was primarily driven by the $62 million reversal of accrued interest previously recorded related to the annulled 2018 EC fine.

[0001728949-22-000040:mdna:59]
Net losses on marketable securities for the three and nine months ended June 26, 2022 was primarily driven by the change in fair value of certain of our QSI marketable equity investments in early or growth stage companies. The fair values of these investments have been and may continue to be subject to increased volatility. Net gains on other investments for the three and nine months ended June 27, 2021 was driven primarily by realized gains resulting from the sale of certain of our QSI non-marketable investments.

[0001728949-22-000040:mdna:60]
[same as prior period, unchanged from 0001728949-22-000026:mdna:52]

[0001728949-22-000040:mdna:61]
[same as prior period, unchanged from 0001728949-22-000026:mdna:53]

[0001728949-22-000040:mdna:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | June 26,2022 |  | June 27,2021 |
| Expected income tax provision at federal statutory tax rate | $ | 890 |  |  | $ | 474 |  |  | $ | 2,421 |  |  | $ | 1,468 |  |
| Benefit from foreign-derived intangible income (FDII) deduction | (222) |  |  | (119) |  |  | (566) |  |  | (308) |  |
| Excess tax benefit associated with share-based awards | (39) |  |  | (74) |  |  | (254) |  |  | (258) |  |
| Nontaxable reversal of 2018 EC fine | (166) |  |  | — |  |  | (166) |  |  | — |  |
| Benefit related to the research and development tax credit | (49) |  |  | (40) |  |  | (153) |  |  | (138) |  |
| Foreign currency losses (gains) related to foreign withholding tax receivable | 87 |  |  | (1) |  |  | 135 |  |  | (47) |  |
| Other | 8 |  |  | (10) |  |  | 48 |  |  | 27 |  |
| Income tax expense | $ | 509 |  |  | $ | 230 |  |  | $ | 1,465 |  |  | $ | 744 |  |
| Effective tax rate | 12 | % |  | 10 | % |  | 13 | % |  | 11 | % |

[0001728949-22-000040:mdna:63]
We estimate our annual effective income tax rate to be 13% for fiscal 2022, which is lower than the U.S. federal statutory rate, primarily due to (i) a significant portion of our income qualifying for preferential treatment as FDII at a 13% effective tax rate, (ii) the reversal of the 2018 EC fine, which is not taxable and is attributable to a foreign jurisdiction, (iii) excess tax benefits associated with share-based awards and (iv) benefits from our federal research and development tax credit.

[0001728949-22-000040:mdna:64]
[same as prior period, unchanged from 0001728949-22-000026:mdna:75]

[0001728949-22-000040:mdna:65]
Pursuant to U.S. tax law, beginning in fiscal 2023, we are required to capitalize and amortize domestic research and development expenditures over five years and foreign research and development expenditures over fifteen years (currently, such expenditures are deducted as incurred). If this requirement is not delayed or repealed, our cash flows from operations will be adversely affected due to significantly higher cash tax payments. However, since the resulting deferred tax asset will be established at the statutory rate of 21% (rather than the effective tax rate of 13% to 16% after considering the FDII deduction), capitalization will favorably affect our provision for income taxes and results of operations. The adverse cash flow impact and favorable tax provision impact will diminish in future years as capitalized research and development expenditures continue to amortize.

[0001728949-22-000040:mdna:66]
[same as prior period, unchanged from 0001728949-22-000026:mdna:58]

[0001728949-22-000040:mdna:67]
[same as prior period, unchanged from 0001728949-22-000026:mdna:59]

[0001728949-22-000040:mdna:68]
The following should be read in conjunction with our financial results for the third quarter of fiscal 2022 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0001728949-22-000040:mdna:69]
[same as prior period, unchanged from 0001728949-22-000026:mdna:61]

[0001728949-22-000040:mdna:70]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | Change |  | June 26,2022 |  | June 27,2021 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| Handsets (1) | $ | 6,149 |  |  | $ | 3,863 |  |  | $ | 2,286 |  |  | $ | 18,457 |  |  | $ | 12,144 |  |  | $ | 6,313 |  |
| RFFE (2) | 1,046 |  |  | 957 |  |  | 89 |  |  | 3,338 |  |  | 2,921 |  |  | 417 |  |
| Automotive (3) | 350 |  |  | 253 |  |  | 97 |  |  | 945 |  |  | 705 |  |  | 240 |  |
| IoT (internet of things) (4) | 1,833 |  |  | 1,399 |  |  | 434 |  |  | 5,033 |  |  | 3,517 |  |  | 1,516 |  |
| Total revenues | $ | 9,378 |  |  | $ | 6,472 |  |  | $ | 2,906 |  |  | $ | 27,773 |  |  | $ | 19,287 |  |  | $ | 8,486 |  |
| EBT (5) | $ | 2,996 |  |  | $ | 1,795 |  |  | $ | 1,201 |  |  | $ | 9,450 |  |  | $ | 5,299 |  |  | $ | 4,151 |  |
| EBT as a % of revenues | 32 | % |  | 28 | % |  | 4 points |  | 34 | % |  | 27 | % |  | 7 points |

[0001728949-22-000040:mdna:71]
[same as prior period, unchanged from 0001728949-22-000026:mdna:63]

[0001728949-22-000040:mdna:72]
[same as prior period, unchanged from 0001728949-22-000026:mdna:64]

[0001728949-22-000040:mdna:73]
[same as prior period, unchanged from 0001728949-22-000026:mdna:65]

[0001728949-22-000040:mdna:74]
[same as prior period, unchanged from 0001728949-22-000026:mdna:66]

[0001728949-22-000040:mdna:75]
[same as prior period, unchanged from 0001728949-22-000026:mdna:67]

[0001728949-22-000040:mdna:76]
Substantially all of QCT’s revenues consist of equipment and services revenues, which were $9.2 billion and $6.4 billion in the third quarter of fiscal 2022 and 2021, respectively, and $27.3 billion and $19.0 billion in the first nine months of fiscal 2022 and 2021, respectively. QCT handsets, automotive and IoT revenues mostly relate to sales of our Snapdragon platforms (which include processors and modems), stand-alone Mobile Data Modems, radio frequency transceiver, power management and wireless connectivity integrated chipsets.

[0001728949-22-000040:mdna:77]
Third quarter 2022 vs. 2021

[0001728949-22-000040:mdna:78]
The increase in QCT revenues in the third quarter of fiscal 2022 was primarily due to:

[0001728949-22-000040:mdna:79]
+    higher handsets revenues, primarily driven by $1.1 billion in higher revenues per chipset, largely due to increases in average selling prices from higher-tier 5G products, and $1.0 billion in higher chipset shipments from major OEMs

[0001728949-22-000040:mdna:80]
[same as prior period, unchanged from 0001728949-22-000026:mdna:72]

[0001728949-22-000040:mdna:81]
[same as prior period, unchanged from 0001728949-22-000026:mdna:73]

[0001728949-22-000040:mdna:82]
+    higher IoT revenues across consumer, edge networking and industrial products, driven by a $229 million increase from favorable mix and higher average selling prices and a $205 million increase in demand

[0001728949-22-000040:mdna:83]
QCT EBT as a percentage of revenues increased in the third quarter of fiscal 2022 primarily due to:

[0001728949-22-000040:mdna:84]
[same as prior period, unchanged from 0001728949-22-000026:mdna:77]

[0001728949-22-000040:mdna:85]
[same as prior period, unchanged from 0001728949-22-000026:mdna:79]

[0001728949-22-000040:mdna:86]
Gross margin percentage remained flat, primarily driven by higher average selling prices, offset by higher product costs and reserve charges.

[0001728949-22-000040:mdna:87]
First nine months 2022 vs. 2021

[0001728949-22-000040:mdna:88]
The increase in QCT revenues in the first nine months of fiscal 2022 was primarily due to:

[0001728949-22-000040:mdna:89]
+    higher handsets revenues, primarily driven by $5.2 billion in higher revenues per chipset from increases in average selling prices and favorable mix toward higher-tier 5G products and $767 million in higher chipset shipments from major OEMs

[0001728949-22-000040:mdna:90]
[same as prior period, unchanged from 0001728949-22-000026:mdna:83]

[0001728949-22-000040:mdna:91]
[same as prior period, unchanged from 0001728949-22-000026:mdna:84]

[0001728949-22-000040:mdna:92]
+    higher IoT revenues across consumer, edge networking and industrial products, driven by a $759 million increase in demand, with the remaining increase of $757 million primarily due to favorable mix

[0001728949-22-000040:mdna:93]
QCT EBT as a percentage of revenues increased in the first nine months of fiscal 2022 primarily due to:

[0001728949-22-000040:mdna:94]
[same as prior period, unchanged from 0001728949-22-000026:mdna:87]

[0001728949-22-000040:mdna:95]
[same as prior period, unchanged from 0001728949-22-000026:mdna:78]

[0001728949-22-000040:mdna:96]
[same as prior period, unchanged from 0001728949-22-000026:mdna:89]

[0001728949-22-000040:mdna:97]
[same as prior period, unchanged from 0001728949-22-000026:mdna:90]

[0001728949-22-000040:mdna:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | Change |  | June 26,2022 |  | June 27,2021 |  | Change |
| Licensing revenues | $ | 1,519 |  |  | $ | 1,489 |  |  | $ | 30 |  |  | $ | 4,917 |  |  | $ | 4,762 |  |  | $ | 155 |  |
| EBT | 1,080 |  |  | 1,053 |  |  | 27 |  |  | 3,640 |  |  | 3,514 |  |  | 126 |  |
| EBT as a % of revenues | 71 | % |  | 71 | % |  | — |  | 74 | % |  | 74 | % |  | — |

[0001728949-22-000040:mdna:99]
Third quarter 2022 vs. 2021

[0001728949-22-000040:mdna:100]
The increase in QTL licensing revenues in the third quarter of fiscal 2022 was primarily due to:

[0001728949-22-000040:mdna:101]
+    $49 million increase in estimated revenues per unit, which was primarily driven by favorable mix, including 5G

[0001728949-22-000040:mdna:102]
-    $40 million decrease in estimated sales of 3G/4G/5G-based multimode products

[0001728949-22-000040:mdna:103]
QTL EBT as a percentage of revenues remained flat in the third quarter of fiscal 2022.

[0001728949-22-000040:mdna:104]
First nine months 2022 vs. 2021

[0001728949-22-000040:mdna:105]
The increase in QTL licensing revenues in the first nine months of fiscal 2022 was primarily due to:

[0001728949-22-000040:mdna:106]
+    $266 million increase in estimated revenues per unit, which was primarily driven by favorable mix, including 5G

[0001728949-22-000040:mdna:107]
-    $144 million decrease in estimated sales of 3G/4G/5G-based multimode products

[0001728949-22-000040:mdna:108]
QTL EBT as a percentage of revenues remained flat in the first nine months of fiscal 2022.

[0001728949-22-000040:mdna:109]
[same as prior period, unchanged from 0001728949-22-000026:mdna:103]

[0001728949-22-000040:mdna:110]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | Change |  | June 26,2022 |  | June 27,2021 |  | Change |
| Equipment and services revenues | $ | 8 |  |  | $ | 11 |  |  | $ | (3) |  |  | $ | 22 |  |  | $ | 30 |  |  | $ | (8) |  |
| EBT | (101) |  |  | 156 |  |  | (257) |  |  | (248) |  |  | 412 |  |  | (660) |  |

[0001728949-22-000040:mdna:111]
Third quarter and first nine months 2022 vs. 2021

[0001728949-22-000040:mdna:112]
The decrease in QSI EBT in the third quarter and first nine months of fiscal 2022 was primarily due to a $225 million and $614 million increase, respectively, in net losses on investments, which was primarily driven by the change in fair value of certain of our marketable equity investments in early or growth stage companies. The fair values of these investments have been and may continue to be subject to increased volatility.

[0001728949-22-000040:mdna:113]
[same as prior period, unchanged from 0001728949-22-000026:mdna:120]

[0001728949-22-000040:mdna:114]
[same as prior period, unchanged from 0001728949-22-000026:mdna:107]

[0001728949-22-000040:mdna:115]
[same as prior period, unchanged from 0001728949-22-000026:mdna:108]

[0001728949-22-000040:mdna:116]
[same as prior period, unchanged from 0001728949-22-000026:mdna:109]

[0001728949-22-000040:mdna:117]
•Despite the decline in global demand for handsets and other consumer products, driven by the current macroeconomic environment and the impact of COVID-19 measures in China, we expect QCT revenues to continue to be favorably impacted in the fourth fiscal quarter compared to the prior year.

[0001728949-22-000040:mdna:118]
•While we and the semiconductor industry continue to experience certain supply chain complexities and challenges, we currently, and we expect to continue to, see supply and demand generally in balance.

[0001728949-22-000040:mdna:119]
[same as prior period, unchanged from 0001728949-22-000026:mdna:112]

[0001728949-22-000040:mdna:120]
[same as prior period, unchanged from 0001728949-22-000026:mdna:113]

[0001728949-22-000040:mdna:121]
[same as prior period, unchanged from 0001728949-22-000026:mdna:114]

[0001728949-22-000040:mdna:122]
[same as prior period, unchanged from 0001728949-22-000026:mdna:115]

[0001728949-22-000040:mdna:123]
[same as prior period, unchanged from 0001728949-22-000026:mdna:116]

[0001728949-22-000040:mdna:124]
[same as prior period, unchanged from 0001728949-22-000026:mdna:118]

[0001728949-22-000040:mdna:125]
[same as prior period, unchanged from 0001728949-22-000026:mdna:119]

[0001728949-22-000040:mdna:126]
[same as prior period, unchanged from 0001728949-22-000026:mdna:121]

[0001728949-22-000040:mdna:127]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations and cash provided by our debt programs. The following tables present selected financial information related to our liquidity at June 26, 2022 and September 26, 2021 and for the first nine months of fiscal 2022 and 2021 (in millions):

[0001728949-22-000040:mdna:128]
|  | June 26,2022 |  | September 26,2021 |  | Change |  |  |
| Cash and cash equivalents (1) | $ | 2,676 |  |  | $ | 7,116 |  |  | $ | (4,440) |  |  |  |
| Marketable securities | 4,172 |  |  | 5,298 |  |  | (1,126) |  |  |  |
| Cash, cash equivalents and marketable securities | $ | 6,848 |  |  | $ | 12,414 |  |  | $ | (5,566) |  |  |  |

[0001728949-22-000040:mdna:129]
(1) Excludes $522 million of cash and cash equivalents classified as held for sale (included in other current assets) at June 26, 2022.

[0001728949-22-000040:mdna:130]
[same as prior period, unchanged from 0001728949-22-000026:mdna:129]

[0001728949-22-000040:mdna:131]
|  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | Change |  |  |
| Net cash provided by operating activities | $ | 7,650 |  |  | $ | 9,459 |  |  | $ | (1,809) |  |  |  |
| Net cash used by investing activities | (5,514) |  |  | (3,406) |  |  | (2,108) |  |  |  |
| Net cash used by financing activities | (6,004) |  |  | (5,396) |  |  | (608) |  |  |  |

[0001728949-22-000040:mdna:132]
Cash, cash equivalents and marketable securities. The net decrease in cash, cash equivalents and marketable securities was primarily due to $4.7 billion in cash paid for acquisitions and other investments, net of cash acquired (primarily related to Veoneer), $2.6 billion in payments to repurchase shares of our common stock, $2.4 billion in cash dividends paid, $1.6 billion in capital expenditures and $751 million in payments of tax withholdings related to the vesting of share-based awards. This was partially offset by net cash provided by operating activities, which was negatively impacted by advanced payments of $2.3 billion made to suppliers of our integrated circuit products under certain multi-year capacity commitments (which were included within other current assets and other assets), as well as $1.9 billion of net changes in other operating assets and liabilities (excluding the reversal of the 2018 EC fine), primarily consisting of increased working capital requirements, including higher inventory and related operating liabilities to support QCT demand and an increase in accounts receivable as a result of higher revenues (net of an increase in amounts accrued for customer incentive arrangements recorded as a reduction to accounts receivable).

[0001728949-22-000040:mdna:133]
Capital Return Program. On October 12, 2021, we announced a $10.0 billion stock repurchase program. The stock repurchase program has no expiration date. In the first nine months of fiscal 2022, we repurchased and retired 18 million shares of our common stock for $2.6 billion, before commissions. At June 26, 2022, $8.6 billion remained authorized for repurchase under our stock repurchase program. Our stock repurchase program is subject to periodic evaluations to determine when and if repurchases are in the best interests of our stockholders, and we may accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-22-000040:mdna:134]
In the first nine months of fiscal 2022, we paid cash dividends totaling $2.4 billion, or $2.11 per share. On July 15, 2022, we announced a cash dividend of $0.75 per share on our common stock, payable on September 22, 2022 to stockholders of record as of the close of business on September 1, 2022. We currently intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders, among other factors.

[0001728949-22-000040:mdna:135]
Debt. In the third quarter of fiscal 2022, we issued an aggregate principal amount of $1.5 billion of unsecured fixed-rate notes with varying maturities. The net proceeds, together with cash on hand, were used to repay $1.5 billion fixed-rate notes that matured in May 2022. At June 26, 2022, we had an aggregate principal amount of $15.4 billion of floating- and fixed-rate notes outstanding, $1.45 billion of which matures in January 2023. The remaining debt has maturity dates in 2024 through 2052. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At June 26, 2022, we had $500 million of commercial paper outstanding. We also have a Revolving Credit Facility, which provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $4.5 billion, which expires on December 8, 2025. At June 26, 2022, no amounts were outstanding under the Revolving Credit Facility. We expect to issue debt in the future. The amount and timing of such debt will depend on a number of factors, including but not limited to maturities of our existing debt, acquisitions and strategic investments, favorable and/or acceptable interest rates and changes in corporate income tax law. Additional information regarding our outstanding debt is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt.”

[0001728949-22-000040:mdna:136]
[same as prior period, unchanged from 0001728949-22-000026:mdna:130]

[0001728949-22-000040:mdna:137]
Additional Capital Requirements. Expected working and other capital requirements are described in our 2021 Annual Report on Form 10-K in “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations.” At June 26, 2022, other than for the changes disclosed in the “Notes to Condensed Consolidated Financial Statements” and “Liquidity and Capital Resources” in this Quarterly Report, there have been no other material changes to our expected working and other capital requirements described in our 2021 Annual Report on Form 10-K.

[0001728949-22-000040:mdna:138]
29

[0001728949-22-000040:mdna:139]
Further, regulatory authorities in certain jurisdictions have investigated our business practices and instituted proceedings against us and they or other regulatory authorities may do so in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and they or others may in the future pursue, litigation, arbitration or other strategies against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, financial condition and cash flows. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” and “Risk Factors” in this Quarterly Report.

[0001728949-22-000040:mdna:140]
[same as prior period, unchanged from 0001728949-22-000026:mdna:135]

[0001728949-22-000040:mdna:141]
[same as prior period, unchanged from 0001728949-22-000026:mdna:136]

[0001728949-22-000040:mdna:142]
[same as prior period, unchanged from 0001728949-22-000026:mdna:137]

[0001728949-22-000040:mdna:143]
[same as prior period, unchanged from 0001728949-22-000026:mdna:138]

[0001728949-22-000040:mdna:144]
[same as prior period, unchanged from 0001728949-22-000026:mdna:139]

[0001728949-22-000040:mdna:145]
The COVID-19 pandemic resulted in significant economic uncertainty, significant declines in business and consumer confidence and global demand in the wireless industry (among others) and a global economic slowdown, which negatively affected our financial results over certain periods. Specifically, throughout most of calendar 2020 and into early calendar 2021, the decline in demand for smartphones and other consumer devices sold by our customers or licensees resulted in decreased demand for our integrated circuit products (which are incorporated into such devices) and a decrease in the royalties we earned on the licensing of our intellectual property (which is dependent upon the number of such devices sold that utilize our intellectual property). The emergence and spread of new variants of COVID-19, and spikes in COVID-19 cases in various geographic regions, continues to create uncertainty as to when and to what extent normal business, economic and social activity and conditions will resume.

[0001728949-22-000040:mdna:146]
The COVID-19 pandemic also caused us to modify our workforce practices, such as having the vast majority of our employees work from home. We have begun to open our offices globally, and we intend to operate in a “hybrid” working environment, meaning that the majority of our employees will have the flexibility to work remotely at least some of the time for the foreseeable future. We could be negatively affected in the future if, among others, a significant number of our employees, or employees who perform critical functions, become ill and/or are quarantined as the result of exposure to COVID-19, or if government policies restrict the ability of those employees to perform their critical functions. Further, our efforts to reopen our offices safely may not be successful, could expose our employees, customers, licensees and partners to health risks and us to associated liability, and could result in disruptions among our employees. See also the Risk Factor titled “We may not be able to attract and retain qualified employees, and our attempts to fully reopen our offices and operate under a hybrid working environment may not be successful.”

[0001728949-22-000040:mdna:147]
The COVID-19 pandemic could impact our business, results of operations and financial condition in the future as described above, and/or through delayed, reduced or cancelled customer orders; disruptions or delays in our supply chain; the inability of our customers or licensees to purchase or pay for our products or technologies; the insolvency of key suppliers, customers or licensees; delays in reporting or payments from our customers or licensees; or failures by other counterparties. The degree to which the COVID-19 pandemic impacts our future business, results of operations and financial condition will depend on future developments, which are uncertain, including but not limited to the duration of the pandemic; spikes in COVID-19 cases in various geographic regions; the emergence, spread and severity of new variants of COVID-19; the availability, adoption and efficacy of vaccines or other medical treatments for COVID-19; and government responses and other actions to limit the spread of COVID-19 or to mitigate the negative economic effects of the pandemic (including potential increases in corporate tax rates or other tax obligations to pay for stimulus and other actions that have been and may

[0001728949-22-000040:mdna:148]
30

[0001728949-22-000040:mdna:149]
in the future be taken as a result of the pandemic). We are similarly unable to predict the extent to which the pandemic impacts our customers, licensees, suppliers and other partners and their financial conditions, but adverse effects on these parties could also adversely affect us. For example, in response to rising COVID-19 infections, China recently imposed lockdowns in certain parts of the country, which had a negative impact on consumer demand for devices incorporating our products and intellectual property in the region. Finally, the COVID-19 pandemic may make it harder for management to estimate the future performance of our business. To the extent the COVID-19 pandemic adversely affects our business, results of operations and financial condition, it may also have the effect of exacerbating the other risks discussed in this “Risk Factors” section.

[0001728949-22-000040:mdna:150]
[same as prior period, unchanged from 0001728949-22-000026:mdna:143]

[0001728949-22-000040:mdna:151]
[same as prior period, unchanged from 0001728949-22-000026:mdna:144]

[0001728949-22-000040:mdna:152]
[same as prior period, unchanged from 0001728949-22-000026:mdna:145]

[0001728949-22-000040:mdna:153]
In addition, a number of our largest integrated circuit customers have developed, are developing or may develop their own integrated circuit products, or may choose our competitors’ integrated circuit products, which they have in the past utilized, currently utilize and may in the future utilize in some or all of their devices, rather than our products, which could significantly reduce the revenues we derive from these customers. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0001728949-22-000040:mdna:154]
[same as prior period, unchanged from 0001728949-22-000026:mdna:148]

[0001728949-22-000040:mdna:155]
[same as prior period, unchanged from 0001728949-22-000026:mdna:149]

[0001728949-22-000040:mdna:156]
[same as prior period, unchanged from 0001728949-22-000026:mdna:150]

[0001728949-22-000040:mdna:157]
[same as prior period, unchanged from 0001728949-22-000026:mdna:151]

[0001728949-22-000040:mdna:158]
Apple purchases our MDM (or thin modem) products, which do not include our integrated application processor technology, and which have lower revenue and margin contributions than our combined modem and application processor

[0001728949-22-000040:mdna:159]
products. Consequently, to the extent Apple takes device share from our customers who purchase our integrated modem and application processor products, our revenues and margins may be negatively impacted.

[0001728949-22-000040:mdna:160]
[same as prior period, unchanged from 0001728949-22-000026:mdna:153]

[0001728949-22-000040:mdna:161]
[same as prior period, unchanged from 0001728949-22-000026:mdna:154]

[0001728949-22-000040:mdna:162]
[same as prior period, unchanged from 0001728949-22-000026:mdna:155]

[0001728949-22-000040:mdna:163]
[same as prior period, unchanged from 0001728949-22-000026:mdna:156]

[0001728949-22-000040:mdna:164]
Certain of our largest integrated circuit customers (for example, Samsung) develop their own integrated circuit products, which they have in the past utilized, and currently utilize, in certain of their devices and may in the future utilize in some or all of their devices, rather than our products (and they have and may continue to sell their integrated circuit products to third parties, discretely or together with certain of their other products, in competition with us).

[0001728949-22-000040:mdna:165]
[same as prior period, unchanged from 0001728949-22-000026:mdna:158]

[0001728949-22-000040:mdna:166]
[same as prior period, unchanged from 0001728949-22-000026:mdna:159]

[0001728949-22-000040:mdna:167]
[same as prior period, unchanged from 0001728949-22-000026:mdna:160]

[0001728949-22-000040:mdna:168]
If some or all of our largest customers and/or the largest smartphone OEMs utilize their own integrated circuit/modem products in some or all of their devices rather than our products, our business, revenues, results of operations, cash flows and financial position could be materially adversely impacted. See also the Risk Factor titled “We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected.”

[0001728949-22-000040:mdna:169]
32

[0001728949-22-000040:mdna:170]
[same as prior period, unchanged from 0001728949-22-000026:mdna:162]

[0001728949-22-000040:mdna:171]
[same as prior period, unchanged from 0001728949-22-000026:mdna:163]

[0001728949-22-000040:mdna:172]
[same as prior period, unchanged from 0001728949-22-000026:mdna:164]

[0001728949-22-000040:mdna:173]
Political actions, including trade protection and national security policies of the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our Chinese customers or suppliers, limit, prevent or discourage certain of our Chinese customers or suppliers from transacting business with us, or make it more expensive to do so. Given our revenue concentration in China, if, due to actual, threatened or potential U.S. or Chinese government actions or policies: we were further limited in, or prohibited from, selling our integrated circuit products to Chinese OEMs; our non-Chinese OEM customers were limited in, or prohibited from, selling devices into China that incorporate our integrated circuit products; Chinese OEMs develop and use their own integrated circuit products or use our competitors’ integrated circuit products in some or all of their devices rather than our integrated circuit products; Chinese tariffs on our integrated circuit products or on devices which incorporate our integrated circuit products made purchasing such products or devices more expensive to Chinese OEMs or Chinese consumers; or our Chinese licensees delay or cease making payments of license fees they owe us, our business, revenues, results of operations, cash flows and financial position could be materially harmed. Similarly, if, due to U.S. or Chinese government actions or policies, we were limited in or prohibited from obtaining critical integrated circuit products from our suppliers in China, our business, revenues, results of operations, cash flows and financial position could be materially harmed. See also the Risk Factor titled “We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium tier devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected.”

[0001728949-22-000040:mdna:174]
[same as prior period, unchanged from 0001728949-22-000026:mdna:167]

[0001728949-22-000040:mdna:175]
[same as prior period, unchanged from 0001728949-22-000026:mdna:168]

[0001728949-22-000040:mdna:176]
[same as prior period, unchanged from 0001728949-22-000026:mdna:169]

[0001728949-22-000040:mdna:177]
[same as prior period, unchanged from 0001728949-22-000026:mdna:170]

[0001728949-22-000040:mdna:178]
[same as prior period, unchanged from 0001728949-22-000026:mdna:171]

[0001728949-22-000040:mdna:179]
However, our research, development and other investments in these new and expanded product areas, industries and applications, and corresponding technologies and products, as well as in our existing technologies and products and new technologies in mobile handsets, may not succeed because, among other reasons: we may not be issued patents on the technologies we develop; the technologies we develop may not be incorporated into relevant standards; new and expanded product areas, industries and applications beyond mobile handsets, and consumer demand therein, may not develop or grow as anticipated; we may be unable to attract or retain employees with the necessary skills in such new and expanded product areas, industries and applications; our strategies or the strategies of our customers, licensees or partners may not be successful; alternate technologies or products may be better or may reduce the advantages we anticipate from our investments; competitors’ technologies or products may be more cost effective, have more capabilities or fewer limitations or be brought to market faster than our new technologies or products; we may not be able to develop, or our competitors may have more established and/or stronger, customer, vendor, distributor or other channel relationships; and competitors may have longer operating histories in industries and applications that are new to us. We may also underestimate the costs of, or overestimate the future revenues or margins that could result from these investments, and these investments may not, or may take many years to, generate material returns.

[0001728949-22-000040:mdna:180]
[same as prior period, unchanged from 0001728949-22-000026:mdna:173]

[0001728949-22-000040:mdna:181]
[same as prior period, unchanged from 0001728949-22-000026:mdna:174]

[0001728949-22-000040:mdna:182]
[same as prior period, unchanged from 0001728949-22-000026:mdna:175]

[0001728949-22-000040:mdna:183]
[same as prior period, unchanged from 0001728949-22-000026:mdna:177]

[0001728949-22-000040:mdna:184]
[same as prior period, unchanged from 0001728949-22-000026:mdna:178]

[0001728949-22-000040:mdna:185]
Achieving the anticipated benefits of business acquisitions depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, facilities, technology, products, processes, operations (including supply and manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and

[0001728949-22-000040:mdna:186]
[same as prior period, unchanged from 0001728949-22-000026:mdna:185]

[0001728949-22-000040:mdna:187]
we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models, geographic regions, industries and applications served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of our strategic acquisitions.

[0001728949-22-000040:mdna:188]
[same as prior period, unchanged from 0001728949-22-000026:mdna:180]

[0001728949-22-000040:mdna:189]
[same as prior period, unchanged from 0001728949-22-000026:mdna:181]

[0001728949-22-000040:mdna:190]
[same as prior period, unchanged from 0001728949-22-000026:mdna:182]

[0001728949-22-000040:mdna:191]
[same as prior period, unchanged from 0001728949-22-000026:mdna:183]

[0001728949-22-000040:mdna:192]
We primarily utilize a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Other than the facilities we own that manufacture certain of our RFFE modules and RF (radio frequency) filter products, we rely on third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. There are a limited number of such third-party suppliers, and even fewer who are capable of manufacturing at the leading process technology nodes, or who are willing to operate at older process technology nodes necessary for certain of our integrated circuit products. The semiconductor manufacturing foundries that supply our products are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders.

[0001728949-22-000040:mdna:193]
[same as prior period, unchanged from 0001728949-22-000026:mdna:187]

[0001728949-22-000040:mdna:194]
[same as prior period, unchanged from 0001728949-22-000026:mdna:188]

[0001728949-22-000040:mdna:195]
[same as prior period, unchanged from 0001728949-22-000026:mdna:189]

[0001728949-22-000040:mdna:196]
[same as prior period, unchanged from 0001728949-22-000026:mdna:190]

[0001728949-22-000040:mdna:197]
[same as prior period, unchanged from 0001728949-22-000026:mdna:191]

[0001728949-22-000040:mdna:198]
[same as prior period, unchanged from 0001728949-22-000026:mdna:192]

[0001728949-22-000040:mdna:199]
[same as prior period, unchanged from 0001728949-22-000026:mdna:193]

[0001728949-22-000040:mdna:200]
[same as prior period, unchanged from 0001728949-22-000026:mdna:194]

[0001728949-22-000040:mdna:201]
[same as prior period, unchanged from 0001728949-22-000026:mdna:195]

[0001728949-22-000040:mdna:202]
[same as prior period, unchanged from 0001728949-22-000026:mdna:196]

[0001728949-22-000040:mdna:203]
[same as prior period, unchanged from 0001728949-22-000026:mdna:197]

[0001728949-22-000040:mdna:204]
[same as prior period, unchanged from 0001728949-22-000026:mdna:198]

[0001728949-22-000040:mdna:205]
[same as prior period, unchanged from 0001728949-22-000026:mdna:199]

[0001728949-22-000040:mdna:206]
[same as prior period, unchanged from 0001728949-22-000026:mdna:200]

[0001728949-22-000040:mdna:207]
[same as prior period, unchanged from 0001728949-22-000026:mdna:201]

[0001728949-22-000040:mdna:208]
[same as prior period, unchanged from 0001728949-22-000026:mdna:203]

[0001728949-22-000040:mdna:209]
We cannot guarantee that the actions of our suppliers will not cause disruptions in our operations that could harm our ability to meet our delivery obligations to our customers or increase our cost of sales. To the extent we are unable to obtain adequate supply to meet our delivery obligations, we may be obligated to make payments to our customers for such shortfalls. Recently, the global semiconductor industry experienced demand for integrated circuits that exceeded the industry’s capacity to meet that demand. Our ability to meet increased demand for our products has been and may in the future be limited due to the inability to obtain the additional manufacturing, assembly and test capacity necessary to fully meet such demand. If we are unable to fully meet customer demand, this could result in lost sales opportunities, reduced revenue growth and harm to our customer relationships. These issues may be exacerbated if customers overstate their expected demand requirements in order to procure additional supply, which could negatively impact our ability to forecast and to allocate supply appropriately among our customers. These issues may also be exacerbated with respect to our platform solutions, which already entail a great deal of complexity due to differing lead-times, technologies and suppliers for each integrated circuit product included in such solutions.

[0001728949-22-000040:mdna:210]
Additionally, we place orders with our suppliers using our and our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates. As we move to smaller geometry process technologies, the

[0001728949-22-000040:mdna:211]
manufacturing lead-time increases. As a result, the orders we place with our suppliers are generally only partially covered by commitments from our customers. If we, or our customers, overestimate demand, or if demand is impacted by factors outside of our or our customers’ control, and such demand is not covered by a binding commitment from our customers, we may experience increased excess or obsolete inventory or reserve charges, which would negatively impact our results of operations.

[0001728949-22-000040:mdna:212]
[same as prior period, unchanged from 0001728949-22-000026:mdna:206]

[0001728949-22-000040:mdna:213]
[same as prior period, unchanged from 0001728949-22-000026:mdna:207]

[0001728949-22-000040:mdna:214]
[same as prior period, unchanged from 0001728949-22-000026:mdna:208]

[0001728949-22-000040:mdna:215]
We are subject to many complex environmental, health and safety laws, regulations and rules in each jurisdiction in which we operate our manufacturing (and research and development) facilities. The regulatory landscape in these areas continues to evolve, and we anticipate additional laws, regulations and rules in the future. In particular, new, or changes in, environmental and climate change laws, regulations or rules, including relating to greenhouse gas emissions, could lead to new or additional investments in production processes and could increase environmental compliance expenditures. In addition, certain environmental laws impose strict, and in certain circumstances joint and several, liability on current or previous owners or operators of real property, or parties who arranged for hazardous substances to be sent to disposal or treatment facilities, for the cost of investigation, removal or remediation of hazardous substances. As a result, we may incur clean-up costs in connection with any such removal or remediation efforts, as well as other third-party claims in connection with contaminated sites. In addition, we could be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage. If we, or companies or facilities we acquire or have acquired, in the past failed or in the future fail to comply with any such laws and regulations, then we could incur regulatory penalties, fines and legal liabilities; suspension of production; significant compliance requirements; alteration of our manufacturing, assembly or test processes; restriction on our ability to modify or expand our facilities; damage to our reputation; and restrictions on our operations or sales. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. We cannot make assurances that we will at all times be in compliance with such laws, regulations, rules and permits. See also the risk factor titled “Our business may suffer due to the impact of, or our failure to comply with, the various existing, new or amended laws, regulations, policies or standards to which we are subject.”

[0001728949-22-000040:mdna:216]
[same as prior period, unchanged from 0001728949-22-000026:mdna:212]

[0001728949-22-000040:mdna:217]
We have manufacturing facilities in Asia and Europe. If tsunamis, flooding, earthquakes, volcanic eruptions, drought or other natural disasters, effects of climate change or geopolitical conflicts, were to damage, destroy or disrupt our manufacturing facilities, it could disrupt our operations, cease or delay production and shipments of inventory and result in costly repairs, replacements or other costs and lost business. In addition, natural disasters, effects of climate change or geopolitical conflicts may result in disruptions in transportation, distribution channels and supply chains and significant

[0001728949-22-000040:mdna:218]
increases in the prices of raw materials. Further, health crises, including epidemics or pandemics, such as the COVID-19 pandemic, and government and business responses thereto, could affect our manufacturing facilities, including by resulting in quarantines and/or closures, which would result in disruptions to and potential closures of our manufacturing operations. Our manufacturing operations could also be disrupted by cyber-attacks on our IT systems, as described in the Risk Factor below titled “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0001728949-22-000040:mdna:219]
Our manufacturing operations depend on securing raw materials, equipment and other supplies in adequate quality and quantity in a timely manner from multiple suppliers, and in some cases, we rely on a limited number of suppliers, including in some cases sole suppliers, particularly in Asia. There may be cases where supplies of raw materials, equipment and other products are interrupted or limited by natural disaster, geopolitical conflict, accident or some other event affecting a supplier or source of raw materials; supply is suspended due to quality or other issues; there is a shortage of supply due to a rapid increase in demand; and/or we or our suppliers are prohibited from utilizing certain raw materials, or products or components that incorporate such raw materials, due to government restrictions related to the countries from which such raw materials originate, and acceptable alternative suppliers, raw materials or raw materials sources are not available or not available in acceptable time frames or upon acceptable terms, among others, which could impact production and prevent us from supplying our products to our customers. If the supply-demand balance is disrupted, it may considerably increase costs of manufacturing due to increased prices we pay for raw materials. From time to time, suppliers may extend lead times, limit amounts supplied to us or increase prices due to capacity constraints or other factors. Additionally, supply and costs of raw materials, equipment and other products may be negatively impacted by trade and/or national security protection policies, such as tariffs, or actions by governments that limit or prevent us from transacting business with certain countries or companies or that limit or prevent certain companies from transacting business with us, or trade tensions, particularly with countries in Asia. Further, it may be difficult or impossible to substitute one piece of equipment for another or replace one type of material with another. A failure by our suppliers to deliver our requirements could result in disruptions to our manufacturing operations.

[0001728949-22-000040:mdna:220]
Our manufacturing processes are highly complex, require advanced and costly equipment and must be continuously modified to improve yields and performance. Difficulties in the production process can reduce yields or interrupt production, and as a result, we may not be able to deliver our products or do so in a timely, cost-effective or competitive manner. Further, to remain competitive and meet customer demand, we may be required to improve our facilities and process technologies and carry out extensive research and development, each of which may require investment of significant amounts of capital and may have a material adverse effect on our results of operations, cash flows and financial condition.

[0001728949-22-000040:mdna:221]
From time to time, we begin to purchase equipment to meet expected customer demand in advance of any purchase orders or long-term purchase commitments. Further, we typically begin manufacturing our products using our or our customers’ forecasts of demand for our products, which are based on a number of assumptions and estimates and may not be covered by long-term purchase commitments. As a result, we may incur increased inventory and manufacturing costs and/or record impairment charges to the extent anticipated sales ultimately do not materialize or are lower than expected. If we or our customers overestimate demand, or if demand is impacted by factors outside of our or our customers’ control such as the COVID-19 pandemic or trade or national security protection policies, and such demand is not covered by a binding commitment from our customers, we may experience higher inventory carrying and operating costs and/or increased excess or obsolete inventory or reserve charges, which would negatively impact our results of operations.

[0001728949-22-000040:mdna:222]
[same as prior period, unchanged from 0001728949-22-000026:mdna:219]

[0001728949-22-000040:mdna:223]
[same as prior period, unchanged from 0001728949-22-000026:mdna:220]

[0001728949-22-000040:mdna:224]
Third parties regularly attempt to gain unauthorized access to our IT systems, and many such attacks are increasingly more sophisticated. These attacks, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, exploiting vulnerabilities in hardware, software or other IT infrastructure and impersonating authorized users, among others. We are also subject to ransom-style cyber-attacks, which could impact our IT systems and cause widespread disruption to our business, including our manufacturing operations, and expose our confidential or propriety information. Third parties that store and/or process our confidential information, or that provide products, software or services used in our IT infrastructure (including applications), may be subject to similar attacks, which could also result in malware being introduced into our IT infrastructure, e.g., through the third parties’ software and/or software updates. Such attacks could result in the misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our IT systems. We believe that we have a robust cybersecurity

[0001728949-22-000040:mdna:225]
38

[0001728949-22-000040:mdna:226]
program that is aligned to international cybersecurity frameworks, and that we leverage industry best practices across people, processes and technologies in an attempt to mitigate cybersecurity threats. However, we can not anticipate, detect, repel or implement fully effective preventative measures against all cybersecurity threats, particularly because the techniques used are increasingly sophisticated and constantly evolving. As part of our cybersecurity program, we seek to identify and remediate vulnerabilities in our IT systems and software (including third party software used in our IT systems) that could be exploited by hackers or other malicious actors. However, we may not be aware of all such vulnerabilities, and we may fail to identify and/or remediate such vulnerabilities before they are exploited. Attempts to gain unauthorized access to our IT systems or other attacks have in the past, in certain instances and to certain degrees, been successful (but have not caused significant harm), and may in the future be successful, and in some cases, we might be unaware of an incident or its magnitude and effects.

[0001728949-22-000040:mdna:227]
[same as prior period, unchanged from 0001728949-22-000026:mdna:222]

[0001728949-22-000040:mdna:228]
[same as prior period, unchanged from 0001728949-22-000026:mdna:223]

[0001728949-22-000040:mdna:229]
[same as prior period, unchanged from 0001728949-22-000026:mdna:224]

[0001728949-22-000040:mdna:230]
[same as prior period, unchanged from 0001728949-22-000026:mdna:225]

[0001728949-22-000040:mdna:231]
[same as prior period, unchanged from 0001728949-22-000026:mdna:226]

[0001728949-22-000040:mdna:232]
Our future success depends upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. In addition, in order to extend our business into certain new and expanded product areas and industries and applications beyond mobile handsets, we need to attract, retain and motivate engineering and other technical personnel with specialized skills in these areas, and these skills are in high demand among our competitors. The market for employees in our industry is extremely competitive, and competitors for talent, particularly engineering talent, increasingly attempt to hire, and to varying degrees have been successful in hiring, our employees or employment candidates, including by establishing or

[0001728949-22-000040:mdna:233]
expanding local offices near our headquarters in San Diego, California. Further, the increased availability of remote working arrangements, largely driven by the COVID-19 pandemic, has expanded the pool of companies that can compete for our employees and employment candidates. A number of such competitors for talent are significantly larger than us and/or offer compensation in excess of what we are able to offer or other benefits that we generally do not offer, such as the ability to permanently work from home. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller. If we are unable to attract and retain qualified employees, our business may be harmed.

[0001728949-22-000040:mdna:234]
[same as prior period, unchanged from 0001728949-22-000026:mdna:228]

[0001728949-22-000040:mdna:235]
[same as prior period, unchanged from 0001728949-22-000026:mdna:229]

[0001728949-22-000040:mdna:236]
[same as prior period, unchanged from 0001728949-22-000026:mdna:230]

[0001728949-22-000040:mdna:237]
[same as prior period, unchanged from 0001728949-22-000026:mdna:231]

[0001728949-22-000040:mdna:238]
Our patent license agreements in effect that generate a significant portion of our licensing revenues are effective for a specified term. To receive royalties after the expiration date of the specified term, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. We might not be able to extend or modify license agreements, or enter into new license agreements, in the future without negatively affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. In some circumstances, we may extend, modify or enter into new license agreements as a result of arbitration or litigation, and terms imposed by arbitrators or courts may be less favorable to us than existing terms, and may impact the financial or other terms of license agreements not subject to the litigation or arbitration. If there is a delay in extending, modifying or entering into a new license agreement with a licensee, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such licensees.

[0001728949-22-000040:mdna:239]
[same as prior period, unchanged from 0001728949-22-000026:mdna:234]

[0001728949-22-000040:mdna:240]
From time to time, companies initiate various strategies to attempt to negotiate, renegotiate, reduce and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity or unenforceability of our patents or licenses, alleging that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or alleging some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding (and/or the plain language) of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, seeking to impose some form of compulsory licensing or weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) attempts by licensees to shift their royalty obligation to their suppliers in order to lower the wholesale (i.e., licensee’s) selling price on which the royalty is calculated.

[0001728949-22-000040:mdna:241]
In addition, certain licensees have disputed, underreported, underpaid, not reported or not paid royalties owed to us under their license agreements or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or have delayed entering into or renewing license agreements with us for their use of our intellectual property, and they or others may engage in such behavior in the future. The fact that one or more licensees dispute, underreport, underpay, do not report or do not pay royalties owed to us may encourage other licensees to take similar

[0001728949-22-000040:mdna:242]
actions or not renew their existing license agreements, and may encourage other licensees or unlicensed companies to delay entering into, or to not enter into, new license agreements. Further, to the extent such licensees and companies increase their device share, the negative impact of their underreporting, underpayment, non-payment or non-reporting on our business, revenues, results of operations, cash flows and financial condition will be exacerbated.

[0001728949-22-000040:mdna:243]
We have been in the past and are currently subject to various litigation and/or governmental investigations and proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We may become subject to other litigation or governmental investigations or proceedings in the future. Additionally, certain of our direct and indirect customers and licensees have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. See also the Risk Factors below titled “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations” and “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings.”

[0001728949-22-000040:mdna:244]
[same as prior period, unchanged from 0001728949-22-000026:mdna:238]

[0001728949-22-000040:mdna:245]
Further, some third parties have proposed significant changes to existing intellectual property policies for implementation by SDOs and other industry organizations with the goal of significantly devaluing standard-essential patents. For example, some have put forth proposals which would require a maximum aggregate intellectual property royalty rate for the use of all standard-essential patents owned by all of the member companies to be applied to the selling price of any product implementing the relevant standard. They have further proposed that such maximum aggregate royalty rate be apportioned to each member company with standard-essential patents based upon the number of standard-essential patents held by such company. Others have proposed that injunctions should not be an available remedy for infringement of standard-essential patents and have made proposals that could severely limit damage awards and other remedies by courts for patent infringement (e.g., by limiting the base upon which the royalty rate may be applied). A number of these strategies are purportedly based on interpretations of the policies of certain SDOs concerning the licensing of patents that are or may be essential to industry standards and on our (or other companies’) alleged failure to abide by these policies.

[0001728949-22-000040:mdna:246]
Some SDOs, courts and governmental agencies have adopted, and may in the future adopt, some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party. Further, SDOs in certain countries may attempt to modify widely accepted standards and claim the resulting standard as their own.

[0001728949-22-000040:mdna:247]
[same as prior period, unchanged from 0001728949-22-000026:mdna:243]

[0001728949-22-000040:mdna:248]
[same as prior period, unchanged from 0001728949-22-000026:mdna:244]

[0001728949-22-000040:mdna:249]
As described in the Risk Factor below titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings,” we have been in the past, currently are and may in the future be subject to various governmental investigations and/or legal proceedings challenging our patent licensing practices. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We believe that one intent of certain of these governmental investigations and legal proceedings has been to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0001728949-22-000040:mdna:250]
[same as prior period, unchanged from 0001728949-22-000026:mdna:246]

[0001728949-22-000040:mdna:251]
[same as prior period, unchanged from 0001728949-22-000026:mdna:247]

[0001728949-22-000040:mdna:252]
[same as prior period, unchanged from 0001728949-22-000026:mdna:248]

[0001728949-22-000040:mdna:253]
[same as prior period, unchanged from 0001728949-22-000026:mdna:249]

[0001728949-22-000040:mdna:254]
[same as prior period, unchanged from 0001728949-22-000026:mdna:250]

[0001728949-22-000040:mdna:255]
[same as prior period, unchanged from 0001728949-22-000026:mdna:251]

[0001728949-22-000040:mdna:256]
We have been in the past and currently are subject to various governmental investigations and proceedings. Certain of these matters are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations or findings in those matters include or have in the past included, among others: that we violate FRAND licensing commitments by refusing to grant licenses to chipset manufacturers; that our royalty rates are too high; that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions); that we unlawfully require customers to execute a patent license before we sell them cellular modem chipsets; that we have entered into exclusive agreements with chipset customers that foreclose competition; that we leverage our position in baseband chipsets in the RFFE space; and that we violate antitrust laws and engage in anticompetitive conduct and unfair methods of competition. We may become subject to other litigation or governmental investigations or proceedings in the future.

[0001728949-22-000040:mdna:257]
Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition. Depending on the matter, various remedies that could result from an unfavorable resolution include, among others: the loss of our ability to enforce one or more of our patents; injunctions; monetary damages, fines or other orders to pay money; the issuance of orders to cease certain conduct or modify our business practices, such as requiring us to reduce our royalty rates, reduce the base on which our royalties are calculated, grant patent licenses to chipset manufacturers, sell chipsets to unlicensed OEMs or modify or renegotiate some or all of our existing license agreements; and determinations that some or all of our license agreements are invalid or unenforceable. In addition, a governmental body in a particular country or region may successfully assert and impose remedies with effects that extend beyond the borders of that country or region. If some or all of our license agreements are declared invalid or unenforceable and/or we are required to renegotiate these license agreements, we may not receive, or may not be able to recognize, some or any licensing or royalty revenues under the impacted license agreements unless and until we enter into new license agreements; and even licensees whose license agreements are not impacted may demand to renegotiate their agreements or invoke the dispute resolution provision in their agreements, and we may not be able to recognize some or any revenues under such agreements. The renegotiation of license agreements could result in terms

[0001728949-22-000040:mdna:258]
that are less favorable to us than existing terms, or lead to arbitration or litigation to resolve the licensing terms, which could also be less favorable to us than existing terms, and each of which could take months or possibly years. Licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations, arbitration or litigation. In addition, we may be sued for alleged overpayments of past royalties paid to us, including private antitrust actions seeking treble damages under U.S. antitrust laws. The occurrence of any of the above could have a material adverse effect on our business, revenues, results of operations, cash flows and financial condition, and our stock price could decline, possibly significantly, in which case we may have to significantly cut costs and other uses of cash, including in research and development, significantly impairing our ability to maintain product and technology leadership and invest in next generation technologies. Further, depending on the breadth and severity of the circumstances above, we may have to reduce, suspend or eliminate our capital return programs, and our ability to timely pay our indebtedness may be impacted.

[0001728949-22-000040:mdna:259]
[same as prior period, unchanged from 0001728949-22-000026:mdna:254]

[0001728949-22-000040:mdna:260]
[same as prior period, unchanged from 0001728949-22-000026:mdna:255]

[0001728949-22-000040:mdna:261]
[same as prior period, unchanged from 0001728949-22-000026:mdna:256]

[0001728949-22-000040:mdna:262]
[same as prior period, unchanged from 0001728949-22-000026:mdna:257]

[0001728949-22-000040:mdna:263]
[same as prior period, unchanged from 0001728949-22-000026:mdna:258]

[0001728949-22-000040:mdna:264]
[same as prior period, unchanged from 0001728949-22-000026:mdna:260]

[0001728949-22-000040:mdna:265]
[same as prior period, unchanged from 0001728949-22-000026:mdna:261]

[0001728949-22-000040:mdna:266]
[same as prior period, unchanged from 0001728949-22-000026:mdna:262]

[0001728949-22-000040:mdna:267]
We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, and technological and public policy changes. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape. For example, if any key supplier of technologies and intellectual property to the semiconductor industry was sold to one of our competitors, it could negatively affect our ability to

[0001728949-22-000040:mdna:268]
procure or license such technologies and intellectual property in the future, at all or upon acceptable terms, which could have wide-ranging impacts on our business and operations.

[0001728949-22-000040:mdna:269]
[same as prior period, unchanged from 0001728949-22-000026:mdna:264]

[0001728949-22-000040:mdna:270]
[same as prior period, unchanged from 0001728949-22-000026:mdna:265]

[0001728949-22-000040:mdna:271]
[same as prior period, unchanged from 0001728949-22-000026:mdna:266]

[0001728949-22-000040:mdna:272]
[same as prior period, unchanged from 0001728949-22-000026:mdna:267]

[0001728949-22-000040:mdna:273]
[same as prior period, unchanged from 0001728949-22-000026:mdna:268]

[0001728949-22-000040:mdna:274]
[same as prior period, unchanged from 0001728949-22-000026:mdna:269]

[0001728949-22-000040:mdna:275]
[same as prior period, unchanged from 0001728949-22-000026:mdna:270]

[0001728949-22-000040:mdna:276]
[same as prior period, unchanged from 0001728949-22-000026:mdna:271]

[0001728949-22-000040:mdna:277]
[same as prior period, unchanged from 0001728949-22-000026:mdna:272]

[0001728949-22-000040:mdna:278]
[same as prior period, unchanged from 0001728949-22-000026:mdna:273]

[0001728949-22-000040:mdna:279]
[same as prior period, unchanged from 0001728949-22-000026:mdna:274]

[0001728949-22-000040:mdna:280]
[same as prior period, unchanged from 0001728949-22-000026:mdna:275]

[0001728949-22-000040:mdna:281]
[same as prior period, unchanged from 0001728949-22-000026:mdna:276]

[0001728949-22-000040:mdna:282]
[same as prior period, unchanged from 0001728949-22-000026:mdna:277]

[0001728949-22-000040:mdna:283]
In addition, certain of our largest integrated circuit customers have in the past utilized, currently utilize and may in the future utilize our competitors’ integrated circuit products in some or all of their devices, rather than our products. Further, certain of those customers have developed, are developing or may develop their own integrated circuit products (effectively making them competitors), which they have in the past utilized, currently utilize and may in the future utilize in some or all of their devices, rather than our products. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

[0001728949-22-000040:mdna:284]
[same as prior period, unchanged from 0001728949-22-000026:mdna:279]

[0001728949-22-000040:mdna:285]
[same as prior period, unchanged from 0001728949-22-000026:mdna:280]

[0001728949-22-000040:mdna:286]
[same as prior period, unchanged from 0001728949-22-000026:mdna:281]

[0001728949-22-000040:mdna:287]
[same as prior period, unchanged from 0001728949-22-000026:mdna:282]

[0001728949-22-000040:mdna:288]
[same as prior period, unchanged from 0001728949-22-000026:mdna:283]

[0001728949-22-000040:mdna:289]
[same as prior period, unchanged from 0001728949-22-000026:mdna:284]

[0001728949-22-000040:mdna:290]
The use of devices containing our products to interact with untrusted systems or otherwise access untrusted content creates a risk of exposing the system hardware and software in those devices to malicious attacks. Further, security vulnerabilities in our products or the technologies we use could expose our customers, or end users of our customers’ products, to hackers or other unscrupulous third parties who develop and deploy malware that could attack our products or our customers’ products or IT infrastructure. Such attacks could result in the disruption of our customers’ businesses or the misappropriation, theft, misuse, disclosure, loss or destruction of the technology or intellectual property, or the proprietary, confidential or personal information, of our customers, their employees or the end users of our customers’ devices. While we continue to focus on this issue and take measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and applications, and increasing the risk of security failures, and techniques used to perpetrate cybersecurity attacks are increasingly sophisticated and constantly evolving. See also the Risk

[0001728949-22-000040:mdna:291]
Factor titled “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information.”

[0001728949-22-000040:mdna:292]
Our products may be responsible for critical functions in our customers’ products and networks. Failure of our products to perform to specifications, or other product defects, errors or security vulnerabilities, could lead to substantial damage to the products we sell to our customers, the devices into which our products are integrated and the end users of such devices, and, potentially, to our customers’ IT infrastructure. Such defects, errors or security vulnerabilities could give rise to significant costs, including costs related to developing solutions, recalling products, repairing or replacing defective products, writing down defective inventory, or indemnification obligations under our agreements, and could result in the loss of sales and divert the attention of our engineering personnel from our product development efforts. In addition, defects, errors or security vulnerabilities in our products could result in failure to achieve market acceptance, a loss of design wins, a shifting of business to our competitors, and litigation or regulatory action against us, and could harm our reputation, our relationships with customers and partners and our ability to attract new customers, as well as the perceptions of our brand. Other potential adverse impacts of product defects, errors or security vulnerabilities include shipment delays, write-offs of property, plant and equipment and intangible assets, and losses on unfavorable purchase commitments. In addition, defects, errors or security vulnerabilities in the products of our customers or licensees could cause a delay or decrease in demand for the products into which our products are integrated, and thus for our products.

[0001728949-22-000040:mdna:293]
[same as prior period, unchanged from 0001728949-22-000026:mdna:287]

[0001728949-22-000040:mdna:294]
[same as prior period, unchanged from 0001728949-22-000026:mdna:289]

[0001728949-22-000040:mdna:295]
[same as prior period, unchanged from 0001728949-22-000026:mdna:290]

[0001728949-22-000040:mdna:296]
[same as prior period, unchanged from 0001728949-22-000026:mdna:291]

[0001728949-22-000040:mdna:297]
[same as prior period, unchanged from 0001728949-22-000026:mdna:292]

[0001728949-22-000040:mdna:298]
Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. We cannot predict with certainty the long-term effects of any potential changes. In the United States, there is continued discussion regarding potential patent law changes, and there is current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. Further, the laws in certain foreign countries in which our patents are or may be licensed, or our products are or may be manufactured or sold, including certain countries in Asia, may

[0001728949-22-000040:mdna:299]
not protect our intellectual property rights to the same extent as the laws in the United States. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in ways that are detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-22-000040:mdna:300]
[same as prior period, unchanged from 0001728949-22-000026:mdna:294]

[0001728949-22-000040:mdna:301]
We have engaged in litigation and arbitration in the past and may need to further litigate or arbitrate in the future to enforce our contract and intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. As a result of any such litigation or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements or initiating litigation or arbitration), license terms (including but not limited to royalty rates for the use of our intellectual property) could be imposed that are less favorable to us than existing terms, and we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion.

[0001728949-22-000040:mdna:302]
Additionally, although our license agreements generally provide us with the right to audit the books and records of licensees, audits can be expensive, time consuming, incomplete and subject to dispute. Further, certain licensees may not comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements.

[0001728949-22-000040:mdna:303]
[same as prior period, unchanged from 0001728949-22-000026:mdna:298]

[0001728949-22-000040:mdna:304]
[same as prior period, unchanged from 0001728949-22-000026:mdna:299]

[0001728949-22-000040:mdna:305]
From time to time, companies have asserted, and may again assert, patent, copyright or other intellectual property claims against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation, and we are currently involved in such litigation, including those described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products were found to infringe another company’s intellectual property, we could be subject to an injunction or be required to redesign our products, or to license such intellectual property or pay damages or other compensation to such other company (any of which could be costly). If we are unable to redesign our products, license such intellectual property used in our products or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling our products. Similarly, our suppliers could be found to infringe another company’s intellectual property, and such suppliers could then be enjoined from providing products or services to us.

[0001728949-22-000040:mdna:306]
In any potential dispute involving us and another company’s patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products sold by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel and/or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-22-000040:mdna:307]
We may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (or on the sale of our customers’ devices using such products) or the issuance of orders to cease certain conduct or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing corresponding declines in our chipset or licensing revenues.

[0001728949-22-000040:mdna:308]
[same as prior period, unchanged from 0001728949-22-000026:mdna:303]

[0001728949-22-000040:mdna:309]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe that we will continue to see, customers request that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of our products’ source code and may expose our related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of that software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Furthermore, in the course of product development, we may make contributions to third-party open source projects that could subject our intellectual property to adverse licensing conditions. For example, to encourage the growth of a software ecosystem that is interoperable with our products, we may need to contribute certain implementations under the open source licensing terms that govern such projects, which may adversely impact our associated intellectual property. Developing open source products, while adequately protecting the intellectual property upon which our licensing program depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental and third-party scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products.

[0001728949-22-000040:mdna:310]
[same as prior period, unchanged from 0001728949-22-000026:mdna:306]

[0001728949-22-000040:mdna:311]
[same as prior period, unchanged from 0001728949-22-000026:mdna:307]

[0001728949-22-000040:mdna:312]
The semiconductor industry is highly cyclical, volatile, subject to downturns and characterized by constant and rapid technological change, price erosion, evolving technical standards, frequent new product introductions, short product life cycles and fluctuations in product supply and demand. Periods of downturns have been characterized by diminished demand for end-user products, high inventory levels, excess or obsolete inventory adjustments or reserves, underutilization of manufacturing capacity, changes in revenue mix and erosion of average selling prices. We expect our business to continue to be subject to such cyclical downturns. Consequently, our revenues may decline, and our results of operations and financial condition may be adversely impacted.

[0001728949-22-000040:mdna:313]
[same as prior period, unchanged from 0001728949-22-000026:mdna:313]

[0001728949-22-000040:mdna:314]
[same as prior period, unchanged from 0001728949-22-000026:mdna:309]

[0001728949-22-000040:mdna:315]
Our stock price and financial results have fluctuated in the past and are likely to fluctuate in the future. Factors that may have a significant impact on the market price of our stock and our financial results include those identified above and throughout this Risk Factors section, as well as: volatility of the stock market in general and technology and semiconductor companies in particular; announcements concerning us, our suppliers, our competitors or our customers or licensees; and variations between our actual financial results or guidance and expectations of securities analysts or investors, among others. In the past, securities class action litigation has been brought against companies following periods of volatility in the market price of their securities, among other reasons. We are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-22-000040:mdna:316]
[same as prior period, unchanged from 0001728949-22-000026:mdna:311]

[0001728949-22-000040:mdna:317]
Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). These include, among others, Regulations related to: patent licensing practices; antitrust, competition and competitive business practices; the flow of funds out of certain countries (e.g., China); cybersecurity; imports and exports, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; protection of intellectual property; trade and trade protection including tariffs; foreign policy and national security; environmental protection (including climate change), health and safety; supply chain, responsible sourcing, including the use of conflict minerals, and human rights; spectrum availability and license issuance; adoption of standards; taxation; privacy and data protection; labor, employment and human capital; corporate governance; public disclosure; and business conduct. Compliance with, or changes in the interpretation of, existing Regulations, the adoption of new Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, among others, could have an adverse effect on our business and results of operations. See also the Risk Factors titled “Our business may suffer as a result of adverse rulings in governmental investigations or proceedings,” “Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

[0001728949-22-000040:mdna:318]
[same as prior period, unchanged from 0001728949-22-000026:mdna:315]

[0001728949-22-000040:mdna:319]
49

[0001728949-22-000040:mdna:320]
[same as prior period, unchanged from 0001728949-22-000026:mdna:316]

[0001728949-22-000040:mdna:321]
[same as prior period, unchanged from 0001728949-22-000026:mdna:317]

[0001728949-22-000040:mdna:322]
[same as prior period, unchanged from 0001728949-22-000026:mdna:318]

[0001728949-22-000040:mdna:323]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed, as well as countries where we own intellectual property. The final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provisions and accruals. In such case, our income tax provision, results of operations and cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-22-000040:mdna:324]
[same as prior period, unchanged from 0001728949-22-000026:mdna:320]

[0001728949-22-000040:mdna:325]
[same as prior period, unchanged from 0001728949-22-000026:mdna:321]
